from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import importlib
from importlib import metadata, resources
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import time
from typing import Any, cast

from cf_service_contracts import ProviderKey, clear_provider_registry, require_provider

from .cogniflow_paths import resolve_cogniflow_root, resolve_native_env_file
from .console import ensure_console, current_console
from .provider_registry import (
    PROVIDER_REGISTRY_ENV,
    provider_registry_path_for_workspace,
)
from .reporting import (
    InstallationReport,
    StepReport,
    current_event_stream,
    current_timestamp,
)


# Keep the delegated pipeline-manager contract visible to contract drift checks.
_DEMO_PIPELINE_MANAGER_KEY = ProviderKey.PIPELINE_MANAGER


NormalizedRdfTerm = tuple[str, object]
NormalizedRdfTriple = tuple[NormalizedRdfTerm, NormalizedRdfTerm, NormalizedRdfTerm]


def _default_workspace_dir() -> Path:
    return (resolve_cogniflow_root() / "workspace").resolve()


def _emit_demo_progress(message: str) -> None:
    current_console().progress(message)
    current_event_stream().emit("progress", detail=message)


def _emit_demo_step_started(step: str, detail: str) -> None:
    current_event_stream().emit("step_started", step=step, detail=detail)


def version_at_least(candidate_version: str, minimum_version: str) -> bool:
    def _parts(value: str) -> tuple[int, ...]:
        normalized = []
        for token in value.split("."):
            digits = "".join(ch for ch in token if ch.isdigit())
            if not digits:
                break
            normalized.append(int(digits))
        return tuple(normalized)

    if not candidate_version.strip():
        return False
    try:
        return _parts(candidate_version) >= _parts(minimum_version)
    except Exception:
        return False


def installed_package_version(
    python_exe: str, package_name: str, env: dict[str, str]
) -> str:
    code = (
        "import importlib.metadata as md, sys\n"
        "name = sys.argv[1]\n"
        "try:\n"
        "    print(md.version(name))\n"
        "except Exception:\n"
        "    print('')\n"
    )
    completed = subprocess.run(
        [python_exe, "-c", code, package_name],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    if completed.returncode != 0:
        return ""
    return (
        completed.stdout.strip().splitlines()[-1].strip()
        if completed.stdout.strip()
        else ""
    )


def expected_opcua_failure(text: str) -> bool:
    lowered = text.lower()
    patterns = [
        "connection refused",
        "could not connect",
        "opcua",
        "opc ua",
        "opc ua read failed",
        "owner surface failed",
        "endpoint",
        "econnrefused",
    ]
    return any(pattern in lowered for pattern in patterns)


def _retryable_storage_conflict(text: str) -> bool:
    lowered = text.lower()
    return "conflict on update" in lowered or "transactioncontext error" in lowered


def _retry_demo_storage_action(
    action, *, attempts: int = 3, delay_seconds: float = 0.5
):
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return action()
        except Exception as exc:
            last_error = exc
            if attempt >= attempts or not _retryable_storage_conflict(str(exc)):
                raise
            time.sleep(delay_seconds)
    assert last_error is not None
    raise last_error


def wait_tcp_port(hostname: str, port: int, timeout_seconds: int = 30) -> bool:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((hostname, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.5)
    return False


def discover_installed_plugin_dirs(
    python_exe: str, cwd: Path, env: dict[str, str]
) -> list[str]:
    discover_code = """
from importlib import import_module, metadata
from pathlib import Path
import json

dirs = []
seen_pkgs = set()
seen_dirs = set()
try:
    entry_points = metadata.entry_points(group='cogniflow.steps')
except Exception:
    entry_points = []

for ep in entry_points:
    module_name = ep.value.split(':')[0]
    pkg_name = module_name.split('.')[0]
    if pkg_name in seen_pkgs:
        continue
    seen_pkgs.add(pkg_name)
    try:
        module = import_module(pkg_name)
    except Exception:
        continue
    module_file = getattr(module, '__file__', None)
    if not module_file:
        continue
    bin_dir = Path(module_file).resolve().parent / 'bin'
    if not bin_dir.exists():
        continue
    resolved = str(bin_dir)
    if resolved in seen_dirs:
        continue
    seen_dirs.add(resolved)
    dirs.append(resolved)

print(json.dumps(dirs))
"""
    completed = subprocess.run(
        [python_exe, "-c", discover_code],
        cwd=str(cwd),
        env=env,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return []
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return []
    try:
        decoded = json.loads(lines[-1])
    except json.JSONDecodeError:
        return []
    return [str(item) for item in decoded if isinstance(item, str)]


def find_latest_data_hive_run(
    workspace_root: Path, pipeline_id: str
) -> dict[str, Any] | None:
    datahive_runs = require_provider(ProviderKey.DATAHIVE_RUNS)
    return datahive_runs.find_latest_run(workspace_root, pipeline_id)


def load_native_env(
    repo_root: Path, env: dict[str, str]
) -> tuple[dict[str, str], bool]:
    native_cwd = repo_root
    native_env = resolve_native_env_file()
    if not native_env.exists():
        return env, False
    command = (
        f". '{native_env}'; "
        "Get-ChildItem Env: | Sort-Object Name | ForEach-Object { '{0}={1}' -f $_.Name, $_.Value }"
    )
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        check=False,
        capture_output=True,
        text=True,
        cwd=str(native_cwd),
        env=env,
    )
    if completed.returncode != 0:
        return env, False
    loaded = dict(env)
    for line in completed.stdout.splitlines():
        if "=" not in line:
            continue
        name, value = line.split("=", 1)
        loaded[name] = value
    return loaded, True


def _configure_demo_cli_environment(
    python_exe: str, env: dict[str, str]
) -> dict[str, str]:
    configured = dict(env)
    resolved_python = python_exe
    if not Path(resolved_python).is_file():
        discovered_python = shutil.which(python_exe, path=configured.get("PATH"))
        if not discovered_python:
            return configured
        resolved_python = discovered_python

    scripts_dir = Path(resolved_python).resolve().parent
    normalized_scripts_dir = os.path.normcase(str(scripts_dir))
    existing_path_entries = [
        entry for entry in configured.get("PATH", "").split(os.pathsep) if entry
    ]
    normalized_existing_entries = {
        os.path.normcase(entry) for entry in existing_path_entries
    }
    if normalized_scripts_dir not in normalized_existing_entries:
        configured["PATH"] = os.pathsep.join([str(scripts_dir), *existing_path_entries])

    opcua_server_names = (
        ["cf-opcua-server.exe", "cf-opcua-server"]
        if os.name == "nt"
        else ["cf-opcua-server"]
    )
    for executable_name in opcua_server_names:
        opcua_server_exe = scripts_dir / executable_name
        if opcua_server_exe.exists():
            configured["CF_OPCUA_SERVER_CMD"] = str(opcua_server_exe)
            break
    return configured


def run_python(
    python_exe: str,
    args: list[str],
    cwd: Path,
    env: dict[str, str],
    show_details: bool,
    allow_failure: bool = False,
) -> object:
    completed = current_console().run_process([python_exe, *args], cwd=cwd, env=env)
    if completed.returncode != 0 and not allow_failure:
        raise RuntimeError(f"Python command failed: {' '.join(args)}")
    return completed


def start_opcua_server(
    python_exe: str,
    cwd: Path,
    env: dict[str, str],
    *,
    port: int,
    show_details: bool,
    interval_seconds: float = 0.5,
    duration_seconds: int = 600,
) -> subprocess.Popen[str]:
    endpoint = f"opc.tcp://127.0.0.1:{port}/VirtualPhServer"
    server_cmd = env.get("CF_OPCUA_SERVER_CMD") or "cf-opcua-server"
    return subprocess.Popen(
        [
            server_cmd,
            "start",
            "VirtualPhServer",
            "--interval",
            str(interval_seconds),
            "--duration",
            str(duration_seconds),
            "--endpoint",
            endpoint,
            "--bind-endpoint",
            endpoint,
        ],
        cwd=str(cwd),
        env=env,
        stdout=None if show_details else subprocess.DEVNULL,
        stderr=None if show_details else subprocess.DEVNULL,
        text=True,
    )


def _opcua_cli_command(_python_exe: str, env: dict[str, str]) -> list[str]:
    server_cmd = str(env.get("CF_OPCUA_SERVER_CMD") or "").strip()
    if server_cmd:
        return [server_cmd]
    return ["cf-opcua-server"]


def wait_opcua_diagnose_ready(
    python_exe: str,
    cwd: Path,
    env: dict[str, str],
    *,
    endpoint: str,
    timeout_seconds: int = 30,
) -> bool:
    deadline = time.monotonic() + timeout_seconds
    command = [*_opcua_cli_command(python_exe, env), "diagnose", "--endpoint", endpoint, "--compact"]
    while time.monotonic() < deadline:
        completed = subprocess.run(
            command,
            cwd=str(cwd),
            env=env,
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode == 0:
            return True
        time.sleep(0.5)
    return False


@dataclass(frozen=True)
class RunDemoOptions:
    repo_root: Path | None
    python_exe: str
    duckdb_version: str
    native_arch: str
    auto_install_missing_prereqs: bool
    skip_native_deps: bool
    show_details: bool
    log_path: Path | None = None
    execution_mode: str = "repo"
    workspace_dir: Path | None = None
    semantics_dir: Path | None = None
    minimum_basic_io_version: str = "0.1.4"


def _ensure_basic_io_for_demo(
    options: RunDemoOptions, env: dict[str, str], report: InstallationReport
) -> dict[str, str]:
    if options.execution_mode != "distribution":
        report.steps.append(
            StepReport(
                "run_demo_basic_io",
                "skipped",
                "Repository RunDemo skips the distribution cf-basic-io version gate; demo package assets are resolved from the active environment.",
            )
        )
        return env

    installed_version = installed_package_version(
        options.python_exe, "cf-basic-io", env
    )
    if version_at_least(installed_version, options.minimum_basic_io_version):
        report.steps.append(
            StepReport(
                "run_demo_basic_io",
                "success",
                f"Using installed cf-basic-io {installed_version} for demo.",
            )
        )
        return env

    raise RuntimeError(
        f"RunDemo requires installed cf-basic-io >= {options.minimum_basic_io_version}. Current installed version: '{installed_version}'."
    )


def _demo_working_dir(options: RunDemoOptions) -> Path:
    if options.repo_root is not None:
        return options.repo_root
    if options.workspace_dir is not None:
        return options.workspace_dir
    return Path.cwd()


def _demo_workspace_dir(options: RunDemoOptions) -> Path:
    if options.workspace_dir is not None:
        return options.workspace_dir
    return _default_workspace_dir()


def _demo_semantics_dir(options: RunDemoOptions) -> Path:
    if options.semantics_dir is not None:
        return options.semantics_dir
    return _demo_workspace_dir(options) / "semantics"


def _installed_package_assets(
    *,
    context: str,
    package_name: str,
    distribution_name: str,
) -> dict[str, str]:
    distribution = metadata.distribution(distribution_name)
    package_root = Path(
        str(distribution.locate_file(Path(package_name) / "__init__.py"))
    ).resolve().parent

    installed_steps = package_root / "steps.nq"
    installed_bin = package_root / "bin"
    if not installed_steps.exists() or not installed_bin.exists():
        raise RuntimeError(
            f"{context} requires installed package assets for '{package_name}' at '{package_root}'."
        )

    return {
        "steps": installed_steps.as_posix(),
        "bin": installed_bin.as_posix(),
    }


def _module_package_assets(package_name: str) -> dict[str, str] | None:
    try:
        module = importlib.import_module(package_name)
    except Exception:
        return None

    module_file = getattr(module, "__file__", None)
    if not module_file:
        return None

    package_root = Path(str(module_file)).resolve().parent
    steps_path = package_root / "steps.nq"
    bin_path = package_root / "bin"
    if not steps_path.exists() or not bin_path.exists():
        return None
    return {
        "steps": steps_path.as_posix(),
        "bin": bin_path.as_posix(),
    }


def _resolve_distribution_package_assets() -> dict[str, dict[str, str]]:
    package_map = {
        "cf_basic_io": "cf-basic-io",
        "cf_basic_signal": "cf-basic-signal",
        "cf_basic_sinks": "cf-basic-sinks",
    }
    resolved: dict[str, dict[str, str]] = {}
    for package_name, distribution_name in package_map.items():
        resolved[package_name] = _installed_package_assets(
            context="Distribution RunDemo",
            package_name=package_name,
            distribution_name=distribution_name,
        )
    return resolved


def _resolve_repo_package_assets(repo_root: Path) -> dict[str, dict[str, str]]:
    resolved: dict[str, dict[str, str]] = {}
    repo_package_roots = {
        "cf_basic_io": repo_root / "sandcastle" / "cf_basic_steps" / "cf_basic_io" / "src" / "cf_basic_io",
        "cf_basic_signal": repo_root / "sandcastle" / "cf_basic_steps" / "cf_basic_signal" / "src" / "cf_basic_signal",
        "cf_basic_sinks": repo_root / "sandcastle" / "cf_basic_steps" / "cf_basic_sinks" / "src" / "cf_basic_sinks",
    }
    for package_name, distribution_name in (
        ("cf_basic_io", "cf-basic-io"),
        ("cf_basic_signal", "cf-basic-signal"),
        ("cf_basic_sinks", "cf-basic-sinks"),
    ):
        module_assets = _module_package_assets(package_name)
        if module_assets is not None:
            resolved[package_name] = module_assets
            continue

        source_root = repo_package_roots[package_name]
        source_steps = source_root / "steps.nq"
        source_bin = source_root / "bin"
        if source_steps.exists() and source_bin.exists():
            resolved[package_name] = {
                "steps": source_steps.as_posix(),
                "bin": source_bin.as_posix(),
            }
            continue

        resolved[package_name] = _installed_package_assets(
            context="Repository RunDemo",
            package_name=package_name,
            distribution_name=distribution_name,
        )
    return resolved


def _load_packaged_demo_texts() -> tuple[str, str]:
    pipeline_text = (
        resources.files("cf_setup")
        .joinpath("demo", "opcua_fifo_avg_to_duckdb_parquet_triggered.nq")
        .read_text(encoding="utf-8")
    )
    invocation_text = (
        resources.files("cf_setup")
        .joinpath("demo", "invocations", "opcua_fifo_avg.endpoint_4841.invocation.nq")
        .read_text(encoding="utf-8")
    )
    return pipeline_text, invocation_text


def _normalize_distribution_demo_pipeline(
    pipeline_text: str,
    workspace_dir: Path,
    package_assets: dict[str, dict[str, str]],
) -> str:
    normalized_lines: list[str] = []
    for line in pipeline_text.splitlines():
        if (
            "n1_binding_endpoint" in line
            and "https://cogniflow.odea-project.org/cf#value" in line
        ):
            normalized_lines.append(
                line.replace(
                    "opc.tcp://127.0.0.1:4840/VirtualPhServer",
                    "opc.tcp://127.0.0.1:4841/VirtualPhServer",
                )
            )
            continue
        if (
            "n4_binding_windowSize" in line or "n9_binding_windowSize" in line
        ) and "https://cogniflow.odea-project.org/cf#value" in line:
            normalized_lines.append(
                line.replace(
                    '"5"^^<http://www.w3.org/2001/XMLSchema#integer>',
                    '"1"^^<http://www.w3.org/2001/XMLSchema#integer>',
                )
            )
            continue
        if "cf#runner/engineDurationSeconds" in line:
            normalized_lines.append(
                line.replace(
                    '"20.0"^^<http://www.w3.org/2001/XMLSchema#double>',
                    '"5.0"^^<http://www.w3.org/2001/XMLSchema#double>',
                )
            )
            continue
        if (
            "n7_binding_baseDir" in line
            and "https://cogniflow.odea-project.org/cf#value" in line
        ):
            normalized_lines.append(
                line.replace('"./workspace"', f'"{workspace_dir.as_posix()}"')
            )
            continue
        if "cf#stepsPath" in line:
            for package_name, assets in package_assets.items():
                if package_name in line:
                    normalized_lines.append(
                        line[: line.index('"')] + f"\"{assets['steps']}\"  ."
                    )
                    break
            else:
                normalized_lines.append(line)
            continue
        if "cf#pluginPath" in line:
            for package_name, assets in package_assets.items():
                if package_name in line:
                    normalized_lines.append(
                        line[: line.index('"')] + f"\"{assets['bin']}\"  ."
                    )
                    break
            else:
                normalized_lines.append(line)
            continue
        normalized_lines.append(line)
    return "\n".join(normalized_lines) + "\n"


def _resolve_distribution_demo_documents(
    options: RunDemoOptions, report: InstallationReport
) -> tuple[Path, Path]:
    workspace_dir = _demo_workspace_dir(options)
    demo_root = workspace_dir / "_cf_setup_demo"
    invocation_root = demo_root / "invocations"
    invocation_root.mkdir(parents=True, exist_ok=True)
    package_assets = _resolve_distribution_package_assets()
    pipeline_text, invocation_text = _load_packaged_demo_texts()

    pipeline_document = demo_root / "opcua_fifo_avg_to_duckdb_parquet_triggered.nq"
    invocation_document = invocation_root / "opcua_fifo_avg.endpoint_4841.invocation.nq"
    pipeline_document.write_text(
        _normalize_distribution_demo_pipeline(
            pipeline_text,
            workspace_dir,
            package_assets,
        ),
        encoding="utf-8",
    )
    invocation_document.write_text(invocation_text, encoding="utf-8")
    report.notes.append(
        f"RunDemo distribution resources staged from packaged cf_setup demo assets into {demo_root}."
    )
    return pipeline_document, invocation_document


def _resolve_repo_demo_documents(
    options: RunDemoOptions, report: InstallationReport
) -> tuple[Path, Path]:
    if options.repo_root is None:
        raise RuntimeError("Repository RunDemo requires a repo root.")

    workspace_dir = _demo_workspace_dir(options)
    demo_root = workspace_dir / "_cf_setup_demo"
    invocation_root = demo_root / "invocations"
    invocation_root.mkdir(parents=True, exist_ok=True)
    package_assets = _resolve_repo_package_assets(options.repo_root)
    pipeline_text, invocation_text = _load_packaged_demo_texts()

    pipeline_document = demo_root / "opcua_fifo_avg_to_duckdb_parquet_triggered.nq"
    invocation_document = invocation_root / "opcua_fifo_avg.endpoint_4841.invocation.nq"
    pipeline_document.write_text(
        _normalize_distribution_demo_pipeline(
            pipeline_text,
            workspace_dir,
            package_assets,
        ),
        encoding="utf-8",
    )
    invocation_document.write_text(invocation_text, encoding="utf-8")
    report.notes.append(
        f"RunDemo repository resources staged from packaged cf_setup demo assets into {demo_root}."
    )
    return pipeline_document, invocation_document


def _demo_run_request_payload() -> dict[str, object]:
    return {}


def _demo_invocation_document(
    pipeline_id: str, *, opcua_port: int
) -> dict[str, object]:
    endpoint = f"opc.tcp://127.0.0.1:{opcua_port}/VirtualPhServer"
    return {
        "@context": {
            "cf": "https://cogniflow.odea-project.org/cf#",
            "schema": "https://schema.org/",
        },
        "@graph": [
            {
                "@id": f"pipe:{pipeline_id}_invocation",
                "@type": "cf:PipelineInvocation",
                "cf:invokesPipeline": {"@id": f"pipe:{pipeline_id}"},
                "cf:overridesEntryPoint": [
                    {"@id": f"pipe:{pipeline_id}_invocation_override_n1"},
                    {"@id": f"pipe:{pipeline_id}_invocation_override_n4"},
                    {"@id": f"pipe:{pipeline_id}_invocation_override_n9"},
                ],
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n1",
                "@type": "cf:EntryPointOverride",
                "cf:targetsNode": {"@id": f"pipe:{pipeline_id}/n1"},
                "cf:overrideSettings": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n1_settings"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n1_settings",
                "@type": "schema:StructuredValue",
                "schema:additionalProperty": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n1_property_endpoint"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n1_property_endpoint",
                "@type": "schema:PropertyValue",
                "schema:propertyID": "endpoint",
                "schema:value": endpoint,
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n4",
                "@type": "cf:EntryPointOverride",
                "cf:targetsNode": {"@id": f"pipe:{pipeline_id}/n4"},
                "cf:overrideSettings": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n4_settings"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n4_settings",
                "@type": "schema:StructuredValue",
                "schema:additionalProperty": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n4_property_window_size"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n4_property_window_size",
                "@type": "schema:PropertyValue",
                "schema:propertyID": "windowSize",
                "schema:value": 1,
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n9",
                "@type": "cf:EntryPointOverride",
                "cf:targetsNode": {"@id": f"pipe:{pipeline_id}/n9"},
                "cf:overrideSettings": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n9_settings"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n9_settings",
                "@type": "schema:StructuredValue",
                "schema:additionalProperty": {
                    "@id": f"pipe:{pipeline_id}_invocation_override_n9_property_window_size"
                },
            },
            {
                "@id": f"pipe:{pipeline_id}_invocation_override_n9_property_window_size",
                "@type": "schema:PropertyValue",
                "schema:propertyID": "windowSize",
                "schema:value": 1,
            },
        ],
    }


def _write_demo_invocation_document(
    path: Path, pipeline_id: str, *, opcua_port: int
) -> Path:
    from rdflib import Dataset

    document = _demo_invocation_document(pipeline_id, opcua_port=opcua_port)
    dataset = Dataset()
    dataset.parse(data=json.dumps(document), format="json-ld")
    payload = dataset.serialize(format="nquads")
    if isinstance(payload, bytes):
        payload = payload.decode("utf-8")
    path.write_text(payload, encoding="utf-8")
    return path


def _retryable_invocation_failure(text: str) -> bool:
    return (
        expected_opcua_failure(text)
        or "Execution failed for node ex:n5" in text
        or "Execution failed for node ex:n10" in text
        or "Execution failed for node pipe:opcua_fifo_avg_to_duckdb_parquet_triggered/n1"
        in text
    )


def _retryable_manager_timeout(text: str) -> bool:
    lowered = str(text or "").strip().lower()
    return "timed out" in lowered or "timeout" in lowered


@contextmanager
def _temporary_environment(updates: dict[str, str]):
    sentinel = object()
    previous: dict[str, object] = {}
    for key, value in updates.items():
        previous[key] = os.environ.get(key, sentinel)
        os.environ[key] = value
    try:
        yield
    finally:
        for key, value in previous.items():
            if value is sentinel:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)


def _normalized_nquads_lines(text: str) -> tuple[str, ...]:
    return tuple(sorted(line.strip() for line in text.splitlines() if line.strip()))


def _normalize_demo_literal_text(value: str) -> str:
    if (
        os.name == "nt"
        and len(value) >= 3
        and value[0].isalpha()
        and value[1] == ":"
        and value[2] in ("/", "\\")
    ):
        return value[0].lower() + value[1:]
    return value


def _normalize_rdf_term(term: object) -> tuple[str, object]:
    from rdflib import Literal

    if isinstance(term, Literal):
        native = term.toPython()
        if isinstance(native, str):
            return ("literal", _normalize_demo_literal_text(native))
        return ("literal", native)
    return ("term", str(term))


def _parse_rdf_triples(text: str) -> set[NormalizedRdfTriple]:
    from rdflib import Dataset, Graph

    dataset = Dataset()
    try:
        dataset.parse(data=text, format="nquads")
        triples = {
            (
                _normalize_rdf_term(subj),
                _normalize_rdf_term(pred),
                _normalize_rdf_term(obj),
            )
            for subj, pred, obj, _ in dataset.quads((None, None, None, None))
        }
        if triples:
            return triples
    except Exception:
        pass

    graph = Graph()
    try:
        graph.parse(data=text, format="nt")
    except Exception:
        graph.parse(data=text, format="xml")
    return {
        (_normalize_rdf_term(subj), _normalize_rdf_term(pred), _normalize_rdf_term(obj))
        for subj, pred, obj in graph.triples((None, None, None))
    }


def _nquads_documents_match(left: str, right: str) -> bool:
    try:
        return _parse_rdf_triples(left) == _parse_rdf_triples(right)
    except Exception:
        return _normalized_nquads_lines(left) == _normalized_nquads_lines(right)


def _resolve_demo_pipeline_state(
    *,
    pipeline_id: str,
    pipeline_document: Path,
    semantics_dir: Path,
) -> tuple[bool, bool]:
    try:
        with _temporary_environment({"CF_SEMANTICS_DIR": str(semantics_dir)}):
            bootstrap = require_provider(ProviderKey.SETUP_BOOTSTRAP)
            current_revision = bootstrap.get_pipeline_revision_nquads(pipeline_id)
            state_rows = bootstrap.list_pipeline_state_rows()
    except Exception:
        return False, False

    if not current_revision:
        return False, False

    desired_revision = pipeline_document.read_text(encoding="utf-8")
    revision_matches = _nquads_documents_match(current_revision, desired_revision)
    state_initialized = any(
        isinstance(row, dict)
        and str(row.get("pipeline_id") or "").strip() == pipeline_id
        for row in state_rows
    )
    return revision_matches, state_initialized


def _runtime_pipeline_id(value: str) -> str:
    text = str(value or "").strip()
    if text.startswith("pipe:"):
        return text.split(":", 1)[1]
    return text


def _wait_for_demo_evidence(
    workspace_dir: Path, pipeline_id: str, timeout_seconds: int = 20
) -> dict[str, str] | None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        evidence = find_latest_data_hive_run(workspace_dir, pipeline_id)
        if (
            evidence
            and evidence["manifest_status"] == "committed"
            and evidence["parquet_files"]
        ):
            return evidence
        time.sleep(1)
    return find_latest_data_hive_run(workspace_dir, pipeline_id)


def _resolve_demo_pipeline_manager(*, timeout_seconds: float = 60.0) -> Any:
    provider = require_provider(_DEMO_PIPELINE_MANAGER_KEY)
    if hasattr(provider, "timeout"):
        provider.timeout = max(float(timeout_seconds), 0.1)
    return provider


def _restart_pipeline_manager_daemon(*, timeout_seconds: float = 180.0) -> Any:
    pipeline_manager = _resolve_demo_pipeline_manager(timeout_seconds=timeout_seconds)
    try:
        pipeline_manager.stop_daemon()
    except Exception:
        pass
    pipeline_manager = _resolve_demo_pipeline_manager(timeout_seconds=timeout_seconds)
    pipeline_manager.ensure_daemon(timeout=timeout_seconds)
    return pipeline_manager


def _stop_pipeline_manager_daemon(*, timeout_seconds: float = 60.0) -> None:
    pipeline_manager = _resolve_demo_pipeline_manager(timeout_seconds=timeout_seconds)
    try:
        pipeline_manager.stop_daemon()
    except Exception:
        pass


def _wait_for_demo_run_terminal_status(
    pipeline_manager: Any,
    *,
    pipeline_id: str,
    run_id: str,
    timeout_seconds: float = 90.0,
    poll_interval_seconds: float = 0.5,
) -> tuple[dict[str, Any] | None, str | None]:
    deadline = time.monotonic() + timeout_seconds
    selected_run: dict[str, Any] | None = None
    last_timeout_error: str | None = None
    while time.monotonic() < deadline:
        try:
            snapshot_getter = getattr(
                pipeline_manager, "get_runtime_snapshot", None
            ) or getattr(pipeline_manager, "snapshot", None)
            if not callable(snapshot_getter):
                raise RuntimeError("Pipeline manager does not support runtime snapshots.")
            snapshot = snapshot_getter(pipeline_id, selected_run_id=run_id)
        except Exception as exc:
            detail = str(exc).strip()
            if not _retryable_manager_timeout(detail):
                raise
            last_timeout_error = detail or "timed out"
            time.sleep(poll_interval_seconds)
            continue
        selected = snapshot.get("selected_run") if isinstance(snapshot, dict) else None
        if isinstance(selected, dict):
            selected_run = selected
            status = str(selected.get("status") or "").strip().lower()
            if status in {"succeeded", "failed", "stopped"}:
                return selected_run, last_timeout_error
        time.sleep(poll_interval_seconds)
    return selected_run, last_timeout_error


def _ensure_live_semantics_backend() -> dict[str, Any]:
    semantics_store = cast(Any, require_provider(ProviderKey.SEMANTICS_STORE))
    runtime = dict(semantics_store.ensure_dataset() or {})
    backend_kind = str(runtime.get("backend_kind") or "").strip()
    if backend_kind != "jena_fuseki_tdb2":
        raise RuntimeError(
            "RunDemo requires managed Jena Fuseki for semantics runtime, "
            f"but backend_kind is '{backend_kind or 'unknown'}'."
        )
    if not bool(runtime.get("service_managed")) or not bool(
        runtime.get("service_running")
    ):
        raise RuntimeError("RunDemo requires a running managed Fuseki service.")
    if not bool(runtime.get("service_endpoint_reachable")) or not bool(
        runtime.get("dataset_ready")
    ):
        raise RuntimeError(
            "RunDemo requires a reachable, ready Fuseki-backed semantics dataset."
        )
    return runtime


def execute_run_demo(options: RunDemoOptions, report: InstallationReport) -> None:
    with ensure_console(show_details=options.show_details, log_path=options.log_path):
        overall_started_at = current_timestamp()
        env = dict(os.environ)
        env = _ensure_basic_io_for_demo(options, env, report)
        if options.repo_root is not None:
            env, _ = load_native_env(options.repo_root, env)
        env = _configure_demo_cli_environment(options.python_exe, env)
        env.setdefault("CF_OPCUA_READER_TIMEOUT_SECONDS", "10.0")

        working_dir = _demo_working_dir(options)
        workspace_dir = _demo_workspace_dir(options)
        semantics_dir = _demo_semantics_dir(options)
        env[PROVIDER_REGISTRY_ENV] = str(
            provider_registry_path_for_workspace(workspace_dir)
        )

        _emit_demo_progress("Preparing demo resources")
        _emit_demo_step_started("run_demo_prepare", "Preparing demo resources")
        prepare_started_at = current_timestamp()
        if options.execution_mode == "distribution":
            pipeline_document, invocation_document = (
                _resolve_distribution_demo_documents(options, report)
            )
        else:
            pipeline_document, invocation_document = _resolve_repo_demo_documents(
                options, report
            )

        plugin_dirs = discover_installed_plugin_dirs(
            options.python_exe, working_dir, env
        )
        report.notes.append(
            f"RunDemo discovered {len(plugin_dirs)} installed plugin bin directorie(s)."
        )
        semantics_dir.mkdir(parents=True, exist_ok=True)
        report.steps.append(
            StepReport.completed(
                "run_demo_prepare",
                "success",
                f"Prepared demo resources for {options.execution_mode} mode.",
                started_at=prepare_started_at,
                ended_at=current_timestamp(),
            )
        )

        _emit_demo_progress("Preparing pipeline")
        _emit_demo_step_started("run_demo_pipeline", "Preparing pipeline")
        pipeline_started_at = current_timestamp()
        clear_provider_registry()
        bootstrap = require_provider(ProviderKey.SETUP_BOOTSTRAP)
        pipeline_id = _runtime_pipeline_id(
            bootstrap.derive_pipeline_id_from_document(pipeline_document)
        )
        if not pipeline_id:
            raise RuntimeError("Derived pipeline id is empty for demo pipeline.")

        env_updates = {
            "CF_SEMANTICS_DIR": str(semantics_dir),
            PROVIDER_REGISTRY_ENV: str(
                provider_registry_path_for_workspace(workspace_dir)
            ),
        }
        for key in ("CF_OPCUA_READER_TIMEOUT_SECONDS", "CF_OPCUA_SERVER_CMD", "PATH"):
            value = env.get(key)
            if value:
                env_updates[key] = value

        pipeline_actions: list[str] = []
        with _temporary_environment(env_updates):
            _stop_pipeline_manager_daemon()
            semantics_runtime = _ensure_live_semantics_backend()
            report.notes.append(
                "RunDemo semantics runtime: "
                + json.dumps(
                    {
                        "backend_kind": semantics_runtime.get("backend_kind"),
                        "runtime_source_mode": semantics_runtime.get(
                            "runtime_source_mode"
                        ),
                        "service_health": semantics_runtime.get("service_health"),
                        "fuseki_home": semantics_runtime.get("fuseki_home"),
                        "dataset_name": semantics_runtime.get("dataset_name"),
                    }
                )
            )
            clear_provider_registry()
            bootstrap = require_provider(ProviderKey.SETUP_BOOTSTRAP)
            revision_matches, state_initialized = _resolve_demo_pipeline_state(
                pipeline_id=pipeline_id,
                pipeline_document=pipeline_document,
                semantics_dir=semantics_dir,
            )

            if revision_matches:
                pipeline_actions.append("reused committed revision")
            else:
                _emit_demo_progress("Persisting pipeline revision")
                _retry_demo_storage_action(
                    lambda: bootstrap.commit_pipeline(
                        pipeline_id,
                        pipeline_document,
                        user="cf_setup",
                        message="cf_setup_run_demo",
                    )
                )
                pipeline_actions.append("committed pipeline definition")

            if revision_matches and state_initialized:
                pipeline_actions.append("reused pipeline runtime state")
            else:
                pipeline_actions.append("initialized pipeline runtime state")

        report.steps.append(
            StepReport.completed(
                "run_demo_pipeline",
                "success",
                f"{'; '.join(pipeline_actions).capitalize()} for pipeline '{pipeline_id}'.",
                started_at=pipeline_started_at,
                ended_at=current_timestamp(),
            )
        )
        _emit_demo_progress("Starting OPC UA server")
        _emit_demo_step_started("run_demo_server", "Starting OPC UA server")

        opcua_port = 4841
        server_started_at = current_timestamp()
        server_proc = start_opcua_server(
            options.python_exe,
            working_dir,
            env,
            port=opcua_port,
            show_details=options.show_details,
            duration_seconds=600,
        )
        try:
            if not wait_tcp_port("127.0.0.1", opcua_port, timeout_seconds=30):
                raise RuntimeError(
                    f"OPC UA demo server did not become ready on 127.0.0.1:{opcua_port}"
                )
            endpoint = f"opc.tcp://127.0.0.1:{opcua_port}/VirtualPhServer"
            if not wait_opcua_diagnose_ready(
                options.python_exe,
                working_dir,
                env,
                endpoint=endpoint,
                timeout_seconds=30,
            ):
                raise RuntimeError(
                    f"OPC UA demo server became reachable on 127.0.0.1:{opcua_port} but did not pass diagnose readiness checks."
                )
            report.steps.append(
                StepReport.completed(
                    "run_demo_server",
                    "success",
                    f"Started and validated OPC UA server on {endpoint}.",
                    started_at=server_started_at,
                    ended_at=current_timestamp(),
                )
            )

            _emit_demo_progress("Running invocation")
            _emit_demo_step_started("run_demo_invocation", "Running invocation")
            invocation_started_at = current_timestamp()
            max_invocation_attempts = 2
            invocation_poll_timeout_seconds = 90.0
            invocation_attempt = 0
            run_id: str | None = None
            with _temporary_environment(env_updates):
                pipeline_manager = _restart_pipeline_manager_daemon()
                while invocation_attempt < max_invocation_attempts:
                    invocation_attempt += 1
                    result = pipeline_manager.submit_run(
                        pipeline_id,
                        source="cf_setup",
                        metadata=_demo_run_request_payload(),
                    )
                    run_id = str(
                        ((result.get("triggered_run") or {}).get("run_id") or "")
                    ).strip()
                    if not run_id:
                        raise RuntimeError(
                            "Manager submit_run did not return a run_id."
                        )
                    selected_run, last_timeout_error = (
                        _wait_for_demo_run_terminal_status(
                            pipeline_manager,
                            pipeline_id=pipeline_id,
                            run_id=run_id,
                            timeout_seconds=invocation_poll_timeout_seconds,
                        )
                    )
                    status = (
                        str((selected_run or {}).get("status") or "").strip().lower()
                    )
                    if status == "succeeded":
                        break
                    failure_detail = str(
                        (selected_run or {}).get("termination_reason") or ""
                    ).strip()
                    if not failure_detail:
                        failure_detail = str(last_timeout_error or "").strip()
                    if invocation_attempt < max_invocation_attempts:
                        retry_detail = failure_detail or status or "unknown"
                        report.steps.append(
                            StepReport(
                                "run_demo_invocation",
                                "retry",
                                f"Invocation attempt {invocation_attempt} ended with status '{status or 'unknown'}' ({retry_detail}); retrying once.",
                            )
                        )
                        time.sleep(1)
                        continue
                    if not status and failure_detail:
                        raise RuntimeError(
                            "Invocation status polling did not observe a terminal run state "
                            f"within {invocation_poll_timeout_seconds:g}s on attempt {invocation_attempt}: {failure_detail}"
                        )
                    raise RuntimeError(
                        f"Invocation run failed on attempt {invocation_attempt} with status '{status or 'unknown'}'{': ' + failure_detail if failure_detail else ''}."
                    )
            report.steps.append(
                StepReport.completed(
                    "run_demo_invocation",
                    "success",
                    f"Invocation completed successfully on attempt {invocation_attempt} for run '{run_id}'.",
                    started_at=invocation_started_at,
                    ended_at=current_timestamp(),
                )
            )

            _emit_demo_progress("Validating Data Hive output")
            _emit_demo_step_started("run_demo_validate", "Validating Data Hive output")
            validate_started_at = current_timestamp()
            with _temporary_environment(env_updates):
                _stop_pipeline_manager_daemon()
                _ensure_live_semantics_backend()
                clear_provider_registry()
                pipeline_authoring = cast(
                    Any, require_provider(ProviderKey.PIPELINE_AUTHORING)
                )
                validation = dict(
                    pipeline_authoring.validate_pipeline_document(pipeline_document)
                    or {}
                )
                if not bool(validation.get("conforms")):
                    raise RuntimeError(
                        "Pipeline validation failed during RunDemo live semantics check: "
                        f"{str(validation.get('report_text') or '').strip() or 'unknown validation error'}"
                    )
            evidence = _wait_for_demo_evidence(workspace_dir, pipeline_id)
            if not evidence:
                raise RuntimeError(
                    f"latest.txt was not produced for Data Hive pipeline '{pipeline_id}'."
                )
            if evidence["manifest_status"] != "committed":
                raise RuntimeError(
                    f"manifest.json is not committed for Data Hive pipeline '{pipeline_id}'."
                )
            if not evidence["parquet_files"]:
                raise RuntimeError(
                    f"No parquet files were produced for Data Hive pipeline '{pipeline_id}'."
                )
            report.steps.append(
                StepReport.completed(
                    "run_demo_validate",
                    "success",
                    f"Validated Data Hive evidence for run '{evidence['run_id']}'.",
                    started_at=validate_started_at,
                    ended_at=current_timestamp(),
                )
            )
            report.notes.append(
                "RunDemo evidence: "
                + json.dumps(
                    {
                        "pipeline_id": pipeline_id,
                        "run_id": evidence["run_id"],
                        "manifest_path": evidence["manifest_path"],
                        "latest_path": evidence["latest_path"],
                        "parquet_files": evidence["parquet_files"],
                    }
                )
            )
            current_console().success(
                f"Demo completed successfully: pipeline_id={pipeline_id}, run_id={evidence['run_id']}, manifest={evidence['manifest_path']}"
            )
            report.steps.append(
                StepReport.completed(
                    "run_demo",
                    "success",
                    f"Demo completed for pipeline id '{pipeline_id}'.",
                    started_at=overall_started_at,
                    ended_at=current_timestamp(),
                )
            )
        finally:
            _stop_pipeline_manager_daemon()
            if server_proc.poll() is None:
                server_proc.kill()
                try:
                    server_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
