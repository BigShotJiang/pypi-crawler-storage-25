from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime


def _default_repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _resolve_repo_root(value: str | None) -> Path:
    if value and value.strip():
        return Path(value).resolve()
    return _default_repo_root()


def resolve_bootstrap_python(requested_python: str | None, repo_root: Path) -> str:
    if requested_python and requested_python.strip():
        return requested_python

    venv_python = repo_root / ".venv" / "Scripts" / "python.exe"
    if venv_python.exists():
        return str(venv_python)

    for candidate in ("python", "py"):
        resolved = shutil_which(candidate)
        if resolved is not None:
            return resolved

    raise RuntimeError("Python bootstrap interpreter not found.")


def shutil_which(name: str) -> str | None:
    paths = os.environ.get("PATH", "").split(os.pathsep)
    suffixes = [""]
    if os.name == "nt":
        suffixes = [".exe", ".cmd", ".bat", ""]
    for base in paths:
        for suffix in suffixes:
            candidate = Path(base) / f"{name}{suffix}"
            if candidate.exists():
                return str(candidate)
    return None


def ensure_venv_python(repo_root: Path, bootstrap_python: str) -> str:
    venv_python = repo_root / ".venv" / "Scripts" / "python.exe"
    if venv_python.exists():
        return str(venv_python)

    bootstrap_name = Path(bootstrap_python).name.lower()
    command = [bootstrap_python]
    if bootstrap_name in {"py", "py.exe"}:
        command.append("-3.14")
    command.extend(["-m", "venv", str(repo_root / ".venv")])
    subprocess.run(command, check=True, cwd=str(repo_root))
    if not venv_python.exists():
        raise RuntimeError("Failed to create .venv bootstrap environment.")
    return str(venv_python)


def ensure_bootstrap_dependency(python_exe: str, module_name: str, package_spec: str, repo_root: Path) -> None:
    probe = subprocess.run(
        [python_exe, "-c", f"import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('{module_name}') else 1)"],
        cwd=str(repo_root),
        check=False,
    )
    if probe.returncode == 0:
        return
    subprocess.run([python_exe, "-m", "pip", "install", package_spec], check=True, cwd=str(repo_root))


def bootstrap_pythonpath_entries(repo_root: Path) -> list[str]:
    return [
        str((repo_root / "sandcastle" / "cf_setup" / "src").resolve()),
        str((repo_root / "sandcastle" / "cf_service_contracts" / "src").resolve()),
    ]


def default_install_artifact_paths(
    repo_root: Path,
    command: str,
    output: str | None,
    log_path: str | None,
    event_path: str | None,
) -> tuple[str, str, str]:
    def _resolve_path(value: str | None, fallback: Path) -> Path:
        if not value or not value.strip():
            return fallback.resolve()
        path = Path(value)
        if not path.is_absolute():
            path = repo_root / path
        return path.resolve()

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    log_root = repo_root / ".logs" / "cf_setup"
    report = _resolve_path(output, log_root / f"{command}_{timestamp}.json")
    log = _resolve_path(log_path, log_root / f"{command}_{timestamp}.log")
    events = _resolve_path(event_path, log_root / f"{command}_{timestamp}.events.jsonl")
    report.parent.mkdir(parents=True, exist_ok=True)
    log.parent.mkdir(parents=True, exist_ok=True)
    events.parent.mkdir(parents=True, exist_ok=True)
    return str(report), str(log), str(events)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cf_setup.bootstrap", description="Bootstrap local cf_setup execution.")
    parser.add_argument("command", choices=["install", "incremental", "plan", "diagnose"])
    parser.add_argument("--repo-root")
    parser.add_argument("--python")
    parser.add_argument("--manifest")
    parser.add_argument("--output")
    parser.add_argument("--log-path")
    parser.add_argument("--event-path")
    return parser


def _with_or_replace_arg(args: list[str], flag: str, value: str) -> list[str]:
    if flag in args:
        index = args.index(flag)
        if index + 1 < len(args):
            args[index + 1] = value
            return args
    return [*args, flag, value]


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    known, passthrough = parser.parse_known_args(argv)
    repo_root = _resolve_repo_root(known.repo_root)
    bootstrap_python = resolve_bootstrap_python(known.python, repo_root)
    venv_python = ensure_venv_python(repo_root, bootstrap_python)
    ensure_bootstrap_dependency(venv_python, "packaging", "packaging>=24", repo_root)

    env = dict(os.environ)
    pythonpath_entries = bootstrap_pythonpath_entries(repo_root)
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = os.pathsep.join([*pythonpath_entries, existing_pythonpath] if existing_pythonpath else pythonpath_entries)

    command_args = list(passthrough)
    if known.command in {"install", "incremental", "plan"}:
        command_args = _with_or_replace_arg(command_args, "--repo-root", str(repo_root))
    if known.command in {"install", "incremental", "plan"}:
        if known.manifest and known.manifest.strip():
            command_args = _with_or_replace_arg(command_args, "--manifest", str(Path(known.manifest).resolve()))
        else:
            command_args = _with_or_replace_arg(
                command_args,
                "--manifest",
                str((repo_root / "sandcastle" / "cf_setup" / "src" / "cf_setup" / "install_manifest.toml").resolve()),
            )
    if known.command in {"install", "incremental"}:
        command_args = _with_or_replace_arg(command_args, "--python", venv_python)

    if known.command in {"install", "incremental"}:
        report_path, log_path, event_path = default_install_artifact_paths(
            repo_root,
            known.command,
            known.output,
            known.log_path,
            known.event_path,
        )
        command_args = _with_or_replace_arg(command_args, "--output", report_path)
        command_args = _with_or_replace_arg(command_args, "--log-path", log_path)
        command_args = _with_or_replace_arg(command_args, "--event-path", event_path)
    elif known.output and known.output.strip():
        resolved_output = Path(known.output)
        if not resolved_output.is_absolute():
            resolved_output = (repo_root / resolved_output).resolve()
        command_args = _with_or_replace_arg(command_args, "--output", str(resolved_output))

    command = [venv_python, "-m", "cf_setup", known.command, *command_args]
    completed = subprocess.run(command, cwd=str(repo_root), env=env, check=False)
    return int(completed.returncode or 0)


if __name__ == "__main__":
    raise SystemExit(main())
