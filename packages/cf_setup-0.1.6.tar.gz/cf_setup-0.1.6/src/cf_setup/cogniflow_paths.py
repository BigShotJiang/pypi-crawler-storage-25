from __future__ import annotations

import os
from pathlib import Path


def resolve_cogniflow_root() -> Path:
    env_path = os.environ.get("COGNIFLOW_HOME", "")
    if env_path:
        return Path(env_path).expanduser().resolve()
    return (Path.home() / ".cogniflow").resolve()


def resolve_workspace_dir() -> Path:
    return (resolve_cogniflow_root() / "workspace").resolve()


def resolve_tools_dir() -> Path:
    return (resolve_cogniflow_root() / "tools").resolve()


def resolve_cache_dir() -> Path:
    return (resolve_cogniflow_root() / "cache").resolve()


def resolve_native_cache_dir() -> Path:
    return (resolve_cache_dir() / "native").resolve()


def resolve_native_env_file() -> Path:
    return (resolve_native_cache_dir() / "env.ps1").resolve()


__all__ = [
    "resolve_cache_dir",
    "resolve_cogniflow_root",
    "resolve_native_cache_dir",
    "resolve_native_env_file",
    "resolve_tools_dir",
    "resolve_workspace_dir",
]
