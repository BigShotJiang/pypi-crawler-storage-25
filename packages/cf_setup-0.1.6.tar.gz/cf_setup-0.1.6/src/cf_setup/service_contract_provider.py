from __future__ import annotations

from pathlib import Path
from typing import Any

from cf_service_contracts import ProviderKey, SetupInstallRequest, SetupOrchestrationContractV1, SetupPlanRequest
from cf_service_contracts.registry import register_provider

from . import DEFAULT_MANIFEST_PATH, find_repo_root
from .installer import InstallerOptions, build_options_from_namespace, plan_installation
from .providers.windows import WindowsProvider


class SetupOrchestrationProvider:
    __slots__ = ()

    def resolve_repo_root(self) -> str | None:
        root = find_repo_root()
        return str(root) if root else None

    def default_manifest_path(self) -> str:
        return str(DEFAULT_MANIFEST_PATH)

    def plan_installation(self, request: SetupPlanRequest) -> dict[str, Any]:
        repo_root = Path(request.get('repo_root')) if request.get('repo_root') else None
        manifest_path = Path(request.get('manifest_path')) if request.get('manifest_path') else DEFAULT_MANIFEST_PATH
        profile = request.get('profile', 'full')
        execution_mode = request.get('execution_mode', 'auto')
        editable = request.get('editable', [])

        _, plan = plan_installation(
            manifest_path=manifest_path,
            repo_root=repo_root,
            profile=profile,
            editable_overrides=editable,
            execution_mode=execution_mode,
        )

        return {
            'profile': plan.profile,
            'requested_modules': list(plan.requested_modules),
            'ordered_modules': [
                {
                    'package_name': item.package_name,
                    'path': str(item.module.path),
                    'source': item.source,
                    'reason': item.reason,
                    'local_version': item.local_version,
                    'pypi_version': item.pypi_version,
                    'editable': item.source == 'editable',
                }
                for item in plan.ordered_modules
            ],
            'hooks': [
                {
                    'hook_id': hook.hook_id,
                    'action': hook.action,
                    'when': hook.when,
                }
                for hook in plan.hooks
            ],
        }

    def diagnose_prerequisites(self) -> dict[str, Any]:
        diagnostics = {tool.name: tool for tool in WindowsProvider().diagnose()}
        return {
            name: {
                'available': tool.available,
                'version': tool.version,
                'source': tool.source,
                'detail': tool.detail,
            }
            for name, tool in diagnostics.items()
        }

    def execute_install(self, request: SetupInstallRequest) -> dict[str, Any]:
        from argparse import Namespace

        args = Namespace(
            command='install',
            profile=request.get('profile', 'full'),
            mode=request.get('execution_mode', 'auto'),
            dev=False,
            repo_root=request.get('repo_root'),
            manifest=request.get('manifest_path'),
            python=request.get('python_exe'),
            editable=list(request.get('editable', [])),
            wheel_only=request.get('wheel_only', True),
            clean=request.get('clean', False),
            delete_native_deps=False,
            skip_native_deps=request.get('skip_native_deps', False),
            auto_install_missing_prereqs=request.get('auto_install_missing_prereqs', False),
            skip_engine_build=request.get('skip_engine_build', False),
            skip_web_build=request.get('skip_web_build', False),
            duckdb_version='1.4.2',
            native_arch='x64-windows-static',
            show_details=request.get('show_details', True),
            run_demo=request.get('run_demo'),
            dry_run=request.get('dry_run', False),
            output=request.get('output'),
            log_path=request.get('log_path'),
            event_path=request.get('event_path'),
        )

        options = build_options_from_namespace(args)
        return self._run_install(options)

    def _run_install(self, options: InstallerOptions) -> dict[str, Any]:
        from .installer import execute_install as do_execute_install
        return do_execute_install(options)


def provide_setup_orchestration_contract() -> SetupOrchestrationContractV1:
    provider = SetupOrchestrationProvider()
    register_provider(ProviderKey.SETUP_ORCHESTRATION, provider)
    return provider
