from __future__ import annotations

from dataclasses import dataclass
from importlib import metadata
import importlib
import json
import os
from pathlib import Path
import re
from functools import lru_cache
import site
import shutil
import stat
import subprocess
import sys
import sysconfig
import tomllib
from typing import Any
from typing import Iterable
from urllib import error, request
from urllib.parse import unquote, urlparse
from packaging.requirements import InvalidRequirement, Requirement

from . import DEFAULT_MANIFEST_PATH, DISTRIBUTION_MANIFEST_PATH, find_repo_root
from .console import activate_console, current_console
from .cogniflow_paths import resolve_cogniflow_root, resolve_native_cache_dir, resolve_native_env_file, resolve_workspace_dir
from .manifest import InstallManifest, load_manifest
from .planner import (
    InstallPlan,
    PlannedModule,
    SourceDecision,
    add_dependency_closure,
    add_incremental_scope,
    build_install_plan,
    topologically_sort,
)
from .provider_registry import PROVIDER_REGISTRY_ENV, refresh_provider_registry
from .providers.windows import WindowsProvider
from .reporting import (
    InstallationReport,
    StepReport,
    activate_event_stream,
    current_event_stream,
    current_timestamp,
    format_duration_seconds,
    timestamp_to_iso,
    write_json_report,
)
from .run_demo import RunDemoOptions, execute_run_demo


VERSION_TOKEN_RE = re.compile(r"(\d+|[A-Za-z]+)")
BLOCKED_TOOLCHAIN_RE = re.compile(r"msys64|mingw|rtools", re.IGNORECASE)
PREFERRED_CMAKE_PATH = Path(r"C:\Program Files\CMake\bin\cmake.exe")
DEFAULT_FUSEKI_VERSION = "6.0.0"
VCVARS_CANDIDATES = (
    Path(
        r"C:\Program Files\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    ),
    Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    ),
)
VSWHERE_CANDIDATES = (
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"),
    Path(r"C:\Program Files\Microsoft Visual Studio\Installer\vswhere.exe"),
)
STEP_MODULE_PREFIXES = (
    "cf-basic-dev",
    "cf-basic-io",
    "cf-basic-signal",
    "cf-basic-sinks",
)
DEMO_REQUIRED_MODULES = ("cf-basic-io", "cf-basic-signal", "cf-basic-sinks")
CRITICAL_CHANGED_PATH_PREFIXES = (
    "sandcastle/cf_setup/src/cf_setup/",
    "sandcastle/cf_setup/tests/",
)
CRITICAL_CHANGED_PATHS = {
    "sandcastle/cf_setup/src/cf_setup/bootstrap.py",
    "scripts/build_cf_pipeline_engine_v2.ps1",
    "scripts/build_cf_web_frontend.ps1",
    "scripts/setup_native_deps_v2.ps1",
    "sandcastle/cf_setup/src/cf_setup/install_manifest.toml",
}


@dataclass(frozen=True)
class ChangedModuleSelection:
    requested_modules: tuple[str, ...]
    changed_files: tuple[str, ...]
    unmatched_files: tuple[str, ...]
    critical_unmatched_files: tuple[str, ...]
    base_ref: str | None
    include_worktree_changes: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "requested_modules": list(self.requested_modules),
            "changed_files": list(self.changed_files),
            "unmatched_files": list(self.unmatched_files),
            "critical_unmatched_files": list(self.critical_unmatched_files),
            "base_ref": self.base_ref,
            "include_worktree_changes": self.include_worktree_changes,
        }


@dataclass(frozen=True)
class InstalledPackageState:
    installed: bool
    version: str | None
    editable: bool | None
    local_directory: bool | None


@dataclass(frozen=True)
class InstallerOptions:
    command_name: str
    repo_root: Path | None
    manifest_path: Path
    execution_mode: str
    profile: str
    modules: tuple[str, ...]
    python_exe: str
    editable_overrides: tuple[str, ...]
    wheel_only: bool
    clean: bool
    delete_native_deps: bool
    skip_native_deps: bool
    auto_install_missing_prereqs: bool
    skip_engine_build: bool
    skip_web_build: bool
    duckdb_version: str
    native_arch: str
    show_details: bool
    smoke: bool
    run_demo: bool | None
    dry_run: bool
    progress_mode: str = "batch"
    changed_only: bool = False
    base_ref: str | None = None
    include_worktree_changes: bool = True
    log_path: Path | None = None
    event_path: Path | None = None
    report_path: Path | None = None


def parse_version(value: str | None) -> tuple[int | str, ...]:
    if not value:
        return tuple()
    parsed: list[int | str] = []
    for token in VERSION_TOKEN_RE.findall(value):
        parsed.append(int(token) if token.isdigit() else token.lower())
    return tuple(parsed)


def read_local_version(project_root: Path) -> str | None:
    pyproject = project_root / "pyproject.toml"
    if not pyproject.exists():
        return None
    import tomllib

    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    project = data.get("project", {})
    version = project.get("version")
    return str(version) if version else None


def _normalize_decision_target_version(
    local_version: str | None, pypi_version: str | None, source: str
) -> str | None:
    if source in {"editable", "local-build"}:
        return local_version
    return pypi_version


def _is_current_cf_cli_invocation() -> bool:
    argv0 = Path(sys.argv[0]).name.lower()
    return argv0 in {"cf", "cf.exe", "cf.cmd", "cf-script.py"}


def detect_execution_mode(repo_root: Path | None, requested_mode: str) -> str:
    if requested_mode != "auto":
        return requested_mode
    return "repo" if repo_root and repo_root.exists() else "distribution"


def fetch_latest_pypi_version(package_name: str) -> str | None:
    url = f"https://pypi.org/pypi/{package_name}/json"
    try:
        with request.urlopen(url, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except error.HTTPError as exc:
        if exc.code == 404:
            return None
        raise
    return str(payload["info"]["version"])


def _git_tracked_changed_files(repo_root: Path) -> tuple[str, ...]:
    changed_files: set[str] = set()
    changed_files.update(_git_stdout_lines(repo_root, ["diff", "--name-only"]))
    changed_files.update(
        _git_stdout_lines(repo_root, ["diff", "--name-only", "--cached"])
    )
    return tuple(sorted(changed_files))


def _detect_modules_with_tracked_changes(
    manifest: InstallManifest, repo_root: Path
) -> set[str]:
    module_paths = sorted(
        (
            (_normalize_repo_relative_path(item.path), package_name)
            for package_name, item in manifest.modules.items()
        ),
        key=lambda item: len(item[0]),
        reverse=True,
    )
    changed_modules: set[str] = set()
    for changed_file in _git_tracked_changed_files(repo_root):
        for module_path, package_name in module_paths:
            if changed_file == module_path or changed_file.startswith(
                module_path + "/"
            ):
                changed_modules.add(package_name)
                break
    return changed_modules


def _should_promote_local_source(
    manifest: InstallManifest,
    module_name: str,
    dependency_name: str,
) -> bool:
    module_definition = manifest.modules[module_name]
    dependency_definition = manifest.modules[dependency_name]
    for dependency in module_definition.dependencies:
        if dependency.package_name != dependency_name:
            continue
        return dependency.kind == "compile" or (
            module_definition.native_prereqs and dependency_definition.native_prereqs
        )
    return False


def resolve_install_sources(
    manifest: InstallManifest,
    repo_root: Path,
    selected_modules: Iterable[str],
    editable_overrides: Iterable[str],
    *,
    execution_mode: str = "repo",
) -> dict[str, SourceDecision]:
    selected = tuple(selected_modules)
    override_set = {manifest.resolve_module_name(name) for name in editable_overrides}
    dirty_modules = (
        _detect_modules_with_tracked_changes(manifest, repo_root)
        if execution_mode == "repo"
        else set()
    )
    decisions: dict[str, SourceDecision] = {}
    for module_name in selected:
        definition = manifest.modules[module_name]
        local_version = (
            read_local_version(repo_root / definition.path)
            if execution_mode == "repo"
            else None
        )
        pypi_version = fetch_latest_pypi_version(definition.package_name)
        if execution_mode == "distribution":
            decisions[module_name] = SourceDecision(
                "pypi",
                "distribution mode uses published package artifacts",
                None,
                pypi_version,
            )
            continue
        if module_name in override_set:
            decisions[module_name] = SourceDecision(
                "editable", "explicit editable override", local_version, pypi_version
            )
            continue
        if module_name in dirty_modules:
            decisions[module_name] = SourceDecision(
                "editable",
                "tracked git changes detected in module path",
                local_version,
                pypi_version,
            )
            continue
        if execution_mode == "repo" and definition.web_build:
            decisions[module_name] = SourceDecision(
                "editable" if definition.editable else "local-build",
                "repo web module requires local source build",
                local_version,
                pypi_version,
            )
            continue
        if pypi_version is None:
            decisions[module_name] = SourceDecision(
                "local-build", "package not published on PyPI", local_version, None
            )
            continue
        if local_version and parse_version(local_version) > parse_version(pypi_version):
            decisions[module_name] = SourceDecision(
                "local-build",
                "local version is ahead of PyPI",
                local_version,
                pypi_version,
            )
            continue
        decisions[module_name] = SourceDecision(
            "pypi", "PyPI-first default", local_version, pypi_version
        )

    changed = True
    while changed:
        changed = False
        for module_name in selected:
            current = decisions[module_name]
            if current.source != "pypi":
                continue
            promoted_dependencies = [
                dependency.package_name
                for dependency in manifest.modules[module_name].dependencies
                if dependency.package_name in decisions
                and decisions[dependency.package_name].source
                in {"editable", "local-build"}
                and _should_promote_local_source(
                    manifest, module_name, dependency.package_name
                )
            ]
            if not promoted_dependencies:
                continue
            local_version = current.local_version or read_local_version(
                repo_root / manifest.modules[module_name].path
            )
            decisions[module_name] = SourceDecision(
                "local-build",
                "depends on local first-party compile/native module(s): "
                + ", ".join(promoted_dependencies),
                local_version,
                current.pypi_version,
            )
            changed = True
    return decisions


def _read_installed_package_state_for_planning(
    package_name: str,
) -> InstalledPackageState:
    try:
        distribution = metadata.distribution(package_name)
    except metadata.PackageNotFoundError:
        return InstalledPackageState(
            installed=False, version=None, editable=None, local_directory=None
        )

    editable: bool | None = None
    local_directory: bool | None = None
    try:
        direct_url_raw = distribution.read_text("direct_url.json")
    except Exception:
        direct_url_raw = None
    if direct_url_raw:
        try:
            direct_url = json.loads(direct_url_raw)
            dir_info = direct_url.get("dir_info", {})
            editable = bool(dir_info.get("editable", False))
            parsed_url = urlparse(str(direct_url.get("url", "")))
            local_directory = parsed_url.scheme == "file"
        except json.JSONDecodeError:
            editable = None
            local_directory = None
    return InstalledPackageState(
        installed=True,
        version=distribution.version,
        editable=editable,
        local_directory=local_directory,
    )


def _is_source_decision_satisfied(package_name: str, decision: SourceDecision) -> bool:
    installed_state = _read_installed_package_state_for_planning(package_name)
    if not installed_state.installed:
        return False
    if package_name in DEMO_REQUIRED_MODULES and not _installed_package_asset_surface_satisfied(package_name):
        return False
    if decision.source == "editable":
        if installed_state.editable is not True:
            return False
        if decision.local_version and installed_state.version != decision.local_version:
            return False
        if not _installed_package_import_surface_satisfied(package_name):
            return False
        return True
    if decision.source == "local-build":
        if installed_state.editable is True:
            return False
        if installed_state.local_directory is not True:
            return False
        if decision.local_version and installed_state.version != decision.local_version:
            return False
        if not _installed_package_import_surface_satisfied(package_name):
            return False
        return True
    if not decision.pypi_version:
        return False
    if installed_state.editable or installed_state.local_directory:
        return False
    if not _installed_package_import_surface_satisfied(package_name):
        return False
    return parse_version(installed_state.version) >= parse_version(
        decision.pypi_version
    )


def _build_incremental_plan_from_scope(
    manifest: InstallManifest,
    *,
    requested_modules: tuple[str, ...],
    scope_modules: tuple[str, ...],
    source_decisions: dict[str, SourceDecision],
) -> InstallPlan:
    ordered_names = topologically_sort(manifest, scope_modules)
    ordered_modules = tuple(
        PlannedModule(
            package_name=module_name,
            module=manifest.modules[module_name],
            source=source_decisions[module_name].source,
            reason=source_decisions[module_name].reason,
            local_version=source_decisions[module_name].local_version,
            pypi_version=source_decisions[module_name].pypi_version,
        )
        for module_name in ordered_names
    )
    selected_names = {item.package_name for item in ordered_modules}
    hooks = tuple(
        hook
        for hook in manifest.hooks
        if set(hook.requires_modules).issubset(selected_names)
        and hook.when == "post_install"
    )
    return InstallPlan(
        profile="incremental",
        requested_modules=requested_modules,
        ordered_modules=ordered_modules,
        hooks=hooks,
    )


def plan_installation(
    manifest_path: Path,
    repo_root: Path | None,
    profile: str,
    editable_overrides: Iterable[str],
    *,
    execution_mode: str = "repo",
    run_demo: bool = False,
) -> tuple[InstallManifest, InstallPlan]:
    if execution_mode == "distribution":
        effective_manifest_path = DISTRIBUTION_MANIFEST_PATH
    else:
        effective_manifest_path = manifest_path
    manifest = load_manifest(effective_manifest_path)
    from .planner import expand_profile

    expanded = expand_profile(manifest, profile)
    selected_modules = add_dependency_closure(manifest, expanded)
    if run_demo and execution_mode == "repo":
        demo_dependency_scope = add_dependency_closure(manifest, DEMO_REQUIRED_MODULES)
        selected_modules = tuple(dict.fromkeys([*selected_modules, *demo_dependency_scope]))
    source_decisions = resolve_install_sources(
        manifest,
        repo_root or Path.cwd(),
        selected_modules,
        editable_overrides,
        execution_mode=execution_mode,
    )
    plan = build_install_plan(manifest, profile, source_decisions, selected_modules)
    return manifest, plan


def plan_incremental_installation(
    manifest_path: Path,
    repo_root: Path | None,
    modules: Iterable[str],
    editable_overrides: Iterable[str],
    *,
    execution_mode: str = "repo",
    run_demo: bool = False,
    allow_empty: bool = False,
) -> tuple[InstallManifest, InstallPlan]:
    if execution_mode == "distribution":
        effective_manifest_path = DISTRIBUTION_MANIFEST_PATH
    else:
        effective_manifest_path = manifest_path
    manifest = load_manifest(effective_manifest_path)

    requested_modules = tuple(str(module) for module in modules if str(module).strip())
    if not requested_modules:
        if not allow_empty:
            raise ValueError("Incremental mode requires at least one --module value.")
        return manifest, InstallPlan(
            profile="incremental", requested_modules=(), ordered_modules=(), hooks=()
        )
    normalized_requested = tuple(
        manifest.resolve_module_name(name) for name in requested_modules
    )
    selected_modules = add_incremental_scope(manifest, normalized_requested)
    effective_editable_overrides = tuple(editable_overrides)
    full_dependency_scope = add_dependency_closure(manifest, normalized_requested)
    if run_demo and execution_mode == "repo":
        demo_dependency_scope = add_dependency_closure(manifest, DEMO_REQUIRED_MODULES)
        full_dependency_scope = tuple(
            dict.fromkeys([*full_dependency_scope, *demo_dependency_scope])
        )
    full_source_decisions = resolve_install_sources(
        manifest,
        repo_root or Path.cwd(),
        full_dependency_scope,
        effective_editable_overrides,
        execution_mode=execution_mode,
    )
    bootstrap_modules = tuple(
        module_name
        for module_name in full_dependency_scope
        if module_name not in selected_modules
        and not _is_source_decision_satisfied(
            module_name, full_source_decisions[module_name]
        )
    )
    final_scope = tuple(dict.fromkeys([*selected_modules, *bootstrap_modules]))
    scoped_source_decisions = {
        module_name: full_source_decisions[module_name] for module_name in final_scope
    }
    plan = _build_incremental_plan_from_scope(
        manifest,
        requested_modules=normalized_requested,
        scope_modules=final_scope,
        source_decisions=scoped_source_decisions,
    )
    return manifest, plan


def _normalize_repo_relative_path(value: str | Path) -> str:
    raw = str(value).replace("\\", "/")
    while raw.startswith("./"):
        raw = raw[2:]
    return raw.lstrip("/")


def _run_git_capture(
    repo_root: Path, args: list[str]
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=str(repo_root),
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )


def _git_stdout_lines(repo_root: Path, args: list[str]) -> list[str]:
    completed = _run_git_capture(repo_root, args)
    if completed.returncode != 0:
        return []
    return [
        _normalize_repo_relative_path(line)
        for line in completed.stdout.splitlines()
        if line.strip()
    ]


def _git_ref_exists(repo_root: Path, ref_name: str) -> bool:
    completed = _run_git_capture(repo_root, ["rev-parse", "--verify", ref_name])
    return completed.returncode == 0


def _stop_repo_pipeline_manager_daemons(
    repo_root: Path, report: InstallationReport | None = None
) -> None:
    escaped_repo_root = str(repo_root).replace("'", "''")
    command = (
        "$repoRoot = '{0}'; "
        "$targets = Get-CimInstance Win32_Process | Where-Object {{ "
        "$cmd = [string]($_.CommandLine); "
        "$exe = [string]($_.ExecutablePath); "
        "($cmd -like \"*cf_pipeline_manager*daemon-server*\" -or $cmd -like \"*-m cf_pipeline_manager daemon-server*\") "
        "-and ($cmd -like \"*$repoRoot*\" -or $exe -like \"*$repoRoot*\\.venv*\") "
        "}}; "
        "$stopped = @(); "
        "foreach ($proc in $targets) {{ "
        "try {{ Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop; $stopped += $proc.ProcessId }} catch {{}} "
        "}}; "
        "Write-Output ($stopped -join ',')"
    ).format(escaped_repo_root)
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        cwd=str(repo_root),
    )
    stopped = [value for value in completed.stdout.strip().split(",") if value.strip()]
    if report is not None:
        if stopped:
            report.notes.append(
                "Stopped existing pipeline-manager daemon process(es) before clean install: "
                + ", ".join(stopped)
            )
        else:
            report.notes.append(
                "No existing pipeline-manager daemon processes were running before clean install."
            )


def _resolve_base_ref(repo_root: Path, requested_base_ref: str | None) -> str | None:
    if requested_base_ref:
        return requested_base_ref
    for candidate in ("origin/main", "origin/master", "main", "master"):
        if _git_ref_exists(repo_root, candidate):
            return candidate
    return None


def detect_changed_modules(
    manifest: InstallManifest,
    repo_root: Path,
    *,
    base_ref: str | None,
    include_worktree_changes: bool,
) -> ChangedModuleSelection:
    resolved_base_ref = _resolve_base_ref(repo_root, base_ref)
    changed_files: set[str] = set()
    if resolved_base_ref:
        merge_base_lines = _git_stdout_lines(
            repo_root, ["merge-base", "HEAD", resolved_base_ref]
        )
        diff_base = merge_base_lines[0] if merge_base_lines else resolved_base_ref
        changed_files.update(
            _git_stdout_lines(repo_root, ["diff", "--name-only", diff_base, "HEAD"])
        )
    if include_worktree_changes:
        changed_files.update(_git_stdout_lines(repo_root, ["diff", "--name-only"]))
        changed_files.update(
            _git_stdout_lines(repo_root, ["diff", "--name-only", "--cached"])
        )

    module_paths = sorted(
        (
            (_normalize_repo_relative_path(item.path), package_name)
            for package_name, item in manifest.modules.items()
        ),
        key=lambda item: len(item[0]),
        reverse=True,
    )
    matched_modules: set[str] = set()
    unmatched_files: list[str] = []
    for changed_file in sorted(changed_files):
        matched_package = None
        for module_path, package_name in module_paths:
            if changed_file == module_path or changed_file.startswith(
                module_path + "/"
            ):
                matched_package = package_name
                break
        if matched_package is not None:
            matched_modules.add(matched_package)
        else:
            unmatched_files.append(changed_file)

    critical_unmatched_files = tuple(
        changed_file
        for changed_file in unmatched_files
        if changed_file in CRITICAL_CHANGED_PATHS
        or any(
            changed_file.startswith(prefix) for prefix in CRITICAL_CHANGED_PATH_PREFIXES
        )
    )
    return ChangedModuleSelection(
        requested_modules=tuple(sorted(matched_modules)),
        changed_files=tuple(sorted(changed_files)),
        unmatched_files=tuple(unmatched_files),
        critical_unmatched_files=critical_unmatched_files,
        base_ref=resolved_base_ref,
        include_worktree_changes=include_worktree_changes,
    )


def _run_command(
    args: list[str],
    cwd: Path,
    show_details: bool,
    extra_env: dict[str, str] | None = None,
) -> object:
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    return current_console().run_process(args, cwd=cwd, env=env)


def _emit_progress(message: str) -> None:
    current_console().progress(message)
    _emit_event("progress", detail=message)


def _capture_shell_environment(
    args: list[str],
    cwd: Path,
    env: dict[str, str],
) -> dict[str, str] | None:
    completed = subprocess.run(
        args,
        cwd=str(cwd),
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    if completed.returncode != 0:
        return None
    loaded = dict(env)
    for line in completed.stdout.splitlines():
        if "=" not in line:
            continue
        name, value = line.split("=", 1)
        loaded[name] = value
    return loaded


def _load_native_build_env(repo_root: Path, env: dict[str, str]) -> dict[str, str]:
    native_cwd = repo_root
    native_env = resolve_native_env_file()
    if not native_env.exists():
        return env
    command = (
        f". '{native_env}'; "
        "Get-ChildItem Env: | Sort-Object Name | ForEach-Object { '{0}={1}' -f $_.Name, $_.Value }"
    )
    loaded = _capture_shell_environment(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        native_cwd,
        env,
    )
    return loaded or env


def _ensure_managed_fuseki(options: InstallerOptions, report: InstallationReport) -> None:
    if options.repo_root is None:
        report.steps.append(StepReport("fuseki", "skipped", "Repository root is not available for managed Fuseki setup."))
        return
    fuseki_home = (resolve_cogniflow_root() / "tools" / "fuseki" / DEFAULT_FUSEKI_VERSION).resolve()
    launcher_candidates = (
        fuseki_home / "fuseki-server.bat",
        fuseki_home / "bin" / "fuseki-server.bat",
        fuseki_home / "fuseki-server.cmd",
        fuseki_home / "bin" / "fuseki-server.cmd",
    )
    if any(candidate.exists() for candidate in launcher_candidates):
        report.steps.append(StepReport("fuseki", "success", f"Managed Fuseki already available at {fuseki_home}."))
        return
    native_script = options.repo_root / "scripts" / "setup_native_deps_v2.ps1"
    native_args = [
        "-DuckdbVersion",
        options.duckdb_version,
        "-Arch",
        options.native_arch,
        "-FusekiVersion",
        DEFAULT_FUSEKI_VERSION,
    ]
    if options.auto_install_missing_prereqs:
        native_args.append("-AutoInstallMissingPrereqs")
    _run_script(native_script, native_args, options, report, "fuseki")


def _resolve_vswhere() -> Path | None:
    resolved = shutil.which("vswhere")
    if resolved:
        return Path(resolved)
    for candidate in VSWHERE_CANDIDATES:
        if candidate.exists():
            return candidate
    return None


def _resolve_msvc_installation_path() -> Path | None:
    vswhere = _resolve_vswhere()
    if vswhere is None:
        return None
    try:
        completed = subprocess.run(
            [
                str(vswhere),
                "-latest",
                "-products",
                "*",
                "-requires",
                "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                "-property",
                "installationPath",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return None
    install_path = Path(lines[0])
    return install_path if install_path.exists() else None


def _resolve_msvc_vcvars() -> Path | None:
    installation_path = _resolve_msvc_installation_path()
    if installation_path is not None:
        vcvars = installation_path / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
        if vcvars.exists():
            return vcvars
    for candidate in VCVARS_CANDIDATES:
        if candidate.exists():
            return candidate
    return None


def _load_msvc_build_env(repo_root: Path, env: dict[str, str]) -> dict[str, str]:
    vcvars = _resolve_msvc_vcvars()
    if vcvars is None:
        return env
    command = f'"{vcvars}" && set'
    loaded = _capture_shell_environment(["cmd", "/c", command], repo_root, env)
    return loaded or env


def _available_cmake_generators(cmake_path: str | None, env: dict[str, str]) -> tuple[str, ...]:
    command = [cmake_path or "cmake", "--help"]
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
            env=env,
        )
    except Exception:
        return ()
    if completed.returncode != 0:
        return ()
    generators: list[str] = []
    for line in completed.stdout.splitlines():
        match = re.match(r"\s*\*?\s*(Visual Studio \d+ \d{4})\s*=", line)
        if match:
            generators.append(match.group(1))
    return tuple(generators)


def _visual_studio_generator_major_from_installation_path(path: Path) -> str | None:
    year_to_major = {"2022": "17", "2019": "16", "2017": "15", "2015": "14"}
    for part in reversed(path.parts):
        if part in year_to_major:
            return year_to_major[part]
        if re.fullmatch(r"\d+", part):
            return part
    return None


def _resolve_visual_studio_cmake_generator(
    cmake_path: str | None, env: dict[str, str]
) -> str | None:
    generators = _available_cmake_generators(cmake_path, env)
    if not generators:
        return None
    installation_path = _resolve_msvc_installation_path()
    if installation_path is not None:
        major = _visual_studio_generator_major_from_installation_path(installation_path)
        if major:
            for generator in generators:
                if generator.startswith(f"Visual Studio {major} "):
                    return generator
    return generators[0]


def _sanitize_toolchain_path(
    env: dict[str, str], cmake_path: str | None
) -> dict[str, str]:
    sanitized = dict(env)
    path_parts = [part for part in sanitized.get("PATH", "").split(os.pathsep) if part]
    cleaned_parts = [
        part for part in path_parts if not BLOCKED_TOOLCHAIN_RE.search(part)
    ]
    if cmake_path:
        cmake_dir = str(Path(cmake_path).parent)
        if cmake_dir not in cleaned_parts:
            cleaned_parts.insert(0, cmake_dir)
    sanitized["PATH"] = os.pathsep.join(dict.fromkeys(cleaned_parts))
    for key in ("CC", "CXX", "CMAKE_MAKE_PROGRAM"):
        value = sanitized.get(key)
        if value and BLOCKED_TOOLCHAIN_RE.search(value):
            sanitized.pop(key, None)
    return sanitized


def _resolve_preferred_cmake(env: dict[str, str]) -> str | None:
    if PREFERRED_CMAKE_PATH.exists():
        return str(PREFERRED_CMAKE_PATH)
    resolved = shutil.which("cmake", path=env.get("PATH"))
    if resolved and not BLOCKED_TOOLCHAIN_RE.search(resolved):
        return resolved
    return None


def _prepare_editable_build_env(
    options: InstallerOptions, report: InstallationReport
) -> dict[str, str]:
    assert options.repo_root is not None
    build_env = os.environ.copy()
    build_env.pop("CF_DATAHIVE_CPP_DUCKDB_LINKAGE", None)
    build_env = _load_native_build_env(options.repo_root, build_env)
    build_env.pop("CF_DATAHIVE_CPP_DUCKDB_LINKAGE", None)
    build_env = _load_msvc_build_env(options.repo_root, build_env)
    cmake_path = _resolve_preferred_cmake(build_env)
    build_env = _sanitize_toolchain_path(build_env, cmake_path)
    if cmake_path:
        build_env["CMAKE_COMMAND"] = cmake_path
    if shutil.which("ninja", path=build_env.get("PATH")):
        build_env.pop("CMAKE_GENERATOR", None)
        build_env.pop("CMAKE_GENERATOR_PLATFORM", None)
        report.notes.append("Editable native builds will use Ninja when available.")
    else:
        generator = _resolve_visual_studio_cmake_generator(cmake_path, build_env)
        if generator:
            build_env.setdefault("CMAKE_GENERATOR", generator)
            build_env.setdefault("CMAKE_GENERATOR_PLATFORM", "x64")
            report.notes.append(f"Editable native builds will use {generator}.")
        else:
            report.notes.append(
                "Editable native builds did not find Ninja or a Visual Studio CMake generator."
            )
    report.notes.append(
        "Editable native builds run with a sanitized MSVC/CMake environment prepared by cf_setup."
    )
    if cmake_path:
        report.notes.append(f"Editable build cmake: {cmake_path}")
    vcvars = _resolve_msvc_vcvars()
    if vcvars is not None:
        report.notes.append(f"Editable build msvc env: {vcvars}")
    return build_env


def _ensure_build_tooling(
    options: InstallerOptions, report: InstallationReport
) -> None:
    if options.repo_root is None:
        raise RuntimeError("Editable build tooling requires repository mode.")
    args = [
        options.python_exe,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "pip",
        "setuptools",
        "wheel",
        "build",
        "pybind11",
        "numpy",
        "rdflib>=7,<8",
        "scikit-build-core",
        "pytest<9",
    ]
    started_at = current_timestamp()
    completed = _run_command(args, options.repo_root, options.show_details)
    if completed.returncode != 0:
        raise RuntimeError(
            "Failed to install Python build tooling for editable modules."
        )
    report.steps.append(
        StepReport.completed(
            "py_build_tooling",
            "success",
            "Installed editable-build tooling.",
            started_at=started_at,
            ended_at=current_timestamp(),
        )
    )


def _refresh_current_python_import_paths() -> None:
    candidates: list[Path] = []
    path_config = sysconfig.get_paths()
    for key in ("purelib", "platlib"):
        value = path_config.get(key)
        if value:
            candidates.append(Path(value))

    get_site_packages = getattr(site, "getsitepackages", None)
    if callable(get_site_packages):
        for entry in get_site_packages():
            if entry:
                candidates.append(Path(entry))

    get_user_site = getattr(site, "getusersitepackages", None)
    if callable(get_user_site):
        user_site = get_user_site()
        if user_site:
            candidates.append(Path(user_site))

    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            resolved = candidate
        key = str(resolved)
        if key in seen or not resolved.exists():
            continue
        seen.add(key)
        site.addsitedir(str(resolved))

    importlib.invalidate_caches()


def _run_script(
    script_path: Path,
    script_args: list[str],
    options: InstallerOptions,
    report: InstallationReport,
    step_name: str,
) -> None:
    args = [
        "powershell",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script_path),
        *script_args,
    ]
    started_at = current_timestamp()
    _emit_step_started(step_name, f"Delegating to {script_path.name}.")
    completed = _run_command(args, options.repo_root, options.show_details)
    if completed.returncode != 0:
        raise RuntimeError(f"Delegated script failed for step '{step_name}'.")
    report.steps.append(
        StepReport.completed(
            step_name,
            "success",
            f"Delegated to {script_path.name}.",
            started_at=started_at,
            ended_at=current_timestamp(),
        )
    )


def _pip_install_module(
    package_name: str,
    install_args: list[str],
    cwd: Path,
    show_details: bool,
    report: InstallationReport,
    extra_env: dict[str, str] | None = None,
) -> None:
    started_at = current_timestamp()
    _mark_module_install_attempt(report, package_name)
    _emit_module_state_changed(package_name, "installing")
    _emit_step_started(
        f"install:{package_name}",
        "Module install started.",
        package=package_name,
    )
    completed = _run_command(install_args, cwd, show_details, extra_env=extra_env)
    if completed.returncode != 0:
        _mark_module_install_failed(report, package_name)
        _emit_module_state_changed(package_name, "failed")
        raise RuntimeError(f"Failed to install module '{package_name}'.")
    _emit_module_state_changed(package_name, "installed")
    report.steps.append(
        StepReport.completed(
            f"install:{package_name}",
            "success",
            "Module installed successfully.",
            started_at=started_at,
            ended_at=current_timestamp(),
        )
    )


def _pip_install_distribution_batch(
    package_names: list[str],
    install_args: list[str],
    cwd: Path,
    show_details: bool,
    report: InstallationReport,
) -> None:
    started_at = current_timestamp()
    _mark_module_install_attempt(report, *package_names)
    _emit_event(
        "batch_started",
        step="pip_install_batch",
        packages=package_names,
        started_at=timestamp_to_iso(started_at),
    )
    for package_name in package_names:
        _emit_module_state_changed(package_name, "in_batch", batch="pip_install_batch")
    completed = _run_command(install_args, cwd, show_details)
    if completed.returncode != 0:
        ended_at = current_timestamp()
        _mark_module_install_failed(report, *package_names)
        _emit_event(
            "batch_finished",
            step="pip_install_batch",
            status="failed",
            packages=package_names,
            started_at=timestamp_to_iso(started_at),
            ended_at=timestamp_to_iso(ended_at),
            duration_seconds=max((ended_at - started_at).total_seconds(), 0.0),
        )
        for package_name in package_names:
            _emit_module_state_changed(package_name, "failed", batch="pip_install_batch")
        raise RuntimeError("Failed to install distribution-mode package batch.")
    ended_at = current_timestamp()
    _emit_event(
        "batch_finished",
        step="pip_install_batch",
        status="success",
        packages=package_names,
        started_at=timestamp_to_iso(started_at),
        ended_at=timestamp_to_iso(ended_at),
        duration_seconds=max((ended_at - started_at).total_seconds(), 0.0),
    )
    for package_name in package_names:
        _emit_module_state_changed(package_name, "installed", batch="pip_install_batch")
        report.steps.append(
            StepReport.completed(
                f"install:{package_name}",
                "success",
                "Module installed successfully as part of the distribution-mode batch.",
                started_at=started_at,
                ended_at=ended_at,
            )
        )


def _pip_install_distribution_packages(
    package_names: list[str],
    install_args: list[str],
    cwd: Path,
    show_details: bool,
    report: InstallationReport,
    *,
    progress_mode: str,
) -> None:
    if progress_mode == "precise":
        base_install_args = install_args[:-len(package_names)] if package_names else install_args
        for package_name in package_names:
            _pip_install_module(
                package_name,
                [*base_install_args, package_name],
                cwd,
                show_details,
                report,
            )
        return
    _pip_install_distribution_batch(package_names, install_args, cwd, show_details, report)


@lru_cache(maxsize=128)
def _repo_local_dependency_module_roots(
    package_name: str, manifest_path: str, repo_root: str
) -> tuple[str, ...]:
    manifest = load_manifest(Path(manifest_path))
    dependency_closure = add_dependency_closure(manifest, (package_name,))
    roots: list[str] = []
    for dependency_name in dependency_closure:
        if dependency_name == package_name:
            continue
        roots.append(
            str((Path(repo_root) / manifest.modules[dependency_name].path).resolve())
        )
    return tuple(roots)


def _is_distribution_package_already_satisfied(item) -> bool:
    state = _read_installed_package_state(item.package_name)
    if not item.pypi_version or not state.installed:
        return False
    if state.editable is True or state.local_directory is True:
        return False
    if not state.version:
        return False
    return parse_version(state.version) >= parse_version(item.pypi_version)


def _emit_already_installed_step(
    item, report: InstallationReport, *, mode_label: str
) -> None:
    installed_version = _read_installed_package_state(item.package_name).version or "-"
    target_version = _normalize_decision_target_version(
        item.local_version, item.pypi_version, item.source
    )
    report.steps.append(
        StepReport(
            f"install:{item.package_name}",
            "success",
            f"Module already installed at version {installed_version}, satisfying {mode_label} target {target_version or '-'}.",
        )
    )
    _emit_module_state_changed(item.package_name, "installed", mode="retained")


def _can_retain_self_hosted_cf_core_cli(item) -> bool:
    if item.package_name != "cf-core-cli" or not _is_current_cf_cli_invocation():
        return False
    if item.source in {"editable", "local-build"}:
        return True
    state = _read_installed_package_state(item.package_name)
    target_version = _normalize_decision_target_version(
        item.local_version, item.pypi_version, item.source
    )
    if not state.installed or not target_version or state.version != target_version:
        return False
    if item.source == "pypi":
        return parse_version(state.version) >= parse_version(target_version)
    return False


def _emit_self_hosted_cli_retained_step(item, report: InstallationReport) -> None:
    installed_version = _read_installed_package_state(item.package_name).version or "-"
    report.steps.append(
        StepReport(
            f"install:{item.package_name}",
            "success",
            "Retained the current cf-core-cli install while running through the cf launcher to avoid a Windows file lock on cf.exe; rerun via `python -m cf_setup ...` only if you need to rewrite the launcher itself. "
            f"Installed version {installed_version} already satisfies target {_normalize_decision_target_version(item.local_version, item.pypi_version, item.source) or '-' }.",
        )
    )
    _emit_module_state_changed(item.package_name, "installed", mode="retained")


def _is_local_build_module_already_satisfied(item) -> bool:
    state = _read_installed_package_state(item.package_name)
    if (
        not state.installed
        or state.editable is True
        or state.local_directory is not True
    ):
        return False
    if item.local_version and state.version != item.local_version:
        return False
    if not _installed_package_runtime_requirements_satisfied(item.package_name):
        return False
    module_root = None
    module = getattr(item, "module", None)
    module_path = getattr(module, "path", None)
    repo_root = find_repo_root(Path(__file__).resolve())
    if module_path and repo_root is not None:
        module_root = repo_root / module_path
    if not _installed_package_import_surface_satisfied(item.package_name, module_root):
        return False
    if not _installed_package_asset_surface_satisfied(item.package_name, module_root):
        return False
    return True


def _resolve_scikit_build_dir(module_root: Path) -> Path | None:
    pyproject_path = module_root / "pyproject.toml"
    if not pyproject_path.exists():
        return None
    try:
        payload = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return None
    tool = payload.get("tool")
    if not isinstance(tool, dict):
        return None
    scikit_build = tool.get("scikit-build")
    if not isinstance(scikit_build, dict):
        return None
    raw_build_dir = scikit_build.get("build-dir")
    if not isinstance(raw_build_dir, str) or not raw_build_dir.strip():
        return None
    return (module_root / raw_build_dir).resolve()

def _resolve_shared_scikit_build_dir(package_name: str) -> Path:
    return (resolve_native_cache_dir() / "scikit-build" / package_name).resolve()


def _handle_remove_readonly(func, path, exc_info):
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except OSError:
        pass
    func(path)


def _reset_scikit_build_dir(module_root: Path, report: InstallationReport, package_name: str) -> None:
    candidate_dirs: list[Path] = []
    shared_build_dir = _resolve_shared_scikit_build_dir(package_name)
    candidate_dirs.append(shared_build_dir)
    legacy_build_dir = _resolve_scikit_build_dir(module_root)
    if legacy_build_dir is not None:
        candidate_dirs.append(legacy_build_dir)
    seen: set[str] = set()
    for build_dir in candidate_dirs:
        key = str(build_dir)
        if key in seen or not build_dir.exists():
            continue
        seen.add(key)
        shutil.rmtree(build_dir, ignore_errors=False, onerror=_handle_remove_readonly)
        report.notes.append(f"Reset scikit-build directory for {package_name}: {build_dir}")


def _reset_setuptools_build_dir(module_root: Path, report: InstallationReport, package_name: str) -> None:
    build_dir = module_root / "build"
    if not build_dir.exists():
        return
    shutil.rmtree(build_dir, ignore_errors=False, onerror=_handle_remove_readonly)
    report.notes.append(f"Reset setuptools build directory for {package_name}: {build_dir}")


def _install_repo_module(
    item,
    options: InstallerOptions,
    report: InstallationReport,
    *,
    editable_build_env: dict[str, str] | None,
    force_reinstall: bool,
) -> None:
    assert options.repo_root is not None
    module_root = options.repo_root / item.module.path
    module_build_env = dict(editable_build_env or {})
    module_build_env["SKBUILD_BUILD_DIR"] = str(_resolve_shared_scikit_build_dir(item.package_name))

    if _can_retain_self_hosted_cf_core_cli(item):
        _emit_self_hosted_cli_retained_step(item, report)
        return

    if item.source == "editable":
        _reset_scikit_build_dir(module_root, report, item.package_name)
        _reset_setuptools_build_dir(module_root, report, item.package_name)
        _remove_editable_shadow_packages(module_root, item.package_name, report)
        if not force_reinstall and _is_editable_module_already_satisfied(item):
            _emit_already_installed_step(item, report, mode_label="local")
            return
        install_args = [
            options.python_exe,
            "-m",
            "pip",
            "install",
            "--no-build-isolation",
            "-e",
            str(module_root),
        ]
        _pip_install_module(
            item.package_name,
            install_args,
            options.repo_root,
            options.show_details,
            report,
            extra_env=module_build_env,
        )
        return

    if item.source == "local-build":
        _reset_scikit_build_dir(module_root, report, item.package_name)
        _reset_setuptools_build_dir(module_root, report, item.package_name)
        if not force_reinstall and _is_local_build_module_already_satisfied(item):
            _emit_already_installed_step(item, report, mode_label="local build")
            return
        installed_state = _read_installed_package_state(item.package_name)
        install_args = [
            options.python_exe,
            "-m",
            "pip",
            "install",
            "--no-build-isolation",
        ]
        if force_reinstall or installed_state.installed:
            install_args.append("--force-reinstall")
            install_args.extend(
                _repo_local_dependency_module_roots(
                    item.package_name,
                    str(options.manifest_path),
                    str(options.repo_root),
                )
            )
        install_args.append(str(module_root))
        _pip_install_module(
            item.package_name,
            install_args,
            options.repo_root,
            options.show_details,
            report,
            extra_env=module_build_env,
        )
        return

    if not force_reinstall and _is_distribution_package_already_satisfied(item):
        _emit_already_installed_step(item, report, mode_label="published")
        return

    install_args = [options.python_exe, "-m", "pip", "install", "--upgrade"]
    if force_reinstall:
        install_args.append("--force-reinstall")
    if options.wheel_only:
        install_args.extend(["--only-binary", ":all:", "--prefer-binary"])
    install_args.append(item.package_name)
    _pip_install_module(
        item.package_name, install_args, options.repo_root, options.show_details, report
    )


def _update_hook_status(report: InstallationReport, hook_id: str, status: str) -> None:
    for hook_entry in report.hooks:
        if hook_entry["hook_id"] == hook_id:
            hook_entry["status"] = status
            return


def _build_installation_report(
    *,
    command: str,
    repo_root: Path | None,
    profile: str,
    dry_run: bool,
    execution_mode: str,
    manifest: InstallManifest,
    plan: InstallPlan,
    clean_result: dict[str, object] | None = None,
    wizard_invocation: str | None = None,
) -> InstallationReport:
    effective_repo_root: Path | None = (
        None if execution_mode == "distribution" else repo_root
    )
    report = InstallationReport(
        command=command,
        repo_root=str(effective_repo_root) if effective_repo_root else None,
        profile=profile,
        dry_run=dry_run,
        execution_mode=execution_mode,
        log_path=None,
        requested_modules=list(plan.requested_modules),
        scope_modules=[item.package_name for item in plan.ordered_modules],
        skipped_modules=sorted(
            name
            for name in manifest.modules
            if name not in {item.package_name for item in plan.ordered_modules}
        ),
    )
    planned_modules = {item.package_name: item for item in plan.ordered_modules}
    ordered_package_names = [item.package_name for item in plan.ordered_modules]
    ordered_package_names.extend(
        sorted(
            definition.package_name
            for definition in manifest.modules.values()
            if definition.package_name not in planned_modules
        )
    )

    report.modules = []
    for package_name in ordered_package_names:
        planned_item = planned_modules.get(package_name)
        if planned_item is not None:
            report.modules.append(
                {
                    "package_name": planned_item.package_name,
                    "path": planned_item.module.path,
                    "source": planned_item.source,
                    "editable": planned_item.source == "editable",
                    "reason": planned_item.reason,
                    "local_version": planned_item.local_version,
                    "pypi_version": planned_item.pypi_version,
                    "target_version": _normalize_decision_target_version(
                        planned_item.local_version,
                        planned_item.pypi_version,
                        planned_item.source,
                    ),
                    "scope_status": "in_scope",
                    "result": "planned" if dry_run else "pending",
                }
            )
            continue

        module_definition = next(
            definition
            for definition in manifest.modules.values()
            if definition.package_name == package_name
        )
        local_version = (
            read_local_version(repo_root / module_definition.path)
            if repo_root and execution_mode == "repo"
            else None
        )
        report.modules.append(
            {
                "package_name": module_definition.package_name,
                "path": module_definition.path,
                "source": "out_of_scope",
                "editable": None,
                "reason": "not part of this run",
                "local_version": local_version,
                "pypi_version": None,
                "target_version": local_version,
                "scope_status": "out_of_scope",
                "result": "pending",
            }
        )
    report.hooks = [
        {
            "hook_id": hook.hook_id,
            "status": "planned" if dry_run else "pending",
            "action": hook.action,
        }
        for hook in plan.hooks
    ]
    report.clean_result = clean_result
    report.wizard_invocation = wizard_invocation
    return report


def _emit_event(event_type: str, **payload: object) -> None:
    current_event_stream().emit(event_type, **payload)


def _emit_step_started(step: str, detail: str, **payload: object) -> None:
    _emit_event("step_started", step=step, detail=detail, **payload)


def _emit_step_finished(step_report: StepReport) -> None:
    _emit_event(
        "step_finished",
        step=step_report.step,
        status=step_report.status,
        detail=step_report.detail,
        started_at=step_report.started_at,
        ended_at=step_report.ended_at,
        duration_seconds=step_report.duration_seconds,
    )


def _emit_module_queued_events(plan: InstallPlan) -> None:
    for index, item in enumerate(plan.ordered_modules, start=1):
        _emit_event(
            "module_queued",
            package=item.package_name,
            source=item.source,
            order=index,
            reason=item.reason,
        )


def _emit_module_state_changed(package_name: str, state: str, **payload: object) -> None:
    _emit_event("module_state_changed", package=package_name, state=state, **payload)


def _emit_install_lifecycle_event(
    event_type: str,
    *,
    options: InstallerOptions,
    execution_mode: str,
    package_names: list[str],
    status: str | None = None,
) -> None:
    payload: dict[str, object] = {
        "command": options.command_name,
        "profile": options.profile,
        "execution_mode": execution_mode,
        "progress_mode": options.progress_mode,
        "packages": package_names,
    }
    if options.log_path is not None:
        payload["log_path"] = str(options.log_path)
    if options.report_path is not None:
        payload["report_path"] = str(options.report_path)
    if options.event_path is not None:
        payload["event_path"] = str(options.event_path)
    if status is not None:
        payload["status"] = status
    _emit_event(event_type, **payload)


def _installed_target_packages(package_names: Iterable[str]) -> list[str]:
    installed: list[str] = []
    for package_name in package_names:
        try:
            metadata.version(package_name)
        except metadata.PackageNotFoundError:
            continue
        installed.append(package_name)
    return installed


def _record_failure(
    options: InstallerOptions, report: InstallationReport, exc: Exception
) -> None:
    report.steps.append(StepReport("failure", "failed", str(exc)))
    current_console().error(str(exc))
    if not options.show_details:
        current_console().print_recent_log_tail(header="Recent log tail")


def _read_installed_package_state(package_name: str) -> InstalledPackageState:
    return _read_installed_package_state_for_planning(package_name)


def _installed_package_runtime_requirements_satisfied(package_name: str) -> bool:
    try:
        distribution = metadata.distribution(package_name)
    except metadata.PackageNotFoundError:
        return False

    for raw_requirement in distribution.requires or ():
        try:
            requirement = Requirement(raw_requirement)
        except InvalidRequirement:
            return False
        if requirement.marker and not requirement.marker.evaluate({"extra": ""}):
            continue
        try:
            installed_version = metadata.version(requirement.name)
        except metadata.PackageNotFoundError:
            return False
        if requirement.specifier and installed_version not in requirement.specifier:
            return False
    return True


def _installed_package_import_surface_satisfied(
    package_name: str,
    module_root: Path | None = None,
) -> bool:
    import_names: list[str] = []
    if module_root is not None:
        import_names.extend(_top_level_editable_import_names(module_root, package_name))
    else:
        try:
            distribution = metadata.distribution(package_name)
        except metadata.PackageNotFoundError:
            return False
        top_level_raw = distribution.read_text("top_level.txt") or ""
        import_names.extend(
            line.strip() for line in top_level_raw.splitlines() if line.strip()
        )

    normalized = package_name.replace("-", "_")
    if normalized and normalized not in import_names:
        import_names.insert(0, normalized)

    ordered_names = tuple(dict.fromkeys(name for name in import_names if name))
    if not ordered_names:
        return True

    resolved = {
        name: importlib.util.find_spec(name) is not None for name in ordered_names
    }
    if normalized:
        return resolved.get(normalized, False)
    return any(resolved.values())


def _installed_package_asset_surface_satisfied(
    package_name: str,
    module_root: Path | None = None,
) -> bool:
    candidate_roots: list[Path] = []
    if module_root is not None:
        candidate_roots.append(module_root / "src" / package_name)

    try:
        distribution = metadata.distribution(package_name)
    except metadata.PackageNotFoundError:
        distribution = None
    if distribution is not None:
        candidate_roots.append(
            Path(str(distribution.locate_file(Path(package_name) / "__init__.py"))).resolve().parent
        )

    seen: set[str] = set()
    for package_root in candidate_roots:
        key = str(package_root)
        if key in seen:
            continue
        seen.add(key)
        if (package_root / "steps.nq").exists() and (package_root / "bin").exists():
            return True
    return False


def _is_editable_module_already_satisfied(item) -> bool:
    state = _read_installed_package_state(item.package_name)
    if not state.installed or state.editable is not True:
        return False
    if item.local_version and state.version != item.local_version:
        return False
    if not _installed_package_runtime_requirements_satisfied(item.package_name):
        return False
    module_root = None
    module = getattr(item, "module", None)
    module_path = getattr(module, "path", None)
    repo_root = find_repo_root(Path(__file__).resolve())
    if module_path and repo_root is not None:
        module_root = repo_root / module_path
    if not _installed_package_import_surface_satisfied(item.package_name, module_root):
        return False
    if not _installed_package_asset_surface_satisfied(item.package_name, module_root):
        return False
    return True


def _mark_module_install_attempt(
    report: InstallationReport, *package_names: str
) -> None:
    selected = set(package_names)
    for module_entry in report.modules:
        if str(module_entry.get("package_name")) in selected:
            module_entry["install_attempted"] = True


def _mark_module_install_failed(
    report: InstallationReport, *package_names: str
) -> None:
    selected = set(package_names)
    for module_entry in report.modules:
        if str(module_entry.get("package_name")) in selected:
            module_entry["install_failed"] = True


def _snapshot_installed_package_states(
    package_names: Iterable[str],
) -> dict[str, InstalledPackageState]:
    return {
        package_name: _read_installed_package_state(package_name)
        for package_name in package_names
    }


def _top_level_editable_import_names(module_root: Path, package_name: str) -> tuple[str, ...]:
    src_root = module_root / "src"
    names: list[str] = []
    if src_root.is_dir():
        for child in src_root.iterdir():
            if child.name.startswith("."):
                continue
            if child.is_dir() and (child / "__init__.py").exists():
                names.append(child.name)
                continue
            if child.is_file() and child.suffix == ".py":
                names.append(child.stem)
    normalized = package_name.replace("-", "_")
    if normalized and normalized not in names:
        names.append(normalized)
    return tuple(dict.fromkeys(name for name in names if name))


def _remove_editable_shadow_packages(
    module_root: Path,
    package_name: str,
    report: InstallationReport,
) -> None:
    purelib = Path(sysconfig.get_paths()["purelib"])
    removed: list[Path] = []
    for import_name in _top_level_editable_import_names(module_root, package_name):
        package_dir = purelib / import_name
        module_file = purelib / f"{import_name}.py"
        if package_dir.is_dir():
            shutil.rmtree(package_dir, ignore_errors=False, onerror=_handle_remove_readonly)
            removed.append(package_dir)
        if module_file.is_file():
            module_file.unlink()
            removed.append(module_file)
    if removed:
        report.notes.append(
            f"Removed stale editable shadow paths for {package_name}: "
            + ", ".join(str(path) for path in removed)
        )


def _apply_module_snapshot(
    report: InstallationReport,
    snapshot: dict[str, InstalledPackageState],
    *,
    stage: str,
) -> None:
    for module_entry in report.modules:
        state = snapshot.get(
            str(module_entry["package_name"]),
            InstalledPackageState(False, None, None, None),
        )
        if stage == "before":
            module_entry["installed_before"] = state.installed
            module_entry["installed_version_before"] = state.version
            module_entry["editable_before"] = state.editable
            module_entry["local_directory_before"] = state.local_directory
        else:
            module_entry["installed_after"] = state.installed
            module_entry["installed_version_after"] = state.version
            module_entry["editable_after"] = state.editable
            module_entry["local_directory_after"] = state.local_directory


def _prepare_report_tracking(
    report: InstallationReport,
) -> dict[str, InstalledPackageState]:
    def _record_step(step_report: StepReport) -> None:
        current_console().record_step(step_report)
        _emit_step_finished(step_report)

    report.steps.emitter = _record_step
    before_snapshot = _snapshot_installed_package_states(
        module["package_name"] for module in report.modules
    )
    _apply_module_snapshot(report, before_snapshot, stage="before")
    return before_snapshot


def _finalize_module_results(
    report: InstallationReport,
    before_snapshot: dict[str, InstalledPackageState],
) -> None:
    after_snapshot = _snapshot_installed_package_states(
        module["package_name"] for module in report.modules
    )
    _apply_module_snapshot(report, after_snapshot, stage="after")
    for module_entry in report.modules:
        package_name = str(module_entry["package_name"])
        before_state = before_snapshot.get(
            package_name, InstalledPackageState(False, None, None, None)
        )
        after_state = after_snapshot.get(
            package_name, InstalledPackageState(False, None, None, None)
        )
        scope_status = str(module_entry.get("scope_status") or "in_scope")
        attempted = bool(module_entry.get("install_attempted"))
        failed = bool(module_entry.get("install_failed"))
        if report.dry_run:
            if scope_status == "in_scope":
                module_entry["result"] = "planned"
            else:
                module_entry["result"] = (
                    "already installed" if after_state.installed else "not installed"
                )
        elif failed:
            module_entry["result"] = "failed"
        elif scope_status != "in_scope":
            if not after_state.installed:
                module_entry["result"] = "not installed"
            elif attempted:
                module_entry["result"] = (
                    "re-installed" if before_state.installed else "installed"
                )
            else:
                module_entry["result"] = "already installed"
        elif not after_state.installed:
            module_entry["result"] = "failed" if attempted else "not installed"
        elif attempted:
            module_entry["result"] = (
                "re-installed" if before_state.installed else "installed"
            )
        else:
            module_entry["result"] = "already installed"


def _emit_report_summary(report: InstallationReport) -> None:
    current_console().emit_table(
        "Package summary",
        ["package", "pypi version", "local version", "installed version", "state"],
        [
            [
                str(module["package_name"]),
                str(module.get("pypi_version") or "-"),
                str(module.get("local_version") or "-"),
                str(
                    module.get("installed_version_after")
                    or module.get("installed_version_before")
                    or "-"
                ),
                str(module.get("result") or "-"),
            ]
            for module in report.modules
        ],
    )
    if report.duration_seconds is not None:
        current_console().success(
            f"Total runtime: {format_duration_seconds(report.duration_seconds)}"
        )


def _finalize_report(
    report: InstallationReport, before_snapshot: dict[str, InstalledPackageState]
) -> dict[str, object]:
    if report.finished_at is None:
        _finalize_module_results(report, before_snapshot)
        report.finalize()
        _emit_report_summary(report)
    return report.to_dict()


def _step_modules_in_scope(plan: InstallPlan) -> bool:
    selected_names = {item.package_name for item in plan.ordered_modules}
    return any(module_name in selected_names for module_name in STEP_MODULE_PREFIXES)


def _resolve_semantics_store_paths(semantics_dir: Path):
    class _SemanticsStorePaths:
        def __init__(self, base: Path) -> None:
            self.store_root = base / "rdf_store"
            self.tdb2 = self.store_root / "tdb2"
            self.graphs = self.store_root / "graphs"
            self.catalog = self.store_root / "graphs.catalog.json"
            self.pid_file = self.store_root / "fuseki.pid"

    return _SemanticsStorePaths(semantics_dir)


def _read_semantics_store_catalog(catalog_path: Path) -> list[dict[str, object]]:
    if not catalog_path.exists():
        return []
    try:
        payload = json.loads(catalog_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, dict)]


def _repo_semantics_requires_recreate(semantics_dir: Path) -> bool:
    if not semantics_dir.exists():
        return True
    store_paths = _resolve_semantics_store_paths(semantics_dir)
    if not store_paths.store_root.exists():
        return True
    if not store_paths.tdb2.exists() or not store_paths.graphs.exists() or not store_paths.catalog.exists():
        return True
    graph_ids = {
        str(item.get("graph_id") or "")
        for item in _read_semantics_store_catalog(store_paths.catalog)
    }
    return not {"core", "shapes"}.issubset(graph_ids)


def _run_post_install_hooks(
    options: InstallerOptions,
    report: InstallationReport,
    hooks: tuple,
    *,
    workspace_dir: Path,
    semantics_dir: Path,
    cwd: Path,
    run_hooks: bool,
) -> None:
    for hook in hooks:
        if hook.action == "cf_setup_refresh_provider_registry":
            started_at = current_timestamp()
            _emit_step_started("provider_registry", "Refreshing provider registry.")
            result = refresh_provider_registry(
                workspace_dir,
                distribution_mode=(getattr(options, "execution_mode", "repo") == "distribution"),
            )
            provider_keys = sorted(
                key
                for key in (
                    result.payload.get("providers", {})
                    if isinstance(result.payload, dict)
                    else {}
                )
                if isinstance(key, str)
            )
            os.environ[PROVIDER_REGISTRY_ENV] = str(result.path)
            report.steps.append(
                StepReport.completed(
                    "provider_registry",
                    "success",
                    f"Refreshed provider registry at {result.path} with {len(provider_keys)} provider(s): {', '.join(provider_keys)}.",
                    started_at=started_at,
                    ended_at=current_timestamp(),
                )
            )
            _update_hook_status(report, hook.hook_id, "success")
            continue
        if hook.action in {
            "cf_semantics_runtime_sync_installed_steps",
        }:
            if not run_hooks:
                _update_hook_status(report, hook.hook_id, "skipped")
                continue
            _emit_progress(f"Running post-install hook '{hook.hook_id}'...")
            _emit_step_started(f"hook:{hook.hook_id}", f"Running post-install hook '{hook.hook_id}'.")
            hook_code = "\n".join(
                [
                    "import os",
                    f"os.environ['CF_SEMANTICS_DIR'] = r'{semantics_dir}'",
                    "from cf_semantics_runtime.service_contract_provider import provide_semantics_runtime_contract",
                    "runtime = provide_semantics_runtime_contract()",
                    "print(runtime.sync_installed_step_graphs_to_workspace().get('synced', 0))",
                ]
            )
            hook_args = [
                options.python_exe,
                "-c",
                hook_code,
            ]
            started_at = current_timestamp()
            completed = _run_command(hook_args, cwd, options.show_details)
            if completed.returncode != 0:
                raise RuntimeError(f"Post-install hook '{hook.hook_id}' failed.")
            report.steps.append(
                StepReport.completed(
                    f"hook:{hook.hook_id}",
                    "success",
                    f"Executed post-install hook '{hook.hook_id}'.",
                    started_at=started_at,
                    ended_at=current_timestamp(),
                )
            )
            _update_hook_status(report, hook.hook_id, "success")
            continue
        if hook.action == "cf_web_prime_pipeline_editor_steps":
            if not run_hooks:
                _update_hook_status(report, hook.hook_id, "skipped")
                continue
            _emit_progress(f"Running post-install hook '{hook.hook_id}'...")
            _emit_step_started(f"hook:{hook.hook_id}", f"Running post-install hook '{hook.hook_id}'.")
            hook_args = [
                options.python_exe,
                "-c",
                (
                    "import os; "
                    "os.environ.setdefault('CF_ENABLE_STEP_PACKAGES', '1'); "
                    "from cf_web.services.pipeline_creator_service import PipelineCreatorService; "
                    "service = PipelineCreatorService(); "
                    "loader = getattr(service, 'prewarm_steps', service.get_steps); "
                    "print(len(loader()))"
                ),
            ]
            started_at = current_timestamp()
            completed = _run_command(hook_args, cwd, options.show_details)
            if completed.returncode != 0:
                raise RuntimeError(f"Post-install hook '{hook.hook_id}' failed.")
            report.steps.append(
                StepReport.completed(
                    f"hook:{hook.hook_id}",
                    "success",
                    f"Executed post-install hook '{hook.hook_id}'.",
                    started_at=started_at,
                    ended_at=current_timestamp(),
                )
            )
            _update_hook_status(report, hook.hook_id, "success")
            continue
        _update_hook_status(report, hook.hook_id, "skipped")


def _run_incremental_smoke(
    options: InstallerOptions,
    plan: InstallPlan,
    report: InstallationReport,
    *,
    cwd: Path,
) -> None:
    test_targets: list[str] = []
    if options.repo_root is not None:
        for item in plan.ordered_modules:
            test_path = (
                options.repo_root
                / item.module.path
                / "tests"
                / "test_install_surface.py"
            )
            if test_path.exists():
                test_targets.append(str(test_path))

    if test_targets:
        smoke_args = [
            options.python_exe,
            "-m",
            "pytest",
            "--import-mode=importlib",
            "-q",
            *test_targets,
        ]
        started_at = current_timestamp()
        completed = _run_command(smoke_args, cwd, options.show_details)
        if completed.returncode != 0:
            raise RuntimeError("Incremental smoke tests failed.")
        report.steps.append(
            StepReport.completed(
                "smoke",
                "success",
                f"Smoke tests passed for {len(test_targets)} install-surface target(s).",
                started_at=started_at,
                ended_at=current_timestamp(),
            )
        )
        return

    smoke_code = (
        "from importlib import metadata\n"
        "import sys\n"
        "for name in sys.argv[1:]:\n"
        "    metadata.version(name)\n"
    )
    package_names = [item.package_name for item in plan.ordered_modules]
    started_at = current_timestamp()
    completed = _run_command(
        [options.python_exe, "-c", smoke_code, *package_names],
        cwd,
        options.show_details,
    )
    if completed.returncode != 0:
        raise RuntimeError("Incremental metadata smoke check failed.")
    report.steps.append(
        StepReport.completed(
            "smoke",
            "success",
            f"Metadata smoke check passed for {len(package_names)} package(s).",
            started_at=started_at,
            ended_at=current_timestamp(),
        )
    )


def _resolve_distribution_workspace_dir() -> Path:
    return resolve_workspace_dir()


def _resolve_repo_workspace_dir(repo_root: Path) -> Path:
    del repo_root
    return _resolve_distribution_workspace_dir()


def _resolve_distribution_semantics_dir(workspace_dir: Path) -> Path:
    return (workspace_dir / "semantics").resolve()


def _resolve_legacy_semantics_db_paths(semantics_dir: Path):
    """Return delete-only legacy RDF DuckDB paths kept for cleanup during migration."""

    class _SemanticsDbPaths:
        def __init__(self, base: Path) -> None:
            self.ontology = base / "cf-ontology.store.db"
            self.steps = base / "cf-steps.store.db"
            self.pipelines = base / "cf-pipelines.store.db"

        def as_dict(self) -> dict[str, Path]:
            return {
                "ontology": self.ontology,
                "steps": self.steps,
                "pipelines": self.pipelines,
            }

    return _SemanticsDbPaths(semantics_dir)


def _recreate_semantics_runtime(
    semantics_dir: Path,
    *,
    python_exe: str,
    cwd: Path,
    show_details: bool,
    report: InstallationReport,
) -> None:
    semantics_dir.mkdir(parents=True, exist_ok=True)
    db_paths = _resolve_legacy_semantics_db_paths(semantics_dir)
    removed_paths: list[str] = []
    for path in db_paths.as_dict().values():
        if path.exists():
            path.unlink()
            removed_paths.append(str(path))
    runs_dir = semantics_dir / "runs"
    if runs_dir.exists():
        shutil.rmtree(runs_dir, ignore_errors=True)
        removed_paths.append(str(runs_dir))

    bootstrap_code = "\n".join(
        [
            "import os",
            f"os.environ['CF_SEMANTICS_DIR'] = r'{semantics_dir}'",
            "from cf_semantics_store.service_contract_provider import provide_semantics_store_contract",
            "from cf_semantics_runtime.service_contract_provider import provide_semantics_runtime_contract",
            "store = provide_semantics_store_contract()",
            "store.reset_dataset()",
            "runtime = provide_semantics_runtime_contract()",
            "ontology_sync = runtime.sync_packaged_ontology_to_workspace()",
            "step_sync = runtime.sync_installed_step_graphs_to_workspace()",
            "if int(ontology_sync.get('synced', 0)) <= 0:",
            "    raise RuntimeError('Failed to resolve packaged ontology NQ resources from cf_ontology.')",
            "if int(step_sync.get('synced', 0)) <= 0:",
            "    raise RuntimeError('Failed to sync installed step packages into the semantics store.')",
            "store.ensure_dataset()",
        ]
    )
    init_args = [
        python_exe,
        "-c",
        bootstrap_code,
    ]
    started_at = current_timestamp()
    _emit_step_started("semantics_init", f"Initializing semantics workspace at {semantics_dir}.")
    init_completed = _run_command(init_args, cwd, show_details)
    if init_completed.returncode != 0:
        raise RuntimeError(
            f"Failed to initialize semantics workspace at {semantics_dir}."
        )

    detail = f"Initialized semantics store runtime in {semantics_dir}."
    if removed_paths:
        detail += f" Removed stale legacy semantics artifacts: {', '.join(removed_paths)}."
    report.steps.append(
        StepReport.completed(
            "semantics_init",
            "success",
            detail,
            started_at=started_at,
            ended_at=current_timestamp(),
        )
    )


def _initialize_distribution_workspace(
    options: InstallerOptions,
    plan: InstallPlan,
    report: InstallationReport,
) -> tuple[Path, Path]:
    workspace_dir = _resolve_distribution_workspace_dir()
    semantics_dir = _resolve_distribution_semantics_dir(workspace_dir)
    workspace_dir.mkdir(parents=True, exist_ok=True)
    semantics_dir.mkdir(parents=True, exist_ok=True)
    report.steps.append(
        StepReport(
            "workspace_init",
            "success",
            f"Ensured distribution workspace at {workspace_dir} and semantics dir at {semantics_dir}.",
        )
    )
    report.notes.append(f"Distribution workspace: {workspace_dir}")
    report.notes.append(f"Distribution semantics dir: {semantics_dir}")

    selected_names = {item.package_name for item in plan.ordered_modules}
    required_semantics_packages = {"cf-ontology", "cf-semantics-store"}
    missing_semantics_packages = sorted(required_semantics_packages - selected_names)
    if missing_semantics_packages:
        report.steps.append(
            StepReport(
                "semantics_init",
                "skipped",
                "Skipped semantics initialization because required packages are missing from the selected distribution plan: "
                + ", ".join(missing_semantics_packages)
                + ".",
            )
        )
        _run_post_install_hooks(
            options,
            report,
            plan.hooks,
            workspace_dir=workspace_dir,
            semantics_dir=semantics_dir,
            cwd=Path.cwd(),
            run_hooks=False,
        )
        return workspace_dir, semantics_dir

    _recreate_semantics_runtime(
        semantics_dir,
        python_exe=options.python_exe,
        cwd=Path.cwd(),
        show_details=options.show_details,
        report=report,
    )

    _run_post_install_hooks(
        options,
        report,
        plan.hooks,
        workspace_dir=workspace_dir,
        semantics_dir=semantics_dir,
        cwd=Path.cwd(),
        run_hooks=True,
    )
    return workspace_dir, semantics_dir


def execute_install(options: InstallerOptions) -> dict[str, object]:
    with activate_event_stream(options.event_path), activate_console(
        show_details=options.show_details, log_path=options.log_path
    ):
        execution_mode = detect_execution_mode(options.repo_root, options.execution_mode)
        effective_run_demo = (
            options.run_demo if options.run_demo is not None else execution_mode == "repo"
        )
        manifest, plan = plan_installation(
            manifest_path=options.manifest_path,
            repo_root=options.repo_root,
            profile=options.profile,
            editable_overrides=options.editable_overrides,
            execution_mode=execution_mode,
            run_demo=effective_run_demo,
        )
        provider = WindowsProvider()
        if execution_mode == "distribution":
            clean_result: dict[str, object] = {
                "profile": "full-clean",
                "mode": "execute",
                "phases": {
                    "repo_clean": {"failure_classification": None},
                    "workspace_clean": {"failure_classification": None},
                },
                "notes": "Distribution mode: factory-reset not required (no repository state to clean). State deletion implied by fresh external installation.",
            }
            wizard_invocation = "cf setup install --mode distribution --profile full --run-demo"
        else:
            clean_result = None
            wizard_invocation = None
        report = _build_installation_report(
            command="cf_setup install",
            repo_root=options.repo_root,
            profile=plan.profile,
            dry_run=options.dry_run,
            execution_mode=execution_mode,
            manifest=manifest,
            plan=plan,
            clean_result=clean_result,
            wizard_invocation=wizard_invocation,
        )
        report.log_path = str(options.log_path) if options.log_path else None
        report.prerequisites = [item.to_dict() for item in provider.diagnose()]
        _emit_module_queued_events(plan)
        _emit_install_lifecycle_event(
            "install_started",
            options=options,
            execution_mode=execution_mode,
            package_names=[item.package_name for item in plan.ordered_modules],
        )
        before_snapshot = _prepare_report_tracking(report)

        if effective_run_demo:
            report.notes.append(
                "RunDemo requested; cf_setup will execute the minimal OPC UA invocation demo after installation steps complete."
            )
        if execution_mode == "distribution":
            report.notes.append(
                "Distribution mode uses packaged manifest resources and published package installs only."
            )

        try:
            if options.dry_run:
                report.steps.append(
                    StepReport("plan", "planned", "Dry-run only; no install steps executed.")
                )
                return _finalize_report(report, before_snapshot)

            if execution_mode == "distribution":
                report.steps.append(
                    StepReport(
                        "native_deps",
                        "skipped",
                        "Distribution mode does not invoke repository PowerShell prerequisites.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "build_engine",
                        "skipped",
                        "Distribution mode does not invoke repository build scripts.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "build_web",
                        "skipped",
                        "Distribution mode does not invoke repository build scripts.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "py_build_tooling",
                        "skipped",
                        "Distribution mode installs published artifacts only.",
                    )
                )
                install_items = [
                    item
                    for item in plan.ordered_modules
                    if not _is_distribution_package_already_satisfied(item)
                ]
                retained_items = [
                    item for item in plan.ordered_modules if item not in install_items
                ]
                package_names = [item.package_name for item in install_items]
                if package_names:
                    install_args = [
                        options.python_exe,
                        "-m",
                        "pip",
                        "install",
                        "--upgrade",
                    ]
                    if options.wheel_only:
                        install_args.extend(["--only-binary", ":all:", "--prefer-binary"])
                    install_args.extend(package_names)
                    _pip_install_distribution_packages(
                        package_names,
                        install_args,
                        Path.cwd(),
                        options.show_details,
                        report,
                        progress_mode=options.progress_mode,
                    )
                for item in retained_items:
                    installed_version = metadata.version(item.package_name)
                    report.steps.append(
                        StepReport(
                            f"install:{item.package_name}",
                            "success",
                            f"Module already installed at version {installed_version}, satisfying published target {item.pypi_version}; retained in distribution mode.",
                        )
                    )
                _refresh_current_python_import_paths()
                _emit_step_started("pip_check", "Running pip check.")
                pip_check = _run_command(
                    [options.python_exe, "-m", "pip", "check"],
                    Path.cwd(),
                    options.show_details,
                )
                if pip_check.returncode != 0:
                    raise RuntimeError("pip check failed after distribution-mode installation.")
                report.steps.append(
                    StepReport("pip_check", "success", "pip check completed successfully.")
                )
                workspace_dir, semantics_dir = _initialize_distribution_workspace(
                    options, plan, report
                )
                if effective_run_demo:
                    _ensure_managed_fuseki(options, report)
                    execute_run_demo(
                        RunDemoOptions(
                            repo_root=None,
                            python_exe=options.python_exe,
                            duckdb_version=options.duckdb_version,
                            native_arch=options.native_arch,
                            auto_install_missing_prereqs=options.auto_install_missing_prereqs,
                            skip_native_deps=options.skip_native_deps,
                            show_details=options.show_details,
                            log_path=options.log_path,
                            execution_mode="distribution",
                            workspace_dir=workspace_dir,
                            semantics_dir=semantics_dir,
                        ),
                        report,
                    )
                return _finalize_report(report, before_snapshot)

            if options.clean:
                assert options.repo_root is not None
                _stop_repo_pipeline_manager_daemons(options.repo_root, report)
                factory_reset_script = options.repo_root / "scripts" / "factory_reset_v2.ps1"
                reset_args = ["-Force", "-KeepVenv", "-KeepLogs"]
                if options.delete_native_deps:
                    reset_args.append("-DeleteNativeDeps")
                _run_script(factory_reset_script, reset_args, options, report, "factory_reset")
            else:
                report.steps.append(
                    StepReport("factory_reset", "skipped", "Clean install not requested.")
                )

            if not options.clean and options.repo_root is not None:
                _stop_repo_pipeline_manager_daemons(options.repo_root, report)

            editable_modules = [
                item for item in plan.ordered_modules if item.source == "editable"
            ]
            pypi_modules = [item for item in plan.ordered_modules if item.source == "pypi"]
            local_build_modules = [
                item for item in plan.ordered_modules if item.source == "local-build"
            ]
            if plan.requires_native_prereqs and not options.skip_native_deps:
                assert options.repo_root is not None
                native_script = options.repo_root / "scripts" / "setup_native_deps_v2.ps1"
                native_args = [
                    "-DuckdbVersion",
                    options.duckdb_version,
                    "-Arch",
                    options.native_arch,
                ]
                if options.auto_install_missing_prereqs:
                    native_args.append("-AutoInstallMissingPrereqs")
                _run_script(native_script, native_args, options, report, "native_deps")
            else:
                report.steps.append(
                    StepReport("native_deps", "skipped", "Native prerequisite setup skipped.")
                )

            if effective_run_demo and not options.skip_native_deps:
                _ensure_managed_fuseki(options, report)
            elif effective_run_demo:
                report.steps.append(
                    StepReport(
                        "fuseki",
                        "skipped",
                        "Managed Fuseki setup skipped because native prerequisites were skipped.",
                    )
                )

            if editable_modules or local_build_modules:
                _ensure_build_tooling(options, report)
            else:
                report.steps.append(
                    StepReport(
                        "py_build_tooling",
                        "skipped",
                        "No editable or local-build modules selected.",
                    )
                )

            editable_build_env = (
                _prepare_editable_build_env(options, report) if editable_modules else None
            )

            assert options.repo_root is not None
            report.steps.append(
                StepReport(
                    "uninstall_targets",
                    "skipped",
                    "Repo install reconciles packages in place and avoids global uninstall.",
                )
            )

            install_pypi_items = [
                item
                for item in pypi_modules
                if not _is_distribution_package_already_satisfied(item)
                and not _can_retain_self_hosted_cf_core_cli(item)
            ]
            retained_pypi_items = [
                item for item in pypi_modules if item not in install_pypi_items
            ]
            if install_pypi_items:
                package_names = [item.package_name for item in install_pypi_items]
                install_args = [options.python_exe, "-m", "pip", "install", "--upgrade"]
                if options.wheel_only:
                    install_args.extend(["--only-binary", ":all:", "--prefer-binary"])
                install_args.extend(package_names)
                try:
                    _pip_install_distribution_packages(
                        package_names,
                        install_args,
                        options.repo_root,
                        options.show_details,
                        report,
                        progress_mode=options.progress_mode,
                    )
                except RuntimeError:
                    for item in install_pypi_items:
                        _install_repo_module(
                            item,
                            options,
                            report,
                            editable_build_env=editable_build_env,
                            force_reinstall=True,
                        )

            for item in retained_pypi_items:
                if _can_retain_self_hosted_cf_core_cli(item):
                    _emit_self_hosted_cli_retained_step(item, report)
                    continue
                _emit_already_installed_step(item, report, mode_label="published")

            defer_web_modules = plan.requires_web_build and not options.skip_web_build
            ordered_repo_modules = [item for item in plan.ordered_modules if item.source != "pypi"]
            deferred_web_modules = [item for item in ordered_repo_modules if defer_web_modules and item.module.web_build]
            initial_repo_modules = [item for item in ordered_repo_modules if item not in deferred_web_modules]
            for item in initial_repo_modules:
                _install_repo_module(
                    item,
                    options,
                    report,
                    editable_build_env=editable_build_env,
                    force_reinstall=item.source == "editable",
                )
            _refresh_current_python_import_paths()

            if plan.requires_engine_build and not options.skip_engine_build:
                assert options.repo_root is not None
                _run_script(
                    options.repo_root / "scripts" / "build_cf_pipeline_engine_v2.ps1",
                    [],
                    options,
                    report,
                    "build_engine",
                )
            else:
                report.steps.append(
                    StepReport(
                        "build_engine",
                        "skipped",
                        "Engine build not required or explicitly skipped.",
                    )
                )

            if plan.requires_web_build and not options.skip_web_build:
                assert options.repo_root is not None
                _run_script(
                    options.repo_root / "scripts" / "build_cf_web_frontend.ps1",
                    [],
                    options,
                    report,
                    "build_web",
                )
            else:
                report.steps.append(
                    StepReport(
                        "build_web",
                        "skipped",
                        "Web build not required or explicitly skipped.",
                    )
                )

            for item in deferred_web_modules:
                _install_repo_module(
                    item,
                    options,
                    report,
                    editable_build_env=editable_build_env,
                    force_reinstall=True,
                )

            _emit_step_started("pip_check", "Running pip check.")
            pip_check = _run_command(
                [options.python_exe, "-m", "pip", "check"],
                options.repo_root,
                options.show_details,
            )
            if pip_check.returncode != 0:
                raise RuntimeError("pip check failed after installation.")
            report.steps.append(
                StepReport("pip_check", "success", "pip check completed successfully.")
            )

            workspace_dir = _resolve_repo_workspace_dir(options.repo_root)
            workspace_dir.mkdir(parents=True, exist_ok=True)
            semantics_dir = workspace_dir / "semantics"
            semantics_dir.mkdir(parents=True, exist_ok=True)
            selected_names = {item.package_name for item in plan.ordered_modules}
            if "cf-ontology" in selected_names:
                _recreate_semantics_runtime(
                    semantics_dir,
                    python_exe=options.python_exe,
                    cwd=options.repo_root,
                    show_details=options.show_details,
                    report=report,
                )

            _run_post_install_hooks(
                options,
                report,
                plan.hooks,
                workspace_dir=workspace_dir,
                semantics_dir=semantics_dir,
                cwd=options.repo_root,
                run_hooks=True,
            )

            if effective_run_demo:
                assert options.repo_root is not None
                _emit_progress("Starting demo after installation")
                execute_run_demo(
                    RunDemoOptions(
                        repo_root=options.repo_root,
                        python_exe=options.python_exe,
                        duckdb_version=options.duckdb_version,
                        native_arch=options.native_arch,
                        auto_install_missing_prereqs=options.auto_install_missing_prereqs,
                        skip_native_deps=options.skip_native_deps,
                        show_details=options.show_details,
                        log_path=options.log_path,
                        execution_mode="repo",
                    ),
                    report,
                )

            return _finalize_report(report, before_snapshot)
        except Exception as exc:
            _record_failure(options, report, exc)
            raise
        finally:
            payload = _finalize_report(report, before_snapshot)
            if options.report_path:
                write_json_report(options.report_path, payload)
            _emit_install_lifecycle_event(
                "install_finished",
                options=options,
                execution_mode=execution_mode,
                package_names=[item.package_name for item in plan.ordered_modules],
                status=(
                    "failed" if any(step.status == "failed" for step in report.steps) else "success"
                ),
            )


def execute_incremental(options: InstallerOptions) -> dict[str, object]:
    with activate_event_stream(options.event_path), activate_console(
        show_details=options.show_details, log_path=options.log_path
    ):
        execution_mode = detect_execution_mode(options.repo_root, options.execution_mode)
        detection: ChangedModuleSelection | None = None
        requested_modules = options.modules
        if options.changed_only:
            detection_manifest = load_manifest(options.manifest_path)
            detection = detect_changed_modules(
                detection_manifest,
                options.repo_root or Path.cwd(),
                base_ref=options.base_ref,
                include_worktree_changes=options.include_worktree_changes,
            )
            requested_modules = detection.requested_modules
        manifest, plan = plan_incremental_installation(
            manifest_path=options.manifest_path,
            repo_root=options.repo_root,
            modules=requested_modules,
            editable_overrides=options.editable_overrides,
            execution_mode=execution_mode,
            run_demo=bool(options.run_demo),
            allow_empty=options.changed_only,
        )
        provider = WindowsProvider()
        report = _build_installation_report(
            command="cf_setup incremental",
            repo_root=options.repo_root,
            profile=plan.profile,
            dry_run=options.dry_run,
            execution_mode=execution_mode,
            manifest=manifest,
            plan=plan,
        )
        report.log_path = str(options.log_path) if options.log_path else None
        report.prerequisites = [item.to_dict() for item in provider.diagnose()]
        _emit_module_queued_events(plan)
        _emit_install_lifecycle_event(
            "install_started",
            options=options,
            execution_mode=execution_mode,
            package_names=[item.package_name for item in plan.ordered_modules],
        )
        before_snapshot = _prepare_report_tracking(report)
        report.notes.append(
            "Incremental mode updates the requested module scope plus compile/tooling prerequisites."
        )
        if detection is not None:
            report.changed_files = list(detection.changed_files)
            report.unmatched_changed_files = list(detection.unmatched_files)
            report.change_detection = detection.to_dict()
            if detection.requested_modules:
                detail = ", ".join(detection.requested_modules)
                report.steps.append(
                    StepReport(
                        "change_detection",
                        "success",
                        f"Detected changed module scope from git diff against {detection.base_ref or 'working tree'}: {detail}.",
                    )
                )
            else:
                report.steps.append(
                    StepReport(
                        "change_detection",
                        "skipped",
                        f"No manifest modules matched the detected changed files against {detection.base_ref or 'working tree'}.",
                    )
                )
            if detection.critical_unmatched_files:
                report.notes.append(
                    "Critical unmapped change(s) were detected outside manifest module paths: "
                    + ", ".join(detection.critical_unmatched_files)
                )
            elif detection.unmatched_files:
                report.notes.append(
                    "Unmapped changed files were ignored for module selection: "
                    + ", ".join(detection.unmatched_files)
                )
        if options.run_demo:
            report.notes.append(
                "RunDemo requested; cf_setup will execute the minimal OPC UA invocation demo after incremental installation."
            )
            if execution_mode == "repo":
                report.notes.append(
                    "Incremental planning may bootstrap the minimal demo step packages when their plugin artifacts are not already available."
                )
        if options.smoke:
            report.notes.append(
                "Smoke requested; cf_setup will run the lightweight post-install smoke path."
            )
        if execution_mode == "distribution":
            report.notes.append(
                "Distribution mode uses packaged manifest resources and published package installs only."
            )

        try:
            if options.changed_only and not plan.ordered_modules:
                report.steps.append(
                    StepReport(
                        "plan",
                        "skipped",
                        "No install actions are required because no changed files mapped to manifest modules.",
                    )
                )
                return _finalize_report(report, before_snapshot)

            if options.dry_run:
                report.steps.append(
                    StepReport(
                        "plan",
                        "planned",
                        "Dry-run only; no incremental install steps executed.",
                    )
                )
                return _finalize_report(report, before_snapshot)

            if execution_mode == "distribution":
                report.steps.append(
                    StepReport(
                        "native_deps",
                        "skipped",
                        "Distribution mode does not invoke repository PowerShell prerequisites.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "build_engine",
                        "skipped",
                        "Incremental mode does not invoke standalone engine builds.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "build_web",
                        "skipped",
                        "Distribution mode does not invoke repository build scripts.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "py_build_tooling",
                        "skipped",
                        "Distribution mode installs published artifacts only.",
                    )
                )
                report.steps.append(
                    StepReport(
                        "uninstall_targets",
                        "skipped",
                        "Incremental mode never performs global uninstall.",
                    )
                )

                install_items = [
                    item
                    for item in plan.ordered_modules
                    if not _is_distribution_package_already_satisfied(item)
                ]
                retained_items = [
                    item for item in plan.ordered_modules if item not in install_items
                ]
                package_names = [item.package_name for item in install_items]
                if package_names:
                    install_args = [
                        options.python_exe,
                        "-m",
                        "pip",
                        "install",
                        "--upgrade",
                    ]
                    if options.wheel_only:
                        install_args.extend(["--only-binary", ":all:", "--prefer-binary"])
                    install_args.extend(package_names)
                    _pip_install_distribution_packages(
                        package_names,
                        install_args,
                        Path.cwd(),
                        options.show_details,
                        report,
                        progress_mode=options.progress_mode,
                    )
                for item in retained_items:
                    installed_version = metadata.version(item.package_name)
                    report.steps.append(
                        StepReport(
                            f"install:{item.package_name}",
                            "success",
                            f"Module already installed at version {installed_version}, satisfying published target {item.pypi_version}; retained in incremental mode.",
                        )
                    )

                _refresh_current_python_import_paths()
                _emit_step_started("pip_check", "Running pip check.")
                pip_check = _run_command(
                    [options.python_exe, "-m", "pip", "check"],
                    Path.cwd(),
                    options.show_details,
                )
                if pip_check.returncode != 0:
                    raise RuntimeError("pip check failed after incremental installation.")
                report.steps.append(
                    StepReport("pip_check", "success", "pip check completed successfully.")
                )

                workspace_dir = _resolve_distribution_workspace_dir()
                semantics_dir = _resolve_distribution_semantics_dir(workspace_dir)
                workspace_dir.mkdir(parents=True, exist_ok=True)
                semantics_dir.mkdir(parents=True, exist_ok=True)
                report.steps.append(
                    StepReport(
                        "workspace_init",
                        "success",
                        f"Ensured distribution workspace at {workspace_dir} and semantics dir at {semantics_dir}.",
                    )
                )

                selected_names = {item.package_name for item in plan.ordered_modules}
                should_recreate_semantics = "cf-ontology" in selected_names or (
                    _step_modules_in_scope(plan)
                    and _repo_semantics_requires_recreate(semantics_dir)
                )
                if should_recreate_semantics:
                    _recreate_semantics_runtime(
                        semantics_dir,
                        python_exe=options.python_exe,
                        cwd=Path.cwd(),
                        show_details=options.show_details,
                        report=report,
                    )
                else:
                    report.steps.append(
                        StepReport(
                            "semantics_init",
                            "skipped",
                            "Incremental scope does not require semantics reinitialization.",
                        )
                    )

                _run_post_install_hooks(
                    options,
                    report,
                    plan.hooks,
                    workspace_dir=workspace_dir,
                    semantics_dir=semantics_dir,
                    cwd=Path.cwd(),
                    run_hooks=(
                        "cf-ontology" in selected_names or _step_modules_in_scope(plan)
                    ),
                )

                if options.smoke:
                    _run_incremental_smoke(options, plan, report, cwd=Path.cwd())

                if options.run_demo:
                    _ensure_managed_fuseki(options, report)
                    execute_run_demo(
                        RunDemoOptions(
                            repo_root=None,
                            python_exe=options.python_exe,
                            duckdb_version=options.duckdb_version,
                            native_arch=options.native_arch,
                            auto_install_missing_prereqs=options.auto_install_missing_prereqs,
                            skip_native_deps=options.skip_native_deps,
                            show_details=options.show_details,
                            log_path=options.log_path,
                            execution_mode="distribution",
                            workspace_dir=workspace_dir,
                            semantics_dir=semantics_dir,
                        ),
                        report,
                    )
                return _finalize_report(report, before_snapshot)

            report.steps.append(
                StepReport(
                    "factory_reset",
                    "skipped",
                    "Incremental mode does not run factory reset.",
                )
            )
            report.steps.append(
                StepReport(
                    "uninstall_targets",
                    "skipped",
                    "Incremental mode never performs global uninstall.",
                )
            )

            editable_modules = [
                item for item in plan.ordered_modules if item.source == "editable"
            ]
            local_build_modules = [
                item for item in plan.ordered_modules if item.source == "local-build"
            ]
            if plan.requires_native_prereqs and not options.skip_native_deps:
                assert options.repo_root is not None
                native_script = options.repo_root / "scripts" / "setup_native_deps_v2.ps1"
                native_args = [
                    "-DuckdbVersion",
                    options.duckdb_version,
                    "-Arch",
                    options.native_arch,
                ]
                if options.auto_install_missing_prereqs:
                    native_args.append("-AutoInstallMissingPrereqs")
                _run_script(native_script, native_args, options, report, "native_deps")
            else:
                report.steps.append(
                    StepReport("native_deps", "skipped", "Native prerequisite setup skipped.")
                )

            if options.run_demo and not options.skip_native_deps:
                _ensure_managed_fuseki(options, report)
            elif options.run_demo:
                report.steps.append(
                    StepReport(
                        "fuseki",
                        "skipped",
                        "Managed Fuseki setup skipped because native prerequisites were skipped.",
                    )
                )

            report.steps.append(
                StepReport(
                    "build_engine",
                    "skipped",
                    "Incremental mode does not invoke standalone engine builds.",
                )
            )

            if editable_modules or local_build_modules:
                _ensure_build_tooling(options, report)
            else:
                report.steps.append(
                    StepReport(
                        "py_build_tooling",
                        "skipped",
                        "No editable or local-build modules selected.",
                    )
                )

            editable_build_env = (
                _prepare_editable_build_env(options, report) if editable_modules else None
            )

            explicit_requested_modules = set(plan.requested_modules)
            defer_web_modules = plan.requires_web_build and not options.skip_web_build
            assert options.repo_root is not None
            deferred_web_modules = [item for item in plan.ordered_modules if defer_web_modules and item.module.web_build]
            initial_modules = [item for item in plan.ordered_modules if item not in deferred_web_modules]
            for item in initial_modules:
                _install_repo_module(
                    item,
                    options,
                    report,
                    editable_build_env=editable_build_env,
                    force_reinstall=item.source == "editable"
                    and item.package_name in explicit_requested_modules,
                )

            _refresh_current_python_import_paths()

            if plan.requires_web_build and not options.skip_web_build:
                _run_script(
                    options.repo_root / "scripts" / "build_cf_web_frontend.ps1",
                    [],
                    options,
                    report,
                    "build_web",
                )
            else:
                report.steps.append(
                    StepReport(
                        "build_web",
                        "skipped",
                        "Web build not required or explicitly skipped.",
                    )
                )

            for item in deferred_web_modules:
                _install_repo_module(
                    item,
                    options,
                    report,
                    editable_build_env=editable_build_env,
                    force_reinstall=True,
                )

            _emit_step_started("pip_check", "Running pip check.")
            pip_check = _run_command(
                [options.python_exe, "-m", "pip", "check"],
                options.repo_root,
                options.show_details,
            )
            if pip_check.returncode != 0:
                raise RuntimeError("pip check failed after incremental installation.")
            report.steps.append(
                StepReport("pip_check", "success", "pip check completed successfully.")
            )

            workspace_dir = _resolve_repo_workspace_dir(options.repo_root)
            workspace_dir.mkdir(parents=True, exist_ok=True)
            semantics_dir = workspace_dir / "semantics"
            semantics_dir.mkdir(parents=True, exist_ok=True)
            selected_names = {item.package_name for item in plan.ordered_modules}
            should_recreate_semantics = "cf-ontology" in selected_names or (
                _step_modules_in_scope(plan)
                and _repo_semantics_requires_recreate(semantics_dir)
            )
            if should_recreate_semantics:
                _recreate_semantics_runtime(
                    semantics_dir,
                    python_exe=options.python_exe,
                    cwd=options.repo_root,
                    show_details=options.show_details,
                    report=report,
                )
            else:
                report.steps.append(
                    StepReport(
                        "semantics_init",
                        "skipped",
                        "Incremental scope does not require semantics reinitialization.",
                    )
                )

            _run_post_install_hooks(
                options,
                report,
                plan.hooks,
                workspace_dir=workspace_dir,
                semantics_dir=semantics_dir,
                cwd=options.repo_root,
                run_hooks=(
                    "cf-ontology" in selected_names or _step_modules_in_scope(plan)
                ),
            )

            if options.smoke:
                _run_incremental_smoke(options, plan, report, cwd=options.repo_root)

            if options.run_demo:
                _emit_progress("Starting demo after incremental installation")
                execute_run_demo(
                    RunDemoOptions(
                        repo_root=options.repo_root,
                        python_exe=options.python_exe,
                        duckdb_version=options.duckdb_version,
                        native_arch=options.native_arch,
                        auto_install_missing_prereqs=options.auto_install_missing_prereqs,
                        skip_native_deps=options.skip_native_deps,
                        show_details=options.show_details,
                        log_path=options.log_path,
                        execution_mode="repo",
                    ),
                    report,
                )

            return _finalize_report(report, before_snapshot)
        except Exception as exc:
            _record_failure(options, report, exc)
            raise
        finally:
            payload = _finalize_report(report, before_snapshot)
            if options.report_path:
                write_json_report(options.report_path, payload)
            _emit_install_lifecycle_event(
                "install_finished",
                options=options,
                execution_mode=execution_mode,
                package_names=[item.package_name for item in plan.ordered_modules],
                status=(
                    "failed" if any(step.status == "failed" for step in report.steps) else "success"
                ),
            )


def manifest_path_from_args(manifest_path: str | None, repo_root: Path) -> Path:
    if manifest_path:
        return Path(manifest_path).resolve()
    return DEFAULT_MANIFEST_PATH


def output_payload(payload: dict[str, object], output: Path | None) -> None:
    if output:
        write_json_report(output, payload)
    else:
        print(json.dumps(payload, indent=2))


def build_options_from_namespace(args) -> InstallerOptions:
    raw_repo_root = getattr(args, "repo_root", None)
    requested_mode = getattr(args, "mode", "auto")
    detected_mode = "distribution" if requested_mode == "distribution" else "repo"
    repo_root = None if detected_mode == "distribution" else (Path(raw_repo_root).resolve() if raw_repo_root else find_repo_root())
    manifest_path = manifest_path_from_args(
        getattr(args, "manifest", None), repo_root or Path.cwd()
    )
    log_path = (
        Path(args.log_path).resolve() if getattr(args, "log_path", None) else None
    )
    event_path = (
        Path(args.event_path).resolve() if getattr(args, "event_path", None) else None
    )
    report_path = Path(args.output).resolve() if getattr(args, "output", None) else None
    return InstallerOptions(
        command_name=getattr(args, "command", "install"),
        repo_root=repo_root,
        manifest_path=manifest_path,
        execution_mode=getattr(args, "mode", "auto"),
        profile=getattr(args, "profile", "incremental"),
        modules=tuple(getattr(args, "module", []) or ()),
        python_exe=args.python,
        editable_overrides=tuple(args.editable or ()),
        wheel_only=args.wheel_only,
        clean=getattr(args, "clean", False),
        delete_native_deps=getattr(args, "delete_native_deps", False),
        skip_native_deps=getattr(args, "skip_native_deps", False),
        auto_install_missing_prereqs=getattr(
            args, "auto_install_missing_prereqs", False
        ),
        skip_engine_build=getattr(args, "skip_engine_build", False),
        skip_web_build=getattr(args, "skip_web_build", False),
        duckdb_version=getattr(args, "duckdb_version", "1.4.2"),
        native_arch=getattr(args, "native_arch", "x64-windows-static"),
        show_details=getattr(args, "show_details", False),
        smoke=getattr(args, "smoke", False),
        run_demo=getattr(args, "run_demo", None),
        dry_run=getattr(args, "dry_run", False),
        progress_mode=getattr(args, "progress_mode", "batch"),
        changed_only=getattr(args, "changed_only", False),
        base_ref=getattr(args, "base_ref", None),
        include_worktree_changes=getattr(args, "include_worktree_changes", True),
        log_path=log_path,
        event_path=event_path,
        report_path=report_path,
    )
