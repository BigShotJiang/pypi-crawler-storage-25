from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass

from .manifest import HookDefinition, InstallManifest, ModuleDefinition, normalize_name


@dataclass(frozen=True)
class SourceDecision:
    source: str
    reason: str
    local_version: str | None
    pypi_version: str | None


@dataclass(frozen=True)
class PlannedModule:
    package_name: str
    module: ModuleDefinition
    source: str
    reason: str
    local_version: str | None
    pypi_version: str | None


@dataclass(frozen=True)
class InstallPlan:
    profile: str
    requested_modules: tuple[str, ...]
    ordered_modules: tuple[PlannedModule, ...]
    hooks: tuple[HookDefinition, ...]

    @property
    def editable_modules(self) -> tuple[PlannedModule, ...]:
        return tuple(item for item in self.ordered_modules if item.source == "editable")

    @property
    def local_source_modules(self) -> tuple[PlannedModule, ...]:
        return tuple(item for item in self.ordered_modules if item.source in {"editable", "local-build"})

    @property
    def requires_native_prereqs(self) -> bool:
        return any(item.module.native_prereqs and item.source in {"editable", "local-build"} for item in self.ordered_modules)

    @property
    def requires_engine_build(self) -> bool:
        return any(item.module.engine_build and item.source in {"editable", "local-build"} for item in self.ordered_modules)

    @property
    def requires_web_build(self) -> bool:
        return any(item.module.web_build and item.source in {"editable", "local-build"} for item in self.ordered_modules)


def resolve_requested_modules(manifest: InstallManifest, requested_modules: tuple[str, ...]) -> tuple[str, ...]:
    resolved: list[str] = []
    seen: set[str] = set()
    for raw_name in requested_modules:
        module_name = manifest.resolve_module_name(raw_name)
        if module_name in seen:
            continue
        seen.add(module_name)
        resolved.append(module_name)
    return tuple(resolved)


def expand_profile(manifest: InstallManifest, profile_name: str) -> tuple[str, ...]:
    normalized_profile = normalize_name(profile_name)
    if normalized_profile not in manifest.profiles:
        supported = ", ".join(sorted(manifest.profiles))
        raise ValueError(f"Unknown profile '{profile_name}'. Supported profiles: {supported}")

    resolved: list[str] = []
    seen_profiles: set[str] = set()
    seen_modules: set[str] = set()

    def _expand(current_profile: str) -> None:
        if current_profile in seen_profiles:
            return
        seen_profiles.add(current_profile)
        for entry in manifest.profiles[current_profile]:
            if entry.startswith("profile:"):
                referenced_profile = normalize_name(entry.split(":", 1)[1])
                if referenced_profile not in manifest.profiles:
                    raise ValueError(f"Profile '{current_profile}' references unknown profile '{referenced_profile}'.")
                _expand(referenced_profile)
                continue
            module_name = manifest.resolve_module_name(entry)
            if module_name not in seen_modules:
                seen_modules.add(module_name)
                resolved.append(module_name)

    _expand(normalized_profile)
    return tuple(resolved)


def add_dependency_closure(manifest: InstallManifest, requested_modules: tuple[str, ...]) -> tuple[str, ...]:
    return add_dependency_closure_for_kinds(manifest, requested_modules, None)


def add_dependency_closure_for_kinds(
    manifest: InstallManifest,
    requested_modules: tuple[str, ...],
    allowed_kinds: set[str] | None,
) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()

    def _visit(module_name: str) -> None:
        if module_name in seen:
            return
        seen.add(module_name)
        for dependency in manifest.modules[module_name].dependencies:
            if allowed_kinds is not None and dependency.kind not in allowed_kinds:
                continue
            _visit(dependency.package_name)
        ordered.append(module_name)

    for module_name in requested_modules:
        _visit(module_name)
    return tuple(ordered)


def add_dependent_closure(manifest: InstallManifest, requested_modules: tuple[str, ...]) -> tuple[str, ...]:
    return add_dependent_closure_for_kinds(manifest, requested_modules, None)


def add_dependent_closure_for_kinds(
    manifest: InstallManifest,
    requested_modules: tuple[str, ...],
    allowed_kinds: set[str] | None,
) -> tuple[str, ...]:
    reverse_dependencies: dict[str, list[str]] = defaultdict(list)
    for module_name, definition in manifest.modules.items():
        for dependency in definition.dependencies:
            if allowed_kinds is not None and dependency.kind not in allowed_kinds:
                continue
            reverse_dependencies[dependency.package_name].append(module_name)

    ordered: list[str] = list(requested_modules)
    queue = deque(requested_modules)
    seen = set(requested_modules)

    while queue:
        current = queue.popleft()
        for dependent in sorted(reverse_dependencies.get(current, [])):
            if dependent in seen:
                continue
            seen.add(dependent)
            ordered.append(dependent)
            queue.append(dependent)
    return tuple(ordered)


def add_bidirectional_closure(manifest: InstallManifest, requested_modules: tuple[str, ...]) -> tuple[str, ...]:
    scope = resolve_requested_modules(manifest, requested_modules)
    previous: tuple[str, ...] | None = None
    while previous != scope:
        previous = scope
        with_dependencies = add_dependency_closure(manifest, scope)
        with_dependents = add_dependent_closure(manifest, with_dependencies)
        scope = resolve_requested_modules(manifest, with_dependents)
    return scope


def add_incremental_scope(manifest: InstallManifest, requested_modules: tuple[str, ...]) -> tuple[str, ...]:
    normalized = resolve_requested_modules(manifest, requested_modules)
    incremental_kinds = {"compile", "tooling"}
    return add_dependency_closure_for_kinds(manifest, normalized, incremental_kinds)


def topologically_sort(manifest: InstallManifest, module_names: tuple[str, ...]) -> tuple[str, ...]:
    selected = set(module_names)
    indegree: dict[str, int] = {name: 0 for name in module_names}
    outgoing: dict[str, list[str]] = defaultdict(list)
    for module_name in module_names:
        for dependency in manifest.modules[module_name].depends_on:
            if dependency not in selected:
                continue
            indegree[module_name] += 1
            outgoing[dependency].append(module_name)

    queue = deque(sorted(name for name, degree in indegree.items() if degree == 0))
    ordered: list[str] = []
    while queue:
        current = queue.popleft()
        ordered.append(current)
        for dependent in sorted(outgoing.get(current, [])):
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                queue.append(dependent)

    if len(ordered) != len(module_names):
        raise ValueError("Manifest dependency graph contains a cycle.")
    return tuple(ordered)


def build_install_plan(
    manifest: InstallManifest,
    profile_name: str,
    source_decisions: dict[str, SourceDecision],
    scope_modules: tuple[str, ...] | None = None,
) -> InstallPlan:
    requested_modules = expand_profile(manifest, profile_name)
    with_dependencies = scope_modules or add_dependency_closure(manifest, requested_modules)
    ordered_names = topologically_sort(manifest, with_dependencies)
    ordered_modules = tuple(
        PlannedModule(
            package_name=module_name,
            module=manifest.modules[module_name],
            source=source_decisions[module_name].source,
            reason=source_decisions[module_name].reason,
            local_version=source_decisions[module_name].local_version,
            pypi_version=source_decisions[module_name].pypi_version,
        )
        for module_name in ordered_names
    )
    selected_names = {item.package_name for item in ordered_modules}
    hooks = tuple(
        hook for hook in manifest.hooks if set(hook.requires_modules).issubset(selected_names) and hook.when == "post_install"
    )
    return InstallPlan(
        profile=normalize_name(profile_name),
        requested_modules=requested_modules,
        ordered_modules=ordered_modules,
        hooks=hooks,
    )


def build_incremental_plan(
    manifest: InstallManifest,
    requested_modules: tuple[str, ...],
    source_decisions: dict[str, SourceDecision],
) -> InstallPlan:
    normalized_requested = resolve_requested_modules(manifest, requested_modules)
    scope = add_incremental_scope(manifest, normalized_requested)
    ordered_names = topologically_sort(manifest, scope)
    ordered_modules = tuple(
        PlannedModule(
            package_name=module_name,
            module=manifest.modules[module_name],
            source=source_decisions[module_name].source,
            reason=source_decisions[module_name].reason,
            local_version=source_decisions[module_name].local_version,
            pypi_version=source_decisions[module_name].pypi_version,
        )
        for module_name in ordered_names
    )
    selected_names = {item.package_name for item in ordered_modules}
    hooks = tuple(
        hook for hook in manifest.hooks if set(hook.requires_modules).issubset(selected_names) and hook.when == "post_install"
    )
    return InstallPlan(
        profile="incremental",
        requested_modules=normalized_requested,
        ordered_modules=ordered_modules,
        hooks=hooks,
    )
