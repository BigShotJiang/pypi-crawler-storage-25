from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from .base import PrerequisiteProvider, ToolStatus


VSWHERE_CANDIDATES = (
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"),
    Path(r"C:\Program Files\Microsoft Visual Studio\Installer\vswhere.exe"),
)
VCVARS_CANDIDATES = (
    Path(r"C:\Program Files\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"),
    Path(r"C:\Program Files (x86)\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"),
)


def _command_version(command: list[str]) -> str | None:
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return None
    output = (completed.stdout or completed.stderr).strip().splitlines()
    return output[0].strip() if output else None


def _resolve_vswhere() -> Path | None:
    resolved = shutil.which("vswhere")
    if resolved:
        return Path(resolved)
    for candidate in VSWHERE_CANDIDATES:
        if candidate.exists():
            return candidate
    return None


def _resolve_msvc_installation_path() -> Path | None:
    vswhere = _resolve_vswhere()
    if vswhere is None:
        return None
    try:
        completed = subprocess.run(
            [
                str(vswhere),
                "-latest",
                "-products",
                "*",
                "-requires",
                "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                "-property",
                "installationPath",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return None
    install_path = Path(lines[0])
    return install_path if install_path.exists() else None


def _resolve_msvc_vcvars() -> Path | None:
    installation_path = _resolve_msvc_installation_path()
    if installation_path is not None:
        vcvars = installation_path / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
        if vcvars.exists():
            return vcvars
    for candidate in VCVARS_CANDIDATES:
        if candidate.exists():
            return candidate
    return None


class WindowsProvider(PrerequisiteProvider):
    name = "windows"
    _blocked_toolchain_markers = ("msys64", "mingw", "rtools")

    def diagnose(self) -> list[ToolStatus]:
        python_exe = Path(sys.executable)
        statuses = [
            ToolStatus(
                name="python",
                available=True,
                version=_command_version([str(python_exe), "--version"]),
                source=str(python_exe),
                detail="Current interpreter used for cf_setup.",
            ),
            ToolStatus(
                name="pip",
                available=True,
                version=_command_version([str(python_exe), "-m", "pip", "--version"]),
                source=str(python_exe),
                detail="Resolved via python -m pip.",
            ),
            ToolStatus(
                name="venv",
                available=True,
                version=None,
                source=str(python_exe),
                detail="Resolved via stdlib python -m venv.",
            ),
        ]
        statuses.extend(
            [
                self._binary_status("cmake", ["cmake", "--version"]),
                self._binary_status("git", ["git", "--version"]),
                self._binary_status("node", ["node", "--version"]),
                self._binary_status("npm", ["npm", "--version"]),
                self._msvc_status(),
            ]
        )
        return statuses

    def _binary_status(self, name: str, version_command: list[str]) -> ToolStatus:
        executable = shutil.which(name)
        if not executable:
            return ToolStatus(name=name, available=False, version=None, source=None, detail=f"{name} not found on PATH.")
        lowered = executable.lower()
        if name == "cmake" and any(marker in lowered for marker in self._blocked_toolchain_markers):
            return ToolStatus(
                name=name,
                available=False,
                version=_command_version(version_command),
                source=executable,
                detail="cmake resolves to an MSYS/MinGW/Rtools toolchain path and is not accepted for native builds.",
            )
        return ToolStatus(
            name=name,
            available=True,
            version=_command_version(version_command),
            source=executable,
            detail=f"{name} resolved from PATH.",
        )

    def _msvc_status(self) -> ToolStatus:
        cl_path = shutil.which("cl")
        if cl_path:
            return ToolStatus(
                name="msvc",
                available=True,
                version=_command_version(["cl"]),
                source=cl_path,
                detail="MSVC compiler found on PATH.",
            )

        vcvars = _resolve_msvc_vcvars()
        if vcvars is not None:
            return ToolStatus(
                name="msvc",
                available=True,
                version=None,
                source=str(vcvars),
                detail="Visual Studio Build Tools detected via vcvars64.bat.",
            )
        return ToolStatus(
            name="msvc",
            available=False,
            version=None,
            source=None,
            detail="MSVC Build Tools not detected on PATH or via vcvars64.bat.",
        )
