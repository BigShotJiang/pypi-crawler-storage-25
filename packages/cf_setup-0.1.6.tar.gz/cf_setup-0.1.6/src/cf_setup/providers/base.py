from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ToolStatus:
    name: str
    available: bool
    version: str | None
    source: str | None
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "available": self.available,
            "version": self.version,
            "source": self.source,
            "detail": self.detail,
        }


class PrerequisiteProvider:
    name = "base"

    def diagnose(self) -> list[ToolStatus]:
        raise NotImplementedError
