"""Prerequisite provider implementations for cf_setup."""
