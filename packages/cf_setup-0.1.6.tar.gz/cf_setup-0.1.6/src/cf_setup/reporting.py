from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
import json
from pathlib import Path
from contextlib import contextmanager
from typing import Callable
from typing import Iterator


def current_timestamp() -> datetime:
    return datetime.now().astimezone()


def timestamp_to_iso(value: datetime | None) -> str | None:
    return value.isoformat() if value is not None else None


def format_duration_seconds(value: float | None) -> str:
    if value is None:
        return ""
    if value < 1:
        return f"{value:.2f}s"
    if value < 60:
        return f"{value:.1f}s"
    minutes, seconds = divmod(value, 60)
    if minutes < 60:
        return f"{int(minutes)}m {seconds:04.1f}s"
    hours, minutes = divmod(int(minutes), 60)
    return f"{hours}h {minutes:02d}m {seconds:04.1f}s"


class EventStream:
    def __init__(self, path: Path | None) -> None:
        self.path = path.resolve() if path else None
        self._handle = None
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._handle = self.path.open("a", encoding="utf-8")

    def close(self) -> None:
        if self._handle is not None:
            self._handle.close()
            self._handle = None

    def emit(self, event_type: str, **payload: object) -> None:
        if self._handle is None:
            return
        event = {"type": event_type, "ts": current_timestamp().isoformat(), **payload}
        self._handle.write(json.dumps(event, ensure_ascii=True) + "\n")
        self._handle.flush()


_NULL_EVENT_STREAM = EventStream(None)
_ACTIVE_EVENT_STREAM: EventStream | None = None


def current_event_stream() -> EventStream:
    return _ACTIVE_EVENT_STREAM or _NULL_EVENT_STREAM


@contextmanager
def activate_event_stream(path: Path | None) -> Iterator[EventStream]:
    global _ACTIVE_EVENT_STREAM
    previous = _ACTIVE_EVENT_STREAM
    stream = EventStream(path)
    _ACTIVE_EVENT_STREAM = stream
    try:
        yield stream
    finally:
        stream.close()
        _ACTIVE_EVENT_STREAM = previous


@dataclass
class StepReport:
    step: str
    status: str
    detail: str
    started_at: str | None = None
    ended_at: str | None = None
    duration_seconds: float | None = None

    @classmethod
    def completed(
        cls,
        step: str,
        status: str,
        detail: str,
        *,
        started_at: datetime | None = None,
        ended_at: datetime | None = None,
    ) -> StepReport:
        if started_at is None or ended_at is None:
            return cls(step=step, status=status, detail=detail)
        return cls(
            step=step,
            status=status,
            detail=detail,
            started_at=timestamp_to_iso(started_at),
            ended_at=timestamp_to_iso(ended_at),
            duration_seconds=max((ended_at - started_at).total_seconds(), 0.0),
        )

    def to_dict(self) -> dict[str, str | float | None]:
        return {
            "step": self.step,
            "status": self.status,
            "detail": self.detail,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "duration_seconds": self.duration_seconds,
        }


class StepReportList(list[StepReport]):
    def __init__(self, emitter: Callable[[StepReport], None] | None = None) -> None:
        super().__init__()
        self.emitter = emitter

    def append(self, item: StepReport) -> None:
        super().append(item)
        if self.emitter is not None:
            self.emitter(item)


@dataclass
class InstallationReport:
    command: str
    repo_root: str | None
    profile: str
    dry_run: bool
    execution_mode: str = "repo"
    started_at: str = field(default_factory=lambda: current_timestamp().isoformat())
    finished_at: str | None = None
    duration_seconds: float | None = None
    log_path: str | None = None
    requested_modules: list[str] = field(default_factory=list)
    scope_modules: list[str] = field(default_factory=list)
    skipped_modules: list[str] = field(default_factory=list)
    changed_files: list[str] = field(default_factory=list)
    unmatched_changed_files: list[str] = field(default_factory=list)
    change_detection: dict[str, object] | None = None
    modules: list[dict[str, object]] = field(default_factory=list)
    prerequisites: list[dict[str, object]] = field(default_factory=list)
    steps: StepReportList = field(default_factory=StepReportList)
    hooks: list[dict[str, object]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    clean_result: dict[str, object] | None = field(default=None)
    wizard_invocation: str | None = field(default=None)

    def finalize(self) -> None:
        finished = current_timestamp()
        self.finished_at = finished.isoformat()
        started = datetime.fromisoformat(self.started_at)
        self.duration_seconds = max((finished - started).total_seconds(), 0.0)

    def to_dict(self) -> dict[str, object]:
        result: dict[str, object] = {
            "generated_at": current_timestamp().isoformat(),
            "command": self.command,
            "repo_root": self.repo_root,
            "profile": self.profile,
            "dry_run": self.dry_run,
            "execution_mode": self.execution_mode,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": self.duration_seconds,
            "log_path": self.log_path,
            "requested_modules": self.requested_modules,
            "scope_modules": self.scope_modules,
            "skipped_modules": self.skipped_modules,
            "changed_files": self.changed_files,
            "unmatched_changed_files": self.unmatched_changed_files,
            "change_detection": self.change_detection,
            "modules": self.modules,
            "prerequisites": self.prerequisites,
            "steps": [step.to_dict() for step in self.steps],
            "hooks": self.hooks,
            "notes": self.notes,
        }
        if self.clean_result is not None:
            result["clean_result"] = self.clean_result
        if self.wizard_invocation is not None:
            result["wizard_invocation"] = self.wizard_invocation
        return result


def write_json_report(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
