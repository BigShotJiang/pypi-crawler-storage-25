from pathlib import Path

from cf_setup.manifest import load_manifest

DISTRIBUTION_MANIFEST_PATH = (
    Path(__file__).resolve().parents[1] / "src" / "cf_setup" / "install_manifest_distribution.toml"
)


def test_distribution_manifest_has_no_local_paths() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    local_path_count = 0
    for module in manifest.modules.values():
        if hasattr(module, "path") and module.path:
            if module.path.startswith("sandcastle/") or module.path.startswith("resources/"):
                local_path_count += 1
    assert local_path_count == 0, f"Found {local_path_count} modules with local paths in distribution manifest"


def test_distribution_manifest_has_no_editable_true() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    editable_true_count = 0
    for module in manifest.modules.values():
        if hasattr(module, "editable") and module.editable is True:
            editable_true_count += 1
    assert editable_true_count == 0, f"Found {editable_true_count} modules with editable=true in distribution manifest"


def test_distribution_manifest_contains_all_required_modules() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    required_modules = {
        "cf-ontology",
        "cf-semantics-store",
        "cf-semantics-runtime",
        "cf-package-contracts",
        "cf-service-contracts",
        "cf-step-tooling",
        "cf-datahive",
        "cf-workspace-store",
        "cf-opcua-server",
        "cf-pipeline-cert",
        "cf-pipeline-creator",
        "cf-pipeline-report",
        "cf-pipeline-sdk",
        "cf-pipeline-engine",
        "cf-pipeline-manager",
        "cf-core-cli",
        "cf-setup",
        "cf-basic-dev",
        "cf-basic-io",
        "cf-basic-signal",
        "cf-basic-sinks",
        "cf-streamfind",
        "cf-web",
    }
    for module_name in required_modules:
        assert module_name in manifest.modules, f"Missing required module: {module_name}"


def test_distribution_manifest_has_all_profiles() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    assert "core" in manifest.profiles
    assert "steps" in manifest.profiles
    assert "web" in manifest.profiles
    assert "full" in manifest.profiles


def test_distribution_manifest_has_dependencies_preserved() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    assert "cf-workspace-store" in manifest.modules["cf-ontology"].depends_on
    assert "cf-service-contracts" in manifest.modules["cf-ontology"].depends_on
    assert "cf-semantics-runtime" in manifest.modules["cf-ontology"].depends_on
    assert "cf-package-contracts" in manifest.modules["cf-datahive"].depends_on
    assert "cf-workspace-store" in manifest.modules["cf-datahive"].depends_on


def test_distribution_manifest_hooks_preserved() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    assert any(hook.hook_id == "refresh-provider-registry" for hook in manifest.hooks)
    assert any(hook.hook_id == "ingest-installed-steps" for hook in manifest.hooks)
    assert any(hook.hook_id == "prime-pipeline-editor-steps" for hook in manifest.hooks)


def test_distribution_manifest_native_prereqs_preserved() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    assert manifest.modules["cf-datahive"].native_prereqs is True
    assert manifest.modules["cf-workspace-store"].native_prereqs is True
    assert manifest.modules["cf-opcua-server"].native_prereqs is True
    assert manifest.modules["cf-basic-io"].native_prereqs is True
    assert manifest.modules["cf-basic-signal"].native_prereqs is True
    assert manifest.modules["cf-basic-sinks"].native_prereqs is True
    assert manifest.modules["cf-streamfind"].native_prereqs is True


def test_distribution_manifest_web_build_preserved() -> None:
    manifest = load_manifest(DISTRIBUTION_MANIFEST_PATH)
    assert manifest.modules["cf-web"].web_build is True


def test_distribution_manifest_included_in_package_data() -> None:
    import tomllib
    pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
    with pyproject_path.open("rb") as f:
        pyproject = tomllib.load(f)

    package_data = pyproject.get("tool", {}).get("setuptools", {}).get("package-data", {}).get("cf_setup", [])
    assert "install_manifest_distribution.toml" in package_data, (
        f"install_manifest_distribution.toml must be in cf_setup package-data. "
        f"Current package-data: {package_data}. "
        "R7/R8/R16: Distribution manifest must be included in packaged cf-setup artifacts."
    )