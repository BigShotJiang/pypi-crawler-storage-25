from importlib import metadata
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from cf_setup import DEFAULT_MANIFEST_PATH, REPO_ROOT
from types import SimpleNamespace

from cf_setup.console import ConsoleLogger, activate_console
from cf_setup.installer import (
    ChangedModuleSelection,
    InstallerOptions,
    InstalledPackageState,
    _build_installation_report,
    _is_editable_module_already_satisfied,
    _installed_package_runtime_requirements_satisfied,
    _is_local_build_module_already_satisfied,
    _remove_editable_shadow_packages,
    _repo_semantics_requires_recreate,
    _resolve_msvc_installation_path,
    _resolve_visual_studio_cmake_generator,
    _run_post_install_hooks,
    _top_level_editable_import_names,
    _finalize_module_results,
    _run_command,
    _prepare_editable_build_env,
    _visual_studio_generator_major_from_installation_path,
    _pip_install_distribution_packages,
    build_options_from_namespace,
    detect_changed_modules,
    execute_incremental,
    execute_install,
    plan_installation,
    plan_incremental_installation,
    resolve_install_sources,
)
from cf_setup.manifest import load_manifest
from cf_setup.reporting import InstallationReport, StepReport, activate_event_stream


def _repo_root() -> Path:
    assert REPO_ROOT is not None
    return REPO_ROOT


def _fake_recreate_semantics_runtime(
    semantics_dir: Path,
    *,
    python_exe: str,
    cwd: Path,
    show_details: bool,
    report,
) -> None:
    semantics_dir.mkdir(parents=True, exist_ok=True)
    report.steps.append(
        StepReport("semantics_init", "success", f"Initialized semantics store runtime in {semantics_dir}.")
    )


def test_repo_semantics_requires_recreate_when_store_layout_is_missing(tmp_path: Path) -> None:
    assert _repo_semantics_requires_recreate(tmp_path / "semantics") is True


def test_repo_semantics_requires_recreate_when_core_store_graphs_exist(tmp_path: Path) -> None:
    semantics_dir = tmp_path / "semantics"
    store_root = semantics_dir / "rdf_store"
    (store_root / "tdb2").mkdir(parents=True, exist_ok=True)
    (store_root / "graphs").mkdir(parents=True, exist_ok=True)
    (store_root / "graphs.catalog.json").write_text(
        '[{"graph_id": "core"}, {"graph_id": "shapes"}]',
        encoding="utf-8",
    )

    assert _repo_semantics_requires_recreate(semantics_dir) is False


def test_installed_package_runtime_requirements_satisfied_detects_missing_dependency(monkeypatch) -> None:
    def fake_distribution(name: str):
        if name == "cf-opcua-server":
            return SimpleNamespace(requires=["asyncua>=1.0"])
        raise metadata.PackageNotFoundError(name)

    def fake_version(name: str) -> str:
        raise metadata.PackageNotFoundError(name)

    monkeypatch.setattr("cf_setup.installer.metadata.distribution", fake_distribution)
    monkeypatch.setattr("cf_setup.installer.metadata.version", fake_version)

    assert _installed_package_runtime_requirements_satisfied("cf-opcua-server") is False


def test_local_build_module_not_satisfied_when_runtime_dependency_is_missing(monkeypatch) -> None:
    item = SimpleNamespace(package_name="cf-pipeline-cert", local_version="0.2.3")

    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda package_name: InstalledPackageState(
            installed=True,
            version="0.2.3",
            editable=False,
            local_directory=True,
        ),
    )
    monkeypatch.setattr(
        "cf_setup.installer._installed_package_runtime_requirements_satisfied",
        lambda package_name: False,
    )

    assert _is_local_build_module_already_satisfied(item) is False


def test_local_build_module_not_satisfied_when_import_surface_is_missing(monkeypatch) -> None:
    item = SimpleNamespace(
        package_name="cf-package-contracts",
        local_version="0.1.1",
        module=SimpleNamespace(path="sandcastle/cf_package_contracts"),
    )

    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda package_name: InstalledPackageState(
            installed=True,
            version="0.1.1",
            editable=False,
            local_directory=True,
        ),
    )
    monkeypatch.setattr(
        "cf_setup.installer._installed_package_runtime_requirements_satisfied",
        lambda package_name: True,
    )
    monkeypatch.setattr(
        "cf_setup.installer._installed_package_import_surface_satisfied",
        lambda package_name, module_root=None: False,
    )

    assert _is_local_build_module_already_satisfied(item) is False


def test_editable_module_not_satisfied_when_import_surface_is_missing(monkeypatch) -> None:
    item = SimpleNamespace(
        package_name="cf-step-tooling",
        local_version="0.1.0",
        module=SimpleNamespace(path="sandcastle/cf_step_tooling"),
    )

    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda package_name: InstalledPackageState(
            installed=True,
            version="0.1.0",
            editable=True,
            local_directory=True,
        ),
    )
    monkeypatch.setattr(
        "cf_setup.installer._installed_package_runtime_requirements_satisfied",
        lambda package_name: True,
    )
    monkeypatch.setattr(
        "cf_setup.installer._installed_package_import_surface_satisfied",
        lambda package_name, module_root=None: False,
    )

    assert _is_editable_module_already_satisfied(item) is False


def test_top_level_editable_import_names_prefers_src_packages(tmp_path: Path) -> None:
    module_root = tmp_path / "cf_web"
    src_root = module_root / "src"
    (src_root / "cf_web").mkdir(parents=True)
    (src_root / "cf_web" / "__init__.py").write_text("", encoding="utf-8")
    (src_root / "helper.py").write_text("", encoding="utf-8")

    assert _top_level_editable_import_names(module_root, "cf-web") == (
        "cf_web",
        "helper",
    )


def test_remove_editable_shadow_packages_cleans_site_packages(monkeypatch, tmp_path: Path) -> None:
    module_root = tmp_path / "cf_web"
    src_root = module_root / "src"
    (src_root / "cf_web").mkdir(parents=True)
    (src_root / "cf_web" / "__init__.py").write_text("", encoding="utf-8")
    purelib = tmp_path / "site-packages"
    shadow_dir = purelib / "cf_web"
    shadow_dir.mkdir(parents=True)
    (shadow_dir / "cli.py").write_text("stale", encoding="utf-8")
    shadow_file = purelib / "cf_web.py"
    shadow_file.write_text("stale", encoding="utf-8")
    report = InstallationReport(
        command="install",
        repo_root=str(_repo_root()),
        profile="full",
        dry_run=False,
        execution_mode="repo",
    )
    monkeypatch.setattr("cf_setup.installer.sysconfig.get_paths", lambda: {"purelib": str(purelib)})

    _remove_editable_shadow_packages(module_root, "cf-web", report)

    assert not shadow_dir.exists()
    assert not shadow_file.exists()
    assert any("Removed stale editable shadow paths for cf-web" in note for note in report.notes)


def test_run_post_install_hooks_primes_pipeline_editor_steps(monkeypatch, tmp_path: Path) -> None:
    commands: list[list[str]] = []
    report = InstallationReport(
        command="install",
        repo_root=str(_repo_root()),
        profile="full",
        dry_run=False,
        execution_mode="repo",
    )
    report.hooks = [{"hook_id": "prime-pipeline-editor-steps", "status": "pending"}]
    hooks = (
        SimpleNamespace(
            hook_id="prime-pipeline-editor-steps",
            action="cf_web_prime_pipeline_editor_steps",
        ),
    )
    options = InstallerOptions(
        command_name="install",
        repo_root=_repo_root(),
        manifest_path=DEFAULT_MANIFEST_PATH,
        execution_mode="repo",
        profile="full",
        modules=(),
        python_exe="python",
        editable_overrides=(),
        wheel_only=False,
        clean=False,
        delete_native_deps=False,
        skip_native_deps=False,
        auto_install_missing_prereqs=False,
        skip_engine_build=False,
        skip_web_build=False,
        duckdb_version="1.4.2",
        native_arch="x64-windows-static",
        show_details=False,
        smoke=False,
        run_demo=False,
        dry_run=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        commands.append(args)
        return SimpleNamespace(returncode=0, stdout="17\n", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)

    _run_post_install_hooks(
        options,
        report,
        hooks,
        workspace_dir=tmp_path / "workspace",
        semantics_dir=tmp_path / "workspace" / "semantics",
        cwd=tmp_path,
        run_hooks=True,
    )

    assert commands
    assert commands[0][0:2] == ["python", "-c"]
    assert "getattr(service, 'prewarm_steps', service.get_steps)" in commands[0][2]
    assert any(step.step == "hook:prime-pipeline-editor-steps" for step in report.steps)


def test_dirty_compile_dependency_promotes_dependents_to_local_build(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.1.0")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: {"cf-package-contracts"})

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-package-contracts", "cf-pipeline-engine"),
        editable_overrides=(),
    )

    assert decisions["cf-package-contracts"].source == "editable"
    assert decisions["cf-pipeline-engine"].source == "local-build"
    assert "cf-package-contracts" in decisions["cf-pipeline-engine"].reason


def test_explicit_editable_override_is_preserved(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.1.0")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: set())

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-package-contracts", "cf-pipeline-engine"),
        editable_overrides=("cf-package-contracts",),
    )

    assert decisions["cf-package-contracts"].source == "editable"
    assert decisions["cf-pipeline-engine"].source == "local-build"
    assert decisions["cf-pipeline-engine"].reason.startswith("depends on local first-party compile/native module")


def test_local_version_ahead_uses_local_build(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "0.1.0")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.2.0")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: set())

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-ontology",),
        editable_overrides=(),
    )

    assert decisions["cf-ontology"].source == "local-build"
    assert decisions["cf-ontology"].reason == "local version is ahead of PyPI"


def test_repo_install_plan_includes_demo_packages_when_run_demo_is_enabled(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "0.0.0")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: set())

    _, plan = plan_installation(
        manifest_path=DEFAULT_MANIFEST_PATH,
        repo_root=_repo_root(),
        profile="core",
        editable_overrides=(),
        execution_mode="repo",
        run_demo=True,
    )

    ordered = {item.package_name: item for item in plan.ordered_modules}
    assert "cf-basic-io" in ordered
    assert ordered["cf-basic-io"].source == "local-build"


def test_tracked_changes_override_version_selection(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.1.0")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: {"cf-ontology"})

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-ontology",),
        editable_overrides=(),
    )

    assert decisions["cf-ontology"].source == "editable"
    assert decisions["cf-ontology"].reason == "tracked git changes detected in module path"


def test_distribution_mode_uses_pypi_sources(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "1.2.3")

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-datahive", "cf-pipeline-engine"),
        editable_overrides=("cf-datahive",),
        execution_mode="distribution",
    )

    assert decisions["cf-datahive"].source == "pypi"
    assert decisions["cf-pipeline-engine"].source == "pypi"
    assert decisions["cf-datahive"].reason == "distribution mode uses published package artifacts"


def test_repo_web_module_uses_local_source_even_when_pypi_is_available(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.2.7")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: set())

    decisions = resolve_install_sources(
        manifest=manifest,
        repo_root=_repo_root(),
        selected_modules=("cf-web",),
        editable_overrides=(),
    )

    assert decisions["cf-web"].source == "editable"
    assert decisions["cf-web"].reason == "repo web module requires local source build"


def test_distribution_mode_installs_published_packages_in_single_batch(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    original_version = metadata.version

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-ontology", "cf-semantics-store", "cf-pipeline-report", "cf-web"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-ontology",
                module=SimpleNamespace(path="sandcastle/cf_ontology"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.2.7",
            ),
            SimpleNamespace(
                package_name="cf-semantics-store",
                module=SimpleNamespace(path="sandcastle/cf_semantics_store"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.1.0",
            ),
            SimpleNamespace(
                package_name="cf-pipeline-report",
                module=SimpleNamespace(path="sandcastle/cf_pipeline/cf_pipeline_report"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.1.3",
            ),
            SimpleNamespace(
                package_name="cf-web",
                module=SimpleNamespace(path="sandcastle/cf_web"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.2.6",
            ),
        ),
        hooks=(
            SimpleNamespace(
                hook_id="ingest-installed-steps",
                action="cf_semantics_runtime_sync_installed_steps",
            ),
        ),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr(
        "cf_setup.installer.metadata.version",
        lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)) if name.startswith("cf-") else original_version(name),
    )
    # Force all packages through the install path (not the already-satisfied retention path)
    # so the batch install command is exercised regardless of the current dev environment state.
    monkeypatch.setattr("cf_setup.installer._is_distribution_package_already_satisfied", lambda item: False)
    monkeypatch.setattr("cf_setup.installer.Path.home", lambda: tmp_path)

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=None,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="distribution",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "distribution-report.json",
        )
    )

    assert command_calls[0] == [
        "python",
        "-m",
        "pip",
        "install",
        "--upgrade",
        "cf-ontology",
        "cf-semantics-store",
        "cf-pipeline-report",
        "cf-web",
    ]
    assert command_calls[1] == ["python", "-m", "pip", "check"]
    assert command_calls[2][:2] == ["python", "-c"]
    assert "CF_SEMANTICS_DIR" in command_calls[2][2]
    assert "provide_semantics_runtime_contract" in command_calls[2][2]
    assert "sync_installed_step_graphs_to_workspace" in command_calls[2][2]
    assert payload["execution_mode"] == "distribution"
    assert [step["step"] for step in payload["steps"] if step["step"].startswith("install:")] == [
        "install:cf-ontology",
        "install:cf-semantics-store",
        "install:cf-pipeline-report",
        "install:cf-web",
    ]
    assert any(step["step"] == "workspace_init" for step in payload["steps"])
    assert any(step["step"] == "semantics_init" and step["status"] == "success" for step in payload["steps"])


def test_precise_progress_mode_installs_distribution_packages_individually(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    event_path = tmp_path / "precise.events.jsonl"

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)

    report = InstallationReport(
        command="install",
        repo_root=str(tmp_path),
        profile="full",
        dry_run=False,
        execution_mode="distribution",
    )

    with activate_event_stream(event_path):
        _pip_install_distribution_packages(
            ["cf-ontology", "cf-web"],
            ["python", "-m", "pip", "install", "--upgrade", "cf-ontology", "cf-web"],
            tmp_path,
            False,
            report,
            progress_mode="precise",
        )

    assert command_calls == [
        ["python", "-m", "pip", "install", "--upgrade", "cf-ontology"],
        ["python", "-m", "pip", "install", "--upgrade", "cf-web"],
    ]
    assert [step.step for step in report.steps] == ["install:cf-ontology", "install:cf-web"]

    events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines()]
    assert [event["type"] for event in events] == [
        "module_state_changed",
        "step_started",
        "module_state_changed",
        "module_state_changed",
        "step_started",
        "module_state_changed",
    ]
    assert all(event["type"] != "batch_started" for event in events)
    assert [event.get("package") for event in events if event["type"] == "step_started"] == [
        "cf-ontology",
        "cf-web",
    ]


def test_distribution_mode_retains_already_satisfied_runtime_packages(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    original_version = metadata.version

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-core-cli", "cf-ontology"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-core-cli",
                module=SimpleNamespace(path="sandcastle/cf_core_cli"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.1.5",
            ),
            SimpleNamespace(
                package_name="cf-ontology",
                module=SimpleNamespace(path="sandcastle/cf_ontology"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.2.2",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    def fake_distribution(name: str):
        if name == "cf-core-cli":
            return SimpleNamespace(version="0.1.6", read_text=lambda _: None)
        raise metadata.PackageNotFoundError(name)

    monkeypatch.setattr("cf_setup.installer.metadata.distribution", fake_distribution)
    monkeypatch.setattr("cf_setup.installer.metadata.version", original_version)
    monkeypatch.setattr("cf_setup.installer.Path.home", lambda: tmp_path)

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=None,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="distribution",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "distribution-retained-report.json",
        )
    )

    assert command_calls[0] == [
        "python",
        "-m",
        "pip",
        "install",
        "--upgrade",
        "cf-ontology",
    ]
    assert any(
        step["step"] == "install:cf-core-cli"
        and "satisfying published target 0.1.5" in step["detail"]
        for step in payload["steps"]
    )


def test_distribution_mode_run_demo_uses_distribution_workspace(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    captured_demo_options: list[object] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    def fake_execute_run_demo(options, report):
        captured_demo_options.append(options)
        report.steps.append(StepReport("run_demo", "success", f"demo against {options.workspace_dir}"))

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-ontology", "cf-pipeline-engine"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-ontology",
                module=SimpleNamespace(path="sandcastle/cf_ontology"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.2.2",
            ),
            SimpleNamespace(
                package_name="cf-pipeline-engine",
                module=SimpleNamespace(path="sandcastle/cf_pipeline/cf_pipeline_engine"),
                source="pypi",
                reason="distribution mode uses published package artifacts",
                local_version=None,
                pypi_version="0.3.1",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.execute_run_demo", fake_execute_run_demo)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer.Path.home", lambda: tmp_path)

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=None,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="distribution",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=True,
            dry_run=False,
            report_path=tmp_path / "distribution-demo-report.json",
        )
    )

    assert captured_demo_options
    demo_options = captured_demo_options[0]
    assert demo_options.execution_mode == "distribution"
    assert demo_options.repo_root is None
    assert demo_options.workspace_dir == (tmp_path / ".cogniflow" / "workspace").resolve()
    assert demo_options.semantics_dir == (tmp_path / ".cogniflow" / "workspace" / "semantics").resolve()
    assert any(step["step"] == "run_demo" and step["status"] == "success" for step in payload["steps"])


def test_incremental_repo_mode_installs_only_scope_without_global_uninstall(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="incremental",
        requested_modules=("cf-basic-io",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-package-contracts",
                module=SimpleNamespace(path="sandcastle/cf_package_contracts"),
                source="editable",
                reason="explicit editable override",
                local_version="0.1.1",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-step-tooling",
                module=SimpleNamespace(path="sandcastle/cf_step_tooling"),
                source="editable",
                reason="explicit editable override",
                local_version="0.1.0",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-basic-io",
                module=SimpleNamespace(path="sandcastle/cf_basic_steps/cf_basic_io"),
                source="editable",
                reason="explicit editable override",
                local_version="0.2.6",
                pypi_version="0.2.4",
            ),
        ),
        hooks=(
            SimpleNamespace(
                hook_id="ingest-installed-steps",
                action="cf_semantics_runtime_sync_installed_steps",
            ),
        ),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_incremental_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr(
        "cf_setup.installer._ensure_build_tooling",
        lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")),
    )
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._repo_semantics_requires_recreate", lambda semantics_dir: False)
    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda package_name: InstalledPackageState(
            installed=True, version="0.1.0", editable=None, local_directory=None
        ),
    )

    payload = execute_incremental(
        InstallerOptions(
            command_name="incremental",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="incremental",
            modules=("cf-basic-io",),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "incremental-report.json",
        )
    )

    assert all(args[:4] != ["python", "-m", "pip", "uninstall"] for args in command_calls)
    install_calls = [args for args in command_calls if args[:4] == ["python", "-m", "pip", "install"]]
    assert len(install_calls) == 3
    assert all("-e" in args for args in install_calls)
    assert any(args[:3] == ["python", "-m", "pip"] and "check" in args for args in command_calls)
    assert any(
        args[:2] == ["python", "-c"]
        and "sync_installed_step_graphs_to_workspace" in args[2]
        for args in command_calls
    )
    assert payload["requested_modules"] == ["cf-basic-io"]
    assert payload["scope_modules"] == ["cf-package-contracts", "cf-step-tooling", "cf-basic-io"]
    assert any(module["package_name"] == "cf-step-tooling" and module["scope_status"] == "in_scope" for module in payload["modules"])
    assert any(module["package_name"] == "cf-basic-io" and module["result"] == "re-installed" for module in payload["modules"])
    assert any(module["package_name"] == "cf-web" and module["scope_status"] == "out_of_scope" for module in payload["modules"])
    assert any(step["step"] == "uninstall_targets" and step["status"] == "skipped" for step in payload["steps"])


def test_incremental_repo_mode_runs_optional_smoke_and_demo(monkeypatch, tmp_path: Path) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="incremental",
        requested_modules=("cf-pipeline-report",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-pipeline-report",
                module=SimpleNamespace(path="sandcastle/cf_pipeline/cf_pipeline_report"),
                source="editable",
                reason="explicit editable override",
                local_version="0.1.4",
                pypi_version="0.1.3",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    smoke_calls: list[list[str]] = []
    demo_calls: list[object] = []

    def fake_run_command(args, cwd, show_details, extra_env=None):
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    def fake_smoke(options, current_plan, report, *, cwd):
        smoke_calls.append([item.package_name for item in current_plan.ordered_modules])
        report.steps.append(StepReport("smoke", "success", "smoke"))

    def fake_run_demo(options, report):
        demo_calls.append(options)
        report.steps.append(StepReport("run_demo", "success", "demo"))

    monkeypatch.setattr("cf_setup.installer.plan_incremental_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr(
        "cf_setup.installer._ensure_build_tooling",
        lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")),
    )
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_incremental_smoke", fake_smoke)
    monkeypatch.setattr("cf_setup.installer.execute_run_demo", fake_run_demo)

    payload = execute_incremental(
        InstallerOptions(
            command_name="incremental",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="incremental",
            modules=("cf-pipeline-report",),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=True,
            run_demo=True,
            dry_run=False,
            report_path=tmp_path / "incremental-smoke-report.json",
        )
    )

    assert smoke_calls == [["cf-pipeline-report"]]
    assert len(demo_calls) == 1
    assert any(step["step"] == "smoke" and step["status"] == "success" for step in payload["steps"])
    assert any(step["step"] == "run_demo" and step["status"] == "success" for step in payload["steps"])


def test_build_installation_report_includes_manifest_inventory() -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        requested_modules=("cf-basic-io",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-basic-io",
                module=SimpleNamespace(path="sandcastle/cf_basic_steps/cf_basic_io"),
                source="editable",
                reason="explicit editable override",
                local_version="0.1.4",
                pypi_version="0.1.3",
            ),
        ),
        hooks=(),
    )

    report = _build_installation_report(
        command="incremental",
        repo_root=_repo_root(),
        profile="incremental",
        dry_run=False,
        execution_mode="repo",
        manifest=manifest,
        plan=plan,
    )

    assert any(module["package_name"] == "cf-basic-io" and module["scope_status"] == "in_scope" for module in report.modules)
    assert any(module["package_name"] == "cf-web" and module["scope_status"] == "out_of_scope" for module in report.modules)


def test_finalize_module_results_marks_out_of_scope_modules_as_present_unchanged(monkeypatch) -> None:
    report = SimpleNamespace(dry_run=False, modules=[{"package_name": "cf-web", "scope_status": "out_of_scope"}])
    before_snapshot = {"cf-web": InstalledPackageState(installed=True, version="0.2.7", editable=False, local_directory=False)}

    monkeypatch.setattr(
        "cf_setup.installer._snapshot_installed_package_states",
        lambda package_names: {
            "cf-web": InstalledPackageState(installed=True, version="0.2.7", editable=False, local_directory=False)
        },
    )

    _finalize_module_results(report, before_snapshot)

    assert report.modules[0]["result"] == "already installed"


def test_plan_incremental_installation_bootstraps_missing_runtime_dependencies(monkeypatch) -> None:
    monkeypatch.setattr(
        "cf_setup.installer.fetch_latest_pypi_version",
        lambda name: {
            "cf-package-contracts": "0.1.0",
            "cf-workspace-store": "0.1.0",
            "cf-ontology": "0.2.7",
        }.get(name, "0.0.1"),
    )
    monkeypatch.setattr(
        "cf_setup.installer.metadata.distribution",
        lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)),
    )

    manifest, plan = plan_incremental_installation(
        manifest_path=DEFAULT_MANIFEST_PATH,
        repo_root=_repo_root(),
        modules=("cf-ontology",),
        editable_overrides=(),
        execution_mode="repo",
    )

    assert manifest.modules["cf-ontology"].package_name == "cf-ontology"
    assert plan.requested_modules == ("cf-ontology",)
    assert [item.package_name for item in plan.ordered_modules] == [
        "cf-package-contracts",
        "cf-service-contracts",
        "cf-workspace-store",
        "cf-semantics-store",
        "cf-semantics-runtime",
        "cf-ontology",
    ]


def test_plan_incremental_installation_bootstraps_demo_step_modules_when_demo_enabled(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: None)
    monkeypatch.setattr(
        "cf_setup.installer.metadata.distribution",
        lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)),
    )

    manifest, plan = plan_incremental_installation(
        manifest_path=DEFAULT_MANIFEST_PATH,
        repo_root=_repo_root(),
        modules=("cf-ontology",),
        editable_overrides=(),
        execution_mode="repo",
        run_demo=True,
    )

    assert manifest.modules["cf-basic-io"].package_name == "cf-basic-io"
    assert plan.requested_modules == ("cf-ontology",)
    assert [item.package_name for item in plan.ordered_modules] == [
        "cf-package-contracts",
        "cf-service-contracts",
        "cf-step-tooling",
        "cf-workspace-store",
        "cf-basic-io",
        "cf-basic-signal",
        "cf-basic-sinks",
        "cf-semantics-store",
        "cf-semantics-runtime",
        "cf-ontology",
    ]


def test_incremental_requested_pypi_module_keeps_satisfied_install(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="incremental",
        requested_modules=("cf-pipeline-report",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-pipeline-report",
                module=SimpleNamespace(path="sandcastle/cf_pipeline/cf_pipeline_report", editable=True),
                source="pypi",
                reason="PyPI-first default",
                local_version="0.1.4",
                pypi_version="0.1.4",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_incremental_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._repo_semantics_requires_recreate", lambda semantics_dir: False)
    monkeypatch.setattr("cf_setup.installer.metadata.distribution", lambda name: SimpleNamespace(version="0.1.4", read_text=lambda _: None))

    payload = execute_incremental(
        InstallerOptions(
            command_name="incremental",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="incremental",
            modules=("cf-pipeline-report",),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "incremental-force-report.json",
        )
    )

    assert not any("cf-pipeline-report" in args and args[:4] == ["python", "-m", "pip", "install"] for args in command_calls)
    assert any(module["package_name"] == "cf-pipeline-report" and module["result"] == "already installed" for module in payload["modules"])


def test_incremental_repo_mode_raises_when_pypi_install_fails(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="incremental",
        requested_modules=("cf-workspace-store",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-workspace-store",
                module=SimpleNamespace(path="sandcastle/cf_workspace_store", editable=True),
                source="pypi",
                reason="PyPI-first default",
                local_version="0.1.1",
                pypi_version="0.1.0",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        if args[:4] == ["python", "-m", "pip", "install"] and "cf-workspace-store" in args and "-e" not in args:
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_incremental_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._repo_semantics_requires_recreate", lambda semantics_dir: False)
    monkeypatch.setattr("cf_setup.installer.metadata.distribution", lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)))

    try:
        execute_incremental(
            InstallerOptions(
                command_name="incremental",
                repo_root=tmp_path,
                manifest_path=DEFAULT_MANIFEST_PATH,
                execution_mode="repo",
                profile="incremental",
                modules=("cf-workspace-store",),
                python_exe="python",
                editable_overrides=(),
                wheel_only=False,
                clean=False,
                delete_native_deps=False,
                skip_native_deps=False,
                auto_install_missing_prereqs=False,
                skip_engine_build=False,
                skip_web_build=False,
                duckdb_version="1.4.2",
                native_arch="x64",
                show_details=False,
                smoke=False,
                run_demo=False,
                dry_run=False,
                report_path=tmp_path / "incremental-pypi-failure-report.json",
            )
        )
    except RuntimeError as exc:
        assert str(exc) == "Failed to install module 'cf-workspace-store'."
    else:
        raise AssertionError("Expected incremental install to fail when the selected PyPI package install fails.")

    assert any(args == ["python", "-m", "pip", "install", "--upgrade", "cf-workspace-store"] for args in command_calls)
    assert not any(args[:6] == ["python", "-m", "pip", "install", "--no-build-isolation", "-e"] for args in command_calls)


def test_prepare_editable_build_env_strips_stale_datahive_linkage_from_native_env(monkeypatch, tmp_path: Path) -> None:
    options = InstallerOptions(
        command_name="install",
        repo_root=tmp_path,
        manifest_path=DEFAULT_MANIFEST_PATH,
        execution_mode="repo",
        profile="full",
        modules=(),
        python_exe="python",
        editable_overrides=(),
        wheel_only=False,
        clean=False,
        delete_native_deps=False,
        skip_native_deps=False,
        auto_install_missing_prereqs=False,
        skip_engine_build=False,
        skip_web_build=False,
        duckdb_version="1.4.2",
        native_arch="x64",
        show_details=False,
        smoke=False,
        run_demo=False,
        dry_run=False,
        report_path=None,
    )
    report = SimpleNamespace(notes=[])

    monkeypatch.delenv("CF_DATAHIVE_CPP_DUCKDB_LINKAGE", raising=False)
    monkeypatch.setattr("cf_setup.installer._load_native_build_env", lambda repo_root, env: {**env, "CF_DATAHIVE_CPP_DUCKDB_LINKAGE": "static"})
    monkeypatch.setattr("cf_setup.installer._load_msvc_build_env", lambda repo_root, env: env)
    monkeypatch.setattr("cf_setup.installer._resolve_preferred_cmake", lambda env: None)
    monkeypatch.setattr("cf_setup.installer._sanitize_toolchain_path", lambda env, cmake_path: env)
    monkeypatch.setattr("cf_setup.installer._resolve_msvc_vcvars", lambda: None)

    build_env = _prepare_editable_build_env(options, report)

    assert "CF_DATAHIVE_CPP_DUCKDB_LINKAGE" not in build_env


def test_prepare_editable_build_env_strips_stale_user_datahive_linkage_override(monkeypatch, tmp_path: Path) -> None:
    options = InstallerOptions(
        command_name="install",
        repo_root=tmp_path,
        manifest_path=DEFAULT_MANIFEST_PATH,
        execution_mode="repo",
        profile="full",
        modules=(),
        python_exe="python",
        editable_overrides=(),
        wheel_only=False,
        clean=False,
        delete_native_deps=False,
        skip_native_deps=False,
        auto_install_missing_prereqs=False,
        skip_engine_build=False,
        skip_web_build=False,
        duckdb_version="1.4.2",
        native_arch="x64",
        show_details=False,
        smoke=False,
        run_demo=False,
        dry_run=False,
        report_path=None,
    )
    report = SimpleNamespace(notes=[])

    monkeypatch.setenv("CF_DATAHIVE_CPP_DUCKDB_LINKAGE", "static")
    monkeypatch.setattr("cf_setup.installer._load_native_build_env", lambda repo_root, env: {**env, "CF_DATAHIVE_CPP_DUCKDB_LINKAGE": "shared"})
    monkeypatch.setattr("cf_setup.installer._load_msvc_build_env", lambda repo_root, env: env)
    monkeypatch.setattr("cf_setup.installer._resolve_preferred_cmake", lambda env: None)
    monkeypatch.setattr("cf_setup.installer._sanitize_toolchain_path", lambda env, cmake_path: env)
    monkeypatch.setattr("cf_setup.installer._resolve_msvc_vcvars", lambda: None)

    build_env = _prepare_editable_build_env(options, report)

    assert "CF_DATAHIVE_CPP_DUCKDB_LINKAGE" not in build_env


def test_resolve_msvc_installation_path_uses_vswhere(monkeypatch) -> None:
    install_path = Path(r"C:\VS\18\BuildTools")
    vswhere = Path(r"C:\VS\Installer\vswhere.exe")

    monkeypatch.setattr("cf_setup.installer._resolve_vswhere", lambda: vswhere)
    monkeypatch.setattr("cf_setup.installer.Path.exists", lambda path: path == install_path)

    def fake_run(args, **kwargs):
        assert args[0] == str(vswhere)
        assert "Microsoft.VisualStudio.Component.VC.Tools.x86.x64" in args
        return SimpleNamespace(returncode=0, stdout=f"{install_path}\n")

    monkeypatch.setattr("cf_setup.installer.subprocess.run", fake_run)

    assert _resolve_msvc_installation_path() == install_path


def test_resolve_visual_studio_generator_matches_vswhere_major(monkeypatch) -> None:
    install_path = Path(r"C:\VS\18\BuildTools")
    monkeypatch.setattr("cf_setup.installer._resolve_msvc_installation_path", lambda: install_path)
    monkeypatch.setattr(
        "cf_setup.installer._available_cmake_generators",
        lambda cmake_path, env: ("Visual Studio 18 2026", "Visual Studio 17 2022"),
    )

    assert _resolve_visual_studio_cmake_generator("cmake", {}) == "Visual Studio 18 2026"


def test_visual_studio_generator_major_maps_year_install_paths() -> None:
    assert (
        _visual_studio_generator_major_from_installation_path(
            Path(r"C:\Program Files\Microsoft Visual Studio\2022\BuildTools")
        )
        == "17"
    )
    assert (
        _visual_studio_generator_major_from_installation_path(
            Path(r"C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools")
        )
        == "18"
    )


def test_prepare_editable_build_env_uses_dynamic_visual_studio_generator(monkeypatch) -> None:
    repo_root = Path(r"C:\repo")
    options = InstallerOptions(
        command_name="install",
        repo_root=repo_root,
        manifest_path=DEFAULT_MANIFEST_PATH,
        execution_mode="repo",
        profile="full",
        modules=(),
        python_exe="python",
        editable_overrides=(),
        wheel_only=False,
        clean=False,
        delete_native_deps=False,
        skip_native_deps=False,
        auto_install_missing_prereqs=False,
        skip_engine_build=False,
        skip_web_build=False,
        duckdb_version="1.4.2",
        native_arch="x64",
        show_details=False,
        smoke=False,
        run_demo=False,
        dry_run=False,
        report_path=None,
    )
    report = SimpleNamespace(notes=[])

    monkeypatch.setattr("cf_setup.installer._load_native_build_env", lambda repo_root, env: env)
    monkeypatch.setattr("cf_setup.installer._load_msvc_build_env", lambda repo_root, env: env)
    monkeypatch.setattr("cf_setup.installer._resolve_preferred_cmake", lambda env: "cmake")
    monkeypatch.setattr("cf_setup.installer._sanitize_toolchain_path", lambda env, cmake_path: env)
    monkeypatch.setattr("cf_setup.installer.shutil.which", lambda command, path=None: None)
    monkeypatch.setattr(
        "cf_setup.installer._resolve_visual_studio_cmake_generator",
        lambda cmake_path, env: "Visual Studio 18 2026",
    )
    monkeypatch.setattr("cf_setup.installer._resolve_msvc_vcvars", lambda: None)

    build_env = _prepare_editable_build_env(options, report)

    assert build_env["CMAKE_GENERATOR"] == "Visual Studio 18 2026"
    assert build_env["CMAKE_GENERATOR_PLATFORM"] == "x64"
    assert any("Visual Studio 18 2026" in note for note in report.notes)


def test_run_command_quiet_mode_logs_without_terminal_spam(tmp_path: Path, capsys) -> None:
    log_path = tmp_path / "fresh-install.log"

    with activate_console(show_details=False, log_path=log_path):
        completed = _run_command(
            ["python", "-c", "print('hello from quiet logger')"],
            cwd=tmp_path,
            show_details=False,
        )

    captured = capsys.readouterr()
    assert completed.returncode == 0
    assert captured.out == ""
    assert "hello from quiet logger" not in captured.err
    assert "hello from quiet logger" in log_path.read_text(encoding="utf-8")


def test_console_logger_replaces_unencodable_terminal_characters() -> None:
    import io

    stream = io.TextIOWrapper(io.BytesIO(), encoding="cp1252")

    rendered = ConsoleLogger._safe_terminal_text("[ok] ✓ transformed", stream)

    assert rendered == "[ok] ? transformed"


def test_repo_mode_skips_uninstall_when_no_targets_are_installed(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-workspace-store", "cf-ontology"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-workspace-store",
                module=SimpleNamespace(path="sandcastle/cf_workspace_store"),
                source="pypi",
                reason="PyPI-first default",
                local_version=None,
                pypi_version="0.1.0",
            ),
            SimpleNamespace(
                package_name="cf-ontology",
                module=SimpleNamespace(path="sandcastle/cf_ontology"),
                source="editable",
                reason="explicit editable override",
                local_version="0.2.8",
                pypi_version="0.2.7",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._ensure_build_tooling", lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")))
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.metadata.version", lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)))

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-install-report.json",
        )
    )

    assert all(args[:4] != ["python", "-m", "pip", "uninstall"] for args in command_calls)
    assert any(
        step["step"] == "uninstall_targets"
        and step["status"] == "skipped"
        and "reconciles packages in place" in step["detail"]
        for step in payload["steps"]
    )


def test_repo_mode_keeps_web_module_out_of_pypi_batch(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-workspace-store", "cf-ontology", "cf-web"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-workspace-store",
                module=SimpleNamespace(path="sandcastle/cf_workspace_store", web_build=False),
                source="pypi",
                reason="PyPI-first default",
                local_version=None,
                pypi_version="0.1.0",
            ),
            SimpleNamespace(
                package_name="cf-web",
                module=SimpleNamespace(path="sandcastle/cf_web", web_build=True),
                source="editable",
                reason="repo web module requires local source build",
                local_version="0.2.7",
                pypi_version="0.2.6",
            ),
            SimpleNamespace(
                package_name="cf-ontology",
                module=SimpleNamespace(path="sandcastle/cf_ontology", web_build=False),
                source="editable",
                reason="explicit editable override",
                local_version="0.2.8",
                pypi_version="0.2.7",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=True,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._ensure_build_tooling", lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")))
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr(
        "cf_setup.installer.metadata.version",
        lambda name: "0.0.1" if name == "cf-ontology" else (_ for _ in ()).throw(metadata.PackageNotFoundError(name)),
    )
    # Force pypi-sourced packages through the install path to test batch install behaviour
    # regardless of the current dev environment state.
    monkeypatch.setattr("cf_setup.installer._is_distribution_package_already_satisfied", lambda item: False)

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=("cf-ontology",),
            wheel_only=True,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-batch-report.json",
        )
    )

    assert all(args[:4] != ["python", "-m", "pip", "uninstall"] for args in command_calls)
    assert any(
        args == [
            "python",
            "-m",
            "pip",
            "install",
            "--upgrade",
            "--only-binary",
            ":all:",
            "--prefer-binary",
            "cf-workspace-store",
        ]
        for args in command_calls
    )
    editable_calls = [args for args in command_calls if args[:4] == ["python", "-m", "pip", "install"] and "-e" in args]
    assert len(editable_calls) == 2
    assert any(str(tmp_path / "sandcastle" / "cf_web") in args for args in editable_calls)
    build_index = next(i for i, args in enumerate(command_calls) if "build_cf_web_frontend.ps1" in " ".join(args))
    web_install_index = next(
        i
        for i, args in enumerate(command_calls)
        if args[:4] == ["python", "-m", "pip", "install"] and "-e" in args and str(tmp_path / "sandcastle" / "cf_web") in args
    )
    assert web_install_index > build_index
    assert any(step["step"] == "install:cf-workspace-store" for step in payload["steps"])
    assert any(step["step"] == "install:cf-web" for step in payload["steps"])
    assert any(step["step"] == "install:cf-ontology" for step in payload["steps"])


def test_repo_mode_preserves_non_pypi_topology_order(monkeypatch, tmp_path: Path) -> None:
    install_order: list[str] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-workspace-store", "cf-datahive"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-package-contracts",
                module=SimpleNamespace(path="sandcastle/cf_package_contracts"),
                source="local-build",
                reason="package not published on PyPI",
                local_version="0.1.1",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-service-contracts",
                module=SimpleNamespace(path="sandcastle/cf_service_contracts"),
                source="editable",
                reason="tracked git changes detected in module path",
                local_version="0.1.1",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-workspace-store",
                module=SimpleNamespace(path="sandcastle/cf_workspace_store"),
                source="editable",
                reason="tracked git changes detected in module path",
                local_version="0.1.1",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-datahive",
                module=SimpleNamespace(path="sandcastle/cf_datahive"),
                source="local-build",
                reason="local version is ahead of PyPI",
                local_version="0.1.12",
                pypi_version="0.1.11",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr(
        "cf_setup.installer._ensure_build_tooling",
        lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")),
    )
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})

    def fake_install_repo_module(item, options, report, editable_build_env=None, force_reinstall=False):
        install_order.append(item.package_name)
        report.steps.append(StepReport(f"install:{item.package_name}", "success", "Module installed successfully."))

    monkeypatch.setattr("cf_setup.installer._install_repo_module", fake_install_repo_module)
    monkeypatch.setattr(
        "cf_setup.installer.metadata.version",
        lambda name: "0.0.1",
    )

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=True,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-topology-report.json",
        )
    )

    assert install_order == [
        "cf-package-contracts",
        "cf-service-contracts",
        "cf-workspace-store",
        "cf-datahive",
    ]


def test_repo_clean_install_stops_existing_pipeline_manager_daemons(monkeypatch, tmp_path: Path) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="full",
        requested_modules=(),
        ordered_modules=(),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    stopped_roots: list[Path] = []

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._stop_repo_pipeline_manager_daemons", lambda repo_root, report=None: stopped_roots.append(repo_root))
    monkeypatch.setattr("cf_setup.installer._run_script", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._run_command", lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="", stderr=""))

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=True,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-clean-report.json",
        )
    )

    assert stopped_roots == [tmp_path]


def test_repo_nonclean_install_stops_existing_pipeline_manager_daemons(monkeypatch, tmp_path: Path) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="full",
        requested_modules=(),
        ordered_modules=(),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    stopped_roots: list[Path] = []

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._stop_repo_pipeline_manager_daemons", lambda repo_root, report=None: stopped_roots.append(repo_root))
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._run_command", lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="", stderr=""))

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-nonclean-report.json",
        )
    )

    assert stopped_roots == [tmp_path]


def test_repo_install_run_demo_ensures_managed_fuseki_without_native_build_prereqs(monkeypatch, tmp_path: Path) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="full",
        requested_modules=(),
        ordered_modules=(),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    ensured: list[str] = []

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._ensure_managed_fuseki", lambda options, report: ensured.append("fuseki"))
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.execute_run_demo", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._run_command", lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="", stderr=""))

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=True,
            dry_run=False,
            report_path=tmp_path / "repo-demo-fuseki-report.json",
        )
    )

    assert ensured == ["fuseki"]


def test_distribution_install_run_demo_ensures_managed_fuseki(monkeypatch, tmp_path: Path) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)
    plan = SimpleNamespace(
        profile="full",
        requested_modules=(),
        ordered_modules=(),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )
    ensured: list[str] = []

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._ensure_managed_fuseki", lambda options, report: ensured.append("fuseki"))
    monkeypatch.setattr("cf_setup.installer._initialize_distribution_workspace", lambda options, plan, report: (tmp_path / "workspace", tmp_path / "workspace" / "semantics"))
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_command", lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="", stderr=""))
    monkeypatch.setattr("cf_setup.installer.execute_run_demo", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._pip_install_distribution_batch", lambda *args, **kwargs: None)

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="distribution",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=True,
            dry_run=False,
            report_path=tmp_path / "dist-demo-fuseki-report.json",
        )
    )

    assert ensured == ["fuseki"]


def test_repo_mode_retains_self_hosted_cf_core_cli_when_running_via_cf(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-core-cli",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-core-cli",
                module=SimpleNamespace(path="sandcastle/cf_core_cli"),
                source="local-build",
                reason="local version is ahead of PyPI",
                local_version="0.1.6",
                pypi_version="0.1.5",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._ensure_build_tooling", lambda options, report: report.steps.append(StepReport("py_build_tooling", "skipped", "No editable modules selected.")))
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: True)
    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda name: InstalledPackageState(installed=True, version="0.1.6", editable=True, local_directory=True),
    )
    monkeypatch.setattr("cf_setup.installer.metadata.version", lambda name: "0.1.6")

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-self-cli-report.json",
        )
    )

    assert not any(args[:4] == ["python", "-m", "pip", "install"] and "cf-core-cli" in args for args in command_calls)
    assert any(
        step["step"] == "install:cf-core-cli"
        and "avoid a Windows file lock on cf.exe" in step["detail"]
        for step in payload["steps"]
    )


def test_repo_mode_retains_self_hosted_cf_core_cli_for_pypi_target(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-core-cli",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-core-cli",
                module=SimpleNamespace(path="sandcastle/cf_core_cli"),
                source="pypi",
                reason="PyPI-first default",
                local_version="0.1.6",
                pypi_version="0.1.6",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: True)
    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda name: InstalledPackageState(installed=True, version="0.1.6", editable=False, local_directory=False),
    )
    monkeypatch.setattr("cf_setup.installer.metadata.version", lambda name: "0.1.6")

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-self-cli-pypi-report.json",
        )
    )

    assert not any(args[:4] == ["python", "-m", "pip", "install"] and "cf-core-cli" in args for args in command_calls)
    assert any(
        step["step"] == "install:cf-core-cli"
        and "avoid a Windows file lock on cf.exe" in step["detail"]
        for step in payload["steps"]
    )


def test_repo_mode_retains_self_hosted_cf_core_cli_with_incomplete_metadata(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-core-cli",),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-core-cli",
                module=SimpleNamespace(path="sandcastle/cf_core_cli"),
                source="editable",
                reason="tracked git changes detected in module path",
                local_version="0.1.6",
                pypi_version="0.1.5",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=False,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr(
        "cf_setup.installer._ensure_build_tooling",
        lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")),
    )
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: True)
    monkeypatch.setattr(
        "cf_setup.installer._read_installed_package_state",
        lambda name: InstalledPackageState(installed=False, version=None, editable=None, local_directory=None),
    )
    monkeypatch.setattr("cf_setup.installer.metadata.version", lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)))

    payload = execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-self-cli-incomplete-report.json",
        )
    )

    assert not any(args[:4] == ["python", "-m", "pip", "install"] and "cf-core-cli" in args for args in command_calls)
    assert any(
        step["step"] == "install:cf-core-cli"
        and "avoid a Windows file lock on cf.exe" in step["detail"]
        for step in payload["steps"]
    )


def test_repo_mode_runs_engine_build_after_python_module_installs(monkeypatch, tmp_path: Path) -> None:
    command_calls: list[list[str]] = []
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    plan = SimpleNamespace(
        profile="full",
        requested_modules=("cf-package-contracts", "cf-pipeline-engine"),
        ordered_modules=(
            SimpleNamespace(
                package_name="cf-package-contracts",
                module=SimpleNamespace(path="sandcastle/cf_package_contracts"),
                source="editable",
                reason="package not published on PyPI",
                local_version="0.1.1",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-step-tooling",
                module=SimpleNamespace(path="sandcastle/cf_step_tooling"),
                source="editable",
                reason="package not published on PyPI",
                local_version="0.1.0",
                pypi_version=None,
            ),
            SimpleNamespace(
                package_name="cf-pipeline-engine",
                module=SimpleNamespace(path="sandcastle/cf_pipeline/cf_pipeline_engine"),
                source="editable",
                reason="local version is ahead of PyPI",
                local_version="0.3.2",
                pypi_version="0.3.1",
            ),
        ),
        hooks=(),
        requires_native_prereqs=False,
        requires_engine_build=True,
        requires_web_build=False,
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer.plan_installation", lambda *args, **kwargs: (manifest, plan))
    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])
    monkeypatch.setattr(
        "cf_setup.installer._ensure_build_tooling",
        lambda options, report: report.steps.append(StepReport("py_build_tooling", "success", "Installed editable-build tooling.")),
    )
    monkeypatch.setattr("cf_setup.installer._prepare_editable_build_env", lambda options, report: {})
    monkeypatch.setattr("cf_setup.installer._refresh_current_python_import_paths", lambda: None)
    monkeypatch.setattr("cf_setup.installer._run_post_install_hooks", lambda *args, **kwargs: None)
    monkeypatch.setattr("cf_setup.installer._recreate_semantics_runtime", _fake_recreate_semantics_runtime)
    monkeypatch.setattr("cf_setup.installer.metadata.version", lambda name: (_ for _ in ()).throw(metadata.PackageNotFoundError(name)))

    execute_install(
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            report_path=tmp_path / "repo-engine-order-report.json",
        )
    )

    install_indexes = [
        index
        for index, args in enumerate(command_calls)
        if args[:4] == ["python", "-m", "pip", "install"] and "-e" in args
    ]
    engine_build_index = next(
        index
        for index, args in enumerate(command_calls)
        if len(args) >= 6 and args[0] == "powershell" and args[5].endswith("build_cf_pipeline_engine_v2.ps1")
    )

    assert install_indexes
    assert engine_build_index > max(install_indexes)


def test_install_repo_module_resets_legacy_scikit_build_dir(monkeypatch, tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    build_dir = tmp_path / "build-cache"
    build_dir.mkdir()
    (build_dir / "stale.txt").write_text("x", encoding="utf-8")
    (project_dir / "pyproject.toml").write_text(
        "[tool.scikit-build]\n"
        f'build-dir = "{build_dir.as_posix()}"\n',
        encoding="utf-8",
    )
    command_calls: list[list[str]] = []

    def fake_run_command(args, cwd, show_details, extra_env=None):
        command_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    item = SimpleNamespace(
        package_name="cf-basic-sinks",
        module=SimpleNamespace(path=str(project_dir.relative_to(tmp_path))),
        source="editable",
        local_version="0.2.5",
        pypi_version="0.2.4",
    )
    report = _build_installation_report(
        command="test",
        repo_root=tmp_path,
        profile="full",
        dry_run=False,
        execution_mode="repo",
        manifest=load_manifest(DEFAULT_MANIFEST_PATH),
        plan=SimpleNamespace(profile="full", requested_modules=(), ordered_modules=(), hooks=()),
    )

    monkeypatch.setattr("cf_setup.installer._is_editable_module_already_satisfied", lambda _: False)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: False)

    from cf_setup.installer import _install_repo_module

    _install_repo_module(
        item,
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
        ),
        report,
        editable_build_env=None,
        force_reinstall=True,
    )

    assert not build_dir.exists()
    assert any("cf-basic-sinks" in note and "scikit-build" in note for note in report.notes)


def test_install_repo_module_resets_shared_scikit_build_dir(monkeypatch, tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    (project_dir / "pyproject.toml").write_text("[tool.scikit-build]\n", encoding="utf-8")
    build_dir = tmp_path / ".cogniflow" / "cache" / "native" / "scikit-build" / "cf-basic-io"
    build_dir.mkdir(parents=True)
    (build_dir / "stale.txt").write_text("x", encoding="utf-8")

    def fake_run_command(args, cwd, show_details, extra_env=None):
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer._is_editable_module_already_satisfied", lambda _: False)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: False)
    monkeypatch.setattr("cf_setup.installer.Path.home", lambda: tmp_path)

    item = SimpleNamespace(
        package_name="cf-basic-io",
        module=SimpleNamespace(path=str(project_dir.relative_to(tmp_path))),
        source="editable",
        local_version="0.2.7",
        pypi_version="0.2.6",
    )
    report = _build_installation_report(
        command="test",
        repo_root=tmp_path,
        profile="full",
        dry_run=False,
        execution_mode="repo",
        manifest=load_manifest(DEFAULT_MANIFEST_PATH),
        plan=SimpleNamespace(profile="full", requested_modules=(), ordered_modules=(), hooks=()),
    )

    from cf_setup.installer import _install_repo_module

    _install_repo_module(
        item,
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
        ),
        report,
        editable_build_env=None,
        force_reinstall=True,
    )

    assert not build_dir.exists()
    assert any(str(build_dir.resolve()) in note for note in report.notes)


def test_install_repo_module_resets_read_only_scikit_build_dir(monkeypatch, tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    build_dir = tmp_path / "build-cache"
    nested_dir = build_dir / "_deps" / "pkg"
    nested_dir.mkdir(parents=True)
    read_only_file = nested_dir / "artifact.txt"
    read_only_file.write_text("x", encoding="utf-8")
    read_only_file.chmod(0o444)
    (project_dir / "pyproject.toml").write_text(
        "[tool.scikit-build]\n"
        f'build-dir = "{build_dir.as_posix()}"\n',
        encoding="utf-8",
    )

    def fake_run_command(args, cwd, show_details, extra_env=None):
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer._is_editable_module_already_satisfied", lambda _: False)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: False)

    item = SimpleNamespace(
        package_name="cf-pipeline-engine",
        module=SimpleNamespace(path=str(project_dir.relative_to(tmp_path))),
        source="editable",
        local_version="0.3.2",
        pypi_version="0.3.1",
    )
    report = _build_installation_report(
        command="test",
        repo_root=tmp_path,
        profile="full",
        dry_run=False,
        execution_mode="repo",
        manifest=load_manifest(DEFAULT_MANIFEST_PATH),
        plan=SimpleNamespace(profile="full", requested_modules=(), ordered_modules=(), hooks=()),
    )

    from cf_setup.installer import _install_repo_module

    _install_repo_module(
        item,
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
        ),
        report,
        editable_build_env=None,
        force_reinstall=True,
    )

    assert not build_dir.exists()
    assert any("cf-pipeline-engine" in note and "scikit-build" in note for note in report.notes)


def test_install_repo_module_sets_shared_skbuild_build_dir(monkeypatch, tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    (project_dir / "pyproject.toml").write_text("[tool.scikit-build]\n", encoding="utf-8")
    captured_env: dict[str, str] = {}

    def fake_run_command(args, cwd, show_details, extra_env=None):
        nonlocal captured_env
        captured_env = dict(extra_env or {})
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("cf_setup.installer._run_command", fake_run_command)
    monkeypatch.setattr("cf_setup.installer._is_editable_module_already_satisfied", lambda _: False)
    monkeypatch.setattr("cf_setup.installer._is_current_cf_cli_invocation", lambda: False)
    monkeypatch.setattr("cf_setup.installer.Path.home", lambda: tmp_path)

    item = SimpleNamespace(
        package_name="cf-basic-io",
        module=SimpleNamespace(path=str(project_dir.relative_to(tmp_path))),
        source="editable",
        local_version="0.2.7",
        pypi_version="0.2.6",
    )
    report = _build_installation_report(
        command="test",
        repo_root=tmp_path,
        profile="full",
        dry_run=False,
        execution_mode="repo",
        manifest=load_manifest(DEFAULT_MANIFEST_PATH),
        plan=SimpleNamespace(profile="full", requested_modules=(), ordered_modules=(), hooks=()),
    )

    from cf_setup.installer import _install_repo_module

    _install_repo_module(
        item,
        InstallerOptions(
            command_name="install",
            repo_root=tmp_path,
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="full",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
        ),
        report,
        editable_build_env={"X": "1"},
        force_reinstall=True,
    )

    assert captured_env["X"] == "1"
    assert captured_env["SKBUILD_BUILD_DIR"] == str(
        (tmp_path / ".cogniflow" / "cache" / "native" / "scikit-build" / "cf-basic-io").resolve()
    )


def test_build_options_from_namespace_reads_log_path(tmp_path: Path) -> None:
    args = SimpleNamespace(
        command="install",
        repo_root=str(tmp_path),
        manifest=str(DEFAULT_MANIFEST_PATH),
        mode="repo",
        profile="full",
        module=[],
        python="python",
        editable=[],
        wheel_only=True,
        clean=False,
        delete_native_deps=False,
        skip_native_deps=False,
        auto_install_missing_prereqs=False,
        skip_engine_build=False,
        skip_web_build=False,
        duckdb_version="1.4.2",
        native_arch="x64",
        show_details=False,
        smoke=False,
        run_demo=True,
        dry_run=False,
        log_path=str(tmp_path / "install.log"),
        output=str(tmp_path / "report.json"),
    )

    options = build_options_from_namespace(args)

    assert options.log_path == (tmp_path / "install.log").resolve()
    assert options.report_path == (tmp_path / "report.json").resolve()


def test_detect_changed_modules_maps_manifest_paths(monkeypatch) -> None:
    manifest = load_manifest(DEFAULT_MANIFEST_PATH)

    def fake_git_stdout_lines(repo_root, args):
        if args[:3] == ["merge-base", "HEAD", "origin/main"]:
            return ["abc123"]
        if args == ["diff", "--name-only", "abc123", "HEAD"]:
            return [
                "sandcastle/cf_ontology/src/cf_ontology/cli.py",
                "sandcastle/cf_basic_steps/cf_basic_io/src/cf_basic_io/steps.nq",
                "sandcastle/cf_setup/src/cf_setup/bootstrap.py",
            ]
        if args == ["diff", "--name-only"]:
            return ["README.md"]
        if args == ["diff", "--name-only", "--cached"]:
            return []
        return []

    monkeypatch.setattr("cf_setup.installer._resolve_base_ref", lambda repo_root, requested_base_ref: "origin/main")
    monkeypatch.setattr("cf_setup.installer._git_stdout_lines", fake_git_stdout_lines)

    selection = detect_changed_modules(
        manifest,
        _repo_root(),
        base_ref=None,
        include_worktree_changes=True,
    )

    assert selection.requested_modules == ("cf-basic-io", "cf-ontology", "cf-setup")
    assert "sandcastle/cf_setup/src/cf_setup/bootstrap.py" not in selection.unmatched_files
    assert "README.md" in selection.unmatched_files
    assert selection.critical_unmatched_files == ()


def test_python_bootstrap_exposes_service_contracts_source() -> None:
    script = (_repo_root() / "sandcastle" / "cf_setup" / "src" / "cf_setup" / "bootstrap.py").read_text(encoding="utf-8")

    assert 'sandcastle" / "cf_setup" / "src' in script
    assert 'sandcastle" / "cf_service_contracts" / "src' in script


def test_python_bootstrap_ensures_packaging_dependency() -> None:
    script = (_repo_root() / "sandcastle" / "cf_setup" / "src" / "cf_setup" / "bootstrap.py").read_text(encoding="utf-8")

    assert 'ensure_bootstrap_dependency' in script
    assert '"packaging"' in script
    assert '"packaging>=24"' in script


def test_execute_incremental_changed_only_noop_returns_summary(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "cf_setup.installer.detect_changed_modules",
        lambda *args, **kwargs: ChangedModuleSelection(
            requested_modules=(),
            changed_files=("README.md",),
            unmatched_files=("README.md",),
            critical_unmatched_files=(),
            base_ref="origin/main",
            include_worktree_changes=True,
        ),
    )
    monkeypatch.setattr("cf_setup.installer.WindowsProvider.diagnose", lambda self: [])

    payload = execute_incremental(
        InstallerOptions(
            command_name="incremental",
            repo_root=_repo_root(),
            manifest_path=DEFAULT_MANIFEST_PATH,
            execution_mode="repo",
            profile="incremental",
            modules=(),
            python_exe="python",
            editable_overrides=(),
            wheel_only=False,
            clean=False,
            delete_native_deps=False,
            skip_native_deps=False,
            auto_install_missing_prereqs=False,
            skip_engine_build=False,
            skip_web_build=False,
            duckdb_version="1.4.2",
            native_arch="x64",
            show_details=False,
            smoke=False,
            run_demo=False,
            dry_run=False,
            changed_only=True,
            base_ref="origin/main",
            include_worktree_changes=True,
            report_path=tmp_path / "changed-only-noop.json",
        )
    )

    assert payload["change_detection"]["requested_modules"] == []
    assert payload["changed_files"] == ["README.md"]
    assert any(step["step"] == "plan" and step["status"] == "skipped" for step in payload["steps"])
    assert payload["duration_seconds"] is not None
