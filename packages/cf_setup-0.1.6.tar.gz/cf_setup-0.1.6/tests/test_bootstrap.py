from __future__ import annotations

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from cf_setup import bootstrap


def test_bootstrap_pythonpath_entries_include_local_sources(tmp_path: Path) -> None:
    repo_root = tmp_path

    entries = bootstrap.bootstrap_pythonpath_entries(repo_root)

    assert entries == [
        str((repo_root / "sandcastle" / "cf_setup" / "src").resolve()),
        str((repo_root / "sandcastle" / "cf_service_contracts" / "src").resolve()),
    ]


def test_default_install_artifact_paths_use_cf_setup_log_root(tmp_path: Path) -> None:
    report, log, events = bootstrap.default_install_artifact_paths(tmp_path, "install", None, None, None)

    assert Path(report).parent == (tmp_path / ".logs" / "cf_setup").resolve()
    assert Path(log).parent == (tmp_path / ".logs" / "cf_setup").resolve()
    assert Path(events).parent == (tmp_path / ".logs" / "cf_setup").resolve()
    assert Path(report).name.startswith("install_")
    assert Path(log).name.startswith("install_")
    assert Path(events).name.startswith("install_")


def test_default_install_artifact_paths_resolve_relative_paths_from_repo_root(tmp_path: Path) -> None:
    report, log, events = bootstrap.default_install_artifact_paths(
        tmp_path,
        "install",
        "reports/install.json",
        "logs/install.log",
        "events/install.jsonl",
    )

    assert Path(report) == (tmp_path / "reports" / "install.json").resolve()
    assert Path(log) == (tmp_path / "logs" / "install.log").resolve()
    assert Path(events) == (tmp_path / "events" / "install.jsonl").resolve()


def test_bootstrap_main_delegates_to_cf_setup(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, object] = {}

    def fake_resolve_bootstrap_python(requested_python: str | None, repo_root: Path) -> str:
        captured["resolve"] = (requested_python, repo_root)
        return "C:/Python/python.exe"

    def fake_ensure_venv_python(repo_root: Path, bootstrap_python: str) -> str:
        captured["venv"] = (repo_root, bootstrap_python)
        return "C:/repo/.venv/Scripts/python.exe"

    def fake_ensure_bootstrap_dependency(python_exe: str, module_name: str, package_spec: str, repo_root: Path) -> None:
        captured["dependency"] = (python_exe, module_name, package_spec, repo_root)

    def fake_run(command, cwd, env, check):
        captured["command"] = command
        captured["cwd"] = cwd
        captured["env"] = env

        class _Completed:
            returncode = 0

        return _Completed()

    monkeypatch.setattr(bootstrap, "resolve_bootstrap_python", fake_resolve_bootstrap_python)
    monkeypatch.setattr(bootstrap, "ensure_venv_python", fake_ensure_venv_python)
    monkeypatch.setattr(bootstrap, "ensure_bootstrap_dependency", fake_ensure_bootstrap_dependency)
    monkeypatch.setattr(bootstrap.subprocess, "run", fake_run)

    exit_code = bootstrap.main([
        "install",
        "--repo-root",
        str(tmp_path),
        "--profile",
        "full",
        "--run-demo",
    ])

    assert exit_code == 0
    assert captured["command"][0:3] == [
        "C:/repo/.venv/Scripts/python.exe",
        "-m",
        "cf_setup",
    ]
    assert captured["command"][3] == "install"
    assert "--repo-root" in captured["command"]
    assert "--manifest" in captured["command"]
    assert "--python" in captured["command"]
    assert "--output" in captured["command"]
    assert "--log-path" in captured["command"]
    assert "--event-path" in captured["command"]
    assert "--profile" in captured["command"]
    assert "--run-demo" in captured["command"]
    assert captured["cwd"] == str(tmp_path)


def test_pyproject_exposes_bootstrap_script_entrypoint() -> None:
    pyproject = (Path(__file__).resolve().parent.parent / "pyproject.toml").read_text(encoding="utf-8")

    assert 'cf-setup-bootstrap = "cf_setup.bootstrap:main"' in pyproject
