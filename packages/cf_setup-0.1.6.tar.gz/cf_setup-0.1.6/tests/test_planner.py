from importlib import metadata
from pathlib import Path
from types import SimpleNamespace

from cf_setup.installer import plan_incremental_installation, plan_installation

LOCAL_MANIFEST_PATH = (
    Path(__file__).resolve().parents[1] / "src" / "cf_setup" / "install_manifest.toml"
)


def test_plan_expands_core_profile_in_dependency_order(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    _, plan = plan_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        profile="core",
        editable_overrides=[],
    )
    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered.index("cf-service-contracts") < ordered.index("cf-setup")
    assert ordered.index("cf-package-contracts") < ordered.index("cf-pipeline-sdk")
    assert ordered.index("cf-package-contracts") < ordered.index("cf-workspace-store")
    assert ordered.index("cf-workspace-store") < ordered.index("cf-datahive")
    assert ordered.index("cf-workspace-store") < ordered.index("cf-semantics-store")
    assert ordered.index("cf-semantics-store") < ordered.index("cf-semantics-runtime")
    assert ordered.index("cf-semantics-runtime") < ordered.index("cf-ontology")
    assert ordered.index("cf-workspace-store") < ordered.index("cf-ontology")
    assert ordered.index("cf-pipeline-sdk") < ordered.index("cf-pipeline-engine")
    assert ordered.index("cf-ontology") < ordered.index("cf-pipeline-manager")
    assert ordered.index("cf-pipeline-engine") < ordered.index("cf-pipeline-manager")
    assert plan.requires_engine_build is False


def test_step_profile_pulls_in_step_tooling_before_step_packages(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    _, plan = plan_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        profile="steps",
        editable_overrides=[],
    )
    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered.index("cf-step-tooling") < ordered.index("cf-basic-io")
    assert ordered.index("cf-package-contracts") < ordered.index("cf-basic-io")


def test_incremental_plan_forces_selected_module_editable_and_keeps_scope_small(monkeypatch) -> None:
    versions = {
        "cf-basic-sinks": "0.2.4",
        "cf-package-contracts": None,
        "cf-step-tooling": None,
    }
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: versions.get(name, "9.9.9"))
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    monkeypatch.setattr("cf_setup.installer._detect_modules_with_tracked_changes", lambda manifest, repo_root: {"cf-basic-sinks"})
    _, plan = plan_incremental_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        modules=["cf-basic-sinks"],
        editable_overrides=[],
    )

    ordered = [item.package_name for item in plan.ordered_modules]
    assert plan.profile == "incremental"
    assert plan.requested_modules == ("cf-basic-sinks",)
    assert "cf-package-contracts" in ordered
    assert "cf-step-tooling" in ordered
    assert "cf-web" not in ordered
    assert next(item for item in plan.ordered_modules if item.package_name == "cf-basic-sinks").source == "editable"


def test_incremental_plan_for_compile_boundary_stays_requested_module_only(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    _, plan = plan_incremental_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        modules=["cf-package-contracts"],
        editable_overrides=[],
    )

    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered == ["cf-package-contracts"]


def test_incremental_provider_scope_does_not_pull_runtime_service_consumers(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    monkeypatch.setattr(
        "cf_setup.installer.metadata.distribution",
        lambda name: SimpleNamespace(version="9.9.9", read_text=lambda _: None)
        if name == "cf-workspace-store"
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(name)),
    )
    # Force all packages to appear unsatisfied so the test is environment-independent
    monkeypatch.setattr("cf_setup.installer._is_source_decision_satisfied", lambda package_name, decision: False)
    _, plan = plan_incremental_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        modules=["cf-datahive"],
        editable_overrides=[],
    )

    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered == ["cf-package-contracts", "cf-service-contracts", "cf-workspace-store", "cf-datahive"]


def test_incremental_step_tooling_scope_stays_local(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    _, plan = plan_incremental_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        modules=["cf-step-tooling"],
        editable_overrides=[],
    )

    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered == ["cf-step-tooling"]


def test_incremental_engine_scope_omits_runtime_service_providers_and_app_consumers(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "9.9.9")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "0.0.1")
    monkeypatch.setattr(
        "cf_setup.installer.metadata.distribution",
        lambda name: SimpleNamespace(version="9.9.9", read_text=lambda _: None)
        if name in {"cf-datahive", "cf-opcua-server", "cf-pipeline-sdk", "cf-workspace-store"}
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(name)),
    )
    # Force all packages to appear unsatisfied so the test is environment-independent
    monkeypatch.setattr("cf_setup.installer._is_source_decision_satisfied", lambda package_name, decision: False)
    _, plan = plan_incremental_installation(
        manifest_path=LOCAL_MANIFEST_PATH,
        repo_root=Path(".").resolve(),
        modules=["cf-pipeline-engine"],
        editable_overrides=[],
    )

    ordered = [item.package_name for item in plan.ordered_modules]
    assert ordered[:3] == ["cf-package-contracts", "cf-service-contracts", "cf-step-tooling"]
    assert "cf-workspace-store" in ordered
    assert "cf-datahive" in ordered
    assert ordered[-1] == "cf-pipeline-engine"
    assert "cf-web" not in ordered
    assert "cf-ontology" not in ordered
