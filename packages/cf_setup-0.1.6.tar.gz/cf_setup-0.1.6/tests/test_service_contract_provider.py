from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from cf_service_contracts import ProviderKey, SetupOrchestrationContractV1
from cf_setup.service_contract_provider import SetupOrchestrationProvider, provide_setup_orchestration_contract
from cf_setup.installer import InstallerOptions


class TestSetupOrchestrationProvider:
    def test_provider_provides_contract(self):
        provider = SetupOrchestrationProvider()
        assert isinstance(provider, SetupOrchestrationContractV1)

    def test_resolve_repo_root_returns_string_or_none(self):
        provider = SetupOrchestrationProvider()
        result = provider.resolve_repo_root()
        assert result is None or isinstance(result, str)

    def test_default_manifest_path_returns_string(self):
        provider = SetupOrchestrationProvider()
        result = provider.default_manifest_path()
        assert isinstance(result, str)
        assert "install_manifest.toml" in result

    def test_diagnose_prerequisites_returns_dict(self):
        provider = SetupOrchestrationProvider()
        result = provider.diagnose_prerequisites()
        assert isinstance(result, dict)

    def test_execute_install_signature_has_request_param(self):
        provider = SetupOrchestrationProvider()
        sig_params = provider.execute_install.__code__.co_varnames
        assert "request" in sig_params


class TestSetupOrchestrationProviderBehavioral:
    """Behavioral tests verifying request-derived option propagation via InstallerOptions inspection."""

    def test_profile_option_propagates_to_execution(self):
        """Profile from request is propagated to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"profile": "core"})
        assert len(captured) == 1
        assert captured[0].profile == "core"

    def test_dry_run_option_propagates(self):
        """Dry-run mode is propagated to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"dry_run": True})
        assert len(captured) == 1
        assert captured[0].dry_run is True

    def test_python_executable_propagates(self):
        """Python executable from request is propagated to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"python_exe": "/custom/python"})
        assert len(captured) == 1
        assert captured[0].python_exe == "/custom/python"

    def test_show_details_option_propagates(self):
        """Show-details flag propagates to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"show_details": True})
        assert len(captured) == 1
        assert captured[0].show_details is True

    def test_editable_list_propagates(self):
        """Editable overrides list propagates to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"editable": ["cf-core-cli"]})
        assert len(captured) == 1
        assert "cf-core-cli" in captured[0].editable_overrides

    def test_execution_mode_propagates(self):
        """Execution mode propagates to InstallerOptions."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({"execution_mode": "auto"})
        assert len(captured) == 1
        assert captured[0].execution_mode == "auto"

    def test_combined_options_propagate(self):
        """Multiple options from request are all propagated correctly."""
        from cf_setup.installer import InstallerOptions
        captured: list[InstallerOptions] = []

        def capture_install(options: InstallerOptions) -> dict[str, Any]:
            captured.append(options)
            return {"success": True}

        with patch("cf_setup.installer.execute_install", side_effect=capture_install):
            provider = SetupOrchestrationProvider()
            provider.execute_install({
                "profile": "steps",
                "dry_run": True,
                "python_exe": "/usr/bin/python",
                "show_details": False,
                "editable": ["cf-core-cli", "cf-web"],
            })
        assert len(captured) == 1
        opts = captured[0]
        assert opts.profile == "steps"
        assert opts.dry_run is True
        assert opts.python_exe == "/usr/bin/python"
        assert opts.show_details is False
        assert "cf-core-cli" in opts.editable_overrides
        assert "cf-web" in opts.editable_overrides


class TestProviderRegistration:
    def test_provide_setup_orchestration_contract_returns_provider(self):
        provider = provide_setup_orchestration_contract()
        assert isinstance(provider, SetupOrchestrationProvider)
        assert isinstance(provider, SetupOrchestrationContractV1)