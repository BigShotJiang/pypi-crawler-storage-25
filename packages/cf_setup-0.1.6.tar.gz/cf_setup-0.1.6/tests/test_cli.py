import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from cf_setup import DEFAULT_MANIFEST_PATH, cli


def test_plan_command_writes_json(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "0.0.1")
    output_path = tmp_path / "plan.json"
    exit_code = cli.main(
        [
            "plan",
            "--repo-root",
            str(Path(".").resolve()),
            "--profile",
            "core",
            "--output",
            str(output_path),
        ]
    )
    assert exit_code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["profile"] == "core"
    assert payload["ordered_modules"]


def test_plan_command_supports_distribution_mode(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "1.0.0")
    output_path = tmp_path / "distribution-plan.json"
    exit_code = cli.main(
        [
            "plan",
            "--mode",
            "distribution",
            "--manifest",
            str(DEFAULT_MANIFEST_PATH),
            "--profile",
            "core",
            "--output",
            str(output_path),
        ]
    )
    assert exit_code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["execution_mode"] == "distribution"
    assert all(item["source"] == "pypi" for item in payload["ordered_modules"])


def test_plan_command_supports_dev_alias(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("cf_setup.installer.fetch_latest_pypi_version", lambda name: "1.0.0")
    monkeypatch.setattr("cf_setup.installer.read_local_version", lambda path: "2.0.0")
    output_path = tmp_path / "dev-plan.json"
    exit_code = cli.main(
        [
            "plan",
            "--dev",
            "--repo-root",
            str(Path(".").resolve()),
            "--profile",
            "core",
            "--output",
            str(output_path),
        ]
    )
    assert exit_code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["execution_mode"] == "repo"


def test_incremental_command_writes_json(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_incremental(options):
        captured["options"] = options
        return {
            "command": "cf_setup incremental",
            "requested_modules": list(options.modules),
            "scope_modules": list(options.modules),
        }

    monkeypatch.setattr("cf_setup.cli.execute_incremental", fake_execute_incremental)
    exit_code = cli.main(
        [
            "incremental",
            "--repo-root",
            str(Path(".").resolve()),
            "--module",
            "cf-basic-io",
            "--smoke",
        ]
    )

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].smoke is True


def test_incremental_command_supports_changed_only(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_incremental(options):
        captured["options"] = options
        return {
            "command": "cf_setup incremental",
            "requested_modules": list(options.modules),
            "change_detection": {
                "base_ref": options.base_ref,
                "include_worktree_changes": options.include_worktree_changes,
            },
        }

    monkeypatch.setattr("cf_setup.cli.execute_incremental", fake_execute_incremental)
    exit_code = cli.main(
        [
            "incremental",
            "--repo-root",
            str(Path(".").resolve()),
            "--changed-only",
            "--base-ref",
            "origin/main",
            "--no-include-working-tree",
        ]
    )

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].changed_only is True
    assert captured["options"].base_ref == "origin/main"
    assert captured["options"].include_worktree_changes is False


def test_install_command_supports_dev_alias(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_install(options):
        captured["options"] = options
        return {"command": "cf_setup install", "execution_mode": options.execution_mode}

    monkeypatch.setattr("cf_setup.cli.execute_install", fake_execute_install)
    exit_code = cli.main(["install", "--dev"])

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].execution_mode == "repo"


def test_install_command_defaults_demo_on_for_repo_mode(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_install(options):
        captured["options"] = options
        return {"command": "cf_setup install"}

    monkeypatch.setattr("cf_setup.cli.execute_install", fake_execute_install)
    exit_code = cli.main(["install", "--dev"])

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].run_demo is None


def test_install_command_supports_no_run_demo(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_install(options):
        captured["options"] = options
        return {"command": "cf_setup install"}

    monkeypatch.setattr("cf_setup.cli.execute_install", fake_execute_install)
    exit_code = cli.main(["install", "--dev", "--no-run-demo"])

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].run_demo is False


def test_install_command_supports_precise_progress_mode(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_install(options):
        captured["options"] = options
        return {"command": "cf_setup install"}

    monkeypatch.setattr("cf_setup.cli.execute_install", fake_execute_install)
    exit_code = cli.main(["install", "--progress-mode", "precise"])

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].progress_mode == "precise"


def test_incremental_command_supports_precise_progress_mode(monkeypatch, capsys) -> None:
    captured = {}

    def fake_execute_incremental(options):
        captured["options"] = options
        return {"command": "cf_setup incremental"}

    monkeypatch.setattr("cf_setup.cli.execute_incremental", fake_execute_incremental)
    exit_code = cli.main(["incremental", "--module", "cf-basic-io", "--progress-mode", "precise"])

    assert exit_code == 0
    assert capsys.readouterr().out == ""
    assert captured["options"].progress_mode == "precise"
