import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "cf_datahive" / "src"))

from cf_setup.run_demo import (
    _configure_demo_cli_environment,
    _ensure_live_semantics_backend,
    _normalize_distribution_demo_pipeline,
    _nquads_documents_match,
    _demo_invocation_document,
    _demo_run_request_payload,
    _retry_demo_storage_action,
    _retryable_manager_timeout,
    _retryable_storage_conflict,
    _restart_pipeline_manager_daemon,
    _resolve_repo_package_assets,
    _stop_pipeline_manager_daemon,
    _wait_for_demo_run_terminal_status,
    _write_demo_invocation_document,
    _resolve_demo_pipeline_state,
    _resolve_distribution_demo_documents,
    _ensure_basic_io_for_demo,
    RunDemoOptions,
    discover_installed_plugin_dirs,
    expected_opcua_failure,
    find_latest_data_hive_run,
    run_python,
    start_opcua_server,
    wait_opcua_diagnose_ready,
    version_at_least,
)
from cf_service_contracts import ProviderKey, clear_provider_registry, register_datahive_runs_test_provider, register_provider


def _register_datahive_runs_provider() -> None:
    from cf_datahive.service_contract_provider import DataHiveRunsProvider
    register_provider(ProviderKey.DATAHIVE_RUNS, DataHiveRunsProvider())


def test_version_at_least_handles_semver_strings() -> None:
    assert version_at_least("0.1.4", "0.1.4") is True
    assert version_at_least("0.1.5.dev1", "0.1.4") is True
    assert version_at_least("0.1.3", "0.1.4") is False


def test_expected_opcua_failure_matches_known_signatures() -> None:
    assert expected_opcua_failure("Connection refused while reading OPC UA endpoint") is True
    assert expected_opcua_failure("unexpected value") is False


def test_retryable_storage_conflict_matches_duckdb_conflict_text() -> None:
    assert _retryable_storage_conflict("TransactionContext Error: Conflict on update!") is True
    assert _retryable_storage_conflict("different failure") is False


def test_retryable_manager_timeout_matches_timeout_text() -> None:
    assert _retryable_manager_timeout("timed out") is True
    assert _retryable_manager_timeout("Pipeline manager request timeout while polling") is True
    assert _retryable_manager_timeout("connection refused") is False


def test_retry_demo_storage_action_retries_conflict_once(monkeypatch) -> None:
    attempts = {"count": 0}
    monkeypatch.setattr("cf_setup.run_demo.time.sleep", lambda _: None)

    def flaky_action():
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise RuntimeError('{"error": "TransactionContext Error: Conflict on update!"}')
        return "ok"

    assert _retry_demo_storage_action(flaky_action) == "ok"
    assert attempts["count"] == 2


def test_wait_for_demo_run_terminal_status_retries_transient_timeout(monkeypatch) -> None:
    monkeypatch.setattr("cf_setup.run_demo.time.sleep", lambda _: None)

    class DummyPipelineManager:
        def __init__(self) -> None:
            self.calls = 0

        def snapshot(self, pipeline_id: str, *, selected_run_id: str | None = None):
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("timed out")
            return {
                "selected_run": {
                    "run_id": selected_run_id,
                    "status": "succeeded",
                }
            }

    selected_run, last_timeout_error = _wait_for_demo_run_terminal_status(
        DummyPipelineManager(),
        pipeline_id="demo",
        run_id="run-1",
        timeout_seconds=1.0,
        poll_interval_seconds=0.0,
    )

    assert selected_run is not None
    assert selected_run["status"] == "succeeded"
    assert last_timeout_error == "timed out"


def test_restart_pipeline_manager_daemon_stops_then_starts_fresh(monkeypatch) -> None:
    calls: list[str] = []

    class DummyPipelineManager:
        def stop_daemon(self):
            calls.append("stop")
            return {"stopped": True}

        def ensure_daemon(self, *, timeout: float | None = None):
            calls.append(f"ensure:{timeout}")
            return {"status": "ready"}

    monkeypatch.setattr(
        "cf_setup.run_demo._resolve_demo_pipeline_manager",
        lambda **_: DummyPipelineManager(),
    )

    manager = _restart_pipeline_manager_daemon(timeout_seconds=12.0)

    assert isinstance(manager, DummyPipelineManager)
    assert calls == ["stop", "ensure:12.0"]


def test_stop_pipeline_manager_daemon_stops_daemon(monkeypatch) -> None:
    calls: list[str] = []

    class DummyPipelineManager:
        def stop_daemon(self):
            calls.append("stop")
            return {"stopped": True}

    monkeypatch.setattr(
        "cf_setup.run_demo._resolve_demo_pipeline_manager",
        lambda **_: DummyPipelineManager(),
    )

    _stop_pipeline_manager_daemon(timeout_seconds=12.0)

    assert calls == ["stop"]


def test_find_latest_data_hive_run_supports_session_layout(tmp_path: Path) -> None:
    clear_provider_registry()
    _register_datahive_runs_provider()

    workspace_root = tmp_path / ".cogniflow" / "workspace"
    pipeline_root = workspace_root / "data_hive" / "p1"
    run_id = "r1"
    session_id = "session-s1"
    session_root = pipeline_root / "2026" / "03" / "19" / session_id
    run_root = session_root / "runs" / run_id
    table_root = session_root / "tables" / "measurements" / f"run_id={run_id}"
    run_root.mkdir(parents=True)
    table_root.mkdir(parents=True)
    (pipeline_root / "latest.txt").write_text(run_id + "\n", encoding="utf-8")
    (pipeline_root / "latest_session.txt").write_text(session_id + "\n", encoding="utf-8")
    (run_root / "manifest.json").write_text(
        json.dumps(
            {
                "status": "committed",
                "session_id": session_id,
                "session_run_index": 0,
                "tables": {
                    "measurements": {
                        "path": f"tables/measurements/run_id={run_id}/part-0000.parquet",
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    parquet_path = table_root / "part-0000.parquet"
    parquet_path.parent.mkdir(parents=True, exist_ok=True)
    parquet_path.write_bytes(b"PAR1")

    evidence = find_latest_data_hive_run(workspace_root, "p1")

    assert evidence is not None
    assert evidence["run_id"] == run_id
    assert evidence["manifest_status"] == "committed"
    assert evidence["parquet_files"] == [str(parquet_path)]
    clear_provider_registry()


def test_demo_run_request_payload_is_empty() -> None:
    payload = _demo_run_request_payload()

    assert payload == {}


def test_demo_invocation_document_contains_endpoint_and_window_overrides() -> None:
    document = _demo_invocation_document("opcua_fifo_avg_to_duckdb_parquet_triggered", opcua_port=4841)

    graph = document["@graph"]
    endpoint_node = next(node for node in graph if node.get("schema:propertyID") == "endpoint")
    window_nodes = [node for node in graph if node.get("schema:propertyID") == "windowSize"]

    assert endpoint_node["schema:value"] == "opc.tcp://127.0.0.1:4841/VirtualPhServer"
    assert len(window_nodes) == 2
    assert all(node["schema:value"] == 1 for node in window_nodes)


def test_write_demo_invocation_document_serializes_nquads(tmp_path: Path) -> None:
    path = _write_demo_invocation_document(
        tmp_path / "invocation.nq",
        "opcua_fifo_avg_to_duckdb_parquet_triggered",
        opcua_port=4841,
    )

    text = path.read_text(encoding="utf-8")
    assert path.is_file()
    assert "opc.tcp://127.0.0.1:4841/VirtualPhServer" in text
    assert "windowSize" in text


def test_nquads_documents_match_ignores_named_graph_ids() -> None:
    left = '<urn:a> <urn:b> <urn:c> <urn:g:left> .\n'
    right = '<urn:a> <urn:b> <urn:c> <urn:g:right> .\n'

    assert _nquads_documents_match(left, right) is True


def test_nquads_documents_match_ignores_string_datatype_annotation() -> None:
    left = '<urn:a> <urn:b> "value"^^<http://www.w3.org/2001/XMLSchema#string> <urn:g:left> .\n'
    right = '<urn:a> <urn:b> "value" <urn:g:right> .\n'

    assert _nquads_documents_match(left, right) is True


def test_nquads_documents_match_accepts_rdfxml_left_side() -> None:
    left = (
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n'
        '  <rdf:Description rdf:about="urn:a">\n'
        '    <urn:b xmlns:urn="urn:">\n'
        '      <rdf:Description rdf:about="urn:c"/>\n'
        '    </urn:b>\n'
        '  </rdf:Description>\n'
        '</rdf:RDF>\n'
    )
    right = '<urn:a> <urn:b> <urn:c> <urn:g:right> .\n'

    assert _nquads_documents_match(left, right) is True


def test_configure_demo_cli_environment_prepends_scripts_dir_and_binds_opcua_command(tmp_path: Path) -> None:
    scripts_dir = tmp_path / "Scripts"
    scripts_dir.mkdir()
    python_exe = scripts_dir / "python.exe"
    python_exe.write_text("", encoding="utf-8")
    opcua_exe = scripts_dir / "cf-opcua-server.exe"
    opcua_exe.write_text("", encoding="utf-8")
    original_path = str(tmp_path / "elsewhere")

    configured = _configure_demo_cli_environment(str(python_exe), {"PATH": original_path, "X": "1"})

    assert configured["CF_OPCUA_SERVER_CMD"] == str(opcua_exe)
    assert configured["PATH"].split(";")[0] == str(scripts_dir)
    assert configured["X"] == "1"

def test_discover_installed_plugin_dirs_reads_subprocess_json(monkeypatch, tmp_path: Path) -> None:
    class Completed:
        returncode = 0
        stdout = json.dumps([str(tmp_path / "plugin-a"), str(tmp_path / "plugin-b")]) + "\n"

    monkeypatch.setattr("cf_setup.run_demo.subprocess.run", lambda *args, **kwargs: Completed())

    discovered = discover_installed_plugin_dirs("python", tmp_path, {})

    assert discovered == [str(tmp_path / "plugin-a"), str(tmp_path / "plugin-b")]


def test_load_native_env_reads_shared_home_cache_env(monkeypatch, tmp_path: Path) -> None:
    native_env = tmp_path / ".cogniflow" / "cache" / "native" / "env.ps1"
    native_env.parent.mkdir(parents=True)
    native_env.write_text("# shared native env\n", encoding="utf-8")

    class Completed:
        returncode = 0
        stdout = "A=1\nB=2\n"

    monkeypatch.setattr("cf_setup.run_demo.Path.home", lambda: tmp_path)
    monkeypatch.setattr("cf_setup.run_demo.subprocess.run", lambda *args, **kwargs: Completed())

    loaded, ok = __import__("cf_setup.run_demo", fromlist=["load_native_env"]).load_native_env(tmp_path, {"X": "0"})

    assert ok is True
    assert loaded["A"] == "1"
    assert loaded["B"] == "2"
    assert loaded["X"] == "0"


def test_ensure_live_semantics_backend_requires_managed_fuseki(monkeypatch) -> None:
    class DummySemanticsStore:
        def ensure_dataset(self):
            return {
                "backend_kind": "catalog_state",
                "service_managed": False,
                "service_running": False,
                "service_endpoint_reachable": False,
                "dataset_ready": False,
            }

    clear_provider_registry()
    register_provider(ProviderKey.SEMANTICS_STORE, DummySemanticsStore())

    try:
        _ensure_live_semantics_backend()
    except RuntimeError as exc:
        assert "managed Jena Fuseki" in str(exc)
    else:
        raise AssertionError("Expected RunDemo live semantics backend check to fail without Fuseki.")
    finally:
        clear_provider_registry()


def test_ensure_live_semantics_backend_returns_runtime_source_mode(monkeypatch) -> None:
    class DummySemanticsStore:
        def ensure_dataset(self):
            return {
                "backend_kind": "jena_fuseki_tdb2",
                "service_managed": True,
                "service_running": True,
                "service_endpoint_reachable": True,
                "dataset_ready": True,
                "runtime_source_mode": "live",
                "dataset_name": "demo",
            }

    monkeypatch.setattr("cf_setup.run_demo.clear_provider_registry", lambda: None)
    monkeypatch.setattr("cf_setup.run_demo.require_provider", lambda _key: DummySemanticsStore())

    runtime = _ensure_live_semantics_backend()

    assert runtime["runtime_source_mode"] == "live"
    assert runtime["dataset_name"] == "demo"


def test_start_opcua_server_uses_same_advertised_and_bind_endpoint(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, object] = {}

    class DummyProcess:
        pass

    def fake_popen(args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return DummyProcess()

    monkeypatch.setattr("cf_setup.run_demo.subprocess.Popen", fake_popen)

    start_opcua_server(
        "python",
        tmp_path,
        {"X": "1"},
        port=4841,
        show_details=False,
    )

    args = captured["args"]
    assert isinstance(args, list)
    assert args[2] == "VirtualPhServer"
    endpoint_value = args[args.index("--endpoint") + 1]
    bind_value = args[args.index("--bind-endpoint") + 1]
    duration_value = args[args.index("--duration") + 1]
    assert endpoint_value == "opc.tcp://127.0.0.1:4841/VirtualPhServer"
    assert bind_value == endpoint_value
    assert duration_value == "600"


def test_wait_opcua_diagnose_ready_uses_cli_and_returns_true_on_success(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, object] = {}

    class Completed:
        returncode = 0
        stdout = "{}"
        stderr = ""

    def fake_run(args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return Completed()

    monkeypatch.setattr("cf_setup.run_demo.subprocess.run", fake_run)

    ok = wait_opcua_diagnose_ready(
        "python",
        tmp_path,
        {"CF_OPCUA_SERVER_CMD": "cf-opcua-server"},
        endpoint="opc.tcp://127.0.0.1:4841/VirtualPhServer",
        timeout_seconds=1,
    )

    assert ok is True
    assert captured["args"] == [
        "cf-opcua-server",
        "diagnose",
        "--endpoint",
        "opc.tcp://127.0.0.1:4841/VirtualPhServer",
        "--compact",
    ]


def test_wait_opcua_diagnose_ready_returns_false_after_timeout(monkeypatch, tmp_path: Path) -> None:
    class Completed:
        returncode = 1
        stdout = ""
        stderr = "not ready"

    calls = {"count": 0}

    def fake_run(*args, **kwargs):
        calls["count"] += 1
        return Completed()

    times = iter([0.0, 0.6, 1.2])
    monkeypatch.setattr("cf_setup.run_demo.subprocess.run", fake_run)
    monkeypatch.setattr("cf_setup.run_demo.time.monotonic", lambda: next(times))
    monkeypatch.setattr("cf_setup.run_demo.time.sleep", lambda _: None)

    ok = wait_opcua_diagnose_ready(
        "python",
        tmp_path,
        {},
        endpoint="opc.tcp://127.0.0.1:4841/VirtualPhServer",
        timeout_seconds=1,
    )

    assert ok is False
    assert calls["count"] == 1


def test_resolve_demo_pipeline_state_reuses_matching_enabled_pipeline(monkeypatch, tmp_path: Path) -> None:
    pipeline_document = tmp_path / "demo.nq"
    pipeline_text = "<a> <b> <c> <g> .\n"
    pipeline_document.write_text(pipeline_text, encoding="utf-8")

    class DummyBootstrap:
        def get_pipeline_revision_nquads(self, pipeline_id: str) -> str:
            assert pipeline_id == "pipe:demo"
            return pipeline_text

        def list_pipeline_state_rows(self):
            return [{"pipeline_id": "pipe:demo", "state": "enabled"}]

    clear_provider_registry()
    register_provider(ProviderKey.SETUP_BOOTSTRAP, DummyBootstrap())

    matches_revision, enabled = _resolve_demo_pipeline_state(
        pipeline_id="pipe:demo",
        pipeline_document=pipeline_document,
        semantics_dir=tmp_path / "semantics",
    )

    assert matches_revision is True
    assert enabled is True
    clear_provider_registry()


def test_ensure_basic_io_for_demo_fails_without_required_installed_version(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("cf_setup.run_demo.installed_package_version", lambda *args, **kwargs: "0.1.3")

    options = RunDemoOptions(
        repo_root=tmp_path,
        python_exe="python",
        duckdb_version="1.4.2",
        native_arch="x64",
        auto_install_missing_prereqs=True,
        skip_native_deps=False,
        show_details=False,
        execution_mode="distribution",
    )
    report = SimpleNamespace(steps=[])

    try:
        _ensure_basic_io_for_demo(options, {}, report)
    except RuntimeError as exc:
        assert str(exc) == "RunDemo requires installed cf-basic-io >= 0.1.4. Current installed version: '0.1.3'."
    else:  # pragma: no cover - defensive guard
        raise AssertionError("Expected RunDemo to fail when installed cf-basic-io is below the minimum version.")


def test_ensure_basic_io_for_demo_skips_installed_check_in_repo_mode(monkeypatch, tmp_path: Path) -> None:
    def _unexpected_lookup(*args, **kwargs):
        raise AssertionError("installed_package_version should not be called in repo mode")

    monkeypatch.setattr("cf_setup.run_demo.installed_package_version", _unexpected_lookup)

    options = RunDemoOptions(
        repo_root=tmp_path,
        python_exe="python",
        duckdb_version="1.4.2",
        native_arch="x64",
        auto_install_missing_prereqs=True,
        skip_native_deps=False,
        show_details=False,
        execution_mode="repo",
    )
    report = SimpleNamespace(steps=[])

    env = _ensure_basic_io_for_demo(options, {"X": "1"}, report)

    assert env == {"X": "1"}
    assert len(report.steps) == 1
    assert report.steps[0].status == "skipped"
    assert "skips the distribution cf-basic-io version gate" in report.steps[0].detail


def test_normalize_distribution_demo_pipeline_rewrites_workspace_and_drops_repo_headers(tmp_path: Path) -> None:
    source = """
<x/stepsHeader> <https://cogniflow.odea-project.org/cf#stepsPath> "../../../cf_basic_steps/cf_basic_io/src/cf_basic_io/steps.nq" .
<x/pluginsHeader> <https://cogniflow.odea-project.org/cf#pluginPath> "../../../cf_basic_steps/cf_basic_io/src/cf_basic_io/bin" .
<x/n7_binding_baseDir> <https://cogniflow.odea-project.org/cf#value> "./workspace" .
""".strip()
    package_assets = {
        "cf_basic_io": {
            "steps": (tmp_path / "pkg" / "cf_basic_io" / "steps.nq").as_posix(),
            "bin": (tmp_path / "pkg" / "cf_basic_io" / "bin").as_posix(),
        }
    }

    normalized = _normalize_distribution_demo_pipeline(source, tmp_path / ".cogniflow" / "workspace", package_assets)

    assert "\"./workspace\"" not in normalized
    assert f"\"{(tmp_path / '.cogniflow' / 'workspace').as_posix()}\"" in normalized
    assert f"\"{package_assets['cf_basic_io']['steps']}\"" in normalized
    assert f"\"{package_assets['cf_basic_io']['bin']}\"" in normalized


def test_resolve_distribution_demo_documents_stages_packaged_resources(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("cf_setup.run_demo.Path.home", lambda: tmp_path)
    monkeypatch.setattr(
        "cf_setup.run_demo._load_packaged_demo_texts",
        lambda: (
            "<x/n7_binding_baseDir> <https://cogniflow.odea-project.org/cf#value> \"./workspace\" .\n"
            "<x/stepsHeader> <https://cogniflow.odea-project.org/cf#stepsPath> \"../../../cf_basic_io/steps.nq\" .\n",
            "<x> <y> <z> .\n",
        ),
    )
    monkeypatch.setattr(
        "cf_setup.run_demo._resolve_distribution_package_assets",
        lambda: {
            "cf_basic_io": {
                "steps": (tmp_path / "resolved" / "cf_basic_io" / "steps.nq").as_posix(),
                "bin": (tmp_path / "resolved" / "cf_basic_io" / "bin").as_posix(),
            }
        },
    )

    options = RunDemoOptions(
        repo_root=None,
        python_exe="python",
        duckdb_version="1.4.2",
        native_arch="x64",
        auto_install_missing_prereqs=False,
        skip_native_deps=False,
        show_details=False,
        execution_mode="distribution",
    )
    report = SimpleNamespace(notes=[])

    staged_pipeline, staged_invocation = _resolve_distribution_demo_documents(options, report)

    assert staged_pipeline.is_file()
    assert staged_invocation.is_file()
    staged_text = staged_pipeline.read_text(encoding="utf-8")
    assert f"\"{(tmp_path / '.cogniflow' / 'workspace').as_posix()}\"" in staged_text
    assert "resolved/cf_basic_io/steps.nq" in staged_text.replace("\\", "/")
    assert any("RunDemo distribution resources staged from packaged cf_setup demo assets" in note for note in report.notes)


def test_resolve_repo_package_assets_uses_installed_distribution_paths(monkeypatch, tmp_path: Path) -> None:
    site_packages_root = tmp_path / "site-packages"
    module_roots = {
        name: site_packages_root / name
        for name in ("cf_basic_io", "cf_basic_signal", "cf_basic_sinks")
    }
    for root in module_roots.values():
        root.mkdir(parents=True)
        (root / "steps.nq").write_text("", encoding="utf-8")
        (root / "bin").mkdir()

    distribution_roots = {
        "cf-basic-io": site_packages_root,
        "cf-basic-signal": site_packages_root,
        "cf-basic-sinks": site_packages_root,
    }

    class _FakeDistribution:
        def __init__(self, root: Path) -> None:
            self._root = root

        def locate_file(self, path: Path) -> Path:
            return self._root / path

    def fake_distribution(name: str):
        return _FakeDistribution(distribution_roots[name])

    monkeypatch.setattr("cf_setup.run_demo.importlib.import_module", lambda name: (_ for _ in ()).throw(ModuleNotFoundError(name)))
    monkeypatch.setattr("cf_setup.run_demo.metadata.distribution", fake_distribution)

    assets = _resolve_repo_package_assets(tmp_path)

    assert assets["cf_basic_io"]["steps"] == (module_roots["cf_basic_io"] / "steps.nq").as_posix()
    assert assets["cf_basic_signal"]["bin"] == (module_roots["cf_basic_signal"] / "bin").as_posix()
    assert assets["cf_basic_sinks"]["steps"] == (module_roots["cf_basic_sinks"] / "steps.nq").as_posix()


def test_resolve_repo_package_assets_prefers_imported_editable_module_assets(monkeypatch, tmp_path: Path) -> None:
    imported_root = tmp_path / "editable" / "cf_basic_io"
    imported_root.mkdir(parents=True)
    (imported_root / "__init__.py").write_text("", encoding="utf-8")
    (imported_root / "steps.nq").write_text("", encoding="utf-8")
    (imported_root / "bin").mkdir()

    class _ImportedModule:
        __file__ = str(imported_root / "__init__.py")

    def fake_import_module(name: str):
        if name == "cf_basic_io":
            return _ImportedModule()
        raise ModuleNotFoundError(name)

    monkeypatch.setattr("cf_setup.run_demo.importlib.import_module", fake_import_module)

    # Provide fake distributions for the remaining packages so the resolver
    # does not crash when repo sources are absent and the packages are not
    # installed in the environment.
    fallback_root = tmp_path / "fallback"
    for pkg in ("cf_basic_signal", "cf_basic_sinks"):
        pkg_dir = fallback_root / pkg
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "__init__.py").write_text("", encoding="utf-8")
        (pkg_dir / "steps.nq").write_text("", encoding="utf-8")
        (pkg_dir / "bin").mkdir()

    class _FakeDistribution:
        def __init__(self, root: Path) -> None:
            self._root = root

        def locate_file(self, path: Path) -> Path:
            return self._root / path

    def fake_distribution(name: str):
        return _FakeDistribution(fallback_root)

    monkeypatch.setattr("cf_setup.run_demo.metadata.distribution", fake_distribution)

    assets = _resolve_repo_package_assets(tmp_path)

    assert assets["cf_basic_io"]["steps"] == (imported_root / "steps.nq").as_posix()
    assert assets["cf_basic_io"]["bin"] == (imported_root / "bin").as_posix()


def test_run_python_uses_console_logger_in_quiet_mode(monkeypatch, tmp_path: Path) -> None:
    calls: list[tuple[list[str], Path, dict[str, str]]] = []

    class DummyConsole:
        def run_process(self, args, *, cwd, env):
            calls.append((list(args), cwd, dict(env)))
            return SimpleNamespace(returncode=0, stdout="demo-output\n", stderr="")

    monkeypatch.setattr("cf_setup.run_demo.current_console", lambda: DummyConsole())

    completed = run_python(
        "python",
        ["-c", "print('demo')"],
        tmp_path,
        {"X": "1"},
        show_details=False,
    )

    assert completed.returncode == 0
    assert completed.stdout == "demo-output\n"
    assert calls == [(["python", "-c", "print('demo')"], tmp_path, {"X": "1"})]
