from pathlib import Path

from cf_setup.providers.windows import WindowsProvider


def test_windows_provider_returns_python_and_pip_status() -> None:
    provider = WindowsProvider()
    tools = {item.name: item for item in provider.diagnose()}
    assert tools["python"].available is True
    assert tools["pip"].available is True


def test_windows_provider_detects_msvc_from_vswhere(monkeypatch) -> None:
    install_path = Path(r"C:\VS\18\BuildTools")
    vcvars = install_path / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"

    monkeypatch.setattr("cf_setup.providers.windows.shutil.which", lambda name: None)
    monkeypatch.setattr(
        "cf_setup.providers.windows._resolve_msvc_installation_path",
        lambda: install_path,
    )
    monkeypatch.setattr("cf_setup.providers.windows.Path.exists", lambda path: path == vcvars)

    status = WindowsProvider()._msvc_status()

    assert status.available is True
    assert status.source == str(vcvars)
