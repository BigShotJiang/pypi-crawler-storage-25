from __future__ import annotations

import json
from importlib import metadata
from pathlib import Path
from types import SimpleNamespace
from typing import cast
import tomllib

import pytest

from cf_setup.provider_registry import (
    build_provider_registry_payload,
    refresh_provider_registry,
    validate_python_consumer_semantics,
    validate_python_provider_semantics,
)


class _FakeDistribution:
    def __init__(self, root: Path, *, direct_url_payload: dict[str, object] | None = None) -> None:
        self._root = root
        self._direct_url_payload = direct_url_payload

    def locate_file(self, path: Path) -> Path:
        return self._root / path

    def read_text(self, filename: str) -> str | None:
        if filename == "direct_url.json" and self._direct_url_payload is not None:
            return json.dumps(self._direct_url_payload)
        return None


def _write_descriptor(root: Path, descriptor_relative_path: str, library_relative_path: str, runtime_relative_path: str, *, provider_key: str, contract_symbol: str) -> None:
    descriptor_path = root / descriptor_relative_path
    descriptor_path.parent.mkdir(parents=True, exist_ok=True)
    descriptor_path.write_text(
        json.dumps(
            {
                "schema_version": "provider_descriptor.v1",
                "provider_key": provider_key,
                "contract_symbol": contract_symbol,
                "contract_version": 1,
                "library_candidates": [library_relative_path],
                "runtime_dir_candidates": [runtime_relative_path],
            }
        ),
        encoding="utf-8",
    )


def _write_library(root: Path, library_relative_path: str, runtime_relative_path: str) -> None:
    library_path = root / library_relative_path
    library_path.parent.mkdir(parents=True, exist_ok=True)
    library_path.write_text("binary", encoding="utf-8")
    (root / runtime_relative_path).mkdir(parents=True, exist_ok=True)


def _write_ontology_provider_vocab(root: Path) -> Path:
    path = root / "service_contracts.nq"
    path.write_text(
        """
<https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "ontology_read" .
<https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "ontology_read" .
<https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "step_discovery" .
<https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "step_discovery" .
<https://cogniflow.odea-project.org/cf#PipelineAuthoringPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#PipelineAuthoringPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#PipelineAuthoringPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "pipeline_authoring" .
<https://cogniflow.odea-project.org/cf#PipelineAuthoringPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#PipelineAuthoringPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "pipeline_authoring" .
<https://cogniflow.odea-project.org/cf#StepCataloguePythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#StepCataloguePythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#StepCataloguePythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "step_catalogue" .
<https://cogniflow.odea-project.org/cf#StepCataloguePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#StepCataloguePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "step_catalogue" .
<https://cogniflow.odea-project.org/cf#PipelineDraftPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#PipelineDraftPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#PipelineDraftPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "pipeline_draft" .
<https://cogniflow.odea-project.org/cf#PipelineDraftPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#PipelineDraftPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "pipeline_draft" .
<https://cogniflow.odea-project.org/cf#PipelineManagerPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#PipelineManagerPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#PipelineManagerPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "pipeline_manager" .
<https://cogniflow.odea-project.org/cf#PipelineManagerPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#PipelineManagerPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "pipeline_manager" .
<https://cogniflow.odea-project.org/cf#WorkspaceStorePythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#WorkspaceStorePythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#WorkspaceStorePythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "workspace_store" .
<https://cogniflow.odea-project.org/cf#WorkspaceStorePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#WorkspaceStorePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "workspace_store" .
<https://cogniflow.odea-project.org/cf#SetupBootstrapPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#SetupBootstrapPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#SetupBootstrapPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "setup_bootstrap" .
<https://cogniflow.odea-project.org/cf#SetupBootstrapPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#SetupBootstrapPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "setup_bootstrap" .
<https://cogniflow.odea-project.org/cf#EngineRunnerPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#EngineRunnerPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#EngineRunnerPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "engine_runner" .
<https://cogniflow.odea-project.org/cf#EngineRunnerPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#EngineRunnerPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "engine_runner" .
<https://cogniflow.odea-project.org/cf#DataHiveRunsPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#DataHiveRunsPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#DataHiveRunsPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "datahive_runs" .
<https://cogniflow.odea-project.org/cf#DataHiveRunsPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#DataHiveRunsPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "datahive_runs" .
<https://cogniflow.odea-project.org/cf#SemanticsStorePythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#SemanticsStorePythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#SemanticsStorePythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "semantics_store" .
<https://cogniflow.odea-project.org/cf#SemanticsStorePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#SemanticsStorePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "semantics_store" .
<https://cogniflow.odea-project.org/cf#SemanticsRuntimePythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#SemanticsRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#SemanticsRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "semantics_runtime" .
<https://cogniflow.odea-project.org/cf#SemanticsRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#SemanticsRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "semantics_runtime" .
<https://cogniflow.odea-project.org/cf#PipelineRuntimePythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#PipelineRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#PipelineRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "pipeline_runtime" .
<https://cogniflow.odea-project.org/cf#PipelineRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#PipelineRuntimePythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "pipeline_runtime" .
<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point> .
<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <https://cogniflow.odea-project.org/cf#providerKey> "setup_orchestration" .
<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointGroup> "cogniflow.service_providers" .
<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <https://cogniflow.odea-project.org/cf#entryPointName> "setup_orchestration" .
<https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_native_registry> .
<https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider> <https://cogniflow.odea-project.org/cf#providerKey> "step_runtime" .
<https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider> <https://cogniflow.odea-project.org/cf#contractSymbol> "cf_get_step_runtime_contract_v1" .
<https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider> <https://cogniflow.odea-project.org/cf#descriptorSchemaVersion> "provider_descriptor.v1" .
<https://cogniflow.odea-project.org/cf#OpcuaOwnerNativeProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#OpcuaOwnerNativeProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_native_registry> .
<https://cogniflow.odea-project.org/cf#OpcuaOwnerNativeProvider> <https://cogniflow.odea-project.org/cf#providerKey> "opcua_owner" .
<https://cogniflow.odea-project.org/cf#OpcuaOwnerNativeProvider> <https://cogniflow.odea-project.org/cf#contractSymbol> "cf_get_opcua_owner_contract_v1" .
<https://cogniflow.odea-project.org/cf#OpcuaOwnerNativeProvider> <https://cogniflow.odea-project.org/cf#descriptorSchemaVersion> "provider_descriptor.v1" .
<https://cogniflow.odea-project.org/cf#DataHiveSinkNativeProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#DataHiveSinkNativeProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_native_registry> .
<https://cogniflow.odea-project.org/cf#DataHiveSinkNativeProvider> <https://cogniflow.odea-project.org/cf#providerKey> "datahive_sink" .
<https://cogniflow.odea-project.org/cf#DataHiveSinkNativeProvider> <https://cogniflow.odea-project.org/cf#contractSymbol> "cf_get_datahive_sink_contract_v1" .
<https://cogniflow.odea-project.org/cf#DataHiveSinkNativeProvider> <https://cogniflow.odea-project.org/cf#descriptorSchemaVersion> "provider_descriptor.v1" .
<https://cogniflow.odea-project.org/cf#WorkspaceStoreNativeProvider> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://cogniflow.odea-project.org/cf#ServiceProvider> .
<https://cogniflow.odea-project.org/cf#WorkspaceStoreNativeProvider> <https://cogniflow.odea-project.org/cf#providerKind> <https://cogniflow.odea-project.org/cf#provider_kind_native_registry> .
<https://cogniflow.odea-project.org/cf#WorkspaceStoreNativeProvider> <https://cogniflow.odea-project.org/cf#providerKey> "workspace_store" .
<https://cogniflow.odea-project.org/cf#WorkspaceStoreNativeProvider> <https://cogniflow.odea-project.org/cf#contractSymbol> "cf_get_workspace_store_contract_v1" .
<https://cogniflow.odea-project.org/cf#WorkspaceStoreNativeProvider> <https://cogniflow.odea-project.org/cf#descriptorSchemaVersion> "provider_descriptor.v1" .
""".strip(),
        encoding="utf-8",
    )
    return path


def test_provider_registry_collects_installed_provider_descriptors(monkeypatch, tmp_path: Path) -> None:
    ontology_vocab = _write_ontology_provider_vocab(tmp_path)
    sdk_root = tmp_path / "sdk-dist"
    opcua_root = tmp_path / "opcua-dist"
    datahive_root = tmp_path / "datahive-dist"
    workspace_store_root = tmp_path / "workspace-store-dist"

    _write_descriptor(
        sdk_root,
        "cogniflow_pipeline_sdk/provider_descriptor.v1.json",
        "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll",
        "cogniflow_pipeline_sdk/bin",
        provider_key="step_runtime",
        contract_symbol="cf_get_step_runtime_contract_v1",
    )
    _write_library(sdk_root, "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll", "cogniflow_pipeline_sdk/bin")

    _write_descriptor(
        opcua_root,
        "cf_opcua_server/provider_descriptor.v1.json",
        "cf_opcua_server/native/bin/cf_opcua_owner_provider.dll",
        "cf_opcua_server/native/bin",
        provider_key="opcua_owner",
        contract_symbol="cf_get_opcua_owner_contract_v1",
    )
    _write_library(opcua_root, "cf_opcua_server/native/bin/cf_opcua_owner_provider.dll", "cf_opcua_server/native/bin")

    _write_descriptor(
        datahive_root,
        "cf_datahive/provider_descriptor.v1.json",
        "cf_datahive/native/bin/cf_datahive_cpp.dll",
        "cf_datahive/native/bin",
        provider_key="datahive_sink",
        contract_symbol="cf_get_datahive_sink_contract_v1",
    )
    _write_library(datahive_root, "cf_datahive/native/bin/cf_datahive_cpp.dll", "cf_datahive/native/bin")

    _write_descriptor(
        workspace_store_root,
        "cf_workspace_store/provider_descriptor.v1.json",
        "cf_workspace_store/native/bin/cf_workspace_store_provider.dll",
        "cf_workspace_store/native/bin",
        provider_key="workspace_store",
        contract_symbol="cf_get_workspace_store_contract_v1",
    )
    _write_library(
        workspace_store_root,
        "cf_workspace_store/native/bin/cf_workspace_store_provider.dll",
        "cf_workspace_store/native/bin",
    )

    fake_distributions = {
        "cf-pipeline-sdk": _FakeDistribution(sdk_root),
        "cf-opcua-server": _FakeDistribution(opcua_root),
        "cf-datahive": _FakeDistribution(datahive_root),
        "cf-workspace-store": _FakeDistribution(workspace_store_root),
    }

    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.distribution",
        lambda package_name: fake_distributions[package_name]
        if package_name in fake_distributions
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(package_name)),
    )
    monkeypatch.setattr("cf_setup.provider_registry._locate_ontology_provider_vocab", lambda: ontology_vocab)
    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.entry_points",
        lambda: [
            SimpleNamespace(name="ontology_read", value="cf_semantics_runtime.service_contract_provider:OntologyReadProvider"),
            SimpleNamespace(name="step_discovery", value="cf_semantics_runtime.service_contract_provider:StepDiscoveryProvider"),
            SimpleNamespace(name="pipeline_authoring", value="cf_semantics_runtime.service_contract_provider:PipelineAuthoringProvider"),
            SimpleNamespace(name="step_catalogue", value="cf_pipeline_creator.service_contract_provider:StepCatalogueProvider"),
            SimpleNamespace(name="pipeline_draft", value="cf_pipeline_creator.service_contract_provider:PipelineDraftProvider"),
            SimpleNamespace(name="pipeline_manager", value="cf_pipeline_manager.service_contract_provider:PipelineManagerProvider"),
            SimpleNamespace(name="workspace_store", value="cf_workspace_store.service_contract_provider:WorkspaceStoreProvider"),
            SimpleNamespace(name="setup_bootstrap", value="cf_semantics_runtime.service_contract_provider:SetupBootstrapProvider"),
            SimpleNamespace(name="engine_runner", value="cf_pipeline_engine.service_contract_provider:EngineRunnerProvider"),
            SimpleNamespace(name="datahive_runs", value="cf_datahive.service_contract_provider:DataHiveRunsProvider"),
            SimpleNamespace(name="semantics_store", value="cf_semantics_store.service_contract_provider:SemanticsStoreProvider"),
            SimpleNamespace(name="semantics_runtime", value="cf_semantics_runtime.service_contract_provider:SemanticsRuntimeProvider"),
            SimpleNamespace(name="pipeline_runtime", value="cf_pipeline_manager.service_contract_provider:provide_pipeline_runtime_contract"),
            SimpleNamespace(name="setup_orchestration", value="cf_setup.service_contract_provider:SetupOrchestrationProvider"),
        ],
    )
    monkeypatch.setattr("cf_setup.provider_registry.validate_python_consumer_semantics", lambda **kwargs: None)

    payload = build_provider_registry_payload()
    providers = cast(dict[str, dict[str, object]], payload["providers"])
    assert sorted(providers) == ["datahive_sink", "opcua_owner", "step_runtime", "workspace_store"]

    result = refresh_provider_registry(tmp_path / "workspace")
    written = json.loads(result.path.read_text(encoding="utf-8"))
    written_providers = cast(dict[str, dict[str, object]], written["providers"])
    assert written["schema_version"] == "provider_registry.v1"
    assert sorted(written_providers) == ["datahive_sink", "opcua_owner", "step_runtime", "workspace_store"]


def test_provider_registry_uses_editable_project_descriptor_when_dist_metadata_is_missing(monkeypatch, tmp_path: Path) -> None:
    ontology_vocab = _write_ontology_provider_vocab(tmp_path)
    project_root = tmp_path / "cf_pipeline_sdk_project"
    dist_root = tmp_path / "sdk-dist"

    _write_descriptor(
        project_root / "src",
        "cogniflow_pipeline_sdk/provider_descriptor.v1.json",
        "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll",
        "cogniflow_pipeline_sdk/bin",
        provider_key="step_runtime",
        contract_symbol="cf_get_step_runtime_contract_v1",
    )
    _write_library(dist_root, "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll", "cogniflow_pipeline_sdk/bin")

    fake_distribution = _FakeDistribution(
        dist_root,
        direct_url_payload={
            "dir_info": {"editable": True},
            "url": project_root.as_uri(),
        },
    )

    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.distribution",
        lambda package_name: fake_distribution
        if package_name == "cf-pipeline-sdk"
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(package_name)),
    )
    monkeypatch.setattr("cf_setup.provider_registry._locate_ontology_provider_vocab", lambda: ontology_vocab)

    payload = build_provider_registry_payload()
    providers = cast(dict[str, dict[str, object]], payload["providers"])
    assert list(providers) == ["step_runtime"]
    assert str(providers["step_runtime"]["library_path"]).endswith("cf_step_runtime_provider.dll")


def test_cf_ontology_pyproject_does_not_advertise_service_provider_entry_points() -> None:
    pyproject_path = Path(__file__).resolve().parents[3] / "sandcastle" / "cf_ontology" / "pyproject.toml"
    pyproject = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))

    project = cast(dict[str, object], pyproject.get("project", {}))
    entry_points = cast(dict[str, object], project.get("entry-points", {}))

    assert "cogniflow.service_providers" not in entry_points


def test_setup_orchestration_contract_surface_is_fully_declared() -> None:
    ontology_path = (
        Path(__file__).resolve().parents[3]
        / "sandcastle"
        / "cf_ontology"
        / "src"
        / "cf_ontology"
        / "ontology"
        / "foundations"
        / "contracts"
        / "service_contracts.nq"
    )
    ontology = ontology_path.read_text(encoding="utf-8")

    assert '<https://cogniflow.odea-project.org/cf#SetupOrchestrationContractV1> <https://cogniflow.odea-project.org/cf#contractScope> <https://cogniflow.odea-project.org/cf#setupOrchestrationScope> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#SetupOrchestrationContractV1> <https://cogniflow.odea-project.org/cf#contractVersion> "1"^^<http://www.w3.org/2001/XMLSchema#integer> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#SetupOrchestrationContractV1> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#setupOrchestrationScope> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#SetupOrchestrationContractV1> <https://cogniflow.odea-project.org/cf#hasOperation> <https://cogniflow.odea-project.org/cf#setup_orchestration_plan_installation> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#setup_orchestration_plan_installation> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#setup_orchestration_diagnose_prerequisites> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#setup_orchestration_execute_install> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology
    assert '<https://cogniflow.odea-project.org/cf#SetupOrchestrationPythonProvider> <https://cogniflow.odea-project.org/cf#hasCategory> <https://cogniflow.odea-project.org/cf#bindingCategory> .' in ontology


def test_provider_registry_fails_when_installed_provider_descriptor_is_missing(monkeypatch, tmp_path: Path) -> None:
    ontology_vocab = _write_ontology_provider_vocab(tmp_path)
    dist_root = tmp_path / "datahive-dist"
    _write_library(dist_root, "cf_datahive/native/bin/cf_datahive_cpp.dll", "cf_datahive/native/bin")

    fake_distribution = _FakeDistribution(dist_root)
    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.distribution",
        lambda package_name: fake_distribution
        if package_name == "cf-datahive"
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(package_name)),
    )
    monkeypatch.setattr("cf_setup.provider_registry._locate_ontology_provider_vocab", lambda: ontology_vocab)

    with pytest.raises(FileNotFoundError, match="Provider descriptor for cf-datahive not found"):
        build_provider_registry_payload()


def test_validate_python_provider_semantics_rejects_entry_point_drift(monkeypatch, tmp_path: Path) -> None:
    ontology_vocab = _write_ontology_provider_vocab(tmp_path)
    monkeypatch.setattr("cf_setup.provider_registry._locate_ontology_provider_vocab", lambda: ontology_vocab)
    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.entry_points",
        lambda: [
            SimpleNamespace(name="ontology_read", value="x:y"),
            SimpleNamespace(name="step_discovery", value="x:y"),
            SimpleNamespace(name="pipeline_authoring", value="x:y"),
            SimpleNamespace(name="step_catalogue", value="x:y"),
            SimpleNamespace(name="pipeline_draft", value="x:y"),
            SimpleNamespace(name="pipeline_manager", value="x:y"),
            SimpleNamespace(name="workspace_store", value="x:y"),
            SimpleNamespace(name="setup_bootstrap", value="x:y"),
            SimpleNamespace(name="engine_runner", value="x:y"),
            SimpleNamespace(name="datahive_runs", value="x:y"),
            SimpleNamespace(name="semantics_store", value="x:y"),
            SimpleNamespace(name="semantics_runtime", value="x:y"),
        ],
    )

    with pytest.raises(ValueError, match="do not match installed cogniflow.service_providers entry points"):
        validate_python_provider_semantics()


def test_provider_registry_rejects_native_descriptor_drift_against_ontology(monkeypatch, tmp_path: Path) -> None:
    ontology_vocab = _write_ontology_provider_vocab(tmp_path)
    sdk_root = tmp_path / "sdk-dist"
    _write_descriptor(
        sdk_root,
        "cogniflow_pipeline_sdk/provider_descriptor.v1.json",
        "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll",
        "cogniflow_pipeline_sdk/bin",
        provider_key="step_runtime",
        contract_symbol="wrong_symbol",
    )
    _write_library(sdk_root, "cogniflow_pipeline_sdk/bin/cf_step_runtime_provider.dll", "cogniflow_pipeline_sdk/bin")

    monkeypatch.setattr("cf_setup.provider_registry._locate_ontology_provider_vocab", lambda: ontology_vocab)
    monkeypatch.setattr(
        "cf_setup.provider_registry.metadata.distribution",
        lambda package_name: _FakeDistribution(sdk_root)
        if package_name == "cf-pipeline-sdk"
        else (_ for _ in ()).throw(metadata.PackageNotFoundError(package_name)),
    )

    with pytest.raises(ValueError, match="contractSymbol mismatch"):
        build_provider_registry_payload()


def test_validate_python_consumer_semantics_matches_package_level_contract_usage(monkeypatch, tmp_path: Path) -> None:
    for consumer_key, relative_root, provider_key_names in (
        ("cf_web_backend", Path("sandcastle/cf_web/src"), ("SEMANTICS_RUNTIME", "SEMANTICS_STORE", "STEP_CATALOGUE", "PIPELINE_DRAFT", "PIPELINE_MANAGER")),
        (
            "cf_pipeline_manager",
            Path("sandcastle/cf_pipeline/cf_pipeline_manager/src"),
            ("ENGINE_RUNNER", "WORKSPACE_STORE", "ONTOLOGY_READ", "PIPELINE_AUTHORING"),
        ),
        ("cf_pipeline_creator", Path("sandcastle/cf_pipeline/cf_pipeline_creator/src"), ("SEMANTICS_RUNTIME", "PIPELINE_AUTHORING")),
        (
            "cf_setup",
            Path("sandcastle/cf_setup/src"),
            ("SETUP_BOOTSTRAP", "DATAHIVE_RUNS", "SEMANTICS_STORE", "PIPELINE_AUTHORING", "PIPELINE_MANAGER"),
        ),
        ("cf_iri_site", Path("sandcastle/cf_iri_site/src"), "ONTOLOGY_READ"),
        ("cf_semantics_runtime", Path("sandcastle/cf_semantics_runtime/src"), ("SEMANTICS_STORE", "STEP_CATALOGUE")),
    ):
        source_root = tmp_path / relative_root
        source_root.mkdir(parents=True, exist_ok=True)
        if isinstance(provider_key_names, tuple):
            assignments = "\n".join(
                f"KEY_{index} = ProviderKey.{provider_key_name}"
                for index, provider_key_name in enumerate(provider_key_names, start=1)
            )
            content = f"from cf_service_contracts import ProviderKey\n{assignments}\n"
        else:
            content = f"from cf_service_contracts import ProviderKey\nKEY = ProviderKey.{provider_key_names}\n"
        (source_root / "consumer.py").write_text(content, encoding="utf-8")

    monkeypatch.setattr("cf_setup.provider_registry._repo_root", lambda: tmp_path)
    monkeypatch.setattr(
        "cf_setup.provider_registry._load_ontology_consumer_semantics",
        lambda: [
            SimpleNamespace(consumer_key="cf_web_backend", contract_keys=frozenset({"semantics_runtime", "semantics_store", "step_catalogue", "pipeline_draft", "pipeline_manager"})),
            SimpleNamespace(
                consumer_key="cf_pipeline_manager",
                contract_keys=frozenset(
                    {
                        "engine_runner",
                        "workspace_store",
                        "ontology_read",
                        "pipeline_authoring",
                    }
                ),
            ),
            SimpleNamespace(consumer_key="cf_pipeline_creator", contract_keys=frozenset({"semantics_runtime", "pipeline_authoring"})),
            SimpleNamespace(
                consumer_key="cf_setup",
                contract_keys=frozenset(
                    {
                        "setup_bootstrap",
                        "datahive_runs",
                        "semantics_store",
                        "pipeline_authoring",
                        "pipeline_manager",
                    }
                ),
            ),
            SimpleNamespace(consumer_key="cf_iri_site", contract_keys=frozenset({"ontology_read"})),
            SimpleNamespace(consumer_key="cf_semantics_runtime", contract_keys=frozenset({"semantics_store", "step_catalogue"})),
        ],
    )

    validate_python_consumer_semantics()


def test_validate_python_consumer_semantics_rejects_contract_usage_drift(monkeypatch, tmp_path: Path) -> None:
    source_root = tmp_path / "sandcastle" / "cf_web" / "src"
    source_root.mkdir(parents=True, exist_ok=True)
    (source_root / "consumer.py").write_text(
        "from cf_service_contracts import ProviderKey\nKEY = ProviderKey.ONTOLOGY_READ\n",
        encoding="utf-8",
    )
    for relative_root in (
        Path("sandcastle/cf_pipeline/cf_pipeline_manager/src"),
        Path("sandcastle/cf_pipeline/cf_pipeline_creator/src"),
        Path("sandcastle/cf_setup/src"),
        Path("sandcastle/cf_iri_site/src"),
        Path("sandcastle/cf_semantics_runtime/src"),
    ):
        target = tmp_path / relative_root
        target.mkdir(parents=True, exist_ok=True)
        (target / "noop.py").write_text("", encoding="utf-8")

    monkeypatch.setattr("cf_setup.provider_registry._repo_root", lambda: tmp_path)
    monkeypatch.setattr(
        "cf_setup.provider_registry._load_ontology_consumer_semantics",
        lambda: [
            SimpleNamespace(consumer_key="cf_web_backend", contract_keys=frozenset({"pipeline_manager"})),
            SimpleNamespace(consumer_key="cf_pipeline_manager", contract_keys=frozenset()),
            SimpleNamespace(consumer_key="cf_pipeline_creator", contract_keys=frozenset()),
            SimpleNamespace(consumer_key="cf_setup", contract_keys=frozenset()),
            SimpleNamespace(consumer_key="cf_iri_site", contract_keys=frozenset()),
            SimpleNamespace(consumer_key="cf_semantics_runtime", contract_keys=frozenset()),
        ],
    )

    with pytest.raises(ValueError, match="Service consumer contract usage drift"):
        validate_python_consumer_semantics()
