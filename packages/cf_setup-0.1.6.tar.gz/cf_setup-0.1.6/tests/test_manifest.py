from pathlib import Path

from cf_setup.manifest import load_manifest

LOCAL_MANIFEST_PATH = (
    Path(__file__).resolve().parents[1] / "src" / "cf_setup" / "install_manifest.toml"
)


def test_load_manifest_reads_profiles_and_modules() -> None:
    manifest = load_manifest(LOCAL_MANIFEST_PATH)
    assert "cf-ontology" in manifest.modules
    assert "cf-semantics-store" in manifest.modules
    assert "cf-semantics-runtime" in manifest.modules
    assert "cf-package-contracts" in manifest.modules
    assert "cf-step-tooling" in manifest.modules
    assert "cf-pipeline-creator" in manifest.modules
    assert "cf-pipeline-manager" in manifest.modules
    assert "cf-setup" in manifest.modules
    assert "core" in manifest.profiles
    assert "cf-setup" in manifest.profiles["core"]
    assert manifest.modules["cf-core-cli"].path == "sandcastle/cf_core_cli"
    assert manifest.modules["cf-setup"].path == "sandcastle/cf_setup"
    assert manifest.modules["cf-semantics-store"].path == "sandcastle/cf_semantics_store"
    assert manifest.modules["cf-semantics-runtime"].path == "sandcastle/cf_semantics_runtime"
    assert manifest.modules["cf-package-contracts"].path == "sandcastle/cf_package_contracts"
    assert manifest.modules["cf-step-tooling"].path == "sandcastle/cf_step_tooling"
    assert "cf-package-contracts" in manifest.modules["cf-pipeline-sdk"].depends_on
    assert "cf-package-contracts" in manifest.modules["cf-pipeline-engine"].depends_on
    assert "cf-pipeline-engine" in manifest.modules["cf-pipeline-manager"].depends_on
    assert "cf-ontology" in manifest.modules["cf-pipeline-manager"].depends_on
    assert "cf-semantics-runtime" in manifest.modules["cf-ontology"].depends_on
    assert manifest.modules["cf-pipeline-engine"].dependencies[0].kind == "runtime_service"
    assert any(dependency.kind == "compile" for dependency in manifest.modules["cf-pipeline-engine"].dependencies)
    assert "cf-step-tooling" in manifest.modules["cf-basic-io"].depends_on
    assert manifest.modules["cf-pipeline-engine"].engine_build is False
    assert "cf-pipeline-creator" in manifest.modules["cf-web"].depends_on
    assert any(hook.hook_id == "refresh-provider-registry" for hook in manifest.hooks)
    assert any(hook.hook_id == "ingest-installed-steps" for hook in manifest.hooks)
