from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from cf_setup.doctor import (
    run_contract_diagnostics,
    run_provider_diagnostics,
    run_runtime_diagnostics,
    run_setup_diagnostics,
    run_step_diagnostics,
)


class TestProviderDiagnostics:
    """Tests verifying provider diagnostic output shape and failure classification."""

    def test_provider_diagnostics_output_shape(self, monkeypatch, tmp_path: Path) -> None:
        """Provider diagnostic payload contains stable keys and expected sections."""
        monkeypatch.setattr(
            "cf_setup.doctor._safe_load_entry_point",
            lambda entry_point_value: (True, None),
        )
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "ontology_read": "cf_semantics_runtime.service_contract_provider:OntologyReadProvider",
                "step_discovery": "cf_semantics_runtime.service_contract_provider:StepDiscoveryProvider",
            },
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_provider_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider",
                    provider_key="ontology_read",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point",
                    entry_point_group="cogniflow.service_providers",
                    entry_point_name="ontology_read",
                    contract_symbol=None,
                    descriptor_schema_version=None,
                ),
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider",
                    provider_key="step_runtime",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_native_registry",
                    entry_point_group=None,
                    entry_point_name=None,
                    contract_symbol="cf_get_step_runtime_contract_v1",
                    descriptor_schema_version="provider_descriptor.v1",
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor.build_provider_registry_payload",
            lambda: {
                "schema_version": "provider_registry.v1",
                "providers": {
                    "step_runtime": {
                        "package_name": "cf-pipeline-sdk",
                        "contract_symbol": "cf_get_step_runtime_contract_v1",
                        "contract_version": 1,
                        "library_path": "/path/lib.dll",
                        "runtime_paths": ["/path"],
                    }
                },
            },
        )

        payload = run_provider_diagnostics()

        assert payload["schema_version"] == "cf_doctor_providers.v1"
        assert isinstance(payload["python_providers"], list)
        assert isinstance(payload["native_providers"], list)
        assert isinstance(payload["missing_providers"], list)
        assert isinstance(payload["duplicate_providers"], list)
        assert isinstance(payload["load_errors"], list)

        ontology_read = next(
            p for p in payload["python_providers"] if p["provider_key"] == "ontology_read"
        )
        assert ontology_read["status"] == "resolved"
        assert ontology_read["entry_point_value"] == "cf_semantics_runtime.service_contract_provider:OntologyReadProvider"

        step_runtime = next(
            p for p in payload["native_providers"] if p["provider_key"] == "step_runtime"
        )
        assert step_runtime["status"] == "resolved"
        assert step_runtime["contract_symbol"] == "cf_get_step_runtime_contract_v1"

        # Missing provider should be reported
        assert any(
            p["provider_key"] == "semantics_store" and p["status"] == "missing"
            for p in payload["python_providers"]
        )

    def test_provider_diagnostics_classifies_load_error(self, monkeypatch, tmp_path: Path) -> None:
        """A provider entry point that fails to load is classified as load_error."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "ontology_read": "nonexistent.module:MissingClass",
            },
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_provider_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider",
                    provider_key="ontology_read",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point",
                    entry_point_group="cogniflow.service_providers",
                    entry_point_name="ontology_read",
                    contract_symbol=None,
                    descriptor_schema_version=None,
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor.build_provider_registry_payload",
            lambda: {"schema_version": "provider_registry.v1", "providers": {}},
        )

        payload = run_provider_diagnostics()

        ontology_read = next(
            p for p in payload["python_providers"] if p["provider_key"] == "ontology_read"
        )
        assert ontology_read["status"] == "load_error"
        assert ontology_read["load_error"] is not None
        assert any(
            le["provider_key"] == "ontology_read" for le in payload["load_errors"]
        )

    def test_provider_diagnostics_reports_duplicate_python_entry_points(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        """Duplicate Python provider entry-point registrations populate duplicate_providers."""
        monkeypatch.setattr(
            "cf_setup.doctor._list_service_provider_entry_points",
            lambda: [
                ("ontology_read", "cf_semantics_runtime.service_contract_provider:OntologyReadProvider"),
                ("ontology_read", "cf_semantics_runtime.service_contract_provider:DuplicateProvider"),
                ("step_discovery", "cf_semantics_runtime.service_contract_provider:StepDiscoveryProvider"),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "ontology_read": "cf_semantics_runtime.service_contract_provider:OntologyReadProvider",
                "step_discovery": "cf_semantics_runtime.service_contract_provider:StepDiscoveryProvider",
            },
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_provider_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#OntologyReadPythonProvider",
                    provider_key="ontology_read",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point",
                    entry_point_group="cogniflow.service_providers",
                    entry_point_name="ontology_read",
                    contract_symbol=None,
                    descriptor_schema_version=None,
                ),
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#StepDiscoveryPythonProvider",
                    provider_key="step_discovery",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_python_entry_point",
                    entry_point_group="cogniflow.service_providers",
                    entry_point_name="step_discovery",
                    contract_symbol=None,
                    descriptor_schema_version=None,
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor.build_provider_registry_payload",
            lambda: {"schema_version": "provider_registry.v1", "providers": {}},
        )

        payload = run_provider_diagnostics()

        assert "ontology_read" in payload["duplicate_providers"]
        assert "step_discovery" not in payload["duplicate_providers"]

    def test_provider_diagnostics_reports_native_registry_error(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        """Native provider registry build failures are reported without crashing."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {},
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_provider_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#StepRuntimeNativeProvider",
                    provider_key="step_runtime",
                    provider_kind="https://cogniflow.odea-project.org/cf#provider_kind_native_registry",
                    entry_point_group=None,
                    entry_point_name=None,
                    contract_symbol="cf_get_step_runtime_contract_v1",
                    descriptor_schema_version="provider_descriptor.v1",
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor.build_provider_registry_payload",
            lambda: (_ for _ in ()).throw(RuntimeError("native registry failed")),
        )

        payload = run_provider_diagnostics()

        step_runtime = next(
            p for p in payload["native_providers"] if p["provider_key"] == "step_runtime"
        )
        assert step_runtime["status"] == "registry_error"
        assert step_runtime["load_error"] is not None
        assert any(
            le["provider_key"] == "step_runtime" for le in payload["load_errors"]
        )


class TestContractDiagnostics:
    """Tests verifying contract diagnostic output shape."""

    def test_contract_diagnostics_output_shape(self, monkeypatch, tmp_path: Path) -> None:
        """Contract diagnostic payload contains stable keys and expected sections."""
        monkeypatch.setattr(
            "cf_setup.doctor.load_ontology_contract_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#OntologyReadContractV1",
                    contract_name="OntologyReadContractV1",
                    contract_version="1",
                    scope_iri="https://cogniflow.odea-project.org/cf#ontologyReadScope",
                    provider_key="ontology_read",
                ),
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#StepRuntimeContractV1",
                    contract_name="StepRuntimeContractV1",
                    contract_version="1",
                    scope_iri="https://cogniflow.odea-project.org/cf#pipelineRuntimeScope",
                    provider_key="step_runtime",
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_consumer_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#CfWebBackendConsumer",
                    consumer_key="cf_web_backend",
                    contract_keys=frozenset({"ontology_read"}),
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "ontology_read": "cf_semantics_runtime.service_contract_provider:OntologyReadProvider",
                "step_runtime": "cf_pipeline_engine.service_contract_provider:EngineRunnerProvider",
            },
        )

        payload = run_contract_diagnostics()

        assert payload["schema_version"] == "cf_doctor_contracts.v1"
        assert isinstance(payload["contracts"], list)
        assert isinstance(payload["missing_contracts"], list)

        ontology_read = next(
            c for c in payload["contracts"] if c["contract_name"] == "OntologyReadContractV1"
        )
        assert ontology_read["contract_version"] == "1"
        assert ontology_read["provider_key"] == "ontology_read"
        assert "cf_web_backend" in ontology_read["consumer_keys"]
        assert ontology_read["status"] == "active"

    def test_contract_diagnostics_missing_provider_entry_point(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        """Contract whose provider lacks an entry point is classified missing_provider_entry_point."""
        monkeypatch.setattr(
            "cf_setup.doctor.load_ontology_contract_semantics",
            lambda: [
                SimpleNamespace(
                    iri="https://cogniflow.odea-project.org/cf#OntologyReadContractV1",
                    contract_name="OntologyReadContractV1",
                    contract_version="1",
                    scope_iri="https://cogniflow.odea-project.org/cf#ontologyReadScope",
                    provider_key="ontology_read",
                ),
            ],
        )
        monkeypatch.setattr(
            "cf_setup.doctor._load_ontology_consumer_semantics",
            lambda: [],
        )
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {},
        )

        payload = run_contract_diagnostics()

        ontology_read = next(
            c for c in payload["contracts"] if c["contract_name"] == "OntologyReadContractV1"
        )
        assert ontology_read["status"] == "missing_provider_entry_point"
        assert "OntologyReadContractV1" in payload["missing_contracts"]


class TestSetupDiagnostics:
    """Tests verifying setup diagnostic output shape and contract consumption evidence."""

    def test_setup_diagnostics_output_shape(self, monkeypatch, tmp_path: Path) -> None:
        """Setup diagnostic payload contains stable keys and expected sections."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "setup_orchestration": "cf_setup.service_contract_provider:SetupOrchestrationProvider",
            },
        )

        payload = run_setup_diagnostics()

        assert payload["schema_version"] == "cf_doctor_setup.v1"
        assert isinstance(payload["setup_contract"], dict)
        assert isinstance(payload["prerequisites"], dict)
        assert isinstance(payload["provider_registry_refresh"], dict)
        assert isinstance(payload["plan_capability"], dict)
        assert isinstance(payload["bootstrap_paths"], list)
        assert isinstance(payload["contract_consumption"], dict)
        assert isinstance(payload["bypass_findings"], list)

        assert payload["setup_contract"]["provider_key"] == "setup_orchestration"
        assert payload["setup_contract"]["status"] == "resolved"
        assert payload["prerequisites"]["status"] == "resolved"
        assert payload["provider_registry_refresh"]["status"] == "path_computed"
        assert payload["plan_capability"]["install_dry_run_capable"] is True

    def test_setup_diagnostics_reports_missing_setup_contract(self, monkeypatch, tmp_path: Path) -> None:
        """When setup orchestration entry point is missing, status is missing_entry_point."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {},
        )

        payload = run_setup_diagnostics()

        assert payload["setup_contract"]["status"] == "missing_entry_point"
        assert payload["setup_contract"]["provider_key"] == "setup_orchestration"

    def test_setup_diagnostics_contract_consumption_map(self, monkeypatch, tmp_path: Path) -> None:
        """Contract consumption map reports all setup-adjacent contracts as contract_bound."""
        payload = run_setup_diagnostics()

        consumption = payload["contract_consumption"]
        assert consumption["setup_orchestration"] in {"resolved", "missing_entry_point", "load_error", "error"}
        assert consumption["setup_bootstrap"] == "contract_bound"
        assert consumption["pipeline_authoring"] == "contract_bound"
        assert consumption["pipeline_manager"] == "contract_bound"
        assert consumption["datahive_runs"] == "contract_bound"
        assert consumption["semantics_store"] == "contract_bound"

    def test_setup_diagnostics_bootstrap_paths_classified(self, monkeypatch, tmp_path: Path) -> None:
        """Bootstrap paths are classified as setup_bootstrap, not runtime bypass."""
        payload = run_setup_diagnostics()

        paths = payload["bootstrap_paths"]
        assert len(paths) >= 2
        for path_entry in paths:
            assert path_entry["classification"] == "setup_bootstrap"
            assert "owner" in path_entry
            assert "reason" in path_entry

    def test_setup_diagnostics_no_bypass_findings(self, monkeypatch, tmp_path: Path) -> None:
        """No unclassified setup bypass findings are present in the diagnostic output."""
        payload = run_setup_diagnostics()

        assert payload["bypass_findings"] == []


class TestStepDiagnostics:
    """Tests verifying step diagnostic output shape and contract consumption evidence."""

    def test_step_diagnostics_output_shape(self, monkeypatch, tmp_path: Path) -> None:
        """Step diagnostic payload contains stable keys and expected sections."""
        monkeypatch.setattr(
            "cf_setup.doctor._safe_load_entry_point",
            lambda entry_point_value: (True, None),
        )
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "step_discovery": "cf_semantics_runtime.service_contract_provider:StepDiscoveryProvider",
            },
        )
        monkeypatch.setattr(
            "cf_setup.doctor.require_provider",
            lambda key: SimpleNamespace(
                get_step_packages=lambda: [],
                get_processing_steps=lambda: [],
            ),
        )

        payload = run_step_diagnostics()

        assert payload["schema_version"] == "cf_doctor_steps.v1"
        assert isinstance(payload["step_discovery"], dict)
        assert isinstance(payload["step_packages"], list)
        assert isinstance(payload["processing_steps"], list)
        assert isinstance(payload["step_graphs"], list)
        assert isinstance(payload["step_entry_points"], list)
        assert isinstance(payload["missing_providers"], list)

        assert payload["step_discovery"]["provider_key"] == "step_discovery"
        assert payload["step_discovery"]["status"] == "resolved"

    def test_step_diagnostics_reports_missing_step_discovery(self, monkeypatch, tmp_path: Path) -> None:
        """When step discovery entry point is missing, status is missing_entry_point."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {},
        )

        payload = run_step_diagnostics()

        assert payload["step_discovery"]["status"] == "missing_entry_point"
        assert payload["missing_providers"] == ["step_discovery"]

    def test_step_diagnostics_load_error_classified(self, monkeypatch, tmp_path: Path) -> None:
        """A step discovery entry point that fails to load is classified as load_error."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "step_discovery": "nonexistent.module:MissingClass",
            },
        )

        payload = run_step_diagnostics()

        assert payload["step_discovery"]["status"] == "load_error"
        assert payload["step_discovery"]["error"] is not None
        assert "step_discovery" in payload["missing_providers"]


class TestRuntimeDiagnostics:
    """Tests verifying runtime diagnostic output shape and contract consumption evidence."""

    def test_runtime_diagnostics_output_shape(self, monkeypatch, tmp_path: Path) -> None:
        """Runtime diagnostic payload contains stable keys and expected sections."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "pipeline_manager": "cf_pipeline_manager.service_contract_provider:PipelineManagerProvider",
                "pipeline_runtime": "cf_pipeline_manager.service_contract_provider:PipelineRuntimeProvider",
                "engine_runner": "cf_pipeline_engine.service_contract_provider:EngineRunnerProvider",
                "datahive_runs": "cf_datahive.service_contract_provider:DataHiveRunsProvider",
            },
        )

        payload = run_runtime_diagnostics()

        assert payload["schema_version"] == "cf_doctor_runtime.v1"
        assert isinstance(payload["pipeline_manager"], dict)
        assert isinstance(payload["pipeline_runtime"], dict)
        assert isinstance(payload["engine_runner"], dict)
        assert isinstance(payload["datahive_runs"], dict)
        assert isinstance(payload["missing_providers"], list)

        assert payload["pipeline_manager"]["provider_key"] == "pipeline_manager"
        assert payload["pipeline_runtime"]["provider_key"] == "pipeline_runtime"
        assert payload["engine_runner"]["provider_key"] == "engine_runner"
        assert payload["datahive_runs"]["provider_key"] == "datahive_runs"

    def test_runtime_diagnostics_reports_missing_providers(self, monkeypatch, tmp_path: Path) -> None:
        """When runtime entry points are missing, they are classified as missing_entry_point."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {},
        )

        payload = run_runtime_diagnostics()

        assert payload["pipeline_manager"]["status"] == "missing_entry_point"
        assert payload["pipeline_runtime"]["status"] == "missing_entry_point"
        assert payload["engine_runner"]["status"] == "missing_entry_point"
        assert payload["datahive_runs"]["status"] == "missing_entry_point"
        assert set(payload["missing_providers"]) == {
            "pipeline_manager",
            "pipeline_runtime",
            "engine_runner",
            "datahive_runs",
        }

    def test_runtime_diagnostics_load_error_classified(self, monkeypatch, tmp_path: Path) -> None:
        """A runtime entry point that fails to load is classified as load_error."""
        monkeypatch.setattr(
            "cf_setup.doctor._iter_service_provider_entry_points",
            lambda: {
                "engine_runner": "nonexistent.module:MissingClass",
            },
        )

        payload = run_runtime_diagnostics()

        assert payload["engine_runner"]["status"] == "load_error"
        assert payload["engine_runner"]["error"] is not None
        assert "engine_runner" in payload["missing_providers"]
