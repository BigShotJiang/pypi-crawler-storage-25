# AITracer SDK

Python SDK for AITracer verification and trace retrieval primitives.

Designed for teams that need simple, programmatic access to AITracer records and verification checks.

## Install

```bash
pip install aitracer-sdk
```

Latest release: `0.1.1`

## Quickstart

```python
from aitracer_sdk import AITracerClient

client = AITracerClient(base_url="https://aitracer.app", bearer_token="<token>")

# Service availability check
print(client.verify_service())

# Retrieve a trace/interaction record
print(client.get_chat_raw("<interaction_id>"))
```

## Core capabilities

- Service verification (`verify_service`)
- Trace retrieval (`get_chat_raw`)
- Attestation verification (`verify_attestation`)

## Simple usage pattern

```python
result = client.verify_attestation(attestation_id="<attestation_id>")
print(result)
```

## Notes

- Keep bearer tokens secure and out of source control.
- This repository intentionally keeps implementation details minimal in public-facing documentation.

## Local package smoke test

Use the smoke script to verify build/install/import in a fresh environment:

```bash
./scripts/smoke-install-test.sh
```
