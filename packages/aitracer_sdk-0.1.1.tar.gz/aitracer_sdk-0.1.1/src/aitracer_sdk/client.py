from __future__ import annotations

from typing import Any, Dict, Optional

import requests


class AITracerSDKError(RuntimeError):
    """Raised when AITracer SDK request execution fails."""


class AITracerClient:
    def __init__(self, base_url: str, bearer_token: Optional[str] = None, timeout: int = 15) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})
        if bearer_token:
            self.session.headers.update({"Authorization": f"Bearer {bearer_token}"})

    def verify_service(self) -> Dict[str, Any]:
        checks = {
            "api": f"{self.base_url}/health",
        }
        results: Dict[str, Any] = {}
        for name, url in checks.items():
            try:
                resp = self.session.get(url, timeout=self.timeout)
                results[name] = {
                    "ok": resp.status_code == 200,
                    "status_code": resp.status_code,
                    "url": url,
                }
            except requests.RequestException as exc:
                results[name] = {
                    "ok": False,
                    "error": str(exc),
                    "url": url,
                }
        return results

    def get_chat_raw(self, interaction_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/api/ledger/{interaction_id}"
        try:
            resp = self.session.get(url, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            raise AITracerSDKError(f"Failed to fetch raw chat data from {url}: {exc}") from exc

    def verify_attestation(self, attestation_id: str, interaction_hash: Optional[str] = None) -> Dict[str, Any]:
        url = f"{self.base_url}/api/verification/verify"
        payload: Dict[str, Any] = {"attestation_id": attestation_id}
        if interaction_hash:
            payload["interaction_hash"] = interaction_hash
        try:
            resp = self.session.post(url, json=payload, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            raise AITracerSDKError(f"Failed to verify attestation using {url}: {exc}") from exc
