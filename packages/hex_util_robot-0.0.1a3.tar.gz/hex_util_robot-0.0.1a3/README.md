# hex_util_robot
`hex_util_robot` is a lightweight utility library for robotic systems, featuring mathematical utilities and reusable robotics components for algorithm development and system integration.
