#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2025 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2025-09-18
################################################################

import copy
import numpy as np
import hex_dynamic as dyn
from typing import Tuple, List

from hex_util_robot.math_utils import trans2part, part2trans
from hex_util_robot.math_utils import trans_inv, trans2se3
from hex_util_robot.math_utils import single_euler2rot, rot2euler
from hex_util_robot.math_utils import angle_norm, hat
from hex_util_robot.common_utils import deadzone


class HexDynUtil:

    TRANS_FLANGE_IN_LAST = part2trans(
        np.array([0.0, 0.0, 0.0]),
        np.array([0.7071068, 0.0, -0.7071068, 0.0]),
    )

    def __init__(
            self,
            model_path: str,
            last_link: str = "link_6",
            pose_end_in_flange: np.ndarray = np.array(
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]),
            gravity: np.ndarray = np.array([0, 0, -9.81]),
    ):
        ### dyn init
        self.__model = dyn.parse_urdf_file(model_path)
        self.__data = self.__model.createData()
        self.__joint_num = self.__model.njoints - 1
        self.__end_link_id = self.__model.getFrameId(last_link)
        self.__end_joint_id = self.__joint_num
        self._lower_limit = self.__model.lowerPositionLimit
        self._upper_limit = self.__model.upperPositionLimit

        ### gravity vector
        if isinstance(gravity, np.ndarray):
            self.__model.set_gravity(gravity)

        ### end in flange
        self.__pose_end_in_flange = None
        self.__jac_trans = None
        self._trans_end_in_last = None
        self._trans_last_in_end = None
        self.set_pose_end_in_flange(pose_end_in_flange)

    def get_gravity(self) -> np.ndarray:
        return self.__model.gravity

    def set_gravity(
            self,
            gravity: np.ndarray = np.array([0, 0, -9.81]),
    ):
        gravity = np.ascontiguousarray(np.array(gravity, dtype=np.float64))
        self.__model.set_gravity(gravity)

    def set_pose_end_in_flange(self, pose: np.ndarray):
        self.__pose_end_in_flange = pose.copy()
        trans_end_in_flange = part2trans(pose[:3], pose[3:])
        self._trans_end_in_last = self.TRANS_FLANGE_IN_LAST @ trans_end_in_flange
        self._trans_last_in_end = trans_inv(self._trans_end_in_last)
        self.__jac_trans = self.__cal_jac_trans(self._trans_end_in_last)

    def get_pose_end_in_flange(self) -> np.ndarray:
        return self.__pose_end_in_flange

    def get_joint_num(self) -> int:
        return self.__joint_num

    def get_limit(self) -> Tuple[np.ndarray, np.ndarray]:
        return copy.deepcopy(self._lower_limit), copy.deepcopy(
            self._upper_limit)

    def __cal_jac_trans(self, trans_end_in_last: np.ndarray) -> np.ndarray:
        rot = trans_end_in_last[:3, :3]
        pos = trans_end_in_last[:3, 3]

        jac_trans = np.eye(6)
        jac_trans[:3, :3] = rot.T
        jac_trans[3:, :3] = -rot.T @ hat(pos)
        jac_trans[3:, 3:] = rot.T
        return jac_trans

    # get [M(q), C(q, q_dot), G(q), J(q), J_dot(q, q_dot)]
    # v = J @ q_dot
    def dynamic_params(
        self,
        q: np.ndarray,
        dq: np.ndarray,
        base_frame: bool = False,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        q = np.ascontiguousarray(np.array(q, dtype=np.float64))
        dq = np.ascontiguousarray(np.array(dq, dtype=np.float64))

        # Compute all dynamic parameters
        dyn.computeAllTerms(self.__model, self.__data, q, dq)
        dyn.computeCoriolisMatrix(self.__model, self.__data, q, dq)
        m_mat = self.__data.M
        c_mat = self.__data.C
        g_vec = self.__data.g
        jac = dyn.getFrameJacobian(
            self.__model,
            self.__data,
            self.__end_link_id,
            dyn.ReferenceFrame.LOCAL,
        )
        jac_dot = dyn.getFrameJacobianTimeVariation(
            self.__model,
            self.__data,
            self.__end_link_id,
            dyn.ReferenceFrame.LOCAL,
        )

        jac = self.__jac_trans @ jac
        jac_dot = self.__jac_trans @ jac_dot
        if base_frame:
            trans_last_in_base = self.__data.oMi[self.__joint_num].homogeneous
            trans_end_in_base = trans_last_in_base @ self._trans_end_in_last
            rot_end_in_base = trans_end_in_base[:3, :3]

            jac_trans = np.eye(6)
            jac_trans[:3, :3] = rot_end_in_base
            jac_trans[3:, 3:] = rot_end_in_base
            jac = jac_trans @ jac
            jac_dot = jac_trans @ jac_dot

        return m_mat, c_mat, g_vec, jac, jac_dot

    # compensation = C(q, dq) @ dq + G(q)
    def compensation(self, q: np.ndarray, dq: np.ndarray) -> np.ndarray:
        q = np.ascontiguousarray(np.array(q, dtype=np.float64))
        dq = np.ascontiguousarray(np.array(dq, dtype=np.float64))

        # Compute all dynamic parameters
        dyn.computeAllTerms(self.__model, self.__data, q, dq)
        dyn.computeCoriolisMatrix(self.__model, self.__data, q, dq)
        c_mat = self.__data.C
        g_vec = self.__data.g

        return c_mat @ dq + g_vec

    # get [pose_1, pose_2, ..., pose_n]
    def forward_kinematics(
        self,
        q: np.ndarray,
    ) -> List[Tuple[np.ndarray, np.ndarray]]:
        q = np.ascontiguousarray(np.array(q, dtype=np.float64))

        # Compute forward kinematics to update joint placements
        dyn.forwardKinematics(self.__model, self.__data, q)

        # Collect the poses of all joints
        poses = []
        trans = None
        for i in range(self.__joint_num):
            trans = self.__data.oMi[i + 1].homogeneous
            pos, quat = trans2part(trans)
            poses.append((pos, quat))
        trans_end_in_base = trans @ self._trans_end_in_last
        pos, quat = trans2part(trans_end_in_base)
        poses.append((pos, quat))
        return poses

    def inverse_kinematics(
        self,
        tar_pose: Tuple[np.ndarray, np.ndarray],
        start_q: np.ndarray,
        dt: float = 1e-1,
        exit_eps: float = 1e-3,
        feasible_eps: float = 1e-2,
        damp: float = 1e-12,
        max_iter: int = 300,
    ) -> Tuple[bool, np.ndarray, float]:
        result_q = np.ascontiguousarray(np.array(start_q, dtype=np.float64))
        trans_end_tar_in_base = copy.deepcopy(
            part2trans(
                tar_pose[0],
                tar_pose[1],
            ))
        trans_tar_in_base = trans_end_tar_in_base @ self._trans_last_in_end
        trans_base_in_tar = trans_inv(trans_tar_in_base)

        # inverse kinematics
        result_flag = False
        for _ in range(max_iter):
            dyn.computeJointJacobians(
                self.__model,
                self.__data,
                result_q,
            )
            trans_end_in_base = self.__data.oMi[
                self.__end_joint_id].homogeneous
            trans_tar_in_end = trans_inv(trans_end_in_base) @ trans_tar_in_base
            err = trans2se3(trans_tar_in_end)

            err_norm = np.linalg.norm(err)
            if err_norm < exit_eps:
                result_flag = True
                break

            # jac in end link
            jac = dyn.getFrameJacobian(
                self.__model,
                self.__data,
                self.__end_link_id,
                dyn.ReferenceFrame.LOCAL,
            )
            dq = np.linalg.pinv(jac, rcond=damp) @ err

            result_q += dq * dt
            result_q = np.clip(
                angle_norm(result_q),
                self._lower_limit,
                self._upper_limit,
            )

        # post process
        result_q = np.clip(
            angle_norm(result_q),
            self._lower_limit,
            self._upper_limit,
        )

        # check feasible
        dyn.forwardKinematics(self.__model, self.__data, result_q)
        trans_end_in_base = self.__data.oMi[self.__end_joint_id].homogeneous
        trans_tar_in_end = trans_base_in_tar @ trans_end_in_base
        err = trans2se3(trans_tar_in_end)
        err_norm = np.linalg.norm(err)
        if err_norm < feasible_eps:
            result_flag = True

        return result_flag, result_q, err_norm


class HexDynUtilY6(HexDynUtil):

    def __init__(
            self,
            model_path: str,
            last_link: str = "link_6",
            pose_end_in_flange: np.ndarray = np.array(
                [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]),
            gravity: np.ndarray = np.array([0, 0, -9.81]),
    ):
        super().__init__(
            model_path=model_path,
            last_link=last_link,
            pose_end_in_flange=pose_end_in_flange,
            gravity=gravity,
        )
        self.__analytic_dict = self.__cal_analytic_dict()

    def __cal_analytic_dict(self):
        fk_list = self.forward_kinematics(np.zeros(6))

        # trans values
        trans_ik0_in_base = np.eye(4)
        trans_ik0_in_base[2, 3] = fk_list[1][0][2]
        pos_last_in_ik456 = np.array(
            [fk_list[5][0][2] - fk_list[4][0][2], 0.0, 0.0])
        trans_ik6_in_last = trans_inv(
            part2trans(pos_last_in_ik456,
                       np.array([0.7071068, 0.0, 0.7071068, 0.0])))
        trans_ik6_in_end = self._trans_last_in_end @ trans_ik6_in_last

        # length values
        l_ik3_to_ik456 = fk_list[4][0][2] - fk_list[3][0][2]
        l1 = fk_list[1][0][0] - fk_list[0][0][0]
        l2 = fk_list[2][0][2] - fk_list[1][0][2]
        l3_x = fk_list[3][0][0] - fk_list[2][0][0]
        l3_y = fk_list[3][0][2] - fk_list[2][0][2]
        l3 = np.sqrt(l3_x**2 + l3_y**2)

        # other values
        q2_offset = np.arctan2(l3_x, l3_y)
        min_norm = np.fabs(l2 - l3)
        max_norm = l2 + l3
        joint_rot_list = [
            # (inv, bias, axis)
            (1.0, 0.0, "z"),
            (1.0, -0.5 * np.pi, "y"),
            (1.0, 0.0, "y"),
            (1.0, 0.0, "y"),
            (1.0, 0.0, "z"),
            (1.0, 0.0, "x"),
        ]

        return {
            "trans_ik0_in_base": trans_ik0_in_base,
            "trans_ik6_in_end": trans_ik6_in_end,
            "l_ik3_to_ik456": l_ik3_to_ik456,
            "l1": l1,
            "l2": l2,
            "l3": l3,
            "q2_offset": q2_offset,
            "min_norm": min_norm,
            "max_norm": max_norm,
            "joint_rot_list": joint_rot_list,
        }

    def __triangle_theta(self, a, b, c):
        return np.arccos(
            np.clip((a**2 + b**2 - c**2) / (2.0 * a * b), -1.0, 1.0))

    def __single_joint_rot(self, q: float, idx: int):
        inv, bias, axis = self.__analytic_dict["joint_rot_list"][idx]
        return single_euler2rot(q * inv + bias, axis)

    def inverse_kinematics_analytic(
        self,
        tar_pose: tuple[np.ndarray, np.ndarray],
        start_q: np.ndarray,
        eps: float = 1e-3,
    ) -> tuple[bool, np.ndarray]:
        ik_success = True
        result_q = copy.deepcopy(start_q)
        trans_end_tar_in_base = copy.deepcopy(
            part2trans(
                tar_pose[0],
                tar_pose[1],
            ))
        trans_ik6_in_ik0 = trans_inv(
            self.__analytic_dict["trans_ik0_in_base"]
        ) @ trans_end_tar_in_base @ self.__analytic_dict["trans_ik6_in_end"]
        pos_ik456_in_ik0 = trans_ik6_in_ik0[:3, 3]
        rot_ik6_in_ik0 = trans_ik6_in_ik0[:3, :3]

        # q0
        xy_norm = np.linalg.norm(pos_ik456_in_ik0[:2])
        if xy_norm > eps:
            # print(f"xy_norm: {xy_norm}")
            result_q[0] = np.arctan2(pos_ik456_in_ik0[1], pos_ik456_in_ik0[0])
            delta_q0 = result_q[0] - start_q[0]
            if delta_q0 < -1.57:
                result_q[0] += np.pi
            elif delta_q0 > 1.57:
                result_q[0] -= np.pi
        rot_ik1_in_ik0 = self.__single_joint_rot(result_q[0], 0)

        # pos_ik3_in_ik1
        normal_workplane = np.array([
            -np.sin(result_q[0]),
            np.cos(result_q[0]),
            0.0,
        ])
        axis_to_proj = rot_ik6_in_ik0 @ np.array([1.0, 0.0, 0.0])
        axis_perp = np.dot(axis_to_proj, normal_workplane) * normal_workplane
        axis_in_plane = rot_ik1_in_ik0.T @ (axis_to_proj - axis_perp)
        norm_axis_in_plane = np.linalg.norm(axis_in_plane)
        axis_in_plane = axis_in_plane / norm_axis_in_plane
        pos_ik3_in_ik1 = rot_ik1_in_ik0.T @ pos_ik456_in_ik0 - axis_in_plane * self.__analytic_dict[
            "l_ik3_to_ik456"] - np.array(
                [self.__analytic_dict["l1"], 0.0, 0.0])
        norm_pos_ik3_in_ik1 = np.linalg.norm(pos_ik3_in_ik1) + 1e-6
        if norm_pos_ik3_in_ik1 < self.__analytic_dict["min_norm"]:
            pos_ik3_in_ik1 = pos_ik3_in_ik1 / norm_pos_ik3_in_ik1 * self.__analytic_dict[
                "min_norm"]
            norm_pos_ik3_in_ik1 = self.__analytic_dict["min_norm"]
            ik_success = False
        elif norm_pos_ik3_in_ik1 > self.__analytic_dict["max_norm"]:
            pos_ik3_in_ik1 = pos_ik3_in_ik1 / norm_pos_ik3_in_ik1 * self.__analytic_dict[
                "max_norm"]
            norm_pos_ik3_in_ik1 = self.__analytic_dict["max_norm"]
            ik_success = False

        # q1 and q2
        theta2 = self.__triangle_theta(
            self.__analytic_dict["l2"],
            self.__analytic_dict["l3"],
            norm_pos_ik3_in_ik1,
        )
        result_q[2] = np.pi - (theta2 + self.__analytic_dict["q2_offset"])
        if result_q[2] < 0.0:
            result_q[2] += 2.0 * np.pi
        theta_triangle = self.__triangle_theta(
            norm_pos_ik3_in_ik1,
            self.__analytic_dict["l2"],
            self.__analytic_dict["l3"],
        )
        theta_ik4 = np.arctan2(pos_ik3_in_ik1[2], pos_ik3_in_ik1[0])
        theta1 = theta_ik4 + theta_triangle
        result_q[1] = 0.5 * np.pi - theta1

        # rot_ik6_in_ik3
        rot_ik3_in_ik0 = rot_ik1_in_ik0 @ self.__single_joint_rot(
            result_q[1], 1) @ self.__single_joint_rot(result_q[2], 2)
        rot_ik6_in_ik3 = rot_ik3_in_ik0.T @ trans_ik6_in_ik0[:3, :3]

        # q3, q4, q5
        result_q[3:] = rot2euler(rot_ik6_in_ik3,
                                 format="yzx",
                                 last_euler=result_q[3:].copy())

        # check limit
        result_q = angle_norm(result_q)
        lower_mask = result_q < self._lower_limit
        upper_mask = result_q > self._upper_limit
        if np.any(lower_mask) or np.any(upper_mask):
            ik_success = False
            result_q[lower_mask] = self._lower_limit[lower_mask]
            result_q[upper_mask] = self._upper_limit[upper_mask]

        return ik_success, result_q


class HexMirrorUtil:

    def __init__(self, inv: np.ndarray):
        self.__inv = inv.copy()
        self.__inv_extended = self.__inv[:, np.newaxis]

    def __call__(self, state: np.ndarray) -> np.ndarray:
        if len(state.shape) == 1:
            return self.__inv * state
        else:
            return self.__inv_extended * state


class HexFricUtil:
    # tanh-based friction model
    # tau_f = fc * tanh(k * dq) + fv * dq + fo
    def __init__(
            self,
            fc: np.ndarray = np.array([1.0] * 6),
            fv: np.ndarray = np.array([1.0] * 6),
            fo: np.ndarray = np.array([0.0] * 6),
            k: np.ndarray = np.array([100.0] * 6),
    ):
        # constants
        self.__fc = fc.copy()
        self.__fv = fv.copy()
        self.__fo = fo.copy()
        self.__k = k.copy()

    def __call__(self, dq: np.ndarray):
        tau_c = self.__fc * np.tanh(self.__k * dq)
        tau_v = self.__fv * dq
        tau_o = self.__fo
        tau_f = tau_c + tau_v + tau_o
        return tau_f


class HexFeedbackUtil:

    def __init__(
            self,
            kp: np.ndarray = np.array([0.0] * 6),
            kd: np.ndarray = np.array([0.0] * 6),
            deadzone: np.ndarray = np.array([0.0] * 6),
    ):
        self.__kp = kp.copy()
        self.__kd = kd.copy()
        self.__deadzone = deadzone.copy()

    def __call__(
        self,
        leader_state: np.ndarray,
        follower_q: np.ndarray,
        tar_dq: np.ndarray,
    ) -> np.ndarray:
        q_err = follower_q - leader_state[:, 0]
        dq_err = tar_dq - leader_state[:, 1]
        tau_fb = self.__kp * q_err + self.__kd * dq_err
        return deadzone(tau_fb, self.__deadzone)
