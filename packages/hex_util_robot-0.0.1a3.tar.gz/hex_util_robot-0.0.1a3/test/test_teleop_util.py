#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-02-22
################################################################

import numpy as np
from hex_util_runtime import HexRate
from hex_util_robot import HexTeleopUtilKeyboard
from hex_util_robot import HexTeleopUtilHello


def keyboard_main():
    keyboard_util = HexTeleopUtilKeyboard()
    keyboard_util.start()

    rate = HexRate(2000.0)
    try:
        while keyboard_util.is_working():
            rate.sleep()
            value = keyboard_util.pop_value()
            if value is not None:
                print(f"Got value: {value}")
                if value["key"] == 'q':
                    break
    finally:
        keyboard_util.close()


def hello_main():
    hello_util = HexTeleopUtilHello()
    hello_util.start()
    rate = HexRate(2000.0)
    cnt = 0
    try:
        while hello_util.is_working():
            rate.sleep()

            cnt += 1
            if cnt >= 1000:
                cnt = 0
                hello_util.append_msg(np.array([1.0, -1.0, -1.0, 1.0]))
            value = hello_util.pop_value()
            if value is not None:
                print(f"Got value: {value}")
                if value["button_W"] == True:
                    break
    finally:
        hello_util.close()


try:
    from hex_util_robot import HexTeleopUtilJoystick

    def joystick_main():
        joystick_util = HexTeleopUtilJoystick()
        joystick_util.start()
        rate = HexRate(2000.0)
        try:
            while joystick_util.is_working():
                rate.sleep()
                value = joystick_util.pop_value()
                if value is not None:
                    print(f"Got value: {value}")
                    if value["button_B"] == True:
                        break
        finally:
            joystick_util.close()
except ImportError:
    pass

if __name__ == '__main__':
    # keyboard_main()
    hello_main()
    # if _HAS_JOYSTICK:
    #     joystick_main()
