"""Synapt: persistent conversational memory for AI coding assistants."""

__version__ = "0.12.1"
