from pathlib import Path
import flet as ft

class OrrinCLI:
    def __init__(self):
        self.root = Path.cwd()
        self.python_files = list(self.root.rglob("*.py"))
        self.connected_file = None
        self.editor_panel = ft.Container(expand=True)

    # ---------------- UI: file list ----------------
    def file_item(self, page: ft.Page, file):
        return ft.Container(
            padding=10,
            border_radius=12,
            bgcolor="#242424",
            border=ft.border.all(1, "#333333"),
            ink=True,
            on_click=lambda e: self.connect_file(page, file),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.START,
                controls=[
                    # File Icon Box
                    ft.Container(
                        width=40, 
                        height=40,
                        bgcolor="#1f1f1f",
                        border=ft.border.all(1, "#333333"),
                        border_radius=10,
                        alignment=ft.alignment.center,
                        content=ft.Icon(ft.icons.CODE, color="#9e9d9d", size=16)
                    ),
                    # File Info
                    ft.Column(
                        expand=True,
                        spacing=4,
                        controls=[
                            ft.Text(
                                file.name,
                                color="white",
                                size=12,
                                weight=ft.FontWeight.W_300,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS
                            ),
                            ft.Text(
                                "Python Script", 
                                color="#9e9d9d", 
                                size=8
                            )
                        ]
                    ),
                    # Chevron to indicate action
                    ft.Icon(ft.icons.CHEVRON_RIGHT, color="#6B7280", size=20)
                ]
            )
        )

    # ---------------- UI: left panel ----------------
    def build_file_panel(self, page: ft.Page):
        return ft.Container(
            width=360,
            bgcolor="#191919",
            border=ft.border.only(right=ft.border.BorderSide(1, "#2a2a2a")),
            padding=ft.padding.only(left=24, top=32, right=16, bottom=24),
            content=ft.Column(
                controls=[
                    # Panel Header mapped to HTML style
                    ft.Text(
                        "Explore Scripts",
                        color="#dddddd",
                        size=20,
                        weight=ft.FontWeight.W_500
                    ),
                    ft.Text(
                        "Find Python files in your directory.",
                        color="#9e9d9d",
                        size=14
                    ),
                    ft.Container(height=24), # Spacer
                    
                    # File List
                    ft.ListView(
                        expand=True,
                        spacing=12,
                        controls=[
                            self.file_item(page, f)
                            for f in self.python_files
                        ],
                    ),
                ]
            )
        )

    # ---------------- UI: right panel ----------------
    def build_editor_panel(self):
        # Empty State (mirrors "Tools Coming Soon" style)
        if not self.connected_file:
            return ft.Container(
                expand=True,
                bgcolor="#191919",
                alignment=ft.alignment.center,
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Container(
                            padding=ft.padding.symmetric(horizontal=0, vertical=12),
                            content=ft.Column(
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                alignment=ft.MainAxisAlignment.CENTER,
                                controls=[
                                    ft.Container(
                                        width=80, 
                                        height=80,
                                        bgcolor="#242424",
                                        border=ft.border.all(1, "#333333"),
                                        border_radius=20,
                                        alignment=ft.alignment.center,
                                        shadow=ft.BoxShadow(spread_radius=1, blur_radius=15, color=ft.colors.with_opacity(0.1, "black")),
                                        content=ft.Icon(ft.icons.FILE_OPEN_OUTLINED, color="#9e9d9d", size=32)
                                    ),
                                    ft.Container(height=16),
                                    ft.Text(
                                        "No file selected",
                                        color="white",
                                        size=20,
                                        weight=ft.FontWeight.W_500
                                    ),
                                    ft.Text(
                                        "Select a script from the explorer to view details.",
                                        color="#9e9d9d",
                                        size=15,
                                        text_align=ft.TextAlign.CENTER
                                    )
                                ]
                            )
                        )
                    ]
                )
            )

        # ---------------- UPDATED EDITOR PANEL ----------------
        return ft.Container(
            expand=True,
            bgcolor="#191919",
            padding=ft.padding.all(32), # Slightly reduced padding for less bulk
            content=ft.Column(
                expand=True, # Allows the chat input to be pushed to the bottom
                controls=[
                    
                    # --- Sleek Header & Metadata ---
                    ft.Column(
                        spacing=16,
                        controls=[
                            # Title
                            ft.Column(
                                spacing=4,
                                controls=[
                                    ft.Container(
                                        padding=ft.padding.symmetric(horizontal=10, vertical=10),
                                        content=ft.Column(
                                            controls=[
                                                ft.Text("File Details", color="#dddddd", size=20, weight=ft.FontWeight.W_500),
                                                ft.Text("Information about the connected script.", color="#9e9d9d", size=12)
                                            ]
                                        )
                                    )
                                ]
                            ),
                            
                            # Compact Metadata Row
                            ft.Container(
                                padding=ft.padding.symmetric(horizontal=10, vertical=0),
                                content=ft.Container(
                                padding=ft.padding.symmetric(horizontal=12, vertical=8),
                                bgcolor="#242424",
                                border=ft.border.all(1, "#333333"),
                                border_radius=8,
                                content=ft.Row(
                                    spacing=12,
                                    controls=[
                                        ft.Icon(ft.icons.INSERT_DRIVE_FILE, color="#9e9d9d", size=20),
                                        ft.Column(
                                            controls=[
                                                ft.Container(
                                                    padding=ft.padding.symmetric(horizontal=8, vertical=0),
                                                    bgcolor="#1a1a1a",
                                                    border=ft.border.all(1, "#333333"),
                                                    border_radius=12,
                                                    content=ft.Text("CONNECTED", size=10, color="#10b981", weight=ft.FontWeight.BOLD) # Emerald green
                                                ),
                                                ft.Text(self.connected_file.name, color="white", weight=ft.FontWeight.W_300, size=12),
                                            ]
                                        ),
                                        
                                        ft.Text("•", color="#4b5563", size=15), # Bullet separator
                                        
                                        # Path (Truncated automatically if it gets too long)
                                        ft.Text(
                                            str(self.connected_file), 
                                            color="#6B7280", 
                                            size=13, 
                                            selectable=True, 
                                            overflow=ft.TextOverflow.ELLIPSIS, 
                                            expand=True
                                        ),
                                    ]
                                ))
                            )
                        ]
                    ),
                    
                    # --- Main Editor / Empty Space Spacer ---
                    # Expanding this container forces the chat input below it to stick to the bottom
                    ft.Container(expand=True),
                    
                    # --- Chat Input Field ---
                    ft.Container(
                        padding=ft.Padding(left=8, right=8, top=0, bottom=14),
                        content=ft.Container(
                        padding=ft.padding.symmetric(horizontal=12, vertical=0),
                        bgcolor="#242424",
                        border=ft.border.all(1, "#333333"),
                        border_radius=24,
                        content=ft.Row(
                            controls=[
                                ft.Icon(ft.icons.AUTO_AWESOME, color="#6B7280", size=14), # AI spark icon
                                ft.TextField(
                                    expand=True,
                                    hint_text="Chat with OrrinCLI...",
                                    hint_style=ft.TextStyle(color="#6B7280", size=12),
                                    border=ft.InputBorder.NONE,
                                    color="white",
                                    cursor_color="#dddddd",
                                    content_padding=ft.padding.symmetric(vertical=12, horizontal=4),
                                ),
                                # Modern Send Button (Similar to state-of-the-art AI interfaces)
                                ft.IconButton(
                                    icon=ft.icons.ARROW_UPWARD_ROUNDED,
                                    icon_color="black",
                                    bgcolor="white",
                                    icon_size=12,
                                    width=24,
                                    height=24,
                                    style=ft.ButtonStyle(
                                        padding=0,
                                        shape=ft.CircleBorder()
                                    ),
                                    tooltip="Send Message"
                                )
                            ]
                        )
                    )
                    )
                ]
            )
        )

    # ---------------- state change ----------------
    def connect_file(self, page: ft.Page, file):
        self.connected_file = file
        self.editor_panel.content = self.build_editor_panel().content
        page.update()

    # ---------------- main layout ----------------
    def main(self, page: ft.Page):
        page.title = "OrrinCLI"
        page.bgcolor = "#191919"  # Matched to HTML body bg
        page.padding = 0

        # Create Top Navigation Appbar (matching the HTML fixed nav)
        top_nav = ft.Container(
            bgcolor="#191919",
            padding=ft.padding.symmetric(horizontal=24, vertical=16),
            border=ft.border.only(bottom=ft.border.BorderSide(1, "#2a2a2a")),
            content=ft.Row([
                # Mock Logo
                ft.Container(
                    bgcolor="white", border_radius=6, width=24, height=24,
                    alignment=ft.alignment.center,
                    content=ft.Text("O", color="black", weight=ft.FontWeight.BOLD, size=14)
                ),
                ft.Text("Orrin", color="white", size=16, weight=ft.FontWeight.W_500),
                ft.Text("CLI", color="#9e9d9d", size=16, weight=ft.FontWeight.W_400),
            ], spacing=8)
        )

        self.editor_panel = self.build_editor_panel()

        # Layout Splitter
        layout = ft.Row([
            self.build_file_panel(page),
            self.editor_panel
        ], expand=True, spacing=0)

        # Main Page Stacking
        page.add(
            ft.Column([
                top_nav,
                layout
            ], expand=True, spacing=0)
        )

    def start(self):
        ft.app(target=self.main)