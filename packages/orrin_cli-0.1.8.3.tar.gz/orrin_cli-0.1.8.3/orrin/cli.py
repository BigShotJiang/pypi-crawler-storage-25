from click import Choice
import typer
import requests
import json
import os
from pathlib import Path
from platformdirs import user_config_dir
import yaml, tomli, toml
from pathlib import Path

app = typer.Typer(help="""
Welcome to Orrin CLI v0.1.8!\n\n
                  
Orrin CLI enables you to perform actions within your terminal that would otherwise require
an entire dashboard. Though there is a dashboard, Orrin CLI enables a feasible development
experience for all developers, as they can swiftly run a command to upload their frontend,
perform checks on their app review status, and more!
""", no_args_is_help=True)

config = typer.Typer(help="Configure your Orrin Apps developer API with Orrin CLI")
app.add_typer(config, name='config')

ui = typer.Typer(help="UI related commands")
app.add_typer(ui, name="ui")

projects = typer.Typer(help='OrrinSDK project commands')
app.add_typer(projects, name='projects')

API_BASE = "https://stellr-company.com"

APP_NAME = "orrin"
APP_AUTHOR = "orrin"  # optional but recommended on Windows

config_dir = Path(user_config_dir(APP_NAME, APP_AUTHOR))
config_dir.mkdir(parents=True, exist_ok=True)

config_file = config_dir / "config.json"

# ---- Configuration based commands/helper functions ----

def save_config_data(api_key: str, email: str):
    data = {"api_key": api_key, 'email': email}
    with open(config_file, "w") as f:
        json.dump(data, f)

def load_config():
    if not config_file.exists():
        return None
    with open(config_file) as f:
        return json.load(f)#json.load(f).get("api_key")

@config.command(help="""
Add your Developer API key and email to the Orrin CLI to perform tasks explicitly relating to your developer account.
Your email will be added to your developer account details, and correspondence regarding your submission
will take place via the dashboard and email, if the email is valid.
""")
def configure_dev():
    dev_email = typer.prompt(
        'Enter your email',
        hide_input=False,
        confirmation_prompt=True
    )

    dev_api = typer.prompt(
        "Enter your Developer API key",
        hide_input=True,
        confirmation_prompt=True,
    )
    
    resp = requests.post(
        f'{API_BASE}/api/orrin_apps/developer_api_exists',
        json={'developer_api_key': dev_api}
    )
    
    if not resp.ok:
        typer.echo(f'❌ No developer account was found with API key:\n\n{dev_api}')
        raise typer.Exit(1)
    
    # Add email to developer account
    resp = requests.post(
        f'{API_BASE}/api/orrin_apps/add_email_to_developer_account',
        json={'email': dev_email, 'developer_id': dev_api}
    )

    if not resp.ok:
        typer.echo(f'❌ Something went wrong adding email to developer account. Try again.\n\nIf the problem persists, contact us:\n\thttps://stellr-company.com/contact')
        raise typer.Exit(1)
    
    save_config_data(api_key=dev_api, email=dev_email)
    typer.echo("✅ Developer API and email configured with Orrin CLI")

@config.command(help='Revokes the Developer API currently configured with Orrin CLI')
def revoke_config():
    if not config_file.exists():
        typer.echo("ℹ️ No configuration found to revoke.")
        raise typer.Exit(code=0)

    try:
        config_file.unlink()
        typer.echo("✅ Credentials revoked. Local config removed.")
    except Exception as e:
        typer.echo(f"❌ Failed to revoke credentials: {e}")
        raise typer.Exit(code=1)

@config.command(help='Show configured Developer API key')
def show_configuration():
    if not config_file.exists():
        typer.echo("ℹ️ No Developer API key configured with Orrin CLI")
        raise typer.Exit(code=0)
    
    config = load_config()

    typer.echo(f'\n\tConfigured Developer API key:\n\t\t{config["api_key"]}\n\n\tConfigured Developer Email:\n\t\t{config["email"]}\n')

# -------------------------------------------------------

# ---- UI based commands/helper functions ----

@ui.command(help='''Build static output for next.js code, and generate a zip file to be uploaded.\n\nEnsure you have the following in next.config.tsx:\n\n
------------------------------------------------------\n\n
/** @type {import('next').NextConfig} */\n\n
const nextConfig = {\n\n
  output: 'export',\n\n
  trailingSlash: true,\n\n
  basePath: '/<your_app_name>/current',\n\n
  reactStrictMode: true,\n\n
};\n\n
\n\n
module.exports = nextConfig;
------------------------------------------------------\n\n
\n\n
Where <your_app_name> is the name of your app, which was configured in your backend.
''')
def generate_zip():
    os.system('npm install && npm run build')
    os.system('cd out && zip -r ../ui-build.zip .')

@ui.command(help="Upload your frontend code to be reviewed")
def upload(
    #zip_path: Path = typer.Argument(..., exists=True),
    app_name: str = typer.Option(..., "--app")
):
    """
    Upload a UI zip to Orrin.
    """
    if not os.path.isfile(os.path.join(os.getcwd(), 'ui-build.zip')):
        typer.echo(f"❌ Path {os.path.join(os.getcwd(), 'ui-build.zip')} does not exist.\n\nEnsure you run `orrin ui generate-zip`, or build the zip yourself.")
        raise typer.Exit(1)
    
    dev_api = load_config()['api_key']

    if dev_api is None:
        typer.echo("❌ You have not configured an API key. Please register with `orrin configure configure-dev-api`.")
        raise typer.Exit(1)
    
    with open(os.path.join(os.getcwd(), 'ui-build.zip'), "rb") as f:
        response = requests.post(
            f"{API_BASE}/ui/upload",
            files={"file": f},
            data={
                "developer_id": dev_api,
                "app_name": app_name
            }
        )

    if response.status_code != 200:
        try:
            data = response.json()
            typer.echo(f'❌ Upload failed: {response.status_code}\n\nMessage: {data["Message"]}')
        except:
            typer.echo("❌ Upload failed")
        raise typer.Exit(1)

    data = response.json()
    typer.echo("✅ Uploaded")
    typer.echo(f"Upload ID: {data.get('upload_id')}")

# --------------------------------------------

# ---- For SDK based projects ----

@projects.command(help='Create a project for an app backend with OrrinAppsSDK')
def init_app_backend_project():
    project_name = typer.prompt(
        "Project Name",
        hide_input=False,
        confirmation_prompt=True,
    )

    project_desc = typer.prompt(
        'Project Description',
        hide_input=False
    )

    project_toml = {
        'general': {
            'project_type': 'app',
            'name': project_name,
            'desc': project_desc
        },
    }

    path = os.path.join(os.getcwd(), project_name)
    os.mkdir(path)

    config = load_config()

    source_code = f'''
from orrinsdk import OrrinAppsSDK

orrin_sdk = OrrinAppsSDK(
    developer_api='{config["api_key"]}'
)

@orrin_sdk.action(
    'ExampleBackendAction',
    required_payload=[{{'name': 'a', 'type': 'any'}}]
)
def ExampleBackendAction(a):
    # Do something here
    return {{ 'status': 200, ... }}

orrin_sdk.finalize()
'''
    
    with open(os.path.join(path, 'project.toml'), 'w') as file:
        file.write(toml.dumps(project_toml))

    with open(os.path.join(path, 'main.py'), 'w') as file:
        file.write(source_code)

@projects.command(help='init-app-backend-project')
def iabp():
    init_app_backend_project()

@projects.command(help='Create a project for creating a tool with OrrinToolsSDK')
def init_tool_project():
    project_name = typer.prompt(
        "Project Name",
        hide_input=False,
        confirmation_prompt=True,
    )

    typer.echo(f'\n\t[orrin-cli] Version for {project_name} will default to 1.0.0\n')

    project_desc = typer.prompt(
        'Project Description',
        hide_input=False
    )

    has_plugins = typer.confirm(
        'Support Plugins?'
    )

    project_toml = {
            'general': {
                'project_type': 'tool',
                'name': project_name,
                'desc': project_desc,
                'nuances': {}
            },
            'icons': {
                '24x24': '<path>',
                '32x32': '<path>',
                '48x48': '<path>',
                '64x64': '<path>'
            },
            'plugins': {
                'supported': False
            },
            'metadata': {},
            'public': {
                'display_name': '',
                'display_desc': '',
                'usage_rundown': '',
                'whats_new': '',
                'authors': [],
                'open_source': False,
                'copyright': ''
            }
        }
    
    # Create project
    path = os.path.join(os.getcwd(), project_name)
    os.mkdir(path)

    config = load_config()

    plugin_entries = []

    if has_plugins:
        project_toml['plugins']['supported'] = True
        project_toml['plugins']['config'] = 'plugins.yaml'
        
        number_of_plugins = int(typer.prompt(
            'How Many Plugins?',
            hide_input=False
        ))

        plugins = []

        for i in range(number_of_plugins):
            plugin_for = typer.prompt(
                f'Plugin {i} For',
                hide_input=False
            )

            plugin_type = typer.prompt(
                f'Plugin {i} Type',
                hide_input=False,
                type=Choice(["internal", "external"], case_sensitive=False)
            )

            plugin_name = typer.prompt(
                f'Plugin {i} Name',
                hide_input=False
            )

            plugin_display_name = typer.prompt(
                f'Plugin {i} Display Name',
                hide_input=False
            )

            plugins.append({
                'for': plugin_for,
                'type': plugin_type,
                'name': plugin_name,
                'display_name': plugin_display_name,
                'actions': [
                    {
                        'action': '',
                        'helper': '',
                        'type': ''
                    }
                ]
            })

            if plugin_for == 'blink':
                plugin_entries.append('''
@orrin_sdk.plugin_entry(
    plugin='blink'
)
def blink_plugin_entry(cc: any, all_context: any):
    if not isinstance(cc, dict):
        return {'status': 400, 'message': 'invalid_type'}
        
    if not isinstance(all_context, str):
        return {'status': 400, 'message': 'invalid_type'}

    # Handoff to Exegesis or process contextual data yourself
    pass
''')
            else:
                plugin_entries.append(f'''
@orrin_sdk.plugin_entry(
    plugin='{plugin_for}'
)
def custom_plugin_entry(cc: any, all_context: any):
    if not isinstance(cc, dict):
        return {{'status': 400, 'message': 'invalid_type'}}
        
    if not isinstance(all_context, str):
        return {{'status': 400, 'message': 'invalid_type'}}

    # Handoff to Exegesis or process contextual data yourself
    pass
''')
        
        with open(os.path.join(path, 'plugins.yaml'), 'w') as file:
            yaml.safe_dump({'plugins': plugins}, file)
            file.close()
    
    plugin_entries.append('') # filler to trigger another newline

    source_code = f'''
from orrinsdk import OrrinToolsSDK

orrin_sdk = OrrinToolsSDK(
    developer_api_key='{config["api_key"]}'
)''' + "\n".join(plugin_entries) + '''
@orrin_sdk.action(
    name='ExampleAction',
    payload_schema='',
    desc=''
)
def ExampleAction(data: any):
    if not isinstance(data, dict):
        return { 'status': 400, 'message': 'invalid_data' }
    
    # Process data. Perform some sort of action
        
    return { 'status': 200 }

orrin_sdk.finalize()
'''
    
    with open(os.path.join(path, 'project.toml'), 'w') as file:
        file.write(toml.dumps(project_toml))

    with open(os.path.join(path, 'main.py'), 'w') as file:
        file.write(source_code)

"""@projects.command(help='Get help writing code for a project that uses OrrinSDK')
def connect_to_project():
    root = Path.cwd()

    # 1. Find all Python files
    python_files = list(root.rglob("*.py"))

    # 2. Handle empty case
    if not python_files:
        typer.echo("❌ No Python files exist in this project.")
        raise typer.Exit()

    # 3. Display files
    typer.echo("\n📂 Python files found:\n")
    for idx, file in enumerate(python_files, start=1):
        typer.echo(f"{idx}. {file.relative_to(root)}")

    # 4. Prompt selection
    while True:
        choice = typer.prompt("\nSelect a file by number")

        if not choice.isdigit():
            typer.echo("❌ Please enter a valid number.")
            continue

        choice = int(choice)

        if 1 <= choice <= len(python_files):
            selected_file = python_files[choice - 1]
            break

        typer.echo("❌ Number out of range.")

    # 5. "Connect" result
    typer.echo(f"\n✅ Connected to: {selected_file}")

    content = selected_file.read_text()

    # Launch TUI
    c = OrrinCLI(file_path=str(selected_file), file_content=content)
    c.run()"""

@projects.command(help='init-tool-project')
def itp():
    init_tool_project()

"""@projects.command(help='Get help creating a tool or app backend')
def orrin_cli():
    from minimal_display import OrrinCLI
    OrrinCLI().start()"""

# --------------------------------

def main():
    app()

if __name__ == "__main__":
    main()
