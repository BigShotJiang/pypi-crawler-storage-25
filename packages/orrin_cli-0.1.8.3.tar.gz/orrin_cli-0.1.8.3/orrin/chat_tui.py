import requests
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Input, Markdown
from textual.containers import ScrollableContainer
from textual import events

class OrrinCLI(App):
    CSS = """
    Screen {
        background: $background;
    }

    #chat_container {
        height: 1fr;
        overflow-y: auto;
        padding: 1 2;
    }

    Markdown {
        margin: 0 0 1 0;
        background: $surface;
        border: tall $primary;
        padding: 1;
    }

    /* Style user messages differently */
    .user {
        border: tall $accent;
        background: $boost;
    }

    #input {
        dock: bottom;
        margin: 1 2;
    }
    """

    def __init__(self, file_path: str, file_content: str):
        super().__init__()
        self.file_path = file_path
        self.file_content = file_content

        self.chat_history = [
            {
                'role': 'system',
                'content': '''You are **OrrinCLI**, an expert with **Orrin SDK**, Exegesis CE (Centralized Execution), and the **Stellr API**...'''  # ← keep your full system prompt here
            },
            {
                'role': 'assistant',
                'content': f'I obtained the contents of the file that I am connected to. Here they are:\n\n```python\n{file_content}\n```'
            }
        ]

    def compose(self) -> ComposeResult:
        yield Header()
        yield ScrollableContainer(id="chat_container")
        yield Input(
            placeholder="Chat with AI about this file... (press Enter to send)",
            id="input"
        )
        yield Footer()

    def on_mount(self) -> None:
        container = self.query_one("#chat_container", ScrollableContainer)

        # Initial welcome message
        welcome = Markdown(
            f"📄 **Connected to:** `{self.file_path}`\n"
            f"File size: `{len(self.file_content)}` characters\n\n"
            "Ask me anything about this file!\n"
            "─" * 60
        )
        container.mount(welcome)

        # Show the initial AI message from history
        initial_ai = Markdown(self.chat_history[1]['content'])
        container.mount(initial_ai)

        container.scroll_end(animate=False)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        user_msg = event.value.strip()
        if not user_msg:
            return

        event.input.value = ""

        container = self.query_one("#chat_container", ScrollableContainer)

        # 1. Add User Message (styled differently)
        user_md = Markdown(f"🧑 **You:** {user_msg}")
        user_md.add_class("user")
        container.mount(user_md)

        # Add to history
        self.chat_history.append({'role': 'user', 'content': user_msg})

        # 2. Add a "thinking" indicator (optional but nice)
        thinking = Markdown("🤖 **OrrinCLI** is thinking...")
        container.mount(thinking)
        container.scroll_end(animate=False)

        # 3. Get real AI response
        ai_response = self.prompt_ai()

        # 4. Remove thinking message and add real response
        thinking.remove()
        ai_md = Markdown(ai_response)
        container.mount(ai_md)

        # Add to history
        self.chat_history.append({'role': 'assistant', 'content': ai_response})

        container.scroll_end(animate=False)

    def prompt_ai(self) -> str:
        try:
            resp = requests.post(
                'http://172.20.10.2:8080/api/prompt_grok',
                headers={'authorization': 'a7759iujj590poeu52199093kmeyahwpqudjw'},
                json={'history': self.chat_history},
                timeout=90
            )
            if resp.ok:
                return resp.json().get('response', 'No response received from AI.')
            else:
                return f"**Error:** HTTP {resp.status_code} — {resp.text[:200]}"
        except Exception as e:
            return f"**Connection error:** {str(e)}"


# For quick testing
if __name__ == "__main__":
    app = AIChatApp(
        file_path="example.py",
        file_content="print('Hello world')"
    )
    app.run()