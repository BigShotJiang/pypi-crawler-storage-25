# Orrin CLI v0.0.8

Please refer to [the docs](https://stellr-company.com/orrin/sdk) for more information over Orrin CLI.