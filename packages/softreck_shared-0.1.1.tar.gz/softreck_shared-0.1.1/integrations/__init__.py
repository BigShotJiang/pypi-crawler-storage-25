"""Shared integrations for Softreck ecosystem.

Provides common interfaces and implementations for:
- Ticket management (Jira, GitHub, GitLab)
- Project management
- Issue tracking
"""

from .base import TicketRef, TicketStatus, PMBackend
from .generic import GenericBackend

# Platform-specific implementations (optional dependencies)
try:
    from .github import GitHubBackend
except ImportError:
    GitHubBackend = None

__all__ = [
    "TicketRef",
    "TicketStatus", 
    "PMBackend",
    "GenericBackend",
    "GitHubBackend",
]
