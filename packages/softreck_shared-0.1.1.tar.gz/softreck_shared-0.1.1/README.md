# Softreck Shared Integrations

Common integration components for the Softreck ecosystem.

## Overview

This package provides shared interfaces and implementations for:
- Ticket management systems (Jira, GitHub, GitLab)
- Project management backends
- Issue tracking platforms

## Installation

```bash
pip install softreck-shared
```

## Usage

### Base Interfaces

```python
from softreck_shared.integrations import PMBackend, TicketRef, TicketStatus

# Implement a custom backend
class MyBackend(PMBackend):
    def create_ticket(self, title: str, body: str, **kwargs) -> TicketRef:
        # Implementation
        pass
    
    def update_ticket(self, ticket_id: str, **kwargs) -> None:
        # Implementation
        pass
```

### Generic Backend

```python
from softreck_shared.integrations import GenericBackend

# Use with any REST API
backend = GenericBackend(
    base_url="https://api.example.com",
    api_key="your-api-key"
)

# Create a ticket
ticket = backend.create_ticket(
    title="Bug fix",
    body="Fix the login issue",
    labels=["bug", "urgent"],
    priority="high"
)
```

### Platform-Specific Backends

Install with optional dependencies:

```bash
# For Jira
pip install softreck-shared[jira]

# For GitHub
pip install softreck-shared[github]

# For GitLab
pip install softreck-shared[gitlab]

# Or all at once
pip install softreck-shared[all]
```

```python
from softreck_shared.integrations import JiraBackend, GitHubBackend, GitLabBackend

# Jira
jira = JiraBackend(
    server="https://company.atlassian.net",
    username="user@example.com",
    api_key="your-api-key"
)

# GitHub
github = GitHubBackend(
    token="github-token",
    repo="owner/repo"
)

# GitLab
gitlab = GitLabBackend(
    url="https://gitlab.com",
    token="gitlab-token"
)
```

## Architecture

The shared integrations follow a protocol-based design:

- `PMBackend` - Protocol defining the interface
- `TicketRef` - Reference to a created/updated ticket
- `TicketStatus` - Status information for a ticket
- `GenericBackend` - HTTP-based implementation for REST APIs

## Contributing

When adding new platform integrations:

1. Implement the `PMBackend` protocol
2. Add platform-specific optional dependencies
3. Include comprehensive error handling
4. Add type hints for all public methods
5. Write tests for the implementation

## License

Apache License 2.0
