"""Unit coverage for channel-ingest ingress-handle minting."""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from shisad.channels.identity import ChannelIdentityMap
from shisad.core.types import SessionId, TaintLabel
from shisad.daemon.handlers._impl_admin import AdminImplMixin
from shisad.memory.ingress import IngressContextRegistry
from shisad.memory.manager import MemoryManager
from shisad.memory.participation import (
    channel_participation_key,
    channel_summary_key,
    compose_channel_binding,
    inbox_item_key,
    person_note_key,
    response_feedback_key,
)
from shisad.memory.schema import MemorySource
from shisad.security.firewall import FirewallResult


class _DeliveryResult:
    def __init__(self, *, sent: bool = True, reason: str = "ok") -> None:
        self.sent = sent
        self.reason = reason

    def as_dict(self) -> dict[str, Any]:
        return {"attempted": True, "sent": self.sent, "reason": self.reason, "target": {}}


class _DeliveryStub:
    async def send(self, *, target: object, message: str) -> _DeliveryResult:
        _ = (target, message)
        return _DeliveryResult()


class _TranscriptStoreStub:
    def __init__(self) -> None:
        self.entries: list[dict[str, object]] = []

    def append(
        self,
        sid: object,
        *,
        role: str,
        content: str,
        taint_labels: object,
        metadata: dict[str, object],
    ) -> None:
        self.entries.append(
            {
                "session_id": str(sid),
                "role": role,
                "content": content,
                "taint_labels": taint_labels,
                "metadata": metadata,
            }
        )


class _SessionManagerStub:
    def __init__(self) -> None:
        self._sessions: dict[str, object] = {}
        self.terminated: list[tuple[str, str]] = []

    def get(self, sid: object) -> object | None:
        return self._sessions.get(str(sid))

    def find_by_binding(
        self,
        *,
        channel: str,
        user_id: object,
        workspace_id: object,
    ) -> object | None:
        _ = (channel, user_id, workspace_id)
        return None

    def terminate(self, sid: object, *, reason: str) -> None:
        self.terminated.append((str(sid), reason))

    def put(self, sid: str) -> None:
        self._sessions[sid] = SimpleNamespace(id=SessionId(sid))


class _AdminChannelIngressHarness(AdminImplMixin):
    def __init__(
        self,
        *,
        tmp_path: Path,
        default_trust: str = "owner",
        allowlisted_users: set[str] | None = None,
    ) -> None:
        self._config = SimpleNamespace(
            discord_channel_rules=(),
            matrix_room_id="",
            discord_trusted_users=["owner-user"],
            slack_trusted_users=[],
            matrix_trusted_users=[],
            telegram_trusted_users=[],
        )
        self._matrix_channel = None
        self._discord_channel = None
        self._telegram_channel = None
        self._slack_channel = None
        self._identity_map = ChannelIdentityMap(
            default_trust={"discord": default_trust},
            allowlists={"discord": set(allowlisted_users or {"alice"})},
        )
        self._channel_ingress = SimpleNamespace(process=self._process_channel_ingress)
        self._transcript_root = Path("/tmp/shisad-tests")
        self._transcript_store = _TranscriptStoreStub()
        self._session_manager = _SessionManagerStub()
        self._delivery = _DeliveryStub()
        self._channel_proactive_last_sent_at: dict[str, object] = {}
        self._internal_ingress_marker = object()
        self._event_bus = SimpleNamespace(publish=self._publish)
        self._memory_ingress_registry = IngressContextRegistry()
        self._memory_manager = MemoryManager(tmp_path / "memory_entries")
        self.created_payloads: list[dict[str, Any]] = []
        self.message_payloads: list[dict[str, Any]] = []

    def _is_verified_channel_identity(self, *, channel: str, external_user_id: str) -> bool:
        _ = (channel, external_user_id)
        return False

    def _process_channel_ingress(
        self,
        message: object,
        *,
        trusted_input: bool,
    ) -> tuple[object, FirewallResult]:
        _ = message
        return (
            message,
            FirewallResult(
                sanitized_text="remember that I like tea",
                original_hash="0" * 64,
                risk_score=0.1,
                taint_labels=[] if trusted_input else [TaintLabel.UNTRUSTED],
            ),
        )

    async def _publish(self, _event: object) -> None:
        return None

    async def do_session_create(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.created_payloads.append(dict(payload))
        session_id = "sess-channel"
        self._session_manager.put(session_id)
        return {"session_id": session_id}

    async def do_session_message(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.message_payloads.append(dict(payload))
        return {"session_id": str(payload["session_id"]), "response": "ok"}


@pytest.mark.asyncio
async def test_m1_channel_ingest_mints_explicit_memory_handle_at_boundary(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(tmp_path=tmp_path)

    result = await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "alice",
                "workspace_hint": "guild-1",
                "reply_target": "chan-1",
                "message_id": "msg-9",
                "content": "remember that I like tea",
            }
        }
    )

    assert result["response"] == "ok"
    assert len(harness.message_payloads) == 1
    payload = harness.message_payloads[0]
    handle_id = str(payload.get("_explicit_memory_ingress_context", ""))
    assert handle_id
    context = harness._memory_ingress_registry.resolve(handle_id)
    assert context.source_origin == "user_direct"
    assert context.channel_trust == "owner_observed"
    assert context.confirmation_status == "auto_accepted"
    assert context.scope == "user"
    assert context.source_id == "discord:msg-9"


@pytest.mark.asyncio
async def test_m3_channel_ingest_persists_structured_participation_memory(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-1"},
    )

    result = await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-1",
                "workspace_hint": "guild-1",
                "reply_target": "chan-1",
                "message_id": "msg-21",
                "content": "Can you share the release notes?",
                "metadata": {
                    "display_name": "Guest One",
                    "interaction_type": "direct",
                },
            }
        }
    )

    assert result["response"] == "ok"
    entries = harness._memory_manager.list_entries(limit=20)
    by_key = {entry.key: entry for entry in entries}
    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-1",
    )

    inbox = by_key[inbox_item_key(owner_id="owner-user", item_id="msg-21")]
    assert inbox.entry_type == "inbox_item"
    assert inbox.scope == "user"
    assert inbox.source_origin == "external_message"
    assert inbox.channel_trust == "shared_participant"

    note = by_key[person_note_key(channel_id=channel_binding, external_user_id="guest-1")]
    assert note.entry_type == "person_note"
    assert note.scope == "channel"
    assert note.channel_trust == "shared_participant"

    participation = by_key[channel_participation_key(channel_id=channel_binding)]
    assert participation.entry_type == "channel_participation"
    assert participation.scope == "channel"
    assert participation.channel_trust == "shared_participant"


@pytest.mark.asyncio
async def test_m3_channel_ingest_persists_summary_and_feedback_records_from_metadata(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-2"},
    )

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-2",
                "workspace_hint": "guild-1",
                "reply_target": "chan-2",
                "message_id": "msg-30",
                "content": "thumbs up",
                "metadata": {
                    "interaction_type": "direct",
                    "summary_kind": "digest",
                    "summary_text": "Guest follow-up summary.",
                    "feedback_signal": "reaction_add",
                    "feedback_target_message_id": "agent-msg-9",
                    "feedback_emoji": ":+1:",
                    "feedback_valence": "positive",
                },
            }
        }
    )

    entries = harness._memory_manager.list_entries(limit=20)
    by_key = {entry.key: entry for entry in entries}
    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-2",
    )

    summary = by_key[channel_summary_key(channel_id=channel_binding, summary_kind="digest")]
    assert summary.entry_type == "channel_summary"
    assert summary.scope == "channel"

    feedback = by_key[
        response_feedback_key(
            channel_id=channel_binding,
            message_id="agent-msg-9",
            actor_external_user_id="guest-2",
            signal="reaction_add",
        )
    ]
    assert feedback.entry_type == "response_feedback"
    assert feedback.scope == "channel"


@pytest.mark.asyncio
async def test_m3_channel_ingest_observation_updates_participation_without_inbox_item(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-3"},
    )

    result = await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-3",
                "workspace_hint": "guild-1",
                "reply_target": "chan-3",
                "message_id": "msg-44",
                "content": "reading along here",
                "metadata": {
                    "interaction_type": "observed",
                    "passive_reason": "passive_observe",
                },
            }
        }
    )

    assert result["response"] == ""
    entries = harness._memory_manager.list_entries(limit=20)
    keys = {entry.key for entry in entries}
    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-3",
    )
    assert channel_participation_key(channel_id=channel_binding) in keys
    assert person_note_key(channel_id=channel_binding, external_user_id="guest-3") in keys
    assert inbox_item_key(owner_id="owner-user", item_id="msg-44") not in keys


@pytest.mark.asyncio
async def test_m3_channel_ingest_migrates_legacy_bare_inbox_bindings(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-4"},
    )
    harness._transcript_store.append(
        SessionId("sess-legacy-1"),
        role="user",
        content="legacy workspace one",
        taint_labels=set(),
        metadata={
            "channel_message_id": "legacy-msg-1",
            "delivery_target": {
                "channel": "discord",
                "recipient": "chan-legacy",
                "workspace_hint": "guild-1",
                "thread_id": "",
            },
        },
    )
    harness._transcript_store.append(
        SessionId("sess-legacy-2"),
        role="user",
        content="legacy workspace two",
        taint_labels=set(),
        metadata={
            "channel_message_id": "legacy-msg-2",
            "delivery_target": {
                "channel": "discord",
                "recipient": "chan-legacy",
                "workspace_hint": "guild-2",
                "thread_id": "",
            },
        },
    )
    legacy = harness._memory_manager.write_with_provenance(
        entry_type="inbox_item",
        key=inbox_item_key(owner_id="owner-user", item_id="legacy-1"),
        value={
            "owner_id": "owner-user",
            "sender_id": "guest-4",
            "channel_id": "chan-legacy",
            "body": "Legacy bare channel binding.",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-msg-1",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-msg-1",
        scope="user",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy.kind == "allow"
    assert legacy.entry is not None
    other_workspace = harness._memory_manager.write_with_provenance(
        entry_type="inbox_item",
        key=inbox_item_key(owner_id="owner-user", item_id="legacy-2"),
        value={
            "owner_id": "owner-user",
            "sender_id": "guest-4",
            "channel_id": "chan-legacy",
            "body": "Legacy bare channel binding from another workspace.",
        },
        source=MemorySource(
            origin="external",
            source_id="legacy-msg-2",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-msg-2",
        scope="user",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert other_workspace.kind == "allow"
    assert other_workspace.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-4",
                "workspace_hint": "guild-1",
                "reply_target": "chan-legacy",
                "message_id": "msg-55",
                "content": "fresh message on the same channel",
                "metadata": {"interaction_type": "direct"},
            }
        }
    )

    legacy_entry = harness._memory_manager.get_entry(legacy.entry.id)
    assert legacy_entry is not None
    assert isinstance(legacy_entry.value, dict)
    other_workspace_entry = harness._memory_manager.get_entry(other_workspace.entry.id)
    assert other_workspace_entry is not None
    assert isinstance(other_workspace_entry.value, dict)
    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-legacy",
    )
    assert legacy_entry.value["channel_id"] == channel_binding
    assert other_workspace_entry.value["channel_id"] == "chan-legacy"

    pack = harness._memory_manager.compile_active_attention(
        max_tokens=256,
        scope_filter={"user"},
        channel_binding=channel_binding,
    )

    surfaced_ids = {entry.id for entry in pack.entries}
    assert legacy.entry.id in surfaced_ids
    assert other_workspace.entry.id not in surfaced_ids


@pytest.mark.asyncio
async def test_m3_channel_ingest_carries_forward_legacy_keyed_channel_state(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-5"},
    )
    for session_id, message_id in (
        ("sess-note", "legacy-note-msg"),
        ("sess-participation", "legacy-participation-msg"),
        ("sess-summary", "legacy-summary-msg"),
        ("sess-note-other", "legacy-note-msg-other"),
        ("sess-participation-other", "legacy-participation-msg-other"),
        ("sess-summary-other", "legacy-summary-msg-other"),
    ):
        harness._transcript_store.append(
            SessionId(session_id),
            role="user",
            content=f"legacy {message_id}",
            taint_labels=set(),
            metadata={
                "channel_message_id": message_id,
                "delivery_target": {
                    "channel": "discord",
                    "recipient": "chan-state",
                    "workspace_hint": "guild-2" if message_id.endswith("-other") else "guild-1",
                    "thread_id": "",
                },
            },
        )

    legacy_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id="chan-state", external_user_id="guest-5"),
        value={
            "external_user_id": "guest-5",
            "display_name": "Guest Five",
            "channel_id": "chan-state",
            "total_interactions": 2,
            "interaction_summary": "Legacy note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-note-msg",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_note.kind == "allow"
    assert legacy_note.entry is not None

    other_workspace_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id="chan-state", external_user_id="guest-5"),
        value={
            "external_user_id": "guest-5",
            "display_name": "Guest Five Elsewhere",
            "channel_id": "chan-state",
            "total_interactions": 7,
            "interaction_summary": "Other workspace note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg-other",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-note-msg-other",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert other_workspace_note.kind == "allow"
    assert other_workspace_note.entry is not None

    legacy_participation = harness._memory_manager.write_with_provenance(
        entry_type="channel_participation",
        key=channel_participation_key(channel_id="chan-state"),
        value={
            "channel_id": "chan-state",
            "tracked_threads": [
                {
                    "thread_id": "chan-state",
                    "participants": ["guest-5"],
                }
            ],
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-participation-msg",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-participation-msg",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_participation.kind == "allow"
    assert legacy_participation.entry is not None

    other_workspace_participation = harness._memory_manager.write_with_provenance(
        entry_type="channel_participation",
        key=channel_participation_key(channel_id="chan-state"),
        value={
            "channel_id": "chan-state",
            "tracked_threads": [
                {
                    "thread_id": "chan-state",
                    "participants": ["guest-5", "guest-elsewhere"],
                }
            ],
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-participation-msg-other",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-participation-msg-other",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert other_workspace_participation.kind == "allow"
    assert other_workspace_participation.entry is not None

    legacy_summary = harness._memory_manager.write_with_provenance(
        entry_type="channel_summary",
        key=channel_summary_key(channel_id="chan-state", summary_kind="digest"),
        value={
            "channel_id": "chan-state",
            "summary_kind": "digest",
            "summary_text": "Legacy digest",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-summary-msg",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-summary-msg",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_summary.kind == "allow"
    assert legacy_summary.entry is not None

    other_workspace_summary = harness._memory_manager.write_with_provenance(
        entry_type="channel_summary",
        key=channel_summary_key(channel_id="chan-state", summary_kind="digest"),
        value={
            "channel_id": "chan-state",
            "summary_kind": "digest",
            "summary_text": "Other workspace digest",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-summary-msg-other",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-summary-msg-other",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert other_workspace_summary.kind == "allow"
    assert other_workspace_summary.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-5",
                "workspace_hint": "guild-1",
                "reply_target": "chan-state",
                "message_id": "msg-77",
                "content": "carry forward legacy state",
                "metadata": {
                    "interaction_type": "direct",
                    "display_name": "Guest Five",
                    "summary_kind": "digest",
                    "summary_text": "Updated digest",
                },
            }
        }
    )

    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-state",
    )
    current_entries = {
        entry.key: entry
        for entry in harness._memory_manager.list_entries(limit=20)
        if entry.superseded_by is None
    }

    current_note = current_entries[
        person_note_key(channel_id=channel_binding, external_user_id="guest-5")
    ]
    assert current_note.supersedes == legacy_note.entry.id
    assert current_note.value["total_interactions"] == 3

    current_participation = current_entries[channel_participation_key(channel_id=channel_binding)]
    assert current_participation.supersedes == legacy_participation.entry.id
    assert current_participation.value["tracked_threads"][0]["participants"] == ["guest-5"]

    current_summary = current_entries[
        channel_summary_key(channel_id=channel_binding, summary_kind="digest")
    ]
    assert current_summary.supersedes == legacy_summary.entry.id

    preserved_note = harness._memory_manager.get_entry(other_workspace_note.entry.id)
    assert preserved_note is not None
    assert preserved_note.key == person_note_key(
        channel_id="chan-state",
        external_user_id="guest-5",
    )
    assert preserved_note.superseded_by is None

    preserved_participation = harness._memory_manager.get_entry(
        other_workspace_participation.entry.id
    )
    assert preserved_participation is not None
    assert preserved_participation.key == channel_participation_key(channel_id="chan-state")
    assert preserved_participation.superseded_by is None

    preserved_summary = harness._memory_manager.get_entry(other_workspace_summary.entry.id)
    assert preserved_summary is not None
    assert preserved_summary.key == channel_summary_key(
        channel_id="chan-state",
        summary_kind="digest",
    )
    assert preserved_summary.superseded_by is None


@pytest.mark.asyncio
async def test_m3_channel_ingest_carries_forward_legacy_keyed_state_without_workspace_hint(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-6"},
    )
    for session_id, message_id in (
        ("sess-note-blank", "legacy-note-msg-blank"),
        ("sess-participation-blank", "legacy-participation-msg-blank"),
        ("sess-summary-blank", "legacy-summary-msg-blank"),
    ):
        harness._transcript_store.append(
            SessionId(session_id),
            role="user",
            content=f"legacy {message_id}",
            taint_labels=set(),
            metadata={
                "channel_message_id": message_id,
                "delivery_target": {
                    "channel": "discord",
                    "recipient": "chan-blank",
                    "workspace_hint": "",
                    "thread_id": "",
                },
            },
        )

    legacy_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id="chan-blank", external_user_id="guest-6"),
        value={
            "external_user_id": "guest-6",
            "display_name": "Guest Six",
            "channel_id": "chan-blank",
            "total_interactions": 4,
            "interaction_summary": "Blank workspace note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg-blank",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-note-msg-blank",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_note.kind == "allow"
    assert legacy_note.entry is not None

    legacy_participation = harness._memory_manager.write_with_provenance(
        entry_type="channel_participation",
        key=channel_participation_key(channel_id="chan-blank"),
        value={
            "channel_id": "chan-blank",
            "tracked_threads": [
                {
                    "thread_id": "chan-blank",
                    "participants": ["guest-6"],
                }
            ],
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-participation-msg-blank",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-participation-msg-blank",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_participation.kind == "allow"
    assert legacy_participation.entry is not None

    legacy_summary = harness._memory_manager.write_with_provenance(
        entry_type="channel_summary",
        key=channel_summary_key(channel_id="chan-blank", summary_kind="digest"),
        value={
            "channel_id": "chan-blank",
            "summary_kind": "digest",
            "summary_text": "Blank workspace digest",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-summary-msg-blank",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-summary-msg-blank",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_summary.kind == "allow"
    assert legacy_summary.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-6",
                "workspace_hint": "",
                "reply_target": "chan-blank",
                "message_id": "msg-88",
                "content": "carry forward blank-workspace state",
                "metadata": {
                    "interaction_type": "direct",
                    "display_name": "Guest Six",
                    "summary_kind": "digest",
                    "summary_text": "Updated blank workspace digest",
                },
            }
        }
    )

    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="",
        channel_id="chan-blank",
    )
    current_entries = {
        entry.key: entry
        for entry in harness._memory_manager.list_entries(limit=20)
        if entry.superseded_by is None
    }

    current_note = current_entries[
        person_note_key(channel_id=channel_binding, external_user_id="guest-6")
    ]
    assert current_note.supersedes == legacy_note.entry.id
    assert current_note.value["total_interactions"] == 5

    current_participation = current_entries[channel_participation_key(channel_id=channel_binding)]
    assert current_participation.supersedes == legacy_participation.entry.id

    current_summary = current_entries[
        channel_summary_key(channel_id=channel_binding, summary_kind="digest")
    ]
    assert current_summary.supersedes == legacy_summary.entry.id


@pytest.mark.asyncio
async def test_m3_channel_ingest_requires_explicit_blank_workspace_hint_for_legacy_carry_forward(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-7"},
    )
    transcript_dir = tmp_path / "transcripts"
    transcript_dir.mkdir()
    (transcript_dir / "channel.jsonl").write_text(
        json.dumps(
            {
                "session_id": "sess-note-missing-workspace",
                "role": "user",
                "content": "legacy note without workspace hint",
                "metadata": {
                    "channel_message_id": "legacy-note-msg-missing-workspace",
                    "delivery_target": {
                        "channel": "discord",
                        "recipient": "chan-missing-workspace",
                        "thread_id": "",
                    },
                },
            }
        )
        + "\n",
        encoding="utf-8",
    )
    harness._transcript_store.entries = None
    harness._transcript_store._transcript_dir = transcript_dir

    legacy_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(
            channel_id="chan-missing-workspace",
            external_user_id="guest-7",
        ),
        value={
            "external_user_id": "guest-7",
            "display_name": "Guest Seven",
            "channel_id": "chan-missing-workspace",
            "total_interactions": 6,
            "interaction_summary": "Missing workspace note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg-missing-workspace",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-note-msg-missing-workspace",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_note.kind == "allow"
    assert legacy_note.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-7",
                "workspace_hint": "",
                "reply_target": "chan-missing-workspace",
                "message_id": "msg-99",
                "content": "fresh blank-workspace message",
                "metadata": {
                    "interaction_type": "direct",
                    "display_name": "Guest Seven",
                },
            }
        }
    )

    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="",
        channel_id="chan-missing-workspace",
    )
    current_entries = {
        entry.key: entry
        for entry in harness._memory_manager.list_entries(limit=20)
        if entry.superseded_by is None
    }

    current_note = current_entries[
        person_note_key(channel_id=channel_binding, external_user_id="guest-7")
    ]
    assert current_note.supersedes is None
    assert current_note.value["total_interactions"] == 1

    preserved_legacy = harness._memory_manager.get_entry(legacy_note.entry.id)
    assert preserved_legacy is not None
    assert preserved_legacy.key == person_note_key(
        channel_id="chan-missing-workspace",
        external_user_id="guest-7",
    )
    assert preserved_legacy.superseded_by is None


@pytest.mark.asyncio
async def test_m3_channel_ingest_ignores_non_active_predecessors_for_keyed_state(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-8"},
    )
    harness._transcript_store.append(
        SessionId("sess-note-pending-review"),
        role="user",
        content="legacy note pending review",
        taint_labels=set(),
        metadata={
            "channel_message_id": "legacy-note-msg-pending-review",
            "delivery_target": {
                "channel": "discord",
                "recipient": "chan-review-state",
                "workspace_hint": "guild-1",
                "thread_id": "",
            },
        },
    )

    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-review-state",
    )
    current_quarantined = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id=channel_binding, external_user_id="guest-8"),
        value={
            "external_user_id": "guest-8",
            "display_name": "Guest Eight",
            "channel_id": channel_binding,
            "total_interactions": 9,
            "interaction_summary": "Quarantined canonical note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:canonical-note-msg",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:canonical-note-msg",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert current_quarantined.kind == "allow"
    assert current_quarantined.entry is not None
    assert harness._memory_manager.quarantine(
        current_quarantined.entry.id,
        reason="manual-review",
    )

    pending_review_legacy = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id="chan-review-state", external_user_id="guest-8"),
        value={
            "external_user_id": "guest-8",
            "display_name": "Guest Eight",
            "channel_id": "chan-review-state",
            "total_interactions": 4,
            "interaction_summary": "Pending review legacy note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg-pending-review",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="discord:legacy-note-msg-pending-review",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=False,
    )
    assert pending_review_legacy.kind == "allow"
    assert pending_review_legacy.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-8",
                "workspace_hint": "guild-1",
                "reply_target": "chan-review-state",
                "message_id": "msg-109",
                "content": "fresh active message",
                "metadata": {
                    "interaction_type": "direct",
                    "display_name": "Guest Eight",
                },
            }
        }
    )

    current_entries = {
        entry.key: entry
        for entry in harness._memory_manager.list_entries(limit=20)
        if entry.superseded_by is None
    }

    current_note = current_entries[
        person_note_key(channel_id=channel_binding, external_user_id="guest-8")
    ]
    assert current_note.supersedes is None
    assert current_note.value["total_interactions"] == 1

    quarantined_entry = harness._memory_manager.get_entry(
        current_quarantined.entry.id,
        include_quarantined=True,
    )
    assert quarantined_entry is not None
    assert quarantined_entry.status == "quarantined"
    assert quarantined_entry.superseded_by is None

    pending_review_entry = harness._memory_manager.get_entry(
        pending_review_legacy.entry.id,
        include_pending_review=True,
    )
    assert pending_review_entry is not None
    assert pending_review_entry.confirmation_status == "pending_review"
    assert pending_review_entry.superseded_by is None


@pytest.mark.asyncio
async def test_m3_channel_ingest_skips_keyed_state_when_canonical_pending_review_exists(
    tmp_path: Path,
) -> None:
    harness = _AdminChannelIngressHarness(
        tmp_path=tmp_path,
        default_trust="public",
        allowlisted_users={"guest-9"},
    )
    for session_id, message_id in (
        ("sess-note-pending-current", "legacy-note-msg-current"),
        ("sess-participation-pending-current", "legacy-participation-msg-current"),
        ("sess-summary-pending-current", "legacy-summary-msg-current"),
    ):
        harness._transcript_store.append(
            SessionId(session_id),
            role="user",
            content=f"legacy {message_id}",
            taint_labels=set(),
            metadata={
                "channel_message_id": message_id,
                "delivery_target": {
                    "channel": "discord",
                    "recipient": "chan-pending-current",
                    "workspace_hint": "guild-1",
                    "thread_id": "",
                },
            },
        )

    channel_binding = compose_channel_binding(
        channel="discord",
        workspace_hint="guild-1",
        channel_id="chan-pending-current",
    )

    legacy_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id="chan-pending-current", external_user_id="guest-9"),
        value={
            "external_user_id": "guest-9",
            "display_name": "Guest Nine",
            "channel_id": "chan-pending-current",
            "total_interactions": 4,
            "interaction_summary": "Legacy note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-note-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-note-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_note.kind == "allow"
    assert legacy_note.entry is not None

    pending_review_note = harness._memory_manager.write_with_provenance(
        entry_type="person_note",
        key=person_note_key(channel_id=channel_binding, external_user_id="guest-9"),
        value={
            "external_user_id": "guest-9",
            "display_name": "Guest Nine",
            "channel_id": channel_binding,
            "total_interactions": 8,
            "interaction_summary": "Pending review note",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:pending-note-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="discord:pending-note-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=False,
    )
    assert pending_review_note.kind == "allow"
    assert pending_review_note.entry is not None

    legacy_participation = harness._memory_manager.write_with_provenance(
        entry_type="channel_participation",
        key=channel_participation_key(channel_id="chan-pending-current"),
        value={
            "channel_id": "chan-pending-current",
            "tracked_threads": [
                {
                    "thread_id": "chan-pending-current",
                    "participants": ["guest-9"],
                }
            ],
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-participation-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-participation-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_participation.kind == "allow"
    assert legacy_participation.entry is not None

    pending_review_participation = harness._memory_manager.write_with_provenance(
        entry_type="channel_participation",
        key=channel_participation_key(channel_id=channel_binding),
        value={
            "channel_id": channel_binding,
            "tracked_threads": [
                {
                    "thread_id": "chan-pending-current",
                    "participants": ["guest-9", "guest-review"],
                }
            ],
        },
        source=MemorySource(
            origin="external",
            source_id="discord:pending-participation-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="discord:pending-participation-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=False,
    )
    assert pending_review_participation.kind == "allow"
    assert pending_review_participation.entry is not None

    legacy_summary = harness._memory_manager.write_with_provenance(
        entry_type="channel_summary",
        key=channel_summary_key(channel_id="chan-pending-current", summary_kind="digest"),
        value={
            "channel_id": "chan-pending-current",
            "summary_kind": "digest",
            "summary_text": "Legacy digest",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:legacy-summary-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="auto_accepted",
        source_id="discord:legacy-summary-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=True,
    )
    assert legacy_summary.kind == "allow"
    assert legacy_summary.entry is not None

    pending_review_summary = harness._memory_manager.write_with_provenance(
        entry_type="channel_summary",
        key=channel_summary_key(channel_id=channel_binding, summary_kind="digest"),
        value={
            "channel_id": channel_binding,
            "summary_kind": "digest",
            "summary_text": "Pending review digest",
        },
        source=MemorySource(
            origin="external",
            source_id="discord:pending-summary-msg-current",
            extraction_method="channel.ingest.structured",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="discord:pending-summary-msg-current",
        scope="channel",
        confidence=0.5,
        confirmation_satisfied=False,
    )
    assert pending_review_summary.kind == "allow"
    assert pending_review_summary.entry is not None

    await harness.do_channel_ingest(
        {
            "message": {
                "channel": "discord",
                "external_user_id": "guest-9",
                "workspace_hint": "guild-1",
                "reply_target": "chan-pending-current",
                "message_id": "msg-119",
                "content": "fresh active message with pending review collision",
                "metadata": {
                    "interaction_type": "direct",
                    "display_name": "Guest Nine",
                    "summary_kind": "digest",
                    "summary_text": "Fresh digest",
                },
            }
        }
    )

    current_entries = {
        entry.key: entry
        for entry in harness._memory_manager.list_entries(limit=30)
        if entry.superseded_by is None
    }

    assert (
        person_note_key(channel_id=channel_binding, external_user_id="guest-9")
        not in current_entries
    )
    assert channel_participation_key(channel_id=channel_binding) not in current_entries
    assert (
        channel_summary_key(channel_id=channel_binding, summary_kind="digest")
        not in current_entries
    )

    preserved_legacy_note = harness._memory_manager.get_entry(legacy_note.entry.id)
    assert preserved_legacy_note is not None
    assert preserved_legacy_note.key == person_note_key(
        channel_id="chan-pending-current",
        external_user_id="guest-9",
    )
    assert preserved_legacy_note.superseded_by is None

    preserved_legacy_participation = harness._memory_manager.get_entry(
        legacy_participation.entry.id
    )
    assert preserved_legacy_participation is not None
    assert preserved_legacy_participation.key == channel_participation_key(
        channel_id="chan-pending-current"
    )
    assert preserved_legacy_participation.superseded_by is None

    preserved_legacy_summary = harness._memory_manager.get_entry(legacy_summary.entry.id)
    assert preserved_legacy_summary is not None
    assert preserved_legacy_summary.key == channel_summary_key(
        channel_id="chan-pending-current",
        summary_kind="digest",
    )
    assert preserved_legacy_summary.superseded_by is None

    pending_note_entry = harness._memory_manager.get_entry(
        pending_review_note.entry.id,
        include_pending_review=True,
    )
    assert pending_note_entry is not None
    assert pending_note_entry.confirmation_status == "pending_review"
    assert pending_note_entry.superseded_by is None

    pending_participation_entry = harness._memory_manager.get_entry(
        pending_review_participation.entry.id,
        include_pending_review=True,
    )
    assert pending_participation_entry is not None
    assert pending_participation_entry.confirmation_status == "pending_review"
    assert pending_participation_entry.superseded_by is None

    pending_summary_entry = harness._memory_manager.get_entry(
        pending_review_summary.entry.id,
        include_pending_review=True,
    )
    assert pending_summary_entry is not None
    assert pending_summary_entry.confirmation_status == "pending_review"
    assert pending_summary_entry.superseded_by is None
