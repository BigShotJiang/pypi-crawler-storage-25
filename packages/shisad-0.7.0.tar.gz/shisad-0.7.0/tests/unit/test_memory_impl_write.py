"""Unit coverage for handle-based memory writes."""

from __future__ import annotations

from pathlib import Path

import pytest

from shisad.daemon.handlers._impl_memory import MemoryImplMixin
from shisad.memory.ingress import IngressContextRegistry
from shisad.memory.manager import MemoryManager, MemorySource
from shisad.memory.remap import digest_memory_value
from shisad.memory.trust import TrustGateViolation


class _MemoryWriteHarness(MemoryImplMixin):
    def __init__(self, tmp_path: Path, *, audit_hook=None) -> None:
        self._memory_manager = MemoryManager(tmp_path / "memory", audit_hook=audit_hook)
        self._memory_ingress_registry = IngressContextRegistry()


@pytest.mark.asyncio
async def test_memory_mint_ingress_context_returns_authenticated_user_handle(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_memory_mint_ingress_context({"content": "remember this"})

    assert result["source_origin"] == "user_direct"
    assert result["channel_trust"] == "command"
    assert result["confirmation_status"] == "user_asserted"
    assert result["scope"] == "user"
    assert result["source_id"] == "cli"
    context = harness._memory_ingress_registry.resolve(str(result["ingress_context"]))
    assert context.content_digest == result["content_digest"]


@pytest.mark.asyncio
async def test_memory_mint_ingress_context_public_path_ignores_caller_provenance_fields(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_memory_mint_ingress_context(
        {
            "content": "remember this",
            "source_type": "external",
            "source_id": "forged-source",
        }
    )

    assert result["source_origin"] == "user_direct"
    assert result["channel_trust"] == "command"
    assert result["confirmation_status"] == "user_asserted"
    assert result["source_id"] == "cli"


@pytest.mark.asyncio
async def test_memory_mint_ingress_context_internal_path_preserves_boundary_provenance(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    harness._internal_ingress_marker = object()

    result = await harness.do_memory_mint_ingress_context(
        {
            "_internal_ingress_marker": harness._internal_ingress_marker,
            "content": "fetched page",
            "source_type": "external",
            "source_id": "web:doc-7",
        }
    )

    assert result["source_origin"] == "external_web"
    assert result["channel_trust"] == "web_passed"
    assert result["confirmation_status"] == "auto_accepted"
    assert result["source_id"] == "web:doc-7"


@pytest.mark.asyncio
async def test_memory_write_accepts_handle_bound_direct_payload(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-1",
        content="remember this",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "fact",
            "key": "profile.note",
            "value": "remember this",
            "confidence": 0.99,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["channel_trust"] == "command"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["scope"] == "user"
    assert entry["ingress_handle_id"] == context.handle_id
    assert entry["content_digest"] == context.content_digest
    assert entry["confidence"] == pytest.approx(0.95)


@pytest.mark.asyncio
async def test_memory_write_rejects_preference_missing_predicate_with_hint(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-1",
        content="prefers terse replies",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "preference",
            "key": "pref:response_style",
            "value": "prefers terse replies",
        }
    )

    assert result["kind"] == "reject"
    assert result["reason"] == "preference_predicate_required"
    assert "require a predicate" in str(result["reason_detail"])
    assert "prefers(response_style)" in str(result["hint"])


@pytest.mark.asyncio
async def test_memory_write_rejects_mismatched_handle_binding(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-2",
        content="trusted payload",
    )

    with pytest.raises(TrustGateViolation):
        await harness.do_memory_write(
            {
                "ingress_context": context.handle_id,
                "entry_type": "fact",
                "key": "profile.note",
                "value": "different payload",
            }
        )


@pytest.mark.asyncio
async def test_memory_write_handle_scope_and_source_id_override_are_ignored(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="channel",
        source_id="discord:msg-42",
        content="shared channel note",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "note",
            "key": "note:shared-channel",
            "value": "shared channel note",
            "scope": "user",
            "source_id": "forged-source-id",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["scope"] == "channel"
    assert entry["source_id"] == "discord:msg-42"
    assert entry["source_origin"] == "user_direct"
    assert entry["channel_trust"] == "command"
    assert entry["confirmation_status"] == "user_asserted"


@pytest.mark.asyncio
async def test_memory_invoke_skill_routes_through_manager_and_forwards_rpc_peer(
    tmp_path: Path,
) -> None:
    audits: list[tuple[str, dict[str, object]]] = []
    harness = _MemoryWriteHarness(
        tmp_path,
        audit_hook=lambda action, data: audits.append((action, data)),
    )
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-skill-1",
        content="Release close checklist\nRun behavioral validation before release close.",
    )
    written = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "skill",
            "key": "skill:release-close",
            "value": "Release close checklist\nRun behavioral validation before release close.",
            "invocation_eligible": True,
        }
    )

    result = await harness.do_memory_invoke_skill(
        {
            "skill_id": written["entry"]["id"],
            "_rpc_peer": {"host": "127.0.0.1", "port": 31337},
        }
    )

    assert result["found"] is True
    assert result["invoked"] is True
    assert result["artifact"]["id"] == written["entry"]["id"]
    assert result["artifact"]["content"].startswith("Release close checklist")
    assert audits[-1] == (
        "memory.skill_invoked",
        {
            "skill_id": written["entry"]["id"],
            "entry_id": written["entry"]["id"],
            "entry_type": "skill",
            "found": True,
            "invoked": True,
            "reason": "",
            "trust_band": "elevated",
            "caller_context": {
                "method": "memory.invoke_skill",
                "rpc_peer": {"host": "127.0.0.1", "port": 31337},
            },
        },
    )


@pytest.mark.asyncio
async def test_memory_promote_skill_promotes_pending_review_candidate_from_handle(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    candidate = harness._memory_manager.write_with_provenance(
        entry_type="skill",
        key="skill:release-close",
        value="Release close checklist\nCandidate version",
        source=MemorySource(
            origin="external",
            source_id="review-candidate-1",
            extraction_method="review.queue",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="review-candidate-1",
        scope="user",
        confidence=0.62,
        confirmation_satisfied=True,
    )
    assert candidate.entry is not None
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-promote-1",
        content="Release close checklist\nCandidate version",
    )

    result = await harness.do_memory_promote_skill(
        {
            "ingress_context": context.handle_id,
            "entry_id": candidate.entry.id,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["supersedes"] == candidate.entry.id
    assert entry["invocation_eligible"] is True


@pytest.mark.asyncio
async def test_memory_promote_skill_derives_tool_install_context_from_tool_output_handle(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    skill_body = "Release close checklist\nTool-installed candidate"
    candidate = harness._memory_manager.write_with_provenance(
        entry_type="skill",
        key="skill:tool-release-close",
        value=skill_body,
        source=MemorySource(
            origin="external",
            source_id="review-candidate-tool-1",
            extraction_method="review.queue",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="review-candidate-tool-1",
        scope="user",
        confidence=0.62,
        confirmation_satisfied=True,
    )
    assert candidate.entry is not None
    tool_context = harness._memory_ingress_registry.mint(
        source_origin="tool_output",
        channel_trust="tool_passed",
        confirmation_status="auto_accepted",
        scope="session",
        source_id="session-1:skill.install",
        content=skill_body,
    )

    result = await harness.do_memory_promote_skill(
        {
            "ingress_context": tool_context.handle_id,
            "entry_id": candidate.entry.id,
            "_control_api_authenticated_write": True,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "tool_output"
    assert entry["channel_trust"] == "tool_passed"
    assert entry["confirmation_status"] == "pep_approved"
    assert entry["scope"] == "user"
    assert entry["invocation_eligible"] is True
    assert entry["ingress_handle_id"] != tool_context.handle_id
    promoted = harness._memory_manager.get_entry(str(entry["id"]))
    assert promoted is not None
    assert promoted.trust_band == "untrusted"
    install_context = harness._memory_ingress_registry.resolve(str(entry["ingress_handle_id"]))
    assert install_context.confirmation_status == "pep_approved"
    assert install_context.scope == "user"


@pytest.mark.asyncio
async def test_memory_promote_identity_candidate_rejects_quarantined_candidate_before_binding_check(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    candidate = harness._memory_manager.write_with_provenance(
        entry_type="preference",
        key="preference:tea",
        value="I prefer tea over coffee.",
        predicate="likes(tea)",
        source=MemorySource(
            origin="external",
            source_id="candidate-promote-quarantine-1",
            extraction_method="identity.candidate",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="candidate-promote-quarantine-1",
        scope="user",
        confidence=0.62,
        confirmation_satisfied=True,
    )
    assert candidate.entry is not None
    assert harness._memory_manager.quarantine(candidate.entry.id, reason="test_quarantine")
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-promote-quarantine-1",
        content="mismatched promotion payload",
    )

    result = await harness.do_memory_promote_identity_candidate(
        {
            "ingress_context": context.handle_id,
            "candidate_id": candidate.entry.id,
        }
    )

    assert result == {
        "kind": "reject",
        "reason": "candidate_not_found",
        "entry": None,
    }


@pytest.mark.asyncio
async def test_memory_promote_skill_rejects_quarantined_candidate_before_binding_check(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    candidate = harness._memory_manager.write_with_provenance(
        entry_type="skill",
        key="skill:release-close",
        value="Release close checklist\nQuarantined candidate",
        source=MemorySource(
            origin="external",
            source_id="skill-promote-quarantine-1",
            extraction_method="review.queue",
        ),
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        source_id="skill-promote-quarantine-1",
        scope="user",
        confidence=0.62,
        confirmation_satisfied=True,
    )
    assert candidate.entry is not None
    assert harness._memory_manager.quarantine(candidate.entry.id, reason="test_quarantine")
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-skill-quarantine-1",
        content="mismatched skill promotion payload",
    )

    result = await harness.do_memory_promote_skill(
        {
            "ingress_context": context.handle_id,
            "entry_id": candidate.entry.id,
        }
    )

    assert result == {
        "kind": "reject",
        "reason": "skill_not_found",
        "entry": None,
    }


@pytest.mark.asyncio
async def test_note_create_accepts_handle_bound_extracted_payload(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-3",
        content="remember that my favorite color is blue",
    )

    result = await harness.do_note_create(
        {
            "ingress_context": context.handle_id,
            "key": "note:favorite-color",
            "content": "my favorite color is blue",
            "content_digest": digest_memory_value("my favorite color is blue"),
            "derivation_path": "extracted",
            "parent_digest": context.content_digest,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["entry_type"] == "note"
    assert entry["source_origin"] == "user_direct"
    assert entry["channel_trust"] == "command"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["ingress_handle_id"] == context.handle_id
    assert entry["content_digest"] == digest_memory_value("my favorite color is blue")


@pytest.mark.asyncio
async def test_note_create_allows_short_user_asserted_extracted_payload(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-3b",
        content="remember that blue",
    )

    result = await harness.do_note_create(
        {
            "ingress_context": context.handle_id,
            "key": "note:short-color",
            "content": "blue",
            "content_digest": digest_memory_value("blue"),
            "derivation_path": "extracted",
            "parent_digest": context.content_digest,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["value"] == "blue"
    assert entry["source_origin"] == "user_direct"


@pytest.mark.asyncio
async def test_memory_write_rejects_low_signal_non_user_handle_payload(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="consolidation_derived",
        channel_trust="consolidation",
        confirmation_status="auto_accepted",
        scope="user",
        source_id="summary-1",
        content="okay",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "note",
            "key": "conversation.remembered",
            "value": "okay",
        }
    )

    assert result["kind"] == "reject"
    assert result["reason"] == "insufficient_memory_signal"


@pytest.mark.asyncio
async def test_memory_write_routes_pending_review_handles_to_review_queue(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="external_message",
        channel_trust="shared_participant",
        confirmation_status="pending_review",
        scope="user",
        source_id="discord:msg-review-1",
        content="Needs operator review",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "note",
            "key": "note:queue",
            "value": "Needs operator review",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["confirmation_status"] == "pending_review"
    assert harness._memory_manager.get_entry(str(entry["id"])) is None
    assert harness._memory_manager.list_review_queue(limit=10)[0].id == str(entry["id"])


@pytest.mark.asyncio
async def test_todo_create_accepts_handle_bound_extracted_payload(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-4",
        content="add a todo: review PRs tomorrow",
    )

    todo_payload = {
        "title": "review PRs",
        "details": "",
        "status": "open",
        "due_date": "tomorrow",
    }
    result = await harness.do_todo_create(
        {
            **todo_payload,
            "ingress_context": context.handle_id,
            "content_digest": digest_memory_value(todo_payload),
            "derivation_path": "extracted",
            "parent_digest": context.content_digest,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["entry_type"] == "todo"
    assert entry["source_origin"] == "user_direct"
    assert entry["channel_trust"] == "command"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["ingress_handle_id"] == context.handle_id
    assert entry["content_digest"] == digest_memory_value(todo_payload)
    assert entry["value"]["title"] == "review PRs"


@pytest.mark.asyncio
async def test_memory_write_rejects_unauthenticated_raw_source_shape(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    with pytest.raises(ValueError, match=r"ingress_context is required for memory\.write"):
        await harness.do_memory_write(
            {
                "source": {
                    "origin": "user",
                    "source_id": "legacy-1",
                    "extraction_method": "manual",
                },
                "entry_type": "fact",
                "key": "profile.name",
                "value": "alice",
            }
        )


@pytest.mark.asyncio
async def test_memory_supersede_rejects_unauthenticated_raw_source_shape(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    with pytest.raises(ValueError, match=r"ingress_context is required for memory\.supersede"):
        await harness.do_memory_supersede(
            {
                "source": {
                    "origin": "external",
                    "source_id": "doc-1",
                    "extraction_method": "extract",
                },
                "entry_type": "fact",
                "key": "project.note",
                "value": "external fact",
                "supersedes": "entry-1",
            }
        )


@pytest.mark.asyncio
async def test_memory_write_accepts_procedural_install_triple(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="tool_output",
        channel_trust="tool_passed",
        confirmation_status="pep_approved",
        scope="user",
        source_id="tool-install-1",
        content="skill demo v1",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "skill",
            "key": "skill:demo",
            "value": "skill demo v1",
            "invocation_eligible": True,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["invocation_eligible"] is True
    assert entry["source_origin"] == "tool_output"
    assert entry["channel_trust"] == "tool_passed"
    assert entry["confirmation_status"] == "pep_approved"


@pytest.mark.asyncio
async def test_memory_write_rejects_invalid_install_triple_for_procedural_entry(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="auto_accepted",
        scope="user",
        source_id="turn-5",
        content="skill from command channel",
    )

    result = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "skill",
            "key": "skill:command",
            "value": "skill from command channel",
            "invocation_eligible": True,
        }
    )

    assert result["kind"] == "reject"
    assert result["reason"] == "invocation_eligible_requires_install_triple"


@pytest.mark.asyncio
async def test_memory_write_supports_supersedes_chain(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-6",
        content="draft one",
    )
    first = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "note",
            "key": "note:chain",
            "value": "draft one",
        }
    )
    assert first["entry"] is not None

    next_context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-7",
        content="draft two",
    )
    second = await harness.do_memory_write(
        {
            "ingress_context": next_context.handle_id,
            "entry_type": "note",
            "key": "note:chain",
            "value": "draft two",
            "supersedes": first["entry"]["id"],
        }
    )

    assert second["kind"] == "allow"
    assert second["entry"] is not None
    assert second["entry"]["version"] == 2
    assert second["entry"]["supersedes"] == first["entry"]["id"]


@pytest.mark.asyncio
async def test_memory_supersede_impl_reuses_write_path(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-8",
        content="first draft",
    )
    first = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "note",
            "key": "note:supersede-api",
            "value": "first draft",
        }
    )

    assert first["entry"] is not None

    next_context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-9",
        content="second draft",
    )
    second = await harness.do_memory_supersede(
        {
            "ingress_context": next_context.handle_id,
            "entry_type": "note",
            "key": "note:supersede-api",
            "value": "second draft",
            "supersedes": first["entry"]["id"],
        }
    )

    assert second["kind"] == "allow"
    assert second["entry"] is not None
    assert second["entry"]["version"] == 2
    assert second["entry"]["supersedes"] == first["entry"]["id"]
    original = harness._memory_manager.get_entry(str(first["entry"]["id"]), include_deleted=True)
    assert original is not None
    assert original.superseded_by == second["entry"]["id"]


@pytest.mark.asyncio
async def test_memory_set_workflow_state_updates_active_agenda_entry(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-open-thread",
        content="follow up with vendor tomorrow",
    )

    created = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "open_thread",
            "key": "thread:vendor-followup",
            "value": "follow up with vendor tomorrow",
        }
    )

    assert created["entry"] is not None
    entry_id = str(created["entry"]["id"])

    updated = await harness.do_memory_set_workflow_state(
        {
            "entry_id": entry_id,
            "workflow_state": "closed",
        }
    )

    assert updated["changed"] is True
    assert updated["workflow_state"] == "closed"
    entry = harness._memory_manager.get_entry(entry_id)
    assert entry is not None
    assert entry.workflow_state == "closed"
    assert entry.status == "active"


@pytest.mark.asyncio
async def test_memory_quarantine_cycle_preserves_workflow_state_via_impl(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)
    context = harness._memory_ingress_registry.mint(
        source_origin="user_direct",
        channel_trust="command",
        confirmation_status="user_asserted",
        scope="user",
        source_id="turn-waiting-thread",
        content="waiting on customer response",
    )

    created = await harness.do_memory_write(
        {
            "ingress_context": context.handle_id,
            "entry_type": "open_thread",
            "key": "thread:customer-response",
            "value": "waiting on customer response",
            "workflow_state": "waiting",
        }
    )

    assert created["entry"] is not None
    entry_id = str(created["entry"]["id"])

    quarantined = await harness.do_memory_quarantine(
        {
            "entry_id": entry_id,
            "reason": "manual-review",
        }
    )
    restored = await harness.do_memory_unquarantine(
        {
            "entry_id": entry_id,
            "reason": "review-cleared",
        }
    )

    assert quarantined["changed"] is True
    assert restored["changed"] is True
    entry = harness._memory_manager.get_entry(entry_id)
    assert entry is not None
    assert entry.workflow_state == "waiting"
    assert entry.status == "active"


@pytest.mark.asyncio
async def test_memory_write_control_api_path_mints_user_asserted_handle(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_memory_write(
        {
            "_control_api_authenticated_write": True,
            "entry_type": "fact",
            "key": "profile.note",
            "value": "typed directly in CLI",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["channel_trust"] == "command"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["ingress_handle_id"]


@pytest.mark.asyncio
async def test_note_create_control_api_path_mints_user_asserted_handle(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_note_create(
        {
            "_control_api_authenticated_write": True,
            "key": "note:cli",
            "content": "direct note command",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["ingress_handle_id"]


@pytest.mark.asyncio
async def test_note_create_control_api_path_respects_user_confirmed_flag(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_note_create(
        {
            "_control_api_authenticated_write": True,
            "key": "note:confirmed",
            "content": "confirmed note command",
            "user_confirmed": True,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_confirmed"
    assert entry["confirmation_status"] == "user_confirmed"
    assert entry["ingress_handle_id"]


@pytest.mark.asyncio
async def test_note_create_control_api_path_normalizes_null_source_id_to_cli(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_note_create(
        {
            "_control_api_authenticated_write": True,
            "key": "note:null-source",
            "content": "note with explicit null source id",
            "source_id": None,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_id"] == "cli"


@pytest.mark.asyncio
async def test_note_create_legacy_fallback_mints_compat_handle(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_note_create(
        {
            "key": "note:legacy",
            "content": "legacy note path",
            "origin": "user",
            "source_id": "legacy-note-1",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["ingress_handle_id"]


@pytest.mark.asyncio
async def test_todo_create_control_api_path_mints_user_asserted_handle(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_todo_create(
        {
            "_control_api_authenticated_write": True,
            "title": "review queue",
            "details": "",
            "status": "open",
            "due_date": "",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["confirmation_status"] == "user_asserted"
    assert entry["ingress_handle_id"]


@pytest.mark.asyncio
async def test_todo_create_control_api_path_normalizes_null_source_id_to_cli(
    tmp_path: Path,
) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_todo_create(
        {
            "_control_api_authenticated_write": True,
            "title": "todo null source",
            "details": "",
            "status": "open",
            "due_date": "",
            "source_id": None,
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_id"] == "cli"


@pytest.mark.asyncio
async def test_todo_create_legacy_fallback_mints_compat_handle(tmp_path: Path) -> None:
    harness = _MemoryWriteHarness(tmp_path)

    result = await harness.do_todo_create(
        {
            "title": "legacy todo",
            "details": "",
            "status": "open",
            "due_date": "",
            "origin": "user",
            "source_id": "legacy-todo-1",
        }
    )

    assert result["kind"] == "allow"
    entry = result["entry"]
    assert entry is not None
    assert entry["source_origin"] == "user_direct"
    assert entry["ingress_handle_id"]
