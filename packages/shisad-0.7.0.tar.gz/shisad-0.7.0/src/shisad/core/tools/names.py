"""Canonical tool-name helpers.

Runtime and control-plane logic use dotted tool IDs as canonical names.
Legacy underscore/hyphen aliases are translated through this module only.
"""

from __future__ import annotations

import logging

from shisad.core.types import ToolName

logger = logging.getLogger(__name__)
_WARNED_LEGACY_ALIASES: set[str] = set()

# Transitional alias map kept in one place to avoid split classifier/runtime drift.
LEGACY_TOOL_NAME_ALIASES: dict[str, str] = {
    "shell_exec": "shell.exec",
    "shell-exec": "shell.exec",
    "http_request": "http.request",
    "http-request": "http.request",
    "file_read": "file.read",
    "file-read": "file.read",
    "file_write": "file.write",
    "file-write": "file.write",
    "write_file": "file.write",
    "write-file": "file.write",
    "web_search": "web.search",
    "web-search": "web.search",
    "web_fetch": "web.fetch",
    "web-fetch": "web.fetch",
    "browser_navigate": "browser.navigate",
    "browser-navigate": "browser.navigate",
    "browser_read_page": "browser.read_page",
    "browser-read-page": "browser.read_page",
    "browser_screenshot": "browser.screenshot",
    "browser-screenshot": "browser.screenshot",
    "browser_click": "browser.click",
    "browser-click": "browser.click",
    "browser_type_text": "browser.type_text",
    "browser-type-text": "browser.type_text",
    "browser_end_session": "browser.end_session",
    "browser-end-session": "browser.end_session",
    "fs_list": "fs.list",
    "fs-list": "fs.list",
    "fs_read": "fs.read",
    "fs-read": "fs.read",
    "fs_write": "fs.write",
    "fs-write": "fs.write",
    "git_status": "git.status",
    "git-status": "git.status",
    "git_diff": "git.diff",
    "git-diff": "git.diff",
    "git_log": "git.log",
    "git-log": "git.log",
    "realitycheck_search": "realitycheck.search",
    "realitycheck-search": "realitycheck.search",
    "realitycheck_read": "realitycheck.read",
    "realitycheck-read": "realitycheck.read",
    "attachment_ingest": "attachment.ingest",
    "attachment-ingest": "attachment.ingest",
    "evidence_read": "evidence.read",
    "evidence-read": "evidence.read",
    "evidence_promote": "evidence.promote",
    "evidence-promote": "evidence.promote",
    "note_create": "note.create",
    "note-create": "note.create",
    "note_list": "note.list",
    "note-list": "note.list",
    "note_search": "note.search",
    "note-search": "note.search",
    "note_get": "note.get",
    "note-get": "note.get",
    "note_delete": "note.delete",
    "note-delete": "note.delete",
    "note_verify": "note.verify",
    "note-verify": "note.verify",
    "note_export": "note.export",
    "note-export": "note.export",
    "todo_create": "todo.create",
    "todo-create": "todo.create",
    "todo_list": "todo.list",
    "todo-list": "todo.list",
    "todo_complete": "todo.complete",
    "todo-complete": "todo.complete",
    "todo_get": "todo.get",
    "todo-get": "todo.get",
    "todo_delete": "todo.delete",
    "todo-delete": "todo.delete",
    "todo_verify": "todo.verify",
    "todo-verify": "todo.verify",
    "todo_export": "todo.export",
    "todo-export": "todo.export",
    "reminder_create": "reminder.create",
    "reminder-create": "reminder.create",
    "reminder_list": "reminder.list",
    "reminder-list": "reminder.list",
    "message_send": "message.send",
    "message-send": "message.send",
    "task_create": "task.create",
    "task-create": "task.create",
    "task_list": "task.list",
    "task-list": "task.list",
    "task_disable": "task.disable",
    "task-disable": "task.disable",
}


def canonical_tool_name(name: str, *, warn_on_alias: bool = True) -> str:
    """Return canonical dotted tool name for runtime/control-plane use."""
    lowered = name.strip().lower()
    if not lowered:
        return ""
    had_functions_prefix = lowered.startswith("functions.")
    if had_functions_prefix:
        lowered = lowered[len("functions.") :]
        if not lowered:
            return ""
    canonical = LEGACY_TOOL_NAME_ALIASES.get(lowered)
    if canonical is not None:
        if warn_on_alias and not had_functions_prefix and lowered not in _WARNED_LEGACY_ALIASES:
            logger.warning(
                "Legacy tool alias '%s' is deprecated; use '%s' instead.",
                lowered,
                canonical,
            )
            _WARNED_LEGACY_ALIASES.add(lowered)
        return canonical
    return lowered


def canonical_tool_name_typed(name: ToolName | str, *, warn_on_alias: bool = True) -> ToolName:
    """Typed wrapper over :func:`canonical_tool_name`."""
    return ToolName(canonical_tool_name(str(name), warn_on_alias=warn_on_alias))
