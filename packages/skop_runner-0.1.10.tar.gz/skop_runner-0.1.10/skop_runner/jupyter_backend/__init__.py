"""
Jupyter Server backend for kernel management.

This package provides a KernelBackend implementation using Jupyter Server
for kernel lifecycle management and code execution.

Components:
- JupyterBackend: Main backend class implementing KernelBackend protocol
- JupyterServerManager: Jupyter Server subprocess management
- JupyterAPIClient: HTTP REST client for Jupyter Server API
- JupyterKernelWebSocket: WebSocket client for kernel communication
"""

from .backend import JupyterBackend
from .server_manager import JupyterServerManager
from .api_client import JupyterAPIClient
from .ws_client import JupyterKernelWebSocket

__all__ = [
    "JupyterBackend",
    "JupyterServerManager",
    "JupyterAPIClient",
    "JupyterKernelWebSocket",
]
