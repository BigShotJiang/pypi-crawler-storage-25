"""Shared test fixtures."""

import shutil
import sys
from pathlib import Path

import pytest

from skop_runner.mock_backend import MockKernelBackend

# Cross-platform test markers
unix_only = pytest.mark.skipif(
    sys.platform == "win32",
    reason="Unix-only test (signals, permissions, or shell commands)"
)

windows_only = pytest.mark.skipif(
    sys.platform != "win32",
    reason="Windows-only test"
)


def _jupyter_available() -> bool:
    """Check if jupyter command is available (in PATH or in the active venv)."""
    if shutil.which("jupyter") is not None:
        return True
    # Also check the venv's bin directory (not always on PATH when running tests)
    venv_bin = Path(sys.executable).parent / "jupyter"
    return venv_bin.exists()


def pytest_collection_modifyitems(config, items):
    """Skip integration tests when jupyter-server is not installed."""
    if not _jupyter_available():
        skip_integration = pytest.mark.skip(
            reason="jupyter-server not installed (skipping integration tests)"
        )
        for item in items:
            if "integration" in item.keywords:
                item.add_marker(skip_integration)


@pytest.fixture
def mock_backend():
    """Create a MockKernelBackend instance for testing."""
    return MockKernelBackend()


@pytest.fixture
async def initialized_mock_backend():
    """Create an initialized MockKernelBackend instance."""
    backend = MockKernelBackend()
    await backend.initialize()
    yield backend
    await backend.close()
