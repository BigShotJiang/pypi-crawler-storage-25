# PyOdoo

[![Travis CI Build Status](https://img.shields.io/travis/com/muflone/pyodoo/master.svg)](https://www.travis-ci.com/github/muflone/pyodoo)
[![CircleCI Build Status](https://img.shields.io/circleci/project/github/muflone/pyodoo/master.svg)](https://circleci.com/gh/muflone/pyodoo)
[![Python 3.9](https://github.com/muflone/pyodoo/actions/workflows/python-3.9.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.9.yml)
[![Python 3.10](https://github.com/muflone/pyodoo/actions/workflows/python-3.10.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.10.yml)
[![Python 3.11](https://github.com/muflone/pyodoo/actions/workflows/python-3.11.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.11.yml)
[![Python 3.12](https://github.com/muflone/pyodoo/actions/workflows/python-3.12.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.12.yml)
[![Python 3.13](https://github.com/muflone/pyodoo/actions/workflows/python-3.13.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.13.yml)
[![Python 3.14](https://github.com/muflone/pyodoo/actions/workflows/python-3.14.yml/badge.svg)](https://github.com/muflone/pyodoo/actions/workflows/python-3.14.yml)
[![PyPI - Version](https://img.shields.io/pypi/v/PyOdoo.svg)](https://pypi.org/project/PyOdoo/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/PyOdoo.svg)](https://pypi.org/project/PyOdoo/)

**Description:** API for Odoo

**Copyright:** 2021-2026 Fabio Castelli (Muflone) <muflone@muflone.com>

**License:** GPL-3+

**Source code:** https://github.com/muflone/pyodoo

**Documentation:** http://www.muflone.com/pyodoo/

# Description

PyOdoo is an attempt to build a common API to interact with any
[**Odoo**](https://www.odoo.com/) server in order to operate using
its APIs.

Currently the following implementations are provided:
- XML-RPC
- JSON-RPC

# System Requirements

* Python 3.x
* xlrd 2.0.x (https://pypi.org/project/xlrd/)
* requests 2.32.x (https://pypi.org/project/requests/)

# Usage

Please see the **samples** and the **tests** folders for some usage examples.
