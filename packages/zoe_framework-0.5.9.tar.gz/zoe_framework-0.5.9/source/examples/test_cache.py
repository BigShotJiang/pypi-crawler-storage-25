import threading
import time

from zoe_cache.cache_registry import CacheRegistry
from zoe_cache.decorators.cache import cache
from zoe_cache.decorators.invalidates import invalidates

call_count = 0


def reset():
    global call_count
    call_count = 0
    CacheRegistry.clear()


def expect(actual, expected, label):
    status = "✅" if actual == expected else "❌"
    print(f"{status} {label}: {actual} chamadas (esperado: {expected})")


# ════════════════════════════════════════════════
class ProductRepo:
    @cache(ttl=5)
    def get_all(self):
        global call_count
        call_count += 1
        return ["cone", "faixa", "capacete"]

    @cache(ttl=5, by="product_id")
    def get_by_id(self, product_id: str):
        global call_count
        call_count += 1
        return {"id": product_id, "name": f"produto-{product_id}"}

    @cache(ttl=5, by=("brand", "active"))
    def get_by_brand_and_active(self, brand: str, active: bool):
        global call_count
        call_count += 1
        return [f"{brand}-{active}"]

    @cache(ttl=1)  # TTL curto pra teste
    def get_expensive(self):
        global call_count
        call_count += 1
        return "resultado caro"

    @invalidates(get_all, get_by_id)
    def create(self, name: str):
        pass

    @invalidates(get_all, get_by_id, get_by_brand_and_active)
    def delete(self, product_id: str):
        pass

    @invalidates(get_by_id)
    def update(self, product_id: str, name: str):
        pass


repo = ProductRepo()

# ════════════════════════════════════════════════
print("\n══════ BLOCO 1: cache básico sem by ══════")
reset()
repo.get_all()
repo.get_all()
repo.get_all()
expect(call_count, 1, "3 chamadas = 1 miss + 2 hits")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 2: cache com by simples ══════")
reset()
repo.get_by_id("p-001")
repo.get_by_id("p-001")  # hit
repo.get_by_id("p-002")  # miss
repo.get_by_id("p-002")  # hit
repo.get_by_id("p-003")  # miss
expect(call_count, 3, "5 chamadas = 3 ids únicos")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 3: cache com by=tuple ══════")
reset()
repo.get_by_brand_and_active("SHERMAN", True)
repo.get_by_brand_and_active("SHERMAN", True)  # hit
repo.get_by_brand_and_active("SHERMAN", False)  # miss — active diferente
repo.get_by_brand_and_active("3M", True)  # miss — brand diferente
repo.get_by_brand_and_active("3M", True)  # hit
repo.get_by_brand_and_active("SHERMAN", False)  # hit
expect(call_count, 3, "6 chamadas = 3 combinações únicas")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 4: invalidate parcial (update só invalida get_by_id) ══════")
reset()
repo.get_all()  # miss #1
repo.get_by_id("p-001")  # miss #2
repo.get_by_id("p-002")  # miss #3
repo.update("p-001", "novo nome")  # invalida só get_by_id
repo.get_all()  # hit — não foi invalidado
repo.get_by_id("p-001")  # miss #4 — invalidado
repo.get_by_id("p-002")  # miss #5 — invalidado (startswith invalida tudo)
expect(call_count, 5, "update invalida get_by_id mas nao get_all")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 5: delete invalida tudo ══════")
reset()
repo.get_all()
repo.get_by_id("p-001")
repo.get_by_brand_and_active("SHERMAN", True)
repo.delete("p-001")  # invalida get_all, get_by_id, get_by_brand_and_active
repo.get_all()
repo.get_by_id("p-001")
repo.get_by_brand_and_active("SHERMAN", True)
expect(call_count, 6, "delete invalida tudo — 3 miss + 3 miss apos delete")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 6: TTL curto expira ══════")
reset()
repo.get_expensive()  # miss
repo.get_expensive()  # hit
print("  aguardando 2s para TTL expirar...")
time.sleep(2)
repo.get_expensive()  # miss — expirou
repo.get_expensive()  # hit
expect(call_count, 2, "TTL de 1s expira apos 2s")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 7: TTL nao expira antes do tempo ══════")
reset()
repo.get_expensive()  # miss
print("  aguardando 0.5s (TTL=1s, nao deve expirar)...")
time.sleep(0.5)
repo.get_expensive()  # hit — ainda valido
expect(call_count, 1, "TTL de 1s nao expira em 0.5s")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 8: thread safety ══════")
reset()
results = []


def worker():
    for _ in range(10):
        repo.get_all()


threads = [threading.Thread(target=worker) for _ in range(10)]
for t in threads:
    t.start()
for t in threads:
    t.join()

expect(call_count, 1, "100 chamadas concorrentes = exatamente 1 miss")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 9: invalidate duplo nao quebra ══════")
reset()
repo.get_all()  # miss
repo.create("novo")  # invalida
repo.create("novo2")  # invalida dnv — nao deve quebrar com key ja ausente
repo.get_all()  # miss
expect(call_count, 2, "double invalidate nao quebra")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 10: cache independente entre instâncias ══════")
reset()
repo1 = ProductRepo()
repo2 = ProductRepo()
repo1.get_by_id("p-001")  # miss
repo2.get_by_id("p-001")  # hit — mesmo cache (CacheRegistry é global)
repo1.get_by_id("p-002")  # miss
repo2.get_by_id("p-002")  # hit
expect(call_count, 2, "instancias diferentes compartilham o mesmo cache global")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 11: funcao sem self (standalone) ══════")
reset()


@cache(ttl=5, by="order_id")
def get_order(order_id: str):
    global call_count
    call_count += 1
    return {"id": order_id}


@invalidates(get_order)
def delete_order(order_id: str):
    pass


get_order("o-001")
get_order("o-001")  # hit
get_order("o-002")  # miss
delete_order("o-001")
get_order("o-001")  # miss — invalidado
get_order("o-002")  # miss — startswith invalida tudo
expect(call_count, 4, "funcao standalone sem self funciona")

# ════════════════════════════════════════════════
print("\n══════ BLOCO 12: cache retorna None corretamente ══════")
reset()


@cache(ttl=5)
def returns_none():
    global call_count
    call_count += 1
    return None


r1 = returns_none()  # miss — resultado é None
r2 = returns_none()  # deve ser hit mesmo retornando None
r3 = returns_none()  # hit
expect(call_count, 1, "cache funciona quando resultado é None")
assert r1 is None and r2 is None and r3 is None, "❌ valores deveriam ser None"
print("✅ valores None retornados corretamente")
