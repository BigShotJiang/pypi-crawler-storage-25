# Changelog

All notable changes to this project will be documented in this file.

## [0.2.9] - 2026-05-04

### Features

- *(logging)* Default structlog configuration for SDK and notebooks (#26) ([7002d32](https://github.com/mendaml/menda-cli/commit/7002d32d8e6bbd84a9c05c38aea0474df5803f92))

## [0.2.8] - 2026-04-24

### Refactor

- Improve error message formatting in MendaCLIError and update default log level to error ([e47825c](https://github.com/mendaml/menda-cli/commit/e47825c90bb511bb0a03b5bb7d78cd1542819edd))

## [0.2.7] - 2026-04-23

### Features

- [MENDA-627] incorporate feedback from getting started (#23) ([803f3b0](https://github.com/mendaml/menda-cli/commit/803f3b0cfbc486753c47d5d211a3465c08926fe9))

## [0.2.6] - 2026-04-22

### Bug Fixes

- Update menda private artifactory URL in pyproject.toml (#20) ([7f00de0](https://github.com/mendaml/menda-cli/commit/7f00de0a112e5fcacd57e0e5dfa0c55bc71414e9))

## [0.2.4] - 2026-04-21

### Features

- Menda 622 fix device auth login issues (#18) ([59cb101](https://github.com/mendaml/menda-cli/commit/59cb1015bc7535c1bcaa0134b19d05d1ece7b44e))

## [0.2.3] - 2026-04-14

### Features

- Implement fetch_tenant_config and update device authorization flow (#16) ([9c31568](https://github.com/mendaml/menda-cli/commit/9c315689d07f24996928f7ab641e98de1c598b26))

## [0.2.2] - 2026-04-06

### Features

- Add out method do rich (#14) ([281eabf](https://github.com/mendaml/menda-cli/commit/281eabfbb720bcee92dcdef7fa2d089fc3945d8e))

## [0.2.0rc5] - 2026-03-30

### Bug Fixes

- Menda 301 fix issues with keyring onboarding (#9) ([a3c5e36](https://github.com/mendaml/menda-cli/commit/a3c5e36cffdfebe630a111f38583edcce3ce8ca6))

### Features

- Add flags to facilitate auth configuration (#10) ([cdcb902](https://github.com/mendaml/menda-cli/commit/cdcb902f93d6dea912e482e1e4f6ee87602c7aa1))

## [0.2.0rc4] - 2026-03-30

### Features

- Add menda init command for project scaffolding (#7) ([6fa449a](https://github.com/mendaml/menda-cli/commit/6fa449ae99a334ba12d414c800d63660b3fdaa68))

## [0.2.0rc2] - 2026-03-27

### Features

- Add auth missing tests (#3) ([b68b38a](https://github.com/mendaml/menda-cli/commit/b68b38aa4729f58ab0429e8826e5ebca7fdf0170))

## [0.2.0rc1] - 2026-03-27

### Features

- Initial project from cookiecutter template ([99339db](https://github.com/mendaml/menda-cli/commit/99339db6171cefc46fa63890b9c07eeabb75ac5e))
- *(deps)* Update dependencies lock and add missing workflows from template ([e705513](https://github.com/mendaml/menda-cli/commit/e70551395e214d5e12c2f94e97bde3ec12de0047))
- Add example test so that actions don't fail on first template ([2835ca8](https://github.com/mendaml/menda-cli/commit/2835ca8e03e9b1c9866d3aa40bc31341fa6de3db))
- Add auth command subgroup (#1) ([cd20706](https://github.com/mendaml/menda-cli/commit/cd207062631d7a2c2039847f763b061101db0e7c))

