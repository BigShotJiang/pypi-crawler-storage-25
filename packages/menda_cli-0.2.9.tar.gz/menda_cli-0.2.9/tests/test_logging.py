"""Tests for menda.logging configuration and env-var fallbacks."""

import pytest
import structlog
from click.testing import CliRunner

from menda.cli.main import cli
from menda.logging import (
    DEFAULT_LOG_LEVEL,
    MENDA_LOG_LEVEL,
    MENDA_LOG_SHOW_LOCALS,
    MENDA_OUTPUT,
    configure_logging,
)


def _reconfigure(monkeypatch, env: dict):
    """Clear structlog cache and run configure_logging with the given env vars."""
    structlog.reset_defaults()
    for key in (MENDA_LOG_LEVEL, MENDA_OUTPUT, MENDA_LOG_SHOW_LOCALS):
        monkeypatch.delenv(key, raising=False)
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    configure_logging()


def _processor_names() -> list[str]:
    return [type(p).__name__ for p in structlog.get_config()["processors"]]


def _wrapper_class_name() -> str:
    return structlog.get_config()["wrapper_class"].__name__


class TestDefaults:
    def test_default_log_level_is_error(self):
        assert DEFAULT_LOG_LEVEL == "error"

    def test_no_args_uses_error_level(self, monkeypatch):
        _reconfigure(monkeypatch, {})
        assert _wrapper_class_name() == "BoundLoggerFilteringAtError"

    def test_no_args_uses_console_renderer(self, monkeypatch):
        _reconfigure(monkeypatch, {})
        assert "ConsoleRenderer" in _processor_names()
        assert "JSONRenderer" not in _processor_names()

    def test_invalid_log_level_raises(self):
        with pytest.raises(ValueError, match="Invalid log level"):
            configure_logging(log_level="nonsense")


class TestEnvVarFallbacks:
    def test_menda_log_level_sets_level(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_LOG_LEVEL: "debug"})
        # No exception == accepted level

    def test_menda_output_json_enables_json(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_OUTPUT: "json"})

    def test_menda_output_text_uses_console(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_OUTPUT: "text"})

    def test_menda_log_show_locals_true(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_LOG_SHOW_LOCALS: "true"})

    def test_menda_log_show_locals_one(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_LOG_SHOW_LOCALS: "1"})

    def test_menda_log_show_locals_false_by_default(self, monkeypatch):
        _reconfigure(monkeypatch, {})


class TestExplicitArgsOverrideEnvVars:
    def test_explicit_log_level_overrides_env(self, monkeypatch):
        monkeypatch.setenv(MENDA_LOG_LEVEL, "debug")
        structlog.reset_defaults()
        configure_logging(log_level="error")  # explicit should win

    def test_explicit_json_output_overrides_env(self, monkeypatch):
        monkeypatch.setenv(MENDA_OUTPUT, "json")
        structlog.reset_defaults()
        configure_logging(log_level="error", json_output=False)  # explicit False wins

    def test_explicit_show_locals_overrides_env(self, monkeypatch):
        monkeypatch.setenv(MENDA_LOG_SHOW_LOCALS, "true")
        structlog.reset_defaults()
        configure_logging(log_level="error", show_locals=False)  # explicit False wins


class TestNotebookImport:
    """Verify the auto-configure that fires at `import menda` behaves correctly.

    The module-level call is `configure_logging()` (no args), so these tests
    replicate that exact call with various env-var combinations and assert the
    resulting structlog config — the same check a notebook caller would rely on.
    """

    def test_default_import_uses_error_level(self, monkeypatch):
        _reconfigure(monkeypatch, {})
        assert _wrapper_class_name() == "BoundLoggerFilteringAtError"

    def test_default_import_uses_console_renderer(self, monkeypatch):
        _reconfigure(monkeypatch, {})
        assert "ConsoleRenderer" in _processor_names()
        assert "JSONRenderer" not in _processor_names()

    def test_menda_log_level_env_sets_level_at_import(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_LOG_LEVEL: "warning"})
        assert _wrapper_class_name() == "BoundLoggerFilteringAtWarning"

    def test_menda_output_json_switches_to_json_renderer(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_OUTPUT: "json"})
        assert "JSONRenderer" in _processor_names()
        assert "ConsoleRenderer" not in _processor_names()

    def test_menda_output_text_keeps_console_renderer(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_OUTPUT: "text"})
        assert "ConsoleRenderer" in _processor_names()
        assert "JSONRenderer" not in _processor_names()

    def test_debug_level_adds_callsite_processor(self, monkeypatch):
        """Debug level should include CallsiteParameterAdder for source location."""
        _reconfigure(monkeypatch, {MENDA_LOG_LEVEL: "debug"})
        assert "CallsiteParameterAdder" in _processor_names()

    def test_non_debug_level_omits_callsite_processor(self, monkeypatch):
        _reconfigure(monkeypatch, {MENDA_LOG_LEVEL: "info"})
        assert "CallsiteParameterAdder" not in _processor_names()


class TestCLIPrecedence:
    def test_output_text_flag_overrides_menda_output_json(self, monkeypatch):
        """--output text must ignore MENDA_OUTPUT=json."""
        monkeypatch.setenv(MENDA_OUTPUT, "json")
        runner = CliRunner()
        result = runner.invoke(cli, ["--output", "text", "-h"])
        assert result.exit_code == 0

    def test_output_json_flag_overrides_menda_output_text(self, monkeypatch):
        """--output json must work regardless of MENDA_OUTPUT."""
        monkeypatch.setenv(MENDA_OUTPUT, "text")
        runner = CliRunner()
        result = runner.invoke(cli, ["--output", "json", "-h"])
        assert result.exit_code == 0

    def test_menda_output_env_drives_cli_output(self, monkeypatch):
        """MENDA_OUTPUT=json should be picked up by --output when no flag given."""
        monkeypatch.setenv(MENDA_OUTPUT, "json")
        runner = CliRunner(env={MENDA_OUTPUT: "json"})
        result = runner.invoke(cli, ["-h"])
        assert result.exit_code == 0

    def test_log_level_env_drives_cli_log_level(self, monkeypatch):
        """MENDA_LOG_LEVEL should be honoured by --log-level when no flag given."""
        runner = CliRunner(env={MENDA_LOG_LEVEL: "debug"})
        result = runner.invoke(cli, ["-h"])
        assert result.exit_code == 0
