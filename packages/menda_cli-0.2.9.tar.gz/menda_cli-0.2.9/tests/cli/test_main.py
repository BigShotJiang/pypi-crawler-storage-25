"""Tests for the main CLI entry point."""

from click.testing import CliRunner

from menda.cli.main import cli


def test_cli_help():
    """Test that -h flag shows help output."""
    runner = CliRunner()
    result = runner.invoke(cli, ["-h"])
    assert result.exit_code == 0
    assert "menda" in result.output.lower()


def test_cli_version():
    """Test that --version flag works."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0


def test_cli_no_args_shows_help():
    """Test that invoking without args shows help (exit 0 or 2 per Click's no_args_is_help)."""
    runner = CliRunner()
    result = runner.invoke(cli)
    assert result.exit_code in (0, 2)
    assert "Usage" in result.output or "usage" in result.output.lower()


def test_global_flags_accepted():
    """Test that all global flags are accepted."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--log-level", "debug", "--output", "json", "--quiet", "--no-color", "-h"])
    assert result.exit_code == 0


def test_auth_group_exists():
    """Test that the auth command group exists with expected subcommands."""
    runner = CliRunner()
    result = runner.invoke(cli, ["auth", "-h"])
    assert result.exit_code == 0
    assert "configure" in result.output
    assert "login" in result.output
    assert "whoami" in result.output


def test_version_command():
    """Test that version subcommand shows a table with menda-cli as first row."""
    runner = CliRunner()
    result = runner.invoke(cli, ["version"])
    assert result.exit_code == 0
    assert "menda-cli" in result.output


def test_version_command_no_packages_subcommand():
    """Test that the packages group no longer exists."""
    runner = CliRunner()
    result = runner.invoke(cli, ["packages", "list"])
    assert result.exit_code != 0


def test_logo_in_help():
    """Test that the menda logo appears in help output."""
    runner = CliRunner()
    result = runner.invoke(cli, ["-h"])
    assert result.exit_code == 0
    assert "menda" in result.output


def test_init_command_exists() -> None:
    """Test that the init command is registered on the root CLI group."""
    runner = CliRunner()
    result = runner.invoke(cli, ["-h"])
    assert result.exit_code == 0
    assert "init" in result.output
