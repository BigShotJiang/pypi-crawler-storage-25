from collections.abc import Generator
from contextlib import closing
from pathlib import Path
from unittest import mock

import pytest
import structlog
from click.testing import CliRunner

from menda.auth.env import get_auth_env
from menda.cli.main import cli

logger = structlog.get_logger()


class TestConfigureCommand:
    """Test cases for the 'configure' CLI command."""

    @pytest.fixture
    def setup_and_teardown(self, tmpdir: Path) -> Generator[None, None, None]:
        """Set up test environment before each test."""
        self.tmp_path = str(tmpdir / "test_mendacfg")
        auth_env = get_auth_env()
        env = {**auth_env.model_dump(mode="python"), "MENDA_CONFIG_FILE": self.tmp_path}
        self.runner = CliRunner(env=env)
        yield

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_new_profile(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test creating a new profile when it doesn't exist."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://test.example.com"

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'test_profile' created successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with new profile")

        # Verify file content
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://test.example.com" in content, f"Content: {content}"
            assert "auth_type = u2m" in content, f"Content: {content}"
        logger.info("File validated with new profile")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_overwrite_profile")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_existing_profile_overwrite(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_overwrite: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test overwriting an existing profile."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_overwrite.return_value = True
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://updated.example.com"

        # Create initial profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://initial.example.com\n")

        logger.info("Wrote initial profile to file for overwriting test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"], catch_exceptions=False)
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'test_profile' updated successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with overwritten profile")

        # Verify file content updated
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://updated.example.com" in content, f"Content: {content}"
            assert "auth_type = u2m" in content, f"Content: {content}"
        logger.info("File validated with overwritten content")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_overwrite_profile")
    def test_configure_existing_profile_no_overwrite(
        self,
        mock_overwrite: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test not overwriting an existing profile when user declines."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_overwrite.return_value = False

        # Create initial profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://initial.example.com\n")

        logger.info("Wrote initial profile to file for no-overwrite test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"], catch_exceptions=False)
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "Configuration cancelled." in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with no changes")

        # Verify file content remains unchanged
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://initial.example.com" in content, f"Content: {content}"
        logger.info("File validated with unchanged content")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_add_new_profile_with_existing(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test adding a new profile when another profile already exists."""
        # Setup mocks
        mock_profile_name.return_value = "new_profile"
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://new.example.com"

        # Create initial profile with a different name
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[existing_profile]\nhost = https://existing.example.com\n")

        logger.info("Wrote existing profile to file before adding new profile")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'new_profile' created successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with new profile added")

        # Verify file content contains both profiles
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            # Check existing profile is still there
            assert "[existing_profile]" in content, f"Content: {content}"
            assert "host = https://existing.example.com" in content, f"Content: {content}"
            # Check new profile was added
            assert "[new_profile]" in content, f"Content: {content}"
            assert "host = https://new.example.com" in content, f"Content: {content}"
        logger.info("File validated with both existing and new profiles")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_all_u2m_flags_skip_prompts(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """When all three flags are provided for u2m, no prompts are called."""
        result = self.runner.invoke(
            cli,
            [
                "auth",
                "configure",
                "--menda-profile-id",
                "flagged",
                "--auth-type",
                "u2m",
                "--host",
                "https://flag.example.com",
            ],
            catch_exceptions=False,
        )

        assert result.exit_code == 0, f"Output: {result.output}"
        assert "✓ Profile 'flagged' created successfully" in result.output

        mock_profile_name.assert_not_called()
        mock_auth_type.assert_not_called()
        mock_host.assert_not_called()

        with open(self.tmp_path) as f:
            content = f.read()
        assert "[flagged]" in content
        assert "host = https://flag.example.com" in content
        assert "auth_type = u2m" in content

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    @mock.patch("menda.auth.inquirer.prompt_for_client_id")
    @mock.patch("menda.auth.inquirer.prompt_for_client_secret")
    def test_configure_m2m_flags_still_prompts_credentials(
        self,
        mock_client_secret: mock.Mock,
        mock_client_id: mock.Mock,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """When auth-type=m2m flag is provided, client_id/secret are still prompted."""
        mock_client_id.return_value = "my-client-id"
        mock_client_secret.return_value = "my-client-secret"

        result = self.runner.invoke(
            cli,
            [
                "auth",
                "configure",
                "--menda-profile-id",
                "svc",
                "--auth-type",
                "m2m",
                "--host",
                "https://prod.example.com",
            ],
            catch_exceptions=False,
        )

        assert result.exit_code == 0, f"Output: {result.output}"
        assert "✓ Profile 'svc' created successfully" in result.output

        mock_profile_name.assert_not_called()
        mock_auth_type.assert_not_called()
        mock_host.assert_not_called()
        mock_client_id.assert_called_once()
        mock_client_secret.assert_called_once()

        with open(self.tmp_path) as f:
            content = f.read()
        assert "auth_type = m2m" in content
        assert "client_id = my-client-id" in content
        assert "client_secret = my-client-secret" in content

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_partial_flags_prompts_missing_values(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """When only --host is provided, profile name and auth type are still prompted."""
        mock_profile_name.return_value = "prompted_profile"
        mock_auth_type.return_value = "u2m"

        result = self.runner.invoke(
            cli,
            ["auth", "configure", "--host", "https://partial.example.com"],
            catch_exceptions=False,
        )

        assert result.exit_code == 0, f"Output: {result.output}"
        assert "✓ Profile 'prompted_profile' created successfully" in result.output

        mock_profile_name.assert_called_once()
        mock_auth_type.assert_called_once()
        mock_host.assert_not_called()

        with open(self.tmp_path) as f:
            content = f.read()
        assert "host = https://partial.example.com" in content

    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_profile_id_flag_does_not_use_env_var(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """MENDA_PROFILE_ID env var does not pre-fill --menda-profile-id for configure."""
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://env.example.com"

        # Inject MENDA_PROFILE_ID into env — it must NOT silently be used as the profile name
        env = {**self.runner.env, "MENDA_PROFILE_ID": "env_profile"}
        runner_with_env = CliRunner(env=env)

        with mock.patch(
            "menda.auth.inquirer.prompt_for_profile_name", return_value="manually_entered"
        ) as mock_profile_name:
            result = runner_with_env.invoke(cli, ["auth", "configure"], catch_exceptions=False)

        assert result.exit_code == 0, f"Output: {result.output}"
        # Profile name came from the prompt, not from MENDA_PROFILE_ID
        assert "✓ Profile 'manually_entered' created successfully" in result.output
        mock_profile_name.assert_called_once()

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    @mock.patch("menda.auth.inquirer.prompt_for_client_id")
    @mock.patch("menda.auth.inquirer.prompt_for_client_secret")
    def test_configure_new_profile_m2m(
        self,
        mock_client_secret: mock.Mock,
        mock_client_id: mock.Mock,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test creating a new m2m profile when it doesn't exist."""
        mock_profile_name.return_value = "test_profile_m2m"
        mock_auth_type.return_value = "m2m"
        mock_host.return_value = "https://test.example.com"
        mock_client_id.return_value = "client-id-123"
        mock_client_secret.return_value = "client-secret-xyz"

        result = self.runner.invoke(cli, ["auth", "configure"])
        assert result.exit_code == 0, f"Output: {result.output}"
        assert "✓ Profile 'test_profile_m2m' created successfully" in result.output, f"Output: {result.output}"

        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile_m2m]" in content, f"Content: {content}"
            assert "host = https://test.example.com" in content, f"Content: {content}"
            assert "auth_type = m2m" in content, f"Content: {content}"
            assert "client_id = client-id-123" in content, f"Content: {content}"
            assert "client_secret = client-secret-xyz" in content, f"Content: {content}"
