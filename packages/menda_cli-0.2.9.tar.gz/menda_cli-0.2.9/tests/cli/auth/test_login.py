from collections.abc import Generator
from contextlib import closing
from pathlib import Path
from unittest import mock

import pytest
import structlog
from click.testing import CliRunner

from menda.auth.exceptions import AuthenticationError, ProfileNotFoundError
from menda.cli.main import cli

logger = structlog.get_logger(__name__)


class TestLoginCommand:
    """Test cases for the 'login' CLI command."""

    @pytest.fixture
    def setup_and_teardown(self, tmpdir: Path) -> Generator[None, None, None]:
        """Set up test environment before each test."""
        self.runner = CliRunner()
        self.tmp_path = str(tmpdir / "test_mendacfg")

        # Create test config file with a profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://test.example.com\nauth_type = u2m\n")

        # Create patch for environment variables — clear M2M vars to prevent env leakage
        self.env_patcher = mock.patch.dict(
            "os.environ",
            {
                "MENDA_CONFIG_FILE": self.tmp_path,
                "MENDA_PROFILE_ID": "test_profile",
                "MENDA_CLIENT_ID": "",
                "MENDA_CLIENT_SECRET": "",
                "MENDA_HOST": "",
            },
        )
        self.env_mock = self.env_patcher.start()

        yield

        self.env_patcher.stop()

    @mock.patch("menda.auth.oauth2.client.fetch_tenant_config", return_value="test-app-client-id")
    @mock.patch("menda.auth.oauth2.client.authorize_device")
    @mock.patch("menda.auth.oauth2.client.open_browser")
    @mock.patch("menda.auth.oauth2.client.login_with_device")
    @mock.patch("menda.auth.oauth2.token.cache_token")
    @mock.patch("menda.auth.http.requests_session")
    def test_login_success(
        self,
        mock_session: mock.Mock,
        mock_cache_token: mock.Mock,
        mock_login_with_device: mock.Mock,
        mock_open_browser: mock.Mock,
        mock_authorize_device: mock.Mock,
        mock_fetch_tenant_config: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test successful login flow."""
        # Setup mocks
        mock_session_instance = mock.MagicMock()
        mock_session.return_value = mock_session_instance

        # Mock device authentication flow
        device_model = mock.MagicMock()
        device_model.verification_uri_complete = "/device/activate?user_code=ABC123"
        mock_authorize_device.return_value = device_model

        # Mock successful login
        credentials = mock.MagicMock()
        mock_login_with_device.return_value = credentials

        logger.info("Starting login success test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "login", "--menda-profile-id", "test_profile"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Authentication successful" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with authentication")

        # Verify flow
        mock_authorize_device.assert_called_once()
        mock_open_browser.assert_called_once()
        mock_login_with_device.assert_called_once()
        mock_cache_token.assert_called_once_with(credentials=credentials, profile_id="test_profile")
        logger.info("All mocks verified successfully")

    @mock.patch("menda.auth.oauth2.client.fetch_tenant_config", return_value="test-app-client-id")
    @mock.patch("menda.auth.oauth2.client.authorize_device")
    @mock.patch("menda.auth.oauth2.client.open_browser")
    @mock.patch("menda.auth.oauth2.client.login_with_device")
    @mock.patch("menda.auth.http.requests_session")
    def test_login_authentication_error(
        self,
        mock_session: mock.Mock,
        mock_login_with_device: mock.Mock,
        mock_open_browser: mock.Mock,
        mock_authorize_device: mock.Mock,
        mock_fetch_tenant_config: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test login flow with authentication error."""
        # Setup mocks
        mock_session_instance = mock.MagicMock()
        mock_session.return_value = mock_session_instance

        # Mock device authentication flow
        device_model = mock.MagicMock()
        device_model.verification_uri_complete = "/device/activate?user_code=ABC123"
        mock_authorize_device.return_value = device_model

        # Mock authentication error
        mock_login_with_device.side_effect = AuthenticationError(detail="Authentication failed")

        logger.info("Starting login authentication error test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "login", "--menda-profile-id", "test_profile"])

        assert result.exit_code == 1, f"Output: {result.output}"
        assert isinstance(result.exception, AuthenticationError)
        assert "Authentication failed" in str(result.exception)
        logger.info("Command handled authentication error correctly")

    def test_login_invalid_profile(self, setup_and_teardown: pytest.FixtureRequest) -> None:
        """Test login with a non-existent profile."""
        logger.info("Starting login with invalid profile test")

        # Execute CLI command with invalid profile
        result = self.runner.invoke(cli, ["auth", "login", "--menda-profile-id", "non_existent_profile"])

        assert result.exit_code == 1, f"Output: {result.output}"
        assert isinstance(result.exception, ProfileNotFoundError)
        assert "non_existent_profile" in str(result.exception)
        logger.info("Command correctly rejected invalid profile")
