"""Tests for the menda init command."""

from pathlib import Path
from unittest import mock

from click.testing import CliRunner

from menda.cli.main import cli


class TestInitCommandHappyPath:
    def test_all_flags_supplied(self, tmp_path: Path) -> None:
        runner = CliRunner()
        with mock.patch("cookiecutter.main.cookiecutter") as mock_cc:
            result = runner.invoke(
                cli,
                [
                    "init",
                    "my-project",
                    "--provider",
                    "databricks",
                    "--template",
                    "default",
                    "--output-dir",
                    str(tmp_path),
                ],
            )
        assert result.exit_code == 0, result.output
        mock_cc.assert_called_once()
        call_kwargs = mock_cc.call_args
        assert call_kwargs.kwargs["no_input"] is True
        assert call_kwargs.kwargs["output_dir"] == str(tmp_path)
        assert call_kwargs.kwargs["extra_context"]["project_name"] == "my-project"
        assert call_kwargs.kwargs["extra_context"]["project_slug"] == "my_project"

    def test_slug_derived_from_name_with_hyphens(self, tmp_path: Path) -> None:
        runner = CliRunner()
        with mock.patch("cookiecutter.main.cookiecutter"):
            result = runner.invoke(
                cli,
                [
                    "init",
                    "my-cool-project",
                    "--provider",
                    "databricks",
                    "--template",
                    "default",
                    "--output-dir",
                    str(tmp_path),
                ],
            )
        assert result.exit_code == 0, result.output

    def test_success_message_shown(self, tmp_path: Path) -> None:
        runner = CliRunner()
        with mock.patch("cookiecutter.main.cookiecutter"):
            result = runner.invoke(
                cli,
                [
                    "init",
                    "my-project",
                    "--provider",
                    "databricks",
                    "--template",
                    "default",
                    "--output-dir",
                    str(tmp_path),
                ],
            )
        assert "my-project" in result.output

    def test_single_template_skips_template_prompt(self, tmp_path: Path) -> None:
        """When only one template exists for a provider, --template defaults without prompting."""
        runner = CliRunner()
        with (
            mock.patch("cookiecutter.main.cookiecutter"),
            mock.patch("menda.cli.init.commands.prompt_for_template") as mock_prompt,
        ):
            result = runner.invoke(
                cli,
                ["init", "my-project", "--provider", "databricks", "--output-dir", str(tmp_path)],
            )
        assert result.exit_code == 0, result.output
        mock_prompt.assert_not_called()

    def test_prompts_called_when_flags_omitted(self, tmp_path: Path) -> None:
        runner = CliRunner()
        with (
            mock.patch("cookiecutter.main.cookiecutter"),
            mock.patch("menda.cli.init.commands.prompt_for_project_name", return_value="prompted-project") as mock_name,
            mock.patch("menda.cli.init.commands.prompt_for_provider", return_value="databricks") as mock_provider,
        ):
            result = runner.invoke(cli, ["init", "--output-dir", str(tmp_path)])
        assert result.exit_code == 0, result.output
        mock_name.assert_called_once()
        mock_provider.assert_called_once()


class TestInitCommandValidation:
    def test_unknown_provider_raises_error(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", "my-project", "--provider", "nonexistent", "--template", "default", "--output-dir", str(tmp_path)],
        )
        assert result.exit_code != 0
        assert "nonexistent" in str(result.exception)

    def test_unknown_template_raises_error(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            [
                "init",
                "my-project",
                "--provider",
                "databricks",
                "--template",
                "nonexistent",
                "--output-dir",
                str(tmp_path),
            ],
        )
        assert result.exit_code != 0
        assert "nonexistent" in str(result.exception)

    def test_existing_directory_raises_error(self, tmp_path: Path) -> None:
        (tmp_path / "my-project").mkdir()
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", "my-project", "--provider", "databricks", "--template", "default", "--output-dir", str(tmp_path)],
        )
        assert result.exit_code != 0
        assert "already exists" in str(result.exception)

    def test_empty_project_name_raises_error(self, tmp_path: Path) -> None:
        runner = CliRunner()
        with mock.patch("menda.cli.init.commands.prompt_for_project_name", return_value=""):
            result = runner.invoke(
                cli,
                ["init", "--provider", "databricks", "--template", "default", "--output-dir", str(tmp_path)],
            )
        assert result.exit_code != 0

    def test_project_name_with_slash_raises_error(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", "my/project", "--provider", "databricks", "--template", "default", "--output-dir", str(tmp_path)],
        )
        assert result.exit_code != 0
        assert "Invalid project name" in str(result.exception)

    def test_project_name_with_leading_dot_raises_error(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", ".my-project", "--provider", "databricks", "--template", "default", "--output-dir", str(tmp_path)],
        )
        assert result.exit_code != 0
        assert "Invalid project name" in str(result.exception)


class TestInitCommandPartialFailure:
    def test_cleans_up_partial_directory_on_failure(self, tmp_path: Path) -> None:
        partial_dir = tmp_path / "my-project"

        def fake_cookiecutter(*args: object, **kwargs: object) -> None:
            partial_dir.mkdir()
            raise RuntimeError("cookiecutter mid-generation failure")

        runner = CliRunner()
        with mock.patch("cookiecutter.main.cookiecutter", side_effect=fake_cookiecutter):
            result = runner.invoke(
                cli,
                [
                    "init",
                    "my-project",
                    "--provider",
                    "databricks",
                    "--template",
                    "default",
                    "--output-dir",
                    str(tmp_path),
                ],
            )

        assert not partial_dir.exists(), "Partial directory should have been removed"
        assert result.exit_code != 0

    def test_warns_about_cleanup(self, tmp_path: Path) -> None:
        partial_dir = tmp_path / "my-project"

        def fake_cookiecutter(*args: object, **kwargs: object) -> None:
            partial_dir.mkdir()
            raise RuntimeError("cookiecutter mid-generation failure")

        runner = CliRunner()
        with mock.patch("cookiecutter.main.cookiecutter", side_effect=fake_cookiecutter):
            result = runner.invoke(
                cli,
                [
                    "init",
                    "my-project",
                    "--provider",
                    "databricks",
                    "--template",
                    "default",
                    "--output-dir",
                    str(tmp_path),
                ],
            )

        assert "removed" in result.output.lower() or "partial" in result.output.lower()
