"""Tests for template discovery and slug derivation."""

from pathlib import Path

from menda.cli.init.templates import derive_slug, list_providers, list_templates, template_path


class TestListProviders:
    def test_returns_databricks(self) -> None:
        providers = list_providers()
        assert "databricks" in providers

    def test_returns_sorted_list(self) -> None:
        providers = list_providers()
        assert providers == sorted(providers)

    def test_returns_list_of_strings(self) -> None:
        providers = list_providers()
        assert all(isinstance(p, str) for p in providers)


class TestListTemplates:
    def test_databricks_has_default(self) -> None:
        templates = list_templates("databricks")
        assert "default" in templates

    def test_returns_sorted_list(self) -> None:
        templates = list_templates("databricks")
        assert templates == sorted(templates)

    def test_unknown_provider_returns_empty(self) -> None:
        templates = list_templates("nonexistent-provider")
        assert templates == []


class TestTemplatePath:
    def test_yields_real_path(self) -> None:
        with template_path("databricks", "default") as p:
            assert isinstance(p, Path)
            assert p.exists()

    def test_contains_cookiecutter_json(self) -> None:
        with template_path("databricks", "default") as p:
            assert (p / "cookiecutter.json").exists()


class TestDeriveSlug:
    def test_lowercase(self) -> None:
        assert derive_slug("MyProject") == "myproject"

    def test_hyphens_to_underscores(self) -> None:
        assert derive_slug("my-project") == "my_project"

    def test_spaces_to_underscores(self) -> None:
        assert derive_slug("my project") == "my_project"

    def test_combined(self) -> None:
        assert derive_slug("My-Cool Project") == "my_cool_project"

    def test_already_valid(self) -> None:
        assert derive_slug("my_project") == "my_project"
