"""Tests for fetch_tenant_config."""

from unittest.mock import MagicMock, patch

import pytest

from menda.auth.exceptions import AuthenticationError
from menda.auth.oauth2.client import fetch_tenant_config


def _mock_response(status_code: int, json_data: dict | None = None, json_raises: bool = False) -> MagicMock:
    response = MagicMock()
    response.status_code = status_code
    if json_raises:
        response.json.side_effect = ValueError("No JSON")
    else:
        response.json.return_value = json_data
    return response


class TestFetchTenantConfig:
    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_returns_app_client_id_on_success(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(200, {"app_client_id": "abc123", "userpool_id": "us-east-1_xyz"})

        result = fetch_tenant_config(session, "https://acme.cloud.mendaml.com")

        assert result == "abc123"
        mock_config.assert_called_once_with(session=session, hostname="acme.cloud.mendaml.com")

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_raises_on_empty_app_client_id(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(200, {"app_client_id": "", "userpool_id": "us-east-1_xyz"})

        with pytest.raises(AuthenticationError, match="missing app_client_id"):
            fetch_tenant_config(session, "https://acme.cloud.mendaml.com")

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_raises_on_missing_app_client_id(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(200, {"userpool_id": "us-east-1_xyz"})

        with pytest.raises(AuthenticationError, match="missing app_client_id"):
            fetch_tenant_config(session, "https://acme.cloud.mendaml.com")

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_raises_on_non_json_response(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(200, json_raises=True)

        with pytest.raises(AuthenticationError, match="non-JSON response"):
            fetch_tenant_config(session, "http://localhost:3000")

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_raises_on_404(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(
            404, {"detail": "No tenant configuration found for hostname: unknown"}
        )

        with pytest.raises(AuthenticationError, match="No tenant configuration found"):
            fetch_tenant_config(session, "https://unknown.mendaml.com")

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_raises_on_server_error(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(500, {"detail": "Internal Server Error"})

        with pytest.raises(AuthenticationError) as exc_info:
            fetch_tenant_config(session, "https://acme.cloud.mendaml.com")
        assert exc_info.value.code == 500

    @patch("menda.auth.oauth2.client.AuthRoutes.config")
    def test_parses_hostname_from_url(self, mock_config: MagicMock) -> None:
        session = MagicMock()
        mock_config.return_value = _mock_response(200, {"app_client_id": "abc123"})

        fetch_tenant_config(session, "https://acme.cloud.mendaml.com:8443/some/path")

        mock_config.assert_called_once_with(session=session, hostname="acme.cloud.mendaml.com")
