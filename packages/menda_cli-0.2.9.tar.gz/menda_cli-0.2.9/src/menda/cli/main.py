"""Main CLI entry point for menda."""

from importlib.metadata import version as pkg_version

import click
import structlog

from menda.cli.auth.commands import auth
from menda.cli.console import Console, OutputMode
from menda.cli.discovery import discover_packages, get_discovered_packages
from menda.cli.exceptions import MendaCLIError
from menda.cli.init.commands import init
from menda.logging import (
    DEFAULT_LOG_LEVEL,
    MENDA_LOG_LEVEL,
    MENDA_OUTPUT,
    configure_logging,
)

logger = structlog.get_logger()

PACKAGE_LOGO = r"""
                          _
                         | |
 _ __ ___   ___ _ __   __| | __ _
| '_ ` _ \ / _ \ '_ \ / _` |/ _` |
| | | | | |  __/ | | | (_| | (_| |
|_| |_| |_|\___|_| |_|\__,_|\__,_|

"""


class MendaGroup(click.Group):
    """Custom Click group that displays the package logo in help output."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Display logo before standard help."""
        formatter.write(PACKAGE_LOGO)
        super().format_help(ctx, formatter)


@click.group(
    cls=MendaGroup,
    name="menda",
    invoke_without_command=True,
    no_args_is_help=True,
    epilog="Select one of these sub-commands to find more help.",
    context_settings={
        "help_option_names": ["-h", "--help"],
        "token_normalize_func": lambda x: str(x).lower(),
    },
)
@click.option(
    "--log-level",
    type=click.Choice(["debug", "info", "warning", "error", "critical"], case_sensitive=False),
    default=DEFAULT_LOG_LEVEL,
    envvar=MENDA_LOG_LEVEL,
    help="Minimum log level.",
)
@click.option(
    "--output",
    type=click.Choice(["text", "json"]),
    default="text",
    envvar=MENDA_OUTPUT,
    help="Output format.",
)
@click.option("--quiet", is_flag=True, default=False, help="Suppress non-error output.")
@click.option("--no-color", is_flag=True, default=False, help="Disable colored output.")
@click.option("-v", "--verbose", is_flag=True, default=False, help="Shorthand for --log-level debug.")
@click.version_option(package_name="menda-cli")
@click.pass_context
def cli(ctx: click.Context, log_level: str, output: str, quiet: bool, no_color: bool, verbose: bool) -> None:
    """CLI for building, deploying and managing menda data products."""
    effective_log_level = "debug" if verbose else log_level
    # CLI args take precedence over env vars: pass json_output explicitly so
    # MENDA_LOG_TO_JSON cannot override --output. show_locals stays None so
    # MENDA_LOG_SHOW_LOCALS still controls it (no CLI flag for it).
    configure_logging(effective_log_level, json_output=(output == "json"))
    ctx.ensure_object(dict)
    ctx.obj["console"] = Console(
        output=OutputMode(output),
        quiet=quiet,
        no_color=no_color,
    )


# Register built-in commands
cli.add_command(auth)
cli.add_command(init)

# Discover and register package commands at import time so that
# `from menda.cli.main import cli` always has all commands available
# (e.g. in test suites that don't go through safe_main).
discover_packages(cli)


@cli.command("version")
@click.pass_context
def version_cmd(ctx: click.Context) -> None:
    """Show menda-cli and installed package versions."""
    console: Console = ctx.obj["console"]
    cli_version = pkg_version("menda-cli")
    discovered = get_discovered_packages()

    if console.output_mode == OutputMode.JSON:
        console.json([
            {"name": "menda-cli", "version": cli_version, "status": "loaded"},
            *[
                {"name": p.name, "version": p.version, "status": p.status, **({"error": p.error} if p.error else {})}
                for p in discovered
            ],
        ])
    else:
        rows = [["menda-cli", cli_version, "loaded"]]
        for p in discovered:
            row = [p.name, p.version or "unknown", p.status]
            if p.error:
                row.append(p.error)
            rows.append(row)
        headers = (
            ["Name", "Version", "Status", "Error"]
            if any(p.error for p in discovered)
            else ["Name", "Version", "Status"]
        )
        console.table(headers=headers, rows=[r[: len(headers)] for r in rows])


def _is_ipython() -> bool:
    """Return true if running inside an IPython kernel (e.g. Databricks job runtime)."""
    import sys

    return "IPython" in sys.modules


def safe_main() -> None:
    """Entry point with IPython detection, and error handling."""
    console = Console()  # default console for pre-context errors

    if _is_ipython():
        # Non-standalone mode for Databricks/IPython compatibility.
        # Click's sys.exit() conflicts with IPython — catch and re-route.
        try:
            cli(standalone_mode=False)
        except SystemExit as e:
            import sys

            code = e.code
            is_success = code is None or code == 0
            if is_success:
                sys.exit(0)
            else:
                raise
    else:
        try:
            cli(standalone_mode=False)
        except click.exceptions.Exit as e:
            raise SystemExit(e.exit_code) from None
        except click.ClickException as e:
            e.show()
            raise SystemExit(e.exit_code) from None
        except click.Abort:
            console.error("Aborted.")
            raise SystemExit(130) from None
        except MendaCLIError as e:
            console.error(e.format_for_display())
            raise SystemExit(e.exit_code) from None
        except Exception as e:
            console.error(f"Unexpected error: {e}")
            logger.exception("unhandled_error")
            raise SystemExit(1) from None
