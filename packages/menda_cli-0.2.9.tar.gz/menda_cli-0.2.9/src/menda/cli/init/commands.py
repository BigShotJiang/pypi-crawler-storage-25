"""menda init command — scaffold a new menda project from a cookiecutter template."""

import shutil
from pathlib import Path

import click

from menda.cli.console import Console
from menda.cli.exceptions import MendaCLIError, ValidationError
from menda.cli.init.prompts import prompt_for_project_name, prompt_for_provider, prompt_for_template
from menda.cli.init.templates import derive_slug, list_providers, list_templates, template_path


def _validate_project_name(name: str) -> None:
    """Raise ValidationError if project_name is not a safe plain name."""
    if not name or not name.strip():
        raise ValidationError(
            message=f"Invalid project name '{name}'. Use a plain name with no path separators or leading dots.",
            suggestion="Example: 'my-menda-project'",
        )
    if any(sep in name for sep in ("/", "\\")):
        raise ValidationError(
            message=f"Invalid project name '{name}'. Use a plain name with no path separators or leading dots.",
            suggestion="Example: 'my-menda-project'",
        )
    if name.startswith("."):
        raise ValidationError(
            message=f"Invalid project name '{name}'. Use a plain name with no path separators or leading dots.",
            suggestion="Example: 'my-menda-project'",
        )


@click.command("init")
@click.argument("project_name", required=False, default=None)
@click.option("--provider", default=None, help="Provider name (e.g. databricks).")
@click.option("--template", default=None, help="Template variant (e.g. default).")
@click.option(
    "--output-dir",
    default=".",
    type=click.Path(exists=True, file_okay=False),
    help="Directory in which to create the project folder.",
)
@click.pass_context
def init(
    ctx: click.Context,
    project_name: str | None,
    provider: str | None,
    template: str | None,
    output_dir: str,
) -> None:
    """Scaffold a new menda project from a cookiecutter template."""
    from cookiecutter.main import cookiecutter

    console: Console = ctx.obj["console"]

    # ── Collect project_name ──────────────────────────────────────────────
    if not project_name:
        project_name = prompt_for_project_name()
    _validate_project_name(project_name)

    # ── Collect provider ──────────────────────────────────────────────────
    available_providers = list_providers()
    if not provider:
        provider = prompt_for_provider(available_providers)
    if provider not in available_providers:
        raise ValidationError(
            message=f"Unknown provider '{provider}'. Available: {', '.join(available_providers)}.",
        )

    # ── Collect template ──────────────────────────────────────────────────
    available_templates = list_templates(provider)
    if not template:
        if len(available_templates) == 1:
            template = available_templates[0]
        else:
            template = prompt_for_template(provider, available_templates)
    if template not in available_templates:
        raise ValidationError(
            message=f"Unknown template '{template}' for provider '{provider}'. Available: {', '.join(available_templates)}.",
        )

    # ── Validate output directory ─────────────────────────────────────────
    target = Path(output_dir).resolve() / project_name
    if target.exists():
        raise ValidationError(
            message=f"Directory `{target}` already exists. Choose a different name or use --output-dir.",
        )

    # ── Derive slug and run cookiecutter ──────────────────────────────────
    project_slug = derive_slug(project_name)

    with template_path(provider, template) as tmpl:
        try:
            cookiecutter(
                str(tmpl),
                no_input=True,
                output_dir=output_dir,
                extra_context={"project_name": project_name, "project_slug": project_slug},
            )
        except Exception as exc:
            if target.exists():
                shutil.rmtree(target)
                console.warning(f"Partial output at '{target}' was removed.")
            raise MendaCLIError(
                message=f"Failed to generate project '{project_name}': {exc}",
                suggestion="Check the error above and try again.",
            ) from exc

    console.success(f"Project '{project_name}' created.")
    console.info(f"  Location: {target}")
    console.info(f"  Next steps: cd {project_name} && menda auth login")
