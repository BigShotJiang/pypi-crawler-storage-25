"""InquirerPy prompt functions for menda init."""

from InquirerPy import inquirer
from InquirerPy.base.control import Choice


def prompt_for_project_name() -> str:
    """Prompt the user for a project name."""
    return inquirer.text(
        message="Enter a project name:",
    ).execute()


def prompt_for_provider(providers: list[str]) -> str:
    """Prompt the user to select a provider from available options."""
    return inquirer.select(
        message="Select a provider:",
        choices=[Choice(value=p, name=p) for p in providers],
    ).execute()


def prompt_for_template(provider: str, templates: list[str]) -> str:
    """Prompt the user to select a template variant for the chosen provider."""
    return inquirer.select(
        message=f"Select a template for '{provider}':",
        choices=[Choice(value=t, name=t) for t in templates],
    ).execute()
