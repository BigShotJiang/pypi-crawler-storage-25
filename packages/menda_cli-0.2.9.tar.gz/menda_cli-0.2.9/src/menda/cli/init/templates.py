"""Template discovery for menda init."""

from collections.abc import Iterator
from contextlib import contextmanager
from importlib.resources import as_file, files
from pathlib import Path


def list_providers() -> list[str]:
    """Return sorted list of available provider names derived from bundled cookiecutters."""
    cookiecutters_ref = files("menda.cli").joinpath("cookiecutters")
    with as_file(cookiecutters_ref) as cookiecutters_path:
        if not cookiecutters_path.exists():
            return []
        providers = {
            entry.name.split("-", 1)[0]
            for entry in cookiecutters_path.iterdir()
            if entry.is_dir() and "-" in entry.name
        }
    return sorted(providers)


def list_templates(provider: str) -> list[str]:
    """Return sorted list of template variants for a given provider."""
    cookiecutters_ref = files("menda.cli").joinpath("cookiecutters")
    with as_file(cookiecutters_ref) as cookiecutters_path:
        if not cookiecutters_path.exists():
            return []
        prefix = f"{provider}-"
        variants = [
            entry.name[len(prefix) :]
            for entry in cookiecutters_path.iterdir()
            if entry.is_dir() and entry.name.startswith(prefix)
        ]
    return sorted(variants)


@contextmanager
def template_path(provider: str, template: str) -> Iterator[Path]:
    """Yield the filesystem path to the cookiecutter template directory.

    Uses importlib.resources.files() + as_file() so the path is real on disk
    even inside a zip-based install.
    """
    ref = files("menda.cli").joinpath(f"cookiecutters/{provider}-{template}")
    with as_file(ref) as p:
        yield p


def derive_slug(project_name: str) -> str:
    """Derive a Python-safe package name from a project name."""
    return project_name.lower().replace("-", "_").replace(" ", "_")
