"""Auth CLI commands — thin wrappers over menda.auth business logic."""

import click

from menda.cli.console import Console
from menda.cli.params import menda_profile_id


@click.group()
def auth() -> None:
    """Authenticate to Menda Cloud."""


@auth.command("configure")
@click.option("--menda-profile-id", default=None, type=str, help="Profile name to configure.")
@click.option(
    "--auth-type",
    default=None,
    type=click.Choice(["u2m", "m2m"]),
    help="Authentication type.",
)
@click.option("--host", default=None, type=str, help="Menda Cloud host URL (must start with https://).")
@click.pass_context
def configure(ctx: click.Context, menda_profile_id: str | None, auth_type: str | None, host: str | None) -> None:
    """Configure authentication profile for Menda Cloud."""
    from menda.auth.task import configure as do_configure

    console: Console = ctx.obj["console"]
    do_configure(console, profile_id=menda_profile_id, auth_type=auth_type, host=host)


@auth.command("login")
@menda_profile_id
@click.pass_context
def login(ctx: click.Context, menda_profile_id: str | None) -> None:
    """Login to Menda Cloud via device flow."""
    from menda.auth.task import login as do_login

    console: Console = ctx.obj["console"]
    do_login(console, menda_profile_id)


@auth.command("whoami")
@menda_profile_id
@click.pass_context
def whoami(ctx: click.Context, menda_profile_id: str | None) -> None:
    """Show the current authenticated user."""
    from menda.auth.task import whoami as do_whoami

    console: Console = ctx.obj["console"]
    do_whoami(console, menda_profile_id)
