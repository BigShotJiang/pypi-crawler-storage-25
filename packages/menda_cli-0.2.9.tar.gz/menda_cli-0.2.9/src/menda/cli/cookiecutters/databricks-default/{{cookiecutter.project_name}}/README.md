# {{cookiecutter.project_name}}

A menda data product project.

## Getting started

```bash
menda auth login
```
