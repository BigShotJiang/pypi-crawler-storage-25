from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

from menda.logging import configure_logging

configure_logging()
