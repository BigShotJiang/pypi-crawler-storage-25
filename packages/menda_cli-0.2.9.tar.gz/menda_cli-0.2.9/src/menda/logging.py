"""Structured logging configuration for menda packages.

This module lives at menda.logging (top-level namespace) so both
CLI and programmatic consumers can configure logging without importing
the CLI package.

- CLI path: cli() calls configure_logging() with explicit args (overrides env vars below)
- Programmatic path: env vars control behaviour at import time:
    - MENDA_LOG_LEVEL (default: error)
    - MENDA_OUTPUT="json" to emit JSON logs (default: text)
    - MENDA_LOG_SHOW_LOCALS="1"/"true" to include locals in tracebacks
- Explicit override: call configure_logging(...) before instantiating DataProduct
"""

import os

import structlog
from structlog.dev import ConsoleRenderer, RichTracebackFormatter, plain_traceback
from structlog.processors import ExceptionRenderer
from structlog.typing import Processor

DEFAULT_LOG_LEVEL = "error"

MENDA_LOG_LEVEL = "MENDA_LOG_LEVEL"
MENDA_OUTPUT = "MENDA_OUTPUT"
MENDA_LOG_SHOW_LOCALS = "MENDA_LOG_SHOW_LOCALS"


def configure_logging(
    log_level: str | None = None,
    json_output: bool | None = None,
    show_locals: bool | None = None,
) -> None:
    """Configure structlog processors, output format, and level.

    Any argument left as None falls back to its environment variable:
    - log_level: MENDA_LOG_LEVEL (default: error)
    - json_output: MENDA_OUTPUT="json" (default: false)
    - show_locals: MENDA_LOG_SHOW_LOCALS="1"/"true" (default: false)

    Args:
        log_level: Minimum log level (debug, info, warning, error).
        json_output: If True, output logs as JSON.
        show_locals: If True, include local variables in exception tracebacks.

    """
    if log_level is None:
        log_level = os.getenv(MENDA_LOG_LEVEL, DEFAULT_LOG_LEVEL)
    if json_output is None:
        json_output = os.environ.get(MENDA_OUTPUT, "").lower() == "json"
    if show_locals is None:
        show_locals = os.environ.get(MENDA_LOG_SHOW_LOCALS, "").lower() in ("1", "true")

    numeric_level = structlog.stdlib.NAME_TO_LEVEL.get(log_level.lower())
    if numeric_level is None:
        msg = f"Invalid log level: {log_level}"
        raise ValueError(msg)

    shared_processors: list[Processor] = [
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="%Y-%m-%d %H:%M:%S"),
        structlog.contextvars.merge_contextvars,
    ]

    if numeric_level < 20:  # debug level
        shared_processors.append(
            structlog.processors.CallsiteParameterAdder(
                [structlog.processors.CallsiteParameter.MODULE],
                additional_ignores=[__name__],
            ),
        )

    renderers: list[Processor]
    if json_output:
        renderers = [
            ExceptionRenderer(structlog.processors.ExceptionDictTransformer(show_locals=show_locals)),
            structlog.processors.JSONRenderer(),
        ]
    else:
        # structlog's default rich formatter has show_locals=True, which leaks
        # internal state (config values, tokens, etc.) into end-user tracebacks.
        # Opt into a formatter that honors our flag and defaults to off.
        exception_formatter = RichTracebackFormatter(show_locals=True) if show_locals else plain_traceback
        renderers = [
            ConsoleRenderer(
                colors=True,
                exception_formatter=exception_formatter,
                level_styles={
                    "debug": "\033[36m",
                    "info": "\033[32m",
                    "warning": "\033[33m",
                    "error": "\033[31m",
                    "critical": "\033[41m",
                },
            ),
        ]

    structlog.configure(
        processors=[*shared_processors, *renderers],
        cache_logger_on_first_use=True,
        wrapper_class=structlog.make_filtering_bound_logger(min_level=numeric_level),
    )
