"""OAuth2 client — device flow and M2M credentials."""

import time
import typing
import webbrowser
from urllib.parse import urljoin

import requests
import structlog

from menda.auth import exceptions, models
from menda.auth.api import AuthRoutes
from menda.auth.exceptions import AuthenticationError

logger = structlog.get_logger()
SCOPE = ["openid"]
GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
CALLBACK_PATH = "/auth/device/callback"


def fetch_tenant_config(session: requests.Session, host: str) -> str:
    """Fetch app_client_id for the tenant from the config endpoint."""
    from urllib.parse import urlparse

    hostname = urlparse(host).hostname
    if not hostname:
        raise AuthenticationError(detail=f"Invalid host URL: {host}")
    response = AuthRoutes.config(session=session, hostname=hostname)
    try:
        body = response.json()
    except Exception as err:
        raise AuthenticationError(
            code=response.status_code,
            detail=f"Failed to resolve tenant config for '{hostname}': server returned non-JSON response (status {response.status_code})",
        ) from err
    if response.status_code == 200:
        app_client_id = body.get("app_client_id")
        if not app_client_id:
            raise AuthenticationError(
                code=response.status_code,
                detail=f"Tenant config for '{hostname}' is missing app_client_id",
            )
        return app_client_id
    detail = body.get("detail", "Failed to resolve tenant config")
    raise AuthenticationError(code=response.status_code, detail=detail)


def poll_for_token(interval: int, expires_in: int, api: typing.Callable[[], requests.Response]) -> requests.Response:
    """Poll an API endpoint at intervals until success or timeout."""
    deadline = time.time() + expires_in
    logger.debug("Starting device code polling", interval=interval, expires_in=expires_in)
    while True:
        time.sleep(interval)
        response: requests.Response = api()
        logger.debug("Poll response", status_code=response.status_code)
        if response.status_code == 200:
            return response
        detail = response.json().get("detail", "")
        if not is_device_code_in_valid_state(detail):
            return response
        if time.time() >= deadline:
            raise AuthenticationError(code=response.status_code, detail=f"Device code expired: {detail}.")


def is_device_code_in_valid_state(state: str) -> bool:
    """Check if device code state is valid (authorized or pending)."""
    return state in ["authorized", "pending"]


def authorize_device(session: requests.Session, code_challenge: str, client_id: str) -> models.DeviceAuthResponseModel:
    """Request device authorization."""
    response = AuthRoutes.authorize_device(
        session=session, client_id=client_id, scope=SCOPE, code_challenge=code_challenge, code_challenge_method="S256"
    )
    if response and response.status_code == 200:
        return models.DeviceAuthResponseModel(**response.json())
    detail = response.json().get("detail")
    raise AuthenticationError(code=response.status_code, detail=detail)


def open_browser(url: str) -> None:
    """Open the browser to the verification URI."""
    webbrowser.open(url)


def login_with_device(
    session: requests.Session,
    device_model: models.DeviceAuthResponseModel,
    host: str,
    code_verifier: str,
    client_id: str,
) -> models.CredentialsModel:
    """Complete device flow login."""
    response = poll_for_token(
        interval=device_model.interval,
        expires_in=device_model.expires_in,
        api=lambda: AuthRoutes.token(
            session=session,
            client_id=client_id,
            redirect_uri=urljoin(host, CALLBACK_PATH),
            device_code=device_model.device_code,
            grant_type=GRANT_TYPE,
            code_verifier=code_verifier,
        ),
    )
    if response and response.status_code == 200:
        return models.CredentialsModel(**response.json())
    detail = response.json().get("detail")
    raise exceptions.AuthenticationError(code=response.status_code, detail=detail)


def login_with_client_credentials(
    session: requests.Session, *, client_id: str, client_secret: str, scope: str = "api/all"
) -> models.CredentialsModel:
    """Login using OAuth2 client-credentials (M2M)."""
    response = AuthRoutes.oauth2_token(
        session=session, client_id=client_id, client_secret=client_secret, grant_type="client_credentials", scope=scope
    )
    if response and response.status_code == 200:
        return models.CredentialsModel(**response.json())
    detail = response.json().get("detail", "") if response is not None else ""
    raise exceptions.AuthenticationError(code=response.status_code if response is not None else None, detail=detail)
