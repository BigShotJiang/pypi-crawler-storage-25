"""HTTP session factory for auth API calls."""

import typing
from functools import partial
from urllib.parse import urlparse

import requests

from menda.cli.exceptions import NetworkError

API_VERSION = "/api/v1"


class CustomRequestsSession(requests.Session):
    """Requests session with custom methods."""

    def delete_with_payload(self, **kwargs: typing.Any) -> requests.Response:  # noqa: ANN401
        """DELETE with request body support."""
        return self.request(method="DELETE", **kwargs)


def _translate_connection_error(err: requests.exceptions.RequestException, base_url: str) -> NetworkError:
    """Convert a low-level requests exception into a user-friendly NetworkError."""
    host = urlparse(base_url).hostname or base_url

    if isinstance(err, requests.exceptions.SSLError):
        return NetworkError(
            message=f"TLS/SSL handshake failed when contacting '{host}'.",
            context=f"network:ssl:{host}",
            suggestion=(
                "Check that the host URL in your mendacfg profile is correct "
                "and that your system clock and CA certificates are up to date."
            ),
        )

    if isinstance(err, requests.exceptions.ConnectTimeout):
        return NetworkError(
            message=f"Timed out while connecting to '{host}'.",
            context=f"network:timeout:{host}",
            suggestion="Check your network connection or try again in a moment.",
        )

    if isinstance(err, requests.exceptions.ReadTimeout):
        return NetworkError(
            message=f"Timed out while waiting for a response from '{host}'.",
            context=f"network:timeout:{host}",
            suggestion="The service may be slow or unavailable — please try again.",
        )

    if isinstance(err, requests.exceptions.ConnectionError):
        cause = str(err.__cause__) if err.__cause__ else str(err)
        is_dns = "resolve" in cause.lower() or "name or service" in cause.lower() or "nodename" in cause.lower()
        if is_dns:
            return NetworkError(
                message=f"Could not resolve '{host}'.",
                context=f"network:dns:{host}",
                suggestion=(
                    "Check the 'host' value in your mendacfg profile and confirm you have internet connectivity."
                ),
            )
        return NetworkError(
            message=f"Could not connect to '{host}'.",
            context=f"network:connection:{host}",
            suggestion=("Verify the host is reachable and that the 'host' value in your mendacfg profile is correct."),
        )

    return NetworkError(
        message=f"Network error while contacting '{host}': {err}",
        context=f"network:other:{host}",
        suggestion="Check your network connection and profile configuration.",
    )


def requests_session(base_url: str) -> CustomRequestsSession:
    """Create a requests session with a base URL prepended to all requests.

    Connection-layer failures (DNS, TLS, timeouts, refused connections) are
    translated into NetworkError so users see a concise, actionable message
    instead of a requests/urllib3 traceback.
    """

    def new_request(
        base_url: str,
        f: typing.Callable,
        method: str,
        url: str,
        *args: typing.Any,  # noqa: ANN401
        **kwargs: typing.Any,  # noqa: ANN401
    ) -> requests.Response:
        try:
            return f(method, base_url + API_VERSION + url, *args, **kwargs)
        except requests.exceptions.RequestException as err:
            raise _translate_connection_error(err, base_url) from err

    base_url = "" if base_url is None else base_url.rstrip("/")
    s = CustomRequestsSession()
    s.request = partial(new_request, base_url, s.request)  # ty:ignore[invalid-assignment]
    return s
