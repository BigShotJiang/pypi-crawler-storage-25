"""Pydantic models for authentication."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, field_validator


class DeviceAuthResponseModel(BaseModel):
    """RFC8628 device authorization response."""

    model_config = ConfigDict(extra="forbid")

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int
    interval: int


class MendaCloudProfileModel(BaseModel):
    """Menda Cloud profile configuration."""

    model_config = ConfigDict(extra="forbid")

    host: str
    auth_type: Literal["u2m", "m2m"]
    client_id: str | None = None
    client_secret: str | None = None

    @field_validator("host")
    @classmethod
    def host_must_have_scheme(cls, v: str) -> str:
        """Validate that host starts with http:// or https://."""
        if not v.startswith(("https://", "http://")):
            msg = "host must start with 'https://' or 'http://'"
            raise ValueError(msg)
        return v


class CredentialsModel(BaseModel):
    """OAuth2 credentials with optional caching metadata."""

    model_config = ConfigDict(extra="forbid")

    id_token: str = ""
    access_token: str
    refresh_token: str = ""
    expires_in: int
    token_type: str
    cached_at: float | None = None
