from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "{{ cookiecutter.service_name }}"
    port: int = {{ cookiecutter.port }}

    jwt_secret: str = "dev-secret-change-me-please-32-bytes"
    jwt_algorithm: str = "HS256"
    jwt_issuer: str = "{{ cookiecutter.service_name }}"
    jwt_audience: str = "cluster"
    jwt_ttl_seconds: int = 3600

    db_path: str = "{{ cookiecutter.db_path }}"
    identity_service_url: str = "{{ cookiecutter.identity_service_url }}"


settings = Settings()
