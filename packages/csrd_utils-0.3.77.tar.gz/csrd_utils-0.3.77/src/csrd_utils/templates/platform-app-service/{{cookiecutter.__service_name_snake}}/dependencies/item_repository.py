from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends

from csrd.repository import SQLiteAdapter

from ..repositories import ItemRepository
from ..settings import settings


async def item_repository_factory() -> AsyncIterator[ItemRepository]:
    adapter = SQLiteAdapter(settings.db_path)
    await adapter.connect()
    repo = ItemRepository(adapter)
    await repo._init_schema()
    try:
        yield repo
    finally:
        await adapter.close()


ItemRepositoryDep = Annotated[ItemRepository, Depends(item_repository_factory)]

__all__ = ("ItemRepositoryDep", "item_repository_factory")
