# {{ cookiecutter.service_name }}

Platform app service with auth-guarded item endpoints.

Items are persisted in SQLite so this service can share the same DB file
as platform auth and identity services.

## Endpoints

- `GET /health` - liveness probe
- `POST /signup` - passthrough to identity signup (public)
- `POST /login` - passthrough to auth token issue (public)
- `POST /api/items` - create item (bearer required)
- `GET /api/items` - list items (bearer required)
- `GET /api/items/{entity_id}` - get item (bearer required)
- `PUT /api/items/{entity_id}` - update item (bearer required)
- `PUT /api/items/{entity_id}/upsert` - upsert item (bearer required)
- `DELETE /api/items/{entity_id}` - delete item (bearer required)

## Configuration

| Variable | Default | Description |
|---|---|---|
| `DB_PATH` | `{{ cookiecutter.db_path }}` | Shared SQLite database file path |
| `AUTH_SERVICE_URL` | `{{ cookiecutter.auth_service_url }}` | Auth service verify endpoint base URL |
| `IDENTITY_SERVICE_URL` | `{{ cookiecutter.identity_service_url }}` | Identity service base URL for signup passthrough |

## Run

```bash
pip install -r requirements.txt
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```
