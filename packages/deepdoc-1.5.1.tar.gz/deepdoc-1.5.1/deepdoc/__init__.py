"""DeepDoc — Auto-generate beautiful docs from any codebase."""

__version__ = "1.5.1"
