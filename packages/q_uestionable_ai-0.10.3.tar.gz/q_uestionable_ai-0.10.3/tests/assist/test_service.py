"""Tests for the assist service module."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from q_ai.assist.service import (
    AssistantNotConfiguredError,
    _resolve_base_url,
    _resolve_embedding_model,
    _resolve_knowledge_dir,
    _resolve_model_string,
    chat,
    chat_stream,
)


class TestResolveModelString:
    """Model string resolution from config."""

    @patch("q_ai.assist.service.resolve")
    def test_builds_provider_model_string(self, mock_resolve: object) -> None:
        # resolve returns (value, source) tuples
        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "ollama", "db"
            if key == "assist.model":
                return "llama3.1", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "ollama/llama3.1"

    @patch("q_ai.assist.service.resolve")
    def test_strips_duplicate_provider_prefix(self, mock_resolve: object) -> None:
        """Model set via UI already includes provider prefix — no double-prefix."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "anthropic", "db"
            if key == "assist.model":
                return "anthropic/claude-opus-4-6", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "anthropic/claude-opus-4-6"

    @patch("q_ai.assist.service.resolve")
    def test_google_uses_gemini_prefix(self, mock_resolve: object) -> None:
        """Google provider maps to gemini/ litellm prefix."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "google", "db"
            if key == "assist.model":
                return "gemini-2.5-pro", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "gemini/gemini-2.5-pro"

    @patch("q_ai.assist.service.resolve")
    def test_google_ui_model_with_litellm_prefix(self, mock_resolve: object) -> None:
        """Google model set via UI already has gemini/ prefix."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "google", "db"
            if key == "assist.model":
                return "gemini/gemini-2.5-pro", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "gemini/gemini-2.5-pro"

    @patch("q_ai.assist.service.resolve")
    def test_google_stale_db_prefix_corrected(self, mock_resolve: object) -> None:
        """Stale google/ prefix in DB is corrected to gemini/."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "google", "db"
            if key == "assist.model":
                return "google/gemini-2.5-pro", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "gemini/gemini-2.5-pro"

    @patch("q_ai.assist.service.resolve")
    def test_lmstudio_uses_lm_studio_prefix(self, mock_resolve: object) -> None:
        """LM Studio provider maps to lm_studio/ litellm prefix."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "lmstudio", "db"
            if key == "assist.model":
                return "qwen2.5-7b", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_model_string()
        assert result == "lm_studio/qwen2.5-7b"

    @patch("q_ai.assist.service.resolve", return_value=(None, "default"))
    def test_raises_when_not_configured(self, _mock: object) -> None:
        with pytest.raises(AssistantNotConfiguredError, match="not configured"):
            _resolve_model_string()

    @patch("q_ai.assist.service.resolve")
    def test_raises_when_only_provider_set(self, mock_resolve: object) -> None:
        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.provider":
                return "ollama", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        with pytest.raises(AssistantNotConfiguredError):
            _resolve_model_string()


class TestResolveEmbeddingModel:
    """Embedding model resolution."""

    @patch("q_ai.assist.service.resolve", return_value=(None, "default"))
    def test_default_model(self, _mock: object) -> None:
        result = _resolve_embedding_model()
        assert result == "all-MiniLM-L6-v2"

    @patch("q_ai.assist.service.resolve", return_value=("custom-model", "db"))
    def test_custom_model(self, _mock: object) -> None:
        result = _resolve_embedding_model()
        assert result == "custom-model"


class TestResolveKnowledgeDir:
    """Knowledge directory resolution."""

    @patch("q_ai.assist.service.resolve", return_value=(None, "default"))
    def test_default_dir(self, _mock: object) -> None:
        result = _resolve_knowledge_dir()
        assert result.name == "knowledge"
        assert ".qai" in str(result)

    @patch("q_ai.assist.service.resolve", return_value=("/custom/path", "db"))
    def test_custom_dir(self, _mock: object) -> None:
        from pathlib import PurePosixPath

        result = _resolve_knowledge_dir()
        # Compare as PurePosixPath to handle Windows path separator differences
        assert PurePosixPath(str(result).replace("\\", "/")) == PurePosixPath("/custom/path")


class TestResolveBaseUrl:
    """Base URL resolution with provider default fallback."""

    @patch("q_ai.assist.service.resolve")
    def test_explicit_base_url(self, mock_resolve: object) -> None:
        mock_resolve.return_value = ("http://custom:8080", "db")  # type: ignore[attr-defined]
        result = _resolve_base_url()
        assert result == "http://custom:8080"

    @patch("q_ai.assist.service.resolve")
    def test_falls_back_to_provider_default(self, mock_resolve: object) -> None:
        """When assist.base_url is empty, use provider's default_base_url."""

        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.base_url":
                return None, "default"
            if key == "assist.provider":
                return "lmstudio", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_base_url()
        assert result == "http://localhost:1234"

    @patch("q_ai.assist.service.resolve")
    def test_ollama_default_url(self, mock_resolve: object) -> None:
        def side_effect(key: str, **kwargs: object) -> tuple[str | None, str]:
            if key == "assist.base_url":
                return None, "default"
            if key == "assist.provider":
                return "ollama", "db"
            return None, "default"

        mock_resolve.side_effect = side_effect  # type: ignore[attr-defined]
        result = _resolve_base_url()
        assert result == "http://localhost:11434"

    @patch("q_ai.assist.service.resolve", return_value=(None, "default"))
    def test_no_provider_returns_none(self, _mock: object) -> None:
        result = _resolve_base_url()
        assert result is None


class TestAssistantBoundaryCalls:
    """Assistant service boundary usage."""

    async def test_chat_uses_core_litellm_boundary(self) -> None:
        """chat() should delegate completion through the internal LiteLLM boundary."""
        kb = MagicMock()
        messages = [{"role": "user", "content": "hello"}]

        with (
            patch("q_ai.assist.service._resolve_model_string", return_value="ollama/llama3.1"),
            patch("q_ai.assist.service._resolve_credential", return_value="secret"),
            patch("q_ai.assist.service._get_knowledge_base", return_value=kb),
            patch("q_ai.assist.service._prepare_messages", return_value=messages),
            patch("q_ai.assist.service._resolve_base_url", return_value="http://localhost:11434"),
            patch("q_ai.assist.service.complete_text", new_callable=AsyncMock) as mock_complete,
        ):
            mock_complete.return_value = "assistant reply"
            result = await chat("hello", scan_context="{}", history=[], source="web_ui")

        assert result == "assistant reply"
        kb.ensure_indexed.assert_called_once_with()
        mock_complete.assert_awaited_once_with(
            "ollama/llama3.1",
            messages,
            api_base="http://localhost:11434",
            api_key="secret",
        )

    async def test_chat_stream_uses_core_litellm_boundary(self) -> None:
        """chat_stream() should delegate streaming through the internal LiteLLM boundary."""
        kb = MagicMock()
        messages = [{"role": "user", "content": "hello"}]
        call_args: dict[str, object] = {}

        async def fake_stream(
            model: str,
            streamed_messages: list[dict[str, str]],
            *,
            api_base: str | None = None,
            api_key: str | None = None,
            timeout: float = 120.0,
        ) -> object:
            call_args["model"] = model
            call_args["messages"] = streamed_messages
            call_args["api_base"] = api_base
            call_args["api_key"] = api_key
            call_args["timeout"] = timeout
            yield "assistant"
            yield " stream"

        with (
            patch("q_ai.assist.service._resolve_model_string", return_value="openai/gpt-4o"),
            patch("q_ai.assist.service._resolve_credential", return_value="secret"),
            patch("q_ai.assist.service._get_knowledge_base", return_value=kb),
            patch("q_ai.assist.service._prepare_messages", return_value=messages),
            patch("q_ai.assist.service._resolve_base_url", return_value="https://api.example.com"),
            patch("q_ai.assist.service.stream_text", new=fake_stream),
        ):
            result = [token async for token in chat_stream("hello")]

        assert result == ["assistant", " stream"]
        kb.ensure_indexed.assert_called_once_with()
        assert call_args == {
            "model": "openai/gpt-4o",
            "messages": messages,
            "api_base": "https://api.example.com",
            "api_key": "secret",
            "timeout": 120.0,
        }
