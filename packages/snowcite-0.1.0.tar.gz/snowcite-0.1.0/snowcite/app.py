from mcp.server.fastmcp import FastMCP


mcp = FastMCP("snowcite")
