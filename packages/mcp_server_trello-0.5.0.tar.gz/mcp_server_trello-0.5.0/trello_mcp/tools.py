"""Primary Trello MCP tool business functions."""

from __future__ import annotations

import re
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from typing import Any

from fastmcp import FastMCP

from .board_maps import refresh_board_map
from .domain_models import simplify_checklist
from .extended_tools import (
    assign_members,
    batch_get_compact,
    manage_attachments,
    manage_boards,
    manage_cards,
    manage_checklists,
    manage_comments,
    manage_custom_fields,
    manage_labels,
    manage_lists,
)
from .models import (
    card_receipt,
    envelope,
    error,
    simplify_action,
    simplify_board,
    simplify_card,
    simplify_label,
    simplify_list,
    warning,
)
from .raw_tools import trello_delete, trello_get, trello_post, trello_put
from .resolvers import resolve_board, resolve_card, resolve_label, resolve_list
from .trello_client import TrelloAPIError, TrelloClient


mcp = FastMCP("Trello")


def get_version() -> dict[str, Any]:
    """Return the installed mcp-server-trello package version."""
    try:
        ver = _pkg_version("mcp-server-trello")
    except PackageNotFoundError:
        ver = "unknown"
    return envelope("get_version", result={"version": ver})


def open_board(name_or_id: str, client: TrelloClient | None = None) -> dict[str, Any]:
    """Open a board, refresh its board map, and return compact metadata."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(name_or_id, trello)
    except TrelloAPIError as exc:
        return _error_envelope("open_board", exc, name_or_id)
    if opened.get("error"):
        from trello_mcp.resolvers import classify_ref
        kind = classify_ref(name_or_id)
        wrong_tool_envelope = envelope(
            "open_board",
            errors=[error(
                "wrong_tool",
                f"{name_or_id} looks like a {kind.replace('_', ' ')}. Use get_card_context or find_cards.",
                input_ref=name_or_id,
            )],
        )
        if kind == "card_url":
            # URL shape is unambiguous; no verification needed.
            return wrong_tool_envelope
        if kind == "card_short_link":
            # Verify the ref actually resolves as a card before emitting wrong_tool.
            # 8-char alnum could be a real board shortLink that failed for unrelated
            # reasons (auth scope, deleted board, transient).
            try:
                trello.request(f"/cards/{name_or_id}", params={"fields": "id"})
            except TrelloAPIError as exc:
                if exc.code == "not_found":
                    return envelope("open_board", errors=[opened["error"]])
                raise
            return wrong_tool_envelope
        # kind == "card_id" or "unknown" → ambiguous; return the original not_found.
        return envelope("open_board", errors=[opened["error"]])
    return envelope(
        "open_board",
        board=opened["board"],
        result={
            "board": simplify_board(opened["board"]),
            "board_map_status": opened["board_map_status"],
            "board_map": opened["board_map"],
            "lists": [simplify_list(item) for item in opened["lists"]],
            "labels": [simplify_label(item) for item in opened["labels"]],
        },
        warnings=opened["warnings"],
    )


def get_board_snapshot(
    board_id_or_name: str,
    include: str = "summary",
    include_descriptions: bool = False,
    activity_limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact board state."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_board_snapshot", errors=[opened["error"]])
        board = opened["board"]
        lists = opened["lists"]
        labels = opened["labels"]
        result: dict[str, Any] = {
            "board_map_status": opened["board_map_status"],
            "lists": [simplify_list(item) for item in lists],
            "labels": [simplify_label(item) for item in labels],
        }
        include_set = _include_set(include)
        if include_set & {"cards", "all"}:
            cards = trello.request(f"/boards/{board['id']}/cards", params={"filter": "open"})
            list_names = {item.get("id"): item.get("name") for item in lists}
            result["cards"] = [
                simplify_card(
                    card,
                    include_description=include_descriptions,
                    list_name=list_names.get(card.get("idList")),
                    board_map=opened["board_map"],
                )
                for card in cards
            ]
        if include_set & {"activity", "all"}:
            actions = trello.request(
                f"/boards/{board['id']}/actions",
                params={"limit": activity_limit},
            )
            result["activity"] = [simplify_action(action) for action in actions]
        return envelope(
            "get_board_snapshot",
            board=board,
            result=result,
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_board_snapshot", exc, board_id_or_name)


def find_cards(
    board_id_or_name: str,
    query: str,
    filters: dict[str, Any] | None = None,
    limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Search board cards with safe Trello params and local fallback."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("find_cards", errors=[opened["error"]])
        board = opened["board"]
        params: dict[str, Any] = {
            "query": query,
            "modelTypes": "cards",
            "idBoards": board["id"],
        }
        if limit > 0:
            params["cards_limit"] = limit
        try:
            search = trello.request("/search", params=params)
            cards = search.get("cards", []) if isinstance(search, dict) else []
        except TrelloAPIError:
            cards = _local_card_search(trello, board["id"], query, filters)
        list_names = {item.get("id"): item.get("name") for item in opened["lists"]}
        if filters:
            cards = _filter_cards(cards, filters, opened)
        if limit > 0:
            cards = cards[:limit]
        return envelope(
            "find_cards",
            board=board,
            result={
                "cards": [
                    simplify_card(
                        card,
                        list_name=list_names.get(card.get("idList")),
                        board_map=opened["board_map"],
                    )
                    for card in cards
                ],
                "truncated": limit > 0 and len(cards) == limit,
            },
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("find_cards", exc, board_id_or_name)


def get_card_context(
    board_id_or_name: str,
    card: str,
    include: list[str] | None = None,
    activity_limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact card context."""
    trello = client or TrelloClient()
    include = include or []
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_card_context", errors=[opened["error"]])
        board = opened["board"]
        extra_fields = ["desc"] if "description" in include else None
        cards = _board_cards(trello, board["id"], extra_fields=extra_fields)
        found, err = resolve_card(card, cards)
        if err:
            return envelope("get_card_context", board=board, errors=[err])
        list_names = {item.get("id"): item.get("name") for item in opened["lists"]}
        result = {
            "card": simplify_card(
                found,
                include_description="description" in include,
                list_name=list_names.get(found.get("idList")),
                board_map=opened["board_map"],
            )
        }
        if "activity" in include:
            actions = trello.request(
                f"/cards/{found['id']}/actions",
                params={"limit": activity_limit},
            )
            result["activity"] = [simplify_action(action) for action in actions]
        if "comments" in include:
            comments = trello.request(
                f"/cards/{found['id']}/actions",
                params={"filter": "commentCard", "limit": activity_limit},
            )
            result["comments"] = [simplify_action(action) for action in comments]
        if "checklists" in include:
            checklists = trello.request(f"/cards/{found['id']}/checklists")
            result["checklists"] = [simplify_checklist(item) for item in checklists]
        if "list" in include:
            current_list = next(
                (item for item in opened["lists"] if item.get("id") == found.get("idList")),
                None,
            )
            if current_list is not None:
                result["list"] = simplify_list(current_list)
        return envelope(
            "get_card_context",
            board=board,
            result=result,
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_card_context", exc, board_id_or_name)


def get_board_activity(
    board_id_or_name: str,
    limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact recent board activity."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_board_activity", errors=[opened["error"]])
        board = opened["board"]
        actions = trello.request(f"/boards/{board['id']}/actions", params={"limit": limit})
        return envelope(
            "get_board_activity",
            board=board,
            result={"activity": [simplify_action(action) for action in actions]},
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_board_activity", exc, board_id_or_name)


def create_cards(
    board_id_or_name: str,
    list: str,
    cards: list[dict[str, Any]],
    dry_run: bool = False,
    dedupe_by_name: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Create cards in one resolved list."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("create_cards", errors=[context["error"]])
        target_list, list_error = resolve_list(list, context["lists"], context["board_map"])
        if list_error:
            return envelope("create_cards", board=context["board"], errors=[list_error])
        existing_cards = _board_cards(trello, context["board"]["id"])
        board_map = context["board_map"]
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        sub_warnings: list[dict[str, Any]] = []
        for index, spec in enumerate(cards):
            duplicate = _find_exact_card(spec.get("name", ""), target_list["id"], existing_cards)
            if dedupe_by_name and duplicate:
                receipts.append(
                    card_receipt(duplicate, list_name=target_list.get("name"), status="unchanged")
                )
                continue
            labels, label_errors = _resolve_labels(spec.get("labels", []), context)
            draft = {
                "id": None,
                "name": spec.get("name"),
                "idList": target_list["id"],
                "url": None,
                "labels": labels,
            }
            if label_errors:
                receipts.append(
                    card_receipt(draft, list_name=target_list.get("name"), status="failed")
                )
                item_errors.extend(label_errors)
                continue
            checklists_spec = spec.get("checklists") or []
            comments_spec = spec.get("comments") or []
            if dry_run:
                receipt = card_receipt(draft, list_name=target_list.get("name"), status="would_create")
                receipt["would_create_checklists"] = len(checklists_spec)
                receipt["would_create_checklist_items"] = sum(
                    len(cl.get("items") or []) for cl in checklists_spec
                )
                receipt["would_create_comments"] = len(comments_spec)
                receipts.append(receipt)
                continue
            try:
                created = trello.request(
                    "/cards",
                    method="POST",
                    data=_create_card_payload(spec, target_list["id"], labels),
                )
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("create_cards", exc, spec.get("name", str(index)))
                receipts.append(
                    card_receipt(draft, list_name=target_list.get("name"), status="failed")
                )
                item_errors.append(
                    error(exc.code, exc.message, input_ref=spec.get("name"), retryable=exc.retryable)
                )
                continue
            card_id = created.get("id")
            for cl_spec in checklists_spec:
                cl_name = cl_spec.get("name") or ""
                try:
                    checklist = trello.request(
                        "/checklists",
                        method="POST",
                        data={"idCard": card_id, "name": cl_name},
                    )
                except TrelloAPIError as exc:
                    sub_warnings.append(warning(
                        "partial_failure",
                        f"checklist '{cl_name}' failed: {exc.message}",
                        input_ref={"card": card_id, "resource": "checklist", "name": cl_name},
                    ))
                    continue
                cl_id = checklist.get("id")
                for item_name in cl_spec.get("items") or []:
                    try:
                        trello.request(
                            f"/checklists/{cl_id}/checkItems",
                            method="POST",
                            data={"name": item_name},
                        )
                    except TrelloAPIError as exc:
                        sub_warnings.append(warning(
                            "partial_failure",
                            f"checklist_item '{item_name}' failed: {exc.message}",
                            input_ref={"card": card_id, "resource": "checklist_item", "name": item_name},
                        ))
            for comment_text in comments_spec:
                try:
                    trello.request(
                        f"/cards/{card_id}/actions/comments",
                        method="POST",
                        data={"text": comment_text},
                    )
                except TrelloAPIError as exc:
                    sub_warnings.append(warning(
                        "partial_failure",
                        f"comment failed: {exc.message}",
                        input_ref={"card": card_id, "resource": "comment", "name": comment_text[:40]},
                    ))
            receipts.append(
                card_receipt(created, board_map=board_map, list_name=target_list.get("name"), status="created")
            )
        env = _mutation_envelope("create_cards", context, receipts, item_errors, "created")
        if sub_warnings:
            existing = env.get("warnings") or []
            env["warnings"] = [*existing, *sub_warnings]
        return env
    except TrelloAPIError as exc:
        return _error_envelope("create_cards", exc, board_id_or_name)


def update_cards(
    board_id_or_name: str,
    updates: list[dict[str, Any]],
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Update cards. Each update: {card, name?, desc? (alias: description), due?, due_complete?, closed?, pos?, id_list?, id_members?}."""
    from trello_mcp.input_specs import UpdateCardSpec, validate

    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("update_cards", errors=[context["error"]])
        board_map = context["board_map"]
        cards = _board_cards(trello, context["board"]["id"])
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        aliased_summary: dict[str, str] = {}
        ignored_summary: list[dict[str, str]] = []

        for update in updates:
            clean, report = validate(UpdateCardSpec, update)
            aliased_summary.update(report["aliased"])
            for ig in report["ignored"]:
                if ig not in ignored_summary:
                    ignored_summary.append(ig)
            if clean is None:
                code = "invalid_input" if report["missing"] else "no_changes_requested"
                err = error(code, "Validation failed", input_ref=str(update.get("card") or ""))
                if report["missing"]:
                    err["missing"] = report["missing"]
                item_errors.append(err)
                receipts.append(_failed_receipt(update.get("card")))
                continue

            card, card_error = resolve_card(clean["card"], cards)
            if card_error:
                item_errors.append(card_error)
                receipts.append(_failed_receipt(clean["card"]))
                continue

            if dry_run:
                receipts.append(card_receipt(card, board_map=board_map, list_name=_list_name(card, context), status="would_change"))
                continue

            try:
                put_body = _to_trello_card_payload(clean)
                updated = trello.request(f"/cards/{card['id']}", method="PUT", data=put_body) if put_body else card
                receipts.append(card_receipt(updated, board_map=board_map, list_name=_list_name(updated, context), status="changed"))
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("update_cards", exc, clean["card"])
                receipts.append(card_receipt(card, board_map=board_map, list_name=_list_name(card, context), status="failed"))
                item_errors.append(error(exc.code, exc.message, input_ref=clean["card"], retryable=exc.retryable))

        env = _mutation_envelope("update_cards", context, receipts, item_errors, "changed")
        if aliased_summary or ignored_summary:
            env["fields_summary"] = {"aliased": aliased_summary, "ignored": ignored_summary}
        return env
    except TrelloAPIError as exc:
        return _error_envelope("update_cards", exc, board_id_or_name)


def move_cards(
    board_id_or_name: str,
    moves: list[dict[str, Any]],
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Move cards. Each move: {card, to_list (alias: list, target_list), pos?}."""
    from trello_mcp.input_specs import MoveCardSpec, validate

    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("move_cards", errors=[context["error"]])
        board_map = context["board_map"]
        cards = _board_cards(trello, context["board"]["id"])
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        aliased_summary: dict[str, str] = {}
        ignored_summary: list[dict[str, str]] = []

        for move in moves:
            clean, report = validate(MoveCardSpec, move)
            aliased_summary.update(report["aliased"])
            for ig in report["ignored"]:
                if ig not in ignored_summary:
                    ignored_summary.append(ig)
            if clean is None:
                if report["missing"]:
                    item_errors.append(error(
                        "invalid_input",
                        f"Missing required fields: {', '.join(report['missing'])}",
                        input_ref=str(move.get("card") or ""),
                        candidates=[],
                    ) | {"missing": report["missing"]})
                else:
                    item_errors.append(error(
                        "no_changes_requested",
                        "No mutable fields supplied",
                        input_ref=str(move.get("card") or ""),
                    ))
                receipts.append(_failed_receipt(move.get("card")))
                continue

            card, card_error = resolve_card(clean["card"], cards)
            target_list, list_error = resolve_list(clean["to_list"], context["lists"], board_map)
            if card_error and list_error:
                item_errors.append(card_error)
                receipts.append(_failed_receipt(clean["card"]))
                continue
            if card_error or list_error:
                err = error(
                    "partial_resolution",
                    f"{'list' if list_error else 'card'} failed to resolve",
                    input_ref={"card": clean["card"], "to_list": clean["to_list"]},
                )
                err["resolved"] = {}
                if not card_error:
                    err["resolved"]["card"] = {"id": card["id"], "name": card.get("name")}
                if not list_error:
                    err["resolved"]["to_list"] = {"id": target_list["id"], "name": target_list.get("name")}
                err["missing"] = ["to_list"] if list_error else ["card"]
                item_errors.append(err)
                receipts.append(_failed_receipt(clean["card"]))
                continue

            if card.get("idList") == target_list["id"] and "pos" not in clean:
                receipts.append(card_receipt(card, board_map=board_map, list_name=target_list.get("name"), status="unchanged"))
                continue
            if dry_run:
                draft = dict(card, idList=target_list["id"])
                receipts.append(card_receipt(draft, board_map=board_map, list_name=target_list.get("name"), status="would_change"))
                continue
            try:
                put_body: dict[str, Any] = {"idList": target_list["id"]}
                if "pos" in clean:
                    put_body["pos"] = clean["pos"]
                moved = trello.request(f"/cards/{card['id']}", method="PUT", data=put_body)
                receipts.append(card_receipt(moved, board_map=board_map, list_name=target_list.get("name"), status="changed"))
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("move_cards", exc, clean["card"])
                receipts.append(card_receipt(card, board_map=board_map, list_name=_list_name(card, context), status="failed"))
                item_errors.append(error(exc.code, exc.message, input_ref=clean["card"], retryable=exc.retryable))

        env = _mutation_envelope("move_cards", context, receipts, item_errors, "changed")
        if aliased_summary or ignored_summary:
            env["fields_summary"] = {"aliased": aliased_summary, "ignored": ignored_summary}
        return env
    except TrelloAPIError as exc:
        return _error_envelope("move_cards", exc, board_id_or_name)


def label_cards(
    board_id_or_name: str,
    card_refs: list[str] | None = None,
    query: str | None = None,
    add: list[str] | None = None,
    remove: list[str] | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Label cards. Provide card_refs or query. add/remove take label names or IDs."""
    from trello_mcp.input_specs import LabelCardOp, validate

    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("label_cards", errors=[context["error"]])
        board_map = context["board_map"]
        cards = _board_cards(trello, context["board"]["id"])

        clean, report = validate(LabelCardOp, {
            "card_refs": card_refs,
            "query": query,
            "add": add,
            "remove": remove,
        })
        if clean is None:
            code = "invalid_input" if report["missing"] else "no_changes_requested"
            err = error(code, "Validation failed")
            if report["missing"]:
                err["missing"] = report["missing"]
            return envelope("label_cards", errors=[err])

        targets, target_errors = _target_cards(cards, clean.get("card_refs"), clean.get("query"))
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        for failed_ref, failed_error in target_errors:
            receipts.append(_failed_receipt(failed_ref))
            item_errors.append(failed_error)

        # Hoisted resolution (spec §9.3): both add and remove resolved pre-loop.
        add_labels, add_errors = _resolve_labels(clean.get("add") or [], context)
        remove_labels, remove_errors = _resolve_labels(clean.get("remove") or [], context)
        item_errors.extend(add_errors)
        item_errors.extend(remove_errors)

        # Guard: input had refs but everything failed to resolve.
        if (clean.get("add") or clean.get("remove")) and not add_labels and not remove_labels:
            return envelope("label_cards", errors=[error("no_changes_requested", "No labels resolved")] + item_errors)

        for target_ref, target in targets:
            already_has_all = add_labels and all(label["id"] in target.get("idLabels", []) for label in add_labels)
            no_remove_to_apply = (not remove_labels) or all(label["id"] not in target.get("idLabels", []) for label in remove_labels)
            if already_has_all and no_remove_to_apply:
                receipts.append(card_receipt(target, board_map=board_map, list_name=_list_name(target, context), status="unchanged"))
                continue
            if dry_run:
                receipts.append(card_receipt(target, board_map=board_map, list_name=_list_name(target, context), status="would_change"))
                continue
            try:
                latest = target
                for label in add_labels:
                    latest_resp = trello.request(
                        f"/cards/{target['id']}/idLabels",
                        method="POST",
                        data={"value": label["id"]},
                    )
                    if isinstance(latest_resp, list):
                        ids = [item["id"] if isinstance(item, dict) else item for item in latest_resp]
                        latest = dict(latest, idLabels=ids)
                    elif isinstance(latest_resp, dict):
                        merge_keys = ("id", "name", "idList", "idLabels", "idMembers", "due", "dueComplete", "closed", "dateLastActivity", "shortLink")
                        merged = dict(latest)
                        for key in merge_keys:
                            if key in latest_resp:
                                merged[key] = latest_resp[key]
                        current = list(merged.get("idLabels", []))
                        if label["id"] not in current:
                            current.append(label["id"])
                        merged["idLabels"] = current
                        latest = merged
                    else:
                        current = list(latest.get("idLabels", []))
                        if label["id"] not in current:
                            current.append(label["id"])
                        latest = dict(latest, idLabels=current)
                for label in remove_labels:
                    latest_resp = trello.request(
                        f"/cards/{target['id']}/idLabels/{label['id']}",
                        method="DELETE",
                    )
                    if isinstance(latest_resp, list):
                        ids = [item["id"] if isinstance(item, dict) else item for item in latest_resp]
                        latest = dict(latest, idLabels=ids)
                    elif isinstance(latest_resp, dict):
                        merge_keys = ("id", "name", "idList", "idLabels", "idMembers", "due", "dueComplete", "closed", "dateLastActivity", "shortLink")
                        merged = dict(latest)
                        for key in merge_keys:
                            if key in latest_resp:
                                merged[key] = latest_resp[key]
                        current = list(merged.get("idLabels", []))
                        if label["id"] in current:
                            current.remove(label["id"])
                        merged["idLabels"] = current
                        latest = merged
                    else:
                        current = list(latest.get("idLabels", []))
                        if label["id"] in current:
                            current.remove(label["id"])
                        latest = dict(latest, idLabels=current)
                receipts.append(card_receipt(latest, board_map=board_map, list_name=_list_name(target, context), status="changed"))
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("label_cards", exc, target_ref)
                receipts.append(card_receipt(target, board_map=board_map, list_name=_list_name(target, context), status="failed"))
                item_errors.append(error(exc.code, exc.message, input_ref=target.get("name"), retryable=exc.retryable))

        return _mutation_envelope("label_cards", context, receipts, item_errors, "changed")
    except TrelloAPIError as exc:
        return _error_envelope("label_cards", exc, board_id_or_name)


def comment_on_card(
    board_id_or_name: str,
    card: str,
    text: str,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Add a comment to a card."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("comment_on_card", errors=[context["error"]])
        cards = _board_cards(trello, context["board"]["id"])
        found, card_error = resolve_card(card, cards)
        if card_error:
            return envelope("comment_on_card", board=context["board"], errors=[card_error])
        trello.request(
            f"/cards/{found['id']}/actions/comments",
            method="POST",
            data={"text": text},
        )
        return envelope(
            "comment_on_card",
            board=context["board"],
            result={"commented": 1, "card": card_receipt(found, list_name=_list_name(found, context), status="changed")},
            warnings=context["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("comment_on_card", exc, card)


def _open_board_data(name_or_id: str, trello: TrelloClient) -> dict[str, Any]:
    boards = _candidate_boards(name_or_id, trello)
    board, err = resolve_board(name_or_id, boards)
    if err:
        return {"error": err}
    lists = trello.request(f"/boards/{board['id']}/lists")
    labels = trello.request(f"/boards/{board['id']}/labels")
    board_map, status, warnings = refresh_board_map(board, lists, labels)
    return {
        "board": board,
        "lists": lists,
        "labels": labels,
        "board_map": board_map,
        "board_map_status": status,
        "warnings": warnings,
    }


def _mutation_context(board_id_or_name: str, trello: TrelloClient) -> dict[str, Any]:
    return _open_board_data(board_id_or_name, trello)


def _board_cards(
    trello: TrelloClient,
    board_id: str,
    extra_fields: list[str] | None = None,
) -> list[dict[str, Any]]:
    base = "name,idList,idLabels,idMembers,due,dueComplete,closed,dateLastActivity,url,shortLink,shortUrl,labels"
    fields = f"{base},{','.join(extra_fields)}" if extra_fields else base
    return trello.request(
        f"/boards/{board_id}/cards",
        params={"filter": "open", "fields": fields},
    )


def _find_exact_card(name: str, list_id: str, cards: list[dict[str, Any]]) -> dict[str, Any] | None:
    for card in cards:
        if card.get("name") == name and card.get("idList") == list_id and not card.get("closed"):
            return card
    return None


def _create_card_payload(
    spec: dict[str, Any], list_id: str, labels: list[dict[str, Any]]
) -> dict[str, Any]:
    payload = {"idList": list_id, "name": spec.get("name")}
    if spec.get("desc"):
        payload["desc"] = spec["desc"]
    if spec.get("due"):
        payload["due"] = spec["due"]
    if labels:
        payload["idLabels"] = ",".join(label["id"] for label in labels)
    return payload


def _resolve_labels(
    refs: list[str], context: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    labels = []
    errors = []
    for ref in refs:
        label, label_error = resolve_label(ref, context["labels"], context["board_map"])
        if label_error:
            errors.append(label_error)
        else:
            labels.append(label)
    return labels, errors


_TO_TRELLO_KEYS = {
    "name": "name",
    "desc": "desc",
    "due": "due",
    "due_complete": "dueComplete",
    "closed": "closed",
    "pos": "pos",
    "id_list": "idList",
    "id_members": "idMembers",
}


def _to_trello_card_payload(canonical: dict[str, Any]) -> dict[str, Any]:
    """Map canonical UpdateCardSpec fields to the Trello PUT body."""
    return {
        _TO_TRELLO_KEYS[k]: v
        for k, v in canonical.items()
        if k in _TO_TRELLO_KEYS
    }


def _target_cards(
    cards: list[dict[str, Any]], refs: list[str] | None, query: str | None
) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, dict[str, Any]]]]:
    if refs:
        targets = []
        errors = []
        for ref in refs:
            card, card_error = resolve_card(ref, cards)
            if card_error:
                errors.append((ref, card_error))
            else:
                targets.append((ref, card))
        return targets, errors
    if query:
        query_lower = query.lower()
        return [
            (card.get("name") or card.get("id"), card)
            for card in cards
            if query_lower in card.get("name", "").lower()
        ], []
    return [], []


def _list_name(card: dict[str, Any], context: dict[str, Any]) -> str | None:
    list_id = card.get("idList") or card.get("list_id")
    for item in context["lists"]:
        if item.get("id") == list_id:
            return item.get("name")
    return None


def _failed_receipt(input_ref: Any) -> dict[str, Any]:
    """Sentinel receipt for a card we never resolved or successfully mutated."""
    return {
        "id": None,
        "name": input_ref,
        "list_id": None,
        "list_name": None,
        "status": "failed",
    }


def _mutation_envelope(
    tool: str,
    context: dict[str, Any],
    receipts: list[dict[str, Any]],
    item_errors: list[dict[str, Any]],
    changed_status: str,
) -> dict[str, Any]:
    changed = sum(1 for receipt in receipts if receipt["status"] in {changed_status, "created", "changed"})
    unchanged = sum(1 for receipt in receipts if receipt["status"] == "unchanged")
    failed = sum(1 for receipt in receipts if receipt["status"] == "failed")
    would_create = sum(1 for receipt in receipts if receipt["status"] == "would_create")
    would_change = sum(1 for receipt in receipts if receipt["status"] == "would_change")
    result = {
        "changed": changed,
        "created": sum(1 for receipt in receipts if receipt["status"] == "created"),
        "unchanged": unchanged,
        "failed": failed,
        "would_create": would_create,
        "would_change": would_change,
        "cards": receipts,
    }
    errors = []
    if failed and (changed or result["created"] or unchanged or would_create or would_change):
        errors.append(error("partial_failure", "Some items failed", retryable=False))
    errors.extend(item_errors)
    return envelope(
        tool,
        board=context["board"],
        result=result,
        warnings=context["warnings"],
        errors=errors,
    )


def _is_batch_stopping_error(exc: TrelloAPIError) -> bool:
    return exc.code in {"trello_auth_error", "trello_rate_limited"}


def _candidate_boards(name_or_id: str, trello: TrelloClient) -> list[dict[str, Any]]:
    if name_or_id.startswith("http"):
        return trello.request("/members/me/boards")
    # Direct /boards/<ref> works for 24-char hex IDs AND 8-char base62 board
    # shortLinks (e.g. TJYrvblV from a board URL). Without this branch the
    # request falls through to /search → name miss → classify_ref → wrong_tool
    # for what is actually a real board reference.
    if _looks_like_trello_id(name_or_id) or _looks_like_short_link(name_or_id):
        try:
            # Request shortLink explicitly so resolve_board can match against
            # an 8-char shortLink ref. Trello's /boards/<id> default response
            # omits shortLink in some configurations; the extra param is cheap.
            return [trello.request(
                f"/boards/{name_or_id}",
                params={"fields": "name,url,shortUrl,shortLink,closed,idOrganization"},
            )]
        except TrelloAPIError as exc:
            if exc.code != "not_found":
                raise
    try:
        result = trello.request(
            "/search",
            params={"query": name_or_id, "modelTypes": "boards", "boards_limit": 10},
        )
        boards = result.get("boards", []) if isinstance(result, dict) else []
        if boards:
            return boards
    except TrelloAPIError as exc:
        if exc.code != "trello_bad_request":
            raise
    return trello.request("/members/me/boards")


def _local_card_search(
    trello: TrelloClient,
    board_id: str,
    query: str,
    filters: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    cards = trello.request(f"/boards/{board_id}/cards", params={"filter": "open"})
    query_lower = query.lower()
    matches = [card for card in cards if query_lower in card.get("name", "").lower()]
    return _filter_cards(matches, filters or {}, {})


def _filter_cards(
    cards: list[dict[str, Any]],
    filters: dict[str, Any],
    opened: dict[str, Any],
) -> list[dict[str, Any]]:
    filtered = cards
    state = filters.get("state")
    if state == "open":
        filtered = [card for card in filtered if not card.get("closed")]
    elif state == "archived":
        filtered = [card for card in filtered if card.get("closed")]
    return filtered


def _include_set(include: str) -> set[str]:
    return {item.strip() for item in include.split(",") if item.strip()} or {"summary"}


def _looks_like_trello_id(value: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{8,}", value))


def _looks_like_short_link(value: str) -> bool:
    """8-char base62 — used by Trello for both card and board shortLinks."""
    return bool(re.fullmatch(r"[A-Za-z0-9]{8}", value))


def _error_envelope(tool: str, exc: TrelloAPIError, input_ref: str) -> dict[str, Any]:
    return envelope(
        tool,
        errors=[
            error(
                exc.code,
                exc.message,
                input_ref=input_ref,
                retryable=exc.retryable,
            )
        ],
    )


def _register_tools() -> None:
    @mcp.tool(name="get_version")
    def _mcp_get_version() -> dict[str, Any]:
        """Return the installed mcp-server-trello version. Call only on demand; not part of normal workflows."""
        return get_version()

    @mcp.tool(name="open_board")
    def _mcp_open_board(name_or_id: str) -> dict[str, Any]:
        """Open a board by name or ID. Refreshes the board map and returns {board, board_map_status, board_map, lists, labels}."""
        return open_board(name_or_id)

    @mcp.tool(name="get_board_snapshot")
    def _mcp_get_board_snapshot(
        board_id_or_name: str,
        include: str = "summary",
        include_descriptions: bool = False,
        activity_limit: int = 10,
    ) -> dict[str, Any]:
        """Compact board snapshot. include: "summary" (default), "cards", "all". include_descriptions and activity_limit inflate tokens; raise only when needed."""
        return get_board_snapshot(
            board_id_or_name,
            include=include,
            include_descriptions=include_descriptions,
            activity_limit=activity_limit,
        )

    @mcp.tool(name="find_cards")
    def _mcp_find_cards(
        board_id_or_name: str,
        query: str,
        filters: dict[str, Any] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Search cards on a board (query required). filters: {list, label, member} narrow results. limit caps tokens. Returns {cards, truncated} with hydrated label names."""
        return find_cards(board_id_or_name, query, filters=filters, limit=limit)

    @mcp.tool(name="get_card_context")
    def _mcp_get_card_context(
        board_id_or_name: str,
        card: str,
        include: list[str] | None = None,
        activity_limit: int = 10,
    ) -> dict[str, Any]:
        """Compact context for one card (ID/URL/name). Each include adds a fetch: "description", "comments", "checklists", "activity", "list". Pick only what you need."""
        return get_card_context(
            board_id_or_name,
            card,
            include=include,
            activity_limit=activity_limit,
        )

    @mcp.tool(name="get_board_activity")
    def _mcp_get_board_activity(board_id_or_name: str, limit: int = 10) -> dict[str, Any]:
        """Recent compact actions for a board. limit caps tokens (default 10)."""
        return get_board_activity(board_id_or_name, limit=limit)

    @mcp.tool(name="create_cards")
    def _mcp_create_cards(
        board_id_or_name: str,
        list: str,
        cards: list[dict[str, Any]],
        dry_run: bool = False,
        dedupe_by_name: bool = False,
    ) -> dict[str, Any]:
        """Create cards in one resolved list. Each spec: {name, desc?, labels?, pos?, due?}. dedupe_by_name skips existing names; dry_run previews without writes."""
        return create_cards(
            board_id_or_name,
            list,
            cards,
            dry_run=dry_run,
            dedupe_by_name=dedupe_by_name,
        )

    @mcp.tool(name="update_cards")
    def _mcp_update_cards(
        board_id_or_name: str,
        updates: list[dict[str, Any]],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Update cards. Each: {card, name?, desc? (alias: description), due?, due_complete?, closed?, pos?}. Returns per-card status + envelope-level fields_summary."""
        return update_cards(board_id_or_name, updates, dry_run=dry_run)

    @mcp.tool(name="move_cards")
    def _mcp_move_cards(
        board_id_or_name: str,
        moves: list[dict[str, Any]],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Move cards. Each: {card, to_list (alias: list, target_list, destination), pos?}. Returns per-card status; emits partial_resolution if only one ref resolves."""
        return move_cards(board_id_or_name, moves, dry_run=dry_run)

    @mcp.tool(name="label_cards")
    def _mcp_label_cards(
        board_id_or_name: str,
        card_refs: list[str] | None = None,
        query: str | None = None,
        add: list[str] | None = None,
        remove: list[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Label cards. Provide card_refs OR query (same syntax as find_cards). add/remove take label names or IDs. Returns per-card status + fields_summary."""
        return label_cards(
            board_id_or_name,
            card_refs=card_refs,
            query=query,
            add=add,
            remove=remove,
            dry_run=dry_run,
        )

    @mcp.tool(name="comment_on_card")
    def _mcp_comment_on_card(board_id_or_name: str, card: str, text: str) -> dict[str, Any]:
        """Add a comment to a card (ID/URL/name). text required. Returns {commented, card} envelope."""
        return comment_on_card(board_id_or_name, card, text)

    @mcp.tool(name="manage_boards")
    def _mcp_manage_boards(
        operation: str,
        board_id_or_name: str | None = None,
        name: str | None = None,
        desc: str = "",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """List, get, or create Trello boards. operation: "list" (no args), "get" (board_id_or_name), "create" (name, desc?)."""
        return manage_boards(
            operation,
            board_id_or_name=board_id_or_name,
            name=name,
            desc=desc,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_cards")
    def _mcp_manage_cards(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        list: str | None = None,
        confirm: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """List cards in a list, or archive/unarchive/delete a card. operation: "list" (list), "archive"/"unarchive" (card), "delete" (card, confirm=True). Use create/update/move_cards for those."""
        return manage_cards(
            board_id_or_name,
            operation,
            card=card,
            list=list,
            confirm=confirm,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_comments")
    def _mcp_manage_comments(
        operation: str,
        action: str,
        text: str | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        """Edit or delete a comment by action ID. operation: "update" (text), "delete" (confirm=True). Add via comment_on_card; read via get_card_context."""
        return manage_comments(
            operation,
            action,
            text=text,
            confirm=confirm,
        )

    @mcp.tool(name="manage_checklists")
    def _mcp_manage_checklists(
        board_id_or_name: str,
        card: str,
        operation: str = "list",
        checklist: str | None = None,
        item: str | None = None,
        updates: list[dict[str, Any]] | None = None,
        name: str | None = None,
        checked: bool | None = None,
        state: str | None = None,
        pos: str | int | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Checklists/items on a card. operation: "list" (default), "create" (name), "delete" (checklist), "add_item" (checklist, name), "update_item"/"update_items"/"delete_item" (checklist, item)."""
        return manage_checklists(
            board_id_or_name,
            card,
            operation=operation,
            checklist=checklist,
            item=item,
            updates=updates,
            name=name,
            checked=checked,
            state=state,
            pos=pos,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_attachments")
    def _mcp_manage_attachments(
        board_id_or_name: str,
        card: str,
        operation: str = "list",
        attachment: str | None = None,
        url: str | None = None,
        file_path: str | None = None,
        name: str | None = None,
        confirm: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Attachments on a card. operation: "list" (default), "add_url" (url, name?), "upload_file" (file_path, confirm=True), "delete" (attachment)."""
        return manage_attachments(
            board_id_or_name,
            card,
            operation=operation,
            attachment=attachment,
            url=url,
            file_path=file_path,
            name=name,
            confirm=confirm,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_custom_fields")
    def _mcp_manage_custom_fields(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        field: str | None = None,
        value: Any = None,
        option: str | None = None,
        name: str | None = None,
        type: str | None = None,
        pos: str | int | None = None,
        display_cardFront: bool | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Board custom field defs and per-card values. operation: list_definitions, get_card_values (card), set_card_value (card, field, value/option), create/update/delete_definition, add/delete_option."""
        return manage_custom_fields(
            board_id_or_name,
            operation,
            card=card,
            field=field,
            value=value,
            option=option,
            name=name,
            type=type,
            pos=pos,
            display_cardFront=display_cardFront,
            dry_run=dry_run,
        )

    @mcp.tool(name="assign_members")
    def _mcp_assign_members(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        members: list[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """List board members or add/remove members on a card. operation: "list_board_members", "add" (card, members), "remove" (card, members). members: usernames or member IDs."""
        return assign_members(
            board_id_or_name,
            operation,
            card=card,
            members=members,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_lists")
    def _mcp_manage_lists(
        board_id_or_name: str,
        operation: str,
        list: str | None = None,
        target_list: str | None = None,
        name: str | None = None,
        pos: str | int | None = None,
        closed: bool | None = None,
        ordered_names: list[str] | None = None,
        confirm: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """operation: list, create, rename, update, ensure (idempotent case-insensitive), reorder (ordered_names), archive, unarchive, archive_all_cards, move_all_cards (confirm=True when N>1)."""
        return manage_lists(
            board_id_or_name,
            operation,
            list=list,
            target_list=target_list,
            name=name,
            pos=pos,
            closed=closed,
            ordered_names=ordered_names,
            confirm=confirm,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_labels")
    def _mcp_manage_labels(
        board_id_or_name: str,
        operation: str,
        label: str | None = None,
        name: str | None = None,
        color: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Labels on a board. operation: "list", "create" (name, color), "ensure" (name, color?; idempotent case-insensitive), "update" (label, +name/color), "delete" (label). Use label_cards on cards."""
        return manage_labels(
            board_id_or_name,
            operation,
            label=label,
            name=name,
            color=color,
            dry_run=dry_run,
        )

    @mcp.tool(name="batch_get_compact")
    def _mcp_batch_get_compact(urls: list[str]) -> dict[str, Any]:
        """Fetch multiple Trello GET endpoints in one call. Each URL is one request; results dict keyed by URL preserves input order."""
        return batch_get_compact(urls)

    @mcp.tool(name="trello_get")
    def _mcp_trello_get(
        endpoint: str,
        params: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        """Raw Trello REST GET escape hatch. Prefer structured tools above. endpoint: Trello API path like "/boards/{id}/cards". Returns Trello response wrapped in standard envelope."""
        return trello_get(endpoint, params=params, compact=compact)

    @mcp.tool(name="trello_post")
    def _mcp_trello_post(
        endpoint: str,
        data: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        """Raw Trello REST POST escape hatch. Prefer structured tools above. Returns Trello response wrapped in standard envelope."""
        return trello_post(endpoint, data=data, compact=compact)

    @mcp.tool(name="trello_put")
    def _mcp_trello_put(
        endpoint: str,
        data: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        """Raw Trello REST PUT escape hatch. Prefer structured tools above. Returns Trello response wrapped in standard envelope."""
        return trello_put(endpoint, data=data, compact=compact)

    @mcp.tool(name="trello_delete")
    def _mcp_trello_delete(
        endpoint: str,
        data: dict[str, Any] | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        """Raw Trello REST DELETE escape hatch. Requires confirm=True. Prefer structured tools above. Returns Trello response wrapped in standard envelope."""
        return trello_delete(endpoint, data=data, confirm=confirm)


def main() -> None:
    """Run the Trello MCP server."""
    mcp.run()


_register_tools()
