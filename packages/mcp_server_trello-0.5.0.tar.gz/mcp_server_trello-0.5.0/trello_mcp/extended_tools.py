"""Grouped Trello capability tools."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .domain_models import (
    operation_receipt,
    simplify_attachment,
    simplify_check_item,
    simplify_checklist,
    simplify_custom_field,
    simplify_custom_field_item,
    simplify_member,
)
from .models import envelope, error, simplify_board, simplify_card, simplify_label, simplify_list
from .resolvers import resolve_card, resolve_label, resolve_list
from .tool_context import (
    error_envelope,
    open_board_data,
    resolve_check_item,
    resolve_checklist,
    resolve_custom_field,
    resolve_custom_field_option,
    resolve_member,
    validate_batch_urls,
)
from .trello_client import TrelloAPIError, TrelloClient


def manage_boards(
    operation: str,
    board_id_or_name: str | None = None,
    name: str | None = None,
    desc: str = "",
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List, get, or create Trello boards."""
    trello = client or TrelloClient()
    try:
        if operation == "list":
            boards = trello.request("/members/me/boards")
            return envelope(
                "manage_boards",
                result={"boards": [simplify_board(board) for board in boards]},
            )
        if operation == "get":
            if not board_id_or_name:
                return _invalid_operation("manage_boards", "board_id_or_name is required")
            opened = open_board_data(board_id_or_name, trello)
            if opened.get("error"):
                return envelope("manage_boards", errors=[opened["error"]])
            return envelope(
                "manage_boards",
                board=opened["board"],
                result={"board": simplify_board(opened["board"])},
                warnings=opened["warnings"],
            )
        if operation == "create":
            if not name:
                return _invalid_operation("manage_boards", "name is required")
            if dry_run:
                return envelope(
                    "manage_boards",
                    result={
                        "receipts": [
                            operation_receipt("create", name, None, "would_create")
                        ]
                    },
                )
            board = trello.request("/boards", method="POST", data={"name": name, "desc": desc})
            return envelope(
                "manage_boards",
                board=board,
                result={
                    "board": simplify_board(board),
                    "receipts": [
                        operation_receipt("create", name, board.get("id"), "created", board.get("name"))
                    ],
                },
            )
        return _invalid_operation("manage_boards", f"Unknown operation: {operation}")
    except TrelloAPIError as exc:
        return error_envelope("manage_boards", exc, board_id_or_name or operation)


def manage_cards(
    board_id_or_name: str,
    operation: str,
    card: str | None = None,
    list: str | None = None,
    confirm: bool = False,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List cards by list and archive, unarchive, or delete resolved cards."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_cards", errors=[opened["error"]])
        board = opened["board"]
        if operation in {"list", "list_by_list"}:
            if not list:
                return _invalid_operation("manage_cards", "list is required", board)
            resolved_list, list_error = resolve_list(list, opened["lists"], opened["board_map"])
            if list_error:
                return envelope("manage_cards", board=board, errors=[list_error])
            cards = trello.request(f"/lists/{resolved_list['id']}/cards")
            return envelope(
                "manage_cards",
                board=board,
                result={
                    "cards": [
                        simplify_card(
                            card_data,
                            list_name=resolved_list.get("name"),
                            board_map=opened["board_map"],
                        )
                        for card_data in cards
                    ]
                },
                warnings=opened["warnings"],
            )
        if operation in {"archive", "unarchive", "delete"}:
            if not card:
                return _invalid_operation("manage_cards", "card is required", board)
            cards = _all_board_cards(trello, board["id"])
            resolved_card, card_error = resolve_card(card, cards)
            if card_error:
                return envelope("manage_cards", board=board, errors=[card_error])
            if operation == "delete" and not confirm:
                return envelope(
                    "manage_cards",
                    board=board,
                    errors=[
                        error(
                            "unsafe_operation",
                            "Deleting a card requires confirm=True",
                            input_ref=card,
                        )
                    ],
                )
            status = "would_delete" if operation == "delete" else "would_change"
            if dry_run:
                return envelope(
                    "manage_cards",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(operation, card, resolved_card.get("id"), status, resolved_card.get("name"))
                        ]
                    },
                    warnings=opened["warnings"],
                )
            if operation == "delete":
                trello.request(f"/cards/{resolved_card['id']}", method="DELETE")
                changed = resolved_card
                receipt_status = "deleted"
            else:
                closed = operation == "archive"
                changed = trello.request(
                    f"/cards/{resolved_card['id']}",
                    method="PUT",
                    data={"closed": closed},
                )
                receipt_status = "changed"
            return envelope(
                "manage_cards",
                board=board,
                result={
                    "card": simplify_card(changed, board_map=opened["board_map"]),
                    "receipts": [
                        operation_receipt(operation, card, resolved_card.get("id"), receipt_status, resolved_card.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_cards", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_cards", exc, board_id_or_name)


def manage_comments(
    operation: str,
    action: str,
    text: str | None = None,
    confirm: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Update or delete Trello comment actions."""
    trello = client or TrelloClient()
    try:
        if operation == "get_action":
            return _invalid_operation(
                "manage_comments",
                "get_action is raw-only through trello_get('/actions/{id}')",
            )
        if operation == "update":
            if text is None:
                return _invalid_operation("manage_comments", "text is required")
            updated = trello.request(f"/actions/{action}", method="PUT", data={"text": text})
            return envelope(
                "manage_comments",
                result={
                    "action": updated,
                    "receipts": [
                        operation_receipt("update", action, updated.get("id"), "changed")
                    ],
                },
            )
        if operation == "delete":
            if not confirm:
                return envelope(
                    "manage_comments",
                    errors=[
                        error(
                            "unsafe_operation",
                            "Deleting a comment requires confirm=True",
                            input_ref=action,
                        )
                    ],
                )
            trello.request(f"/actions/{action}", method="DELETE")
            return envelope(
                "manage_comments",
                result={
                    "receipts": [
                        operation_receipt("delete", action, action, "deleted")
                    ]
                },
            )
        return _invalid_operation("manage_comments", f"Unknown operation: {operation}")
    except TrelloAPIError as exc:
        return error_envelope("manage_comments", exc, action)


def manage_checklists(
    board_id_or_name: str,
    card: str,
    operation: str = "list",
    checklist: str | None = None,
    item: str | None = None,
    updates: list[dict[str, Any]] | None = None,
    name: str | None = None,
    checked: bool | None = None,
    state: str | None = None,
    pos: str | int | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List and mutate Trello checklists and checklist items for one card."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_checklists", errors=[opened["error"]])
        board = opened["board"]
        cards = _all_board_cards(trello, board["id"])
        resolved_card, card_error = resolve_card(card, cards)
        if card_error:
            return envelope("manage_checklists", board=board, errors=[card_error])
        card_id = resolved_card["id"]

        if operation == "create":
            if name is None:
                return _invalid_operation("manage_checklists", "name is required", board)
            if dry_run:
                return envelope(
                    "manage_checklists",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt("create", name, None, "would_create")
                        ]
                    },
                    warnings=opened["warnings"],
                )
            created = trello.request(
                "/checklists",
                method="POST",
                data={"idCard": card_id, "name": name},
            )
            return envelope(
                "manage_checklists",
                board=board,
                result={
                    "checklist": simplify_checklist(created),
                    "receipts": [
                        operation_receipt("create", name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )

        checklists = trello.request(f"/cards/{card_id}/checklists")
        if operation == "list":
            return envelope(
                "manage_checklists",
                board=board,
                result={"checklists": [simplify_checklist(value) for value in checklists]},
                warnings=opened["warnings"],
            )
        if operation == "delete":
            if checklist is None:
                return _invalid_operation("manage_checklists", "checklist is required", board)
            resolved_checklist, checklist_error = resolve_checklist(checklist, checklists)
            if checklist_error:
                return envelope("manage_checklists", board=board, errors=[checklist_error])
            if dry_run:
                return envelope(
                    "manage_checklists",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "delete",
                                checklist,
                                resolved_checklist.get("id"),
                                "would_delete",
                                resolved_checklist.get("name"),
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            trello.request(f"/checklists/{resolved_checklist['id']}", method="DELETE")
            return envelope(
                "manage_checklists",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(
                            "delete",
                            checklist,
                            resolved_checklist.get("id"),
                            "deleted",
                            resolved_checklist.get("name"),
                        )
                    ]
                },
                warnings=opened["warnings"],
            )
        if operation == "add_item":
            if checklist is None:
                return _invalid_operation("manage_checklists", "checklist is required", board)
            if name is None:
                return _invalid_operation("manage_checklists", "name is required", board)
            resolved_checklist, checklist_error = resolve_checklist(checklist, checklists)
            if checklist_error:
                return envelope("manage_checklists", board=board, errors=[checklist_error])
            data: dict[str, Any] = {"name": name}
            if checked is not None:
                data["checked"] = checked
            if pos is not None:
                data["pos"] = pos
            if dry_run:
                return envelope(
                    "manage_checklists",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt("add_item", name, None, "would_create")
                        ]
                    },
                    warnings=opened["warnings"],
                )
            created = trello.request(
                f"/checklists/{resolved_checklist['id']}/checkItems",
                method="POST",
                data=data,
            )
            return envelope(
                "manage_checklists",
                board=board,
                result={
                    "item": simplify_check_item(created),
                    "receipts": [
                        operation_receipt("add_item", name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "update_item":
            if checklist is None:
                return _invalid_operation("manage_checklists", "checklist is required", board)
            if item is None:
                return _invalid_operation("manage_checklists", "item is required", board)
            resolved_checklist, checklist_error = resolve_checklist(checklist, checklists)
            if checklist_error:
                return envelope("manage_checklists", board=board, errors=[checklist_error])
            resolved_item, item_error = resolve_check_item(item, checklists, checklist)
            if item_error:
                return envelope("manage_checklists", board=board, errors=[item_error])
            data, state_error = _check_item_update_payload(
                checked=checked,
                state=state,
                name=name,
                pos=pos,
                input_ref=item,
            )
            if state_error:
                return envelope("manage_checklists", board=board, errors=[state_error])
            if dry_run:
                return envelope(
                    "manage_checklists",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "update_item",
                                item,
                                resolved_item.get("id"),
                                "would_change",
                                resolved_item.get("name"),
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            updated = trello.request(
                f"/cards/{card_id}/checkItem/{resolved_item['id']}",
                method="PUT",
                data=data,
            )
            return envelope(
                "manage_checklists",
                board=board,
                result={
                    "item": simplify_check_item(updated),
                    "receipts": [
                        operation_receipt(
                            "update_item",
                            item,
                            resolved_item.get("id"),
                            "changed",
                            updated.get("name", resolved_item.get("name")),
                        )
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "update_items":
            if checklist is None:
                return _invalid_operation("manage_checklists", "checklist is required", board)
            if updates is None:
                return _invalid_operation("manage_checklists", "updates is required", board)
            resolved_checklist, checklist_error = resolve_checklist(checklist, checklists)
            if checklist_error:
                return envelope("manage_checklists", board=board, errors=[checklist_error])
            receipts: list[dict[str, Any]] = []
            items: list[dict[str, Any]] = []
            item_errors: list[dict[str, Any]] = []
            for index, update in enumerate(updates):
                item_ref = update.get("item")
                if item_ref is None:
                    input_ref = str(index)
                    receipts.append(operation_receipt("update_item", input_ref, None, "failed"))
                    item_errors.append(
                        error("invalid_input", "item is required", input_ref=input_ref)
                    )
                    continue
                resolved_item, item_error = resolve_check_item(item_ref, checklists, checklist)
                if item_error:
                    receipts.append(operation_receipt("update_item", item_ref, None, "failed"))
                    item_errors.append(item_error)
                    continue
                data, state_error = _check_item_update_payload(
                    checked=update.get("checked") if "checked" in update else None,
                    state=update.get("state"),
                    name=update.get("name"),
                    pos=update.get("pos"),
                    input_ref=item_ref,
                )
                if state_error:
                    receipts.append(
                        operation_receipt(
                            "update_item",
                            item_ref,
                            resolved_item.get("id"),
                            "failed",
                            resolved_item.get("name"),
                        )
                    )
                    item_errors.append(state_error)
                    continue
                if dry_run:
                    receipts.append(
                        operation_receipt(
                            "update_item",
                            item_ref,
                            resolved_item.get("id"),
                            "would_change",
                            resolved_item.get("name"),
                        )
                    )
                    continue
                try:
                    updated = trello.request(
                        f"/cards/{card_id}/checkItem/{resolved_item['id']}",
                        method="PUT",
                        data=data,
                    )
                except TrelloAPIError as exc:
                    receipts.append(
                        operation_receipt(
                            "update_item",
                            item_ref,
                            resolved_item.get("id"),
                            "failed",
                            resolved_item.get("name"),
                        )
                    )
                    item_errors.append(
                        error(exc.code, exc.message, input_ref=item_ref, retryable=exc.retryable)
                    )
                    continue
                items.append(simplify_check_item(updated))
                receipts.append(
                    operation_receipt(
                        "update_item",
                        item_ref,
                        resolved_item.get("id"),
                        "changed",
                        updated.get("name", resolved_item.get("name")),
                    )
                )
            return _checklist_update_items_envelope(
                board=board,
                warnings=opened["warnings"],
                receipts=receipts,
                item_errors=item_errors,
                items=items,
            )
        if operation == "delete_item":
            if checklist is None:
                return _invalid_operation("manage_checklists", "checklist is required", board)
            if item is None:
                return _invalid_operation("manage_checklists", "item is required", board)
            resolved_checklist, checklist_error = resolve_checklist(checklist, checklists)
            if checklist_error:
                return envelope("manage_checklists", board=board, errors=[checklist_error])
            resolved_item, item_error = resolve_check_item(item, checklists, checklist)
            if item_error:
                return envelope("manage_checklists", board=board, errors=[item_error])
            if dry_run:
                return envelope(
                    "manage_checklists",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "delete_item",
                                item,
                                resolved_item.get("id"),
                                "would_delete",
                                resolved_item.get("name"),
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            trello.request(
                f"/checklists/{resolved_checklist['id']}/checkItems/{resolved_item['id']}",
                method="DELETE",
            )
            return envelope(
                "manage_checklists",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(
                            "delete_item",
                            item,
                            resolved_item.get("id"),
                            "deleted",
                            resolved_item.get("name"),
                        )
                    ]
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_checklists", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_checklists", exc, board_id_or_name)


def manage_attachments(
    board_id_or_name: str,
    card: str,
    operation: str = "list",
    attachment: str | None = None,
    url: str | None = None,
    file_path: str | None = None,
    name: str | None = None,
    confirm: bool = False,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List and mutate Trello attachments for one card."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_attachments", errors=[opened["error"]])
        board = opened["board"]
        cards = _all_board_cards(trello, board["id"])
        resolved_card, card_error = resolve_card(card, cards)
        if card_error:
            return envelope("manage_attachments", board=board, errors=[card_error])
        card_id = resolved_card["id"]

        if operation == "list":
            attachments = trello.request(f"/cards/{card_id}/attachments")
            return envelope(
                "manage_attachments",
                board=board,
                result={"attachments": [simplify_attachment(item) for item in attachments]},
                warnings=opened["warnings"],
            )
        if operation == "add_url":
            if url is None:
                return _invalid_operation("manage_attachments", "url is required", board)
            data = {"url": url}
            if name is not None:
                data["name"] = name
            if dry_run:
                return envelope(
                    "manage_attachments",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt("add_url", url, None, "would_create", name)
                        ]
                    },
                    warnings=opened["warnings"],
                )
            created = trello.request(
                f"/cards/{card_id}/attachments",
                method="POST",
                data=data,
            )
            return envelope(
                "manage_attachments",
                board=board,
                result={
                    "attachment": simplify_attachment(created),
                    "receipts": [
                        operation_receipt("add_url", url, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "upload_file":
            if not confirm:
                return envelope(
                    "manage_attachments",
                    board=board,
                    errors=[
                        error(
                            "unsafe_operation",
                            "Uploading a local file requires confirm=True",
                            input_ref=file_path,
                        )
                    ],
                )
            file_error = _validate_attachment_path(file_path)
            if file_error:
                return envelope("manage_attachments", board=board, errors=[file_error])
            if dry_run:
                return envelope(
                    "manage_attachments",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt("upload_file", file_path, None, "would_create", name)
                        ]
                    },
                    warnings=opened["warnings"],
                )
            path = Path(file_path or "")
            data = {"name": name} if name is not None else None
            with path.open("rb") as handle:
                created = trello.request(
                    f"/cards/{card_id}/attachments",
                    method="POST",
                    data=data,
                    files={"file": handle},
                )
            return envelope(
                "manage_attachments",
                board=board,
                result={
                    "attachment": simplify_attachment(created),
                    "receipts": [
                        operation_receipt(
                            "upload_file",
                            file_path,
                            created.get("id"),
                            "created",
                            created.get("name"),
                        )
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "delete":
            if attachment is None:
                return _invalid_operation("manage_attachments", "attachment is required", board)
            attachments = trello.request(f"/cards/{card_id}/attachments")
            resolved_attachment, attachment_error = _resolve_attachment(attachment, attachments)
            if attachment_error:
                return envelope("manage_attachments", board=board, errors=[attachment_error])
            if dry_run:
                return envelope(
                    "manage_attachments",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "delete",
                                attachment,
                                resolved_attachment.get("id"),
                                "would_delete",
                                resolved_attachment.get("name"),
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            trello.request(
                f"/cards/{card_id}/attachments/{resolved_attachment['id']}",
                method="DELETE",
            )
            return envelope(
                "manage_attachments",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(
                            "delete",
                            attachment,
                            resolved_attachment.get("id"),
                            "deleted",
                            resolved_attachment.get("name"),
                        )
                    ]
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_attachments", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_attachments", exc, board_id_or_name)


def manage_custom_fields(
    board_id_or_name: str,
    operation: str,
    card: str | None = None,
    field: str | None = None,
    value: Any = None,
    option: str | None = None,
    name: str | None = None,
    type: str | None = None,
    pos: str | int | None = None,
    display_cardFront: bool | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List and mutate Trello custom-field definitions and card values."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_custom_fields", errors=[opened["error"]])
        board = opened["board"]

        if operation == "list_definitions":
            fields = _board_custom_fields(trello, board["id"])
            return envelope(
                "manage_custom_fields",
                board=board,
                result={"fields": [simplify_custom_field(item) for item in fields]},
                warnings=opened["warnings"],
            )
        if operation == "get_card_values":
            if card is None:
                return _invalid_operation("manage_custom_fields", "card is required", board)
            resolved_card, card_error = _resolve_board_card(trello, board["id"], card)
            if card_error:
                return envelope("manage_custom_fields", board=board, errors=[card_error])
            values = trello.request(f"/cards/{resolved_card['id']}/customFieldItems")
            return envelope(
                "manage_custom_fields",
                board=board,
                result={"values": [simplify_custom_field_item(item) for item in values]},
                warnings=opened["warnings"],
            )
        if operation == "set_card_value":
            if card is None:
                return _invalid_operation("manage_custom_fields", "card is required", board)
            if field is None:
                return _invalid_operation("manage_custom_fields", "field is required", board)
            resolved_card, card_error = _resolve_board_card(trello, board["id"], card)
            if card_error:
                return envelope("manage_custom_fields", board=board, errors=[card_error])
            fields = _board_custom_fields(trello, board["id"])
            resolved_field, field_error = resolve_custom_field(field, fields)
            if field_error:
                return envelope("manage_custom_fields", board=board, errors=[field_error])
            payload, payload_error = _custom_field_value_payload(resolved_field, value, option)
            if payload_error:
                return envelope("manage_custom_fields", board=board, errors=[payload_error])
            if dry_run:
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "payload": payload,
                        "receipts": [
                            operation_receipt(
                                "set_card_value",
                                field,
                                resolved_field.get("id"),
                                "would_change",
                                resolved_field.get("name"),
                            )
                        ],
                    },
                    warnings=opened["warnings"],
                )
            updated = trello.request(
                f"/cards/{resolved_card['id']}/customField/{resolved_field['id']}/item",
                method="PUT",
                data=payload,
            )
            return envelope(
                "manage_custom_fields",
                board=board,
                result={
                    "value": simplify_custom_field_item(updated),
                    "receipts": [
                        operation_receipt(
                            "set_card_value",
                            field,
                            resolved_field.get("id"),
                            "changed",
                            resolved_field.get("name"),
                        )
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "create_definition":
            if name is None:
                return _invalid_operation("manage_custom_fields", "name is required", board)
            if type is None:
                return _invalid_operation("manage_custom_fields", "type is required", board)
            data = _custom_field_definition_payload(
                board["id"],
                name=name,
                type=type,
                pos=pos,
                display_cardFront=display_cardFront,
            )
            if dry_run:
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "payload": data,
                        "receipts": [
                            operation_receipt("create_definition", name, None, "would_create")
                        ],
                    },
                    warnings=opened["warnings"],
                )
            created = trello.request("/customFields", method="POST", data=data)
            return envelope(
                "manage_custom_fields",
                board=board,
                result={
                    "field": simplify_custom_field(created),
                    "receipts": [
                        operation_receipt("create_definition", name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation in {"update_definition", "delete_definition", "add_option", "delete_option"}:
            if field is None:
                return _invalid_operation("manage_custom_fields", "field is required", board)
            fields = _board_custom_fields(trello, board["id"])
            resolved_field, field_error = resolve_custom_field(field, fields)
            if field_error:
                return envelope("manage_custom_fields", board=board, errors=[field_error])
            if operation == "update_definition":
                data = _custom_field_update_payload(
                    name=name,
                    type=type,
                    pos=pos,
                    display_cardFront=display_cardFront,
                )
                if dry_run:
                    return envelope(
                        "manage_custom_fields",
                        board=board,
                        result={
                            "payload": data,
                            "receipts": [
                                operation_receipt(
                                    "update_definition",
                                    field,
                                    resolved_field.get("id"),
                                    "would_change",
                                    resolved_field.get("name"),
                                )
                            ],
                        },
                        warnings=opened["warnings"],
                    )
                updated = trello.request(
                    f"/customFields/{resolved_field['id']}",
                    method="PUT",
                    data=data,
                )
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "field": simplify_custom_field(updated),
                        "receipts": [
                            operation_receipt(
                                "update_definition",
                                field,
                                resolved_field.get("id"),
                                "changed",
                                updated.get("name", resolved_field.get("name")),
                            )
                        ],
                    },
                    warnings=opened["warnings"],
                )
            if operation == "delete_definition":
                if dry_run:
                    return envelope(
                        "manage_custom_fields",
                        board=board,
                        result={
                            "receipts": [
                                operation_receipt(
                                    "delete_definition",
                                    field,
                                    resolved_field.get("id"),
                                    "would_delete",
                                    resolved_field.get("name"),
                                )
                            ]
                        },
                        warnings=opened["warnings"],
                    )
                trello.request(f"/customFields/{resolved_field['id']}", method="DELETE")
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "delete_definition",
                                field,
                                resolved_field.get("id"),
                                "deleted",
                                resolved_field.get("name"),
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            if operation == "add_option":
                option_name = option if option is not None else name
                if option_name is None:
                    return _invalid_operation("manage_custom_fields", "option or name is required", board)
                data = {"value": {"text": str(option_name)}}
                if pos is not None:
                    data["pos"] = pos
                if dry_run:
                    return envelope(
                        "manage_custom_fields",
                        board=board,
                        result={
                            "payload": data,
                            "receipts": [
                                operation_receipt("add_option", option_name, None, "would_create")
                            ],
                        },
                        warnings=opened["warnings"],
                    )
                created = trello.request(
                    f"/customFields/{resolved_field['id']}/options",
                    method="POST",
                    data=data,
                )
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "option": created,
                        "receipts": [
                            operation_receipt("add_option", option_name, created.get("id"), "created")
                        ],
                    },
                    warnings=opened["warnings"],
                )
            if option is None:
                return _invalid_operation("manage_custom_fields", "option is required", board)
            resolved_option, option_error = resolve_custom_field_option(option, resolved_field)
            if option_error:
                return envelope("manage_custom_fields", board=board, errors=[option_error])
            if dry_run:
                return envelope(
                    "manage_custom_fields",
                    board=board,
                    result={
                        "receipts": [
                            operation_receipt(
                                "delete_option",
                                option,
                                resolved_option.get("id"),
                                "would_delete",
                            )
                        ]
                    },
                    warnings=opened["warnings"],
                )
            trello.request(
                f"/customFields/{resolved_field['id']}/options/{resolved_option['id']}",
                method="DELETE",
            )
            return envelope(
                "manage_custom_fields",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(
                            "delete_option",
                            option,
                            resolved_option.get("id"),
                            "deleted",
                        )
                    ]
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_custom_fields", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_custom_fields", exc, board_id_or_name)


def assign_members(
    board_id_or_name: str,
    operation: str,
    card: str | None = None,
    members: list[str] | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List board members and assign or remove members from one card."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("assign_members", errors=[opened["error"]])
        board = opened["board"]
        if operation == "list_board_members":
            board_members = _board_members(trello, board["id"])
            return envelope(
                "assign_members",
                board=board,
                result={"members": [simplify_member(member) for member in board_members]},
                warnings=opened["warnings"],
            )
        if operation in {"add", "remove"}:
            if card is None:
                return _invalid_operation("assign_members", "card is required", board)
            if not members:
                return _invalid_operation("assign_members", "members is required", board)
            resolved_card, card_error = _resolve_board_card(trello, board["id"], card)
            if card_error:
                return envelope("assign_members", board=board, errors=[card_error])
            board_members = _board_members(trello, board["id"])
            receipts = []
            item_errors = []
            for member_ref in members:
                member, member_error = resolve_member(member_ref, board_members)
                if member_error:
                    item_errors.append(member_error)
                    receipts.append(operation_receipt(operation, member_ref, None, "failed"))
                    continue
                status = "would_change" if dry_run else "changed"
                if not dry_run:
                    if operation == "add":
                        trello.request(
                            f"/cards/{resolved_card['id']}/idMembers",
                            method="POST",
                            data={"value": member["id"]},
                        )
                    else:
                        trello.request(
                            f"/cards/{resolved_card['id']}/idMembers/{member['id']}",
                            method="DELETE",
                        )
                receipts.append(
                    operation_receipt(
                        operation,
                        member_ref,
                        member.get("id"),
                        status,
                        member.get("fullName") or member.get("username"),
                    )
                )
            return envelope(
                "assign_members",
                board=board,
                result={"receipts": receipts},
                warnings=opened["warnings"],
                errors=item_errors,
            )
        return _invalid_operation("assign_members", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("assign_members", exc, board_id_or_name)


def manage_lists(
    board_id_or_name: str,
    operation: str,
    list: str | None = None,
    target_list: str | None = None,
    name: str | None = None,
    pos: str | int | None = None,
    closed: bool | None = None,
    ordered_names: list[str] | None = None,
    confirm: bool = False,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List and mutate Trello workflow lists."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_lists", errors=[opened["error"]])
        board = opened["board"]
        if operation == "list":
            return envelope(
                "manage_lists",
                board=board,
                result={"lists": [simplify_list(item) for item in opened["lists"]]},
                warnings=opened["warnings"],
            )
        if operation == "create":
            if name is None:
                return _invalid_operation("manage_lists", "name is required", board)
            data: dict[str, Any] = {"idBoard": board["id"], "name": name}
            if pos is not None:
                data["pos"] = pos
            if dry_run:
                return _dry_receipt("manage_lists", board, opened, "create", name, "would_create", payload=data)
            created = trello.request("/lists", method="POST", data=data)
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "list": simplify_list(created),
                    "receipts": [
                        operation_receipt("create", name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "ensure":
            from .input_specs import EnsureListOp, validate
            clean, report = validate(EnsureListOp, {"name": name, "pos": pos})
            if clean is None:
                return _invalid_operation("manage_lists", "name is required", board)
            target_name = clean["name"]
            target_lower = target_name.lower()
            for existing in opened["lists"]:
                if existing.get("closed"):
                    continue
                if str(existing.get("name", "")).lower() == target_lower:
                    return envelope(
                        "manage_lists",
                        board=board,
                        result={
                            "list": simplify_list(existing),
                            "receipts": [
                                operation_receipt("ensure", target_name, existing.get("id"), "matched", existing.get("name"))
                            ],
                        },
                        warnings=opened["warnings"],
                    )
            data = {"idBoard": board["id"], "name": target_name}
            if "pos" in clean:
                data["pos"] = clean["pos"]
            if dry_run:
                return _dry_receipt("manage_lists", board, opened, "ensure", target_name, "would_create", payload=data)
            created = trello.request("/lists", method="POST", data=data)
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "list": simplify_list(created),
                    "receipts": [
                        operation_receipt("ensure", target_name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "reorder":
            from .input_specs import ReorderListsOp, validate
            clean, report = validate(ReorderListsOp, {"ordered_names": ordered_names})
            if clean is None:
                return _invalid_operation("manage_lists", "ordered_names is required (non-empty)", board)
            requested = clean["ordered_names"]
            open_lists = [item for item in opened["lists"] if not item.get("closed")]
            by_name_lower = {str(item.get("name", "")).lower(): item for item in open_lists}
            resolved: list[dict[str, Any]] = []
            item_errors: list[dict[str, Any]] = []
            for ref in requested:
                match = by_name_lower.get(str(ref).lower())
                if match is None:
                    item_errors.append(error("not_found", f"No list matched '{ref}'", input_ref=ref))
                else:
                    resolved.append(match)
            resolved_ids = {item.get("id") for item in resolved}
            trailing = [item for item in open_lists if item.get("id") not in resolved_ids]
            target_pos: dict[str, int] = {}
            for i, item in enumerate(resolved):
                target_pos[item["id"]] = (i + 1) * 65536
            n = len(resolved)
            for j, item in enumerate(trailing):
                target_pos[item["id"]] = (n + j + 1) * 65536
            receipts: list[dict[str, Any]] = []
            for item in resolved + trailing:
                new_pos = target_pos[item["id"]]
                if item.get("pos") == new_pos:
                    receipts.append(operation_receipt("reorder", item.get("name"), item.get("id"), "unchanged", item.get("name")))
                    continue
                if dry_run:
                    receipts.append(operation_receipt("reorder", item.get("name"), item.get("id"), "would_change", item.get("name")))
                    continue
                trello.request(f"/lists/{item['id']}/pos", method="PUT", data={"value": new_pos})
                receipts.append(operation_receipt("reorder", item.get("name"), item.get("id"), "moved", item.get("name")))
            return envelope(
                "manage_lists",
                board=board,
                result={"receipts": receipts},
                warnings=opened["warnings"],
                errors=item_errors or None,
            )
        if list is None:
            return _invalid_operation("manage_lists", "list is required", board)
        resolved_list, list_error = _resolve_list_for_mutation(trello, board, opened, list)
        if list_error:
            return envelope("manage_lists", board=board, errors=[list_error])
        if operation in {"rename", "update"}:
            data = _list_update_payload(name=name, pos=pos, closed=closed)
            if operation == "rename" and name is None:
                return _invalid_operation("manage_lists", "name is required", board)
            if dry_run:
                return _dry_receipt(
                    "manage_lists",
                    board,
                    opened,
                    operation,
                    list,
                    "would_change",
                    item_id=resolved_list.get("id"),
                    name=resolved_list.get("name"),
                    payload=data,
                )
            updated = trello.request(f"/lists/{resolved_list['id']}", method="PUT", data=data)
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "list": simplify_list(updated),
                    "receipts": [
                        operation_receipt(operation, list, resolved_list.get("id"), "changed", updated.get("name", resolved_list.get("name")))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation in {"archive", "unarchive"}:
            data = {"value": operation == "archive"}
            if dry_run:
                return _dry_receipt("manage_lists", board, opened, operation, list, "would_change", resolved_list.get("id"), resolved_list.get("name"), data)
            updated = trello.request(f"/lists/{resolved_list['id']}/closed", method="PUT", data=data)
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "list": simplify_list(updated),
                    "receipts": [
                        operation_receipt(operation, list, resolved_list.get("id"), "changed", resolved_list.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "archive_all_cards":
            if dry_run:
                return _dry_receipt("manage_lists", board, opened, operation, list, "would_change", resolved_list.get("id"), resolved_list.get("name"))
            trello.request(f"/lists/{resolved_list['id']}/archiveAllCards", method="POST")
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(operation, list, resolved_list.get("id"), "changed", resolved_list.get("name"))
                    ]
                },
                warnings=opened["warnings"],
            )
        if operation == "move_all_cards":
            if target_list is None:
                return _invalid_operation("manage_lists", "target_list is required", board)
            resolved_target, target_error = _resolve_list_for_mutation(trello, board, opened, target_list)
            if target_error:
                return envelope("manage_lists", board=board, errors=[target_error])
            data = {"idBoard": board["id"], "idList": resolved_target["id"]}
            source_cards = trello.request(
                f"/lists/{resolved_list['id']}/cards", params={"filter": "open"}
            )
            card_count = len(source_cards) if source_cards else 0
            if dry_run:
                dry = _dry_receipt("manage_lists", board, opened, operation, list, "would_change", resolved_list.get("id"), resolved_list.get("name"), data)
                dry["result"]["receipts"][0]["card_count"] = card_count
                return dry
            if card_count > 1 and not confirm:
                err = error(
                    "unsafe_operation",
                    f"Pass confirm=True to move {card_count} cards.",
                    input_ref=list,
                )
                err["card_count"] = card_count
                return envelope("manage_lists", board=board, errors=[err])
            trello.request(f"/lists/{resolved_list['id']}/moveAllCards", method="POST", data=data)
            return envelope(
                "manage_lists",
                board=board,
                result={
                    "receipts": [
                        operation_receipt(operation, list, resolved_list.get("id"), "changed", resolved_list.get("name"))
                    ]
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_lists", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_lists", exc, board_id_or_name)


def manage_labels(
    board_id_or_name: str,
    operation: str,
    label: str | None = None,
    name: str | None = None,
    color: str | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """List and mutate Trello label definitions."""
    trello = client or TrelloClient()
    try:
        opened = open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("manage_labels", errors=[opened["error"]])
        board = opened["board"]
        if operation == "list":
            return envelope(
                "manage_labels",
                board=board,
                result={"labels": [simplify_label(item) for item in opened["labels"]]},
                warnings=opened["warnings"],
            )
        if operation == "create":
            if name is None:
                return _invalid_operation("manage_labels", "name is required", board)
            if color is None:
                return _invalid_operation("manage_labels", "color is required", board)
            data = {"idBoard": board["id"], "name": name, "color": color}
            if dry_run:
                return _dry_receipt("manage_labels", board, opened, "create", name, "would_create", payload=data)
            created = trello.request("/labels", method="POST", data=data)
            return envelope(
                "manage_labels",
                board=board,
                result={
                    "label": simplify_label(created),
                    "receipts": [
                        operation_receipt("create", name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "ensure":
            from .input_specs import EnsureLabelOp, validate
            clean, report = validate(EnsureLabelOp, {"name": name, "color": color})
            if clean is None:
                return _invalid_operation("manage_labels", "name is required", board)
            target_name = clean["name"]
            target_lower = target_name.lower()
            # Labels have no `closed` field in Trello (unlike lists); scan unconditionally.
            for existing in opened["labels"]:
                if str(existing.get("name", "")).lower() == target_lower:
                    return envelope(
                        "manage_labels",
                        board=board,
                        result={
                            "label": simplify_label(existing),
                            "receipts": [
                                operation_receipt("ensure", target_name, existing.get("id"), "matched", existing.get("name"))
                            ],
                        },
                        warnings=opened["warnings"],
                    )
            data = {"idBoard": board["id"], "name": target_name}
            if "color" in clean:
                data["color"] = clean["color"]
            if dry_run:
                return _dry_receipt("manage_labels", board, opened, "ensure", target_name, "would_create", payload=data)
            created = trello.request("/labels", method="POST", data=data)
            return envelope(
                "manage_labels",
                board=board,
                result={
                    "label": simplify_label(created),
                    "receipts": [
                        operation_receipt("ensure", target_name, created.get("id"), "created", created.get("name"))
                    ],
                },
                warnings=opened["warnings"],
            )
        if label is None:
            return _invalid_operation("manage_labels", "label is required", board)
        resolved_label, label_error = resolve_label(label, opened["labels"], opened["board_map"])
        if label_error:
            return envelope("manage_labels", board=board, errors=[label_error])
        if operation == "update":
            data = _label_update_payload(name=name, color=color)
            if dry_run:
                return _dry_receipt("manage_labels", board, opened, "update", label, "would_change", resolved_label.get("id"), resolved_label.get("name"), data)
            updated = trello.request(f"/labels/{resolved_label['id']}", method="PUT", data=data)
            return envelope(
                "manage_labels",
                board=board,
                result={
                    "label": simplify_label(updated),
                    "receipts": [
                        operation_receipt("update", label, resolved_label.get("id"), "changed", updated.get("name", resolved_label.get("name")))
                    ],
                },
                warnings=opened["warnings"],
            )
        if operation == "delete":
            if dry_run:
                return _dry_receipt("manage_labels", board, opened, "delete", label, "would_delete", resolved_label.get("id"), resolved_label.get("name"))
            trello.request(f"/labels/{resolved_label['id']}", method="DELETE")
            return envelope(
                "manage_labels",
                board=board,
                result={
                    "receipts": [
                        operation_receipt("delete", label, resolved_label.get("id"), "deleted", resolved_label.get("name"))
                    ]
                },
                warnings=opened["warnings"],
            )
        return _invalid_operation("manage_labels", f"Unknown operation: {operation}", board)
    except TrelloAPIError as exc:
        return error_envelope("manage_labels", exc, board_id_or_name)


def batch_get_compact(
    urls: list[str],
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Run a guarded Trello batch GET and compact known response shapes."""
    valid_urls, validation_error = validate_batch_urls(urls)
    if validation_error:
        return envelope("batch_get_compact", errors=[validation_error])
    trello = client or TrelloClient()
    try:
        responses = trello.request(
            "/batch",
            params={"urls": ",".join(valid_urls or [])},
        )
        items = [
            {
                "url": url,
                "result": _compact_batch_response(url, response),
            }
            for url, response in zip(valid_urls or [], responses)
        ]
        return envelope("batch_get_compact", result={"items": items})
    except TrelloAPIError as exc:
        return error_envelope("batch_get_compact", exc, ",".join(urls))


def _invalid_operation(
    tool: str, message: str, board: dict[str, Any] | None = None
) -> dict[str, Any]:
    return envelope(tool, board=board, errors=[error("invalid_input", message)])


def _check_item_update_payload(
    checked: bool | None,
    state: str | None,
    name: str | None,
    pos: str | int | None,
    input_ref: str | None,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    data: dict[str, Any] = {}
    normalized_state = _normalize_check_item_state(checked, state)
    if normalized_state is False:
        return {}, error(
            "invalid_input",
            "checked and state conflict",
            input_ref=input_ref,
        )
    if name is not None:
        data["name"] = name
    if normalized_state is not None:
        data["state"] = normalized_state
    if pos is not None:
        data["pos"] = pos
    return data, None


def _normalize_check_item_state(
    checked: bool | None, state: str | None
) -> str | None | bool:
    checked_state = None
    if checked is True:
        checked_state = "complete"
    elif checked is False:
        checked_state = "incomplete"
    if checked_state is None:
        return state
    if state is not None and state != checked_state:
        return False
    return checked_state


def _checklist_update_items_envelope(
    board: dict[str, Any],
    warnings: list[dict[str, Any]],
    receipts: list[dict[str, Any]],
    item_errors: list[dict[str, Any]],
    items: list[dict[str, Any]],
) -> dict[str, Any]:
    failed = sum(1 for receipt in receipts if receipt["status"] == "failed")
    changed = sum(1 for receipt in receipts if receipt["status"] == "changed")
    would_change = sum(1 for receipt in receipts if receipt["status"] == "would_change")
    errors = []
    if failed and (changed or would_change):
        errors.append(error("partial_failure", "Some items failed", retryable=False))
    errors.extend(item_errors)
    return envelope(
        "manage_checklists",
        board=board,
        result={
            "changed": changed,
            "failed": failed,
            "would_change": would_change,
            "items": items,
            "receipts": receipts,
        },
        warnings=warnings,
        errors=errors,
    )


def _all_board_cards(trello: TrelloClient, board_id: str) -> list[dict[str, Any]]:
    return trello.request(f"/boards/{board_id}/cards", params={"filter": "all"})


def _resolve_board_card(
    trello: TrelloClient, board_id: str, card_ref: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    cards = _all_board_cards(trello, board_id)
    return resolve_card(card_ref, cards)


def _board_custom_fields(trello: TrelloClient, board_id: str) -> list[dict[str, Any]]:
    return trello.request(f"/boards/{board_id}/customFields")


def _board_members(trello: TrelloClient, board_id: str) -> list[dict[str, Any]]:
    return trello.request(f"/boards/{board_id}/members")


def _board_lists(
    trello: TrelloClient, board_id: str, filter: str = "all"
) -> list[dict[str, Any]]:
    return trello.request(f"/boards/{board_id}/lists/{filter}")


def _resolve_list_for_mutation(
    trello: TrelloClient,
    board: dict[str, Any],
    opened: dict[str, Any],
    list_ref: str,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    resolved_list, list_error = resolve_list(
        list_ref, opened["lists"], opened["board_map"]
    )
    if list_error is None:
        return resolved_list, None
    all_lists = _board_lists(trello, board["id"], filter="all")
    return resolve_list(list_ref, all_lists, opened["board_map"])


def _dry_receipt(
    tool: str,
    board: dict[str, Any],
    opened: dict[str, Any],
    operation: str,
    input_ref: str | None,
    status: str,
    item_id: str | None = None,
    name: str | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "receipts": [operation_receipt(operation, input_ref, item_id, status, name)]
    }
    if payload is not None:
        result["payload"] = payload
    return envelope(tool, board=board, result=result, warnings=opened["warnings"])


def _list_update_payload(
    name: str | None = None,
    pos: str | int | None = None,
    closed: bool | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {}
    if name is not None:
        data["name"] = name
    if pos is not None:
        data["pos"] = pos
    if closed is not None:
        data["closed"] = closed
    return data


def _label_update_payload(
    name: str | None = None,
    color: str | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {}
    if name is not None:
        data["name"] = name
    if color is not None:
        data["color"] = color
    return data


def _compact_batch_response(url: str, response: Any) -> Any:
    body = _batch_response_body(response)
    path = url.split("?", 1)[0].strip("/")
    parts = path.split("/")
    resource = _batch_resource(parts)
    if isinstance(body, list):
        serializer = _batch_serializer(resource)
        if serializer is None:
            return _redact_credentials(body)
        return [serializer(item) if isinstance(item, dict) else _redact_credentials(item) for item in body]
    if not isinstance(body, dict):
        return _redact_credentials(body)
    serializer = _batch_serializer(resource)
    if serializer is not None:
        return serializer(body)
    return _redact_credentials(body)


def _batch_serializer(resource: str) -> Any:
    if resource == "cards":
        return simplify_card
    if resource == "lists":
        return simplify_list
    if resource == "labels":
        return simplify_label
    if resource == "checklists":
        return simplify_checklist
    if resource == "members":
        return simplify_member
    if resource == "customFields":
        return simplify_custom_field
    if resource == "customFieldItems":
        return simplify_custom_field_item
    if resource == "attachments":
        return simplify_attachment
    return None


def _batch_response_body(response: Any) -> Any:
    if isinstance(response, dict) and "body" in response:
        return response["body"]
    return response


def _batch_resource(parts: list[str]) -> str:
    if len(parts) >= 2 and parts[0] == "cards" and parts[-1] == "customFieldItems":
        return "customFieldItems"
    if len(parts) >= 2 and parts[0] == "cards" and parts[2:3] == ["checklists"]:
        return "checklists"
    if len(parts) >= 2 and parts[0] == "cards" and parts[2:3] == ["attachments"]:
        return "attachments"
    if len(parts) >= 3 and parts[0] == "boards" and parts[-2] == "labels":
        return "labels"
    if len(parts) >= 3 and parts[0] == "boards":
        return parts[2]
    return parts[0] if parts else ""


def _redact_credentials(value: Any) -> Any:
    if isinstance(value, dict):
        redacted = {}
        for key, item in value.items():
            if str(key).lower() in {"key", "token"}:
                continue
            redacted[key] = _redact_credentials(item)
        return redacted
    if isinstance(value, list):
        return [_redact_credentials(item) for item in value]
    return value


def _custom_field_value_payload(
    field: dict[str, Any], value: Any, option: str | None
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    field_type = field.get("type")
    if field_type == "list":
        option_ref = option if option is not None else value
        if option_ref is None:
            return None, error("invalid_input", "option or value is required for list field")
        resolved_option, option_error = resolve_custom_field_option(str(option_ref), field)
        if option_error:
            return None, option_error
        return {"idValue": resolved_option["id"]}, None
    if value is None:
        return None, error("invalid_input", "value is required", input_ref=field.get("name"))
    if field_type == "checkbox":
        checked = "true" if _truthy_checkbox(value) else "false"
        return {"value": {"checked": checked}}, None
    if field_type == "date":
        return {"value": {"date": value}}, None
    if field_type == "number":
        return {"value": {"number": str(value)}}, None
    if field_type == "text":
        return {"value": {"text": str(value)}}, None
    return None, error(
        "invalid_input",
        f"Unsupported custom field type: {field_type}",
        input_ref=field.get("name"),
    )


def _truthy_checkbox(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "checked"}
    return bool(value)


def _custom_field_definition_payload(
    board_id: str,
    name: str,
    type: str,
    pos: str | int | None = None,
    display_cardFront: bool | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {
        "idModel": board_id,
        "modelType": "board",
        "name": name,
        "type": type,
    }
    if pos is not None:
        data["pos"] = pos
    if display_cardFront is not None:
        data["display/cardFront"] = display_cardFront
    return data


def _custom_field_update_payload(
    name: str | None = None,
    type: str | None = None,
    pos: str | int | None = None,
    display_cardFront: bool | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {}
    if name is not None:
        data["name"] = name
    if type is not None:
        data["type"] = type
    if pos is not None:
        data["pos"] = pos
    if display_cardFront is not None:
        data["display/cardFront"] = display_cardFront
    return data


def _validate_attachment_path(file_path: str | None) -> dict[str, Any] | None:
    if not file_path:
        return error("invalid_input", "file_path is required")
    lowered = file_path.lower()
    sensitive_terms = (".env", ".pem", ".key", "id_rsa", "token", "secret", "credentials")
    if any(term in lowered for term in sensitive_terms):
        return error(
            "unsafe_operation",
            "Refusing to upload sensitive-looking file path",
            input_ref=file_path,
        )
    path = Path(file_path)
    if not path.exists():
        return error("invalid_input", "file_path does not exist", input_ref=file_path)
    if not path.is_file():
        return error("invalid_input", "file_path must be a regular file", input_ref=file_path)
    return None


def _resolve_attachment(
    ref: str, attachments: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    ref_text = str(ref).strip()
    if not ref_text:
        return None, error("not_found", "No attachment matched empty reference", ref)
    id_matches = [item for item in attachments if item.get("id") == ref_text]
    if id_matches:
        return _single_attachment(id_matches, ref_text)
    ref_lower = ref_text.lower()
    exact_matches = [
        item for item in attachments if str(item.get("name", "")).lower() == ref_lower
    ]
    if exact_matches:
        return _single_attachment(exact_matches, ref_text)
    partial_matches = [
        item for item in attachments if ref_lower in str(item.get("name", "")).lower()
    ]
    if partial_matches:
        return _single_attachment(partial_matches, ref_text)
    return None, error("not_found", f"No attachment matched '{ref_text}'", ref_text)


def _single_attachment(
    matches: list[dict[str, Any]], ref: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if len(matches) == 1:
        return matches[0], None
    return None, error(
        "ambiguous_ref",
        f"Multiple attachments matched '{ref}'",
        input_ref=ref,
        candidates=[
            {"id": item.get("id"), "name": item.get("name")}
            for item in matches
        ],
    )
