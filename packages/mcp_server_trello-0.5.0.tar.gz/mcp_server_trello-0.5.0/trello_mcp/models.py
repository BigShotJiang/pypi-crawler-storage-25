"""Shared response models and compact Trello object helpers."""

from __future__ import annotations

from typing import Any


ERROR_CODES = {
    "not_found",
    "ambiguous_ref",
    "invalid_input",
    "trello_bad_request",
    "trello_auth_error",
    "trello_rate_limited",
    "trello_unavailable",
    "partial_failure",
    "unsafe_operation",
    "board_map_stale",
    "board_map_corrupt",
    "no_changes_requested",
    "partial_resolution",
    "wrong_tool",
    "alias_collision",
}

WARNING_CODES = {
    "board_map_name_changed",
    "board_map_stale_object",
    "result_truncated",
    "using_inferred_unsaved_map",
    "description_omitted",
    "board_map_corrupt",
    "partial_failure",
}


def board_summary(board: dict[str, Any] | None) -> dict[str, Any] | None:
    """Return the compact board identity used by response envelopes."""
    if board is None:
        return None
    return {
        "id": board.get("id"),
        "name": board.get("name"),
        "url": board.get("url") or board.get("shortUrl"),
    }


def error(
    code: str,
    message: str,
    input_ref: str | dict[str, Any] | None = None,
    retryable: bool = False,
    candidates: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a stable machine-readable error object."""
    if code not in ERROR_CODES:
        raise ValueError(f"Unknown error code: {code}")
    return {
        "code": code,
        "message": message,
        "input_ref": input_ref,
        "retryable": retryable,
        "candidates": (candidates or [])[:3],
    }


def warning(
    code: str,
    message: str,
    input_ref: str | dict[str, Any] | None = None,
    retryable: bool = False,
) -> dict[str, Any]:
    """Build a stable machine-readable warning object."""
    if code not in WARNING_CODES:
        raise ValueError(f"Unknown warning code: {code}")
    return {
        "code": code,
        "message": message,
        "input_ref": input_ref,
        "retryable": retryable,
    }


def envelope(
    tool: str,
    board: dict[str, Any] | None = None,
    result: dict[str, Any] | None = None,
    warnings: list[dict[str, Any]] | None = None,
    errors: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build the canonical dict-shaped tool response envelope."""
    response_errors = errors or []
    return {
        "ok": not response_errors,
        "tool": tool,
        "board": board_summary(board),
        "result": result or {},
        "warnings": warnings or [],
        "errors": response_errors,
    }


def normalize_card_output(
    card: dict[str, Any],
    board_map: dict[str, Any] | None,
) -> dict[str, Any]:
    """Single chokepoint for card output. Hydrates labels, fills list_name,
    drops empty arrays and url-when-id-present. Idempotent."""
    list_id = card.get("list_id") or card.get("idList")
    label_ids = card.get("label_ids") or card.get("idLabels") or []
    member_ids = card.get("member_ids") or card.get("idMembers") or []

    list_name = card.get("list_name")
    if not list_name and list_id and board_map:
        for lst in board_map.get("lists", []):
            if lst.get("id") == list_id:
                list_name = lst.get("name")
                break

    label_names: list[str | None] = []
    if label_ids and board_map:
        by_id = {lbl["id"]: lbl.get("name") for lbl in board_map.get("labels", [])}
        for lid in label_ids:
            label_names.append(by_id.get(lid))

    out: dict[str, Any] = {
        "id": card.get("id"),
        "name": card.get("name"),
        "list_id": list_id,
        "list_name": list_name,
        "label_ids": list(label_ids),
        "member_ids": list(member_ids),
        "due": card.get("due"),
        "due_complete": card.get("due_complete") if "due_complete" in card else card.get("dueComplete"),
        "closed": card.get("closed"),
        "date_last_activity": card.get("date_last_activity") or card.get("dateLastActivity"),
    }
    if not card.get("id") and (card.get("url") or card.get("shortUrl")):
        out["url"] = card.get("url") or card.get("shortUrl")
    if label_names:
        out["labels"] = label_names
        # When labels (names) are emitted, drop label_ids to save tokens.
        # Agent can cross-reference IDs from the board map if it needs them.
        out["label_ids"] = []
    elif isinstance(card.get("labels"), list) and card["labels"]:
        # Idempotence: a previously-normalized card has `labels` populated
        # but no `label_ids`. Pass the names through unchanged.
        out["labels"] = list(card["labels"])
        out["label_ids"] = []

    # Drop only None, empty containers, and empty strings.
    # IMPORTANT: do NOT drop False or 0 — those are meaningful values
    # (e.g. due_complete=False, closed=False).
    def _is_dropped(v: Any) -> bool:
        if v is None:
            return True
        if isinstance(v, (list, dict, str)) and len(v) == 0:
            return True
        return False
    return {k: v for k, v in out.items() if not _is_dropped(v)}


def card_receipt(
    card: dict[str, Any],
    board_map: dict[str, Any] | None = None,
    list_name: str | None = None,
    status: str = "changed",
) -> dict[str, Any]:
    """Compact mutation receipt for a card.

    Routes through normalize_card_output (the single chokepoint).
    Only adds the `status` key and optionally overrides `list_name`.
    Does not re-introduce keys that normalize_card_output dropped.
    """
    base = normalize_card_output(card, board_map)
    base["status"] = status
    if list_name is not None:
        base["list_name"] = list_name
    return base


def simplify_label(label: dict[str, Any]) -> dict[str, Any]:
    """Simplify a label object."""
    return {
        "id": label.get("id"),
        "name": label.get("name"),
        "color": label.get("color"),
    }


def simplify_list(list_obj: dict[str, Any]) -> dict[str, Any]:
    """Simplify a list object."""
    return {
        "id": list_obj.get("id"),
        "name": list_obj.get("name"),
        "closed": list_obj.get("closed"),
        "pos": list_obj.get("pos"),
        "board_id": list_obj.get("idBoard") or list_obj.get("board_id"),
    }


def simplify_board(board: dict[str, Any]) -> dict[str, Any]:
    """Simplify a board object."""
    return {
        "id": board.get("id"),
        "name": board.get("name"),
        "url": board.get("url") or board.get("shortUrl"),
    }


def simplify_card(
    card: dict[str, Any],
    include_description: bool = False,
    list_name: str | None = None,
    board_map: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Simplify a card object. Wrapper over normalize_card_output."""
    out = normalize_card_output(card, board_map)
    if list_name is not None:
        out["list_name"] = list_name
    if include_description and card.get("desc"):
        out["desc"] = card.get("desc")
    return out


def simplify_action(action: dict[str, Any]) -> dict[str, Any]:
    """Simplify an action object without member/avatar payloads."""
    compact = {
        "id": action.get("id"),
        "type": action.get("type"),
        "date": action.get("date"),
        "data": _compact_action_data(action.get("data", {})),
    }
    return {key: value for key, value in compact.items() if value is not None}


def _compact_action_data(data: dict[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {}
    for key, value in data.items():
        if key in {"member", "memberCreator"}:
            continue
        if isinstance(value, dict):
            compact[key] = {
                nested_key: nested_value
                for nested_key, nested_value in value.items()
                if nested_key not in {"avatarUrl", "initials", "username", "fullName"}
            }
        else:
            compact[key] = value
    return compact
