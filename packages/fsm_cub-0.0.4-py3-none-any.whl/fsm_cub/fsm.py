"""Finite state machines for entities whose state isn't just one boolean.

Two layers, mirroring `ecs_bear::FSM<State>` and `ecs_bear::EcsFSM<State>`:

  - `FSM[S]` — standalone state machine.  Knows nothing about events.
  - `EventBoundFSM[S]` — adds optional `Topic[StateChanged[S]]` publishing
    on every successful transition, so other systems can react without the
    FSM knowing they exist.

Both are Pydantic BaseModels so they round-trip through saves cleanly.  S
should be `StrEnum` or `IntEnum` — both round-trip through JSON cleanly.
Plain `Enum` works in memory but fails round-trip (JSON keys are strings, and
Pydantic can't coerce them back into a non-string Enum value).

Strict mode (`set_strict(True)` or `FSM_CUB_STRICT=1`) makes invalid
transitions raise instead of silently failing; default lenient.

See the project README and `examples/` for runnable usage.
"""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING, Any, Self

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, computed_field

from fsm_cub._strict import is_strict

if TYPE_CHECKING:
    from collections.abc import Callable

    from fsm_cub.events import Topic


class StateChanged[S](BaseModel):
    """Event emitted by `EventBoundFSM` after every successful transition.

    `entity_id` ties the event back to its source — useful when many entities
    share a topic (one Topic per state-enum, many entities per topic).
    """

    model_config = ConfigDict(frozen=True)

    entity_id: int = Field(default=-1, description="The entity that transitioned, or -1 if unbound.")
    from_state: S
    to_state: S


class FSM[S](BaseModel):
    """A standalone finite state machine.  Knows nothing about events.

    The transition table is a dict[from_state] → set[to_state].  Callbacks
    tied to specific states fire on enter/exit.  All state and configuration
    serializes through Pydantic for clean save round-trips.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    initial: S
    """The state the FSM starts in. Stored separately from `current` so a save knows where the machine *began* even after many transitions."""
    allowed: dict[S, set[S]] = Field(default_factory=dict)
    """Transition table: from_state → set of allowed destination states."""

    _on_enter: dict[Any, Callable[[], None]] = PrivateAttr(default_factory=dict)
    _on_exit: dict[Any, Callable[[], None]] = PrivateAttr(default_factory=dict)
    # Transition history is opt-in via `track_history()` — disabled by default
    # to keep the memory footprint zero for FSMs that don't need it.
    _history: deque[tuple[Any, Any]] | None = PrivateAttr(default=None)

    current_: S | None = Field(default=None, alias="current", exclude=True)
    _is_init: bool = PrivateAttr(default=False)

    @computed_field
    @property
    def current(self) -> S:
        """The currently-active state.

        `current` is None pre-init, but after construction it's always set to a valid state
        (defaulting to `initial` if not given).  If you try to access it before it's set,
        that's a bug — raise an error instead of silently returning None.
        """
        if self.current_ is None and self._is_init:
            raise ValueError("FSM: current state is not set yet and class was already initialized")
        if self.current_ is None:
            self.current_ = self.initial
        return self.current_

    @current.setter
    def current(self, value: S) -> None:
        self.current_ = value

    def model_post_init(self, _ctx: Any) -> None:
        """If `current` wasn't given, default it to `initial` (auto-start)."""
        if self.current_ is None:
            self.current = self.initial
        self._is_init = True

    def allow(self, from_state: S, to_state: S) -> Self:
        """Permit a transition from one state to another.  Returns self for chaining."""
        self.allowed.setdefault(from_state, set()).add(to_state)
        return self

    def allow_many(self, *transitions: tuple[S, S]) -> Self:
        """Bulk-add transitions: `fsm.allow_many((A, B), (B, C), (C, A))`.  Returns self."""
        for from_state, to_state in transitions:
            self.allow(from_state, to_state)
        return self

    def allow_bidirectional(self, a: S, b: S) -> Self:
        """Permit transitions in both directions: A↔B.  Sugar for `allow_many((a, b), (b, a))`."""
        return self.allow_many((a, b), (b, a))

    def on_enter(self, state: S, callback: Callable[[], None]) -> Self:
        """Register a callback that fires whenever the FSM enters `state`."""
        self._on_enter[state] = callback
        return self

    def on_exit(self, state: S, callback: Callable[[], None]) -> Self:
        """Register a callback that fires whenever the FSM leaves `state`."""
        self._on_exit[state] = callback
        return self

    # ── transitions ──────────────────────────────────────────────────────────

    def can_transition(self, to_state: S) -> bool:
        """True if a transition from `current` to `to_state` is currently allowed."""
        if self.current is None:
            return False
        return to_state in self.allowed.get(self.current, set())

    def transition(self, to_state: S) -> bool:
        """Move to `to_state` if the transition is allowed.

        Fires the exit callback for the old state, then the enter callback for
        the new one.  Returns True on success, False if not allowed (or raises
        ValueError if strict mode is on).
        """
        if not self.can_transition(to_state):
            if is_strict():
                raise ValueError(f"FSM: invalid transition {self.current!r} -> {to_state!r}")
            return False
        old: S | None = self.current
        if old is not None and (exit_cb := self._on_exit.get(old)):
            exit_cb()
        self.current = to_state
        if enter_cb := self._on_enter.get(to_state):
            enter_cb()
        if self._history is not None and old is not None:
            self._history.append((old, to_state))
        self._post_transition(old, to_state)
        return True

    def _post_transition(self, _old: S | None, _new: S) -> None:
        """Hook for subclasses (EventBoundFSM uses this to publish StateChanged)."""
        return

    def force(self, to_state: S) -> None:
        """Move to `to_state` regardless of the transition table.  Bypasses callbacks too.

        Useful for: loading from a save, test setup, "GM-mode" debugging.  Don't use
        as part of normal puzzle logic — that's what `transition` is for.
        """
        self.current = to_state

    def reset(self) -> None:
        """Return to `initial`, firing `on_exit(current)` then `on_enter(initial)`.

        Unlike `force()`, this respects callbacks — use it for game-over restarts
        or scene changes where cleanup/setup hooks need to run.  Bypasses the
        transition table on purpose (reset is structural, not user-puzzle).
        """
        old: S = self.current
        if exit_cb := self._on_exit.get(old):
            exit_cb()
        self.current = self.initial
        if enter_cb := self._on_enter.get(self.initial):
            enter_cb()
        if self._history is not None:
            self._history.append((old, self.initial))
        self._post_transition(old, self.initial)

    # ── history (opt-in) ──────────────────────────────────────────────────────

    def track_history(self, max_len: int = 64) -> Self:
        """Enable a bounded ring-buffer of `(from, to)` transition tuples.

        Off by default — opt in when you want a debug breadcrumb trail.  Old
        entries fall off the back when `max_len` is reached.  Calling this
        again with a new `max_len` replaces the buffer.  Returns self for chaining.
        """
        self._history = deque(maxlen=max_len)
        return self

    @property
    def history(self) -> tuple[tuple[S, S], ...]:
        """Recorded transitions as `(from, to)` tuples, oldest first.

        Empty tuple if `track_history()` was never called — that way callers
        can read `fsm.history` unconditionally without checking enablement.
        """
        if self._history is None:
            return ()
        return tuple(self._history)

    def clear_history(self) -> None:
        """Drop every recorded transition without disabling tracking."""
        if self._history is not None:
            self._history.clear()

    # ── queries ──────────────────────────────────────────────────────────────

    def is_(self, state: S) -> bool:
        """True if currently in `state`.  Trailing underscore avoids shadowing the `is` keyword."""
        return self.current == state

    def is_any(self, *states: S) -> bool:
        """True if currently in any of the listed states."""
        return self.current in states

    def transitions_from(self, state: S) -> set[S]:
        """Set of destination states reachable from `state`.  Empty set if unknown."""
        return set(self.allowed.get(state, set()))

    def all_states(self) -> set[S]:
        """Every state ever referenced in the transition table — derived, not declared."""
        result: set[S] = set()
        for from_state, tos in self.allowed.items():
            result.add(from_state)
            result.update(tos)
        return result


class EventBoundFSM[S](FSM[S]):
    """An FSM that publishes a `StateChanged[S]` event on every successful transition.

    Bind to a Topic with `bind(entity_id, topic)`.  Until bound, behaves
    identically to a plain FSM (no events emitted).  Unbinding restores
    standalone behavior.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    entity_id: int = -1
    """ID of the entity this FSM is attached to, for event payload routing."""
    # The topic is behavior/wiring, not state, so don't serialize it.  PrivateAttr
    # is the explicit Pydantic way: not a field, not in dumps, but assignable on
    # the instance and protected from accidentally being treated as data.
    _topic: Any = PrivateAttr(default=None)

    def bind(self, entity_id: int, topic: Topic[StateChanged[S]]) -> Self:
        """Wire this FSM into a Topic.  Subsequent transitions emit `StateChanged`."""
        self.entity_id = entity_id
        self._topic = topic
        return self

    def unbind(self) -> Self:
        """Stop publishing events.  Useful for tests / hot-swap."""
        self._topic = None
        return self

    def is_bound(self) -> bool:
        """True if this FSM is currently publishing to a topic."""
        return self._topic is not None

    def _post_transition(self, old: S | None, new: S) -> None:
        """Publish `StateChanged` to the bound topic (if any)."""
        if self._topic is None or old is None:
            return
        self._topic.emit(StateChanged[type(new)](entity_id=self.entity_id, from_state=old, to_state=new))
