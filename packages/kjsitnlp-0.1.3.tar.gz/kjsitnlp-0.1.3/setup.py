import os
from setuptools import setup, find_packages

# Read README for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="kjsitnlp",
    version="0.1.3",
    author="Your Name",
    author_email="your.email@example.com",
    description="A python library with pre-written codes, text files, and .ipynb files",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/kjsitnlp",
    packages=find_packages(),
    include_package_data=True, # This allows us to include non-python files defined in MANIFEST.in
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    entry_points={
        'console_scripts': [
            'kjsitnlp=kjsitnlp.cli:main',
        ],
    },
)
