import os
import sys
import shutil
from pathlib import Path

def main():
    if len(sys.argv) > 1:
        dest_dir = sys.argv[1]
    else:
        # Default to the current terminal directory
        dest_dir = os.getcwd()
    
    # Get the directory where this package is installed
    package_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(package_dir, "data")
    
    if not os.path.exists(data_dir):
        print(f"Error: Could not find the data directory inside the package at {data_dir}")
        sys.exit(1)
        
    try:
        # If destination doesn't exist, create it
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
            print(f"Created destination directory: {dest_dir}")
            
        print(f"Extracting files to {dest_dir}...")
        
        # Copy everything from data_dir to dest_dir
        for item in os.listdir(data_dir):
            s = os.path.join(data_dir, item)
            d = os.path.join(dest_dir, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, dirs_exist_ok=True)
            else:
                shutil.copy2(s, d)
                
        print("Success! All files have been extracted.")
    except Exception as e:
        print(f"An error occurred while copying files: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
