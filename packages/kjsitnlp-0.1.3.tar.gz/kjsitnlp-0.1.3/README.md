# kjsitnlp

A Python library containing pre-written code, text files, and Jupyter notebooks.

## Installation

```bash
pip install kjsitnlp
```

## Extracting Files

To copy the bundled files to a specific directory (like `D:\my_kjsit_files`):

```bash
kjsitnlp-extract D:\my_kjsit_files
```
