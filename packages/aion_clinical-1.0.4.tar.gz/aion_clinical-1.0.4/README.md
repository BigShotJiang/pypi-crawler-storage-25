# AION — Algebraic Interval Ontology for Clinical Networks

> Formal temporal and causal structure for consistent clinical data across systems.

[![Tests](https://img.shields.io/badge/tests-326%20passing-brightgreen)](https://codeberg.org/fm2-project/aion)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org)
[![License](https://img.shields.io/badge/license-EUPL--1.2-blue)](LICENSE)
[![FHIR R4](https://img.shields.io/badge/FHIR-R4-orange)](https://hl7.org/fhir/R4/)

---

Clinical data systems often produce inconsistent results.

Not because of missing interfaces —  
but because **time, semantics and causality are not modelled consistently**.

AION makes clinical data **consistent and verifiable** across systems.

It provides a **formal, executable structure** to:
- represent clinical events over time
- define and validate relationships between them
- support reproducible analytics
- enable reliable AI and interoperable data interpretation

---

## Why AION?

Most systems can exchange clinical data.

The harder problem begins afterwards:
- data is interpreted differently across systems
- temporal relations remain implicit
- causal assumptions are hidden in project-specific logic
- analytics become difficult to compare and reproduce

AION addresses this structural layer directly.

Instead of modelling isolated data points only, AION models:
- **intervals instead of points**
- **relations instead of implicit assumptions**
- **causal structures instead of static data**
- **verifiable consistency instead of hidden transformation logic**

---

## Quick Start

```bash
pip install aion-clinical
```

```python
from aion.core import Interval, classify
import datetime

dt = lambda h: datetime.datetime(2024, 1, 1, h, 0)

anaesthesia = Interval(dt(7), dt(12))
operation   = Interval(dt(8), dt(11))

print(classify(anaesthesia, operation))
# -> AllenRelation.CONTAINS
```

This means:
- the events are not just stored
- their **temporal relationship** is explicitly defined
- that relationship can be checked and reused across analyses

---

## What makes AION different?

Most clinical systems model events as isolated records.

AION models the **structure between events**.

This enables:
- consistent temporal reasoning
- reproducible analytics
- explicit causal modelling
- formal validation of data structures
- better reuse across systems and projects

---

## Core Capabilities

### Temporal Model
- Complete Allen interval algebra (13 relations)
- Fuzzy intervals with probabilistic reasoning

### Data Model
- Universal clinical event model (6-tuple)
- Type system with hierarchy and schema evolution

### Query & Analytics
- Cohort algebra
- Temporal pattern languages

### Causal Inference
- Causal graphs
- Do-operator
- Structure learning

### AI Integration
- Formal AI component model
- Explainability (Shapley, counterfactuals)

### Privacy
- Differential privacy (Laplace / Gaussian)
- Federated computation

### Interoperability
- FHIR mapping via structural homomorphism

---

## Example: Cohort Query

```python
from aion.query.cohort import query_event_sequence

q = query_event_sequence("Diagnosis", "Procedure")
cohort = q.evaluate(ctx)
```

---

## Example: Causal Analysis

```python
from aion.causal.graph import CausalGraph
from aion.causal.do import DoOperator

g = CausalGraph()
g.add_edge("Diagnosis", "Procedure")

do = DoOperator(g, data)
result = do.intervene("Procedure", "Outcome")
```

---

## Architecture Overview

```text
aion/
├── core        Temporal algebra, event model
├── abstraction Episodes and trajectories
├── query       Cohort algebra
├── causal      Causal inference
├── privacy     Differential privacy
├── ai          AI model integration
├── explain     Explainability
├── schema      Schema evolution
└── adapters    FHIR mapping
```

---

## Test Suite

```bash
pytest aion/tests/
# 326 tests, ~2s runtime
```

---

## Positioning

AION is not:
- a data format
- a data warehouse
- a FHIR replacement

AION is:
> **the structural consistency layer beneath clinical data systems**

---

## Formal Foundation

AION generalises earlier formal work into a domain-independent structure for clinical information systems.

It formalises, among others:
- temporal relations
- event structure
- abstraction layers
- cohort logic
- causal inference
- explainability
- schema evolution
- privacy-preserving federation
- FHIR-compatible structural mapping

---

## License & Citation

EUPL-1.2 — open source  
Commercial licensing: `licensing@iscad-it.de`

```bibtex
@software{aion2026,
  title  = {AION: Algebraic Interval Ontology for Clinical Networks},
  author = {Matten, Friedhelm},
  year   = {2026},
  url    = {https://codeberg.org/fm2-project/aion}
}
```

© Friedhelm Matten, ISCaD GmbH
