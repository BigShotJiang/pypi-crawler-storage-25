"""
tibet-tail CLI — Main entry point.

Usage::

    tibet-tail                      # Live stream (default)
    tibet-tail --history 100        # Show last 100 events first
    tibet-tail --cat ains           # Filter by category
    tibet-tail --cat ipoll          # I-Poll messages
    tibet-tail --cat ains_claim     # Domain claim events
    tibet-tail --level ERROR        # Only errors
    tibet-tail --json               # Raw JSON output
    tibet-tail --file               # Read JSONL directly (no API)
    tibet-tail tui                  # Interactive TUI node monitor
"""

import argparse
import json
import os
import sys

from .formatter import VERSION
from .stream import DEFAULT_API, JSONL_PATH


def run(args) -> int:
    """Main event loop."""
    from rich.console import Console

    from .formatter import format_event_rich, print_banner, print_summary
    from .stats import Stats
    from .stream import load_history, stream_from_file, stream_from_sse

    console = Console()

    if not args.file:
        try:
            import httpx  # noqa: F401
            from httpx_sse import connect_sse  # noqa: F401
        except ImportError:
            print("Error: httpx-sse package required for SSE mode.", file=sys.stderr)
            print("Install with: pip install httpx httpx-sse", file=sys.stderr)
            print("Or use --file mode to tail the JSONL directly.", file=sys.stderr)
            return 1

    # Parse filters
    cat_filter = set()
    if args.cat:
        cat_filter = set(c.strip() for c in args.cat.split(","))

    level_filter = args.level.upper() if args.level else ""

    print_banner(console, args)

    stats = Stats()

    # Show history first if requested
    if args.history and not args.file:
        console.print(f"[dim]\u2500\u2500 Loading last {args.history} events \u2500\u2500[/]")
        events = load_history(args.api, args.history, cat_filter)
        for ev in events:
            if level_filter and ev.get("level") != level_filter:
                continue
            if args.json:
                print(json.dumps(ev, ensure_ascii=False))
            else:
                format_event_rich(ev, console)
            stats.record(ev)
        if events:
            console.print(f"[dim]\u2500\u2500 {len(events)} historical events loaded \u2500\u2500[/]")
            console.print()

    # Live stream
    console.print("[bold cyan]\u25b8 Listening for events...[/]")
    console.print()

    event_count = 0
    summary_interval = 25  # Print summary every N events

    try:
        if args.file:
            jsonl_path = os.environ.get("TIBET_TAIL_JSONL", JSONL_PATH)
            source = stream_from_file(jsonl_path, cat_filter, level_filter)
        else:
            source = stream_from_sse(args.api, cat_filter, level_filter)

        for event in source:
            # Handle SSE connection message
            if event.get("_connected"):
                console.print(f"[green]\u2713 {event.get('msg', 'Connected')}[/]")
                continue

            stats.record(event)
            event_count += 1

            if args.json:
                print(json.dumps(event, ensure_ascii=False), flush=True)
            else:
                format_event_rich(event, console)

            # Periodic summary
            if event_count % summary_interval == 0:
                console.print()
                print_summary(console, stats)
                console.print()

    except KeyboardInterrupt:
        console.print()
        console.print("=" * 60, style="dim")
        console.print()
        print_summary(console, stats)
        console.print()
        console.print(f"  [dim]tibet-tail stopped. {stats.total} events captured in {stats.uptime_str}[/]")
        console.print("=" * 60, style="dim")
        console.print()
        return 0
    except Exception as e:
        import httpx as _httpx

        if isinstance(e, _httpx.ConnectError):
            console.print("[bold red]\u2717 Cannot connect to brain_api[/]")
            console.print(f"  [dim]URL: {args.api}[/]")
            console.print("  [dim]Is brain_api running? Check: systemctl status brain_api[/]")
            return 1
        console.print(f"[bold red]\u2717 Error: {e}[/]")
        return 1


def run_tui_mode() -> int:
    """Launch the interactive TUI node monitor."""
    try:
        from .tui import run_tui
    except ImportError:
        print("Error: TUI requires 'textual' package.", file=sys.stderr)
        print("Install with: pip install tibet-tail[tui]", file=sys.stderr)
        return 1
    run_tui()
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-tail",
        description="Live AInternet Event Viewer \u2014 tail -f for the AInternet",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Modes:
  tibet-tail                          Stream mode (default)
  tibet-tail tui                      Interactive TUI node monitor

Categories:
  ains        AINS name resolution (green)
  ami         Asterisk AMI commands (yellow)
  tibet       TIBET token events (magenta)
  call        Call flow events (cyan)
  resolve     SIP resolution (blue)
  devices     Device listing (white)
  delegation  Delegation events (green bg)
  handoff     Handoff events (blue bg)
  ipoll       I-Poll messages (red bg)
  ains_claim  Domain claim events (blue bg)
  general     Other events (dim)

Examples:
  tibet-tail                          Live stream all events
  tibet-tail tui                      Interactive node monitor
  tibet-tail --history 50             Show 50 recent + live
  tibet-tail --cat ains               Only AINS events
  tibet-tail --cat ipoll              Only I-Poll events
  tibet-tail --cat ains,tibet         AINS + TIBET events
  tibet-tail --level ERROR            Only errors
  tibet-tail --file                   Tail JSONL file directly
  tibet-tail --json                   Raw JSON output (pipeable)
  tibet-tail --json | jq .cat         Extract categories with jq
""",
    )

    # Subcommands
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("tui", help="Interactive TUI node monitor (like htop for the AInternet)")

    parser.add_argument(
        "--api", default=DEFAULT_API,
        help=f"Brain API URL (default: {DEFAULT_API})",
    )
    parser.add_argument(
        "--cat", "-c", default="",
        help="Filter by category (comma-separated: ains,tibet,ipoll,ains_claim)",
    )
    parser.add_argument(
        "--level", "-l", default="",
        help="Filter by level (ERROR, WARNING, INFO, DEBUG)",
    )
    parser.add_argument(
        "--history", "-n", type=int, default=0,
        help="Show N recent events before live stream",
    )
    parser.add_argument(
        "--json", "-j", action="store_true",
        help="Output raw JSON (for piping to jq etc.)",
    )
    parser.add_argument(
        "--file", "-f", action="store_true",
        help=f"Tail JSONL file directly instead of SSE ({JSONL_PATH})",
    )
    parser.add_argument(
        "--version", "-V", action="version",
        version=f"tibet-tail {VERSION}",
    )

    args = parser.parse_args()

    # Route to TUI or stream mode
    if args.command == "tui":
        sys.exit(run_tui_mode())
    else:
        sys.exit(run(args))


if __name__ == "__main__":
    main()
