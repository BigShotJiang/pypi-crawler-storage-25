"""
tibet-tail formatter — Rich and plain-text event formatters.
"""

from datetime import datetime, timezone

from rich.console import Console
from rich.text import Text

from .categories import CAT_STYLE, LEVEL_STYLE
from .stats import Stats


VERSION = "0.2.0"


def format_event_rich(event: dict, console: Console) -> None:
    """Print a single event with rich formatting."""
    ts = event.get("ts", "")
    # Show only HH:MM:SS from ISO timestamp
    if "T" in ts:
        ts = ts.split("T")[1][:8]

    cat = event.get("cat", "general")
    level = event.get("level", "INFO")
    msg = event.get("msg", "")
    pid = event.get("pid", "")

    cat_style, cat_icon = CAT_STYLE.get(cat, ("dim", "  "))
    level_style = LEVEL_STYLE.get(level, "")

    # Build the line
    text = Text()
    text.append(f" {ts} ", style="dim")
    text.append(f"{cat_icon} ", style=cat_style)
    text.append(f"{cat:10s}", style=cat_style)
    text.append(" \u2502 ", style="dim")

    if level == "ERROR":
        text.append(f"\u2717 {msg}", style="bold red")
    elif level == "WARNING":
        text.append(f"\u26a0 {msg}", style="bold yellow")
    else:
        text.append(msg, style=level_style)

    if pid:
        text.append(f"  [{pid}]", style="dim")

    console.print(text)


def format_event_plain(event: dict) -> str:
    """Format event as plain text (no colors)."""
    ts = event.get("ts", "")
    if "T" in ts:
        ts = ts.split("T")[1][:8]
    cat = event.get("cat", "general")
    level = event.get("level", "INFO")
    msg = event.get("msg", "")
    pid = event.get("pid", "")
    return f"{ts} [{cat:10s}] {level:7s} {msg}  [{pid}]"


def print_summary(console: Console, stats: Stats) -> None:
    """Print a summary status bar."""
    parts = []
    for cat, (style, icon) in CAT_STYLE.items():
        count = stats.by_cat.get(cat, 0)
        if count > 0:
            parts.append(f"[{style}]{icon} {cat}={count}[/]")

    errors = stats.errors
    err_str = f"[bold red]\u2717 {errors} errors[/]" if errors else "[green]\u2713 0 errors[/]"
    now = datetime.now(timezone.utc).strftime("%H:%M:%S")

    console.print(
        f" {err_str}  \u2502  "
        + "  ".join(parts)
        + f"  \u2502  total={stats.total}  \u2502  uptime={stats.uptime_str}  \u2502  {now} UTC",
        highlight=False,
    )


def print_banner(console: Console, args) -> None:
    """Print startup banner."""
    console.print()
    console.print("=" * 60, style="dim")
    console.print(f"  \U0001f4e1 [bold]tibet-tail[/] v{VERSION} \u2014 Live AInternet Event Viewer")
    console.print(f"     Source: {'JSONL file' if args.file else 'SSE stream'}", style="dim")
    if args.cat:
        console.print(f"     Filter: {args.cat}", style="dim")
    if args.level:
        console.print(f"     Level:  {args.level}", style="dim")
    console.print("     Press [bold]Ctrl+C[/] to stop", style="dim")
    console.print("=" * 60, style="dim")
    console.print()
