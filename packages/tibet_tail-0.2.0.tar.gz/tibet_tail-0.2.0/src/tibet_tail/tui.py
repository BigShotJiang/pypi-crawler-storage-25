"""
tibet-tail TUI -- Interactive AInternet Node Monitor

Like htop, but for the AInternet.
Each .aint domain is a node. Events flow through nodes.
Select a node to see its details and recent traffic.

Keybindings:
    R  -- Refresh (reload AINS + events)
    L  -- Toggle log stream view
    D  -- Toggle detail panel
    F  -- Cycle category filter
    J  -- Export JSON snapshot
    Q  -- Quit
"""

import json
import os
import threading
import time
from datetime import datetime, timezone
from typing import Optional

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.reactive import reactive
from textual.timer import Timer
from textual.widgets import (
    DataTable,
    Footer,
    Header,
    RichLog,
    Static,
)

from .categories import CAT_ICON
from .stream import JSONL_PATH


# -- Constants ---------------------------------------------------------------

AINS_REGISTRY = os.environ.get(
    "TIBET_TAIL_AINS_REGISTRY",
    "/srv/jtel-stack/brain_api/ains_registry.json",
)
MAX_NODE_EVENTS = 50  # Keep last N events per node

ENTITY_ICON = {
    "idd":     "\U0001f916",
    "ai":      "\U0001f9e0",
    "human":   "\U0001f464",
    "device":  "\U0001f4e1",
    "service": "\u2699\ufe0f",
}

STATUS_THRESHOLDS = {
    "active": 60,       # Event within last 60s
    "idle":   600,      # Event within last 10m
    "quiet":  999999,   # Everything else
}


# -- Node state --------------------------------------------------------------

class NodeState:
    """Track a single .aint domain's state and event history."""

    __slots__ = (
        "domain", "entity_type", "trust_score", "jis_identity",
        "description", "capabilities", "sip_extension", "tibet_protected",
        "hardware", "device_ip", "status", "owner",
        "events", "event_count", "last_event_at", "error_count",
    )

    def __init__(self, domain: str, data: dict):
        self.domain = domain
        self.entity_type = data.get("entity_type", "?")
        self.trust_score = data.get("trust_score", 0.0)
        self.jis_identity = data.get("jis_identity", "")
        self.description = data.get("description", "")
        self.capabilities = data.get("capabilities", [])
        self.owner = data.get("owner", "")

        sip = data.get("sip_bridge", {})
        self.sip_extension = sip.get("extension", "")
        self.tibet_protected = sip.get("tibet_protected", False)
        self.device_ip = sip.get("device_ip", "")

        hw = data.get("hardware", {})
        self.hardware = f"{hw['manufacturer']} {hw['model']}" if hw.get("manufacturer") else ""

        self.status = data.get("status", "unknown")
        self.events: list[dict] = []
        self.event_count = 0
        self.last_event_at: Optional[datetime] = None
        self.error_count = 0

    def add_event(self, event: dict) -> None:
        self.events.append(event)
        if len(self.events) > MAX_NODE_EVENTS:
            self.events.pop(0)
        self.event_count += 1
        self.last_event_at = datetime.now(timezone.utc)
        if event.get("level") == "ERROR":
            self.error_count += 1

    @property
    def age_str(self) -> str:
        if not self.last_event_at:
            return "\u2014"
        delta = (datetime.now(timezone.utc) - self.last_event_at).total_seconds()
        if delta < 60:
            return f"{int(delta)}s"
        elif delta < 3600:
            return f"{int(delta // 60)}m"
        else:
            return f"{int(delta // 3600)}h"

    @property
    def activity_status(self) -> str:
        if not self.last_event_at:
            return "quiet"
        age = (datetime.now(timezone.utc) - self.last_event_at).total_seconds()
        if age < STATUS_THRESHOLDS["active"]:
            return "active"
        elif age < STATUS_THRESHOLDS["idle"]:
            return "idle"
        return "quiet"

    @property
    def status_display(self) -> str:
        s = self.activity_status
        if s == "active":
            return "[bold green]\u25cf active [/]"
        elif s == "idle":
            return "[bold yellow]\u25cf idle   [/]"
        return "[dim]\u25cb quiet  [/]"

    @property
    def last_event_summary(self) -> str:
        if not self.events:
            return "[dim]\u2014[/]"
        ev = self.events[-1]
        cat = ev.get("cat", "")
        msg = ev.get("msg", "")
        icon = CAT_ICON.get(cat, "")
        # Truncate message
        if len(msg) > 45:
            msg = msg[:42] + "..."
        return f"{icon} {msg}"

    @property
    def icon(self) -> str:
        return ENTITY_ICON.get(self.entity_type, "\u2753")

    @property
    def sort_key(self) -> tuple:
        """Sort: active first, then by event count descending."""
        status_order = {"active": 0, "idle": 1, "quiet": 2}
        return (status_order.get(self.activity_status, 3), -self.event_count)


# -- Summary bar -------------------------------------------------------------

class SummaryBar(Static):
    """Top bar with overall stats."""

    def update_stats(self, nodes: list[NodeState], total_events: int, uptime_secs: int) -> None:
        active = sum(1 for n in nodes if n.activity_status == "active")
        idle = sum(1 for n in nodes if n.activity_status == "idle")
        quiet = sum(1 for n in nodes if n.activity_status == "quiet")
        errors = sum(n.error_count for n in nodes)

        # Cat counts from all events
        cat_counts = {}
        for n in nodes:
            for ev in n.events:
                c = ev.get("cat", "general")
                cat_counts[c] = cat_counts.get(c, 0) + 1

        # Health
        if errors == 0 and active > 0:
            grade = "[bold green]HEALTHY[/]"
        elif errors > 0:
            grade = "[bold red]DEGRADED[/]" if errors > 3 else "[bold yellow]WARNING[/]"
        else:
            grade = "[bold cyan]LISTENING[/]"

        # Uptime
        if uptime_secs < 60:
            up = f"{uptime_secs}s"
        elif uptime_secs < 3600:
            up = f"{uptime_secs // 60}m{uptime_secs % 60}s"
        else:
            up = f"{uptime_secs // 3600}h{(uptime_secs % 3600) // 60}m"

        # Cat parts
        cat_parts = []
        for cat, icon in CAT_ICON.items():
            cnt = cat_counts.get(cat, 0)
            if cnt > 0:
                cat_parts.append(f"{icon}{cnt}")

        now = datetime.now(timezone.utc).strftime("%H:%M:%S")
        err_str = f"[bold red]\u2717{errors}[/]" if errors else "[green]\u27130[/]"

        self.update(
            f" {grade}  \u2502  "
            f"[green]{active}[/] active  [yellow]{idle}[/] idle  [dim]{quiet}[/] quiet  \u2502  "
            f"{'  '.join(cat_parts)}  \u2502  "
            f"err={err_str}  events={total_events}  \u2502  up {up}  \u2502  {now} UTC"
        )


# -- Detail panel ------------------------------------------------------------

class DetailPanel(Static):
    """Bottom panel showing selected node details."""

    def show_node(self, node: Optional[NodeState]) -> None:
        if node is None:
            self.update("[dim]Select a node to see details[/]")
            return

        tibet = "[green]YES[/]" if node.tibet_protected else "[dim]no[/]"
        trust_color = "green" if node.trust_score >= 0.8 else "yellow" if node.trust_score >= 0.5 else "red"

        lines = [
            f"[bold]{node.icon} {node.domain}[/]  {node.status_display}",
            f"[dim]JIS:[/] {node.jis_identity or '\u2014'}    [dim]Trust:[/] [{trust_color}]{node.trust_score}[/]    [dim]TIBET:[/] {tibet}",
        ]

        info_parts = []
        if node.sip_extension:
            info_parts.append(f"[dim]Ext:[/] {node.sip_extension}")
        if node.hardware:
            info_parts.append(f"[dim]HW:[/] {node.hardware}")
        if node.device_ip:
            info_parts.append(f"[dim]IP:[/] {node.device_ip}")
        if node.owner:
            info_parts.append(f"[dim]Owner:[/] {node.owner}")
        if info_parts:
            lines.append("    ".join(info_parts))

        if node.capabilities:
            lines.append(f"[dim]Caps:[/] {', '.join(node.capabilities[:6])}")

        if node.description:
            lines.append(f"[dim]{node.description}[/]")

        # Recent events
        if node.events:
            lines.append("")
            lines.append(f"[bold]Recent events[/] ({node.event_count} total, {node.error_count} errors):")
            for ev in reversed(node.events[-8:]):
                ts = ev.get("ts", "")
                if "T" in ts:
                    ts = ts.split("T")[1][:8]
                cat = ev.get("cat", "")
                level = ev.get("level", "INFO")
                msg = ev.get("msg", "")
                icon = CAT_ICON.get(cat, "")

                if level == "ERROR":
                    lines.append(f"  {ts}  {icon} [bold red]\u2717 {msg[:80]}[/]")
                elif level == "WARNING":
                    lines.append(f"  {ts}  {icon} [yellow]\u26a0 {msg[:80]}[/]")
                else:
                    lines.append(f"  {ts}  {icon} {msg[:80]}")
        else:
            lines.append("\n[dim]No events yet[/]")

        self.update("\n".join(lines))


# -- Event reader thread -----------------------------------------------------

class EventReader:
    """Background thread that tails the JSONL file."""

    def __init__(self):
        self.events: list[dict] = []
        self.lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._tail, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def drain(self) -> list[dict]:
        """Get and clear pending events."""
        with self.lock:
            events = self.events[:]
            self.events.clear()
            return events

    def _tail(self):
        """Tail the JSONL file continuously."""
        jsonl_path = JSONL_PATH

        # Read existing events first
        if os.path.exists(jsonl_path):
            try:
                with open(jsonl_path, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                ev = json.loads(line)
                                with self.lock:
                                    self.events.append(ev)
                            except (json.JSONDecodeError, ValueError):
                                pass
            except Exception:
                pass

        # Now tail for new events
        try:
            with open(jsonl_path, "r") as f:
                f.seek(0, 2)  # End of file
                while self._running:
                    line = f.readline()
                    if not line:
                        time.sleep(0.3)
                        continue
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        ev = json.loads(line)
                        with self.lock:
                            self.events.append(ev)
                    except (json.JSONDecodeError, ValueError):
                        pass
        except FileNotFoundError:
            # Wait for file to appear
            while self._running and not os.path.exists(jsonl_path):
                time.sleep(1)
            if self._running:
                self._tail()  # Retry


# -- Main TUI App -----------------------------------------------------------

class TibetTailApp(App):
    """tibet-tail -- Live AInternet Node Monitor"""

    TITLE = "tibet-tail"
    SUB_TITLE = "Live AInternet Monitor"

    CSS = """
    Screen {
        layout: vertical;
    }
    #summary-bar {
        height: 1;
        background: $surface;
        color: $text;
        padding: 0 1;
    }
    #node-table {
        height: 1fr;
    }
    #detail-panel {
        height: auto;
        max-height: 16;
        border-top: solid $primary;
        padding: 0 1;
        background: $surface;
    }
    #log-panel {
        height: 10;
        border-top: solid $accent;
        background: $surface;
        display: none;
    }
    DataTable {
        height: 1fr;
    }
    DataTable > .datatable--cursor {
        background: $accent 30%;
    }
    """

    BINDINGS = [
        Binding("r", "refresh", "Refresh", show=True),
        Binding("l", "toggle_log", "Log", show=True),
        Binding("d", "toggle_detail", "Detail", show=True),
        Binding("j", "export_json", "JSON", show=True),
        Binding("q", "quit", "Quit", show=True),
    ]

    show_detail: reactive[bool] = reactive(True)
    show_log: reactive[bool] = reactive(False)

    def __init__(self):
        super().__init__()
        self.nodes: dict[str, NodeState] = {}
        self.total_events = 0
        self.started_at = datetime.now(timezone.utc)
        self.reader = EventReader()
        self._poll_timer: Optional[Timer] = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield SummaryBar(id="summary-bar")
        yield DataTable(id="node-table")
        yield DetailPanel(id="detail-panel")
        yield RichLog(id="log-panel", highlight=True, markup=True)
        yield Footer()

    def on_mount(self) -> None:
        self._load_ains_registry()

        table = self.query_one(DataTable)
        table.cursor_type = "row"
        table.add_columns("", "Status", "Domain", "Type", "Trust", "Ext", "Last Event", "#", "Age")
        self._refresh_table()
        self._update_summary()

        # Start event reader and polling
        self.reader.start()
        self._poll_timer = self.set_interval(0.5, self._poll_events)

    def _load_ains_registry(self) -> None:
        """Load all .aint domains as nodes."""
        try:
            with open(AINS_REGISTRY, "r") as f:
                data = json.load(f)
            for domain, ddata in data.get("domains", {}).items():
                if domain not in self.nodes:
                    self.nodes[domain] = NodeState(domain, ddata)
        except Exception:
            pass

    def _match_event_to_node(self, event: dict) -> Optional[str]:
        """Try to match an event to a .aint domain."""
        msg = event.get("msg", "")
        extra = event.get("extra", {})

        # Check extra fields first
        for field in ("to_jis", "from_jis", "domain"):
            val = extra.get(field, "")
            if val:
                # Match by jis_identity
                for domain, node in self.nodes.items():
                    if node.jis_identity == val:
                        return domain
                # Match by domain name
                if val in self.nodes:
                    return val
                # Match by .aint suffix
                if not val.endswith(".aint"):
                    candidate = val + ".aint"
                    if candidate in self.nodes:
                        return candidate

        # Check extension in extra
        for field in ("from_ext", "to_ext", "from", "to"):
            ext = str(extra.get(field, ""))
            if ext:
                for domain, node in self.nodes.items():
                    if node.sip_extension == ext:
                        return domain

        # Fuzzy: scan message for domain names or extensions
        for domain, node in self.nodes.items():
            if node.jis_identity and node.jis_identity in msg:
                return domain
            if node.sip_extension and f"PJSIP/{node.sip_extension}" in msg:
                return domain
            if domain.replace(".aint", "") in msg:
                return domain

        return None

    def _poll_events(self) -> None:
        """Called periodically to drain new events from reader."""
        new_events = self.reader.drain()
        if not new_events:
            # Still update summary for age changes
            self._update_summary()
            return

        log_panel = self.query_one(RichLog)

        for event in new_events:
            self.total_events += 1

            # Route event to a node
            domain = self._match_event_to_node(event)
            if domain and domain in self.nodes:
                self.nodes[domain].add_event(event)

            # Write to log panel
            if self.show_log:
                ts = event.get("ts", "")
                if "T" in ts:
                    ts = ts.split("T")[1][:8]
                cat = event.get("cat", "general")
                level = event.get("level", "INFO")
                msg = event.get("msg", "")
                icon = CAT_ICON.get(cat, "")

                if level == "ERROR":
                    log_panel.write(f"[dim]{ts}[/] {icon} [bold red]\u2717 {msg}[/]")
                elif level == "WARNING":
                    log_panel.write(f"[dim]{ts}[/] {icon} [yellow]\u26a0 {msg}[/]")
                else:
                    log_panel.write(f"[dim]{ts}[/] {icon} {msg}")

        self._refresh_table()
        self._update_summary()

        # Update detail panel for selected node
        if self.show_detail:
            node = self._selected_node()
            self.query_one(DetailPanel).show_node(node)

    def _refresh_table(self) -> None:
        """Rebuild the node table."""
        table = self.query_one(DataTable)
        cursor_row = table.cursor_row

        table.clear()

        # Sort nodes: active first, then by event count
        sorted_nodes = sorted(self.nodes.values(), key=lambda n: n.sort_key)

        for node in sorted_nodes:
            icon = node.icon
            status = node.status_display
            domain = node.domain
            etype = node.entity_type
            trust = f"{node.trust_score:.1f}"
            ext = node.sip_extension or "[dim]\u2014[/]"
            last = node.last_event_summary
            count = str(node.event_count) if node.event_count else "[dim]0[/]"
            age = node.age_str

            table.add_row(icon, status, domain, etype, trust, ext, last, count, age, key=domain)

        # Restore cursor
        if cursor_row is not None and cursor_row < len(sorted_nodes):
            table.move_cursor(row=cursor_row)

    def _update_summary(self) -> None:
        uptime = int((datetime.now(timezone.utc) - self.started_at).total_seconds())
        self.query_one(SummaryBar).update_stats(
            list(self.nodes.values()), self.total_events, uptime
        )

    def _selected_node(self) -> Optional[NodeState]:
        table = self.query_one(DataTable)
        if table.cursor_row is not None:
            try:
                sorted_nodes = sorted(self.nodes.values(), key=lambda n: n.sort_key)
                if table.cursor_row < len(sorted_nodes):
                    return sorted_nodes[table.cursor_row]
            except (IndexError, KeyError):
                pass
        return None

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if self.show_detail:
            node = self._selected_node()
            self.query_one(DetailPanel).show_node(node)

    # -- Actions -----------------------------------------------------------

    def action_refresh(self) -> None:
        """R -- Reload AINS registry and refresh."""
        self._load_ains_registry()
        self._refresh_table()
        self._update_summary()
        self.notify("AINS registry reloaded", severity="information")

    def action_toggle_log(self) -> None:
        """L -- Toggle live log stream panel."""
        self.show_log = not self.show_log
        panel = self.query_one("#log-panel")
        panel.display = self.show_log
        if self.show_log:
            self.notify("Log stream ON", severity="information")
        else:
            self.notify("Log stream OFF", severity="information")

    def action_toggle_detail(self) -> None:
        """D -- Toggle detail panel."""
        self.show_detail = not self.show_detail
        panel = self.query_one(DetailPanel)
        panel.display = self.show_detail
        if self.show_detail:
            panel.show_node(self._selected_node())

    def action_export_json(self) -> None:
        """J -- Export current state as JSON."""
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"tibet-tail-snapshot_{ts}.json"

        data = {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "total_events": self.total_events,
            "uptime_seconds": int((datetime.now(timezone.utc) - self.started_at).total_seconds()),
            "nodes": {
                domain: {
                    "entity_type": node.entity_type,
                    "trust_score": node.trust_score,
                    "jis_identity": node.jis_identity,
                    "sip_extension": node.sip_extension,
                    "activity_status": node.activity_status,
                    "event_count": node.event_count,
                    "error_count": node.error_count,
                    "last_event_age": node.age_str,
                    "recent_events": node.events[-5:],
                }
                for domain, node in self.nodes.items()
            },
        }

        with open(filename, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        self.notify(f"Exported: {filename}", severity="information")

    def on_unmount(self) -> None:
        self.reader.stop()


# -- Entry point -------------------------------------------------------------

def run_tui() -> None:
    """Launch the tibet-tail TUI."""
    app = TibetTailApp()
    app.run()


if __name__ == "__main__":
    run_tui()
