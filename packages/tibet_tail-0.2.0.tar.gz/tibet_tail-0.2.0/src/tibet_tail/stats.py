"""
tibet-tail stats — Event statistics tracker.
"""

from datetime import datetime, timezone


class Stats:
    """Track event counts and rates."""

    __slots__ = ("total", "by_cat", "by_level", "errors", "started_at", "last_event_at")

    def __init__(self):
        self.total = 0
        self.by_cat = {}
        self.by_level = {}
        self.errors = 0
        self.started_at = datetime.now(timezone.utc)
        self.last_event_at = None

    def record(self, event: dict) -> None:
        self.total += 1
        cat = event.get("cat", "general")
        level = event.get("level", "INFO")
        self.by_cat[cat] = self.by_cat.get(cat, 0) + 1
        self.by_level[level] = self.by_level.get(level, 0) + 1
        if level == "ERROR":
            self.errors += 1
        self.last_event_at = datetime.now(timezone.utc)

    @property
    def uptime_str(self) -> str:
        delta = datetime.now(timezone.utc) - self.started_at
        secs = int(delta.total_seconds())
        if secs < 60:
            return f"{secs}s"
        elif secs < 3600:
            return f"{secs // 60}m{secs % 60}s"
        else:
            return f"{secs // 3600}h{(secs % 3600) // 60}m"
