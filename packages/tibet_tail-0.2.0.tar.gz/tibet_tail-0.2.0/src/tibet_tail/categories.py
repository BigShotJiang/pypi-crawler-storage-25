"""
tibet-tail categories — Single source of truth for event categories and styles.
"""

# Category colors and icons
CAT_STYLE = {
    "ains":       ("bold green",                    "\U0001f310"),   # globe
    "ami":        ("bold yellow",                   "\U0001f4e1"),   # satellite
    "tibet":      ("bold magenta",                  "\U0001f517"),   # link
    "call":       ("bold cyan",                     "\U0001f4de"),   # phone
    "resolve":    ("bold blue",                     "\U0001f50d"),   # search
    "devices":    ("bold white",                    "\U0001f4f1"),   # mobile
    "delegation": ("bold white on dark_green",      "\U0001f91d"),   # handshake
    "handoff":    ("bold cyan on dark_blue",        "\U0001f500"),   # shuffle
    "ipoll":      ("bold yellow on dark_red",       "\U0001f4e8"),   # mailbox
    "ains_claim": ("bold green on dark_blue",       "\U0001f3f7\ufe0f"),  # label
    "general":    ("dim",                           "  "),
}

LEVEL_STYLE = {
    "ERROR":   "bold red",
    "WARNING": "bold yellow",
    "INFO":    "",
    "DEBUG":   "dim",
}

# Icon lookup for TUI (plain icons without styles)
CAT_ICON = {cat: icon for cat, (_, icon) in CAT_STYLE.items()}
