"""
tibet-tail -- Live AInternet Event Viewer.

Like tail -f, but for the AInternet. Shows live events from
brain_api's JIS-SIP bridge with color-coded categories and
real-time statistics.

Part of the TIBET ecosystem -- Traceable Intent-Based Event Tokens.
"""

__version__ = "0.2.0"

from .categories import CAT_STYLE, LEVEL_STYLE, CAT_ICON
from .stats import Stats
from .formatter import format_event_rich, format_event_plain, print_summary
from .stream import stream_from_sse, stream_from_file, load_history

__all__ = [
    "__version__",
    "CAT_STYLE",
    "LEVEL_STYLE",
    "CAT_ICON",
    "Stats",
    "format_event_rich",
    "format_event_plain",
    "print_summary",
    "stream_from_sse",
    "stream_from_file",
    "load_history",
]
