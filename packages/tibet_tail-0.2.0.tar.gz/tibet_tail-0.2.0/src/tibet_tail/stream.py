"""
tibet-tail stream — SSE and file tail stream sources.
"""

import json
import os
import time

import httpx
from httpx_sse import connect_sse


# Configurable via env vars
DEFAULT_API = os.environ.get("BRAIN_API_URL", "http://localhost:8000")
JSONL_PATH = os.environ.get("TIBET_TAIL_JSONL", "/tmp/jis_sip_events.jsonl")


def stream_from_sse(api_url: str, cat_filter: set, level_filter: str):
    """Yield events from the SSE stream endpoint."""
    url = f"{api_url}/api/jis/sip/logs/stream"

    with httpx.Client(timeout=None) as client:
        with connect_sse(client, "GET", url) as sse:
            for event in sse.iter_sse():
                if not event.data:
                    continue
                try:
                    data = json.loads(event.data)
                except (json.JSONDecodeError, ValueError):
                    continue

                # Skip connection message
                if data.get("type") == "connected":
                    yield {"_connected": True, "msg": data.get("msg", "")}
                    continue

                # Apply filters
                if cat_filter and data.get("cat") not in cat_filter:
                    continue
                if level_filter and data.get("level") != level_filter:
                    continue

                yield data


def stream_from_file(path: str, cat_filter: set, level_filter: str, from_end: bool = True):
    """Yield events by tailing the JSONL file directly."""
    if not os.path.exists(path):
        # Wait for file to appear
        while not os.path.exists(path):
            time.sleep(0.5)

    with open(path, "r") as f:
        if from_end:
            f.seek(0, 2)  # Start from end

        while True:
            line = f.readline()
            if not line:
                time.sleep(0.3)
                continue

            line = line.strip()
            if not line:
                continue

            try:
                data = json.loads(line)
            except (json.JSONDecodeError, ValueError):
                continue

            # Apply filters
            if cat_filter and data.get("cat") not in cat_filter:
                continue
            if level_filter and data.get("level") != level_filter:
                continue

            yield data


def load_history(api_url: str, limit: int, cat_filter: set) -> list:
    """Load recent history from REST endpoint."""
    url = f"{api_url}/api/jis/sip/logs"
    params = {"limit": limit}
    if cat_filter and len(cat_filter) == 1:
        params["category"] = next(iter(cat_filter))

    try:
        resp = httpx.get(url, params=params, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("events", [])
    except Exception:
        pass
    return []
