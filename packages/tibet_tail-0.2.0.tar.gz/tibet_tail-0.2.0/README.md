# tibet-tail

Live AInternet Event Viewer -- `tail -f` for the AInternet.

Shows live events from brain_api's JIS-SIP bridge with color-coded categories and real-time statistics.

## Install

```bash
pip install tibet-tail
```

For TUI mode (interactive node monitor):

```bash
pip install tibet-tail[tui]
```

## Usage

```bash
tibet-tail                      # Live SSE stream (default)
tibet-tail --history 100        # Show last 100 events first
tibet-tail --cat ains           # Filter by category
tibet-tail --cat ains,tibet     # Multiple categories
tibet-tail --cat ipoll          # I-Poll messages
tibet-tail --level ERROR        # Only errors
tibet-tail --json               # Raw JSON output
tibet-tail --file               # Read JSONL directly (no API)
tibet-tail tui                  # Interactive TUI node monitor
```

## Categories

| Category | Icon | Description |
|----------|------|-------------|
| ains | globe | AINS name resolution |
| ami | satellite | Asterisk AMI commands |
| tibet | link | TIBET token events |
| call | phone | Call flow events |
| resolve | search | SIP resolution |
| devices | mobile | Device listing |
| delegation | handshake | Delegation events |
| handoff | shuffle | Handoff events |
| ipoll | mailbox | I-Poll messages |
| ains_claim | label | Domain claim events |

## Configuration

| Env var | Default | Description |
|---------|---------|-------------|
| `BRAIN_API_URL` | `http://localhost:8000` | brain_api address |
| `TIBET_TAIL_JSONL` | `/tmp/jis_sip_events.jsonl` | JSONL file path |

## Part of HumoticaOS

tibet-tail is part of the TIBET ecosystem -- Traceable Intent-Based Event Tokens.

One love, one fAmIly.
