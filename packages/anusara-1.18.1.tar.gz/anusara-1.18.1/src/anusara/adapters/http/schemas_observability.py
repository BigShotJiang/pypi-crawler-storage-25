from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class CircuitBreakerStateSchema(BaseModel):
    key: str
    state: str
    consecutive_failures: int
    opened_at_monotonic: float | None
    half_open_in_flight: bool


class CircuitBreakerStatesResponse(BaseModel):
    circuits: list[CircuitBreakerStateSchema]


class CircuitBreakerEventSchema(BaseModel):
    key: str
    from_state: str
    to_state: str
    reason: str


class CircuitBreakerEventsResponse(BaseModel):
    events: list[CircuitBreakerEventSchema]


class SnapshotAgentResultSchema(BaseModel):
    success: bool
    output: object | None
    errors: list[str]
    confidence: float
    metadata: dict[str, object] | None


class SnapshotAttemptSchema(BaseModel):
    attempt: int
    sequence_number: int
    forced: bool
    started_at: datetime | None
    completed_at: datetime | None
    result: SnapshotAgentResultSchema


class ExecutionSnapshotResponse(BaseModel):
    schema_version: str
    request_id: str
    started_at: datetime | None
    completed_at: datetime | None
    overall_success: bool
    confidence: float
    records: dict[str, list[SnapshotAttemptSchema]]
    scenario: dict[str, object] | None
    metadata: dict[str, object] | None
