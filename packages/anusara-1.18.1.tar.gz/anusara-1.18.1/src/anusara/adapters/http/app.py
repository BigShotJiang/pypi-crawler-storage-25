from __future__ import annotations

import asyncio
import uuid
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from typing import Any, cast

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel

from anusara._builtin.agents.echo_agent import EchoAgent
from anusara._builtin.agents.hello_agent import HelloAgent
from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._core.execution_engine import ExecutionEngine
from anusara._core.execution_status import ExecutionStatus
from anusara._introspection.serialization import (
    ExecutionSnapshotSerializer,
)
from anusara._registry.agent_registry import AgentRegistry
from anusara._registry.errors import AgentNotFoundError
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._routing.execution_graph import ExecutionGraph
from anusara._runtime.circuit_breaker_registry import CircuitBreakerRegistry
from anusara._runtime.config import RuntimeConfig
from anusara._runtime.schema_validation import validate_payload_against_schema
from anusara.adapters.http.projections import (
    to_agent_schema_descriptor_schema,
    to_circuit_breaker_events_response,
    to_circuit_breaker_states_response,
    to_execution_trace_response,
    to_registered_agent_schema,
    to_registered_agents_data,
)
from anusara.adapters.http.runtime import (
    RuntimeContainer,
    get_container,
    get_engine,
    get_registry,
    initialize_runtime,
)
from anusara.adapters.http.schemas import (
    AgentSchemaResponse,
    AvailableFactoriesData,
    AvailableFactoriesResponse,
    ExecuteRequest,
    ExternalAgentRegistrationRequest,
    ExternalAgentRegistrationResponse,
    HealthResponse,
    RegisteredAgentResponse,
    RegisteredAgentsResponse,
)
from anusara.adapters.http.schemas_observability import (
    CircuitBreakerEventsResponse,
    CircuitBreakerStatesResponse,
)
from anusara.adapters.http.schemas_trace import ExecutionTraceResponse
from anusara.adapters.http.utils import default_root
from anusara.api.helper import JSONValue


def _validate_entry_node_payloads(
    request: ExecuteRequest,
    registry: AgentRegistry,
    graph: ExecutionGraph,
) -> None:
    for entry_node_id in request.entry_nodes:
        if entry_node_id not in graph.nodes:
            continue

        node = graph.nodes[entry_node_id]
        node_agent = node.agent

        if node_agent is None:
            continue

        definition = registry.get_definition(node_agent)
        descriptor = registry.get_schema_descriptor(definition.agent_id)

        if descriptor is None or descriptor.input_schema is None:
            continue

        payload = cast(dict[str, JSONValue], request.payload)
        errors = validate_payload_against_schema(payload, descriptor.input_schema)

        if errors:
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "Payload does not satisfy agent input schema",
                    "agent_id": definition.agent_id,
                    "details": errors,
                },
            )


class AgentRegisterRequest(BaseModel):
    name: str


def get_package_version() -> str:
    try:
        return pkg_version("anusara")
    except PackageNotFoundError:
        return "0.0.0-dev"


def get_circuit_breakers(request: Request) -> CircuitBreakerRegistry:
    circuit_breakers = getattr(request.app.state, "circuit_breakers", None)
    if not isinstance(circuit_breakers, CircuitBreakerRegistry):
        raise RuntimeError("Circuit breaker registry is not configured")
    return circuit_breakers


def create_app(
    *,
    async_mode: bool = True,
    title: str = "Anusara Service",
    version: str | None = None,
    container: RuntimeContainer | None = None,
    circuit_breakers: CircuitBreakerRegistry | None = None,
) -> FastAPI:
    """
    Create and configure the HTTP application.
    """

    if version is None:
        version = get_package_version()

    if container is None:
        initialize_runtime(RuntimeConfig.from_env())
        container = get_container()

    if circuit_breakers is None:
        circuit_breakers = CircuitBreakerRegistry()

    register_builtin_agents(container)

    app = FastAPI(title=title, version=version)
    app.state.async_mode = async_mode
    app.state.circuit_breakers = circuit_breakers

    def _get_engine_override() -> ExecutionEngine:
        return container.engine

    def _get_registry_override() -> AgentRegistry:
        return container.registry

    def _get_container_override() -> RuntimeContainer:
        return container

    app.dependency_overrides[get_engine] = _get_engine_override
    app.dependency_overrides[get_registry] = _get_registry_override
    app.dependency_overrides[get_container] = _get_container_override

    @app.get("/")
    async def root() -> dict[str, str]:
        return default_root(
            service="anusara",
            version=version,
            architecture="event-driven-mesh",
        )

    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(
            status="ok",
            service="anusara",
            architecture="event-driven-mesh",
            version=version,
        )

    @app.post("/executions", status_code=status.HTTP_202_ACCEPTED)
    async def execute(
        request: ExecuteRequest,
        http_request: Request,
        engine: ExecutionEngine = Depends(get_engine),
        registry: AgentRegistry = Depends(get_registry),
    ) -> dict[str, str]:
        request_id = str(uuid.uuid4())
        execution_request = request.to_execution_request(request_id)

        try:
            graph = engine.compile(execution_request)

            for node in graph.nodes.values():
                if node.agent and not registry.exists(node.agent):
                    raise HTTPException(
                        status_code=400,
                        detail={
                            "error": f"Agent '{node.agent}' is not registered",
                            "available": registry.list(),
                        },
                    )

            _validate_entry_node_payloads(request, registry, graph)

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        if http_request.app.state.async_mode:
            asyncio.create_task(engine.execute(execution_request, registry))
        else:
            await engine.execute(execution_request, registry)

        return {
            "request_id": request_id,
            "status": "ACCEPTED",
        }

    @app.get("/architecture")
    async def architecture() -> dict[str, JSONValue]:
        return {
            "architecture": "event-driven-mesh",
            "components": [
                "execution-engine",
                "event-log",
                "graph-compiler",
                "agent-registry",
                "mutation-engine",
            ],
        }

    @app.get("/executions/{request_id}")
    async def get_status(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, str]:
        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        return {
            "request_id": request_id,
            "status": status_value.name,
        }

    @app.get("/executions/{request_id}/snapshot")
    async def get_snapshot(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, Any]:
        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        try:
            snapshot = engine.get_snapshot(request_id)
            data = ExecutionSnapshotSerializer.snapshot_to_dict(snapshot)
            return cast(dict[str, Any], jsonable_encoder(data))

        except Exception:
            return {
                "request_id": request_id,
                "started_at": None,
                "completed_at": None,
                "overall_success": False,
                "confidence": 0.0,
                "records": {},
                "scenario": None,
                "metadata": None,
            }

    @app.post("/agents/register")
    async def register_agent(
        body: AgentRegisterRequest,
        container: RuntimeContainer = Depends(get_container),
    ) -> dict[str, object]:
        try:
            container.create_and_register(body.name)

        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        except RuntimeError as e:
            raise HTTPException(
                status_code=500,
                detail="Runtime not initialized",
            ) from e

        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=str(e),
            ) from e

        return {
            "status": "success",
            "data": {
                "agent": body.name,
            },
        }

    @app.post(
        "/agents/register/external",
        response_model=ExternalAgentRegistrationResponse,
    )
    async def register_external_agent(
        body: ExternalAgentRegistrationRequest,
        registry: AgentRegistry = Depends(get_registry),
    ) -> ExternalAgentRegistrationResponse:
        try:
            registry.register_external(
                name=body.agent_id,
                module=body.source.module,
                symbol=body.source.symbol,
                namespace=body.namespace,
                version=body.version,
                is_builtin=body.is_builtin,
                replace=body.replace,
            )

            metadata = registry.metadata(body.agent_id)

            namespace_value = metadata["namespace"] or None
            version_value = metadata["version"] or None
            is_builtin_value = metadata["is_builtin"] == "True"

            return ExternalAgentRegistrationResponse(
                agent_id=metadata["agent_id"],
                namespace=namespace_value,
                version=version_value,
                is_builtin=is_builtin_value,
                source_kind=metadata["source_kind"],
                source_ref=metadata["source_ref"],
                factory_type=metadata["factory_type"],
            )

        except KeyError as e:
            raise HTTPException(status_code=409, detail=str(e)) from e

        except (ValueError, ImportError, AttributeError, TypeError) as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

    @app.get("/agents", response_model=RegisteredAgentsResponse)
    async def list_agents(
        namespace: str | None = None,
        capability: str | None = None,
        registry: AgentRegistry = Depends(get_registry),
    ) -> RegisteredAgentsResponse:
        try:
            definitions = registry.list_definitions()

            filtered: list[ExecutableDefinition] = []
            descriptors: dict[str, AgentSchemaDescriptor | None] = {}

            for definition in definitions:
                if namespace is not None and definition.namespace != namespace:
                    continue

                descriptor = registry.get_schema_descriptor(definition.agent_id)

                if capability is not None:
                    descriptor_capabilities = (
                        list(descriptor.capabilities) if descriptor is not None else []
                    )

                    if capability not in descriptor_capabilities:
                        continue

                filtered.append(definition)
                descriptors[definition.agent_id] = descriptor

        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail="Failed to retrieve registered agents",
            ) from e

        return RegisteredAgentsResponse(
            status="success",
            data=to_registered_agents_data(filtered, descriptors),
        )

    @app.get("/agents/available", response_model=AvailableFactoriesResponse)
    async def list_available_agents(
        container: RuntimeContainer = Depends(get_container),
    ) -> AvailableFactoriesResponse:
        try:
            available = container.list_factories()

        except RuntimeError as e:
            raise HTTPException(
                status_code=500,
                detail="Runtime not initialized",
            ) from e

        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail="Failed to retrieve available agents",
            ) from e

        return AvailableFactoriesResponse(
            status="success",
            data=AvailableFactoriesData(available_factories=available),
        )

    @app.get("/agents/{agent_id}", response_model=RegisteredAgentResponse)
    async def get_agent(
        agent_id: str,
        registry: AgentRegistry = Depends(get_registry),
    ) -> RegisteredAgentResponse:
        try:
            definition = registry.get_definition(agent_id)

        except AgentNotFoundError as e:
            raise HTTPException(status_code=404, detail="Agent not found") from e

        descriptor = registry.get_schema_descriptor(definition.agent_id)

        return RegisteredAgentResponse(
            status="success",
            data=to_registered_agent_schema(definition, descriptor),
        )

    @app.get("/agents/{agent_id}/schema", response_model=AgentSchemaResponse)
    async def get_agent_schema(
        agent_id: str,
        registry: AgentRegistry = Depends(get_registry),
    ) -> AgentSchemaResponse:
        try:
            definition = registry.get_definition(agent_id)

        except AgentNotFoundError as e:
            raise HTTPException(status_code=404, detail="Agent not found") from e

        try:
            descriptor = registry.get_schema_descriptor(definition.agent_id)
            schema_data = to_agent_schema_descriptor_schema(definition, descriptor)

            return AgentSchemaResponse(
                status="success",
                data=schema_data,
            )

        except TypeError as e:
            raise HTTPException(status_code=500, detail=str(e)) from e

    @app.get(
        "/observability/circuit-breakers",
        response_model=CircuitBreakerStatesResponse,
    )
    async def list_circuit_breakers(
        circuit_breakers: CircuitBreakerRegistry = Depends(get_circuit_breakers),
    ) -> CircuitBreakerStatesResponse:
        snapshot = circuit_breakers.snapshot_all()
        return to_circuit_breaker_states_response(snapshot)

    @app.get(
        "/observability/circuit-breakers/events",
        response_model=CircuitBreakerEventsResponse,
    )
    async def list_circuit_breaker_events(
        circuit_breakers: CircuitBreakerRegistry = Depends(get_circuit_breakers),
    ) -> CircuitBreakerEventsResponse:
        events = circuit_breakers.list_events()
        return to_circuit_breaker_events_response(events)

    @app.get(
        "/executions/{request_id}/trace",
        response_model=ExecutionTraceResponse,
    )
    async def get_execution_trace(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> ExecutionTraceResponse:
        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        try:
            state = engine.rebuild_state_from_log(request_id)

            request_obj = state.execution_request
            if request_obj is None:
                raise RuntimeError("Execution request missing from rebuilt state")

            graph = engine.compile(request_obj)

            return to_execution_trace_response(
                request_id=request_id,
                status=status_value.name,
                state=state,
                graph=graph,
            )

        except RuntimeError as e:
            raise HTTPException(status_code=500, detail=str(e)) from e

    return app


def register_builtin_agents(container: RuntimeContainer) -> None:
    factories = set(container.list_factories())

    if "echo" not in factories:
        container.register_factory("echo", lambda: EchoAgent())

    if "hello" not in factories:
        container.register_factory("hello", lambda: HelloAgent())
