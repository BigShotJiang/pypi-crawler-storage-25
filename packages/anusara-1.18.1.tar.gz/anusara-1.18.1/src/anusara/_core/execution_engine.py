import asyncio
import copy
from collections.abc import Iterator, Sequence
from datetime import UTC
from typing import cast

from anusara._aggregation.result_aggregator import ResultAggregator
from anusara._contracts.agent import Agent
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionPaused,
    ExecutionStarted,
    MutationEvaluationMissing,
    OrchestrationEvent,
)
from anusara._contracts.execution_request import (
    ExecutionRequest,
    ExecutionRequestDict,
)
from anusara._contracts.mesh_result import MeshResult
from anusara._core.errors import (
    ApprovalRequiredError,
    ExecutionAlreadyRunningError,
    MaxHopExceededError,
    SimulatedHardKillError,
)
from anusara._core.execution_log_inspector import ExecutionLogInspector
from anusara._core.execution_policy import FailureMode
from anusara._core.execution_reducer import ExecutionReducer
from anusara._core.execution_status import ExecutionStatus
from anusara._core.execution_summary import ExecutionSummary
from anusara._core.node_executor import NodeExecutor
from anusara._core.orchestration_event_emitter import OrchestrationEventEmitter
from anusara._introspection.execution_snapshot import (
    AttemptSnapshot,
    ExecutionSnapshot,
)
from anusara._introspection.mode import SnapshotMode
from anusara._mutation.compliance import (
    MutationComplianceChecker,
    MutationComplianceError,
)
from anusara._mutation.event_log import MutationEventLog
from anusara._observability.in_memory_event_log import InMemoryExecutionEventLog
from anusara._observability.observer import ExecutionObserver
from anusara._registry.agent_registry import AgentRegistry
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._routing.errors import ResolutionError
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState
from anusara._routing.graph_compiler import GraphCompiler
from anusara._runtime.invokers.python_plugin import PythonPluginInvoker
from anusara._runtime.invokers.registry import InvokerRegistry
from anusara._runtime.invokers.remote_http import RemoteHttpInvoker
from anusara._utils.time import utc_now

StateSig = tuple[int, int, bool, float]


def _record_sort_key(record: ExecutionRecord) -> tuple[int, int]:
    return (record.attempt, record.sequence_number)


def _record_sort_key_optional_seq(record: ExecutionRecord) -> tuple[int, int]:
    return (record.attempt, record.sequence_number or 0)


class ExecutionEngine:
    """
    Sole orchestration authority for:

    - Graph compilation & validation
    - Execution lifecycle
    - Replay semantics
    - Snapshot generation
    """

    def __init__(
        self,
        observers: Sequence[ExecutionObserver] | None = None,
        event_log: ExecutionEventLog | None = None,
        mutation_event_log: MutationEventLog | None = None,
    ) -> None:
        self._compiler = GraphCompiler()
        self._aggregator = ResultAggregator()
        self._reducer = ExecutionReducer()

        self._event_log: ExecutionEventLog = (
            event_log if event_log is not None else InMemoryExecutionEventLog()
        )

        self._mutation_event_log = mutation_event_log
        # observers are reused, emitter is NOT
        self._observers = observers or []

        self._active_requests: set[str] = set()
        self._states: dict[str, ExecutionState] = {}

        self._request_guard = asyncio.Lock()

    # ------------------------------------------------------------------
    # PROPERTIES
    # ------------------------------------------------------------------

    @property
    def event_log(self) -> ExecutionEventLog:
        return self._event_log

    @property
    def events(self) -> list[OrchestrationEvent]:
        return self._event_log.read_all()

    # ------------------------------------------------------------------
    # INTERNAL: Create per-execution emitter
    # ------------------------------------------------------------------

    def _create_emitter(
        self, state: ExecutionState, graph: ExecutionGraph
    ) -> OrchestrationEventEmitter:
        emitter = OrchestrationEventEmitter(
            observers=self._observers,
            event_log=self._event_log,
            reducer=self._reducer,
        )
        emitter.bind_runtime(state, graph)
        return emitter

    # ------------------------------------------------------------------
    # PUBLIC GRAPH COMPILATION
    # ------------------------------------------------------------------

    def compile(self, request: ExecutionRequest) -> ExecutionGraph:
        return self._compiler.compile(request)

    # ------------------------------------------------------------------
    # EXECUTE
    # ------------------------------------------------------------------
    async def execute(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
    ) -> tuple[MeshResult, ExecutionState]:
        await self._acquire_request_lock(request.request_id)

        try:
            request.validate()

            # ---------------------------------------------------------
            # Mutation compliance (pre-check)
            # ---------------------------------------------------------
            if request.policy.mutation_evaluation_mode == "required":
                if self._mutation_event_log is None:
                    raise MutationComplianceError("Mutation log not configured")

                MutationComplianceChecker.assert_compliant(
                    request_id=request.request_id,
                    mutation_events=self._mutation_event_log.read_by_request(
                        request.request_id
                    ),
                )

            # ---------------------------------------------------------
            # Compile graph
            # ---------------------------------------------------------
            graph = self._compiler.compile(request)
            graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
            graph.assign_topological_order()

            # ---------------------------------------------------------
            # Scenario
            # ---------------------------------------------------------
            raw_skip_nodes = request.scenario.param("skip_nodes", [])

            skip_nodes: set[str] = (
                {v for v in raw_skip_nodes if isinstance(v, str)}
                if isinstance(raw_skip_nodes, list)
                else set()
            )

            # ---------------------------------------------------------
            # State + emitter
            # ---------------------------------------------------------
            state = ExecutionState(graph, request)
            self._states[request.request_id] = state

            emitter = self._create_emitter(state, graph)

            started_at = utc_now()

            emitter.emit(
                ExecutionStarted(
                    request_id=request.request_id,
                    timestamp=started_at,
                    execution_request=request.to_dict(),
                )
            )

            # ---------------------------------------------------------
            # Executor + concurrency
            # ---------------------------------------------------------
            invokers = self._build_invokers(registry)

            node_executor = NodeExecutor(
                registry=registry,
                retry_policy=request.policy.retry_policy,
                event_emitter=emitter,
                graph=graph,
                invokers=invokers,
            )

            semaphore = (
                asyncio.Semaphore(request.policy.max_concurrency)
                if request.policy.max_concurrency
                else None
            )

            async def run_node(nid: str, _an: str) -> AgentResult:
                node = graph.nodes[nid]

                if node.agent is None:
                    raise RuntimeError(f"Node '{nid}' has no agent")

                sequence_number = graph.topo_index[nid]

                if semaphore:
                    async with semaphore:
                        return await node_executor.execute(
                            nid,
                            node.agent,
                            request,
                            state,
                            sequence_number=sequence_number,
                        )

                return await node_executor.execute(
                    nid,
                    node.agent,
                    request,
                    state,
                    sequence_number=sequence_number,
                )

            # ---------------------------------------------------------
            # Execution bookkeeping
            # ---------------------------------------------------------
            in_degree: dict[str, int] = {
                node_id: len(
                    [
                        d
                        for d in graph.dependencies_of(node_id)
                        if d != GraphCompiler.SYNTHETIC_ROOT
                    ]
                )
                for node_id in graph.nodes.keys()
            }

            ready: set[str] = set(graph.children_of(GraphCompiler.SYNTHETIC_ROOT))
            hop_count = 0

            # ---------------------------------------------------------
            # MAIN LOOP
            # ---------------------------------------------------------
            try:
                while ready:
                    if request.policy.max_hops and hop_count >= request.policy.max_hops:
                        raise MaxHopExceededError(request.policy.max_hops)

                    current_wave = sorted(ready, key=graph.topo_index.__getitem__)
                    ready.clear()

                    tasks: list[tuple[str, asyncio.Task[AgentResult]]] = []
                    next_ready: set[str] = set()

                    # -----------------------------
                    # Phase 1: schedule / skip
                    # -----------------------------
                    for node_id in current_wave:
                        node = graph.nodes[node_id]

                        if node_id in skip_nodes:
                            for child_id in graph.children_of(node_id):
                                in_degree[child_id] -= 1
                                if in_degree[child_id] == 0:
                                    next_ready.add(child_id)
                            continue

                        if (
                            node.agent is None
                            and node_id != GraphCompiler.SYNTHETIC_ROOT
                        ):
                            continue

                        if node.agent is None:
                            continue

                        tasks.append(
                            (
                                node_id,
                                asyncio.create_task(run_node(node_id, node.agent)),
                            )
                        )

                    # -----------------------------
                    # Phase 2: execute
                    # -----------------------------
                    executed_nodes: list[str] = []

                    if tasks:
                        gathered = await asyncio.gather(*[t for _, t in tasks])
                        for (node_id, _), _result in zip(tasks, gathered, strict=True):
                            executed_nodes.append(node_id)
                            hop_count += 1
                    else:
                        gathered = []

                    # -----------------------------
                    # Phase 3: propagate (retry-aware)
                    # -----------------------------

                    stable_nodes: list[str] = []

                    for node_id in executed_nodes:
                        records = state.records_for(node_id)

                        if not records:
                            continue

                        last = records[-1]

                        # ---------------------------------------------------------
                        # Retry barrier:
                        # Do NOT propagate if this node is still in retry lifecycle
                        # ---------------------------------------------------------
                        if not last.result.success:

                            # 🔥 KEY FIX: allow non-blocking failures to be stable
                            if last.result.metadata.get("non_blocking", False):
                                pass  # treat as stable

                            elif (
                                last.attempt < request.policy.retry_policy.max_attempts
                            ):
                                continue  # still retryable → NOT stable

                        stable_nodes.append(node_id)

                    # ---------------------------------------------------------
                    # Now propagate ONLY from stable nodes
                    # ---------------------------------------------------------
                    for node_id in stable_nodes:

                        record = state.latest_record(node_id)

                        if record is None:
                            continue

                        # FAIL FAST behavior
                        if (
                            not record.result.success
                            and request.policy.failure_mode == FailureMode.FAIL_FAST
                        ):
                            ready.clear()
                            break

                        for child_id in graph.children_of(node_id):
                            in_degree[child_id] -= 1

                            if in_degree[child_id] != 0:
                                continue

                            if self._dependencies_ready(
                                state=state,
                                graph=graph,
                                node_id=child_id,
                                max_attempts=request.policy.retry_policy.max_attempts,
                            ):
                                next_ready.add(child_id)

                    ready.update(next_ready)

                # ---------------------------------------------------------
                # SUCCESS COMPLETION
                # ---------------------------------------------------------
                result = self._aggregator.aggregate(
                    graph=graph,
                    state=state,
                    policy=request.policy,
                )

                # ---------------------------------------------------------
                # 🔥 Retry-aware failure propagation (graph-aware)
                # ---------------------------------------------------------
                for node_id, records in state._records.items():
                    children = graph.children_of(node_id)

                    if not children:
                        continue

                    latest = records[-1] if records else None

                    if latest is None:
                        continue

                    if not latest.result.success and not latest.result.metadata.get(
                        "non_blocking",
                        False,
                    ):
                        result.success = False
                        break

                completed_at = utc_now()

                emitter.emit(
                    ExecutionCompleted(
                        request_id=request.request_id,
                        timestamp=completed_at,
                        success=result.success,
                        total_nodes=len(graph.nodes),
                    )
                )

                self._enforce_mutation_policy(request)

                return result, state

            # ---------------------------------------------------------
            # PAUSE (approval)
            # ---------------------------------------------------------
            except ApprovalRequiredError as e:
                emitter.emit(
                    ExecutionPaused(
                        request_id=request.request_id,
                        timestamp=utc_now(),
                        reason=str(e),
                    )
                )

                return (
                    self._aggregator.aggregate(
                        graph=graph,
                        state=state,
                        policy=request.policy,
                    ),
                    state,
                )

            # ---------------------------------------------------------
            # HARD STOP
            # ---------------------------------------------------------
            except SimulatedHardKillError:
                raise

            # ---------------------------------------------------------
            # FAILURE
            # ---------------------------------------------------------
            except Exception as e:
                emitter.emit(
                    ExecutionFailed(
                        request_id=request.request_id,
                        error=str(e),
                        timestamp=utc_now(),
                    )
                )
                raise

        finally:
            self._active_requests.remove(request.request_id)

    # ------------------------------------------------------------------
    # REPLAY
    # ------------------------------------------------------------------
    async def replay(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        state: ExecutionState,
        start_nodes: list[str] | None = None,
        force: bool = False,
    ) -> MeshResult:

        await self._acquire_request_lock(request.request_id)

        try:
            request.validate()

            # ---------------------------------------------------------
            # Compile graph
            # ---------------------------------------------------------
            graph = self._compiler.compile(request)
            graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
            graph.assign_topological_order()

            # ---------------------------------------------------------
            # 🔥 Validate start_nodes (must exist in graph)
            # ---------------------------------------------------------
            if start_nodes:
                unknown = [
                    node_id for node_id in start_nodes if node_id not in graph.nodes
                ]

                if unknown:
                    raise ResolutionError(
                        identifier=unknown[0],
                        message=f"Unknown start node(s): {unknown}",
                    )

            # ---------------------------------------------------------
            # Read event log
            # ---------------------------------------------------------
            events = list(self._event_log.read_by_request(request.request_id))

            # ---------------------------------------------------------
            # 🔥 FALLBACK VALIDATION (no event log case)
            # ---------------------------------------------------------
            if not events and state._records:
                for node_id, records in state._records.items():
                    for record in records:
                        if record.result is None:
                            raise RuntimeError(
                                f"Corrupted execution record: missing result for node {node_id}"
                            )

            # ---------------------------------------------------------
            # Helpers
            # ---------------------------------------------------------
            def _state_signature(s: ExecutionState) -> dict[str, list[StateSig]]:
                sig: dict[str, list[StateSig]] = {}

                for node_id, records in s._records.items():
                    sig[node_id] = [
                        (
                            r.attempt,
                            r.sequence_number,
                            r.result.success,
                            r.result.confidence,
                        )
                        for r in sorted(
                            records,
                            key=_record_sort_key,
                        )
                    ]

                return sig

            # ---------------------------------------------------------
            # 🔥 PRE-VALIDATION (CRITICAL)
            # ---------------------------------------------------------
            is_partial_replay = start_nodes is not None and not force

            if events:
                temp_state = ExecutionState(graph, request)

                self._rebuild_state_from_events(
                    state=temp_state,
                    events=events,
                )

                sig_expected = _state_signature(temp_state)
                sig_actual = _state_signature(state)

                # -----------------------------------------------------
                # 🔥 RULE 1: If state is empty → allow ONLY for fresh resume
                # -----------------------------------------------------
                if not sig_actual:
                    if not is_partial_replay:
                        pass  # allow (resume flow)
                    else:
                        raise RuntimeError(
                            "Execution state missing while event log exists"
                        )

                else:
                    # -------------------------------------------------
                    # FULL replay → strict
                    # -------------------------------------------------
                    if not is_partial_replay:
                        if sig_actual != sig_expected:
                            raise RuntimeError(
                                "Execution state is inconsistent with event log"
                            )

                    # -------------------------------------------------
                    # PARTIAL replay → prefix match
                    # -------------------------------------------------
                    else:
                        for node_id, actual_records in sig_actual.items():

                            if node_id not in sig_expected:
                                raise RuntimeError(
                                    "Execution state diverges from event log"
                                )

                            expected_records = sig_expected[node_id]

                            if len(actual_records) > len(expected_records):
                                raise RuntimeError(
                                    "Execution state diverges from event log"
                                )

                            for i, actual in enumerate(actual_records):
                                expected = expected_records[i]

                                # success cannot flip from False → True
                                if actual[2] is True and expected[2] is False:
                                    raise RuntimeError(
                                        "Execution state diverges from event log"
                                    )

            # ---------------------------------------------------------
            # Rebuild authoritative state
            # ---------------------------------------------------------
            rebuilt_state = ExecutionState(graph, request)

            if events:
                self._rebuild_state_from_events(state=rebuilt_state, events=events)
            elif state._records:
                rebuilt_state._records = {
                    k: [copy.deepcopy(r) for r in v] for k, v in state._records.items()
                }

            # ---------------------------------------------------------
            # 🔥 EVENT LOG SEMANTIC VALIDATION
            # ---------------------------------------------------------
            for _node_id, records in rebuilt_state._records.items():
                records = sorted(records, key=_record_sort_key)

                for i, r in enumerate(records):

                    if r.result is None:
                        raise RuntimeError("Corrupted execution record: missing result")

                    if i > 0:
                        if records[i].sequence_number <= records[i - 1].sequence_number:
                            raise RuntimeError(
                                "Corrupted execution record: invalid sequence order"
                            )

            # ---------------------------------------------------------
            # Hydrate working state
            # ---------------------------------------------------------
            state._records = {
                k: [copy.deepcopy(r) for r in v]
                for k, v in rebuilt_state._records.items()
            }
            state._started_at = rebuilt_state.started_at
            state._completed_at = rebuilt_state.completed_at
            state.paused_at = rebuilt_state.paused_at
            state._open_attempts = dict(rebuilt_state._open_attempts)

            working_state = state

            # ---------------------------------------------------------
            # Runtime
            # ---------------------------------------------------------
            emitter = self._create_replay_emitter(working_state, graph)

            return await self._continue_execution(
                request=request,
                registry=registry,
                state=working_state,
                graph=graph,
                emitter=emitter,
                start_nodes=start_nodes,
                force=force,
            )

        finally:
            self._active_requests.remove(request.request_id)

    # ------------------------------------------------------------------
    # LOCKING
    # ------------------------------------------------------------------

    async def _acquire_request_lock(self, request_id: str) -> None:
        async with self._request_guard:
            if request_id in self._active_requests:
                raise ExecutionAlreadyRunningError(request_id)

            self._active_requests.add(request_id)

    # ---------------------------------------------------------
    # Lifecycle Inspection
    # ---------------------------------------------------------

    def list_executions(self) -> Iterator[ExecutionSummary]:
        inspector = ExecutionLogInspector(self._event_log)
        return inspector.stream_summaries()

    def get_execution_status(self, request_id: str) -> ExecutionStatus:
        for summary in self.list_executions():
            if summary.request_id == request_id:
                return summary.status

        return ExecutionStatus.NOT_FOUND

    def rebuild_state(self, request: ExecutionRequest) -> ExecutionState:
        events = list(self._event_log.read_by_request(request.request_id))

        if not events:
            raise RuntimeError("Execution not found")

        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        state = ExecutionState(graph, request)

        self._rebuild_state_from_events(state=state, events=events)

        return state

    async def resume(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
    ) -> MeshResult:
        status = self.get_execution_status(request.request_id)

        if status == ExecutionStatus.NOT_FOUND:
            raise RuntimeError("No persisted execution found")

        if status == ExecutionStatus.COMPLETED:
            raise RuntimeError("Execution already completed")

        if status not in {
            ExecutionStatus.INCOMPLETE,
            ExecutionStatus.PAUSED,
            ExecutionStatus.FAILED,
        }:
            raise RuntimeError("Execution log corrupted")

        events = list(self._event_log.read_by_request(request.request_id))

        if not events:
            raise RuntimeError("Execution log corrupted")

        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        state = ExecutionState(graph, request)

        self._rebuild_state_from_events(
            state=state,
            events=events,
        )

        if state.started_at is None:
            raise RuntimeError("Execution never started")

        if state.completed_at is not None:
            raise RuntimeError("Execution already completed")

        state.paused_at = None

        emitter = self._create_emitter(state, graph)

        result = await self._continue_execution(
            request=request,
            registry=registry,
            state=state,
            graph=graph,
            emitter=emitter,
            start_nodes=None,
            force=False,
        )

        self._states[request.request_id] = state

        return result

    def snapshot(
        self,
        request: ExecutionRequest,
        graph: ExecutionGraph,
        state: ExecutionState,
        result: MeshResult,
        mode: SnapshotMode = SnapshotMode.FULL_HISTORY,
    ) -> ExecutionSnapshot:

        records: dict[str, list[AttemptSnapshot]] = {}

        for node_id, attempts in state._records.items():

            # 🔥 CRITICAL: exclude synthetic root from external snapshot
            if node_id == GraphCompiler.SYNTHETIC_ROOT:
                continue

            attempt_records: list[ExecutionRecord] = list(attempts)

            # Deterministic ordering
            sorted_attempts = sorted(
                attempt_records,
                key=_record_sort_key_optional_seq,
            )

            # -----------------------------------------------------
            # Mode handling
            # -----------------------------------------------------
            if mode == SnapshotMode.FULL_HISTORY:
                selected_attempts = sorted_attempts
            else:  # FINAL_ONLY
                selected_attempts = [sorted_attempts[-1]] if sorted_attempts else []

            # -----------------------------------------------------
            # Build snapshots
            # -----------------------------------------------------
            records[node_id] = [
                AttemptSnapshot(
                    attempt=r.attempt,
                    sequence_number=r.sequence_number,
                    forced=r.forced,
                    started_at=r.started_at,
                    completed_at=r.completed_at,
                    result=r.result,
                )
                for r in selected_attempts
            ]

        return ExecutionSnapshot(
            request_id=state.request_id,
            started_at=state.started_at,
            completed_at=state.completed_at,
            records=records,
            overall_success=result.success,
            confidence=result.confidence,
            scenario=request.scenario,
            metadata=request.metadata,
        )

    def get_snapshot(self, request_id: str) -> ExecutionSnapshot:
        # ---------------------------------------------------------
        # Enforce lifecycle: snapshot only after completion
        # ---------------------------------------------------------
        status = self.get_execution_status(request_id)

        if status != ExecutionStatus.COMPLETED:
            raise RuntimeError("Snapshot available only after execution completion")

        # ---------------------------------------------------------
        # Always use event log (deterministic replay)
        # ---------------------------------------------------------
        events = list(self._event_log.read_by_request(request_id))

        if not events:
            raise RuntimeError("Execution not found")

        # ---------------------------------------------------------
        # Extract original request
        # ---------------------------------------------------------
        started_event = next(
            (e for e in events if isinstance(e, ExecutionStarted)),
            None,
        )

        if started_event is None:
            raise RuntimeError("ExecutionStarted event not found")

        request = ExecutionRequest.from_dict(
            cast(ExecutionRequestDict, started_event.execution_request)
        )

        # ---------------------------------------------------------
        # Rebuild graph
        # ---------------------------------------------------------
        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        # ---------------------------------------------------------
        # 🔥 Create fresh state + rebuild IN PLACE
        # ---------------------------------------------------------
        state = ExecutionState(graph, request)

        self._rebuild_state_from_events(
            state=state,
            events=events,
        )

        # ---------------------------------------------------------
        # Ensure synthetic root is marked as successful
        # ---------------------------------------------------------
        if GraphCompiler.SYNTHETIC_ROOT not in state._records:
            from datetime import datetime

            state._records[GraphCompiler.SYNTHETIC_ROOT] = [
                ExecutionRecord(
                    node_id=GraphCompiler.SYNTHETIC_ROOT,
                    result=AgentResult(
                        success=True,
                        output=None,
                        errors=[],
                        confidence=1.0,
                    ),
                    attempt=0,
                    sequence_number=0,
                    started_at=datetime.now(UTC),
                    completed_at=datetime.now(UTC),
                    forced=False,
                )
            ]

        # ---------------------------------------------------------
        # Aggregate final result
        # ---------------------------------------------------------
        result = self._aggregator.aggregate(
            graph=graph,
            state=state,
            policy=request.policy,
        )

        # ---------------------------------------------------------
        # Build snapshot
        # ---------------------------------------------------------
        return self.snapshot(request, graph, state, result)

    def rebuild_state_from_log(self, request_id: str) -> ExecutionState:

        events = list(self._event_log.read_by_request(request_id))

        if not events:
            raise RuntimeError("Execution not found")

        start_event = next(
            (e for e in events if isinstance(e, ExecutionStarted)),
            None,
        )

        if start_event is None:
            raise RuntimeError("ExecutionStarted event not found")

        execution_request = ExecutionRequest.from_dict(
            cast(ExecutionRequestDict, start_event.execution_request)
        )

        return self.rebuild_state(execution_request)

    def _enforce_mutation_policy(self, request: ExecutionRequest) -> None:
        if request.policy.mutation_evaluation_mode != "required":
            return

        if self._mutation_event_log is None:
            raise MutationComplianceError("Mutation log not configured")

        mutation_events = self._mutation_event_log.read_by_request(request.request_id)

        try:
            MutationComplianceChecker.assert_compliant(
                request_id=request.request_id,
                mutation_events=mutation_events,
            )

        except MutationComplianceError as err:
            # This is still an orchestration-level lifecycle signal
            self._event_log.append(
                MutationEvaluationMissing(
                    request_id=request.request_id,
                    timestamp=utc_now(),
                    policy_mode="required",
                    reason=str(err),
                )
            )
            raise

    async def replay_from_state(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        state: ExecutionState,
    ) -> MeshResult:
        return await self.replay(
            request=request,
            registry=registry,
            state=state,
            start_nodes=None,
        )

    async def resume_from_snapshot(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        snapshot: bytes,
    ) -> MeshResult:
        state = ExecutionState.restore(snapshot)

        return await self.replay_from_state(
            request,
            registry,
            state,
        )

    def _collect_subgraph(
        self,
        graph: ExecutionGraph,
        start_nodes: list[str],
    ) -> set[str]:
        visited = set()
        stack = list(start_nodes)

        while stack:
            node = stack.pop()
            if node in visited:
                continue

            visited.add(node)

            for child in graph.children_of(node):
                stack.append(child)

        return visited

    def _rebuild_state_from_events(
        self,
        *,
        state: ExecutionState,
        events: list[OrchestrationEvent],
    ) -> None:
        """
        Canonical state reconstruction from event log.

        Invariants:
        - Deterministic: same events → same state
        - Isolated: no shared mutable components
        - Complete: all state derived ONLY from events
        - In-place: DOES NOT replace state object
        """
        assert state is not None

        assert (
            state.execution_request is not None
        ), "ExecutionState must contain execution_request for rebuild"

        request = state.execution_request

        # ---------------------------------------------------------
        # Validate request
        # ---------------------------------------------------------
        request.validate()

        # ---------------------------------------------------------
        # Compile graph (must match execution-time graph)
        # ---------------------------------------------------------
        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        # ---------------------------------------------------------
        # 🔥 CRITICAL: RESET EXISTING STATE (in-place)
        # ---------------------------------------------------------
        state._records.clear()
        state._started_at = None
        state._completed_at = None

        # (add more fields here if ExecutionState evolves)
        state.paused_at = None
        state._open_attempts.clear()

        # ---------------------------------------------------------
        # 🔥 CRITICAL: fresh reducer (stateless replay)
        # ---------------------------------------------------------
        reducer = ExecutionReducer()

        # ---------------------------------------------------------
        # Apply events in order
        # ---------------------------------------------------------
        for event in events:
            reducer.apply(event, state, graph)

    def _create_replay_emitter(
        self,
        state: ExecutionState,
        graph: ExecutionGraph,
    ) -> OrchestrationEventEmitter:
        emitter = OrchestrationEventEmitter(
            observers=self._observers,
            event_log=None,
            reducer=self._reducer,
        )
        emitter.bind_runtime(state, graph)
        return emitter

    def _dependency_record_allows_progress(
        self,
        record: ExecutionRecord | None,
        max_attempts: int,
    ) -> bool:
        if record is None:
            return False

        if record.result.success:
            return True

        if record.result.metadata.get("non_blocking", False):
            return True

        if record.attempt < max_attempts:
            return False

        return False

    def _dependencies_ready(
        self,
        *,
        state: ExecutionState,
        graph: ExecutionGraph,
        node_id: str,
        max_attempts: int,
    ) -> bool:
        deps = graph.dependencies_of(node_id)

        for dep in deps:
            if dep == GraphCompiler.SYNTHETIC_ROOT:
                continue

            dep_record = state.latest_record(dep)

            if not self._dependency_record_allows_progress(
                dep_record,
                max_attempts,
            ):
                return False

        return True

    async def _continue_execution(
        self,
        *,
        request: ExecutionRequest,
        registry: AgentRegistry,
        state: ExecutionState,
        graph: ExecutionGraph,
        emitter: OrchestrationEventEmitter,
        start_nodes: list[str] | None,
        force: bool,
    ) -> MeshResult:
        # ---------------------------------------------------------
        # Replay / continuation scope
        # ---------------------------------------------------------
        allowed_nodes: set[str] | None = None

        if start_nodes:
            unknown = [node_id for node_id in start_nodes if node_id not in graph.nodes]

            if unknown:
                raise ResolutionError(
                    identifier=unknown[0],
                    message=f"Unknown start node(s): {unknown}",
                )

            allowed_nodes = self._collect_subgraph(graph, start_nodes)

        # ---------------------------------------------------------
        # Scenario
        # ---------------------------------------------------------
        raw_skip_nodes = request.scenario.param("skip_nodes", [])

        skip_nodes: set[str] = (
            {value for value in raw_skip_nodes if isinstance(value, str)}
            if isinstance(raw_skip_nodes, list)
            else set()
        )

        invokers = self._build_invokers(registry)

        node_executor = NodeExecutor(
            registry=registry,
            retry_policy=request.policy.retry_policy,
            event_emitter=emitter,
            graph=graph,
            invokers=invokers,
        )

        in_degree: dict[str, int] = {
            node_id: len(
                [
                    dep
                    for dep in graph.dependencies_of(node_id)
                    if dep != GraphCompiler.SYNTHETIC_ROOT
                ]
            )
            for node_id in graph.nodes.keys()
        }

        if start_nodes:
            ready: set[str] = set(start_nodes)
        else:
            ready = set(graph.children_of(GraphCompiler.SYNTHETIC_ROOT))

        while ready:
            current_wave = sorted(ready, key=graph.topo_index.__getitem__)
            ready.clear()

            executed_nodes: list[str] = []
            next_ready: set[str] = set()

            for node_id in current_wave:
                if allowed_nodes is not None and node_id not in allowed_nodes:
                    continue

                node = graph.nodes[node_id]

                if node_id in skip_nodes:
                    executed_nodes.append(node_id)
                    continue

                if node.agent is None:
                    continue

                latest = state.latest_record(node_id)

                if not force and latest is not None and latest.result.success:
                    executed_nodes.append(node_id)
                    continue

                if not force and not self._dependencies_ready(
                    state=state,
                    graph=graph,
                    node_id=node_id,
                    max_attempts=request.policy.retry_policy.max_attempts,
                ):
                    continue

                sequence_number = graph.topo_index[node_id]

                await node_executor.execute(
                    node_id,
                    node.agent,
                    request,
                    state,
                    sequence_number,
                )

                executed_nodes.append(node_id)

            for node_id in executed_nodes:
                record = state.latest_record(node_id)

                if record is None:
                    continue

                for child_id in graph.children_of(node_id):
                    in_degree[child_id] -= 1

                    if allowed_nodes is not None and child_id not in allowed_nodes:
                        continue

                    if in_degree[child_id] != 0:
                        continue

                    if self._dependencies_ready(
                        state=state,
                        graph=graph,
                        node_id=child_id,
                        max_attempts=request.policy.retry_policy.max_attempts,
                    ):
                        next_ready.add(child_id)

            ready.update(next_ready)

        result = self._aggregator.aggregate(
            graph=graph,
            state=state,
            policy=request.policy,
        )

        emitter.emit(
            ExecutionCompleted(
                request_id=request.request_id,
                timestamp=utc_now(),
                success=result.success,
                total_nodes=len(graph.nodes),
            )
        )

        self._enforce_mutation_policy(request)

        return result

    def _create_plugin_agent_from_definition(
        self,
        registry: AgentRegistry,
        definition: ExecutableDefinition,
    ) -> Agent:
        return registry.get(definition.agent_id)

    def _build_invokers(self, registry: AgentRegistry) -> InvokerRegistry:
        def load_plugin_agent(definition: ExecutableDefinition) -> Agent:
            return self._create_plugin_agent_from_definition(registry, definition)

        return InvokerRegistry(
            plugin_invoker=PythonPluginInvoker(
                agent_loader=load_plugin_agent,
            ),
            remote_http_invoker=RemoteHttpInvoker(),
        )
