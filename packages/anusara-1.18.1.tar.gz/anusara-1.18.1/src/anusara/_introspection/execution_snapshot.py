from dataclasses import asdict, dataclass
from datetime import datetime
from typing import cast

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.json_types import JSONValue

# ---------------------------------------------------------
# Attempt Snapshot (Immutable DTO)
# ---------------------------------------------------------


@dataclass(frozen=True)
class AttemptSnapshot:
    attempt: int
    sequence_number: int
    result: AgentResult

    forced: bool = False
    started_at: datetime | None = None
    completed_at: datetime | None = None


# ---------------------------------------------------------
# Execution Snapshot (Canonical Immutable Projection)
# ---------------------------------------------------------


@dataclass(frozen=True)
class ExecutionSnapshot:
    request_id: str
    overall_success: bool
    confidence: float
    records: dict[str, list[AttemptSnapshot]]
    started_at: datetime | None
    completed_at: datetime | None
    scenario: ExecutionScenario | None = None
    metadata: dict[str, JSONValue] | None = None

    # -----------------------------------------------------
    # Derived Properties
    # -----------------------------------------------------

    @property
    def total_nodes(self) -> int:
        return len(self.records)

    @property
    def total_attempts(self) -> int:
        return sum(len(attempts) for attempts in self.records.values())

    # -----------------------------------------------------
    # Serialization
    # -----------------------------------------------------

    def to_dict(self) -> dict[str, object]:
        data = cast(dict[str, object], asdict(self))

        if self.started_at is not None:
            data["started_at"] = self.started_at.isoformat()

        if self.completed_at is not None:
            data["completed_at"] = self.completed_at.isoformat()

        return data
