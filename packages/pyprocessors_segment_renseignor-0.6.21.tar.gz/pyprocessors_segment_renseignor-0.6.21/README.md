# pyprocessors_segment_renseignor

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_segment_renseignor)](https://github.com/oterrier/pyprocessors_segment_renseignor/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_segment_renseignor/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_segment_renseignor/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_segment_renseignor)](https://codecov.io/gh/oterrier/pyprocessors_segment_renseignor)
[![docs](https://img.shields.io/readthedocs/pyprocessors_segment_renseignor)](https://pyprocessors_segment_renseignor.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_segment_renseignor)](https://pypi.org/project/pyprocessors_segment_renseignor/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_segment_renseignor)](https://pypi.org/project/pyprocessors_segment_renseignor/)

A processor that creates segments from annotations in Renseignor documents. It extracts individual articles from annotated newsletter-style documents by identifying headers, topics, table of contents, and source boundaries.

## Installation

You can simply `pip install pyprocessors_segment_renseignor`.

## Developing

### Pre-requisites

You will need to install `uv` for package management:

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_segment_renseignor
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
