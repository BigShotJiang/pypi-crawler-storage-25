import os
import uuid
import time
import re
import ast

from git import Repo
import chromadb
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, HRFlowable
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# AI SDKs
from openai import OpenAI
import google.generativeai as genai
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
import threading
import itertools

console = Console()

def _animated_panel(live: Live, batch_num: int, total: int, stop_event: threading.Event):
    """Runs in a thread — animates until stop_event is set."""
    frames = itertools.cycle([
        "█▓▒░          ░▒▓█",
        " █▓▒░        ░▒▓█ ",
        "  █▓▒░      ░▒▓█  ",
        "   █▓▒░    ░▒▓█   ",
        "    █▓▒░  ░▒▓█    ",
        "     █▓▒░░▒▓█     ",
        "      █▓▒▒▓█      ",
        "       █▓▓█       ",
        "        ██        ",
        "       █▓▓█       ",
        "      █▓▒▒▓█      ",
        "     █▓▒░░▒▓█     ",
        "    █▓▒░  ░▒▓█    ",
        "   █▓▒░    ░▒▓█   ",
        "  █▓▒░      ░▒▓█  ",
        " █▓▒░        ░▒▓█ ",
    ])

    colors_cycle = itertools.cycle([
        "bold magenta", "bold cyan", "bold blue",
        "bold magenta", "bold cyan", "bold blue",
    ])

    progress_filled = int((batch_num - 1) / total * 30)
    progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)

    while not stop_event.is_set():
        frame = next(frames)
        color = next(colors_cycle)
        live.update(Panel(
            f"\n"
            f"[bold cyan]  🧠 Batch {batch_num}/{total}[/bold cyan]\n\n"
            f"[{color}]  {frame}[/{color}]\n\n"
            f"[dim]  [{progress_bar}] {int((batch_num-1)/total*100)}%[/dim]\n\n"
            f"[dim italic]  Analyzing codebase...[/dim italic]\n",
            title="[bold magenta]◈ GitPutra[/bold magenta]",
            border_style=color,
            padding=(1, 4),
        ))
        time.sleep(0.07)

# ─────────────────────────────────────────────
# GLOBALS
# ─────────────────────────────────────────────
_ai_config     = {}
_openai_client = None
_language      = "English"
_ai_disabled   = False

CHROMA_CLIENT = chromadb.PersistentClient(path="./chroma_db")

SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".pdf", ".txt",
    ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)

# Extensionless files to match by exact name
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__",
             ".idea", ".vscode", "dist", "build", ".mypy_cache", ".pytest_cache"}

AI_OPTIONS = {
    "gemini": {
        "name": "Gemini",
        "text_model": "models/gemini-2.5-flash",
        "embed_model": "models/gemini-embedding-001",
    },
    "openai": {
        "name": "OpenAI",
        "text_model": "gpt-4o-mini",
        "embed_model": "text-embedding-3-large",
    },
   
}


# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
def init(ai_choice: str, api_key: str, language: str = "English"):
    global _ai_config, _openai_client, _language

    _language  = language
    _ai_config = AI_OPTIONS[ai_choice]

    if ai_choice == "gemini":
        genai.configure(api_key=api_key)

    elif ai_choice == "openai":
        _openai_client = OpenAI(api_key=api_key)

# ─────────────────────────────────────────────
# COLLECTION PER REPO
# ─────────────────────────────────────────────
def get_collection(repo_name: str, branch: str = None):
    suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    safe_name = repo_name.replace("-", "_").replace(".", "_")
    return CHROMA_CLIENT.get_or_create_collection(name=f"repo_{safe_name}{suffix}")


# ─────────────────────────────────────────────
# AI — GENERATE
# ─────────────────────────────────────────────
def safe_generate(prompt: str, retries: int = 2) -> str | None:
    global _ai_disabled

    if _ai_disabled:
        return None

    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                model = genai.GenerativeModel(_ai_config["text_model"])
                res   = model.generate_content(
                    prompt,
                    generation_config={"max_output_tokens": 8192},
                )
                return getattr(res, "text", None)

            elif name == "OpenAI":
                res = _openai_client.chat.completions.create(
                    model=_ai_config["text_model"],
                    max_tokens=4096,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.choices[0].message.content

           

        except Exception as e:
            err = str(e)
            if "quota" in err.lower() and "429" not in err:
                console.print("⚠️  Quota exceeded → AI disabled for this session", style="bold red")
                _ai_disabled = True
                return None
            elif "429" in err or "rate" in err.lower():
                console.print(f"⏳ Rate limited — waiting 60 seconds...", style="bold blue")
                time.sleep(60)
                continue
            console.print(f"⚠️  Generation error (attempt {attempt + 1}/{retries}): {err}", style="bold red")
            if attempt < retries - 1:
                time.sleep(2)

    return None


# ─────────────────────────────────────────────
# AI — EMBED
# ─────────────────────────────────────────────
def embed_text(text: str, is_query: bool = False) -> list[float]:
    try:
        name = _ai_config["name"]

        if name == "Gemini":
            task_type = "retrieval_query" if is_query else "retrieval_document"
            res = genai.embed_content(
                model=_ai_config["embed_model"],
                content=text,
                task_type=task_type,
            )
            return res["embedding"]

        elif name == "OpenAI":
            res = _openai_client.embeddings.create(
                model=_ai_config["embed_model"],
                input=text,
            )
            return res.data[0].embedding

    except Exception as e:
        console.print(f"❌ Embedding failed-> {e}", style="bold red")
        return [0.0] * 1536  # Return dummy embedding on failure to avoid crashes; RAG results will be unreliable


# ─────────────────────────────────────────────
# REPO — CLONE & LOAD
# ─────────────────────────────────────────────
def clone_repo(url: str, branch: str = None) -> tuple[str, str]:
    os.makedirs("repos", exist_ok=True)
    name = url.rstrip("/").split("/")[-1].replace(".git", "")
    branch_suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    path = os.path.join("repos", f"{name}{branch_suffix}")

    if not os.path.exists(path):
        console.print(f"📥 Cloning {url} {'@ ' + branch if branch else ''} ...", style="bold cyan")
        kwargs = {"branch": branch} if branch else {}
        Repo.clone_from(url, path, **kwargs)
    else:
        console.print(f"✅ Repo already exists at {path}", style="bold green")

    return path, name

def load_files(repo_path: str) -> list[tuple[str, str]]:
    files_data = []

    for root, dirnames, files in os.walk(repo_path):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]  # prune in-place
        for file in files:
            if file.endswith(SUPPORTED_EXT) or file in SUPPORTED_NAMES:
                try:
                    if file.endswith(".pdf"):
                        import pdfplumber
                        with pdfplumber.open(os.path.join(root, file)) as pdf:
                            content = "\n".join(page.extract_text() or "" for page in pdf.pages).strip()
                    else:
                        with open(os.path.join(root, file), "r", errors="ignore") as f:
                            content = f.read().strip()
                    if content:
                        files_data.append((file, content))
                except Exception as e:
                    console.print (f"⚠️ Failed to load file {file}: {e}", style="bold red")

    console.print(f"📂 Loaded {len(files_data)} source files", style = "bold yellow")
    return files_data


# ─────────────────────────────────────────────
# CHUNKING
# ─────────────────────────────────────────────
def chunk_by_file(files: list[tuple[str, str]], max_chars: int = 3000) -> list[str]:
    chunks, current = [], ""

    for fname, content in files:
        piece = f"\n# FILE: {fname}\n{content}\n"
        if len(current) + len(piece) > max_chars:
            if current:
                chunks.append(current)
            current = piece
        else:
            current += piece

    if current:
        chunks.append(current)

    return chunks


# ─────────────────────────────────────────────
# CHROMADB — STORE & QUERY
# ─────────────────────────────────────────────
def store_chunks(files: list[tuple[str, str]], repo_name: str, branch: str = None):
    collection = get_collection(repo_name, branch)
    console.print("💾 Storing embeddings...", style = "bold yellow")

    chunks = chunk_by_file(files, max_chars=3000)
    for chunk in chunks:
        emb = embed_text(chunk)
        collection.add(
            documents=[chunk],
            embeddings=[emb],
            ids=[str(uuid.uuid4())],
            metadatas=[{"chunk": chunk[:80]}],  # store a short preview for debugging
        )

    console.print(f"✅ Stored {len(chunks)} chunks", style="bold green")


def query_rag(question: str, repo_name: str, branch: str = None) -> str:
    collection = get_collection(repo_name, branch)

    emb  = embed_text(question, is_query=True)  # <-- fix
    res  = collection.query(query_embeddings=[emb], n_results=5)
    docs = res.get("documents", [[]])[0]
    context = "\n".join(docs) if docs else ""

    prompt = f"""Answer in {_language}.

Context from codebase:
{context}

Question:
{question}
"""
    return safe_generate(prompt) or "⚠️ AI unavailable."


# ─────────────────────────────────────────────
# ANALYSIS
# ─────────────────────────────────────────────

# Max chars to send in a single API call.
# ~60k chars ≈ 15k tokens — safe for Gemini 2.5 Flash, GPT-4o-mini
# (all support 128k+ context). Fits ~20 chunks of 3000 chars each.
_BATCH_CHARS = 60_000

def analyze_repo(files: list[tuple[str, str]]) -> str:
    console.print("\n🔍 Analyzing repo...\n", style = "bold blue")
    chunks = chunk_by_file(files)

    # ── pack chunks into batches ─────────────────────────────────────────────
    batches: list[str] = []
    current_batch: list[str] = []
    current_len = 0

    for chunk in chunks:
        if current_len + len(chunk) > _BATCH_CHARS and current_batch:
            batches.append("\n".join(current_batch))
            current_batch, current_len = [], 0
        current_batch.append(chunk)
        current_len += len(chunk)

    if current_batch:
        batches.append("\n".join(current_batch))

    console.print(f"  📦 {len(chunks)} chunks → {len(batches)} batch call(s) + 1 synthesis\n", style = "bold yellow")

    # ── one summary call per batch ───────────────────────────────────────────
    summaries = []
    with Live(console=console, refresh_per_second=20) as live:
        for i, batch in enumerate(batches, 1):
            # start animation thread
            stop_event = threading.Event()
            thread = threading.Thread(
                target=_animated_panel,
                args=(live, i, len(batches), stop_event),
                daemon=True
            )
            thread.start()

            # actual API call — animation runs while this blocks
            res = safe_generate(f"""
You are a senior software engineer performing a deep technical audit of a real-world codebase.

STRICT RULES:
- Do NOT assume components that are not present in the code.
- Do NOT invent architecture or modules.
- Every claim must be grounded in actual code.
- Reference file names or code snippets as evidence.
- If something is unclear or missing, explicitly say so.

Your job is NOT to summarize — it is to reverse-engineer and critique.

Analyze the following codebase chunk and provide:

1. REAL FUNCTIONALITY
- What does this code ACTUALLY do (not what it intends to do)
- What problem it is solving in practice

2. CORE LOGIC BREAKDOWN
- Key functions/classes and how they work internally
- Data flow within this chunk
- Any algorithms or patterns used

3. DEPENDENCIES & INTERACTIONS
- Libraries used and why
- How different parts of the code interact

4. ENGINEERING QUALITY
- Code quality issues (duplication, inefficiency, bad patterns)
- Performance concerns
- Maintainability problems

5. NON-OBVIOUS INSIGHTS
- Hidden clever tricks
- Design decisions that are interesting or unusual

Code:
{batch}
""")
            stop_event.set()
            thread.join()

            if res:
                summaries.append(res)

            # flash completion
            progress_filled = int(i / len(batches) * 30)
            progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)
            live.update(Panel(
                f"\n"
                f"[bold green]  ✅ Batch {i}/{len(batches)} complete[/bold green]\n\n"
                f"[bold green]  {'█' * 18}[/bold green]\n\n"
                f"[dim]  [{progress_bar}] {int(i/len(batches)*100)}%[/dim]\n\n"
                f"[dim italic]  {'Synthesizing final report...' if i == len(batches) else 'Next batch loading...'}[/dim italic]\n",
                title="[bold magenta]✦ GitPutra[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
            ))
            time.sleep(0.6)    

    if not summaries:
        return "⚠️ AI unavailable — no analysis generated."

    # ── final synthesis (unchanged) ──────────────────────────────────────────
    return safe_generate(f"""
You are a principal engineer reviewing a codebase for production readiness.

STRICT RULES:
- Do NOT invent components not present in the summaries
- Base everything ONLY on provided summaries
- Be critical, not polite
- Prefer accuracy over completeness

Generate a detailed technical report with:

### ACTUAL SYSTEM SUMMARY
- What the system truly does (not idealized version)
- Real capabilities vs implied ones

### ARCHITECTURE (REAL, NOT ASSUMED)
- How the system is actually structured
- Data flow across components
- Highlight fragmentation or inconsistencies

### KEY ENGINEERING DECISIONS
- Important patterns (e.g., two-stage inference, frame skipping)
- Why they matter

### CODE QUALITY ANALYSIS
- Duplication, lack of abstraction, bad practices
- Scalability and maintainability issues

### FALSE ASSUMPTIONS / GAPS
- Missing components that SHOULD exist but don’t
- Mismatch between expected vs actual system

### PERFORMANCE & DESIGN INSIGHTS
- What is optimized well
- What is inefficient

### CONCRETE IMPROVEMENTS
- Specific fixes with examples
- Refactoring suggestions
- Architecture redesign ideas

Be brutally honest. Avoid generic statements.

Summaries:
{chr(10).join(summaries)}
""") or "⚠️ Final synthesis failed."


# ─────────────────────────────────────────────
# DIAGRAMS
# ─────────────────────────────────────────────
def _clean(name: str) -> str:
    return (
        name.replace(".py", "_py")
            .replace(".", "_")
            .replace("-", "_")
            .replace("/", "_")
    )

_FUNC_PATTERNS = {
    # language: (function definition pattern, call pattern)
    ".py":    (r"^def (\w+)\s*\(",           r"(\w+)\s*\("),
    ".js":    (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".ts":    (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".jsx":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".tsx":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".java":  (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(", r"(\w+)\s*\("),
    ".go":    (r"^func (\w+)\s*\(",           r"(\w+)\s*\("),
    ".rs":    (r"^fn (\w+)\s*\(",             r"(\w+)\s*\("),
    ".c":     (r"^\w[\w\s\*]+(\w+)\s*\(",     r"(\w+)\s*\("),
    ".cpp":   (r"^\w[\w\s\*]+(\w+)\s*\(",     r"(\w+)\s*\("),
    ".cs":    (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(", r"(\w+)\s*\("),
    ".rb":    (r"^def (\w+)",                 r"(\w+)\s*[\(\s]"),
    ".php":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".swift": (r"func (\w+)\s*\(",            r"(\w+)\s*\("),
    ".kt":    (r"fun (\w+)\s*\(",             r"(\w+)\s*\("),
    ".lua":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
}

# names to always ignore — builtins, keywords, noise
_IGNORE = {
    "if", "for", "while", "switch", "return", "print", "len", "range",
    "str", "int", "float", "bool", "list", "dict", "set", "tuple",
    "new", "this", "self", "super", "null", "true", "false",
    "console", "log", "err", "error", "fmt", "append", "make",
    "require", "import", "include", "define", "typeof", "instanceof",
}


def _extract_calls(fname: str, content: str) -> dict[str, set[str]]:
    ext = os.path.splitext(fname)[1].lower()

    # Python gets accurate AST-based extraction
    if ext == ".py":
        try:
            tree = ast.parse(content)
            calls: dict[str, set[str]] = {}
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    func_name = f"{os.path.splitext(fname)[0]}.{node.name}"
                    called = set()
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call):
                            if isinstance(child.func, ast.Name):
                                called.add(child.func.id)
                            elif isinstance(child.func, ast.Attribute):
                                called.add(child.func.attr)
                    calls[func_name] = called - _IGNORE
            return calls
        except SyntaxError:
            pass  # fall through to regex

    # Everything else — regex based
    if ext not in _FUNC_PATTERNS:
        return {}

    def_pattern, call_pattern = _FUNC_PATTERNS[ext]
    calls: dict[str, set[str]] = {}
    current_func = None

    for line in content.splitlines():
        # check if this line defines a new function
        m = re.search(def_pattern, line)
        if m:
            current_func = f"{os.path.splitext(fname)[0]}.{m.group(1)}"
            calls[current_func] = set()

        # collect calls within the current function scope
        if current_func:
            for m in re.finditer(call_pattern, line):
                name = m.group(1)
                if name not in _IGNORE and name != current_func.split(".")[-1]:
                    calls[current_func].add(name)

    return calls


def generate_diagram(files: list[tuple[str, str]]):
    G = nx.DiGraph()

    # collect all known function names across the project
    all_funcs: dict[str, str] = {}  # short_name -> full_name
    all_calls: dict[str, set[str]] = {}

    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)
        for full_name in calls:
            short = full_name.split(".")[-1]
            all_funcs[short] = full_name

    # only draw edges where the callee is a project-defined function
    for func, called_set in all_calls.items():
        for callee in called_set:
            if callee in all_funcs and all_funcs[callee] != func:
                G.add_edge(func, all_funcs[callee])

    os.makedirs("output", exist_ok=True)

    if G.number_of_edges() == 0:
        console.print("📊 No intra-project function calls found — skipping diagram", style="bold yellow")
        return

    plt.figure(figsize=(16, 12))
    pos = nx.spring_layout(G, k=2, seed=42)
    nx.draw(
        G, pos,
        with_labels=True,
        node_size=1200,
        node_color="steelblue",
        font_color="white",
        font_size=7,
        edge_color="gray",
        arrows=True,
        arrowsize=15,
    )
    plt.tight_layout()
    plt.savefig("output/diagram.png", dpi=150)
    plt.close()
    console.print("📊 Saved output/diagram.png", style = "bold yellow")



def generate_mermaid(files: list[tuple[str, str]]):
    lines, seen = ["graph TD"], set()

    all_funcs: dict[str, str] = {}
    all_calls: dict[str, set[str]] = {}

    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)
        for full_name in calls:
            short = full_name.split(".")[-1]
            all_funcs[short] = full_name

    for func, called_set in all_calls.items():
        func_node = func.replace(".", "_").replace("-", "_")
        for callee in called_set:
            if callee in all_funcs and all_funcs[callee] != func:
                callee_node = all_funcs[callee].replace(".", "_").replace("-", "_")
                edge = f"{func_node} --> {callee_node}"
                if edge not in seen:
                    lines.append(f"    {edge}")
                    seen.add(edge)

    os.makedirs("output", exist_ok=True)

    if len(lines) == 1:  # only "graph TD", no edges
        console.print("🗺️  No intra-project function calls found — skipping mermaid", style="bold red")
        return

    with open("output/mermaid.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    console.print("🗺️  Saved output/mermaid.txt", style="bold green")


# ─────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _register_fonts():
    font_dir = os.path.join(_BASE_DIR, "fonts")
    mappings = {
        "NotoLatin":      "NotoSans-Regular.ttf",
        "NotoBengali":    "NotoSansBengali-Regular.ttf",
        "NotoDevanagari": "NotoSansDevanagari-Regular.ttf",
    }
    for font_name, filename in mappings.items():
        path = os.path.join(font_dir, filename)
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont(font_name, path))


def _get_font(language: str) -> str:
    lang = language.lower()
    if lang in ("bengali", "bangla"):
        font = "NotoBengali"
    elif lang == "hindi":
        font = "NotoDevanagari"
    else:
        font = "NotoLatin"

    try:
        pdfmetrics.getFont(font)
        return font
    except KeyError:
        return "Helvetica"


def generate_pdf(text: str):
    os.makedirs("output", exist_ok=True)
    _register_fonts()
    font = _get_font(_language)

    styles = {
        "title": ParagraphStyle(
            "title",
            fontName=font,
            fontSize=22,
            leading=26,
            textColor=colors.darkblue,
            spaceAfter=16
        ),
        "head": ParagraphStyle(
            "head",
            fontName=font,
            fontSize=16,
            leading=20,
            textColor=colors.HexColor("#1f4e79"),
            spaceBefore=12,
            spaceAfter=8
        ),
        "body": ParagraphStyle(
            "body",
            fontName=font,
            fontSize=11,
            leading=16,
            spaceAfter=6
        ),
        "bullet": ParagraphStyle(
            "bullet",
            fontName=font,
            fontSize=11,
            leading=14,
            leftIndent=12
        )
    }
    story = [
        Paragraph(f"Repo Analysis Report ({_language})", styles["title"]),
        Paragraph(
            "Automated technical audit generated using AI-assisted repository analysis.",
            styles["body"]
        ),
        Spacer(1, 12),
    ]

    for section in text.split("###"):
        lines = section.splitlines()
        if not lines:
            continue
        heading = lines[0].strip()
        if not heading:
            continue
        # Divider line
        story.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
        story.append(Spacer(1, 6))

        # Heading
        story.append(Paragraph(f"<b>{heading}</b>", styles["head"]))

        # Body parsing
        for line in lines[1:]:
            clean = (
                line.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("**", "")
                    .replace("*", "")
                    .replace("`", "")
                    .strip()
            )

            if not clean:
                continue
            
            if clean.startswith("-"):
                story.append(Paragraph(f"• {clean[1:].strip()}", styles["bullet"]))
            else:
                story.append(Paragraph(clean, styles["body"]))

        story.append(Spacer(1, 10))

    diagram_path = "output/diagram.png"
    if os.path.exists(diagram_path):
        story.append(Image(diagram_path, width=500, height=380))

    doc = SimpleDocTemplate(
    "output/report.pdf",
    rightMargin=40,
    leftMargin=40,
    topMargin=50,
    bottomMargin=40
    )

    doc.build(story)
    console.print("📄 Saved output/report.pdf", style="bold green")