import os
import json
import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from rich import print as rprint

console = Console()

# ── Re-use the same extension filter as corelogic.py ──────────────────────────
SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".pdf", 
    ".txt", ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

# Files/dirs that are noise — never include them
SKIP_DIRS  = {".git", ".venv", "venv", "node_modules", "__pycache__",
              ".idea", ".vscode", "dist", "build", ".mypy_cache", ".pytest_cache"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "poetry.lock", "Pipfile.lock"}

# How many chars of a file to send to the AI for summarisation
MAX_CHARS_PER_FILE = 4000
# Rough limit for the "full source dump" section in the export
MAX_CHARS_FULL_DUMP = 8000


# ──────────────────────────────────────────────────────────────────────────────
# 1. FILE DISCOVERY
# ──────────────────────────────────────────────────────────────────────────────

def _should_include(fname: str) -> bool:
    if fname in SKIP_FILES:
        return False
    return fname.endswith(SUPPORTED_EXT) or fname in SUPPORTED_NAMES


def scan_project(root: str) -> list[dict]:
    """
    Walk *root* and return a list of dicts:
        { path (relative), abs_path, size_bytes, content (str) }
    """
    results = []

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune unwanted dirs in-place so os.walk doesn't recurse into them
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]

        rel_dir = os.path.relpath(dirpath, root)

        for fname in filenames:
            if not _should_include(fname):
                continue

            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.join(rel_dir, fname).lstrip("./\\")

            try:
                if fname.endswith(".pdf"):
                    import pdfplumber
                    with pdfplumber.open(abs_path) as pdf:
                        content = "\n".join(
                            page.extract_text() or "" for page in pdf.pages
                        ).strip()
                else:
                    with open(abs_path, "r", errors="ignore") as fh:
                        content = fh.read()
                if not content.strip():
                    continue
                results.append({
                    "path":      rel_path,
                    "abs_path":  abs_path,
                    "size_bytes": os.path.getsize(abs_path),
                    "content":   content,
                })
            except Exception as e:
                console.log(f"⚠️ Error reading {abs_path}: {e}")

    # Stable, deterministic order
    results.sort(key=lambda f: f["path"])
    console.log(f"📂  Found {len(results)} source files in '{os.path.basename(root)}'")
    return results


# ──────────────────────────────────────────────────────────────────────────────
# 2. FILE TREE
# ──────────────────────────────────────────────────────────────────────────────

def build_file_tree(files: list[dict]) -> str:
    """Render an ASCII file tree from the scanned file list."""
    tree: dict = {}
    for f in files:
        parts = f["path"].replace("\\", "/").split("/")
        node  = tree
        for part in parts:
            node = node.setdefault(part, {})

    lines = []

    def _render(node: dict, prefix: str = ""):
        items = sorted(node.keys())
        for i, key in enumerate(items):
            connector = "└── " if i == len(items) - 1 else "├── "
            lines.append(f"{prefix}{connector}{key}")
            child = node[key]
            if child:
                extension = "    " if i == len(items) - 1 else "│   "
                _render(child, prefix + extension)

    _render(tree)
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────────
# 3. TECH STACK DETECTION (heuristic, no AI needed)
# ──────────────────────────────────────────────────────────────────────────────

_TECH_HINTS = {
    # Languages
    ".py":    "Python",
    ".js":    "JavaScript",
    ".ts":    "TypeScript",
    ".go":    "Go",
    ".rs":    "Rust",
    ".java":  "Java",
    ".cpp":   "C++",
    ".c":     "C",  
    ".cs":    "C#",
    ".rb":    "Ruby",
    ".php":   "PHP",
    ".swift": "Swift",
    ".kt":    "Kotlin",
    ".dart":  "Dart",
    ".scala": "Scala",
    ".r":     "R",
    ".lua":   "Lua",
    # Config / infra
    "Dockerfile":      "Docker",
    "docker-compose":  "Docker Compose",
    ".tf":             "Terraform",
    ".yaml":           "YAML config",
    ".yml":            "YAML config",
    # Frontend
    ".vue":  "Vue.js",
    ".jsx":  "React (JSX)",
    ".tsx":  "React (TSX)",
    ".html": "HTML",
    ".css":  "CSS",
    # Data / notebooks
    ".ipynb": "Jupyter Notebook",
    ".sql":   "SQL",
}

_FRAMEWORK_HINTS = {
    "requirements.txt":  "pip / Python deps",
    "pyproject.toml":    "Poetry / PEP 517",
    "setup.py":          "setuptools",
    "package.json":      "Node.js / npm",
    "pom.xml":           "Maven (Java)",
    "build.gradle":      "Gradle (Java/Kotlin)",
    "Cargo.toml":        "Cargo (Rust)",
    "go.mod":            "Go modules",
    "Gemfile":           "Bundler (Ruby)",
    "composer.json":     "Composer (PHP)",
}


def detect_tech_stack(files: list[dict]) -> dict:
    langs:     set[str] = set()
    infra:     set[str] = set()
    pkg_files: list[str] = []

    for f in files:
        fname = os.path.basename(f["path"])
        ext   = os.path.splitext(fname)[1].lower()

        if ext in _TECH_HINTS:
            langs.add(_TECH_HINTS[ext])
        if fname in _TECH_HINTS:
            infra.add(_TECH_HINTS[fname])
        if fname in _FRAMEWORK_HINTS:
            pkg_files.append(f"{fname}  →  {_FRAMEWORK_HINTS[fname]}")

    return {
        "languages":  sorted(langs),
        "infra":      sorted(infra),
        "pkg_files":  sorted(set(pkg_files)),
    }


# ──────────────────────────────────────────────────────────────────────────────
# 4. AI SUMMARIES  (uses safe_generate from corelogic — injected at call time)
# ──────────────────────────────────────────────────────────────────────────────

def _summarise_file(fname: str, content: str, language: str, safe_generate_fn) -> str:
    snippet = content[:MAX_CHARS_PER_FILE]
    prompt  = f"""Respond ONLY in {language}.
You are summarising a single source file for a developer switching AI tools.
Be concise but complete. Cover:
- Purpose of this file (1-2 sentences)
- Key functions / classes / exports and what they do
- Notable patterns, dependencies, or side-effects

File: {fname}
---
{snippet}
{"...[truncated]" if len(content) > MAX_CHARS_PER_FILE else ""}
"""
    return safe_generate_fn(prompt) or "(summary unavailable)"


def _synthesise_project(
    project_name: str,
    file_summaries: list[dict],
    tech: dict,
    language: str,
    safe_generate_fn,
) -> str:
    summaries_text = "\n\n".join(
        f"### {s['path']}\n{s['summary']}" for s in file_summaries
    )

    prompt = f"""Respond ONLY in {language}.
A developer is exporting their codebase context so they can continue working
with a DIFFERENT AI tool without losing context. Write a comprehensive project
brief covering:

1. **Project Goal** — what does this project do and why?
2. **Architecture Overview** — how are the major components connected?
3. **Key Design Decisions** — patterns, tradeoffs, or constraints to be aware of.
4. **Current State** — what is complete, what is WIP, any known issues?
5. **How to Resume Work** — the most important things a new AI agent must know.

Tech stack detected: {', '.join(tech['languages'] + tech['infra']) or 'unknown'}
Package files: {', '.join(tech['pkg_files']) or 'none found'}

Per-file summaries:
{summaries_text}
"""
    return safe_generate_fn(prompt) or "(project synthesis unavailable)"


# ──────────────────────────────────────────────────────────────────────────────
# 5. MARKDOWN ASSEMBLY
# ──────────────────────────────────────────────────────────────────────────────

def _md_section(title: str, body: str) -> str:
    return f"## {title}\n\n{body.strip()}\n\n"


def assemble_markdown(
    project_name: str,
    root: str,
    files: list[dict],
    tech: dict,
    file_summaries: list[dict],
    project_summary: str,
    language: str,
) -> str:
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    parts = [
        f"# 🧠 GitPutra Context Export — `{project_name}`\n\n",
        f"> **Generated:** {now}  |  **Language:** {language}  "
        f"|  **Files:** {len(files)}  |  **Root:** `{root}`\n\n",
        "---\n\n",
        "<!-- HOW TO USE THIS FILE\n"
        "Paste this entire file into any AI chat (ChatGPT, Gemini …)\n"
        "and say: 'I am sharing my codebase context. Read it and help me continue.'\n"
        "-->\n\n",
    ]

    # ── Project summary ──────────────────────────────────────────────────────
    parts.append(_md_section("📋 Project Overview", project_summary))

    # ── Tech stack ───────────────────────────────────────────────────────────
    tech_body = ""
    if tech["languages"]:
        tech_body += "**Languages:** " + ", ".join(tech["languages"]) + "\n\n"
    if tech["infra"]:
        tech_body += "**Infra / tooling:** " + ", ".join(tech["infra"]) + "\n\n"
    if tech["pkg_files"]:
        tech_body += "**Package files detected:**\n" + "\n".join(
            f"- {p}" for p in tech["pkg_files"]
        ) + "\n"
    parts.append(_md_section("🛠️ Tech Stack", tech_body or "Not detected."))

    # ── File tree ────────────────────────────────────────────────────────────
    tree = build_file_tree(files)
    parts.append(_md_section("📁 File Tree", f"```\n{tree}\n```"))

    # ── Per-file summaries ───────────────────────────────────────────────────
    summaries_md = ""
    for s in file_summaries:
        size_kb = s["size_bytes"] / 1024
        summaries_md += (
            f"### `{s['path']}`  _{size_kb:.1f} KB_\n\n"
            f"{s['summary']}\n\n"
            "---\n\n"
        )

    if not summaries_md:
        # --no-ai path: still show each file with size so the section isn't blank
        for f in files:
            size_kb = f["size_bytes"] / 1024
            summaries_md += (
                f"### `{f['path']}`  _{size_kb:.1f} KB_\n\n"
                f"_(AI summary skipped — see full source in the Source Snapshot below.)_\n\n"
                "---\n\n"
            )

    parts.append(f"## 📄 File-by-File Summaries\n\n{summaries_md}")

    # ── Full source (truncated) ───────────────────────────────────────────────
    source_md = ""
    for f in files:
        snippet = f["content"][:MAX_CHARS_FULL_DUMP]
        truncated = len(f["content"]) > MAX_CHARS_FULL_DUMP
        ext = os.path.splitext(f["path"])[1].lstrip(".")
        source_md += (
            f"### `{f['path']}`\n\n"
            f"```{ext}\n{snippet}"
            f"\n{'// ... [truncated — see full file in repo]' if truncated else ''}"
            f"\n```\n\n"
        )
    parts.append(f"## 📦 Source Snapshot\n\n{source_md}")

    # ── Footer ───────────────────────────────────────────────────────────────
    parts.append(
        "---\n\n"
        "_Context exported by [GitPutra](https://pypi.org/project/gitputra/) — "
        "AI-powered repository analyzer._\n"
    )

    return "".join(parts)


# ──────────────────────────────────────────────────────────────────────────────
# 6. MAIN ENTRY POINT
# ──────────────────────────────────────────────────────────────────────────────

def export_context(
    project_path: str,
    safe_generate_fn,          # injected from corelogic so we don't duplicate AI logic
    language:    str  = "English",
    output_dir:  str  = "output",
    skip_ai:     bool = False,  # --no-ai flag: produce tree + stack only, no LLM calls
) -> str:
    """
    Full pipeline. Returns the path to the written .md file.

    Args:
        project_path    – absolute or relative path to the local codebase root
        safe_generate_fn – corelogic.safe_generate (already initialised with provider + key)
        language        – human language for AI summaries
        output_dir      – where to write the .md file
        skip_ai         – if True, omit LLM summaries (fast, offline)
    """
    project_path = os.path.abspath(project_path.strip())
    project_name = os.path.basename(project_path)

    if not os.path.isdir(project_path):
        raise NotADirectoryError(f"'{project_path}' is not a directory.")

    # 1. Scan
    files = scan_project(project_path)
    if not files:
        raise ValueError(f"No supported source files found in '{project_path}'.")

    # 2. Tech stack (heuristic, instant)
    tech = detect_tech_stack(files)
    console.log(f"🔍  Languages: {', '.join(tech['languages']) or 'none detected'}")

    # 3. Per-file AI summaries
    file_summaries: list[dict] = []
    if skip_ai:
        console.log("⚡  --no-ai: skipping LLM summaries")
    else:
        total = len(files)
        for f in track(files, description="🧠 Summarizing files..."):
            summary = _summarise_file(f["path"], f["content"], language, safe_generate_fn)
            file_summaries.append({
                "path":       f["path"],
                "size_bytes": f["size_bytes"],
                "summary":    summary,
            })

    # 4. Project-level synthesis
    console.log("🧩  Synthesising project overview...")
    if skip_ai or not file_summaries:
        project_summary = (
            f"*AI summaries were skipped (`--no-ai`). "
            f"This export contains the file tree, tech stack, and full source snapshot "
            f"for `{project_name}`.*"
        )
    else:
        project_summary = _synthesise_project(
            project_name, file_summaries, tech, language, safe_generate_fn
        )

    # 5. Assemble Markdown
    md = assemble_markdown(
        project_name    = project_name,
        root            = project_path,
        files           = files,
        tech            = tech,
        file_summaries  = file_summaries,
        project_summary = project_summary,
        language        = language,
    )

    # 6. Write output
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path  = os.path.join(output_dir, f"context_{project_name}_{timestamp}.md")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(md)

    size_kb = os.path.getsize(out_path) / 1024
    console.log(f"\n✅  Context exported → {out_path}  ({size_kb:.1f} KB)")
    console.log(
        "\n💡  How to use:\n"
        "    1. Open the .md file\n"
        "    2. Paste it into any AI chat (ChatGPT, Gemini …)\n"
        '    3. Say: "Here is my codebase context. Read it and help me continue."\n'
    )

    return out_path