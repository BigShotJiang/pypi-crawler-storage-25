import click
from dotenv import load_dotenv
from . import corelogic as core
from . import context_export as ctx
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from rich import print as rprint

console = Console()

load_dotenv()


@click.group()
@click.version_option("0.2.5", prog_name="gitputra")
def main():
    """🔍 Gitputra — AI-powered GitHub repo analyzer."""
    pass


# ─────────────────────────────────────────────
# ANALYZE
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai"], case_sensitive=False),
    default="gemini", show_default=True,
    help="AI provider to use."
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option(
    "--lang", default="English", show_default=True,
    help="Output language for the report."
)
@click.option(
    "--no-pdf", is_flag=True, default=False,
    help="Skip PDF generation."
)
@click.option(
    "--no-diagram", is_flag=True, default=False,
    help="Skip diagram generation."
)
@click.option(
    "--local", is_flag=True, default=False,
    help="Analyze a local directory instead of cloning a GitHub URL."
)
def analyze(url, branch, ai_choice, key, lang, no_pdf, no_diagram, local):
    """Clone a GitHub repo and generate an AI analysis report.

    \b
    Remote repo:
        gitputra analyze https://github.com/user/repo --ai gemini --key AIza...
    \b
    Local codebase:
        gitputra analyze ./my-project --local --ai gemini --key AIza...
        gitputra analyze "C:\\path\\with spaces\\project" --local --ai gemini --key AIza...
    """
    if not key:
        key = click.prompt("🔑 Enter API key", hide_input=True)

    core.init(ai_choice.lower(), key, lang)

    if local:
        import os
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Analyzing local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    files = core.load_files(repo_path)

    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)

    collection = core.get_collection(repo_name, branch)
    if collection.count() == 0:
        core.store_chunks(files, repo_name, branch)
    else:
        console.print("ℹ️  Using existing index (run 'clear-db' to re-index).", style="bold cyan")

    analysis = core.analyze_repo(files)

    console.print(Panel.fit(analysis, title="🔍 Analysis Report", border_style="green"))

    if not no_diagram:
        core.generate_diagram(files)
        core.generate_mermaid(files)

    if not no_pdf:
        core.generate_pdf(analysis)

    console.print("✅ Done! Outputs saved in ./output/", style="bold green")


# ─────────────────────────────────────────────
# CHAT
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai"], case_sensitive=False),
    default="gemini", show_default=True,
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option("--lang", default="English", show_default=True)
@click.option(
    "--local", is_flag=True, default=False,
    help="Chat about a local directory instead of cloning a GitHub URL."
)
def chat(url, branch, ai_choice, key, lang, local):
    """Start an interactive RAG chat about a repo.

    \b
    Remote repo:
        gitputra chat https://github.com/user/repo --ai gemini
    \b
    Local codebase:
        gitputra chat ./my-project --local --ai gemini --key AIza...
        Type 'exit' or Ctrl+C to quit.
    """
    if not key:
        key = click.prompt("🔑 Enter API key", hide_input=True)
    core.init(ai_choice.lower(), key, lang)

    if local:
        import os
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Using local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    collection = core.get_collection(repo_name, branch)
    if collection.count() == 0:
        console.print("📂 No existing index found — indexing now...", style="bold yellow")
        files = core.load_files(repo_path)
        if not files:
            console.print("❌ No supported source files found.", style="bold red")
            raise SystemExit(1)
        core.store_chunks(files, repo_name, branch)
        console.print("✅ Indexed.", style="bold green")
    else:
        console.print("✅ Using existing index.", style="bold cyan")

    console.print(f"\n💬 Chat mode [{repo_name}] — ask anything about the codebase. Type 'exit' to quit.\n", style="bold cyan")

    while True:
        try:
            question = console.input("[bold cyan]>> [/]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n NAMASKAR", style="bold magenta")
            break

        if question.strip().lower() in ("exit", "quit", "q"):
            console.print("\n NAMASKAR", style="bold magenta")
            break

        answer = core.query_rag(question, repo_name, branch)
        console.print(Panel(answer, title="🤖 Answer", border_style="blue"))


# ─────────────────────────────────────────────
# EXPORT CONTEXT
# ─────────────────────────────────────────────
@main.command("export-context")
@click.argument("project_path", default=".", metavar="PROJECT_PATH", type=click.Path())
@click.option("--branch", default=None, help="Branch to clone (only used with --remote).")
@click.option("--remote", is_flag=True, default=False, help="Treat PROJECT_PATH as a GitHub URL and clone it first.")

@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai"], case_sensitive=False),
    default="gemini", show_default=True,
    help="AI provider to use for summaries."
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env)."
)
@click.option(
    "--lang", default="English", show_default=True,
    help="Language for AI-generated summaries."
)
@click.option(
    "--use-ai", "no_ai", is_flag=True, default=True, flag_value=False,
    help="Use LLM to generate AI summaries and project overview (requires --ai and --key)."
)
def export_context_cmd(project_path, branch, remote, ai_choice, key, lang, no_ai):
    """Export a portable context file from a local or remote codebase.

    Scans PROJECT_PATH (defaults to current directory), generates AI summaries
    of every file, and writes a single Markdown file you can paste into any AI
    tool (ChatGPT, Gemini ...) to continue work without re-explaining
    the project.

    \b
    IMPORTANT — wrap paths in quotes if they contain spaces:
        gitputra export-context "C:\\Users\\you\\My Project"

    \b
    Examples:
        gitputra export-context ./my-project                              (fast, no key needed)
        gitputra export-context "C:\\path\\with spaces\\project"
        gitputra export-context ./my-project --use-ai --ai gemini --key AIza...
        gitputra export-context ./my-project --use-ai --ai openai --key sk-ant-...
        gitputra export-context                                           (scans current dir)
    """
    if remote:
        project_path, _ = core.clone_repo(project_path, branch)

    if no_ai:
        gen_fn = lambda _prompt: None
    else:
        if not key:
            key = click.prompt("🔑 Enter API key", hide_input=True)
        core.init(ai_choice.lower(), key, lang)
        gen_fn = core.safe_generate

    ctx.export_context(
        project_path     = project_path,
        safe_generate_fn = gen_fn,
        language         = lang,
        skip_ai          = no_ai,
    )


# ─────────────────────────────────────────────
# CLEAR DB
# ─────────────────────────────────────────────
@main.command("clear-db")
def clear_db():
    """Wipe the local ChromaDB collection."""
    import chromadb
    client = chromadb.PersistentClient(path="./chroma_db")
    for col in client.list_collections():
        client.delete_collection(col.name)
    console.print("🗑️  ChromaDB cleared.", style="bold yellow")

# ─────────────────────────────────────────────
# INFORMATION
# ─────────────────────────────────────────────
@main.command()
def info():
    """Show supported AIs, languages, extensions, and commands."""
    console.print("\n")
    console.print("   ██████╗ ██╗████████╗██████╗ ██╗   ██╗████████╗██████╗  █████╗ ", style="bold red")
    console.print("  ██╔════╝ ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██╔══██╗", style="bold red")
    console.print("  ██║  ███╗██║   ██║   ██████╔╝██║   ██║   ██║   ██████╔╝███████║", style="bold yellow")
    console.print("  ██║   ██║██║   ██║   ██╔═══╝ ██║   ██║   ██║   ██╔══██╗██╔══██║", style="bold blue")
    console.print("  ╚██████╔╝██║   ██║   ██║     ╚██████╔╝   ██║   ██║  ██║██║  ██║", style="bold blue")
    console.print("   ╚═════╝ ╚═╝   ╚═╝   ╚═╝      ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝", style="bold yellow")
    console.print("\n ◈ GitPutra — Analyze • Visualize • Synthesize ", style="bold cyan")

    table = Table(title="📦 GitPutra Info", show_lines=True)

    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Details", style="yellow")

    table.add_row("🤖 Description", "[bold magenta]Chat with your codebase using Gemini or OpenAI[/bold magenta]")
    table.add_row("🏷️ Version", "[bold magenta]0.2.5[/bold magenta]")
    table.add_row("👨‍💻 Author", "[bold bright_blue]Adityava Gangopadhyay[/bold bright_blue]")
    table.add_row("💼 Email", "[bold bright_blue]adityava49cse@gmail.com[/bold bright_blue]")
    table.add_row("🔗 LinkedIn", "[bold #FFA500]https://www.linkedin.com/in/adityava-gangopadhyay/[/bold #FFA500]")
    table.add_row("📦 Project URL", "[bold #FFA500]https://pypi.org/project/gitputra/[/bold #FFA500]")

    console.print(table)
    
    console.print("   💬 Special Message-> Feel free to contact for any suggestion or issues\n", style="bold blue")
    
    console.print("📦 Commands:", style="bold yellow")
    commands = [
        ("analyze <url>",         "Clone & analyze a remote GitHub repo"),
        ("analyze <path> --local","Analyze a local codebase (no cloning)"),
        ("chat <url>",            "RAG chat about a remote GitHub repo"),
        ("chat <path> --local",   "RAG chat about a local codebase"),
        ("export-context",        "Export portable context .md (AI off by default)"),
        ("export-context <path>", "Export context .md from local dir (AI off by default)"),
        ("export-context <url> --remote", "Export context .md from remote GitHub repo"),
        ("clear-db",              "Wipe the local ChromaDB index"),
        ("info",                  "Show this info screen"),

    ]
    table = Table(title="📦 Commands")

    table.add_column("Command", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")

    for cmd, desc in commands:
        table.add_row(f"gitputra {cmd}", desc)

    console.print(table)

    console.print("\n🤖 Supported AI Providers:", style="bold yellow")
    ais = [
        ("gemini", "Google Gemini 2.5 Flash",    "gemini-embedding-001"),
        ("openai", "OpenAI GPT-4o Mini",          "text-embedding-3-large"),
    ]
    ai_table = Table(title="🤖 Supported AI Providers")

    ai_table.add_column("Flag", style="cyan")
    ai_table.add_column("Model", style="green")
    ai_table.add_column("Embedding", style="magenta")

    for flag, model, embed in ais:
        ai_table.add_row(flag, model, embed)

    console.print(ai_table)

    table = Table(title="🌍 PDF Output Languages (~110 supported)", show_lines=True)

    table.add_column("Script", style="bold cyan", no_wrap=True)
    table.add_column("Languages", style="white")

    latin = [
        "English", "French", "Spanish", "Portuguese", "Italian", "German",
        "Dutch", "Swedish", "Norwegian", "Danish", "Finnish", "Polish",
        "Czech", "Slovak", "Hungarian", "Romanian", "Croatian", "Serbian (Latin)",
        "Slovenian", "Albanian", "Lithuanian", "Latvian", "Estonian",
        "Turkish", "Azerbaijani", "Uzbek", "Kazakh (Latin)", "Turkmen",
        "Indonesian", "Malay", "Filipino", "Swahili", "Zulu", "Xhosa",
        "Afrikaans", "Yoruba", "Igbo", "Hausa", "Somali", "Kinyarwanda",
        "Welsh", "Irish", "Basque", "Catalan", "Galician", "Maltese",
        "Icelandic", "Faroese", "Vietnamese", "Hawaiian", "Maori",
        "Tok Pisin", "Tswana", "Shona", "Sesotho",
    ]

    bengali = ["Bengali", "Assamese"]

    devanagari = ["Hindi", "Marathi", "Nepali", "Sanskrit", "Maithili", "Konkani", "Bodo", "Dogri"]

    # Join nicely instead of manual spacing gymnastics
    table.add_row("Latin script", ", ".join(latin))
    table.add_row("Bengali script", " | ".join(bengali))
    table.add_row("Devanagari script", " | ".join(devanagari))

    console.print(table)

    console.print("\n(AI response language depends on the chosen model's capability)", style="dim")

    ext_table = Table(title=f"📁 Supported File Extensions ({len(core.SUPPORTED_EXT)} types)")
    ext_table.add_column("Extensions", style="cyan", overflow="fold")
    exts = sorted(core.SUPPORTED_EXT) 
    chunk_size = 10
    for i in range(0, len(exts), chunk_size):
        ext_table.add_row(", ".join(exts[i:i+chunk_size]))

    console.print(ext_table)

    click.echo()