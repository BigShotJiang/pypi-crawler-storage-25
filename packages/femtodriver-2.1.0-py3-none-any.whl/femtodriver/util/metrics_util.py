import ast


def dictify_string_metrics(s):
    """Parse the pretty-printed, human-readable metrics string
    (tab-indented key: value) into a nested dict."""

    def parse_value(v):
        v = v.strip()
        if v.startswith("("):
            try:
                return list(ast.literal_eval(v))
            except Exception:
                pass
        try:
            return int(v)
        except ValueError:
            pass
        try:
            return float(v)
        except ValueError:
            pass
        return v

    result = {}
    stack = [(-1, result)]

    for line in s.split("\n"):
        if not line.strip() or ":" not in line:
            continue

        indent = len(line) - len(line.lstrip("\t"))
        stripped = line.strip()

        before, _, after = stripped.rpartition(":")
        key = before.strip()
        value = after.strip()

        while stack[-1][0] >= indent:
            stack.pop()

        parent = stack[-1][1]

        if not value:
            new_dict = {}
            parent[key] = new_dict
            stack.append((indent, new_dict))
        else:
            parent[key] = parse_value(value)

    return result
