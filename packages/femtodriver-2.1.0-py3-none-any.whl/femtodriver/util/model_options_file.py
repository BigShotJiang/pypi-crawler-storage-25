import logging
import os
import yaml

logger = logging.getLogger(__name__)


def get_options_path(model_source_dir, model_options_file):
    if model_options_file is not None:
        model_options_file = os.path.expanduser(model_options_file)
        if not os.path.exists(model_options_file):
            raise ValueError(
                f"supplied model options file {model_options_file} does not exist"
            )
        return model_options_file
    else:
        if model_source_dir is None:
            return None
        else:
            return os.path.join(model_source_dir, "options.yaml")


def load_model_options(model, options_path):
    """Look up compiler_kwargs and opt_profile for a model from an options YAML file."""

    if options_path is not None:
        with open(options_path, "r") as file:
            model_desc = yaml.safe_load(file)

        if "DEFAULT" in model_desc:
            logger.info("found DEFAULT compiler options")
            compiler_kwargs = model_desc["DEFAULT"].get("compiler_kwargs", {})
            opt_profile = model_desc["DEFAULT"].get("opt_profile", None)
        else:
            compiler_kwargs = {}
            opt_profile = None

        if model in model_desc:
            if "compiler_kwargs" in model_desc[model]:
                compiler_kwargs.update(model_desc[model]["compiler_kwargs"])
            if "opt_profile" in model_desc[model]:
                opt_profile = model_desc[model]["opt_profile"]
            if "opt-profile" in model_desc[model]:
                opt_profile = model_desc[model]["opt-profile"]
    else:
        model_desc = {}
        compiler_kwargs = {}
        opt_profile = None

    logger.info("loaded the following compiler options")
    if options_path and "DEFAULT" in model_desc:
        logger.info("(based on DEFAULT from options file)")
    for k, v in compiler_kwargs.items():
        logger.info(f"  {k} : {v}")
    if opt_profile is not None:
        logger.info(f"  opt_profile : {opt_profile}")

    return {"compiler_kwargs": compiler_kwargs, "opt_profile": opt_profile}
