#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

import math
from femtodriver.typing_help import ARRAYU64, ARRAYU32, ARRAYINT
from typing import Tuple, Literal, Union
import numpy as np
import time
import sys


def set_bits(x: int, y: int, lo: int, hi: int | None = None) -> int:
    """x[hi:lo] = y; return x"""
    if hi is None:
        hi = lo

    x = np.uint64(x)
    y = np.uint64(y)
    lo = np.uint64(lo)
    hi = np.uint64(hi)

    if y >= 2 ** (hi + 1 - lo):
        raise ValueError("tried to set_bits with y bigger than bitrange")

    hi_lo_mask = ((1 << (hi + 1)) - 1) - ((1 << lo) - 1)
    x_masked = x & (~hi_lo_mask)
    return x_masked | (y << lo)


def get_bits(x: int, lo: int, hi: int | None = None) -> int:
    """return x[hi:lo]"""
    if hi is None:
        hi = lo

    x = np.uint64(x)
    lo = np.uint64(lo)
    hi = np.uint64(hi)

    hi_lo_mask = ((1 << (hi + 1)) - 1) - ((1 << lo) - 1)
    return (x & hi_lo_mask) >> lo


def pack_word(
    field_spec: dict[str, int | tuple[int, int]], **field_vals: dict[str, tuple[int]]
) -> int:
    """pack up a word using set_bits for each field

    Arguments:
        packing spec
            {fieldname : (lo, hi) | lo}
        values
            {fieldname : val}

    returns packed int
    """
    x = 0
    for fieldname in field_vals:
        assert fieldname in field_spec
        lo_hi = field_spec[fieldname]
        if isinstance(lo_hi, int):
            lo_hi = (lo_hi,)
        x = set_bits(x, field_vals[fieldname], *lo_hi)
    return x


def unpack_word(field_spec: dict[str, int | tuple[int, int]], x) -> dict[str, int]:
    """unpack up a word using get_bits for each field

    Arguments:
        packing spec
            {fieldname : (lo, hi)}

    returns keyed values {fieldname : val}
    """
    vals = {}
    for fieldname, lo_hi in field_spec.items():
        if isinstance(lo_hi, int):
            lo_hi = (lo_hi,)
        vals[fieldname] = get_bits(x, *lo_hi)
    return vals


def maxval_signed(B):
    return (1 << (B - 1)) - 1


def minval_signed(B):
    return -(1 << (B - 1))


def maxval_unsigned(B):
    return (1 << B) - 1


def minval_unsigned(B):
    return 0


def minval(signedness, B):
    if signedness == "s":
        return minval_signed(B)
    elif signedness == "u":
        return minval_unsigned(B)
    else:
        assert False


def maxval(signedness, B):
    if signedness == "s":
        return maxval_signed(B)
    elif signedness == "u":
        return maxval_unsigned(B)
    else:
        assert False


def in_range_signed(x, B):
    """Checks that all values in x are representable with B-bits, signed"""
    return np.max(x) <= maxval_signed(B) and np.min(x) >= minval_signed(B)


def in_range_unsigned(x, B):
    """Checks that all values in x are representable with B-bits, unsigned"""
    return np.max(x) <= maxval_unsigned(B) and np.min(x) >= 0


def assert_in_range_signed(x, B):
    """Checks that all values in x are representable with B-bits, signed"""
    if not in_range_signed(x, B):
        raise ValueError("trying to set signed {}'b{}".format(B, x))


def assert_in_range_unsigned(x, B):
    """Checks that all values in x are representable with B-bits, unsigned"""
    if not in_range_unsigned(x, B):
        raise ValueError("trying to set unsigned {}'b{}".format(B, x))


def unsigned_to_signed(x_unsigned, B):
    assert_in_range_unsigned(x_unsigned, B)
    max_pos = maxval_signed(B)
    if isinstance(x_unsigned, np.ndarray):
        x_signed = x_unsigned.copy()
        x_signed[x_unsigned > max_pos] -= 2**B
        return x_signed.astype(np.int64)
    else:
        if x_unsigned > max_pos:
            return np.int64(x_unsigned) - 2**B
        else:
            return np.int64(x_unsigned)


def signed_to_unsigned(x_signed, B):
    """Convert signed int value to bit-equivalent unsigned value

    e.g. in 8-bits
        signed -> unsigned
           127 -> 127
              ...
             1 -> 1
             0 -> 0
            -1 -> 255
              ...
          -128 -> 128
    """
    x_signed = np.int64(x_signed)
    assert_in_range_signed(x_signed, B)
    if isinstance(x_signed, np.ndarray):
        x_unsigned = x_signed.copy()
        x_unsigned[x_unsigned < 0] += 2**B
        return x_unsigned
    else:
        if x_signed < 0:
            return x_signed + 2**B
        else:
            return x_signed


def prec_elts_per_word(precision: str) -> int:
    assert 64 % prec_bits(precision) == 0
    return int(64 / prec_bits(precision))


def prec_bits(precision: str) -> int:
    return precision


def words_to_els(words: int, precision: str) -> int:
    return words * prec_elts_per_word(precision)


def els_to_words(els: int, precision: str, assert_even: bool = False) -> int:
    n_per_word = prec_elts_per_word(precision)
    if assert_even:
        assert els % n_per_word == 0
    return int(math.ceil(els / n_per_word))


def pack_V(precision: Union[int, str], el_vals: ARRAYINT) -> ARRAYU64:
    """convert signed data element array (e.g. one 16b signed per entry) to packed uint64"""
    B = precision
    num_words = int(np.ceil(len(el_vals) * B / 64))
    elts_per_word = 64 // B

    # skip packing if data is already packed
    if (
        B == 8 and el_vals.dtype == np.int8 or B == 16 and el_vals.dtype == np.int16
    ) and sys.byteorder == "little":
        packed = el_vals.view(np.uint64)
        return packed

    packed = np.full((num_words,), 0, dtype=np.uint64)
    for i in range(num_words):
        for j in range(elts_per_word):
            signed_el = el_vals[i * elts_per_word + j]
            unsigned_el = signed_to_unsigned(signed_el, B)
            packed[i] |= np.uint64(unsigned_el << (B * j))

    return packed


def unpack_V(precision: int, packed_vals: ARRAYU64) -> ARRAYINT:
    """convert packed uint64 to signed data element array (e.g. one 16b signed per entry)"""

    B = precision
    num_words = len(packed_vals)
    elts_per_word = 64 // B
    num_elts = elts_per_word * num_words

    # if endianness is OK, no need to unpack, just return narrower dtype
    if sys.byteorder == "little":
        if B == 8:
            return packed_vals.view(np.int8)
        elif B == 16:
            return packed_vals.view(np.int16)
        else:
            assert False

    unpacked = np.full((num_elts,), 0, dtype=np.int64)
    for i in range(num_words):
        for j in range(elts_per_word):
            mask = np.uint64(((1 << B) - 1) << (B * j))
            unsigned_el = (mask & np.uint64(packed_vals[i])) >> np.uint64(B * j)
            unpacked[i * elts_per_word + j] = unsigned_to_signed(
                np.uint16(unsigned_el), B
            )

    return unpacked


def pack_addr_64_to_32(base_addr: int, end_addr: int, length: int) -> ARRAYU32:
    return base_addr, end_addr, length * 2


def pack_data_64_to_32(vals: ARRAYU32) -> ARRAYU32:
    datas_msbs = vals >> 32
    datas_lsbs = vals & (2**32 - 1)

    datas_combined = np.zeros((len(vals) * 2,), dtype=np.uint32)

    datas_combined[0::2] = datas_lsbs
    datas_combined[1::2] = datas_msbs

    return datas_combined


def pack_64_to_32(
    base_addr: int, end_addr: int, length: int, vals: ARRAYU64
) -> Tuple[ARRAYU32, ARRAYU32]:
    """pack 64b addresses/vals into 32b"""
    return (pack_addr_64_to_32(base_addr, end_addr, length), pack_data_64_to_32(vals))


def unpack_32_to_64(vals: ARRAYU32) -> ARRAYU64:
    lsbs = vals[0::2]
    msbs = vals[1::2]
    assert len(lsbs) == len(msbs)

    combined = msbs.astype(np.uint64)
    combined = combined << 32
    combined += lsbs

    return combined
