#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

"""RedisPlugin : IOPlugin, helps SPURunner talk to any redis client

Just handles the packing/unpacking of message data into redis API calls

The client could be anything--initial target is RTL simulator DPI-C
"""

import atexit
import numpy as np
import signal
import subprocess
import time
import os
import sys

from femtodriver.plugins.io_plugin import *

from femtodriver.typing_help import *
from typing import *

import redis

import logging

logger = logging.getLogger(__name__)

# Module-level bookkeeping of PIDs we spawned (redis-server, fake_redis_client).
# We deliberately store *just PIDs*, not Popen objects — holding Popen refs
# would keep each subprocess's /dev/null stdio FDs alive until interpreter
# shutdown, reintroducing the very leak the earlier atexit-on-teardown fix
# was removing. PIDs are cheap and Popen objects are free to GC per-test.
# At process exit, we SIGTERM any of those PIDs that are still alive and
# still look like something we started (guards against PID reuse).
_spawned_subprocess_pids: set[int] = set()


def _looks_like_our_subproc(pid: int) -> bool:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().replace(b"\x00", b" ")
    except OSError:
        return False
    return b"redis-server" in cmdline or b"fake_redis_client" in cmdline


def _cleanup_spawned_subprocesses() -> None:
    # SIGTERM is what the old atexit-registered teardown effectively did via
    # wait_for_process; redis-server handles it cleanly (shuts down, releases
    # its port) and the fake_redis_client script exits on connection loss.
    for pid in list(_spawned_subprocess_pids):
        if not _looks_like_our_subproc(pid):
            continue
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass


atexit.register(_cleanup_spawned_subprocesses)


io_targets = ["apb", "axis", "spu_top", "host"]
CODE_TO_MSG = {i: k for i, k in enumerate(io_targets)}
MSG_TO_CODE = {k: i for i, k in enumerate(io_targets)}

RECV_TIMEOUT = 600  # 10 minutes for reply timeout

# originally were trying to put everything into one addr space
# but now we pack the message type into the message
# easier to sort things that way than by looking at addr

# lower half of address space used for SPU APB
# upper half is system regs
SYS_ADDR0 = 2**31
NUM_SPI_REG = 16 * 1024  # don't need this many, but reserved
NUM_HOST_REG = 16 * 1024  # don't need this many, but reserved

ADDR_SPACE_SIZES = {
    "apb": 2**31,
    "axis": 4,
    "spi": NUM_SPI_REG * 4,
    "host": NUM_HOST_REG * 4,
}
cum_sizes = np.cumsum([v for v in ADDR_SPACE_SIZES.values()])
ADDR_SPACE = {k: v for k, v in zip(ADDR_SPACE_SIZES.keys(), cum_sizes)}

# def redis_addr_map(msgtype, offset):
#    foo = ADDR_SPACE[msgtype]
#    return ADDR_SPACE[msgtype] + offset


def redis_addr_map(msgtype, offset):
    return offset


def as_32b_hex(val):
    return "0x{:08x}".format(val)


# address map
HOST_REGS = {"WAIT": 0, "HARD_RESET": 1}


class RedisPlugin(IOPlugin):
    def __init__(
        self,
        fake_connection=False,
        no_server_start=False,
        fake_hw_recv_vals: ARRAYINT = None,
        logfiledir: str = "io_records",
        no_client_shutdown: bool = True,
        **kwargs,
    ):
        """RedisPlugin is used by HWRunner to send data to and from another redis client
        that "implements" wraps the SPU (or a simulation of the SPU)

        provides, (partially via parent class IOPlugin)
            setup()
            teardown()
            hw_send()
            hw_recv()
            recording-related functions, e.g. start_apb_recording()

        Args:
            fake_connection : bool (default False) :
                instantiate fake redis client to subscribe to traffic
            fake_hw_recv_vals : ARRAYINT (default None)
                values to return from hw_recv with a fake client
                used for board-less unit tests
            log_to_file=True

        we'll use redis with the following queues:

        (32b data for all elements)

        req : (read)
            [0, (=read)
             target_type_code,
             base_addr,
             final_addr,
             len]

        req : (write)
            [1, (=write)
             target_type_code,
             base_addr,
             final_addr,
             len,
             data, data, data, ...]

        reply (filled by receiver) :
            [data, data, data, ...]

        """
        if not no_server_start:
            self.start_redis_server()
        else:
            self.redis_server_proc = None

        # used when we don't want the QFR server to die after one SPURunner lifetime
        # amortizes QFR init time
        self.no_client_shutdown = no_client_shutdown

        if fake_connection:
            self.start_fake_client(fake_hw_recv_vals)
        else:
            self.fake_client_proc = None

        self.setup()
        super().__init__(logfiledir=logfiledir)
        self.init_complete = True

    @staticmethod
    def _get_user_port():
        uid = os.getuid()
        # 6379 is redis default, assign each user a port above that
        # this has to match the formula that the redis_client has
        # e.g. femtocad/femtorunners/questa/redis_client.c:_GetUserPort()
        return uid % 20 + 6379

    def start_redis_server(self, port=None):
        portid = self._get_user_port()

        # If a redis-server is already responsive on this port, reuse it
        # instead of spawning another one. This handles all the cases where
        # someone else already owns the port:
        #   - a long-lived server started by the caller (e.g.
        #     build_FD_QFR.sh, run_coverage.sh, run_redis_test.sh)
        #   - a systemd-managed redis whose port happens to match
        #   - a leftover server from a previous (aborted) run
        #   - a dev-machine manual redis the user started
        # In every one of those cases the unconditional Popen would fail
        # to bind and its child would exit immediately, leaving a POSIX
        # zombie until GC/Popen.__del__ reaps it. Detecting the existing
        # server up-front is cleaner and avoids the wasted fork+exec.
        try:
            probe = redis.Redis(port=portid, socket_connect_timeout=0.5)
            probe.ping()
            probe.close()
            try:
                probe.connection_pool.disconnect()
            except Exception:
                pass
            self.redis_server_proc = None
            logger.info(
                f"reusing existing redis-server on port {portid} "
                f"(probed, ping succeeded)"
            )
            return
        except (redis.ConnectionError, redis.TimeoutError):
            # nothing responsive on the port -- fall through and start one
            pass

        # Detach stdio from the parent's pipes so an orphaned redis-server
        # can't hold them open past parent exit (which would block any
        # consumer like `tee` on our stdout pipeline).
        self.redis_server_proc = subprocess.Popen(
            ["redis-server", "--port", f"{portid}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _spawned_subprocess_pids.add(self.redis_server_proc.pid)
        logger.info(
            f"started redis server on port {portid}, pid = {self.redis_server_proc}"
        )

    def start_fake_client(self, fake_hw_recv_vals):
        # opens up a subprocess to run the client in
        this_dir_path = os.path.dirname(os.path.realpath(__file__))
        fake_client_script = os.path.join(this_dir_path, "fake_redis_client.py")

        if fake_hw_recv_vals is not None:
            # save the fake vals
            valfile_fname = "fake_valfile.txt"
            np.savetxt(valfile_fname, fake_hw_recv_vals)
            args = [sys.executable, fake_client_script, "--valfile", valfile_fname]
        else:
            args = [sys.executable, fake_client_script]

        # Detach stdio from the parent's pipes for the same reason as the
        # redis-server Popen: if the fake client outlives the parent, it
        # would otherwise hold the parent's stdout pipe open and stall any
        # downstream consumer (e.g. `tee`).
        self.fake_client_proc = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        _spawned_subprocess_pids.add(self.fake_client_proc.pid)
        logger.info(f"fake client started with PID {self.fake_client_proc.pid}!")
        # can be killed by setting key 'client_shutdown'

    def wait_for_redis(self):
        """waits for redis server to come online"""
        while True:
            try:
                self.r.ping()
                break
            except redis.ConnectionError:
                time.sleep(1)
                logger.info("waiting for redis-server to come online")

    def _init_redis(self):
        portid = self._get_user_port()
        self.r = redis.Redis(port=portid)
        self.wait_for_redis()
        self.r.flushdb()
        self.r.set("client_shutdown", 0)
        self.r.set("client_freerunning", 0)
        self.r.delete("req")
        self.r.delete("reply")
        self.set_encrypted(False)

    def set_encrypted(self, encrypted):
        # workaround: encrypted disables fast memory programming
        self.r.set("client_encrypted", int(encrypted))
        self.r.set("client_fast_mem_programming", int(not encrypted))
        # self.r.set("client_fast_mem_programming", 0)

    # def __del__(self):
    #    self.teardown(clean=False)

    def reset(self, num_hold_cycles=20):
        """hard reset of SPU, commands host to pulse the reset pad"""

        # set reset to 1
        self.hw_send(
            "host",
            HOST_REGS["HARD_RESET"],
            HOST_REGS["HARD_RESET"] + 1,
            1,
            np.array([1], dtype=np.uint32),
            comment="reset high",
        )

        # hold reset for 20 cycles
        self.wait(num_hold_cycles)

        # set reset to 0
        self.hw_send(
            "host",
            HOST_REGS["HARD_RESET"],
            HOST_REGS["HARD_RESET"] + 1,
            1,
            np.array([0], dtype=np.uint32),
            comment="reset low",
        )

    def setup(self):
        """called whenever connection to hardware is established
        In this case, connects to the redis server
        """
        self._init_redis()

    def teardown(self, clean=True):
        """called whenever connection to hardware broken
        In this case, disconnects from the redis server

        Idempotent: safe to call more than once. Releases the redis
        TCP socket and drops Popen references so pipe FDs can be reaped.
        """
        if getattr(self, "_torn_down", False):
            return
        self._torn_down = True

        try:
            if self.init_complete:
                logger.info("told client to exit")
                self.wait_for_process(self.fake_client_proc)
                self.wait_for_process(self.redis_server_proc)
        except AttributeError:
            logger.warning(f"init was not complete yet during teardown")
        except redis.ConnectionError:
            logger.warning(f"redis server already down during teardown")

        r = getattr(self, "r", None)
        if r is not None:
            try:
                r.close()
            except Exception as e:
                logger.warning(f"r.close() raised: {e}")
            try:
                r.connection_pool.disconnect()
            except Exception as e:
                logger.warning(f"connection_pool.disconnect() raised: {e}")
            self.r = None

        self.fake_client_proc = None
        self.redis_server_proc = None

        logger.info("told redis server to exit")

    def wait_for_process(self, proc, timeout_secs=3):
        if proc is None:
            return

        # Actively signal shutdown — the previous code only *waited* and
        # fell through to kill on timeout, which left the redis TCP port
        # in TIME_WAIT long enough that the next testcase's server hit
        # "Address already in use" on the same port.
        try:
            proc.terminate()
        except Exception as e:
            logger.debug(f"proc.terminate() raised: {e}")

        try:
            logger.debug(f"waiting {timeout_secs} secs for process {proc.pid} to exit")
            proc.wait(timeout=timeout_secs)
        except subprocess.TimeoutExpired:
            logger.debug(f"timeout expired, killing process {proc.pid}")
            proc.kill()
            try:
                proc.wait(timeout=timeout_secs)
            except subprocess.TimeoutExpired:
                logger.warning(f"process {proc.pid} ignored SIGKILL")

    def wait(self, sim_cycles):
        """tell the simulator to cycle"""
        self.hw_send(
            "host",
            HOST_REGS["WAIT"],
            HOST_REGS["WAIT"] + 1,
            1,
            np.array([sim_cycles], dtype=np.uint32),
            comment=f"cycle reference clock for {sim_cycles} cycles",
        )

    def _push_redis(self, queue_name, vals):
        """low-level redis queue push"""
        assert queue_name in ["req"]
        for val in vals:
            self.r.rpush(queue_name, int(val))

    def _pop_redis(self, queue_name, num_to_pop):
        assert queue_name in ["reply"]
        """low-level redis queue pop"""
        popped = []
        logger.debug("waiting for reply")
        while len(popped) < num_to_pop:
            pop_out = self.r.blpop(queue_name, timeout=RECV_TIMEOUT)
            if pop_out:
                _, val_bytes = pop_out
                val = int(val_bytes)
                popped.append(val)
            else:
                # if timed out, die
                raise RuntimeError(
                    f"timed out waiting for a reply from HW. Timeout was {RECV_TIMEOUT}s."
                )

        return np.array(popped, dtype=np.uint32)

    def _hw_send(
        self,
        msgtype: IOTARGET,
        start_addr: int,
        end_addr: int,
        length: int,
        vals: ARRAYU32,
        flush: bool = True,
    ):
        """send burst transactions to the hardware"""

        if not flush:
            raise NotImplementedError()

        if not isinstance(vals, np.ndarray):
            vals = np.atleast_1d(vals)

        req_data = [
            1,
            MSG_TO_CODE[msgtype],
            redis_addr_map(msgtype, start_addr),
            redis_addr_map(msgtype, end_addr),
            length,
        ] + list(vals)

        self._push_redis("req", req_data)
        logger.debug(f"pushed to redis, req queue len is now {self.r.llen('req')}")

    def _hw_recv(
        self, msgtype: IOTARGET, start_addr: int, end_addr: int, length: int
    ) -> list[ARRAYU32]:
        """recv burst transactions from the hardware"""

        req_data = [
            0,
            MSG_TO_CODE[msgtype],
            redis_addr_map(msgtype, start_addr),
            redis_addr_map(msgtype, end_addr),
            length,
        ]
        logger.debug(f"sending request of len {length}")
        self._push_redis("req", req_data)
        return [self._pop_redis("reply", length)]  # XXX FIXME multiple RTR messages?

    # @classmethod
    # def set_client_shutdown(cls):
    #    assert False # shouldn't be using this
    #    portid = cls._get_user_port()
    #    r = redis.Redis(port=portid)
    #    r.set("client_shutdown", 1)

    @classmethod
    def unset_client_shutdown(cls):
        portid = cls._get_user_port()
        r = redis.Redis(port=portid)
        r.set("client_shutdown", 0)
