"""001/150/etc HAL"""
import logging
import numpy as np
from typing import Literal, Optional


from abc import ABC, abstractmethod
from femtodriver.typing_help import IOTARGET
from femtodriver.cfg import spucfg

logger = logging.getLogger(__name__)

F_VCO = 150e6


class SPUHAL(ABC):
    def __init__(self, spu: Optional["SPURunner"]):
        """hardware abstraction layer for SPU
        makes 001, 150, etc "look the same"
        if spu is not supplied, will not implement communication functions,
        but can still be used to get config/address map info
        """
        self._spu = spu

        # alias some functions
        # avoid using self._spu
        # document API usage here
        if self._spu is not None:
            self.platform = spu.platform
            self.hw_send = self._spu.hw_send
            self.hw_recv = self._spu.hw_recv
            self.wait = self._spu.wait
        else:
            self.platform = None

            def NotImplFn(*args, **kwargs):
                raise NotImplementedError(
                    "tried use HAL instantiated w/o SPURunner to talk to HW"
                )

            self.hw_send = NotImplFn
            self.hw_recv = NotImplFn
            self.wait = NotImplFn

    ##############################################
    # abstractmethods
    # HAL derivatives must implement these to be complete

    # ---------------------------------------------
    # two key properties: cfg and am
    # each HAL must define:
    #  cfg : core config (HW parameters that SPURunner needs)
    #  am  : address map

    @property
    def cfg(self):
        """get SPU core config"""
        return spucfg

    @property
    @abstractmethod
    def am(self):
        """get SPU address map"""
        pass

    # ---------------------------------------------
    # other methods, general abstract controls used by SPURunner

    @abstractmethod
    def get_refclk_hz(self, platform):
        """get reference clock for this HW, platform"""
        pass

    @abstractmethod
    def program_pll(self, multiplier: int, nr: int = 1, nd: int = 1) -> None:
        """program PLL with a multiplier, but leave it bypassed or gated"""
        pass

    @abstractmethod
    def ungate_pll(self) -> None:
        """after programming PLL, ungate/unbypass the clock"""
        pass

    @abstractmethod
    def check_pll_lock(self) -> bool:
        """check PLL lock once"""
        pass

    @abstractmethod
    def set_spu_core_clocks(self, cores: int | list[int], clock_on: bool) -> None:
        """control clock gating for each core's clocks"""
        pass

    @abstractmethod
    def set_spu_core_resets(self, cores: int | list[int], reset: bool) -> None:
        """control resets for each core"""
        pass

    @abstractmethod
    def set_core_power(self, cores: int | list[int], pwr_on: bool) -> None:
        """turn core power gates on or off
        may modify clock gating
        """
        pass

    @abstractmethod
    def set_spu_master_clocks(self, clock_on: bool) -> None:
        """parent clock gate for entire SPU domain, if present"""
        pass

    @abstractmethod
    def set_spu_master_resets(self, reset: bool) -> None:
        """master reset for SPU"""
        pass

    @abstractmethod
    def set_spu_master_clocks(self, clock_on: bool) -> None:
        """parent clock gate for entire SPU domain, if present"""
        pass

    @abstractmethod
    def reset_sequence_spu_cores(self) -> None:
        """reset sequence for SPU logic"""
        pass

    @abstractmethod
    def check_interrupt_reg(self) -> None:
        """check if output is ready"""
        pass

    @abstractmethod
    def enter_debug_mode(self, debugger) -> None:
        """enter debug mode. Femto use only"""
        pass

    ########################################
    # common interfaces, for now

    # address mapping,
    # memory power controls, etc
    # no difference between 001 and 150 for now
    # put here because that could change

    def get_ioplugin_msgtype(self, obj: str) -> IOTARGET:
        """translate obj names to keys used by IOPlugin"""
        if obj == "RTR":
            msgtype = "axis"
        elif obj in self.am.SPI_REGS_TO_IDXS:  # SPU system-wide (SPI) registers
            msgtype = "spu_top"
        elif obj == "HOST":
            msgtype = "host"
        elif obj in self.am.ALL_AXI:
            msgtype = "apb"
        else:
            raise ValueError(f"unknown message type {obj}")

        return msgtype

    def addr_range(self, obj: str, offset: int, length: int) -> (int, int):
        """compute address range for burst, relative to object
        assume 32b data stream, like IOPlugin
        returns (start, end)
        """
        if obj in self.am.SPI_REGS_TO_IDXS:
            base = self.am.SPI_REGS_TO_IDXS[obj]

            return (
                base + offset,
                base + offset + length * self.am.IDX_TO_SPI_REGS_STEP,
            )

        elif obj in self.am.ALL_AXI:
            # everything else, 32b data, byte addressing
            base = self.am.ALL_AXI[obj]
            return (base + offset, base + offset + length * 4)

        elif obj == "RTR":
            # special case: filled in by the host, just return 0
            return (0, 0)

        else:
            raise ValueError(f"did not find address for {obj}")

    def poll_until_pll_lock(self):
        """poll until PLL is locked"""
        self.wait(4000, 0.05)
        while self.check_pll_lock() == 0:
            logger.info("polling for PLL lock")
            self.wait(4000, 0.05)
        logger.info("PLL locked")

    # useful mem power state values:
    # (default timing adjust pin values)
    #
    # allowed transitions
    # off <-> CD
    # on <->
    # sleep_trans <-> CD
    # sleep_trans <-> sleep
    #
    # e.g.:
    # power on:
    #   off -> CD -> on
    # power off:
    #   on  -> CD -> off
    # powered -> retention:
    #   on  -> CD -> sleep_trans -> sleep
    # retention -> powered:
    #   sleep -> sleep_trans -> CD -> on

    MEM_TO_OFF = 0x01098
    MEM_TO_CD = 0x05098
    MEM_TO_SLEEP = 0x09098
    MEM_TO_SLEEP_TRANS = 0x0D098
    MEM_TO_ON = 0x11098
    MEM_TO_FSM = 0x15098  # not used in SPU150

    def power_up_mem(self, core: int, mem: str):
        """assumes that the memories are currently off"""
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_CD], comment=f"core {core} mem {mem} to CD"
        )
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_ON], comment=f"core {core} mem {mem} to ON"
        )

    def power_dn_mem(self, core: int, mem: str):
        """assumes that the memories are currently on"""
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_CD], comment=f"core {core} mem {mem} to CD"
        )
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_OFF], comment=f"core {core} mem {mem} to OFF"
        )

    def sleep_mem(self, core: int, mem: str):
        """assumes that the memories are currently on"""
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_CD], comment=f"core {core} mem {mem} to CD"
        )
        self.hw_send(
            (core, mem, 0),
            [self.MEM_TO_SLEEP_TRANS],
            comment=f"core {core} mem {mem} to SLEEP_TRANS",
        )
        self.hw_send(
            (core, mem, 0),
            [self.MEM_TO_SLEEP],
            comment=f"core {core} mem {mem} to SLEEP",
        )

    def wake_mem(self, core: int, mem: str):
        """assumes that the memories are currently asleep"""
        self.hw_send(
            (core, mem, 0),
            [self.MEM_TO_SLEEP_TRANS],
            comment=f"core {core} mem {mem} to SLEEP_TRANS",
        )
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_CD], comment=f"core {core} mem {mem} to CD"
        )
        self.hw_send(
            (core, mem, 0), [self.MEM_TO_ON], comment=f"core {core} mem {mem} to ON"
        )

    @abstractmethod
    def check_version_reg(self):
        pass

    def write_encryption_regs(self, key_idx, salt):
        # set encryption key index
        assert key_idx < 32
        self.hw_send("SPI_ENCRYPTION_KEY_IDX", [key_idx])

        # set salt, split across 4 registers
        assert 0 <= salt < 2**64
        for i in range(4):
            salt_part = (salt >> 16 * i) & 0xFFFF
            self.hw_send(f"SPI_ENCRYPTION_SALT_{i}", [salt_part])

    def set_AXIS_mode(self, SPI_or_stream: Literal["SPI", "stream"]) -> None:
        """allow SPU to receive AXIS traffic from SPI or real-time stream"""
        pass

    def check_version_reg(self) -> bool:
        """check that version reg has correct value"""
        return True

    def init(self, program_pll=True) -> bool:
        """perform init sequence for this hardware
        should generally make the chip ready for programming
        doesn't need to turn on/off specific cores though
        doesn't handle encryption settings, fake connections, etc
        """

        if program_pll:
            pll_mult = int(np.ceil(F_VCO / self.get_refclk_hz()))
            self.program_pll(pll_mult)
            self.poll_until_pll_lock()

            # open up the master gate, core gates already open
            self.ungate_pll()

        self.reset_sequence_spu_cores()
        self.set_spu_master_clocks(True)
        self.set_AXIS_mode("SPI")
