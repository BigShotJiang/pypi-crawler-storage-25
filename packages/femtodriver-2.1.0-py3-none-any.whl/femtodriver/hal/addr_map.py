from dataclasses import dataclass

from . import otp_150


@dataclass
class SPUAddrMap_001_MP:
    #############################################
    # 16b SPI reg space
    # still programmable with 32b words
    # really byte addresses, but called "IDX" here to align across 001/150
    IDX_TO_SPI_REGS = {
        0x00: "SPI_CONF",  # basic conf settings (core clock gating)
        0x04: "PAD_CONF",  # pad IO settings, including osc pad
        0x08: "PLL_CONF",  # PLL control bits
        0x0C: "PLL_BWADJ",  # bandwidth adjust, half of CLKF
        0x10: "PLL_CLKOD",  # output divider
        0x14: "PLL_CLKF",  # frequency multiplier
        0x18: "PLL_CLKR",  # pre-VCO divider
        0x1C: "PLL_LOCK",  # pll lock check (read only)
        0x20: "SPI_STATUS_UNUSED",  # SPI status reg, doesn't do anything useful
        0x24: "OUTPUT_INT",  # internal version of spi_int
    }
    # distance between adjacent regs in "IDX" space
    # used by hal.addr_range()
    IDX_TO_SPI_REGS_STEP = 4
    SPI_REGS_TO_IDXS = {v: k for k, v in IDX_TO_SPI_REGS.items()}

    ##############################################
    # 32b control register space

    AXI_TO_SPU = {
        0x0000_0000: "VERSION",  # HW version, 8b, {4b: major , 4b: minor}
        0x0000_0004: "RST",  # core reset
        0x0000_0008: "DM_TIMERS",  # automatic sleep FSM regs
        0x0000_000C: "TM_TIMERS",
        0x0000_0010: "IM_TIMERS",
        0x0000_0014: "REG_DP_ACK_DELAY",  # how many fudge cycles to pad on the end of the datapaths' ack
        0x0000_0018: "SPI_ENCRYPTION_KEY_IDX",  # select from preset keys
        0x0000_001C: "SPI_ENCRYPTION_SALT_3",  # user can modify key
        0x0000_0020: "SPI_ENCRYPTION_SALT_2",
        0x0000_0024: "SPI_ENCRYPTION_SALT_1",
        0x0000_0028: "SPI_ENCRYPTION_SALT_0",
        # core 0 conf regs
        0x0000_0034: "C0_DM_CONF0",
        0x0000_0038: "C0_DM_CONF1",
        0x0000_003C: "C0_DM_CONF2",
        0x0000_0040: "C0_DM_CONF3",
        0x0000_0044: "C0_DM_CONF4",
        0x0000_0048: "C0_DM_CONF5",
        0x0000_004C: "C0_DM_CONF6",
        0x0000_0050: "C0_DM_CONF7",
        0x0000_0054: "C0_TM_CONF0",
        0x0000_0058: "C0_TM_CONF1",
        0x0000_005C: "C0_TM_CONF2",
        0x0000_0060: "C0_TM_CONF3",
        0x0000_0064: "C0_IM_CONF",
        # core 1 conf regs
        0x0000_0068: "C1_DM_CONF0",
        0x0000_006C: "C1_DM_CONF1",
        0x0000_0070: "C1_DM_CONF2",
        0x0000_0074: "C1_DM_CONF3",
        0x0000_0078: "C1_DM_CONF4",
        0x0000_007C: "C1_DM_CONF5",
        0x0000_0080: "C1_DM_CONF6",
        0x0000_0084: "C1_DM_CONF7",
        0x0000_0088: "C1_TM_CONF0",
        0x0000_008C: "C1_TM_CONF1",
        0x0000_0090: "C1_TM_CONF2",
        0x0000_0094: "C1_TM_CONF3",
        0x0000_0098: "C1_IM_CONF",
        # core 0 memories
        0x0010_0000: "C0_DM0",
        0x0010_FFF8: "C0_DM0_END",
        0x0011_0000: "C0_DM1",
        0x0011_FFF8: "C0_DM1_END",
        0x0012_0000: "C0_DM2",
        0x0012_FFF8: "C0_DM2_END",
        0x0013_0000: "C0_DM3",
        0x0013_FFF8: "C0_DM3_END",
        0x0014_0000: "C0_DM4",
        0x0014_FFF8: "C0_DM4_END",
        0x0015_0000: "C0_DM5",
        0x0015_FFF8: "C0_DM5_END",
        0x0016_0000: "C0_DM6",
        0x0016_FFF8: "C0_DM6_END",
        0x0017_0000: "C0_DM7",
        0x0017_FFF8: "C0_DM7_END",
        0x0018_0000: "C0_TM0",
        0x0018_3FF8: "C0_TM0_END",
        0x0019_0000: "C0_TM1",
        0x0019_3FF8: "C0_TM1_END",
        0x001A_0000: "C0_TM2",
        0x001A_3FF8: "C0_TM2_END",
        0x001B_0000: "C0_TM3",
        0x001B_3FF8: "C0_TM3_END",
        0x001C_0000: "C0_SB",
        0x001C_01F8: "C0_SB_END",
        0x001D_0000: "C0_RQ",
        0x001D_01F8: "C0_RQ_END",
        0x001E_0000: "C0_PB",
        0x001E_01F8: "C0_PB_END",
        0x001F_0000: "C0_IM",
        0x001F_7FF8: "C0_IM_END",
        0x001F_FFE8: "C0_HEAD_TAIL_REG",
        # core 1 memories
        0x0020_0000: "C1_DM0",
        0x0020_FFF8: "C1_DM0_END",
        0x0021_0000: "C1_DM1",
        0x0021_FFF8: "C1_DM1_END",
        0x0022_0000: "C1_DM2",
        0x0022_FFF8: "C1_DM2_END",
        0x0023_0000: "C1_DM3",
        0x0023_FFF8: "C1_DM3_END",
        0x0024_0000: "C1_DM4",
        0x0024_FFF8: "C1_DM4_END",
        0x0025_0000: "C1_DM5",
        0x0025_FFF8: "C1_DM5_END",
        0x0026_0000: "C1_DM6",
        0x0026_FFF8: "C1_DM6_END",
        0x0027_0000: "C1_DM7",
        0x0027_FFF8: "C1_DM7_END",
        0x0028_0000: "C1_TM0",
        0x0028_3FF8: "C1_TM0_END",
        0x0029_0000: "C1_TM1",
        0x0029_3FF8: "C1_TM1_END",
        0x002A_0000: "C1_TM2",
        0x002A_3FF8: "C1_TM2_END",
        0x002B_0000: "C1_TM3",
        0x002B_3FF8: "C1_TM3_END",
        0x002C_0000: "C1_SB",
        0x002C_01F8: "C1_SB_END",
        0x002D_0000: "C1_RQ",
        0x002D_01F8: "C1_RQ_END",
        0x002E_0000: "C1_PB",
        0x002E_01F8: "C1_PB_END",
        0x002F_0000: "C1_IM",
        0x002F_7FF8: "C1_IM_END",
        0x002F_FFE8: "C1_HEAD_TAIL_REG",
    }

    SPU_TO_AXI = {v: k for k, v in AXI_TO_SPU.items()}
    ALL_AXI = SPU_TO_AXI

    # XXX would be nice to not need this
    # add on DM, TM bases, used by get_vars
    for i in range(2):  # cores
        ALL_AXI[f"C{i}_DM"] = ALL_AXI[f"C{i}_DM0"]
        ALL_AXI[f"C{i}_TM"] = ALL_AXI[f"C{i}_TM0"]

    ##############################################
    # autodoc

    @classmethod
    def get_spu_addr_map(cls) -> str:
        MEM_WIDTHS = {"DM": 64, "TM": 16, "IM": 64, "SB": 11, "RQ": 12, "PB": 12}

        def hexify(x):
            return "{:08X}".format(x)

        L = []  # lines

        def _print_dict_lines(D):
            for k, v in D.items():
                L.append(f"{hexify(k)} : {v}")

        L.append("######################################")
        L.append("SPU001 AXI address space")
        L.append("######################################")

        _print_dict_lines({v: k for k, v in cls.ALL_AXI.items()})

        return "\n".join(L)


@dataclass
class SPUAddrMap_150_TC1:
    #############################################
    # SPI registers
    # has boot-time clock control
    # see https://femtolab.net/qspi

    # 16b addressing
    IDX_TO_SPI_REGS = {
        0x00: "PLL_CTRL",  # {osc_en, osc_test, X, X, pwrdn, bypass, test, fast, ensat, reset}
        0x01: "PLL_CLKF",  # pllmult[15:7], 13b used (8K max)
        0x02: "PLL_BWADJ",  # pllmult[31:16], 12b used (4K max)
        0x03: "PLL_DIV",  # [5:0] is clkr, [11:8] is clkod
        0x04: "PLL_STAT",  # lock, slip, etc
    }
    # distance between adjacent regs in "IDX" space
    # used by hal.addr_range()
    IDX_TO_SPI_REGS_STEP = 1
    SPI_REGS_TO_IDXS = {v: k for k, v in IDX_TO_SPI_REGS.items()}

    #############################################
    # SOC-level regs
    # sysmgr etc
    # see https://femtolab.net/one50/sysmgr.htm

    # 8b addressing, relative AXI addr
    REL_AXI_TO_SYSMGR_REGS = {
        0x20: "SYSMGR_PLLCTRL",
        0x24: "SYSMGR_PLLMULT",  # CLKF + BWADJ
        0x28: "SYSMGR_PLLDIV",  # CLKR, CLKOD
        0x2C: "SYSMGR_PLLSTAT",
        # ...
        0x64: "SYSMGR_CLKDIV",  # loopback tested with 0x31, doc may not be correct for TC1
        0x68: "SYSMGR_CLKCTRL",  # {..., spu1x, spu2x, el2}
        0x6C: "SYSMGR_RESETN",  # {..., spu, el2}
        0x70: "SYSMGR_IRQ",
        0x74: "SYSMGR_EL2INT",
    }

    SOC_TO_AXI = {}
    for k, v in REL_AXI_TO_SYSMGR_REGS.items():
        SOC_TO_AXI[v] = 0x1000_0000 + k

    # copy over OTP regs
    for regname, regaddr in otp_150.OTPWords.REG.items():
        SOC_TO_AXI[regname] = regaddr

    #############################################
    # SPU: toplevel registers, outside core array

    # 16b SPI reg space
    # still programmable with 32b words
    REL_AXI_TO_SPU_SYS = {
        0x00_0000: "VERSION",  # HW version, 8b, {4b: major , 4b: minor}
        0x00_0004: "SPI_ENCRYPTION_KEY_IDX",  # select from preset keys
        0x00_0008: "SPI_ENCRYPTION_SALT_3",  # user can modify key
        0x00_000C: "SPI_ENCRYPTION_SALT_2",
        0x00_0010: "SPI_ENCRYPTION_SALT_1",
        0x00_0014: "SPI_ENCRYPTION_SALT_0",
        0x00_0018: "AXIS_SELECT",  # where to source/sink AXIS streams, 1=APB or 0=external
        0x00_0022: "AXIS_START",  # APB -> RTR crossover, lowest possible addr
        0x0F_FFFC: "AXIS_LAST",  # APB -> RTR crossover, tx/rx must end on this addr
    }

    ##############################################
    # SPU: per-core address space
    #
    # cores each occupy 0x20_0000 bytes
    #   addresses 0x00_0000 - 0x10_0000 are conf registers (mostly unused)
    #   addresses 0x10_0000 - 0x20_0000 are memories (~half used)
    #
    # core 0 starts on 0x20_0000
    # core 1 starts on 0x40_0000
    # core 2 starts on 0x60_0000
    # core 3 starts on 0x80_0000

    REL_AXI_TO_SPU_CORE = {
        0x00_0000: "RST",  # core clock enable and soft reset
        0x00_0004: "LOGIC_PG_CONF",  # core power gating : {clk_en, rstn, sw_gate_en, isol_en_n}
        0x00_0008: "DM_TIMERS",  # automatic sleep FSM regs
        0x00_000C: "TM_TIMERS",
        0x00_0010: "IM_TIMERS",
        0x00_0014: "REG_DP_ACK_DELAY",  # how many fudge cycles to pad on the end of the datapaths' ack
        0x00_0018: "DM_CONF0",  # these index the _physical_ banks of DM, TM
        0x00_001C: "DM_CONF1",
        0x00_0020: "DM_CONF2",
        0x00_0024: "DM_CONF3",
        0x00_0028: "TM_CONF0",
        0x00_002C: "TM_CONF1",
        0x00_0030: "TM_CONF2",
        0x00_0034: "TM_CONF3",
        0x00_0038: "IM_CONF",
        0x10_0000: "DM0",
        0x13_FFF8: "DM0_END",
        0x14_0000: "TM0",
        0x14_FFF8: "TM0_END",
        # (there is a big gap here, it is a historical quirk)
        # (there used to be 4x logical TMs spread out)
        0x18_0000: "IM",
        0x18_7FF8: "IM_END",
        0x18_8000: "IM_MSB",
        0x18_FFF8: "IM_MSB_END",
        0x19_0000: "SB",
        0x19_01F8: "SB_END",
        0x1A_0000: "RQ",
        0x1A_01F8: "RQ_END",
        0x1B_0000: "PB",
        0x1B_01F8: "PB_END",
        0x1F_FFE8: "HEAD_TAIL_REG",
    }

    ##############################################
    # SPU: collect SPU core addresses

    SPU_TO_AXI = {}
    for k, v in REL_AXI_TO_SPU_SYS.items():
        SPU_TO_AXI[v] = 0x2000_0000 + k
    for i in range(4):
        for k, v in REL_AXI_TO_SPU_CORE.items():
            core_k = f"C{i}_" + v
            assert core_k not in SPU_TO_AXI
            SPU_TO_AXI[core_k] = 0x2000_0000 + 0x0020_0000 * (i + 1) + k

    ##############################################
    # collect APB/AXI objects

    ALL_AXI = SPU_TO_AXI | SOC_TO_AXI

    # XXX would be nice to not need this
    # add on DM, TM bases, used by get_vars
    for i in range(4):  # cores
        ALL_AXI[f"C{i}_DM"] = ALL_AXI[f"C{i}_DM0"]
        ALL_AXI[f"C{i}_TM"] = ALL_AXI[f"C{i}_TM0"]

    ##############################################
    # autodoc

    @classmethod
    def get_spu_addr_map(cls) -> str:
        MEM_WIDTHS = {
            "DM": 64,
            "TM": 16,
            "IM": 64,
            "IM_MSB": 7,
            "SB": 11,
            "RQ": 12,
            "PB": 12,
        }

        def hexify(x):
            return "{:08X}".format(x)

        L = []  # lines

        def _print_dict_lines(D):
            for k, v in D.items():
                L.append(f"{hexify(k)} : {v}")

        L.append("######################################")
        L.append("SPU150 AXI address space")
        L.append("######################################")
        L.append("")
        L.append("######################################")
        L.append("system-wide registers")
        L.append("######################################")

        to_print = {cls.SPU_TO_AXI[k]: k for k in cls.REL_AXI_TO_SPU_SYS.values()}
        _print_dict_lines(to_print)

        for i in range(4):  # cores
            reg_to_print = {}
            mem_to_print = {}
            for k, v in cls.SPU_TO_AXI.items():
                if k.startswith(f"C{i}"):
                    if v % 0x20_0000 < 0x10_0000:
                        reg_to_print[v] = k
                    else:
                        if k not in MEM_WIDTHS:
                            mem_to_print[v] = k
                        else:
                            mem_to_print[v] = f"{k} (width={MEM_WIDTHS[k]}b)"

            L.append("######################################")
            L.append(f"core {i} configuration registers")
            L.append("######################################")
            _print_dict_lines(reg_to_print)

            L.append("######################################")
            L.append(f"core {i} primary memory")
            L.append("######################################")
            _print_dict_lines(mem_to_print)

        return "\n".join(L)


if __name__ == "__main__":
    with open("spu001_addr_map.txt", "w") as f:
        f.write(SPUAddrMap_001_MP.get_spu_addr_map())

    with open("spu150_addr_map.txt", "w") as f:
        f.write(SPUAddrMap_150_TC1.get_spu_addr_map())
