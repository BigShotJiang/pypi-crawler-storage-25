"""HAL for 001 mass production part"""
import logging
from typing import Literal, Optional

import numpy as np

from .hal import SPUHAL
from . import addr_map

logger = logging.getLogger(__name__)

F_VCO = 150e6


class SPUHAL_001_MP(SPUHAL):
    def __init__(self, spu: Optional["SPURunner"]):
        super().__init__(spu=spu)

        # stateful, avoid reading to set incrementally
        self._SPI_conf = 0x806  # in reset, clocks on

    @property
    def am(self):
        """get SPU address map"""
        return addr_map.SPUAddrMap_001_MP

    def check_version_reg(self) -> bool:
        """check that version reg has correct value"""
        addrlo, _ = self.addr_range("VERSION", 0, 1)
        version = self.hw_recv("VERSION")
        logger.debug(f"version reg ({addrlo}) : {hex(version)}")
        return version == 0x13

    def get_refclk_hz(self):
        """get reference clock for this HW, platform"""
        if self.platform == "zcu104":
            return 819200  # .8192 MHz
        if self.platform == "evk2":
            return 32768  # 32KHz
        else:
            assert False

    @staticmethod
    def _get_pll_conf_word(reset=False, bypass=False, pwrdn=False, clkdisable=False):
        # set up conf word
        conf_word = 0
        if reset:
            conf_word |= 1  # reset
        if bypass:
            conf_word |= 1 << 4  # bypass
        if pwrdn:
            conf_word |= 1 << 5  # power down
        if not clkdisable:
            conf_word |= 1 << 6  # post-PLL clock gate is transparent
        return conf_word

    def program_pll(self, multiplier: int, nr: int = 1, nd: int = 1) -> None:
        """program the PLL, using CLKOD = 1 (targeting min VCO)"""

        logger.info("programming PLL")

        assert multiplier >= 1
        assert multiplier < 8192

        CLKF = multiplier - 1
        BWADJ = int(multiplier / 2) - 1  # BWADJ is half of CLKF
        CLKOD = nd - 1
        CLKR = nr - 1

        self.hw_send("PLL_BWADJ", [BWADJ])
        self.hw_send("PLL_CLKOD", [CLKOD])
        self.hw_send("PLL_CLKF", [CLKF])
        self.hw_send("PLL_CLKR", [CLKR])

        # power up, reset hi, but keep gate on
        conf = self._get_pll_conf_word(
            reset=True,
            bypass=False,
            pwrdn=False,
            clkdisable=True,
        )
        self.hw_send("PLL_CONF", [conf])

        # reset lo, STILL GATED
        conf = self._get_pll_conf_word(
            reset=False,
            bypass=False,
            pwrdn=False,
            clkdisable=True,
        )
        self.hw_send("PLL_CONF", [conf])

        # wait a little for lock
        logger.info("sleeping .1s to wait for PLL")
        self.wait(200, 0.1)

    def ungate_pll(self):
        """after programming PLL, ungate/unbypass the clock"""
        conf = self._get_pll_conf_word(
            reset=False,
            bypass=False,
            pwrdn=False,
            clkdisable=False,
        )
        self.hw_send("PLL_CONF", [conf])

    def check_pll_lock(self) -> bool:
        """check PLL lock once"""

        # no PLL to lock for these setups
        if self.platform == "zcu104" or self.platform == "redis":
            return 1

        pllstat = self.hw_recv("PLL_LOCK")
        lock = pllstat & 0x1
        rfslip = pllstat & 0x10
        fbslip = pllstat & 0x20
        return lock

    def reset_sequence_spu_cores(self) -> None:
        """reset sequence for SPU logic"""
        init_SPI_conf = self._SPI_conf

        # synchronous reset, must enable clocks
        if init_SPI_conf & 0x006:
            self.set_spu_master_clocks(True)

        # toggle reset
        self.set_spu_master_resets(True)
        self.set_spu_master_resets(False)

        # turn clock back off if it was initially off
        if init_SPI_conf & 0x806:
            self.set_spu_master_clocks(False)

    def set_spu_master_resets(self, reset: bool) -> None:
        """master reset for SPU"""
        # curr_SPI_conf = self.hw_recv("SPI_CONF")
        curr_SPI_conf = self._SPI_conf

        new_SPI_conf = curr_SPI_conf & ~0x800 | 0x800 * reset
        self._SPI_conf = new_SPI_conf
        self.hw_send((None, "SPI_CONF", 0), new_SPI_conf, comment="reset both cores")

    def set_spu_master_clocks(self, clock_on: bool) -> None:
        """parent clock gate for entire SPU domain, if present"""
        # this probably should be the post-PLL gate instead
        self.set_spu_core_clocks([0, 1], True)

    def set_spu_core_clocks(self, cores: int | list[int], clock_on: bool) -> None:
        """control clock gating for each core's clocks
        not implemented!
        """
        curr_SPI_conf = self._SPI_conf
        core_bits = 0x000
        if 0 in cores:
            core_bits |= 0x004 * (not clock_on)
        if 1 in cores:
            core_bits |= 0x002 * (not clock_on)
        new_SPI_conf = curr_SPI_conf & ~0x006 | core_bits
        self._SPI_conf = new_SPI_conf

        self.hw_send(
            (None, "SPI_CONF", 0), new_SPI_conf, comment=f"spu core {cores} clocks on"
        )

    def set_spu_core_resets(self, cores: int | list[int], reset: bool) -> None:
        """control resets for each core"""
        # exists, but not used right now
        pass

    def set_core_power(self, cores: int | list[int], pwr_on: bool) -> None:
        """turn core power gates on or off
        may modify clock gating
        """
        # no logic power domains in 001
        pass

    def check_interrupt_reg(self) -> None:
        """check if output is ready"""
        return self.hw_recv("OUTPUT_INT")

    def enter_debug_mode(self, debugger) -> None:
        """enter debug mode. Femto use only"""
        return debugger.enter_debug_mode_1p3()

    def init(self, program_pll=True) -> bool:
        """perform init sequence for this hardware
        should generally make the chip ready for programming
        doesn't need to turn on/off specific cores though
        doesn't handle encryption settings, fake connections, etc
        """

        if self.platform == "evk2":
            # enable oscillator
            self.hw_send("PAD_CONF", [0b10001001000])

        if program_pll:
            pll_mult = int(np.ceil(F_VCO / self.get_refclk_hz()))
            self.program_pll(pll_mult)
            self.poll_until_pll_lock()

            # open up the master gate, core gates already open
            self.ungate_pll()

        self.reset_sequence_spu_cores()
        self.set_spu_master_clocks(True)
