from dataclasses import dataclass

"""
#include <stdint.h>
// #include <stdio.h>

/* register test macros */
#define readl(a)    (*(volatile uint32_t*)(a))
#define readb(a)    (*(volatile  uint8_t*)(a))
#define writel(a,v) (*(volatile uint32_t*)(a) = (v))
#define writeb(a,v) (*(volatile  uint8_t*)(a) = (v))

#define STDOUT 0xff000000

// OTP controller defines

// Controller Commands
#define CTRL_INIT_CMD                                       0x00000000
#define CTRL_STANDBY_CMD                                    0x00000001
#define CTRL_LPM_ON_CMD                                     0x00000002
#define CTRL_LPM_OFF_CMD                                    0x00000003
#define CTRL_TDEC_CMD                                       0x00000004
#define CTRL_TDEC_ROW_CMD                                   0x00000005
#define CTRL_BCHK_CMD                                       0x00000006
#define CTRL_BCHK_ROW_CMD                                   0x00000007

// Controller Register Addresses
#define CMD_REG_ADDR                                        0xFF007100
#define CFG_MEM_SEL_REG_ADDR                                0xFF007101
#define CFG_BCHK_REG_ADDR                                   0xFF007102
#define CFG_PGM_REG_ADDR                                    0xFF007103
#define CFG_LOCK_REG_ADDR                                   0xFF007104
#define CFG_START_END_ADDR_REG_ADDR                         0xFF007106
#define STATUS_REG_ADDR                                     0xFF007108
#define DEBUG0_REG_ADDR                                     0xFF007109
#define DEBUG1_REG_ADDR                                     0xFF00710A
#define DEBUG2_REG_ADDR                                     0xFF00710B

// Controller Status Register Values
#define STATUS_PASSED                                       0x00000000
#define STATUS_FAILED_TDEC_MAIN_ARRAY                       0x00000011
#define STATUS_FAILED_TDEC_REDUNDANT_ARRAY                  0x00000012
#define STATUS_FAILED_TDEC_WRTEST_ROW                       0x00000013
#define STATUS_FAILED_TDEC_REPAIR_ROW                       0x00000014
#define STATUS_FAILED_BCHK_WRTEST_ROW                       0x00000021
#define STATUS_FAILED_BCHK_REPAIR_ROW                       0x00000022
#define STATUS_FAILED_BCHK_REPAIR_DISABLED                  0x00000023
#define STATUS_FAILED_BCHK_REPAIR_COUNT_EXCEEDED            0x00000024
#define STATUS_FAILED_BCHK_REPAIR                           0x00000025
#define STATUS_PASSED_EXTRA_BCHK_MEMORY_ARRAY               0x00000026
#define STATUS_FAILED_EXTRA_BCHK_MEMORY_ARRAY               0x00000027
#define STATUS_FAILED_EXTRA_BCHK_SPARE_ROWS                 0x00000028
#define STATUS_FAILED_PGM_WRTEST_ROW                        0x00000031
#define STATUS_FAILED_PGM_REPAIR_DISABLED                   0x00000032
#define STATUS_FAILED_PGM_BCHK_REPAIR_ADDRESS               0x00000033
#define STATUS_FAILED_PGM_PGM_REPAIR_ADDRESS                0x00000034
#define STATUS_FAILED_PGM_REPAIR_COUNT_EXCEEDED             0x00000035
#define STATUS_FAILED_PGM_DISTURBANCE                       0x00000036
#define STATUS_FAILED_PGM_SECTOR_LOCKED                     0x00000037
#define STATUS_FAILED_PGM_REPAIR_ROW_RO                     0x00000038
#define STATUS_FAILED_LPM_NOT_STANDBY_MODE                  0x00000041
#define STATUS_FAILED_WRITE_REG_RO_REG_SELECTED             0x00000081
#define STATUS_FAILED_READ_REG_WO_REG_SELECTED              0x00000082
#define STATUS_FAILED_INVALID_REG_ADDRESS                   0x000000FC
#define STATUS_FAILED_INVALID_REG_DATA                      0x000000FD
#define STATUS_FAILED_INVALID_COMMAND                       0x000000FE
#define STATUS_FAILED_INVALID_OPERATION                     0x000000FF

// OTP Test Mode Commands
#define OTP_TM_TDEC_CMD                                     0xFF007021
#define OTP_TM_BCHK_CMD                                     0xFF007024
#define OTP_TM_WRTEST_CMD                                   0xFF007001
#define OTP_TM_REPAIR_CMD                                   0xFF007030
#define OTP_TM_TDEC_REPAIR_CMD                              0xFF007031
#define OTP_TM_BCHK_REPAIR_CMD                              0xFF007034
#define OTP_TM_WRTEST_PGMVFY_CMD                            0xFF007005
#define OTP_TM_PGMVFY_CMD                                   0xFF007004


void my_putc(char c) {
  writeb(STDOUT,c);
}

void my_puts(char *s) {
  while (*s) my_putc(*s++);
}

void run_cmd(char *msg, int addr, int data, int check_status) {
  int result_data;

  // my_puts(msg);
  writel(addr, data);
  // my_puts("done\n");
  if (check_status) {
    result_data = readb(CMD_REG_ADDR);
    if (result_data) {
      // my_puts("\nresult is FAIL\n");
    } else {
      // my_puts("\nresult is PASS\n");
    }
  }
}


void main(void) {
  uint8_t result_data;
  uint32_t i;
  char str[25];

  //clock and reset
  writel(0x10000068,0xf9f);//stream/i2s/pdm/uart/gpio on
  writel(0x1000006C,0xf9f);

  // stream : PDM -> i2s
  writel(0x40000000 + 1*8, 0x01); // 0000_0001

  //i2s/pdm/uart pinmux
  writel(0x10000034,0x10001110);
  writel(0x10000038,0x00000331);

  //uart baud rate
  writel(0xff000004,0x20003);

  //puts print to uart

  // Initialize the OTP to operational mode - PWRDY = 1, PORB = 1, CEB = 1, WAKEUP = 1, LPM = 0
  run_cmd("\nOTP Init...\n", CMD_REG_ADDR, CTRL_INIT_CMD, 0);

  // Put the OTP in sleep mode - PWRDY = 1, PORB = 1, CEB = 1, WAKEUP = 0, LPM = 0
  run_cmd("\nOTP sleep mode...\n", CMD_REG_ADDR, CTRL_STANDBY_CMD, 1);

  // Put the OTP in power down mode - PWRDY = 1, PORB = 1, CEB = 1, WAKEUP = 0, LPM = 1
  run_cmd("\nOTP power down mode...\n", CMD_REG_ADDR, CTRL_LPM_ON_CMD, 1);

  // Put the OTP back in sleep mode - PWRDY = 1, PORB = 1, CEB = 1, WAKEUP = 0, LPM = 0
  run_cmd("\nOTP return to sleep mode...\n", CMD_REG_ADDR, CTRL_LPM_OFF_CMD, 1);

  // Put the OTP back in operational mode - PWRDY 1= , PORB = 1, CEB = 0, WAKEUP = 1, LPM = 0
  run_cmd("\nOTP return to operation mode...\n", CMD_REG_ADDR, CTRL_INIT_CMD, 1);

  return;
}
"""


@dataclass
class OTPWords:
    REG = {
        # Controller Register Addresses
        # note, preamble'd w/ OTP from Darren's original code
        "OTP_CMD_REG_ADDR": 0xFF007100,
        "OTP_CFG_MEM_SEL_REG_ADDR": 0xFF007101,
        "OTP_CFG_BCHK_REG_ADDR": 0xFF007102,
        "OTP_CFG_PGM_REG_ADDR": 0xFF007103,
        "OTP_CFG_LOCK_REG_ADDR": 0xFF007104,
        "OTP_CFG_START_END_ADDR_REG_ADDR": 0xFF007106,
        "OTP_STATUS_REG_ADDR": 0xFF007108,
        "OTP_DEBUG0_REG_ADDR": 0xFF007109,
        "OTP_DEBUG1_REG_ADDR": 0xFF00710A,
        "OTP_DEBUG2_REG_ADDR": 0xFF00710B,
        # OTP Test Mode Commands
        "OTP_TM_TDEC_CMD": 0xFF007021,
        "OTP_TM_BCHK_CMD": 0xFF007024,
        "OTP_TM_WRTEST_CMD": 0xFF007001,
        "OTP_TM_REPAIR_CMD": 0xFF007030,
        "OTP_TM_TDEC_REPAIR_CMD": 0xFF007031,
        "OTP_TM_BCHK_REPAIR_CMD": 0xFF007034,
        "OTP_TM_WRTEST_PGMVFY_CMD": 0xFF007005,
        "OTP_TM_PGMVFY_CMD": 0xFF007004,
    }

    # Controller Commands
    CTRL_INIT_CMD = 0x00000000
    CTRL_STANDBY_CMD = 0x00000001
    CTRL_LPM_ON_CMD = 0x00000002
    CTRL_LPM_OFF_CMD = 0x00000003
    CTRL_TDEC_CMD = 0x00000004
    CTRL_TDEC_ROW_CMD = 0x00000005
    CTRL_BCHK_CMD = 0x00000006
    CTRL_BCHK_ROW_CMD = 0x00000007

    # Controller Status Register Values
    STATUS_PASSED = 0x00000000
    STATUS_FAILED_TDEC_MAIN_ARRAY = 0x00000011
    STATUS_FAILED_TDEC_REDUNDANT_ARRAY = 0x00000012
    STATUS_FAILED_TDEC_WRTEST_ROW = 0x00000013
    STATUS_FAILED_TDEC_REPAIR_ROW = 0x00000014
    STATUS_FAILED_BCHK_WRTEST_ROW = 0x00000021
    STATUS_FAILED_BCHK_REPAIR_ROW = 0x00000022
    STATUS_FAILED_BCHK_REPAIR_DISABLED = 0x00000023
    STATUS_FAILED_BCHK_REPAIR_COUNT_EXCEEDED = 0x00000024
    STATUS_FAILED_BCHK_REPAIR = 0x00000025
    STATUS_PASSED_EXTRA_BCHK_MEMORY_ARRAY = 0x00000026
    STATUS_FAILED_EXTRA_BCHK_MEMORY_ARRAY = 0x00000027
    STATUS_FAILED_EXTRA_BCHK_SPARE_ROWS = 0x00000028
    STATUS_FAILED_PGM_WRTEST_ROW = 0x00000031
    STATUS_FAILED_PGM_REPAIR_DISABLED = 0x00000032
    STATUS_FAILED_PGM_BCHK_REPAIR_ADDRESS = 0x00000033
    STATUS_FAILED_PGM_PGM_REPAIR_ADDRESS = 0x00000034
    STATUS_FAILED_PGM_REPAIR_COUNT_EXCEEDED = 0x00000035
    STATUS_FAILED_PGM_DISTURBANCE = 0x00000036
    STATUS_FAILED_PGM_SECTOR_LOCKED = 0x00000037
    STATUS_FAILED_PGM_REPAIR_ROW_RO = 0x00000038
    STATUS_FAILED_LPM_NOT_STANDBY_MODE = 0x00000041
    STATUS_FAILED_WRITE_REG_RO_REG_SELECTED = 0x00000081
    STATUS_FAILED_READ_REG_WO_REG_SELECTED = 0x00000082
    STATUS_FAILED_INVALID_REG_ADDRESS = 0x000000FC
    STATUS_FAILED_INVALID_REG_DATA = 0x000000FD
    STATUS_FAILED_INVALID_COMMAND = 0x000000FE
    STATUS_FAILED_INVALID_OPERATION = 0x000000FF
