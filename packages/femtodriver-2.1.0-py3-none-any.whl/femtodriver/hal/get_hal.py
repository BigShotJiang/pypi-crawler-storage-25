import os
from typing import Optional

from .hal import SPUHAL
from .hal_150_tc1 import SPUHAL_150_TC1
from .hal_150_array_apb import SPUHAL_150_ArrayAPB
from .hal_001_mp import SPUHAL_001_MP


def get_ISA() -> float:
    hwcfg = os.getenv("FS_HW_CFG")
    # e.g. spu1p3v1.dat
    major = hwcfg[3]
    minor = hwcfg[5]
    return float(f"{major}.{minor}")


def get_ISA_str() -> str:
    s = str(get_ISA())
    return s.replace(".", "p")


def get_spu_name() -> str:
    isa = get_ISA()
    if isa == 1.3:
        return "spu001"
    elif isa == 2.0:
        return "spu150tc1"
    elif isa == 2.1:
        return "spu150"
    else:
        assert False


def get_HAL(
    spu: Optional["SPURunner"] = None, platform: Optional[str] = None
) -> SPUHAL:
    # select HAL, based on env var
    # this should change in the future, move away from the var
    # just have user specify exact HW (001 MP, 150 TC1, etc)
    isa = get_ISA()
    if isa == 1.3:
        return SPUHAL_001_MP(spu)
    elif isa == 2.0:
        return SPUHAL_150_TC1(spu)
    elif isa == 2.1:
        return SPUHAL_150_ArrayAPB(spu)
    else:
        raise ValueError(
            f"unknown FS_HW_CFG value {hwcfg}. "
            "Must be spu1p3v1.dat or spu2p0v1.dat for SPU-001 or SPU-150 prototype,"
            "respectively"
        )
