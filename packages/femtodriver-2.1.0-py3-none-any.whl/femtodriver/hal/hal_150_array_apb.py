"""HAL for 150 core-only simulation"""

import logging

from .hal import SPUHAL
from . import addr_map
from .hal_150_tc1 import SPUHAL_150_TC1

logger = logging.getLogger(__name__)


# inherit 150_TC1, but nop global controls
class SPUHAL_150_ArrayAPB(SPUHAL_150_TC1):
    @property
    def am(self):
        """get SPU address map"""
        return addr_map.SPUAddrMap_150_TC1  # addr map same as TC1, for now

    def get_refclk_hz(self):
        """get reference clock for this HW, platform"""
        if self.platform == "redis":
            # no PLL
            return 150000000
        else:
            assert False

    def addr_range(self, obj: str, offset: int, length: int) -> (int, int):
        """compute address range for burst, relative to object
        assume 32b data stream, like IOPlugin
        returns (start, end)
        we need to remove the 0x2000_0000 offset for array_apb_top
        """
        lo_soc, hi_soc = super().addr_range(obj, offset, length)
        return lo_soc - 0x20000000, hi_soc - 0x20000000

    def check_version_reg(self) -> bool:
        """check that version reg has correct value"""
        addrlo, _ = self.addr_range("VERSION", 0, 1)
        version = self.hw_recv("VERSION")
        logger.debug(f"version reg ({addrlo}) : {hex(version)}")
        return version == 0x21

    def program_pll(self, multiplier: int, nr: int = 1, nd: int = 1) -> None:
        """program the PLL, using CLKOD = 1 (targeting min VCO)"""
        pass

    def ungate_pll(self):
        """after programming PLL, ungate/unbypass the clock"""
        pass

    def check_pll_lock(self) -> bool:
        """check PLL lock once"""
        # no PLL to lock
        assert self.platform == "redis"
        return 1

    def set_spu_master_resets(self, reset: bool) -> None:
        """master reset for SPU"""
        pass

    def set_spu_master_clocks(self, clock_on: bool) -> None:
        """parent clock gate for entire SPU domain, if present"""
        pass

    def reset_sequence_spu_cores(self) -> None:
        """reset sequence for SPU logic"""
        pass
