"""HAL for 150 TC1"""

import numpy as np
import logging
from typing import Literal

from femtodriver.util.packing import pack_word, unpack_word

from .hal import SPUHAL
from . import addr_map
from . import otp_150

logger = logging.getLogger(__name__)


def _bitflip(x):
    return ~np.uint32(x)


class SPUHAL_150_TC1(SPUHAL):
    # word packings
    PLL_CTRL_WORD = {
        "reset": 0,
        "ensat": 1,
        "fast": 2,
        "test": 3,
        "bypass": 4,
        "pwrdn": 5,
        "osc_test": 8,
        "osc_en": 9,
    }

    PLL_STAT_WORD = {
        "lock": 0,
        "rfslip": 4,
        "fbslip": 5,
        "rfen": 8,
        "fben": 9,
    }

    CORE_PG_CONF_WORD = {
        "clk_en": 0,
        "rstn": 1,
        "sw_gate_en": 2,
        "isol_en_n": 3,
    }

    def __init__(self, spu: "SPURunner"):
        super().__init__(spu)
        self._core_power_states = [True] * self.cfg.N_CORES

    @property
    def am(self):
        """get SPU address map"""
        return addr_map.SPUAddrMap_150_TC1

    def get_refclk_hz(self):
        """get reference clock for this HW, platform"""
        if self.platform == "evk2":
            return 32768
        else:
            raise NotImplementedError("SPU150 TC1 only supported w/ EVK2")

    def _uhvt_PLL_BWADJ(self, NF: int) -> int:
        # NB ~ NF / 16
        NB = float(NF) / 16.0
        NB = np.clip(np.round(NB), 1, 4096)

        # NB_ADJ = clip(round(8 /
        NB_ADJ = 8.0 / np.sqrt(float(self.get_refclk_hz()) / 32000.0)
        NB_ADJ = np.clip(np.round(NB_ADJ), 1, 8)

        # BWADJ = NB * NB_ADJ - 1
        BWADJ = int(NB * NB_ADJ - 1)
        return BWADJ

    def power_down_pll(self, bypass=True) -> None:
        """turn off PLL"""

        # read PLL_CTRL, get osc state
        pll_ctrl = self.hw_recv("PLL_CTRL")
        pll_ctrl_vals = unpack_word(self.PLL_CTRL_WORD, pll_ctrl)

        # power up, reset hi, bypass clock
        osc_en_pll_on_bypass = pack_word(
            self.PLL_CTRL_WORD,
            reset=1,
            bypass=bypass,
            pwrdn=1,
            osc_test=pll_ctrl_vals["osc_test"],
            osc_en=pll_ctrl_vals["osc_en"],
        )
        self.hw_send("PLL_CTRL", [osc_en_pll_on_bypass])

    def program_pll(self, multiplier: int, nr: int = 1, nd: int = 1) -> None:
        """program the PLL, using CLKOD = 1 (targeting min VCO)"""

        logger.info("programming PLL")

        assert multiplier >= 1
        assert multiplier < 8192

        CLKF = multiplier - 1
        BWADJ = self._uhvt_PLL_BWADJ(multiplier)
        CLKOD = nd - 1
        CLKR = nr - 1

        self.hw_send("PLL_BWADJ", [BWADJ])
        self.hw_send("PLL_DIV", [CLKR + (CLKOD << 8)])
        self.hw_send("PLL_CLKF", [CLKF])

        # read PLL_CTRL, get osc state
        pll_ctrl = self.hw_recv("PLL_CTRL")
        pll_ctrl_vals = unpack_word(self.PLL_CTRL_WORD, pll_ctrl)

        # power up, reset hi, bypass clock
        osc_en_pll_on_bypass = pack_word(
            self.PLL_CTRL_WORD,
            reset=1,
            bypass=1,
            pwrdn=0,
            osc_test=pll_ctrl_vals["osc_test"],
            osc_en=pll_ctrl_vals["osc_en"],
        )
        self.hw_send("PLL_CTRL", [osc_en_pll_on_bypass])

        deassert_reset = pack_word(
            self.PLL_CTRL_WORD,
            reset=0,
            bypass=1,
            pwrdn=0,
            osc_test=1,
            osc_en=0,
        )
        self.hw_send("PLL_CTRL", [deassert_reset])

        # wait a little for lock
        logger.info("sleeping .5s to wait for PLL")
        self.wait(200, 0.5)

    def ungate_pll(self):
        """after programming PLL, ungate/unbypass the clock"""
        ctrl = pack_word(
            self.PLL_CTRL_WORD, reset=0, bypass=0, pwrdn=0, osc_test=1, osc_en=0
        )
        self.hw_send("PLL_CTRL", [ctrl])

    def check_pll_lock(self) -> bool:
        """check PLL lock once"""
        pll_stat = self.hw_recv("PLL_STAT")
        pll_stat_vals = unpack_word(self.PLL_STAT_WORD, pll_stat)
        return pll_stat_vals["lock"]

    def set_spu_master_resets(self, reset: bool) -> None:
        """master reset for SPU"""

        # XXX write a _WORD if this gets more elaborate

        resetn_curr = self.hw_recv("SYSMGR_RESETN")
        resetn_curr = (
            resetn_curr & _bitflip(0x03) | (not bool(reset)) * 0x03
        )  # spu is bit 1, el2 is bit 0
        resetn_curr = resetn_curr | 1 << 11  # fuse

        self.hw_send("SYSMGR_RESETN", [resetn_curr], comment=f"cores reset = {reset}")

    def set_spu_master_clocks(self, clock_on: bool) -> None:
        """parent clock gate for entire SPU domain, if present"""

        # XXX write a _WORD if this gets more elaborate

        # FIXME this is not the right place for this
        # set clock dividers to known working configuration
        self.hw_send("SYSMGR_CLKDIV", [0x31], comment="spu is 2x el2")

        clk_curr = self.hw_recv("SYSMGR_CLKCTRL")
        clk_curr = (
            clk_curr & _bitflip(0x07) | clock_on * 0x07
        )  # spu is bits 2, 1, el2 is bit 0
        clk_curr = clk_curr | 1 << 11  # fuse

        self.hw_send(
            "SYSMGR_CLKCTRL", [clk_curr], comment=f"core clock gates = {clock_on}"
        )

    def set_spu_core_clocks(self, cores: int | list[int], clock_on: bool) -> None:
        """control clock gating for each core's clocks"""
        pass

    def set_spu_core_resets(self, cores: int | list[int], reset: bool) -> None:
        """control resets for each core"""
        pass

    def set_core_power(self, cores: int | list[int], pwr_on: bool) -> None:
        """turn core power gates on or off
        may modify clock gating

        RTL sequence:

        // see the end of core_pkg.sv

        // turn core 0 off
        // {clk_en, rstn, sw_gate_en, isol_en_n}
        // initial: 1101 (ON)
        wr_axi32(32'h2020_0004, 'b1100); // -> turn on isolation (C)
        wr_axi32(32'h2020_0004, 'b0100); // -> disable clocks (B)
        wr_axi32(32'h2020_0004, 'b0000); // -> reset enable (A)
        wr_axi32(32'h2020_0004, 'b0010); // -> power off (OFF)

        // turn core 0 on
        // {clk_en, rstn, sw_gate_en, isol_en_n}
        // initial: 0010 (OFF)
        wr_axi32(32'h2020_0004, 'b0000); // -> power on (A)
        wr_axi32(32'h2020_0004, 'b0100); // -> reset disable (B)
        wr_axi32(32'h2020_0004, 'b1100); // -> enable clocks (C)
        wr_axi32(32'h2020_0004, 'b1101); // -> turn off isolation (ON)

        """

        if isinstance(cores, int):
            cores = [cores]

        for core in cores:
            reg = f"C{core}_LOGIC_PG_CONF"

            if not pwr_on:
                logger.info(f"powering core {core} off")

                if not self._core_power_states[core]:
                    continue
                self._core_power_states[core] = False

                # {clk_en, rstn, sw_gate_en, isol_en_n}
                #            from 0b1101
                self.hw_send(reg, 0b1100)  # iso on
                self.hw_send(reg, 0b0100)  # clock off
                self.hw_send(reg, 0b0000)  # reset on
                self.hw_send(reg, 0b0010)  # power off
            else:
                logger.info(f"powering core {core} on")

                if self._core_power_states[core]:
                    continue
                self._core_power_states[core] = True

                # {clk_en, rstn, sw_gate_en, isol_en_n}
                #            from 0b0010
                self.hw_send(reg, 0b0000)  # power on
                self.hw_send(reg, 0b0100)  # reset off
                self.hw_send(reg, 0b1100)  # clock on
                self.hw_send(reg, 0b1101)  # iso off

    def reset_sequence_spu_cores(self) -> None:
        """reset sequence for SPU logic"""
        # 001 has sync reset, need to hold reset under clock
        self.set_spu_master_resets(True)
        self.set_spu_master_clocks(True)
        self.set_spu_master_resets(False)
        self.set_spu_master_clocks(False)

    def check_interrupt_reg(self) -> None:
        """check if output is ready"""
        return 1

    def enter_debug_mode(self, debugger) -> None:
        """enter debug mode. Femto use only"""
        return debugger.enter_debug_mode_2p0()

    def set_AXIS_mode(self, SPI_or_stream: Literal["SPI", "stream"]) -> None:
        """allow SPU to receive AXIS traffic from SPI or real-time stream"""
        logger.info("setting APB mode")
        if SPI_or_stream == "SPI":
            self.hw_send("AXIS_SELECT", 0b11)
        elif SPI_or_stream == "stream":
            self.hw_send("AXIS_SELECT", 0b00)
        else:
            assert False
        pass

    def check_version_reg(self) -> bool:
        """check that version reg has correct value"""
        addrlo, _ = self.addr_range("VERSION", 0, 1)
        version = self.hw_recv("VERSION")
        logger.debug(f"version reg ({addrlo}) : {version}")
        return version == 0x20

    def set_OTP_power_state(self, state: Literal["sleep", "off", "on"]) -> None:
        """control OTP power state"""
        # go to sleep/standby, this sequence always gets you there the "right" way

        # self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_INIT_CMD)
        # self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_STANDBY_CMD)
        # self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_LPM_ON_CMD)
        # print(hex(self.hw_recv("OTP_CMD_REG_ADDR")))

        logger.debug(f"OTP to sleep")
        self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_LPM_OFF_CMD)
        self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_STANDBY_CMD)

        if state == "sleep":
            pass  # already there
        elif state == "off":
            logger.debug(f"OTP to {state}")
            self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_LPM_ON_CMD)
        elif state == "on":
            logger.debug(f"OTP to {state}")
            self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_LPM_OFF_CMD)
            self.hw_send("OTP_CMD_REG_ADDR", otp_150.OTPWords.CTRL_INIT_CMD)
        else:
            raise ValueError("state must be one of 'sleep', 'off', 'on'")
