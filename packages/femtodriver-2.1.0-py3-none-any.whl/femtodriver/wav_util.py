import logging

import numpy as np
from scipy.io import wavfile
from femtorun import IOSpec

logger = logging.getLogger(__name__)


def generate_wav_inputs(
    wavfname: str,
    iospec: IOSpec,
    spu_chan_idx=0,
    wav_bits=32,
    spu_bits=16,
    input_sample_indices: list | None = None,
) -> dict[str, np.ndarray]:
    """create audio wav inputs compatible with an IOSpec"""

    # Load the wav file
    sampling_rate, data = wavfile.read(wavfname)

    data = data[:, spu_chan_idx]

    # 'sampling_rate' is the sampling rate of the wav file
    # 'data' is a numpy array containing the audio data
    logger.info(f"Input wavfile sampling rate: {sampling_rate} data type: {data.dtype}")

    assert spu_bits == 16  # would need to handle 16 + 8, 24b inputs

    if not len(iospec.inputs) == 1:
        raise RuntimeError("can only generate wav input for single-input models")

    # This just gets the first key from the dict since there should only be 1.
    input_var_name = next(iter(iospec.inputs))
    hop_size = iospec.inputs[input_var_name]["length"]
    padded_hop_size = iospec.inputs[input_var_name]["padded_length"]

    if not hop_size == padded_hop_size:
        raise RuntimeError("can only generate wav input for model with unpadded input")

    # The first part of this line data[:len(data)//hop_size * hop_size]
    # truncates the data into something divisible by hop_size and
    # then we reshape to (frames, hop_size) to match what the model expects
    data = data[: len(data) // hop_size * hop_size].reshape(-1, hop_size)

    shaped_inputs = {input_var_name: data >> (wav_bits - spu_bits)}

    # trim to sample range, if supplied
    if input_sample_indices is not None:
        lo, hi = input_sample_indices[0], input_sample_indices[1]
        for k, v in shaped_inputs.items():
            shaped_inputs[k] = shaped_inputs[k][int(lo) : int(hi)]

    return shaped_inputs
