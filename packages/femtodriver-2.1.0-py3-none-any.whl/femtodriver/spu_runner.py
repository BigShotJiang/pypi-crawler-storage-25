#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

import time
import os
import atexit
import logging
from collections import defaultdict
from typing import List, Dict, Tuple, Literal, Union, Optional, Any
import warnings
import numpy as np
import yaml

# this is nothing fancy
# a Mock just allows any method to be called on it, doing nothing
# in this case, NullDebugger will take Debugger's calls and do nothing with them
from unittest.mock import Mock

from femtorun import FemtoRunner, IOSpec

import femtodriver.util.packing as packing
from femtodriver import CompiledData

from femtodriver.typing_help import VARVALS, ARRAYU64, ARRAYINT, IOTARGET, HWTARGET

from femtodriver.plugins.zynq_plugin import ZynqPlugin
from femtodriver.plugins.redis_plugin import RedisPlugin
from femtodriver.plugins.evk2_plugin import Evk2Plugin

from femtodriver.hal import get_HAL, get_ISA_str

logger = logging.getLogger(__name__)

# program/dump only used locations in DM/TM
# saves programming time
LIMIT_PROGRAMMING = True

SEND_TO_RECV_WAIT = 0.010  # seconds

PROCESSING_SUCCESSFUL = 0x1F


class SPURunner(FemtoRunner):
    def __init__(
        self,
        compiled_data: CompiledData,
        platform: str = "zcu104",
        debug_vars: Union[str, List[str]] = [],
        mem_expectations: Dict[str, np.ndarray] = {},
        fake_connection: bool = False,
        fake_hw_recv_vals: Union[None, ARRAYU64] = None,
        salt: int = None,
        program_pll: bool = True,
        insert_debug_stores: bool = False,
        compiler_kwargs: Dict = {},
        io_records_dir: str | None = None,
        hardware_address: str | None = None,
        ioplugin_kwargs: Dict = {},
        **kwargs,
    ):  # catch unused kwargs used by other runners
        """FemtoRunner for real SPU hardware
        Args:
            compiled_data : CompiledData containing in memory representation of compiler metadata
                directory with memory images and metadata in it
            platform : str (default "zcu104") :
                hardware platform to target (PCB board)
                under the hood, will select a different IOPlugin
            debug_vars : list of strings, or 'all' :
                names of variables to extract values for each run() step()
            mem_expectations : dict[str, np.ndarray] :
                primarily for FB unit test-style run_all(): which variables should have which values at the end of the test
            fake_connection : bool :
                don't actually connect to the hardware, useful if you just want to create an SD card of commands
            encrypt : bool :
                encrypt programming stream
            encryption_key_idx : int (optional)
                index of encryption key to select. if not provided, uses FS_ENCRYPTION_KEY_IDX environment variable or default 0
            salt : int (optional)
                encryption salt. if not provided, uses FS_ENCRYPTION_SALT environment variable or default 0
            program_pll : bool :
                whether or not PLL should be programmed upon reset
            insert_debug_stores : bool :
                manually edit program to insert more stores
            io_records_dir : str :
                where to write IO record yaml
            hardware_address : str :
                identifier of the device to use (serial number for EVK2, ip address/hostname of the zynq board)
        """
        self.dbg = NullDebugger()

        self.compiled_data = compiled_data

        self._io_records_dir = io_records_dir

        self.meta = self._load_metadata(self.compiled_data)

        self.encrypt = self.compiled_data.encrypted
        self.encryption_key_idx = self.compiled_data.encryption_key_idx
        self.encryption_key_salt = self.meta.get("encryption_key_salt", 0)

        super().__init__(compiled_data.iospec)

        ##########################################################
        # supported hardware platforms -> IO plugins
        # IO plugin classes must provide hw_send(), hw_recv()
        platform_to_plugin = {
            "zcu104": ZynqPlugin,
            "redis": RedisPlugin,
            "evk2": Evk2Plugin,
        }
        self.platform = platform
        self.fake_connection = fake_connection
        if platform not in platform_to_plugin:
            raise NotImplementedError(
                f"unrecognized hardware platform {platform}, must be one of {platform_to_plugin.keys()}"
            )
        try:
            self.ioplug = platform_to_plugin[platform](
                fake_connection=fake_connection,
                fake_hw_recv_vals=fake_hw_recv_vals,
                logfiledir=self.io_records_dir,
                host=hardware_address,
                **ioplugin_kwargs,
            )
        except Exception as e:
            raise e

        # Do NOT atexit-register the bound method: it pins self.ioplug
        # (and therefore the redis-server Popen + redis.Redis socket)
        # alive for the life of the process, leaking FDs across
        # parametrized pytest testcases. _finish() already tears down.
        # atexit.register(self.ioplug.teardown)

        # workaround: encrypted disables fast memory programming
        if isinstance(self.ioplug, RedisPlugin):
            self.ioplug.set_encrypted(self.encrypt)
            logger.info(
                f"Told redis that encryption is {'on' if self.encrypt else 'off'}"
            )
            if self.encrypt:
                logger.warning("Using redis with encryption enabled.")
                logger.warning("Fast memory programming will be disabled.")
                logger.warning("This may take a really long time on large networks.")

        self.program_pll = program_pll

        self.debug_vars = debug_vars
        self.expectations = mem_expectations

        # just need to have this key for use w/ FB test
        self.cycles_run = None

        # select HAL (--> specific HW backend), based on config options
        # HAL is responsible for going from hardware-agnostic actions
        #   e.g. program the PLL, turn on a core, get address ranges
        # to specific commands and addresses for one hardware
        self.hal = get_HAL(self, platform)

        (
            self.mailbox_id_to_varname,
            self.mailbox_id_to_num_words,
        ) = self._get_output_lookup_info()

    @property
    def io_records_dir(self):
        if self._io_records_dir is not None:
            return self._io_records_dir
        else:
            return "last_io_records"

    def _get_output_lookup_info(self):
        """flip around tables in iospec. Hardware will return mailbox ids,
        we need to map that to varname, var sizes
        """
        mailbox_id_to_varname = {}
        mailbox_id_to_num_words = {}
        for varname, settings in self.io.outputs.items():
            mailbox_id_to_varname[settings["mailbox_id"]] = varname
            mailbox_id_to_num_words[settings["mailbox_id"]] = settings[
                "length_64b_words"
            ]
        return mailbox_id_to_varname, mailbox_id_to_num_words

    def attach_debugger(self, fasmir: Optional["FASMIR"]):
        try:
            from femtodriver_dev.debugger import SPUDebugger

            self.dbg = SPUDebugger(self, fasmir)

            if fasmir is not None:
                # set up debug vars, expands 'all' debug vars, checks keys
                self.dbg.process_debug_vars()

        except ImportError:
            # raise ImportError(
            #    "Couldn't import debug package. This is a FS-internal feature. Exiting"
            # )
            logger.warning("Couldn't import debug package")

    def _unpack_target(self, target):
        # standardize to new C<N>_OBJ form
        if isinstance(target, tuple):
            if len(target) == 3:
                core, obj, offset = target
                if core is None:
                    c_obj = obj
                else:
                    c_obj = f"C{core}_{obj}"
            elif len(target) == 2:
                obj, offset = target
                assert obj.startswith("C")
        else:
            c_obj = target
            offset = 0
        return c_obj, offset

    def hw_send(
        self,
        target: HWTARGET,
        vals: Union[ARRAYU64, List[int]],
        is_64b_data: bool = False,  # 64b data must be repacked
        flush: bool = True,
        comment: Optional[str] = None,
    ):
        """send raw data to the hardware

        has different target keys than IOPlugin's hw_send
        allows targetting relative to SPU-specific objects e.g. a particular memory
        IOPlugin flattens this into basic transaction types
        e.g. puts all SPU core controls into APB addr space
        works with 32 and 64b words, which differ by object type
        translates them into 32b words
        """
        vals = np.atleast_1d(np.array(vals, dtype=np.uint64))

        if is_64b_data:  # break up 64b SPU words
            vals = packing.pack_data_64_to_32(vals)
        else:
            if not np.all(vals < 2**32):
                raise ValueError(
                    "hw_send was passed data wider than 32b without is_64b_data=True"
                )

        # XXX also converts legacy core, "obj" to "C<N>_obj"
        obj, offset = self._unpack_target(target)

        # HAL functions: get IOPlugin message type, address range
        msgtype = self.hal.get_ioplugin_msgtype(obj)
        base, end = self.hal.addr_range(obj, offset, len(vals))

        if comment is None:
            comment = f"hw_send to (obj, offset) ({obj}, {offset})"
        logger.debug(comment)
        logger.debug(f"{hex(base)}, {hex(end)}, {len(vals)}")

        self.ioplug.hw_send(msgtype, base, end, len(vals), vals, flush, comment=comment)

    def hw_recv(
        self,
        target: HWTARGET,
        num_words: int = 1,
        is_64b_data: bool = False,  # 64b data must be repacked
        comment: Optional[str] = None,
    ) -> np.uint64 | ARRAYU64:
        """get raw data back from the hardware

        has different target keys than IOPlugin's hw_send
        allows targetting relative to SPU-specific objects e.g. a particular memory
        IOPlugin flattens this into basic transaction types
        e.g. puts all SPU core controls into APB addr space
        takes 32b words, translates them to
        32 and 64b words, which differ by object type
        """

        # XXX also converts legacy core, obj to C<N>_obj
        obj, offset = self._unpack_target(target)

        if is_64b_data:
            num_words *= 2

        msgtype = self.hal.get_ioplugin_msgtype(obj)
        base, end = self.hal.addr_range(obj, offset, num_words)

        if comment is None:
            comment = f"hw_recv from (obj, offset) ({obj}, {offset})"

        vals = self.ioplug.hw_recv(
            msgtype, base, end, num_words, comment=comment
        )  # 32b words

        if is_64b_data:
            vals = [packing.unpack_32_to_64(v) for v in vals]

        assert isinstance(vals, list)
        vals_arr = np.concatenate(vals)

        if len(vals_arr) == 1:
            return vals_arr[0]
        else:
            return vals_arr

    def _load_metadata(self, compiled_data) -> Any:
        """
        Take in a compiled_data object and load information from metadata.yaml
        return just a metadata object from metadata.yaml.
        """

        meta = compiled_data.metadata

        # unpack bank sizes
        self.data_bank_sizes = meta["data_bank_sizes"]
        self.table_bank_sizes = meta["table_bank_sizes"]
        self.inst_counts = meta["inst_counts"]

        return meta

    def _hw_write_mem_inner(self, mem: Tuple[str], datas: np.ndarray) -> None:
        cidx, memname, offset = mem

        # use first bitgroup if not IM
        # spu2 IM uses 2 bgs
        if memname != "IM":
            datas = datas[0]

        if len(datas) == 0:
            return

        logger.debug("writing to memory %s", mem)

        # go bank by bank, only up to used sizes
        if memname == "DM":
            if cidx in self.data_bank_sizes:
                for i in range(self.hal.cfg.CORE_DATA_MEM_BANKS):
                    membank = f"DM{i}"
                    maxidx = self.data_bank_sizes[cidx][i]
                    if maxidx > 0:
                        logger.debug(f"data bank {i}, max size {maxidx}")
                        N = self.hal.cfg.DATA_MEM_BANK_WORDS
                        valid_datas = datas[N * i : N * i + maxidx]
                        self.hw_send((cidx, membank, 0), valid_datas, is_64b_data=True)
        elif memname == "TM":
            if cidx in self.table_bank_sizes:
                for i in range(self.hal.cfg.CORE_TABLE_MEM_BANKS):
                    membank = f"TM{i}"
                    maxidx = self.table_bank_sizes[cidx][i]
                    if maxidx > 0:
                        logger.debug(f"table bank {i}, max size {maxidx}")
                        N = self.hal.cfg.TABLE_MEM_BANK_WORDS
                        valid_datas = datas[N * i : N * i + maxidx]
                        self.hw_send((cidx, membank, 0), valid_datas, is_64b_data=True)
        elif memname == "IM":
            if self.hal.cfg.ISA == 1.3:
                datas = datas[0]  # bitgroup 0
                maxidx = self.inst_counts[cidx]
                valid_datas = datas[0:maxidx]
                self.hw_send(mem, valid_datas, is_64b_data=True)
            elif self.hal.cfg.ISA >= 2.0 and self.hal.cfg.ISA < 3.0:
                # spu2 IM has >64b
                # need to use both bitgroups
                # MSBs are programmed to a
                # "virtual" IM bank above the first one
                maxidx = self.inst_counts[cidx]
                lsbs = datas[0][0:maxidx]
                msbs = datas[1][0:maxidx]
                self.hw_send((cidx, "IM", 0), lsbs, is_64b_data=True)
                self.hw_send(
                    (cidx, "IM_MSB", 0), msbs, is_64b_data=True
                )  # note offset!
            else:
                assert False
        else:
            # the others are small
            assert memname in ["PB", "RQ", "SB"]
            self.hw_send(mem, datas, is_64b_data=True)

    def _hw_write_from_compiled_data(self, mem: Tuple[str]) -> None:
        cidx, memname, _ = mem
        datas = self.compiled_data.mems_per_core[cidx][memname]
        self._hw_write_mem_inner(mem, datas)

    def get_vars(self, varnames: List[str]) -> VARVALS:
        return self.dbg.get_vars(varnames)

    def set_vars(self, set_vals: VARVALS):
        self.dbg.set_vars(set_vals)

    def soft_reset(self):
        # FIXME enable cores does the same thing
        logger.info("soft reset called")
        self.hw_send("RST", 0b11, comment="soft reset high")
        self.hw_send("RST", 0b00, comment="soft reset low")

    def change_mem_power_state(self, action: str):
        """controls used memories in used cores"""
        # FIXME, should probably only go up to used data banks
        logger.debug(self.data_bank_sizes)
        logger.debug(self.table_bank_sizes)
        for core in range(self.used_cores):  # used cores
            used_mem_confs = ["IM_CONF"]
            if core in self.data_bank_sizes:
                used_dms = sum([x > 0 for x in self.data_bank_sizes[core].values()])
                logger.info(f"core {core} uses {used_dms} DM banks")

                logger.debug(f"core {core} data bank sizes")
                logger.debug(self.data_bank_sizes[core])

                for i, b in self.data_bank_sizes[core].items():
                    if b > 0:
                        used_mem_confs.append(f"DM_CONF{i}")
            if core in self.table_bank_sizes:
                used_tms = sum([x > 0 for x in self.table_bank_sizes[core].values()])
                logger.info(f"core {core} uses {used_tms} TM banks")

                for i, b in self.table_bank_sizes[core].items():
                    if b > 0:
                        used_mem_confs.append(f"TM_CONF{i}")
            logger.debug(used_mem_confs)

            for mem in used_mem_confs:  # all core regs are mem ctrls in TC2
                if action == "on":
                    logger.debug(f"turning on core {core} mem {mem}")
                    self.hal.power_up_mem(core, mem)
                elif action == "off":
                    logger.debug(f"turning off core {core} mem {mem}")
                    self.hal.power_dn_mem(core, mem)
                elif action == "sleep":
                    logger.debug(f"sleeping core {core} mem {mem}")
                    self.hal.sleep_mem(core, mem)
                elif action == "wake":
                    logger.debug(f"waking core {core} mem {mem}")
                    self.hal.wake_mem(core, mem)

    def integrity_check_all_memories(
        self, N: int = 8191
    ) -> Tuple[int, List[List[int]]]:
        """do a single read/write to bottom addr of all memories, all cores
        returns total failures and bit-failures per bank for each core

        args:
        ------
        N : int :
            number of entries tested per memory. Over 2K will have weird effects but might work.
            The smallest memory has 2K entries. I suspect it might just alias.
            8K entries is the max memory size. If N is too large, it will be truncated to the max
            size for each type of memory

        e.g.
            total_fail, by_bank = integrity_check_all_memories(...)
            fails_for_core_idx_bank_idx = by_bank[core_idx][bank_idx]
        bank_idx order: 4 DMs, 8 TMs, 1 IM
        """

        N_max = {
            "DM": 8191,  # for some reason, using 8192 always fails.
            "TM": 2048,
            "IM": 4096,
        }
        all_core_mems = (
            [f"DM{i}" for i in range(am.PHYS_DM_BANKS)]
            + [f"TM{i}" for i in range(am.PHYS_TM_BANKS)]
            + ["IM"]
        )
        bitfail = [[0] * len(all_core_mems) for i in range(cfg.N_CORES)]

        def _test_one_pattern(cidx, test_val_64b: int, test_val_16b: int):
            # compute number of bit-failures per memory

            for mem in all_core_mems:
                self.hw_send((cidx, mem, 0), [test_val_64b] * min(N, N_max[mem[:2]]))

            logger.info("Running memory integrity check")
            for idx, mem in enumerate(all_core_mems):
                read_values = []
                for i in range(min(N, N_max[mem[:2]])):
                    r = self.hw_recv((cidx, mem, i), is_64b_data=True)
                    read_values.append(r)

                logger.info(
                    f"first word of {mem} : {int(read_values[0]):016x}, read {len(read_values)} total words"
                )
                if mem.startswith("TM"):
                    test_val = test_val_16b
                else:
                    test_val = test_val_64b

                for read_val in read_values:
                    read_val = int(read_val)
                    # compute number of differing bits per word
                    bitdiff = read_val ^ test_val  # XOR
                    num_ones = bitdiff.bit_count()
                    bitfail[cidx][idx] += num_ones

                if mem == "DM0":
                    numlog = min(N, 100)
                    logger.debug(f"integrity check: first {numlog} DM0 entries")
                    logger.debug(f"  expected: {int(test_val):016x}")
                    for i in range(numlog):
                        logger.debug(f"  {i} : {int(read_values[i]):016x}")

        for cidx in range(0, self.hal.cfg.N_CORES):
            # test in a checkerboard pattern
            # first write/read 01010101
            # then write/read  10101010
            # this stresses the bitcells by making their neighbors have the opposite bit

            test_val_64b = 0xAAAAAAAAAAAAAAAA
            test_val_16b = 0xAAAA
            _test_one_pattern(cidx, test_val_64b, test_val_16b)

            test_val_64b = 0x5555555555555555
            test_val_16b = 0x5555
            _test_one_pattern(cidx, test_val_64b, test_val_16b)

        total_fails = np.sum(np.array(bitfail))
        fail = total_fails > 0
        bits_tested = (
            self.hal.cfg.N_CORES
            * N
            * (am.PHYS_DM_BANKS * 64 + am.PHYS_TM_BANKS * 16 + 71)
        )
        # TODO: bits_tested will be wrong for large values of N

        if fail:
            logger.warning(
                f"integrity check of all memories FAILED. fails/bits tested = {total_fails} / {bits_tested}"
            )
        else:
            logger.info("integrity check of all memories was OK")

        return total_fails, bitfail

    def check_interrupt_reg(self):
        if self.fake_connection:
            logger.info("trying to check interrupt reg for a fake connection")
            logger.info("fake runners should work instantaneously, just returning")
            return np.array([1], dtype=np.uint64)
        else:
            return self.hal.check_interrupt_reg()

    @property
    def used_cores(self):
        return len(self.inst_counts)

    def program_network(self):
        """use self.compiled_data to program

        includes all setup intrinsic to the network
        which memory power states

        also sets head/tail"""

        logger.info("powering on memories")
        self.change_mem_power_state("on")

        for cidx in range(self.used_cores):
            for mem in ["DM", "TM", "SB", "RQ", "PB", "IM"]:
                logger.debug(f"PROGRAMMING {mem}")
                self._hw_write_from_compiled_data((cidx, mem, 0))

        # optional, verify programming by reading data back out
        # must be done before H/T below
        # self.verify_programming()

        # set head/tail register for ready queue
        # this is only needed if there are threads with 0 initial score
        # otherwise, the reset value of 0 is correct
        # FB tests need this, but also need are generally run w/o encryption
        self.set_head_tail()

    def init_spu(self):
        """pull hard reset, set up PLL, enabled cores, possibly enter debug mode"""

        # maybe do some platform-specific reset stuff before programming
        # generally, pulls hard reset, any other reset hacks
        self.ioplug.reset()
        self.wait(1000, 0.1)

        # chip-specific init sequence
        self.hal.init(program_pll=self.program_pll)

        if not self.encrypt:
            logger.info(f">>> DEBUG MODE <<<")
            self.hal.enter_debug_mode(self.dbg)
        else:
            logger.info(f"Using encryption key index {self.encryption_key_idx}")
            logger.info(f"Using salt {hex(self.encryption_key_salt)}")
            self.hal.write_encryption_regs(
                self.encryption_key_idx, self.encryption_key_salt
            )

        if not self.fake_connection and not self.hal.check_version_reg():
            raise RuntimeError("version reg didn't show correct value")
        else:
            logger.info("version reg OK")

    def reset_hidden_state(self):
        # if init'd from FQIR, we know which variables are in the init part of the graph
        # can write "reset hidden state" file (RHS) for these
        # note that init is always to 0 right now--might not always work!
        if self.encrypt:
            logger.debug("RHS not performed. NEED TO IMPLEMENT RHS WITH ENCRYPTION")
        else:
            if self.dbg.fqir is not None:
                # XXX FIXME, might need to pass some other kind of metadata for this
                # or extend FASMIR in general for more general reset sequence
                self._reset_hidden_state()
            else:
                logger.warning(
                    "NO DEBUGGER WITH FQIR, NOT COLLECTING RESET HIDDEN STATE (RHS)"
                )

    def _reset(self, reset_vals=None, record=True):
        """reset the program into initial state
        In this case, reprogram the memories, set head/tail
        """
        if reset_vals is not None:
            raise NotImplementedError()
            # I think this is just if you want to reset certain variables?

        if record:
            self.ioplug.start_recording("init_spu")

        # set up clocks, power memories
        self.init_spu()

        if record:
            self.ioplug.start_recording("program_network")

        # program memories
        self.program_network()

        # reset hidden states (not strictly necessary,
        # we just do this to get the record file
        if record:
            self.ioplug.start_recording("RHS")
            self.reset_hidden_state()

        if record:
            self.ioplug.commit_recording("setup.yaml")
            self.commit_APB_to_files()

    def _finish(self):
        self.ioplug.teardown()
        # self.ioplug.commit_recording("all.yaml")
        pass

    def _reset_hidden_state(self, sleeptime: float = 0.030):
        """reset the supplied variables to 0"""
        # XXX extend to non-zero RHS vals
        reset_vars = self.dbg.get_RHS_vars()
        var_objs = self.dbg.get_vars(reset_vars)
        reset_varvals = {
            var: np.zeros(var_objs[var].data.numpy.shape, dtype=np.int64)
            for var in reset_vars
        }
        self.set_vars(reset_varvals)
        self.wait(50, sleeptime)

    def set_head_tail(self):
        """set the head/tail register to match the state in the program initially
        so any threads that are ready to start (score 0 initially)
        are effectively placed "on deck"
        """

        # set the head-tail registers in each core
        for core in range(self.used_cores):
            rqueue_len = len(self.compiled_data.mems_per_core[core]["RQ"][0])
            if self.encrypt:
                if rqueue_len > 0:
                    # the head/tail reg is actually in the encrypted address range,
                    # probably need to hardcode some values
                    raise RuntimeError(
                        "Had to set H/T to nonzero value. Need to implement w/ encryption turned on"
                    )
                else:
                    logger.info(f"core {core} has 0 wake-on-start threads")
            else:
                logger.info(
                    f"setting core {core} head-tail reg to have {rqueue_len} threads"
                )
                self.hw_send((core, "HEAD_TAIL_REG", 0), [rqueue_len], is_64b_data=True)

    def run_all(self, check_exp=False, n_cycles=1000, wait_for_sec=1.0):
        """Run command used by FB unit tests, which have no external IO
        (a thread just starts running--test compares memory states after run to expected values)
        expected values are supplied to the __init__ as mem_expectations
        """
        # NOTE: deliberately do NOT call self.finish() here. The QFR/redis
        # architecture keeps a single redis-server alive across testcases
        # (external QFR client stays connected to it). Calling finish()
        # would teardown() -> SIGTERM the server between tests, and the
        # next test's hw_recv would hang waiting for the disconnected QFR.
        # Cleanup of the last live plugin happens at process exit; between
        # tests, the plugin object goes out of scope and GC closes its
        # redis client socket + Popen pipes, which is what recovers the
        # FDs without disturbing the server.

        self.reset()  # program, set H/T (which should start some thread(s) automatically)

        logger.info("waiting")
        self.wait(n_cycles, wait_for_sec)

        # if logger.getEffectiveLevel() == logging.DEBUG:
        #    self.dump_mems(basename='debug/dump_final')

        for var in self.debug_vars:
            logger.debug("getting value of debug_var %s", var)
            logger.debug("%s", str(self.get_vars([var])))

        logger.info("run over, reading expected vars")
        extracted_vals = self.get_vars(self.expectations.keys())

        if (
            FemtoRunner.compare_outputs(
                "expected", [self.expectations], "hardware", [extracted_vals]
            )
            != 0
        ):
            raise ValueError(
                "OUTPUT COMPARISONS FAILED! See log"
            )  # match format pytest expects

        return extracted_vals

    def verify_programming(self, throw=True):
        if not (self.hal.cfg.ISA == 2.0 or self.hal.cfg.ISA == 2.1):
            raise NotImplementedError("fix this up for 001")

        self.wait(10, 0.001)
        cd = self.dump_mems()
        dm_ext = cd.mems_per_core[0]["DM"][0]
        dm_exp = self.compiled_data.mems_per_core[0]["DM"][0]
        len_used_DM = len(dm_ext)
        compare_mask = dm_ext == dm_exp[:len_used_DM]
        compare_ok = np.all(compare_mask)
        if throw:
            if not compare_ok:
                raise RuntimeError("DM dump didn't match programmed values")

        return compare_ok, compare_mask, dm_ext

    def dump_mems(self, output_dir=None) -> CompiledData:
        dumped = CompiledData()
        dumped.mems_per_core = defaultdict(lambda: defaultdict(list))

        mem_sizes = {
            "DM": self.data_bank_sizes,
            "TM": self.table_bank_sizes,
            "SB": {i: self.hal.cfg.MAX_THREADS for i in range(self.hal.cfg.N_CORES)},
            "RQ": {i: self.hal.cfg.MAX_THREADS for i in range(self.hal.cfg.N_CORES)},
            "PB": {i: self.hal.cfg.MAX_THREADS for i in range(self.hal.cfg.N_CORES)},
            "IM": self.inst_counts,
        }

        for mem, core_bank_sizes in mem_sizes.items():
            for cidx, bank_sizes in core_bank_sizes.items():
                if isinstance(bank_sizes, int):
                    bank_sizes = {0: bank_sizes}

                for bidx, bank_size in bank_sizes.items():
                    if (
                        self.hal.cfg.ISA >= 2.0
                        and self.hal.cfg.ISA < 3.0
                        and mem == "IM"
                    ):
                        bank_size *= 2  # MSBs for IM too

                    if mem in ["DM", "TM"]:
                        mem_name_ext = mem + str(bidx)
                    else:
                        mem_name_ext = mem

                    hw_data = self.hw_recv(
                        (cidx, mem_name_ext, 0),
                        bank_size,
                        comment="dump memory",
                        is_64b_data=True,
                    )
                    dumped.mems_per_core[cidx][mem].append(hw_data)

        if output_dir is not None:
            dumped.write_to_files(output_dir)

        return dumped

    def _env_SEND_RDY_packer(
        self,
        send_or_rdy: str,
        core_idx: int,
        pc_val: int,
        packed_payload: Union[None, ARRAYU64],
    ):
        """takes already-packed payload and puts it into router word format:
        prepends the (route, PC) word before data"""

        # this design: one core, or daisy-chained cores, cidx unused

        if send_or_rdy == "SEND":
            # message stream is just payload with leading PC
            msg_words = np.zeros((packed_payload.shape[0] + 1,), dtype=np.uint64)
            msg_words[0] = pc_val << 32 | core_idx
            msg_words[1:] = packed_payload
        elif send_or_rdy == "RDY":
            assert packed_payload is None
            msg_word = pc_val << 32 | core_idx
            msg_words = np.array(msg_word, dtype=np.uint64)
        else:
            raise RuntimeError(f"unknown message type {send_or_rdy}")

        return np.atleast_1d(msg_words)

    def _env_RECV_unpacker(self, raw_64b_hw_data_list: ARRAYU64) -> Dict[int, ARRAYU64]:
        """unpacks ((route, mailbox), data, data, ..., data, (route, mailbox), data, data, ..., data),
        returns dict of {mailbox id : packed payloads}"""

        mailbox_to_packed = {}
        next_word_is_header = True
        words_to_read = 0
        curr_payload = []
        for word in raw_64b_hw_data_list:
            if next_word_is_header:
                mailbox = int(word) >> 32
                processing_status = int(word) & 0xFFFFFFFF
                assert processing_status == PROCESSING_SUCCESSFUL
                words_to_read = self.mailbox_id_to_num_words[mailbox]
            else:
                words_to_read -= 1
                assert words_to_read >= 0
                curr_payload.append(word)

            if words_to_read == 0:
                next_word_is_header = True
                mailbox_to_packed[mailbox] = np.array(curr_payload, dtype=np.uint64)
                curr_payload.clear()
            else:
                next_word_is_header = False

        return mailbox_to_packed

    def env_SEND(self, input_vals: VARVALS):
        """Transmit a SEND from the environment

        converts varnames and packs up element values into 64b words

        Args:
            varvals : dict[str, ARRAYU64] : varnames to element values
        """
        for varname, element_vals in input_vals.items():
            # look up varname -> core/pc/precision
            settings = self.io.inputs[varname]

            # pack it up
            # t0 = time.time()
            payload = packing.pack_V(
                settings["precision"],
                element_vals,
            )  # element vals -> 64b words
            # print(f"packing took {round(time.time() - t0, 3)}")

            assert settings["length_64b_words"] == len(payload)
            msg = self._env_SEND_RDY_packer(
                "SEND", settings["core_id"], settings["pc"], payload
            )

            # send it
            t0 = time.time()
            logger.debug(
                "about to transmit env_SEND() for var %s (core %d pc_val %s)",
                varname,
                settings["core_id"],
                settings["pc"],
            )
            self.hw_send(
                "RTR",
                msg,
                comment=f"env_SEND to vars {list(input_vals.keys())}",
                is_64b_data=True,
            )
            print(f"  hw_send took {round(time.time() - t0, 3)}")

    def env_RECV(self, total_words=None) -> VARVALS:
        """Environment performs a RECV
        Assumes that we've waited long enough for everything to come out
        """
        # receive all output vars, looking at fasmir to know how big they are
        if total_words is None:
            total_words = 0
            for output_var, settings in self.io.outputs.items():
                # adding 1 to account for the output parameter header (processing_status+mailbox_id)
                total_words += settings["length_64b_words"] + 1
        logger.debug(f"env_RECV : about to try to grab {total_words} words")

        # ask for data
        t0 = time.time()
        messages = self.hw_recv(
            "RTR", num_words=total_words, comment="env_RECV", is_64b_data=True
        )
        print(f"  hw_recv took {round(time.time() - t0, 3)}")

        # t0 = time.time()
        # convert mailbox ids to varnames, unpack data
        mailbox_to_packed_data = self._env_RECV_unpacker(messages)

        element_vals = {}
        for mid, data in mailbox_to_packed_data.items():
            varname = self.mailbox_id_to_varname[mid]
            settings = self.io.outputs[varname]
            assert settings["length_64b_words"] == len(data)
            element_vals[varname] = packing.unpack_V(settings["precision"], data)
        # print(f"unpacking took {round(time.time() - t0, 3)}")

        for varname, vals in element_vals.items():
            logger.debug(f"env_RECV : element values for {varname}")
            logger.debug(f"  {vals}")

        return element_vals

    def wait(self, sim_cycles, real_seconds):
        if isinstance(self.ioplug, RedisPlugin):
            self.ioplug.wait(sim_cycles)
        else:
            time.sleep(real_seconds)

    # def step(self, input_vals: VARVALS) -> VARVALS:
    #    """Execute one timestep, driving input_vals and getting outputs

    #    Args:
    #        input_vals (dict) :
    #            keyed by variable names, values are numpy arrays for one timestep

    #    Returns:
    #        (output_vals, internal_vals) tuple(dict, dict)) :
    #            tuple of dictionaries with same format as input_vals,
    #            values for the output variables as well as all internal variables
    #    """
    #    # apply padding if nominal input length differs from implemented padded size
    #    # this is implemented in FR base
    #    padded_inputs = self._pad_inputs(input_vals)

    #    # undo padding on the way out
    #    # this is implemented in FR base
    #    output_vals = self._unpad_outputs(padded_outputs)

    #    return output_vals, internal_vals

    def _send_inputs(self, inputs: VARVALS):
        """send in inputs"""
        # send inputs in
        t0 = time.time()
        self.env_SEND(inputs)
        print(f"send_inputs took {round(time.time() - t0, 3)}")

    def _recv_outputs(self, expected_output_names: list[str]) -> VARVALS:
        """wait for outputs to be ready, then receive them"""
        # sleep for a bit, just to make sure processing is done
        t0 = time.time()
        self.wait(100000, SEND_TO_RECV_WAIT)

        # now poll for interrupt
        while self.check_interrupt_reg() == 0:
            logger.debug("polling for interrupt")
            # SPI clock is typically run at 100MHz in simuation for faster overall speed
            # this is unrealistically fast, but .05ms @ 100MHz is 5K cycles
            # this is a lot of cycles--we can affort to check more often
            self.wait(10000, 0.05e-3)

        outputs = self.env_RECV()
        print(f"recv_outputs took {round(time.time() - t0, 3)}")

        return outputs

    def _get_internals(self) -> VARVALS:
        return self.get_vars(self.debug_vars)

    def get_single_output_name(self):
        """assert the model has one output, return its name"""
        assert len(self.meta["outputs"]) == 1
        return next(iter(self.meta["outputs"]))

    def commit_APB_to_files(self):
        """Dumps captured APB records to files"""
        PROG_path = os.path.join(self.io_records_dir, "apb_records")
        if not os.path.exists(PROG_path):
            os.makedirs(PROG_path)
        self.ioplug.records.dump_apb_to_text(PROG_path)

    @classmethod
    def write_APB_files(cls, *runner_args, **runner_kwargs):
        """capture PROG and RHS (reset hidden state) programming files for SD card"""
        hw_runner = cls(*runner_args, fake_connection=True, **runner_kwargs)
        hw_runner.reset()


class NullDebugger(Mock):
    def get_RHS_vars(self):
        return []

    def get_vars(self, varnames: List[str]) -> VARVALS:
        return {}

    def enter_debug_mode(self) -> None:
        raise RuntimeError("Developer access is needed to enter debug mode.")

    def enter_debug_mode_1p3(self) -> None:
        raise RuntimeError("Developer access is needed to enter debug mode.")

    def enter_debug_mode_2p0(self) -> None:
        raise RuntimeError("Developer access is needed to enter debug mode.")


class FakeSPURunner(SPURunner):
    def __init__(self, *args, **kwargs):
        """just a SPURunner with fake_connection set true, useful if there's not a convenient way to pass args"""
        super().__init__(*args, fake_connection=True, **kwargs)
