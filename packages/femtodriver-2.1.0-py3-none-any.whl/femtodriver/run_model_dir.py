#!/usr/bin/env python
"""Run femtodrive on every .pt model in a directory (like production_fqirs)

Accepts the same options as the femtodrive CLI, except the positional 'model'
is replaced with 'model_dir'.  All femtodrive flags are parsed by
Femtodriver._parse_args() directly, so this script stays in sync with the CLI
automatically.

Claude did this

Example
-------
    python run_model_dir.py production_fqirs --runners fqir,fasmir --n-frames 4
"""

import itertools
import logging
import re
import sys
import threading
import time
import traceback
from pathlib import Path

from colorama import Fore, Style, init as colorama_init

from femtodriver.femtodrive import Femtodriver

colorama_init()

logger = logging.getLogger(__name__)

_W = 72  # report width


# ── helpers ──────────────────────────────────────────────────────────────────


def _strip_ansi(s: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*m", "", s)


class _Spinner:
    """Braille spinner that runs in a background thread."""

    _FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, prefix: str, stream):
        self._prefix = prefix
        self._stream = stream
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *_):
        self._stop.set()
        self._thread.join()
        # blank the spinner character so the caller can overwrite the line
        self._stream.write(f"\r{_strip_ansi(self._prefix)}  \r")
        self._stream.flush()

    def _run(self):
        for frame in itertools.cycle(self._FRAMES):
            if self._stop.is_set():
                break
            self._stream.write(f"\r{self._prefix}  {Fore.CYAN}{frame}{Style.RESET_ALL}")
            self._stream.flush()
            time.sleep(0.08)


# ── argument parsing ──────────────────────────────────────────────────────────


def _parse_args(argv):
    parser = Femtodriver._make_parser()

    for action in parser._actions:
        if action.dest == "model":
            action.help = "directory containing .pt FQIR files (searched recursively)"
            action.metavar = "model_dir"
            break

    parser.add_argument(
        "--log-dir",
        default="femtodrive_logs",
        help="directory for per-model log files (default: femtodrive_logs)",
    )

    args = parser.parse_args(argv)

    if not args.model:
        parser.error("model_dir is required")

    return args


# ── per-model run ─────────────────────────────────────────────────────────────


def _run_one(model_path: Path, args, log_path: Path) -> dict:
    """Run femtodrive on one model; always returns a result dict (never raises)."""
    result = {
        "model": model_path.name,
        "log": str(log_path),
        "pass": False,
        "error": None,
    }

    log_file = open(log_path, "w")
    orig_stdout, orig_stderr = sys.stdout, sys.stderr

    sys.stdout = sys.stderr = log_file

    # StreamHandlers store a direct stream reference — patch them too
    root = logging.getLogger()
    redirected: list[tuple[logging.StreamHandler, object]] = []
    for handler in root.handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(
            handler, logging.FileHandler
        ):
            if handler.stream in (orig_stdout, orig_stderr):
                redirected.append((handler, handler.stream))
                handler.stream = log_file

    try:
        with Femtodriver(
            debug=args.debug,
            force_femtocrux_compile=args.force_femtocrux_compile,
            force_femtocrux_sim=args.force_femtocrux_sim,
        ) as fd:
            args_dict = {
                k: v
                for k, v in vars(args).items()
                if k not in ("log_dir", "model_name")
            }
            args_dict["model"] = str(model_path)
            args_dict["model_name"] = model_path.stem

            run_result = fd.run(**args_dict)

        if isinstance(run_result, dict) and "pass" in run_result:
            result["pass"] = run_result["pass"]
        else:
            result["pass"] = True

    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
        print(traceback.format_exc(), file=log_file)
    finally:
        sys.stdout, sys.stderr = orig_stdout, orig_stderr
        for handler, orig_stream in redirected:
            handler.stream = orig_stream
        log_file.close()

    return result


# ── report ────────────────────────────────────────────────────────────────────


def _status_tag(r: dict, color=True) -> str:
    if r["error"]:
        tag = "! ERROR"
        return (Fore.YELLOW + Style.BRIGHT + tag + Style.RESET_ALL) if color else tag
    elif r["pass"]:
        tag = "✓ PASS"
        return (Fore.GREEN + Style.BRIGHT + tag + Style.RESET_ALL) if color else tag
    else:
        tag = "✗ FAIL"
        return (Fore.RED + Style.BRIGHT + tag + Style.RESET_ALL) if color else tag


def _print_report(results: list, log_dir: Path) -> int:
    passed = sum(1 for r in results if r["pass"] and not r["error"])
    failed = sum(1 for r in results if not r["pass"] and not r["error"])
    errored = sum(1 for r in results if r["error"])
    total = len(results)

    name_w = max(len(r["model"]) for r in results) + 2

    def _build(color: bool) -> str:
        DIM = Style.DIM if color else ""
        RESET = Style.RESET_ALL if color else ""
        BOLD = Style.BRIGHT if color else ""
        CYAN = Fore.CYAN if color else ""

        bar = "═" * _W
        thin = "─" * _W
        rows = []
        rows.append("")
        rows.append(f"{BOLD}{bar}{RESET}")
        rows.append(f"{BOLD}{'RESULTS SUMMARY':^{_W}}{RESET}")
        rows.append(f"{BOLD}{bar}{RESET}")

        for r in results:
            tag = _status_tag(r, color)
            extra = f"  {DIM}{r['error']}{RESET}" if r["error"] else ""
            rows.append(f"  {r['model']:<{name_w}}  {tag}{extra}")

        rows.append(f"{DIM}{thin}{RESET}")

        p = f"{Fore.GREEN if color else ''}{passed} passed{RESET}"
        f_ = f"{Fore.RED if color else ''}{failed} failed{RESET}"
        e = f"{Fore.YELLOW if color else ''}{errored} errors{RESET}"
        rows.append(f"  {p}  │  {f_}  │  {e}  │  {total} total")
        rows.append(f"{BOLD}{bar}{RESET}")

        if failed or errored:
            rows.append(f"\n{BOLD}Logs for failures:{RESET}")
            for r in results:
                if r["error"] or not r["pass"]:
                    rows.append(f"  {DIM}{r['model']}:{RESET} {r['log']}")

        rows.append(f"\n{CYAN}Logs:{RESET} {log_dir.resolve()}/")
        return "\n".join(rows)

    colored = _build(color=True)
    plain = _strip_ansi(_build(color=False))

    print(colored)
    (log_dir / "summary.txt").write_text(plain + "\n")

    return 0 if (failed == 0 and errored == 0) else 1


# ── main ──────────────────────────────────────────────────────────────────────


def main(argv=None):
    args = _parse_args(sys.argv[1:] if argv is None else argv)

    model_dir = Path(args.model)
    if not model_dir.is_dir():
        print(
            f"{Fore.RED}Error:{Style.RESET_ALL} '{model_dir}' is not a directory",
            file=sys.stderr,
        )
        return 1

    models = sorted(model_dir.rglob("*.pt"))
    if not models:
        print(
            f"{Fore.RED}Error:{Style.RESET_ALL} no .pt files found under '{model_dir}'",
            file=sys.stderr,
        )
        return 1

    log_dir = Path(args.log_dir)
    log_dir.mkdir(exist_ok=True)

    n = len(models)
    idx_w = len(str(n))
    print(
        f"\n{Style.BRIGHT}femtodrive batch run{Style.RESET_ALL}  "
        f"{Fore.CYAN}{model_dir}{Style.RESET_ALL}  "
        f"{Style.DIM}({n} model{'s' if n != 1 else ''}){Style.RESET_ALL}\n"
    )

    results = []
    for i, model_path in enumerate(models, 1):
        log_path = log_dir / f"{model_path.stem}.log"

        prefix = f"{Style.DIM}[{i:{idx_w}}/{n}]{Style.RESET_ALL} " f"{model_path.name}"
        term = sys.stdout  # capture before _run_one redirects it

        with _Spinner(prefix, term):
            result = _run_one(model_path, args, log_path)

        tag = _status_tag(result)
        extra = (
            f"  {Style.DIM}{result['error']}{Style.RESET_ALL}"
            if result["error"]
            else ""
        )
        print(f"\r{prefix}  {tag}{extra}")

        results.append(result)

    return _print_report(results, log_dir)


if __name__ == "__main__":
    sys.exit(main())
