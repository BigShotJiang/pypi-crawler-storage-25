#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

from copy import deepcopy
import logging
import os
import shutil
import zipfile
from typing import Any, Optional, Union
from pathlib import Path

import yaml
from scipy.io import wavfile
import numpy as np

import femtodriver
from femtodriver import CompiledData, SPURunner
from femtodriver.hal import get_ISA, get_spu_name
from femtocrux import CompilerClient, FQIRModel
from femtodriver.fqir_runner import FQIRArithRunner
from femtorun import IOSpec, FemtoRunner

logger = logging.getLogger(__name__)

from femtodriver.fx_runner import FXRunner


def compile(
    fqir: "FQIR",
    user_io_spec: IOSpec | None,
    femtocrux_client: CompilerClient,
    opt_profile: str | None = None,
    user_configuration: dict | None = None,
    memory_reservations: dict | None = None,
) -> tuple[dict[str, "IR"], dict[str, IOSpec]]:
    """Create IRs and IOSpecs from FQIR using femtocrux

    Arguments:
        fqir : input FQIR
        user_io_spec : IOSpec, or None to let the compiler infer it
        femtocrux_client : docker client object
        opt_profile : compiler optimization profile
        user_configuration : compiler configuration overrides
        memory_reservations : compiler memory reservation hints

    Returns:
        ({'fqir' : FQIR, 'hw' : CompiledData},
         {'fqir' : IOSpec, 'hw' : IOSpec})
    """
    compiled_data, io_spec, _ = _compile_with_fx(
        fqir,
        user_io_spec,
        femtocrux_client,
        opt_profile=opt_profile,
        user_configuration=user_configuration,
        memory_reservations=memory_reservations,
    )

    IRs = {
        "fqir": fqir,
        "hw": compiled_data,
    }
    io_specs = {
        "fqir": user_io_spec,
        "hw": io_spec,
    }

    return IRs, io_specs


def _compile_with_fx(
    fqir: "FQIR",
    user_io_spec: None | IOSpec,
    femtocrux_client: CompilerClient,
    opt_profile: str | None = None,
    user_configuration: dict | None = None,
    memory_reservations: dict | None = None,
) -> tuple[CompiledData, IOSpec, dict[str, "IR"]]:
    """calls FX to turn fqir into the zipfile
    returns CompiledData, {'fqir' : FQIR}
    """

    bitstream, iospec, memory_reservations = femtocrux_client.compile(
        FQIRModel(
            fqir,
            batch_dim=0,
            sequence_dim=1,
        ),
        iospec=user_io_spec,
        opt_profile=opt_profile,
        user_configuration=user_configuration,
        memory_reservations=memory_reservations,
    )

    compiled_data = CompiledData.read_from_zip(bitstream)

    # these manual updates are a little iffy
    compiled_data.iospec = iospec
    compiled_data.memory_reservations = memory_reservations

    return compiled_data, iospec, {"fqir": fqir}


def get_runners(
    IRs: dict[str, "IR"],
    io_specs: dict[str, IOSpec],
    femtocrux_client: CompilerClient,
    desired_runners: None | list[str] = None,
    # SPURunner
    spu_runner_platform: str = "evk2",
    spu_runner_kwargs: dict | None = None,
    # FXRunner
    compiler_args: dict | None = None,
    fx_input_period: float = 0.016,
    fx_runner_kwargs: dict | None = None,
) -> dict[str, FemtoRunner]:
    if spu_runner_kwargs is None:
        spu_runner_kwargs = {}
    if compiler_args is None:
        compiler_args = {}
    if fx_runner_kwargs is None:
        fx_runner_kwargs = {}

    if desired_runners is None:
        desired_runners = list(IRs.keys())

    FRs = {}
    for irname in desired_runners:
        io_spec = io_specs[irname]

        if irname == "fqir":
            FRs["fqir"] = FQIRArithRunner(IRs["fqir"], io_spec)
        elif irname == "fasmir":
            FRs["fasmir"] = FXRunner(
                IRs["fqir"],  # FX always takes fqir as input, will recompile
                compiler_client=femtocrux_client,
                input_padding=io_spec.input_padding,
                output_padding=io_spec.output_padding,
                compiler_args=compiler_args,
                input_period=fx_input_period,
                **fx_runner_kwargs,
            )
        elif irname == "hw":
            FRs["hw"] = SPURunner(
                IRs["hw"],  # CompiledData, has IOSpec in it
                platform=spu_runner_platform,
                **spu_runner_kwargs,
            )

    return FRs


def femto_compile(
    fqir: "FQIR",
    user_io_spec: IOSpec | None,
    opt_profile: str | None = None,
    user_configuration: dict | None = None,
    memory_reservations: dict | None = None,
) -> tuple[dict[str, "IR"], dict[str, IOSpec]]:
    """Create CompiledData and a dictionary with FemtoRunners from FQIR

    Arguments:
        fqir : input FQIR
        compiler_kwargs (optional) : dictionary of compiler options
        input_period (float, s) : for simulation metrics

    Returns:
        ({'fqir' : FQIR, 'fasmir' : FASMIR, 'fmir': FMIR, 'hw' : CompiledData},
         {'fqir', etc : IOSpecs for each})
    """
    user_io_spec_editable = deepcopy(user_io_spec)
    IRs, io_specs = _compile_with_fm(
        fqir,
        user_io_spec_editable,
        opt_profile=opt_profile,
        user_configuration=user_configuration,
        memory_reservations=memory_reservations,
    )

    return IRs, io_specs


def _compile_with_fm(
    fqir: "FQIR",
    user_io_spec: None | IOSpec,
    memory_reservations: dict | None = None,
    opt_profile: str | None = None,
    user_configuration: dict | None = None,
) -> tuple[dict[str, "IR"], dict[str, IOSpec]]:
    try:
        import femtomapper.user_api as fm_api
    except ImportError:
        raise ImportError(
            "tried to use femto_compile(). This is a FemtoAI-internal developer mode. "
            "Use compile() instead"
        )

    state, io_spec, reservations = fm_api.compile(
        fqir,
        user_iospec=user_io_spec,
        opt_profile=opt_profile,
        user_configuration=user_configuration,
    )

    compiled_data = extract_compiled_data_from_fasmir(state.fasmir, encrypt=True)
    compiled_data.iospec = io_spec
    compiled_data.memory_reservations = memory_reservations

    compiled_data_noenc = extract_compiled_data_from_fasmir(state.fasmir, encrypt=False)
    compiled_data_noenc.iospec = io_spec
    compiled_data_noenc.memory_reservations = memory_reservations

    IRs = {
        "fqir": fqir,
        "fmir": state.fmir,
        "fasmir": state.fasmir,
        "hw": compiled_data,
        "hw_noenc": compiled_data_noenc,
    }
    io_specs = {
        "fqir": user_io_spec,
        "fmir": io_spec,
        "fasmir": io_spec,
        "hw": io_spec,
        "hw_noenc": io_spec,
    }

    return IRs, io_specs


def extract_compiled_data_from_fasmir(
    fasmir_or_fasmtxt: Union["FASMIR", str],
    io_spec=None,
    insert_debug_stores: bool = False,
    encrypt: bool = True,
):
    """emit memory images from fasmir"""

    try:
        from femtobehav import assemble
        from femtobehav.fasmir.fasmir_builder import FASMIRBuilder
    except ImportError:
        raise ImportError(
            "tried to use extract_compiled_data_from_fasmir(). "
            + "This is a FemtoAI-internal developer feature."
        )

    # convert fasmtxt if needed
    if isinstance(fasmir_or_fasmtxt, str):
        fasmir = FASMIRBuilder().build(fasmir_or_fasmtxt)
    else:
        fasmir = fasmir_or_fasmtxt

    # debug stores, calls the debugger
    if insert_debug_stores:
        from femtodriver_dev.debugger import SPUDebugger

        SPUDebugger.insert_debug_stores(fasmir)

    encryption_key_idx = 0
    encryption_key_salt = 0
    mem_contents, metadata = assemble(
        fasmir,
        encrypt=encrypt,
        encryption_key_idx=encryption_key_idx,
        encryption_key_salt=encryption_key_salt,
    )

    # by default, give it a MIMO IOSpec, can be overridden later
    if io_spec is None:
        io_spec = fasmir.get_simple_IOSpec()

    # make cd from metadata yaml and images
    compiled_data = CompiledData(
        iospec=io_spec,
        metadata=metadata,
        mems_per_core=mem_contents,
        encrypted=encrypt,
        ISA=get_ISA(),
    )

    return compiled_data


def femto_get_runners(
    IRs: dict[str, "IR"],
    io_specs: dict[str, IOSpec],
    desired_runners: None | list[str] = None,
    # SPURunner
    spu_runner_platform: str = "evk2",
    spu_runner_kwargs: dict = None,
    # SimRunner
    sim_runner_input_period: float = 0.016,
    sim_runner_kwargs: dict | None = None,
) -> dict[str, FemtoRunner]:
    try:
        from femtobehav.sim.runner import SimRunner
    except ImportError:
        raise ImportError(
            "tried to use femto_get_runners(). This is a FemtoAI-internal developer mode. "
            + "Use get_runners() instead"
        )

    if spu_runner_kwargs is None:
        spu_runner_kwargs = {}
    if sim_runner_kwargs is None:
        sim_runner_kwargs = {}

    # we can pass in all the IRs
    # but then trim which runners we create
    # important for debug mode with HW, but no FASMIR sim
    if desired_runners is None:
        desired_runners = IRs.keys()

    # make runners
    FRs = {}
    for irname in desired_runners:
        IR = IRs[irname]
        io_spec = io_specs[irname]

        if irname == "fqir":
            FR = FQIRArithRunner(IR, io_spec)
        elif irname == "fasmir":
            FR = SimRunner(
                IR,
                io_spec,
                **sim_runner_kwargs,
            )
        elif irname in ["hw", "hw_noenc"]:
            FR = SPURunner(
                IR,  # ComipiledData, has IOSpec in it
                platform=spu_runner_platform,
                **spu_runner_kwargs,
            )
            if not IR.encrypted:
                fasmir = IRs.get("fasmir", None)
                FR.attach_debugger(fasmir)

        FRs[irname] = FR

    return FRs


def write_programming_files(
    IRs,
    write_dir=None,
    model_name: str | None = None,
    model_type: str | None = None,
    model_version: str | None = None,
) -> dict[str:Path]:
    """returns model_dir, femtofile, metadata, iospec"""

    if write_dir is None:
        write_dir = "progfiles"

    if "hw" not in IRs and "hw_noenc" not in IRs:
        raise ValueError("need CompiledData (IRs['hw']) to write_programming_files()")

    # amend model_name with isa

    for hw in ["hw_noenc", "hw"]:
        if hw not in IRs:
            continue

        compiled_data = IRs[hw]

        model_spu = f"{model_name}_{get_spu_name()}"
        enc_str = "" if compiled_data.encrypted else "_noenc"
        model_dir = os.path.join(write_dir, f"{model_spu}{enc_str}")
        debug_dir = os.path.join(model_dir, "debug")

        # os.rmdir(model_dir, missing_ok=True)
        os.makedirs(model_dir, exist_ok=True)
        os.makedirs(debug_dir, exist_ok=True)

        femtofile = compiled_data.to_femtofile(
            femtodriver_version=femtodriver.__version__,
            model_type=model_type,
            model_name=model_name,
            model_version=model_version,
        )

        # append the version to the output file
        femtofile_path, femtofile_size = femtofile.export_file(
            export_path=model_dir, file_name=model_spu
        )

        femtofile_path = Path(femtofile_path)

        # os.rmdir(model_dir, missing_ok=True)
        # dump metadata yaml
        yamltxt = yaml.dump(compiled_data.metadata, sort_keys=False)
        meta_fname = os.path.join(model_dir, f"{model_spu}.yaml")
        with open(meta_fname, "w") as f:
            f.writelines(yamltxt)

        # dump final iospec
        io_spec_fname = os.path.join(model_dir, f"{model_spu}.yaml")
        compiled_data.iospec.write_spec_to_file(io_spec_fname)

        logger.info(
            f"Exported model femtofile in: {femtofile_path} ({round(femtofile_size / 1024)}KB)"
        )
        logger.info(f"Exported model metadata in: {meta_fname}")
        logger.info(f"Exported model iospec in: {io_spec_fname}")

        # dump fqir
        if "fqir" in IRs:
            fname = os.path.join(debug_dir, f"{model_spu}.fqirtxt")
            fqir = IRs["fqir"]
            with open(fname, "w") as f:
                f.write(str(fqir))

        # dump fasmtxt
        if "fasmir" in IRs:
            fname = os.path.join(debug_dir, f"{model_spu}.fasmtxt")
            fasmir = IRs["fasmir"]
            with open(fname, "w") as f:
                f.write(str(fasmir))

    return {
        "model_dir": model_dir,
        "femtofile": femtofile_path,
        "meta": meta_fname,
        "io_spec": io_spec_fname,
    }


def write_reference_io_files(
    write_dir,
    inputs,
    outputs,
    spu_bits=16,
    spu_chan=1,
    wav_bits=32,
    wav_chan=2,
    wav_rate=16000,
) -> None:
    """write inputs and outputs that the model should return"""
    refio_dir = os.path.join(write_dir, "ref_io")
    os.makedirs(refio_dir, exist_ok=True)

    for varname, vals in (inputs | outputs).items():
        txtfname = os.path.join(refio_dir, f"{varname}.csv")
        np.savetxt(txtfname, vals, delimiter=",", fmt="%d")
        logger.info(f"Exported reference io file: {txtfname}")

        # save as a wav, too, even if it isn't audio
        wavfname = os.path.join(refio_dir, f"{varname}.wav")
        vals = (vals).flatten().astype(np.int32)

        # pad for unused channels
        assert spu_chan == 1
        vals_pad = np.zeros((vals.shape[0], wav_chan), dtype=np.int32)
        vals_pad[:, 0] = vals
        vals = vals_pad

        vals = vals << (wav_bits - spu_bits)
        wavfile.write(wavfname, wav_rate, vals)
