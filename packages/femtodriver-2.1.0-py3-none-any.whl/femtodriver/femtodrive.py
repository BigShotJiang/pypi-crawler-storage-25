#!/usr/bin/env python
#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

"""
1. New paradigm:
    python API:
        fd.compile()
        fd.simulate()
        fd.compare()
        fd.execute_runner()
        fd.generate_audio_inputs()
        fd.cleanup_docker_containers()
        fd.get_docker_logs()
    cli:
        fd.run()
2. Only 1 docker client that is shared. Use a context manager so we clean up properly
3. More functional stype functions that have clear input args and returns
4. Got rid of passing args object everywhere
5. all functions but especially run_comparisons broken down into smaller bits
6. Docstrings/typehints
7. print statements are now logger statements
8. Keep objects in memory instead of writing to disk all the time
9. Better docstrings
10. Write more unit tests
"""

import atexit
import argparse
import fmot
import importlib
import logging
import os
import pickle
import sys
from argparse import (
    RawTextHelpFormatter,
)  # allow carriage returns in help strings, for displaying model options
from colorama import Fore, Style
from pathlib import Path

import docker
import numpy as np
import torch
import yaml
from femtocrux import CompilerClient
from femtorun import DummyRunner, FemtoRunner, IOSpec
from fmot.fqir import GraphProto
from fmot import iospec_from_fqir
from scipy.io import wavfile

import femtodriver
from femtodriver import CompiledData, SPURunner
from femtodriver.fx_runner import FXRunner
from femtodriver.fqir_runner import FQIRArithRunner
from femtodriver.compile_runners import (
    femto_compile,
    write_programming_files,
    compile as fx_compile,
)
from femtodriver.util.print_header import print_header
from femtodriver.util.run_util import process_single_outputs
from femtodriver.util.metrics_util import dictify_string_metrics
from femtodriver.util.model_options_file import get_options_path, load_model_options
from femtodriver.plugins.evk2_plugin import Evk2Plugin
from pathlib import Path

# Configure the logging format
logging.basicConfig(
    format="[%(asctime)s][%(name)s][%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
    # level=logging.DEBUG,
)
logger = logging.getLogger(__name__)

try:
    from femtobehav.sim.runner import SimRunner  # for comparison
    from femtomapper.run import FMIRRunner

    DEV_MODE = True
except ImportError:
    DEV_MODE = False
    FMIRRunner = object
    SimRunner = object


if DEV_MODE:
    TOP_LEVEL_PACKAGE_DIR = Path(femtodriver.__file__).parent.parent.parent
    MODEL_SOURCE_DIR = TOP_LEVEL_PACKAGE_DIR / Path("models")
    # will only work if installed locally with -e
    if os.path.exists(MODEL_SOURCE_DIR):
        MODEL_SOURCE_DIR = str(MODEL_SOURCE_DIR)
    else:
        MODEL_SOURCE_DIR = None
else:
    MODEL_SOURCE_DIR = None


def check_dev_mode(feat):
    if not DEV_MODE:
        raise RuntimeError(
            f"{feat} is a FS-only feature, requires internal packages. Exiting"
        )


class Femtodriver:
    def __init__(
        self,
        model_source_dir: str | None = MODEL_SOURCE_DIR,
        debug: bool = False,
        force_femtocrux_compile: bool = False,
        force_femtocrux_sim: bool = False,
    ):
        """
        @param model_source_dir
        @param debug: the log level of the debugger True sets level to DEBUG otherwise INFO
        @param force_femtocrux_compile: use femtocrux to compile. Internal use.
        @param force_femtocrux_sim: whether to force the simulation to use femtocrux. Internal use.
        """
        self.model_source_dir = model_source_dir

        self.model_dir: str | None = None  # the output dir for the model
        self.modelname = None
        self.compiled_data = None
        self.fqir = None
        self.fasmir = None
        self.fmir = None

        # for internal data comparison with SPU, which variables to extract
        self.spu_debug_vars = []

        # important internal objs
        self.compare_runners: list[FemtoRunner]

        # recording of simulation metrics
        self.sim_metrics: dict

        self.femtocrux_client: CompilerClient | None = None
        self.using_cli: bool = False
        self.spu_runner: SPURunner = None
        self.force_femtocrux_compile: bool = force_femtocrux_compile
        self.force_femtocrux_sim: bool = force_femtocrux_sim
        self.compiler_kwargs = {}
        self.opt_profile = None
        self.iospec = None

        self._suppress_import_debug(debug)

    def __enter__(self):
        """
        Enter definition for context manager.
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        When exiting the Context Manager, clean up the docker container
        """
        if exc_type:
            logger.error(f"Exception type: {exc_type}")
            logger.error(f"Exception value: {exc_val}")
            logger.error(f"Traceback: {exc_tb}")

        # Always clean up the Docker client, regardless of any
        if self.femtocrux_client:
            self.femtocrux_client.close()

        # Return False to propagate the exception, if any
        return False

    @staticmethod
    def _make_parser():
        """Build and return the argument parser (without parsing)."""
        parser = argparse.ArgumentParser(
            formatter_class=RawTextHelpFormatter,
            description="run a pickled FASMIR or FQIR on hardware. Compare with output of FB's SimRunner\n\n"
            + "Useful recipes:\n"
            + "----------------------\n"
            + "Run on hardware, default comparisons with full debug (fasmir):\n"
            + "\tpython run_from_pt.py ../models/modelname --hardware=zynq --runners=fasmir --debug --debug_vars=all\n\n"
            + "Generate SD (no board/cable needed):\n"
            + "\tpython run_from_pt.py ../models/modelname\n\n"
            + "Run simulator (no board/cable needed, ignore the comparison):\n"
            + "\tpython run_from_pt.py ../models/modelname --runners=fasmir\n\n",
        )

        parser.add_argument(
            "model",
            nargs="?",
            help="model to run. " + Femtodriver._model_helpstr(),
        )
        parser.add_argument(
            "--opt-profile", default=None, help="Compiler opt_profile to use."
        )
        parser.add_argument(
            "--model-options-file",
            default=None,
            help=".yaml with run options for different models (e.g. compiler options)."
            "Default is femtodriver/femtodriver/models/options.yaml",
        )
        parser.add_argument(
            "--output-dir",
            default="model_datas",
            help="where to write fasmir, fqir, programming images, programming streams, etc",
        )
        parser.add_argument(
            "--n-frames",
            default=2,
            type=int,
            help="number of random sim inputs to drive in",
        )
        parser.add_argument(
            "--input-file",
            default=None,
            help="file with inputs to drive in. Expects .npy from numpy.save."
            "Expecting single 2D array of values, indices are (timestep, vector_dim)",
        )
        parser.add_argument(
            "--input-sample-indices",
            default=None,
            help="lo,hi indices to run from input_file",
        )
        parser.add_argument(
            "--force-femtocrux-compile",
            default=False,
            action="store_true",
            help="force femtocrux as the compiler, even if FS internal packages present",
        )
        parser.add_argument(
            "--force-femtocrux-sim",
            default=False,
            action="store_true",
            help="force femtocrux as the simulator, even if FS internal packages present",
        )
        parser.add_argument(
            "--hardware",
            default="fakezynq",
            help="primary runner to use: (options: zynq, fakezynq, redis, evk2)",
        )
        parser.add_argument(
            "--runners",
            default="",
            help="which runners to execute. If there are multiple, compare each of them to the first, "
            "comma-separated. Options: hw, fasmir, fqir, fmir, fakehw",
        )
        parser.add_argument(
            "--debug-vars",
            default=None,
            help="debug variables to collect and compare values for, comma-separated (no spaces), or 'all'",
        )
        parser.add_argument(
            "--debug-vars-fname",
            default=None,
            help="file with a debug variable name on each line",
        )
        parser.add_argument(
            "--debug", default=False, action="store_true", help="set debug log level"
        )
        parser.add_argument(
            "--noencrypt",
            default=False,
            action="store_true",
            help="don't encrypt programming files",
        )
        parser.add_argument(
            "--input-period",
            default=0.016,
            type=float,
            help="simulator input period for energy estimation. No impact on runtime. Floating point seconds",
        )
        parser.add_argument(
            "--dummy-output-file",
            default=None,
            help="for fakezynq, the values that the runner should reply with. Specify a .npy for a single variable",
        )
        parser.add_argument(
            "--cleanup-docker",
            action="store_true",
            help="special argument to cleanup running femtocrux docker containers",
        )
        parser.add_argument(
            "--hardware-address",
            default=None,
            help="when using a real zynq board, specify ip address or hostname to connect to.",
        )
        parser.add_argument(
            "--list-connected-hardware",
            action="store_true",
            help="lists SPU-001 hardware connected",
        )
        parser.add_argument(
            "--iospec-file",
            default="",
            type=str,
            help="Path to iospec yaml file",
        )
        return parser

    @staticmethod
    def _parse_args(argv):
        """returns argparse object and sets self.args
        also sets:
            self.comparisons
        """
        parser = Femtodriver._make_parser()
        args = parser.parse_args(argv)

        # Logic to handle special argument
        if args.cleanup_docker:
            print(
                "Special argument --cleanup-docker provided, input_file is not required."
            )
        elif args.list_connected_hardware:
            print(
                "Special argument --list-connected-hardware provided, input_file is not required."
            )
            return args
        elif not args.model:
            print("Error: model is required unless --cleanup-docker is run.")
            parser.print_help()
            sys.exit(1)

        args.model_name = Path(args.model).stem

        return args

    def _get_compiler_env_for_docker(self, docker_kwargs):
        # get compiler version
        hwcfg = os.getenv("FS_HW_CFG")
        if hwcfg is None:
            hwcfg = "spu1p3v1.dat"
        if hwcfg is not None:
            if hwcfg.startswith("spu1p3v1"):
                version = {"FS_HW_CFG": hwcfg}
            elif hwcfg.startswith("spu2p0v1"):
                version = {"FS_HW_CFG": hwcfg}
            elif hwcfg.startswith("spu2p1v1"):
                version = {"FS_HW_CFG": hwcfg}
            else:
                raise ValueError(
                    f"unknown FS_HW_CFG value {hwcfg}. "
                    "Must be spu1p3v1.dat or spu2p0v1.dat for SPU-001 or SPU-150 prototype,"
                    "respectively"
                )
        else:
            # assume default of 1p3
            version = {"FS_HW_CFG": "spu1p3v1.dat"}
            logger.warning(
                "FS_HW_CFG not explicitly set. Assuming default of ISA 1p3v1 (mass production chip)"
            )
            logger.warning(
                "  set 'export FS_HW_CFG=spu1p3v1.dat' for mass production chip"
            )
            logger.warning("  set 'export FS_HW_CFG=spu1p2v1.dat' for TC2")
            yn = input(
                "\nEnter 'y' if the default of ISA 1p3 is OK, otherwise set the environment variable and try again: "
            )
            if yn != "y":
                exit(-1)

        docker_kwargs["environment"].update(version)

    def _load_fasmir_pickle(self, model_path):
        fasmir = pickle.load(open(model_path, "rb"))
        if fasmir.__class__.__name__ not in ["FASMIR", "SteerableFASMIR"]:
            raise RuntimeError(f"supplied model {model_path} didn't contain FASMIR")
        return fasmir

    def _load_fqir_torchpickle(self, model_path):
        fqir = fmot.load(model_path, map_location=torch.device("cpu"))
        if fqir.__class__.__name__ not in ["GraphProto"]:
            raise RuntimeError(f"supplied model {model_path} didn't contain FQIR")
        return fqir

    def load_model(
        self, model: str | Path | GraphProto, name: str | None = "fqir"
    ) -> tuple:
        """
        Load a model from a file or in memory fmot fqir GraphProto.

        @param: model: a path to a model fqir on disk or the fqir in memory GraphProto
        @param: name: a string name for the model. Useful only with in memory GraphProto

        @returns tuple of modelname, fqir, fmir, fasmir
        """
        model_path = "resources/identity.pt"
        if isinstance(model, GraphProto):
            self.modelname = name
            self.fqir = model
            return self.modelname, self.fqir, None, None
        elif isinstance(model, Path):
            model_path = str(model)
        elif isinstance(model, str):
            model_path = model

        # get "hello world"/identity out of the way, it's in the package
        if model_path == "LOOPBACK":
            model_path = importlib.resources.files("femtodriver").joinpath(
                "resources/identity.pt"
            )
            self.modelname = "LOOPBACK"
            self.fqir = fmot.load(model_path, map_location=torch.device("cpu"))
            return self.modelname, self.fqir, self.fmir, self.fasmir

        model_with_ext = os.path.basename(os.path.expanduser(model_path))
        self.modelname, model_ext = os.path.splitext(model_with_ext)

        if model_ext in [".pt", ".pth"]:
            # FQIR
            self.fqir = self._load_fqir_torchpickle(model_path)
        elif model_ext == ".pck":
            # FASMIR
            raise ValueError(
                "Femtodriver no longer supports FASMIR pickle input. Use standalone scripts"
            )
        elif model_ext == ".femto":
            # from femtofile
            self.compiled_data = CompiledData.read_from_femtofile(
                femtofile_path=model_path
            )
        else:
            raise ValueError(
                f"invalid model extension. Got {model_ext}. Need one of: .pt/.pth (FQIR pickle) or .pck (FASMIR pickle)"
            )
        return self.modelname, self.fqir, self.fmir, self.fasmir

    def compile_metadata(
        self,
        iospec: IOSpec,
        opt_profile: str | None = None,
        user_configuration: dict | None = None,
        memory_reservations: dict | None = None,
        noencrypt: bool = False,
    ) -> CompiledData:
        """
        Compile the model and create CompiledData.
        Will also set self.IRs and self.iospecs, which could include FQIR, FASMIR, etc

        also may generate new self.fmir, self.fasmir if starting w/ FQIR

        @param: noencrypt: use encryption or not (only useful internally)

        @returns: CompiledData object
        """
        if noencrypt and not DEV_MODE:
            raise RuntimeError(
                "noencrypt requires DEV_MODE (femtomapper). Not supported with femtocrux."
            )

        if self.compiled_data is not None:
            logger.info(
                "Skipping compilation because we started from compiled femtofile."
            )
            if self.compiled_data.encrypted:
                irname = "hw"
            else:
                irname = "hw_noenc"
            self.IRs = {irname: self.compiled_data}
            self.iospecs = {irname: self.compiled_data.iospec}

            return self.compiled_data

        else:
            # docker kwargs
            docker_kwargs = {"environment": {}}
            self._get_compiler_env_for_docker(
                docker_kwargs=docker_kwargs
            )  # get compiler version

            if DEV_MODE and not self.force_femtocrux_compile:
                compiler_name = "femtomapper"
            else:
                compiler_name = "femtocrux"
                self.femtocrux_client = CompilerClient(docker_kwargs)
                atexit.register(self.femtocrux_client.on_exit)

            if compiler_name == "femtomapper":
                IRs, io_specs = femto_compile(
                    self.fqir,
                    user_io_spec=iospec,
                    opt_profile=opt_profile,
                    user_configuration=user_configuration,
                    memory_reservations=memory_reservations,
                )
            elif compiler_name == "femtocrux":
                IRs, io_specs = fx_compile(
                    self.fqir,
                    user_io_spec=iospec,
                    femtocrux_client=self.femtocrux_client,
                    opt_profile=opt_profile,
                    user_configuration=user_configuration,
                    memory_reservations=memory_reservations,
                )
            self.IRs = IRs
            self.iospecs = io_specs

            self.fasmir = IRs.get("fasmir", None)
            self.fqir = IRs.get("fqir", None)
            self.fmir = IRs.get("fmir", None)

        if noencrypt:
            return self.IRs["hw_noenc"]
        else:
            return self.IRs["hw"]

    @staticmethod
    def _get_runner_kwargs(noencrypt, hardware):
        runner_kwargs: dict[str, str | bool] = {"encrypt": not noencrypt}
        if hardware == "zynq":  # hard SPU plugged into FPGA
            runner_kwargs["platform"] = "zcu104"
            runner_kwargs["program_pll"] = True
            runner_kwargs["fake_connection"] = False

        elif hardware == "fpgazynq":  # soft SPU inside FPGA logic
            runner_kwargs["platform"] = "zcu104"
            runner_kwargs["program_pll"] = False
            runner_kwargs["fake_connection"] = False

        elif hardware == "redis":  # redis-based simulation (questa)
            runner_kwargs["platform"] = "redis"
            runner_kwargs["program_pll"] = True
            runner_kwargs["fake_connection"] = False

        elif hardware == "fakezynq":  # e.g. for generating EVK program
            runner_kwargs["platform"] = "zcu104"
            runner_kwargs["program_pll"] = False
            runner_kwargs["fake_connection"] = True

        elif hardware == "fakeredis":  # e.g. for integration test
            runner_kwargs["platform"] = "redis"
            runner_kwargs["program_pll"] = False
            runner_kwargs["fake_connection"] = True

        elif hardware == "evk2":  # e.g. for integration test
            runner_kwargs["platform"] = "evk2"
            runner_kwargs["program_pll"] = True
            runner_kwargs["fake_connection"] = False
        else:
            raise RuntimeError(f"Unknown runner {hardware}")

        return runner_kwargs

    def create_SPURunner(
        self,
        compiled_data: CompiledData,
        meta_dir: str,  # unused
        noencrypt: bool = False,
        hardware: str = "fakezynq",
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        dummy_output_file: str | None = None,
        hardware_address: str | None = None,
    ) -> SPURunner:
        """instantiates spu_runner = SPURunner()
        handles debug-vars-related options
        and fake outputs/recv vals
        returns spu_runner
        """

        runner_kwargs = self._get_runner_kwargs(noencrypt=noencrypt, hardware=hardware)

        if not os.path.exists(self.io_records_dir):
            os.makedirs(self.io_records_dir)

        # make SPURunner and SimRunner to compare it to
        fake_hw_recv_vals = None
        if dummy_output_file is not None:
            fake_hw_recv_vals = np.load(dummy_output_file)

        # collect debug vars
        self.spu_debug_vars = []
        if debug_vars_fname is not None:
            varf = open(debug_vars_fname, "r")
            self.spu_debug_vars += varf.readlines()

        if debug_vars is not None:
            self.spu_debug_vars += debug_vars.split(",")
        try:
            spu_runner = SPURunner(
                compiled_data,
                fake_hw_recv_vals=fake_hw_recv_vals,
                debug_vars=self.spu_debug_vars,
                io_records_dir=self.io_records_dir,
                hardware_address=hardware_address,
                **runner_kwargs,
            )
        except Exception as e:
            raise e

        if DEV_MODE:
            spu_runner.attach_debugger(self.fasmir)

        # fill in for 'all' debug vars option
        # not all runners can necesarily take 'all' as a debug vars arg
        if debug_vars == "all" or debug_vars == ["all"]:
            self.spu_debug_vars = spu_runner.debug_vars

        return spu_runner

    def generate_audio_inputs(
        self,
        input: str | np.ndarray | None = None,
        spu_runner: SPURunner | None = None,
        n_frames: int = 2,
        input_sample_indices: list | None = None,
    ) -> dict[str, np.ndarray]:
        """
        Read inputs from a file or generate some fake inputs for testing the model in simulation.

        If no input_file is specified, you can specify n_frames to generate fake inputs for

        @param: spu_runner: The FemtoRunner to use, could be hw, fmir, fqir, fasmir
        @param: input_file: the wav file to load into a np.ndarray or the npy file to load a generalized input
        @param: n_frames: allows you to specify length of fake input in frames if not using a wav file input
        @param: input_sample_indices: the slice of the input to simulate. Useful if the input is long to make
                simulation faster.

        @returns A dictionary of the form {"varname": np.ndarray} See the docs about how inputs to models are handled
        """

        if spu_runner is None:
            spu_runner = self.spu_runner

        # if still None, make a fake one
        if spu_runner is None:
            if self.compiled_data is None:
                raise RuntimeError(
                    "can't generate_audio_inputs() with no supplied shape without compiling first"
                )

            spu_runner = self._create_fake_spu_runner()

        N = n_frames

        if input is None:
            np.random.seed(0)
            shaped_inputs = spu_runner.make_fake_inputs(N, style="sawtooth", scale=64)
            return shaped_inputs
        elif isinstance(input, np.ndarray):
            input_vals = self._create_shaped_input_from_ndarray(input, spu_runner)
        elif input.endswith(".wav"):
            input_vals = self._create_shaped_input_from_wav(input, spu_runner)
        elif input.endswith(".npy"):
            input_vals = np.load(input)
        else:
            raise RuntimeError(
                "unsupported file format for --input_file, only .wav and .npy is supported"
            )

        # Create a fake input to get the correct shape and then fill it with the input_vals from above.
        N = input_vals.shape[0]
        shaped_inputs = spu_runner.make_fake_inputs(N, style="random")

        if len(shaped_inputs) > 1:
            raise RuntimeError("can only support one input via file")
        for k, v in shaped_inputs.items():
            shaped_inputs[k] = input_vals

        # trim to sample range, if supplied
        if input_sample_indices is not None:
            lo, hi = input_sample_indices[0], input_sample_indices[1]
            for k, v in shaped_inputs.items():
                shaped_inputs[k] = shaped_inputs[k][int(lo) : int(hi)]

        return shaped_inputs

    def execute_runner(
        self,
        requested_runner: str,
        model_inputs: dict[str, np.ndarray] | list[dict[str, np.ndarray]],
        noencrypt: bool = False,
        hardware: str = "fakezynq",
        input_period: float = 0.016,
        dummy_output_file: str | None = None,
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        hardware_address: str | None = None,
    ) -> tuple[dict, FemtoRunner]:
        """
        Runs an input through a given spu_runner. Runners could be hw, fasmir, fmir, fqir.
        The input could be a fake autogenerated random input or an np.ndarray. Use the helper
        function generate_audio_inputs() to turn wav files into the correct shape ndarray.

        @param: requested_runner: a string runner out of set({"hw", "fasmir", "fmir", "fqir"})
        @param: model_inputs: dict[str, np.ndarray] | list[dict[str, np.ndarray]]
        @param: input_period: the input period processing time for a frame in seconds

        @returns: returns a tuple
                    element1: dictionary which contains the internals activations and outputs of a runner.
                    element2: the runner object
        """

        femto_runner, runner_name = self.create_runner(
            requested_runner=requested_runner,
            spu_runner=self.spu_runner,
            fqir=self.fqir,
            sim_fasmir=self.fasmir,
            sim_fmir=self.fmir,
            noencrypt=noencrypt,
            hardware=hardware,
            input_period=input_period,
            dummy_output_file=dummy_output_file,
            debug_vars=debug_vars,
            debug_vars_fname=debug_vars_fname,
            hardware_address=hardware_address,
        )

        femto_runner.reset()
        output_vals, internal_vals, _ = femto_runner.run(model_inputs)
        outputs = {runner_name: output_vals}
        internals = {runner_name: internal_vals}
        femto_runner.finish()

        result = {
            "compare_str": "Single Runner",
            "pass": "No Comparisons",
            "internals": internals,
            "outputs": outputs,
        }

        return result, femto_runner

    def _get_runner_metrics(self, runner, input_period: float = 0.016) -> dict:
        """
        Get the metrics from the FXRunner or the SimRunner

        @returns: the sim metrics as a string
        """
        metrics = {}
        if runner.__class__.__name__ == "SimRunner":
            logger.info("Found a SimRunner")

            metrics = runner.get_metrics(
                input_period=input_period,
                as_yamlable=True,
            )
            self.sim_metrics = metrics

        elif runner.__class__.__name__ == "FXRunner":
            logger.info("found Femtocrux's simulator.")
            metrics = dictify_string_metrics(runner.sim_report)

        return metrics

    def _dump_pickles(self, inputs, outputs, internals):
        """
        Optionally dump pickles
        """
        debug_dir = os.path.join(self.model_dir, "debug")
        os.makedirs(debug_dir, exist_ok=True)

        pickle.dump(
            {"in": inputs, "out": outputs, "internals": internals},
            open(os.path.join(debug_dir, "runner_inout.pck"), "wb"),
        )

        logger.info(
            f"runner inputs, outputs, and internal variables pickles saved to {os.path.join(debug_dir, 'runner_inout.pck')}"
        )
        logger.info(
            "  unpickle with vals = pickle.load(open('runner_inout.pck', 'rb'))"
        )
        logger.info("  then vals['in'|'out'|'internals'][runner_name][varname][j]")
        logger.info("  is runner_name's values for varname at timestep j")
        logger.info("  fasmir, fmir, fqir will report everything.")
        logger.info(
            "  the setting of --debug_vars determines what's available from hardware."
        )

        logger.debug("===============================")
        logger.debug("outputs:")
        for runner, vals in outputs.items():
            logger.debug("-------------------------------")
            logger.debug(f"runner {runner}")
            logger.debug(outputs)
        logger.debug("===============================")

    def _prepare_comparisons(
        self,
        spu_runner,
        comparisons,
        fqir,
        sim_fasmir,
        sim_fmir,
        noencrypt: bool = False,
        hardware="fakezynq",
        dummy_output_file: str | None = None,
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        hardware_address: str | None = None,
    ):
        """
        This function creates different runners based on the input comparison list. These runners can then later be
        executed and the outputs can be compared to check that they match.
        """
        runners_to_compare = {}
        for comp in comparisons:
            runner, name = self.create_runner(
                comp,
                spu_runner,
                fqir,
                sim_fasmir,
                sim_fmir,
                noencrypt=noencrypt,
                hardware=hardware,
                dummy_output_file=dummy_output_file,
                debug_vars=debug_vars,
                debug_vars_fname=debug_vars_fname,
                hardware_address=hardware_address,
            )
            runners_to_compare[name] = runner

        return list(runners_to_compare.values()), list(runners_to_compare.keys())

    def create_runner(
        self,
        requested_runner: str,
        spu_runner: SPURunner = None,
        fqir=None,
        sim_fasmir=None,
        sim_fmir=None,
        noencrypt: bool = False,
        hardware: str = "fakezynq",
        input_period: float = 0.016,
        dummy_output_file: str | None = None,
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        hardware_address: str | None = None,
    ) -> tuple[FemtoRunner, str]:
        """
        This function creates a runner based on which runner is requested.
        """
        if spu_runner is None:
            spu_runner = self.spu_runner
        if fqir is None:
            fqir = self.fqir
        if sim_fasmir is None:
            sim_fasmir = self.fasmir
        if sim_fmir is None:
            sim_fmir = self.fmir
        runner = None
        name = ""
        if requested_runner == "hw":
            spu_runner = self.create_SPURunner(
                self.compiled_data,
                meta_dir=None,
                noencrypt=noencrypt,
                hardware=hardware,
                debug_vars=debug_vars,
                debug_vars_fname=debug_vars_fname,
                dummy_output_file=dummy_output_file,
                hardware_address=hardware_address,
            )
            runner = spu_runner
            self.spu_runner = spu_runner
            name = "hardware"
        elif requested_runner == "fasmir":
            if DEV_MODE and not self.force_femtocrux_sim:
                # FB runner
                fasmir_runner = SimRunner(
                    sim_fasmir,  # model might be fqir, need to compile for SimRunner
                    io_spec=self.iospecs["fasmir"],
                )

            else:
                # use FXRunner which wraps docker
                fasmir_runner = FXRunner(
                    self.fqir,  # XXX it will recompile, not sure if there's a way to get it to use what it already compiled
                    iospec=self.iospec,
                    compiler_client=self.femtocrux_client,
                    compiler_args=self.compiler_kwargs,
                    opt_profile=self.opt_profile,
                    input_period=input_period,
                )

            runner = fasmir_runner
            name = "fasmir"

        elif requested_runner == "fqir":
            if fqir is not None:
                # FIXME the def'n is duplicated in FD and FM, should really go in fmot
                fqir_runner = FQIRArithRunner(fqir, io_spec=self.iospec)
                runner = fqir_runner
                name = "fqir"
            else:
                raise (Exception("Requested fqir runner but no fqir was present."))
        elif requested_runner == "fmir":
            self._check_dev_mode("comparison to FMIR runner")
            if self.force_femtocrux_compile and self.force_femtocrux_sim:
                raise NotImplementedError("FX can't simulate FMIR")
            if fqir is not None:
                fmir_runner = FMIRRunner(sim_fmir)
                runner = fmir_runner
                name = "fmir"
        elif requested_runner == "dummy":
            # for fake runner, what do you reply with
            if dummy_output_file is not None:
                fname = dummy_output_file
                if fname.endswith(".npy"):
                    dummy_vals = np.load(fname)
                    dummy_output_dict = {
                        spu_runner.get_single_output_name(): dummy_vals
                    }
                elif fname.endswith(".pt"):
                    # would put dictionary with multiple output vars in here
                    raise RuntimeError(
                        "unsupported file format for --dummy_output_file, only .npy is supported"
                    )
                else:
                    raise RuntimeError(
                        "unsupported file format for --dummy_output_file, only .npy is supported"
                    )
            else:
                dummy_output_dict = None
            fakehw_runner = DummyRunner(dummy_output_dict)
            runner = fakehw_runner
            name = "dummy"
        else:
            raise RuntimeError(f"unknown comparison runner '{requested_runner}'")

        return runner, name

    def _run_comparisons(
        self,
        comparisons: list[str],
        inputs: dict[str, np.ndarray],
        noencrypt: bool = False,
        hardware="fakezynq",
        input_period: float = 0.016,
        dummy_output_file: str | None = None,
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        hardware_address: str | None = None,
    ) -> dict:
        """
        Run comparisons between the different runners.

        @param comparisons: list of comparisons. Possible values, hw, fasmir, fqir, fmir
        @param inputs: an array with a shapre based on the model in question (batch=1 during inference, frames, samples)
        @param dummy_output_file: file containing dummy outputs (only useful internally)
        """
        fqir = self.fqir
        sim_fasmir = self.fasmir
        sim_fmir = self.fmir

        if len(comparisons) <= 1:
            logger.info(
                "You have only specified one item in comparison list. "
                "If this is the intention use simulate() otherwise specify multiple comparisons."
            )
            return 1

        # & is set intersection: fqir, fmir in comparisons set
        if {"fqir", "fmir"} & set(comparisons) and fqir is None:
            raise RuntimeError(
                "asked for fqir or fmir comparison, but did't start from FQIR"
            )
        if {"fasmir"} & set(comparisons) and (fqir is None and sim_fasmir is None):
            raise RuntimeError(
                "asked for fasmir comparison, but we can't make fasmir. "
                "If you started from a femtofile, this isn't supported."
            )

        spu_runner = self.spu_runner

        compare_runners, compare_names = self._prepare_comparisons(
            spu_runner=spu_runner,
            comparisons=comparisons,
            fqir=fqir,
            sim_fasmir=sim_fasmir,
            sim_fmir=sim_fmir,
            noencrypt=noencrypt,
            hardware=hardware,
            dummy_output_file=dummy_output_file,
            debug_vars=debug_vars,
            debug_vars_fname=debug_vars_fname,
            hardware_address=hardware_address,
        )

        self.compare_runners = compare_runners

        if spu_runner is not None:
            spu_runner.ioplug.start_recording("io_sequence")

        # compare_runs returns
        # outputs, internals, (CompareStatus NamedTuple)
        outputs, internals, compare_status_obj = FemtoRunner.compare_runs(
            inputs,
            *compare_runners,
            names=compare_names,
            compare_internals=len(self.spu_debug_vars) > 0,
            except_on_error=False,
        )

        if spu_runner is not None:
            spu_runner.ioplug.commit_recording("all.yaml")

        self._dump_pickles(inputs, outputs, internals)

        for runner in compare_runners:
            metrics = self._get_runner_metrics(runner, input_period=input_period)
            if metrics:
                metrics_path = os.path.join(self.model_dir, "compare_metrics.yaml")
                self.write_metrics_to_disk(metrics, output_path=metrics_path)
                break

        self.compare_status = {}
        self.compare_status["pass"] = compare_status_obj.passed
        self.compare_status["status_str"] = compare_status_obj.status_str
        self.compare_status["outputs"] = outputs
        self.compare_status["internals"] = internals

        return self.compare_status

    def print_comparison_results(self, compare_status) -> None:
        # repeat output comparison result
        line_width = 80
        if compare_status["pass"]:
            logger.info(Fore.GREEN)
            logger.info("@" * line_width)
            logger.info("comparison good!")
            logger.info("@" * line_width)
            logger.info(Style.RESET_ALL)
        else:
            logger.info(Fore.RED)
            logger.info(compare_status["status_str"])
            logger.info("X" * line_width)
            logger.info("X" * line_width)
            logger.info("COMPARISON FAILED")
            logger.info("X" * line_width)
            logger.info("X" * line_width)
            logger.info(Style.RESET_ALL)

    def _suppress_import_debug(self, debug):
        if debug:
            logging.getLogger().setLevel(logging.DEBUG)
            # turn these down, they're long and annoying
            logging.getLogger("matplotlib").setLevel(logging.WARNING)
            logging.getLogger("PIL").setLevel(logging.WARNING)
        else:
            logging.getLogger().setLevel(logging.INFO)

    @staticmethod
    def _check_dev_mode(feat):
        if not DEV_MODE:
            raise RuntimeError(
                f"{feat} is a FS-only feature, requires internal packages. Exiting"
            )

    @staticmethod
    def _model_helpstr(model_source_dir=MODEL_SOURCE_DIR):
        if model_source_dir is None:
            return ""

        yamlfname = f"{model_source_dir}/options.yaml"
        with open(yamlfname, "r") as file:
            model_desc = yaml.safe_load(file)

        s = "\navailable models in femtodriver/femtodriver/models:\n"
        thisdir, subdirs, files = next(iter(os.walk(model_source_dir)))
        for file in files:
            if file.endswith(".pt"):
                modelname = file[:-3]

                s += f"  {modelname}"
                if modelname not in model_desc:
                    s += "\t  <-- missing specification in options.yaml"
                s += "\n"
            elif file.endswith(".pck"):
                modelname = file[:-4]

                s += f"  {modelname}"
                if modelname not in model_desc:
                    s += "\t  <-- missing specification in options.yaml"
                s += "\n"

        return s

    @property
    def io_records_dir(self):
        return os.path.join(self.model_dir, "io_records")

    def _create_shaped_input_from_wav(
        self, file_path: str, spu_runner: SPURunner
    ) -> np.ndarray:
        """
        Convert an input wav file to a numpy array with the correct shape
        to run through the model. This often means converting it to a
        shape of (frames, samples) where the value of samples is the hop_size.

        @parm file_path: input wavfile
        @returns a numpy array with shape (frames, samples) e.g. (N, 32) for 32 samples per frame
        """

        # Load the wav file
        sampling_rate, data = wavfile.read(file_path)

        # 'sampling_rate' is the sampling rate of the wav file
        # 'data' is a numpy array containing the audio data
        logger.info(
            f"Input wavfile sampling rate: {sampling_rate} data type: {data.dtype}"
        )
        return self._create_shaped_input_from_ndarray(data, spu_runner)

    def _create_shaped_input_from_ndarray(
        self, data: np.ndarray, spu_runner: SPURunner
    ):
        """
        Convert an input wav file to a numpy array with the correct shape
        to run through the model. This often means converting it to a
        shape of (frames, samples) where the value of samples is the hop_size.

        @parm data: a numpy array containing the data with shape (N,) where N is the number of samples
        @returns a numpy array with shape (frames, samples) e.g. (N, 32) for 32 samples per frame
        """

        # Figure out the shape that we need by creating a fake input and reshaping
        # the real data to match this shape.
        fake_input = spu_runner.make_fake_inputs(1, style="random")
        if len(fake_input.keys()) != 1:
            raise (
                Exception(
                    "There is more than 1 expected input for this model so we can't pass the wavfile to it."
                )
            )

        # This just gets the first key from the dict since there should only be 1.
        input_var_name = next(iter(fake_input))

        # This is to find out the shape the input needs to be for the model
        _, samples = fake_input[input_var_name].shape

        # The first part of this line data[:len(data)//samples * samples]
        # truncates the data into something divisible by samples and
        # then we reshape to (frames, samples) to match what the model expects
        data = data[: len(data) // samples * samples].reshape(-1, samples)

        return data

    def _create_fake_spu_runner(self):
        fake_spu_runner = self.create_SPURunner(
            self.compiled_data,
            None,  # unused
            noencrypt=self.noencrypt,
            hardware="fakezynq",
        )
        return fake_spu_runner

    def write_metrics_to_disk(self, metrics: str, output_path: Path):
        """
        Write the metrics returned from simulator to the output path
        """
        with open(output_path, "w") as f:
            yaml.dump(metrics, f, sort_keys=False)

        logger.info(f"Wrote metrics.txt to {output_path}")

    def get_docker_logs(self) -> str:
        """
        Get the logs for the docker container if it's running.
        """

        if self.femtocrux_client:
            logs = self.femtocrux_client.container.logs()
            logs = logs.decode("utf-8")
            formatted_logs = logs.replace("\\n", "\n")
            return formatted_logs
        else:
            logger.error(
                "Can't get logs because we don't have a handle to a container."
            )
        return "No logs available"

    def list_connected_hardware(self) -> None:
        """
        Lists all the compatible SPU-001 hardware detected
        """
        evk2_available, evk2_used = Evk2Plugin.find_evk2s()

        if len(evk2_available) == 0 and len(evk2_used) == 0:
            print("No compatible hardware detected")
            return

        print("EVK2")
        print("Available:")
        if len(evk2_available) == 0:
            print("- None")
        else:
            print("\n".join([f"- {dev}" for dev in evk2_available]))

        print("In use:")
        if len(evk2_used) == 0:
            print("- None")
        else:
            print("\n".join([f"- {dev}" for dev in evk2_used]))
        print("")

    def cleanup_docker_containers(self) -> None:
        """
        If you have running femtocrux docker containers because you were using a debugger and exited before
        the cleanup __exit__ of the context manager could be called, we provide this helper to manually
        cleanup any running docker containers.
        """
        # Initialize Docker client
        client = docker.from_env()

        # Get a list of all running containers
        running_containers = client.containers.list()

        # Filter containers that are using the image ghcr.io/femtosense/femtocrux
        femtocrux_containers = [
            container
            for container in running_containers
            if container.image.tags
            and any(
                tag.startswith("ghcr.io/femtosense/femtocrux")
                for tag in container.image.tags
            )
        ]

        if not femtocrux_containers:
            print(
                "No running containers found with the image tag 'ghcr.io/femtosense/femtocrux'."
            )
        else:
            for container in femtocrux_containers:
                print(f"Stopping container {container.name} with ID {container.id}...")
                container.stop()
                print(f"Container {container.name} stopped.")

    def compile(
        self,
        model,
        iospec: IOSpec | None = None,
        opt_profile: str | None = None,
        user_configuration: dict | None = None,
        memory_reservations: dict | None = None,
        model_name: str = "provide_model_name_to_compile_call",
        model_options_file=None,
        output_dir: str | Path = "model_datas",
        noencrypt: bool = False,
        model_type: str | None = None,
        model_version: str | None = None,
        target_spu: str | None = None,
    ) -> tuple[str, str, str, IOSpec]:
        """
        Compiles the model (FQIR or LOOPBACK)
        generates program files in femto format

        @params: Look at the run() method docstring for information in parameters

        @returns: A tuple of (the metadata directory on disk, the femtofile_path, femtofile_size, iospec)
        """
        if isinstance(output_dir, Path):
            output_dir = str(output_dir)

        # Set this to none so that it can get repopulated on each call
        self.model_dir = None
        self.noencrypt = noencrypt

        self.modelname, self.fqir, self.fmir, self.fasmir = self.load_model(
            model, model_name
        )

        if iospec is None and self.fqir is not None:
            iospec = iospec_from_fqir(self.fqir)

        self.iospec = iospec

        # Load per-model options from file; compile() args take priority.
        model_options_path = get_options_path(self.model_source_dir, model_options_file)
        file_options = load_model_options(self.modelname, model_options_path)
        self.compiler_kwargs = (
            user_configuration
            if user_configuration is not None
            else file_options["compiler_kwargs"]
        )
        self.opt_profile = (
            opt_profile if opt_profile is not None else file_options["opt_profile"]
        )

        if self.using_cli:
            print_header("Compiling Metadata")

        # compile the model
        # also populates self.IRs
        self.compiled_data = self.compile_metadata(
            iospec,
            opt_profile=self.opt_profile,
            user_configuration=self.compiler_kwargs,
            memory_reservations=memory_reservations,
            noencrypt=noencrypt,
        )

        if model_name is None:
            model_info = self.io_records_dir.split("/")
            model_name = model_info[-2] if len(model_info) > 2 else "fqir"

        if self.using_cli:
            print_header("Exporting femtofile")

        prog_paths = write_programming_files(
            self.IRs,
            write_dir=output_dir,
            model_name=model_name,
            model_type=model_type,
            model_version=model_version,
        )
        self.model_dir = prog_paths["model_dir"]
        ff_path = prog_paths["femtofile"]

        return (
            self.model_dir,
            ff_path,
            os.path.getsize(ff_path),
            self.compiled_data.iospec,
        )

    def get_compiler_metadata(self) -> dict:
        """
        Return the compiler metadata which contains information about data memory usage,
        instructions count and table memory usage.
        @returns (dict) metadata
        """
        if self.compiled_data is None:
            logger.warning(
                "We don't have metadata to query. Did you call compile() first?"
            )
            return {}

        meta = self.compiled_data.metadata

        def sum_across_cores_and_banks(meta, key):
            total = 0
            for core_amounts in meta[key].values():
                if isinstance(core_amounts, dict):
                    total += sum(core_amounts.values())
                else:
                    total += core_amounts

            return total

        total_data = sum_across_cores_and_banks(meta, "data_bank_sizes")
        total_table = sum_across_cores_and_banks(meta, "table_bank_sizes")
        total_inst = sum_across_cores_and_banks(meta, "inst_counts")

        # 8B per data word, total SPU-001 resources are 1MB
        meta["total_data_kB"] = total_data * 8 / 1024
        # total SPU-001 resources are 16000 table words
        meta["total_table"] = total_table
        # total SPU-001 resources are 8000 instructions
        meta["total_instructions"] = total_inst

        return dict(**meta)

    def simulate(
        self,
        model_inputs: dict[str, np.ndarray] | list[dict[str, np.ndarray]],
        input_period: float,
    ) -> tuple[dict, dict]:
        """
        Runs a simulation using Fasmir and returns metrics including estimated power.

        @params: See run() docstring for details on parameters

        @returns: A tuple with the first element as a dictionary of sim results and the second element
                  is string representation of the yaml sim metrics
        """
        if self.model_dir:
            logger.info("running Simulation")
        else:
            logger.info(
                "You haven't compiled a model. Please compile a model before simulating"
            )

        requested_runner = "fasmir"

        if self.fasmir is None and self.fqir is None:
            raise (
                Exception(
                    "Can't run hardware simulation without fqir or fasmir. Did you start from a femtofile?\n"
                    "Running simulate() starting from a femtofile is not supported. Start from fqir if you can."
                )
            )

        result, runner = self.execute_runner(
            requested_runner,
            model_inputs=model_inputs,
            input_period=input_period,
        )

        metrics = self._get_runner_metrics(runner, input_period=input_period)

        return result, metrics

    def compare(
        self,
        model_inputs: dict[str, np.ndarray] | list[dict[str, np.ndarray]],
        runners_to_compare: list,
        noencrypt: bool = False,
        hardware="fakezynq",
        input_period: float = 0.016,
        dummy_output_file: str | None = None,
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        hardware_address: str | None = None,
    ) -> dict:
        """
        Compare runs a comparison between different FemtoRunners.

        @param runners_to_compare: The runners to compare. These are fqir, fmir, fasmir and hw.
                                   information on the rest of the arguments are in the run() docstring
        @returns: returns a dictionary of the status of the comparison and any mismatches as well as the results of
                  each runner.
        """
        if self.model_dir:
            logger.info("running Simulation")
        else:
            logger.info(
                "You haven't compiled a model. Please compile a model before simulating"
            )

        return self._run_comparisons(
            runners_to_compare,
            inputs=model_inputs,
            noencrypt=noencrypt,
            hardware=hardware,
            input_period=input_period,
            dummy_output_file=dummy_output_file,
            debug_vars=debug_vars,
            debug_vars_fname=debug_vars_fname,
            hardware_address=hardware_address,
        )

    def run(
        self,
        model: str | Path | GraphProto,
        model_options_file=None,
        output_dir: str = "model_datas",
        n_frames: int = 2,
        input_file: str = None,
        input_sample_indices: str | None = None,
        force_femtocrux_compile: bool = False,
        force_femtocrux_sim: bool = False,
        hardware: str = "fakezynq",
        runners: str = "",
        debug_vars: str | None = None,
        debug_vars_fname: str | None = None,
        debug: bool = False,
        noencrypt: bool = False,
        input_period: float = 0.016,
        dummy_output_file: str | None = None,
        cleanup_docker: bool = False,
        hardware_address: str | None = None,
        list_connected_hardware: bool = False,
        iospec_file: str | None = None,
        opt_profile: str | None = None,
        model_name: str = "provide_model_name_to_cli",
    ):
        """
        This is the python API version of the CLI argparse arguments. The descriptions from there hold.

        Required params:
        model:                          Model to run.

        Optional:
        model_options_file:             .yaml with run options for different models (e.g., compiler options).
                                        Default is femtodriver/femtodriver/models/options.yaml
        output_dir:                     Directory where to write fasmir, fqir, programming images,
                                        programming streams, etc.
        n_frames:                       Number of random frames to run through simulation.
        input_file:                     File with inputs to drive in. Expects .npy from numpy.save.
                                        Expecting single 2D array of values, indices are (timestep, vector_dim)
        input_sample_indices:           lo, hi indices to run from input_file.
        force_femtocrux_compile:        Force femtocrux as the compiler, even if FS internal packages present.
        force_femtocrux_sim:            Force femtocrux as the simulator, even if FS internal packages present.
        hardware:                       Primary runner to use: (options: zynq, fakezynq, redis).
        runners:                        Which runners to execute. If there are multiple, compare each of them
                                        to the first, comma-separated. Options: hw, fasmir, fqir, fmir, fakehw.
        debug_vars:                     Debug variables to collect and compare values for, comma-separated
                                        (no spaces), or 'all'.
        debug_vars_fname:               File with a debug variable name on each line.
        debug:                          Set debug log level.
        noencrypt:                      Don't encrypt programming files.
        input_period:                   Simulator input period for energy estimation. No impact on runtime.
                                        Floating point seconds.
        dummy_output_file:              For fakezynq, the values that the runner should reply with.
                                        Specify a .npy for a single variable.
        hardware_address:               Identifier of the device to use (e.g. serial number for EVK2, ip address/hostname of the zynq board)
        list_connected_hardware:        Lists all the compatible SPU-001 hardware detected
        iospec_file:                    Path to the iospec file
        opt_profile:                    Optimization profile to use in the compiler
        model_name:                     Name to give the .femto file

        """

        if cleanup_docker:
            print_header("Cleaning up femtocrux docker containers")
            self.cleanup_docker_containers()
            return 0

        if list_connected_hardware:
            print_header("SPU-001 hardware detected")
            self.list_connected_hardware()
            return {}

        if isinstance(output_dir, Path):
            output_dir = str(output_dir)

        # Set this to none so that it can get repopulated on each call
        self.model_dir = None

        # collect comparisons
        if runners == "":
            self.comparisons = []
        else:
            self.comparisons = runners.split(",")
        ########################################################

        if iospec_file:
            iospec = IOSpec(iospec_file)
        else:
            iospec = None

        self.using_cli = True
        model_dir, femtofile_path, femtofile_size, iospec = self.compile(
            model,
            iospec=iospec,
            model_options_file=model_options_file,
            output_dir=output_dir,
            noencrypt=noencrypt,
            opt_profile=opt_profile,
            model_name=model_name,
        )

        result = {}

        if input_sample_indices is not None:
            input_sample_indices = input_sample_indices.split(",")

        # we need to make a SPURunner to have generate_audio_inputs work
        # previously, I think write_prog_files was doing this incidentally
        _, _ = self.create_runner("hw")

        model_inputs = self.generate_audio_inputs(
            input=input_file,
            spu_runner=self.spu_runner,
            n_frames=n_frames,
            input_sample_indices=input_sample_indices,
        )

        if len(self.comparisons) == 1 and "fasmir" in self.comparisons:
            print_header("Running Simulation")
            sim_result, sim_metrics = self.simulate(
                model_inputs=model_inputs,
                input_period=input_period,
            )
            metrics_path = os.path.join(model_dir, "run_metrics.yaml")
            self.write_metrics_to_disk(sim_metrics, output_path=metrics_path)
        elif len(self.comparisons) == 1:
            print_header(f"Executing runner {self.comparisons[0]} on {hardware}")

            result, runner = self.execute_runner(
                requested_runner=self.comparisons[0],
                model_inputs=model_inputs,
                noencrypt=noencrypt,
                hardware=hardware,
                dummy_output_file=dummy_output_file,
                debug_vars=debug_vars,
                debug_vars_fname=debug_vars_fname,
                hardware_address=hardware_address,
            )
            logger.info(f"Result of runner execution: {result}")

        elif len(self.comparisons) > 1:
            print_header("Running Comparisons")
            result = self.compare(
                runners_to_compare=self.comparisons,
                model_inputs=model_inputs,
                noencrypt=noencrypt,
                hardware=hardware,
                input_period=input_period,
                dummy_output_file=dummy_output_file,
                debug_vars=debug_vars,
                debug_vars_fname=debug_vars_fname,
                hardware_address=hardware_address,
            )
            self.print_comparison_results(result)

        return result

    def main(self, parsed_args) -> int:
        self.args = parsed_args
        args_dict = vars(self.args)

        return self.run(**args_dict)


def main(argv, model_source_dir=MODEL_SOURCE_DIR):
    parsed_args = Femtodriver._parse_args(argv)

    with Femtodriver(
        model_source_dir=model_source_dir,
        debug=parsed_args.debug,
        force_femtocrux_sim=parsed_args.force_femtocrux_sim,
        force_femtocrux_compile=parsed_args.force_femtocrux_compile,
    ) as fd:
        result = fd.main(parsed_args)

    if result == {}:  # no comparison performed, but clean exit
        return 0
    elif isinstance(result, dict) and "pass" in result:
        return not result["pass"]  #  0 = pass, 1 = no pass
    else:
        assert False and "got unexpected output from fd.main()"


def cli():
    main(sys.argv[1:])


if __name__ == "__main__":
    fd = Femtodriver()
    exit(fd.main(sys.argv[1:]))
