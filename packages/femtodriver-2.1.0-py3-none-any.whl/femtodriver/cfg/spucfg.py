#  Copyright Femtosense 2024
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#

import os
from dataclasses import dataclass
from abc import ABC, abstractmethod


@dataclass
class SPUCfg(ABC):
    ISA = None
    N_CORES = 2
    B_DATA_ADDR = 16
    B_CONF_ADDR = 17
    CORE_DATA_MEM_BANKS = 8
    CORE_TABLE_MEM_BANKS = 4
    B_DATA_WORD = 64
    B_TABLE_WORD = 16
    DATA_MEM_BANK_WORDS = 8192
    TABLE_MEM_BANK_WORDS = 2048
    MAX_THREADS = 64
    MAX_INSTR = 4096
    B_PC = 12
    B_INSTR = 64
    B_SB = 11
    B_TIDX = 6
    B_RQ = 2**B_TIDX


class SPU1p3Cfg(SPUCfg):
    ISA = 1.3


class SPU2p0Cfg(SPUCfg):
    ISA = 2.0

    # overrides for changed core size
    # XXX B_INSTR = 64 as used by fd_dataclasses, is right, not 71
    N_CORES = 4
    B_DATA_ADDR = 15
    B_CONF_ADDR = 16
    CORE_DATA_MEM_BANKS = 1
    CORE_TABLE_MEM_BANKS = 1


class SPU2p1Cfg(SPU2p0Cfg):
    ISA = 2.1


def _get_ISA() -> float:
    hwcfg = os.getenv("FS_HW_CFG")
    # e.g. spu1p3v1.dat
    major = hwcfg[3]
    minor = hwcfg[5]
    return float(f"{major}.{minor}")


def _get_spucfg():
    CFGs = [
        SPU1p3Cfg,
        SPU2p0Cfg,
        SPU2p1Cfg,
    ]

    isa = _get_ISA()
    for cfg in CFGs:
        if cfg.ISA == isa:
            return cfg()


spucfg = _get_spucfg()
