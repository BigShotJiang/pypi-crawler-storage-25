import unittest

from sheaftrace import TraceEvent, receipt_summary, render_timeline


class TraceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.events = [
            TraceEvent("collect", "ok", 1, "start"),
            TraceEvent("normalize", "ok", 2, "done"),
        ]

    def test_receipt_summary(self) -> None:
        self.assertEqual(receipt_summary(self.events)["count"], 2)

    def test_render_timeline(self) -> None:
        self.assertIn("normalize [ok]", render_timeline(self.events))

