from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TraceEvent:
    step: str
    status: str
    ts: int
    detail: str = ""


def receipt_summary(events: list[TraceEvent]) -> dict[str, object]:
    return {
        "count": len(events),
        "steps": [event.step for event in events],
        "last_status": events[-1].status if events else None,
    }


def render_timeline(events: list[TraceEvent]) -> str:
    return "\n".join(f"{event.ts}: {event.step} [{event.status}] {event.detail}".rstrip() for event in events)

