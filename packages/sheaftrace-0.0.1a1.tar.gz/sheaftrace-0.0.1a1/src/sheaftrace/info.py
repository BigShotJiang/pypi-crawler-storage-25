def project_info() -> dict[str, str]:
    return {
        "name": "sheaftrace",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheaftrace-python",
    }

