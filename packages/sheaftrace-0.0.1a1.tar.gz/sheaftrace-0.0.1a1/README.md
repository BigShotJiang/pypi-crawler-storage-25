# sheaftrace

`sheaftrace` is the official Python package namespace for lightweight tracing
and receipt helpers used by the SheafLab project.

This initial public release provides event records, receipt summaries, and a
compact timeline renderer for inspectable execution traces.

