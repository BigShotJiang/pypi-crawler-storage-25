"""LightlyStudio VideoDataset."""

from __future__ import annotations

import logging
from collections.abc import Iterable
from pathlib import Path
from uuid import UUID

from labelformat.formats import (
    YouTubeVISInstanceSegmentationTrackInput,
    YouTubeVISObjectDetectionTrackInput,
)
from sqlmodel import Session

from lightly_studio.core.dataset import BaseSampleDataset
from lightly_studio.core.dataset_query.dataset_query import DatasetQuery
from lightly_studio.core.video import add_videos
from lightly_studio.core.video.add_videos import VIDEO_EXTENSIONS
from lightly_studio.core.video.video_sample import VideoSample
from lightly_studio.dataset import fsspec_lister
from lightly_studio.dataset.embedding_manager import EmbeddingManagerProvider
from lightly_studio.export.export_video_dataset import VideoDatasetExport
from lightly_studio.models.annotation.annotation_base import AnnotationType
from lightly_studio.models.collection import SampleType
from lightly_studio.resolvers import video_resolver
from lightly_studio.type_definitions import PathLike

logger = logging.getLogger(__name__)


class VideoDataset(BaseSampleDataset[VideoSample]):
    """Video dataset.

    It can be created or loaded using one of the static methods:
    ```python
    dataset = VideoDataset.create()
    dataset = VideoDataset.load()
    dataset = VideoDataset.load_or_create()
    ```

    Samples can be added to the dataset using:
    ```python
    dataset.add_videos_from_path(...)
    ```

    The dataset samples can be queried directly by iterating over it or slicing it:
    ```python
    dataset = VideoDataset.load("my_dataset")
    first_ten_samples = dataset[:10]
    for sample in dataset:
        print(sample.file_name)
        sample.metadata["new_key"] = "new_value"
    ```

    For filtering or ordering samples first, use the query interface:
    ```python
    from lightly_studio.core.dataset_query.video_sample_field import VideoSampleField

    dataset = VideoDataset.load("my_dataset")
    query = dataset.match(VideoSampleField.width > 10).order_by(VideoSampleField.file_name)
    for sample in query:
        ...
    ```
    """

    @staticmethod
    def sample_type() -> SampleType:
        """Returns the sample type."""
        return SampleType.VIDEO

    @staticmethod
    def sample_class() -> type[VideoSample]:
        """Returns the sample class."""
        return VideoSample

    def export(self, query: DatasetQuery[VideoSample] | None = None) -> VideoDatasetExport:
        """Return an export interface for the (optionally filtered) video dataset."""
        if query is None:
            query = self.query()
        return VideoDatasetExport(session=self.session, samples=query)

    def get_sample(self, sample_id: UUID) -> VideoSample:
        """Get a single sample from the dataset by its ID.

        Args:
            sample_id: The UUID of the sample to retrieve.

        Returns:
            A single VideoSample object.

        Raises:
            IndexError: If no sample is found with the given sample_id.
        """
        sample = video_resolver.get_by_id(self.session, sample_id=sample_id)

        if sample is None:
            raise IndexError(f"No sample found for sample_id: {sample_id}")
        return VideoSample(inner=sample)

    def add_videos_from_path(
        self,
        path: PathLike,
        allowed_extensions: Iterable[str] | None = None,
        num_decode_threads: int | None = None,
        embed: bool = True,
    ) -> None:
        """Adding video frames from the specified path to the dataset.

        Args:
            path: Path to the folder containing the videos to add.
            allowed_extensions: An iterable container of allowed video file
                extensions in lowercase, including the leading dot. If None,
                uses default VIDEO_EXTENSIONS.
            num_decode_threads: Optional override for the number of FFmpeg decode threads.
                If omitted, the available CPU cores - 1 (max 16) are used.
            embed: If True, generate embeddings for the newly added videos.
        """
        video_paths = _collect_video_file_paths(path=path, allowed_extensions=allowed_extensions)
        logger.info(f"Found {len(video_paths)} videos in {path}.")

        # Process videos.
        created_sample_ids, _ = add_videos.load_into_collection_from_paths(
            session=self.session,
            collection_id=self.collection_id,
            video_paths=video_paths,
            num_decode_threads=num_decode_threads,
        )

        if embed:
            _generate_embeddings_video(
                session=self.session,
                collection_id=self.collection_id,
                sample_ids=created_sample_ids,
            )

    def add_videos_from_youtube_vis(
        self,
        annotations_json: PathLike,
        videos_path: PathLike,
        allowed_extensions: Iterable[str] | None = None,
        annotation_type: AnnotationType = AnnotationType.OBJECT_DETECTION,
        embed: bool = True,
    ) -> None:
        """Load videos and YouTube-VIS annotations and store them in the database.

        Args:
            annotations_json: Path to the YouTube-VIS annotations JSON file.
            videos_path: Path to the folder containing the videos.
            allowed_extensions: An iterable container of allowed video file
                extensions in lowercase, including the leading dot. If None,
                uses default VIDEO_EXTENSIONS.
                Note: This is used when a path in YouTube-VIS does not contain the file extension.
            annotation_type: The type of annotation to be loaded (e.g., 'ObjectDetection',
                'InstanceSegmentation').
            embed: If True, generate embeddings for the newly added videos.
        """
        annotations_json = Path(annotations_json).absolute()

        if not annotations_json.is_file() or annotations_json.suffix != ".json":
            raise FileNotFoundError(
                f"YouTube-VIS annotations json file not found: '{annotations_json}'"
            )
        input_labels: YouTubeVISObjectDetectionTrackInput | YouTubeVISInstanceSegmentationTrackInput
        if annotation_type == AnnotationType.OBJECT_DETECTION:
            input_labels = YouTubeVISObjectDetectionTrackInput(input_file=annotations_json)
        elif annotation_type == AnnotationType.INSTANCE_SEGMENTATION:
            input_labels = YouTubeVISInstanceSegmentationTrackInput(input_file=annotations_json)
        else:
            raise ValueError(f"Invalid annotation type: {annotation_type}")

        video_paths = _collect_video_file_paths(
            path=videos_path, allowed_extensions=allowed_extensions
        )

        created_sample_ids, _ = add_videos.load_video_annotations_from_labelformat(
            session=self.session,
            collection_id=self.collection_id,
            video_paths=video_paths,
            input_labels=input_labels,
            input_labels_paths_root=videos_path,
        )

        if embed:
            _generate_embeddings_video(
                session=self.session,
                collection_id=self.collection_id,
                sample_ids=created_sample_ids,
            )


def _generate_embeddings_video(
    session: Session,
    collection_id: UUID,
    sample_ids: list[UUID],
) -> None:
    """Generate and store embeddings for samples.

    Args:
        session: Database session for resolver operations.
        collection_id: The ID of the collection to associate with the embedding model.
        sample_ids: List of sample IDs to generate embeddings for.
    """
    if not sample_ids:
        return

    embedding_manager = EmbeddingManagerProvider.get_embedding_manager()
    model_id = embedding_manager.load_or_get_default_model(
        session=session, collection_id=collection_id
    )
    if model_id is None:
        logger.warning("No embedding model loaded. Skipping embedding generation.")
        return

    embedding_manager.embed_videos(
        session=session,
        collection_id=collection_id,
        sample_ids=sample_ids,
        embedding_model_id=model_id,
    )


def _collect_video_file_paths(
    path: PathLike,
    allowed_extensions: Iterable[str] | None = None,
) -> list[str]:
    # Collect video file paths.
    if allowed_extensions:
        allowed_extensions_set = {ext.lower() for ext in allowed_extensions}
    else:
        allowed_extensions_set = VIDEO_EXTENSIONS
    return list(
        fsspec_lister.iter_files_from_path(
            path=str(path), allowed_extensions=allowed_extensions_set
        )
    )
