function a(t){return(t==null?void 0:t.type)==="image"}export{a as i};
