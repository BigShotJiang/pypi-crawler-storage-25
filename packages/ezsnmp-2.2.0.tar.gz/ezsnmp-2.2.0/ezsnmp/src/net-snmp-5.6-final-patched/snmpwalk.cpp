/* straight copy from https://github.com/net-snmp/net-snmp/tree/master/apps */
/*
 * snmpwalk.c - send snmp GETNEXT requests to a network entity, walking a
 * subtree.
 *
 */
/**********************************************************************
        Copyright 1988, 1989, 1991, 1992 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
#include <net-snmp/net-snmp-config.h>

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#else
#include <strings.h>
#endif
#include <sys/types.h>
#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif
#ifdef TIME_WITH_SYS_TIME
#include <sys/time.h>
#include <time.h>
#else
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif
#endif
#ifdef HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif
#include <stdio.h>
#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif
#ifdef HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif

#include <net-snmp/net-snmp-includes.h>

#include <mutex>

#define NETSNMP_DS_WALK_INCLUDE_REQUESTED 1
#define NETSNMP_DS_WALK_PRINT_STATISTICS 2
#define NETSNMP_DS_WALK_DONT_CHECK_LEXICOGRAPHIC 3
#define NETSNMP_DS_WALK_TIME_RESULTS 4
#define NETSNMP_DS_WALK_DONT_GET_REQUESTED 5
#define NETSNMP_DS_WALK_TIME_RESULTS_SINGLE 6

oid objid_mib[] = {1, 3, 6, 1, 2, 1};
thread_local int numprinted = 0;

thread_local char *end_name = NULL;

#include "exceptionsbase.h"
#include "helpers.h"
#include "snmpwalk.h"
#include "thread_safety.h"

std::vector<std::string> snmpwalk_snmp_get_and_print(netsnmp_session *ss,
                                                     oid *theoid,
                                                     size_t theoid_len) {
   std::vector<std::string> str_values;

   netsnmp_pdu *pdu, *response;
   netsnmp_variable_list *vars;
   int status;

   pdu = snmp_pdu_create(SNMP_MSG_GET);
   snmp_add_null_var(pdu, theoid, theoid_len);

   status = snmp_synch_response(ss, pdu, &response);
   if (status == STAT_SUCCESS) {
      snmp_check_null_response(response);
      if (response->errstat == SNMP_ERR_NOERROR) {
         for (vars = response->variables; vars; vars = vars->next_variable) {
            numprinted++;
            auto const &str_value = print_variable_to_string(vars->name, vars->name_length, vars);
            str_values.push_back(str_value);
         }
      }
   }
   if (response) {
      snmp_free_pdu(response);
   }

   return str_values;
}

void snmpwalk_optProc(int, char *const *argv, int opt) {
   switch (opt) {
      case 'C':
         while (*optarg) {
            switch (*optarg++) {
               case 'i':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_INCLUDE_REQUESTED);
                  break;

               case 'I':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_DONT_GET_REQUESTED);
                  break;

               case 'p':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_PRINT_STATISTICS);
                  break;

               case 'c':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_DONT_CHECK_LEXICOGRAPHIC);
                  break;

               case 't':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_TIME_RESULTS);
                  break;

               case 'E':
                  end_name = argv[optind++];
                  break;

               case 'T':
                  netsnmp_ds_toggle_boolean(NETSNMP_DS_APPLICATION_ID,
                                            NETSNMP_DS_WALK_TIME_RESULTS_SINGLE);
                  break;

               default:
                  std::string err_msg =
                      "Unknown flag passed to -C: " + std::string(1, optarg[-1]) + "\n";
                  throw ParseErrorBase(err_msg);
            }
         }
         break;
   }
}

std::vector<Result> snmpwalk(std::vector<std::string> const &args,
                             std::string const &init_app_name) {
   // Reference-counted initialization: only first thread calls init_snmp
   netsnmp_thread_init(init_app_name);

   int argc;
   std::unique_ptr<char *[], Deleter> argv = create_argv(args, argc);
   std::vector<std::string> return_vector;

   netsnmp_session session;
   std::unique_ptr<netsnmp_session, SnmpSessionCloser> ss;
   netsnmp_pdu *pdu, *response;
   netsnmp_variable_list *vars;
   int arg;
   oid name[MAX_OID_LEN];
   size_t name_length;
   oid root[MAX_OID_LEN];
   size_t rootlen;
   oid end_oid[MAX_OID_LEN];
   size_t end_len = 0;
   int count;
   int running;
   int status = STAT_ERROR;
   int check;
   struct timeval tv1, tv2, tv_a, tv_b;

   SOCK_STARTUP;

   // Reset thread-local defaults for each invocation.
   numprinted = 0;
   end_name = NULL;

   // Captured application-level flags (set under setup mutex, used after)
   int include_requested, print_statistics, dont_check_lexicographic;
   int time_results, dont_get_requested, time_results_single;

   // Serialize Net-SNMP global setup: resetting DS flags and parsing arguments
   // both modify shared Net-SNMP global state.
   {
      std::lock_guard<std::mutex> setup_lock(g_netsnmp_setup_mutex);

      // Reset application-level walk flags for each invocation.
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_INCLUDE_REQUESTED, 0);
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_PRINT_STATISTICS, 0);
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_DONT_CHECK_LEXICOGRAPHIC,
                             0);
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_TIME_RESULTS, 0);
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_DONT_GET_REQUESTED, 0);
      netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_TIME_RESULTS_SINGLE, 0);

      /*
       * get the common command line arguments
       */
      netsnmp_register_loghandler(NETSNMP_LOGHANDLER_NONE, 0);
      netsnmp_ds_set_int(NETSNMP_DS_LIBRARY_ID, NETSNMP_DS_LIB_MIB_WARNINGS, 0);
      switch (arg = snmp_parse_args(argc, argv.get(), &session, "C:", snmpwalk_optProc)) {
         case NETSNMP_PARSE_ARGS_ERROR:
            throw ParseErrorBase("NETSNMP_PARSE_ARGS_ERROR");

         case NETSNMP_PARSE_ARGS_SUCCESS_EXIT:
            throw ParseErrorBase("NETSNMP_PARSE_ARGS_SUCCESS_EXIT");

         case NETSNMP_PARSE_ARGS_ERROR_USAGE:
            throw ParseErrorBase("NETSNMP_PARSE_ARGS_ERROR_USAGE");

         default:
            break;
      }

      // Capture flags while still holding the setup mutex so no other thread
      // can reset them before we read their values for this invocation.
      include_requested =
          netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_INCLUDE_REQUESTED);
      print_statistics =
          netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_PRINT_STATISTICS);
      dont_check_lexicographic = netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID,
                                                        NETSNMP_DS_WALK_DONT_CHECK_LEXICOGRAPHIC);
      time_results =
          netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_TIME_RESULTS);
      dont_get_requested =
          netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_DONT_GET_REQUESTED);
      time_results_single =
          netsnmp_ds_get_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_WALK_TIME_RESULTS_SINGLE);
   }

   /*
    * get the initial object and subtree
    */
   if (arg < argc) {
      /*
       * specified on the command line
       */
      rootlen = MAX_OID_LEN;
      {
         std::lock_guard<std::mutex> lock(g_netsnmp_mib_mutex);
         if (snmp_parse_oid(argv[arg], root, &rootlen) == NULL) {
            snmp_perror_exception(argv[arg]);
         }
      }
   } else {
      /*
       * use default value
       */
      memmove(root, objid_mib, sizeof(objid_mib));
      rootlen = OID_LENGTH(objid_mib);
   }

   /*
    * If we've been given an explicit end point,
    *  then convert this to an OID, otherwise
    *  move to the next sibling of the start.
    */
   if (end_name) {
      end_len = MAX_OID_LEN;
      {
         std::lock_guard<std::mutex> lock(g_netsnmp_mib_mutex);
         if (snmp_parse_oid(end_name, end_oid, &end_len) == NULL) {
            snmp_perror_exception(end_name);
         }
      }
   } else {
      memmove(end_oid, root, rootlen * sizeof(oid));
      end_len = rootlen;
      end_oid[end_len - 1]++;
   }

   /*
    * open an SNMP session
    */
   ss.reset(snmp_open(&session));
   if (!ss) {
      /*
       * diagnose snmp_open errors with the input netsnmp_session pointer
       */
      snmp_sess_perror_exception("snmpwalk", &session);
   }

   /*
    * get first object to start walk
    */
   memmove(name, root, rootlen * sizeof(oid));
   name_length = rootlen;

   running = 1;

   check = !dont_check_lexicographic;
   if (include_requested) {
      auto retval = snmpwalk_snmp_get_and_print(ss.get(), root, rootlen);

      for (auto const &item : retval) {
         return_vector.push_back(item);
      }
   }

   if (time_results) {
      gettimeofday(&tv1, NULL);
   }

   while (running) {
      /*
       * create PDU for GETNEXT request and add object name to request
       */
      pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
      snmp_add_null_var(pdu, name, name_length);

      /*
       * do the request
       */
      if (time_results_single) {
         gettimeofday(&tv_a, NULL);
      }
      status = snmp_synch_response(ss.get(), pdu, &response);
      if (status == STAT_SUCCESS) {
         if (time_results_single) {
            gettimeofday(&tv_b, NULL);
         }
         snmp_check_null_response(response);
         if (response->errstat == SNMP_ERR_NOERROR) {
            /*
             * check resulting variables
             */
            for (vars = response->variables; vars; vars = vars->next_variable) {
               if (snmp_oid_compare(end_oid, end_len, vars->name, vars->name_length) <= 0) {
                  /*
                   * not part of this subtree
                   */
                  running = 0;
                  continue;
               }
               numprinted++;
               if (time_results_single) {
                  fprintf(stdout, "%f s: ",
                          (double)(tv_b.tv_usec - tv_a.tv_usec) / 1000000 +
                              (double)(tv_b.tv_sec - tv_a.tv_sec));
               }

               auto const &str_value =
                   print_variable_to_string(vars->name, vars->name_length, vars);
               return_vector.push_back(str_value);

               if ((vars->type != SNMP_ENDOFMIBVIEW) && (vars->type != SNMP_NOSUCHOBJECT) &&
                   (vars->type != SNMP_NOSUCHINSTANCE)) {
                  /*
                   * not an exception value
                   */
                  if (check &&
                      snmp_oid_compare(name, name_length, vars->name, vars->name_length) >= 0) {
                     std::string err_msg = "Error: OID not increasing: ";
                     err_msg = err_msg + print_objid_to_string(name, name_length) + " >= ";
                     err_msg =
                         err_msg + print_objid_to_string(vars->name, vars->name_length) + "\n";

                     throw GenericErrorBase(err_msg);
                  }
                  memmove((char *)name, (char *)vars->name, vars->name_length * sizeof(oid));
                  name_length = vars->name_length;
               } else {
                  /*
                   * an exception value, so stop
                   */
                  running = 0;
               }
            }
         } else {
            /*
             * error in response, print it
             */
            running = 0;
            if (response->errstat == SNMP_ERR_NOSUCHNAME) {
               // printf("End of MIB\n");
            } else {
               std::string err_msg =
                   "Error in packet.\nReason: " + std::string(snmp_errstring(response->errstat)) +
                   "\n";

               if (response->errindex != 0) {
                  err_msg = err_msg + "Failed object: ";
                  for (count = 1, vars = response->variables; vars && count != response->errindex;
                       vars = vars->next_variable, count++)
                     /*EMPTY*/;
                  if (vars) {
                     err_msg = err_msg + print_objid_to_string(vars->name, vars->name_length);
                  }
                  err_msg = err_msg + "\n";
                  throw PacketErrorBase(err_msg);
               }
            }
         }
      } else if (status == STAT_TIMEOUT) {
         std::string err_msg = "Timeout: No Response from " + std::string(session.peername) + ".\n";
         throw TimeoutErrorBase(err_msg);
      } else { /* status == STAT_ERROR */
         snmp_sess_perror_exception("snmpwalk", ss.get());
      }
      if (response) {
         snmp_free_pdu(response);
      }
   }
   if (time_results) {
      gettimeofday(&tv2, NULL);
   }

   if (numprinted == 0 && status == STAT_SUCCESS) {
      /*
       * no printed successful results, which may mean we were
       * pointed at an only existing instance.  Attempt a GET, just
       * for get measure.
       */
      if (!dont_get_requested) {
         auto retval = snmpwalk_snmp_get_and_print(ss.get(), root, rootlen);

         for (auto const &item : retval) {
            return_vector.push_back(item);
         }
      }
   }

   if (print_statistics) {
      printf("Variables found: %d\n", numprinted);
   }
   if (time_results) {
      fprintf(stderr, "Total traversal time = %f seconds\n",
              (double)(tv2.tv_usec - tv1.tv_usec) / 1000000 + (double)(tv2.tv_sec - tv1.tv_sec));
   }

   {
      std::unique_ptr<netsnmp_session, SnmpSessionCloser> ss_guard(ss.release());
   }

   clear_net_snmp_library_data();
   SOCK_CLEANUP;
   return parse_results(return_vector);
}
