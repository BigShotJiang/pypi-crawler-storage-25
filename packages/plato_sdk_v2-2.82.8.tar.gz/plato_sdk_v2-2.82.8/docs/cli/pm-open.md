# `plato pm open`

Open one or more simulators in a Playwright browser with the login flow executed. Meant for manually poking at a sim — sanity-checking a fix, reproducing a reviewer comment, validating that `data_artifact_id` actually has the data you think it does.

## When to use it

- You want to click through a sim yourself without launching a full Chronos session.
- You want to verify a sim's login flow still works.
- You have a specific artifact UUID (e.g. from a Chronos session result) and want to open it directly.

## Synopsis

```
plato pm open <sims...> [options]
```

### Arguments

- `<sims...>` — one or more of:
  - simulator name (e.g. `bookstack`) — artifact resolved from the sim's current `data_artifact_id` / `base_artifact_id`
  - bare artifact UUID (`b07fcb30-6af9-4e28-bef3-1aa6764b93c9`) — used directly, skips sim lookup
  - colon notation (`bookstack:b07fcb30-...`) — explicit artifact, no API lookup

### Options

| Flag | Effect |
|---|---|
| `--base` | Use `base_artifact_id` (pre-datagen snapshot). Mutually exclusive with `--data`. |
| `--data` | Use `data_artifact_id` (post-datagen snapshot). Default already falls back to base if data is missing. |
| `-a, --artifact-id <uuid>` | Explicit artifact UUID — requires exactly one simulator name. Rejected if combined with a bare-UUID positional. |
| `--headless` | Run Playwright headless (default: headed). |
| `--dataset <name>` | Flow dataset to run. Default `base` picks the `login` flow. |
| `--timeout <seconds>` | VM ready timeout (default: 1800). |

## Examples

```bash
# Single sim, headed, default dataset (login flow)
plato pm open bookstack

# Pre-datagen snapshot
plato pm open bookstack --base

# Multiple sims in one session (N tabs, one login per env)
plato pm open bookstack mattermost aimeos --data

# Explicit artifact via colon or -a
plato pm open bookstack:1b642f11-...
plato pm open bookstack -a 1b642f11-...

# Direct artifact UUID, no sim lookup
plato pm open b07fcb30-6af9-4e28-bef3-1aa6764b93c9

# Headless, custom flow dataset
plato pm open bookstack --headless --dataset login_admin
```

## What happens under the hood

1. Resolves every positional into `{name, artifact_id}` — same semantics as `pm start from-template`.
2. Creates one Plato session (v2 SDK) with all artifacts attached as envs.
3. `session.reset()` to bring the envs to a known state.
4. Launches Playwright Chromium (headed by default) and calls `session.login(browser, dataset=<dataset>)`. One tab per env, each navigated to its public URL with the sim's declared login flow executed.
5. Prints the logged-in URLs and blocks on Enter. On exit, closes the browser and the Plato session cleanly.

## Prerequisites

```bash
export PLATO_API_KEY=pk_user_...
```

Playwright is imported lazily so the rest of `plato pm` works without it. The first time you run `pm open`, install it:

```bash
uv pip install playwright && playwright install chromium
```

## See also

- [`plato pm start from-template`](./pm-from-template.md) — non-interactive counterpart for running templates across N sims
- [`pm.md`](./pm.md) — the full `plato pm` command index
