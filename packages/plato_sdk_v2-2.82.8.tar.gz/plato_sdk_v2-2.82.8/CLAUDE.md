# Python SDK — Claude Code

See [`AGENTS.md`](AGENTS.md) for SDK overview and documentation links.

For the `@durable` caching/memoization framework, see [`docs/sdk/durable.md`](../docs/sdk/durable.md).

## Testing

- Unit tests have a **global 10s timeout** (`timeout = 10` in `pyproject.toml`). Any unit test exceeding 10s will fail automatically.
- To exempt a specific test that legitimately needs more time, use `@pytest.mark.timeout(60)` (or whatever duration is appropriate).
- Tests that require real infrastructure (VMs, APIs, FUSE mounts) must be marked `@pytest.mark.integration` so they are excluded from unit runs (`-m "not integration"`).
