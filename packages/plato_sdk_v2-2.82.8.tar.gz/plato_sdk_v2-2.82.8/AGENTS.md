# Python SDK

Primary Python SDK (`plato-sdk-v2`) with async/sync clients, Chronos integration, and CLI commands.

For full documentation:

**→ [`docs/sdk/agent.md`](../docs/sdk/agent.md)**
