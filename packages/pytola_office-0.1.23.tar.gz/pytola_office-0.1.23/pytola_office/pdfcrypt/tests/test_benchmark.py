"""Performance benchmarks for pdfcrypt module."""

from __future__ import annotations

import atexit
import contextlib
import tempfile
from pathlib import Path

import pytest
from pypdf import PdfWriter

from pytola_office.pdfcrypt.cli import decrypt_pdf, encrypt_pdf


@pytest.fixture(autouse=True)
def disable_config_save():
    """Disable configuration auto-save during tests to prevent logging errors."""
    # Remove the atexit handler that saves config
    import pytola_office.pdfcrypt.cli as pdfcrypt_module

    atexit.unregister(pdfcrypt_module.conf.save)
    yield
    # Re-register the handler after test
    atexit.register(pdfcrypt_module.conf.save)


@pytest.fixture
def large_pdf_file():
    """Create a larger PDF file for performance testing."""
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp_file:
        writer = PdfWriter()
        # Create a PDF with multiple pages
        for _i in range(10):
            writer.add_blank_page(width=200, height=200)
        with Path(tmp_file.name).open("wb") as f:
            writer.write(f)
        file_path = Path(tmp_file.name)
        yield file_path
        # Cleanup - handle Windows file locking
        try:
            file_path.unlink(missing_ok=True)
        except PermissionError:
            # On Windows, file might still be locked, try again later
            import time

            time.sleep(0.1)
            with contextlib.suppress(PermissionError):
                file_path.unlink(missing_ok=True)


@pytest.fixture
def medium_pdf_file():
    """Create a medium-sized PDF file for performance testing."""
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp_file:
        writer = PdfWriter()
        # Create a PDF with fewer pages
        for _i in range(3):
            writer.add_blank_page(width=200, height=200)
        with Path(tmp_file.name).open("wb") as f:
            writer.write(f)
        file_path = Path(tmp_file.name)
        yield file_path
        # Cleanup - handle Windows file locking
        try:
            file_path.unlink(missing_ok=True)
        except PermissionError:
            # On Windows, file might still be locked, try again later
            import time

            time.sleep(0.1)
            with contextlib.suppress(PermissionError):
                file_path.unlink(missing_ok=True)


@pytest.fixture
def test_password():
    """Provide a test password for encryption/decryption operations."""
    return "test_password_123"


class TestPerformanceBenchmarks:
    """Performance benchmark tests."""

    @pytest.mark.benchmark(group="encryption")
    def test_encrypt_single_large_file(self, benchmark, large_pdf_file, test_password):
        """Benchmark encryption of a single large PDF file."""

        def encrypt_operation():
            return encrypt_pdf(large_pdf_file, test_password)

        result = benchmark(encrypt_operation)
        assert result[1] is not None  # Encrypted file should exist

    @pytest.mark.benchmark(group="encryption")
    def test_encrypt_single_medium_file(self, benchmark, medium_pdf_file, test_password):
        """Benchmark encryption of a single medium PDF file."""

        def encrypt_operation():
            return encrypt_pdf(medium_pdf_file, test_password)

        result = benchmark(encrypt_operation)
        assert result[1] is not None

    @pytest.mark.benchmark(group="decryption")
    def test_decrypt_single_file(self, benchmark, medium_pdf_file, test_password):
        """Benchmark decryption of a single PDF file."""
        # First encrypt the file
        _, encrypted_file = encrypt_pdf(medium_pdf_file, test_password)
        assert encrypted_file is not None

        def decrypt_operation():
            return decrypt_pdf(encrypted_file, test_password)

        result = benchmark(decrypt_operation)
        assert result[1] is not None  # Decrypted file should exist

    @pytest.mark.benchmark(group="operations")
    def test_complete_encrypt_decrypt_cycle(self, benchmark, medium_pdf_file, test_password):
        """Benchmark complete encrypt-decrypt cycle."""

        def complete_cycle():
            # Encrypt
            _, encrypted = encrypt_pdf(medium_pdf_file, test_password)
            if encrypted is None:
                return None
            # Decrypt
            _, decrypted = decrypt_pdf(encrypted, test_password)
            return decrypted

        result = benchmark(complete_cycle)
        assert result is not None

    @pytest.mark.benchmark(group="memory")
    def test_memory_usage_during_encryption(self, benchmark, large_pdf_file, test_password):
        """Benchmark memory usage during encryption."""

        def encrypt_with_memory_tracking():
            return encrypt_pdf(large_pdf_file, test_password)

        result = benchmark(encrypt_with_memory_tracking)
        assert result[1] is not None


class TestScalability:
    """Scalability tests for handling multiple files."""

    @pytest.mark.parametrize("file_count", [1, 5, 10])
    @pytest.mark.benchmark(group="batch_processing")
    def test_multiple_file_encryption(self, benchmark, tmp_path, file_count, test_password):
        """Benchmark encryption of multiple files."""
        files = []

        # Create multiple PDF files
        for i in range(file_count):
            pdf_path = tmp_path / f"test_{i}.pdf"
            writer = PdfWriter()
            writer.add_blank_page(width=100, height=100)
            with Path(pdf_path).open("wb") as f:
                writer.write(f)
            files.append(pdf_path)

        def batch_encrypt():
            results = []
            for pdf_file in files:
                result = encrypt_pdf(pdf_file, test_password)
                results.append(result)
            return results

        results = benchmark(batch_encrypt)
        # Verify all operations succeeded
        assert all(result[1] is not None for result in results)

    @pytest.mark.benchmark(group="configuration")
    def test_config_property_caching(self, benchmark):
        """Benchmark configuration property caching performance."""
        from pytola_office.pdfcrypt.cli import PDFCryptConfig

        config = PDFCryptConfig()

        def access_cached_properties():
            # Access properties multiple times to test caching
            results = []
            for _ in range(100):
                results.extend((config.is_configured, config.config_summary))
            return results

        results = benchmark(access_cached_properties)
        assert len(results) == 200


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--benchmark-only"])
