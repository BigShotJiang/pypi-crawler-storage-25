"""PDF encryption/decryption utilities.

This module provides functionality to encrypt and decrypt PDF files
using strong encryption algorithms. It supports batch processing
of multiple files with configurable passwords and security settings.
"""
