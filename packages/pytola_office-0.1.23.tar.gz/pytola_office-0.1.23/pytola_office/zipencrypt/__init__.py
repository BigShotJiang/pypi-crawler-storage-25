"""Zip encryption utility module."""
