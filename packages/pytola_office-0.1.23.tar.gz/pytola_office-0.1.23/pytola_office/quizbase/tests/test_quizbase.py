"""Tests for quizbase module."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from pytola_office.quizbase.cli import (
    EssayQuestion,
    FillBlankQuestion,
    MultipleChoiceQuestion,
    Question,
    QuestionType,
    QuizResult,
    QuizSession,
    TrueFalseQuestion,
    create_sample_quiz_data,
)


@pytest.fixture
def sample_quiz_json(tmp_path: Path) -> Path:
    """Create a sample quiz JSON file."""
    quiz_file = tmp_path / "quiz.json"
    quiz_data = {
        "questions": [
            {
                "question_id": "mc1",
                "question_type": "multiple_choice",
                "question_text": "What is 2+2?",
                "options": ["3", "4", "5", "6"],
                "correct_answer": 1,
                "allow_multiple": False,
                "points": 1.0,
            },
            {
                "question_id": "mc2",
                "question_type": "multiple_choice",
                "question_text": "Select prime numbers",
                "options": ["2", "4", "5", "6"],
                "correct_answer": [0, 2],
                "allow_multiple": True,
                "points": 2.0,
            },
            {
                "question_id": "fb1",
                "question_type": "fill_blank",
                "question_text": "The capital of France is _____.",
                "correct_answers": ["Paris"],
                "case_sensitive": False,
                "points": 1.0,
            },
            {
                "question_id": "tf1",
                "question_type": "true_false",
                "question_text": "Python is a compiled language.",
                "correct_answer": False,
                "points": 1.0,
            },
            {
                "question_id": "es1",
                "question_type": "essay",
                "question_text": "Explain OOP.",
                "model_answer": "Object-oriented programming...",
                "keywords": ["objects", "classes", "inheritance"],
                "points": 5.0,
            },
        ],
    }
    with Path(quiz_file).open("w", encoding="utf-8") as f:
        json.dump(quiz_data, f)
    return quiz_file


class TestMultipleChoiceQuestion:
    """Tests for MultipleChoiceQuestion."""

    def test_single_correct_answer(self):
        """Test checking single correct answer."""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="What is 2+2?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        is_correct, explanation = question.check_answer(1)
        assert is_correct, f"Expected is_correct to be True, got {is_correct}"
        assert "Correct" in explanation, f"Expected 'Correct' in explanation, got '{explanation}'"

        is_correct, explanation = question.check_answer(0)
        assert not is_correct, f"Expected is_correct to be False, got {is_correct}"
        assert "Incorrect" in explanation, f"Expected 'Incorrect' in explanation, got '{explanation}'"
        assert "4" in explanation, f"Expected '4' in explanation, got '{explanation}'"

    def test_multiple_correct_answers(self):
        """Test checking multiple correct answers."""
        question = MultipleChoiceQuestion(
            question_id="mc2",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="Select prime numbers",
            options=["2", "4", "5", "6"],
            correct_answer=[0, 2],
            allow_multiple=True,
        )

        is_correct, explanation = question.check_answer([0, 2])
        assert is_correct, f"Expected is_correct to be True, got {is_correct}"
        assert "Correct" in explanation, f"Expected 'Correct' in explanation, got '{explanation}'"

        is_correct, explanation = question.check_answer([0])
        assert not is_correct, f"Expected is_correct to be False, got {is_correct}"

    def test_to_dict(self):
        """Test converting question to dictionary."""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="What is 2+2?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        data = question.to_dict()
        assert data["question_id"] == "mc1", f"Expected question_id 'mc1', got '{data['question_id']}'"
        assert data["question_type"] == "multiple_choice", (
            f"Expected question_type 'multiple_choice', got '{data['question_type']}'"
        )
        assert data["options"] == ["3", "4", "5", "6"], f"Expected options ['3', '4', '5', '6'], got {data['options']}"
        assert data["correct_answer"] == 1, f"Expected correct_answer 1, got {data['correct_answer']}"

    def test_from_dict(self):
        """Test creating question from dictionary."""
        data = {
            "question_id": "mc1",
            "question_type": "multiple_choice",
            "question_text": "What is 2+2?",
            "options": ["3", "4", "5", "6"],
            "correct_answer": 1,
            "allow_multiple": False,
            "points": 1.0,
        }

        question = MultipleChoiceQuestion.from_dict(data)
        assert question.question_id == "mc1", f"Expected question_id 'mc1', got '{question.question_id}'"
        assert question.correct_answer == 1, f"Expected correct_answer 1, got {question.correct_answer}"
        assert question.points == pytest.approx(1.0), f"Expected points 1.0, got {question.points}"


class TestFillBlankQuestion:
    """Tests for FillBlankQuestion."""

    def test_case_insensitive_answer(self):
        """Test checking case-insensitive answer."""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="The capital of France is _____.",
            correct_answers=["Paris"],
            case_sensitive=False,
        )

        is_correct, _ = question.check_answer("Paris")
        assert is_correct, f"Expected is_correct to be True for answer 'Paris', got {is_correct}"

        is_correct, _ = question.check_answer("paris")
        assert is_correct, f"Expected is_correct to be True for answer 'paris', got {is_correct}"

        is_correct, _ = question.check_answer("PARIS")
        assert is_correct, f"Expected is_correct to be True for answer 'PARIS', got {is_correct}"

    def test_case_sensitive_answer(self):
        """Test checking case-sensitive answer."""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="The capital of France is _____.",
            correct_answers=["Paris"],
            case_sensitive=True,
        )

        is_correct, _ = question.check_answer("Paris")
        assert is_correct, f"Expected is_correct to be True for answer 'Paris', got {is_correct}"

        is_correct, _ = question.check_answer("paris")
        assert not is_correct, f"Expected is_correct to be False for answer 'paris', got {is_correct}"

    def test_multiple_valid_answers(self):
        """Test checking multiple valid answers."""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="Select colors",
            correct_answers=["Red", "Blue", "Green"],
            case_sensitive=False,
        )

        is_correct, _ = question.check_answer("red")
        assert is_correct, f"Expected is_correct to be True for answer 'red', got {is_correct}"

        is_correct, _ = question.check_answer("blue")
        assert is_correct, f"Expected is_correct to be True for answer 'blue', got {is_correct}"

    def test_to_dict_and_from_dict(self):
        """Test serialization and deserialization."""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="The capital of France is _____.",
            correct_answers=["Paris"],
            case_sensitive=False,
            points=2.0,
        )

        data = question.to_dict()
        assert data["correct_answers"] == ["Paris"], (
            f"Expected correct_answers ['Paris'], got {data['correct_answers']}"
        )
        assert data["case_sensitive"] is False, f"Expected case_sensitive False, got {data['case_sensitive']}"

        new_question = FillBlankQuestion.from_dict(data)
        assert new_question.question_id == "fb1", f"Expected question_id 'fb1', got '{new_question.question_id}'"
        assert new_question.correct_answers == ["Paris"], (
            f"Expected correct_answers ['Paris'], got {new_question.correct_answers}"
        )


class TestTrueFalseQuestion:
    """Tests for TrueFalseQuestion."""

    def test_boolean_answer(self):
        """Test checking boolean answer."""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python is a compiled language.",
            correct_answer=False,
        )

        is_correct, _ = question.check_answer(answer=False)
        assert is_correct, f"Expected is_correct to be True for answer False, got {is_correct}"

        is_correct, _ = question.check_answer(answer=True)
        assert not is_correct, f"Expected is_correct to be False for answer True, got {is_correct}"

    def test_string_answer(self):
        """Test checking string answer."""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python is a compiled language.",
            correct_answer=False,
        )

        for answer in ["false", "f", "no", "n"]:
            is_correct, _ = question.check_answer(answer=answer)
            assert is_correct, f"Expected is_correct to be True for answer '{answer}', got {is_correct}"

        for answer in ["true", "t", "yes", "y"]:
            is_correct, _ = question.check_answer(answer=answer)
            assert not is_correct, f"Expected is_correct to be False for answer '{answer}', got {is_correct}"

    def test_invalid_string_answer(self):
        """Test invalid string answer."""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python is a compiled language.",
            correct_answer=False,
        )

        is_correct, explanation = question.check_answer(answer="invalid")
        assert not is_correct, f"Expected is_correct to be False for answer 'invalid', got {is_correct}"
        assert "Invalid" in explanation, f"Expected 'Invalid' in explanation, got '{explanation}'"


class TestEssayQuestion:
    """Tests for EssayQuestion."""

    def test_keyword_validation(self):
        """Test keyword-based validation."""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="Explain OOP.",
            model_answer="Object-oriented programming...",
            keywords=["objects", "classes", "inheritance"],
        )

        # All keywords present
        is_correct, _ = question.check_answer("OOP uses objects and classes with inheritance.")
        assert is_correct, f"Expected is_correct to be True, got {is_correct}"

        # Partial keywords
        is_correct, _ = question.check_answer("OOP uses objects and classes.")
        assert is_correct, (
            f"Expected is_correct to be True (2 out of 3 keywords), got {is_correct}"
        )  # 2 out of 3 keywords (>= 50%)

        # No keywords
        is_correct, _ = question.check_answer("I don't know.")
        assert not is_correct, f"Expected is_correct to be False, got {is_correct}"

    def test_no_keywords(self):
        """Test essay question without keywords."""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="Explain OOP.",
            model_answer="Object-oriented programming...",
            keywords=[],
        )

        is_correct, explanation = question.check_answer("Some answer.")
        assert is_correct, f"Expected is_correct to be True when no keywords, got {is_correct}"
        assert "recorded" in explanation, f"Expected 'recorded' in explanation, got '{explanation}'"

    def test_to_dict_and_from_dict(self):
        """Test serialization and deserialization."""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="Explain OOP.",
            model_answer="Object-oriented programming...",
            keywords=["objects", "classes", "inheritance"],
            points=5.0,
        )

        data = question.to_dict()
        assert data["model_answer"] == "Object-oriented programming...", (
            f"Expected model_answer 'Object-oriented programming...', got '{data['model_answer']}'"
        )
        assert data["keywords"] == ["objects", "classes", "inheritance"], (
            f"Expected keywords ['objects', 'classes', 'inheritance'], got {data['keywords']}"
        )

        new_question = EssayQuestion.from_dict(data)
        assert new_question.question_id == "es1", f"Expected question_id 'es1', got '{new_question.question_id}'"
        assert new_question.keywords == ["objects", "classes", "inheritance"], (
            f"Expected keywords ['objects', 'classes', 'inheritance'], got {new_question.keywords}"
        )


class TestQuestionFactory:
    """Tests for Question factory methods."""

    def test_from_dict_multiple_choice(self):
        """Test creating MultipleChoiceQuestion from dict."""
        data: dict[str, Any] = {
            "question_id": "mc1",
            "question_type": "multiple_choice",
            "question_text": "What is 2+2?",
            "options": ["3", "4", "5", "6"],
            "correct_answer": 1,
            "allow_multiple": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, MultipleChoiceQuestion), (
            f"Expected MultipleChoiceQuestion instance, got {type(question)}"
        )

    def test_from_dict_fill_blank(self):
        """Test creating FillBlankQuestion from dict."""
        data: dict[str, Any] = {
            "question_id": "fb1",
            "question_type": "fill_blank",
            "question_text": "The capital of France is _____.",
            "correct_answers": ["Paris"],
            "case_sensitive": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, FillBlankQuestion), f"Expected FillBlankQuestion instance, got {type(question)}"

    def test_from_dict_true_false(self):
        """Test creating TrueFalseQuestion from dict."""
        data: dict[str, Any] = {
            "question_id": "tf1",
            "question_type": "true_false",
            "question_text": "Python is a compiled language.",
            "correct_answer": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, TrueFalseQuestion), f"Expected TrueFalseQuestion instance, got {type(question)}"

    def test_from_dict_essay(self):
        """Test creating EssayQuestion from dict."""
        data: dict[str, Any] = {
            "question_id": "es1",
            "question_type": "essay",
            "question_text": "Explain OOP.",
            "model_answer": "Object-oriented programming...",
            "keywords": ["objects", "classes"],
        }
        question = Question.from_dict(data)
        assert isinstance(question, EssayQuestion), f"Expected EssayQuestion instance, got {type(question)}"


class TestQuizSession:
    """Tests for QuizSession."""

    def test_load_from_json(self, sample_quiz_json: Path):
        """Test loading questions from JSON file."""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)
        assert session.total_questions == 5, f"Expected total_questions 5, got {session.total_questions}"

    def test_sequential_order(self, sample_quiz_json: Path):
        """Test sequential question order."""
        session = QuizSession(random_order=False)
        session.load_from_json(sample_quiz_json)

        first_question = session.get_current_question()
        assert first_question, "Expected first_question to be not None"
        assert first_question.question_id == "mc1", f"Expected question_id 'mc1', got '{first_question.question_id}'"

        session.submit_answer(1)

        second_question = session.get_current_question()
        assert second_question, "Expected second_question to be not None"
        assert second_question.question_id == "mc2", f"Expected question_id 'mc2', got '{second_question.question_id}'"

    def test_random_order(self, sample_quiz_json: Path):
        """Test random question order."""
        session = QuizSession(random_order=True)
        session.load_from_json(sample_quiz_json)

        # Get all question IDs in random order
        question_ids = []
        while not session.is_finished():
            question = session.get_current_question()
            if question:
                question_ids.append(question.question_id)
                session.submit_answer(1 if isinstance(question, MultipleChoiceQuestion) else "test")

        # Verify all questions were answered
        assert len(question_ids) == 5, f"Expected 5 question_ids, got {len(question_ids)}"

    def test_submit_answer(self, sample_quiz_json: Path):
        """Test submitting answer."""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        question = session.get_current_question()
        assert isinstance(question, MultipleChoiceQuestion), f"Expected MultipleChoiceQuestion, got {type(question)}"

        result = session.submit_answer(1)  # Correct answer for "What is 2+2?"
        assert result is not None, "Expected result to be not None"
        assert result.is_correct, f"Expected result.is_correct to be True, got {result.is_correct}"
        assert result.user_answer == 1, f"Expected user_answer 1, got {result.user_answer}"

    def test_statistics(self, sample_quiz_json: Path):
        """Test session statistics calculation."""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        # Answer all questions
        while not session.is_finished():
            question = session.get_current_question()
            if question:
                if isinstance(question, MultipleChoiceQuestion):
                    session.submit_answer(1 if not question.allow_multiple else [0])
                elif isinstance(question, FillBlankQuestion):
                    session.submit_answer("Paris")
                elif isinstance(question, TrueFalseQuestion):
                    session.submit_answer(True)
                else:
                    session.submit_answer("Some answer")

        summary = session.get_summary()
        assert summary["total_questions"] == 5, f"Expected total_questions 5, got {summary['total_questions']}"
        assert summary["answered"] == 5, f"Expected answered 5, got {summary['answered']}"
        assert summary["correct"] > 0 or summary["wrong"] > 0, (
            f"Expected correct>0 or wrong>0, got correct={summary['correct']}, wrong={summary['wrong']}"
        )
        assert summary["accuracy"] >= 0.0, f"Expected accuracy >= 0.0, got {summary['accuracy']}"
        assert summary["accuracy"] <= 100.0, f"Expected accuracy <= 100.0, got {summary['accuracy']}"

    def test_wrong_answers(self, tmp_path: Path):
        """Test wrong answers collection and saving."""
        quiz_file = tmp_path / "quiz.json"
        quiz_data = {
            "questions": [
                {
                    "question_id": "mc1",
                    "question_type": "multiple_choice",
                    "question_text": "What is 2+2?",
                    "options": ["3", "4", "5"],
                    "correct_answer": 1,
                    "allow_multiple": False,
                },
            ],
        }
        with Path(quiz_file).open("w", encoding="utf-8") as f:
            json.dump(quiz_data, f)

        session = QuizSession(wrong_answer_file=str(tmp_path / "wrong.json"))
        session.load_from_json(quiz_file)

        # Submit wrong answer
        session.submit_answer(0)

        wrong_answers = session.get_wrong_answers()
        assert len(wrong_answers) == 1, f"Expected 1 wrong answer, got {len(wrong_answers)}"
        assert not wrong_answers[0].is_correct, f"Expected is_correct to be False, got {wrong_answers[0].is_correct}"

        # Save wrong answers
        session.save_wrong_answers()

        wrong_file = tmp_path / "wrong.json"
        assert wrong_file.exists(), f"Expected wrong_file {wrong_file} to exist"

        with Path(wrong_file).open(encoding="utf-8") as f:
            data = json.load(f)
            assert "wrong_answers" in data, f"Expected 'wrong_answers' key in data, got {data.keys()}"
            assert len(data["wrong_answers"]) == 1, f"Expected 1 wrong_answer in data, got {len(data['wrong_answers'])}"

    def test_reset(self, sample_quiz_json: Path):
        """Test resetting quiz session."""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        # Answer one question
        session.submit_answer(1)
        assert len(session.results) == 1, f"Expected 1 result, got {len(session.results)}"

        # Reset
        session.reset()
        assert len(session.results) == 0, f"Expected 0 results after reset, got {len(session.results)}"
        assert session._current_index == 0, f"Expected _current_index 0, got {session._current_index}"

    def test_get_current_question_after_finish(self, sample_quiz_json: Path):
        """Test getting current question after quiz is finished."""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        # Answer all questions
        while not session.is_finished():
            question = session.get_current_question()
            if question:
                session.submit_answer(1 if isinstance(question, MultipleChoiceQuestion) else "test")

        # Try to get question after finish
        question = session.get_current_question()
        assert question is None, f"Expected question to be None after quiz finished, got {question}"


class TestCreateSampleQuizData:
    """Tests for create_sample_quiz_data function."""

    def test_create_sample_quiz(self, tmp_path: Path):
        """Test creating sample quiz data file."""
        output_file = tmp_path / "sample_quiz.json"
        create_sample_quiz_data(output_file)

        assert output_file.exists(), f"Expected output_file {output_file} to exist"

        with Path(output_file).open(encoding="utf-8") as f:
            data = json.load(f)
            assert "title" in data, f"Expected 'title' key in data, got {data.keys()}"
            assert "questions" in data, f"Expected 'questions' key in data, got {data.keys()}"
            assert len(data["questions"]) == 7, f"Expected 7 questions, got {len(data['questions'])}"

            # Verify all question types are present
            question_types = {q["question_type"] for q in data["questions"]}
            expected_types = {
                "multiple_choice",
                "fill_blank",
                "true_false",
                "essay",
            }
            assert question_types == expected_types, f"Expected question_types {expected_types}, got {question_types}"


class TestQuizResult:
    """Tests for QuizResult dataclass."""

    def test_to_dict(self):
        """Test converting result to dictionary."""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="What is 2+2?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        result = QuizResult(question=question, user_answer=1, is_correct=True, explanation="Correct!")

        data = result.to_dict()
        assert data["question"]["question_id"] == "mc1", (
            f"Expected question_id 'mc1', got '{data['question']['question_id']}'"
        )
        assert data["user_answer"] == 1, f"Expected user_answer 1, got {data['user_answer']}"
        assert data["is_correct"] is True, f"Expected is_correct True, got {data['is_correct']}"
        assert data["explanation"] == "Correct!", f"Expected explanation 'Correct!', got '{data['explanation']}'"
