"""Tests for pdf2img module."""
