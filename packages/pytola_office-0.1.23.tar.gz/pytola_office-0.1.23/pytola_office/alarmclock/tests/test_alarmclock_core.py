"""Core tests for alarmclock module (non-GUI tests)."""

from __future__ import annotations

import pytest

from pytola_office.alarmclock.gui import AlarmClockConfig


class TestAlarmClockFunctionality:
    """Tests for alarm clock core functionality."""

    def test_digital_clock_time_format(self):
        """Test digital clock time formatting."""
        from datetime import datetime, timedelta, timezone

        # Test time formatting
        test_time = datetime.now(timezone.utc) + timedelta(hours=8)
        formatted_time = test_time.strftime("%H:%M:%S")

        # Verify format
        assert len(formatted_time) == 8  # HH:MM:SS
        assert formatted_time[2] == ":"  # Hour-minute separator
        assert formatted_time[5] == ":"  # Minute-second separator

    def test_delay_steps_calculation(self):
        """Test delay steps calculation."""
        config = AlarmClockConfig()

        # Verify delay steps are reasonable
        assert len(config.DELAY_STEPS) == 6
        assert all(isinstance(step, int) for step in config.DELAY_STEPS)
        assert all(step > 0 for step in config.DELAY_STEPS)

    def test_blink_colors_validation(self):
        """Test blink colors are valid."""
        config = AlarmClockConfig()

        # Verify blink colors are valid hex colors
        for color in config.BLINK_BG_COLORS:
            assert color.startswith("#")
            assert len(color) == 7  # #RRGGBB format
            assert all(c.lower() in "0123456789abcdef" for c in color[1:])

    def test_digital_colors_validation(self):
        """Test digital clock colors are valid."""
        config = AlarmClockConfig()

        # Verify digital colors are valid
        assert config.DIGITAL_COLOR.startswith("#")
        assert len(config.DIGITAL_COLOR) == 7

        for color in config.DIGITAL_BORDER_COLORS:
            assert color.startswith("#")
            assert len(color) == 7


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
