"""Threads module for filescan."""
