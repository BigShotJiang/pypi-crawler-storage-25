"""Widgets module for filescan."""
