"""Filetreeviewer Ui module for widgets."""

# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'filetreeviewer.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_FileTreeViewer(object):
    def setupUi(self, FileTreeViewer):
        if not FileTreeViewer.objectName():
            FileTreeViewer.setObjectName(u"FileTreeViewer")
        FileTreeViewer.resize(720, 480)
        FileTreeViewer.setMinimumSize(QSize(720, 480))
        self.verticalLayout_2 = QVBoxLayout(FileTreeViewer)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.stacked_widget = QStackedWidget(FileTreeViewer)
        self.stacked_widget.setObjectName(u"stacked_widget")
        self.page_by_directory = QWidget()
        self.page_by_directory.setObjectName(u"page_by_directory")
        self.horizontalLayout_2 = QHBoxLayout(self.page_by_directory)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.directory_tree = QTreeView(self.page_by_directory)
        self.directory_tree.setObjectName(u"directory_tree")

        self.horizontalLayout_2.addWidget(self.directory_tree)

        self.stacked_widget.addWidget(self.page_by_directory)
        self.page_by_category = QWidget()
        self.page_by_category.setObjectName(u"page_by_category")
        self.horizontalLayout_3 = QHBoxLayout(self.page_by_category)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.category_tree = QTreeView(self.page_by_category)
        self.category_tree.setObjectName(u"category_tree")

        self.horizontalLayout_3.addWidget(self.category_tree)

        self.stacked_widget.addWidget(self.page_by_category)

        self.horizontalLayout.addWidget(self.stacked_widget)

        self.operation_groupbox = QGroupBox(FileTreeViewer)
        self.operation_groupbox.setObjectName(u"operation_groupbox")
        self.verticalLayout = QVBoxLayout(self.operation_groupbox)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.open_button = QPushButton(self.operation_groupbox)
        self.open_button.setObjectName(u"open_button")
        self.open_button.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.open_button)

        self.locate_button = QPushButton(self.operation_groupbox)
        self.locate_button.setObjectName(u"locate_button")
        self.locate_button.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.locate_button)

        self.mark_normal_button = QPushButton(self.operation_groupbox)
        self.mark_normal_button.setObjectName(u"mark_normal_button")
        self.mark_normal_button.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.mark_normal_button)

        self.spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.spacer)

        self.toggle_view_button = QPushButton(self.operation_groupbox)
        self.toggle_view_button.setObjectName(u"toggle_view_button")
        self.toggle_view_button.setMinimumSize(QSize(0, 30))

        self.verticalLayout.addWidget(self.toggle_view_button)


        self.horizontalLayout.addWidget(self.operation_groupbox)


        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.progress_bar = QProgressBar(FileTreeViewer)
        self.progress_bar.setObjectName(u"progress_bar")
        self.progress_bar.setValue(24)

        self.verticalLayout_2.addWidget(self.progress_bar)


        self.retranslateUi(FileTreeViewer)

        self.stacked_widget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(FileTreeViewer)
    # setupUi

    def retranslateUi(self, FileTreeViewer):
        FileTreeViewer.setWindowTitle(QCoreApplication.translate("FileTreeViewer", u"\u641c\u7d22\u7ed3\u679c", None))
        self.operation_groupbox.setTitle(QCoreApplication.translate("FileTreeViewer", u"\u64cd\u4f5c", None))
        self.open_button.setText(QCoreApplication.translate("FileTreeViewer", u"\u67e5\u770b\u6587\u4ef6", None))
        self.locate_button.setText(QCoreApplication.translate("FileTreeViewer", u"\u5b9a\u4f4d\u6587\u4ef6", None))
        self.mark_normal_button.setText(QCoreApplication.translate("FileTreeViewer", u"\u6807\u8bb0\u8df3\u8fc7", None))
        self.toggle_view_button.setText(QCoreApplication.translate("FileTreeViewer", u"\u5207\u6362\u89c6\u56fe", None))
    # retranslateUi
