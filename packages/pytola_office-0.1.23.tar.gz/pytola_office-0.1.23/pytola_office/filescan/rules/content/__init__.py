"""Content rules module for filescan - 文件内容规则."""

from ._base import BaseContentRule
from .csv import CsvRule
from .docx import DocxRule
from .epub import EpubRule
from .html import HtmlRule
from .image import ImageRule
from .markdown import MarkdownRule
from .odt import OdtRule
from .pdf import PdfRule
from .pptx import PptxRule
from .rtf import RtfRule
from .xlsx import XlsxRule
from .xml import XmlRule

__all__ = [
    "BaseContentRule",
    "CsvRule",
    "DocxRule",
    "EpubRule",
    "HtmlRule",
    "ImageRule",
    "MarkdownRule",
    "OdtRule",
    "PdfRule",
    "PptxRule",
    "RtfRule",
    "XlsxRule",
    "XmlRule",
]
