"""Tests for filescan rules module - 文件扫描规则测试模块."""
