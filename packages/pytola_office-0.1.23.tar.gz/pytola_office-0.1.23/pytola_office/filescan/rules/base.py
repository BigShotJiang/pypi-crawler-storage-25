"""Base rule module for filescan - 规则基础类."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from ..models.fileinfo import FileInfo, MatchInfo


@dataclass
class BaseRuleConfig:
    """规则配置基础类."""

    name: str
    description: str
    level: int
    patterns: list[str]
    regex: bool
    case_sensitive: bool

    @classmethod
    def from_dict(cls, data: dict) -> BaseRuleConfig:
        """从字典创建规则配置对象.

        Args:
            data: 包含规则配置的字典

        Returns
        -------
            规则配置对象
        """
        return cls(
            name=data["name"],
            description=data["description"],
            level=data["level"],
            patterns=data["patterns"],
            regex=data["regex"],
            case_sensitive=data["case_sensitive"],
        )


class BaseRule(ABC):
    """规则基础类."""

    @abstractmethod
    def match(self, fileinfo: FileInfo) -> MatchInfo | None:
        """匹配文件.

        Args:
            fileinfo: 文件信息

        Returns
        -------
            如果匹配返回 MatchInfo，否则返回 None
        """
