"""Rules module for filescan."""
