"""Image to ICO conversion module.

This module provides functionality to convert various image formats to ICO files.
Includes both command-line and GUI interfaces.
"""

from __future__ import annotations

from .cli import ImageToIcoConfig, ImageToIcoRunner, is_valid_image, main, parse_sizes
from .gui import main as gui_main

__all__ = [
    "ImageToIcoConfig",
    "ImageToIcoRunner",
    "gui_main",
    "is_valid_image",
    "main",
    "parse_sizes",
]
