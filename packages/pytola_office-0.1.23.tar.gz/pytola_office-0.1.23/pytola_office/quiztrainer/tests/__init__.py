"""QuizTrainer 测试包."""
