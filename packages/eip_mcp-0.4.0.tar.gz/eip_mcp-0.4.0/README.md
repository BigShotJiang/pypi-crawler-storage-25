# Exploit Intel Platform MCP Server
<!-- mcp-name: com.exploit-intel/eip-mcp -->

Package/command: `eip-mcp`

<p align="center">
  <img src="https://exploit-intel.com/static/brand/mark-cyan.svg" width="160" alt="Exploit Intel Platform (EIP)" />
</p>

An MCP (Model Context Protocol) server that gives AI assistants access to the [Exploit Intelligence Platform](https://exploit-intel.com) — vulnerability and exploit intelligence from NVD, CISA KEV, VulnCheck KEV, InTheWild.io, ENISA EUVD, OSV.dev, EPSS, ExploitDB, Metasploit, GitHub, and more. Supports both stdio and Streamable HTTP transport.

Part of the same project family:
- [`eip-search`](https://github.com/exploitintel/eip-search) — terminal client
- [`eip-mcp`](https://github.com/exploitintel/eip-mcp) — MCP server for AI assistants

## Overview

### Highlights

- Give AI assistants real-time vulnerability and exploit intelligence
- Query CVEs with rich filters and ranked exploit context
- Include AI exploit analysis, MITRE ATT&CK mapping, and trojan indicators
- Generate pentest findings directly from CVE data
- Every exploit includes a clickable source URL (GitHub, ExploitDB, Metasploit)
- Nuclei templates include description, impact, and remediation text
- Run over stdio for desktop clients or Streamable HTTP for hosted deployments

### What This Enables

With this MCP server, your AI assistant can:

- Search vulnerabilities with 15+ filters (severity, vendor, product, EPSS, KEV, Nuclei, year, date range)
- Choose score semantics explicitly when needed:
  - legacy `min_cvss` stays CVSS v3-only
  - `min_score` + `score_version=v3|v4|effective`
  - `sort=score_desc`
- Search exploits by source, language, author, GitHub stars, or LLM classification
- Get full CVE intelligence briefs with ranked exploits and trojan warnings
- Find all exploits for a specific CVE, vendor, or product
- Resolve alternate IDs (EDB-XXXXX, GHSA-XXXXX) to their CVE
- Discover exact product names for any vendor (CPE product name lookup)
- Look up exploit authors and their work
- Browse CWE categories and vendor threat landscapes
- Audit a tech stack for exploitable vulnerabilities
- Generate pentest report findings from real CVE data (all sections present with N/A when data is absent)
- Retrieve exploit source code for analysis
- See MITRE ATT&CK techniques and deception indicators for trojans

## Tools (17)

| Tool | Description |
|---|---|
| `search_vulnerabilities` | Search CVEs with full-text `query` and filters: severity, vendor, product, ecosystem, CWE, CVSS/EPSS thresholds, KEV, Nuclei, year, date range. Supports explicit score mode via `score_version` + `min_score` + `sort=score_desc`. **Start here for product research.** |
| `get_vulnerability` | Full intelligence brief for a CVE or EIP-ID. **Includes ranked exploits** (AI analysis, MITRE techniques, source URLs), products, Nuclei templates (with description/impact/remediation), references. |
| `search_exploits` | Browse exploits with **structured filters only** (no free-text query): source, language, LLM classification, author, stars, CVE, vendor, product, attack_type, complexity, reliability, requires_auth. |
| `get_exploit_code` | Retrieve exploit source code by platform ID (auto-selects main file) |
| `get_exploit_analysis` | Full AI analysis for a single exploit: classification, attack type, complexity, reliability, MITRE ATT&CK, summary, and trojan/deception indicators |
| `get_nuclei_templates` | Nuclei scanner templates with description, impact, remediation, and Shodan/FOFA/Google dork queries |
| `list_authors` | Top exploit researchers ranked by exploit count |
| `get_author` | Author profile with all their exploits and CVE context |
| `list_cwes` | CWE categories ranked by vulnerability count |
| `get_cwe` | CWE detail with description, exploit likelihood, parent hierarchy |
| `list_vendors` | Software vendors ranked by vulnerability count |
| `list_products` | Discover exact product names for a vendor (CPE name lookup with vuln counts) |
| `lookup_alt_id` | Resolve alternate IDs (EDB-XXXXX, GHSA-XXXXX) to their CVE |
| `audit_stack` | Audit a tech stack for critical/high severity CVEs with exploits, sorted by EPSS risk |
| `generate_finding` | Generate a Markdown pentest report finding — all sections present with N/A when data is absent |
| `get_platform_stats` | Platform-wide counts and data freshness |
| `check_health` | API health and ingestion source timestamps |

## Prompts (6)

Built-in MCP prompts are also exported for clients that support prompts/skills:

| Prompt | Description |
|---|---|
| `investigate-cve` | Deep-dive workflow for a specific CVE or EIP-ID |
| `audit-stack` | Prioritized stack audit workflow for up to 5 technologies |
| `pentest-finding` | Pentest finding workflow with optional target and notes |
| `threat-landscape` | Vendor/product threat landscape workflow |
| `exploit-analysis` | Safety-first exploit review workflow |
| `trending-threats` | Recent threat briefing focused on KEV, ransomware, or in-the-wild exploitation |

## Installation

### Requirements

- **Python 3.10 or newer** (check with `python3 --version` or `python --version`)
- **pip** (comes with Python on most systems)
- An MCP-compatible AI client (Cursor IDE, Claude Desktop, etc.)

Base installation is enough for stdio clients. If you want to run the standalone Streamable HTTP server, install the optional HTTP extra:

```bash
pip install "eip-mcp[http]"
# or
pipx install 'eip-mcp[http]'
```

### macOS

```bash
# Install Python 3 via Homebrew if needed
brew install python3

# Recommended: pipx (isolated install, eip-mcp command available globally)
brew install pipx
pipx install eip-mcp

# Alternative: virtual environment
python3 -m venv ~/.venvs/eip-mcp
source ~/.venvs/eip-mcp/bin/activate
pip install eip-mcp
```

### Kali Linux / Debian / Ubuntu

```bash
# Option 1: Native APT repo (recommended on Kali/Debian/Ubuntu)
curl -fsSL https://repo.exploit-intel.com/setup.sh | sudo bash
sudo apt install -y eip-mcp

# Option 2: pipx (isolated install, eip-mcp command available globally)
sudo apt install -y pipx
pipx install eip-mcp

# Option 3: virtual environment
sudo apt update && sudo apt install -y python3-pip python3-venv
python3 -m venv ~/.venvs/eip-mcp
source ~/.venvs/eip-mcp/bin/activate
pip install eip-mcp
```

> **Kali users**: If you see `error: externally-managed-environment`, use APT, `pipx`, or a virtual environment. Kali 2024+ enforces PEP 668 and blocks global pip installs.

### Windows

```powershell
# Install Python 3 from https://python.org (check "Add to PATH" during install)

# Option 1: pipx
pip install pipx
pipx install eip-mcp

# Option 2: virtual environment
python -m venv %USERPROFILE%\.venvs\eip-mcp
%USERPROFILE%\.venvs\eip-mcp\Scripts\activate
pip install eip-mcp
```

### Arch Linux / Manjaro

```bash
sudo pacman -S python python-pip python-pipx
pipx install eip-mcp
```

### From Source (all platforms)

```bash
git clone https://github.com/exploitintel/eip-mcp.git
cd eip-mcp
python3 -m venv .venv
source .venv/bin/activate      # Linux/macOS
# .venv\Scripts\activate       # Windows
pip install -e .

# Optional: include HTTP transport dependencies
pip install -e '.[http]'
```

## Running the Server Directly

### stdio (default)

```bash
eip-mcp
```

### Streamable HTTP

Install the HTTP extra first, then run:

```bash
eip-mcp --transport streamable-http
```

Useful flags:

- `--host 127.0.0.1` and `--port 8080` control the bind address
- `--stateless` disables session tracking for horizontally scaled deployments

Equivalent environment variables:

- `EIP_MCP_TRANSPORT`
- `EIP_MCP_HOST`
- `EIP_MCP_PORT`
- `EIP_MCP_STATELESS`
- `EIP_API_KEY` to forward an optional `X-API-Key` header for custom deployments that expect it

If you bind HTTP to `0.0.0.0` or `::`, set `EIP_MCP_ALLOWED_HOSTS` to the hostname or IP your clients will use. For browser-based access, also set `EIP_MCP_ALLOWED_ORIGINS`.

## Connecting to Your AI Client

### Cursor IDE

Add to `.cursor/mcp.json` in your workspace (or globally at `~/.cursor/mcp.json`):

**If installed with pipx** (recommended):

```json
{
  "mcpServers": {
    "eip": {
      "command": "eip-mcp",
      "args": [],
      "env": {}
    }
  }
}
```

**If installed in a virtual environment:**

```json
{
  "mcpServers": {
    "eip": {
      "command": "/absolute/path/to/.venvs/eip-mcp/bin/eip-mcp",
      "args": [],
      "env": {}
    }
  }
}
```

> **Note**: When using a virtual environment, use the absolute path to the `eip-mcp` binary inside it. On macOS/Linux: `~/.venvs/eip-mcp/bin/eip-mcp`. On Windows: `%USERPROFILE%\.venvs\eip-mcp\Scripts\eip-mcp.exe`.

### Claude Desktop

**macOS** — add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "eip": {
      "command": "eip-mcp",
      "args": [],
      "env": {}
    }
  }
}
```

**Windows** — add to `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "eip": {
      "command": "eip-mcp",
      "args": [],
      "env": {}
    }
  }
}
```

> If your AI client can't find `eip-mcp`, use the full path to the binary (see virtual environment note above).

### Verify

After restarting your AI client, you should see 17 tools available. In clients that surface prompts, you should also see 6 prompts. Try asking:

> "Show me all trojan exploits"

### Troubleshooting

| Problem | Solution |
|---|---|
| MCP server not showing up | If using a venv, use the full absolute path to the `eip-mcp` binary |
| `command not found: eip-mcp` | Make sure your venv is activated, or use `pipx` which manages PATH automatically |
| `externally-managed-environment` | Use `pipx` or a virtual environment (see install instructions above) |
| `Streamable HTTP transport requires additional packages` | Install the optional HTTP dependencies with `pip install "eip-mcp[http]"` or `pip install -e '.[http]'` |
| Connection timeout errors | Check that you can reach `https://exploit-intel.com` from your machine |
| 0 tools showing | Restart Cursor/Claude Desktop after editing the MCP config |

### Demo

[![asciicast](https://asciinema.org/a/hSVPAlO9qNqQIxug.svg)](https://asciinema.org/a/hSVPAlO9qNqQIxug)

### What Questions Can You Ask?

Below are representative example prompts with sample output from the live platform. Exact counts and rankings will change over time.

---

#### "Show me all the backdoored/trojan exploits"

Uses `search_exploits` with `llm_classification=trojan`:

```
Found 38 exploits (page 1/13):

      ★0  nomisec      vatslaaeytoygag/CVE-2025-59287
         CVE-2025-59287  CRITICAL  CVSS:9.8  [] trojan
         AI: other | moderate | theoretical
         !! Obfuscated hex strings in `encrypt.py`
         !! Subprocess calls to execute remote payloads

          writeup      exploit-116218
         CVE-2026-2641  LOW  CVSS:3.3  [] trojan
         AI: other | complex | theoretical
         !! obfuscated garbage characters
         !! no functional exploit logic
```

38 exploits flagged as trojans by AI analysis. Each shows deception indicators explaining exactly how the trojan deceives users.

---

#### "Find all reliable RCE exploits"

Uses `search_exploits` with `attack_type=RCE, reliability=reliable, sort=stars_desc`:

```
Found 24,204 exploits (page 1/4841):

   ★4275  nomisec      zhzyker/exphub
         CVE-2020-14882  CRITICAL  CVSS:9.8  [] working_poc
         AI: RCE | moderate | reliable

   ★3436  nomisec      fullhunt/log4j-scan
         CVE-2021-44228  CRITICAL  CVSS:10.0  [] scanner
         AI: RCE | moderate | reliable

   ★1848  nomisec      kozmer/log4j-shell-poc
         CVE-2021-44228  CRITICAL  CVSS:10.0  [] working_poc
         AI: RCE | moderate | reliable

   ★1835  github       neex/phuip-fpizdam
         CVE-2019-11043  HIGH  CVSS:8.7  [] working_poc
         AI: RCE | moderate | reliable
```

24,204 reliable RCE exploits. Filter further with `complexity=trivial` for easy wins or `requires_auth=false` for unauthenticated attacks.

---

#### "Show me trivial SQL injection exploits that don't require auth"

Uses `search_exploits` with `attack_type=SQLi, complexity=trivial, requires_auth=false`:

```
Found 6,979 exploits (page 1/1396):

      ★0  github       pwnpwnpur1n/CVE-2024-22983
         CVE-2024-22983  HIGH  CVSS:8.1  [php] writeup
         AI: SQLi | trivial | reliable

      ★0  github       security-n/CVE-2021-39379
         CVE-2021-39379  CRITICAL  CVSS:9.8  [] writeup
         AI: SQLi | trivial | reliable
      ...
```

---

#### "Give me all exploits for CVE-2024-3400"

Uses `search_exploits` with `cve=CVE-2024-3400, sort=stars_desc`:

```
Found 43 exploits (page 1/9):

    ★161  github       h4x0r-dz/CVE-2024-3400
         CVE-2024-3400  CRITICAL  CVSS:10.0  [http] working_poc

     ★90  github       W01fh4cker/CVE-2024-3400-RCE-Scan
         CVE-2024-3400  CRITICAL  CVSS:10.0  [python] working_poc

     ★72  github       0x0d3ad/CVE-2024-3400
         CVE-2024-3400  CRITICAL  CVSS:10.0  [python] working_poc

     ★30  github       ihebski/CVE-2024-3400
         CVE-2024-3400  CRITICAL  CVSS:10.0  [http/network] working_poc

     ★14  github       Chocapikk/CVE-2024-3400
         CVE-2024-3400  CRITICAL  CVSS:10.0  [python] working_poc
```

43 exploits, ranked by GitHub stars, with LLM quality classification.

---

#### "How many Mitel exploits are there?"

Uses `search_exploits` with `vendor=mitel, has_code=true`:

```
Found 100 exploits (page 1/34):

          exploitdb    EDB-46666
         CVE-2019-9591  MEDIUM  CVSS:6.1  []

          exploitdb    EDB-32745
         CVE-2014-0160  HIGH  CVSS:7.5  [python]

      ★0  github       lu4m575/CVE-2024-35286_scan.nse
         CVE-2024-35286  CRITICAL  CVSS:9.8  []

      ★17  github       Chocapikk/CVE-2024-41713
         CVE-2024-41713  CRITICAL  CVSS:9.1  [python] working_poc
      ...
```

100 Mitel exploits with downloadable code, across all affected CVEs.

---

#### "Who are the top exploit authors?"

Uses `list_authors`:

```
Exploit Authors (40,931 total):

  Metasploit                      1875 exploits
  Google Security Research        1214 exploits
  Ihsan Sencan                     970 exploits
  LiquidWorm                       780 exploits
  Gjoko 'LiquidWorm' Krstic        674 exploits
```

---

#### "Show me all exploits by Chocapikk"

Uses `get_author` with `author_name=Chocapikk`:

```
Author: Chocapikk
Exploits: 91  |  Active since: 2017-04-25

Exploits:
    ★244  CVE-2026-21858  Chocapikk/CVE-2026-21858  working_poc
    ★235  CVE-2023-29357  Chocapikk/CVE-2023-29357  working_poc
    ★179  CVE-2024-25600  Chocapikk/CVE-2024-25600  working_poc
    ★148  CVE-2023-22515  Chocapikk/CVE-2023-22515  working_poc
    ★134  CVE-2024-45519  Chocapikk/CVE-2024-45519  working_poc
     ★99  CVE-2024-3273  Chocapikk/CVE-2024-3273  working_poc
      ...
```

91 exploits by Chocapikk, ranked by GitHub stars, all classified as working PoCs.

---

#### "What are the most common vulnerability types?"

Uses `list_cwes`:

```
CWE Categories (200 with vulnerabilities):

    CWE-79   41774 vulns  XSS
    CWE-89   17788 vulns  SQL Injection
   CWE-787   13374 vulns  Out-of-Bounds Write
   CWE-119   13344 vulns  Memory Corruption
    CWE-20   11770 vulns  Improper Input Validation
   CWE-200    9555 vulns  Information Disclosure
   CWE-352    8710 vulns  CSRF
   CWE-125    8163 vulns  Out-of-Bounds Read
    CWE-22    8141 vulns  Path Traversal
   CWE-862    6683 vulns  Missing Authorization
      ...
```

---

#### "Tell me about SQL Injection (CWE-89)"

Uses `get_cwe` with `cwe_id=CWE-89`:

```
CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')
Short label: SQL Injection
Exploit likelihood: High
Vulnerabilities: 17,788
Parent: CWE-943 (Improper Neutralization of Special Elements in Data Query Logic)

Description:
The product constructs all or part of an SQL command using externally-influenced
input from an upstream component, but it does not neutralize or incorrectly
neutralizes special elements that could modify the intended SQL command when it
is sent to a downstream component...
```

---

#### "Which vendors have the most vulnerabilities?"

Uses `list_vendors`:

```
Top Vendors (200 total):

  microsoft                       13697 vulns
  google                          12451 vulns
  linux                           12096 vulns
  oracle                          10107 vulns
  debian                          10072 vulns
  apple                            8426 vulns
  ibm                              7981 vulns
  adobe                            6960 vulns
  cisco                            6526 vulns
  redhat                           5505 vulns
      ...
```

---

#### "What critical Fortinet vulns are being actively exploited?"

Uses `search_vulnerabilities` with `vendor=fortinet, severity=critical, is_kev=true, sort=epss_desc`:

```
Found 16 vulnerabilities (page 1/6):

  CVE-2018-13379  CRITICAL  CVSS:9.1  EPSS:94.5%  Exploits:14 [KEV] [NUCLEI]
    Fortinet Fortiproxy < 1.2.9 - Path Traversal

  CVE-2022-40684  CRITICAL  CVSS:9.8  EPSS:94.4%  Exploits:31 [KEV] [NUCLEI]
    Fortinet Fortiproxy < 7.0.7 - Authentication Bypass

  CVE-2024-55591  CRITICAL  CVSS:9.8  EPSS:94.2%  Exploits:9 [KEV] [NUCLEI]
    Fortinet Fortiproxy < 7.0.20 - Authentication Bypass
```

---

#### "Tell me about CVE-2019-0708 (BlueKeep)"

Uses `get_vulnerability` with `cve_id=CVE-2019-0708`:

```
============================================================
CVE-2019-0708  [CRITICAL]  [KEV]
============================================================
Title: BlueKeep RDP Remote Windows Kernel Use After Free

CVSS: 9.8  EPSS: 94.5% (100.0th percentile)
Attack Vector: NETWORK | CWE: CWE-416 | Published: 2019-05-16 | KEV Added: 2021-11-03

EXPLOITS (127 total):
  METASPLOIT MODULES:
    - cve_2019_0708_bluekeep_rce.rb  [ruby]  Rank: manual
      AI: RCE | complexity:complex | reliability:racy | target:Microsoft Windows 7 SP1
      MITRE: T1059 - Command and Scripting Interpreter, T1068 - Exploitation for Privilege Escalation
  VERIFIED (ExploitDB):
    - EDB-47416  [ruby]  verified
      AI: RCE | complexity:complex | reliability:racy | target:Microsoft Windows RDP (7 SP1 / 2008 R2)
      MITRE: T1068, T1210 - Exploitation of Remote Services
  PROOF OF CONCEPT:
    - ★1187  nomisec  Ekultek/BlueKeep  working_poc
      AI: RCE | complexity:moderate | reliability:reliable | target:Windows RDP
      MITRE: T1189 - Drive-by Compromise, T1068
    - ★914   nomisec  robertdavidgraham/rdpscan  scanner
      AI: info_leak | complexity:moderate | reliability:reliable
      MITRE: T1046 - Network Service Scanning
      ...and 113 more PoCs
  *** SUSPICIOUS / TROJAN ***:
    - WARNING: ttsite/CVE-2019-0708-  [TROJAN] — flagged by AI analysis
      Summary: The repository is a scam and does not contain any exploit code.
      Deception indicators:
        - False claims about exploit availability
        - Deceptive contact information
        - No actual exploit code or technical details
```

Every exploit now shows AI analysis: attack type, complexity, reliability, target software, and MITRE ATT&CK techniques. Trojans show deception indicators explaining exactly how they deceive users.

---

#### "Audit our stack: nginx, postgresql, redis"

Uses `audit_stack` with `technologies=nginx, postgresql, redis`:

```
STACK AUDIT RESULTS
========================================

--- NGINX (66 exploitable CVEs) ---
  CVE-2023-44487  HIGH  CVSS:7.5  EPSS:94.4%  Exploits:22 [KEV]
    HTTP/2 Rapid Reset DoS
  CVE-2013-2028  CVSS:--  EPSS:92.8%  Exploits:25
    Nginx < 1.4.0 - Out-of-Bounds Write
  CVE-2017-7529  HIGH  CVSS:7.5  EPSS:91.9%  Exploits:54
    Nginx <1.14 - Info Disclosure
      ...and 56 more

--- POSTGRESQL (56 exploitable CVEs) ---
  CVE-2019-9193  HIGH  CVSS:7.2  EPSS:93.4%  Exploits:41
    PostgreSQL < 11.2 - OS Command Injection
  CVE-2018-1058  HIGH  CVSS:8.8  EPSS:82.7%  Exploits:13
    PostgreSQL < 9.3.22 - Improper Input Validation
      ...and 46 more

--- REDIS (39 exploitable CVEs) ---
  CVE-2022-0543  CRITICAL  CVSS:10.0  EPSS:94.4%  Exploits:32 [KEV]
    Redis Lua Sandbox Escape
  CVE-2018-11218  CRITICAL  CVSS:9.8  EPSS:80.3%  Exploits:3
    Redis < 3.2.12 - Out-of-Bounds Write
      ...and 29 more

Total: 30 findings shown across 3 technologies
```

---

#### "Get me the Nuclei dorks for TeamCity"

Uses `get_nuclei_templates` with `cve_id=CVE-2024-27198`:

```
NUCLEI TEMPLATES (1):
  Template: CVE-2024-27198  [critical] [verified]
  Name: TeamCity < 2023.11.4 - Authentication Bypass
  Author: DhiyaneshDk
  Tags: cve, cve2024, teamcity, jetbrains, auth-bypass, kev

  Recon Queries:
    Shodan:  http.component:"TeamCity" || http.title:teamcity
    FOFA:    title=teamcity
    Google:  intitle:teamcity

  Run: nuclei -t CVE-2024-27198 -u https://target.com
```

---

#### "Write a pentest finding for CVE-2024-3400"

Uses `generate_finding` with `cve_id=CVE-2024-3400, target=fw.corp.example.com, notes=Confirmed RCE via GlobalProtect`:

```markdown
# CVE-2024-3400: Palo Alto Networks PAN-OS Unauthenticated Remote Code Execution

**Severity:** CRITICAL
**CVSS v3 Score:** 10.0  (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H)
**EPSS Score:** 94.3% probability of exploitation
**Exploited in the Wild:** Yes (CISA KEV) (VulnCheck KEV) (InTheWild.io) — **ransomware campaigns confirmed**
**CWE:** CWE-77, CWE-20

**Affected Target:** fw.corp.example.com

## Description
A command injection vulnerability in the GlobalProtect feature of PAN-OS...

## Exploit Availability (43 public exploits)
- **Metasploit:** panos_telemetry_cmd_exec.rb  (rank: excellent)

## References
- https://security.paloaltonetworks.com/CVE-2024-3400

## Tester Notes
Confirmed RCE via GlobalProtect
```

---

#### "List all Metasploit modules"

Uses `search_exploits` with `source=metasploit`:

```
Found 2,993 exploits (page 1/599):

          metasploit   modules/exploits/linux/http/beyondtrust_pra_rs_unauth_rce.rb
         CVE-2024-12356  CRITICAL  CVSS:9.8  [ruby] working_poc
         AI: RCE | moderate | reliable

          metasploit   modules/exploits/multi/http/log4shell_header_injection.rb
         CVE-2021-44228  CRITICAL  CVSS:10.0  [ruby] working_poc
         AI: RCE | moderate | reliable
      ...
```

~3,000 Metasploit modules indexed.

## Architecture

### Tools (17)

| Tool | Description |
|---|---|
| `search_vulnerabilities` | Search CVEs with full-text `query` and filters: severity, vendor, product, ecosystem, CWE, CVSS/EPSS thresholds, KEV, Nuclei, year, date range. **Start here for product research.** |
| `get_vulnerability` | Full intelligence brief for a CVE or EIP-ID. **Includes ranked exploits** (AI analysis, MITRE techniques, source URLs), products, Nuclei templates (with description/impact/remediation), references. |
| `search_exploits` | Browse exploits with **structured filters only** (no free-text query): source, language, LLM classification, author, stars, CVE, vendor, product, attack_type, complexity, reliability, requires_auth. |
| `get_exploit_code` | Retrieve exploit source code by platform ID (auto-selects main file) |
| `get_exploit_analysis` | Full AI analysis for a single exploit: classification, attack type, complexity, reliability, MITRE ATT&CK, summary, and trojan/deception indicators |
| `get_nuclei_templates` | Nuclei scanner templates with description, impact, remediation, and Shodan/FOFA/Google dork queries |
| `list_authors` | Top exploit researchers ranked by exploit count |
| `get_author` | Author profile with all their exploits and CVE context |
| `list_cwes` | CWE categories ranked by vulnerability count |
| `get_cwe` | CWE detail with description, exploit likelihood, parent hierarchy |
| `list_vendors` | Software vendors ranked by vulnerability count |
| `list_products` | Discover exact product names for a vendor (CPE name lookup with vuln counts) |
| `lookup_alt_id` | Resolve alternate IDs (EDB-XXXXX, GHSA-XXXXX) to their CVE |
| `audit_stack` | Audit a tech stack for critical/high severity CVEs with exploits, sorted by EPSS risk |
| `generate_finding` | Generate a Markdown pentest report finding — all sections present with N/A when data is absent |
| `get_platform_stats` | Platform-wide counts and data freshness |
| `check_health` | API health and ingestion source timestamps |

### Security Model

This MCP server runs locally and proxies requests to the public EIP API over HTTPS.

#### Input Validation

Every parameter passes through strict validation:

- **CVE/EIP IDs**: Regex `^(CVE|EIP)-\d{4}-\d{4,7}$`
- **Exploit IDs**: Positive integers, capped at 2^31
- **Strings**: Max 200 chars, null bytes rejected, control characters stripped
- **Numerics**: CVSS 0-10, EPSS 0-1, per_page 1-25
- **Enums**: Severity, sort, ecosystem validated against allowlists
- **File paths**: `..`, absolute paths, null bytes all blocked
- **Technology names**: Alphanumeric + dots/hyphens/spaces, max 5 items

#### Response Safety

- Exploit code capped at 50KB
- All responses are plain text (no executable content)
- Error messages are generic (no internal API leakage)
- Trojan exploits are explicitly flagged

#### Network Safety

- API base URL hardcoded to `https://exploit-intel.com`
- TLS verification enabled
- 30-second timeout on all calls
- Optional `X-API-Key` header forwarding via `EIP_API_KEY` for custom deployments; the public EIP API does not require it

### Dependencies

- `mcp>=1.23.0` — Official MCP Python SDK
- `httpx>=0.27.0` — HTTP client
- Python 3.10+

## Testing

Run the default regression suite:

```bash
PYTHONPATH=. pytest tests
```

Live MCP integration tests are opt-in under `pytest`. Start the HTTP transport first:

```bash
eip-mcp --transport streamable-http --port 8080
```

Then run:

```bash
PYTHONPATH=. pytest tests/test_mcp_tools.py --base-url http://127.0.0.1:8080/mcp/
```

The script entrypoints still work if you prefer them:

```bash
python3 tests/test_mcp_tools.py --base-url http://127.0.0.1:8080/mcp/
python3 tests/test_mcp_timing.py --base-url http://127.0.0.1:8080/mcp/
```

## Deploy

### Optional `X-API-Key` Forwarding

The public EIP API does not require an API key. If you are routing through your own frontend or deployment that expects `X-API-Key`, `eip-mcp` will forward `EIP_API_KEY` when it is set:

```json
{
  "mcpServers": {
    "eip": {
      "command": "eip-mcp",
      "args": [],
      "env": {
        "EIP_API_KEY": "your-key-here"
      }
    }
  }
}
```

If `EIP_API_KEY` is unset, requests are still sent normally to the public API. Public rate limiting is currently documented as 60 requests/minute.

### Distribution

- **PyPI** — `pip install eip-mcp` / `pipx install eip-mcp`
- **APT repo** — `repo.exploit-intel.com` (Kali/Debian/Ubuntu native packages)
- **Remote MCP** — `https://mcp.exploit-intel.com/mcp` (Streamable HTTP; no local install needed)

### Git Workflow

**Never push directly to `main`.** All changes go through a branch and PR.

```bash
git checkout -b <branch-name>
# make changes
git push origin <branch-name>
gh pr create
```

PRs require review before merge.

## License

MIT

---

[![MCP Badge](https://lobehub.com/badge/mcp-full/exploit-intel-eip-mcp?theme=light)](https://lobehub.com/mcp/exploit-intel-eip-mcp)
