"""eip-mcp: MCP server for the Exploit Intelligence Platform."""

__version__ = "0.4.0"
