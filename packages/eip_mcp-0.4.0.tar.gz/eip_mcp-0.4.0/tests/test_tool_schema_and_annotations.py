"""Regression tests for the MCP rubric improvements:
- Every tool must declare ToolAnnotations.
- inputSchema must carry the constraints the validators enforce.
- format_vuln_detail / format_finding must cap large responses.
"""
from __future__ import annotations

from eip_mcp import formatters
from eip_mcp.formatters import MAX_DETAIL_OUTPUT
from eip_mcp.server import TOOLS


def test_every_tool_has_read_only_annotations() -> None:
    """All EIP tools are read-only lookups against an external API."""
    assert len(TOOLS) == 17, f"expected 17 tools, got {len(TOOLS)}"
    for tool in TOOLS:
        ann = tool.annotations
        assert ann is not None, f"{tool.name} is missing annotations"
        assert ann.title, f"{tool.name} annotation is missing a title"
        assert ann.readOnlyHint is True, f"{tool.name} should be read-only"
        assert ann.destructiveHint is False, f"{tool.name} should not be destructive"
        assert ann.idempotentHint is True, f"{tool.name} should be idempotent"
        assert ann.openWorldHint is True, f"{tool.name} talks to an external API"


def _tool_by_name(name: str):
    for t in TOOLS:
        if t.name == name:
            return t
    raise AssertionError(f"tool {name!r} not found")


def test_pagination_schema_has_bounds_and_defaults() -> None:
    """page/per_page must declare minimum/maximum/default so clients don't
    have to discover bounds by failing tool calls."""
    for name in ("search_vulnerabilities", "search_exploits"):
        props = _tool_by_name(name).inputSchema["properties"]
        assert props["page"]["minimum"] == 1
        assert props["page"]["default"] == 1
        per = props["per_page"]
        assert per["minimum"] == 1 and per["maximum"] == 25 and per["default"] == 10

    list_authors = _tool_by_name("list_authors").inputSchema["properties"]
    assert list_authors["per_page"]["maximum"] == 50
    assert list_authors["per_page"]["default"] == 25


def test_score_and_year_constraints() -> None:
    props = _tool_by_name("search_vulnerabilities").inputSchema["properties"]
    assert props["min_cvss"]["minimum"] == 0 and props["min_cvss"]["maximum"] == 10
    assert props["min_score"]["minimum"] == 0 and props["min_score"]["maximum"] == 10
    assert props["min_epss"]["minimum"] == 0 and props["min_epss"]["maximum"] == 1
    assert props["year"]["minimum"] == 1999 and props["year"]["maximum"] == 2030


def test_id_patterns_and_lengths() -> None:
    """CVE/EIP/CWE/exploit_id schemas must include patterns and bounds."""
    cve_id = _tool_by_name("get_vulnerability").inputSchema["properties"]["cve_id"]
    assert cve_id["pattern"] == r"^(?:CVE|EIP)-\d{4}-\d{4,7}$"
    assert cve_id["maxLength"] == 20

    eid = _tool_by_name("get_exploit_analysis").inputSchema["properties"]["exploit_id"]
    assert eid["minimum"] == 1 and eid["maximum"] == 2**31

    cwe = _tool_by_name("get_cwe").inputSchema["properties"]["cwe_id"]
    assert "pattern" in cwe and cwe["maxLength"] == 12


def test_search_exploits_enums_match_validator_allowlists() -> None:
    """Source / classification / complexity / reliability schemas must
    advertise the allowlist instead of free-form strings."""
    from eip_mcp import validators

    props = _tool_by_name("search_exploits").inputSchema["properties"]
    assert set(props["source"]["enum"]) == set(validators._SOURCES)
    assert set(props["llm_classification"]["enum"]) == set(validators._LLM_CLASSIFICATIONS)
    assert set(props["complexity"]["enum"]) == set(validators._COMPLEXITIES)
    assert set(props["reliability"]["enum"]) == set(validators._RELIABILITIES)


def test_cap_output_truncates_above_limit_and_appends_notice() -> None:
    """The safety-net helper: any string over the limit is cut at a line
    boundary and gets a TRUNCATED notice appended."""
    payload = ("a really useful line of detail.\n" * 5000)  # ~155 KB
    capped = formatters._cap_output(payload)
    assert len(capped) <= MAX_DETAIL_OUTPUT + 512
    assert "TRUNCATED" in capped
    # The cut should land on a line boundary, not mid-word.
    body, _, _ = capped.partition("\n\n... [TRUNCATED")
    assert body.endswith("a really useful line of detail.")


def test_cap_output_passthrough_when_under_limit() -> None:
    payload = "small\noutput\n"
    assert formatters._cap_output(payload) == payload


def test_cap_output_respects_custom_limit() -> None:
    capped = formatters._cap_output("x" * 5000, limit=1024)
    assert len(capped) <= 1024 + 512
    assert "TRUNCATED" in capped


def test_format_vuln_detail_does_not_cap_normal_output() -> None:
    """Realistic detail views must NOT trigger the cap."""
    out = formatters.format_vuln_detail(
        {
            "cve_id": "CVE-2024-3400",
            "title": "Palo Alto PAN-OS RCE",
            "severity_label": "critical",
            "cvss_v3_score": 10.0,
            "description": "Command injection in GlobalProtect.",
            "exploits": [],
            "affected_products": [],
            "references": [{"url": "https://security.paloaltonetworks.com/CVE-2024-3400", "type": "Vendor Advisory"}],
            "alt_identifiers": [],
            "nuclei_templates": [],
        }
    )
    assert "TRUNCATED" not in out
