#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'haoyang'
__date__ = '2026/1/20 15:02'

import base64
from io import BytesIO

from PIL import Image


class ImageProcessor:

  @staticmethod
  def image_show(base64_str):
    """base64字符串转PIL Image并显示"""
    from io import BytesIO
    import base64
    img_data = base64.b64decode(base64_str)
    img = Image.open(BytesIO(img_data))
    img.show()

  @staticmethod
  def image_to_base64(img: Image.Image, format='PNG') -> str:
    """PIL Image -> base64 字符串"""
    buffer = BytesIO()
    img.save(buffer, format=format)
    return base64.b64encode(buffer.getvalue()).decode('utf-8')

  @staticmethod
  def crop_to_base64(img: Image.Image, coordinate) -> str:
    """
    img: PIL Image
    coordinate: [xmin, ymin, xmax, ymax] 图像坐标
    return: 裁剪区域的 base64
    """
    if not isinstance(coordinate, (list, tuple)) or len(coordinate) != 4:
      raise ValueError("coordinate 必须是长度为 4 的 list 或 tuple")

    xmin, ymin, xmax, ymax = [int(c) for c in coordinate]
    cropped = img.crop((xmin, ymin, xmax, ymax))
    return ImageProcessor.image_to_base64(cropped)
