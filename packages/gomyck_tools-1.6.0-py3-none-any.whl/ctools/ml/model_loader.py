#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'haoyang'
__date__ = '2026/2/3 16:07'

import tempfile
import shutil
from pathlib import Path
from typing import Optional
from ctools.util.file_crypto import FileCrypto


class TempDecryptedDir:
  """
  解密到临时目录的上下文工具
  """

  def __init__(self, encrypted_file: str, password: str):
    self.encrypted_file = encrypted_file
    self.password = password
    self.temp_dir: Optional[Path] = None

  def __enter__(self) -> str:
    self.temp_dir = Path(
      tempfile.mkdtemp(prefix="secure_model_")
    )
    FileCrypto.decrypt_to_directory(
      encrypted_file=self.encrypted_file,
      output_dir=str(self.temp_dir),
      password=self.password
    )
    return str(self.temp_dir)

  def __exit__(self, exc_type, exc, tb):
    if self.temp_dir and self.temp_dir.exists():
      shutil.rmtree(self.temp_dir, ignore_errors=True)
