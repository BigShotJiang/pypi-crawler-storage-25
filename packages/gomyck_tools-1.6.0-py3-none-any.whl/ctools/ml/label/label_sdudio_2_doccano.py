#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'haoyang'
__date__ = '2026/2/25 09:05'

import json

label_studio_file_path = '/Users/haoyang/Downloads/project-5-at-2026-02-24-06-59-fcab2a29.json'

with open(label_studio_file_path, "r", encoding="utf-8") as f:
  data = json.load(f)

with open("doccano.jsonl", "w", encoding="utf-8") as f:
  for item in data:
    line = {
      "id": item["id"],
      "data": item["text"],
      "label": [item["label"]]
    }
    f.write(json.dumps(line, ensure_ascii=False) + "\n")
