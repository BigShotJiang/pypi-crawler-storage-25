#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'haoyang'
__date__ = '2026/2/28 09:20'

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional
import os


class EmailSender:
    def __init__(
            self,
            smtp_host: str,
            smtp_port: int,
            username: str,
            password: str,
            use_ssl: bool = True,
            timeout: int = 10,
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.use_ssl = use_ssl
        self.timeout = timeout

    def send(
            self,
            subject: str,
            content: str,
            to: List[str],
            html: bool = False,
            cc: Optional[List[str]] = None,
            bcc: Optional[List[str]] = None,
            attachments: Optional[List[str]] = None,
            sender_name: Optional[str] = None,
    ):
        if not to:
            raise ValueError("收件人不能为空")

        msg = MIMEMultipart()
        sender = f"{sender_name} <{self.username}>" if sender_name else self.username
        msg["From"] = sender
        msg["To"] = ",".join(to)
        msg["Subject"] = subject

        if cc:
            msg["Cc"] = ",".join(cc)

        body = MIMEText(content, "html" if html else "plain", "utf-8")
        msg.attach(body)

        if attachments:
            for path in attachments:
                if not os.path.isfile(path):
                    raise FileNotFoundError(f"附件不存在: {path}")

                filename = os.path.basename(path)
                part = MIMEBase("application", "octet-stream")
                with open(path, "rb") as f:
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f'attachment; filename="{filename}"'
                )
                msg.attach(part)

        all_receivers = to + (cc or []) + (bcc or [])

        if self.use_ssl:
            server = smtplib.SMTP_SSL(self.smtp_host, self.smtp_port, timeout=self.timeout)
        else:
            server = smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=self.timeout)
            server.starttls()

        try:
            server.login(self.username, self.password)
            server.sendmail(self.username, all_receivers, msg.as_string())
        finally:
            server.quit()

# if __name__ == '__main__':
#     sender = EmailSender(
#         smtp_host="smtp.163.com",
#         smtp_port=465,
#         username="hylinknotice@163.com",
#         password="SEPfE3PykW2uAAB8",
#         use_ssl=True
#     )
#
#     sender.send(
#         subject="系统告警",
#         content="服务器CPU使用率超过80%",
#         to=["hao474798383@163.com"]
#     )
