#!/usr/bin/env python
# -*- coding: UTF-8 -*-
__author__ = 'haoyang'
__date__ = '2026/2/3 16:07'

import tarfile
import tempfile
import hashlib
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import secrets


class FileCrypto:
  """
  文件 / 目录 加密解密工具
  - AES-256-GCM
  - 支持目录整体加密
  """
  NONCE_SIZE = 12
  KEY_SIZE = 32
  @staticmethod
  def derive_key(password: str) -> bytes:
    """
    从口令派生固定长度 key（简化版，工程可控）
    """
    return hashlib.sha256(password.encode("utf-8")).digest()

  @staticmethod
  def encrypt_directory(
    src_dir: str,
    output_file: str,
    password: str
  ) -> None:
    """
    加密整个目录
    """
    src_dir = Path(src_dir).resolve()
    output_file = Path(output_file).resolve()

    with tempfile.NamedTemporaryFile(suffix=".tar", delete=False) as tmp_tar:
      tar_path = Path(tmp_tar.name)

    try:
      # 1. 打包目录
      with tarfile.open(tar_path, "w") as tar:
        tar.add(src_dir, arcname=".")

      # 2. 加密
      key = FileCrypto.derive_key(password)
      aesgcm = AESGCM(key)
      nonce = secrets.token_bytes(FileCrypto.NONCE_SIZE)

      data = tar_path.read_bytes()
      encrypted = aesgcm.encrypt(nonce, data, None)

      output_file.write_bytes(nonce + encrypted)

    finally:
      tar_path.unlink(missing_ok=True)

  @staticmethod
  def decrypt_to_directory(
    encrypted_file: str,
    output_dir: str,
    password: str
  ) -> None:
    """
    解密文件并解包到指定目录
    """
    encrypted_file = Path(encrypted_file).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    raw = encrypted_file.read_bytes()
    nonce = raw[:FileCrypto.NONCE_SIZE]
    ciphertext = raw[FileCrypto.NONCE_SIZE:]

    key = FileCrypto.derive_key(password)
    aesgcm = AESGCM(key)

    data = aesgcm.decrypt(nonce, ciphertext, None)

    with tempfile.NamedTemporaryFile(suffix=".tar", delete=False) as tmp_tar:
      tmp_tar.write(data)
      tar_path = Path(tmp_tar.name)

    try:
      with tarfile.open(tar_path, "r") as tar:
        tar.extractall(output_dir)
    finally:
      tar_path.unlink(missing_ok=True)
