import asyncio
import importlib.util

if importlib.util.find_spec("uvloop"):
  import uvloop
  asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
else:
  pass
