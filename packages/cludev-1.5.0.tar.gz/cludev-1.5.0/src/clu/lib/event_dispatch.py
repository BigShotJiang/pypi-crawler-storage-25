"""Agent-agnostic event dispatch for adapter lifecycle events."""


from typing import Tuple

from clu.adapter import Adapter
from clu.adapter.events import (
    AdapterEvent,
    HookEventIgnored,
    SessionEnded,
    SessionStarted,
)
from clu.models.session import Session
from clu.store import Store


def dispatch_event(
    *,
    event: AdapterEvent,
    adapter: Adapter,
    db: Store,
    agent: str,
    cwd: str,
) -> None:
    """Execute session lifecycle actions for an adapter event."""
    if isinstance(event, HookEventIgnored):
        return

    repo_path, is_git_repo, git_remote_url = _resolve_git_context(cwd=cwd)

    if isinstance(event, SessionStarted):
        db.sessions.find_or_create(
            path=repo_path,
            agent=agent,
            transcript_path=event.transcript_path,
            is_git_repo=is_git_repo,
            git_remote_url=git_remote_url,
        )
        return

    if not is_git_repo:
        return

    session = db.sessions.active_for_path(path=repo_path)
    if session is None or not session.transcript_path:
        return

    _parse_and_store_messages(db=db, session=session, adapter=adapter)

    if isinstance(event, SessionEnded):
        db.sessions.end(session_id=session.id)


def _parse_and_store_messages(
    *,
    db: Store,
    session: Session,
    adapter: Adapter,
) -> None:
    """Parse and persist any new transcript messages for a session."""
    messages, new_watermark = adapter.parse_transcript(
        path=session.transcript_path,
        session_id=session.id,
        cwd=session.path,
        watermark=session.transcript_parsing_watermark,
        turn_offset=db.messages.count_for_session(session_id=session.id),
    )
    if messages:
        db.messages.insert_many(messages=messages)
    if new_watermark > session.transcript_parsing_watermark:
        db.sessions.update_watermark(
            session_id=session.id, watermark=new_watermark,
        )


def _resolve_git_context(*, cwd: str) -> Tuple[str, bool, str]:
    """Return repository path, git presence, and origin remote URL from a cwd."""
    try:
        from clu.git import remote_url, repo_root

        root = repo_root(path=cwd)
        return root, True, remote_url(path=root)
    except Exception:
        return cwd, False, ""
