"""auth login / auth status commands."""


import click

from clu.lib.auth_login import run_auth_login
from clu.lib.auth_status import get_auth_status


@click.group()
def auth() -> None:
    """Authenticate clu against the configured backend."""


@auth.command()
@click.option("--supabase-url", default="", help="Supabase project URL")
@click.option("--anon-key", default="", help="Supabase anon key")
@click.option("--github-app-install-url", default="", help="GitHub App installation URL")
@click.option("--provider", default="github", help="OAuth provider to use")
@click.option("--listen-addr", default="localhost:3000", help="Local callback address")
@click.option("--no-browser", is_flag=True, help="Print the login URL instead of opening a browser")
def login(
    supabase_url: str,
    anon_key: str,
    github_app_install_url: str,
    provider: str,
    listen_addr: str,
    no_browser: bool,
) -> None:
    """Run a local browser-based OAuth flow and persist the session."""
    try:
        result = run_auth_login(
            supabase_url=supabase_url,
            anon_key=anon_key,
            github_app_install_url=github_app_install_url,
            provider=provider,
            listen_addr=listen_addr,
            no_browser=no_browser,
        )
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error

    if no_browser:
        click.echo(f"Starting local login flow at {result}")
        click.echo(f"Open this URL in your browser:\n{result}")
        return

    click.echo(f"Login succeeded for {result}")


@auth.command()
def status() -> None:
    """Verify the current auth session and print the active user."""
    try:
        auth_status = get_auth_status()
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error
    click.echo(auth_status.model_dump_json(indent=2))
