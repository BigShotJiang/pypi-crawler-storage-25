"""
pytest_formatter.py — Opinionated pytest output formatter.

Output style:

  tests/test_foo.py
    --- PASS  test_something                             0.8ms
    --- FAIL  test_other                                 1.2ms
      E  AssertionError: assert 3 == 30
    --- ERROR test_broken                                0.1ms
      E  AttributeError: 'NoneType' object has no attribute 'get'
    --- SKIP  test_ignored                               0.0ms
      E  Skipped: reason here
  => 1 passed, 1 failed, 1 error, 1 skipped

  Total: 1 passed, 1 failed, 1 error, 1 skipped  in 0.12s

Load via Makefile:
    PYTHONPATH=. pytest -p no:terminal -p pytest_formatter [TARGET]
"""
from __future__ import annotations

import io
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import pytest

try:
    from _pytest._io import TerminalWriter as _PytestTerminalWriter
except ImportError:  # pragma: no cover — only missing outside a pytest install
    _PytestTerminalWriter = None  # type: ignore[assignment,misc]

# ── ANSI palette ──────────────────────────────────────────────────────────────
# Plain functions so linters don't flag unnecessary-lambda-assignment.
# Change the escape codes here to retheme everything.

_NO_COLOR = not sys.stdout.isatty() or bool(os.environ.get("NO_COLOR"))

# FIX 1: _RED_SOFT was "\033[0;38;2;252;205;174;49" — two bugs:
#   • It included a "\033[" prefix; _esc() already supplies that, so the
#     rendered escape became "\033[\033[…m" (doubled CSI).
#   • It had a trailing ";49" (default-background reset) that was unintentional.
_RED_SOFT      = "0;38;2;252;205;174"   # 24-bit peach — c_emsg / context lines
_BRIGHT_GREEN  = "92"
_BRIGHT_RED    = "91"
_BRIGHT_YELLOW = "93"
# FIX 2: Errors and failures were both using _BRIGHT_RED, making them
#   visually indistinguishable despite different semantic meanings.
#   Errors (collection failures, setup/teardown crashes) now use standard
#   red so they read as distinct from assertion-failure highlights.
_STANDARD_RED  = "31"
_GRAY          = "90"
_DIM           = "2"
_BOLD          = "1"

# ── Max E-lines surfaced inline ───────────────────────────────────────────────
# FIX 8: Hard-coded limit of 6 was too low for large assertion diffs
#   (e.g. comparing big dicts/lists). Raised and named so it's easy to tune.
#   Noise filtering in _render_result provides a second layer of trimming.
MAX_E_LINES: int = 15


def _esc(code: str, text: str) -> str:
    return text if _NO_COLOR else f"\033[{code}m{text}\033[0m"


def c_pass(t: str) -> str:
    """Bright green — passing tests / received values."""
    return _esc(_BRIGHT_GREEN, t)


def c_fail(t: str) -> str:
    """Bright red — FAIL badge, expected values in assertions."""
    return _esc(_BRIGHT_RED, t)


def c_error(t: str) -> str:
    """Standard red — ERROR badge, collection errors, setup/teardown crashes."""
    return _esc(_STANDARD_RED, t)


def c_skip(t: str) -> str:
    """Bright yellow — skipped tests."""
    return _esc(_BRIGHT_YELLOW, t)


def c_xfail(t: str) -> str:
    """Gray — expected failures."""
    return _esc(_GRAY, t)


def c_xpass(t: str) -> str:
    """Yellow — unexpected passes."""
    return _esc(_BRIGHT_YELLOW, t)


def c_emsg(t: str) -> str:
    """Peach / soft red — E-line messages, context lines, assert keywords."""
    return _esc(_RED_SOFT, t)


def c_section(t: str) -> str:
    """Gray — captured output section headers."""
    return _esc(_GRAY, t)


def c_dim(t: str) -> str:
    """Dim — metadata, timing, context lines."""
    return _esc(_DIM, t)


def c_bold(t: str) -> str:
    """Bold — totals label."""
    return _esc(_BOLD, t)


# ── Outcome tables ────────────────────────────────────────────────────────────

_OUTCOME_ORDER = ("passed", "failed", "error", "skipped", "xfailed", "xpassed")

_BADGE: Dict[str, str] = {
    "passed":  c_pass("PASS"),
    "failed":  c_fail("FAIL"),
    "error":   c_error("ERROR"),
    "skipped": c_skip("SKIP"),
    "xfailed": c_xfail("XFAIL"),
    "xpassed": c_xpass("XPASS"),
}

# Color function applied to the "---" prefix — matches the badge for each outcome.
_OUTCOME_COLOR = {
    "passed":  c_pass,
    "failed":  c_fail,
    "error":   c_error,
    "skipped": c_skip,
    "xfailed": c_xfail,
    "xpassed": c_xpass,
}

_SUMMARY_FMT = {
    "passed":  lambda n: c_pass(f"{n} passed"),
    "failed":  lambda n: c_fail(f"{n} failed"),
    "error":   lambda n: c_error(f"{n} errors"),
    "skipped": lambda n: c_skip(f"{n} skipped"),
    "xfailed": lambda n: c_xfail(f"{n} xfailed"),
    "xpassed": lambda n: c_xpass(f"{n} xpassed"),
}

# ── Domain ────────────────────────────────────────────────────────────────────


@dataclass
class TestResult:
    """Normalised result for a single test, ready for rendering."""

    nodeid:    str
    file:      str
    name:      str
    outcome:   str                       # one of _OUTCOME_ORDER
    duration:  float                     # seconds
    short_msg: Optional[str] = None      # one-liner shown on the E line
    sections:  List[Tuple[str, str]] = field(default_factory=list)


# ── Line coloring ─────────────────────────────────────────────────────────────

class LineColorizer:
    """
    All E-line coloring decisions, extracted for unit testability.

    Fully independent of pytest internals — operates on plain strings.
    The key feature is parse_assert(), which splits 'assert X op Y' so
    X (received) can be colored green and Y (expected) red, matching the
    +/- diff coloring on subsequent lines.
    """

    # Operators ordered longest-first to prevent partial matches
    # (e.g. "is not" must be tried before "is", "not in" before "in")
    _CMP_OPS: Tuple[str, ...] = (
        "is not", "not in",
        "==", "!=", "<=", ">=",
        "is", "in",
        "<", ">",
    )

    # E lines that add no value in compact output.
    # FIX 7: "Full diff" → "Full diff:" to avoid false positives on test
    #   output that legitimately contains the phrase "Full diff calculated" etc.
    _NOISE: Tuple[str, ...] = (
        "Use -v to get more diff",
        "use -vv to show",
        "Omitting",
        "Full diff:",
    )

    # Characters that begin a Python value expression.
    # Used to distinguish real values from prose words when checking whether
    # an operator match is meaningful (e.g. the 'in' in 'Extra items in the
    # left set:' must not be treated as a comparison operator).
    VALUE_STARTERS: frozenset = frozenset("\"'([{-0123456789")

    # Label-prefixed E-lines emitted by pytest plugins (e.g. pytest-approx).
    # Maps the exact label string (including the trailing space) to the color
    # function that should be applied to the value that follows it.
    #
    # Semantic choice (intentionally inverted from the assert-line convention):
    #   Obtained → c_fail (red)  — the wrong value, the one that caused the failure
    #   Expected → c_pass (green)— the target value, what the test demanded
    #
    # This reads naturally as a standalone label pair: red = bad, green = goal.
    _LABEL_COLORS: Tuple[Tuple[str, object], ...] = (
        ("Obtained: ", c_fail),
        ("Expected: ", c_pass),
    )

    @classmethod
    def parse_approx_table_row(cls, text: str) -> Optional[Tuple[str, str, str]]:
        """
        Parse a pytest-approx pipe-separated table **data** row.

        Matches the per-element rows emitted for list and dict approx failures::

            '0     | 0.30000000000000004 | 0.4 ± 1.0e-09'
            'x     | 1.0                 | 2.0 ± 1.0e-09'

        Returns ``(index_col, obtained_col, expected_col)`` where each value
        includes its original surrounding whitespace so the caller can preserve
        column alignment when applying colors.

        Returns ``None`` for:
          - The header row   ``'Index | Obtained  | Expected'``  — obtained column
            starts with a letter, not a digit.
          - Any line with a pipe count other than exactly 2.
          - Lines where the obtained column is empty after stripping.
        """
        if text.count("|") != 2:
            return None
        idx_col, obt_col, exp_col = text.split("|")
        obtained_stripped = obt_col.strip()
        if not obtained_stripped:
            return None
        # Discriminate data rows from the header: obtained starts with a digit
        # (or '-' for negative numbers). The header has "Obtained" (starts 'O').
        if not (obtained_stripped[0].isdigit() or obtained_stripped[0] == "-"):
            return None
        return idx_col, obt_col, exp_col

    @classmethod
    def split_prefix(cls, text: str) -> Tuple[str, str]:
        """
        Separate a human-readable prose prefix from a Python value expression.

        Scans left-to-right for the first ': ' immediately followed by a
        VALUE_STARTERS character.  Everything up to and including that ': ' is
        the prefix; everything after is the value.

        Examples::

            'At index 0 diff: \\'Global Launch\\''
                → ('At index 0 diff: ', '\\'Global Launch\\'')

            '\\'Global Launch\\''   → ('', '\\'Global Launch\\'')
            'Extra items'         → ('', 'Extra items')   # no value found
            '{\\'b\\': 2}'          → ('', '{\\'b\\': 2}')  # starts with value char
        """
        if not text or text[0] in cls.VALUE_STARTERS:
            return "", text
        i = 0
        while i < len(text) - 2:
            if text[i] == ":" and text[i + 1] == " " and text[i + 2] in cls.VALUE_STARTERS:
                return text[: i + 2], text[i + 2 :]
            i += 1
        return "", text

    @classmethod
    def parse_assert(cls, text: str) -> Optional[Tuple[str, str, str]]:
        """
        Parse an assertion line into (received, operator, expected).

        Handles:
          'assert 3 == 30'
          'AssertionError: assert X == Y'
          'assert None is not None'
          'assert "foo" in ["bar", "baz"]'
          'assert {1, 2} == {1, 3}'

        The parser tracks bracket and quote depth so operators inside
        string literals or containers are not mistakenly matched.

        Returns None if the text is not a recognisable assertion.
        """
        # Strip optional "AssertionError: " prefix
        body = text
        if body.startswith("AssertionError: "):
            body = body[len("AssertionError: "):]

        if not body.startswith("assert "):
            return None

        inner = body[len("assert "):]
        result = cls._find_op(inner)
        if result is None:
            return None

        pos, op = result
        received = inner[:pos].strip()
        expected = inner[pos + len(f" {op} "):].strip()
        return received, op, expected

    @classmethod
    def parse_bare_assert(cls, text: str) -> Optional[str]:
        """
        Parse ``assert VALUE`` where there is no comparison operator.

        Returns the bare value string, or ``None`` if the line is not a bare
        assertion (i.e. it has an operator, is not an assertion at all, or the
        inner expression is empty after stripping).

        Examples::

            'assert False'              → 'False'
            'assert None'               → 'None'
            'assert is_valid'           → 'is_valid'
            'assert None is not None'   → None  (has operator, use parse_assert)
            'RuntimeError: boom'        → None  (not an assertion)
        """
        body = text
        if body.startswith("AssertionError: "):
            body = body[len("AssertionError: "):]
        if not body.startswith("assert "):
            return None
        inner = body[len("assert "):].strip()
        if not inner or cls._find_op(inner) is not None:
            return None
        return inner

    @classmethod
    def _find_op(cls, text: str) -> Optional[Tuple[int, str]]:
        """
        Scan text for the first comparison operator at bracket/quote depth 0.

        Returns (position, operator) or None.
        Depth tracking:
          - Bracket pairs ()[]{}  increment / decrement depth
          - String literals ' and " are consumed so their contents are skipped

        Known limitation: triple-quoted strings ('''…''' / \"\"\"…\"\"\") are
        not handled — the parser treats each quote as starting/ending a single-
        character string literal. This is unlikely to appear in pytest repr()
        output, but worth noting if the formatter is ever extended.
        """
        depth = 0
        in_str: Optional[str] = None
        i = 0

        while i < len(text):
            ch = text[i]

            # Inside a string literal — skip until closing quote
            if in_str is not None:
                if ch == in_str and (i == 0 or text[i - 1] != "\\"):
                    in_str = None
                i += 1
                continue

            # Start of a string literal
            if ch in ('"', "'"):
                in_str = ch
                i += 1
                continue

            # Bracket depth tracking
            if ch in "([{":
                depth += 1
                i += 1
                continue

            if ch in ")]}":
                depth -= 1
                i += 1
                continue

            # Only match operators at the top level
            if depth == 0:
                for op in cls._CMP_OPS:
                    pattern = f" {op} "
                    if text[i: i + len(pattern)] == pattern:
                        return i, op

            i += 1

        return None

    @classmethod
    def parse_comparison(cls, text: str) -> Optional[Tuple[str, str, str]]:
        """
        Parse 'X op Y' without requiring an 'assert' prefix.

        Used for context lines like:  {'b': 2} != {'b': 999}
        Returns (received, operator, expected) or None.

        ``received`` may include a prose prefix (e.g. ``'At index 0 diff:
        \\'Global Launch\\''``); callers that render it should pass it through
        :meth:`split_prefix` to isolate the actual value.

        Returns ``None`` when the apparent operands are prose words rather than
        Python value expressions.  This prevents false positives such as the
        ``in`` operator being matched in ``'Extra items in the left set:'``.
        """
        result = cls._find_op(text)
        if result is None:
            return None
        pos, op = result
        received = text[:pos].strip()
        expected = text[pos + len(f" {op} ") :].strip()
        if not received or not expected:
            return None
        # Gate on both sides being real Python value expressions.
        # Use split_prefix so a prose prefix like "At index 0 diff: " does not
        # disqualify a line that carries a genuine value after the colon.
        _, received_value = cls.split_prefix(received)
        if not received_value or received_value[0] not in cls.VALUE_STARTERS:
            return None
        if expected[0] not in cls.VALUE_STARTERS:
            return None
        return received, op, expected

    @classmethod
    def color_assert_line(cls, text: str) -> str:
        """
        Color assertion lines, dispatching on the form of the assertion.

        Color convention (consistent with diff lines, Obtained/Expected labels,
        and approx table rows throughout the formatter):
          received value  → bright red  (c_fail) — the wrong value
          expected value  → green       (c_pass) — the target value

        Two-sided (``assert X op Y``):
            ``assert`` + op → soft red; received (X) → red; expected (Y) → green.

        Bare (``assert VALUE`` with no operator):
            ``assert`` → soft red; VALUE → bright red.
            The value is the falsy thing that caused the failure.

        Unrecognised lines fall back to uniform soft red.

        The optional ``AssertionError: `` prefix is preserved in soft red in
        all cases.
        """
        # ── two-sided: assert X op Y ─────────────────────────────────────────
        parsed = cls.parse_assert(text)
        if parsed is not None:
            received, op, expected = parsed
            prefix = c_emsg("AssertionError: ") if text.startswith("AssertionError: ") else ""
            # 'is not' — render as 'is' + 'not VALUE' so the expected reads as
            # a natural unit ("not None") rather than repeating the same token.
            if op == "is not":
                colored_op       = c_emsg(" is ")
                colored_expected = c_pass(f"not {expected}")   # green — target condition
            else:
                colored_op       = c_emsg(f" {op} ")
                colored_expected = c_pass(expected)            # green — target value
            return (
                prefix
                + c_emsg("assert ")
                + c_fail(received)       # red   — the wrong value
                + colored_op
                + colored_expected
            )

        # ── bare: assert VALUE (no operator) ─────────────────────────────────
        bare = cls.parse_bare_assert(text)
        if bare is not None:
            prefix = c_emsg("AssertionError: ") if text.startswith("AssertionError: ") else ""
            return prefix + c_emsg("assert ") + c_fail(bare)  # red — the falsy value

        # ── fallback ──────────────────────────────────────────────────────────
        return c_emsg(text)

    @classmethod
    def color_e_line(cls, line: str, outcome: str, is_first: bool) -> str:
        """
        Dispatch coloring for one E line based on content and context.

        Color convention (applied consistently across all line types):
          received / obtained → bright red   — the wrong value
          expected            → green        — the target value

        Rules (in priority order):
          skipped outcome      → yellow
          starts with '- '     → green      (expected content — present in expected, absent in received)
          starts with '+ '     → bright red (received content — present in received, absent in expected)
          starts with '? '     → soft red   (diff caret pointer)
          assertion line       → received red, expected green (via color_assert_line)
          context + comparison → received red, expected green
          label line           → Obtained: red  /  Expected: green
          approx table row     → obtained column red, expected column green
          any other line       → soft red
        """
        if outcome == "skipped":
            return c_skip(line)
        if line.startswith("- ") or line == "-":
            return c_pass(line)
        if line.startswith("+ ") or line == "+":
            return c_fail(line)
        if line.startswith("? "):
            return c_emsg(line)
        if is_first:
            # color_assert_line already falls back to c_emsg when the line
            # is not a recognisable assertion, so no need to call parse_assert
            # here first — that would be a redundant parse and an extra return.
            return cls.color_assert_line(line)
        # Non-first assertion lines (e.g. 'assert False' appearing after the
        # AssertionError: message line) need the same treatment as first-line
        # assertions.  parse_comparison would miss them entirely.
        if line.startswith("assert ") or line.startswith("AssertionError: assert "):
            return cls.color_assert_line(line)
        parsed = cls.parse_comparison(line)
        if parsed is not None:
            received, op, expected = parsed
            prefix, value = cls.split_prefix(received)
            # prefix   → soft red  (prose description, e.g. "At index 0 diff: ")
            # value    → bright red (received — the wrong value)
            # op       → soft red
            # expected → green     (expected — the target value)
            return c_emsg(prefix) + c_fail(value) + c_emsg(f" {op} ") + c_pass(expected)
        # Label-prefixed lines from pytest plugins (e.g. "Obtained: …", "Expected: …").
        for label, color_fn in cls._LABEL_COLORS:
            if line.startswith(label):
                return c_emsg(label) + color_fn(line[len(label):])  # type: ignore[operator]
        # Pipe-separated approx table data rows: "index | obtained | expected".
        # Each column is colored individually while preserving the original
        # whitespace padding so the table alignment stays intact.
        table = cls.parse_approx_table_row(line)
        if table is not None:
            idx_col, obt_col, exp_col = table

            def _color_col(col: str, color_fn) -> str:  # type: ignore[type-arg]
                """Color just the value inside a padded column, keep spaces soft-red."""
                stripped = col.strip()
                leading  = col[: len(col) - len(col.lstrip())]
                trailing = col[len(col.rstrip()) :]
                return c_emsg(leading) + color_fn(stripped) + c_emsg(trailing)

            return (
                c_emsg(idx_col)
                + c_emsg("|")
                + _color_col(obt_col, c_fail)  # obtained → bright red
                + c_emsg("|")
                + _color_col(exp_col, c_pass)  # expected → green
            )
        return c_emsg(line)

    @classmethod
    def is_noise(cls, line: str) -> bool:
        """Return True if the line adds no value and should be suppressed."""
        if any(noise in line for noise in cls._NOISE):
            return True
        if line.startswith("?") and all(c in " -+^" for c in line[1:]):
            return True
        return False


# ── Plugin ────────────────────────────────────────────────────────────────────

class FormatterPlugin:
    """
    Drop-in replacement for pytest's default terminal reporter.

    Design decisions:
    - Failures surface inline — no need to scroll to a deferred FAILURES block.
    - Per-file => summaries give instant orientation across multi-suite runs.
    - Collection errors (bad imports, syntax) are surfaced clearly.
    - Captured stdout/stderr/logs are shown only on failing tests.
    """

    def __init__(self) -> None:
        self._results:    List[TestResult] = []
        self._t0:         float = 0.0
        self._cur_file:   Optional[str] = None
        self._file_buf:   List[TestResult] = []
        self._col_errors: List[Tuple[str, str]] = []

    # ── I/O ───────────────────────────────────────────────────────────────────

    def _p(self, text: str = "") -> None:
        print(text, flush=True)

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def classify(report) -> str:
        """Map a raw pytest report to one of the canonical outcome strings."""
        if hasattr(report, "wasxfail"):
            return "xpassed" if report.outcome == "passed" else "xfailed"
        if report.when in ("setup", "teardown") and report.outcome == "failed":
            return "error"
        return report.outcome  # passed | failed | skipped

    @staticmethod
    def extract_short(report, outcome: str) -> Optional[str]:
        """
        Extract the most useful inline message for the E line.

        Priority:
          1. xfail/xpass reason from report.wasxfail
          2. Skip reason from the (file, lineno, reason) tuple
          3. E-prefixed assertion introspection lines from the traceback
          4. reprcrash.message as fallback
          5. First non-blank line of the string repr
        """
        if outcome in ("xfailed", "xpassed"):
            reason = getattr(report, "wasxfail", "")
            return f"{outcome}: {reason}" if reason else outcome

        lr = report.longrepr
        if not lr:
            return None

        if isinstance(lr, tuple) and len(lr) == 3:
            return str(lr[2])

        reprcrash = getattr(lr, "reprcrash", None)
        if reprcrash is not None:
            e_lines = [
                stripped[1:].strip()
                for raw in str(lr).splitlines()
                if (stripped := raw.lstrip())
                and (stripped.startswith("E ") or stripped == "E")
                and stripped[1:].strip()
            ]
            if e_lines:
                # FIX 8: was [:6] — too low for large assertion diffs.
                # Noise filtering in _render_result provides a second pass.
                return "\n".join(e_lines[:MAX_E_LINES])
            return reprcrash.message  # type: ignore[union-attr]

        return next(
            (ln.strip()[:300] for ln in str(lr).strip().splitlines() if ln.strip()),
            None,
        )

    @staticmethod
    def split_nodeid(nodeid: str) -> Tuple[str, str]:
        """'a/b.py::foo[x-y]' → ('a/b.py', 'foo[x-y]')."""
        file, sep, name = nodeid.partition("::")
        return file, (name if sep else nodeid)

    # ── File-group management ─────────────────────────────────────────────────

    def _open_file_group(self, file: str) -> None:
        """On file change: flush the previous group's summary, print new header."""
        if file == self._cur_file:
            return
        if self._cur_file is not None:
            self._flush_file_summary()
            self._p()
        self._cur_file = file
        self._file_buf = []
        self._p(file)

    def _flush_file_summary(self) -> None:
        """Print the per-file '=> N passed, N failed' summary line."""
        counts: Dict[str, int] = {}
        for r in self._file_buf:
            counts[r.outcome] = counts.get(r.outcome, 0) + 1

        parts = [
            _SUMMARY_FMT[o](n)
            for o in _OUTCOME_ORDER
            if (n := counts.get(o))  # pylint: disable=superfluous-parens
        ]
        self._p(f"  => {', '.join(parts) if parts else c_dim('nothing ran')}")
        # FIX 4: Reset the buffer here so the intent is explicit. _open_file_group
        # also resets it for the new file, but clearing at the flush site makes
        # the ownership clear and prevents subtle bugs if the call order changes.
        self._file_buf = []

    # ── Per-result rendering ──────────────────────────────────────────────────

    def _render_result(self, r: TestResult) -> None:
        """Print one test result line, inline E lines, and captured sections."""
        badge    = _BADGE.get(r.outcome, r.outcome.upper())
        color_fn = _OUTCOME_COLOR.get(r.outcome, c_dim)
        dur      = c_dim(f"  {r.duration * 1000:.1f}ms")
        self._p(f"  {color_fn('---')} {badge}  {r.name}{dur}")

        if r.short_msg:
            lines = [
                ln for ln in r.short_msg.splitlines()
                if not LineColorizer.is_noise(ln)
            ]
            for i, line in enumerate(lines):
                colored = LineColorizer.color_e_line(line, r.outcome, is_first=i == 0)
                self._p(f"    {c_emsg('E')}  {colored}")

        if r.outcome not in ("passed", "xfailed"):
            for section_name, content in r.sections:
                if not content.strip():
                    continue
                self._p(f"    {c_section('── ' + section_name + ' ──')}")
                for ln in content.rstrip().splitlines():
                    self._p(f"    {ln}")

    # ── pytest hooks ──────────────────────────────────────────────────────────

    @pytest.hookimpl(tryfirst=True)
    def pytest_sessionstart(self) -> None:
        """Record session start time."""
        self._t0 = time.monotonic()
        self._p()

    @pytest.hookimpl(tryfirst=True)
    def pytest_collection_finish(self, session) -> None:
        """Print the 'collected N tests' header."""
        n    = len(session.items)
        noun = "test" if n == 1 else "tests"
        self._p(f"{c_dim('collected')} {c_bold(str(n))} {c_dim(noun)}")
        self._p()

    @pytest.hookimpl(tryfirst=True)
    def pytest_collectreport(self, report) -> None:
        """Capture collection-phase errors: bad imports, syntax errors, etc."""
        if report.failed and report.longrepr:
            self._col_errors.append(
                (str(report.nodeid), str(report.longrepr).strip())
            )

    @pytest.hookimpl(tryfirst=True)
    def pytest_runtest_logreport(self, report) -> None:
        """Handle each test phase report and render the result line."""
        if report.when != "call" and report.outcome == "passed":
            return

        outcome    = self.classify(report)
        short_msg  = self.extract_short(report, outcome)
        file, name = self.split_nodeid(report.nodeid)

        result = TestResult(
            nodeid    = report.nodeid,
            file      = file,
            name      = name,
            outcome   = outcome,
            duration  = getattr(report, "duration", 0.0),
            short_msg = short_msg,
            sections  = list(report.sections),
        )

        self._open_file_group(file)
        self._file_buf.append(result)
        self._results.append(result)
        self._render_result(result)

    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self) -> None:
        """Flush the last file summary and print the global Total line."""
        # FIX 5: Was `if self._file_buf` — that guard would silently skip the
        # summary if the buffer happened to be empty (e.g. after a refactor
        # that cleared it early). Keying on _cur_file is the correct signal:
        # if we opened at least one file group, we must close it.
        if self._cur_file is not None:
            self._flush_file_summary()

        if self._col_errors:
            self._p()
            self._p(c_bold(c_error("COLLECTION ERRORS")))
            for nodeid, msg in self._col_errors:
                self._p(f"  {c_error('⚠')}  {nodeid}")
                for line in msg.splitlines():
                    self._p(f"    {c_dim(line)}")

        elapsed = time.monotonic() - self._t0
        counts: Dict[str, int] = {}
        for r in self._results:
            counts[r.outcome] = counts.get(r.outcome, 0) + 1

        parts = [
            _SUMMARY_FMT[o](n)
            for o in _OUTCOME_ORDER
            if (n := counts.get(o))  # pylint: disable=superfluous-parens
        ]
        summary = ", ".join(parts) if parts else c_dim("no tests ran")
        self._p()
        self._p(f"{c_bold('Total:')} {summary}  {c_dim(f'in {elapsed:.2f}s')}")
        self._p()


# ── Registration ──────────────────────────────────────────────────────────────

def pytest_configure(config: pytest.Config) -> None:
    """Register the formatter plugin and a terminal-reporter stub if needed.

    The stub is only registered when the user has explicitly silenced the
    default terminal reporter with ``-p no:terminal``.  If the terminal
    plugin is still active, registering the stub would conflict with it
    when pytest's own terminal reporter tries to register later — causing
    a ``ValueError: Plugin name already registered`` crash.
    """
    _plugin_key = "_pytest_formatter_instance"
    if not config.pluginmanager.get_plugin(_plugin_key):
        config.pluginmanager.register(FormatterPlugin(), _plugin_key)

    terminal_blocked = config.pluginmanager.is_blocked("terminal")
    terminal_absent  = not config.pluginmanager.get_plugin("terminalreporter")
    if terminal_blocked and terminal_absent and _PytestTerminalWriter is not None:
        _writer_cls = _PytestTerminalWriter  # local binding — narrows type for Pyright

        class _TerminalReporterStub:  # pylint: disable=too-few-public-methods
            """Exists only to satisfy config.get_terminal_writer()."""

            def __init__(self) -> None:
                self._tw = _writer_cls(io.StringIO())

        config.pluginmanager.register(_TerminalReporterStub(), "terminalreporter")
