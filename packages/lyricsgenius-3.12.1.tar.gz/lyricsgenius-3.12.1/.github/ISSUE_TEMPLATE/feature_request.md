---
name: Feature request
about: Suggest an idea for improving LyricsGenius

---

**Is your feature request related to a problem? Please describe.**
Write a clear and concise description of what the problem is -- e.g. "I'm always frustrated when [...]"

**Describe the solution you'd like**
Write a clear and concise description of what you want to happen.

**Describe alternatives you've considered**
Write a clear and concise description of any alternative solutions or features you've considered.

**Additional context**
Add any other context or screenshots about the feature request here.
