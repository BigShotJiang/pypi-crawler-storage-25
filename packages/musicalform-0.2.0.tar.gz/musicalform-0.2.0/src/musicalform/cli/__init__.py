"""CLI package for musicalform."""
