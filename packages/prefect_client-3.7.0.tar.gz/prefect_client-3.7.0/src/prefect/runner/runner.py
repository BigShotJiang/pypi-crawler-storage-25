"""
Runners are responsible for managing the execution of all deployments.

When creating a deployment using either `flow.serve` or the `serve` utility,
they also will poll for scheduled runs.

Example:
    ```python
    import time
    from prefect import flow, serve


    @flow
    def slow_flow(sleep: int = 60):
        "Sleepy flow - sleeps the provided amount of time (in seconds)."
        time.sleep(sleep)


    @flow
    def fast_flow():
        "Fastest flow this side of the Mississippi."
        return


    if __name__ == "__main__":
        slow_deploy = slow_flow.to_deployment(name="sleeper", interval=45)
        fast_deploy = fast_flow.to_deployment(name="fast")

        # serve generates a Runner instance
        serve(slow_deploy, fast_deploy)
    ```

"""

from __future__ import annotations

import asyncio
import datetime
import logging
import multiprocessing.context
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import warnings
from contextlib import AsyncExitStack
from copy import deepcopy
from functools import partial
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    TypedDict,
    Union,
)
from uuid import UUID, uuid4

import anyio
import anyio.abc
import anyio.to_thread
from typing_extensions import Self

from prefect._internal.compatibility.async_dispatch import async_dispatch
from prefect._internal.compatibility.deprecated import (
    PrefectDeprecationWarning,
    generate_deprecation_message,
)
from prefect._internal.concurrency.api import (
    create_call,
    from_async,
    from_sync,
)
from prefect._observers import FlowRunCancellingObserver
from prefect.bundles import (
    SerializedBundle,
    execute_bundle_in_subprocess,
    extract_flow_from_bundle,
)
from prefect.client.orchestration import get_client
from prefect.client.schemas.objects import (
    ConcurrencyLimitConfig,
    State,
)
from prefect.client.schemas.objects import Flow as APIFlow
from prefect.events import DeploymentTriggerTypes, TriggerTypes
from prefect.events.clients import (  # noqa: F401 (patch target)
    EventsClient,
    get_events_client,
)
from prefect.exceptions import Abort, ObjectNotFound
from prefect.flow_engine import run_flow_in_subprocess
from prefect.flows import Flow, FlowStateHook, load_flow_from_flow_run
from prefect.logging.loggers import PrefectLogAdapter, flow_run_logger, get_logger
from prefect.runner._cancel_finalizer import (
    finalize_cancelled_state,
    should_skip_cancel_after_acked_process_exit,
)
from prefect.runner._cancellation_manager import CancellationManager
from prefect.runner._control_channel import ControlChannel
from prefect.runner._deployment_registry import DeploymentRegistry
from prefect.runner._event_emitter import EventEmitter
from prefect.runner._flow_run_executor import ProcessStarter
from prefect.runner._hook_runner import HookRunner
from prefect.runner._limit_manager import LimitManager
from prefect.runner._process_manager import ProcessManager, _pid_is_alive
from prefect.runner._scheduled_run_poller import ScheduledRunPoller
from prefect.runner._starter_direct import DirectSubprocessStarter
from prefect.runner._starter_engine import EngineCommandStarter
from prefect.runner._state_proposer import StateProposer
from prefect.runner.storage import RunnerStorage
from prefect.schedules import Schedule
from prefect.settings import (
    PREFECT_API_URL,
    PREFECT_RUNNER_SERVER_ENABLE,
    get_current_settings,
)
from prefect.states import (
    AwaitingRetry,
)
from prefect.types.entrypoint import EntrypointType
from prefect.utilities._engine import get_hook_name
from prefect.utilities._infrastructure_exit_codes import get_infrastructure_exit_info
from prefect.utilities.annotations import NotSet
from prefect.utilities.asyncutils import (
    asyncnullcontext,
    is_async_fn,
)
from prefect.utilities.engine import (  # noqa: F401 (patch target)
    propose_state,
    propose_state_sync,
)
from prefect.utilities.processutils import (
    command_from_string,
    get_sys_executable,
    run_process,
    sanitize_subprocess_env,
)
from prefect.utilities.services import (
    start_client_metrics_server,
)

if TYPE_CHECKING:
    import concurrent.futures

    from prefect.client.schemas.objects import FlowRun
    from prefect.client.schemas.responses import DeploymentResponse
    from prefect.client.types.flexible_schedule_list import FlexibleScheduleList
    from prefect.deployments.runner import RunnerDeployment


def _is_windows_platform() -> bool:
    return os.name == "nt"


__all__ = ["Runner"]


class ProcessMapEntry(TypedDict):
    flow_run: "FlowRun"
    pid: int


class Runner:
    def __init__(
        self,
        name: Optional[str] = None,
        query_seconds: Optional[float] = None,
        prefetch_seconds: float = 10,
        heartbeat_seconds: Optional[float] = None,
        limit: int | type[NotSet] | None = NotSet,
        pause_on_shutdown: bool = True,
        webserver: bool = False,
    ):
        """
        Responsible for managing the execution of remotely initiated flow runs.

        Args:
            name: The name of the runner. If not provided, a random one
                will be generated. If provided, it cannot contain '/' or '%'.
            query_seconds: The number of seconds to wait between querying for
                scheduled flow runs; defaults to `PREFECT_RUNNER_POLL_FREQUENCY`
            prefetch_seconds: The number of seconds to prefetch flow runs for.
            heartbeat_seconds: The number of seconds between heartbeat events emitted
                by flow runs managed by this runner. If not provided, the value of
                `PREFECT_FLOWS_HEARTBEAT_FREQUENCY` will be used. Heartbeats are used
                to detect crashed flow runs.
            limit: The maximum number of flow runs this runner should be running at. Provide `None` for no limit.
                If not provided, the runner will use the value of `PREFECT_RUNNER_PROCESS_LIMIT`.
            pause_on_shutdown: A boolean for whether or not to automatically pause
                deployment schedules on shutdown; defaults to `True`
            webserver: a boolean flag for whether to start a webserver for this runner

        Examples:
            Set up a Runner to manage the execute of scheduled flow runs for two flows:
                ```python
                import asyncio
                from prefect import flow, Runner

                @flow
                def hello_flow(name):
                    print(f"hello {name}")

                @flow
                def goodbye_flow(name):
                    print(f"goodbye {name}")

                if __name__ == "__main__"
                    runner = Runner(name="my-runner")

                    # Will be runnable via the API
                    runner.add_flow(hello_flow)

                    # Run on a cron schedule
                    runner.add_flow(goodbye_flow, schedule={"cron": "0 * * * *"})

                    asyncio.run(runner.start())
                ```
        """
        self._heartbeat_seconds = heartbeat_seconds

        settings = get_current_settings()

        if name and ("/" in name or "%" in name):
            raise ValueError("Runner name cannot contain '/' or '%'")
        self.name: str = Path(name).stem if name is not None else f"runner-{uuid4()}"
        self._logger: "logging.Logger" = get_logger("runner")

        self.started: bool = False
        self.stopping: bool = False
        self.pause_on_shutdown: bool = pause_on_shutdown
        self.limit: int | None = (
            settings.runner.process_limit
            if limit is NotSet or isinstance(limit, type)
            else limit
        )
        self.webserver: bool = webserver

        self.query_seconds: float = query_seconds or settings.runner.poll_frequency
        self._prefetch_seconds: float = prefetch_seconds

        self._exit_stack = AsyncExitStack()
        self._cancelling_observer: FlowRunCancellingObserver | None = None
        self._scheduled_task_scopes: set[anyio.abc.CancelScope] = set()
        self._flow_run_bundle_map: dict[UUID, SerializedBundle] = dict()

        self._tmp_dir: Path = (
            Path(tempfile.gettempdir()) / "runner_storage" / str(uuid4())
        )
        self._storage_objs: list[RunnerStorage] = []

        self._loop: Optional[asyncio.AbstractEventLoop] = None

        self._last_polled_fallback: datetime.datetime | None = None

        # --- Services (client-independent, constructed eagerly) ---
        self._deployment_registry = DeploymentRegistry()
        self._process_manager = ProcessManager()
        self._limit_manager = LimitManager(limit=self.limit)
        # HookRunner is constructed in __aenter__ once the client is available,
        # so we can build a storage-aware flow resolver closure.
        self._hook_runner: HookRunner | None = None
        # Cross-platform IPC channel for delivering control intent (cancel
        # today; suspend in a follow-up) into child subprocesses; see
        # prefect.runner._control_channel.
        self._control_channel: ControlChannel = ControlChannel()

        # --- Facade-owned mutable state (kept until methods are fully delegated) ---
        self._submitting_flow_run_ids: set[UUID] = set()
        self._rescheduling: bool = False

        # --- Facade-owned mutable containers (exposed via @property) ---
        self.__flow_run_process_map_internal: dict[UUID, ProcessMapEntry] = {}
        self.__cancelling_flow_run_ids_internal: set[UUID] = set()

    @property
    def _flow_run_process_map(self) -> dict[UUID, ProcessMapEntry]:
        return self.__flow_run_process_map_internal

    @property
    def _cancelling_flow_run_ids(self) -> set[UUID]:
        return self.__cancelling_flow_run_ids_internal

    @property
    def last_polled(self) -> datetime.datetime | None:
        if hasattr(self, "_scheduled_run_poller"):
            return self._scheduled_run_poller.last_polled
        return self._last_polled_fallback

    @last_polled.setter
    def last_polled(self, value: datetime.datetime | None) -> None:
        if hasattr(self, "_scheduled_run_poller"):
            self._scheduled_run_poller.last_polled = value
        else:
            self._last_polled_fallback = value

    @property
    def _limiter(self) -> anyio.CapacityLimiter | None:
        # Test line 291: assert runner._limiter is None (before __aenter__)
        # LimitManager._limiter is None before __aenter__; property delegates correctly
        return self._limit_manager._limiter

    @property
    def _flow_run_process_map_lock(self) -> asyncio.Lock:
        return self._process_manager._process_map_lock

    @property
    def _events_client(self) -> EventsClient:
        """Backward-compatible delegate — returns the EventEmitter's inner client."""
        return self._event_emitter._events_client

    async def _add_flow_run_process_map_entry(
        self, flow_run_id: UUID, process_map_entry: ProcessMapEntry
    ):
        async with self._flow_run_process_map_lock:
            self._flow_run_process_map[flow_run_id] = process_map_entry

            if TYPE_CHECKING:
                assert self._cancelling_observer is not None
            self._cancelling_observer.add_in_flight_flow_run_id(flow_run_id)

    async def _remove_flow_run_process_map_entry(self, flow_run_id: UUID):
        async with self._flow_run_process_map_lock:
            self._flow_run_process_map.pop(flow_run_id, None)

            if TYPE_CHECKING:
                assert self._cancelling_observer is not None
            self._cancelling_observer.remove_in_flight_flow_run_id(flow_run_id)

        # Drop the control channel registration so the per-run token,
        # connection, and pending state are released.
        self._control_channel.unregister(flow_run_id)

    async def aadd_deployment(
        self,
        deployment: "RunnerDeployment",
    ) -> UUID:
        """
        Registers the deployment with the Prefect API and will monitor for work once
        the runner is started. Async version.

        Args:
            deployment: A deployment for the runner to register.
        """
        deployment_id = await deployment.aapply()
        storage = deployment.storage
        if storage is not None:
            storage = self._add_storage(storage)
            self._deployment_registry.register_storage(deployment_id, storage)
        self._deployment_registry.register_deployment(deployment_id)

        return deployment_id

    @async_dispatch(aadd_deployment)
    def add_deployment(
        self,
        deployment: "RunnerDeployment",
    ) -> UUID:
        """
        Registers the deployment with the Prefect API and will monitor for work once
        the runner is started.

        Args:
            deployment: A deployment for the runner to register.
        """
        return from_sync.call_soon_in_loop_thread(
            create_call(self.aadd_deployment, deployment)
        ).result()

    async def aadd_flow(
        self,
        flow: Flow[Any, Any],
        name: Optional[str] = None,
        interval: Optional[
            Union[
                Iterable[Union[int, float, datetime.timedelta]],
                int,
                float,
                datetime.timedelta,
            ]
        ] = None,
        cron: Optional[Union[Iterable[str], str]] = None,
        rrule: Optional[Union[Iterable[str], str]] = None,
        paused: Optional[bool] = None,
        schedule: Optional[Schedule] = None,
        schedules: Optional["FlexibleScheduleList"] = None,
        concurrency_limit: Optional[Union[int, ConcurrencyLimitConfig, None]] = None,
        parameters: Optional[dict[str, Any]] = None,
        triggers: Optional[List[Union[DeploymentTriggerTypes, TriggerTypes]]] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        version: Optional[str] = None,
        enforce_parameter_schema: bool = True,
        entrypoint_type: EntrypointType = EntrypointType.FILE_PATH,
    ) -> UUID:
        """
        Provides a flow to the runner to be run based on the provided configuration.
        Async version.

        Will create a deployment for the provided flow and register the deployment
        with the runner.

        Args:
            flow: A flow for the runner to run.
            name: The name to give the created deployment. Will default to the name
                of the runner.
            interval: An interval on which to execute the current flow. Accepts either a number
                or a timedelta object. If a number is given, it will be interpreted as seconds.
            cron: A cron schedule of when to execute runs of this flow.
            rrule: An rrule schedule of when to execute runs of this flow.
            paused: Whether or not to set the created deployment as paused.
            schedule: A schedule object defining when to execute runs of this deployment.
                Used to provide additional scheduling options like `timezone` or `parameters`.
            schedules: A list of schedule objects defining when to execute runs of this flow.
                Used to define multiple schedules or additional scheduling options like `timezone`.
            concurrency_limit: The maximum number of concurrent runs of this flow to allow.
            triggers: A list of triggers that should kick of a run of this flow.
            parameters: A dictionary of default parameter values to pass to runs of this flow.
            description: A description for the created deployment. Defaults to the flow's
                description if not provided.
            tags: A list of tags to associate with the created deployment for organizational
                purposes.
            version: A version for the created deployment. Defaults to the flow's version.
            entrypoint_type: Type of entrypoint to use for the deployment. When using a module path
                entrypoint, ensure that the module will be importable in the execution environment.
        """
        api = PREFECT_API_URL.value()
        if any([interval, cron, rrule, schedule, schedules]) and not api:
            self._logger.warning(
                "Cannot schedule flows on an ephemeral server; run `prefect server"
                " start` to start the scheduler."
            )
        name = self.name if name is None else name

        deployment = await flow.ato_deployment(
            name=name,
            interval=interval,
            cron=cron,
            rrule=rrule,
            schedule=schedule,
            schedules=schedules,
            paused=paused,
            triggers=triggers,
            parameters=parameters,
            description=description,
            tags=tags,
            version=version,
            enforce_parameter_schema=enforce_parameter_schema,
            entrypoint_type=entrypoint_type,
            concurrency_limit=concurrency_limit,
        )

        # Explicitly mark work pool fields as set so _update() includes them
        # in the payload. This clears any existing work pool config on the
        # server, ensuring runs execute locally instead of on a remote worker.
        deployment.work_pool_name = None
        deployment.work_queue_name = None

        deployment_id = await self.aadd_deployment(deployment)

        # Only add the flow to the map if it is not loaded from storage
        # Further work is needed to support directly running flows created using `flow.from_source`
        if not getattr(flow, "_storage", None):
            self._deployment_registry.register_flow(deployment_id, flow)
        return deployment_id

    @async_dispatch(aadd_flow)
    def add_flow(
        self,
        flow: Flow[Any, Any],
        name: Optional[str] = None,
        interval: Optional[
            Union[
                Iterable[Union[int, float, datetime.timedelta]],
                int,
                float,
                datetime.timedelta,
            ]
        ] = None,
        cron: Optional[Union[Iterable[str], str]] = None,
        rrule: Optional[Union[Iterable[str], str]] = None,
        paused: Optional[bool] = None,
        schedule: Optional[Schedule] = None,
        schedules: Optional["FlexibleScheduleList"] = None,
        concurrency_limit: Optional[Union[int, ConcurrencyLimitConfig, None]] = None,
        parameters: Optional[dict[str, Any]] = None,
        triggers: Optional[List[Union[DeploymentTriggerTypes, TriggerTypes]]] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        version: Optional[str] = None,
        enforce_parameter_schema: bool = True,
        entrypoint_type: EntrypointType = EntrypointType.FILE_PATH,
    ) -> UUID:
        """
        Provides a flow to the runner to be run based on the provided configuration.

        Will create a deployment for the provided flow and register the deployment
        with the runner.

        Args:
            flow: A flow for the runner to run.
            name: The name to give the created deployment. Will default to the name
                of the runner.
            interval: An interval on which to execute the current flow. Accepts either a number
                or a timedelta object. If a number is given, it will be interpreted as seconds.
            cron: A cron schedule of when to execute runs of this flow.
            rrule: An rrule schedule of when to execute runs of this flow.
            paused: Whether or not to set the created deployment as paused.
            schedule: A schedule object defining when to execute runs of this deployment.
                Used to provide additional scheduling options like `timezone` or `parameters`.
            schedules: A list of schedule objects defining when to execute runs of this flow.
                Used to define multiple schedules or additional scheduling options like `timezone`.
            concurrency_limit: The maximum number of concurrent runs of this flow to allow.
            triggers: A list of triggers that should kick of a run of this flow.
            parameters: A dictionary of default parameter values to pass to runs of this flow.
            description: A description for the created deployment. Defaults to the flow's
                description if not provided.
            tags: A list of tags to associate with the created deployment for organizational
                purposes.
            version: A version for the created deployment. Defaults to the flow's version.
            entrypoint_type: Type of entrypoint to use for the deployment. When using a module path
                entrypoint, ensure that the module will be importable in the execution environment.
        """
        return from_sync.call_soon_in_loop_thread(
            create_call(
                self.aadd_flow,
                flow,
                name=name,
                interval=interval,
                cron=cron,
                rrule=rrule,
                paused=paused,
                schedule=schedule,
                schedules=schedules,
                concurrency_limit=concurrency_limit,
                parameters=parameters,
                triggers=triggers,
                description=description,
                tags=tags,
                version=version,
                enforce_parameter_schema=enforce_parameter_schema,
                entrypoint_type=entrypoint_type,
            )
        ).result()

    def _add_storage(self, storage: RunnerStorage) -> RunnerStorage:
        """
        Adds a storage object to the runner. The storage object will be used to pull
        code to the runner's working directory before the runner starts.

        Args:
            storage: The storage object to add to the runner.
        Returns:
            The updated storage object that was added to the runner.
        """
        if storage not in self._storage_objs:
            storage_copy = deepcopy(storage)
            storage_copy.set_base_path(self._tmp_dir)

            self._logger.debug(
                f"Adding storage {storage_copy!r} to runner at"
                f" {str(storage_copy.destination)!r}"
            )
            self._storage_objs.append(storage_copy)

            return storage_copy
        else:
            return next(s for s in self._storage_objs if s == storage)

    def handle_sigterm(self, *args: Any, **kwargs: Any) -> None:
        """
        Gracefully shuts down the runner when a SIGTERM is received.
        """
        self._logger.info("SIGTERM received, initiating graceful shutdown...")
        self.stop()

        sys.exit(0)

    async def start(
        self, run_once: bool = False, webserver: Optional[bool] = None
    ) -> None:
        """
        Starts a runner.

        The runner will begin monitoring for and executing any scheduled work for all added flows.

        Args:
            run_once: If True, the runner will through one query loop and then exit.
            webserver: a boolean for whether to start a webserver for this runner. If provided,
                overrides the default on the runner

        Examples:
            Initialize a Runner, add two flows, and serve them by starting the Runner:

            ```python
            import asyncio
            from prefect import flow, Runner

            @flow
            def hello_flow(name):
                print(f"hello {name}")

            @flow
            def goodbye_flow(name):
                print(f"goodbye {name}")

            if __name__ == "__main__"
                runner = Runner(name="my-runner")

                # Will be runnable via the API
                runner.add_flow(hello_flow)

                # Run on a cron schedule
                runner.add_flow(goodbye_flow, schedule={"cron": "0 * * * *"})

                asyncio.run(runner.start())
            ```
        """
        from prefect.runner.server import start_webserver

        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGTERM, self.handle_sigterm)

        webserver = webserver if webserver is not None else self.webserver

        if webserver or PREFECT_RUNNER_SERVER_ENABLE.value():
            # we'll start the ASGI server in a separate thread so that
            # uvicorn does not block the main thread
            server_thread = threading.Thread(
                name="runner-server-thread",
                target=partial(
                    start_webserver,
                    runner=self,
                ),
                daemon=True,
            )
            server_thread.start()

        start_client_metrics_server()

        async with self:
            # This task group isn't included in the exit stack because we want to
            # stay in this function until the runner is told to stop
            async with self._loops_task_group:
                if run_once:
                    # Pull storage once before polling (run_once skips storage loops)
                    for storage in self._storage_objs:
                        await storage.pull_code()
                    await self._scheduled_run_poller.run_once()
                else:
                    self._loops_task_group.start_soon(self._scheduled_run_poller.run)

    def execute_in_background(
        self, func: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> "concurrent.futures.Future[Any]":
        """
        Executes a function in the background.
        """
        if TYPE_CHECKING:
            assert self._loop is not None

        return asyncio.run_coroutine_threadsafe(func(*args, **kwargs), self._loop)

    async def cancel_all(self) -> None:
        await self._cancellation_manager.cancel_all()

    async def astop(self) -> None:
        """Stops the runner's polling cycle. Async version."""
        if not self.started:
            raise RuntimeError(
                "Runner has not yet started. Please start the runner by calling"
                " .start()"
            )

        self.started = False
        self.stopping = True
        if hasattr(self, "_scheduled_run_poller") and self._scheduled_run_poller:
            self._scheduled_run_poller.stopping = True
        await self.cancel_all()
        try:
            self._loops_task_group.cancel_scope.cancel()
        except Exception:
            self._logger.exception(
                "Exception encountered while shutting down", exc_info=True
            )

    @async_dispatch(astop)
    def stop(self):
        """Stops the runner's polling cycle."""
        from_sync.call_soon_in_loop_thread(create_call(self.astop)).result()

    async def execute_flow_run(
        self,
        flow_run_id: UUID,
        entrypoint: str | None = None,
        command: str | None = None,
        cwd: Path | str | None = None,
        env: dict[str, str | None] | None = None,
        task_status: anyio.abc.TaskStatus[int] = anyio.TASK_STATUS_IGNORED,
        stream_output: bool = True,
    ) -> anyio.abc.Process | multiprocessing.context.SpawnProcess | None:
        """
        Executes a single flow run with the given ID.

        Deprecated: Use `FlowRunExecutorContext` with `EngineCommandStarter` instead.

        Execution will wait to monitor for cancellation requests. Exits once
        the flow run process has exited.

        Returns:
            The flow run process.
        """
        warnings.warn(
            generate_deprecation_message(
                name="Runner.execute_flow_run",
                start_date="Mar 2026",
                help="Use `FlowRunExecutorContext` with `EngineCommandStarter` instead.",
            ),
            PrefectDeprecationWarning,
            stacklevel=2,
        )
        self.pause_on_shutdown = False
        context = self if not self.started else asyncnullcontext()

        async with context:
            if not self._acquire_limit_slot(flow_run_id):
                return

            self._submitting_flow_run_ids.add(flow_run_id)
            flow_run = await self._client.read_flow_run(flow_run_id)

            # If the flow run is already cancelling or cancelled, exit early
            if flow_run.state and flow_run.state.is_cancelling():
                await self._mark_flow_run_as_cancelled(
                    flow_run,
                    state_updates={
                        "message": "Flow run was cancelled before execution started."
                    },
                )
                self._release_limit_slot(flow_run_id)
                self._submitting_flow_run_ids.discard(flow_run_id)
                return

            if flow_run.state and flow_run.state.is_cancelled():
                self._release_limit_slot(flow_run_id)
                self._submitting_flow_run_ids.discard(flow_run_id)
                return

            process: (
                anyio.abc.Process | multiprocessing.context.SpawnProcess | Exception
            ) = await self._runs_task_group.start(
                partial(
                    self._submit_run_and_capture_errors,
                    flow_run=flow_run,
                    entrypoint=entrypoint,
                    command=command,
                    cwd=cwd,
                    env=env,
                    stream_output=stream_output,
                ),
            )
            if isinstance(process, Exception):
                return

            if process.pid is None:
                raise RuntimeError("Process has no PID")

            task_status.started(process.pid)

            # Only add the process to the map if it is still running
            # The process may be a multiprocessing.context.SpawnProcess, in which case it will have an `exitcode` attribute
            # but no `returncode` attribute
            if (
                getattr(process, "returncode", None)
                or getattr(process, "exitcode", None)
            ) is None:
                await self._add_flow_run_process_map_entry(
                    flow_run.id, ProcessMapEntry(pid=process.pid, flow_run=flow_run)
                )

            while True:
                # Wait until flow run execution is complete and the process has been removed from the map
                await anyio.sleep(0.1)
                if self._flow_run_process_map.get(flow_run.id) is None:
                    break

            return process

    async def execute_bundle(
        self,
        bundle: SerializedBundle,
        cwd: Path | str | None = None,
        env: dict[str, str | None] | None = None,
    ) -> None:
        """
        Executes a bundle in a subprocess.

        Deprecated: Use `execute_bundle()` from `prefect.bundles.execute`
        instead.
        """
        warnings.warn(
            generate_deprecation_message(
                name="Runner.execute_bundle",
                start_date="Mar 2026",
                help="Use `execute_bundle()` from `prefect.bundles.execute` instead.",
            ),
            PrefectDeprecationWarning,
            stacklevel=2,
        )
        from prefect.client.schemas.objects import FlowRun

        self.pause_on_shutdown = False
        context = self if not self.started else asyncnullcontext()

        flow_run = FlowRun.model_validate(bundle["flow_run"])

        # Add heartbeat_seconds to env if configured
        if self._heartbeat_seconds is not None:
            env = env or {}
            env["PREFECT_FLOWS_HEARTBEAT_FREQUENCY"] = str(int(self._heartbeat_seconds))

        async with context:
            if not self._acquire_limit_slot(flow_run.id):
                return

            # Register the flow run with the control channel before spawning
            # so the child can connect back as soon as it starts.
            control_env: dict[str, str] = {}
            control_registered = False
            try:
                port, token = self._control_channel.register(flow_run.id)
                control_env["PREFECT__CONTROL_PORT"] = str(port)
                control_env["PREFECT__CONTROL_TOKEN"] = token
                control_registered = True
            except RuntimeError:
                # Channel not entered (e.g. tests using the legacy facade
                # without __aenter__); silently skip.
                pass

            if control_env:
                env = dict(env or {})
                env.update(control_env)

            try:
                process = execute_bundle_in_subprocess(bundle, cwd=cwd, env=env)
            except BaseException:
                if control_registered:
                    self._control_channel.unregister(flow_run.id)
                raise

            if process.pid is None:
                if control_registered:
                    self._control_channel.unregister(flow_run.id)
                # This shouldn't happen because `execute_bundle_in_subprocess` starts the process
                # but we'll handle it gracefully anyway
                msg = "Failed to start process for flow execution. No PID returned."
                await self._propose_crashed_state(flow_run, msg)
                raise RuntimeError(msg)

            await self._add_flow_run_process_map_entry(
                flow_run.id, ProcessMapEntry(pid=process.pid, flow_run=flow_run)
            )
            self._flow_run_bundle_map[flow_run.id] = bundle

            await anyio.to_thread.run_sync(process.join)

            await self._remove_flow_run_process_map_entry(flow_run.id)

            flow_run_logger = self._get_flow_run_logger(flow_run)
            if process.exitcode is None:
                raise RuntimeError("Process has no exit code")

            if process.exitcode:
                info = get_infrastructure_exit_info(process.exitcode)
                flow_run_logger.log(
                    info.log_level,
                    f"Process for flow run {flow_run.name!r} exited with status code:"
                    f" {process.exitcode}; {info.explanation}",
                )
                if info.resolution:
                    flow_run_logger.info(info.resolution)
                terminal_state = await self._propose_crashed_state(
                    flow_run, info.explanation
                )
                if terminal_state:
                    await self._run_on_crashed_hooks(
                        flow_run=flow_run, state=terminal_state
                    )
            else:
                flow_run_logger.info(
                    f"Process for flow run {flow_run.name!r} exited cleanly."
                )

    def _get_flow_run_logger(self, flow_run: "FlowRun") -> PrefectLogAdapter:
        return flow_run_logger(flow_run=flow_run).getChild(
            "runner",
            extra={
                "runner_name": self.name,
            },
        )

    async def _run_process(
        self,
        flow_run: "FlowRun",
        task_status: anyio.abc.TaskStatus[
            anyio.abc.Process | multiprocessing.context.SpawnProcess
        ] = anyio.TASK_STATUS_IGNORED,
        entrypoint: str | None = None,
        command: str | None = None,
        cwd: Path | str | None = None,
        env: dict[str, str | None] | None = None,
        stream_output: bool = True,
    ) -> int | None:
        """
        Runs the given flow run in a subprocess.

        Args:
            flow_run: Flow run to execute via process. The ID of this flow run
                is stored in the PREFECT__FLOW_RUN_ID environment variable to
                allow the engine to retrieve the corresponding flow's code and
                begin execution.
            task_status: anyio task status used to send a message to the caller
                than the flow run process has started.
        """
        # If we have an instance of the flow for this deployment, run it directly in a subprocess
        if flow_run.deployment_id is not None:
            flow = self._deployment_registry.get_flow(flow_run.deployment_id)
            if flow:
                subprocess_env: dict[str, str] = {}
                control_registered = False
                if self._heartbeat_seconds is not None:
                    subprocess_env["PREFECT_FLOWS_HEARTBEAT_FREQUENCY"] = str(
                        int(self._heartbeat_seconds)
                    )
                try:
                    port, token = self._control_channel.register(flow_run.id)
                    subprocess_env["PREFECT__CONTROL_PORT"] = str(port)
                    subprocess_env["PREFECT__CONTROL_TOKEN"] = token
                    control_registered = True
                except RuntimeError:
                    # Channel not entered (e.g. tests using the legacy facade
                    # without __aenter__); silently skip.
                    pass
                handed_off = False
                try:
                    process = run_flow_in_subprocess(
                        flow, flow_run=flow_run, env=subprocess_env or None
                    )
                    task_status.started(process)
                    handed_off = True
                    await anyio.to_thread.run_sync(process.join)
                    return process.exitcode
                except BaseException:
                    if control_registered and not handed_off:
                        self._control_channel.unregister(flow_run.id)
                    raise

        # Otherwise, we'll need to run a `python -m prefect.engine` command to load and run the flow
        if command is None:
            runner_command = [get_sys_executable(), "-m", "prefect.engine"]
        else:
            runner_command = command_from_string(command)

        flow_run_logger = self._get_flow_run_logger(flow_run)

        # We must add creationflags to a dict so it is only passed as a function
        # parameter on Windows, because the presence of creationflags causes
        # errors on Unix even if set to None
        kwargs: Dict[str, object] = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

        flow_run_logger.info("Starting flow run process...")

        merged_env: dict[str, str | None] = {**os.environ, **(env or {})}
        merged_env.update(
            get_current_settings().to_environment_variables(exclude_unset=True)
        )

        # Register the flow run with the control channel before spawning so
        # the child can connect back as soon as it starts.
        control_env: dict[str, str] = {}
        control_registered = False
        if hasattr(self, "_control_channel"):
            try:
                port, token = self._control_channel.register(flow_run.id)
                control_env["PREFECT__CONTROL_PORT"] = str(port)
                control_env["PREFECT__CONTROL_TOKEN"] = token
                control_registered = True
            except RuntimeError:
                # Channel not entered (e.g. tests using the legacy facade
                # without __aenter__); silently skip.
                pass

        merged_env.update(
            {
                **{
                    "PREFECT__FLOW_RUN_ID": str(flow_run.id),
                    "PREFECT__STORAGE_BASE_PATH": str(self._tmp_dir),
                    "PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS": "false",
                    **control_env,
                },
                **({"PREFECT__FLOW_ENTRYPOINT": entrypoint} if entrypoint else {}),
                **(
                    {
                        "PREFECT_FLOWS_HEARTBEAT_FREQUENCY": str(
                            int(self._heartbeat_seconds)
                        )
                    }
                    if self._heartbeat_seconds is not None
                    else {}
                ),
            }
        )
        sanitized_env = sanitize_subprocess_env(merged_env)
        storage = (
            self._deployment_registry.get_storage(flow_run.deployment_id)
            if flow_run.deployment_id
            else None
        )
        if storage and storage.pull_interval:
            # perform an adhoc pull of code before running the flow if an
            # adhoc pull hasn't been performed in the last pull_interval
            # TODO: Explore integrating this behavior with global concurrency.
            last_adhoc_pull = getattr(storage, "last_adhoc_pull", None)
            if (
                last_adhoc_pull is None
                or last_adhoc_pull
                < datetime.datetime.now()
                - datetime.timedelta(seconds=storage.pull_interval)
            ):
                self._logger.debug(
                    "Performing adhoc pull of code for flow run %s with storage %r",
                    flow_run.id,
                    storage,
                )
                await storage.pull_code()
                setattr(storage, "last_adhoc_pull", datetime.datetime.now())

        handed_off = False

        def _task_status_handler(process: anyio.abc.Process) -> anyio.abc.Process:
            nonlocal handed_off
            handed_off = True
            return process

        try:
            process = await run_process(
                command=runner_command,
                stream_output=stream_output,
                task_status=task_status,
                task_status_handler=_task_status_handler,
                env=sanitized_env,
                cwd=storage.destination if storage else cwd,
                **kwargs,
            )
        except BaseException:
            if control_registered and not handed_off:
                self._control_channel.unregister(flow_run.id)
            raise

        return process.returncode

    async def _kill_process(
        self,
        pid: int,
        grace_seconds: float = 30,
    ):
        """
        Kills a given flow run process.

        Args:
            pid: ID of the process to kill
            grace_seconds: Number of seconds to wait for the process to end.
        """
        # In a non-windows environment first send a SIGTERM, then, after
        # `grace_seconds` seconds have passed subsequent send SIGKILL. In
        # Windows we use CTRL_BREAK_EVENT as SIGTERM is useless:
        # https://bugs.python.org/issue26350
        if sys.platform == "win32":
            try:
                os.kill(pid, signal.CTRL_BREAK_EVENT)
            except (ProcessLookupError, WindowsError):
                raise RuntimeError(
                    f"Unable to kill process {pid!r}: The process was not found."
                )
        else:
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                raise RuntimeError(
                    f"Unable to kill process {pid!r}: The process was not found."
                )

            # Throttle how often we check if the process is still alive to keep
            # from making too many system calls in a short period of time.
            check_interval = max(grace_seconds / 10, 1)

            with anyio.move_on_after(grace_seconds):
                while True:
                    await anyio.sleep(check_interval)

                    # Detect if the process is still alive. If not do an early
                    # return as the process respected the SIGTERM from above.
                    try:
                        os.kill(pid, 0)
                    except ProcessLookupError:
                        return

            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                # We shouldn't ever end up here, but it's possible that the
                # process ended right after the check above.
                return

    async def _wait_for_process_exit(
        self,
        flow_run_id: UUID,
        pid: int,
        grace_seconds: float = 30,
    ) -> bool:
        """Wait for a facade-tracked process to exit without sending a signal."""
        deadline = time.monotonic() + max(grace_seconds, 0)
        check_interval = max(grace_seconds / 10, 1) if grace_seconds > 0 else 0

        while True:
            if self._flow_run_process_map.get(flow_run_id) is None:
                return True

            if not _pid_is_alive(pid):
                return True

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False

            await anyio.sleep(min(check_interval, remaining))

    def reschedule_current_flow_runs(
        self,
    ) -> None:
        """
        Reschedules all flow runs that are currently running.

        Deprecated: SIGTERM rescheduling is now handled inline by the CLI execute path.

        This should only be called when the runner is shutting down because it kill all
        child processes and short-circuit the crash detection logic.
        """
        warnings.warn(
            generate_deprecation_message(
                name="Runner.reschedule_current_flow_runs",
                start_date="Mar 2026",
                help="SIGTERM rescheduling is now handled inline by the CLI execute path.",
            ),
            PrefectDeprecationWarning,
            stacklevel=2,
        )
        self._rescheduling = True
        # Create a new sync client because this will often run in a separate thread
        # as part of a signal handler.
        with get_client(sync_client=True) as client:
            self._logger.info("Rescheduling flow runs...")
            for process_info in self._flow_run_process_map.values():
                flow_run = process_info["flow_run"]
                run_logger = self._get_flow_run_logger(flow_run)
                run_logger.info(
                    "Rescheduling flow run for resubmission in response to SIGTERM"
                )
                try:
                    propose_state_sync(client, AwaitingRetry(), flow_run_id=flow_run.id)
                    os.kill(process_info["pid"], signal.SIGTERM)
                    run_logger.info("Rescheduled flow run for resubmission")
                except ProcessLookupError:
                    # Process may have already exited
                    pass
                except Abort as exc:
                    run_logger.info(
                        (
                            "Aborted submission of flow run. "
                            f"Server sent an abort signal: {exc}"
                        ),
                    )
                except Exception:
                    run_logger.exception(
                        "Failed to reschedule flow run",
                    )

    async def _pause_schedules(self):
        """
        Pauses all deployment schedules.
        """
        self._logger.info("Pausing all deployments...")
        for deployment_id in self._deployment_registry.get_deployment_ids():
            await self._client.pause_deployment(deployment_id)
            self._logger.debug(f"Paused deployment '{deployment_id}'")

        self._logger.info("All deployments have been paused!")

    async def _get_and_submit_flow_runs(self):
        if self.stopping:
            return
        await self._scheduled_run_poller._get_and_submit_flow_runs()

    async def _cancel_run(
        self, flow_run: "FlowRun | uuid.UUID", state_msg: Optional[str] = None
    ):
        if isinstance(flow_run, uuid.UUID):
            if flow_run in self._cancelling_flow_run_ids:
                return
            flow_run = await self._client.read_flow_run(flow_run)
        else:
            if flow_run.id in self._cancelling_flow_run_ids:
                return

        self._cancelling_flow_run_ids.add(flow_run.id)

        # Check ProcessManager first (ScheduledRunPoller path), then fall back
        # to the facade's _flow_run_process_map (execute_flow_run path).
        process_handle = self._process_manager.get(flow_run.id)
        if process_handle and process_handle.pid:
            # Process tracked by ProcessManager -- delegate full sequence
            try:
                await self._cancellation_manager.cancel(flow_run, state_msg)
            except Exception:
                raise
            finally:
                self._cancelling_flow_run_ids.discard(flow_run.id)
            return

        # Facade's own process map (execute_flow_run / execute_bundle path)
        process_map_entry = self._flow_run_process_map.get(flow_run.id)
        pid = process_map_entry.get("pid") if process_map_entry else None
        if not pid:
            self._cancelling_flow_run_ids.discard(flow_run.id)
            return

        run_logger = self._get_flow_run_logger(flow_run)
        # Legacy execute_flow_run path: these runs are tracked in the facade
        # map instead of ProcessManager, so they do not go through
        # CancellationManager.cancel(). Seed cancel intent here too so the
        # child engine observes "cancel" before any real OS kill signal. On
        # POSIX, an ack only means the intent is recorded and the SIGTERM
        # bridge is armed, so the real runner kill still needs to happen
        # immediately. On Windows, an ack means the child has queued its
        # local `_thread.interrupt_main(SIGTERM)`, so it gets a bounded grace
        # period to self-exit before falling back to the legacy kill path.
        acked = False
        grace_seconds = 30.0
        try:
            acked = await self._control_channel.signal(flow_run.id, "cancel")
            if not acked:
                self._logger.debug(
                    "Cancel intent for flow run '%s' was not acked on the"
                    " control channel; proceeding with forced kill.",
                    flow_run.id,
                )
        except Exception:
            self._logger.exception(
                "Failed to deliver cancel intent for flow run '%s' on the"
                " control channel; proceeding with forced kill.",
                flow_run.id,
            )
        try:
            exited_after_ack = False
            remaining_grace = grace_seconds
            if acked and _is_windows_platform():
                wait_started = time.monotonic()
                exited_after_ack = await self._wait_for_process_exit(
                    flow_run.id, pid, grace_seconds=grace_seconds
                )
                if exited_after_ack:
                    should_skip = await should_skip_cancel_after_acked_process_exit(
                        flow_run=flow_run,
                        client=self._client,
                        logger=self._logger,
                    )
                    if should_skip:
                        return
                remaining_grace = max(
                    0.0, grace_seconds - (time.monotonic() - wait_started)
                )
                if not exited_after_ack:
                    self._logger.debug(
                        "Flow run '%s' did not exit within the graceful"
                        " cancellation window after ack; proceeding with"
                        " forced kill.",
                        flow_run.id,
                    )
            if not exited_after_ack:
                await self._kill_process(pid, grace_seconds=remaining_grace)
        except RuntimeError as exc:
            if acked and self._is_process_not_found_runtime_error(exc):
                should_skip = await should_skip_cancel_after_acked_process_exit(
                    flow_run=flow_run,
                    client=self._client,
                    logger=self._logger,
                )
                if should_skip:
                    return
            self._logger.warning(f"{exc} Marking flow run as cancelled.")
            if flow_run.state:
                await self._run_on_cancellation_hooks(flow_run, flow_run.state)
            await self._mark_flow_run_as_cancelled(flow_run)
        except Exception:
            run_logger.exception(
                "Encountered exception while killing process for flow run "
                f"'{flow_run.id}'. Flow run may not be cancelled."
            )
            self._cancelling_flow_run_ids.discard(flow_run.id)
            raise
        else:
            if flow_run.state:
                await self._run_on_cancellation_hooks(flow_run, flow_run.state)
            cancelled = await self._mark_flow_run_as_cancelled(
                flow_run,
                state_updates={
                    "message": state_msg or "Flow run was cancelled successfully."
                },
            )

            if cancelled:
                flow, deployment = await self._get_flow_and_deployment(flow_run)
                await self._emit_flow_run_cancelled_event(
                    flow_run=flow_run, flow=flow, deployment=deployment
                )
                run_logger.info(f"Cancelled flow run '{flow_run.name}'!")

    async def _get_flow_and_deployment(
        self, flow_run: "FlowRun"
    ) -> tuple[Optional["APIFlow"], Optional["DeploymentResponse"]]:
        return await self._event_emitter.get_flow_and_deployment(flow_run)

    async def _emit_flow_run_cancelled_event(
        self,
        flow_run: "FlowRun",
        flow: "Optional[APIFlow]",
        deployment: "Optional[DeploymentResponse]",
    ):
        await self._event_emitter.emit_flow_run_cancelled(flow_run, flow, deployment)

    @staticmethod
    def _is_process_not_found_runtime_error(exc: RuntimeError) -> bool:
        return "not found" in str(exc).lower()

    def has_slots_available(self) -> bool:
        """
        Determine if the flow run limit has been reached.

        Returns:
            - bool: True if the limit has not been reached, False otherwise.
        """
        return self._limit_manager.has_slots_available()

    def _acquire_limit_slot(self, flow_run_id: UUID) -> bool:
        """
        Enforces flow run limit set on runner.

        Returns:
            - bool: True if a slot was acquired, False otherwise.
        """
        result = self._limit_manager.acquire_for_flow_run(flow_run_id)
        if result:
            self._logger.debug("Limit slot acquired for flow run '%s'", flow_run_id)
        elif self._limiter and self._limiter.available_tokens == 0:
            self._logger.debug(
                f"Flow run limit reached; {self._limiter.borrowed_tokens} flow runs"
                " in progress. You can control this limit by adjusting the "
                "PREFECT_RUNNER_PROCESS_LIMIT setting."
            )
        else:
            self._logger.warning(
                f"Duplicate submission of flow run '{flow_run_id}' detected. Runner"
                " will not re-submit flow run."
            )
        return result

    def _release_limit_slot(self, flow_run_id: UUID) -> None:
        """
        Frees up a slot taken by the given flow run id.
        """
        self._limit_manager.release_for_flow_run(flow_run_id)
        self._logger.debug("Limit slot released for flow run '%s'", flow_run_id)

    async def _submit_run_and_capture_errors(
        self,
        flow_run: "FlowRun",
        task_status: anyio.abc.TaskStatus[
            anyio.abc.Process | multiprocessing.context.SpawnProcess | Exception
        ],
        entrypoint: str | None = None,
        command: str | None = None,
        cwd: Path | str | None = None,
        env: dict[str, str | None] | None = None,
        stream_output: bool = True,
    ) -> Union[Optional[int], Exception]:
        run_logger = self._get_flow_run_logger(flow_run)

        try:
            exit_code = await self._run_process(
                flow_run=flow_run,
                task_status=task_status,
                entrypoint=entrypoint,
                command=command,
                cwd=cwd,
                env=env,
                stream_output=stream_output,
            )
            flow_run_logger = self._get_flow_run_logger(flow_run)
            if exit_code:
                info = get_infrastructure_exit_info(exit_code)
                flow_run_logger.log(
                    info.log_level,
                    f"Process for flow run {flow_run.name!r} exited with status code:"
                    f" {exit_code}; {info.explanation}",
                )
                if info.resolution:
                    flow_run_logger.info(info.resolution)
            else:
                flow_run_logger.info(
                    f"Process for flow run {flow_run.name!r} exited cleanly."
                )
        except Exception as exc:
            if not task_status._future.done():  # type: ignore
                # This flow run was being submitted and did not start successfully
                run_logger.exception(
                    f"Failed to start process for flow run '{flow_run.id}'."
                )
                # Mark the task as started to prevent runner crash
                task_status.started(exc)
                message = f"Flow run process could not be started:\n{exc!r}"
                await self._propose_crashed_state(flow_run, message)
            else:
                run_logger.exception(
                    f"An error occurred while monitoring flow run '{flow_run.id}'. "
                    "The flow run will not be marked as failed, but an issue may have "
                    "occurred."
                )
            return exc
        finally:
            self._release_limit_slot(flow_run.id)

            await self._remove_flow_run_process_map_entry(flow_run.id)

        if exit_code != 0 and not self._rescheduling:
            await self._propose_crashed_state(
                flow_run,
                f"Flow run process exited with non-zero status code {exit_code}.",
            )

        try:
            api_flow_run = await self._client.read_flow_run(flow_run_id=flow_run.id)
            terminal_state = api_flow_run.state
            if terminal_state and terminal_state.is_crashed():
                await self._run_on_crashed_hooks(
                    flow_run=flow_run, state=terminal_state
                )
        except ObjectNotFound:
            # Flow run was deleted - log it but don't crash the runner
            run_logger = self._get_flow_run_logger(flow_run)
            run_logger.debug(
                f"Flow run '{flow_run.id}' was deleted before final state could be checked"
            )

        return exit_code

    async def _propose_pending_state(self, flow_run: "FlowRun") -> bool:
        return await self._state_proposer.propose_pending(flow_run)

    async def _propose_failed_state(self, flow_run: "FlowRun", exc: Exception) -> None:
        await self._state_proposer.propose_failed(flow_run, exc)

    async def _propose_crashed_state(
        self, flow_run: "FlowRun", message: str
    ) -> State[Any] | None:
        return await self._state_proposer.propose_crashed(flow_run, message)

    async def _handle_cancellation_observer_failure(self) -> None:
        """Handle failure of the cancellation observer.

        This is called when both the websocket and polling mechanisms for detecting
        cancellation events have failed. Without cancellation observing, flow runs
        cannot be cancelled and may run indefinitely.

        Behavior depends on the `PREFECT_RUNNER_CRASH_ON_CANCELLATION_FAILURE` setting:
        - When enabled: kills all in-flight flow run processes, which triggers crash
          handling when the processes terminate, and stops the runner
        - When disabled (default): logs an error but allows execution to continue
        """
        will_crash = get_current_settings().runner.crash_on_cancellation_failure
        crash_message = (
            "Cancellation observing failed - both websocket and polling mechanisms "
            "are unavailable. Killing flow run process to prevent indefinite execution."
        )
        continue_message = (
            "Cancellation observing failed - both websocket and polling mechanisms "
            "are unavailable. Flow run will continue executing but cannot be "
            "cancelled. Set PREFECT_RUNNER_CRASH_ON_CANCELLATION_FAILURE=true to "
            "crash flow runs and shut down the runner when this occurs."
        )

        if will_crash:
            self.stopping = True

        # Copy to list to avoid dictionary size changing during iteration
        process_entries = list(self._flow_run_process_map.items())
        for flow_run_id, process_entry in process_entries:
            flow_run = process_entry["flow_run"]
            run_logger = self._get_flow_run_logger(flow_run)
            if will_crash:
                run_logger.error(crash_message)
                pid = process_entry.get("pid")
                if pid:
                    try:
                        await self._kill_process(pid)
                    except Exception:
                        run_logger.exception(
                            f"Failed to kill process {pid} for flow run '{flow_run.id}'"
                        )
            else:
                run_logger.warning(continue_message)

    async def _mark_flow_run_as_cancelled(
        self, flow_run: "FlowRun", state_updates: Optional[dict[str, Any]] = None
    ) -> bool:
        return await finalize_cancelled_state(
            flow_run=flow_run,
            state_proposer=self._state_proposer,
            client=self._client,
            logger=self._logger,
            state_updates=state_updates,
        )

    async def _run_on_cancellation_hooks(
        self,
        flow_run: "FlowRun",
        state: State,
    ) -> None:
        """
        Run the hooks for a flow.
        """
        run_logger = self._get_flow_run_logger(flow_run)
        if state.is_cancelling():
            try:
                if flow_run.id in self._flow_run_bundle_map:
                    flow = extract_flow_from_bundle(
                        self._flow_run_bundle_map[flow_run.id]
                    )
                elif flow_run.deployment_id and self._deployment_registry.get_flow(
                    flow_run.deployment_id
                ):
                    flow = self._deployment_registry.get_flow(flow_run.deployment_id)
                else:
                    run_logger.info("Loading flow to check for on_cancellation hooks")
                    flow = await load_flow_from_flow_run(
                        flow_run, storage_base_path=str(self._tmp_dir)
                    )
                hooks = flow.on_cancellation_hooks or []

                await _run_hooks(hooks, flow_run, flow, state)
            except Exception:
                run_logger.warning(
                    f"Runner failed to retrieve flow to execute on_cancellation hooks for flow run {flow_run.id!r}.",
                    exc_info=True,
                )

    async def _run_on_crashed_hooks(
        self,
        flow_run: "FlowRun",
        state: State,
    ) -> None:
        """
        Run the hooks for a flow.
        """
        run_logger = self._get_flow_run_logger(flow_run)
        if state.is_crashed():
            try:
                if flow_run.id in self._flow_run_bundle_map:
                    flow = extract_flow_from_bundle(
                        self._flow_run_bundle_map[flow_run.id]
                    )
                elif flow_run.deployment_id and self._deployment_registry.get_flow(
                    flow_run.deployment_id
                ):
                    flow = self._deployment_registry.get_flow(flow_run.deployment_id)
                else:
                    run_logger.info("Loading flow to check for on_crashed hooks")
                    flow = await load_flow_from_flow_run(
                        flow_run, storage_base_path=str(self._tmp_dir)
                    )
                hooks = flow.on_crashed_hooks or []

                await _run_hooks(hooks, flow_run, flow, state)
            except Exception:
                run_logger.warning(
                    f"Runner failed to retrieve flow to execute on_crashed hooks for flow run {flow_run.id!r}.",
                    exc_info=True,
                )

    async def __aenter__(self) -> Self:
        """Dependency order (LIFO teardown is exact reverse):

        1. client          — exits last (needed by all services)
        2. process_manager — exits 5th (kills survivors after runs complete)
        3. limit_manager   — exits 4th (release tokens after runs complete)
        4. event_emitter   — exits 3rd (flush events before client closes)
        5. runs_task_group — exits 2nd (wait for in-flight runs)
        6. FlowRunCancellingObserver — exits first
        """
        self._logger.debug("Starting runner...")
        self._tmp_dir.mkdir(parents=True, exist_ok=True)
        if not self._loop:
            self._loop = asyncio.get_event_loop()

        self._client = get_client()

        # Step 1: client
        try:
            await self._exit_stack.enter_async_context(self._client)
        except Exception as err:
            raise RuntimeError(f"Runner failed to start: client \u2014 {err}") from err

        # Instantiate the observer early so we can bind its methods as
        # callbacks to ProcessManager.  The observer OBJECT is created here
        # but its CONTEXT MANAGER is entered last (step 6) because it needs
        # runs_task_group.
        self._cancelling_observer = FlowRunCancellingObserver(
            on_cancelling=lambda flow_run_id: self._runs_task_group.start_soon(
                self._cancel_run, flow_run_id
            ),
            on_failure=lambda _: self._runs_task_group.start_soon(
                self._handle_cancellation_observer_failure
            ),
            polling_interval=self.query_seconds,
        )

        # Define async wrapper callbacks for observer's sync methods
        async def _on_process_add(flow_run_id: UUID) -> None:
            self._cancelling_observer.add_in_flight_flow_run_id(flow_run_id)

        async def _on_process_remove(flow_run_id: UUID) -> None:
            self._cancelling_observer.remove_in_flight_flow_run_id(flow_run_id)
            self._control_channel.unregister(flow_run_id)

        # Reconstruct ProcessManager with observer callbacks (replaces the
        # callback-less placeholder from __init__)
        self._process_manager = ProcessManager(
            on_add=_on_process_add,
            on_remove=_on_process_remove,
        )

        # Steps 2-3: process_manager, limit_manager
        for _svc_name, _svc in [
            ("process_manager", self._process_manager),
            ("limit_manager", self._limit_manager),
        ]:
            try:
                await self._exit_stack.enter_async_context(_svc)
            except Exception as err:
                raise RuntimeError(
                    f"Runner failed to start: {_svc_name} \u2014 {err}"
                ) from err

        # Step 4: Construct client-dependent services after client is started

        # Build a storage-aware flow resolver that mirrors the pre-refactor
        # 3-level fallback: bundle map → deployment flow map →
        # load_flow_from_flow_run(storage_base_path=...).
        async def _resolve_flow_for_hooks(flow_run: "FlowRun") -> Flow:
            if flow_run.id in self._flow_run_bundle_map:
                return extract_flow_from_bundle(self._flow_run_bundle_map[flow_run.id])
            if flow_run.deployment_id and self._deployment_registry.get_flow(
                flow_run.deployment_id
            ):
                return self._deployment_registry.get_flow(flow_run.deployment_id)
            return await load_flow_from_flow_run(
                self._client, flow_run, storage_base_path=str(self._tmp_dir)
            )

        self._hook_runner = HookRunner(resolve_flow=_resolve_flow_for_hooks)
        self._state_proposer = StateProposer(client=self._client)
        self._event_emitter = EventEmitter(
            runner_name=self.name,
            client=self._client,
            get_events_client=lambda: get_events_client(checkpoint_every=1),
        )
        try:
            await self._exit_stack.enter_async_context(self._event_emitter)
        except Exception as err:
            raise RuntimeError(
                f"Runner failed to start: event_emitter \u2014 {err}"
            ) from err

        # Control channel: TCP loopback listener used to deliver control
        # intent (cancel today; suspend in a follow-up) into child
        # subprocesses before the runner kills them. Must be bound before
        # any starter spawns a child so the port is available for the child
        # env injection.
        try:
            await self._exit_stack.enter_async_context(self._control_channel)
        except Exception as err:
            raise RuntimeError(
                f"Runner failed to start: control_channel \u2014 {err}"
            ) from err

        self._cancellation_manager = CancellationManager(
            process_manager=self._process_manager,
            hook_runner=self._hook_runner,
            state_proposer=self._state_proposer,
            event_emitter=self._event_emitter,
            client=self._client,
            control_channel=self._control_channel,
        )

        # Step 5: runs_task_group
        self._runs_task_group = anyio.create_task_group()
        try:
            await self._exit_stack.enter_async_context(self._runs_task_group)
        except Exception as err:
            raise RuntimeError(
                f"Runner failed to start: runs_task_group \u2014 {err}"
            ) from err

        # Build resolve_starter factory closing over _deployment_registry
        def _resolve_starter(flow_run: "FlowRun") -> ProcessStarter:
            # If we have an in-memory flow for this deployment (add_flow path),
            # run it directly in a subprocess — no need to spawn
            # `python -m prefect.engine` to re-import the code.
            if flow_run.deployment_id is not None:
                flow = self._deployment_registry.get_flow(flow_run.deployment_id)
                if flow is not None:
                    return DirectSubprocessStarter(
                        flow=flow,
                        heartbeat_seconds=self._heartbeat_seconds,
                        control_channel=self._control_channel,
                    )
            storage = self._deployment_registry.get_storage(flow_run.deployment_id)
            return EngineCommandStarter(
                tmp_dir=self._tmp_dir,
                storage=storage,
                heartbeat_seconds=self._heartbeat_seconds,
                control_channel=self._control_channel,
            )

        self._scheduled_run_poller = ScheduledRunPoller(
            query_seconds=self.query_seconds,
            prefetch_seconds=self._prefetch_seconds,
            client=self._client,
            limit_manager=self._limit_manager,
            deployment_registry=self._deployment_registry,
            resolve_starter=_resolve_starter,
            runs_task_group=self._runs_task_group,
            storage_objs=self._storage_objs,
            process_manager=self._process_manager,
            state_proposer=self._state_proposer,
            hook_runner=self._hook_runner,
            cancellation_manager=self._cancellation_manager,
        )

        # Step 6: Enter observer context manager last
        self._cancelling_observer = await self._exit_stack.enter_async_context(
            self._cancelling_observer
        )

        if not hasattr(self, "_loops_task_group") or not self._loops_task_group:
            self._loops_task_group: anyio.abc.TaskGroup = anyio.create_task_group()

        self.started = True
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        self._logger.debug("Stopping runner...")
        if self.pause_on_shutdown:
            await self._pause_schedules()
        self.started = False

        for scope in self._scheduled_task_scopes:
            scope.cancel()

        await self._exit_stack.__aexit__(*exc_info)

        # Be tolerant to already-removed temp directories
        shutil.rmtree(str(self._tmp_dir), ignore_errors=True)
        if hasattr(self, "_runs_task_group"):
            del self._runs_task_group
        if hasattr(self, "_loops_task_group"):
            del self._loops_task_group

    def __repr__(self) -> str:
        return f"Runner(name={self.name!r})"


async def _run_hooks(
    hooks: list[FlowStateHook[Any, Any]],
    flow_run: "FlowRun",
    flow: "Flow[..., Any]",
    state: State,
):
    logger = flow_run_logger(flow_run, flow)
    for hook in hooks:
        hook_name = get_hook_name(hook)
        try:
            logger.info(
                f"Running hook {hook_name!r} in response to entering state"
                f" {state.name!r}"
            )
            if is_async_fn(hook):
                await hook(flow=flow, flow_run=flow_run, state=state)
            else:
                await from_async.call_in_new_thread(
                    create_call(hook, flow=flow, flow_run=flow_run, state=state)
                )
        except Exception:
            logger.error(
                f"An error was encountered while running hook {hook_name!r}",
                exc_info=True,
            )
        else:
            logger.info(f"Hook {hook_name!r} finished running successfully")


# ---------------------------------------------------------------------------
# Module-level re-exports
# The names below are imported at the top of this file and used here.
# They MUST remain as module-level attributes so that tests can patch them:
#   monkeypatch.setattr(prefect.runner.runner, "run_process", mock)
#   patch("prefect.runner.runner.load_flow_from_flow_run", ...)
#   mock.patch("prefect.runner.runner.threading.Thread")
# Do NOT remove these imports or relocate them inside functions.
# ---------------------------------------------------------------------------
# run_process           (from prefect.utilities.processutils -- imported above)
# get_events_client     (from prefect.events.clients -- imported above)
# propose_state         (from prefect.utilities.engine -- imported above)
# load_flow_from_flow_run (from prefect.flows -- imported above)
# _run_hooks            (defined above in this module)
# threading             (stdlib -- import threading must stay at module level)
