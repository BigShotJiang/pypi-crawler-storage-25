# CHG-2114: AF Search Command

**Applies to:** FXA project
**Last updated:** 2026-03-19
**Last reviewed:** 2026-03-19
**Status:** Proposed
**Date:** 2026-03-19
**Requested by:** —
**Priority:** Medium
**Change Type:** Normal

---

## What

<what is being changed>

## Why

<why this change is needed>

## Impact Analysis

- **Systems affected:** <list>
- **Rollback plan:** <how to undo>

## Implementation Plan

1. Step 1

---

## Change History

| Date | Change | By |
|------|--------|----|
| 2026-03-19 | Initial version | — |
