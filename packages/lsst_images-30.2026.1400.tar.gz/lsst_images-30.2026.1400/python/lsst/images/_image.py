# This file is part of lsst-images.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (https://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# Use of this source code is governed by a 3-clause BSD-style
# license that can be found in the LICENSE file.

from __future__ import annotations

__all__ = ("Image", "ImageSerializationModel")

from collections.abc import Callable, Sequence
from contextlib import ExitStack
from types import EllipsisType
from typing import Any, ClassVar, final

import astropy.io.fits
import astropy.units
import astropy.wcs
import numpy as np
import numpy.typing as npt
import pydantic
from astro_metadata_translator import ObservationInfo

from lsst.resources import ResourcePath, ResourcePathExpression

from . import fits
from ._generalized_image import GeneralizedImage
from ._geom import YX, Box
from ._transforms import Frame, Projection, ProjectionSerializationModel
from .serialization import (
    ArchiveTree,
    ArrayReferenceModel,
    ArrayReferenceQuantityModel,
    InputArchive,
    MetadataValue,
    OutputArchive,
    no_header_updates,
)
from .utils import is_none


@final
class Image(GeneralizedImage):
    """A 2-d array that may be augmented with units and a nonzero origin.

    Parameters
    ----------
    array_or_fill
        Array or fill value for the image.  If a fill value, ``bbox`` or
        ``shape`` must be provided.
    bbox
        Bounding box for the image.
    start
        Logical coordinates of the first pixel in the array, ordered ``y``,
        ``x`` (unless an `XY` instance is passed).  Ignored if
        ``bbox`` is provided.  Defaults to zeros.
    shape
        Leading dimensions of the array, ordered ``y``, ``x`` (unless an `XY`
        instance is passed).   Only needed if ``array_or_fill`` is not an
        array and ``bbox`` is not provided.  Like the bbox, this does not
        include the last dimension of the array.
    dtype
        Pixel data type override.
    unit
        Units for the image's pixel values.
    projection
        Projection that maps the pixel grid to the sky.
    obs_info
        General information about the associated observation in standardized
        form.
    metadata
        Arbitrary flexible metadata to associate with the image.

    Notes
    -----
    Indexing the `array` attribute of an `Image` does not take into account its
    ``start`` offset, but accessing a subimage by indexing an `Image` with a
    `Box` does, and the `bbox` of the subimage is set to match its location
    within the original image.

    Indexed assignment to a subimage requires consistency between the
    coordinate systems and units of both operands, but it will automatically
    select a subimage of the right-hand side and convert compatible units when
    possible.  In other words::

        a[box] = b

    is a shortcut for

        a[box].quantity = b[box].quantity

    An ellipsis (``...``) can be used instead of a `Box` to assign to the full
    image.
    """

    def __init__(
        self,
        array_or_fill: np.ndarray | int | float = 0,
        /,
        *,
        bbox: Box | None = None,
        start: Sequence[int] | None = None,
        shape: Sequence[int] | None = None,
        dtype: npt.DTypeLike | None = None,
        unit: astropy.units.UnitBase | None = None,
        projection: Projection[Any] | None = None,
        obs_info: ObservationInfo | None = None,
        metadata: dict[str, MetadataValue] | None = None,
    ):
        super().__init__(metadata)
        if isinstance(array_or_fill, np.ndarray):
            if dtype is not None:
                array = np.array(array_or_fill, dtype=dtype)
            else:
                array = array_or_fill
            if bbox is None:
                bbox = Box.from_shape(array.shape, start=start)
            elif bbox.shape != array.shape:
                raise ValueError(
                    f"Explicit bbox shape {bbox.shape} does not match array with shape {array.shape}."
                )
            if shape is not None and shape != array.shape:
                raise ValueError(f"Explicit shape {shape} does not match array with shape {array.shape}.")
        else:
            if bbox is None:
                if shape is None:
                    raise TypeError("No bbox, shape, or array provided.")
                bbox = Box.from_shape(shape, start=start)
            elif shape is not None and shape != bbox.shape:
                raise ValueError(f"Explicit shape {shape} does not match bbox shape {bbox.shape}.")
            array = np.full(bbox.shape, array_or_fill, dtype=dtype)
        self._array: np.ndarray = array
        self._bbox: Box = bbox
        self._unit = unit
        self._projection = projection
        self._obs_info = obs_info

    @property
    def array(self) -> np.ndarray:
        """The low-level array (`numpy.ndarray`).

        Assigning to this attribute modifies the existing array in place; the
        bounding box and underlying data pointer are never changed.
        """
        return self._array

    @array.setter
    def array(self, value: np.ndarray | int | float) -> None:
        self._array[...] = value

    @property
    def quantity(self) -> astropy.units.Quantity:
        """The low-level array with units (`astropy.units.Quantity`).

        Assigning to this attribute modifies the existing array in place; the
        bounding box and underlying data pointer are never changed.
        """
        return astropy.units.Quantity(self._array, self._unit, copy=False)

    @quantity.setter
    def quantity(self, value: astropy.units.Quantity) -> None:
        self.quantity[...] = value

    @property
    def bbox(self) -> Box:
        """Bounding box for the image (`Box`)."""
        return self._bbox

    @property
    def unit(self) -> astropy.units.UnitBase | None:
        """Units for the image's pixel values (`astropy.units.Unit` or
        `None`).
        """
        return self._unit

    @property
    def projection(self) -> Projection[Any] | None:
        """The projection that maps this image's pixel grid to the sky
        (`Projection` | `None`).

        Notes
        -----
        The pixel coordinates used by this projection account for the bounding
        box ``start``; they are not just array indices.
        """
        return self._projection

    @property
    def obs_info(self) -> ObservationInfo | None:
        """General information about the associated observation in standard
        form. (`~astro_metadata_translator.ObservationInfo` | `None`).
        """
        return self._obs_info

    def __getitem__(self, bbox: Box | EllipsisType) -> Image:
        if bbox is ...:
            return self
        super().__getitem__(bbox)
        indices = bbox.slice_within(self._bbox)
        return self._transfer_metadata(
            Image(
                self._array[indices],
                bbox=bbox,
                unit=self._unit,
                projection=self._projection,
                obs_info=self._obs_info,
            ),
            bbox=bbox,
        )

    def __setitem__(self, bbox: Box | EllipsisType, value: Image) -> None:
        self[bbox].quantity[...] = value.quantity

    def __str__(self) -> str:
        return f"Image({self.bbox!s}, {self.array.dtype.type.__name__})"

    def __repr__(self) -> str:
        return f"Image(..., bbox={self.bbox!r}, dtype={self.array.dtype!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Image):
            return NotImplemented
        return (
            self._bbox == other._bbox
            and self._unit == other._unit
            and np.array_equal(self._array, other._array, equal_nan=True)
        )

    def copy(self) -> Image:
        return self._transfer_metadata(
            Image(
                self._array.copy(),
                bbox=self._bbox,
                unit=self._unit,
                projection=self._projection,
                obs_info=self._obs_info,
            ),
            copy=True,
        )

    def view(
        self,
        *,
        unit: astropy.units.UnitBase | None | EllipsisType = ...,
        projection: Projection | None | EllipsisType = ...,
        start: Sequence[int] | EllipsisType = ...,
        obs_info: ObservationInfo | None | EllipsisType = ...,
    ) -> Image:
        """Make a view of the image, with optional updates."""
        if unit is ...:
            unit = self._unit
        if projection is ...:
            projection = self._projection
        if start is ...:
            start = self._bbox.start
        if obs_info is ...:
            obs_info = self._obs_info
        return self._transfer_metadata(
            Image(self._array, start=start, unit=unit, projection=projection, obs_info=obs_info)
        )

    def serialize[P: pydantic.BaseModel](
        self,
        archive: OutputArchive[P],
        *,
        update_header: Callable[[astropy.io.fits.Header], None] = no_header_updates,
        save_projection: bool = True,
        add_offset_wcs: str | None = "A",
    ) -> ImageSerializationModel[P]:
        """Serialize the image to an output archive.

        Parameters
        ----------
        archive
            Archive to write to.
        update_header
            A callback that will be given the FITS header for the HDU
            containing this image in order to add keys to it.  This callback
            may be provided but will not be called if the output format is not
            FITS.
        save_projection
            If `True`, save the `Projection` attached to the image, if there
            is one.
        add_offset_wcs
            A FITS WCS single-character suffix to use when adding a linear
            WCS that maps the FITS array to the logical pixel coordinates
            defined by ``bbox.start``.  Set to `None` to not write this WCS.
        """
        if save_projection and add_offset_wcs == "":
            raise TypeError("save_projection=True is not compatible with add_offset_wcs=''.")

        def _update_header(header: astropy.io.fits.Header) -> None:
            update_header(header)
            if self.unit is not None:
                header["BUNIT"] = self.unit.to_string(format="fits")
            if self.projection is not None:
                if self.fits_wcs:
                    header.update(self.fits_wcs.to_header(relax=True))
            if add_offset_wcs is not None:
                fits.add_offset_wcs(header, x=self.bbox.x.start, y=self.bbox.y.start, key=add_offset_wcs)

        ref = archive.add_array(self.array, update_header=_update_header)
        serialized_projection: ProjectionSerializationModel[P] | None = None
        if save_projection and self.projection is not None:
            serialized_projection = archive.serialize_direct("projection", self.projection.serialize)
        if self.unit is None:
            return ImageSerializationModel.model_construct(
                data=ref,
                start=list(self.bbox.start),
                projection=serialized_projection,
                obs_info=self._obs_info,
                metadata=self.metadata,
            )
        else:
            return ImageSerializationModel.model_construct(
                data=ArrayReferenceQuantityModel.model_construct(value=ref, unit=self.unit),
                start=list(self.bbox.start),
                projection=serialized_projection,
                obs_info=self._obs_info,
                metadata=self.metadata,
            )

    @staticmethod
    def deserialize(
        model: ImageSerializationModel[Any],
        archive: InputArchive[Any],
        *,
        bbox: Box | None = None,
        strip_header: Callable[[astropy.io.fits.Header], None] = no_header_updates,
    ) -> Image:
        """Deserialize an image from an input archive.

        Parameters
        ----------
        model
            A Pydantic model representation of the image, holding references
            to data stored in the archive.
        archive
            Archive to read from.
        bbox
            Bounding box of a subimage to read instead.
        strip_header
            A callable that strips out any FITS header cards added by the
            ``update_header`` argument in the corresponding call to
            `serialize`.
        """
        ref: ArrayReferenceModel
        unit: astropy.units.UnitBase | None = None
        if isinstance(model.data, ArrayReferenceQuantityModel):
            ref = model.data.value
            unit = model.data.unit
        else:
            ref = model.data

        def _strip_header(header: astropy.io.fits.Header) -> None:
            if unit is not None:
                header.pop("BUNIT", None)
            fits.strip_wcs_cards(header)
            strip_header(header)

        slices = bbox.slice_within(model.bbox) if bbox is not None else ...
        array = archive.get_array(ref, strip_header=_strip_header, slices=slices)
        projection = (
            Projection.deserialize(model.projection, archive) if model.projection is not None else None
        )
        return Image(
            array,
            start=model.start if bbox is None else bbox.start,
            unit=unit,
            projection=projection,
            obs_info=model.obs_info,
        )._finish_deserialize(model)

    @staticmethod
    def _get_archive_tree_type[P: pydantic.BaseModel](
        pointer_type: type[P],
    ) -> type[ImageSerializationModel[P]]:
        """Return the serialization model type for this object for an archive
        type that uses the given pointer type.
        """
        return ImageSerializationModel[pointer_type]  # type: ignore

    _archive_default_name: ClassVar[str] = "image"
    """The name this object should be serialized with when written as the
    top-level object.
    """

    def write_fits(
        self,
        filename: str,
        *,
        compression: fits.FitsCompressionOptions | None = fits.FitsCompressionOptions.DEFAULT,
        compression_seed: int | None = None,
    ) -> None:
        """Write the image to a FITS file.

        Parameters
        ----------
        filename
            Name of the file to write to.  Must be a local file.
        compression
            Compression options.
        compression_seed
            A FITS tile compression seed to use whenever the configured
            compression seed is `None` or (for backwards compatibility) ``0``.
        """
        compression_options = {}
        if compression is not fits.FitsCompressionOptions.DEFAULT:
            compression_options[self._archive_default_name] = compression
        fits.write(self, filename, compression_options, compression_seed=compression_seed)

    @staticmethod
    def read_fits(url: ResourcePathExpression, *, bbox: Box | None = None) -> Image:
        """Read an image from a FITS file.

        Parameters
        ----------
        url
            URL of the file to read; may be any type supported by
            `lsst.resources.ResourcePath`.
        bbox
            Bounding box of a subimage to read instead.
        """
        return fits.read(Image, url, bbox=bbox).deserialized

    @staticmethod
    def from_legacy(legacy: Any, unit: astropy.units.UnitBase | None = None) -> Image:
        """Convert from an `lsst.afw.image.Image` instance.

        Parameters
        ----------
        legacy
            An `lsst.afw.image.Image` instance that will share pixel data with
           the returned object.
        unit
            Units of the image.
        """
        return Image(legacy.array, start=(legacy.getY0(), legacy.getX0()), unit=unit)

    def to_legacy(self, *, copy: bool | None = None) -> Any:
        """Convert to an `lsst.afw.image.Image` instance.

        Parameters
        ----------
        copy
            If `True`, always copy the pixel data.  If `False`, return a view,
            and raise `TypeError` if the pixel data is read-only (this is not
            supported by afw).  If `None`, onyl if the pixel data is
            read-only.
        """
        import lsst.afw.image
        import lsst.geom

        array = self._array
        if copy:
            array = array.copy()
        elif not self._array.flags.writeable:
            if copy is None:
                array = array.copy()
            else:
                raise TypeError("Cannot create a legacy lsst.afw.image.Image view into a read-only array.")

        return lsst.afw.image.Image(
            array,
            deep=False,
            dtype=array.dtype.type,
            xy0=lsst.geom.Point2I(self._bbox.x.min, self._bbox.y.min),
        )

    @staticmethod
    def read_legacy(
        uri: ResourcePathExpression,
        *,
        preserve_quantization: bool = False,
        ext: str | int = 1,
        fits_wcs_frame: Frame | None = None,
    ) -> Image:
        """Read a FITS file written by `lsst.afw.image.Image.writeFits`.

        Parameters
        ----------
        uri
            URI or file name.
        preserve_quantization
            If `True`, ensure that writing the image back out again will
            exactly preserve quantization-compressed pixel values.  This causes
            the arrays to be marked as read-only and stores the original binary
            table data for those planes in memory. If the `Image` is copied,
            the precompressed pixel values are not transferred to the copy.
        ext
            Name or index of the FITS HDU to read.
        fits_wcs_frame
            If not `None` and the HDU containing the image has a FITS WCS,
            attach a `Projection` to the returned image by converting that
            WCS.
        """
        opaque_metadata = fits.FitsOpaqueMetadata()
        with ExitStack() as exit_stack:
            fs, fspath = ResourcePath(uri).to_fsspec()
            stream = exit_stack.enter_context(fs.open(fspath))
            hdu_list = exit_stack.enter_context(astropy.io.fits.open(stream))
            opaque_metadata.extract_legacy_primary_header(hdu_list[0].header)
            bintable_hdu: astropy.io.fits.BinTableHDU | None = None
            if preserve_quantization:
                bintable_stream = exit_stack.enter_context(fs.open(fspath))
                bintable_hdu_list = exit_stack.enter_context(
                    astropy.io.fits.open(bintable_stream, disable_image_compression=True)
                )
                bintable_hdu = bintable_hdu_list[ext]
            result = Image._read_legacy_hdu(
                hdu_list[ext], opaque_metadata, preserve_bintable=bintable_hdu, fits_wcs_frame=fits_wcs_frame
            )
            result._opaque_metadata = opaque_metadata
        return result

    @staticmethod
    def _read_legacy_hdu(
        hdu: astropy.io.fits.ImageHDU | astropy.io.fits.CompImageHDU,
        opaque_metadata: fits.FitsOpaqueMetadata,
        *,
        preserve_bintable: astropy.io.fits.BinTableHDU | None,
        fits_wcs_frame: Frame | None = None,
    ) -> Image:
        unit: astropy.units.UnitBase | None = None
        if (fits_unit := hdu.header.pop("BUNIT", None)) is not None:
            unit = astropy.units.Unit(fits_unit, format="fits")
        dx: int = hdu.header.pop("LTV1")
        dy: int = hdu.header.pop("LTV2")
        start = YX(y=-dy, x=-dx)
        read_only: bool = False
        if preserve_bintable is not None:
            opaque_metadata.precompressed[hdu.name] = fits.PrecompressedImage.from_bintable(preserve_bintable)
            read_only = True
        projection: Projection | None = None
        if fits_wcs_frame is not None:
            try:
                fits_wcs = astropy.wcs.WCS(hdu.header)
            except KeyError:
                pass
            else:
                projection = Projection.from_fits_wcs(
                    fits_wcs, pixel_frame=fits_wcs_frame, x0=start.x, y0=start.y
                )
        image = Image(hdu.data, start=start, unit=unit, projection=projection)
        if read_only:
            image._array.flags["WRITEABLE"] = False
        fits.strip_wcs_cards(hdu.header)
        hdu.header.strip()
        hdu.header.remove("EXTTYPE", ignore_missing=True)
        hdu.header.remove("INHERIT", ignore_missing=True)
        hdu.header.remove("UZSCALE", ignore_missing=True)
        opaque_metadata.add_header(hdu.header)
        return image


class ImageSerializationModel[P: pydantic.BaseModel](ArchiveTree):
    """Pydantic model used to represent the serialized form of an `.Image`."""

    data: ArrayReferenceQuantityModel | ArrayReferenceModel = pydantic.Field(
        description="Reference to pixel data."
    )
    start: list[int] = pydantic.Field(
        description="Coordinate of the first pixels in the array, ordered (y, x)."
    )
    projection: ProjectionSerializationModel[P] | None = pydantic.Field(
        default=None,
        exclude_if=is_none,
        description="Projection that maps the logical pixel grid onto the sky.",
    )
    obs_info: ObservationInfo | None = pydantic.Field(
        default=None,
        exclude_if=is_none,
        description="Standardized description of image metadata",
    )

    @property
    def bbox(self) -> Box:
        """The bounding box of the image."""
        if isinstance(self.data, ArrayReferenceQuantityModel):
            shape = self.data.value.shape
        else:
            shape = self.data.shape
        return Box.from_shape(shape, self.start)
