# YouTube Downloader UI

A local web UI for downloading YouTube videos. Paste a URL, pick a resolution, and download.

Built with Flask and yt-dlp.

## Install

```bash
uv pip install youtube-downloader-ui
```

## Usage

### Run directly (no install needed)

```bash
uvx youtube-downloader-ui
```

### Run after installing

```bash
youtube-downloader-ui
```

This starts a local server at `http://127.0.0.1:8008` and opens your browser automatically.

### Options

```
--port PORT          Port to serve on (default: 8008)
--output-dir DIR     Directory to save downloads (default: ~/Downloads/youtube-downloader-ui/)
--no-browser         Don't auto-open the browser
```

## How it works

1. Paste a YouTube URL into the input bar
2. Available resolutions and estimated file sizes are shown
3. Select a quality and click Download
4. Progress is displayed in real time
5. Downloaded files are saved to `~/Downloads/youtube-downloader-ui/`

## Requirements

- Python 3.10+
- ffmpeg is bundled automatically via `imageio-ffmpeg` — no manual install needed.
