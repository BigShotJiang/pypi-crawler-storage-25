const urlInput = document.getElementById("url-input");
const fetchBtn = document.getElementById("fetch-btn");
const spinner = document.getElementById("spinner");
const errorMsg = document.getElementById("error-msg");
const videoCard = document.getElementById("video-card");
const videoThumb = document.getElementById("video-thumb");
const videoTitle = document.getElementById("video-title");
const videoDuration = document.getElementById("video-duration");
const formatsSection = document.getElementById("formats-section");
const formatsList = document.getElementById("formats-list");
const downloadBtn = document.getElementById("download-btn");
const progressSection = document.getElementById("progress-section");
const progressBar = document.getElementById("progress-bar");
const progressPercent = document.getElementById("progress-percent");
const progressSpeed = document.getElementById("progress-speed");
const progressEta = document.getElementById("progress-eta");
const progressStatus = document.getElementById("progress-status");
const completeSection = document.getElementById("complete-section");
const completeFilename = document.getElementById("complete-filename");

let currentUrl = "";
let selectedFormatId = "";

// Auto-fetch on paste
urlInput.addEventListener("paste", () => {
    setTimeout(() => fetchInfo(), 100);
});

// Also fetch on Enter
urlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") fetchInfo();
});

function formatDuration(seconds) {
    if (!seconds) return "";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    return `${m}:${String(s).padStart(2, "0")}`;
}

function formatSize(bytes) {
    if (!bytes) return "Size unknown";
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function showError(msg) {
    errorMsg.textContent = msg;
    errorMsg.classList.remove("hidden");
}

function hideError() {
    errorMsg.classList.add("hidden");
}

function resetUI() {
    hideError();
    videoCard.classList.add("hidden");
    formatsSection.classList.add("hidden");
    progressSection.classList.add("hidden");
    completeSection.classList.add("hidden");
    formatsList.innerHTML = "";
    selectedFormatId = "";
    downloadBtn.disabled = true;
}

async function fetchInfo() {
    const url = urlInput.value.trim();
    if (!url) return;

    resetUI();
    currentUrl = url;
    spinner.classList.remove("hidden");
    fetchBtn.disabled = true;

    try {
        const resp = await fetch("/api/info", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url }),
        });
        const data = await resp.json();

        if (!resp.ok || data.error) {
            showError(data.error || "Failed to fetch video info");
            return;
        }

        // Show video card
        videoTitle.textContent = data.title;
        videoDuration.textContent = formatDuration(data.duration);
        if (data.thumbnail) {
            videoThumb.src = data.thumbnail;
            videoThumb.style.display = "";
        } else {
            videoThumb.style.display = "none";
        }
        videoCard.classList.remove("hidden");

        // Render formats
        if (data.formats.length === 0) {
            showError("No downloadable formats found");
            return;
        }

        data.formats.forEach((fmt, i) => {
            const div = document.createElement("div");
            div.className = "format-option";
            if (i === 0) div.classList.add("selected");

            const radio = document.createElement("input");
            radio.type = "radio";
            radio.name = "format";
            radio.value = fmt.format_id;
            if (i === 0) {
                radio.checked = true;
                selectedFormatId = fmt.format_id;
                downloadBtn.disabled = false;
            }

            const label = document.createElement("span");
            label.className = "format-label";
            label.textContent = fmt.label;

            const res = document.createElement("span");
            res.className = "format-res";
            res.textContent = `${fmt.ext.toUpperCase()} · ${fmt.resolution}`;

            const size = document.createElement("span");
            size.className = "format-size";
            size.textContent = formatSize(fmt.filesize_approx);

            div.appendChild(radio);
            div.appendChild(label);
            div.appendChild(res);
            div.appendChild(size);

            div.addEventListener("click", () => {
                document.querySelectorAll(".format-option").forEach(el => el.classList.remove("selected"));
                div.classList.add("selected");
                radio.checked = true;
                selectedFormatId = fmt.format_id;
                downloadBtn.disabled = false;
            });

            formatsList.appendChild(div);
        });

        formatsSection.classList.remove("hidden");
    } catch (err) {
        showError("Network error: " + err.message);
    } finally {
        spinner.classList.add("hidden");
        fetchBtn.disabled = false;
    }
}

async function startDownload() {
    if (!currentUrl || !selectedFormatId) return;

    downloadBtn.disabled = true;
    progressSection.classList.remove("hidden");
    completeSection.classList.add("hidden");
    progressBar.style.width = "0%";
    progressPercent.textContent = "0%";
    progressSpeed.textContent = "";
    progressEta.textContent = "";
    progressStatus.textContent = "Starting download...";

    try {
        const resp = await fetch("/api/download", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: currentUrl, format_id: selectedFormatId }),
        });
        const data = await resp.json();

        if (!resp.ok || data.error) {
            showError(data.error || "Failed to start download");
            progressSection.classList.add("hidden");
            downloadBtn.disabled = false;
            return;
        }

        // Connect to SSE for progress
        const evtSource = new EventSource(`/api/progress/${data.download_id}`);
        evtSource.onmessage = (e) => {
            const state = JSON.parse(e.data);

            if (state.error && state.status !== "error") {
                evtSource.close();
                showError(state.error);
                progressSection.classList.add("hidden");
                downloadBtn.disabled = false;
                return;
            }

            progressBar.style.width = state.percent + "%";
            progressPercent.textContent = state.percent + "%";
            progressSpeed.textContent = state.speed || "";
            progressEta.textContent = state.eta ? `ETA: ${state.eta}` : "";

            if (state.status === "downloading") {
                progressStatus.textContent = "Downloading...";
            } else if (state.status === "merging") {
                progressStatus.textContent = "Merging audio and video...";
            } else if (state.status === "finished") {
                evtSource.close();
                progressSection.classList.add("hidden");
                completeFilename.textContent = state.filename || "";
                completeSection.classList.remove("hidden");
                downloadBtn.disabled = false;
            } else if (state.status === "error") {
                evtSource.close();
                showError(state.error || "Download failed");
                progressSection.classList.add("hidden");
                downloadBtn.disabled = false;
            }
        };

        evtSource.onerror = () => {
            evtSource.close();
            progressStatus.textContent = "Connection lost";
            downloadBtn.disabled = false;
        };
    } catch (err) {
        showError("Network error: " + err.message);
        progressSection.classList.add("hidden");
        downloadBtn.disabled = false;
    }
}
