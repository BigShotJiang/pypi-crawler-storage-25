"""Flask application with API routes for the YouTube downloader."""

import json
import time
import threading
import uuid

from flask import Flask, Response, jsonify, render_template, request

from . import downloader

app = Flask(__name__)
app.config["OUTPUT_DIR"] = ""

# In-memory download state: {download_id: {status, percent, speed, eta, filename, error}}
downloads: dict[str, dict] = {}


@app.route("/")
def index():
    has_ffmpeg = downloader.check_ffmpeg()
    return render_template("index.html", has_ffmpeg=has_ffmpeg)


@app.route("/api/info", methods=["POST"])
def video_info():
    data = request.get_json()
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"error": "URL is required"}), 400

    try:
        info = downloader.extract_info(url)
        return jsonify(info)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/download", methods=["POST"])
def start_download():
    data = request.get_json()
    url = data.get("url", "").strip()
    format_id = data.get("format_id", "").strip()
    if not url or not format_id:
        return jsonify({"error": "url and format_id are required"}), 400

    download_id = uuid.uuid4().hex[:8]
    downloads[download_id] = {
        "status": "starting",
        "percent": 0,
        "speed": "",
        "eta": "",
        "filename": "",
        "error": "",
    }

    def run():
        def on_progress(state: dict):
            downloads[download_id].update(state)

        try:
            downloader.download(
                url, format_id, app.config["OUTPUT_DIR"], on_progress
            )
        except Exception as e:
            downloads[download_id].update({
                "status": "error",
                "error": str(e),
            })

    thread = threading.Thread(target=run, daemon=True)
    thread.start()

    return jsonify({"download_id": download_id})


@app.route("/api/progress/<download_id>")
def progress_stream(download_id):
    def generate():
        while True:
            state = downloads.get(download_id)
            if not state:
                yield f"data: {json.dumps({'error': 'not found'})}\n\n"
                break
            yield f"data: {json.dumps(state)}\n\n"
            if state["status"] in ("finished", "error"):
                break
            time.sleep(0.5)

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
