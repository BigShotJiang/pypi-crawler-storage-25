"""yt-dlp wrapper for video info extraction and downloading."""

import os
import shutil
from typing import Callable

import imageio_ffmpeg
import yt_dlp


def get_ffmpeg_path() -> str | None:
    """Return the path to ffmpeg, preferring system install, falling back to bundled."""
    system = shutil.which("ffmpeg")
    if system:
        return system
    try:
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def check_ffmpeg() -> bool:
    """Check if ffmpeg is available (system or bundled)."""
    return get_ffmpeg_path() is not None


def _estimate_filesize(fmt: dict, duration: float | None) -> int | None:
    """Estimate file size in bytes from format metadata."""
    if fmt.get("filesize"):
        return int(fmt["filesize"])
    if fmt.get("filesize_approx"):
        return int(fmt["filesize_approx"])
    tbr = fmt.get("tbr")
    if tbr and duration:
        return int(tbr * 1000 / 8 * duration)
    return None


def extract_info(url: str) -> dict:
    """Extract video metadata and available formats from a URL.

    Returns a dict with title, thumbnail, duration, and a list of
    download-ready format options (video+audio merged where needed).
    """
    ydl_opts = {"quiet": True, "no_warnings": True}
    ffmpeg = get_ffmpeg_path()
    if ffmpeg:
        ydl_opts["ffmpeg_location"] = os.path.dirname(ffmpeg)
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)

    if info.get("_type") == "playlist":
        entries = info.get("entries", [])
        if not entries:
            raise ValueError("Playlist is empty")
        info = entries[0]

    duration = info.get("duration")
    formats = info.get("formats", [])
    has_ffmpeg = check_ffmpeg()

    # Separate video-only and audio-only formats
    video_only = []
    audio_only = []
    combined = []

    for f in formats:
        vcodec = f.get("vcodec", "none")
        acodec = f.get("acodec", "none")
        has_video = vcodec != "none" and vcodec is not None
        has_audio = acodec != "none" and acodec is not None

        if has_video and has_audio:
            combined.append(f)
        elif has_video:
            video_only.append(f)
        elif has_audio:
            audio_only.append(f)

    # Find best audio stream for merging
    best_audio = None
    best_audio_size = 0
    if audio_only:
        # Prefer m4a/mp4 audio, then sort by bitrate
        audio_sorted = sorted(
            audio_only,
            key=lambda f: (
                f.get("ext") in ("m4a", "mp4"),
                f.get("abr") or f.get("tbr") or 0,
            ),
            reverse=True,
        )
        best_audio = audio_sorted[0]
        best_audio_size = _estimate_filesize(best_audio, duration) or 0

    result_formats = []
    seen_heights = set()

    if has_ffmpeg and best_audio:
        # Create merged entries: video-only + best audio
        for vf in sorted(
            video_only,
            key=lambda f: (f.get("height") or 0, f.get("fps") or 0),
            reverse=True,
        ):
            height = vf.get("height")
            if not height or height in seen_heights:
                continue
            seen_heights.add(height)

            video_size = _estimate_filesize(vf, duration) or 0
            total_size = (video_size + best_audio_size) if video_size else None

            fps = vf.get("fps") or 30
            label = f"{height}p"
            if fps > 30:
                label += f"{fps}"

            result_formats.append({
                "format_id": f"{vf['format_id']}+{best_audio['format_id']}",
                "label": label,
                "resolution": f"{vf.get('width', '?')}x{height}",
                "ext": "mp4",
                "filesize_approx": total_size,
                "height": height,
            })

    # Add combined (pre-merged) formats
    for f in sorted(
        combined,
        key=lambda f: (f.get("height") or 0, f.get("fps") or 0),
        reverse=True,
    ):
        height = f.get("height")
        if not height or height in seen_heights:
            continue
        seen_heights.add(height)

        fps = f.get("fps") or 30
        label = f"{height}p"
        if fps > 30:
            label += f"{fps}"

        result_formats.append({
            "format_id": f["format_id"],
            "label": label,
            "resolution": f"{f.get('width', '?')}x{height}",
            "ext": f.get("ext", "mp4"),
            "filesize_approx": _estimate_filesize(f, duration),
            "height": height,
        })

    # Sort by height descending
    result_formats.sort(key=lambda f: f.get("height", 0), reverse=True)

    return {
        "title": info.get("title", "Unknown"),
        "thumbnail": info.get("thumbnail"),
        "duration": duration,
        "webpage_url": info.get("webpage_url", url),
        "formats": result_formats,
        "has_ffmpeg": has_ffmpeg,
    }


def download(
    url: str,
    format_id: str,
    output_dir: str,
    on_progress: Callable[[dict], None],
) -> str:
    """Download a video with the given format, reporting progress via callback.

    Returns the final output filename.
    """
    os.makedirs(output_dir, exist_ok=True)
    final_filename = None

    def progress_hook(d: dict):
        nonlocal final_filename
        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            downloaded = d.get("downloaded_bytes", 0)
            percent = (downloaded / total * 100) if total else 0
            on_progress({
                "status": "downloading",
                "percent": round(percent, 1),
                "speed": d.get("_speed_str", ""),
                "eta": d.get("_eta_str", ""),
            })
        elif status == "finished":
            final_filename = d.get("filename")
            on_progress({
                "status": "merging",
                "percent": 100,
                "speed": "",
                "eta": "",
            })

    def postprocessor_hook(d: dict):
        if d.get("status") == "finished":
            nonlocal final_filename
            final_filename = d.get("info_dict", {}).get("filepath", final_filename)

    ydl_opts = {
        "format": format_id,
        "outtmpl": os.path.join(output_dir, "%(title)s [%(id)s].%(ext)s"),
        "merge_output_format": "mp4",
        "progress_hooks": [progress_hook],
        "postprocessor_hooks": [postprocessor_hook],
        "quiet": True,
        "no_warnings": True,
    }
    ffmpeg = get_ffmpeg_path()
    if ffmpeg:
        ydl_opts["ffmpeg_location"] = os.path.dirname(ffmpeg)

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

    on_progress({
        "status": "finished",
        "percent": 100,
        "speed": "",
        "eta": "",
        "filename": os.path.basename(final_filename) if final_filename else "",
    })

    return final_filename or ""
