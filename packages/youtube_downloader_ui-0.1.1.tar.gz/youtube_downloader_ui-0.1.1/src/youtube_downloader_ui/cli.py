"""CLI entry point for the YouTube downloader UI."""

import argparse
import os
import threading
import webbrowser


def main():
    parser = argparse.ArgumentParser(description="YouTube Downloader UI")
    parser.add_argument(
        "--port", type=int, default=8008, help="Port to serve on (default: 8008)"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=os.path.join(os.path.expanduser("~"), "Downloads", "youtube-downloader-ui"),
        help="Directory to save downloads (default: ~/Downloads/youtube-downloader-ui/)",
    )
    parser.add_argument(
        "--no-browser", action="store_true", help="Don't auto-open the browser"
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    from .app import app

    app.config["OUTPUT_DIR"] = args.output_dir

    url = f"http://127.0.0.1:{args.port}"
    print(f"YouTube Downloader UI")
    print(f"  Server:    {url}")
    print(f"  Downloads: {args.output_dir}")
    print()

    if not args.no_browser:
        threading.Timer(1.0, webbrowser.open, args=(url,)).start()

    app.run(host="127.0.0.1", port=args.port, threaded=True)
