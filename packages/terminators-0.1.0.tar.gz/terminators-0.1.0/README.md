# terminators

Initial PyPI package scaffold for `terminators`, using `uv` for build and publish.

## Local workflow

```bash
uv build
uv publish
```

`uv publish` reads `UV_PUBLISH_TOKEN` automatically.

If your token is stored as `PYPI_TOKEN`, run:

```bash
export UV_PUBLISH_TOKEN="$PYPI_TOKEN"
uv publish
```

## TestPyPI

```bash
uv publish --publish-url https://test.pypi.org/legacy/
```
