"""Repository-root examples package."""
