"""Streaming progress reporter for the Gap Agent (v0.1.86).

The Gap Agent is a single batched LLM call that returns ALL N KSI
classifications at once (DECISIONS 2026-04-22 — batched-by-design;
classification needs cross-KSI reasoning, not per-KSI isolation).
That single call takes ~60-90s on Sonnet, longer on Opus, with no
intermediate output — the user stares at a blank prompt wondering
if the process is hung.

This module surfaces progress by:

1. Buffering streaming text-deltas as they arrive from the LLM.
2. Regex-extracting `"ksi_id": "KSI-XXX-YYY"` patterns from the
   in-flight JSON as the model emits classifications.
3. Printing a per-KSI line when each new KSI ID is detected:
       [gap] classifying KSI 12/60: KSI-CNA-RNT
4. Falling back to a token-count heartbeat (one line every ~2s)
   when no KSI has been emitted yet — covers the model's preamble
   (`{"reasoning_summary": ...`) before the classification loop
   actually begins.

JSON-streaming is not safe-to-parse incrementally (truncation =
ValueError). Regex pattern-matching on the cumulative text is the
right shape: a `"ksi_id"` token is unambiguous inside the agent's
output schema (the only places it appears are inside per-KSI
classification objects), so regex matches are guaranteed-real even
on partial JSON.
"""

from __future__ import annotations

import re
import sys
import time
from dataclasses import dataclass, field
from typing import TextIO

# Pattern: `"ksi_id": "KSI-FAM-CODE"` with whitespace tolerance. The
# JSON serializer the agent uses is deterministic about field order
# (pydantic), so each classification opens with `"ksi_id"` early in
# its dict — letting us anchor on this token. KSI IDs follow the FRMR
# convention `KSI-<3-letter-family>-<3-letter-code>` (e.g. KSI-CNA-RNT,
# KSI-AFR-UCM); the regex character class matches that shape only.
_KSI_ID_PATTERN = re.compile(r'"ksi_id"\s*:\s*"(KSI-[A-Z]{3}-[A-Z]{3})"')

# Heartbeat throttle: emit a "still working" line at most every 2s
# during the no-KSI-yet preamble phase. Avoids spam while keeping
# the user informed the process isn't hung.
_HEARTBEAT_INTERVAL_SECONDS = 2.0


@dataclass
class GapProgressReporter:
    """Stateful per-call reporter; install via `LLMClient.complete(on_chunk=...)`.

    Usage from the CLI:
        reporter = GapProgressReporter(total_ksis=60, stream=sys.stderr)
        report, response, prompt = self._invoke_llm(
            user_message=...,
            max_tokens=...,
            on_chunk=reporter,
        )
        reporter.finish()  # final summary line

    The reporter is invoked per text-delta with cumulative-text-so-far.
    Stateful: tracks which KSI IDs have already been reported so
    duplicate emissions in retried JSON don't double-print.
    """

    total_ksis: int
    stream: TextIO = field(default_factory=lambda: sys.stderr)
    seen_ksi_ids: set[str] = field(default_factory=set)
    seen_ksi_count: int = 0
    last_heartbeat_at: float = 0.0
    started_at: float = field(default_factory=time.monotonic)

    def __call__(self, cumulative_text: str) -> None:
        """Stream-progress callback. Idempotent on re-emitted text."""
        # Walk every KSI-ID match in the cumulative text. Set semantics
        # mean re-emitting the same delta (or the same KSI on a retry)
        # doesn't double-print.
        new_ids: list[str] = []
        for match in _KSI_ID_PATTERN.finditer(cumulative_text):
            ksi_id = match.group(1)
            if ksi_id not in self.seen_ksi_ids:
                self.seen_ksi_ids.add(ksi_id)
                new_ids.append(ksi_id)

        for ksi_id in new_ids:
            self.seen_ksi_count += 1
            self._emit(f"[gap] classifying KSI {self.seen_ksi_count}/{self.total_ksis}: {ksi_id}")

        # Heartbeat path: if no KSI emitted yet, print a "still working"
        # line periodically so the user sees the process is alive
        # during the model's reasoning-summary preamble.
        if self.seen_ksi_count == 0:
            now = time.monotonic()
            if now - self.last_heartbeat_at >= _HEARTBEAT_INTERVAL_SECONDS:
                elapsed = int(now - self.started_at)
                token_estimate = len(cumulative_text) // 4  # rough
                self._emit(
                    f"[gap] thinking... ({elapsed}s elapsed, ~{token_estimate} tokens received)"
                )
                self.last_heartbeat_at = now

    def finish(self) -> None:
        """Final summary after the run completes."""
        elapsed = time.monotonic() - self.started_at
        if self.seen_ksi_count > 0:
            self._emit(
                f"[gap] done in {elapsed:.1f}s — "
                f"{self.seen_ksi_count}/{self.total_ksis} KSIs classified"
            )

    def _emit(self, line: str) -> None:
        print(line, file=self.stream, flush=True)


def make_reporter_if_tty(total_ksis: int) -> GapProgressReporter | None:
    """Return a GapProgressReporter only when stderr is a TTY.

    CI runs (where stderr is piped to a log file) get None — the
    progress lines would just clutter logs without giving any
    interactive value. Local terminal runs get the live reporter.

    Returns the concrete reporter class (not the abstract callable
    type) so callers can invoke `.finish()` after the agent run.
    GapProgressReporter is itself a `Callable[[str], None]` via its
    `__call__`, so it satisfies `LLMClient.on_chunk` directly.
    """
    if not sys.stderr.isatty():
        return None
    return GapProgressReporter(total_ksis=total_ksis, stream=sys.stderr)
