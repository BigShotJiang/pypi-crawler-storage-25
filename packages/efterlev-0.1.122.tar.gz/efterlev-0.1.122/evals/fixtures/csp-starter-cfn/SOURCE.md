# Source attribution — `csp-starter-cfn` eval fixture

The CFN template under `infra/csp-starter.template.yaml` is **synthetic**
— hand-authored 2026-05-12, NOT vendored from an upstream public CFN
template repository.

## Why synthetic instead of vendored

The Phase 2 lite TF fixtures (`aws-vpc-tfm`, `aws-s3-bucket-tfm`,
`aws-lambda-tfm`, v0.1.63–v0.1.66) were vendored verbatim from the
`terraform-aws-modules/*` projects — the de-facto standard publishers
of real-shape Terraform modules. There is no equivalent
single-publisher-canonical source for CFN templates: the AWS Quick Start
templates exist (and `aws-vpc-cfn` v0.1.72 vendored one), but they
typically focus on a single resource family per template. None of the
public CFN sources happens to have the resource mix that exercises
the v0.1.73–v0.1.77 mapping work end-to-end (S3 + KMS + IAM + RDS +
Lambda + CloudTrail + LogGroup all in one stack).

Synthesizing a fixture for this purpose is honest scope: this is **not**
a published-real-world template, and SOURCE.md says so. It IS designed
to reflect the canonical-AWS-architecture FedRAMP-20x-friendly shape a
SaaS company would land at on day-one of pursuing authorization
(audit-logs-bucket + KMS + IAM scaffold + a data tier + a compute tier
+ centralized logs). A future release may swap this out for a richer
vendored alternative if AWS publishes one (or a CSP publishes their
public CFN equivalent of `terraform-aws-modules/*`).

## What it exercises

Resources by namespace:

| AWS Namespace | Resource Type | Logical ID | Detector(s) it exercises |
|---|---|---|---|
| KMS | Key | `DataTierKey` | `aws.kms_key_rotation`, `aws.kms_customer_managed_keys` |
| S3 | Bucket | `AuditLogsBucket` | `aws.encryption_s3_at_rest` (KMS-encrypted), `aws.s3_public_access_block` (synthesized aws_s3_bucket_public_access_block from `PublicAccessBlockConfiguration`) |
| S3 | BucketPolicy | `AuditLogsBucketPolicy` | `aws.iam_managed_via_terraform` (inventory of policy resources) |
| CloudTrail | Trail | `AuditTrail` | `aws.cloudtrail_audit_logging`, `aws.cloudtrail_log_file_validation` |
| IAM | Role | `AuditorRole` | `aws.iam_admin_policy_usage` (synthesized aws_iam_role_policy_attachment fires — AdministratorAccess attached) |
| IAM | Role | `LambdaExecRole` | `aws.iam_inline_policies_audit` (synthesized aws_iam_role_policy fires — `ReadDataTierKms` inline policy) |
| RDS | DBInstance | `AppDb` | `aws.rds_encryption_at_rest`, `aws.rds_public_accessibility` |
| Lambda | Function | `AppHandler` | `aws.lambda_env_kms_encryption` (env vars without KMS — partial signal), `aws.lambda_vpc_isolation` (no VpcConfig — partial signal), `aws.lambda_logging_configured` |
| Logs | LogGroup | `AppLogs` | `aws.centralized_log_aggregation` (inventory) |

12+ detector firings expected from a single template.

## Intentional partial patterns

The fixture is **not** designed to maximally evidence every KSI. Two
spots are deliberately partial so that the per-KSI verdicts have
defensible-but-not-uniform shapes for labeling discipline:

1. **`AuditorRole` has `AdministratorAccess` attached.** A real CSP
   often lands here at v0 — the auditor role gets full read-everything
   and the maintainer is "supposed to come back later" to scope it down.
   `aws.iam_admin_policy_usage` fires; honest verdict for KSI-IAM-ELP
   is `partial` (admin grants exist but are deliberate scaffolding).
2. **`AppHandler` has env-vars without KMS-encryption AND no VpcConfig.**
   A real Lambda often lands here at v0 — env vars hold non-secret
   tunables (LOG_LEVEL etc.) and the function is internet-reachable
   for development convenience. Both `aws.lambda_env_kms_encryption`
   and `aws.lambda_vpc_isolation` will emit partial-signal Evidence;
   honest verdicts are `partial`.

These partials make the fixture useful as a regression instrument:
they pin agent reasoning about defensible-vs-incorrect verdicts where
the underlying signals are mixed.

## Eval-harness coverage as of v0.1.78

This release ships the fixture + `GROUND_TRUTH.yaml` with conservative
maintainer labels (the "draft labels" pass). The maintainer-validation
LLM-call run (the v0.1.69-equivalent step where we run the gap agent
with a real `ANTHROPIC_API_KEY` and compare verdicts to labels) is
**deferred** to a future release — not run at v0.1.78 due to budget
constraints (Anthropic spend cap + GitHub Actions minute cap currently
at 90% of cap per memory note 2026-04-28).

Reference: DECISIONS 2026-05-12 amendment 6 for the deferral rationale
and how to come back to it.
