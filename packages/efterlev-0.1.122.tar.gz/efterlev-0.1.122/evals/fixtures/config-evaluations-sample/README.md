# config-evaluations-sample

Synthetic AWS Config evaluations fixture for v0.1.114 M1 Stage 3 —
`efterlev import-config` ingestion.

**Provenance:** Hand-crafted from the AWS Config `EvaluationResult`
spec at https://docs.aws.amazon.com/config/latest/APIReference/API_EvaluationResult.html
to exercise the parser + mapper without burning AWS spend on a real
sandbox. Mirrors the shape `aws configservice
get-compliance-details-by-config-rule` produces.

**Coverage at v0.1.114:** 5 evaluations × 4 mapped + 1 unmapped:

| ConfigRuleName | ComplianceType | Maps to |
|--|--|--|
| `encrypted-volumes` | NON_COMPLIANT | KSI-CNA-OFA |
| `s3-bucket-public-read-prohibited` | COMPLIANT | KSI-CNA-RNT |
| `cloudtrail-enabled` | COMPLIANT | KSI-MLA-CMA |
| `iam-root-access-key-check` | COMPLIANT | KSI-IAM-ELP |
| `custom-unmapped-rule` | NON_COMPLIANT | (unmapped — skipped) |

Account IDs and resource IDs are placeholders (`111111111111`,
`vol-aaaaaaaa...1`); not real account references.
