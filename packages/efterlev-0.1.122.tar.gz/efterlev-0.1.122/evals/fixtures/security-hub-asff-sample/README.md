# security-hub-asff-sample

Synthetic ASFF (AWS Security Finding Format) fixture for v0.1.113 M1
Stage 1 — `efterlev import-security-hub` ingestion.

**Provenance:** Hand-crafted from the ASFF spec at
https://docs.aws.amazon.com/securityhub/latest/userguide/securityhub-findings-format.html
to exercise the parser + mapper without burning AWS spend on a real
sandbox. Each finding shape mirrors what `aws securityhub get-findings`
produces for the AWS Foundational Security Best Practices standard.

**Coverage at v0.1.113:** 4 findings × 3 mapped + 1 unmapped (exercises
the unmapped-skip path):

| Finding | Generator ID | Compliance | Maps to |
|--|--|--|--|
| 1 | `aws-foundational-security-best-practices/v/1.0.0/EC2.2` | FAILED | KSI-CNA-RNT |
| 2 | `aws-foundational-security-best-practices/v/1.0.0/IAM.6` | PASSED | KSI-IAM-MFA |
| 3 | `aws-foundational-security-best-practices/v/1.0.0/CloudTrail.1` | PASSED | KSI-MLA-CMA |
| 4 | `aws-foundational-security-best-practices/v/1.0.0/UNMAPPED.99` | FAILED | (unmapped — skipped) |

Account IDs, finding ARNs, and resource ARNs are placeholders
(`111111111111`, all-zeros suffixes); not real account references.

**Refresh:** Update when the v0.1.113.x mapping-table batches expand
the recognized generator-id set; add findings exercising the new
mappings here.
