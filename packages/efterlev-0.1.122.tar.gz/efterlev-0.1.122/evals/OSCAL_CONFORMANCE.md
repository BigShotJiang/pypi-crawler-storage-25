# OSCAL conformance — schema validation + labeled fixture

This document covers how Efterlev validates its emitted OSCAL POA&M JSON
against the NIST OSCAL 1.0.4 schema, and how to refresh the labeled
fixture committed under
`evals/fixtures/csp-starter-cfn/oscal/labeled-poam-v0.1.106.json`.

## What's vendored

| Path | Source | Frozen at |
|--|--|--|
| `catalogs/oscal/oscal_poam_schema_v1.0.4.json` | https://github.com/usnistgov/OSCAL/blob/v1.0.4/json/schema/oscal_poam_schema.json | OSCAL 1.0.4 |
| `catalogs/oscal/oscal_component_schema_v1.0.4.json` | https://github.com/usnistgov/OSCAL/blob/v1.0.4/json/schema/oscal_component_schema.json | OSCAL 1.0.4 |

OSCAL 1.0.4 is the FedRAMP-current version (per FedRAMP's published
OSCAL guidance and the GSA fedramp-automation rule set). When FedRAMP
publishes 1.1.0 guidance, vendor the corresponding schema and bump
`_OSCAL_VERSION` in `src/efterlev/primitives/generate/generate_poam_oscal.py`.

## How the gate works

Two layers, both run on every PR via the existing `lint, type-check, test`
CI job:

**Layer 1 — NIST OSCAL JSON schema (`validate_oscal_poam`, v0.1.106).**
Catches structural conformance — required fields, types, UUID format,
enum-shape constraints in the upstream OSCAL schema. Tests live in
`tests/test_validate_oscal_poam.py` + `tests/test_oscal_labeled_fixture.py`.

**Layer 3 — NIST oscal-cli (Java, v0.1.110).** External canonical
validator from `usnistgov/oscal-cli`. Strict CI gate via
`.github/workflows/oscal-cli-conformance.yml` runs `poam validate` +
`component-definition validate` against the labeled fixtures on every
PR. If NIST's own tool accepts our output, that's the strongest
external conformance signal short of the GSA fedramp-automation Saxon
pipeline. Pinned to a known-good NIST oscal-cli release (bump
`OSCAL_CLI_VERSION` in the workflow when tracking newer NIST output).

**Layer 2 — FedRAMP rule set (`validate_oscal_fedramp_rules`, v0.1.107).**
Catches FedRAMP-specific shape constraints the OSCAL schema doesn't
enforce. Five rules ship at v0.1.107, each with a stable
`FRMP-OSCAL-NNN` identifier:

| ID | Constraint |
|--|--|
| FRMP-OSCAL-001 | POA&M-item severity ∈ {high, moderate, low} |
| FRMP-OSCAL-002 | risk status ∈ {open, investigating, remediation-pending, closed, deviation-requested} |
| FRMP-OSCAL-003 | every poam-item references at least one risk or observation |
| FRMP-OSCAL-004 | frmr-baseline ∈ {fedramp-20x-low, fedramp-20x-moderate, fedramp-20x-high} |
| FRMP-OSCAL-005 | oscal-version is FedRAMP-current (1.0.4) |

Tests live in `tests/test_validate_oscal_fedramp_rules.py`. Rule
violations carry `severity="error"` (gate emit) at v0.1.107; future
rules may ship as `severity="warning"` (informational, no gate).

The validator (`validate_oscal_poam`) uses the `jsonschema` library with
a custom `pattern` keyword that tolerates PCRE Unicode property escapes
(`\p{L}` etc.) — the OSCAL schema uses these for markdown text-shape
constraints, and Python's stdlib `re` doesn't support them. Standard
regex (UUIDs, identifiers) is enforced; unparseable patterns are
skipped silently. Full PCRE coverage will arrive with the GSA
Schematron layer in v0.1.107.

## Refreshing the labeled fixture

The labeled fixture is regenerable from a fixed input set. The input
classifications mirror the csp-starter-cfn Phase 2 lite verdicts (6
representative open KSIs across CMT, CNA, IAM, SVC, MLA, PIY themes).

To refresh after a generator change:

```bash
uv run python scripts/regenerate_oscal_labeled_fixture.py
uv run pytest tests/test_oscal_labeled_fixture.py -v
git add evals/fixtures/csp-starter-cfn/oscal/labeled-poam-v0.1.106.json
```

If you change the underlying inputs (more KSIs, different statuses),
also update the expected-shape assertions in
`tests/test_oscal_labeled_fixture.py::test_labeled_fixture_has_expected_shape`.

## Bumping schema versions

When OSCAL ships a new minor (e.g., 1.0.5):

1. Vendor the new schema under `catalogs/oscal/oscal_poam_schema_v<N>.json`.
2. Update `_SCHEMA_RELATIVE_PATH` in `validate_oscal_poam.py`.
3. Update `_OSCAL_VERSION` in `generate_poam_oscal.py`.
4. Re-run `pytest tests/test_oscal_labeled_fixture.py` and regenerate
   the fixture if metadata changed.
5. Add a CHANGELOG entry noting the schema version bump.

When OSCAL ships a new major (e.g., 1.1.0):

OSCAL 1.1.0 has breaking schema changes. Plan a dual-emit (`--oscal-version`
flag on `oscal export`) before defaulting to the new version, to avoid
breaking customers whose 3PAO-side tooling still targets 1.0.4.

## Why a labeled fixture (not just generator output)

The labeled fixture is a 3PAO-inspectable artifact. Anyone evaluating
Efterlev can open the JSON file directly and see "this is what the tool
produces" without installing or running anything. Regression-protecting
the file with a schema-validation test means the artifact stays valid
as the generator evolves.
