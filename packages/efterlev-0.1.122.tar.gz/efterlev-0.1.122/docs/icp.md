# Ideal Customer Profile

This document names the user Efterlev is designed for. It is the lens for every product decision. When we ask "should we add X?", the test is: does X serve the primary ICP's workflow? If not, X is deferred or declined — however technically interesting it may be.

This document is not a marketing persona. It is an engineering constraint.

---

## The primary ICP (v0 and v1)

**A SaaS company pursuing its first FedRAMP Moderate authorization.**

### Who they are

- **Company stage:** 50–200 engineers. Strong commercial product-market fit. Profitable or venture-funded with real revenue.
- **Product:** A B2B SaaS offering — horizontal (observability, data, CRM, collaboration) or vertical (healthcare, fintech, GRC, security). The product already works and has commercial customers.
- **Trigger event:** A federal agency or a federal prime contractor has indicated they will buy the product *if* it achieves FedRAMP Moderate authorization. Revenue is on the line — typically a committed deal in the $500K–$5M range, or a pipeline of several such deals.
- **Who feels the pain first:** The VP of Engineering, the CTO, or the Head of Security. They are the ones the CEO turns to with "we need FedRAMP — how long?" They don't have the answer.
- **Who does the work:** A DevSecOps lead or senior platform engineer, often the same person who owns the CI pipeline and the Terraform. They're the one who will `pipx install efterlev` at 11pm on a Tuesday.

### What they don't have

- **A compliance team.** At this scale, "compliance" is a hat worn part-time by the Head of Security or outsourced to consultants.
- **Prior FedRAMP experience.** This is their first time. They don't know what an SSP looks like in the wild. They've heard of OSCAL but don't use it.
- **Budget for enterprise compliance platforms.** RegScale and Xacta are priced for larger buyers. Vanta and Drata are affordable but weak on FedRAMP depth (Comp AI shows 41% FedRAMP coverage in their own demo for a reason — it's not their primary target).
- **Time.** The commercial deal has a deadline. 18 months feels impossibly long; six is aspirational; 12 is survivable.

### What their situation looks like concretely

They have:

- **Some infrastructure-as-code, often mixed.** Terraform is the most common, but many ICP A users have CloudFormation, AWS CDK, Pulumi, or a mix — and almost all have Kubernetes manifests for their workloads. A subset have ClickOps-provisioned resources nobody remembers creating. Their IaC maturity is typically the pre-FedRAMP state of things, and the FedRAMP effort is often what forces the codification.
- **A fresh or nearly-fresh FedRAMP boundary (common pattern).** Many ICP A companies run their FedRAMP deployment as a parallel dedicated environment (often a separate AWS account, often in GovCloud) rather than inside their main commercial production. This means the Terraform scanned for the authorization is frequently newer and cleaner than the rest of their codebase, which is useful for v0's Terraform-only coverage.
- **A modern engineering stack.** GitHub, CI via GitHub Actions or CircleCI, containerized workloads (ECS, EKS, Lambda).
- **An existing security posture appropriate for a commercial SaaS** — good enough for SOC 2 Type II or ISO 27001, not obviously ready for FedRAMP Moderate.
- **A consultant engagement (or a pending one)** with a FedRAMP advisor at $200–$500/hour. This consultant may also have recommended a 3PAO.

They need to produce:

- A gap analysis against FedRAMP 20x Moderate, organized around the 60 Key Security Indicators (KSIs) — which is the surface a 20x pilot participant is actually evaluated against, backed by the underlying 800-53 Rev 5 controls that each KSI references. (AWS's [2026-04-27 FedRAMP 20x deep-dive blog](https://aws.amazon.com/blogs/publicsector/deep-dive-into-fedramp-20x-key-security-indicators-decoding-the-63-ksis/) frames the same catalog as 63 KSIs by additionally counting the 3 cross-cutting CSX KSIs; both accountings are defensible. Efterlev's [CSX mapping doc](./csx-mapping.md) shows how the existing pipeline satisfies the CSX KSIs without new detector code.)
- FRMR-compatible validation data for each KSI (attestations grounded in measurable evidence)
- A POA&M for known gaps
- Evidence packages for each KSI
- **Optional, increasingly secondary:** an OSCAL-formatted SSP / Assessment Results for Rev5 transition submissions or for downstream OSCAL-Hub-style tooling. FedRAMP processed 100+ Rev5 authorizations in 2025 with no OSCAL submissions; a new-in-2026 authorization heading into 20x does not lead with OSCAL.

### Implications for what Efterlev accepts as input

v0 scans **Terraform and OpenTofu** (shared syntax; `python-hcl2` handles both). This covers the largest single slice of ICP A's infrastructure and maps naturally to the "fresh FedRAMP boundary" pattern above.

v0 explicitly does **not** cover: CloudFormation, AWS CDK, Pulumi, Kubernetes manifests, or runtime cloud API scanning. These are v1 priorities in the following order of impact for ICP A:

1. **Terraform Plan JSON** — scanning resolved plans rather than raw HCL catches computed values. High value, low cost. v1 early.
2. **CloudFormation / CDK** — CDK compiles to CloudFormation, so one parser covers both. Many AWS-native ICP A users have some of this. v1 month 1–2.
3. **Kubernetes manifests + Helm** — different control set (network policies, pod security, RBAC) but nearly universal in ICP A production. v1 month 2–3.
4. **Pulumi** — code-first IaC; trickier parsing but real demand. v1 month 3–4.
5. **Runtime cloud API scanning** — the "real" answer for partially-codified infrastructure. Different threat model, needs its own design pass. v1.5+.

The architectural commitment that makes this expansion cheap: the detector contract is already source-typed (`source="terraform"` is a field on the decorator), and the detector library folder structure has room for parallel `detectors/aws/cloudformation/`, `detectors/k8s/`, etc. Adding a source type is adding a parser and a set of parallel detectors — not a rearchitecture.

**An ICP A user with a mixed-IaC codebase** should see this explicitly in our positioning. If 60% of their infrastructure is Terraform, v0 covers the majority and they get real value. If they're 100% CloudFormation, v0 is not for them yet and we should be honest about that.

### What their day-one Efterlev experience needs to be

1. They hear about Efterlev from a blog post, a Hacker News thread, a recommendation in a DevSecOps Slack, or a FedRAMP consultant who tried it.
2. They clone the demo or point Efterlev at their own repo. `pipx install efterlev` takes 90 seconds.
3. `efterlev scan` produces findings within 30 seconds. The findings are concrete: "S3 bucket `production-data` lacks server_side_encryption_configuration at `main.tf:142`, relevant to KSI-SVC-VRI (800-53: SC-28)."
4. `efterlev agent gap` classifies their posture across the six (v0) KSIs with confidence and evidence, with the underlying 800-53 controls shown alongside. They see, for the first time, a machine-generated sketch of where they stand in 20x terms.
5. `efterlev agent document --ksi KSI-SVC-SNT` produces an FRMR-compatible draft attestation for one KSI, citing their actual Terraform lines. They forward this to their FedRAMP consultant, who says "this is 70% of what I'd write myself for the 20x pilot package."
6. Within their first session, they have: a concrete gap list, a draft FRMR attestation for a KSI, a remediation diff for at least one finding, and a clear sense that *more detectors would produce more of the same*.
7. Within week one, they have added Efterlev to their CI pipeline. PRs now carry a KSI-status delta. The tool is now part of their workflow, not an occasional scan.

### What makes them keep using Efterlev after week one

- Every new detector we ship extends their KSI coverage without any work on their part. Breadth compounds.
- The FRMR output maps directly onto what FedRAMP 20x is asking for, and v1's OSCAL output covers Rev5 transition edge cases. They don't have to explain or translate their pipeline.
- The provenance chain makes the tool defensible in 3PAO conversations: "here's where each claim in our draft came from."
- CI integration catches regressions before they become audit findings.
- The Remediation Agent produces diffs their team can review and apply, shrinking the time from finding to fix.

### What we must not do to ICP A

- Force them into a SaaS dashboard. They live in the repo.
- Require cloud API access. Many ICP A users don't want a tool with IAM read access to their production account; Terraform source is the right abstraction.
- Overclaim. If Efterlev's output says "KSI-SVC-VRI is implemented" when we've only evidenced the infrastructure layer of the underlying 800-53 control, their 3PAO will catch the overclaim and we will lose their trust permanently.
- Add features that serve compliance teams instead of engineers. ICP A *does not have* a dedicated compliance team; features designed for one are dead weight.

---

## v1 locked scope (2026-04-22, amended 2026-04-23)

Three interdependent commitments, surviving from the 2026-04-22 v1 scope lock. The fourth original commitment (closed-source through v1) was rescinded 2026-04-23 in favor of an open-source-first posture (see below). All three remaining commitments are ICP-material and shape what the archetype user gets in v1.

1. **Archetype-first.** No named design partner at v1 start. We design against the primary ICP as described above and accept that Evidence Manifest schema and Phase 6 detector priorities will need a revision pass once the first real user surfaces. Under the open-source-first posture, that user is more likely to surface through public GitHub discovery than through private outreach — but the archetype-first discipline (build for ICP A specifically, not for every possible compliance user) stays intact.
2. **20x-native output first.** FRMR-compatible attestation JSON is the only v1 production output format. OSCAL SSP / AR / POA&M generators defer to v1.5+, gated on Rev5-transition or OSCAL-Hub-consuming customer demand. The architecture retains the `oscal/` generator slot; it is empty at v1.
3. **Commercial AWS + GovCloud both first** *(amended 2026-04-23).* Deployment modes 1 (developer laptop), 2 (CI runner), AND 3 (customer-owned VM inside a GovCloud boundary) all ship at launch. AWS Bedrock backend — originally deferred to v1 Phase 3 gated on GovCloud-prospect demand — is now a pre-launch readiness gate (A3), because the "runs where the customer wants to run it" promise of the open-source launch is hollow without GovCloud support.

### Rescinded 2026-04-23: ~~Closed-source through v1~~

Originally commitment #4. Rescinded in favor of an open-source-first, gate-driven launch. Efterlev ships as a public Apache-2.0 repository when eight pre-launch readiness gates pass (A1 identity/governance, A2 distribution/packaging, A3 Bedrock backend, A4 detector breadth to 30, A5 trust surface, A6 documentation site, A7 deployment-mode verification, A8 launch rehearsal). Monetization posture: pure OSS, no commercial tier, no paid layer — ever.

Trigger for the pivot: the 2026-04-23 market-reality-check surfaced three facts that invalidated the closed-source rationale: Paramify's FedRAMP 20x Phase 2 Moderate authorization (now category-leading in the "30-day FedRAMP" narrative); compliance.tf's direct technical-substitute positioning with 185 FedRAMP Moderate Rev 4 controls enforced; and FedRAMP 20x Phase 3's expected Q3–Q4 2026 public-authorization opening, which is the demand surge this product was built to serve. Discovery for an OSS tool during that surge happens through public GitHub, not NDA outreach.

Full rationale, alternatives rejected, and sequencing implications in `DECISIONS.md` 2026-04-23 "Rescind closed-source lock; open-source-first, gate-driven launch."

---

These commitments do not change ICP A's shape. They narrow what Efterlev v1 *ships* to serve that ICP. The archetype-first call (commitment #1) is the one most likely to warp in response to first-user feedback; the others are structural.

---

## Secondary ICPs (v1+ expansion)

Named explicitly so we know where we're going without diluting current focus.

### ICP B — The defense contractor pursuing CMMC 2.0 Level 2 or DoD IL

- **Company stage:** 200–1000+ engineers at a defense-industrial-base company.
- **Trigger event:** CMMC 2.0 enforcement is now real; loss of DoD contracts if not certified by the deadline.
- **Why they're secondary for v0:** We don't ship CMMC coverage until v1 (month 5 of the roadmap). Serving them well requires AWS Bedrock in GovCloud (v1), CUI-aware data handling, and air-gap-ready operation.
- **When they become primary:** v1.5–v2, once CMMC overlay, Bedrock backend, and segregation-aware workflows exist.
- **What the expansion requires:** Bedrock backend (committed v1), CMMC 2.0 profile and mappings, IL-overlay detectors, secrets handling hardening beyond v0.

### ICP C — The DevSecOps platform team at a larger gov-contracting org

- **Company stage:** 1000+ engineers. Mature platform team. Already has in-house compliance tooling or a partial SaaS deployment.
- **Trigger event:** They are building or consolidating an internal compliance pipeline for many downstream teams.
- **Why they're secondary for v0:** They need features we haven't built — organization-specific detector contribution workflow, multi-repo coordination, role separation between platform and consumer teams, integration with their existing observability and GRC stack.
- **When they become primary:** v2+, once we have a healthy external contributor ecosystem and proven composability.
- **What the expansion requires:** Mature plugin architecture for detectors (committed), multi-repo state handling, integration with RegScale / OSCAL Hub / Xacta for downstream consumption, organization-scoped policy packs.

---

## Who we are not trying to serve

Explicitly named to avoid drift.

- **Companies pursuing SOC 2 only.** Comp AI, Vanta, Drata, Secureframe, and a dozen others serve this market well. Efterlev's gov-grade depth is wasted here.
- **Companies pursuing ISO 27001, HIPAA, PCI-DSS, or GDPR as their primary framework.** Efterlev can produce supporting evidence for these, but we are not building detector libraries for them. Other tools are better fits.
- **Compliance teams at enterprises already using RegScale, Xacta, or Ignyte.** These tools serve the GRC/AO/ISSO workflow; Efterlev is a developer-side complement, not a replacement.
- **Teams already running AWS Config + Security Hub + CloudTrail for compliance evidence.** AWS-native services produce *runtime* evidence on a 3-day cadence; Efterlev produces *pre-deploy* evidence on every file-save and the CSX-SUM attestation summary 3PAOs actually consume. They're complementary, not competing — see [docs/aws-coexistence.md](./aws-coexistence.md). If you're 100% AWS, technically deep, and willing to build your own evidence pipeline using Landing Zone Accelerator + EventBridge + Step Functions yourself, Efterlev's marginal value to you is the dev-loop layer plus the package generator; some sophisticated AWS shops still adopt it for those, but it's not a forced choice.
- **Authorizing Officials, 3PAOs, and FedRAMP PMO reviewers.** Efterlev produces artifacts they consume; OSCAL Hub and similar platforms are purpose-built for their review workflow.
- **Companies that want a compliance dashboard.** Our locus is the repo and the CLI. Users who want a dashboard are not served well by us.
- **Companies that want to "vibe-code" compliance.** Efterlev refuses to claim authorization, refuses to generate narrative without evidence, and flags every LLM-generated artifact as requiring human review. Teams that want plausible-looking output without rigor will be disappointed, which is the correct outcome.

---

## How this document drives decisions

A non-exhaustive list of product decisions this ICP answers:

- **"Should we add a web UI?"** → Not for ICP A. Defer.
- **"Should we support SOC 2?"** → Not for ICP A. Defer indefinitely.
- **"Should we build continuous monitoring?"** → Roadmap month 6. ICP A gets value from point-in-time scans + CI integration; continuous monitoring is more valuable to ICP B and C.
- **"Should we add a multi-tenant SaaS mode?"** → No. ICP A runs locally. ICP B often cannot use multi-tenant SaaS at all.
- **"Should the Gap Agent's output be auto-submitted to a 3PAO portal?"** → No. ICP A uses human-in-the-loop; their consultant and 3PAO are part of the workflow.
- **"Should we add a 'quick check' mode with fewer controls for faster scans?"** → Worth considering for ICP A — they want fast feedback in CI. Potential v1 feature.
- **"Should we support Pulumi / CloudFormation / Kubernetes manifests?"** → ICP A is mostly Terraform-first. Pulumi and Kubernetes manifests are v1 priorities; CloudFormation is v1.5 unless a specific ICP A user needs it.
- **"Should we integrate with Jira?"** → Likely yes in v1. ICP A's workflow involves tracking findings as tickets.

---

## Validating the ICP choice

This document is a hypothesis. It will be tested by actual usage. Signals that ICP A is right:

- First 10 non-author GitHub stars come from engineers at SaaS companies in the 50–200 range.
- First external contributor PR addresses a control ICP A would hit in a real FedRAMP engagement.
- First "this worked for us" issue or blog post comes from a company matching the ICP A profile.

Signals we may be wrong:

- Early interest is dominated by ICP C (platform teams) — would suggest we lead with composability and plugin docs sooner.
- Early interest is dominated by consultants rather than end users — would suggest the buyer is different from the ICP we modeled.
- Early interest is dominated by ICP B (defense contractors) — would accelerate the CMMC and Bedrock roadmap.

We re-evaluate this document at v0.2 (first external usage) and at every minor release thereafter. Updates are logged in `DECISIONS.md`.

---

*Last reviewed: initial draft. Update this date with every review.*
