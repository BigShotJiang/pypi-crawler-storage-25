# AI-quickstart prompt

The canonical prompt for driving Efterlev with an AI assistant (Claude
Code, Cursor, Codex, Kiro, or any tool with shell access). Paste it
verbatim and the assistant will:

- Confirm the repo root (catches the silent 20%-coverage-loss footgun).
- Ask which LLM backend you want — Anthropic API or AWS Bedrock — and
  surface ambient state (env vars, AWS creds) as informational, not
  decisional.
- For Bedrock: pick the latest Sonnet inference profile, default to it,
  surface Opus / Haiku as overrides.
- Install or upgrade Efterlev. Detects pipx vs uv and gives the right
  command per installer.
- Run init → boundary set → doctor → scan → agent gap → agent document
  → poam.
- Brief you on the top 3 KSIs to focus on (biased toward SVC + IAM —
  the most-cited 3PAO finding categories) plus the partial-status
  KSIs best suited to `agent remediate`.

Cost: ~$0.30–1 on Sonnet 4.6 (the recommended default), or ~$1–2 on
Opus. Wall time: 5–10 minutes total. Soft cost cap baked in at
$3 (Anthropic path) / $5 (Bedrock path) — the assistant stops and
asks before exceeding.

The prompt is self-contained — no other docs needed for the assistant
to drive end-to-end.

---

```text
You are helping me run Efterlev (https://efterlev.com) against my Terraform
for the first time. Efterlev is a FedRAMP 20x compliance scanner that reads
Terraform, classifies it against 60 Key Security Indicators, and drafts
FRMR-compatible attestations with cited evidence (file-level always; HCL
line numbers when scanning .tf source directly). It runs locally; the only
outbound call is to the LLM endpoint I configure.

## Step 0 — confirm the target path

This is the silent footgun, so handle it first.

Ask me for the **absolute path to my repo root** — NOT a Terraform
subdirectory like `infra/terraform/`. Efterlev needs the repo root to
walk all three evidence sources:

  - `**/*.tf` for the Terraform-source detectors
  - `.github/workflows/*.yml` for the GitHub-workflow detectors
    (5 detectors, ~10% of coverage)
  - `.efterlev/manifests/*.yml` for procedural-KSI attestations
    (covers the AFR / CED / INR themes, ~10% of coverage)

If I name a subdir, you'll silently miss workflows + manifests — about
20% of detector coverage disappears with no error message. So:

1. Ask me for the path.
2. Verify it's a git repo root: check for `.git/` AND at least one of
   `**/*.tf` OR `.github/workflows/`. If only one is present, confirm
   with me before proceeding ("I see Terraform but no workflows — is
   this a repo root or a subdir?").
3. `cd` to that path and stay there for the rest of the run.

## Step 1 — pick the LLM backend

**Always ask me this question — do NOT auto-decide based on env vars,
AWS profile state, or any other ambient signal.** The presence of an
`ANTHROPIC_API_KEY` in my environment doesn't mean I want to use it
for *this* run; many users have credentials for both backends and
testing one specifically is the whole point.

You may surface ambient state as informational context, but the choice
is mine:

  > "I see `ANTHROPIC_API_KEY` is set, and `aws sts get-caller-identity`
  >  succeeds for region us-east-1. Which backend would you like to use
  >  for this run?
  >
  >    (a) Direct Anthropic API — fastest path; uses your existing key.
  >    (b) AWS Bedrock — uses your AWS credentials; works for GovCloud
  >        and FedRAMP-authorized infra."

Only proceed once I've answered. If I'm genuinely undecided and ask
you to choose, then default to (a) and say so explicitly.

The trade-off summary, if I want it:

  - **Anthropic API** — ~2 min setup, one env var, no AWS account.
  - **Bedrock** — ~5–10 min setup (model-access opt-in + inference
    profile selection), but works at FedRAMP-authorized scale.

## Step 2a — Anthropic API path

The fast path. ~2 minutes from zero to running.

1. Confirm I have an API key. Verify:
       echo "${ANTHROPIC_API_KEY:0:10}"
   Should start with `sk-ant-`. If empty, stop and tell me to grab
   one at https://console.anthropic.com/settings/keys and export it.
2. Install or upgrade:
   - First-time: `pipx install efterlev` (or `brew install pipx`
     first if pipx is missing).
   - Upgrade:    `pipx upgrade efterlev` (no brackets — extras are
     install-time only).
3. Confirm `efterlev --version` matches the latest published release.
   If older, clean-reinstall: `pipx uninstall efterlev && pipx install efterlev`.
   (Check the latest with `pip index versions efterlev | head -1`.)

Then jump to Step 3.

## Step 2b — Bedrock path

Bedrock connects you to LLMs hosted on AWS. Same Anthropic models, just
billed through your AWS account.

### Step 2b.0 — pick the model family

Ask me which model family I want to use:

  (a) Anthropic Claude — RECOMMENDED. This is what Efterlev's agents
      are tuned for; the only family with full feature support today.
  (b) OpenAI on Bedrock — not yet supported. On the v0.3+ roadmap.
  (c) Other (AI21 / Cohere / Meta / Mistral) — not yet supported.

If I say anything other than Claude, gently flag it's not yet
supported, recommend Claude as the working path, and only proceed
if I explicitly confirm I want to wait for v0.3. The rest of this
step assumes Claude.

### Step 2b.1 — region and credentials

1. Ask me which AWS region to use. Default suggestion: `us-east-1`
   (us-west-2 is the other reliable option). Verify creds:

       aws sts get-caller-identity --region <region>

   If this fails, stop — I need to run `aws configure` first.

2. Confirm Anthropic model access is enabled in this account. The #1
   cold-start cliff. Visit:

       https://console.aws.amazon.com/bedrock/home?region=<region>#/modelaccess

   At least one Claude 4.x must show "Access granted." If not, request
   access there (~near-instant for most accounts) and wait a minute to
   propagate before continuing.

### Step 2b.2 — pick the tier

3. Discover available Claude inference profiles in that region.
   CRITICAL: use `--no-paginate --max-results 1000`. The default
   page size silently truncates at ~100, and older Claude 3.x
   profiles fill the first page hiding 4.x. Run:

       aws bedrock list-inference-profiles --region <region> \
           --type-equals SYSTEM_DEFINED \
           --no-paginate --max-results 1000 \
         | jq -r '.inferenceProfileSummaries[]
                  | select(.inferenceProfileName | test("claude"; "i"))
                  | "\(.inferenceProfileName)\t\(.inferenceProfileArn)"'

   Group results by tier (Opus / Sonnet / Haiku), pick the LATEST
   version of each. Prefer regional `us.` / `eu.` profiles over
   global. If NO 4.x profiles appear after `--no-paginate`, model
   access from step 2 isn't actually granted — go back.

4. Present this as the recommendation, NOT a multiple-choice question.
   Pick the latest Sonnet ARN as MODEL_ARN unless I explicitly object:

       Recommended: Latest Sonnet (e.g. claude-sonnet-4-6)
         — Best cost/quality balance for this workload.
         — ~5× cheaper than Opus; on the 60-KSI sweep the
           classification quality is indistinguishable from Opus.
         — Run cost: ~$0.30–1 on a typical mid-size codebase.
         — Latency: most runs complete in 60–90 seconds.

       Override only if you have a specific reason:
         — Latest Opus (e.g. claude-opus-4-7): higher reasoning
           ceiling. ~5× the spend. Worth it for ambiguous codebases
           or when you want the very best classification.
         — Latest Haiku (e.g. claude-haiku-4-6): cheapest tier;
           fine for smoke tests but quality dips on edge cases.

   If a tier is unavailable in this account, omit it from the
   alternatives. Capture the chosen `inferenceProfileArn` as
   MODEL_ARN.

### Step 2b.3 — install Efterlev

5. Install or upgrade with the Bedrock extra. **Pick the path that
   matches your installer** — pipx and uv tool manage isolated venvs
   at different paths, and using the wrong installer's commands
   silently fails to find the package. `efterlev doctor` detects which
   installer was used and gives the right hint when boto3 is missing,
   but you can pre-empt the round-trip:

   - **pipx users:**
     - First-time: `pipx install 'efterlev[bedrock]'` (keep the quotes —
       bracket extras need them; if pipx is missing, `brew install pipx`
       first).
     - Upgrade: `pipx upgrade efterlev` (drop the `[bedrock]` bracket —
       extras are install-time only). If the prior install was non-
       Bedrock (no boto3 in the venv), also run:
           pipx inject efterlev boto3
       Verify: `pipx runpip efterlev show boto3`.

   - **uv tool users** (e.g. `uv tool install efterlev` previously):
     - Install or re-install with the extra:
           uv tool install --reinstall 'efterlev[bedrock]'
       This is the right command whether you're starting fresh or
       adding boto3 to an existing uv-managed install. Pre-v0.1.9
       runbook pointed at `pipx inject efterlev boto3` — that's wrong
       for uv-installed efterlev (different venv path; pipx-targeted
       commands silently fail to find the package).

   - Confirm `efterlev --version` matches the latest published release.
     If older, clean-reinstall:
         pipx uninstall efterlev && pipx install 'efterlev[bedrock]'
     (Check the latest with `pip index versions efterlev | head -1`.)

## Step 3 — init

You're already at the repo root from Step 0. Run init with `--force`
by default — it preserves customer-authored `.efterlev/manifests/`
(those are the only sticky state you'd ever want to keep) and
regenerates the FRMR cache, provenance store, and `config.toml`. On
upgrades especially, the regenerated `config.toml` picks up any new
defaults the new release shipped (especially relevant on the Bedrock
path, where the latest available inference profiles drift between
releases).

  - Anthropic backend:
      `efterlev init --target . --force`
  - Bedrock backend:
      `efterlev init --target . --force \`
      `  --llm-backend=bedrock --llm-region=<region> --llm-model=<MODEL_ARN>`

Skip `--force` only if I tell you I have an in-progress workspace
with hand-edited `config.toml` I want to preserve.

## Step 4 — doctor + scan

1. Run `efterlev doctor` — surface any warnings or fails. The doctor
   actively pings the LLM (Bedrock InvokeModel or Anthropic API) so
   credential / model-access issues surface here before agent runs
   spend money.

2. Pick a scan mode. Try plan-JSON first when `terraform` is on PATH
   (gives full module coverage); fall back to HCL mode if planning
   isn't possible. Common failure modes are EITHER `terraform init`
   failing on a missing/locked remote backend, OR `terraform plan`
   failing on missing variables / "(known after apply)" / etc. Both
   are recoverable.

   - **Plan-JSON (preferred):**

         terraform init
         terraform plan -out plan.bin
         terraform show -json plan.bin > plan.json
         efterlev scan --plan plan.json

     If `terraform init` fails with a missing S3/Terraform Cloud
     backend (very common when scanning a repo you don't operate),
     skip the remote-state machinery:

         terraform init -backend=false
         terraform plan -refresh=false -out plan.bin
         terraform show -json plan.bin > plan.json
         efterlev scan --plan plan.json

     **Reality check:** some repos have a `terraform { backend "s3" {} }`
     block that `-refresh=false` doesn't bypass — `terraform plan`
     still tries to acquire backend state. If you see "Backend
     initialization required" after the `-backend=false` workaround,
     drop straight to HCL mode. Don't burn 5 minutes on the dance.

     If `terraform plan` STILL fails on missing required variables,
     create a throwaway `.tfvars` with placeholders and pass it via
     `-var-file`. If both routes fail, drop to HCL mode.

   - **HCL fallback:** `efterlev scan`. Keeps HCL line numbers in
     citations (which plan-JSON loses); the trade-off is missed
     coverage on resources defined inside upstream modules.

## Step 5 — agents and a useful brief

1. Run `efterlev agent gap` (~60–90s; ~$0.30–1 on Sonnet, ~$1–2 on
   Opus). Print the absolute path to the HTML report.

2. **Read the gap-report JSON** at
   `.efterlev/reports/gap-<ts>.json` (newest one) and tell me:
   - The classification breakdown — count of `implemented` /
     `partial` / `not_implemented` / `not_applicable` /
     `evidence_layer_inapplicable`.
   - Workspace boundary state (`workspace_boundary_state` field) —
     if `boundary_undeclared`, recommend running
     `efterlev boundary set --include 'pattern' --exclude 'pattern'`
     so the POA&M filter has scope to enforce. Important: if I declare
     `--include 'infra/terraform/**'`, ALL workflow evidence
     (`.github/workflows/*.yml`) becomes `out_of_boundary` because
     workflows aren't under `infra/terraform/`. To keep workflow
     findings in scope, pass two patterns:
     `--include 'infra/terraform/**' --include '.github/workflows/**'`.
   - **Top 3 KSIs to focus on**: pick the highest-impact
     `not_implemented` classifications. Bias toward the SVC theme
     (encryption, integrity, transport) and IAM (MFA, federation)
     since those are typically the most-cited finding categories
     in 3PAO reviews. For each, give me one sentence: KSI id +
     name, one-line rationale from the report, and the canonical
     fix.
   - Any KSI classified `partial` — these are the texture cases
     where `efterlev agent remediate --ksi <id>` produces the most
     useful diff (mid-journey, not zero-to-one). Surface 2 of them.

3. Ask if I also want:
   - Narratives: `efterlev agent document` (~$1–2 on Sonnet —
     always Sonnet by design; the job is structured extractive
     writing, not novel reasoning).
   - POA&M markdown: `efterlev poam` (free, deterministic — no
     LLM call). Lands at `.efterlev/reports/poam/poam-<ts>.md`.

4. After document + poam complete, surface ONE more brief:
   - The mode breakdown of the documentation report —
     `agent_drafted` vs `deterministic_template` counts. The
     `deterministic_template` rows are inapplicable KSIs that
     skipped the LLM (the cost-saving path; ~70% of Sonnet spend
     would have been wasted on procedural-only KSIs without it).
   - The POA&M's open-item count and out-of-boundary-excluded
     count.

## Constraints

- Don't run `efterlev agent remediate` without me asking — it generates
  code-level diffs and I want to be in the loop.
- Don't modify my Terraform. Don't commit anything.
- Soft cost cap: $3 on the Anthropic path, $5 on the Bedrock path
  (Bedrock retries can burn more on first-run config issues). Stop and
  check back before exceeding.
- If anything fails or surprises you, stop and ask — don't paper over.

## When done

Brief me with:
- Counts of `implemented` / `partial` / `not_implemented` /
  `evidence_layer_inapplicable` KSIs.
- Paths to the gap report, FRMR JSON, and POA&M markdown.
- Anything notable: secrets caught by the redaction layer, KSIs flagged
  for review, modules where evidence was sparse.
```
