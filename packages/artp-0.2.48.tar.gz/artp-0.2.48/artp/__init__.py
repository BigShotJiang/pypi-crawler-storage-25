﻿"""ARTp Library - набор крутых приложений на tkinter"""
from pathlib import Path
import tkinter as tk
from tkinter import scrolledtext, messagebox, ttk
import random
import time
from datetime import datetime
import os
import sys
import subprocess
import urllib.request
import threading
from tkinter import filedialog
import json
import platform
__version__ = '0.3.0'


class AppNotepad:
    """Блокнот"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('📝 Блокнот - ARTp')
        root.geometry('700x500')

        text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=('Consolas', 11))
        text_area.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        menubar = tk.Menu(root)
        file_menu = tk.Menu(menubar, tearoff=0)

        def clear_text():
            text_area.delete(1.0, tk.END)

        file_menu.add_command(label='🗑 Очистить', command=clear_text)
        file_menu.add_separator()
        file_menu.add_command(label='❌ Выход', command=root.quit)

        menubar.add_cascade(label='📁 Файл', menu=file_menu)
        root.config(menu=menubar)
        root.mainloop()


class AppCalculator:
    """Калькулятор"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🧮 Калькулятор - ARTp')
        root.geometry('300x450')
        root.resizable(False, False)

        entry = tk.Entry(root, font=('Arial', 24), justify='right', bd=10)
        entry.pack(fill=tk.BOTH, padx=10, pady=10)

        buttons = ['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '=', '+']

        def click(btn):
            if btn == '=':
                try:
                    result = eval(entry.get())
                    entry.delete(0, tk.END)
                    entry.insert(0, str(result))
                except:
                    entry.delete(0, tk.END)
                    entry.insert(0, "Ошибка")
            else:
                entry.insert(tk.END, btn)

        def clear():
            entry.delete(0, tk.END)

        btn_frame = tk.Frame(root)
        btn_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        row, col = 0, 0
        for btn in buttons:
            cmd = lambda x=btn: click(x)
            tk.Button(btn_frame, text=btn, width=5, height=2, font=('Arial', 14), command=cmd).grid(row=row, column=col, padx=3, pady=3)
            col += 1
            if col > 3:
                col = 0
                row += 1

        tk.Button(btn_frame, text='C', width=5, height=2, font=('Arial', 14), bg='red', fg='white', command=clear).grid(row=row, column=0, columnspan=4, sticky='we', padx=3, pady=3)
        root.mainloop()


class AppViktorina:
    """Викторина"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🎯 Викторина - ARTp')
        root.geometry('500x400')

        questions = [
            {"question": "Какой цвет у неба?", "options": ["Красный", "Синий", "Зелёный", "Жёлтый"], "answer": 1},
            {"question": "Сколько дней в неделе?", "options": ["5", "6", "7", "8"], "answer": 2},
            {"question": "Кто написал 'Войну и мир'?", "options": ["Достоевский", "Толстой", "Пушкин", "Чехов"], "answer": 1},
            {"question": "Столица России?", "options": ["СПБ", "Новосибирск", "Москва", "Казань"], "answer": 2},
            {"question": "Python - это...?", "options": ["Змея", "Язык программирования", "И то и другое", "Ни то ни другое"], "answer": 2}
        ]

        current_q = 0
        score = 0

        question_label = tk.Label(root, text="", font=('Arial', 14), wraplength=450)
        question_label.pack(pady=20)

        var = tk.IntVar()
        radio_buttons = []
        frame = tk.Frame(root)
        frame.pack(pady=10)

        for i in range(4):
            rb = tk.Radiobutton(frame, text="", variable=var, value=i, font=('Arial', 11))
            rb.pack(anchor='w', pady=5)
            radio_buttons.append(rb)

        def check_answer():
            nonlocal current_q, score
            if var.get() == questions[current_q]["answer"]:
                score += 1
                messagebox.showinfo("✅ Правильно!", f"Верно! +1 балл\nТекущий счёт: {score}")
            else:
                correct = questions[current_q]["options"][questions[current_q]["answer"]]
                messagebox.showinfo("❌ Неправильно", f"Правильный ответ: {correct}\nСчёт: {score}")

            current_q += 1
            if current_q < len(questions):
                show_question()
            else:
                messagebox.showinfo("🎉 Игра окончена!", f"Твой результат: {score} из {len(questions)}")
                root.destroy()

        def show_question():
            q = questions[current_q]
            question_label.config(text=q["question"])
            for i, rb in enumerate(radio_buttons):
                rb.config(text=q["options"][i])
            var.set(-1)

        submit_btn = tk.Button(root, text="Ответить", font=('Arial', 12), bg='green', fg='white', command=check_answer)
        submit_btn.pack(pady=20)
        show_question()
        root.mainloop()


class AppDigitalClock:
    """Цифровые часы"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🕐 Цифровые часы - ARTp')
        root.geometry('400x200')
        root.configure(bg='black')

        time_label = tk.Label(root, font=('Digital', 70, 'bold'), bg='black', fg='lime')
        time_label.pack(expand=True, fill=tk.BOTH)
        date_label = tk.Label(root, font=('Arial', 20), bg='black', fg='white')
        date_label.pack()

        def update_time():
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            current_date = now.strftime("%d.%m.%Y")
            time_label.config(text=current_time)
            date_label.config(text=current_date)
            root.after(1000, update_time)

        update_time()
        root.mainloop()


class AppColorPicker:
    """Палитра цветов"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🎨 Палитра цветов - ARTp')
        root.geometry('500x400')

        color_box = tk.Label(root, bg='white', width=50, height=10)
        color_box.pack(pady=20)

        def change_color():
            color = color_var.get()
            color_box.config(bg=color)
            hex_label.config(text=color)

        colors = ['red', 'green', 'blue', 'yellow', 'purple', 'orange', 'pink', 'cyan', 'white', 'black']
        color_var = tk.StringVar(value='white')

        color_listbox = tk.Listbox(root, height=6)
        for c in colors:
            color_listbox.insert(tk.END, c)
        color_listbox.pack(pady=10)
        color_listbox.bind('<<ListboxSelect>>', lambda e: change_color())

        hex_label = tk.Label(root, text='white', font=('Arial', 14))
        hex_label.pack()
        root.mainloop()


# ============ НОВЫЕ 10 ПРИЛОЖЕНИЙ ============

class AppSnake:
    """Игра Змейка"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🐍 Змейка - ARTp')
        root.resizable(False, False)

        WIDTH, HEIGHT = 400, 400
        CELL_SIZE = 20
        canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg='black')
        canvas.pack()

        snake = [(100, 100), (80, 100), (60, 100)]
        direction = 'Right'
        dx, dy = CELL_SIZE, 0

        def create_food():
            while True:
                x = random.randint(0, (WIDTH//CELL_SIZE)-1) * CELL_SIZE
                y = random.randint(0, (HEIGHT//CELL_SIZE)-1) * CELL_SIZE
                if (x, y) not in snake:
                    return x, y

        food = create_food()
        score = 0
        score_label = tk.Label(root, text=f'Счёт: {score}', font=('Arial', 14))
        score_label.pack()

        def move():
            nonlocal dx, dy, direction, food, score
            head_x, head_y = snake[0]
            new_head = (head_x + dx, head_y + dy)

            if new_head == food:
                score += 1
                score_label.config(text=f'Счёт: {score}')
                snake.insert(0, new_head)
                food = create_food()
                canvas.delete('food')
                draw_food(food)
            else:
                snake.insert(0, new_head)
                snake.pop()

            if new_head in snake[1:] or new_head[0] < 0 or new_head[0] >= WIDTH or new_head[1] < 0 or new_head[1] >= HEIGHT:
                game_over()
                return

            draw()
            root.after(150, move)

        def draw():
            canvas.delete('all')
            for segment in snake:
                canvas.create_rectangle(segment[0], segment[1], segment[0]+CELL_SIZE, segment[1]+CELL_SIZE, fill='green')
            draw_food(food)

        def draw_food(pos):
            canvas.create_oval(pos[0], pos[1], pos[0]+CELL_SIZE, pos[1]+CELL_SIZE, fill='red', tag='food')

        def change_direction(new_dir):
            nonlocal direction, dx, dy
            if new_dir == 'Left' and direction != 'Right':
                dx, dy = -CELL_SIZE, 0
                direction = new_dir
            elif new_dir == 'Right' and direction != 'Left':
                dx, dy = CELL_SIZE, 0
                direction = new_dir
            elif new_dir == 'Up' and direction != 'Down':
                dx, dy = 0, -CELL_SIZE
                direction = new_dir
            elif new_dir == 'Down' and direction != 'Up':
                dx, dy = 0, CELL_SIZE
                direction = new_dir

        def game_over():
            canvas.create_text(WIDTH//2, HEIGHT//2, text=f'Game Over! Счёт: {score}', fill='white', font=('Arial', 20))

        root.bind('<Left>', lambda e: change_direction('Left'))
        root.bind('<Right>', lambda e: change_direction('Right'))
        root.bind('<Up>', lambda e: change_direction('Up'))
        root.bind('<Down>', lambda e: change_direction('Down'))

        draw_food(food)
        move()
        root.mainloop()


class AppTicTacToe:
    """Крестики-нолики"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('⭕ Крестики-нолики - ARTp')

        board = [''] * 9
        current_player = 'X'
        buttons = []

        def check_winner():
            wins = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
            for a,b,c in wins:
                if board[a] == board[b] == board[c] and board[a]:
                    return board[a]
            if all(board):
                return 'Ничья'
            return None

        def click(pos):
            nonlocal current_player
            if board[pos] == '':
                board[pos] = current_player
                buttons[pos].config(text=current_player)
                winner = check_winner()
                if winner:
                    if winner == 'Ничья':
                        messagebox.showinfo('Игра окончена', 'Ничья!')
                    else:
                        messagebox.showinfo('Игра окончена', f'Победил {winner}!')
                    root.quit()
                else:
                    current_player = 'O' if current_player == 'X' else 'X'

        frame = tk.Frame(root)
        frame.pack()
        for i in range(9):
            btn = tk.Button(frame, text='', width=10, height=3, font=('Arial', 20), command=lambda i=i: click(i))
            btn.grid(row=i//3, column=i%3)
            buttons.append(btn)

        root.mainloop()


class AppTodo:
    """Список дел"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('📝 Список дел - ARTp')
        root.geometry('400x500')

        tasks = []

        def add_task():
            task = entry.get()
            if task:
                tasks.append(task)
                update_list()
                entry.delete(0, tk.END)

        def delete_task():
            selected = listbox.curselection()
            if selected:
                tasks.pop(selected[0])
                update_list()

        def update_list():
            listbox.delete(0, tk.END)
            for task in tasks:
                listbox.insert(tk.END, task)

        entry = tk.Entry(root, font=('Arial', 14))
        entry.pack(fill=tk.X, padx=10, pady=10)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5)
        tk.Button(btn_frame, text='➕ Добавить', command=add_task, bg='green', fg='white').pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text='❌ Удалить', command=delete_task, bg='red', fg='white').pack(side=tk.LEFT, padx=5)

        listbox = tk.Listbox(root, font=('Arial', 12))
        listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        root.mainloop()


class AppPasswordGen:
    """Генератор паролей"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🔐 Генератор паролей - ARTp')
        root.geometry('400x300')

        def generate():
            length = int(length_var.get())
            chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*'
            password = ''.join(random.choice(chars) for _ in range(length))
            password_var.set(password)

        def copy():
            root.clipboard_clear()
            root.clipboard_append(password_var.get())
            messagebox.showinfo('Скопировано', 'Пароль скопирован в буфер обмена!')

        tk.Label(root, text='Генератор паролей', font=('Arial', 18)).pack(pady=10)

        frame = tk.Frame(root)
        frame.pack(pady=10)
        tk.Label(frame, text='Длина:').pack(side=tk.LEFT)
        length_var = tk.StringVar(value='12')
        tk.Spinbox(frame, from_=4, to=32, textvariable=length_var, width=5).pack(side=tk.LEFT, padx=5)

        tk.Button(root, text='🔄 Сгенерировать', command=generate, bg='blue', fg='white', font=('Arial', 12)).pack(pady=10)

        password_var = tk.StringVar()
        tk.Entry(root, textvariable=password_var, font=('Arial', 14), justify='center', state='readonly').pack(fill=tk.X, padx=20, pady=10)
        tk.Button(root, text='📋 Копировать', command=copy, bg='green', fg='white').pack(pady=5)

        root.mainloop()


class AppWeather:
    """Погода (демо)"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🌤️ Погода - ARTp')
        root.geometry('400x300')

        weather_data = {
            'Москва': {'temp': '+5°C', 'desc': 'облачно'},
            'СПБ': {'temp': '+3°C', 'desc': 'дождь'},
            'Новосибирск': {'temp': '-15°C', 'desc': 'снег'},
            'Сочи': {'temp': '+12°C', 'desc': 'солнечно'}
        }

        def show_weather():
            city = city_var.get()
            if city in weather_data:
                data = weather_data[city]
                result_var.set(f'{city}: {data["temp"]}, {data["desc"]}')
            else:
                result_var.set(f'Нет данных для {city}')

        tk.Label(root, text='Погода в городах', font=('Arial', 18)).pack(pady=10)

        city_var = tk.StringVar(value='Москва')
        cities = list(weather_data.keys())
        tk.OptionMenu(root, city_var, *cities).pack(pady=10)

        tk.Button(root, text='Узнать погоду', command=show_weather, bg='blue', fg='white', font=('Arial', 12)).pack(pady=10)

        result_var = tk.StringVar()
        tk.Label(root, textvariable=result_var, font=('Arial', 14), wraplength=350).pack(pady=20)

        root.mainloop()


class AppSysInfo:
    """Информация о системе"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('💻 Инфо о системе - ARTp')
        root.geometry('500x400')

        info = f"""
📋 СИСТЕМНАЯ ИНФОРМАЦИЯ

💻 ОС: {sys.platform}
🐍 Python: {sys.version.split()[0]}
📁 Текущая папка: {os.getcwd()}
🧵 Версия tkinter: {tk.TkVersion}
        """

        text = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=('Consolas', 11))
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        text.insert(1.0, info)
        text.config(state='disabled')

        root.mainloop()


class Minecraft_1_11_2:
    """Запуск Minecraft 1.11.2 - РАБОЧАЯ ВЕРСИЯ"""

    MINECRAFT_DIR = Path(os.path.expanduser("~")) / ".minecraft_1_11_2"

    # ВСЕ ФАЙЛЫ ДЛЯ 1.11.2
    FILES = {
        "1.11.2.jar": "https://piston-data.mojang.com/v1/objects/db5aa600f0b0bf508aaf579509b345c4e34087be/client.jar",
        "1.11.2.json": "https://piston-meta.mojang.com/v1/packages/6bd228727ed48bd7ac7bdc0088587dad0fb7c02b/1.11.2.json",
    }

    @staticmethod
    def check_java():
        """Проверяет наличие 64-битной Java 8"""
        java_paths = [
            r"C:\Program Files\Java\jre1.8.0_491\bin\java.exe",
            r"C:\Program Files\Java\jre1.8.0_421\bin\java.exe",
            r"C:\Program Files\Java\jre1.8.0_391\bin\java.exe",
        ]

        for path in java_paths:
            if os.path.exists(path):
                try:
                    result = subprocess.run([path, "-version"], capture_output=True, text=True)
                    if "64-Bit" in result.stderr or "64-Bit" in result.stdout:
                        return path
                except:
                    pass

        answer = messagebox.askyesno(
            "❌ Java 8 не найдена",
            "Для запуска Minecraft 1.11.2 нужна Java 8 (64-bit)!\n\nСкачать и установить Java 8?"
        )

        if answer:
            import webbrowser
            webbrowser.open(
                "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=251090_3d5a2bb8f8d4428bbe94aed7ec7ae784")
            messagebox.showinfo("Инструкция", "1. Скачай установщик\n2. Установи Java 8\n3. Перезапусти игру")
        return None

    @staticmethod
    def download_libraries(version_json_path):
        """Скачивает все библиотеки из JSON"""
        import json
        with open(version_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        libraries_dir = Minecraft_1_11_2.MINECRAFT_DIR / "libraries"
        libraries_dir.mkdir(parents=True, exist_ok=True)

        downloaded = []

        for lib in data.get("libraries", []):
            if "rules" in lib:
                skip = False
                for rule in lib["rules"]:
                    if rule.get("action") == "disallow":
                        skip = True
                        break
                if skip:
                    continue

            if "downloads" in lib and "artifact" in lib["downloads"]:
                artifact = lib["downloads"]["artifact"]
                url = artifact["url"]
                path = libraries_dir / artifact["path"]
                path.parent.mkdir(parents=True, exist_ok=True)

                if not path.exists():
                    try:
                        urllib.request.urlretrieve(url, path)
                    except:
                        pass
                downloaded.append(str(path))

        return downloaded

    @staticmethod
    def download_natives(version_json_path):
        """Скачивает нативные библиотеки"""
        import json
        with open(version_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        natives_dir = Minecraft_1_11_2.MINECRAFT_DIR / "natives"
        natives_dir.mkdir(exist_ok=True)

        import zipfile
        for lib in data.get("libraries", []):
            if "downloads" in lib and "classifiers" in lib["downloads"]:
                for classifier, artifact in lib["downloads"]["classifiers"].items():
                    if "natives" in classifier and classifier.startswith("natives-windows"):
                        url = artifact["url"]
                        jar_path = Minecraft_1_11_2.MINECRAFT_DIR / artifact["path"]
                        jar_path.parent.mkdir(parents=True, exist_ok=True)

                        if not jar_path.exists():
                            try:
                                urllib.request.urlretrieve(url, jar_path)
                            except:
                                continue

                        # Распаковываем DLL
                        if jar_path.exists():
                            with zipfile.ZipFile(jar_path, 'r') as z:
                                for file in z.namelist():
                                    if file.endswith('.dll'):
                                        z.extract(file, natives_dir)

        return natives_dir

    @staticmethod
    def download_assets(version_json_path):
        """Скачивает ассеты"""
        import json
        with open(version_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        assets_dir = Minecraft_1_11_2.MINECRAFT_DIR / "assets"
        assets_dir.mkdir(exist_ok=True)

        # Создаём иконки
        icons_dir = assets_dir / "icons"
        icons_dir.mkdir(exist_ok=True)

        for icon in ["icon_16x16.png", "icon_32x32.png"]:
            icon_path = icons_dir / icon
            if not icon_path.exists():
                with open(icon_path, 'wb') as f:
                    f.write(
                        b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82')

        return assets_dir

    @staticmethod
    def run():
        java_cmd = Minecraft_1_11_2.check_java()
        if not java_cmd:
            return

        root = tk.Tk()
        root.title("🎮 Minecraft 1.11.2")
        root.geometry("550x500")
        root.configure(bg='#2d2d2d')

        tk.Label(root, text="MINECRAFT 1.11.2", font=('Arial', 20, 'bold'),
                 bg='#2d2d2d', fg='#ffaa00').pack(pady=20)

        # ИНСТРУКЦИЯ
        info_frame = tk.Frame(root, bg='#2d2d2d', relief='solid', bd=1)
        info_frame.pack(pady=5, padx=10, fill='x')

        tk.Label(info_frame, text="💡 Если кнопки не нажимаются:",
                 bg='#2d2d2d', fg='#ffaa00', font=('Arial', 10, 'bold')).pack()
        tk.Label(info_frame, text="   1. Нажми ALT + ENTER (два раза)",
                 bg='#2d2d2d', fg='white', font=('Arial', 9)).pack(anchor='w')
        tk.Label(info_frame, text="   2. Или нажми F11 два раза",
                 bg='#2d2d2d', fg='white', font=('Arial', 9)).pack(anchor='w')

        log = scrolledtext.ScrolledText(root, height=10, bg='#1e1e1e', fg='#00ff00', font=('Consolas', 9))
        log.pack(fill='both', expand=True, padx=10, pady=10)

        def add(msg):
            log.insert(tk.END, msg + "\n")
            log.see(tk.END)
            root.update()

        def download_all():
            Minecraft_1_11_2.MINECRAFT_DIR.mkdir(parents=True, exist_ok=True)

            for filename, url in Minecraft_1_11_2.FILES.items():
                filepath = Minecraft_1_11_2.MINECRAFT_DIR / filename
                if not filepath.exists():
                    add(f"📥 Скачиваем {filename}...")
                    try:
                        urllib.request.urlretrieve(url, filepath)
                        add(f"✅ {filename}")
                    except:
                        add(f"❌ Ошибка: {filename}")
                        return False
                else:
                    add(f"✅ {filename} уже есть")
            return True

        def launch():
            add("🚀 Подготовка...")

            if not download_all():
                add("❌ Ошибка загрузки!")
                return

            json_path = Minecraft_1_11_2.MINECRAFT_DIR / "1.11.2.json"

            add("📚 Скачиваем библиотеки...")
            libraries = Minecraft_1_11_2.download_libraries(json_path)
            add(f"✅ Загружено {len(libraries)} библиотек")

            add("📦 Скачиваем нативные библиотеки...")
            natives_dir = Minecraft_1_11_2.download_natives(json_path)
            add(f"✅ Нативы в {natives_dir}")

            add("🎨 Подготавливаем ассеты...")
            Minecraft_1_11_2.download_assets(json_path)

            # Формируем classpath
            client_jar = Minecraft_1_11_2.MINECRAFT_DIR / "1.11.2.jar"
            classpath = [str(client_jar)] + libraries
            classpath_str = ';'.join(classpath)

            cmd = [
                java_cmd,
                f"-Djava.library.path={natives_dir}",
                "-Xmx1024M",
                "-cp", classpath_str,
                "net.minecraft.client.main.Main",
                "--username", "Player",
                "--version", "1.11.2",
                "--gameDir", str(Minecraft_1_11_2.MINECRAFT_DIR / "game"),
                "--assetsDir", str(Minecraft_1_11_2.MINECRAFT_DIR / "assets"),
                "--assetIndex", "1.11.2",
                "--accessToken", "artp_launcher",
                "--userProperties", "{}",
                "--width", "854",
                "--height", "480"
            ]

            add("🎮 Запуск Minecraft 1.11.2...")
            root.destroy()

            try:
                subprocess.Popen(cmd)
                messagebox.showinfo("Успех!",
                                    "Minecraft 1.11.2 запущен!\n\n"
                                    "⚠️ Если кнопки не нажимаются:\n"
                                    "• Нажми ALT + ENTER два раза\n"
                                    "• Или нажми F11 два раза")
            except Exception as e:
                messagebox.showerror("Ошибка", str(e))

        tk.Button(root, text="🚀 ЗАПУСТИТЬ", command=launch,
                  bg='green', fg='white', font=('Arial', 14)).pack(pady=10)

        tk.Label(root, text=f"📁 {Minecraft_1_11_2.MINECRAFT_DIR}",
                 bg='#2d2d2d', fg='gray', font=('Arial', 8)).pack()

        root.mainloop()
class AppTyping:
    """Тренажёр печати"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('⌨️ Тренажёр печати - ARTp')
        root.geometry('600x400')

        texts = [
            "Привет мир! Это тест скорости печати.",
            "Python - отличный язык программирования.",
            "Быстрая печать развивает навыки работы с компьютером."
        ]
        current_text = random.choice(texts)

        start_time = None
        finished = False

        def start_typing(event=None):
            nonlocal start_time
            if start_time is None:
                start_time = time.time()

        def check_result():
            nonlocal finished
            if finished:
                return
            entered = entry.get(1.0, tk.END).strip()
            if entered == current_text:
                end_time = time.time()
                elapsed = end_time - start_time
                chars = len(entered)
                speed = (chars / elapsed) * 60
                messagebox.showinfo('Результат', f'Время: {elapsed:.1f} сек\nСкорость: {speed:.0f} символов/мин')
                finished = True
            else:
                messagebox.showerror('Ошибка', 'Текст не совпадает! Попробуйте ещё раз')

        tk.Label(root, text='Напечатайте этот текст:', font=('Arial', 12)).pack(pady=5)
        tk.Label(root, text=current_text, font=('Arial', 14), wraplength=550, bg='lightyellow').pack(pady=10)

        tk.Label(root, text='Ваш текст:', font=('Arial', 12)).pack(pady=5)
        entry = scrolledtext.ScrolledText(root, height=5, font=('Arial', 12), wrap=tk.WORD)
        entry.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        entry.bind('<KeyPress>', start_typing)

        tk.Button(root, text='✅ Проверить', command=check_result, bg='green', fg='white', font=('Arial', 12)).pack(pady=10)

        root.mainloop()


# 1. Добавляешь класс
class AppRPS:
    """Камень-ножницы-бумага"""

    @staticmethod
    def run():
        root = tk.Tk()
        root.title('✊ Камень-ножницы-бумага - ARTp')
        root.geometry('400x300')

        result_label = tk.Label(root, text='Сделай ход!', font=('Arial', 16))
        result_label.pack(pady=20)

        def play(player_choice):
            choices = ['✊ Камень', '✌️ Ножницы', '✋ Бумага']
            bot_choice = random.choice(choices)

            if player_choice == bot_choice:
                result = '🤝 Ничья!'
            elif (player_choice == '✊ Камень' and bot_choice == '✌️ Ножницы') or \
                    (player_choice == '✌️ Ножницы' and bot_choice == '✋ Бумага') or \
                    (player_choice == '✋ Бумага' and bot_choice == '✊ Камень'):
                result = '🎉 Ты выиграл!'
            else:
                result = '😞 Ты проиграл!'

            result_label.config(text=f'Ты: {player_choice}\nБот: {bot_choice}\n{result}')

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=20)

        tk.Button(btn_frame, text='✊ Камень', command=lambda: play('✊ Камень'), width=12).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text='✌️ Ножницы', command=lambda: play('✌️ Ножницы'), width=12).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text='✋ Бумага', command=lambda: play('✋ Бумага'), width=12).pack(side=tk.LEFT, padx=5)

        root.mainloop()


class Minecraft_1_5_2:
    """Запуск Minecraft 1.5.2 - РАБОЧАЯ ВЕРСИЯ"""

    MINECRAFT_DIR = Path(os.path.expanduser("~")) / ".minecraft_artp"

    # ВСЕ ФАЙЛЫ С ОФИЦИАЛЬНЫХ ИСТОЧНИКОВ
    FILES = {
        "1.5.2.jar": "https://launcher.mojang.com/v1/objects/e6e87f2b0c8fdee2a7f8e1ae7e0d6e0f8e7e8e0/1.5.2.jar",
        "launchwrapper-1.5.jar": "https://libraries.minecraft.net/net/minecraft/launchwrapper/1.5/launchwrapper-1.5.jar",
        "jopt-simple.jar": "https://repo1.maven.org/maven2/net/sf/jopt-simple/jopt-simple/4.6/jopt-simple-4.6.jar",
        "log4j-api.jar": "https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-api/2.0-beta9/log4j-api-2.0-beta9.jar",
        "log4j-core.jar": "https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/2.0-beta9/log4j-core-2.0-beta9.jar",
        "asm-all.jar": "https://repo1.maven.org/maven2/org/ow2/asm/asm-all/5.2/asm-all-5.2.jar",
        "lwjgl.jar": "https://repo1.maven.org/maven2/org/lwjgl/lwjgl/lwjgl/2.9.1/lwjgl-2.9.1.jar",
        "lwjgl_util.jar": "https://repo1.maven.org/maven2/org/lwjgl/lwjgl/lwjgl_util/2.9.1/lwjgl_util-2.9.1.jar",
        "jinput.jar": "https://repo1.maven.org/maven2/net/java/jinput/jinput/2.0.5/jinput-2.0.5.jar",
    }

    @staticmethod
    def check_java():
        """Проверяет наличие 64-битной Java 8"""
        java_paths = [
            r"C:\Program Files\Java\jre1.8.0_491\bin\java.exe",
            r"C:\Program Files\Java\jre1.8.0_421\bin\java.exe",
            r"C:\Program Files\Java\jre1.8.0_391\bin\java.exe",
        ]

        for path in java_paths:
            if os.path.exists(path):
                try:
                    result = subprocess.run([path, "-version"], capture_output=True, text=True)
                    if "64-Bit" in result.stderr or "64-Bit" in result.stdout:
                        return path
                except:
                    pass

        answer = messagebox.askyesno(
            "❌ Java 8 не найдена",
            "Для запуска Minecraft 1.5.2 нужна Java 8 (64-bit)!\n\nСкачать и установить Java 8?"
        )

        if answer:
            import webbrowser
            webbrowser.open(
                "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=251090_3d5a2bb8f8d4428bbe94aed7ec7ae784")
            messagebox.showinfo("Инструкция", "1. Скачай установщик\n2. Установи Java 8\n3. Перезапусти игру")
        return None

    @staticmethod
    def run():
        java_cmd = Minecraft_1_5_2.check_java()
        if not java_cmd:
            return

        root = tk.Tk()
        root.title("🎮 Minecraft 1.5.2")
        root.geometry("550x500")
        root.configure(bg='#2d2d2d')

        tk.Label(root, text="MINECRAFT 1.5.2", font=('Arial', 20, 'bold'),
                 bg='#2d2d2d', fg='#ffaa00').pack(pady=20)

        # ИНСТРУКЦИЯ ПО КНОПКАМ
        info_frame = tk.Frame(root, bg='#2d2d2d', relief='solid', bd=1)
        info_frame.pack(pady=5, padx=10, fill='x')

        tk.Label(info_frame, text="💡 Если кнопки не нажимаются:",
                 bg='#2d2d2d', fg='#ffaa00', font=('Arial', 10, 'bold')).pack()
        tk.Label(info_frame, text="   1. Нажми ALT + ENTER (два раза)",
                 bg='#2d2d2d', fg='white', font=('Arial', 9)).pack(anchor='w')
        tk.Label(info_frame, text="   2. Или нажми F11 два раза",
                 bg='#2d2d2d', fg='white', font=('Arial', 9)).pack(anchor='w')
        tk.Label(info_frame, text="   3. Или перетащи окно мышкой",
                 bg='#2d2d2d', fg='white', font=('Arial', 9)).pack(anchor='w')

        log = scrolledtext.ScrolledText(root, height=10, bg='#1e1e1e', fg='#00ff00', font=('Consolas', 9))
        log.pack(fill='both', expand=True, padx=10, pady=10)

        def add(msg):
            log.insert(tk.END, msg + "\n")
            log.see(tk.END)
            root.update()

        def download_natives():
            natives_jar = Minecraft_1_5_2.MINECRAFT_DIR / "natives.jar"
            natives_dir = Minecraft_1_5_2.MINECRAFT_DIR / "natives"
            natives_dir.mkdir(exist_ok=True)

            url = "https://repo1.maven.org/maven2/org/lwjgl/lwjgl/lwjgl-platform/2.9.1/lwjgl-platform-2.9.1-natives-windows.jar"

            if not natives_jar.exists():
                add("📥 Скачиваем нативные библиотеки...")
                urllib.request.urlretrieve(url, natives_jar)

            add("📦 Распаковываем DLL...")
            import zipfile
            with zipfile.ZipFile(natives_jar, 'r') as z:
                for file in z.namelist():
                    if file.endswith('.dll'):
                        z.extract(file, natives_dir)
            add("✅ DLL готовы")
            return natives_dir

        def download_all():
            Minecraft_1_5_2.MINECRAFT_DIR.mkdir(parents=True, exist_ok=True)

            for filename, url in Minecraft_1_5_2.FILES.items():
                filepath = Minecraft_1_5_2.MINECRAFT_DIR / filename
                if not filepath.exists():
                    add(f"📥 Скачиваем {filename}...")
                    try:
                        urllib.request.urlretrieve(url, filepath)
                        add(f"✅ {filename}")
                    except:
                        add(f"❌ Ошибка: {filename}")
                        return False
                else:
                    add(f"✅ {filename} уже есть")
            return True

        def download_assets():
            assets_dir = Minecraft_1_5_2.MINECRAFT_DIR / "assets"
            assets_dir.mkdir(exist_ok=True)
            icons_dir = assets_dir / "icons"
            icons_dir.mkdir(exist_ok=True)

            for icon in ["icon_16x16.png", "icon_32x32.png"]:
                icon_path = icons_dir / icon
                if not icon_path.exists():
                    with open(icon_path, 'wb') as f:
                        f.write(
                            b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82')
            return assets_dir

        def launch():
            add("🚀 Подготовка...")

            if not download_all():
                add("❌ Ошибка загрузки!")
                return

            natives_dir = download_natives()
            download_assets()

            jars = [
                Minecraft_1_5_2.MINECRAFT_DIR / "1.5.2.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "launchwrapper-1.5.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "jopt-simple.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "log4j-api.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "log4j-core.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "asm-all.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "lwjgl.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "lwjgl_util.jar",
                Minecraft_1_5_2.MINECRAFT_DIR / "jinput.jar"
            ]
            classpath = ';'.join(str(j) for j in jars)

            cmd = [
                java_cmd,
                "-noverify",
                f"-Djava.library.path={natives_dir}",
                "-Xmx1024M",
                "-cp", classpath,
                "net.minecraft.launchwrapper.Launch",
                "--username", "Player",
                "--version", "1.5.2",
                "--gameDir", str(Minecraft_1_5_2.MINECRAFT_DIR / "game"),
                "--assetsDir", str(Minecraft_1_5_2.MINECRAFT_DIR / "assets"),
                "--assetIndex", "1.5.2",
                "--accessToken", "artp_launcher",
                "--userProperties", "{}",
                "--width", "854",
                "--height", "480"
            ]

            add("🎮 Запуск Minecraft...")
            root.destroy()

            try:
                subprocess.Popen(cmd)
                messagebox.showinfo("Успех!",
                                    "Minecraft 1.5.2 запущен!\n\n"
                                    "⚠️ Если кнопки не нажимаются:\n"
                                    "• Нажми ALT + ENTER два раза\n"
                                    "• Или нажми F11 два раза\n"
                                    "• Или просто перетащи окно")
            except Exception as e:
                messagebox.showerror("Ошибка", str(e))

        tk.Button(root, text="🚀 ЗАПУСТИТЬ", command=launch,
                  bg='green', fg='white', font=('Arial', 14)).pack(pady=10)

        tk.Label(root, text=f"📁 {Minecraft_1_5_2.MINECRAFT_DIR}",
                 bg='#2d2d2d', fg='gray', font=('Arial', 8)).pack()

        root.mainloop()

class AppGameCenter:
    """Игровой центр - Java + Minecraft (с твоими ссылками)"""

    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🎮 Игровой центр - ARTp')
        root.geometry('550x550')
        root.configure(bg='#2d2d2d')

        tk.Label(root, text='ИГРОВОЙ ЦЕНТР', font=('Arial', 20, 'bold'),
                 bg='#2d2d2d', fg='#ffaa00').pack(pady=15)

        # Статус Java
        java_status = tk.Label(root, text='☕ Проверка Java...',
                               bg='#2d2d2d', fg='white', font=('Arial', 11))
        java_status.pack(pady=5)

        # Проверяем Java
        java_installed = False
        try:
            result = subprocess.run(['java', '-version'], capture_output=True, text=True)
            if result.returncode == 0:
                java_installed = True
                version_text = result.stderr.split('\n')[0] if result.stderr else result.stdout.split('\n')[0]
                java_status.config(text=f'☕ Java: ✅ Установлена ({version_text})', fg='lightgreen')
            else:
                java_status.config(text='☕ Java: ❌ Не найдена!', fg='red')
        except FileNotFoundError:
            java_status.config(text='☕ Java: ❌ Не найдена!', fg='red')

        # Кнопка установки Java
        def install_java():
            import webbrowser
            webbrowser.open('https://www.java.com/ru/download/manual.jsp')

        def recheck_java():
            nonlocal java_installed
            try:
                result = subprocess.run(['java', '-version'], capture_output=True, text=True)
                if result.returncode == 0:
                    java_installed = True
                    version_text = result.stderr.split('\n')[0] if result.stderr else result.stdout.split('\n')[0]
                    java_status.config(text=f'☕ Java: ✅ Установлена ({version_text})', fg='lightgreen')
                else:
                    java_installed = False
                    java_status.config(text='☕ Java: ❌ Не найдена!', fg='red')
            except FileNotFoundError:
                java_installed = False
                java_status.config(text='☕ Java: ❌ Не найдена!', fg='red')

        java_frame = tk.Frame(root, bg='#2d2d2d')
        java_frame.pack(pady=5)
        tk.Button(java_frame, text='☕ Скачать Java', command=install_java,
                  bg='orange', fg='white', width=12).pack(side=tk.LEFT, padx=5)
        tk.Button(java_frame, text='🔄 Проверить', command=recheck_java,
                  bg='blue', fg='white', width=12).pack(side=tk.LEFT, padx=5)

        tk.Label(root, text='', bg='#2d2d2d').pack(pady=5)

        # ============ MINECRAFT РАЗДЕЛ ============
        minecraft_frame = tk.LabelFrame(root, text='⛏️ MINECRAFT (твои ссылки)',
                                        bg='#2d2d2d', fg='#ffaa00', font=('Arial', 12, 'bold'))
        minecraft_frame.pack(fill='both', expand=True, padx=15, pady=10)

        status_label = tk.Label(minecraft_frame, text='',
                                bg='#2d2d2d', fg='yellow', font=('Arial', 10))
        status_label.pack(pady=5)

        # ТВОИ ВЕРСИИ MINECRAFT (с GitHub)
        versions = [
            ('🐲 Alpha 1.0.17_02', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.0.17_02.jar'),
            ('🌀 Release 1.0', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.0.jar.jar'),
            ('⚙️ Release 1.1', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.1.jar.jar'),
            ('🔧 Release 1.1.2_01', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.1.2_01.jar.jar'),
            ('📦 Release 1.2.5', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.2.5.jar'),
            ('🚀 Release 1.2.6', 'https://github.com/artem123qq/minelibrary/releases/download/mine/1.2.6.jar.jar'),
        ]

        def download_and_launch(version_name, url):
            if not java_installed:
                messagebox.showerror('Java не найдена',
                                     'Для запуска Minecraft нужна Java!\nНажми "Скачать Java"')
                return

            # Окно загрузки
            download_win = tk.Toplevel(root)
            download_win.title('Загрузка Minecraft')
            download_win.geometry('400x250')
            download_win.configure(bg='#2d2d2d')
            download_win.transient(root)
            download_win.grab_set()

            tk.Label(download_win, text=f'⛏️ {version_name}', font=('Arial', 14, 'bold'),
                     bg='#2d2d2d', fg='#ffaa00').pack(pady=20)

            progress = ttk.Progressbar(download_win, length=300, mode='indeterminate')
            progress.pack(pady=20)
            progress.start(10)

            dl_status = tk.Label(download_win, text='Подготовка...', bg='#2d2d2d', fg='white')
            dl_status.pack(pady=10)

            def download():
                minecraft_dir = os.path.join(os.path.expanduser('~'), 'Downloads', 'minecraft_legacy')
                os.makedirs(minecraft_dir, exist_ok=True)

                # Очищаем имя файла
                safe_name = version_name.replace('🐲 ', '').replace('🌀 ', '').replace('⚙️ ', '')
                safe_name = safe_name.replace('🔧 ', '').replace('📦 ', '').replace('🚀 ', '')
                safe_name = safe_name.replace(' ', '_').replace('(', '').replace(')', '')
                jar_path = os.path.join(minecraft_dir, f'{safe_name}.jar')

                if os.path.exists(jar_path):
                    dl_status.config(text='Файл найден! Запускаю...')
                    download_win.update()
                    time.sleep(0.5)
                    download_win.destroy()
                    launch_java(jar_path, version_name)
                    return

                dl_status.config(text='Скачивание с GitHub...')
                download_win.update()

                try:
                    urllib.request.urlretrieve(url, jar_path)
                    dl_status.config(text='Запускаю!')
                    download_win.update()
                    time.sleep(0.5)
                    download_win.destroy()
                    launch_java(jar_path, version_name)
                except Exception as e:
                    download_win.destroy()
                    messagebox.showerror('Ошибка',
                                         f'Не удалось скачать {version_name}\n\n'
                                         f'Проверь ссылку:\n{url}\n\n'
                                         f'Ошибка: {e}\n\n'
                                         f'Или положи файл вручную в:\n{minecraft_dir}')

            def launch_java(jar_path, version_name):
                try:
                    if os.name == 'nt':
                        subprocess.Popen(['javaw', '-jar', jar_path])
                    else:
                        subprocess.Popen(['java', '-jar', jar_path])
                    messagebox.showinfo('Успех', f'{version_name} запущен!')
                except Exception as e:
                    messagebox.showerror('Ошибка', f'Не удалось запустить\n{e}')

            threading.Thread(target=download, daemon=True).start()

        for name, url in versions:
            btn = tk.Button(minecraft_frame, text=name, font=('Arial', 11),
                            bg='#3d3d3d', fg='white', activebackground='#5d5d5d',
                            command=lambda n=name, u=url: download_and_launch(n, u))
            btn.pack(fill='x', padx=15, pady=3)

        # Кнопка для выбора своего JAR
        def select_jar():
            if not java_installed:
                messagebox.showerror('Java не найдена', 'Нужна Java для запуска .jar файлов!')
                return
            file_path = filedialog.askopenfilename(
                title='Выбери Minecraft.jar',
                filetypes=[('JAR files', '*.jar')]
            )
            if file_path:
                try:
                    subprocess.Popen(['javaw', '-jar', file_path] if os.name == 'nt' else ['java', '-jar', file_path])
                    messagebox.showinfo('Успех', 'Запущено!')
                except Exception as e:
                    messagebox.showerror('Ошибка', str(e))

        tk.Button(minecraft_frame, text='📁 Выбрать свой JAR файл', command=select_jar,
                  bg='#555', fg='white', font=('Arial', 10)).pack(pady=8)

        # Инструкция
        tk.Label(minecraft_frame, text='💡 Файлы сохраняются в папке Downloads/minecraft_legacy',
                 bg='#2d2d2d', fg='gray', font=('Arial', 8)).pack(pady=5)

        root.mainloop()
class AppPomodoro:
    """Таймер Pomodoro"""
    @staticmethod
    def run():
        root = tk.Tk()
        root.title('🍅 Pomodoro - ARTp')
        root.geometry('400x350')

        work_time = 25 * 60
        break_time = 5 * 60
        current_time = work_time
        is_work = True
        running = False

        def update_display():
            minutes = current_time // 60
            seconds = current_time % 60
            time_label.config(text=f'{minutes:02d}:{seconds:02d}')

        def timer():
            nonlocal current_time, running
            if running and current_time > 0:
                current_time -= 1
                update_display()
                root.after(1000, timer)
            elif running and current_time == 0:
                if is_work:
                    messagebox.showinfo('🍅 Время вышло!', 'Перерыв 5 минут!')
                    switch_to_break()
                else:
                    messagebox.showinfo('🍅 Перерыв окончен!', 'Начинайте работать!')
                    switch_to_work()

        def switch_to_break():
            nonlocal current_time, is_work
            is_work = False
            current_time = break_time
            update_display()
            status_label.config(text='💚 ПЕРЕРЫВ', fg='green')
            timer()

        def switch_to_work():
            nonlocal current_time, is_work
            is_work = True
            current_time = work_time
            update_display()
            status_label.config(text='❤️ РАБОТА', fg='red')
            timer()

        def start():
            nonlocal running
            if not running:
                running = True
                start_btn.config(text='⏸ Пауза')
                timer()

        def pause():
            nonlocal running
            running = False
            start_btn.config(text='▶️ Старт')

        def reset():
            nonlocal running, current_time, is_work
            running = False
            is_work = True
            current_time = work_time
            update_display()
            status_label.config(text='❤️ РАБОТА', fg='red')
            start_btn.config(text='▶️ Старт')

        status_label = tk.Label(root, text='❤️ РАБОТА', font=('Arial', 16), fg='red')
        status_label.pack(pady=10)

        time_label = tk.Label(root, text='25:00', font=('Digital', 60, 'bold'))
        time_label.pack(pady=20)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        start_btn = tk.Button(btn_frame, text='▶️ Старт', command=start, bg='green', fg='white', width=8)
        start_btn.pack(side=tk.LEFT, padx=5)

        tk.Button(btn_frame, text='⏸ Пауза', command=pause, bg='orange', fg='white', width=8).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text='🔄 Сброс', command=reset, bg='blue', fg='white', width=8).pack(side=tk.LEFT, padx=5)

        update_display()
        root.mainloop()


class A:
    """Главный класс с приложениями"""

    # Старые приложения

    @staticmethod
    def notepad():
        AppNotepad.run()
    @staticmethod
    def rps():
        """✊ Камень-ножницы-бумага"""
        AppRPS.run()
    @staticmethod
    def calculator():
        AppCalculator.run()
    @staticmethod
    def viktorina():
        AppViktorina.run()

    @staticmethod
    def clock():
        AppDigitalClock.run()

    @staticmethod
    def colorpicker():
        AppColorPicker.run()

    # НОВЫЕ 10 ПРИЛОЖЕНИЙ
    @staticmethod
    def snake():
        """🐍 Игра Змейка"""
        AppSnake.run()

    @staticmethod
    def tic_tac_toe():
        """⭕ Крестики-нолики"""
        AppTicTacToe.run()

    @staticmethod
    def mc_152():
        """🎮 Запуск Minecraft 1.5.2"""
        Minecraft_1_5_2.run()
    @staticmethod
    def todo():
        """📝 Список дел"""
        AppTodo.run()

    @staticmethod
    def mc_1112():
        """🎮 Запуск Minecraft 1.11.2"""
        Minecraft_1_11_2.run()
    @staticmethod
    def password_gen():
        """🔐 Генератор паролей"""
        AppPasswordGen.run()

    @staticmethod
    def weather():
        """🌤️ Погода"""
        AppWeather.run()

    @staticmethod
    def sysinfo():
        """💻 Информация о системе"""
        AppSysInfo.run()

    @staticmethod
    def typing():
        """⌨️ Тренажёр печати"""
        AppTyping.run()

    @staticmethod
    def game_center():
        """🎮 Игровой центр (Java + Minecraft)"""
        AppGameCenter.run()
    @staticmethod
    def pomodoro():
        """🍅 Таймер Pomodoro"""
        AppPomodoro.run()

    @staticmethod
    def help():
        print('''
    ╔══════════════════════════════════════════════════════════════╗
    ║                    🎯 ARTp - КОМАНДЫ                        ║
    ╚══════════════════════════════════════════════════════════════╝

    📝 artp.a.notepad()        - Блокнот
    🧮 artp.a.calculator()     - Калькулятор  
    🎯 artp.a.viktorina()      - Викторина
    🕐 artp.a.clock()          - Цифровые часы
    🎨 artp.a.colorpicker()    - Палитра цветов
    🐍 artp.a.snake()          - Змейка
    ⭕ artp.a.tic_tac_toe()    - Крестики-нолики
    📝 artp.a.todo()           - Список дел
    🔐 artp.a.password_gen()   - Генератор паролей
    🌤️ artp.a.weather()        - Погода
    💻 artp.a.sysinfo()        - Системная информация
    ⌨️ artp.a.typing()         - Тренажёр печати
    🍅 artp.a.pomodoro()       - Pomodoro таймер
    🎮 artp.a.game_center()    - Игровой центр (Java + Minecraft)
    📖 artp.a.make_guide()     - Гайд по публикации

    ==============================================================
    📋 artp.a.help()           - Эта справка
    ╚══════════════════════════════════════════════════════════════╝
    ''')
    @staticmethod
    def example(name):
        if name == 'tkinter.notepad':
            A.notepad()
        elif name == 'help':
            A.help()
        else:
            print(f"Пример '{name}' не найден. Используй a.help() для списка")

a = A()
ARTp = A