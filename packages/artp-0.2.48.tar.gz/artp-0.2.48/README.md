import artp

# Show notepad example
artp.a.example('tkinter.notepad')