from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.pii_entity import PiiEntity


T = TypeVar("T", bound="PiiResult")


@_attrs_define
class PiiResult:
    """
    Attributes:
        redacted_text (str): The input with detected entities replaced by `<TYPE_N>` placeholders.
        entities (list[PiiEntity]):
    """

    redacted_text: str
    entities: list[PiiEntity]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        redacted_text = self.redacted_text

        entities = []
        for entities_item_data in self.entities:
            entities_item = entities_item_data.to_dict()
            entities.append(entities_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "redacted_text": redacted_text,
                "entities": entities,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pii_entity import PiiEntity

        d = dict(src_dict)
        redacted_text = d.pop("redacted_text")

        entities = []
        _entities = d.pop("entities")
        for entities_item_data in _entities:
            entities_item = PiiEntity.from_dict(entities_item_data)

            entities.append(entities_item)

        pii_result = cls(
            redacted_text=redacted_text,
            entities=entities,
        )

        pii_result.additional_properties = d
        return pii_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
