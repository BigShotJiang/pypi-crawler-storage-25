from enum import Enum


class ScanBlockedEventType(str, Enum):
    SCAN_BLOCKED = "scan.blocked"

    def __str__(self) -> str:
        return str(self.value)
