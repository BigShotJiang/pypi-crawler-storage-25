from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.pii_policy_redact_with import PiiPolicyRedactWith
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.custom_recognizer import CustomRecognizer


T = TypeVar("T", bound="PiiPolicy")


@_attrs_define
class PiiPolicy:
    """
    Attributes:
        entities (list[str] | Unset): Entity types to detect (subset of Presidio's defaults plus any
            custom_recognizers below). Omit to detect every supported type.
             Example: ['EMAIL_ADDRESS', 'PHONE_NUMBER', 'PERSON'].
        redact_with (PiiPolicyRedactWith | Unset): Placeholder mode is currently the only supported strategy. Default:
            PiiPolicyRedactWith.PLACEHOLDER.
        custom_recognizers (list[CustomRecognizer] | Unset):
    """

    entities: list[str] | Unset = UNSET
    redact_with: PiiPolicyRedactWith | Unset = PiiPolicyRedactWith.PLACEHOLDER
    custom_recognizers: list[CustomRecognizer] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        entities: list[str] | Unset = UNSET
        if not isinstance(self.entities, Unset):
            entities = self.entities

        redact_with: str | Unset = UNSET
        if not isinstance(self.redact_with, Unset):
            redact_with = self.redact_with.value

        custom_recognizers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.custom_recognizers, Unset):
            custom_recognizers = []
            for custom_recognizers_item_data in self.custom_recognizers:
                custom_recognizers_item = custom_recognizers_item_data.to_dict()
                custom_recognizers.append(custom_recognizers_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if entities is not UNSET:
            field_dict["entities"] = entities
        if redact_with is not UNSET:
            field_dict["redact_with"] = redact_with
        if custom_recognizers is not UNSET:
            field_dict["custom_recognizers"] = custom_recognizers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_recognizer import CustomRecognizer

        d = dict(src_dict)
        entities = cast(list[str], d.pop("entities", UNSET))

        _redact_with = d.pop("redact_with", UNSET)
        redact_with: PiiPolicyRedactWith | Unset
        if isinstance(_redact_with, Unset):
            redact_with = UNSET
        else:
            redact_with = PiiPolicyRedactWith(_redact_with)

        _custom_recognizers = d.pop("custom_recognizers", UNSET)
        custom_recognizers: list[CustomRecognizer] | Unset = UNSET
        if _custom_recognizers is not UNSET:
            custom_recognizers = []
            for custom_recognizers_item_data in _custom_recognizers:
                custom_recognizers_item = CustomRecognizer.from_dict(custom_recognizers_item_data)

                custom_recognizers.append(custom_recognizers_item)

        pii_policy = cls(
            entities=entities,
            redact_with=redact_with,
            custom_recognizers=custom_recognizers,
        )

        pii_policy.additional_properties = d
        return pii_policy

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
