from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.scan_response import ScanResponse


T = TypeVar("T", bound="BatchScanResult")


@_attrs_define
class BatchScanResult:
    """
    Attributes:
        index (int): Zero-based position of this item in the request.
        ok (bool): True if the scan succeeded; false if it errored out.
        scan (ScanResponse | Unset):
        error (str | Unset): Stable error code, present when ok=false (e.g. `sidecar_unavailable`, `internal_error`).
        message (str | Unset): Human-readable detail, present on some error codes.
    """

    index: int
    ok: bool
    scan: ScanResponse | Unset = UNSET
    error: str | Unset = UNSET
    message: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        index = self.index

        ok = self.ok

        scan: dict[str, Any] | Unset = UNSET
        if not isinstance(self.scan, Unset):
            scan = self.scan.to_dict()

        error = self.error

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "index": index,
                "ok": ok,
            }
        )
        if scan is not UNSET:
            field_dict["scan"] = scan
        if error is not UNSET:
            field_dict["error"] = error
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.scan_response import ScanResponse

        d = dict(src_dict)
        index = d.pop("index")

        ok = d.pop("ok")

        _scan = d.pop("scan", UNSET)
        scan: ScanResponse | Unset
        if isinstance(_scan, Unset):
            scan = UNSET
        else:
            scan = ScanResponse.from_dict(_scan)

        error = d.pop("error", UNSET)

        message = d.pop("message", UNSET)

        batch_scan_result = cls(
            index=index,
            ok=ok,
            scan=scan,
            error=error,
            message=message,
        )

        batch_scan_result.additional_properties = d
        return batch_scan_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
