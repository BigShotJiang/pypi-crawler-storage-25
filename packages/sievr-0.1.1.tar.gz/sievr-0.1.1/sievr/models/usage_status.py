from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.usage_status_tier import UsageStatusTier

T = TypeVar("T", bound="UsageStatus")


@_attrs_define
class UsageStatus:
    """
    Attributes:
        tier (UsageStatusTier): The calling key's plan tier.
        limit (int): Included scan units for this plan per UTC month.
        used (int): Scan units consumed in the current period.
        remaining (int): Included units left before overage (paid plans) or 429 (free plan).
        reset (int): Unix epoch seconds at which the counter resets (00:00 UTC on the first of next month).
    """

    tier: UsageStatusTier
    limit: int
    used: int
    remaining: int
    reset: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tier = self.tier.value

        limit = self.limit

        used = self.used

        remaining = self.remaining

        reset = self.reset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tier": tier,
                "limit": limit,
                "used": used,
                "remaining": remaining,
                "reset": reset,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tier = UsageStatusTier(d.pop("tier"))

        limit = d.pop("limit")

        used = d.pop("used")

        remaining = d.pop("remaining")

        reset = d.pop("reset")

        usage_status = cls(
            tier=tier,
            limit=limit,
            used=used,
            remaining=remaining,
            reset=reset,
        )

        usage_status.additional_properties = d
        return usage_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
