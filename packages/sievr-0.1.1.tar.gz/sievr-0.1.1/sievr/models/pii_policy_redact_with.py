from enum import Enum


class PiiPolicyRedactWith(str, Enum):
    PLACEHOLDER = "placeholder"

    def __str__(self) -> str:
        return str(self.value)
