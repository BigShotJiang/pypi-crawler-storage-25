from enum import Enum


class UsageStatusTier(str, Enum):
    FREE = "free"
    PRO = "pro"
    SCALE = "scale"
    STARTER = "starter"

    def __str__(self) -> str:
        return str(self.value)
