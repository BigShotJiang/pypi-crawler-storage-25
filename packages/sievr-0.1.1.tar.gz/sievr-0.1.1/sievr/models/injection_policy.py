from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="InjectionPolicy")


@_attrs_define
class InjectionPolicy:
    """
    Attributes:
        block_threshold (float | Unset): Score at or above which the verdict is `block`. Default: 0.85.
        use_llm_tiebreaker (bool | Unset): When true, an LLM tiebreaker resolves scores in the [0.15, 0.85]
            band. Adds ~400-1500 ms latency on the uncertain band; free
            outside it. Charged at the metered rate of the caller's plan.
             Default: False.
    """

    block_threshold: float | Unset = 0.85
    use_llm_tiebreaker: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        block_threshold = self.block_threshold

        use_llm_tiebreaker = self.use_llm_tiebreaker

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if block_threshold is not UNSET:
            field_dict["block_threshold"] = block_threshold
        if use_llm_tiebreaker is not UNSET:
            field_dict["use_llm_tiebreaker"] = use_llm_tiebreaker

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        block_threshold = d.pop("block_threshold", UNSET)

        use_llm_tiebreaker = d.pop("use_llm_tiebreaker", UNSET)

        injection_policy = cls(
            block_threshold=block_threshold,
            use_llm_tiebreaker=use_llm_tiebreaker,
        )

        injection_policy.additional_properties = d
        return injection_policy

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
