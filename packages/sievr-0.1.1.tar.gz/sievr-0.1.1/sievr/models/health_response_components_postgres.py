from enum import Enum


class HealthResponseComponentsPostgres(str, Enum):
    DOWN = "down"
    OK = "ok"

    def __str__(self) -> str:
        return str(self.value)
