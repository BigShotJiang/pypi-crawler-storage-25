from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PiiEntity")


@_attrs_define
class PiiEntity:
    """
    Attributes:
        type_ (str):  Example: EMAIL_ADDRESS.
        start (int): Inclusive UTF-16 offset in the original text.
        end (int): Exclusive UTF-16 offset in the original text.
        score (float):
        replacement (str):  Example: <EMAIL_1>.
        original (str): The original substring the placeholder replaced. Pass back to /v1/scan/rehydrate to restore it.
            Example: alice@example.com.
    """

    type_: str
    start: int
    end: int
    score: float
    replacement: str
    original: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        start = self.start

        end = self.end

        score = self.score

        replacement = self.replacement

        original = self.original

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "start": start,
                "end": end,
                "score": score,
                "replacement": replacement,
                "original": original,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type")

        start = d.pop("start")

        end = d.pop("end")

        score = d.pop("score")

        replacement = d.pop("replacement")

        original = d.pop("original")

        pii_entity = cls(
            type_=type_,
            start=start,
            end=end,
            score=score,
            replacement=replacement,
            original=original,
        )

        pii_entity.additional_properties = d
        return pii_entity

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
