from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.injection_policy import InjectionPolicy
    from ..models.pii_policy import PiiPolicy


T = TypeVar("T", bound="ScanRequestPolicies")


@_attrs_define
class ScanRequestPolicies:
    """
    Attributes:
        pii (PiiPolicy | Unset):
        injection (InjectionPolicy | Unset):
    """

    pii: PiiPolicy | Unset = UNSET
    injection: InjectionPolicy | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        pii: dict[str, Any] | Unset = UNSET
        if not isinstance(self.pii, Unset):
            pii = self.pii.to_dict()

        injection: dict[str, Any] | Unset = UNSET
        if not isinstance(self.injection, Unset):
            injection = self.injection.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if pii is not UNSET:
            field_dict["pii"] = pii
        if injection is not UNSET:
            field_dict["injection"] = injection

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.injection_policy import InjectionPolicy
        from ..models.pii_policy import PiiPolicy

        d = dict(src_dict)
        _pii = d.pop("pii", UNSET)
        pii: PiiPolicy | Unset
        if isinstance(_pii, Unset):
            pii = UNSET
        else:
            pii = PiiPolicy.from_dict(_pii)

        _injection = d.pop("injection", UNSET)
        injection: InjectionPolicy | Unset
        if isinstance(_injection, Unset):
            injection = UNSET
        else:
            injection = InjectionPolicy.from_dict(_injection)

        scan_request_policies = cls(
            pii=pii,
            injection=injection,
        )

        scan_request_policies.additional_properties = d
        return scan_request_policies

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
