from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.scan_blocked_event_type import ScanBlockedEventType

if TYPE_CHECKING:
    from ..models.scan_blocked_event_data import ScanBlockedEventData


T = TypeVar("T", bound="ScanBlockedEvent")


@_attrs_define
class ScanBlockedEvent:
    """
    Attributes:
        id (str):  Example: evt_01HX....
        type_ (ScanBlockedEventType):
        created (int): Unix epoch seconds at which the event was generated.
        data (ScanBlockedEventData):
    """

    id: str
    type_: ScanBlockedEventType
    created: int
    data: ScanBlockedEventData
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        type_ = self.type_.value

        created = self.created

        data = self.data.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
                "created": created,
                "data": data,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.scan_blocked_event_data import ScanBlockedEventData

        d = dict(src_dict)
        id = d.pop("id")

        type_ = ScanBlockedEventType(d.pop("type"))

        created = d.pop("created")

        data = ScanBlockedEventData.from_dict(d.pop("data"))

        scan_blocked_event = cls(
            id=id,
            type_=type_,
            created=created,
            data=data,
        )

        scan_blocked_event.additional_properties = d
        return scan_blocked_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
