from enum import Enum


class ScanRequestChecksItem(str, Enum):
    INJECTION = "injection"
    PII = "pii"

    def __str__(self) -> str:
        return str(self.value)
