from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CustomRecognizer")


@_attrs_define
class CustomRecognizer:
    """
    Attributes:
        name (str):
        regex (str):
        entity_type (str):
        score (float | Unset):  Default: 0.85.
    """

    name: str
    regex: str
    entity_type: str
    score: float | Unset = 0.85
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        regex = self.regex

        entity_type = self.entity_type

        score = self.score

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "regex": regex,
                "entity_type": entity_type,
            }
        )
        if score is not UNSET:
            field_dict["score"] = score

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        regex = d.pop("regex")

        entity_type = d.pop("entity_type")

        score = d.pop("score", UNSET)

        custom_recognizer = cls(
            name=name,
            regex=regex,
            entity_type=entity_type,
            score=score,
        )

        custom_recognizer.additional_properties = d
        return custom_recognizer

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
