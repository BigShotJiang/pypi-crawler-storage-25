from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.health_response_components_api import HealthResponseComponentsApi
from ..models.health_response_components_postgres import HealthResponseComponentsPostgres
from ..models.health_response_components_presidio import HealthResponseComponentsPresidio
from ..models.health_response_components_redis import HealthResponseComponentsRedis

T = TypeVar("T", bound="HealthResponseComponents")


@_attrs_define
class HealthResponseComponents:
    """Per-subsystem health. Each value is "ok" or "down".

    Attributes:
        api (HealthResponseComponentsApi):
        postgres (HealthResponseComponentsPostgres):
        redis (HealthResponseComponentsRedis):
        presidio (HealthResponseComponentsPresidio):
    """

    api: HealthResponseComponentsApi
    postgres: HealthResponseComponentsPostgres
    redis: HealthResponseComponentsRedis
    presidio: HealthResponseComponentsPresidio
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        api = self.api.value

        postgres = self.postgres.value

        redis = self.redis.value

        presidio = self.presidio.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "api": api,
                "postgres": postgres,
                "redis": redis,
                "presidio": presidio,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api = HealthResponseComponentsApi(d.pop("api"))

        postgres = HealthResponseComponentsPostgres(d.pop("postgres"))

        redis = HealthResponseComponentsRedis(d.pop("redis"))

        presidio = HealthResponseComponentsPresidio(d.pop("presidio"))

        health_response_components = cls(
            api=api,
            postgres=postgres,
            redis=redis,
            presidio=presidio,
        )

        health_response_components.additional_properties = d
        return health_response_components

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
