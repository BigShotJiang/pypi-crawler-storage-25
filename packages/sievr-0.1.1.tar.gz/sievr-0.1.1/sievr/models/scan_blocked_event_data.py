from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ScanBlockedEventData")


@_attrs_define
class ScanBlockedEventData:
    """
    Attributes:
        request_id (str): ULID of the scan that produced this block.
        score (float):
        reasons (list[str]):
        tiebreaker_used (bool):
        pii_entity_count (int): Number of PII entities detected on the same scan
        latency_ms (int):
    """

    request_id: str
    score: float
    reasons: list[str]
    tiebreaker_used: bool
    pii_entity_count: int
    latency_ms: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        request_id = self.request_id

        score = self.score

        reasons = self.reasons

        tiebreaker_used = self.tiebreaker_used

        pii_entity_count = self.pii_entity_count

        latency_ms = self.latency_ms

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "request_id": request_id,
                "score": score,
                "reasons": reasons,
                "tiebreaker_used": tiebreaker_used,
                "pii_entity_count": pii_entity_count,
                "latency_ms": latency_ms,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        request_id = d.pop("request_id")

        score = d.pop("score")

        reasons = cast(list[str], d.pop("reasons"))

        tiebreaker_used = d.pop("tiebreaker_used")

        pii_entity_count = d.pop("pii_entity_count")

        latency_ms = d.pop("latency_ms")

        scan_blocked_event_data = cls(
            request_id=request_id,
            score=score,
            reasons=reasons,
            tiebreaker_used=tiebreaker_used,
            pii_entity_count=pii_entity_count,
            latency_ms=latency_ms,
        )

        scan_blocked_event_data.additional_properties = d
        return scan_blocked_event_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
