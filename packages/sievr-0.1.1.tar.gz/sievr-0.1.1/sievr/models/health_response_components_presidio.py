from enum import Enum


class HealthResponseComponentsPresidio(str, Enum):
    DOWN = "down"
    OK = "ok"

    def __str__(self) -> str:
        return str(self.value)
