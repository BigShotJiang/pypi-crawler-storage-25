from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.scan_request_checks_item import ScanRequestChecksItem
from ..models.scan_request_direction import ScanRequestDirection
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.scan_request_policies import ScanRequestPolicies


T = TypeVar("T", bound="ScanRequest")


@_attrs_define
class ScanRequest:
    """
    Attributes:
        text (str): The user input or model output to inspect.
        direction (ScanRequestDirection | Unset): Whether the text is heading into your model or coming out of it.
            Reserved for future direction-aware policies. Default: ScanRequestDirection.INPUT.
        checks (list[ScanRequestChecksItem] | Unset): Which checks to run. Both run in parallel when both are requested.
        policies (ScanRequestPolicies | Unset):
    """

    text: str
    direction: ScanRequestDirection | Unset = ScanRequestDirection.INPUT
    checks: list[ScanRequestChecksItem] | Unset = UNSET
    policies: ScanRequestPolicies | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        text = self.text

        direction: str | Unset = UNSET
        if not isinstance(self.direction, Unset):
            direction = self.direction.value

        checks: list[str] | Unset = UNSET
        if not isinstance(self.checks, Unset):
            checks = []
            for checks_item_data in self.checks:
                checks_item = checks_item_data.value
                checks.append(checks_item)

        policies: dict[str, Any] | Unset = UNSET
        if not isinstance(self.policies, Unset):
            policies = self.policies.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "text": text,
            }
        )
        if direction is not UNSET:
            field_dict["direction"] = direction
        if checks is not UNSET:
            field_dict["checks"] = checks
        if policies is not UNSET:
            field_dict["policies"] = policies

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.scan_request_policies import ScanRequestPolicies

        d = dict(src_dict)
        text = d.pop("text")

        _direction = d.pop("direction", UNSET)
        direction: ScanRequestDirection | Unset
        if isinstance(_direction, Unset):
            direction = UNSET
        else:
            direction = ScanRequestDirection(_direction)

        _checks = d.pop("checks", UNSET)
        checks: list[ScanRequestChecksItem] | Unset = UNSET
        if _checks is not UNSET:
            checks = []
            for checks_item_data in _checks:
                checks_item = ScanRequestChecksItem(checks_item_data)

                checks.append(checks_item)

        _policies = d.pop("policies", UNSET)
        policies: ScanRequestPolicies | Unset
        if isinstance(_policies, Unset):
            policies = UNSET
        else:
            policies = ScanRequestPolicies.from_dict(_policies)

        scan_request = cls(
            text=text,
            direction=direction,
            checks=checks,
            policies=policies,
        )

        scan_request.additional_properties = d
        return scan_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
