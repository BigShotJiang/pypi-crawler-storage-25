from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.injection_result import InjectionResult
    from ..models.pii_result import PiiResult
    from ..models.usage import Usage


T = TypeVar("T", bound="ScanResponse")


@_attrs_define
class ScanResponse:
    """
    Attributes:
        request_id (str): ULID for tracing this scan in your logs and ours.
        latency_ms (int):
        usage (Usage):
        pii (PiiResult | Unset):
        injection (InjectionResult | Unset):
    """

    request_id: str
    latency_ms: int
    usage: Usage
    pii: PiiResult | Unset = UNSET
    injection: InjectionResult | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        request_id = self.request_id

        latency_ms = self.latency_ms

        usage = self.usage.to_dict()

        pii: dict[str, Any] | Unset = UNSET
        if not isinstance(self.pii, Unset):
            pii = self.pii.to_dict()

        injection: dict[str, Any] | Unset = UNSET
        if not isinstance(self.injection, Unset):
            injection = self.injection.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "request_id": request_id,
                "latency_ms": latency_ms,
                "usage": usage,
            }
        )
        if pii is not UNSET:
            field_dict["pii"] = pii
        if injection is not UNSET:
            field_dict["injection"] = injection

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.injection_result import InjectionResult
        from ..models.pii_result import PiiResult
        from ..models.usage import Usage

        d = dict(src_dict)
        request_id = d.pop("request_id")

        latency_ms = d.pop("latency_ms")

        usage = Usage.from_dict(d.pop("usage"))

        _pii = d.pop("pii", UNSET)
        pii: PiiResult | Unset
        if isinstance(_pii, Unset):
            pii = UNSET
        else:
            pii = PiiResult.from_dict(_pii)

        _injection = d.pop("injection", UNSET)
        injection: InjectionResult | Unset
        if isinstance(_injection, Unset):
            injection = UNSET
        else:
            injection = InjectionResult.from_dict(_injection)

        scan_response = cls(
            request_id=request_id,
            latency_ms=latency_ms,
            usage=usage,
            pii=pii,
            injection=injection,
        )

        scan_response.additional_properties = d
        return scan_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
