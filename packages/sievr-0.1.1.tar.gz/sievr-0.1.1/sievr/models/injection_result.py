from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.injection_result_verdict import InjectionResultVerdict

T = TypeVar("T", bound="InjectionResult")


@_attrs_define
class InjectionResult:
    """
    Attributes:
        verdict (InjectionResultVerdict):
        score (float): Probability of injection in [0, 1]. When the LLM tiebreaker fires, this is its score; otherwise
            it is the max of stage 1 and stage 2 scores.
        reasons (list[str]): Tagged provenance — e.g. `pattern:instruction_override`, `classifier:0.92`,
            `tiebreaker:block:0.95`.
        tiebreaker_used (bool): True when stage 3 (LLM) ran.
    """

    verdict: InjectionResultVerdict
    score: float
    reasons: list[str]
    tiebreaker_used: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        verdict = self.verdict.value

        score = self.score

        reasons = self.reasons

        tiebreaker_used = self.tiebreaker_used

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "verdict": verdict,
                "score": score,
                "reasons": reasons,
                "tiebreaker_used": tiebreaker_used,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        verdict = InjectionResultVerdict(d.pop("verdict"))

        score = d.pop("score")

        reasons = cast(list[str], d.pop("reasons"))

        tiebreaker_used = d.pop("tiebreaker_used")

        injection_result = cls(
            verdict=verdict,
            score=score,
            reasons=reasons,
            tiebreaker_used=tiebreaker_used,
        )

        injection_result.additional_properties = d
        return injection_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
