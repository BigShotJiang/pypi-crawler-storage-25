from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.rehydrate_request import RehydrateRequest
from ...models.rehydrate_response import RehydrateResponse
from ...types import Response


def _get_kwargs(
    *,
    body: RehydrateRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/scan/rehydrate",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | RehydrateResponse | None:
    if response.status_code == 200:
        response_200 = RehydrateResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 413:
        response_413 = Error.from_dict(response.json())

        return response_413

    if response.status_code == 422:
        response_422 = Error.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | RehydrateResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RehydrateRequest,
) -> Response[Error | RehydrateResponse]:
    """Restore PII placeholders to their original values

     Takes text containing `<TYPE_N>` placeholders (typically the output
    of an LLM that ran on redacted input) plus the entity mapping
    returned by `/v1/scan`, and replaces every placeholder with its
    original substring. Free of charge — does not tick the quota meter.

    Entities are matched longest-first so `<EMAIL_1>` does not collide
    with the prefix of `<EMAIL_10>`.

    Args:
        body (RehydrateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | RehydrateResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RehydrateRequest,
) -> Error | RehydrateResponse | None:
    """Restore PII placeholders to their original values

     Takes text containing `<TYPE_N>` placeholders (typically the output
    of an LLM that ran on redacted input) plus the entity mapping
    returned by `/v1/scan`, and replaces every placeholder with its
    original substring. Free of charge — does not tick the quota meter.

    Entities are matched longest-first so `<EMAIL_1>` does not collide
    with the prefix of `<EMAIL_10>`.

    Args:
        body (RehydrateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | RehydrateResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RehydrateRequest,
) -> Response[Error | RehydrateResponse]:
    """Restore PII placeholders to their original values

     Takes text containing `<TYPE_N>` placeholders (typically the output
    of an LLM that ran on redacted input) plus the entity mapping
    returned by `/v1/scan`, and replaces every placeholder with its
    original substring. Free of charge — does not tick the quota meter.

    Entities are matched longest-first so `<EMAIL_1>` does not collide
    with the prefix of `<EMAIL_10>`.

    Args:
        body (RehydrateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | RehydrateResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RehydrateRequest,
) -> Error | RehydrateResponse | None:
    """Restore PII placeholders to their original values

     Takes text containing `<TYPE_N>` placeholders (typically the output
    of an LLM that ran on redacted input) plus the entity mapping
    returned by `/v1/scan`, and replaces every placeholder with its
    original substring. Free of charge — does not tick the quota meter.

    Entities are matched longest-first so `<EMAIL_1>` does not collide
    with the prefix of `<EMAIL_10>`.

    Args:
        body (RehydrateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | RehydrateResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
