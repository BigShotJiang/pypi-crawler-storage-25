from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.scan_request import ScanRequest
from ...models.scan_response import ScanResponse
from ...types import Response


def _get_kwargs(
    *,
    body: ScanRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/scan",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | ScanResponse | None:
    if response.status_code == 200:
        response_200 = ScanResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 413:
        response_413 = Error.from_dict(response.json())

        return response_413

    if response.status_code == 422:
        response_422 = Error.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = Error.from_dict(response.json())

        return response_429

    if response.status_code == 502:
        response_502 = Error.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | ScanResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ScanRequest,
) -> Response[Error | ScanResponse]:
    """Scan text for PII and prompt injection

     Runs the configured checks against the supplied text. The PII check
    returns redacted text and a list of entities (each with the original
    substring so callers can rehydrate later). The injection check runs
    a 3-stage cascade — regex patterns, an ONNX classifier, and an
    opt-in LLM tiebreaker on the uncertain band.

    Quota: 1 scan unit per 1,024 input characters, billed against the
    bearer token's plan. Free-tier callers get a 429 once monthly usage
    reaches 1,000; paid plans always proceed (overage is billed via
    Stripe Meters).

    Rate-limit headers are emitted on every successful response and on
    429s — see the response headers.

    Args:
        body (ScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ScanResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ScanRequest,
) -> Error | ScanResponse | None:
    """Scan text for PII and prompt injection

     Runs the configured checks against the supplied text. The PII check
    returns redacted text and a list of entities (each with the original
    substring so callers can rehydrate later). The injection check runs
    a 3-stage cascade — regex patterns, an ONNX classifier, and an
    opt-in LLM tiebreaker on the uncertain band.

    Quota: 1 scan unit per 1,024 input characters, billed against the
    bearer token's plan. Free-tier callers get a 429 once monthly usage
    reaches 1,000; paid plans always proceed (overage is billed via
    Stripe Meters).

    Rate-limit headers are emitted on every successful response and on
    429s — see the response headers.

    Args:
        body (ScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ScanResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ScanRequest,
) -> Response[Error | ScanResponse]:
    """Scan text for PII and prompt injection

     Runs the configured checks against the supplied text. The PII check
    returns redacted text and a list of entities (each with the original
    substring so callers can rehydrate later). The injection check runs
    a 3-stage cascade — regex patterns, an ONNX classifier, and an
    opt-in LLM tiebreaker on the uncertain band.

    Quota: 1 scan unit per 1,024 input characters, billed against the
    bearer token's plan. Free-tier callers get a 429 once monthly usage
    reaches 1,000; paid plans always proceed (overage is billed via
    Stripe Meters).

    Rate-limit headers are emitted on every successful response and on
    429s — see the response headers.

    Args:
        body (ScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ScanResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ScanRequest,
) -> Error | ScanResponse | None:
    """Scan text for PII and prompt injection

     Runs the configured checks against the supplied text. The PII check
    returns redacted text and a list of entities (each with the original
    substring so callers can rehydrate later). The injection check runs
    a 3-stage cascade — regex patterns, an ONNX classifier, and an
    opt-in LLM tiebreaker on the uncertain band.

    Quota: 1 scan unit per 1,024 input characters, billed against the
    bearer token's plan. Free-tier callers get a 429 once monthly usage
    reaches 1,000; paid plans always proceed (overage is billed via
    Stripe Meters).

    Rate-limit headers are emitted on every successful response and on
    429s — see the response headers.

    Args:
        body (ScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ScanResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
