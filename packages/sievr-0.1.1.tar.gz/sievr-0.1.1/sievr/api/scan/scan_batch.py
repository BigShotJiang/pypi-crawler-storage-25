from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.batch_scan_request import BatchScanRequest
from ...models.batch_scan_response import BatchScanResponse
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    *,
    body: BatchScanRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/scan/batch",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BatchScanResponse | Error | None:
    if response.status_code == 200:
        response_200 = BatchScanResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 413:
        response_413 = Error.from_dict(response.json())

        return response_413

    if response.status_code == 422:
        response_422 = Error.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = Error.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BatchScanResponse | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BatchScanRequest,
) -> Response[BatchScanResponse | Error]:
    """Scan up to 50 texts in a single request

     Same checks and policies as POST /v1/scan, applied to up to 50 items
    in parallel. One bad item does not fail the whole batch — each
    result is either a success (`ok: true`, includes the scan body) or
    an error (`ok: false`, includes a stable error code).

    Quota enforcement runs against the worst-case projected unit cost
    before any item is processed; Free-tier callers that would exceed
    the cap see a 429 for the entire batch. Only successful items are
    billed.

    A single Stripe meter event covers the whole batch's billed units.

    Args:
        body (BatchScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchScanResponse | Error]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: BatchScanRequest,
) -> BatchScanResponse | Error | None:
    """Scan up to 50 texts in a single request

     Same checks and policies as POST /v1/scan, applied to up to 50 items
    in parallel. One bad item does not fail the whole batch — each
    result is either a success (`ok: true`, includes the scan body) or
    an error (`ok: false`, includes a stable error code).

    Quota enforcement runs against the worst-case projected unit cost
    before any item is processed; Free-tier callers that would exceed
    the cap see a 429 for the entire batch. Only successful items are
    billed.

    A single Stripe meter event covers the whole batch's billed units.

    Args:
        body (BatchScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchScanResponse | Error
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BatchScanRequest,
) -> Response[BatchScanResponse | Error]:
    """Scan up to 50 texts in a single request

     Same checks and policies as POST /v1/scan, applied to up to 50 items
    in parallel. One bad item does not fail the whole batch — each
    result is either a success (`ok: true`, includes the scan body) or
    an error (`ok: false`, includes a stable error code).

    Quota enforcement runs against the worst-case projected unit cost
    before any item is processed; Free-tier callers that would exceed
    the cap see a 429 for the entire batch. Only successful items are
    billed.

    A single Stripe meter event covers the whole batch's billed units.

    Args:
        body (BatchScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchScanResponse | Error]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: BatchScanRequest,
) -> BatchScanResponse | Error | None:
    """Scan up to 50 texts in a single request

     Same checks and policies as POST /v1/scan, applied to up to 50 items
    in parallel. One bad item does not fail the whole batch — each
    result is either a success (`ok: true`, includes the scan body) or
    an error (`ok: false`, includes a stable error code).

    Quota enforcement runs against the worst-case projected unit cost
    before any item is processed; Free-tier callers that would exceed
    the cap see a 429 for the entire batch. Only successful items are
    billed.

    A single Stripe meter event covers the whole batch's billed units.

    Args:
        body (BatchScanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchScanResponse | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
