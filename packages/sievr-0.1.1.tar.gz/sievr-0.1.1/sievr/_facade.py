"""High-level convenience wrapper around the generated client.

The generated `sievr.api.*` modules expose endpoint-level functions that
take a configured `AuthenticatedClient`. This module bundles them into a
single `Sievr` class so the common usage looks like:

    from sievr import Sievr
    client = Sievr(api_key="sv_live_...")
    result = client.scan(...)

The lower-level API (`AuthenticatedClient`, `sievr.api.scan.scan_text`,
etc.) stays available for callers who want fine-grained control.
"""

from __future__ import annotations

from typing import Any

from .api.health import get_health
from .api.scan import get_usage, rehydrate_placeholders, scan_batch, scan_text
from .client import AuthenticatedClient
from .models.batch_scan_request import BatchScanRequest
from .models.batch_scan_response import BatchScanResponse
from .models.error import Error
from .models.health_response import HealthResponse
from .models.rehydrate_request import RehydrateRequest
from .models.rehydrate_response import RehydrateResponse
from .models.scan_request import ScanRequest
from .models.scan_response import ScanResponse
from .models.usage_status import UsageStatus

DEFAULT_BASE_URL = "https://api.sievr.dev"


class SievrError(Exception):
    """Raised when the Sievr API returns an error or an empty response."""

    def __init__(self, code: str, *, status: int | None = None, raw: Any = None) -> None:
        super().__init__(f"Sievr API error: {code}")
        self.code = code
        self.status = status
        self.raw = raw


class Sievr:
    """Synchronous client for the Sievr API.

    Args:
        api_key: A live API key (`sv_live_...`) issued from the dashboard.
        base_url: Override the API host — defaults to https://api.sievr.dev.
        timeout: Optional per-request timeout in seconds (passed to httpx).
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | None = None,
    ) -> None:
        kwargs: dict[str, Any] = {"base_url": base_url, "token": api_key}
        if timeout is not None:
            import httpx

            kwargs["timeout"] = httpx.Timeout(timeout)
        self._client = AuthenticatedClient(**kwargs)

    def scan(self, body: ScanRequest | dict[str, Any]) -> ScanResponse:
        body_obj = body if isinstance(body, ScanRequest) else ScanRequest.from_dict(body)
        response = scan_text.sync_detailed(client=self._client, body=body_obj)
        return _unwrap(response, ScanResponse)

    def batch(self, body: BatchScanRequest | dict[str, Any]) -> BatchScanResponse:
        body_obj = body if isinstance(body, BatchScanRequest) else BatchScanRequest.from_dict(body)
        response = scan_batch.sync_detailed(client=self._client, body=body_obj)
        return _unwrap(response, BatchScanResponse)

    def rehydrate(self, body: RehydrateRequest | dict[str, Any]) -> RehydrateResponse:
        body_obj = body if isinstance(body, RehydrateRequest) else RehydrateRequest.from_dict(body)
        response = rehydrate_placeholders.sync_detailed(client=self._client, body=body_obj)
        return _unwrap(response, RehydrateResponse)

    def usage(self) -> UsageStatus:
        response = get_usage.sync_detailed(client=self._client)
        return _unwrap(response, UsageStatus)

    def health(self) -> HealthResponse:
        response = get_health.sync_detailed(client=self._client)
        return _unwrap(response, HealthResponse)


def _unwrap(response: Any, expected: type) -> Any:
    """Pull the parsed body out of a Response, raising SievrError on any error path."""
    parsed = response.parsed
    status = response.status_code
    if isinstance(parsed, Error):
        raise SievrError(parsed.error, status=status, raw=parsed)
    if parsed is None:
        # Status code wasn't in the documented set and raise_on_unexpected_status
        # is off, so the generated parser returned None. Surface the raw body
        # for diagnostics rather than swallowing it.
        body = response.content.decode("utf-8", errors="replace") if response.content else ""
        raise SievrError("unexpected_status", status=status, raw=body)
    if not isinstance(parsed, expected):
        raise SievrError("unexpected_response_type", status=status, raw=parsed)
    return parsed
