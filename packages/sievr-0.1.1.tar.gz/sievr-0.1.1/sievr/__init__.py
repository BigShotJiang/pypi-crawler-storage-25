"""Sievr — drop-in guardrails for LLM apps.

>>> from sievr import Sievr
>>> from sievr.models.scan_request import ScanRequest
>>> client = Sievr(api_key="sv_live_...")
>>> result = client.scan(ScanRequest(text="Email alice@example.com.", checks=["pii"]))
"""

from ._facade import DEFAULT_BASE_URL, Sievr, SievrError
from .client import AuthenticatedClient, Client

__all__ = (
    "AuthenticatedClient",
    "Client",
    "DEFAULT_BASE_URL",
    "Sievr",
    "SievrError",
)
