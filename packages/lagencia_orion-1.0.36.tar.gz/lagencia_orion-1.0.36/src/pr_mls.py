from orion.mls.etl_mls import etl
from orion.mls.mls import get_all_mls  # noqa: F401

if __name__ == "__main__":
    # result = get_all_mls()
    # result.to_excel("result_mls.xlsx", index=False)

    etl()
