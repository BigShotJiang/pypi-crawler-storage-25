import pandas as pd
from loguru import logger
from orion.definition_ids import ID_BASE_MLS
from orion.mls.etl_mls import QuerysMLS, cut_date_str, split_by_transaction, upsert_mls
from orion.mls.mls import filter_mls_for_castillo, filter_mls_for_estrella, filter_mls_for_livin, filter_mls_for_villacruz, generate_url_first_image, get_all_mls
from orion.tools import clean_text, format_column_name  # noqa: F401

from datetime import datetime
from typing import Tuple

import pandas as pd

from orion.databases.db_bellatrix.repositories.querys_mls import QuerysMLS
from orion.mls.mls import get_all_mls
from orion.tools import cut_date_str, df_to_dicts, list_obj_to_df

# mls_api = get_all_mls()
# mls_api.to_excel("mls_ventas_actual.xlsx", index=False)

mls_api = get_all_mls()
    #mls_api.to_excel("mls_api.xlsx", index=False)

# + Consultar MLS de base de datos
records = QuerysMLS.select_all()
mls_db = list_obj_to_df(records)



print("***", mls_api[mls_api["code"]==261496])
print("***", mls_db[mls_db["code"]==261496])


to_insert, to_deactivate, to_update, to_activate = split_by_transaction(mls_api, mls_db)

print("***", to_insert[to_insert["code"]==261496])

#upsert_mls(to_insert, to_deactivate, to_update, to_activate)

# if not mls_db.empty:
#     print("\nRegistros DB activo:")
#     print(mls_db[mls_db["active"] == 1].shape)

#     print("\nRegistros DB inactivo:")
#     print(mls_db[mls_db["active"] == 0].shape)

# print("\nRegistros API:")
# print(mls_api.shape)

# print("\nRegistros para insertar:")
# print(to_insert.shape)

# print("\nRegistros para activar:")
# print(to_activate.shape)

# print("\nRegistros para desactivar:")
# print(to_deactivate.shape)

# print("\nRegistros para actualizar:")
# print(to_update.shape)


# print(to_insert[to_insert["code"]==261496])
# print(to_deactivate[to_deactivate["code"]==261496])
# print(to_update[to_update["code"]==261496])
# print(to_activate[to_activate["code"]==261496])


