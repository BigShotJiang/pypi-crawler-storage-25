import pandas as pd

from orion.acrecer.acrecer import get_all_cities_acrecer_sync, get_all_properties_acrecer_by_city_sync  # noqa: F401
from orion.acrecer.etl_acrecer import load_data_for_table_acrecer as etl_acrecer  # noqa: F401


async def main():

    # service = AcrecerClient(subject=config.SUBJECT_MLS_ACRECER)
    # result_medellin_sin_tilde = await service.get_all_properties_by_cities(["MEDELLiN"])
    # print(result_medellin_sin_tilde)
    # result_medellin_sin_tilde.to_excel("result_medellin_sin_tilde.xlsx", index=False)

    # service = AcrecerClient(subject=config.SUBJECT_MLS_ACRECER)
    # result_medellin_con_tilde = await service.get_all_properties_by_cities(["Medellín"])
    # print(result_medellin_con_tilde)
    # result_medellin_con_tilde.to_excel("result_medellin_con_tilde.xlsx", index=False)

    # service = AcrecerClient(subject=config.SUBJECT_MLS_ACRECER)
    # result_medellin_1 = await service.get_all_properties_by_cities(["medellin"])
    # print(result_medellin_1)
    # result_medellin_1.to_excel("result_medellin_1.xlsx", index=False)

    # service = AcrecerClient(subject=config.SUBJECT_MLS_ACRECER)
    # result_medellin_2 = await service.get_all_properties_by_cities(["medellín"])
    # print(result_medellin_2)
    # result_medellin_2.to_excel("result_medellin_1.xlsx", index=False)

    # service = AcrecerClient(subject=config.SUBJECT_MLS_ACRECER)
    # result_medellin_2 = await service.get_all_properties_by_cities(["MEDELLÍN", "MEDELLIN"])
    # print(result_medellin_2)
    # result_medellin_2.to_excel("result_medellin_1.xlsx", index=False)

    ...


if __name__ == "__main__":
    import ast  # noqa: F401
    import asyncio  # noqa: F401

    # asyncio.run(main())
    result = get_all_properties_acrecer_by_city_sync()
    print(result)
    result.to_excel("mls_acrecer.xlsx", index=False)
    # mls_acrecer_full = get_mls_acrecer_full()
    # #mls_acrecer_full.to_excel("mls_acrecer.xlsx", index=False)
    # result = transform_mls_acrecer_for_properties(mls_acrecer_full)
    # result.to_excel("mls_acrecer_t.xlsx", index=False)
    # etl_acrecer()
    # from collections import defaultdict
    # import ast
    # def group_count_by_city_neighborhood(data):
    #     counts = defaultdict(int)
    #     for item in data:
    #         key = (item.get("city"), item.get("neighborhood"))
    #         counts[key] += 1
    #     result = []
    #     for (city, neighborhood), count in counts.items():
    #         result.append({"city": city, "neighborhood": neighborhood, "count": count})
    #     return result
    # data = pd.read_excel("mls_acrecer.xlsx")["locationData"].to_list()
    # data = [ast.literal_eval(record) for record in data]
    # result =group_count_by_city_neighborhood(data)
    # print(result)
    # pd.DataFrame(result).to_excel("barrios.xlsx", index=False)




    # import pandas as pd

    # def filter_mls_by_location(mls_acrecer, filters_mls_acrecer_for_livin):

    #     df = mls_acrecer.copy()

    #     # convertir el string de dict a dict si es necesario
    #     df["locationData"] = df["locationData"].apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else x)

    #     # expandir el dict a columnas
    #     loc = pd.json_normalize(df["locationData"])

    #     # agregar columnas al df original
    #     df = pd.concat([df, loc[["zone", "city", "neighborhood"]]], axis=1)

    #     # normalizar nombres de columnas del df de filtros
    #     filters = filters_mls_acrecer_for_livin.rename(columns={"Zone": "zone", "City": "city", "Neighborhood": "neighborhood"})

    #     # hacer el match por las 3 columnas
    #     df_filtered = df.merge(filters, on=["zone", "city", "neighborhood"], how="inner")

    #     # si no quieres dejar las columnas auxiliares
    #     df_filtered = df_filtered.drop(columns=["zone", "city", "neighborhood"])

    #     return df_filtered

    # data = pd.read_excel("mls_acrecer.xlsx")
    # filters = pd.read_excel("filters_mls_acrecer_for_livin.xlsx")

    # # result = filter_mls_by_location(mls_acrecer=data, filters_mls_acrecer_for_livin=filters)
    # # result.to_excel("mls_acrecer_filterd.xlsx", index=False)

    # records = data["locationData"].apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else x).to_list()
    # print(records)
    # df= pd.DataFrame(records)
    # print(df)
    # df.to_excel("zonas.xlsx", index=False)


    # result= get_all_properties_acrecer_by_city_sync(cities=[])
    # print(result)

    # result = get_all_cities_acrecer_sync()
    # print(f"{result=}")

    # result.to_excel("all_cities.xlsx", index=False)


