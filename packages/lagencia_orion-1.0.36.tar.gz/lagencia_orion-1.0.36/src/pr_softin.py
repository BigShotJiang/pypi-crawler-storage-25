import asyncio  # noqa: F401

from orion.softin.etl_softin import etl as etl_softin
from orion.searcher.properties.transform_data_softin import transform_softin_for_properties  # noqa: F401
from orion.softin.softin import get_all_softin  # noqa: F401

if __name__ == "__main__":
    result = asyncio.run(get_all_softin())
    print(result)
    result.to_excel("result_softin.xlsx", index=False)

    # result = transform_softin_for_properties(result)

    # print(result)
    # result.to_excel("result_softin_t.xlsx", index=False)

    #etl_softin()
