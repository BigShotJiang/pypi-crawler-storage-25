import pandas as pd
from geoalchemy2.elements import WKTElement
from geoalchemy2.shape import from_shape
from shapely.geometry import MultiPolygon, Polygon

from orion.databases.db_empatia.repositories.querys_searcher import QuerysProperty

# from orion.searcher.gallery.etl_gallery import insert_records_in_table_gallery_properties, update_records_for_table_gallery_properties
from orion.tools import df_to_dicts

"""_summary_: permite actualizar la tabla de propiedades con la informacion
            actual de las tablas de softin, simi y mls
"""


SRID = 4326


def to_model_dict(d: dict) -> dict:
    d = dict(d)  # copia
    geom = d.get("geometry")

    if geom is None:
        return d

    # Caso 1: viene como texto WKT
    if isinstance(geom, str):
        d["geometry"] = WKTElement(geom, srid=SRID)
        return d

    # Caso 2: viene como Shapely geometry
    # Si es Polygon, lo envolvemos como MultiPolygon para que coincida con tu columna
    if isinstance(geom, Polygon):
        geom = MultiPolygon([geom])

    # Asegúrate de que sea MultiPolygon
    if isinstance(geom, MultiPolygon):
        d["geometry"] = from_shape(geom, srid=SRID)  # <-- correcto para Shapely
        return d

    # (Opcional) si viniera WKB (bytes), podrías usar from_wkb
    # else: lanzar error explícito para detectar casos no contemplados
    raise TypeError(f"geometry no soportada: {type(geom)}")


def insert_new_properties(new_properties: pd.DataFrame):
    if new_properties.empty:
        return

    records = df_to_dicts(new_properties)
    print(f"Insertando nuevas propiedades: {len(records)}")
    records = [to_model_dict(record) for record in records]

    QuerysProperty.insert_all(records)


def update_properties(properties: pd.DataFrame):
    if properties.empty:
        return
    records = df_to_dicts(properties)
    print(f"Actualizando propiedades: {len(records)}")
    for record in records:
        QuerysProperty.update_by_id(record, record.get("id"))


def delete_properties(properties: pd.DataFrame):
    if properties.empty:
        return
    records = df_to_dicts(properties)
    print(f"Eliminando propiedades: {len(records)}")
    for record in records:
        QuerysProperty.delete_by_id(record.get("id"))
