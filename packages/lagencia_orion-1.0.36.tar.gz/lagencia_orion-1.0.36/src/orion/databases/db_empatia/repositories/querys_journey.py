from orion.databases.db_empatia.models.model_journey import LogsJounery
from orion.databases.db_empatia.repositories.querys_base_empatia import BaseCRUD


class QuerysLogsJounery(BaseCRUD[LogsJounery]):
    model = LogsJounery
