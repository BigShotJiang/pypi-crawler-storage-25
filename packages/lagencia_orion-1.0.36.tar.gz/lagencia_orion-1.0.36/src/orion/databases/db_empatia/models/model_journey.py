from sqlalchemy import Column, DateTime, Integer, String, Text

from orion.databases.config_db_empatia import BaseEmpatia


class LogsJounery(BaseEmpatia):
    __tablename__ = "logs_journey"
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_subscription = Column(Integer)
    template_sent = Column(String(50))
    date_of_shipment = Column(DateTime)
    shipping_summary = Column(Text)
    shipping_status_code = Column(Integer)
    real_state = Column(String(50))
