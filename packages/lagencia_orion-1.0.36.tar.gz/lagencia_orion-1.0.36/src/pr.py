from typing import List  # noqa: F401

from orion.searcher.sectors_x_properties.sectors_x_properties import insert_records_in_table_sectors_properties_by_sectors  # noqa: F401
from orion.acrecer.etl_acrecer import load_data_for_table_acrecer  # noqa: F401
from orion.databases.db_bellatrix.repositories.query_acrecer import QuerysMLSAcrecer
from orion.databases.db_bellatrix.repositories.querys_simi import QuerysSimi
from orion.databases.db_bellatrix.repositories.querys_softin import QuerysSoftin
from orion.databases.db_empatia.repositories.querys_searcher import QuerysProperty  # noqa: F401
from orion.databases.db_empatia.repositories.repository_for_geospatial_calculations import lugares_a_500m, property_within_sector, test_geometries  # noqa: F401
from orion.databases.db_empatia.repositories.repository_for_loading_to_sectors import (  # noqa: F401
    execute_load_data_table_related_neighborhoods,
    load_alias_into_sectors2_preserve_ids,
    load_barrios_into_sectors2_preserve_ids,
    load_comunas_into_sectors2_preserve_ids,
    load_corregimientos_into_sectors2_preserve_ids,
    load_data_into_all_sector_source_tables,
    load_data_to_table_related_neighborhoods,
    load_lugares_into_sectors2_preserve_ids,
    load_municipios_into_sectors2_preserve_ids,
    load_source_sectors_into_table_sectors,
    load_veredas_into_sectors2_preserve_ids,
    update_field_reference_sector,
    update_field_sector_from_table_sectors_by_barrios,
    update_field_sector_from_table_sectors_by_comuna,
    update_field_sector_from_table_sectors_by_corregimiento,
    update_field_sector_from_table_sectors_by_lugares,
    update_field_sector_from_table_sectors_by_veredas,
)
from orion.databases.db_empatia.sp.sp import create_sp_and_trigers_from_sectors_control, execute_all_sp  # noqa: F401
from orion.mls.etl_mls import QuerysMLS  # noqa: F401
from orion.mls.etl_mls import etl as etl_mls  # noqa: F401
from orion.mls.mls import get_all_mls, get_full_data_mls  # noqa: F401

# from orion.searcher.etl_properties import update_properties  # # noqa: F401
# from orion.searcher.etl_properties import get_all_assets_from_sources  # noqa: F401
from orion.scripts.init_dbs import create_schemas_empatia  # noqa: F401
from orion.searcher.attributes_x_propierties.etl_attribute_properties import insert_records_in_table_attribute_properties, reload_records_in_table_attribute_properties, transform_mls_acrecer_for_attributes_properties, update_records_for_table_attribute_properties  # noqa: F401
from orion.searcher.etl_main import get_properties_to_insert  # noqa: F401
from orion.searcher.gallery_x_properties.etl_gallery import insert_records_in_table_gallery_properties, transform_mls_acrecer_for_gallery_propertirs, transform_mls_for_gallery_propierties, update_records_for_table_gallery_properties  # noqa: F401
from orion.searcher.properties.etl_properties import delete_properties, insert_new_properties, update_properties  # noqa: F401
from orion.searcher.properties.integrations import get_mls_acrecer_full, get_mls_full, get_simi_full, get_softin_full, integrate_sources_to_get_attributes_properties, integrate_sources_to_get_gallery_properties, integrate_sources_to_get_properties  # noqa: F401
from orion.searcher.properties.transform_data_mls import transform_mls_for_properties
from orion.searcher.properties.transform_data_mls_acrecer import transform_mls_acrecer_for_properties
from orion.searcher.properties.transform_data_simi import transform_simi_for_properties
from orion.searcher.properties.transform_data_softin import transform_softin_for_properties
from orion.searcher.properties.utils_properties import get_properties_to_delete, get_properties_to_update  # noqa: F401
from orion.searcher.sectors_x_properties.sectors_x_properties import insert_records_in_table_sectors_properties_by_lugar, insert_records_in_table_sectors_properties_by_sectors, update_records_for_table_sectors_properties, update_records_for_table_sectors_properties_by_lugar  # noqa: F401
from orion.simi.etl_simi import etl as etl_simi  # noqa: F401
from orion.softin.etl_softin import etl as etl_softin  # noqa: F401
from orion.tools import list_obj_to_df

from orion.databases.db_empatia.repositories.querys_searcher import PropertySector, QuerysPropertySector

#insert_records_in_table_sectors_properties_by_sectors()


softin_full = get_softin_full()
simi_full = get_simi_full()
mls_full = get_mls_full()
mls_acrecer_full = get_mls_acrecer_full()

# obtener propiedades
new_properties = integrate_sources_to_get_properties(softin_full, simi_full, mls_full, mls_acrecer_full)


insert_records_in_table_sectors_properties_by_sectors(new_properties["id"])

# # print(new_properties["id"])


# records = QuerysPropertySector().select_all()
# sectors_property = list_obj_to_df(records)
# print(sectors_property["property_id"])


# print(new_properties[~new_properties["id"].isin(sectors_property["property_id"])]["id"])

