import asyncio

from orion.simi.simi import get_all_simi
from orion.simi.etl_simi import etl as etl_simi

if __name__ == "__main__":
    # df = asyncio.run(get_all_simi())
    # df.to_excel("result_simi.xlsx", index=False)

    etl_simi()
