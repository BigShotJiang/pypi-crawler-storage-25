const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const os = require('os');
const { createRequire } = require('module');

if (process.stdout._handle && typeof process.stdout._handle.setBlocking === 'function') {
    process.stdout._handle.setBlocking(true);
}
if (process.stderr._handle && typeof process.stderr._handle.setBlocking === 'function') {
    process.stderr._handle.setBlocking(true);
}

app.use(bodyParser.json());

const loadedModules = {};
const loadErrors = {};

const arg2 = process.argv[2];
const scriptsDir = (arg2 && arg2.trim() !== '') ? path.resolve(arg2) : path.resolve(process.cwd(), './resources/js');

const arg3 = process.argv[3];
const nodeModulesPath = (arg3 && arg3.trim() !== '') ? path.resolve(arg3) : null;

const urlBase = process.argv[4];

let port = 3000;

// 解析端口
if (urlBase) {
    try {
        const url = new URL(urlBase);
        if (url.port) {
            port = parseInt(url.port, 10);
        } else {
            port = (url.protocol === 'https:') ? 443 : 80;
        }
    } catch (e) {
        port = process.env.PORT || 3000;
    }
} else {
    port = process.env.PORT || 3000;
}

if (nodeModulesPath) {
    if (fs.existsSync(nodeModulesPath)) {
        process.env.NODE_PATH = nodeModulesPath + (process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : '');
        require('module')._initPaths();
    } else {
        process.stderr.write(`[WARN] node_modules not found: ${nodeModulesPath}\n`);
    }
}

const W = (msg) => process.stdout.write(msg);
const E = (msg) => process.stderr.write(msg);

/**
 * 创建隔离的 VM 上下文，仅包含全局公共对象。
 * 模块专属变量（exports, require, module, __filename, __dirname）
 * 通过 CommonJS 函数包裹注入，与 Node.js 原生行为一致。
 */
function createContext() {
    const sandbox = {};

    for (const name of Object.getOwnPropertyNames(global)) {
        if (name === 'global' || name === 'globalThis') continue;
        try {
            sandbox[name] = global[name];
        } catch (_) {
        }
    }

    // global / globalThis 指向沙箱自身，防止逃逸到宿主全局
    sandbox.global = sandbox;
    sandbox.globalThis = sandbox;

    vm.createContext(sandbox);
    return sandbox;
}

function loadScripts(directory) {
    if (!fs.existsSync(directory)) {
        console.error(`[ERROR] Scripts directory not found: ${directory}`);
        return;
    }

    const files = fs.readdirSync(directory);
    files.forEach(file => {
        const ext = path.extname(file);
        if (ext !== '.js' && ext !== '.jsx') return;

        const moduleName = path.basename(file, ext);
        const scriptPath = path.join(directory, file);

        // 跳过服务器自身
        if (path.resolve(scriptPath) === path.resolve(__filename)) {
            return;
        }

        try {
            const scriptCode = fs.readFileSync(scriptPath, 'utf-8');
            const absPath = path.resolve(scriptPath);
            const scriptDir = path.dirname(absPath);
            const scriptRequire = createRequire(absPath);
            const sandboxModule = { exports: {} };

            // 为此模块创建独立 VM 上下文（沙箱隔离）
            const context = createContext();

            // 与 Node.js 原生行为一致：包裹在 CommonJS 函数中
            // 这样支持顶层 return、var 局部化、以及正确的 this 指向（module.exports）
            const wrappedCode = `(function(exports, require, module, __filename, __dirname) {\n${scriptCode}\n})`;
            const script = new vm.Script(wrappedCode, {
                filename: absPath,
            });

            // 在 VM 上下文中编译出工厂函数，然后传入模块专属参数调用
            const factory = script.runInContext(context);
            factory.call(sandboxModule.exports, sandboxModule.exports, scriptRequire, sandboxModule, absPath, scriptDir);

            loadedModules[moduleName] = sandboxModule.exports;
        } catch (e) {
            loadErrors[moduleName] = e.message;
            E(`  ERR ${moduleName} \u2500 ${e.message}\n`);
            if (e.stack) {
                E(`    ${e.stack.split('\n').join('\n    ')}\n`);
            }
        }
    });
}

loadScripts(scriptsDir);

app.post('/:filename/invoke', async (req, res) => {
    try {
        const { filename } = req.params;
        const { func_name, args = [] } = req.body;
        W(`  \u2192 ${filename}/${func_name}\n`);

        if (loadErrors[filename]) {
            const errMsg = `Module '${filename}' failed to load: ${loadErrors[filename]}`;
            E(`  ERR ${errMsg}\n`);
            return res.status(500).json({ success: false, error: errMsg });
        }

        if (!loadedModules[filename]) {
            const errMsg = `Module '${filename}' not found. Available: [${Object.keys(loadedModules).join(', ')}]`;
            E(`  ERR ${errMsg}\n`);
            return res.status(404).json({ success: false, error: errMsg });
        }

        const mod = loadedModules[filename];
        if (typeof mod[func_name] === 'function') {
            const result = await mod[func_name](...args);
            res.json({ success: true, result });
        } else {
            const available = Object.keys(mod).filter(k => typeof mod[k] === 'function');
            const errMsg = `Function '${func_name}' not found in '${filename}'. Available: [${available.join(', ')}]`;
            E(`  ERR ${errMsg}\n`);
            res.status(404).json({ success: false, error: errMsg });
        }
    } catch (error) {
        E(`  ERR ${error.message}\n`);
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/status', (req, res) => {
    res.json({ status: 'running', service_name: 'js_invoker_microservice' });
});

app.listen(port, '0.0.0.0', () => {
    const moduleNames = Object.keys(loadedModules);
    const errorNames = Object.keys(loadErrors);
    const totalLoaded = moduleNames.length;
    const totalFailed = errorNames.length;

    // ── Banner ──
    W('\n');
    W('  \u250C\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n');
    W('  \u2502   js invoker by Alhamdulillah-R              \u2502\n');
    W('  \u2502   sandboxed VM runtime                       \u2502\n');
    W('  \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518\n');
    W('\n');

    // ── Config ──
    W(`  scan dir     ${scriptsDir}\n`);
    W(`  node modules ${nodeModulesPath || 'default resolution'}\n`);
    W('\n');

    // ── Modules ──
    if (totalLoaded > 0) {
        W(`  OK ${totalLoaded} module(s) loaded\n`);
        moduleNames.forEach((name, i) => {
            const mod = loadedModules[name];
            const funcs = Object.keys(mod).filter(k => typeof mod[k] === 'function');
            const isLast = (i === totalLoaded - 1) && (totalFailed === 0);
            const branch = isLast ? '\u2514' : '\u251C';
            W(`  ${branch}\u2500 ${name}`);
            if (funcs.length > 0) {
                W(`  [${funcs.join(', ')}]`);
            }
            W('\n');
        });
    } else if (totalFailed === 0) {
        W('  No modules found\n');
    }

    if (totalFailed > 0) {
        E(`  ERR ${totalFailed} module(s) failed\n`);
        errorNames.forEach((name, i) => {
            const isLast = i === totalFailed - 1;
            const branch = isLast ? '\u2514' : '\u251C';
            E(`  ${branch}\u2500 ${name}: ${loadErrors[name]}\n`);
        });
    }
    W('\n');

    // ── Network ──
    const localIps = new Set(['127.0.0.1']);
    const networkInterfaces = os.networkInterfaces();
    for (const name in networkInterfaces) {
        for (const iface of networkInterfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                if (iface.address.startsWith('192.168.') || iface.address.startsWith('10.') || iface.address.startsWith('172.')) {
                    localIps.add(iface.address);
                }
            }
        }
    }
    const ips = Array.from(localIps).sort();

    W('  listening on:\n');
    ips.forEach((ip, i) => {
        const branch = (i === ips.length - 1) ? '\u2514' : '\u251C';
        W(`  ${branch}\u2500 http://${ip}:${port}\n`);
    });
    W('\n');
});