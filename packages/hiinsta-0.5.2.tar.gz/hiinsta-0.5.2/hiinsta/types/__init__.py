from pydantic import BaseModel, Field

from typing import List, Optional, TypedDict


class AttachmentPayload(BaseModel):
    url: Optional[str] = None


class Attachment(BaseModel):
    type: str
    payload: AttachmentPayload


class QuickReply(BaseModel):
    payload: str


class AdsContextData(BaseModel):
    ad_title: str
    photo_url: Optional[str] = None
    video_url: Optional[str] = None


class Referral(BaseModel):
    ref: Optional[str] = None
    ad_id: Optional[str] = None
    source: Optional[str] = None
    type: Optional[str] = None
    ads_context_data: Optional[AdsContextData] = None


class ReplyToStory(BaseModel):
    url: str
    id: str


class ReplyTo(BaseModel):
    mid: Optional[str] = None
    story: Optional[ReplyToStory] = None


class Message(BaseModel):
    mid: str
    attachments: Optional[List[Attachment]] = None
    is_deleted: Optional[bool] = None
    is_echo: bool = Field(default=False)
    is_unsupported: Optional[bool] = None
    quick_reply: Optional[QuickReply] = None
    referral: Optional[Referral] = None
    reply_to: Optional[ReplyTo] = None
    text: Optional[str] = None

class User(BaseModel):
    id: str

class Messaging(BaseModel):
    sender: User
    recipient: User
    timestamp: int
    message: Message


class Entry(BaseModel):
    id: str
    time: int
    messaging: List[Messaging]

class Update(BaseModel):
    """
    Instagram _message_ webhook update object.
    
    Reference:
    - https://developers.facebook.com/docs/instagram-platform/webhooks/examples/#message
    """
    object: str
    entry: List[Entry]

class InstagramUser(BaseModel):
    id: str
    username: str
    name: Optional[str] = None
    
class SendResponse(TypedDict):
    recipient_id: str
    message_id: str



