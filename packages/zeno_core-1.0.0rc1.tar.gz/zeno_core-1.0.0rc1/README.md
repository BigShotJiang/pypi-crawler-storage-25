# zeno-core

Core runtime for the [Zeno](https://github.com/nkootstra/zeno) framework.

## Install

```bash
uv add zeno-framework
```

Public surface:

- `Ctx`, ContextVar plumbing, `@tool` decorator, `Agent` / `SubAgent`.
- `ZenoApp` — binds channels, agent, memory, provider, tracer.
- `Provider` protocol + `Capabilities` dataclass + `ProviderCapabilityError`
  (the v0.3.0 pluggable-provider seam).
- `ClaudeSDKProvider` — first-party `Provider` wrapping the Claude Agent SDK.
- Channel protocol, turn worker, streaming, tracer, failure policies.
- Plugin entry-point discovery (`zeno.sub_agents`, `zeno.providers`,
  `zeno.tools`, `zeno.channels`).

Part of a lockstep `0.x` release. Install via the `zeno-framework` meta-package:

```bash
uv add 'zeno-framework[cli]'          # Claude Agent SDK backend (default)
uv add 'zeno-framework[openai,cli]'   # OpenAI-compatible backend
```

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
