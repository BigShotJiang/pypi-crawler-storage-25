"""`ClaudeSDKProvider` — the v0.2 Claude Agent SDK path wrapped in v0.3.0 `Provider` (R12-R15, R21).

This provider moves the `ClaudeSDKClient` wiring that used to live in each
app's `agent_handler` into framework-owned code. Behaviour is preserved
byte-for-byte — the characterization tests in `test_claude_sdk_provider.py`
are the gatekeeper.

What this provider owns:
  - `Agent.build_options(...)` translation into `ClaudeAgentOptions`
  - optional `session_lookup(user_id, channel, thread_key) -> sdk_session_id`
    for SDK resume
  - `ClaudeSDKClient(...)` construction **inside** the bound Ctx scope so
    tool ContextVars propagate (the invariant called out in `ZenoApp`)
  - streaming assistant text chunks through `ctx.stream(...)`
  - hook-bridge wiring via `build_hooks(tracer, ...)` so SDK tool-use hooks
    surface as `ToolCallStarted` / `ToolCallCompleted` trace events

What this provider intentionally does NOT touch:
  - `ctx.memory.conversation` — the Agent SDK owns its own session history
    (see R9 in the plan). Non-Claude providers that extract state from this
    store have zero effect here.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from zeno.context import current_ctx
from zeno.observability.sdk_hooks import build_hooks
from zeno.providers.protocol import Capabilities

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx


# Session lookup keyed the same way the v0.2 `ZenoApp` did — `(user_id,
# channel, thread_key) -> sdk_session_id | None`. The handler calls this
# before translating options so `ClaudeAgentOptions.resume` gets populated
# when a previous session exists.
SessionLookup = Callable[[str, str, str | None], Awaitable[str | None]]


_CAPABILITIES = Capabilities(
    supports_sub_agents=True,
    supports_built_in_tools=True,
    supports_permission_mode=True,
    supports_streaming=True,
)


class ClaudeSDKProvider:
    """`Provider` adapter over `claude_agent_sdk.ClaudeSDKClient`.

    Constructor arguments:
      - ``session_lookup``: optional async callable used to resolve the SDK
        session id to resume per turn. When ``None``, every turn starts a
        fresh SDK session.
      - ``mcp_server_key``: MCP server name used when translating tools;
        defaults to ``"zeno_app"`` (matches the v0.2 example-chat value).
    """

    def __init__(
        self,
        *,
        session_lookup: SessionLookup | None = None,
        mcp_server_key: str = "zeno_app",
    ) -> None:
        self._session_lookup = session_lookup
        self._mcp_server_key = mcp_server_key

    @property
    def capabilities(self) -> Capabilities:
        return _CAPABILITIES

    async def start(self) -> None:  # pragma: no cover — v0.3.0 no-op
        return None

    async def stop(self) -> None:  # pragma: no cover — v0.3.0 no-op
        return None

    async def run_turn(
        self,
        *,
        agent: Agent,
        ctx: Ctx,
        msg: IncomingMessage,
    ) -> None:
        """Run one turn through `ClaudeSDKClient`, preserving v0.2 behaviour.

        The client is constructed **inside this coroutine** (and therefore
        inside ``bind_ctx`` from the turn worker) so every tool invoked by
        the SDK observes the current `Ctx` via `current_ctx()`. Constructing
        outside would capture the wrong ContextVar snapshot and cause tool
        handlers to raise `LookupError`.
        """
        from claude_agent_sdk import ClaudeSDKClient

        session_id = await self._resolve_session_id(ctx, msg)
        system_prompt_override = ctx.state.get("composed_prompt")
        options = agent.build_options(
            mcp_server_key=self._mcp_server_key,
            session_id=session_id,
            system_prompt_override=system_prompt_override,
        )
        if ctx.tracer is not None:
            options.hooks = build_hooks(  # type: ignore[assignment]
                ctx.tracer,
                turn_id_provider=lambda: current_ctx().turn_id,
                user_id_provider=lambda: current_ctx().user_id,
                session_id_provider=lambda: current_ctx().session_id,
            )
        async with ClaudeSDKClient(options=options) as client:
            await client.query(msg.text)
            async for chunk in client.receive_response():
                text = getattr(chunk, "text", None)
                if text:
                    await ctx.stream(text)
        await ctx.finalize()

    async def _resolve_session_id(self, ctx: Ctx, msg: IncomingMessage) -> str | None:
        if self._session_lookup is None:
            return None
        return await self._session_lookup(msg.user_id, ctx.channel, msg.thread_key)
