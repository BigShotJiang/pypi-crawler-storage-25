"""Protocol surfaces for the memory views a turn's `Ctx` exposes.

These are the only types `zeno-core` knows about. Concrete stores
(`SqliteSessionStore`, `VectorBackedUserMemoryStore`,
`SqliteConversationStore`, etc.) live in `zeno-memory` and the adapter
packages. `zeno-core` never imports those — it just types `Ctx.memory`
against `MemoryViewProtocol`.

Each `*ViewProtocol` is `runtime_checkable`, allowing tests and lightweight
runtime assertions without creating import-time coupling.

``ConversationHandle`` is re-exported here as a type alias so callers can
annotate arguments without importing from ``zeno-memory``. The alias is
``Any`` at runtime — the real dataclass lives in
``zeno.memory.handles.ConversationHandle`` and callers that need its
methods can import it directly.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

ConversationHandle = Any  # Opaque alias; real type in zeno.memory.handles.


@runtime_checkable
class MemoryHit(Protocol):
    """Structural shape of a single search hit (text + score + meta).

    The concrete dataclass lives in ``zeno.memory.protocols`` (zeno-memory)
    and satisfies this Protocol structurally. Defining the shape here lets
    ``zeno-core`` type view-side returns concretely without importing
    ``zeno-memory`` (which would invert the dependency direction).
    """

    text: str
    score: float
    meta: dict[str, Any]


@runtime_checkable
class UserMemoryViewProtocol(Protocol):
    """Context-bound view of the current user's memory (R25).

    No `user_id` parameter: the binding is carried by the view itself,
    established at turn entry from `Ctx.user_id`.
    """

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None: ...


@runtime_checkable
class KnowledgeViewProtocol(Protocol):
    """Context-bound view of the knowledge base.

    Multi-tenant by default: the underlying adapter filters by the same
    `user_id` that bound this view.
    """

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None: ...


@runtime_checkable
class MemoryViewProtocol(Protocol):
    """Composite view exposing `user`, `knowledge`, `session`, `conversation` handles.

    ``session`` and ``conversation`` are intentionally untyped here —
    ``session`` is a ``SessionStore`` adapter pointer the turn worker uses
    out-of-band, and ``conversation`` is a ``ConversationHandle`` whose
    real definition lives in ``zeno.memory.handles`` (see the module-level
    ``ConversationHandle`` alias for annotations).
    """

    user: UserMemoryViewProtocol
    knowledge: KnowledgeViewProtocol
    session: Any
    conversation: Any


@runtime_checkable
class MemoryBinderProtocol(Protocol):
    """Builds a fresh per-turn `MemoryViewProtocol` bound to `user_id`.

    Implementations (e.g. `zeno.memory.ThreeLayer`) own references to the
    concrete stores and materialize a `MemoryView` per turn so cross-user
    isolation (S7) is enforced structurally — the handle a tool sees has
    already captured `user_id`, and there is no path back to another user's
    rows without going around the handle entirely.
    """

    def view_for(
        self, *, user_id: str, channel: str, thread_key: str | None
    ) -> MemoryViewProtocol: ...
