"""Public protocols defining the surfaces that `zeno-core` exposes to callers.

These are kept here — not in `zeno-memory` or any other package — so
`zeno-core` never has to import from its peer packages. `Ctx.memory` is
typed against `MemoryViewProtocol`; concrete implementations live in
`zeno-memory`.
"""

from __future__ import annotations

from zeno.protocols.memory import (
    KnowledgeViewProtocol,
    MemoryBinderProtocol,
    MemoryViewProtocol,
    UserMemoryViewProtocol,
)
from zeno.protocols.secrets import SecretsStore

__all__ = [
    # Memory protocols
    "KnowledgeViewProtocol",
    "MemoryBinderProtocol",
    "MemoryViewProtocol",
    "UserMemoryViewProtocol",
    # Secrets protocol
    "SecretsStore",
]
