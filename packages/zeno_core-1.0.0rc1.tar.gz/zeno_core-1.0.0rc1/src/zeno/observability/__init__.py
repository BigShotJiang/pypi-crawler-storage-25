"""Observability primitives — tracer, event types, hook bridge, failure policies."""

from __future__ import annotations

from zeno.observability.events import (
    InboundMessage,
    MemoryRead,
    MemoryWrite,
    OutboundConfirmed,
    OutboundDispatched,
    SchedulerFireConsumed,
    SchedulerFireErrored,
    SchedulerFireQueued,
    SendFailed,
    SubAgentCompleted,
    SubAgentStarted,
    ToolCallCompleted,
    ToolCallStarted,
    TraceEvent,
    TriggerCancelled,
    TriggerDropped,
    TurnCompleted,
    TurnFailed,
    TurnStarted,
    event_payload,
)
from zeno.observability.sdk_hooks import build_hooks
from zeno.observability.tracer import BackgroundDispatcher, NoOpTracer, StdoutTracer, Tracer

__all__ = [
    # Event types
    "InboundMessage",
    "MemoryRead",
    "MemoryWrite",
    "OutboundConfirmed",
    "OutboundDispatched",
    "SchedulerFireConsumed",
    "SchedulerFireErrored",
    "SchedulerFireQueued",
    "SendFailed",
    "SubAgentCompleted",
    "SubAgentStarted",
    "ToolCallCompleted",
    "ToolCallStarted",
    "TraceEvent",
    "TriggerCancelled",
    "TriggerDropped",
    "TurnCompleted",
    "TurnFailed",
    "TurnStarted",
    # Event helpers
    "event_payload",
    # SDK hook bridge
    "build_hooks",
    # Tracers
    "BackgroundDispatcher",
    "NoOpTracer",
    "StdoutTracer",
    "Tracer",
]
