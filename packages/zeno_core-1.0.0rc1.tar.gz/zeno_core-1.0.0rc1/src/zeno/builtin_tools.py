"""Built-in `recall` / `remember` tools (R23, R24).

These are opt-in — users attach them explicitly:

    from zeno.builtin_tools import recall, remember
    agent = Agent(name="root", instructions="...", tools=[recall, remember])

`recall` lets the model fetch facts that the auto-inject middleware may
not have surfaced (different phrasing, higher-k search, explicit
knowledge lookup). `remember` is how the model persists a fact it just
learned from the user ("my dog's name is Otto"). Both are first-class
`@tool`s, so they get validated schemas and flow through the same MCP
registration path as user-defined tools.

Semantics:
  - Both tools require the current `Ctx`; they read memory views off
    `ctx.memory`. The `@tool` wrapper enforces the `Ctx`-first signature.
  - `memory` arg is a `Literal["user", "knowledge"]` — no typos.
  - `recall` returns a newline-joined `- {text}` bullet list (model-friendly).
  - `remember` returns a short confirmation string.
"""

from __future__ import annotations

import contextlib
import hashlib
from typing import Literal

from zeno.context import Ctx
from zeno.observability.events import MemoryRead, MemoryWrite, _Envelope
from zeno.protocols.memory import KnowledgeViewProtocol, UserMemoryViewProtocol
from zeno.runtime.noop_memory import NoOpMemoryView
from zeno.tool import tool

__all__ = [
    "recall",
    "remember",
]

_MemoryName = Literal["user", "knowledge"]

_STORE_NAMES: dict[_MemoryName, str] = {
    "user": "user_memory",
    "knowledge": "knowledge",
}


@tool
async def recall(
    ctx: Ctx,
    query: str,
    memory: _MemoryName = "user",
    k: int = 5,
) -> str:
    """Search user memory or knowledge for facts matching `query`."""
    view = _pick_view(ctx, memory)
    hits = await view.search(query, k=k)
    _emit_memory_read(ctx, _STORE_NAMES[memory], query, len(hits))
    if not hits:
        return f"No {memory} memory hits for: {query}"
    lines = [f"- {hit.text}" for hit in hits]
    return "\n".join(lines)


@tool
async def remember(
    ctx: Ctx,
    text: str,
    memory: _MemoryName = "user",
) -> str:
    """Persist a fact to user memory or knowledge for later recall."""
    view = _pick_view(ctx, memory)
    await view.add(text)
    _emit_memory_write(ctx, _STORE_NAMES[memory])
    return f"Stored in {memory} memory: {text}"


def _pick_view(ctx: Ctx, memory: _MemoryName) -> UserMemoryViewProtocol | KnowledgeViewProtocol:
    if memory == "user":
        return ctx.memory.user
    if memory == "knowledge":
        return ctx.memory.knowledge
    # Literal narrowing should make this unreachable, but keep a safety net
    # for callers that bypass the type system.
    raise ValueError(f"Unknown memory kind: {memory!r}")


def _emit_memory_read(ctx: Ctx, store: str, query: str, result_count: int) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    query_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()[:12]
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            MemoryRead(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                store=store,
                query_hash=query_hash,
                result_count=result_count,
            )
        )


def _emit_memory_write(ctx: Ctx, store: str) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            MemoryWrite(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                store=store,
            )
        )
