"""`Agent` / `SubAgent` composition + translation to `ClaudeAgentOptions` (R10–R12).

Agent authors compose an assistant as:

    root = Agent(
        name="root",
        instructions="You are a helpful personal assistant.",
        tools=[recall, add_note],
        built_in_tools=["WebSearch", "WebFetch"],
        permission_mode="bypassPermissions",
        sub_agents=[
            SubAgent(
                name="researcher",
                instructions="...",
                tools=[web_search],
                built_in_tools=["WebFetch"],
            ),
        ],
    )

    options = root.build_options(mcp_server_key="zeno_app", session_id=sid)

Semantics enforced here:
  - First positional of every `@tool` function is `Ctx`; see `zeno.tool`.
  - If `sub_agents` is non-empty, core auto-appends `"Agent"` to `allowed_tools`
    so the Claude Agent SDK routes sub-agent dispatches to the `AgentDefinition`s
    we pass in. `"Agent"` is the canonical tool name in the current bundled CLI;
    `"Task"` remains as a CLI-side alias but we emit only the canonical form.
  - Every sub-agent gets its own per-sub-agent MCP server key
    (`f"{mcp_server_key}_{sub_agent.name}"`) so tool-name collisions between
    orchestrator and sub-agent don't silently overwrite each other.
  - `built_in_tools` names SDK-native tools (e.g. ``"WebSearch"``, ``"Bash"``).
    Names pass through unvalidated so new SDK tools work without a Zeno
    release. Duplicates are deduped; order is preserved for deterministic
    `allowed_tools` output.
  - `permission_mode` threads directly into `ClaudeAgentOptions`. Default is
    `None` (SDK's prompting default). Set ``"bypassPermissions"`` on
    non-interactive channels.
  - `instructions` is the default system prompt; callers may override per turn.
  - `resume=session_id` threads through when provided.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from zeno.exceptions import ZenoError
from zeno.runtime.mcp import allowed_tool_names, build_mcp_server
from zeno.tool import ToolSpec, get_spec

if TYPE_CHECKING:
    from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions
    from zeno.tool import ToolHandler

__all__ = [
    "Agent",
    "SubAgent",
]


@dataclass(frozen=True, slots=True)
class SubAgent:
    """A specialist agent delegated to via the sub-agent dispatch tool.

    `max_turns` caps the internal loop of a single dispatch — how many model
    calls this specialist may make before the SDK forces it to return. It
    maps directly to `AgentDefinition.maxTurns` and is orthogonal to
    `TurnBudget.max_dispatches`, which caps how many times the orchestrator
    may invoke any sub-agent per turn.

    `built_in_tools` names Claude Agent SDK built-ins (e.g. ``"WebSearch"``,
    ``"WebFetch"``, ``"Bash"``) this sub-agent is allowed to call. Names pass
    through to the SDK verbatim — no validation — so new built-ins work
    without a Zeno release. Duplicates are deduped while preserving order.
    """

    name: str
    instructions: str
    tools: list[ToolHandler] = field(default_factory=list)
    model: str | None = None
    max_turns: int | None = None
    built_in_tools: list[str] = field(default_factory=list)

    def _tool_specs(self) -> list[ToolSpec]:
        return [get_spec(t) for t in self.tools]


@dataclass(frozen=True, slots=True)
class Agent:
    """Composite agent: instructions + tools + optional sub-agents.

    `sub_agents` is a plain list by type, but `Agent` is frozen — callers
    wiring in discovered sub-agents (entry-point plugins) must rebuild the
    root via `dataclasses.replace(agent, sub_agents=[...])` rather than
    mutating in place.

    `built_in_tools` names Claude Agent SDK built-ins (e.g. ``"WebSearch"``,
    ``"WebFetch"``, ``"Bash"``) the orchestrator is allowed to call. Names
    pass through to the SDK verbatim — no validation — so new built-ins
    work without a Zeno release. Duplicates are deduped while preserving
    order. Sub-agents declare their own ``built_in_tools`` independently.

    `permission_mode` controls the SDK's tool-execution gate and is passed
    through to ``ClaudeAgentOptions.permission_mode`` unchanged. Valid
    values: ``"default"`` (prompt), ``"acceptEdits"``, ``"bypassPermissions"``,
    ``"plan"``. Leave unset for SDK default (prompting). For non-interactive
    channels (Slack, cron, headless apps), set ``"bypassPermissions"``
    explicitly — otherwise the SDK blocks on prompts that nobody can answer.
    """

    name: str
    instructions: str
    tools: list[ToolHandler] = field(default_factory=list)
    sub_agents: list[SubAgent] = field(default_factory=list)
    model: str | None = None
    built_in_tools: list[str] = field(default_factory=list)
    permission_mode: str | None = None

    def __post_init__(self) -> None:
        names = [sa.name for sa in self.sub_agents]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ZenoError(f"Agent '{self.name}' has duplicate sub-agent names: {sorted(dupes)}")

    def _tool_specs(self) -> list[ToolSpec]:
        return [get_spec(t) for t in self.tools]

    def build_options(
        self,
        *,
        mcp_server_key: str,
        session_id: str | None = None,
        system_prompt_override: str | None = None,
    ) -> ClaudeAgentOptions:
        """Translate this `Agent` tree into a `ClaudeAgentOptions`."""
        from claude_agent_sdk import ClaudeAgentOptions

        root_specs = self._tool_specs()
        allowed = allowed_tool_names(mcp_server_key, root_specs)
        # Union in SDK built-ins before appending the "Agent" sentinel so
        # sub-agent routing lands last. `dict.fromkeys` dedupes while
        # preserving insertion order — tests assert list order, so a plain
        # `set(...)` would be a regression.
        if self.built_in_tools:
            allowed = list(dict.fromkeys([*allowed, *self.built_in_tools]))
        mcp_servers: dict[str, object] = {
            mcp_server_key: build_mcp_server(mcp_server_key, root_specs),
        }

        agents: dict[str, AgentDefinition] = {}
        for sa in self.sub_agents:
            sa_key = f"{mcp_server_key}_{sa.name}"
            sa_specs = sa._tool_specs()
            if sa_specs:
                mcp_servers[sa_key] = build_mcp_server(sa_key, sa_specs)
            agents[sa.name] = _to_agent_definition(sa, sa_key)

        if self.sub_agents:
            allowed = [*allowed, "Agent"]

        return ClaudeAgentOptions(
            system_prompt=system_prompt_override or self.instructions,
            allowed_tools=allowed,
            mcp_servers=mcp_servers,  # type: ignore[arg-type]
            agents=agents or None,
            model=self.model,
            permission_mode=self.permission_mode,  # type: ignore[arg-type]
            resume=session_id,
        )


def _to_agent_definition(sub_agent: SubAgent, mcp_server_key: str) -> AgentDefinition:
    """Translate a `SubAgent` into the SDK's `AgentDefinition`."""
    from claude_agent_sdk import AgentDefinition

    specs = sub_agent._tool_specs()
    tool_names = allowed_tool_names(mcp_server_key, specs)
    if sub_agent.built_in_tools:
        tool_names = list(dict.fromkeys([*tool_names, *sub_agent.built_in_tools]))
    return AgentDefinition(
        description=sub_agent.instructions.split("\n", 1)[0].strip(),
        prompt=sub_agent.instructions,
        tools=tool_names,
        model=sub_agent.model,
        mcpServers=[mcp_server_key] if specs else None,
        maxTurns=sub_agent.max_turns,
    )
