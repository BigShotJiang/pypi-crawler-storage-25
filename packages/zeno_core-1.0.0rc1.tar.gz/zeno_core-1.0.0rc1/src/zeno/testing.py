"""Test doubles shipped with `zeno-core` for downstream users and our own tests.

The public names here are part of the v0.3.0 testing surface:

- ``InMemoryConversationStore`` — a ``ConversationStore`` that keeps its log
  in a dict, used in tests and example apps that don't want SQLite on disk.
- ``FakeProvider`` — a canned-response ``Provider`` implementation for unit
  tests of handlers, apps, and tools. Accepts configurable ``Capabilities``
  flags and an optional ``on_turn`` callback to customise ``run_turn``.
- ``FakeSecretsStore`` — in-memory ``SecretsStore`` for tool and app tests.
  Never reads ``os.environ``; raises ``SecretNotFoundError`` on miss.
- ``FakeChannel`` — a ``Channel`` stand-in for tests covering the channel
  loop or the Scheduler's ``inbound_put`` path. Exposes ``inbox`` and
  ``sent`` so tests can drive turns and assert replies.

These are lightweight enough to live in ``zeno-core`` rather than a
dedicated ``zeno-testing`` package; we may split them out if the surface
grows meaningfully.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping, Sequence
from typing import TYPE_CHECKING, Any

from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities as ChannelCapabilities
from zeno.exceptions import SecretNotFoundError
from zeno.providers.protocol import Capabilities

__all__ = [
    "FakeChannel",
    "FakeProvider",
    "FakeSecretsStore",
    "InMemoryConversationStore",
]

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.context import Ctx
    from zeno.memory.protocols import ConversationMessage


class InMemoryConversationStore:
    """Dict-backed `ConversationStore` for tests and example apps."""

    def __init__(self) -> None:
        self._rows: dict[tuple[str, str | None], list[ConversationMessage]] = {}

    async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]:
        return list(self._rows.get((user_id, thread_key), ()))

    async def append(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        messages: Sequence[ConversationMessage],
    ) -> None:
        bucket = self._rows.setdefault((user_id, thread_key), [])
        bucket.extend(messages)

    async def clear(self, *, user_id: str, thread_key: str | None) -> None:
        self._rows.pop((user_id, thread_key), None)


OnTurn = Callable[["Agent", "Ctx", "IncomingMessage"], Awaitable[None]]


class FakeProvider:
    """In-process `Provider` stand-in for tests.

    Constructor flags default to an all-permissive capability set so
    happy-path tests don't need to spell them out. Override any flag to
    exercise the capability-check code in `ZenoApp.start()`.

    ``on_turn`` is an optional async callback invoked inside ``run_turn``
    with the same keyword arguments. Tests that want to assert tool
    dispatch, streaming, or reply behaviour wire it to whatever custom
    handler body they need. If ``on_turn`` is ``None`` the provider is a
    silent no-op and the turn worker's finally-block handles buffer
    finalization.
    """

    def __init__(
        self,
        *,
        supports_sub_agents: bool = True,
        supports_built_in_tools: bool = True,
        supports_permission_mode: bool = True,
        supports_streaming: bool = True,
        on_turn: OnTurn | None = None,
    ) -> None:
        self._capabilities = Capabilities(
            supports_sub_agents=supports_sub_agents,
            supports_built_in_tools=supports_built_in_tools,
            supports_permission_mode=supports_permission_mode,
            supports_streaming=supports_streaming,
        )
        self._on_turn = on_turn
        self.start_calls = 0
        self.stop_calls = 0
        self.run_turn_calls: list[tuple[Agent, Ctx, IncomingMessage]] = []

    @property
    def capabilities(self) -> Capabilities:
        return self._capabilities

    async def start(self) -> None:
        self.start_calls += 1

    async def stop(self) -> None:
        self.stop_calls += 1

    async def run_turn(self, *, agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        self.run_turn_calls.append((agent, ctx, msg))
        if self._on_turn is not None:
            await self._on_turn(agent, ctx, msg)


class FakeSecretsStore:
    """In-memory `SecretsStore` for tool and app tests.

    Constructed with an initial `{name: value}` mapping. `get(name)`
    returns the value if present, raises `SecretNotFoundError(name)`
    otherwise. Never touches `os.environ`.

    `get_calls` records every key asked for, in call order, so tests
    that care about cache hits / idempotency / call count can assert
    against it directly. `set(name, value)` is a convenience for tests
    that want to simulate rotation mid-turn; it is not part of the
    `SecretsStore` protocol.
    """

    def __init__(self, mapping: Mapping[str, str] | None = None) -> None:
        self._mapping: dict[str, str] = dict(mapping or {})
        self.get_calls: list[str] = []

    async def get(self, name: str) -> str:
        self.get_calls.append(name)
        try:
            return self._mapping[name]
        except KeyError as exc:
            raise SecretNotFoundError(name) from exc

    async def set(self, name: str, value: str) -> None:
        self._mapping[name] = value


_SHUTDOWN_SENTINEL: Any = object()


class FakeChannel:
    """In-memory `Channel` for unit tests.

    Combines the patterns we previously copied as `_FakeChannel` clones:

    - Streaming `receive()` for tests of the channel-loop in `ZenoApp.run()`
    - `inbound_put()` for tests of the Scheduler firing into a channel
    - `sent` / `received` lists for assertion
    - `started` / `stopped` flags for lifecycle assertion

    `inbound_put` records to `received` *and* puts to `inbox`, so the same
    instance can be used as either a Scheduler target or a turn source.

    Call `shutdown()` to terminate the `receive()` iterator from the test
    side; otherwise the iterator awaits forever and tests rely on
    `app.request_shutdown()` to cancel the surrounding task.
    """

    def __init__(
        self,
        *,
        name: str = "fake",
        supports_streaming: bool = False,
    ) -> None:
        self.name = name
        self.supports_streaming = supports_streaming
        self.inbox: asyncio.Queue[IncomingMessage] = asyncio.Queue()
        self.received: list[IncomingMessage] = []
        self.sent: list[OutgoingMessage] = []
        self.started = False
        self.stopped = False

    @property
    def capabilities(self) -> ChannelCapabilities:
        return ChannelCapabilities(supports_streaming=self.supports_streaming)

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while True:
            msg = await self.inbox.get()
            if msg is _SHUTDOWN_SENTINEL:
                return
            yield msg

    async def send(self, msg: OutgoingMessage) -> None:
        self.sent.append(msg)

    async def inbound_put(self, msg: IncomingMessage) -> None:
        self.received.append(msg)
        await self.inbox.put(msg)

    def shutdown(self) -> None:
        """Signal the `receive()` iterator to terminate."""
        self.inbox.put_nowait(_SHUTDOWN_SENTINEL)
