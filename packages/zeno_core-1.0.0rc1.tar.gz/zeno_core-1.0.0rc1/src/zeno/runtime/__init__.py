"""Runtime utilities for Zeno — auto-inject, turn dispatch, and streaming."""

from __future__ import annotations

from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt
from zeno.runtime.streaming import StreamBuffer
from zeno.runtime.turn_worker import (
    AgentHandler,
    SendErrorHandler,
    TurnDispatcher,
    TurnErrorHandler,
)

__all__ = [
    # Auto-inject middleware
    "AutoInjectConfig",
    "compose_system_prompt",
    # Streaming
    "StreamBuffer",
    # Turn dispatch
    "AgentHandler",
    "SendErrorHandler",
    "TurnDispatcher",
    "TurnErrorHandler",
]
