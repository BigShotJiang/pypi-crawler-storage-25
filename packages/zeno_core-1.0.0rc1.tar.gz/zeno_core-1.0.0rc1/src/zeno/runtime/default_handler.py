"""Default turn handler — composes system prompt then dispatches to the provider.

The v0.3.0 replacement for the user-supplied ``agent_handler`` seam. `ZenoApp.run()`
wires `make_default_handler(...)` into `TurnDispatcher` as the `AgentHandler`. The
handler is a tiny closure:

1. Call `compose_system_prompt(ctx, msg.text, agent.instructions, config=auto_inject)`.
2. Write the result into `ctx.state["composed_prompt"]` — a well-known key providers
   read (see `Provider` protocol docstring). Providers MUST NOT mutate it.
3. Invoke `provider.run_turn(...)` wrapped in `asyncio.wait_for(..., turn_timeout)` so a
   wedged provider cannot block the per-thread FIFO forever (KD11). A timeout raises
   `asyncio.TimeoutError`, which the turn worker catches as `on_turn_error`.

Kept as a free factory (not a `ZenoApp` method) so `TurnDispatcher` keeps its
existing `agent_handler: AgentHandler` seam — unit tests can substitute a different
handler without reaching into `ZenoApp`.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx
    from zeno.providers.protocol import Provider
    from zeno.runtime.turn_worker import AgentHandler


def make_default_handler(
    *,
    agent: Agent,
    provider: Provider,
    auto_inject: AutoInjectConfig | None = None,
    turn_timeout: float = 120.0,
) -> AgentHandler:
    """Build the closure wired into `TurnDispatcher` as `agent_handler`."""
    cfg = auto_inject or AutoInjectConfig()

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        composed = await compose_system_prompt(ctx, msg.text, agent.instructions, config=cfg)
        ctx.state["composed_prompt"] = composed
        await asyncio.wait_for(
            provider.run_turn(agent=agent, ctx=ctx, msg=msg), timeout=turn_timeout
        )

    return handler
