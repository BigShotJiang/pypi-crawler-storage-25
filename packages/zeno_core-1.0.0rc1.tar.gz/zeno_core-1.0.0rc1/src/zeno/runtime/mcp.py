"""In-process MCP server assembly for Zeno tools.

The Claude Agent SDK exposes `create_sdk_mcp_server(name, version, tools)`
which returns a `McpSdkServerConfig` ready to pass into
`ClaudeAgentOptions(mcp_servers={server_key: server})`. Zeno's
`build_mcp_server` is a thin convenience that turns a list of `ToolSpec`
objects into that shape.

Tool names seen by the SDK follow the canonical `mcp__<server_key>__<tool_name>`
format; see `Agent.build_options` (Unit 4).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from zeno.tool import ToolSpec

if TYPE_CHECKING:
    pass


def build_mcp_server(server_key: str, specs: list[ToolSpec], *, version: str = "1.0.0") -> Any:
    """Build an `McpSdkServerConfig` from a list of `ToolSpec`s.

    The returned value is passed directly as
    `ClaudeAgentOptions.mcp_servers = {server_key: result}`.
    """
    from claude_agent_sdk import create_sdk_mcp_server

    return create_sdk_mcp_server(
        name=server_key,
        version=version,
        tools=[spec.to_sdk_tool() for spec in specs],
    )


def allowed_tool_names(server_key: str, specs: list[ToolSpec]) -> list[str]:
    """Return the `mcp__<server>__<tool>` names the SDK expects in `allowed_tools`."""
    return [f"mcp__{server_key}__{spec.name}" for spec in specs]
