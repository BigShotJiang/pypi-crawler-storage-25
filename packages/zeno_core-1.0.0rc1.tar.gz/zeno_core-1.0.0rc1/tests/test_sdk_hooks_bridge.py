"""Tests for the SDK hook bridge — probe behavior + emit translations."""

from __future__ import annotations

import sys
from collections.abc import Iterator
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock

import pytest
from zeno.observability import sdk_hooks as hooks_mod
from zeno.observability.events import (
    InboundMessage,
    SubAgentStarted,
    ToolCallCompleted,
    ToolCallStarted,
)
from zeno.observability.sdk_hooks import build_hooks


@pytest.fixture(autouse=True)
def _reset_probe_flag() -> Iterator[None]:
    hooks_mod._probe_reported = False
    yield
    hooks_mod._probe_reported = False


def _install_fake_sdk_types(monkeypatch: pytest.MonkeyPatch, *names: str) -> None:
    fake_types = SimpleNamespace(**{n: type(n, (), {}) for n in names})
    fake_module = SimpleNamespace(types=fake_types)
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_module)
    monkeypatch.setitem(sys.modules, "claude_agent_sdk.types", fake_types)


def _uninstall_fake_sdk(monkeypatch: pytest.MonkeyPatch) -> None:
    # Make import fail to simulate the SDK not being installed.
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", None)
    monkeypatch.setitem(sys.modules, "claude_agent_sdk.types", None)


async def _invoke(hooks: dict[str, Any], event: str, payload: dict[str, Any]) -> object:
    """Call the hook callback regardless of whether it is wrapped in `HookMatcher`.

    When the real SDK is importable, `build_hooks` wraps callbacks as
    `[HookMatcher(hooks=[cb])]`. When the SDK is absent or the types module is
    stubbed without `HookMatcher`, it falls back to a bare callable map.
    """
    entry = hooks[event]
    if isinstance(entry, list):
        return await entry[0].hooks[0](payload)
    return await entry(payload)


async def test_core_hooks_always_bound() -> None:
    tracer = MagicMock()
    hooks = build_hooks(tracer)
    assert "PreToolUse" in hooks
    assert "PostToolUse" in hooks
    assert "UserPromptSubmit" in hooks


async def test_pre_tool_use_emits_tool_call_started() -> None:
    tracer = MagicMock()
    hooks = build_hooks(tracer, turn_id_provider=lambda: "turn-1")
    ack = await _invoke(hooks, "PreToolUse", {"tool_name": "search", "tool_use_id": "u1"})

    assert ack == {"async_": True, "asyncTimeout": 5000}
    tracer.on_event.assert_called_once()
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, ToolCallStarted)
    assert event.tool_name == "search"
    assert event.tool_use_id == "u1"
    assert event.envelope.turn_id == "turn-1"


async def test_post_tool_use_emits_tool_call_completed_honoring_is_error() -> None:
    tracer = MagicMock()
    hooks = build_hooks(tracer)
    await _invoke(
        hooks, "PostToolUse", {"tool_name": "search", "tool_use_id": "u1", "is_error": True}
    )
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, ToolCallCompleted)
    assert event.error is True


async def test_user_prompt_submit_emits_inbound_message_metadata_only() -> None:
    tracer = MagicMock()
    hooks = build_hooks(tracer)
    await _invoke(hooks, "UserPromptSubmit", {"prompt": "hello world"})
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, InboundMessage)
    assert event.text_length == len("hello world")


async def test_optional_hooks_bind_when_sdk_surface_present(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake_sdk_types(
        monkeypatch,
        "SubagentStartHookInput",
        "SubagentStopHookInput",
        "PostToolUseFailureHookInput",
    )
    tracer = MagicMock()
    hooks = build_hooks(tracer)
    assert "SubagentStart" in hooks
    assert "SubagentStop" in hooks
    assert "PostToolUseFailure" in hooks

    await _invoke(hooks, "SubagentStart", {"sub_agent": "researcher"})
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, SubAgentStarted)
    assert event.sub_agent_name == "researcher"


async def test_optional_hooks_skipped_and_logged_once_when_absent(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    _install_fake_sdk_types(monkeypatch)  # no optional hook types present
    tracer = MagicMock()
    with caplog.at_level("INFO", logger="zeno.observability"):
        hooks = build_hooks(tracer)
    assert "SubagentStart" not in hooks
    assert "SubagentStop" not in hooks
    assert "PostToolUseFailure" not in hooks
    messages = [r.getMessage() for r in caplog.records]
    assert any("Sub-agent lifecycle hooks unavailable" in m for m in messages), messages


async def test_probe_tolerates_missing_sdk(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    _uninstall_fake_sdk(monkeypatch)
    tracer = MagicMock()
    with caplog.at_level("INFO", logger="zeno.observability"):
        hooks = build_hooks(tracer)
    # Core hooks are still present; optional ones are not.
    assert "PreToolUse" in hooks
    assert "SubagentStart" not in hooks


async def test_tracer_raising_is_caught(monkeypatch: pytest.MonkeyPatch) -> None:
    tracer = MagicMock()
    tracer.on_event.side_effect = RuntimeError("tracer down")
    hooks = build_hooks(tracer)
    # Must not raise into the SDK's hook loop.
    ack = await _invoke(hooks, "PreToolUse", {"tool_name": "search", "tool_use_id": "u1"})
    assert ack == {"async_": True, "asyncTimeout": 5000}


def test_build_hooks_uses_providers_for_envelope() -> None:
    tracer = MagicMock()
    hooks = build_hooks(
        tracer,
        turn_id_provider=lambda: "t99",
        user_id_provider=lambda: "alice",
        session_id_provider=lambda: "sess-1",
    )
    assert set(hooks.keys()) >= {"PreToolUse", "PostToolUse", "UserPromptSubmit"}


def test_extract_handles_dict_and_attribute_payloads() -> None:
    payload = SimpleNamespace(tool_name="x", tool_use_id="u")
    assert hooks_mod._extract(payload, "tool_name") == "x"
    assert hooks_mod._extract({"toolName": "y"}, "tool_name", "toolName") == "y"
    assert hooks_mod._extract({}, "tool_name") is None


def test_build_hooks_wraps_callbacks_in_hook_matchers_when_sdk_present() -> None:
    """The SDK's `_convert_hooks_to_internal_format` iterates matchers reading
    `matcher.hooks`, so a bare callable value is silently dropped. The bridge
    must return `[HookMatcher(hooks=[cb])]` entries when the SDK is importable.
    """
    try:
        from claude_agent_sdk.types import HookMatcher
    except ImportError:
        pytest.skip("claude_agent_sdk not installed; wrapping is a no-op")

    tracer = MagicMock()
    hooks = build_hooks(tracer)
    entry = hooks["PreToolUse"]
    assert isinstance(entry, list)
    assert len(entry) == 1
    assert isinstance(entry[0], HookMatcher)
    assert callable(entry[0].hooks[0])
