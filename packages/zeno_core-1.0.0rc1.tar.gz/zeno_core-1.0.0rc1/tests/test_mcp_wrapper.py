"""Tests for `zeno.runtime.mcp.build_mcp_server` + `allowed_tool_names`."""

from __future__ import annotations

from zeno.context import Ctx
from zeno.runtime.mcp import allowed_tool_names, build_mcp_server
from zeno.tool import get_spec, tool


def test_allowed_tool_names_format() -> None:
    @tool
    async def foo(ctx: Ctx) -> str:
        return "ok"

    @tool
    async def bar(ctx: Ctx, x: int) -> str:
        return "ok"

    specs = [get_spec(foo), get_spec(bar)]
    assert allowed_tool_names("zeno_app", specs) == [
        "mcp__zeno_app__foo",
        "mcp__zeno_app__bar",
    ]


def test_build_mcp_server_round_trip() -> None:
    @tool
    async def hello(ctx: Ctx, name: str) -> str:
        return f"hi {name}"

    server = build_mcp_server("zeno_app", [get_spec(hello)])
    # `create_sdk_mcp_server` returns a dict-like McpSdkServerConfig.
    # Shape: {"type": "sdk", "name": "zeno_app", "instance": <server>}.
    assert server["type"] == "sdk"
    assert server["name"] == "zeno_app"
