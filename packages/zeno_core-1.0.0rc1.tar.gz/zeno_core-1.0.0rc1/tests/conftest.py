"""Shared fixtures for `zeno-core` tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from zeno.context import Ctx
from zeno.protocols.memory import (
    KnowledgeViewProtocol,
    MemoryViewProtocol,
    UserMemoryViewProtocol,
)


@dataclass
class _FakeUserMemoryView(UserMemoryViewProtocol):
    async def search(self, query: str, k: int = 5) -> list[Any]:
        return []

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


@dataclass
class _FakeKnowledgeView(KnowledgeViewProtocol):
    async def search(self, query: str, k: int = 5) -> list[Any]:
        return []

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


@dataclass
class _FakeMemoryView(MemoryViewProtocol):
    user: _FakeUserMemoryView
    knowledge: _FakeKnowledgeView
    session: Any = None


@pytest.fixture
def fake_http_client() -> httpx.AsyncClient:
    """An `httpx.AsyncClient` pointed at a no-op transport."""
    return httpx.AsyncClient(transport=httpx.MockTransport(lambda req: httpx.Response(200)))


@pytest.fixture
def fake_ctx(fake_http_client: httpx.AsyncClient) -> Ctx:
    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=_FakeMemoryView(user=_FakeUserMemoryView(), knowledge=_FakeKnowledgeView()),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=fake_http_client,
        logger=MagicMock(),
        tracer=MagicMock(),
    )
