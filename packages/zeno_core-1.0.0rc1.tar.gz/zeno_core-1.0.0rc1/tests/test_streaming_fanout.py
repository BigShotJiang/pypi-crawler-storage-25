"""Tests for the `StreamBuffer` — chunk-to-channel fan-out."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.runtime.streaming import StreamBuffer


@dataclass
class _CaptureChannel:
    supports_streaming: bool
    sent: list[OutgoingMessage] = field(default_factory=list)

    @property
    def name(self) -> str:
        return "capture"

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(supports_streaming=self.supports_streaming)

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        if False:
            yield  # pragma: no cover
        return

    async def send(self, msg: Any) -> None:
        self.sent.append(msg)


async def test_streaming_channel_sends_each_chunk_partial() -> None:
    ch = _CaptureChannel(supports_streaming=True)
    buf = StreamBuffer(channel=ch, reply_to_thread_key="t1")

    await buf.emit_chunk("hel")
    await buf.emit_chunk("lo")
    await buf.finalize()

    assert len(ch.sent) == 2
    assert ch.sent[0].text == "hel"
    assert ch.sent[1].text == "lo"
    assert all(m.reply_to_thread_key == "t1" for m in ch.sent)


async def test_non_streaming_channel_sends_one_consolidated() -> None:
    ch = _CaptureChannel(supports_streaming=False)
    buf = StreamBuffer(channel=ch)

    await buf.emit_chunk("hel")
    await buf.emit_chunk("lo")
    await buf.finalize()

    assert len(ch.sent) == 1
    assert ch.sent[0].text == "hello"


async def test_finalize_is_idempotent() -> None:
    ch = _CaptureChannel(supports_streaming=False)
    buf = StreamBuffer(channel=ch)
    await buf.emit_chunk("hi")
    await buf.finalize()
    await buf.finalize()
    assert len(ch.sent) == 1


async def test_empty_stream_on_non_streaming_channel_sends_nothing() -> None:
    ch = _CaptureChannel(supports_streaming=False)
    buf = StreamBuffer(channel=ch)
    await buf.finalize()
    assert ch.sent == []


async def test_chunks_after_finalize_are_dropped() -> None:
    ch = _CaptureChannel(supports_streaming=False)
    buf = StreamBuffer(channel=ch)
    await buf.emit_chunk("hi")
    await buf.finalize()
    await buf.emit_chunk(" ignored")
    assert ch.sent[0].text == "hi"
