"""Integration tests for `ZenoApp(secrets=...)` wiring (U2).

Mirrors `test_app_browser_wiring.py` for the secrets broker. Covers:

- `secrets=None` (default) — every turn sees an `EnvSecretsStore`
  instance via `ctx.secrets`.
- Custom store — `ctx.secrets is my_store` inside a turn (identity).
- Custom store — `await ctx.secrets.get("FOO")` inside a tool call
  resolves through the user-supplied store.
- Direct `Ctx(...)` construction with no `secrets=` gets its own
  `EnvSecretsStore` via `field(default_factory=...)` (per-instance).
- `runtime_checkable` `SecretsStore` protocol accepts both the default
  `EnvSecretsStore` and a custom stub.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.context import Ctx
from zeno.protocols.secrets import SecretsStore
from zeno.secrets import EnvSecretsStore
from zeno.testing import FakeProvider, FakeSecretsStore

# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------


@dataclass
class _FakeChannel:
    """Fake channel with an injectable inbox for turn delivery."""

    name: str = "fake"
    inbox: asyncio.Queue[IncomingMessage] = field(default_factory=asyncio.Queue)
    sent: list[OutgoingMessage] = field(default_factory=list)
    started: bool = False
    stopped: bool = False

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities()

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while True:
            msg = await self.inbox.get()
            if msg is _SENTINEL:
                return
            yield msg

    async def send(self, msg: OutgoingMessage) -> None:
        self.sent.append(msg)

    async def inbound_put(self, message: IncomingMessage) -> None:
        await self.inbox.put(message)


_SENTINEL: Any = object()


def _msg(user_id: str = "alice", text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 24, 12, 0, 0, tzinfo=UTC),
    )


async def _drive_one_turn(app: ZenoApp, ch: _FakeChannel, captured: list[Any]) -> None:
    """Boilerplate: start the app, deliver one message, wait for capture, shut down."""
    run_task = asyncio.create_task(app.run())
    await asyncio.sleep(0.05)
    await ch.inbound_put(_msg())
    for _ in range(100):
        if captured:
            break
        await asyncio.sleep(0.05)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


async def test_secrets_default_is_env_store(fake_ctx: Ctx) -> None:
    """`secrets=None` — `ctx.secrets` inside a turn is an `EnvSecretsStore`."""
    ch = _FakeChannel(name="cli")
    captured: list[Any] = []

    async def on_turn(_agent: Agent, ctx: Ctx, _msg: IncomingMessage) -> None:
        captured.append(ctx.secrets)

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )
    await _drive_one_turn(app, ch, captured)

    assert len(captured) == 1
    assert isinstance(captured[0], EnvSecretsStore), "default secrets store must be EnvSecretsStore"


async def test_secrets_custom_store_identity(fake_ctx: Ctx) -> None:
    """`secrets=my_store` — `ctx.secrets is my_store` inside a turn."""
    my_store = FakeSecretsStore({"FOO": "bar"})
    ch = _FakeChannel(name="cli")
    captured: list[Any] = []

    async def on_turn(_agent: Agent, ctx: Ctx, _msg: IncomingMessage) -> None:
        captured.append(ctx.secrets)

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        secrets=my_store,
    )
    await _drive_one_turn(app, ch, captured)

    assert len(captured) == 1
    assert captured[0] is my_store, "ctx.secrets must be the exact store instance passed in"


async def test_secrets_reachable_via_get_in_tool(fake_ctx: Ctx) -> None:
    """`await ctx.secrets.get(name)` inside a turn resolves through the user store."""
    my_store = FakeSecretsStore({"API_KEY": "sk-test-123"})
    ch = _FakeChannel(name="cli")
    captured: list[str] = []

    async def on_turn(_agent: Agent, ctx: Ctx, _msg: IncomingMessage) -> None:
        value = await ctx.secrets.get("API_KEY")
        captured.append(value)

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        secrets=my_store,
    )
    await _drive_one_turn(app, ch, captured)

    assert captured == ["sk-test-123"]
    assert my_store.get_calls == ["API_KEY"]


async def test_secrets_shared_across_turns(fake_ctx: Ctx) -> None:
    """`secrets=None` default resolves once per app — every turn sees the same instance."""
    ch = _FakeChannel(name="cli")
    captured: list[Any] = []

    async def on_turn(_agent: Agent, ctx: Ctx, _msg: IncomingMessage) -> None:
        captured.append(ctx.secrets)

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())
    await asyncio.sleep(0.05)
    await ch.inbound_put(_msg())
    await ch.inbound_put(_msg(text="hi again"))
    for _ in range(200):
        if len(captured) >= 2:
            break
        await asyncio.sleep(0.05)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert len(captured) >= 2
    assert captured[0] is captured[1], (
        "all turns in one app must share the same EnvSecretsStore instance"
    )


def test_direct_ctx_constructs_own_env_store(fake_http_client: Any) -> None:
    """`Ctx(...)` with no explicit `secrets=` gets a fresh `EnvSecretsStore` per instance."""
    from unittest.mock import AsyncMock, MagicMock

    from zeno.protocols.memory import (
        KnowledgeViewProtocol,
        MemoryViewProtocol,
        UserMemoryViewProtocol,
    )

    @dataclass
    class _U(UserMemoryViewProtocol):
        async def search(self, query: str, k: int = 5) -> list[Any]:
            return []

        async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
            return None

    @dataclass
    class _K(KnowledgeViewProtocol):
        async def search(self, query: str, k: int = 5) -> list[Any]:
            return []

        async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
            return None

    @dataclass
    class _M(MemoryViewProtocol):
        user: _U
        knowledge: _K
        session: Any = None
        conversation: Any = None

    ctx1 = Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=_M(user=_U(), knowledge=_K()),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=fake_http_client,
        logger=MagicMock(),
        tracer=MagicMock(),
    )
    ctx2 = Ctx(
        user_id="bob",
        session_id=None,
        channel="test",
        memory=_M(user=_U(), knowledge=_K()),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=fake_http_client,
        logger=MagicMock(),
        tracer=MagicMock(),
    )

    assert isinstance(ctx1.secrets, EnvSecretsStore)
    assert isinstance(ctx2.secrets, EnvSecretsStore)
    assert ctx1.secrets is not ctx2.secrets, (
        "default_factory must allocate a fresh EnvSecretsStore per Ctx instance"
    )


def test_env_store_matches_secrets_protocol() -> None:
    """`runtime_checkable` `SecretsStore` accepts both the default and a fake."""
    assert isinstance(EnvSecretsStore(), SecretsStore)
    assert isinstance(FakeSecretsStore(), SecretsStore)
