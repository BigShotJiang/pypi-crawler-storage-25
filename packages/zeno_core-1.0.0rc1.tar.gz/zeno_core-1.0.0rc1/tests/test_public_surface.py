"""Snapshot tests pinning the public API surface across all zeno-* packages.

Failure means the public surface changed. Update the expected list ONLY if
the change is intentional and acknowledged in the changelog.
"""

from __future__ import annotations

import importlib

import pytest  # noqa: F401 — imported for parametrize

SURFACE: list[tuple[str, list[str]]] = [
    # zeno-core: standalone top-level modules
    (
        "zeno.agent",
        [
            "Agent",
            "SubAgent",
        ],
    ),
    (
        "zeno.app",
        [
            "ZenoApp",
        ],
    ),
    (
        "zeno.builtin_tools",
        [
            "recall",
            "remember",
        ],
    ),
    (
        "zeno.context",
        [
            "Ctx",
            "FinalizeCallable",
            "ReplyCallable",
            "StreamCallable",
            "bind_ctx",
            "current_ctx",
        ],
    ),
    (
        "zeno.exceptions",
        [
            "ChannelError",
            "ConfigurationError",
            "EntryPointCollisionError",
            "MemoryError",
            "ProviderCapabilityError",
            "ProviderError",
            "SecretNotFoundError",
            "SecretsBackendError",
            "SecretsError",
            "ToolError",
            "ZenoError",
        ],
    ),
    (
        "zeno.testing",
        [
            "FakeChannel",
            "FakeProvider",
            "FakeSecretsStore",
            "InMemoryConversationStore",
        ],
    ),
    (
        "zeno.tool",
        [
            "ToolHandler",
            "ToolSpec",
            "get_spec",
            "tool",
        ],
    ),
    (
        "zeno.version",
        [
            "__version__",
        ],
    ),
    # zeno-channel-cli
    (
        "zeno.channels.cli",
        [
            "ChannelError",
            "CliChannel",
        ],
    ),
    # zeno-channel-email
    (
        "zeno.channels.email",
        [
            "ChannelError",
            "EmailBackendError",
            "EmailChannel",
            "EmailEnvelope",
            "EmailOutbound",
        ],
    ),
    # zeno-channel-sendblue
    (
        "zeno.channels.sendblue",
        [
            "ChannelError",
            "SendblueChannel",
            "SendblueError",
        ],
    ),
    # zeno-chroma
    (
        "zeno.chroma",
        [
            "ChromaKnowledgeStore",
        ],
    ),
    # zeno-core: observability
    (
        "zeno.observability",
        [
            "BackgroundDispatcher",
            "InboundMessage",
            "MemoryRead",
            "MemoryWrite",
            "NoOpTracer",
            "OutboundConfirmed",
            "OutboundDispatched",
            "SchedulerFireConsumed",
            "SchedulerFireErrored",
            "SchedulerFireQueued",
            "SendFailed",
            "StdoutTracer",
            "SubAgentCompleted",
            "SubAgentStarted",
            "ToolCallCompleted",
            "ToolCallStarted",
            "TraceEvent",
            "Tracer",
            "TriggerCancelled",
            "TriggerDropped",
            "TurnCompleted",
            "TurnFailed",
            "TurnStarted",
            "build_hooks",
            "event_payload",
        ],
    ),
    # zeno-core: plugins
    (
        "zeno.plugins",
        [
            "ALL_GROUPS",
            "ZENO_CHANNELS",
            "ZENO_MEMORY_STORES",
            "ZENO_PROVIDERS",
            "ZENO_SUB_AGENTS",
            "ZENO_TOOLS",
            "ZENO_VECTORSTORES",
            "discover",
            "discover_all",
        ],
    ),
    # zeno-core: protocols
    (
        "zeno.protocols",
        [
            "KnowledgeViewProtocol",
            "MemoryBinderProtocol",
            "MemoryViewProtocol",
            "SecretsStore",
            "UserMemoryViewProtocol",
        ],
    ),
    # zeno-core: runtime
    (
        "zeno.runtime",
        [
            "AgentHandler",
            "AutoInjectConfig",
            "SendErrorHandler",
            "StreamBuffer",
            "TurnDispatcher",
            "TurnErrorHandler",
            "compose_system_prompt",
        ],
    ),
    # zeno-core: secrets
    (
        "zeno.secrets",
        [
            "EnvSecretsStore",
            "FileSecretsStore",
        ],
    ),
    # zeno-memory
    (
        "zeno.memory",
        [
            "ConversationHandle",
            "ConversationMessage",
            "ConversationStore",
            "KnowledgeStore",
            "KnowledgeView",
            "MemoryHit",
            "MemoryView",
            "SessionHandle",
            "SessionRecord",
            "SessionStore",
            "ThreeLayer",
            "UserMemoryStore",
            "UserMemoryView",
            "VectorBackedUserMemoryStore",
            "VectorStore",
        ],
    ),
    # zeno-provider-openai
    (
        "zeno.providers.openai",
        [
            "OpenAIProvider",
        ],
    ),
    # zeno-qdrant
    (
        "zeno.qdrant",
        [
            "QdrantKnowledgeStore",
        ],
    ),
    # zeno-scheduler
    (
        "zeno.scheduler",
        [
            "OnMissed",
            "ScheduleError",
            "ScheduleLimitError",
            "ScheduleStore",
            "Scheduler",
            "SqliteScheduleStore",
            "TriggerKind",
            "TriggerRow",
            "cancel_trigger",
            "cancel_trigger_by_name",
            "list_triggers",
            "schedule_cron",
            "schedule_heartbeat",
            "schedule_once",
        ],
    ),
    # zeno-secrets-1password
    (
        "zeno.secrets_1password",
        [
            "OpCliSecretsStore",
            "__version__",
        ],
    ),
    # zeno-tools-browser
    (
        "zeno.tools_browser",
        [
            "BrowserError",
            "BrowserEvaluateJsDisabledError",
            "BrowserLimitError",
            "BrowserSession",
            "BrowserSessionClosedError",
            "BrowserSessionPool",
            "BrowserUrlDeniedError",
            "__version__",
            "browse",
            "click",
            "evaluate_js",
            "extract_links",
            "fill_form",
            "press_key",
            "read_text",
            "screenshot",
            "type_text",
            "wait_for_selector",
        ],
    ),
]


@pytest.mark.parametrize(
    ("module_path", "expected"),
    SURFACE,
    ids=lambda v: v if isinstance(v, str) else "",
)
def test_public_surface(module_path: str, expected: list[str]) -> None:
    mod = importlib.import_module(module_path)
    assert hasattr(mod, "__all__"), f"{module_path} must declare __all__"
    actual = sorted(mod.__all__)
    assert actual == sorted(expected), (
        f"{module_path}.__all__ drifted.\n"
        f"  added: {sorted(set(actual) - set(expected))}\n"
        f"  removed: {sorted(set(expected) - set(actual))}"
    )
