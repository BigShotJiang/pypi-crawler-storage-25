"""Unit 10: stateless `ZenoApp` — `memory=` is optional, defaults to no-op view.

Covers the plan's Unit 10 verification:
    - `ZenoApp(...)` constructs without `memory=`
    - `app.memory` is a `NoOpMemoryView` instance
    - The no-op view satisfies `MemoryViewProtocol` (user/knowledge/conversation)
    - `_make_ctx_factory` binds the no-op view as `Ctx.memory`
    - `auto_inject` runs harmlessly through the no-op user/knowledge views
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any

import httpx
from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage
from zeno.channels.protocol import Capabilities as ChannelCapabilities
from zeno.context import Ctx
from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt
from zeno.runtime.noop_memory import NoOpMemoryView
from zeno.testing import FakeProvider


class _StubChannel:
    name = "cli"
    capabilities = ChannelCapabilities(supports_streaming=False)

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def receive(self) -> AsyncIterator[IncomingMessage]:  # pragma: no cover
        if False:
            yield IncomingMessage(user_id="", text="", received_at=datetime.now())

    async def send(self, _msg: Any) -> None:  # pragma: no cover
        return None


def test_zeno_app_constructs_without_memory_kwarg() -> None:
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        channels=[_StubChannel()],
        provider=FakeProvider(),
    )
    assert isinstance(app.memory, NoOpMemoryView)


async def test_noop_memory_view_satisfies_protocol_surface() -> None:
    view = NoOpMemoryView()
    assert await view.user.search("hi") == []
    await view.user.add("fact")  # returns None — just must not raise
    assert await view.knowledge.search("hi") == []
    await view.knowledge.add("fact")
    assert await view.conversation.load() == []
    await view.conversation.append([])


async def test_ctx_factory_binds_noop_view_when_memory_omitted(
    fake_http_client: httpx.AsyncClient,
) -> None:
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        channels=[_StubChannel()],
        provider=FakeProvider(),
        http_client=fake_http_client,
    )
    factory = app._make_ctx_factory(fake_http_client)
    ctx = factory(
        _StubChannel(),
        IncomingMessage(user_id="u1", text="hello", received_at=datetime(2026, 4, 25, 12, 0, 0)),
    )
    assert isinstance(ctx.memory, NoOpMemoryView)
    assert ctx.memory is app.memory


async def test_ctx_factory_mints_unique_turn_id_per_message(
    fake_http_client: httpx.AsyncClient,
) -> None:
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        channels=[_StubChannel()],
        provider=FakeProvider(),
        http_client=fake_http_client,
    )
    factory = app._make_ctx_factory(fake_http_client)
    ch = _StubChannel()
    ctx_a = factory(
        ch,
        IncomingMessage(user_id="u1", text="hi", received_at=datetime(2026, 4, 25, 12, 0, 0)),
    )
    ctx_b = factory(
        ch,
        IncomingMessage(user_id="u1", text="hi", received_at=datetime(2026, 4, 25, 12, 0, 1)),
    )
    assert ctx_a.turn_id != ctx_b.turn_id
    assert isinstance(ctx_a.turn_id, str)
    assert len(ctx_a.turn_id) >= 8


async def test_auto_inject_runs_through_noop_view_without_error(fake_ctx: Ctx) -> None:
    fake_ctx_with_noop = fake_ctx.__class__(
        user_id=fake_ctx.user_id,
        session_id=fake_ctx.session_id,
        channel=fake_ctx.channel,
        memory=NoOpMemoryView(),
        reply=fake_ctx.reply,
        stream=fake_ctx.stream,
        finalize=fake_ctx.finalize,
        http=fake_ctx.http,
        logger=fake_ctx.logger,
        tracer=fake_ctx.tracer,
        state=fake_ctx.state,
        thread_key=fake_ctx.thread_key,
        secrets=fake_ctx.secrets,
    )
    composed = await compose_system_prompt(
        fake_ctx_with_noop,
        "hello world",
        "Base instructions.",
        config=AutoInjectConfig(enabled_user=True, enabled_knowledge=True),
    )
    assert composed == "Base instructions."
