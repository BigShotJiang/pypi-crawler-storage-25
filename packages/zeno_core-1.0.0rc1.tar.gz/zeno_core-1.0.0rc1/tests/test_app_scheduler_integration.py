"""Integration tests for ZenoApp + Scheduler wiring (U6).

Covers:
- scheduler=None (default) preserves v0.3 behavior: no new tasks, no imports.
- Scheduler wired: trigger fires into channel's inbound queue; agent turn runs.
- Shutdown with in-flight scheduler: no hang within 5 seconds.
- Channel without inbound_put: TriggerDropped emitted, worker loop continues.
- Cross-channel routing: trigger with channel_ref="cli" hits cli only.
- ctx.state["scheduler"] is present in a scheduler-triggered turn.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.context import Ctx
from zeno.testing import FakeProvider

# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------


@dataclass
class _FakeChannel:
    """Fake channel that supports inbound_put for scheduler injection."""

    name: str = "fake"
    inbox: asyncio.Queue[IncomingMessage] = field(default_factory=asyncio.Queue)
    sent: list[OutgoingMessage] = field(default_factory=list)
    started: bool = False
    stopped: bool = False

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities()

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while True:
            msg = await self.inbox.get()
            if msg is _SENTINEL:
                return
            yield msg

    async def send(self, msg: OutgoingMessage) -> None:
        self.sent.append(msg)

    async def inbound_put(self, message: IncomingMessage) -> None:
        """Scheduler-injection point."""
        await self.inbox.put(message)


@dataclass
class _NoInboundChannel:
    """Bare-minimum channel without inbound_put — for TriggerDropped test."""

    name: str = "noinbound"
    _stopped: bool = False

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities()

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        self._stopped = True

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        # Block until stopped; yield nothing (no inbound_put support).
        while not self._stopped:
            await asyncio.sleep(0.05)
        # Async generator — must have at least one yield clause.
        if False:
            yield  # pragma: no cover

    async def send(self, msg: OutgoingMessage) -> None:
        return None


_SENTINEL: Any = object()


def _msg(user_id: str = "alice", text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC),
    )


# ---------------------------------------------------------------------------
# Lazy scheduler import helpers — keep zeno-scheduler out of zeno-core deps
# ---------------------------------------------------------------------------


def _make_scheduler(store: Any, channels: Any = None, now_fn: Any = None) -> Any:
    """Import and construct a Scheduler without importing at module level."""
    from zeno.scheduler.scheduler import Scheduler

    return Scheduler(store, channels or {}, None, now_fn=now_fn)


def _make_store() -> Any:
    from zeno.scheduler.testing import InMemoryScheduleStore

    return InMemoryScheduleStore()


# ---------------------------------------------------------------------------
# Test: scheduler=None preserves v0.3 behavior
# ---------------------------------------------------------------------------


async def test_scheduler_none_no_extra_tasks(fake_ctx: Ctx) -> None:
    """ZenoApp(scheduler=None) runs normally without any scheduler-related tasks."""
    ch = _FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        scheduler=None,
    )
    run_task = asyncio.create_task(app.run())
    await asyncio.sleep(0.05)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert ch.started is True
    assert ch.stopped is True


# ---------------------------------------------------------------------------
# Test: scheduler wired — trigger fires, agent turn runs
# ---------------------------------------------------------------------------


async def test_scheduler_trigger_fires_and_turn_runs(fake_ctx: Ctx) -> None:
    """Bootstrap a one-shot trigger; verify agent receives it through the channel."""
    clock = [datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC)]

    def now_fn() -> datetime:
        return clock[0]

    store = _make_store()
    sched = _make_scheduler(store, now_fn=now_fn)

    # Schedule 1 second in the future (will fire immediately once clock advances).
    await sched.schedule_once(
        user_id="alice",
        thread_key=None,
        channel="cli",
        prompt="triggered!",
        delta=timedelta(seconds=1),
    )

    turns_received: list[str] = []

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        turns_received.append(msg.text)
        await ctx.reply(OutgoingMessage(text=f"ack: {msg.text}"))

    ch = _FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    # Advance clock past the fire time before run() so the first worker cycle fires.
    clock[0] = datetime(2026, 4, 23, 12, 0, 5, tzinfo=UTC)

    run_task = asyncio.create_task(app.run())

    # Wait for the turn to be processed.
    for _ in range(100):
        if turns_received:
            break
        await asyncio.sleep(0.05)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)

    assert "triggered!" in turns_received


# ---------------------------------------------------------------------------
# Test: shutdown with in-flight scheduler — no hang
# ---------------------------------------------------------------------------


async def test_shutdown_with_scheduler_no_hang(fake_ctx: Ctx) -> None:
    """Shutdown with an active scheduler completes within 5 seconds."""
    store = _make_store()
    sched = _make_scheduler(store)

    ch = _FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    run_task = asyncio.create_task(app.run())
    await asyncio.sleep(0.05)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)


# ---------------------------------------------------------------------------
# Test: channel without inbound_put → TriggerDropped, worker continues
# ---------------------------------------------------------------------------


async def test_channel_without_inbound_put_emits_trigger_dropped(
    fake_ctx: Ctx,
) -> None:
    """Trigger aimed at a channel without inbound_put emits TriggerDropped.

    The worker loop must continue without crashing.
    """

    clock = [datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC)]

    def now_fn() -> datetime:
        return clock[0]

    store = _make_store()

    events: list[Any] = []

    class _RecordingTracer:
        def on_event(self, event: Any) -> None:
            events.append(event)

    tracer = _RecordingTracer()
    sched = _make_scheduler(store, now_fn=now_fn)
    sched._tracer = tracer

    # Schedule a trigger aimed at the channel with no inbound_put.
    await sched.schedule_once(
        user_id="alice",
        thread_key=None,
        channel="noinbound",
        prompt="should drop",
        delta=timedelta(seconds=1),
    )

    # Advance clock.
    clock[0] = datetime(2026, 4, 23, 12, 0, 5, tzinfo=UTC)

    noinbound_ch = _NoInboundChannel(name="noinbound")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[noinbound_ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    run_task = asyncio.create_task(app.run())

    # Give the scheduler time to fire and emit TriggerDropped (or FireErrored).
    for _ in range(100):
        if events:
            break
        await asyncio.sleep(0.05)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)

    # The scheduler should have emitted a drop/error event, not crashed.
    assert events, "Expected at least one tracer event (TriggerDropped or FireErrored)"
    # Worker loop still alive through shutdown — no exception in run_task.


# ---------------------------------------------------------------------------
# Test: cross-channel routing — trigger fires into correct channel only
# ---------------------------------------------------------------------------


async def test_cross_channel_routing(fake_ctx: Ctx) -> None:
    """Trigger with channel_ref='cli' fires into cli; sendblue receives nothing."""
    clock = [datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC)]

    def now_fn() -> datetime:
        return clock[0]

    store = _make_store()
    sched = _make_scheduler(store, now_fn=now_fn)

    # Schedule into "cli" only.
    await sched.schedule_once(
        user_id="alice",
        thread_key=None,
        channel="cli",
        prompt="for cli only",
        delta=timedelta(seconds=1),
    )

    cli_ch = _FakeChannel(name="cli")
    other_ch = _FakeChannel(name="other")

    turns: list[tuple[str, str]] = []  # (channel_name, msg_text)

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        turns.append((ctx.channel, msg.text))

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[cli_ch, other_ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    clock[0] = datetime(2026, 4, 23, 12, 0, 5, tzinfo=UTC)
    run_task = asyncio.create_task(app.run())

    for _ in range(100):
        if turns:
            break
        await asyncio.sleep(0.05)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)

    # Only cli got the turn; other_ch received nothing.
    assert any(ch == "cli" and txt == "for cli only" for ch, txt in turns)
    assert not any(ch == "other" for ch, txt in turns)


# ---------------------------------------------------------------------------
# Test: ctx.state["scheduler"] is present during a scheduler-triggered turn
# ---------------------------------------------------------------------------


async def test_scheduler_in_ctx_state_during_triggered_turn(fake_ctx: Ctx) -> None:
    """ctx.state["scheduler"] is populated for scheduler-triggered turns."""
    clock = [datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC)]

    def now_fn() -> datetime:
        return clock[0]

    store = _make_store()
    sched = _make_scheduler(store, now_fn=now_fn)

    await sched.schedule_once(
        user_id="alice",
        thread_key=None,
        channel="cli",
        prompt="check ctx.state",
        delta=timedelta(seconds=1),
    )

    state_values: list[Any] = []

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        state_values.append(ctx.state.get("scheduler"))

    ch = _FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    clock[0] = datetime(2026, 4, 23, 12, 0, 5, tzinfo=UTC)
    run_task = asyncio.create_task(app.run())

    for _ in range(100):
        if state_values:
            break
        await asyncio.sleep(0.05)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)

    assert state_values, "on_turn was never called"
    assert state_values[0] is sched, "ctx.state['scheduler'] should be the Scheduler instance"


# ---------------------------------------------------------------------------
# Test: bind_channels is called by ZenoApp — scheduler can fire without
# channels being passed at construction time
# ---------------------------------------------------------------------------


async def test_bind_channels_called_by_zeno_app(fake_ctx: Ctx) -> None:
    """Scheduler constructed with channels={} works after ZenoApp binds channels."""
    clock = [datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC)]

    def now_fn() -> datetime:
        return clock[0]

    store = _make_store()
    # Construct scheduler WITHOUT a channel map — ZenoApp will bind it.
    sched = _make_scheduler(store, channels={}, now_fn=now_fn)

    await sched.schedule_once(
        user_id="alice",
        thread_key=None,
        channel="cli",
        prompt="bound by app",
        delta=timedelta(seconds=1),
    )

    turns: list[str] = []

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        turns.append(msg.text)

    ch = _FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        scheduler=sched,
    )

    clock[0] = datetime(2026, 4, 23, 12, 0, 5, tzinfo=UTC)
    run_task = asyncio.create_task(app.run())

    for _ in range(100):
        if turns:
            break
        await asyncio.sleep(0.05)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=5.0)

    assert "bound by app" in turns
