"""Tests for `@tool` decorator, schema derivation, and the SDK envelope."""

# NOTE: This module intentionally does *not* use `from __future__ import annotations`.
# `get_type_hints` cannot resolve locally-scoped classes when all annotations are
# strings, and tool authors routinely write `class Note(BaseModel): ...` next to
# their `@tool` functions. Keeping eager annotations here matches real-world use.

import datetime as dt
from enum import StrEnum
from typing import Annotated, Literal, TypedDict

import pytest
from pydantic import BaseModel
from zeno.context import Ctx, bind_ctx
from zeno.exceptions import ZenoError
from zeno.tool import get_spec, tool


class _Note(BaseModel):
    text: str
    pinned: bool = False


class _NoteTD(TypedDict):
    text: str
    pinned: bool


class _Mode(StrEnum):
    USER = "user"
    KNOWLEDGE = "knowledge"


class _Arbitrary:
    pass


def test_primitives_schema() -> None:
    @tool
    async def f(ctx: Ctx, s: str, i: int, fl: float, b: bool) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.schema["properties"] == {
        "s": {"type": "string"},
        "i": {"type": "integer"},
        "fl": {"type": "number"},
        "b": {"type": "boolean"},
    }
    assert set(spec.schema["required"]) == {"s", "i", "fl", "b"}


def test_description_from_docstring() -> None:
    @tool
    async def add_note(ctx: Ctx, text: str) -> str:
        """Add a note to user memory.

        Extended text ignored.
        """
        return "ok"

    assert get_spec(add_note).description == "Add a note to user memory."


def test_optional_and_union_none_collapse() -> None:
    @tool
    async def f(ctx: Ctx, a: int | None = None, b: str | None = None) -> str:
        return "ok"

    spec = get_spec(f)
    assert "required" not in spec.schema or spec.schema["required"] == []
    assert spec.schema["properties"]["a"]["type"] == "integer"
    assert spec.schema["properties"]["b"]["type"] == "string"


def test_default_recorded_and_non_required() -> None:
    @tool
    async def f(ctx: Ctx, n: int = 5) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.schema["properties"]["n"]["default"] == 5
    assert "required" not in spec.schema


def test_literal_string_enum() -> None:
    @tool
    async def f(ctx: Ctx, mode: Literal["user", "knowledge"]) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.schema["properties"]["mode"] == {
        "type": "string",
        "enum": ["user", "knowledge"],
    }


def test_list_of_strings() -> None:
    @tool
    async def f(ctx: Ctx, tags: list[str]) -> str:
        return "ok"

    assert get_spec(f).schema["properties"]["tags"] == {
        "type": "array",
        "items": {"type": "string"},
    }


def test_pydantic_model_inlined() -> None:
    @tool
    async def f(ctx: Ctx, note: _Note) -> str:
        return note.text

    spec = get_spec(f)
    note_schema = spec.schema["properties"]["note"]
    assert note_schema["type"] == "object"
    assert "text" in note_schema["properties"]


def test_datetime_format() -> None:
    @tool
    async def f(ctx: Ctx, when: dt.datetime) -> str:
        return when.isoformat()

    spec = get_spec(f)
    assert spec.schema["properties"]["when"] == {
        "type": "string",
        "format": "date-time",
    }


def test_no_kwargs_empty_properties() -> None:
    @tool
    async def f(ctx: Ctx) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.schema == {"type": "object", "properties": {}}


def test_pep604_and_typing_optional_parity() -> None:
    # Exercise both Union shapes by calling the internal schema builder directly;
    # writing two @tool functions would trigger ruff's UP007 rewrite of Optional.
    from typing import Optional, Union

    from zeno.tool import _schema_for

    pep604_schema, _, pep604_opt = _schema_for(int | None)
    typing_schema, _, typing_opt = _schema_for(Optional[int])  # noqa: UP007,UP045
    union_schema, _, union_opt = _schema_for(Union[int, None])  # noqa: UP007

    assert pep604_schema == typing_schema == union_schema
    assert pep604_opt is typing_opt is union_opt is True


def test_typed_dict_schema() -> None:
    @tool
    async def f(ctx: Ctx, note: _NoteTD) -> str:
        return note["text"]

    spec = get_spec(f)
    note_schema = spec.schema["properties"]["note"]
    assert note_schema["type"] == "object"
    assert set(note_schema["required"]) == {"text", "pinned"}


def test_annotated_description() -> None:
    @tool
    async def f(ctx: Ctx, city: Annotated[str, "The city to look up."]) -> str:
        return city

    spec = get_spec(f)
    assert spec.schema["properties"]["city"] == {
        "type": "string",
        "description": "The city to look up.",
    }


def test_dict_additional_properties() -> None:
    @tool
    async def f(ctx: Ctx, meta: dict[str, str]) -> str:
        return "ok"

    assert get_spec(f).schema["properties"]["meta"] == {
        "type": "object",
        "additionalProperties": {"type": "string"},
    }


def test_union_non_none_renders_anyof() -> None:
    @tool
    async def f(ctx: Ctx, x: int | str) -> str:
        return "ok"

    anyof = get_spec(f).schema["properties"]["x"]["anyOf"]
    assert {"type": "integer"} in anyof
    assert {"type": "string"} in anyof


def test_str_enum_class() -> None:
    @tool
    async def f(ctx: Ctx, mode: _Mode) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.schema["properties"]["mode"]["type"] == "string"
    assert set(spec.schema["properties"]["mode"]["enum"]) == {"user", "knowledge"}


def test_first_param_must_be_ctx() -> None:
    async def f(x: int, y: int) -> str:
        return "ok"

    with pytest.raises(ZenoError, match="first parameter must be annotated as Ctx"):
        tool(f)


def test_unsupported_type_raises_at_decoration() -> None:
    with pytest.raises(ZenoError, match="unsupported type"):

        @tool
        async def f(ctx: Ctx, thing: _Arbitrary) -> str:
            return "ok"


def test_sync_function_rejected() -> None:
    def f(ctx: Ctx, x: int) -> str:
        return "ok"

    with pytest.raises(ZenoError, match="requires an async function"):
        tool(f)  # type: ignore[arg-type]


def test_custom_name_and_description() -> None:
    @tool(name="custom.name", description="overridden")
    async def f(ctx: Ctx) -> str:
        return "ok"

    spec = get_spec(f)
    assert spec.name == "custom.name"
    assert spec.description == "overridden"


async def test_sdk_handler_happy_path(fake_ctx: Ctx) -> None:
    @tool
    async def greet(ctx: Ctx, name: str) -> str:
        return f"hi {name}"

    sdk_tool = get_spec(greet).to_sdk_tool()
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({"name": "alice"})
    assert result == {"content": [{"type": "text", "text": "hi alice"}]}


async def test_sdk_handler_serializes_dict_result(fake_ctx: Ctx) -> None:
    @tool
    async def f(ctx: Ctx) -> dict[str, int]:
        return {"count": 3}

    sdk_tool = get_spec(f).to_sdk_tool()
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({})
    assert result["content"][0]["text"] == '{"count": 3}'


async def test_sdk_handler_converts_exception_to_is_error(fake_ctx: Ctx) -> None:
    @tool
    async def f(ctx: Ctx) -> str:
        raise RuntimeError("boom")

    sdk_tool = get_spec(f).to_sdk_tool()
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({})
    assert result["is_error"] is True
    assert "boom" in result["content"][0]["text"]


async def test_sdk_handler_decodes_datetime(fake_ctx: Ctx) -> None:
    seen: list[dt.datetime] = []

    @tool
    async def f(ctx: Ctx, when: dt.datetime) -> str:
        seen.append(when)
        return "ok"

    sdk_tool = get_spec(f).to_sdk_tool()
    with bind_ctx(fake_ctx):
        await sdk_tool.handler({"when": "2026-04-19T10:00:00"})
    assert seen == [dt.datetime(2026, 4, 19, 10, 0, 0)]


async def test_sdk_handler_rehydrates_pydantic(fake_ctx: Ctx) -> None:
    captured: list[_Note] = []

    @tool
    async def f(ctx: Ctx, note: _Note) -> str:
        captured.append(note)
        return note.text

    sdk_tool = get_spec(f).to_sdk_tool()
    with bind_ctx(fake_ctx):
        await sdk_tool.handler({"note": {"text": "hi", "pinned": True}})
    assert captured[0].text == "hi"
    assert captured[0].pinned is True


async def test_sdk_handler_outside_turn_returns_is_error() -> None:
    @tool
    async def f(ctx: Ctx) -> str:
        return "ok"

    sdk_tool = get_spec(f).to_sdk_tool()
    result = await sdk_tool.handler({})
    assert result["is_error"] is True
