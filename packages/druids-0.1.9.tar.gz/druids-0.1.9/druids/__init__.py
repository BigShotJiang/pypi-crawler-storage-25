"""Druids CLI."""
