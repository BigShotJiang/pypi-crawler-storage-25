"""Guards for constitutional enforcement."""
