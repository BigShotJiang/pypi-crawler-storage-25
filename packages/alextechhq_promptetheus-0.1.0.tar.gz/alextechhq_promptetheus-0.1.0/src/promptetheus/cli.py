#!/usr/bin/env python3
"""pt — Promptetheus CLI

  pt list [--cat=<cat>]          List prompts with stable #ID and variables
  pt get  <#N | text>            Print template; shows all matches if ambiguous
  pt fill <#N | text> [k=v ...]  Fill variables and print
  pt copy <#N | text> [k=v ...]  Fill variables and copy to clipboard
  pt search <query>              Search by title or description
  pt login / logout / whoami     Authentication
  pt init                        First-time setup

Zero external dependencies — pure Python ≥ 3.8 stdlib only.
"""

import getpass
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ── Paths & defaults ──────────────────────────────────────────────────────────
CONFIG_DIR   = Path.home() / '.config' / 'pt'
CONFIG_PATH  = CONFIG_DIR / 'config.json'
SESSION_PATH = CONFIG_DIR / 'session.json'

DEFAULT_URL      = 'https://jxistuzrdnamzhekafdx.supabase.co'
DEFAULT_ANON_KEY = 'sb_publishable_8ONvBhXgTXpWg3Ud1F39aA_e17P4D7b'

# ── ANSI colour helpers ───────────────────────────────────────────────────────
def _c(code, s):  return f'\x1b[{code}m{s}\x1b[0m'
def bold(s):      return _c('1', s)
def cyan(s):      return _c('36', s)
def yellow(s):    return _c('33', s)
def green(s):     return _c('32', s)
def red(s):       return _c('31', s)
def grey(s):      return _c('90', s)
def ruler():      return grey('─' * 64)

# ── HTTP helpers ──────────────────────────────────────────────────────────────
def _http(method, url, headers, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req  = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read()), resp.status
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read()), e.code
        except Exception:
            return {'error': str(e.reason)}, e.code
    except urllib.error.URLError as e:
        raise RuntimeError(f'Connection error: {e.reason}')

def http_post(url, headers, body):
    return _http('POST', url, headers, body)

def http_get(url, headers):
    data, status = _http('GET', url, headers)
    if status >= 400:
        raise RuntimeError(f'Supabase {status}: {json.dumps(data)}')
    return data

# ── Load env ──────────────────────────────────────────────────────────────────
# Resolution order (highest → lowest priority):
#   1. process.env               — shell / CI overrides
#   2. ~/.config/pt/config.json  — written by `pt init`
#   3. .env.local / .env.remote / .env  — repo dev fallbacks
def load_env():
    cfg = {}
    try:
        cfg = json.loads(CONFIG_PATH.read_text())
    except Exception:
        pass

    env = {}
    for name in ('.env.local', '.env.remote', '.env'):
        p = Path.cwd() / name
        try:
            for line in p.read_text().splitlines():
                k, _, v = line.partition('=')
                k = k.strip()
                if k and not k.startswith('#'):
                    env[k] = v.strip()
        except Exception:
            pass

    def first(*keys):
        for k in keys:
            v = os.environ.get(k) or cfg.get(k) or env.get(k)
            if v:
                return v
        return ''

    return {
        'url':         first('PT_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_URL') or 'http://127.0.0.1:54321',
        'anon_key':    first('PT_ANON_KEY', 'NEXT_PUBLIC_SUPABASE_ANON_KEY') or '',
        'service_key': first('PT_SERVICE_KEY', 'SUPABASE_SERVICE_ROLE_KEY') or '',
    }

# ── Session management ────────────────────────────────────────────────────────
def load_session():
    try:
        return json.loads(SESSION_PATH.read_text())
    except Exception:
        return None

def save_session(session):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_PATH.write_text(json.dumps(session, indent=2))
    SESSION_PATH.chmod(0o600)

def clear_session():
    try:
        SESSION_PATH.unlink()
    except Exception:
        pass

def refresh_session(session):
    env = load_env()
    data, status = http_post(
        f"{env['url']}/auth/v1/token?grant_type=refresh_token",
        headers={'apikey': env['anon_key'], 'Content-Type': 'application/json'},
        body={'refresh_token': session.get('refresh_token', '')},
    )
    if status != 200:
        return None
    next_session = {
        'access_token':  data.get('access_token', ''),
        'refresh_token': data.get('refresh_token', session.get('refresh_token', '')),
        'expires_at':    int(time.time() * 1000) + data.get('expires_in', 3600) * 1000,
        'email':         session.get('email'),
    }
    save_session(next_session)
    return next_session

def get_access_token():
    session = load_session()
    if not session:
        return None
    expires_at = session.get('expires_at', 0)
    if expires_at and time.time() * 1000 > expires_at - 60_000:
        refreshed = refresh_session(session)
        return refreshed['access_token'] if refreshed else None
    return session.get('access_token')

# ── Auth commands ─────────────────────────────────────────────────────────────
def cmd_login(_args):
    env = load_env()
    if not env['anon_key']:
        print(red('✗') + ' Config not found. Run ' + yellow('pt init') + ' to set up first.')
        sys.exit(1)

    email    = input('Email: ')
    password = getpass.getpass('Password: ')

    data, status = http_post(
        f"{env['url']}/auth/v1/token?grant_type=password",
        headers={'apikey': env['anon_key'], 'Content-Type': 'application/json'},
        body={'email': email, 'password': password},
    )
    if status != 200:
        msg = data.get('error_description') or data.get('msg') or str(status)
        print(red('✗') + f' Login failed: {msg}')
        sys.exit(1)

    save_session({
        'access_token':  data['access_token'],
        'refresh_token': data['refresh_token'],
        'expires_at':    int(time.time() * 1000) + data.get('expires_in', 3600) * 1000,
        'email':         (data.get('user') or {}).get('email'),
    })
    user_email = (data.get('user') or {}).get('email', '')
    print(green('✓') + f' Logged in as {yellow(user_email)}')
    print(grey(f'Session stored at {SESSION_PATH}'))

def cmd_logout(_args):
    if not load_session():
        print('Not logged in.')
        return
    clear_session()
    print(green('✓') + ' Logged out.')

def cmd_whoami(_args):
    s = load_session()
    if not s:
        print('Not logged in.  Run: pt login')
        return
    expires_at = s.get('expires_at', 0)
    mins = round((expires_at - time.time() * 1000) / 60_000) if expires_at else '?'
    print(f"{yellow(s.get('email', 'unknown'))}  {grey(f'(token expires in {mins} min)')}")

# ── Init command ──────────────────────────────────────────────────────────────
def cmd_init(_args):
    print(f'\n{bold("pt init")} — Set up the Promptetheus CLI\n')
    print('The following fixed product credentials will be saved:')
    print(f'  {yellow("PT_SUPABASE_URL")}  {DEFAULT_URL}')
    print(f'  {yellow("PT_ANON_KEY")}      {DEFAULT_ANON_KEY}')
    print()
    print(grey('These are shared, public credentials (not user secrets).'))
    print(grey(f'User session tokens are stored separately after {yellow("pt login")}.'))
    print()

    confirm = input(f'Save to {cyan(str(CONFIG_PATH))}? [Y/n] ').strip().lower()
    if confirm and confirm not in ('y', 'yes'):
        print('Aborted.')
        return

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps({
        'PT_SUPABASE_URL': DEFAULT_URL,
        'PT_ANON_KEY':     DEFAULT_ANON_KEY,
    }, indent=2))
    CONFIG_PATH.chmod(0o600)

    print(green('✓') + f' Config saved to {CONFIG_PATH}  {grey("(mode 0600)")}')
    print(f'\nNext: {yellow("pt login")} — sign in with your Promptetheus account')

# ── Supabase REST client ──────────────────────────────────────────────────────
def sb_fetch(path, params=None):
    env = load_env()
    if not env['anon_key'] and not env['service_key']:
        raise RuntimeError('Config not found. Run: pt init')
    token = get_access_token()
    if not token and not env['service_key']:
        raise RuntimeError('Not logged in. Run: pt login')

    api_key = env['anon_key'] if token else env['service_key']
    auth    = token or env['service_key']
    qs      = ('?' + urllib.parse.urlencode(params)) if params else ''
    return http_get(
        f"{env['url']}/rest/v1/{path}{qs}",
        headers={
            'apikey':        api_key,
            'Authorization': f'Bearer {auth}',
            'Accept':        'application/json',
        },
    )

# ── Prompt data helpers ───────────────────────────────────────────────────────
_FIELDS = 'pt_id,id,title,description,template,variable_definitions,category,models,is_public'

def fetch_all_prompts():
    return sb_fetch('user_prompts', {
        'select': _FIELDS,
        'order':  'pt_id.asc.nullslast,created_at.asc',
        'limit':  '500',
    })

def extract_vars(template=''):
    seen, out = set(), []
    for m in re.finditer(r'\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}', template or ''):
        v = m.group(1)
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out

def fmt_var_tag(prompt):
    vs = extract_vars(prompt.get('template', ''))
    return grey('{{' + ', '.join(vs) + '}}') if vs else ''

# ── Prompt resolution ─────────────────────────────────────────────────────────
def score_match(prompt, needle):
    t, n = prompt['title'].lower(), needle.lower()
    words = n.split()
    if t == n:                                  return 4
    if t.startswith(n):                         return 3
    if words and all(w in t for w in words):    return 2
    if words and any(w in t for w in words):    return 1
    return 0

def resolve_prompt(arg, prompts):
    if re.match(r'^\d+$', arg):
        n   = int(arg)
        hit = next((p for p in prompts if p.get('pt_id') == n), None)
        if not hit:
            print(red('✗') + f' No prompt #{n}.  Run {yellow("pt list")} to see all IDs.')
            return None
        return hit

    matches = sorted(
        (p for p in prompts if score_match(p, arg) > 0),
        key=lambda p: score_match(p, arg),
        reverse=True,
    )
    if not matches:
        print(red('✗') + f' No prompt matching "{arg}".')
        return None
    if len(matches) == 1:
        return matches[0]

    print(f'\n{yellow(str(len(matches)) + " prompts match")} "{arg}":\n')
    for p in matches:
        pt_id  = p.get('pt_id')
        id_str = cyan(f'#{str(pt_id).rjust(2)}') if pt_id is not None else grey('  ?')
        print(f'  {id_str}  {p["title"]}  {fmt_var_tag(p)}')
    print(f'\n{grey("Use pt get <#N> to select one.")}\n')
    return None

# ── Prompt display ────────────────────────────────────────────────────────────
def print_prompt(prompt, filled_vars=None):
    if filled_vars is None:
        filled_vars = {}
    vs    = extract_vars(prompt.get('template', ''))
    defs  = prompt.get('variable_definitions') or {}
    pub   = green('● public') if prompt.get('is_public') else grey('○ private')
    pt_id = prompt.get('pt_id')
    id_str = grey(f' #{pt_id}') if pt_id is not None else ''
    cat   = prompt.get('category') or '—'

    print(f'\n{bold(cyan(prompt["title"]))}{id_str}  {grey("[" + cat + "]")}  {pub}\n')

    if vs:
        print(bold('Variables:'))
        for v in vs:
            df    = defs.get(v) or {}
            parts = [df.get('label', ''), f'e.g. {df["placeholder"]}' if df.get('placeholder') else '']
            label = ' · '.join(p for p in parts if p) or v
            desc  = f'  {grey("— " + df["description"])}' if df.get('description') else ''
            print(f'  {yellow(v.ljust(22))} {label}{desc}')
        print()

    print(ruler())
    print(prompt.get('template', ''))
    print(ruler())

    unfilled = [v for v in vs if v not in filled_vars]
    if unfilled:
        ref     = str(pt_id) if pt_id is not None else f'"{prompt["title"]}"'
        example = ' '.join(f'{v}="..."' for v in unfilled)
        print()
        print(yellow('⚠  Unfilled: ') + yellow(', '.join(unfilled)))
        print(grey(f'   Fill them: pt fill {ref} {example}'))
    print()

# ── Template filling ──────────────────────────────────────────────────────────
def fill_template(template, vars_):
    out = template
    for k, v in vars_.items():
        out = re.sub(r'\{\{' + re.escape(k) + r'\}\}', v, out)
    return re.sub(r'\{\{#if\s+\w+\}\}[\s\S]*?\{\{/if\}\}', '', out)

def parse_var_args(var_args):
    out = {}
    for v in var_args:
        eq = v.find('=')
        if eq != -1:
            out[v[:eq]] = v[eq + 1:]
    return out

def split_args(args):
    eq = next((i for i, a in enumerate(args) if '=' in a), -1)
    return (args, []) if eq == -1 else (args[:eq], args[eq:])

# ── Clipboard ─────────────────────────────────────────────────────────────────
def copy_to_clipboard(text):
    for cmd in (
        ['xclip', '-selection', 'clipboard'],
        ['xsel', '--clipboard', '--input'],
        ['clip.exe'],
        ['pbcopy'],
    ):
        try:
            subprocess.run(
                cmd, input=text.encode(),
                check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return cmd[0]
        except Exception:
            pass
    return None

# ── Prompt commands ───────────────────────────────────────────────────────────
def cmd_list(args):
    cat_filter = next((a.split('=', 1)[1] for a in args if a.startswith('--cat=')), None)
    prompts    = fetch_all_prompts()
    if cat_filter:
        prompts = [p for p in prompts if p.get('category') == cat_filter]
    if not prompts:
        print('No prompts found.')
        return

    by_cat = {}
    for p in prompts:
        by_cat.setdefault(p.get('category') or 'uncategorized', []).append(p)

    for cat, items in sorted(by_cat.items()):
        print(f'\n{cyan(cat.upper())}')
        for p in items:
            pt_id  = p.get('pt_id')
            id_str = cyan(f'#{str(pt_id).rjust(2)}') if pt_id is not None else grey('  ?')
            pub    = green('●') if p.get('is_public') else grey('○')
            models = grey(', '.join((p.get('models') or [])[:2]))
            title  = p['title'].ljust(36)
            print(f'  {id_str}  {pub} {title} {fmt_var_tag(p)}  {models}')

    print(f'\n{grey(str(len(prompts)) + " prompt(s).  pt get <#N>  or  pt get <text>")}\n')

def cmd_get(args):
    no_copy = '--no-copy' in args
    do_copy = '--copy' in args or '-c' in args
    args    = [a for a in args if a not in ('--copy', '-c', '--no-copy')]
    if not args:
        print(f'Usage: pt get {yellow("<#N | text>")} [--no-copy]')
        sys.exit(1)

    prompts = fetch_all_prompts()
    prompt  = resolve_prompt(' '.join(args), prompts)
    if not prompt:
        sys.exit(1)

    copy = True
    if no_copy: copy = False
    if do_copy: copy = True

    print_prompt(prompt)
    if copy:
        tool = copy_to_clipboard(prompt.get('template', ''))
        if tool:
            print(green('✓') + f' "{prompt["title"]}" template copied to clipboard  {grey(f"({tool})")}')
        else:
            print(grey('(Could not auto-copy — pipe: pt get <#N> | xclip)'))

def cmd_fill(args):
    no_copy  = '--no-copy' in args
    do_copy  = '--copy' in args or '-c' in args
    args     = [a for a in args if a not in ('--copy', '-c', '--no-copy')]
    id_args, var_args = split_args(args)
    if not id_args:
        print(f'Usage: pt fill {yellow("<#N | text>")} [key=value ...] [--no-copy]')
        sys.exit(1)

    prompts = fetch_all_prompts()
    prompt  = resolve_prompt(' '.join(id_args), prompts)
    if not prompt:
        sys.exit(1)

    vars_  = parse_var_args(var_args)
    filled = fill_template(prompt.get('template', ''), vars_)
    pt_id  = prompt.get('pt_id')
    pub    = green('● public') if prompt.get('is_public') else grey('○ private')
    id_str = grey(f' #{pt_id}') if pt_id is not None else ''
    cat    = prompt.get('category') or '—'

    print(f'\n{bold(cyan(prompt["title"]))}{id_str}  {grey("[" + cat + "]")}  {pub}\n')
    print(ruler())
    print(filled)
    print(ruler())

    remaining = extract_vars(filled)
    if remaining:
        ref     = str(pt_id) if pt_id is not None else f'"{prompt["title"]}"'
        example = ' '.join(f'{v}="..."' for v in remaining)
        print()
        print(yellow('⚠  Still unfilled: ') + yellow(', '.join(remaining)))
        print(grey(f'   pt fill {ref} {example}'))
    print()

    copy = True
    if no_copy: copy = False
    if do_copy: copy = True

    if copy:
        tool = copy_to_clipboard(filled)
        if tool:
            print(green('✓') + f' "{prompt["title"]}" copied to clipboard  {grey(f"({tool})")}')
        else:
            print(grey('(Could not auto-copy — pipe: pt fill <#N> | xclip)'))

def cmd_copy(args):
    id_args, var_args = split_args(args)
    if not id_args:
        print(f'Usage: pt copy {yellow("<#N | text>")} [key=value ...]')
        sys.exit(1)

    prompts = fetch_all_prompts()
    prompt  = resolve_prompt(' '.join(id_args), prompts)
    if not prompt:
        sys.exit(1)

    filled = fill_template(prompt.get('template', ''), parse_var_args(var_args))
    tool   = copy_to_clipboard(filled)
    if tool:
        print(green('✓') + f' "{prompt["title"]}" copied to clipboard  {grey(f"({tool})")}')
    else:
        print(filled)
        print(grey('(Could not auto-copy — pipe: pt get <#N> | xclip)'))

def cmd_search(args):
    q = ' '.join(args).strip()
    if not q:
        print('Usage: pt search <query>')
        sys.exit(1)

    prompts = fetch_all_prompts()
    lower   = q.lower()
    hits    = [
        p for p in prompts
        if lower in p['title'].lower() or lower in (p.get('description') or '').lower()
    ]
    if not hits:
        print(f'No results for "{q}"')
        return

    print()
    for p in hits:
        pt_id  = p.get('pt_id')
        id_str = cyan(f'#{str(pt_id).rjust(2)}') if pt_id is not None else grey('  ?')
        pub    = green('●') if p.get('is_public') else grey('○')
        cat    = str(p.get('category') or '—')
        print(f'  {id_str}  {pub} {yellow(p["title"].ljust(36))} {fmt_var_tag(p)}  {grey("[" + cat + "]")}')
        if p.get('description'):
            print(grey(f'          {p["description"][:80]}'))
    print()

# ── Help ──────────────────────────────────────────────────────────────────────
def cmd_help(_args=None):
    print(f"""
{bold('pt')} — Promptetheus CLI

{yellow('Setup:')}
  pt init                         One-time setup — saves product config to ~/.config/pt/config.json
  pt login                        Sign in with your Promptetheus account
  pt logout                       Remove the local session
  pt whoami                       Show current user and token expiry

{yellow('Prompt commands:')}
  pt list [--cat=<cat>]           List your prompts with stable #ID and variable list
  pt get  <#N | text>             Copy template to clipboard by default (use --no-copy to print)
  pt fill <#N | text> [k=v ...]   Fill variables and copy to clipboard by default
  pt copy <#N | text> [k=v ...]   Fill variables and copy to clipboard (alias)
  pt search <query>               Search prompts by title or description

{yellow('Examples:')}
  pt init
  pt login
  pt list
  pt list --cat=debugging
  pt get 3                        Prompt #3 (stable DB-assigned ID)
  pt get youtube                  All YouTube prompts (disambiguation if >1)
  pt fill 3 topic="AI" length="10m"
  pt copy 7
  pt get 3 > prompt.txt

{yellow('Config (auto-set by pt init):')}
  PT_SUPABASE_URL     Remote Supabase project URL
  PT_ANON_KEY         Shared project anon key (public, not a user secret)
  PT_SERVICE_KEY      (optional) Service-role key for local dev only

{grey('Config file:  ' + str(CONFIG_PATH))}
{grey('Session file: ' + str(SESSION_PATH))}
""")

# ── Entry point ───────────────────────────────────────────────────────────────
_COMMANDS = {
    'init':   cmd_init,
    'list':   cmd_list,
    'get':    cmd_get,
    'fill':   cmd_fill,
    'copy':   cmd_copy,
    'search': cmd_search,
    'login':  cmd_login,
    'logout': cmd_logout,
    'whoami': cmd_whoami,
}

def main():
    argv = sys.argv[1:]
    cmd  = argv[0] if argv else None
    rest = argv[1:] if len(argv) > 1 else []

    if not cmd or cmd in ('help', '--help', '-h'):
        cmd_help()
        return

    if cmd in _COMMANDS:
        try:
            _COMMANDS[cmd](rest)
        except Exception as e:
            print(red('✗') + ' ' + str(e))
            sys.exit(1)
    else:
        # Bare: pt 3 or pt youtube → treated as pt get
        try:
            cmd_get(argv)
        except Exception as e:
            print(red('✗') + ' ' + str(e))
            sys.exit(1)

if __name__ == '__main__':
    main()
