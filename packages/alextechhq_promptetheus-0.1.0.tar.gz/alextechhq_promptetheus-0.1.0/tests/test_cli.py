"""Basic unit tests for promptetheus.cli."""

import re
import sys
from unittest.mock import patch

import pytest

from promptetheus.cli import (
    extract_vars,
    fill_template,
    parse_var_args,
    score_match,
    split_args,
)
from promptetheus import __version__


# ── extract_vars ──────────────────────────────────────────────────────────────

def test_extract_vars_simple():
    assert extract_vars("Hello {{name}}!") == ["name"]


def test_extract_vars_multiple():
    assert extract_vars("{{a}} and {{b}} and {{a}}") == ["a", "b"]


def test_extract_vars_empty():
    assert extract_vars("No variables here.") == []


def test_extract_vars_none():
    assert extract_vars(None) == []


# ── fill_template ─────────────────────────────────────────────────────────────

def test_fill_template_basic():
    result = fill_template("Hello {{name}}!", {"name": "World"})
    assert result == "Hello World!"


def test_fill_template_multiple():
    result = fill_template("{{a}} + {{b}}", {"a": "foo", "b": "bar"})
    assert result == "foo + bar"


def test_fill_template_unfilled_unchanged():
    result = fill_template("Hello {{name}}!", {})
    assert "{{name}}" in result


# ── parse_var_args ────────────────────────────────────────────────────────────

def test_parse_var_args_basic():
    assert parse_var_args(["key=value"]) == {"key": "value"}


def test_parse_var_args_value_with_equals():
    assert parse_var_args(["key=val=ue"]) == {"key": "val=ue"}


def test_parse_var_args_empty():
    assert parse_var_args([]) == {}


# ── split_args ────────────────────────────────────────────────────────────────

def test_split_args_with_vars():
    ids, vars_ = split_args(["3", "key=val"])
    assert ids == ["3"]
    assert vars_ == ["key=val"]


def test_split_args_no_vars():
    ids, vars_ = split_args(["3", "youtube"])
    assert ids == ["3", "youtube"]
    assert vars_ == []


# ── score_match ───────────────────────────────────────────────────────────────

def test_score_match_exact():
    assert score_match({"title": "my prompt"}, "my prompt") == 4


def test_score_match_prefix():
    assert score_match({"title": "my prompt"}, "my") == 3


def test_score_match_no_match():
    assert score_match({"title": "something else"}, "xyz") == 0


# ── version ───────────────────────────────────────────────────────────────────

def test_version_is_semver():
    assert re.match(r"^\d+\.\d+\.\d+", __version__)


# ── main entry point ──────────────────────────────────────────────────────────

def test_main_help_exits_cleanly():
    with patch("sys.argv", ["pt", "help"]):
        from promptetheus.cli import main
        # help prints and returns without raising
        main()
