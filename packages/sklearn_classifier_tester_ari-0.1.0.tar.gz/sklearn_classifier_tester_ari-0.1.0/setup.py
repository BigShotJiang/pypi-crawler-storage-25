from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    readme = f.read()

setup(
    name='sklearn-classifier-tester-ari',
    version='0.1.0',
    author='Arı Bilgi Fan',
    author_email='aribilgiogr@gmail.com',
    description='Multi-Classifier Tester',
    long_description=readme,
    long_description_content_type='text/markdown',
    url='https://github.com/aribilgiogr/sklearn-classifier-tester',
    packages=find_packages(),
    install_requires=[ 'pandas', 'scikit-learn', 'xgboost', 'lightgbm' ],
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.11',
)