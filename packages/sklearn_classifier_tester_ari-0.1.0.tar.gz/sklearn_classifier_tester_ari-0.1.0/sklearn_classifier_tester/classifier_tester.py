import warnings

import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, classification_report

warnings.filterwarnings("ignore")


def test_data(X, y, test_size=0.3, random_state=42, scale_data=True) -> pd.DataFrame | None:
    """
    Test multiple classification models and return their performance metric values.

    :param X: Feature matrix
    :param y: Target vector
    :param test_size:  Proportion of the dataset to include in the test set
    :param random_state: Random seed for reproducibility
    :param scale_data: Whether to scale the data before fitting models
    :return:
    DataFrame: Results comparing all classifiers
    """
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state,
                                                        stratify=y)

    # Scale data if requested
    if scale_data:
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

    # Initialize classifier models
    models = [
        ('Logistic Regression', LogisticRegression()),
        ('Decision Tree', DecisionTreeClassifier()),
        ('Random Forest', RandomForestClassifier()),
        ('SVM', SVC()),
        ('KNN', KNeighborsClassifier()),
        ('Naive Bayes', GaussianNB()),
        ('Gradient Boosting', GradientBoostingClassifier()),
        ('AdaBoost', AdaBoostClassifier()),
        ('Linear Discriminant Analysis', LinearDiscriminantAnalysis()),
        ('Quadratic Discriminant Analysis', QuadraticDiscriminantAnalysis()),
        ('MLP Neural Network', MLPClassifier()),
        ('SGD Classifier', SGDClassifier()),
        ('XGBoost Classifier', XGBClassifier()),
        ('LightGBM Classifier', LGBMClassifier()),
    ]

    results = []

    for name, model in models:
        try:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            report = classification_report(y_test, y_pred, output_dict=True)

            results.append({
                'Classifier': name,
                'Accuracy': accuracy,
                'Precision (weighted)': report['weighted avg']['precision'],
                'Recall (weighted)': report['weighted avg']['recall'],
                'F1-score (weighted)': report['weighted avg']['f1-score'],
            })

        except Exception as ex:
            print(f'Error with {name}: {str(ex)}')
            results.append({
                'Classifier': name,
                'Accuracy': None,
                'Precision (weighted)': None,
                'Recall (weighted)': None,
                'F1-score (weighted)': None,
            })
    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values('Accuracy', ascending=False).reset_index(drop=True)
    return results_df