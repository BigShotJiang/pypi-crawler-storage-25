from .classifier_tester import test_data

__all__ = ['test_data']
__version__ = '0.1.0'