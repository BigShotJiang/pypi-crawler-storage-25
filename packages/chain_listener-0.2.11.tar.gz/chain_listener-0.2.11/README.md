# Chain Listener SDK

A universal multi-chain distributed blockchain listener SDK that provides reusable multi-chain monitoring capabilities. The SDK focuses on asynchronous blockchain event listening and data processing, offering flexible solutions for different business scenarios.

## Features

- **Universal Multi-Chain Support**: Ethereum, BSC, Polygon, Arbitrum, Optimism, Avalanche, Solana, TRON, Kava, Osmosis, Base
- **Distributed Architecture**: Support for multi-instance deployment with automatic load balancing
- **Event-Driven**: Callback-based event processing with user-defined handlers
- **Fault Tolerant**: Automatic failover and recovery mechanisms
- **High Performance**: Async/await architecture with efficient event processing
- **Flexible Deployment**: From simple standalone to distributed cluster

## Quick Start

## Codex Skill

This repository now includes a Codex skill bundle at
`codex-skills/chain-listener-event-ops`.

- **Analyst workflow**: generate JSONL/CSV capture listeners for on-chain event
  sampling and downstream analysis
- **Developer workflow**: generate event consumer scaffolds for callback-based
  integrations

Example scaffold command:

```bash
poetry run python codex-skills/chain-listener-event-ops/scripts/scaffold_listener.py \
  --persona analyst \
  --chain-name bsc \
  --chain-type bsc \
  --contract-name USDC \
  --contract-address 0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d \
  --abi-path examples/bsc_usdc_transfer_listener/usdc_erc20_abi.json \
  --event Transfer \
  --output examples/generated/bsc_usdc_transfer_capture.py
```

To make the skill globally available in Codex, copy or symlink the skill folder
into `$CODEX_HOME/skills/`.


## Documentation

- [Architecture Overview](docs/architecture.md)
- [Configuration Guide](docs/configuration.md)
- [API Reference](docs/api.md)
- [Examples](examples/)

## Development

### Setup

```bash
# Install Poetry
pip install poetry

# Install dependencies
poetry install

# Activate virtual environment
poetry env activate
```

### Code Quality

```bash
# Format code
black src/ tests/

# Type checking
mypy src/

# Linting
flake8 src/ tests/
```

## License

[License Name]

## Contributing

Please read our contributing guidelines and code of conduct before submitting pull requests.
