# AuditDestinationRouting

Controls how an audit destination is routed 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**external** | **bool** | Whether the destination is routed externally (true) or directly (false).  | 
**sni_proxy** | **bool** | Whether the destination exposes an sni proxy (true).  | [optional] 
**extra_locations** | **[str]** | Extra locations this destination may need to reach. This is primarily used for routing purposes so that if the destination needs to communicate with other endpoints, or forward to them, they can be configured in one simple spot.  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


