from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AgentNode:
    """An agent node to be placed on the workflow canvas.

    Parameters
    ----------
    id:
        Unique identifier for the agent.
    name:
        Display name shown as the card title.
    model_name:
        The AI model name shown as a badge (e.g. "claude-opus-4-6").
    position:
        (x, y) coordinates on the canvas.
    metadata:
        Optional key-value pairs rendered below the card header.

    """

    id: str  
    name: str
    model_name: str
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        return {
            "id": self.id,
            "type": "agent",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "model_name": self.model_name,
                "metadata": self.metadata,
            },
        }
