from dataclasses import dataclass
from typing import Any

from streamlitai_flow_components.step import StepNode


@dataclass(frozen=True)
class LoopNode:
    """A loop node that repeats an ordered sequence of steps on the canvas.

    Parameters
    ----------
    id:
        Unique identifier for the loop.
    name:
        Display name shown as the card title.
    steps:
        Ordered tuple of steps executed each iteration.
    max_iterations:
        Maximum number of times the loop runs.
    condition:
        Optional text describing the exit condition.
    position:
        (x, y) coordinates on the canvas.
    metadata:
        Optional key-value pairs rendered below the card header.

    """

    id: str  
    name: str
    steps: tuple[StepNode, ...] = ()
    max_iterations: int = 1
    condition: str | None = None
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        serialized_steps = []
        for step in self.steps:
            step_dict = step.to_dict()
            serialized_steps.append({"id": step_dict["id"], **step_dict["data"]})
        return {
            "id": self.id,
            "type": "loop",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "steps": serialized_steps,
                "max_iterations": self.max_iterations,
                "condition": self.condition,
                "metadata": self.metadata,
            },
        }
