######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.25                                                                                #
# Generated on 2026-05-05T17:23:09.893622                                                            #
######################################################################################################

from __future__ import annotations


from .._vendor import yaml as yaml

def yaml_parser(content: str) -> dict:
    """
    Parse YAML content to a dictionary.
    
    Parameters
    ----------
    content : str
    
    Returns
    -------
    dict
    """
    ...

