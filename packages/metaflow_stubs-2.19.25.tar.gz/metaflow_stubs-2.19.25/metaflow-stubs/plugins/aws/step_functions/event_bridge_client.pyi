######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.25                                                                                #
# Generated on 2026-05-05T17:23:09.991276                                                            #
######################################################################################################

from __future__ import annotations



class EventBridgeClient(object, metaclass=type):
    def __init__(self, name):
        ...
    def cron(self, cron):
        ...
    def role_arn(self, role_arn):
        ...
    def state_machine_arn(self, state_machine_arn):
        ...
    def schedule(self):
        ...
    def delete(self):
        ...
    ...

def format(name):
    ...

