######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.25                                                                                #
# Generated on 2026-05-05T17:23:09.924835                                                            #
######################################################################################################

from __future__ import annotations


from . import exit_hook_decorator as exit_hook_decorator

