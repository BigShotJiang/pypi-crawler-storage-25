######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.25                                                                                #
# Generated on 2026-05-05T17:23:09.925057                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

