######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.25                                                                                #
# Generated on 2026-05-05T17:23:09.962584                                                            #
######################################################################################################

from __future__ import annotations


from .basic import SerializationErrorComponent as SerializationErrorComponent

def render_safely(func):
    """
    This is a decorator that can be added to any `MetaflowCardComponent.render`
    The goal is to render subcomponents safely and ensure that they are JSON serializable.
    """
    ...

