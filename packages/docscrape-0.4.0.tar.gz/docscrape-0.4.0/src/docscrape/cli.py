"""Simplified CLI for docscrape with smart defaults."""

import asyncio
import re
from pathlib import Path
from typing import Annotated
from urllib.parse import urlparse

import typer
from rich.console import Console
from rich.panel import Panel

from docscrape import __version__
from docscrape.adapters.generic import GenericAdapter
from docscrape.core.interfaces import PlatformAdapter
from docscrape.core.models import ScrapeConfig
from docscrape.engine.crawler import DocumentationCrawler
from docscrape.storage.filesystem import FilesystemStorage

console = Console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[bold]docscrape[/bold] version {__version__}")
        raise typer.Exit()


def _derive_output_from_url(url: str) -> Path:
    """Derive output directory from URL.

    Includes the URL path as nested subdirectories under the domain slug so
    sibling projects on the same domain don't clobber each other's manifest
    and index files (e.g. docs.astral.sh/uv vs docs.astral.sh/ruff).

    Examples:
        https://docs.pipecat.ai                           -> ./pipecat/
        https://docs.astral.sh/uv                         -> ./astral/uv/
        https://docs.astral.sh/ruff                       -> ./astral/ruff/
        https://docs.livekit.io/agents                    -> ./livekit/agents/
        https://xgboost.readthedocs.io/en/release_3.2.0/  -> ./xgboost/en/release_3.2.0/
    """
    parsed = urlparse(url)
    domain = parsed.netloc

    # Remove common prefixes
    for prefix in ["docs.", "www.", "developer.", "developers."]:
        if domain.startswith(prefix):
            domain = domain[len(prefix) :]

    # Extract the main domain name (before .com, .io, .ai, etc.)
    match = re.match(r"^([a-zA-Z0-9-]+)", domain)
    slug = match.group(1).lower() if match else "docs"

    path_segments = [seg for seg in parsed.path.strip("/").split("/") if seg]
    return Path("./", slug, *path_segments)


async def _run_crawler(adapter: PlatformAdapter, config: ScrapeConfig) -> None:
    """Run the crawler asynchronously."""
    storage = FilesystemStorage()
    crawler = DocumentationCrawler(adapter, storage, config)

    # Display header
    console.print()
    console.print(
        Panel(
            f"[bold cyan]Platform:[/bold cyan] {config.platform}\n"
            f"[bold green]URL:[/bold green] {config.base_url}\n"
            f"[bold yellow]Output:[/bold yellow] {config.output_dir}",
            title="[bold]docscrape[/bold]",
            border_style="blue",
        )
    )

    if config.resume:
        console.print("[dim]Resuming from previous scrape...[/dim]")

    console.print()

    try:
        manifest = await crawler.crawl()

        # Print summary
        console.print()
        console.print(
            Panel(
                f"[bold green]Successful:[/bold green] {manifest.successful}\n"
                f"[bold red]Failed:[/bold red] {manifest.failed}\n"
                f"[bold yellow]Output:[/bold yellow] {config.output_dir}",
                title="[bold green]Scrape Complete![/bold green]",
                border_style="green",
            )
        )

        if manifest.failed_urls:
            console.print()
            console.print("[yellow]Failed URLs:[/yellow]")
            for failed in manifest.failed_urls[:5]:
                console.print(f"  [dim]•[/dim] {failed['url']}")
            if len(manifest.failed_urls) > 5:
                console.print(f"  [dim]... and {len(manifest.failed_urls) - 5} more[/dim]")

    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted. Progress saved for resume.[/yellow]")
        raise typer.Exit(1) from None

    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        raise typer.Exit(1) from e


def _scrape(
    url: str,
    output: Path | None,
    max_pages: int,
    delay: float,
    resume: bool,
    verbose: bool,
    quiet: bool,
    include: list[str] | None,
    exclude: list[str] | None,
) -> None:
    """Execute the scrape operation."""
    # Validate URL
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"

    # Auto-detect output directory if not specified
    if output is None:
        output = _derive_output_from_url(url)

    # Create generic adapter
    adapter = GenericAdapter(base_url=url)

    # Create config
    config = ScrapeConfig(
        output_dir=output,
        base_url=url,
        platform=adapter.name,
        max_pages=max_pages,
        request_delay=delay,
        resume=resume,
        verbose=verbose,
        quiet=quiet,
        include_patterns=include or [],
        exclude_patterns=exclude or [],
    )

    # Run crawler
    asyncio.run(_run_crawler(adapter, config))


app = typer.Typer(
    name="docscrape",
    help="Scrape any documentation site to Markdown in seconds.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


@app.command()
def scrape(
    url: Annotated[
        str,
        typer.Argument(help="Documentation URL to scrape (e.g., https://docs.pipecat.ai)"),
    ],
    output: Annotated[
        Path | None,
        typer.Option(
            "-o",
            "--output",
            help="Output directory [default: auto-detected from URL]",
        ),
    ] = None,
    max_pages: Annotated[
        int,
        typer.Option(
            "-m",
            "--max-pages",
            help="Maximum pages to scrape (0 = unlimited)",
        ),
    ] = 0,
    delay: Annotated[
        float,
        typer.Option(
            "-d",
            "--delay",
            help="Delay between requests in seconds",
        ),
    ] = 0.5,
    resume: Annotated[
        bool,
        typer.Option(
            "-r",
            "--resume",
            help="Resume from previous scrape",
        ),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "-v",
            "--verbose",
            help="Verbose output",
        ),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option(
            "-q",
            "--quiet",
            help="Suppress progress bar (for scripting/CI)",
        ),
    ] = False,
    include: Annotated[
        list[str] | None,
        typer.Option(
            "-i",
            "--include",
            help="URL patterns to include (regex)",
        ),
    ] = None,
    exclude: Annotated[
        list[str] | None,
        typer.Option(
            "-e",
            "--exclude",
            help="URL patterns to exclude (regex)",
        ),
    ] = None,
) -> None:
    """Scrape a documentation site to Markdown.

    \b
    Examples:
        docscrape scrape https://docs.pipecat.ai
        docscrape scrape https://docs.livekit.io -o ./livekit-docs
        docscrape scrape https://docs.example.com -m 50 -v
    """
    _scrape(url, output, max_pages, delay, resume, verbose, quiet, include, exclude)


def main() -> None:
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
