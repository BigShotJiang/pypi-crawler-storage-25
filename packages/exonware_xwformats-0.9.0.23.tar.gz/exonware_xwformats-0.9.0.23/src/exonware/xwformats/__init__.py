#!/usr/bin/env python3
#exonware/xwformats/src/exonware/xwformats/__init__.py
"""
xwformats: Enterprise Serialization Formats

Extended serialization format support for enterprise applications.
This library provides heavyweight formats that are typically used in
specialized domains (scientific computing, big data, enterprise systems).

Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.23
Generation Date: 02-Nov-2025

Formats provided:
- Schema: Protobuf, Avro, Parquet, Thrift, ORC, Cap'n Proto, FlatBuffers
- Scientific: HDF5, Feather, Zarr, NetCDF, MAT
- Database: LMDB, GraphDB, LevelDB
- Binary: BSON, UBJSON
- Text: XML (reserved)

Total: 17 enterprise formats (~87 MB dependencies)

Installation:
    pip install exonware-xwformats              # lite: xwsystem + xwlazy
    pip install exonware-xwformats[lazy]        # lazy stack
    pip install exonware-xwformats[full]        # format backends (see pyproject.toml)
    pip install exonware-xwformats[dev]         # pytest, black, mypy, …
"""

try:
    from exonware.xwlazy import config_package_lazy_install_enabled

    config_package_lazy_install_enabled(
        __package__ or "exonware.xwformats",
        enabled=True,
        mode="smart",
    )
except ImportError:
    pass

from .version import (
    __version__,
    __author__,
    __email__,
    __company__,
)

# Import all format serializers
from .formats import *  # noqa: F401,F403

# Auto-register all serializers with UniversalCodecRegistry
from exonware.xwsystem.io.codec.registry import get_registry

_codec_registry = get_registry()

# Get all serializer classes from formats
from .formats.schema import (
    XWProtobufSerializer,
    XWParquetSerializer,
    XWThriftSerializer,
    XWOrcSerializer,
    XWCapnProtoSerializer,
    XWFlatBuffersSerializer,
    ArrowSerializer,
)
# Note: Avro excluded due to cramjam bug on Python 3.12 Windows — see docs/_archive/KNOWN_ISSUES.md
from .formats.scientific import (
    XWHdf5Serializer,
    XWFeatherSerializer,
    XWZarrSerializer,
    XWNetcdfSerializer,
    XWMatSerializer,
)
from .formats.database import (
    XWLmdbSerializer,
    XWGraphDbSerializer,
    XWLeveldbSerializer,
    RocksdbSerializer,
)
from .formats.binary import (
    BincodeSerializer,
    BsonSerializer,
    DillSerializer,
    PostcardSerializer,
    XWUbjsonSerializer,
)
from .formats.text import (
    CsvSerializer,
    RonSerializer,
    TomlSerializer,
    XmlSerializer,
    YamlSerializer,
)


# Register all serializers
for _serializer_class in [
    # Schema formats (Avro excluded — see docs/_archive/KNOWN_ISSUES.md)
    XWProtobufSerializer,
    XWParquetSerializer,
    XWThriftSerializer,
    XWOrcSerializer,
    XWCapnProtoSerializer,
    XWFlatBuffersSerializer,
    ArrowSerializer,
    # Scientific formats
    XWHdf5Serializer,
    XWFeatherSerializer,
    XWZarrSerializer,
    XWNetcdfSerializer,
    XWMatSerializer,
    # Database formats
    XWLmdbSerializer,
    XWGraphDbSerializer,
    XWLeveldbSerializer,
    RocksdbSerializer,
    # Binary formats
    BincodeSerializer,
    BsonSerializer,
    DillSerializer,
    PostcardSerializer,
    XWUbjsonSerializer,
    # Text formats
    CsvSerializer,
    RonSerializer,
    TomlSerializer,
    XmlSerializer,
    YamlSerializer,
]:
    _codec_registry.register(_serializer_class)

# Main public facade
from .facade import XWFormats


__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    "__company__",
    # High-level façade
    "XWFormats",
]

