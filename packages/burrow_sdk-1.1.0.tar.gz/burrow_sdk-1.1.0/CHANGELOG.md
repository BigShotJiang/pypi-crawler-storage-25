# Changelog

## [Unreleased]

## [1.0.0] (2026-03-18)

### BREAKING CHANGES
- **Removed all v1 adapter functions** — single clean API per framework
- **Renamed v2 functions to drop `_v2` suffix**:
  - `create_langchain_callback_v2` → `create_langchain_callback`
  - `create_burrow_guardrail_v2` → `create_burrow_guardrail`
  - `create_burrow_output_guardrail_v2` → `create_burrow_output_guardrail`
  - `create_burrow_hook_provider_v2` → `create_burrow_hook_provider`
  - `create_burrow_callback_v2` → `create_burrow_callback` (ADK)
  - `create_burrow_after_callback_v2` → `create_burrow_after_callback` (ADK)
  - `create_burrow_tool_callback_v2` → `create_burrow_tool_callback` (ADK)
  - `create_burrow_after_tool_callback_v2` → `create_burrow_after_tool_callback` (ADK)
- **Claude SDK hooks**: `create_burrow_hooks()` now returns event-based hook format
- **Removed deprecated `create_burrow_step`** from CrewAI adapter

### Added
- ADK tool-level hooks: `create_burrow_tool_callback()` and `create_burrow_after_tool_callback()`
- Strands `block_on_warn` parameter on `create_burrow_hook_provider()`
- Unit tests for all adapters (216 tests)
- Integration matrix in README
- Strands user-input scanning limitation documented with workaround

### Fixed
- Strands silent block failure: blocked tool results now correctly replaced
- OpenAI Agents tool scanning limitation documented
- Publish workflow: added `contents: read` permission for `actions/checkout`

## 0.5.0 (2026-02-15)

- Initial standalone release (migrated from lattice monorepo)
- Import path: `from burrow import BurrowGuard`
- Integrations: `from burrow.integrations.{framework} import ...`
- Added exception hierarchy (`BurrowError`, `BurrowBlockedError`, `BurrowTimeoutError`)
- Added structured logging via `logging.getLogger("burrow")`
- Added retry transport (`retries=2`) for resilience
- Added `py.typed` PEP 561 marker for type checker support
- Default API URL changed to `https://api.burrow.run`
- Package renamed from `burrow-ai` to `burrow-sdk`
- Build backend migrated from setuptools to hatchling
