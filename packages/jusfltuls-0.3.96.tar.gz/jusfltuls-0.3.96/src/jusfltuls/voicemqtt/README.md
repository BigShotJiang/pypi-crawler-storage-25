# VoiceMQTT

MQTT-activated voice transcription to clipboard with real-time audio level display.

## Overview

VoiceMQTT listens for activation messages via MQTT or keyboard input, records audio from your microphone, transcribes it using OpenAI's Whisper (via faster-whisper), and copies the result to your clipboard.

## Features

- **Dual Activation**: Trigger via MQTT messages OR keyboard commands
- **Real-time Audio Display**: Visual audio level meter during recording
- **Automatic Silence Detection**: Recording stops automatically after silence
- **Interactive Menu**: Adjust settings on-the-fly without restarting
- **MQTT Mode Switching**: Toggle between local, remote, and keyboard-only modes
- **Noise Calibration**: Measure ambient noise for optimal threshold
- **Clipboard/Paste Toggle**: Choose between copy-only or copy+paste modes
- **Dependency Check**: Warns about missing system libraries before failing
- **Local Whisper**: All transcription happens locally - no cloud services

## Installation

### System Dependencies

Required libraries for audio recording:
```bash
sudo apt install libsdl2-dev portaudio19-dev libasound2-dev wl-clipboard
```

Optional (for paste functionality):
```bash
sudo apt install ydotool
```

The program will check for these dependencies at startup and display installation instructions if any are missing.

### Python Package

```bash
pip install jusfltuls
```

Or from source:
```bash
pip install -e .
```

## Usage

### Basic Usage

```bash
# Connect to local MQTT broker (default)
voicemqtt

# Run without MQTT (keyboard-only mode - can also toggle with 'm' key)
voicemqtt --no-mqtt

# Use custom MQTT broker
voicemqtt --mqtt-host 192.168.1.5 --mqtt-port 1883

# Use public MQTT from config file (can also toggle with 'm' key)
voicemqtt --public-mqtt
```

### Interactive Menu

The menu displays on two lines showing current settings:

```
Menu: [q]uit | [r]ecord | [n]oise | [m]qtt=LOCAL | [c]lipboard/paste=ON
       threshold=0.1500 [d]own/[u]p
```

**Status indicators:**
- **MQTT**: `LOCAL` (green=connected, yellow=disconnected), `REMOTE`, or `OFF`
- **Clipboard/Paste**: `ON` (green) or `OFF` (red)

**Available keys:**

| Key | Action |
|-----|--------|
| `q` | Quit the program |
| `r` | Start recording immediately |
| `n` | Measure ambient noise (5s, suggests threshold) |
| `m` | Cycle MQTT mode: local → remote → off → local |
| `c` | Toggle clipboard/paste mode on/off |
| `d` | Decrease silence threshold (more sensitive) |
| `u` | Increase silence threshold (less sensitive) |

### Calibration

Measure your ambient noise level for optimal silence detection:

```bash
# Quick noise measurement via menu (press 'n')
# Or use calibration mode:
voicemqtt --calibrate
```

### Command Line Options

```bash
voicemqtt [OPTIONS]

Options:
  --mqtt-host TEXT              MQTT broker host (default: localhost)
  --mqtt-port INTEGER           MQTT broker port (default: 1883)
  --mqtt-topic TEXT             MQTT activation topic (default: voicemqtt/activate)
  --mqtt-user TEXT              MQTT username
  --mqtt-pass TEXT              MQTT password
  --mqtt-tls                    Enable TLS/SSL for MQTT
  --mqtt-ca-certs TEXT          Path to CA certificates
  --public-mqtt                 Use MQTT from ~/.config/influxdb/totalconfig.conf
  --recording-status-topic TEXT Topic for recording status updates
  --model TEXT                  Whisper model: tiny, base, small, medium, large-v1/v2/v3 (default: base)
  --device TEXT                 Device: cpu, cuda (default: cpu)
  --language TEXT               Language code: en, cs, de, auto (default: en)
  --silence-threshold FLOAT     Audio threshold for silence (default: 0.15)
  --silence-duration FLOAT      Seconds of silence before stopping (default: 3.0)
  --single                      Run once and exit
  --calibrate                   Calibrate silence threshold
  --paste                       Also paste transcription using ydotool
  --no-mqtt                     Run without MQTT broker
  --version                     Show version
  --help                        Show help
```

## MQTT Integration

### Activation Topics

VoiceMQTT listens for messages on the configured topic. These payloads trigger recording:

- `record`
- `start`
- `on`
- `1`
- `true`
- `yes`

### Status Topics

Recording status is published to the status topic:

- `2` - Recording with sound detected
- `1` - Recording with silence detected
- `0` - Idle/not recording

### Example MQTT Commands

```bash
# Trigger recording
mosquitto_pub -t voicemqtt/activate -m "record"

# Check status
mosquitto_sub -t voicemqtt/recording
```

## Configuration

### Public MQTT Config

Create `~/.config/influxdb/totalconfig.conf`:

```ini
[mqtt public]
server = mqtt.example.com:8883
username = your_username
password = your_password
```

Use with: `voicemqtt --public-mqtt`

## Tips

1. **MQTT Mode Switching**: Press 'm' to cycle between modes:
   - **LOCAL**: Connect to the MQTT broker specified via CLI (default: localhost)
   - **REMOTE**: Connect to the public MQTT broker from config file
   - **OFF**: Keyboard-only mode (no MQTT connection)

2. **Threshold Tuning**: If recording stops too early, press 'u' to increase threshold. If it keeps recording background noise, press 'd' to decrease it.

3. **Noise Measurement**: Press 'n' in a quiet room. The system records 5 seconds (skipping the first 1s to avoid spikes) and suggests an appropriate threshold.

4. **Paste Mode**: Toggle with 'c' - when ON, transcription is automatically typed into the active window (requires ydotool).

5. **Color Coding**: During recording:
   - **Cyan**: Audio below silence threshold
   - **Dim/Green/Yellow/Red**: Audio above threshold (increasing volume)

## Troubleshooting

### Missing System Libraries

If you see an error about missing libraries:

```
Missing system libraries detected!
Install required packages:
  sudo apt install libsdl2-dev portaudio19-dev libasound2-dev
```

Install all required dependencies:
```bash
sudo apt install libsdl2-dev portaudio19-dev libasound2-dev
```

### MQTT Connection Failed

```
Failed to connect to MQTT broker
```

Run without MQTT:
```bash
voicemqtt --no-mqtt
```

Or check your broker settings and network connection.

### Clipboard Not Working

```bash
sudo apt install wl-clipboard
```

### ydotool Permission Issues

```bash
sudo usermod -aG input $USER
echo 'KERNEL=="uinput", MODE="0660", GROUP="input"' | sudo tee /etc/udev/rules.d/99-uinput.rules
sudo udevadm control --reload-rules && sudo udevadm trigger
```

Then log out and back in.

## License

Part of jusfltuls - Useful tools for Linux life.
