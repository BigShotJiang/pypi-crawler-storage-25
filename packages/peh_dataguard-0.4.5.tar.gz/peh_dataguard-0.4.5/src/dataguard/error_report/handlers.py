import logging
import traceback
from uuid import uuid4

import pandera.polars as pa
import polars as pl
from pydantic import ValidationError

from dataguard.core.utils.enums import ErrorLevel
from dataguard.error_report.error_collector import ErrorCollector
from dataguard.error_report.error_schemas import (
    DFErrorSchema,
    ErrorReportSchema,
    ErrorSchema,
    ExceptionSchema,
)
from dataguard.error_report.utils import create_row_idx


def exception_handler(
    err: Exception,
    lazy: bool,
    err_level: str,
    logger: logging.Logger,
) -> None:
    logger.error(f'An unknown exception occurred: {str(err)}', exc_info=err)

    if not lazy:
        raise err

    error_traceback = traceback.format_exc()
    logger.error(f'Unknown exception traceback: {error_traceback}')

    exc_schema = ExceptionSchema(
        type=type(err).__name__,
        message=str(err),
        level=err_level,
        traceback=error_traceback,
    )

    ErrorCollector().add_unknown_exception(exc_schema)


def error_handler(
    err: Exception | ValidationError | pl.exceptions.PolarsError,
    err_level: str,
    message: str | None = None,
    lazy: bool = True,
    logger: logging.Logger = logging.getLogger(__name__),
) -> None:
    logger.error(f'Error occurred: {message}', exc_info=err)

    if not lazy:
        raise err

    error_traceback = traceback.format_exc()
    logger.error(f'Error traceback: {error_traceback}')

    err_schema = ErrorSchema(
        level=err_level,
        message=message if message else str(err),
        title=f'{type(err).__name__}: {str(err)}',
        type=type(err).__name__,
        traceback=error_traceback,
    )

    err_report = ErrorReportSchema(
        name='Critical Error Report',
        errors=[err_schema],
        total_errors=1,
        id=str(uuid4()),
    )

    ErrorCollector().add_error_report(err_report)


def pandera_schema_errors_handler(
    err: pa.errors.SchemaErrors | pa.errors.SchemaError,
    lazy: bool = False,
    logger: logging.Logger = logging.getLogger(__name__),
) -> None:
    logger.info(f'Processing pandera schema errors: {str(err)}')

    if not lazy:
        raise err

    idx_columns = getattr(err.schema, 'unique', [])

    errors = []
    if getattr(err, 'schema_errors', None):
        for schema_error in err.schema_errors:
            df_error = parse_schema_error(schema_error, idx_columns)
            errors.append(df_error)
            if df_error.level == ErrorLevel.CRITICAL:
                logger.warning(
                    'Critical error found, stopping further error processing'
                )
                break

    else:
        df_error = parse_schema_error(
            err, idx_columns, error_level=ErrorLevel.CRITICAL.value
        )
        errors.append(df_error)

    err_report = ErrorReportSchema(
        name=err.schema.name,
        errors=errors,
        total_errors=len(errors),
        id=str(uuid4()),
    )

    logger.info(f'Adding error report with {len(errors)} errors to collector')
    ErrorCollector().add_error_report(err_report)


def parse_schema_error(
    schema_error: pa.errors.SchemaError,
    idx_columns: list[str],
    error_level: str = ErrorLevel.ERROR.value,
) -> DFErrorSchema:
    reason_code = schema_error.reason_code

    match reason_code:
        case pa.errors.SchemaErrorReason.SERIES_CONTAINS_NULLS:
            message = (
                'Column under validation must not contain missing values.'  # noqa: E501
            )
        case pa.errors.SchemaErrorReason.COLUMN_NOT_IN_DATAFRAME:
            message = 'Column under validation must not be missing.'
        case pa.errors.SchemaErrorReason.SERIES_CONTAINS_DUPLICATES:
            message = (
                'Column under validation must not contain duplicate values.'  # noqa: E501
            )
        case pa.errors.SchemaErrorReason.DUPLICATES:
            message = (
                'Column under validation must not contain duplicate values.'  # noqa: E501
            )
        case pa.errors.SchemaErrorReason.CHECK_ERROR:
            message = (
                f'Error while executing check: {schema_error.check.title}.'  # noqa: E501
            )
        case _:
            message = message_handler(schema_error)

    return DFErrorSchema(
        type=str(schema_error.reason_code),
        message=message,
        level=getattr(schema_error.check, 'name', error_level),
        title=' '.join(
            (
                schema_error.check.title
                if isinstance(schema_error.check.title, str)
                else schema_error.check.title()
            ).split('_')
        ),
        column_names=(
            list(schema_error.schema.columns.keys())
            if getattr(schema_error.schema, 'columns', None)
            else [schema_error.schema.name]
        ),
        row_ids=create_row_idx(schema_error.check_output),
        idx_columns=idx_columns,
    )


def message_handler(schema_error: pa.errors.SchemaError) -> None:
    msg = schema_error.check.error

    if hasattr(schema_error.schema, 'columns'):
        return msg

    if hasattr(schema_error.failure_cases, 'to_dicts'):
        failure_cases = schema_error.failure_cases.to_dicts()[:5]
        examples_msg = f' Failure case examples: {failure_cases}'

        if len(examples_msg) > 250:  # noqa: PLR2004
            examples_msg = examples_msg[:250] + '...'

        msg += examples_msg

    return msg
