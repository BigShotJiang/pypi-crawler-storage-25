"""sift — AI-Powered Alert Triage Summarizer for SOC Teams."""

__version__ = "1.0.16"
