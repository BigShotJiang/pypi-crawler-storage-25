from setuptools import setup, find_packages

setup(
    name='FloxyUI',
    version='1.0.0rc4',
    author='floxxy0',
    packages=find_packages(),
    description='FloxyUI: Flask-based minimal HTML server',
    long_description='',
    long_description_content_type='text/plain',
    url='',
    classifiers=[],
    python_requires='>=3.6',
    install_requires=['flask'],
)
