"""FloxyUI Package - runs a minimal Flask HTML server."""

__version__ = '1.0.0rc4'
__author__ = 'floxxy0'

from flask import Flask

_app = Flask(__name__)

@_app.route('/')
def home():
    return '<h1>Server running.</h1>'


def start(ip: str, port: int):
    """Starts a Flask HTTP server that shows 'Server running.' on the root route."""
    print(f"Starting Flask server on {ip}:{port}")
    _app.run(host=ip, port=port)
