"""
langchain_signalfuse.tools — LangChain tool wrappers for SignalFuse API.
Drop into any LangChain agent to give it live trading intelligence.
"""

from typing import Type

import requests
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class SignalInput(BaseModel):
    symbol: str = Field(description="Crypto asset ticker, e.g. BTC, ETH, SOL")


class SignalFuseTool(BaseTool):
    """Get fused directional trading signal for a crypto asset."""

    name: str = "signalfuse_signal"
    description: str = (
        "Get fused directional trading signal for a crypto asset. "
        "Returns signal direction (long/short/neutral), signal_strength (0-100), "
        "confidence, macro regime, and component breakdowns. "
        "Use when asked about market conditions, trading decisions, or signal strength."
    )
    args_schema: Type[BaseModel] = SignalInput
    base_url: str = "https://api.signalfuse.co"
    credit_token: str = ""

    def _run(self, symbol: str) -> str:
        headers = {}
        if self.credit_token:
            headers["X-Credit-Token"] = self.credit_token
        r = requests.get(
            f"{self.base_url}/v1/signal/{symbol.upper()}",
            headers=headers,
            timeout=10,
        )
        r.raise_for_status()
        data = r.json()
        return (
            f"{symbol.upper()} Signal: strength={data['signal_strength']}/100 | "
            f"direction={data['signal']} | "
            f"regime={data['regime']} | "
            f"confidence={data['confidence']}"
        )

    async def _arun(self, symbol: str) -> str:
        return self._run(symbol)


class MacroRegimeTool(BaseTool):
    """Get current macro risk regime (risk_on/risk_off/neutral)."""

    name: str = "signalfuse_regime"
    description: str = (
        "Get current macro risk regime (risk_on/risk_off/neutral). "
        "Use for portfolio-level directional bias and position sizing decisions."
    )
    base_url: str = "https://api.signalfuse.co"
    credit_token: str = ""

    def _run(self, *args, **kwargs) -> str:
        headers = {}
        if self.credit_token:
            headers["X-Credit-Token"] = self.credit_token
        r = requests.get(f"{self.base_url}/v1/regime", headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json()
        return f"Macro regime: {data['regime']} (confidence: {data.get('confidence', 'N/A')})"

    async def _arun(self, *args, **kwargs) -> str:
        return self._run()
