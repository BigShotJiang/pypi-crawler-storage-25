# langchain-signalfuse

LangChain tools for the [SignalFuse](https://signalfuse.co) crypto trading signal API.

## Install

```bash
pip install langchain-signalfuse
```

## Usage

```python
from langchain_signalfuse import SignalFuseTool, MacroRegimeTool

tools = [
    SignalFuseTool(credit_token="your-token"),
    MacroRegimeTool(credit_token="your-token"),
]

# Drop into any LangChain agent
from langchain.agents import initialize_agent, AgentType

agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION)
agent.run("What's the current signal for ETH?")
```

### SignalFuseTool

Returns a fused directional signal for a given crypto asset (e.g. BTC, ETH, SOL), including signal strength, direction, confidence, and macro regime.

### MacroRegimeTool

Returns the current macro risk regime (`risk_on` / `risk_off` / `neutral`) for portfolio-level decisions.

## API

Base URL: `https://api.signalfuse.co`

Get 25 free credits (no signup):
```bash
curl -X POST https://api.signalfuse.co/v1/credits/trial \
  -H "Content-Type: application/json" \
  -d '{"wallet":"YOUR_ETH_ADDRESS"}'
```

This tool uses credit tokens for authentication. For x402 per-call payment (automatic USDC on Base), use the [starter bot](https://github.com/hypeprinter007-stack/hyperliquid-starter-bot) which has full x402 SDK integration.
