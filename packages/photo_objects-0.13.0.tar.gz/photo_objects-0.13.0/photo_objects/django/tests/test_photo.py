from base64 import b64decode
from datetime import timedelta
from io import BytesIO
from time import sleep
from unittest import mock

from ciou.time import utcnow
from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from PIL import Image
from urllib3.exceptions import HTTPError

from photo_objects.django.models import Album, SiteSettings
from photo_objects.django.objsto import get_photo
from photo_objects.django.views.ui.utils import year_month

from .utils import (
    TestCase,
    add_permissions,
    create_dummy_photo,
    open_test_photo,
    parse_timestamps,
    temp_static_files,
)


class PhotoModelTests(TestCase):
    def setUp(self):
        self.album = Album.objects.create(
            key="photo-model-test",
            visibility=Album.Visibility.PUBLIC)
        self.photos = [
            create_dummy_photo(
                self.album,
                f"{i:03d}.jpg",
            ) for i in range(3)
        ]

    def test_previous_and_next(self):
        for i in range(3):
            with self.subTest(i=i):
                photo = self.photos[i]
                self.assertEqual(
                    photo.previous(self.album.photo_set).key,
                    self.photos[(i - 1) % 3].key,
                )
                self.assertEqual(
                    photo.next(self.album.photo_set).key,
                    self.photos[(i + 1) % 3].key,
                )


class PhotoViewTests(TestCase):
    def setUp(self):
        user = get_user_model()
        user.objects.create_user(username='no_permission', password='test')

        has_permission = user.objects.create_user(
            username='has_permission', password='test')
        add_permissions(
            has_permission,
            'add_photo',
            'change_album',
            'change_photo',
            'delete_photo',
        )

        Album.objects.create(
            key="test-photo-a",
            visibility=Album.Visibility.PUBLIC)
        Album.objects.create(
            key="test-photo-b",
            visibility=Album.Visibility.HIDDEN)

    def test_post_photo_with_non_formdata_fails(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self.client.post(
            "/api/albums/test-photo-a/photos",
            "key=venice",
            content_type="text/plain")
        self.assertStatus(response, 415)

    def test_post_photo_without_files_fails(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self.client.post(
            "/api/albums/test-photo-a/photos",)
        self.assertStatus(response, 400)

    def test_put_photo_fails(self):
        response = self.client.put("/api/albums/test-photo-a/photos")
        self.assertStatus(response, 405)

    def test_cannot_upload_modify_delete_photo_without_permission(self):
        self.assertRequestStatuses([
            ("POST", "/api/albums/test-photo-a/photos", 401),
            ("PATCH", "/api/albums/test-photo-a/photos/tower.jpg", 401),
            ("DELETE", "/api/albums/test-photo-a/photos/tower.jpg", 401),
        ])

        login_success = self.client.login(
            username='no_permission', password='test')
        self.assertTrue(login_success)

        self.assertRequestStatuses([
            ("POST", "/api/albums/test-photo-a/photos", 403),
            ("PATCH", "/api/albums/test-photo-a/photos/tower.jpg", 403),
            ("DELETE", "/api/albums/test-photo-a/photos/tower.jpg", 403),
        ])

    def test_upload_photo_key_cleaning(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self._upload_photo("test-photo-a", "The Eiffel Tower.JPG")
        self.assertEqual(
            response.json().get("key"),
            "test-photo-a/The-Eiffel-Tower.JPG")

    def test_upload_photo_album_not_found(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        filename = "tower.jpg"
        file = open_test_photo(filename)
        response = self.client.post(
            "/api/albums/not-found/photos",
            {filename: file})
        self.assertStatus(response, 400)

    def test_upload_photo(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        filename = "tower.jpg"
        file = open_test_photo(filename)
        response = self.client.post(
            "/api/albums/test-photo-a/photos",
            {filename: file})
        self.assertStatus(response, 201)

        photo = self.client.get(
            "/api/albums/test-photo-a/photos/tower.jpg").json()
        self.assertEqual(photo.get("timestamp"), "2024-03-20T14:28:04+00:00")
        tiny_base64 = photo.get("tiny_base64")
        width, height = Image.open(BytesIO(b64decode(tiny_base64))).size
        self.assertEqual(width, 3)
        self.assertEqual(height, 3)

        file.seek(0)
        photo_response = get_photo("test-photo-a", filename, "og")
        self.assertEqual(
            photo_response.headers['Content-Type'],
            "image/jpeg")
        self.assertEqual(
            photo_response.read(),
            file.read(),
            "Photo in the file system does not match photo uploaded to the object storage")  # noqa

        file.seek(0)
        response = self.client.post(
            "/api/albums/test-photo-a/photos",
            {filename: file})
        self.assertStatus(response, 400)

    def test_create_photo_key_validation(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        file = open_test_photo("tower.jpg")
        response = self.client.post(
            "/api/albums/test-photo-a/photos",
            {"": file})
        self.assertStatus(response, 400)

    def test_upload_invalid_photo_file(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        filename = "invalid.jpg"
        file = open_test_photo(filename)
        response = self.client.post(
            "/api/albums/test-photo-a/photos",
            {filename: file})
        self.assertStatus(response, 400)

    def test_upload_to_objsto_fails(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        filename = "tower.jpg"
        file = open_test_photo(filename)
        with mock.patch(
            "photo_objects.django.api.photo.objsto.put_photo",
            side_effect=HTTPError,
        ):
            response = self.client.post(
                "/api/albums/test-photo-a/photos",
                {filename: file})
        self.assertStatus(response, 500)

        response = self.client.get(
            "/api/albums/test-photo-a/photos/tower.jpg")
        self.assertStatus(response, 404)

        response = self.client.get(
            "/api/albums/test-photo-a/photos")
        self.assertStatus(response, 200)
        self.assertEqual(len(response.json()), 0)

    def test_get_image_scales_the_image(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self._upload_photo("test-photo-a", "tower.jpg")
        uuid = response.json().get("uuid")

        # Validate Content-Disposition header
        self.assertPhotoObjstoMetadata(
            "og/test-photo-a/tower.jpg",
            "Content-Disposition",
            "inline; filename=tower.jpg",
        )

        # Scales image down from the original size
        small_response = self.client.get(
            f"/api/photos/{uuid}/img?size=sm")
        self.assertStatus(small_response, 200)
        _, height = Image.open(BytesIO(small_response.content)).size
        self.assertEqual(height, 512)

        # Validate Content-Disposition header
        self.assertPhotoObjstoMetadata(
            f"sm/_uuid/{uuid}",
            "Content-Disposition",
            "inline; filename=tower.webp",
        )

        # Does not scale image up from the original size
        large_response = self.client.get(
            f"/api/photos/{uuid}/img?size=lg")
        self.assertStatus(large_response, 200)
        _, height = Image.open(BytesIO(large_response.content)).size
        self.assertEqual(height, 512)

    def test_crud_actions(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self.client.get("/api/photos")
        self.assertStatus(response, 200)
        photos_count = len(response.json())

        response = self._upload_photo("test-photo-a", "tower.jpg")
        tower_uuid = response.json().get("uuid")

        # Can upload photo with the same name to a different album
        tic = utcnow()
        sleep(0.1)

        response = self._upload_photo("test-photo-b", "tower.jpg")

        t = parse_timestamps(response.json())
        self.assertTimestampLess(tic, t.created_at)
        self.assertTimestampLess(tic, t.updated_at)

        response = self.client.get("/api/albums/test-photo-a/photos/tower.jpg")
        self.assertStatus(response, 200)
        data = response.json()
        self.assertEqual(data.get("key"), "test-photo-a/tower.jpg")
        self.assertEqual(data.get("title"), "")
        self.assertEqual(data.get("description"), "")
        self.assertEqual(data.get("timestamp"), "2024-03-20T14:28:04+00:00")
        self.assertEqual(data.get("height"), 512)
        self.assertEqual(data.get("width"), 341)
        self.assertEqual(data.get("camera_make"), "FUJIFILM")
        self.assertEqual(data.get("camera_model"), "X-E3")
        self.assertEqual(data.get("lens_make"), "FUJIFILM")
        self.assertEqual(data.get("lens_model"), "XF23mmF2 R WR")
        self.assertEqual(data.get("focal_length"), 23.0)
        self.assertEqual(data.get("f_number"), 8.0)
        self.assertEqual(data.get("exposure_time"), 0.00025)
        self.assertEqual(data.get("iso_speed"), 800)

        tic = utcnow()
        sleep(0.1)

        req_data = dict(
            title="The Eiffel Tower",
            description="The Eiffel Tower in Paris, France",
            tags=["landmark", "Paris", "France", "tower"],)
        response = self.client.patch(
            "/api/albums/test-photo-a/photos/tower.jpg",
            content_type="application/json",
            data=req_data)
        self.assertStatus(response, 200)
        t = parse_timestamps(response.json())
        self.assertTimestampLess(t.created_at, tic)
        self.assertTimestampLess(tic, t.updated_at)
        # Tags are returned in alphabetical order.
        data = {
            **data,
            **req_data,
            **vars(t),
            "tags": [
                "France",
                "landmark",
                "Paris",
                "tower"]}
        self.assertDictEqual(response.json(), data)

        # Image file does not contain EXIF data so timestamp is the upload
        # time instead of the create time.
        response = self._upload_photo("test-photo-a", "havfrue.jpg")
        last_timestamp = response.json().get("timestamp")
        havfrue_uuid = response.json().get("uuid")
        self.assertGreater(last_timestamp,
                           (utcnow() - timedelta(minutes=1)).isoformat())

        response = self._upload_photo("test-photo-a", "bus-stop.jpg")
        first_timestamp = response.json().get("timestamp")

        response = self.client.get(
            f"/api/photos/{tower_uuid}/img?size=og")
        self.assertStatus(response, 200)

        response = self.client.get(
            "/api/albums/test-photo-a/photos")
        self.assertStatus(response, 200)
        self.assertListEqual(
            [i.get('filename') for i in response.json()],
            ['bus-stop.jpg', 'tower.jpg', 'havfrue.jpg'], response.content)

        response = self.client.get(
            "/api/albums/test-photo-a")
        self.assertResponseStatusAndItems(
            response, 200, {
                'first_timestamp': first_timestamp,
                'last_timestamp': last_timestamp,
                'cover_photo': 'tower.jpg',
            }
        )

        response = self.client.get("/api/photos")
        self.assertStatus(response, 200)
        self.assertEqual(len(response.json()), photos_count + 4)

        response = self.client.delete(
            "/api/albums/test-photo-a/photos/tower.jpg")
        self.assertStatus(response, 204)

        response = self.client.get(
            "/api/albums/test-photo-a")
        self.assertResponseStatusAndItems(
            response, 200, {
                'first_timestamp': first_timestamp,
                'last_timestamp': last_timestamp,
                'cover_photo': 'bus-stop.jpg',
            }
        )

        response = self.client.delete(
            "/api/albums/test-photo-a/photos/bus-stop.jpg")
        self.assertStatus(response, 204)

        response = self.client.get(
            "/api/albums/test-photo-a")
        self.assertResponseStatusAndItems(
            response, 200, {
                'first_timestamp': last_timestamp,
                'last_timestamp': last_timestamp,
                'cover_photo': 'havfrue.jpg',
            }
        )

        response = self.client.get(
            f"/api/photos/{havfrue_uuid}/img?size=og")
        self.assertStatus(response, 200)

        response = self.client.get(
            f"/api/photos/{tower_uuid}/img?size=og")
        self.assertStatus(response, 404)

        response = self.client.get("/api/albums/test-photo-a/photos/tower.jpg")
        self.assertStatus(response, 404)

        response = self.client.delete(
            "/api/albums/test-photo-a/photos/havfrue.jpg")
        self.assertStatus(response, 204)

        response = self.client.get(
            "/api/albums/test-photo-a")
        self.assertResponseStatusAndItems(
            response, 200, {
                'first_timestamp': None,
                'last_timestamp': None,
                'cover_photo': None,
            }
        )

    @temp_static_files
    def test_paging(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        for i in ["bus-stop.jpg", "tower.jpg", "havfrue.jpg"]:
            self._upload_photo("test-photo-a", i)

        # havfrue.jpg does not have capture time in EXIF info, so upload
        # time is used as the timestamp.
        cph_group = year_month(utcnow())

        response = self.client.get("/photos")
        self.assertStatus(response, 200)
        self.assertNotContains(response, 'Page 1 of 2', html=True)
        self.assertNotContains(response, f'<h2>{cph_group}</h2>', html=True)

        response = self.client.get("/api/photos")
        self.assertStatus(response, 200)
        count = len(response.json())

        site_settings = SiteSettings.objects.get(site=Site.objects.get(id=1))
        site_settings.photos_group_by = SiteSettings.GroupBy.MONTH
        site_settings.photos_page_size = count - 2
        site_settings.photos_orphans = 0
        site_settings.save()

        response = self.client.get("/photos")
        self.assertStatus(response, 200)
        self.assertContains(response, f'<h2>{cph_group}</h2>', html=True)
        self.assertContains(response, 'Page 1 of 2', html=True)

        site_settings.photos_orphans = 2
        site_settings.save()

        response = self.client.get("/photos")
        self.assertStatus(response, 200)
        self.assertContains(response, f'<h2>{cph_group}</h2>', html=True)
        self.assertNotContains(response, 'Page 1 of 2', html=True)

    @temp_static_files
    def test_album_link(self):
        login_success = self.client.login(
            username='has_permission', password='test')
        self.assertTrue(login_success)

        response = self._upload_photo("test-photo-b", "tower.jpg")
        photo_uuid = response.json().get("uuid")

        album_title_label = '<div class="label-primary">test-photo-b</div>'

        response = self.client.get(f"/photos/{photo_uuid}")
        self.assertStatus(response, 200)
        self.assertContains(response, album_title_label, html=True)

        response = self.client.get("/albums/test-photo-b/photos/tower.jpg")
        self.assertStatus(response, 200)
        self.assertNotContains(response, album_title_label, html=True)

        self.client.logout()

        response = self.client.get(f"/photos/{photo_uuid}")
        self.assertStatus(response, 200)
        self.assertNotContains(response, album_title_label, html=True)
