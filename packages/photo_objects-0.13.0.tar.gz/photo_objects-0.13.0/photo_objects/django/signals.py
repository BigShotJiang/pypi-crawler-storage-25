from django.db.models.signals import post_save, post_delete, pre_delete
from django.dispatch import receiver

from photo_objects.django.api import create_backup
from photo_objects.django.api.backup import delete_backup

from .models import Backup, Photo, Tag


@receiver(post_save, sender=Photo)
def update_album_on_photo_upload(sender, **kwargs):
    photo = kwargs.get('instance', None)
    album = photo.album

    needs_save = False
    if album.cover_photo is None:
        needs_save = True
        album.cover_photo = photo

    if not album.first_timestamp or photo.timestamp < album.first_timestamp:
        needs_save = True
        album.first_timestamp = photo.timestamp

    if not album.last_timestamp or photo.timestamp > album.last_timestamp:
        needs_save = True
        album.last_timestamp = photo.timestamp

    if needs_save:
        album.save()


@receiver(post_save, sender=Photo)
def remove_unused_tags(sender, **kwargs):
    Tag.objects.filter(photo__isnull=True).delete()


@receiver(post_delete, sender=Photo)
def update_album_on_photo_delete(sender, **kwargs):
    photo = kwargs.get('instance', None)
    album = photo.album

    try:
        first_photo = album.photo_set.latest('-timestamp')
        last_photo = album.photo_set.latest('timestamp')
    except Photo.DoesNotExist:
        album.cover_photo = None
        album.first_timestamp = None
        album.last_timestamp = None
        album.save()
        return

    try:
        cover_photo = album.cover_photo
    except Photo.DoesNotExist:
        cover_photo = None

    needs_save = False
    if cover_photo is None:
        needs_save = True
        album.cover_photo = first_photo

    if album.first_timestamp < first_photo.timestamp:
        needs_save = True
        album.first_timestamp = first_photo.timestamp

    if album.last_timestamp > last_photo.timestamp:
        needs_save = True
        album.last_timestamp = last_photo.timestamp

    if needs_save:
        album.save()


@receiver(post_save, sender=Backup)
def create_backup_to_objsto(sender, **kwargs):
    created = kwargs.get('created', False)
    if not created:
        return None

    backup = kwargs.get('instance', None)
    return create_backup(backup)


@receiver(pre_delete, sender=Backup)
def delete_backup_from_objsto(sender, **kwargs):
    backup = kwargs.get('instance', None)
    return delete_backup(backup)
