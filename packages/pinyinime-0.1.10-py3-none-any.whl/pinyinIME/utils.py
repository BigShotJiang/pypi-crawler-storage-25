LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(funcName)s:%(lineno)d: %(message)s"


class SearchSegmentsTimeoutError(Exception):
    """当 _search_segments 搜索超时时抛出的异常。"""

    def __init__(self, segments: list[str], timeout: float):
        self.segments = segments
        self.timeout = timeout
        super().__init__(f"检索超时 ({timeout}s): segments={segments}")
