import itertools
import logging

from pinyinIME.index.prism import Prism
from pinyinIME.index.table import DictEntry, Table

logger = logging.getLogger(__name__)


class PhraseAnnotator:
    # 从test中看它的输入输出
    def __init__(self, char_pinyins: dict[str, list[str]], max_combos: int = 8):
        self._char_pinyins = char_pinyins
        self._max_combos = max_combos

    def annotate(self, phrase: str) -> list[list[str]]:
        per_char: list[list[str]] = []
        for ch in phrase:
            pinyins = self._char_pinyins.get(ch)
            if not pinyins:
                return []
            per_char.append(pinyins)
        return [list(c) for c in itertools.islice(itertools.product(*per_char), self._max_combos)]


class IndexBuilder:
    def __init__(self, annotator: PhraseAnnotator):
        self._annotator = annotator

    def _build_staging(
        self,
        dict_entries: list[tuple[str, list[str], float]],
        essay_entries: list[tuple[str, int]],
    ) -> dict[tuple[str, str], int | float]:
        """
        合并词典条目与词频数据，返回 {(词, 拼音串): 分数} 的暂存表。
        拼音串为空格分隔的音节，分数取 essay_freq 优先，其次词典权重。
        对 essay 中未被词典覆盖的词，通过 PhraseAnnotator 自动标注拼音。

        返回示例:
          {
              ("你好", "ni hao"):  12345,   # 来自 essay_freq
              ("中国", "zhong guo"): 98765,
          }
        """
        essay_freq: dict[str, int] = {}
        for word, freq in essay_entries:
            if freq > essay_freq.get(word, 0):
                essay_freq[word] = freq
        staging: dict[tuple[str, str], int | float] = {}

        # weight 是发音概率 [0, 1]，无百分比的词默认 1.0
        for word, syllables, prob in dict_entries:
            key = " ".join(syllables)
            base = essay_freq.get(word)
            if base:
                score: float = base * prob  # 发音概率作为乘数，0% 发音趋近于 0
            else:
                score = prob * 100.0  # 无词频兜底：100% → score=100, 0% → score=0
            k = (word, key)
            if k not in staging or staging[k] < score:
                staging[k] = score

        dict_covered = {word for word, _ in staging}

        annotated = skipped = 0
        for word, freq in essay_entries:
            if freq == 0 or word in dict_covered:
                # essay freq=0 视为无效
                # dict_covered 里的词已有准确拼音，跳过自动注音（注音以 dict 为准）
                continue
            combos = self._annotator.annotate(word)
            if not combos:
                skipped += 1
                continue
            for syllables in combos:
                key = " ".join(syllables)
                k = (word, key)
                if k not in staging or staging[k] < freq:
                    staging[k] = freq
            annotated += 1

        logger.debug("essay 新增注音短语: %d，跳过: %d", annotated, skipped)
        return staging

    def build(
        self,
        dict_entries: list[tuple[str, list[str], float]],
        essay_entries: list[tuple[str, int]],
    ) -> tuple[Prism, Table]:
        # staging : ("你好", "ni hao"):  12345
        staging = self._build_staging(dict_entries, essay_entries)
        # 收集所有唯一音节，构建 Prism ;
        all_syllables: list[str] = sorted({syl for _, key in staging for syl in key.split(" ")})
        # Prism 处理单音节
        prism = Prism(all_syllables)  # self._initials_index, 缩写查: "n" → ni, nian, niang
        syl_to_id = {s: i for i, s in enumerate(all_syllables)}

        # 构建 Table
        table = Table()
        # ("你好", "ni hao"):  12345
        for (word, key), score in staging.items():
            syllables = key.split(" ")  # ["ni", "hao"]
            syl_ids = tuple(syl_to_id[s] for s in syllables)
            table.insert(syl_ids, DictEntry(word=word, score=int(score)))
        table.sort_all()

        logger.debug("共插入 %d 条，音节数: %d", len(staging), len(all_syllables))
        return prism, table
