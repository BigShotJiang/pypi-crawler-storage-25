from pathlib import Path


class EmojiLoader:
    @staticmethod
    def load(path: Path) -> list[tuple[str, list[str]]]:
        """解析 rime-emoji 格式的词典文件（emoji_word.simp.txt）。

        每行格式：keyword<TAB>keyword emoji1 emoji2 ...
        返回 [(keyword, [emoji1, emoji2, ...]), ...]。
        keyword 是汉字关键词，供 PhraseAnnotator 自动注音。
        忽略空行、注释行（# 开头）、格式错误行。
        """
        if not path.exists():
            return []
        entries: list[tuple[str, list[str]]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t", 1)
            if len(parts) != 2:
                continue
            keyword, rest = parts
            # right side: "keyword emoji1 emoji2 ..."，跳过第一个 token（=keyword 本身）
            tokens = rest.strip().split(" ")
            emojis = [t for t in tokens[1:] if t.strip()]
            if keyword.strip() and emojis:
                entries.append((keyword.strip(), emojis))
        return entries
