import logging

logger = logging.getLogger(__name__)


class DictLoader:
    @staticmethod
    def load(dict_path: str) -> tuple[dict[str, list[str]], list[tuple[str, list[str], float]]]:
        char_pinyins: dict[str, list[str]] = {}
        entries = []
        in_body = False

        with open(dict_path, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if line.strip() == "...":
                    in_body = True
                    continue
                if not in_body or not line or line.startswith("#"):
                    continue

                parts = line.split("\t")
                if len(parts) < 2:
                    continue

                word = parts[0].strip()
                pinyin_raw = parts[1].strip()
                weight = 1.0  # 无百分比 = 100%（标准/唯一发音）
                if len(parts) >= 3:
                    try:
                        w = parts[2].strip()
                        raw = float(w[:-1]) if w.endswith("%") else float(w)
                        weight = raw / 100.0  # 归一化为 [0, 1] 的发音概率
                    except ValueError:
                        logger.warning("跳过无效权重行: %r", line)

                if word and "\u3100" <= word[0] <= "\u312f":
                    # Bopomofo: 台湾常用的注音输入法符号
                    continue

                syllables = pinyin_raw.split()
                if not syllables:
                    continue

                entries.append((word, syllables, weight))

                # 单字
                if len(word) == 1 and len(syllables) == 1:
                    py = syllables[0]
                    if word not in char_pinyins:
                        char_pinyins[word] = []
                    if py not in char_pinyins[word]:
                        char_pinyins[word].append(py)

        return char_pinyins, entries
