from pathlib import Path


class CustomPhraseLoader:
    @staticmethod
    def parse(text: str) -> list[tuple[str, list[str] | None, int | None]]:
        """从文本内容解析自定义词条，返回 (词, 音节列表或None, 权重或None) 列表。

        格式（逗号分隔，后两列可选）：
          词               → 自动注音，默认权重
          艾伦凯, ai lun kai           → 显式音节（空格分隔），默认权重
          词, pi, 100      → 显式音节 + 自定义权重
        """
        result: list[tuple[str, list[str] | None, int | None]] = []
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split(",")]
            word = parts[0]
            syllables: list[str] | None = None
            weight: int | None = None
            if len(parts) >= 2 and parts[1]:
                syllables = parts[1].split()
            if len(parts) >= 3 and parts[2]:
                try:
                    weight = int(parts[2])
                except ValueError:
                    pass
            result.append((word, syllables, weight))
        return result

    @staticmethod
    def load(path: Path) -> list[tuple[str, list[str] | None, int | None]]:
        """从文件解析自定义词条。"""
        if not path.exists():
            return []
        return CustomPhraseLoader.parse(path.read_text(encoding="utf-8"))
