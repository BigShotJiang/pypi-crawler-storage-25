from typing import NamedTuple


class DictEntry(NamedTuple):
    word: str
    score: int


class Table:
    """syllable_id 序列 → DictEntry 列表（降序存储）"""

    def __init__(self):
        # **trie-like**: node = dict[syl_id, node] | list[DictEntry]
        self._root: dict = {}
        # {402: {'_entries': [DictEntry(word='这', score=0), DictEntry(word='這', score=181776)]}, ...}

    def insert(self, syl_ids: tuple[int, ...], entry: DictEntry):
        # 从根节点出发，沿音节 ID 序列逐层向下游走
        node = self._root
        for sid in syl_ids:
            # 若当前音节 ID 尚无子节点，则新建一个空字典作为子节点
            # syl_ids = (402, 518) 就会在 root → 402 → 518 这条路径上存入词条
            if sid not in node:
                node[sid] = {}
            node = node[sid]  # 进入下一层
        # 到达**路径终点**：在该节点挂载词条列表（延迟初始化）
        if "_entries" not in node:
            node["_entries"] = []
        entries: list[DictEntry] = node["_entries"]
        for i, e in enumerate(entries):
            if e.word == entry.word:
                entries[i] = entry  # 更新已有词条，避免重复占用 top_n 名额
                return
        entries.append(entry)  # 追加词条，排序由 sort_all() 统一完成

    def sort_all(self):
        def _sort(node: dict):
            if "_entries" in node:
                node["_entries"].sort(key=lambda e: -e.score)  # - 降序, sort() 默认按升序排列（小→大）
            for k, v in node.items():
                if k != "_entries":
                    _sort(v)

        _sort(self._root)

    def has_prefix(self, syl_ids: list[int]) -> bool:
        node = self._root
        for sid in syl_ids:
            if sid not in node:
                return False
            node = node[sid]
        return True

    def search(self, syl_ids: tuple[int, ...]) -> list[DictEntry]:
        node = self._root
        for sid in syl_ids:
            if sid not in node:
                return []
            # 通过 for 一直走到到叶子节点
            node = node[sid]
        return node.get("_entries", [])
