from pinyinIME.pipeline.types import INITIALS, SpellingType


class Prism:
    """
    Prism 对应 Rime 原架构里的 prism（棱镜）概念——把一个拼写"折射"成多个可能的音节。
    拼写字符串 → syllable_id 列表，支持声母缩写索引

    声母 initials
    韵母 finals
    """

    def __init__(self, syllables: list[str]):
        self._syllables = syllables  # 所有可能的音节
        # 精确查 ni->ni
        self._syl_to_id: dict[str, int] = {s: i for i, s in enumerate(syllables)}
        # 缩写查 "n" → ni, nian, niang
        self._initials_index: dict[str, list[int]] = {}  # initial -> [syllable_ids]
        # 补全查 "nia" → nian, niang. 注释掉, 问题: 组合爆炸, rime luna_pinyin 也不是这样工作
        self._build()

    def _build(self):
        for syl_id, syl in enumerate(self._syllables):
            # 声母倒排索引
            for initial in INITIALS:
                if syl.startswith(initial) and syl != initial:
                    self._initials_index.setdefault(initial, []).append(syl_id)

    def search(self, spelling: str) -> list[tuple[int, SpellingType]]:
        """返回所有匹配 spelling 的 (syllable_id, SpellingType) 列表"""
        results: list[tuple[int, SpellingType]] = []
        seen: set[int] = set()

        # 完整音节匹配
        if spelling in self._syl_to_id:
            sid = self._syl_to_id[spelling]
            results.append((sid, SpellingType.NORMAL))
            seen.add(sid)

        # 声母缩写
        if spelling in self._initials_index:
            for sid in self._initials_index[spelling]:
                if sid not in seen:
                    results.append((sid, SpellingType.ABBREVIATION))
                    seen.add(sid)

        return results

    def syllables_set(self) -> set[str]:
        return set(self._syllables)

    def syllable(self, syl_id: int) -> str:
        return self._syllables[syl_id]

    def syllable_count(self) -> int:
        return len(self._syllables)
