import logging

logger = logging.getLogger(__name__)


class EssayLoader:
    @staticmethod
    def load(essay_path: str) -> list[tuple[str, int]]:
        entries = []
        with open(essay_path, encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 2:
                    try:
                        entries.append((parts[0], int(parts[1])))
                    except ValueError:
                        logger.warning("跳过无效行: %r", line)
        return entries
