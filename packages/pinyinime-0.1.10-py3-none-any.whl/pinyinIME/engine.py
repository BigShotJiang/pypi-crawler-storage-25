from __future__ import annotations

import logging
import logging.handlers
import pickle
import time
from pathlib import Path

from pinyinIME.index.builder import IndexBuilder, PhraseAnnotator
from pinyinIME.index.custom_phrase_loader import CustomPhraseLoader
from pinyinIME.index.dict_loader import DictLoader
from pinyinIME.index.emoji_loader import EmojiLoader
from pinyinIME.index.essay_loader import EssayLoader
from pinyinIME.index.table import DictEntry, Table
from pinyinIME.pipeline.filter import Filter, TraditionalFilter
from pinyinIME.pipeline.segmentor import FmmStrategy
from pinyinIME.pipeline.translator import Querier
from pinyinIME.session_types import CharByCharState, QueryResult, SelectResult, candidates
from pinyinIME.userdata.user_history import UserHistory
from pinyinIME.userdata.user_paths import (
    CUSTOM_PHRASE,
    EMOJI_BUILTIN,
    LOG_DEBUG,
    LOG_ERROR,
    LOG_INFO,
    ensure_user_dir,
    load_config,
)
from pinyinIME.utils import LOG_FORMAT

logger = logging.getLogger(__name__)


def _setup_logging() -> None:
    """配置文件日志（error.log + info.log + debug.log），幂等。"""
    root = logging.getLogger("pinyinIME")
    if root.handlers:
        return
    root.setLevel(logging.DEBUG)

    fmt = logging.Formatter(LOG_FORMAT)

    err_h = logging.handlers.RotatingFileHandler(
        LOG_ERROR, maxBytes=1 << 20, backupCount=10, encoding="utf-8"
    )  # 1 MB x 10
    err_h.setLevel(logging.ERROR)
    err_h.setFormatter(fmt)

    info_h = logging.handlers.RotatingFileHandler(LOG_INFO, maxBytes=2 << 20, backupCount=10, encoding="utf-8")
    info_h.setLevel(logging.INFO)
    info_h.setFormatter(fmt)

    dbg_h = logging.handlers.RotatingFileHandler(LOG_DEBUG, maxBytes=5 << 20, backupCount=10, encoding="utf-8")
    dbg_h.setLevel(logging.DEBUG)
    dbg_h.setFormatter(fmt)

    root.addHandler(err_h)
    root.addHandler(info_h)
    root.addHandler(dbg_h)

    # 读取 config.json 中的 log.level，控制实际写入日志的最低级别
    level_name = load_config().get("log", {}).get("level", "INFO")
    level = getattr(logging, str(level_name).upper(), logging.INFO)
    root.setLevel(level)


_USER_WEIGHT_MULTIPLIER = 10_000_000  # 确保用户词在 log 域高于任意 essay 词频
_CUSTOM_WEIGHT_MULTIPLIER = 1_000_000  # custom_phrase 低于动态选词，高于 essay
_EMOJI_WEIGHT_MULTIPLIER = 1_000  # emoji 低于 custom_phrase，高于 essay 基准

_MAX_WORD_CANDIDATES = 200  # 一次取完所有词, 帮助确定单字边界
_MAX_CHAR_CANDIDATES = 100  # 单个音节的单字候选上限


class PinyinEngine:
    """
    engine = PinyinEngine.default()
    """

    @classmethod
    def default(cls) -> PinyinEngine:
        """使用内置数据文件初始化引擎"""
        ensure_user_dir()
        _setup_logging()
        data_dir = Path(__file__).parent / "data"
        config = load_config()
        return cls(str(data_dir / "luna_pinyin.dict_simp.yaml"), str(data_dir / "essay_simp.txt"), config=config)

    @staticmethod
    def _cache_path(dict_path: str, essay_path: str) -> Path:
        return Path(dict_path).parent / ".pinyin_prism_table.pkl"

    def __init__(
        self,
        dict_path: str,
        essay_path: str,
        filters: list[Filter] | None = None,
        user_dict: UserHistory | None = None,
        config: dict[str, object] | None = None,
        load_user_history: bool = True,
        load_custom_phrases: bool = True,
        load_emoji: bool = True,
    ):
        self.config = config or {}
        self._filters: list[Filter] = filters if filters is not None else []
        self._user_dict = user_dict if user_dict is not None else UserHistory()
        self._dict_path = dict_path
        self._essay_path = essay_path
        self._load_user_history = load_user_history
        self._load_custom_phrases = load_custom_phrases
        self._load_emoji = load_emoji

        # 保存供 commit() 增量更新使用, 由 _build_querier 赋值
        self._table = None
        self._syl_to_id = None
        self._annotator = None
        self._pending_table = Table()  # 本次会话期间新提交的词，不合并到主表
        self._querier = self._build_querier()

    def _build_querier(self) -> Querier:
        cache_path = self._cache_path(self._dict_path, self._essay_path)

        if cache_path.exists():
            logger.debug("加载缓存: %s", cache_path)
            try:
                with open(cache_path, "rb") as f:
                    prism, table, char_pinyins = pickle.load(f)
            except Exception:
                logger.warning("缓存加载失败，重建索引", exc_info=True)
                cache_path.unlink(missing_ok=True)
                return self._build_querier()
            logger.debug("缓存加载完毕，就绪")
        else:
            logger.debug("加载词典: %s", self._dict_path)
            char_pinyins, dict_entries = DictLoader.load(self._dict_path)
            logger.debug("单字注音: %d 字，词条: %d", len(char_pinyins), len(dict_entries))

            logger.debug("加载词频: %s", self._essay_path)
            essay_entries = EssayLoader.load(self._essay_path)
            logger.debug("essay 条目: %d", len(essay_entries))

            logger.debug("构建索引...")
            annotator = PhraseAnnotator(char_pinyins)
            prism, table = IndexBuilder(annotator).build(dict_entries, essay_entries)

            logger.debug("保存缓存: %s", cache_path)
            with open(cache_path, "wb") as f:
                pickle.dump((prism, table, char_pinyins), f, protocol=pickle.HIGHEST_PROTOCOL)
            logger.debug("索引构建完毕，就绪")

        syl_to_id = {prism.syllable(i): i for i in range(prism.syllable_count())}
        annotator = PhraseAnnotator(char_pinyins)

        # 提前赋值，供下方各 load_* 方法使用, commit() 增量更新也要使用
        self._table = table
        self._syl_to_id = syl_to_id
        self._annotator = annotator

        # 合并 custom_phrase.txt（静态自定义词，不持久化到缓存）
        if self._load_custom_phrases and CUSTOM_PHRASE.exists():
            self.load_custom_phrases(CUSTOM_PHRASE.read_text(encoding="utf-8"))

        # 合并 emoji（内置，不缓存到磁盘）
        if self._load_emoji:
            self._merge_emoji()

        # 合并用户输入词条（不持久化到磁盘缓存，每次启动重新叠加）
        if self._load_user_history:
            self._merge_user_history()

        # 准备好了所有数据! 接下来是算法部分
        return Querier(prism, table, strategy=FmmStrategy(prism), config=self.config, pending_table=self._pending_table)

    def _merge_emoji(self) -> None:
        """将内置 emoji 合并进索引（不缓存到磁盘）。"""
        assert self._table is not None and self._syl_to_id is not None and self._annotator is not None
        emoji_entries = EmojiLoader.load(EMOJI_BUILTIN)
        if not emoji_entries:
            return
        inserted = 0
        for keyword, emojis in emoji_entries:
            combos = self._annotator.annotate(keyword)
            if not combos:
                logger.debug("emoji 关键词 %r 无法注音，跳过", keyword)
                continue
            for syllables in combos:
                raw_ids = [self._syl_to_id.get(s) for s in syllables]
                if None in raw_ids:
                    continue
                syl_ids = tuple(int(i) for i in raw_ids if i is not None)
                for emoji in emojis:
                    self._table.insert(syl_ids, DictEntry(word=emoji, score=_EMOJI_WEIGHT_MULTIPLIER))
                    inserted += 1
        if inserted:
            self._table.sort_all()
        logger.info("合并 emoji: %d 条索引", inserted)

    def _merge_user_history(self) -> None:
        """将用户历史输入词条合并进索引（不持久化到磁盘缓存，每次启动重新叠加）。"""
        assert self._table is not None and self._syl_to_id is not None
        user_entries = self._user_dict.get_entries()
        if not user_entries:
            return
        for word, syllables, freq in user_entries:
            raw_ids = [self._syl_to_id.get(s) for s in syllables]
            if None in raw_ids:
                continue
            syl_ids = tuple(int(i) for i in raw_ids if i is not None)
            self._table.insert(syl_ids, DictEntry(word=word, score=freq * _USER_WEIGHT_MULTIPLIER))
        self._table.sort_all()
        logger.info("合并用户历史输入词条: %d 条", len(user_entries))

    def load_custom_phrases(self, text: str) -> int:
        """将 custom_phrase 格式的文本内容合并进索引，返回插入的索引条数。

        格式（逗号分隔，后两列可选）：
          词               → 自动注音，默认权重
          艾伦凯, ai lun kai           → 显式音节（空格分隔），默认权重
          词, pi, 100      → 显式音节 + 自定义权重
        """
        assert self._table is not None and self._syl_to_id is not None and self._annotator is not None
        custom_words = CustomPhraseLoader.parse(text)
        if not custom_words:
            return 0
        inserted = 0
        for word, explicit_syllables, weight in custom_words:
            score = weight * 1_000 if weight is not None else _CUSTOM_WEIGHT_MULTIPLIER
            combos: list[list[str]] = (
                [explicit_syllables] if explicit_syllables is not None else self._annotator.annotate(word)
            )
            for syllables in combos:
                raw_ids = [self._syl_to_id.get(s) for s in syllables]
                if None in raw_ids:
                    continue
                syl_ids: tuple[int, ...] = tuple(int(i) for i in raw_ids if i is not None)
                self._table.insert(syl_ids, DictEntry(word=word, score=score))
                inserted += 1
        if inserted:
            self._table.sort_all()
        logger.info("合并自定义词条: %d 词，%d 条索引", len(custom_words), inserted)
        return inserted

    def _build_query(self, pinyin: str) -> QueryResult:
        syllables = tuple(self.segment(pinyin))
        word_results = tuple(self.lookup(pinyin, _MAX_WORD_CANDIDATES))
        if len(syllables) > 1:
            first_syl = syllables[0]
            char_results = tuple((w, k, s) for w, k, s in self.lookup(first_syl, _MAX_CHAR_CANDIDATES) if len(w) == 1)
        else:
            char_results = ()
        return QueryResult(word_results, char_results, len(word_results), syllables)

    def get_candidates(self, context: str | CharByCharState) -> tuple[str, ...]:
        """返回完整候选列表。context 为拼音字符串（normal 模式）或 CharByCharState。"""
        if isinstance(context, str):
            return candidates(self._build_query(context))
        return candidates(self._build_query("'".join(context["remaining_syllables"])))

    def query(self, pinyin: str, page: int, page_size: int):
        all_candidates = []
        query_result = self._build_query(pinyin)
        for word, pinyin_key, _ in query_result.word_results:
            all_candidates.append({"word": word, "syllables": pinyin_key.split()})
        for word, pinyin_key, _ in query_result.char_results:
            all_candidates.append({"word": word, "syllables": pinyin_key.split()})
        page_candidates = all_candidates[page * page_size : (page + 1) * page_size]
        result = {
            "syllables": list(query_result.syllables),
            "candidates": page_candidates,
            "max_page": (len(all_candidates) + page_size - 1) // page_size,
        }

        return result
    
    def select(self, context: str | CharByCharState, global_idx: int) -> SelectResult:
        """根据选词计算新状态和 commit 信息（不执行 commit 副作用）。"""
        if isinstance(context, str):
            return self._select_from_normal(context, global_idx)
        return self._select_from_char_by_char(context, global_idx)

    def _select_from_normal(self, input: str, global_idx: int) -> SelectResult:
        query = self._build_query(input)
        word = candidates(query)[global_idx]
        if global_idx < query.word_boundary:
            _, pinyin_key, _ = query.word_results[global_idx]
            return word, (word, pinyin_key.split()), None
        else:
            char_idx = global_idx - query.word_boundary
            _, first_pinyin_key, _ = query.char_results[char_idx]
            remaining = query.syllables[1:]
            new_state: CharByCharState = {
                "original_syllables": list(query.syllables),
                "remaining_syllables": list(remaining),
                "selected_chars": [word],
                "resolved_syllables": first_pinyin_key.split(),
                "type": "char_by_char",
            }
            return word, None, new_state

    def _select_from_char_by_char(self, state: CharByCharState, global_idx: int) -> SelectResult:
        query = self._build_query("'".join(state["remaining_syllables"]))
        word = candidates(query)[global_idx]
        if global_idx < query.word_boundary:
            _, pinyin_key, _ = query.word_results[global_idx]
        else:
            _, pinyin_key, _ = query.char_results[global_idx - query.word_boundary]

        word_syllables = pinyin_key.split()
        consumed = min(len(word_syllables), len(state["remaining_syllables"]))
        new_remaining = state["remaining_syllables"][consumed:]
        new_selected = state["selected_chars"] + [word]
        new_resolved = state["resolved_syllables"] + word_syllables[:consumed]

        if not new_remaining:
            return word, ("".join(new_selected), new_resolved), None
        else:
            new_state: CharByCharState = {
                "original_syllables": state["original_syllables"],
                "remaining_syllables": new_remaining,
                "selected_chars": new_selected,
                "resolved_syllables": new_resolved,
                "type": "char_by_char",
            }
            return word, None, new_state

    def segment(self, pinyin: str) -> list[str]:
        """返回音节列表。支持 segment_delimiter 手动分段（与 Querier.query 行为一致）。"""
        return self._querier.parse_segments(pinyin.strip().lower())

    def clear_pending_table(self):
        # 完全忠于realtalk看见的东西
        self._pending_table = Table()

    def commit(self, word: str, syllables: list[str], transient: bool = False) -> None:
        """用户选词后调用，触发学习。

        新词写入 _pending_table（轻量，无需 sort_all 主表），
        同时持久化到用户历史文件。引擎重启时会从历史文件重建到主表。
        """
        assert self._syl_to_id is not None
        if transient:
            # 用户自定义词典和历史记录都由这个实现? 音节 应该是可选?
            # 添加词典, 每次动态更新 _pending_table , 动态更新
            # self._pending_table = Table()
            # 八股文是默认的, 还是也可配置, 缓存机制基于 md5
            freq = 1
        else:
            freq = self._user_dict.commit(word, syllables)  # 文件 I/O
        raw_ids = [self._syl_to_id.get(s) for s in syllables]
        if None not in raw_ids:
            syl_ids = tuple(int(i) for i in raw_ids if i is not None)
            self._pending_table.insert(syl_ids, DictEntry(word=word, score=freq * _USER_WEIGHT_MULTIPLIER))
            self._pending_table.sort_all()

    def lookup(self, pinyin: str, top_n: int = 10, traditional: bool | None = None) -> list[tuple[str, str, int]]:
        """返回 [(候选词, 完整拼音, 词频), ...] 按词频降序"""
        if traditional is None:
            traditional = self.config.get("engine", {}).get("traditional", False)  # ty: ignore
        t0 = time.perf_counter()
        results = self._querier.query(pinyin, top_n)
        t_query = time.perf_counter()

        active = self._filters + [TraditionalFilter()] if traditional else self._filters
        for f in active:
            results = f.apply(results)
        t_total = time.perf_counter()

        logger.debug("lookup %r → %d 候选  query=%.1fms  filter=%.1fms  total=%.1fms", pinyin, len(results), (t_query - t0) * 1000, (t_total - t_query) * 1000, (t_total - t0) * 1000)  # fmt: skip # noqa
        return results

    def candidates(self, pinyin: str, top_n: int = 10, traditional: bool | None = None) -> list[str]:
        """只返回候选词列表"""
        return [word for word, _, _ in self.lookup(pinyin, top_n, traditional=traditional)]

    @classmethod
    def clear_disk_cache(cls) -> Path | None:
        """删除磁盘上的索引缓存文件，返回被删除的路径，若不存在则返回 None"""
        data_dir = Path(__file__).parent / "data"
        dict_path = str(data_dir / "luna_pinyin.dict_simp.yaml")
        essay_path = str(data_dir / "essay_simp.txt")
        cache_path = cls._cache_path(dict_path, essay_path)
        if cache_path.exists():
            cache_path.unlink()
            return cache_path
        return None
