"""
TODO: 清理后的版本, 等macos客户端同步更新再提交

HTTP daemon — 将 pinyinIME 暴露给本地 HTTP 客户端（如 Swift IMKit 应用或 CLI 交互界面）。

设计原则：服务端完全无状态。所有会话进度由客户端携带。

─── 请求（POST /rpc，JSON body）────────────────────────────────────────────

  query        {"method": "query", "params": {"input": "niha", "page": 0, "page_size": 5}}
  commit       {"method": "commit", "params": {"word": "你好", "syllables": ["ni", "hao"]}}
  ping         {"method": "ping"}

─── 响应────────────────────────────────────────────────────────────────────

  query          {"result": {"syllables": ["ni", "ha"],
                  "candidates": [{"word": "你好", "syllables": ["ni", "hao"]}, ...],
                  "total": 20, "max_page": 4, "page": 0}}
  commit         {"result": "ok"}
  ping           {"result": "pong"}
  error          {"error": "..."}

─── query 接口说明（客户端自行维护选词状态）──────────────────────────────────

  query 返回带音节信息的候选列表，使客户端无需依赖服务端计算选词结果：

  客户端选词逻辑（伪代码）：
    selected = candidates[i]
    consumed = min(len(selected.syllables), len(remaining))
    new_remaining = remaining[consumed:]
    if new_remaining is empty:
        call commit(word="".join(selected_chars + [selected.word]),
                    syllables=resolved + selected.syllables[:consumed])
    else:
        call query(remaining=new_remaining)  # 继续 char-by-char

  syllables：服务端对 input 的分词结果，客户端以此初始化 remaining。
  每个 candidate 的 syllables 表示该词消耗的音节，客户端据此推算 new_remaining。
"""

import json
import logging

from bottle import Bottle, request, response

from pinyinIME.engine import PinyinEngine
from pinyinIME.utils import LOG_FORMAT

logger = logging.getLogger(__name__)

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 12358
DEFAULT_PAGE_SIZE = 5

# ---------------------------------------------------------------------------
# Handler (pure function: engine + request → response dict)
# ---------------------------------------------------------------------------


def _handle(engine: PinyinEngine, req: dict) -> dict:
    method = req.get("method", "")
    params = req.get("params", {})
    logger.debug("request: method=%r", method)
    try:
        if method == "query":
            # 返回带音节信息的候选列表，供客户端自行维护选词状态。
            # input：拼音字符串，支持 ' 作为音节分隔符（续选时客户端自行拼接）
            page = int(params.get("page", 0))
            page_size = int(params.get("page_size", DEFAULT_PAGE_SIZE))
            pinyin_str = str(params.get("input", ""))
            result = engine.query(pinyin_str, page, page_size)
            # logger.debug("query: pinyin=%r page=%d -> %d candidates", pinyin_str, page)
            return {"result": result}

        elif method == "commit":
            word = str(params.get("word", ""))
            syllables = [str(s) for s in params.get("syllables", [])]
            engine.commit(word, syllables)
            logger.debug("commit: word=%r syllables=%r", word, syllables)
            return {"result": "ok"}

        elif method == "ping":
            logger.debug("ping -> pong")
            return {"result": "pong"}

        else:
            logger.warning("unknown method: %r", method)
            return {"error": f"unknown method: {method!r}"}

    except Exception as exc:
        logger.exception("error handling method=%r: %s", method, exc)
        return {"error": str(exc)}


# ---------------------------------------------------------------------------
# Bottle app
# ---------------------------------------------------------------------------


def _add_cors_headers() -> None:
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"


def _make_app(engine: PinyinEngine) -> Bottle:
    app = Bottle()

    @app.route("/rpc", method=["POST", "OPTIONS"])
    def rpc() -> str:
        _add_cors_headers()
        if request.method == "OPTIONS":
            return ""
        try:
            req = request.json
            if req is None:
                raise ValueError("missing or invalid JSON body")
        except Exception as exc:
            resp_data: dict = {"error": f"invalid json: {exc}"}
        else:
            resp_data = _handle(engine, req)
        response.content_type = "application/json; charset=utf-8"
        return json.dumps(resp_data, ensure_ascii=False)

    return app


def serve(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, verbose: bool = False) -> None:
    """启动 HTTP daemon，持续监听候选词查询请求。

    默认监听 127.0.0.1:12358，POST /rpc 接收 JSON 请求。
    """
    if verbose:
        pinyin_logger = logging.getLogger("pinyinIME")
        pinyin_logger.setLevel(logging.DEBUG)
        stream_h = logging.StreamHandler()
        stream_h.setFormatter(logging.Formatter(LOG_FORMAT))
        pinyin_logger.addHandler(stream_h)

    logger.info("加载引擎…")
    engine = PinyinEngine.default()

    app = _make_app(engine)
    logger.info("监听: http://%s:%d/rpc", host, port)
    print(f"[pinyinIME server] 监听: http://{host}:{port}/rpc", flush=True)

    try:
        app.run(host=host, port=port, quiet=True)
    except KeyboardInterrupt:
        logger.info("收到 KeyboardInterrupt，退出")
        print("\n[pinyinIME server] 退出", flush=True)


if __name__ == "__main__":
    serve()
