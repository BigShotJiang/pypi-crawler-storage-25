from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TypeAlias, TypedDict


# QueryResult 仅供 engine 内部使用，不出现在持久状态中。
@dataclass(frozen=True)
class QueryResult:
    word_results: tuple[tuple[str, str, int], ...]  # (word, pinyin_key, score)
    char_results: tuple[tuple[str, str, int], ...]  # 首字单字
    word_boundary: int
    syllables: tuple[str, ...]


def candidates(query: QueryResult) -> tuple[str, ...]:
    return tuple(w for w, _, _ in query.word_results) + tuple(w for w, _, _ in query.char_results)


# ---------------------------------------------------------------------------
# 唯一的持久状态：char-by-char 模式下累积的选词进度。
# page 不在 state 中——它是纯 UI 导航，由客户端单独维护。
# TypedDict — runtime 即 dict，可直接 json.dumps，无需序列化转换。
# ---------------------------------------------------------------------------


class CharByCharState(TypedDict):
    original_syllables: list[str]
    remaining_syllables: list[str]  # 用于重建查询
    selected_chars: list[str]
    resolved_syllables: list[str]
    type: str  # = "char_by_char"


def current_page(all_candidates: Sequence[str], page: int, page_size: int) -> list[str]:
    start = page * page_size
    return list(all_candidates[start : start + page_size])


# select 的返回类型
CommitInfo: TypeAlias = "tuple[str, list[str]]"  # (word, syllables)
SelectResult: TypeAlias = "tuple[str, CommitInfo | None, CharByCharState | None]"
