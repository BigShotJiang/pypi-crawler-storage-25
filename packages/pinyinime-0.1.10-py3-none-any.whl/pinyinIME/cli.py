"""
Console script for pinyinIME.

uv run pinyinIME --verbose lookup nihao
uv run pinyinIME --verbose lookup "xi'an"
uv run pinyinIME --verbose serve
uv run --with rich pinyinIME --verbose interactive
"""

import argparse
import logging
import sys

from pinyinIME.engine import PinyinEngine
from pinyinIME.utils import LOG_FORMAT

logger = logging.getLogger(__name__)


def lookup(args: argparse.Namespace) -> None:
    """查询拼音对应的汉字候选，输出 词语\t拼音\t词频"""
    logger.debug("lookup: pinyin=%r top=%d", args.pinyin, args.top)
    engine = PinyinEngine.default()
    results = engine.lookup(args.pinyin, top_n=args.top)
    logger.debug("lookup: got %d results", len(results))
    for word, full_pinyin, freq in results:
        print(f"{word}\t{full_pinyin}\t{freq}")


def serve(args: argparse.Namespace) -> None:
    """启动 HTTP daemon，对外暴露候选词查询服务（供 Swift IMKit 或 interactive.py 调用）"""
    from pinyinIME.server import serve as _serve

    _serve(host=args.host, port=args.port, verbose=args.verbose)


def interactive(args: argparse.Namespace) -> None:
    """交互式拼音输入（终端 UI，连接本地 HTTP 服务器）"""
    from pinyinIME.interactive import main as _main

    _main(server_url=args.url)


def playground(_args: argparse.Namespace) -> None:
    """在浏览器中打开调试页面（需先运行 serve）"""
    import importlib.resources
    import webbrowser

    pkg_files = importlib.resources.files("pinyinIME")
    html_path = pkg_files / "data" / "playground.html"
    with importlib.resources.as_file(html_path) as p:
        webbrowser.open(p.as_uri())


def clear_cache(args: argparse.Namespace) -> None:
    """清除磁盘索引缓存，下次启动时重新构建"""
    removed = PinyinEngine.clear_disk_cache()
    if removed:
        print(f"已删除缓存: {removed}")
    else:
        print("无缓存文件，无需清除")


def app() -> None:
    parser = argparse.ArgumentParser(
        prog="pinyinIME",
        description="pinyinIME - Pinyin Input Method Engine",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="启用 DEBUG 日志输出",
    )
    subparsers = parser.add_subparsers(dest="command")

    # lookup
    p_lookup = subparsers.add_parser("lookup", help="查询拼音对应的汉字候选，输出 词语\t拼音\t词频")
    p_lookup.add_argument(
        "pinyin", help="拼音输入，支持缩写（如 'nh' 匹配 '你好'）；可用 ' 手动分隔音节（如 \"xi'an\" 匹配 '西安'）"
    )
    p_lookup.add_argument("--top", type=int, default=10, help="最多返回候选数")
    p_lookup.set_defaults(func=lookup)

    # serve
    p_serve = subparsers.add_parser("serve", help="启动 HTTP daemon，对外暴露候选词查询服务")
    p_serve.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    p_serve.add_argument("--port", type=int, default=12358, help="监听端口（默认 12358）")
    p_serve.set_defaults(func=serve)

    # interactive
    p_interactive = subparsers.add_parser("interactive", help="启动交互式终端拼音输入 UI（需先运行 serve）")
    p_interactive.add_argument("--url", default=None, help="服务器地址（默认 http://127.0.0.1:12358/rpc）")
    p_interactive.set_defaults(func=interactive)

    # playground
    p_playground = subparsers.add_parser("playground", help="在浏览器中打开调试页面（需先运行 serve）")
    p_playground.set_defaults(func=playground)

    # clear-cache
    p_clear = subparsers.add_parser("clear-cache", help="清除磁盘索引缓存，下次启动时重新构建")
    p_clear.set_defaults(func=clear_cache)

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.verbose and args.command != "serve":
        # 在 engine _setup_logging 之前设置日志机制， 否则 _setup_logging 会默认使用 INFO level
        pinyin_logger = logging.getLogger("pinyinIME")
        pinyin_logger.setLevel(logging.DEBUG)
        if args.command == "interactive":
            # 交互模式下终端被 UI 占用，日志写到文件避免破坏显示
            from pinyinIME.userdata.user_paths import LOG_DEBUG, ensure_user_dir

            ensure_user_dir()
            handler: logging.Handler = logging.FileHandler(LOG_DEBUG, encoding="utf-8")
        else:
            handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(LOG_FORMAT))
        pinyin_logger.addHandler(handler)

    args.func(args)
