import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_CONFIG_HOME = Path(os.environ.get("PINYIN_CONFIG_HOME", Path.home() / ".config"))
USER_DIR = _CONFIG_HOME / "pinyinIME"

CONFIG_JSON = USER_DIR / "config.json"
USER_DICT_DB = USER_DIR / "pinyin.userdb"
CUSTOM_PHRASE = USER_DIR / "custom_phrase.txt"
EMOJI_BUILTIN = Path(__file__).parent.parent / "data" / "emoji_word.simp.txt"
LOG_DIR = USER_DIR / "log"
LOG_ERROR = LOG_DIR / "error.log"
LOG_INFO = LOG_DIR / "info.log"
LOG_DEBUG = LOG_DIR / "debug.log"

_DEFAULT_CONFIG: dict[str, Any] = {
    "engine": {
        "segment_delimiter": "'",
        "top_n": 10,
        "max_abbrev_fanout": 10,
        "search_timeout": 0.5,
        "traditional": False,
    },
    "log": {
        "level": "INFO",
    },
}

_DEFAULT_CUSTOM_PHRASE = """\
# 每行一个词条，格式：词[, 音节][, 权重]（后两项可选）
一丹中心
阅读场
π, pi, 100

艾伦·凯, ai lun kai
动态媒介
"""


def load_config() -> dict[str, Any]:
    """读取 config.json，若不存在则返回空 dict。"""
    if not CONFIG_JSON.exists():
        return {}
    try:
        return json.loads(CONFIG_JSON.read_text(encoding="utf-8"))
    except Exception:
        logger.error("读取 %s 失败，使用默认配置", CONFIG_JSON, exc_info=True)
        return {}


def ensure_user_dir() -> None:
    """确保用户目录及默认文件存在（幂等）。"""
    USER_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(exist_ok=True)

    if not CONFIG_JSON.exists():
        CONFIG_JSON.write_text(json.dumps(_DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")

    if not CUSTOM_PHRASE.exists():
        CUSTOM_PHRASE.write_text(_DEFAULT_CUSTOM_PHRASE, encoding="utf-8")
