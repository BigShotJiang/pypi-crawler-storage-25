from pinyinIME.userdata.user_history import UserHistory

__all__ = ["UserHistory"]
