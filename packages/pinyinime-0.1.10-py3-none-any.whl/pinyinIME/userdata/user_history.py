import logging
from collections import Counter
from pathlib import Path

from pinyinIME.userdata.user_paths import USER_DICT_DB

_SEP = ", "


class UserHistory:
    def __init__(self, log_path: Path | None = None):
        self._path = log_path or USER_DICT_DB
        self._path.parent.mkdir(parents=True, exist_ok=True)

        self._logger = logging.getLogger(f"pinyinIME.userdict.{id(self)}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        handler = logging.FileHandler(self._path, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(message)s"))
        self._handler = handler
        self._logger.addHandler(handler)

        # 内存计数器，启动时从文件恢复，commit() 时同步更新
        self._counter: Counter[tuple[str, str]] = Counter()
        if self._path.exists():
            for line in self._path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                parts = line.split(_SEP, 1)
                if len(parts) == 2:
                    self._counter[(parts[0], parts[1])] += 1

    def commit(self, word: str, syllables: list[str]) -> int:
        """记录用户选词，每次选词追加一行，返回该词累计选词次数。"""
        key = (word, " ".join(syllables))
        self._counter[key] += 1
        self._logger.info("%s%s%s", word, _SEP, key[1])
        return self._counter[key]

    def get_entries(self) -> list[tuple[str, list[str], int]]:
        """返回 [(word, syllables_list, freq), ...]，按 freq 降序。"""
        return [(word, sylls.split(" "), freq) for (word, sylls), freq in self._counter.most_common()]

    def close(self) -> None:
        self._handler.flush()
        self._handler.close()
        self._logger.removeHandler(self._handler)
