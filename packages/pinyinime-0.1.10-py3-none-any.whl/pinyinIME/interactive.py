"""
交互式拼音输入工具（HTTP 客户端模式）。

用法：
    uv run --with bottle pinyinIME serve         # 先启动服务器
    uv run --with rich pinyinIME interactive  # 再启动交互界面

数字键选词 | [ ] 翻页 | Backspace 删除 | Space 选第1个 | Enter 上屏原始 | ESC 清空输入 | ' 音节分隔 | Ctrl+C 退出

不用方向键: 在命令行里会导致麻烦问题
"""

import json
import logging
import sys
import termios
import tty
import urllib.error
import urllib.request
from typing import Any

from rich.console import Console
from rich.text import Text

from pinyinIME.server import DEFAULT_HOST, DEFAULT_PAGE_SIZE, DEFAULT_PORT

logger = logging.getLogger(__name__)

segment_delimiter = "'"
# punctuation
_PUNCT: set[str] = set(',.!?;:"~`@#$%^&*-+=<>[]{}/\\|，。！？；：、…—·\u201c\u201d\u2018\u2019（）【】《》')
assert segment_delimiter not in _PUNCT


class IMEClient:
    """通过 HTTP 与 pinyinIME 服务器通信的客户端。

    选词状态完全由客户端维护：
      - _remaining: 剩余待选音节列表
      - _selected_chars: 已选字符（char-by-char 模式）
      - _resolved_syllables: 已消耗的音节（用于最终 commit）
    服务端只提供 query（候选查询）和 commit（写入用户历史）。
    """

    def __init__(self, url: str, page_size: int = DEFAULT_PAGE_SIZE) -> None:
        self._url = url
        self._page_size = page_size
        self.mode: str = "normal"
        self.page: int = 0
        self.max_page: int = 0
        self._input: str = ""  # char-by-char 模式下剩余音节的显示字符串

        # 当前页候选（含音节信息），供 select() 查询
        self._page_candidates: list[dict[str, Any]] = []

        # 客户端选词状态
        self._remaining: list[str] = []       # 剩余音节
        self._selected_chars: list[str] = []   # 已选字符
        self._resolved_syllables: list[str] = []  # 已消耗音节

        # 上次查询的拼音串（用于翻页时重新 query）
        self._last_input: str = ""

    def _call(self, method: str, params: dict[str, Any] | None = None) -> Any:
        req_body: dict[str, Any] = {"method": method}
        if params:
            req_body["params"] = params
        data = json.dumps(req_body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self._url, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            result: dict[str, Any] = json.loads(resp.read())
        if "error" in result:
            raise RuntimeError(result["error"])
        return result["result"]

    def _do_query(self, params: dict[str, Any]) -> list[str]:
        """调用 query 接口，更新分页状态，返回当前页词列表。"""
        r: dict[str, Any] = self._call("query", params)
        self.max_page = r["max_page"]
        self._page_candidates = r["candidates"]
        return [c["word"] for c in r["candidates"]]

    def set_input(self, pinyin: str) -> list[str]:
        self._last_input = pinyin
        self._remaining = []
        self._selected_chars = []
        self._resolved_syllables = []
        self.mode = "normal"
        self._input = ""
        if not pinyin:
            self.page = 0
            self.max_page = 0
            self._page_candidates = []
            return []
        r: dict[str, Any] = self._call("query", {"input": pinyin, "page": 0, "page_size": self._page_size})
        self.max_page = r["max_page"]
        self._page_candidates = r["candidates"]
        self._remaining = r["syllables"]
        return [c["word"] for c in r["candidates"]]

    def _current_input(self) -> str:
        """当前查询输入：cbc 模式下为剩余音节拼接，否则为原始输入串。"""
        return self._input if self.mode == "char_by_char" else self._last_input

    def next_page(self) -> list[str]:
        self.page = self.page + 1
        return self._do_query({"input": self._current_input(), "page": self.page, "page_size": self._page_size})

    def prev_page(self) -> list[str]:
        self.page = self.page - 1
        return self._do_query({"input": self._current_input(), "page": max(0, self.page), "page_size": self._page_size})

    def show_states(self):
        print(self._remaining)
        print(self._selected_chars)
        print(self._resolved_syllables)

    def select(self, index: int, pinyin_input: str = "") -> tuple[str, list[str]]:
        """选词。返回 (word, candidates)，并更新 self.mode / self.page / self._input。"""

        self.show_states()
        candidate = self._page_candidates[index]
        word: str = candidate["word"]
        cand_syllables: list[str] = candidate["syllables"]

        consumed = min(len(cand_syllables), len(self._remaining))
        self._remaining = self._remaining[consumed:]
        self._selected_chars.append(word)
        self._resolved_syllables.extend(cand_syllables[:consumed])

        if not self._remaining:
            # 已选完所有音节：提交并重置
            full_word = "".join(self._selected_chars)
            self._call("commit", {"word": full_word, "syllables": self._resolved_syllables})
            self.mode = "normal"
            self._selected_chars = []
            self._resolved_syllables = []
            self._input = ""
            self.show_states()
            return word, []
        else:
            # 还有剩余音节：进入 / 继续 char-by-char 模式
            self.mode = "char_by_char"
            self._input = "'".join(self._remaining)
            words = self._do_query({"input": self._input, "page": 0, "page_size": self._page_size})
            self.show_states()
            return word, words

    def cancel(self) -> None:
        """取消当前选词流程（无需服务端调用，纯本地重置）。"""
        self.mode = "normal"
        self._remaining = []
        self._selected_chars = []
        self._resolved_syllables = []
        self._input = ""


def _getch() -> str:
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        return sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _render(
    console: Console,
    committed: str,
    pinyin_input: str,
    candidates: list[str],
    page: int,
    prev_lines: int,
    char_by_char: bool,
) -> int:
    if prev_lines > 0:
        sys.stdout.write(f"\x1b[{prev_lines}A\x1b[J")
        sys.stdout.flush()

    lines = 0

    input_text = Text()
    if committed:
        input_text.append(committed, style="bold green")
    if char_by_char:
        input_text.append(f"[{pinyin_input}]", style="bold magenta")
    else:
        input_text.append(pinyin_input, style="bold cyan")
    input_text.append("▌", style="dim")
    console.print(Text.assemble("输入: ", input_text), end="\n")
    lines += 1

    if candidates:
        cand_text = Text()
        for i, word in enumerate(candidates, 1):
            cand_text.append(f"[{i}]", style="bold yellow")
            cand_text.append(word, style="white")
            cand_text.append("  ")
        cand_text.append(f"  第{page + 1}页  ", style="dim")
        cand_text.append("[ ]", style="bold blue")
        cand_text.append(" 翻页", style="dim")
        if char_by_char:
            cand_text.append("  [逐字]", style="bold magenta")
        console.print(cand_text, end="\n")
        lines += 1
    elif pinyin_input:
        console.print("[dim](无候选)[/dim]", end="\n")
        lines += 1

    return lines


def _do_select(idx: int, pinyin_input: str, committed: str, client: IMEClient) -> tuple[str, str, list[str]]:
    """执行选词，返回 (pinyin_input, committed, candidates)。"""
    word, candidates = client.select(idx, pinyin_input)
    committed += word

    if client.mode == "char_by_char":
        pinyin_input = client._input
    else:
        pinyin_input = ""
        candidates = []

    return pinyin_input, committed, candidates


def main(server_url: str | None = None) -> None:
    url = server_url or f"http://{DEFAULT_HOST}:{DEFAULT_PORT}/rpc"
    console = Console()

    client = IMEClient(url)
    try:
        client._call("ping")
    except urllib.error.URLError:
        console.print(f"[red]无法连接到 pinyinIME 服务器: {url}[/red]")
        console.print("[dim]请先运行: pinyinIME serve[/dim]")
        return

    console.print("[bold]就绪！[/bold] 输入拼音查询候选词")
    console.print(
        f"[dim]数字键选词 | [ ] 翻页 | Backspace 删除 | Space 选第1个 | Enter 上屏原始 | ESC 清空输入 | {segment_delimiter!r} 音节分隔 | Ctrl+C 退出[/dim]"  # noqa: E501
    )
    console.print()

    pinyin_input = ""  # 当前未提交的拼音输入缓冲区
    committed = ""  # 已上屏的文字（显示在输入行左侧）
    candidates: list[str] = []  # 当前候选词列表

    prev_lines = 0  # 上一次渲染占用的终端行数，用于清屏重绘

    logger.info("session start")
    try:
        prev_lines = _render(console, committed, pinyin_input, candidates, client.page, prev_lines, False)
        while True:
            ch = _getch()
            logger.debug("key: %r  pinyin_input=%r  committed=%r", ch, pinyin_input, committed)

            if ch.isprintable() and ch not in "0123456789[] ":
                # 输入音节
                if client.mode == "char_by_char":
                    pass
                else:
                    pinyin_input += ch
                    candidates = client.set_input(pinyin_input)
                    logger.debug("input: pinyin_input=%r  candidates=%d", pinyin_input, len(candidates))
            elif ch == "]":  # 下一页
                if pinyin_input and candidates:
                    candidates = client.next_page()
                    logger.debug("next page: pinyin_input=%r  page=%d", pinyin_input, client.page)
            elif ch == "[":  # 上一页
                if pinyin_input:
                    candidates = client.prev_page()
                    logger.debug("prev page: pinyin_input=%r  page=%d", pinyin_input, client.page)
            elif ch in "123456789":
                # 选词
                idx = int(ch) - 1
                if 0 <= idx < len(candidates):
                    logger.info("select[%d]: pinyin_input=%r", idx, pinyin_input)
                    pinyin_input, committed, candidates = _do_select(idx, pinyin_input, committed, client)
            elif ch in ("\r", "\n"):  # Enter 通常发送 \r，\n 是兼容写法
                # 与 Swift 一致： Enter 不选候选词，仅上屏原始拼音
                if client.mode == "char_by_char":
                    pass  # 逐字模式忽略
                elif pinyin_input:
                    logger.debug("commit raw: pinyin_input=%r", pinyin_input)
                    committed += pinyin_input
                    pinyin_input = ""
                    candidates = client.set_input("")
            elif ch == " ":
                # 与 Swift 一致：有候选词时选词（不追加空格）；无候选词时上屏原始拼音（不追加空格）；
                # 缓冲区为空时透传空格
                if candidates:
                    logger.info("select[space]: pinyin_input=%r", pinyin_input)
                    pinyin_input, committed, candidates = _do_select(0, pinyin_input, committed, client)
                elif client.mode == "char_by_char":
                    pass  # 逐字模式忽略
                elif pinyin_input:
                    logger.debug("commit raw: pinyin_input=%r", pinyin_input)
                    committed += pinyin_input
                    pinyin_input = ""
                    candidates = client.set_input("")
                else:
                    committed += ch  # 缓冲区为空，透传空格
            elif ch in _PUNCT:
                if candidates:
                    logger.info("select[punct=%r]: pinyin_input=%r", ch, pinyin_input)
                    pinyin_input, committed, candidates = _do_select(0, pinyin_input, committed, client)
                elif pinyin_input:
                    logger.debug("commit raw+punct: pinyin_input=%r  punct=%r", pinyin_input, ch)
                    committed += pinyin_input
                    pinyin_input = ""
                    candidates = client.set_input("")
                if client.mode == "normal":
                    committed += ch

            elif ch == "\x03":  # Ctrl+C
                break
            elif ch == "\x1b":  # ESC
                if client.mode == "char_by_char":
                    client.cancel()
                    pinyin_input = ""
                    candidates = []
                    logger.debug("cancel char_by_char via ESC")
                elif pinyin_input:
                    logger.debug("clear input: pinyin_input=%r", pinyin_input)
                    pinyin_input = ""
                    candidates = client.set_input("")
            elif ch == "\x7f":  # Backspace
                if client.mode == "char_by_char":
                    client.cancel()
                    pinyin_input = ""
                    candidates = []
                    logger.debug("cancel char_by_char via Backspace")
                elif pinyin_input:
                    pinyin_input = pinyin_input[:-1]
                    candidates = client.set_input(pinyin_input)
                elif committed:
                    committed = committed[:-1]

            prev_lines = _render(
                console,
                committed,
                pinyin_input,
                candidates,
                client.page,
                prev_lines,
                client.mode == "char_by_char",
            )

    except (KeyboardInterrupt, EOFError):
        pass

    logger.info("session end: committed=%r", committed)
    sys.stdout.write(f"\x1b[{prev_lines}A\x1b[J")
    sys.stdout.flush()
    if committed or pinyin_input:
        console.print(f"[bold]输入完成:[/bold] {committed}{pinyin_input}")
    console.print("[dim]再见！[/dim]")


if __name__ == "__main__":
    main()
