import math
from enum import Enum

# 标准普通话声母，按长度降序排列确保双字母声母优先匹配
INITIALS: list[str] = ['zh', 'ch', 'sh', 'b', 'p', 'm', 'f', 'd', 't', 'n', 'l', 'g', 'k', 'h', 'j', 'q', 'x', 'z', 'c', 's', 'r', 'y', 'w']  # fmt: skip # noqa

# 标准普通话韵母，按长度降序排列
FINALS: list[str] = ['iang', 'iong', 'uang', 'ueng', 'ian', 'iao', 'ing', 'ong', 'ang', 'eng', 'uai', 'uan', 'ia', 'ie', 'in', 'iu', 'an', 'en', 'ao', 'ou', 'ai', 'ei', 'ui', 'un', 'ua', 'uo', 'ue', 'a', 'o', 'e', 'i', 'u', 'v']  # fmt: skip # noqa


class SpellingType(Enum):
    NORMAL = 0  # 完整音节
    ABBREVIATION = 1  # 声母缩写


SPELLING_PENALTY: dict[SpellingType, float] = {
    SpellingType.NORMAL: 0.0,
    SpellingType.ABBREVIATION: math.log(0.1),  # ≈ -2.303
}
