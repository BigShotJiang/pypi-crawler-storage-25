import logging
import math
import time
from itertools import islice

from pinyinIME.index.prism import Prism
from pinyinIME.index.table import Table
from pinyinIME.pipeline.segmentor import SegmentationStrategy
from pinyinIME.pipeline.types import SPELLING_PENALTY, SpellingType
from pinyinIME.utils import SearchSegmentsTimeoutError

logger = logging.getLogger(__name__)


class Querier:
    """查询器：将用户输入的拼音字符串转换为候选词列表。

    工作流程：
    1. 对输入字符串构建音节 DAG（SyllableGraph）
    2. DFS 枚举 DAG 中所有路径，每条路径对应一种拼音分段方案
    3. 在 Prism（拼写→音节ID）+ Table（音节ID序列→词条）上查找匹配词
    4. 按调整后的得分（对数词频 + 拼写惩罚）排序返回 top_n 候选
    """

    def __init__(
        self,
        prism: Prism,
        table: Table,
        strategy: SegmentationStrategy,
        config: dict[str, object],
        pending_table: Table | None = None,
    ):
        self._prism = prism
        self._table = table
        self._pending_table = pending_table
        self._strategy: SegmentationStrategy = strategy
        # type-check 动态推断写起来非常啰嗦
        self._segment_delimiter = config.get("engine", {}).get("segment_delimiter", "'")  # ty: ignore
        self._search_timeout: float = float(config.get("engine", {}).get("search_timeout", 0.5))  # ty: ignore
        logger.info("[config] segment_delimiter=%r", self._segment_delimiter)
        logger.info("[config] search_timeout=%r", self._search_timeout)

    def _search_segments(
        self,
        segments: list[str],
        top_n: int,
    ) -> list[tuple[str, str, int]]:
        """在 Prism+Table 上搜索一条 DAG 路径，返回 (word, key, adjusted_score)。

        采用递归回溯（DFS）枚举各段的音节 ID 组合：
        - 每个 segment(切割的输入， 完整长度) 在 Prism 中做匹配(完整音节+声母)，得到若干 (syllable_id, SpellingType)
        - 拼接所有段的 ID 序列后，在 Table 中查找对应词条 （要求完全匹配）
        - 同一个词保留得分最高的 key（拼音展开形式）

        seen: word → (key, best_adjusted_score)，用于对同一词去重取最优
        timeout: 超时秒数（默认 0.5s），超时后提前终止搜索并返回已收集的结果
        """
        n = len(segments)
        seen: dict[str, tuple[str, int]] = {}
        deadline = time.perf_counter() + self._search_timeout

        def collect(depth: int, id_path: list[int], stype_path: list[SpellingType], key_parts: list[str]):
            if time.perf_counter() >= deadline:
                logger.warning("search_segments timeout after %.3fs: segments=%r", self._search_timeout, segments)
                raise SearchSegmentsTimeoutError(segments, self._search_timeout)
            if depth == n:
                # 已收集完所有段的音节 ID，查 Table（主表 + overlay 表）
                syl_ids = tuple(id_path)
                entries = self._table.search(syl_ids)
                if self._pending_table is not None:
                    overlay_entries = self._pending_table.search(syl_ids)
                    if overlay_entries:
                        entries = list(entries) + list(overlay_entries) if entries else overlay_entries
                if not entries:
                    return
                key = " ".join(key_parts)
                penalty = sum(SPELLING_PENALTY[st] for st in stype_path)
                for entry in islice(entries, top_n):
                    adjusted = round((math.log(max(entry.score, 1)) + penalty) * 1_000_000)
                    # 同一词保留得分更高的候选
                    if entry.word not in seen or seen[entry.word][1] < adjusted:
                        seen[entry.word] = (key, adjusted)
                return

            seg = segments[depth]
            matches = self._prism.search(seg)  # 完整音节/声母 匹配
            if not matches:
                return

            for sid, stype in matches:  # 同一层， 展开的各种可能性
                syl = self._prism.syllable(sid)
                id_path.append(sid)
                # Trie 前缀剪枝：当前路径在任一 Table 中无前缀则整棵子树必然为空，直接跳过
                has_match = self._table.has_prefix(id_path)
                if not has_match and self._pending_table is not None:
                    has_match = self._pending_table.has_prefix(id_path)
                if not has_match:
                    id_path.pop()
                    continue
                stype_path.append(stype)
                key_parts.append(syl)
                collect(depth + 1, id_path, stype_path, key_parts)
                # 回溯
                id_path.pop()
                stype_path.pop()
                key_parts.pop()

        collect(0, [], [], [])

        return [(word, info[0], info[1]) for word, info in seen.items()]

    def parse_segments(self, raw: str) -> list[str]:
        """将原始拼音字符串解析为音节列表。

        若含 segment_delimiter，按 delimiter 拆分后对每段取 FMM 首选路径展平；
        否则直接取整串的 FMM 首选路径。
        """
        if self._segment_delimiter in raw:
            result: list[str] = []
            for part in raw.split(self._segment_delimiter):
                segs = self._strategy.get_segment_lists(part)
                if segs:
                    result.extend(segs[0])
            return result
        segs = self._strategy.get_segment_lists(raw)
        return segs[0] if segs else []

    def _collect_with_strategy(self, raw: str, top_n: int) -> list[tuple[str, str, int]]:
        """通过分词策略获取候选分段方案，逐一查词后合并结果。

        策略（self._strategy）负责将原始字符串转换为若干分段方案（每个方案是音节列表）；
        本方法对每个方案调用 _search_segments，合并去重后按分数降序返回 top_n 结果。
        """
        seen: dict[str, tuple[str, int]] = {}
        segment_lists = self._strategy.get_segment_lists(raw)
        logger.debug("segment_lists=%r", segment_lists)
        for segments in segment_lists:
            try:
                for word, key, score in self._search_segments(segments, top_n):
                    if word not in seen or seen[word][1] < score:
                        seen[word] = (key, score)
            except SearchSegmentsTimeoutError:
                pass
            if len(seen) > top_n * 20:
                break
        return sorted(
            [(word, info[0], info[1]) for word, info in seen.items()],
            key=lambda x: -x[2],
        )[:top_n]

    def query(self, user_input: str, top_n: int = 10) -> list[tuple[str, str, int]]:
        """对外接口：返回 (word, pinyin_key, score) 列表，按得分降序。

        - 若输入含 segment_delimiter（默认 '），视为已手动分段，直接调用 _search_segments（跳过策略）
        - 否则委托给分词策略（默认 FmmStrategy）生成分段方案后查词
        """
        raw = user_input.strip().lower()
        logger.debug("query raw =%r", raw)
        if not raw:
            return []
        if self._segment_delimiter in raw:
            segments = self.parse_segments(raw)
            results = self._search_segments(segments, top_n)
            return sorted(results, key=lambda x: -x[2])[:top_n]
        return self._collect_with_strategy(raw, top_n)
