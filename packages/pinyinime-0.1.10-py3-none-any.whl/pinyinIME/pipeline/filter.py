from typing import Protocol

Entry = tuple[str, str, int]  # (word, pinyin_key, score)


class Filter(Protocol):
    def apply(self, results: list[Entry]) -> list[Entry]: ...


class TraditionalFilter:
    """简→繁转换（需要 opencc 包）"""

    def __init__(self) -> None:
        try:
            import opencc  # type: ignore[import]

            self._converter = opencc.OpenCC("s2t")
        except ImportError:
            raise ImportError(
                "TraditionalFilter requires opencc. Install it manually:\n  pip install opencc\n  # or: uv add opencc\n"
            ) from None

    def apply(self, results: list[Entry]) -> list[Entry]:
        return [(self._converter.convert(word), py, score) for word, py, score in results]


class DeduplicateFilter:
    """去重，保留最高分"""

    def apply(self, results: list[Entry]) -> list[Entry]:
        seen: dict[str, tuple[str, int]] = {}
        for word, py, score in results:
            if word not in seen or seen[word][1] < score:
                seen[word] = (py, score)
        return sorted(
            [(word, info[0], info[1]) for word, info in seen.items()],
            key=lambda x: -x[2],
        )
