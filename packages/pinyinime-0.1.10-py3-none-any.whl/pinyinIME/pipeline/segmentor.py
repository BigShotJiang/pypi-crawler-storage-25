"""拼音分词模块。

定义 SegmentationStrategy Protocol 及默认实现：
- FmmStrategy: 前向最大匹配（Forward Maximum Matching），O(n×6)，默认策略

未来可新增 ViterbiStrategy、BeamSearchStrategy 等替换此处任一实现，
只需实现 get_segment_lists(raw) -> list[list[str]] 即可接入 Querier。

已弃用策略见 segmentor.deprecated.py。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

from pinyinIME.pipeline.types import INITIALS

if TYPE_CHECKING:
    from pinyinIME.index.prism import Prism


@runtime_checkable
class SegmentationStrategy(Protocol):
    """分词策略协议。

    将原始拼音字符串转换为若干候选分段方案，每种方案是音节字符串列表。
    Querier 对每种方案调用 _search_segments 查词，合并结果。
    """

    def get_segment_lists(self, raw: str) -> list[list[str]]:
        """返回候选分段方案列表。

        每个方案是一个音节字符串列表，如 ["ma", "dao", "cheng", "gong"]。
        允许返回多个方案（如 DAG 枚举多路径），也可只返回一个（如 FMM）。
        """
        ...


class FmmStrategy:
    """前向最大匹配策略（Forward Maximum Matching）。

    从左到右贪婪匹配最长有效音节，O(n×6)。
    只产生一条分割路径，速度极快。

    适合场景：连续拼音输入（如 "madaochenggong"），即输入法的主路径。
    局限：无法处理所有歧义（如 "xian" 可能被切为 "xi"+"an" 而非 "xian"），
          但对常见四声汉语拼音音节，FMM 准确率很高。
    """

    def __init__(self, prism: Prism) -> None:
        self._syllables = prism.syllables_set()

    def get_segment_lists(self, raw: str) -> list[list[str]]:
        """返回唯一一条贪婪分割路径，包含在单元素列表中。"""
        segments: list[str] = []
        i = 0
        while i < len(raw):
            matched: str | None = None
            # 从最长（6）到最短（1）尝试完整音节
            for length in range(min(6, len(raw) - i), 0, -1):
                seg = raw[i : i + length]
                if seg in self._syllables:
                    matched = seg
                    break
            if matched:
                segments.append(matched)
                i += len(matched)
            elif raw[i] in INITIALS:
                # 无完整音节匹配，降级为单声母（最后段常见：用户还在输入）
                segments.append(raw[i])
                i += 1
            else:
                # 无法识别的字符，跳过（不产生空段）
                i += 1
        return [segments] if segments else []
