#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import os
import sys
import time
import traceback
from typing import Any, List

from AnyQt.QtCore import QThread, pyqtSignal, QObject, QEventLoop, QMutex, QWaitCondition

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration, AutoAlignmentPlan, AutoAlignmentStage
from aps.common.logger import get_registered_logger_instance, LoggerColor
from aps.common.scripts.script_data import ScriptData
from aps.common.singleton import synchronized_method
from aps.common.io.printout import date_now_str, time_now_str
from aps.common.widgets.stream_proxy import StreamProxy

from aps.beamline_driver.motion_management.facade import Movement, MotorsInfo, MotorInfo, MethodCallingType, IMotionManager
from aps.beamline_driver.beam_management.beam_manager_factory import create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import create_motion_manager

from aps.ai.beamline_controller.common.legacy_keys import Keys
from aps.ai.beamline_controller.common.bluesky_utility import create_run_engine

from aps.ai.beamline_controller.agent.facade import Fidelity
from aps.ai.beamline_controller.agent.agent_listener_factory import create_agent_listener, initialize_agent_listener_factory, IAgentListener
from aps.ai.beamline_controller.agent.optimization.optimization_listener_decorator import OptimizationListenerDecorator
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, WarmStartDataType, WarmStartStrategy, OptimizationResultItem, OptimizationType
from aps.ai.beamline_controller.agent.optimization.optimizer_factory import create_optimizer
from aps.ai.beamline_controller.agent.optimization.hypervolume_manager_factory import create_hypervolume_manager
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationExecutionParameters, MOBOBayesianOptimizationInputParameters, SelectionAlgorithm
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.facade import NonLinearOptimizationExecutionParameters, NonLinearOptimizationInputParameters
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.scipy.optimizer import ScipyOptimizationModel
from aps.ai.beamline_controller.agent.optimization.soo.bayesian.facade import SOBOBayesianOptimizationExecutionParameters, SOBOBayesianOptimizationInputParameters
from aps.ai.beamline_controller.agent.machine_learning.neural_networks.tandem_neural_network import TandemNeuralNetwork, NeuralNetworkParameters
from aps.ai.beamline_controller.agent.machine_learning.neural_networks.neural_network_manager_factory import create_neural_network_manager

from aps.ai.beamline_controller.execution.configuration_manager import AbstractConfigurationManager

f1 = "%m/%d/%Y"
f2 = "%H:%M:%S"

class IExecutionManager():
    # START OPTIMIZATION
    def start_ai_agent(self, platform, plan_id, **kwargs): raise NotImplementedError() # generator
    def notify_agent_pause_released(self): raise NotImplementedError()
    # GET RESULTS AFTER OPTIMIZATION
    def get_current_result(self): raise NotImplementedError()
    def get_trial(self, trial_index, platform, plan_id, stage_id): raise NotImplementedError()
    def get_pareto_trial_number(self, pareto_selection, platform, plan_id, stage_id): raise NotImplementedError()
    def get_optimization_history(self): raise NotImplementedError()
    # PRE/POST-OPTIMIZATION ACTIONS
    def move_motors_to_trial_data(self, trial_data: OptimizationResultItem): raise NotImplementedError()                                                 # generator

class AbstractExecutionManager(AbstractConfigurationManager, IExecutionManager, IAgentListener):

    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, run_as_generator=False, **kwargs):
        super(AbstractExecutionManager, self).__init__(application_name, working_directory, optical_system_id, **kwargs)

        self._run_as_generator  = run_as_generator

        if run_as_generator:
            setattr(self, "start_ai_agent",            self.__start_ai_agent_generator)
            setattr(self, "move_motors_to_trial_data", self.__move_motors_to_trial_data_generator)
            setattr(self, "_start_ai_plan",            self.__start_ai_plan_generator)
        else:
            setattr(self, "start_ai_agent",            self.__start_ai_agent)
            setattr(self, "move_motors_to_trial_data", self.__move_motors_to_trial_data)
            setattr(self, "_start_ai_plan",            self.__start_ai_plan)

        self.__current_ai_process = None
        self.__current_ai_agent   = None
        self.__current_ai_input   = None
        self.__current_ai_result  = None
        self._current_ai_runner = None

    @abc.abstractmethod
    def abort(self): raise NotImplementedError
    @abc.abstractmethod
    def _create_ai_process(self, platform, plan_id, stage_id): raise NotImplementedError
    @abc.abstractmethod
    def _create_ai_plan_runner(self, plan_list: list): raise NotImplementedError
    @abc.abstractmethod
    def _connect_ai_process_handlers(self, ai_process): raise NotImplementedError
    @abc.abstractmethod
    def _send_agent_completed(self, platform, plan_id, stage_id): raise NotImplementedError()
    @abc.abstractmethod
    def _send_agent_paused(self): raise NotImplementedError()
    @abc.abstractmethod
    def _connect_agent_completed(self, agent_completed_handler): raise NotImplementedError()

    def reload_utils(self):
        super(AbstractExecutionManager, self).reload_utils()

        self._logger  = get_registered_logger_instance(application_name=self._application_name)

    def _get_run_engine(self):
        try:
            run_engine  = self._beamline_controller_initializer.run_engine
            data_broker = self._beamline_controller_initializer.data_broker
        except:
            run_engine, data_broker = create_run_engine()

        return run_engine, data_broker

    # -----------------------------------------------------------------------------------------------------------------------
    #
    # OPTIMIZATION
    #
    # -----------------------------------------------------------------------------------------------------------------------

    def _get_beam_manager_pointers(self, platform, plan_id, stage_id):
        configuration: BeamlineControllerConfiguration = self._configuration

        beam_manager_types = configuration.driver_configuration.beam_manager_types

        plan : AutoAlignmentPlan   = configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
        stage : AutoAlignmentStage = plan.get_stage(stage_id)

        platform_key          = platform
        beam_manager_type_key = beam_manager_types[int(stage.beam_manager_type)]

        beam_manager_ids    = configuration.driver_configuration.beam_manager_configuration[beam_manager_type_key]["beam_manager_ids"]
        beam_manager_id_key = beam_manager_ids[int(stage.beam_manager_id)]

        return platform_key, beam_manager_type_key, beam_manager_id_key

    def __create_ai_agent(self, ai_process, platform, plan_id, stage_id):
        configuration: BeamlineControllerConfiguration = self._configuration
        beam_manager_configuration    = configuration.driver_configuration.beam_manager_configuration
        ai_configuration              = configuration.ai_configuration

        selected_plan : AutoAlignmentPlan   = configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
        selected_stage : AutoAlignmentStage = selected_plan.get_stage(stage_id)

        platform_key, beam_manager_type_key, beam_manager_id_key = self._get_beam_manager_pointers(platform, plan_id, stage_id)

        beam_manager_full_id = Keys.compose_manager_key(optical_system_id=self._optical_system_id,
                                                        platform=platform_key,
                                                        beam_manager_type=beam_manager_type_key,
                                                        beam_manager_id=beam_manager_id_key,
                                                        manager_key=Keys.Managers.BeamManager)

        motion_manager_full_id = Keys.compose_manager_key(optical_system_id=self._optical_system_id,
                                                          platform=platform_key,
                                                          beam_manager_type=beam_manager_type_key,
                                                          beam_manager_id=beam_manager_id_key,
                                                          manager_key=Keys.Managers.MotionManager) \
            if platform_key == Keys.Platforms.DigitalTwin else \
                                 Keys.compose_manager_key(optical_system_id=self._optical_system_id,
                                                          platform=platform_key,
                                                          manager_key=Keys.Managers.MotionManager)

        try: motion_manager = create_motion_manager(motion_manager_id=motion_manager_full_id)
        except: raise ValueError(f"Motion Manager {motion_manager_full_id} not supported")
        try: beam_manager   = create_beam_manager(beam_manager_id=beam_manager_full_id)
        except: raise ValueError(f"Beam Manager {beam_manager_full_id} not supported")

        motors_to_optimize        = configuration.driver_configuration.get_motors_to_optimize(beam_manager_type=beam_manager_type_key,
                                                                                              platform=platform_key,
                                                                                              beam_manager_id=beam_manager_id_key,
                                                                                              motors_info=motion_manager.get_motors_info())
        move_motors_on_best_trial = bool(selected_stage.ai_configuration.get("move_motors_on_best_trial", False))
        requires_pause_at_end     = bool(selected_stage.requires_pause_at_end)

        selected_beam_manager_configuration = beam_manager_configuration[beam_manager_type_key]["defaults"][platform_key][beam_manager_id_key]

        ai_type_key = ai_configuration.ai_types[int(selected_stage.ai_type)]

        if ai_type_key == Keys.AITypes.Optimization:
            objectives                   = selected_beam_manager_configuration["objectives"]
            optimizer_type_key           = ai_configuration.optimization_configuration["optimizer_types"][int(selected_stage.ai_configuration["optimizer_type"])]
            optimizer_type_configuration = ai_configuration.optimization_configuration[optimizer_type_key]
            optimizer_name_key           = optimizer_type_configuration["names"][int(selected_stage.ai_configuration["name"])]
            optimization_type            = selected_stage.ai_configuration["optimization_type"]

            if optimization_type == OptimizationType.FULL_START:
                erase_warm_start_data = bool(selected_stage.ai_configuration.get("erase_warm_start_data", False))
                save_warm_start_data  = bool(selected_stage.ai_configuration.get("save_warm_start_data", False))
            else:
                erase_warm_start_data = False
                save_warm_start_data  = False

            if   optimization_type == OptimizationType.FULL_START:                    warm_start_configuration = ai_configuration.optimization_configuration["warm_start_same"]
            elif optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:      warm_start_configuration = ai_configuration.optimization_configuration["warm_start_same"]
            elif optimization_type == OptimizationType.WARM_START_DIFFERENT_DETECTOR: warm_start_configuration = ai_configuration.optimization_configuration["warm_start_different"]

            optimization_criteria                  = OptimizationCriteria(list(objectives.keys()))
            hypervolume_reference_points           = {}
            optimization_criteria_reference_values = {}
            optimization_criteria_weights          = {}
            exit_loss_function                     = {}

            for optimization_criterion in objectives.keys():
                values = objectives[optimization_criterion]

                optimization_criteria_reference_values[optimization_criterion] = float(values[0])
                hypervolume_reference_points[optimization_criterion]           = float(values[1])
                optimization_criteria_weights[optimization_criterion]          = float(values[2])
                if float(values[3]) != 0.0: exit_loss_function[optimization_criterion] = float(values[3])

            use_exit_strategy = len(exit_loss_function.keys()) > 0

            # added beam_manager_id to home directory, it represents a different optimization pattern
            home_directory = os.path.join(os.path.abspath(os.getcwd()), f"{optimizer_name_key}-{platform_key}-{beam_manager_type_key}-{beam_manager_id_key}-cr{len(objectives.keys())}")

            if (optimization_type == OptimizationType.WARM_START_SAME_DETECTOR or
                    (erase_warm_start_data and optimization_type == OptimizationType.FULL_START)):
                if warm_start_configuration["defaults"].get("warm_start_home_directory_type", 0) == 0: warm_start_home_directory = home_directory
                else:                                                                                  warm_start_home_directory = warm_start_configuration["defaults"].get("warm_start_home_directory")
            else:                                                                                      warm_start_home_directory = None

            optimizer_configuration = optimizer_type_configuration[optimizer_name_key]

            optimizer_id           = f"{optimizer_type_key}-{optimizer_name_key}"
            hypervolume_manager_id = f"{optimizer_type_key}-{optimizer_name_key}-{beam_manager_type_key}"
            initialize_kwargs      = {}

            if optimizer_type_key == Keys.OptimizerType.MOBO:
                acquisition_function_key = optimizer_configuration["acquisition_functions"][int(selected_stage.ai_configuration["acquisition_function"])]

                hypervolume_manager_args = {"hypervolume_reference_points": hypervolume_reference_points,
                                            "optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)


                sobol_trials         = int(selected_stage.ai_configuration.get("sobol_iterations", 0))
                bo_trials            = int(selected_stage.ai_configuration.get("mobo_iterations", 0))
                selection_algorithm  = self.get_selection_algorithm(selected_stage.ai_configuration.get("pareto_selection", 0))

                use_hypervolume_exit  = selected_stage.ai_configuration.get("use_hypervolume_exit", True)
                hypervolume_exit      = selected_stage.ai_configuration["hypervolume_exit"]
                convergence_threshold = hypervolume_exit.get("convergence_threshold", 0.01)
                patience              = hypervolume_exit.get("patience", 5)

                if optimizer_name_key == "ax":
                    initialize_kwargs["add_center_node"]  = platform_key == Keys.Platforms.Beamline
                    initialize_kwargs["surrogate"]        = optimizer_configuration["surrogates"][int(selected_stage.ai_configuration.get("surrogate", 0))]
                    initialize_kwargs["surrogate_action"] = int(selected_stage.ai_configuration.get("surrogate_action", 0))
                    initialize_kwargs["verbose"]          = selected_stage.ai_configuration.get("verbose", False)

                if optimization_type == OptimizationType.FULL_START: # FULL START
                    execution_parameters = MOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       use_hypervolume_exit=use_hypervolume_exit,
                                                                                       convergence_threshold=convergence_threshold,
                                                                                       patience=patience,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       selection_algorithm=selection_algorithm,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = MOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
                elif optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                    warm_start_strategy          = selected_stage.ai_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key      = warm_start_configuration["warm_start_strategies"][int(warm_start_strategy)]
                    warm_start_expansion_factors = selected_stage.ai_configuration.get("warm_start_expansion_factors")[warm_start_strategy_key]

                    execution_parameters = MOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       warm_start_data_type=warm_start_configuration["defaults"].get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       warm_start_strategy=warm_start_strategy,
                                                                                       warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                       use_warm_start_search_space=warm_start_configuration["defaults"].get("use_warm_start_search_space", 1) == 1,
                                                                                       use_warm_start_hypervolume_reference_points=warm_start_configuration["defaults"].get("use_warm_start_hypervolume_reference_points", 1) == 1,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       use_hypervolume_exit=use_hypervolume_exit,
                                                                                       convergence_threshold=convergence_threshold,
                                                                                       patience=patience,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       selection_algorithm=selection_algorithm,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = MOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
                elif optimization_type == OptimizationType.WARM_START_DIFFERENT_DETECTOR:
                    execution_parameters = MOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       convergence_threshold=convergence_threshold,
                                                                                       patience=patience,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       selection_algorithm=selection_algorithm,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = MOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
            elif optimizer_type_key == Keys.OptimizerType.SONL:
                hypervolume_manager_args = {"optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)

                max_iterations    = int(selected_stage.ai_configuration.get("max_iterations", 50))
                x_absolute_change = float(selected_stage.ai_configuration.get("x_absolute_change", 1e-8))
                f_absolute_change = float(selected_stage.ai_configuration.get("f_absolute_change", 1e-8))

                if optimization_type == OptimizationType.FULL_START:
                    execution_parameters = NonLinearOptimizationExecutionParameters(home_directory=home_directory,
                                                                                    optimization_type=optimization_type,
                                                                                    erase_warm_start_data=erase_warm_start_data,
                                                                                    warm_start_home_directory=warm_start_home_directory,
                                                                                    save_warm_start_data=save_warm_start_data,
                                                                                    use_exit_strategy=use_exit_strategy,
                                                                                    exit_loss_function=exit_loss_function,
                                                                                    move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                    requires_pause_at_end=requires_pause_at_end)
                elif optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:  # WARM START SAME
                    warm_start_strategy          = selected_stage.ai_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key      = warm_start_configuration["warm_start_strategies"][int(warm_start_strategy)]
                    warm_start_expansion_factors = selected_stage.ai_configuration.get("warm_start_expansion_factors")[warm_start_strategy_key]

                    execution_parameters = NonLinearOptimizationExecutionParameters(home_directory=home_directory,
                                                                                    optimization_type=optimization_type,
                                                                                    warm_start_data_type=warm_start_configuration["defaults"].get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                    warm_start_home_directory=warm_start_home_directory,
                                                                                    warm_start_strategy=warm_start_strategy,
                                                                                    warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                    erase_warm_start_data=erase_warm_start_data,
                                                                                    save_warm_start_data=save_warm_start_data,
                                                                                    use_exit_strategy=use_exit_strategy,
                                                                                    exit_loss_function=exit_loss_function,
                                                                                    move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                    requires_pause_at_end=requires_pause_at_end)
                elif optimization_type == OptimizationType.WARM_START_DIFFERENT_DETECTOR:
                    execution_parameters = NonLinearOptimizationExecutionParameters(home_directory=home_directory,
                                                                                    optimization_type=optimization_type,
                                                                                    erase_warm_start_data=erase_warm_start_data,
                                                                                    save_warm_start_data=save_warm_start_data,
                                                                                    use_exit_strategy=use_exit_strategy,
                                                                                    exit_loss_function=exit_loss_function,
                                                                                    move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                    requires_pause_at_end=requires_pause_at_end)

                input_parameters = NonLinearOptimizationInputParameters(method=ScipyOptimizationModel.UNCONSTRAINED_MULTIVARIATE_SCALAR_NELDER_MEAD,
                                                                        max_iteration=max_iterations,
                                                                        motors_to_optimize=motors_to_optimize,
                                                                        beam_manager_type=beam_manager_type_key,
                                                                        platform=platform_key,
                                                                        beam_manager_id=beam_manager_id_key,
                                                                        random_seed=int(time.time()),
                                                                        x_absolute_change=x_absolute_change,
                                                                        f_absolute_change=f_absolute_change)
            elif optimizer_type_key == Keys.OptimizerType.SOBO:
                acquisition_functions = optimizer_configuration["acquisition_functions"]
                acquisition_function = optimizer_configuration["acquisition_function"]
                acquisition_function_key = acquisition_functions[int(acquisition_function)]

                hypervolume_manager_args = {"hypervolume_reference_points": hypervolume_reference_points,
                                            "optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)

                sobol_trials = int(optimizer_configuration.get("sobol_iterations", 0))
                bo_trials = int(optimizer_configuration.get("sobo_iterations", 0))

                if optimization_type == OptimizationType.FULL_START:
                    execution_parameters = SOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = SOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
                elif optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                    warm_start_strategy          = selected_stage.ai_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key      = warm_start_configuration["warm_start_strategies"][int(warm_start_strategy)]
                    warm_start_expansion_factors = selected_stage.ai_configuration.get("warm_start_expansion_factors")[warm_start_strategy_key]

                    execution_parameters = SOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       warm_start_data_type=warm_start_configuration["defaults"].get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       warm_start_strategy=warm_start_strategy,
                                                                                       warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                       use_warm_start_search_space=warm_start_configuration["defaults"].get("use_warm_start_search_space", 1) == 1,
                                                                                       use_warm_start_hypervolume_reference_points=warm_start_configuration["defaults"].get("use_warm_start_hypervolume_reference_points", 1) == 1,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = SOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time())),
                elif optimization_type == OptimizationType.WARM_START_DIFFERENT_DETECTOR:
                    execution_parameters = SOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       optimization_type=optimization_type,
                                                                                       erase_warm_start_data=erase_warm_start_data,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       requires_pause_at_end=requires_pause_at_end)
                    input_parameters = SOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
            else:
                raise ValueError("Optimizer Type not recognized")

            optimizer = create_optimizer(optimizer_id=optimizer_id, optimization_listener=ai_process, verbose=True)
            optimizer.initialize_driver(beam_manager, motion_manager)

            if optimizer.requires_run_engine():
                run_engine, data_broker = self._get_run_engine()

                initialize_kwargs["verbose"]    = True
                initialize_kwargs["data_broker"] = data_broker

                self._run_engine = run_engine
            else:
                self._run_engine = None

            optimizer.initialize_optimization(hypervolume_manager, **initialize_kwargs)

            ai_agent = optimizer
            ai_input = optimization_criteria, execution_parameters, input_parameters
        elif ai_type_key == Keys.AITypes.NeuralNetworks:
            self._run_engine = None

            target_properties = selected_beam_manager_configuration["properties"]

            neural_network_configuration = ai_configuration.neural_network_configuration
            neural_network_type_key      = neural_network_configuration["neural_network_types"][int(selected_stage.ai_configuration.get("neural_network_type"))]

            home_directory = os.path.join(os.path.abspath(os.getcwd()), f"nn-{neural_network_type_key}-{platform_key}-{beam_manager_type_key}-{beam_manager_id_key}-tp{len(target_properties.keys())}")
            if not os.path.exists(home_directory): os.mkdir(home_directory)

            initialize_agent_listener_factory(instances={f"{neural_network_type_key}_nn": ai_process})
            neural_network_listener = create_agent_listener(listener_id=f"{neural_network_type_key}_nn")

            neural_network_model_from     = neural_network_configuration.get("neural_network_model_from")
            neural_network_home_directory = neural_network_configuration.get("neural_network_home_directory")
            neural_network_data_type      = neural_network_configuration.get("neural_network_data_type", 2)
            neural_network_args           = neural_network_configuration.get("neural_network_parameters", {})
            neural_network_args["neural_network_data_type"] = neural_network_data_type

            if neural_network_type_key == Keys.NeuralNetworkType.TANDEM:
                if neural_network_model_from == 0:
                    neural_network = TandemNeuralNetwork(neural_network_parameters=NeuralNetworkParameters(input_data_directory=os.path.join(neural_network_home_directory, "ml_data"),
                                                                                                           output_model_directory=os.path.join(home_directory, "trained_nn"),
                                                                                                           **neural_network_args),
                                                         motor_ids_to_optimize=motors_to_optimize,
                                                         beam_properties_names=list(target_properties.keys()),
                                                         beam_manager=beam_manager,
                                                         listener=neural_network_listener)
                elif neural_network_model_from == 1: # trained model file
                    output_model_directory, _ = os.path.split(neural_network_configuration.get("neural_network_trained_model_file"))

                    neural_network = TandemNeuralNetwork(neural_network_parameters=NeuralNetworkParameters(output_model_directory=output_model_directory),
                                                         motor_ids_to_optimize=motors_to_optimize,
                                                         beam_properties_names=list(target_properties.keys()),
                                                         beam_manager=None,
                                                         listener=neural_network_listener)
                else:
                    raise ValueError(f"Neural Network Model From not recognized {neural_network_model_from}")
            else:
                raise ValueError(f"Neural Network Type not recognized {neural_network_type_key}")

            neural_network_manager = create_neural_network_manager(neural_network_manager_id=neural_network_type_key,
                                                                   neural_network_listener=neural_network_listener)

            neural_network_manager.initialize_driver(beam_manager, motion_manager)
            neural_network_manager.initialize_neural_network(neural_network, home_directory)

            ai_agent = neural_network_manager
            ai_input = {target_property: float(target_properties[target_property][0]) for target_property in target_properties.keys()}
        else:
            raise ValueError("Ai type not recognized")

        return ai_agent, ai_input, motion_manager

    # -----------------------------------------------------------------------------------------------------------------------

    def _start_ai_plan(self, ai_plan, **kwargs): pass

    def __start_ai_plan(self, ai_plan, **kwargs):
        if kwargs.get("is_active_gui", True): ai_plan.start()
        else:                                             ai_plan.run_ai_plan()

    def __start_ai_plan_generator(self, ai_process, **kwargs):
        yield from ai_process.run_ai_plan()

    # -----------------------------------------------------------------------------------------------------------------------

    @synchronized_method
    def __start_ai_agent(self, platform, plan_id, **kwargs):
        configuration : BeamlineControllerConfiguration = self._configuration
        stdout = sys.stdout

        try:
            ai_plan_process_list     = [self.__start_ai_agent_body(platform, plan_id, stage_id) for stage_id in configuration.plans_configuration.get_plan(platform, plan_id).get_stages_id()]
            ai_plan_runner           = self._create_ai_plan_runner(ai_plan_process_list)
            self._current_ai_runner = ai_plan_runner

            self._start_ai_plan(ai_plan_runner, **kwargs)
        except:
            self.__start_ai_agent_except(platform, plan_id, "undefined")

        sys.stdout = stdout

    @synchronized_method
    def __start_ai_agent_generator(self, platform, plan_id, **kwargs):
        configuration : BeamlineControllerConfiguration = self._configuration
        stdout = sys.stdout

        try:
            ai_plan_process_list     = [self.__start_ai_agent_body(platform, plan_id, stage_id) for stage_id in configuration.plans_configuration.get_plan(platform, plan_id).get_stages_id()]
            ai_plan_runner           = self._create_ai_plan_runner(ai_plan_process_list)
            self._current_ai_runner = ai_plan_runner

            yield from self._start_ai_plan(ai_plan_runner, **kwargs)
        except:
            self.__start_ai_agent_except(platform, plan_id, "undefined")

        sys.stdout = stdout

    def __start_ai_agent_except(self, platform, plan_id, stage_id):
        self.finish([platform, plan_id, stage_id, None, None])

        self._logger.print_error(traceback.format_exc())

    def __start_ai_agent_body(self, platform, plan_id, stage_id):
        configuration: BeamlineControllerConfiguration = self._configuration

        if configuration.gui_configuration.alignment_configuration["capture_stdout"]: sys.stdout = StreamProxy(stdout_print=self._logger.print)

        if not self.__current_ai_process is None:
            try:
                while (self.__current_ai_process.isRunning()):
                    self.__current_ai_process.quit()
                    time.sleep(0.1)
            except RuntimeError as e:
                if "wrapped C/C++" in str(e): pass

        ai_process = self._create_ai_process(platform, plan_id, stage_id)

        ai_agent, \
        ai_input, \
        motion_manager = self.__create_ai_agent(ai_process, platform, plan_id, stage_id)

        ai_process.initialize(ai_agent=ai_agent,
                              ai_input=ai_input,
                              configuration=self._configuration,
                              run_engine=self._run_engine)

        self._connect_ai_process_handlers(ai_process)

        self.__current_ai_process     = ai_process
        self.__current_ai_agent       = ai_agent
        self.__current_ai_input       = ai_input
        self.__current_motion_manager = motion_manager

        return ai_process

    # -----------------------------------
    # Signals

    def get_selection_algorithm(self, pareto_selection):
        if   pareto_selection == 0: return SelectionAlgorithm.NASH_EQUILIBRIUM
        elif pareto_selection == 1: return SelectionAlgorithm.MOST_INTENSE
        elif pareto_selection == 2: return SelectionAlgorithm.NARROWEST
        elif pareto_selection == 3: return SelectionAlgorithm.CLOSEST_TO_CENTER

    # ----------------------------------------------------------------------------
    #
    # GET RESULTS AFTER OPTIMIZATION
    #
    # ----------------------------------------------------------------------------

    def get_current_result(self): return self.__current_ai_result

    def get_trial(self, trial_index, platform, plan_id, stage_id):
        configuration: BeamlineControllerConfiguration = self._configuration

        plan = self._configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
        stage = plan.get_stage(stage_id)

        ai_type_key = configuration.ai_configuration.ai_types[int(stage.ai_type)]

        if   ai_type_key == Keys.AITypes.Optimization:   return self.__current_ai_agent.get_trial_data(trial_index, check_beam=True, post_processing=True)
        elif ai_type_key == Keys.AITypes.NeuralNetworks: return self.__current_ai_agent.get_alignement_result_data()

    def get_pareto_trial_number(self, pareto_selection, platform, plan_id, stage_id):
        configuration: BeamlineControllerConfiguration = self._configuration

        plan = self._configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
        stage = plan.get_stage(stage_id)

        ai_type_key = configuration.ai_configuration.ai_types[int(stage.ai_type)]

        if ai_type_key == Keys.AITypes.Optimization:
            try:
                best_trial_data, _ = self.__current_ai_agent.get_best_trial_data(algorithm=self.get_selection_algorithm(pareto_selection),
                                                                                 **{"check_beam": False, "show_beam": False, "save_image": False})
                return best_trial_data.trial_number
            except:
                return None
        else:
            return None

    def get_optimization_history(self):
        return self.__current_ai_agent.plot_optimization_history(plot_images=False, save_images=False)

    def get_hypervolume(self):
        return self.__current_ai_agent.plot_hypervolume(plot_images=False, save_images=False)

    # ----------------------------------------------------------------------------
    #
    # PRE/POST-OPTIMIZATION ACTIONS
    #
    # ----------------------------------------------------------------------------

    def __move_motors_to_trial_data_generator(self, trial_data: OptimizationResultItem):
        self._logger.print_message(f"Moving motors to the positions of trial #{trial_data.trial_number}")
        self._logger.print_message("Positions:\n" + str(trial_data.motor_positions))

        yield from self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE)

    def __move_motors_to_trial_data(self, trial_data: OptimizationResultItem):
        self._logger.print_message(f"Moving motors to the positions of trial #{trial_data.trial_number}")
        self._logger.print_message("Positions:\n" + str(trial_data.motor_positions))

        if not self.__current_ai_agent.requires_run_engine():
            self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE)
        else:
            self._run_engine(self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE), purpose="AI-alignment")


    # ----------------------------------------------------------------------------
    #
    # IAgentListener
    #
    # ----------------------------------------------------------------------------

    @synchronized_method
    def feedback(self, text_lines):
        if len(text_lines) > 1:
            for text_line in text_lines:
                if "Trial Number" in text_line:
                    self._logger.print_other(message="", prefix="", color=LoggerColor.BLUE)
                    self._logger.print_other(message=text_line, prefix="", color=LoggerColor.GREEN)
                elif "Current Loss" in text_line:
                    self._logger.print_other(message="", prefix="", color=LoggerColor.BLUE)
                    self._logger.print_other(message=text_line, prefix="\u2192 ", color=LoggerColor.MAGENTA)
                else:
                    self._logger.print_other(message=text_line, prefix="", color=LoggerColor.BLUE)
        else:
            self._logger.print_other(text_lines[0], color=LoggerColor.BLACK)

    # ----------------------------------------------------------------------------
    #
    # Signals
    #
    # ----------------------------------------------------------------------------

    @synchronized_method
    def begin(self):
        self.__current_ai_result = None

        self._logger.print_message(f"AI Started at {date_now_str(format=f1)} {time_now_str(format=f2)}")

    @synchronized_method
    def error(self, text): self._logger.print_error(text)

    @synchronized_method
    def finish(self, ai_data: list):
        platform                  = ai_data[0]
        plan_id                   = ai_data[1]
        stage_id                  = ai_data[2]
        self.__current_ai_agent   = ai_data[3]
        self.__current_ai_result  = ai_data[4]

        # Here final operation that rely on matplotlib.
        # QThread and Matplotlib are notoriously unstable and can lead the gui to crash.
        # By moving these operations here, they will be on the Main Thread.

        if not self.__current_ai_result is None:
            configuration: BeamlineControllerConfiguration = self._configuration
            ai_configuration = configuration.ai_configuration

            plan  = configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
            stage = plan.get_stage(stage_id)

            ai_type_key  = ai_configuration.ai_types[int(stage.ai_type)]

            if ai_type_key == Keys.AITypes.Optimization:
                optimizer_types              = ai_configuration.optimization_configuration["optimizer_types"]
                optimizer_type               = stage.ai_configuration["optimizer_type"]
                optimizer_type_key           = optimizer_types[int(optimizer_type)]

                optimizer = self.__current_ai_agent

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    optimization_result_data, pareto_front_data = self.__current_ai_result

                    selection_algorithm = self.get_selection_algorithm(stage.ai_configuration.get("pareto_selection", 0))

                    optimizer.save_optimization_result()
                    optimizer.plot_optimization_history(**{"plot_images": False, "save_images": True})
                    optimizer.plot_optimization_history_correlations(**{"plot_images": False, "save_images": True})

                    if not pareto_front_data is None and not pareto_front_data.is_empty():
                        optimizer.save_pareto_front()
                        optimizer.plot_pareto_front(**{"plot_images": False, "save_images": True})
                        best_trial_data, _ = optimizer.get_best_trial_data(algorithm=selection_algorithm, **{"check_beam": True, "show_beam": False, "save_image": True})
                    else:
                        best_trial_data = None

                    optimizer.plot_hypervolume(**{"plot_images": False, "save_images": True})

                    self.__current_ai_result = optimization_result_data, pareto_front_data, best_trial_data
                elif optimizer_type_key in [Keys.OptimizerType.SOBO, Keys.OptimizerType.SONL]:  # NL / SOBO
                    optimization_result_data = self.__current_ai_result

                    optimizer.save_optimization_result()
                    optimizer.plot_optimization_history(**{"plot_images": False, "save_images": True})
                    optimizer.plot_optimization_history_correlations(**{"plot_images": False, "save_images": True})

                    best_trial_data, _ = optimizer.get_best_trial_data(move_motors=False, **{"check_beam": True, "show_beam": False, "save_image": True})

                    self.__current_ai_result = optimization_result_data, best_trial_data
            elif ai_type_key == Keys.AITypes.NeuralNetworks:
                result_data            = self.__current_ai_result
                neural_network_manager = self.__current_ai_agent
                neural_network_manager.save_alignment_result()

                self.__current_ai_result =  result_data # redundant but for code symmetry

        self._send_agent_completed(platform, plan_id, stage_id)

    def pause(self):
        self._send_agent_paused()

 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class ExecutionManager(AbstractExecutionManager):
    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, run_as_generator=False, **kwargs):
        super(ExecutionManager, self).__init__(application_name, working_directory, optical_system_id, run_as_generator, **kwargs)

    def abort(self): pass

    def _create_ai_process(self, platform, plan_id, stage_id):
        return AIAgentProcess(
            platform=platform,
            plan_id=plan_id,
            stage_id=stage_id,
            run_as_generator=self._run_as_generator,
            feedback_method=self.feedback,
            error_method=self.error,
            begin_method=self.begin,
            finish_method=self.finish
        )

    def _create_ai_plan_runner(self, plan_processes):
        return AIPlanProcessRunner(plan_processes, run_as_generator=self._run_as_generator)

    def _connect_ai_process_handlers(self, ai_process):          pass
    def _send_agent_completed(self, platform, plan_id, stage_id): pass
    def _send_agent_paused(self): pass
    def _connect_agent_completed(self, agent_completed_handler): pass

# QT APPLICATION: BATCH OR GUI
class QtExecutionManager(AbstractExecutionManager, QObject):
    interrupt            = pyqtSignal()
    agent_completed      = pyqtSignal(list)
    agent_paused         = pyqtSignal()
    pause_released       = pyqtSignal()
    configuration_closed = pyqtSignal()
    configuration_saved  = pyqtSignal()

    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, run_as_generator=False, **kwargs):
        QObject.__init__(self)
        AbstractExecutionManager.__init__(self, application_name, working_directory, optical_system_id, run_as_generator, **kwargs)

        self.configuration_saved.connect(self.reload_configuration)

    def notify_agent_pause_released(self): self.pause_released.emit()

    @synchronized_method
    def _is_ai_plan_running(self):
        if self._current_ai_runner is None: return False
        else: return self._current_ai_runner.isRunning()

    @synchronized_method
    def abort(self): self.interrupt.emit()

    def _create_ai_process(self, platform, plan_id, stage_id) :
        return AIAgentThread(platform, plan_id, stage_id, run_as_generator=self._run_as_generator)

    def _create_ai_plan_runner(self, plan_threads):
        return AIPlanThreadsRunner(plan_threads, run_as_generator=self._run_as_generator)

    def _connect_ai_process_handlers(self, ai_process):
        self.pause_released.connect(ai_process.notify_pause_released)
        ai_process.begin_signal.connect(self.begin)
        ai_process.error_signal.connect(self.error)
        ai_process.feedback_signal.connect(self.feedback)
        ai_process.finish_signal.connect(self.finish)
        ai_process.pause_signal.connect(self.pause)
        ai_process.finished.connect(ai_process.deleteLater)
        self.interrupt.connect(ai_process.interrupt)

    def _send_agent_completed(self, platform, plan_id, stage_id): self.agent_completed.emit([platform, plan_id, stage_id]) # here the main thread can manage the results.
    def _send_agent_paused(self): self.agent_paused.emit()
    def _connect_agent_paused(self, agent_paused_handler): self.agent_paused.connect(agent_paused_handler)
    def _connect_agent_completed(self, agent_completed_handler): self.agent_completed.connect(agent_completed_handler)
    def _connect_configuration_closed(self, configuration_closed_handler): self.configuration_closed.connect(configuration_closed_handler)

    def reload_configuration(self, **kwargs):
        self._available_beam_managers, self._configuration = self._beamline_controller_initializer.initialize_beamline_controller(**kwargs)

# ------------------------------------------------------------------
# EXECUTION PROCESS
# ------------------------------------------------------------------

class AbstractAIAgentProcess(OptimizationListenerDecorator, IAgentListener):
    def __init__(self, platform, plan_id, stage_id, run_as_generator=False, run_engine=None, is_gui=True, **kwargs):
        super(AbstractAIAgentProcess, self).__init__()

        self.__configuration: BeamlineControllerConfiguration = None
        self.__ai_agent         = None
        self.__ai_input         = None
        self.__ai_result        = None
        self.__run_as_generator = run_as_generator
        self.__run_engine       = run_engine
        self.__is_gui           = is_gui
        self.__platform         = platform
        self.__plan_id          = plan_id
        self.__stage_id         = stage_id

        if run_as_generator: setattr(self, "run_ai_agent",    self.__run_ai_agent_generator)
        else:                setattr(self, "run_ai_agent",    self.__run_ai_agent)

    def initialize(self, ai_agent, ai_input, configuration : BeamlineControllerConfiguration, run_engine):
        self.__configuration = configuration
        self.__ai_agent      = ai_agent
        self.__ai_input      = ai_input
        self.__run_engine    = run_engine

    @synchronized_method
    def interrupt(self):
        if not self.__ai_agent is None:
            try:   self.__ai_agent.interrupt = True
            except: self._send_feedback(["Interruption Failed"])

    @abc.abstractmethod
    def _send_feedback(self, feedback: List[str]): raise NotImplementedError
    @abc.abstractmethod
    def _send_error(self, error_message): raise NotImplementedError
    @abc.abstractmethod
    def _send_begin(self): raise NotImplementedError
    @abc.abstractmethod
    def _send_finish(self, data: List[Any]): raise NotImplementedError
    @abc.abstractmethod
    def _send_pause(self): raise NotImplementedError
    @abc.abstractmethod
    def notify_pause_released(self): raise NotImplementedError

    def run_ai_agent(self): pass

    def __run_ai_agent_generator(self):
        self.__ai_result = None

        try:
            stage = self.__configuration.plans_configuration.get_plan(self.__platform, self.__plan_id).get_stage(self.__stage_id)

            ai_type_key, fidelity = self.__run_ai_agent_init()

            if ai_type_key == Keys.AITypes.Optimization:
                (execution_parameters,
                 input_parameters,
                 optimization_criteria,
                 optimizer,
                 optimizer_type_key) = self.__optimization_init()

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    yield from optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    optimization_result_data = self.__finalize_mobo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SOBO:
                    yield from optimizer.optimize(optimization_criteria=optimization_criteria,
                                                  execution_parameters=execution_parameters,
                                                  input_parameters=input_parameters, **{})
                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SONL:
                    raise ValueError(f"Optimizer type {optimizer_type_key} not supported whithin a Run Engine")

                self._send_feedback([" ",
                                     "#########################################################",
                                     " ",
                                             f"Stage: {stage.stage_name}",
                                     f"Optimization completed, total duration: {round(optimization_result_data.get_optimization_duration(), 1)} sec",
                                     " ",
                                     "#########################################################",
                                     " ",
                                     "Post-processing the optimization result, please wait ..."])

                time.sleep(0.1) # this is needed to give the main thread the time to print the last message
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
                if execution_parameters.requires_pause_at_end:
                    time.sleep(0.2)
                    yield from self._send_pause()
            elif ai_type_key == Keys.AITypes.NeuralNetworks:
                arguments, neural_network_manager, target_properties = self.__neural_networks_init()

                yield from neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments)

                self.__finalize_neural_networks(fidelity, neural_network_manager)
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
            else:
                self.__ai_result = None
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
        except Exception:
            self._send_error('Exception occured: {}'.format(traceback.format_exc()))
            self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, None])

    @synchronized_method
    def __run_ai_agent(self):
        self.__ai_result = None

        try:
            stage = self.__configuration.plans_configuration.get_plan(self.__platform, self.__plan_id).get_stage(self.__stage_id)

            ai_type_key, fidelity = self.__run_ai_agent_init()

            if ai_type_key == Keys.AITypes.Optimization:
                (execution_parameters,
                 input_parameters,
                 optimization_criteria,
                 optimizer,
                 optimizer_type_key) = self.__optimization_init()

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    if not optimizer.requires_run_engine():
                        optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    else:
                        self.__run_engine(optimizer.optimize(optimization_criteria=optimization_criteria,
                                                             execution_parameters=execution_parameters,
                                                             input_parameters=input_parameters, **{}), purpose="AI-alignment")

                    optimization_result_data = self.__finalize_mobo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SONL:
                    optimizer.optimize(optimization_criteria=optimization_criteria,
                                       execution_parameters=execution_parameters,
                                       input_parameters=input_parameters, **{})

                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SOBO:
                    if not optimizer.requires_run_engine():
                        optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    else:
                        self.__run_engine(optimizer.optimize(optimization_criteria=optimization_criteria,
                                                             execution_parameters=execution_parameters,
                                                             input_parameters=input_parameters,
                                                             **{"compute_result": True,
                                                                "show_beam":      False,
                                                                "save_image":     True}))
                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)

                self._send_feedback([" ",
                                     "#########################################################",
                                     " ",
                                     f"Stage: {stage.stage_name}",
                                     f"Optimization completed, total duration: {round(optimization_result_data.get_optimization_duration(), 1)} sec",
                                     " ",
                                     "#########################################################",
                                     " ",
                                     "Post-processing the optimization result, please wait ..."])

                time.sleep(0.1) # this is needed to give the main thread the time to print the last message
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
                if execution_parameters.requires_pause_at_end:
                    time.sleep(0.2)
                    self._send_pause()
            elif ai_type_key == Keys.AITypes.NeuralNetworks:
                arguments, neural_network_manager, target_properties = self.__neural_networks_init()

                if not neural_network_manager.requires_run_engine():
                    neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments)
                else:
                    self.__run_engine(neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments), purpose="AI-alignment")

                self.__finalize_neural_networks(fidelity, neural_network_manager)
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
            else:
                self.__ai_result = None
                self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, self.__ai_result])
        except Exception:
            self._send_error('Exception occured: {}'.format(traceback.format_exc()))
            self._send_finish([self.__platform, self.__plan_id, self.__stage_id, self.__ai_agent, None])

    # -----------------------------------------

    def __finalize_neural_networks(self, fidelity, neural_network_manager):
        alignment_result_data, _ = neural_network_manager.get_alignement_result_data()
        if not alignment_result_data is None: alignment_result_data.fidelity = fidelity

        self.__ai_result = alignment_result_data

        self._send_feedback([" ",
                             "#########################################################",
                             " ",
                             f"NN Alignement completed",
                             " ",
                             "#########################################################",
                             " ",
                             "Post-processing the NN result, please wait ..."])

        time.sleep(0.1)  # this is needed to give the main thread the time to print the last message

    # -----------------------------------------

    def __neural_networks_init(self) -> tuple[Any, Any, dict[str, bool]]:
        neural_network_manager = self.__ai_agent
        target_properties = self.__ai_input

        neural_network_model_type = 0 # from gui too or from plan

        neural_network_configuration = self.__configuration.ai_configuration["neural_network"]
        neural_network_model_from = 0 # TODO: this choice is in the gui parameters or from plan

        if neural_network_model_from == 0:
            neural_network_manager.get_neural_network().train_neural_network()
        elif neural_network_model_from == 1:  # trained model file
            _, trained_model_file = os.path.split(neural_network_configuration[neural_network_model_type]["defaults"].get("neural_network_trained_model_file"))
            neural_network_manager.get_neural_network().load_trained_model(file_name=trained_model_file)

        arguments = {"compute_result": True, "show_beam": False, "save_image": False}

        return arguments, neural_network_manager, target_properties

    # -----------------------------------------

    def __finalize_soo(self, fidelity, optimizer) -> Any:
        optimization_result_data = optimizer.get_optimization_result_data()
        optimization_result_data.set_fidelity(fidelity)

        self.__ai_result = optimization_result_data

        return optimization_result_data

    # -----------------------------------------

    def __finalize_mobo(self, fidelity, optimizer) -> Any:
        optimization_result_data = optimizer.get_optimization_result_data()
        optimization_result_data.set_fidelity(fidelity)
        pareto_front_data = optimizer.get_pareto_front_data()
        pareto_front_data.set_fidelity(fidelity)

        self.__ai_result = optimization_result_data, pareto_front_data

        return optimization_result_data

    # -----------------------------------------

    def __optimization_init(self) -> tuple[Any, Any, Any, Any, Any]:
        plan  = self.__configuration.plans_configuration.get_plan(platform=self.__platform,
                                                                  plan_id=self.__plan_id)
        stage = plan.get_stage(self.__stage_id)

        optimizer_types = self.__configuration.ai_configuration.optimization_configuration["optimizer_types"]
        optimizer_type = stage.ai_configuration["optimizer_type"]
        optimizer_type_key = optimizer_types[int(optimizer_type)]

        optimizer = self.__ai_agent
        optimization_criteria, execution_parameters, input_parameters = self.__ai_input

        move_motor_to_initial_positions = (self.__platform == Keys.Platforms.DigitalTwin and
                                           stage.ai_configuration["optimization_type"] == OptimizationType.FULL_START)

        input_parameters.set_parameter("move_motor_to_initial_positions", move_motor_to_initial_positions)

        return execution_parameters, input_parameters, optimization_criteria, optimizer, optimizer_type_key

    # -----------------------------------------

    def __run_ai_agent_init(self) -> tuple[Any, Any]:
        self._send_begin()

        if self.__ai_agent is None or self.__ai_input is None or self.__configuration is None: raise ValueError("AI Process not initialized")

        plan         = self.__configuration.plans_configuration.get_plan(platform=self.__platform,
                                                                         plan_id=self.__plan_id)
        stage        = plan.get_stage(self.__stage_id)
        ai_type      = stage.ai_type
        ai_type_key  = self.__configuration.ai_configuration.ai_types[int(ai_type)]

        fidelity = Fidelity.HIGH if self.__platform == Keys.Platforms.Beamline else Fidelity.LOW

        return ai_type_key, fidelity

    # -----------------------------------------
    # -----------------------------------------
    # -----------------------------------------

    @synchronized_method
    def feedback(self, trial_index: int, motors_to_optimize : list, suggested_motor_positions: dict, actual_motor_positions: dict, current_loss : dict | list, **kwargs):
        text_list = self.prepare_feedback(trial_index, motors_to_optimize, suggested_motor_positions, actual_motor_positions, current_loss, **kwargs)

        if len(text_list) > 0: self._send_feedback(text_list)

#  EXECUTION AS QT GUI
class AIAgentThread(AbstractAIAgentProcess, QThread):
    begin_signal    = pyqtSignal()
    error_signal    = pyqtSignal(str)
    feedback_signal = pyqtSignal(list)
    finish_signal   = pyqtSignal(list)
    pause_signal    = pyqtSignal()

    def __init__(self, platform, plan_id, stage_id, run_as_generator=False):
        super(AIAgentThread, self).__init__(platform, plan_id, stage_id, run_as_generator)
        self._mutex    = QMutex()
        self._cond     = QWaitCondition()
        self._released = False

    def _send_feedback(self, feedback: List[str]): self.feedback_signal.emit(feedback)
    def _send_error(self, error_message):          self.error_signal.emit(error_message)
    def _send_begin(self):                         self.begin_signal.emit()
    def _send_finish(self, data: List[Any]):       self.finish_signal.emit(data)

    def _send_pause(self):
        self._mutex.lock()
        self._released = False
        self.pause_signal.emit()
        while not self._released: self._cond.wait(self._mutex)
        self._mutex.unlock()

    def notify_pause_released(self):
        self._mutex.lock()
        self._released = True
        self._cond.wakeAll()
        self._mutex.unlock()

    def run(self): self.run_ai_agent()

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class AIAgentProcess(AbstractAIAgentProcess):
    def __init__(self,
                 platform,
                 plan_id,
                 stage_id,
                 run_as_generator=False,
                 feedback_method=None,
                 error_method=None,
                 begin_method=None,
                 finish_method=None):
        super(AIAgentProcess, self).__init__(platform, plan_id, stage_id, run_as_generator)

        self.__feedback_method = feedback_method
        self.__error_method    = error_method
        self.__begin_method    = begin_method
        self.__finish_method   = finish_method

        if run_as_generator: setattr(self, "_send_pause", self.__send_pause_generator)
        else:                setattr(self, "_send_pause", self.__send_pause)

    def isRunning(self): return False

    def _send_feedback(self, feedback: List[str]): self.__feedback_method(feedback)
    def _send_error(self, error_message):          self.__error_method(error_message)
    def _send_begin(self):                         self.__begin_method()
    def _send_finish(self, data: List[Any]):       self.__finish_method(data)

    def __send_pause_generator(self):
        from bluesky import plan_stubs as bps
        _ = yield from bps.input_plan("AI autoalignment paused as request. Press any key to proceed to the next stage...")
    def __send_pause(self):
        input("AI autoalignment paused as request. Press any key to proceed to the next stage...")

class AIPlanThreadsRunner(QThread):
    all_done = pyqtSignal() # for future user

    def __init__(self, plan_threads, run_as_generator=False, parent=None):
        super().__init__(parent)
        self.__plan_threads = plan_threads

        if run_as_generator: setattr(self, "run_ai_plan",    self.__run_ai_plan_generator)
        else:                setattr(self, "run_ai_plan",    self.__run_ai_plan)

    def _run_stage(self, t: AIAgentThread):
        loop = QEventLoop()
        t.finished.connect(loop.quit)
        t.start()
        loop.exec()

    def _run_stage_generator(self, t: AIAgentThread):
        loop = QEventLoop()
        t.finished.connect(loop.quit)
        yield from t.run_ai_agent()
        loop.exec_()

    def __run_ai_plan(self):
        for i, t in enumerate(self.__plan_threads, start=1):
            self._run_stage(t)
        self.all_done.emit()

    def __run_ai_plan_generator(self):
        for i, t in enumerate(self.__plan_threads, start=1):
            yield from self._run_stage_generator(t)
        self.all_done.emit()

    def run(self):
        self.__run_ai_plan()

class AIPlanProcessRunner():
    def __init__(self, plan_processes, run_as_generator=False, parent=None):
        self.__plan_processes = plan_processes

        if run_as_generator: setattr(self, "run_ai_plan",    self.__run_ai_plan_generator)
        else:                setattr(self, "run_ai_plan",    self.__run_ai_plan)

    def _run_stage(self, t: AIAgentProcess):
        t.run_ai_agent()

    def _run_stage_generator(self, t: AIAgentProcess):
        yield from t.run_ai_agent()

    def __run_ai_plan(self):
        for i, t in enumerate(self.__plan_processes, start=1):
            self._run_stage(t)

    def __run_ai_plan_generator(self):
        for i, t in enumerate(self.__plan_processes, start=1):
            yield from self._run_stage_generator(t)