import inspect
import logging
from functools import wraps
from typing import Any, Callable, TypeVar, cast

try:
    from pymongo.errors import PyMongoError
except ImportError:
    raise RuntimeError("Mongodb extra is not installed. Run `pip install snakestack[mongodb]`.")

from snakestack.mongodb.exceptions import SnakeMongoDbError

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def handle_mongodb_error() -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except PyMongoError as error:
                logger.exception("Mongodb operation failed.")
                raise SnakeMongoDbError(error)

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except PyMongoError as error:
                logger.exception("Mongodb operation failed.")
                raise SnakeMongoDbError(error)

        if inspect.iscoroutinefunction(func):
            return cast(F, async_wrapper)
        return cast(F, wrapper)

    return decorator
