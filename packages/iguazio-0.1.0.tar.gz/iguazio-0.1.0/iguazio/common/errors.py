# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


class SerializationError(Exception):
    pass


class RetryUntilSuccessfulInProgressErrorMessage(Exception):
    def __init__(self, message, *, variables=None):
        super().__init__(message)
        self.variables = variables if variables else {}
        self.message = message


class RetryUntilSuccessfulFatalError(Exception):
    def __init__(self, message, *, caused_by_exc=None):
        super().__init__(message)
        self.message = message

        # the exception that caused the fatal error
        self.caused_by_exc = caused_by_exc


class RetryTimeoutError(Exception):
    """Raised when retry_until_successful exceeds the given timeout."""
