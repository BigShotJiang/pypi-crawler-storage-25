# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


from .authentication import AuthenticationClientV1
from .authorization import AuthorizationClientV1
from .events import EventsClientV1
from .idp import IdpClientV1
from .info import InfoClientV1
from .monitoring import MonitoringClientV1
from .logs import LogsClientV1
from .profile import ProfileClientV1


class ClientV1(
    AuthenticationClientV1,
    AuthorizationClientV1,
    EventsClientV1,
    IdpClientV1,
    InfoClientV1,
    LogsClientV1,
    MonitoringClientV1,
    ProfileClientV1,
):
    """
    Client for interacting with the Iguazio API v1.
    This client combines functionality from all available v1 clients by inheriting from them.
    """

    pass
