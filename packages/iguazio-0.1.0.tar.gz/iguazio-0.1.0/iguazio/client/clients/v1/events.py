# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.event_activation as event_activation_schema
import iguazio.schemas.v1.resources.event_config as event_config_schema


class EventsClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio events API v1.

    This client provides methods for publishing events to the event system.
    """

    def publish_event(
        self, options: event_activation_schema.EventActivationSpec
    ) -> event_activation_schema.EventActivation:
        """
        Publish an event to the Iguazio event system.

        Events are used to track system activities, audit trails, and notifications.
        The event is persisted to the database and, if configured, published to a message queue
        for downstream processing.

        For catalog events (config_name exists in the event catalog):
        - kind, class, and severity are taken from the catalog configuration
        - Any values passed for these fields are ignored

        For custom events (config_name not in catalog):
        - kind, class, and severity use passed values or defaults
        - Event is only persisted to DB, not published to queue

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.EventActivationSpec(
                config_name="user_login",
                source="api-service",
                details={"username": "john", "ip": "192.168.1.1"}
            )
            event = client.publish_event(options)

        Args:
            options (iguazio.schemas.v1.resources.event_activation.EventActivationSpec):
                The event specification to publish.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivation:
                The created event activation with server-assigned timestamps.
        """
        response = self._request(
            "post",
            "/events/activations",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivation
        )

    def list_event_activations(
        self,
        options: event_activation_schema.ListEventActivationsOptions = None,
        get_all: bool = False,
        batch_size: int = 1000,
    ) -> event_activation_schema.EventActivationList:
        """
        List event activations in the Iguazio system.

        Events can be filtered by kind, name (substring), time range (since/until),
        severity (enum, multi-value), class (substring), source (substring),
        project_name (exact match), entity_name (substring), and visibility.
        Results can be returned in minimal or full mode.

        **Important: Pagination Limits**

        - Default limit when not specified: 1,000 activations per request
        - Maximum limit per request: 1,000 activations
        - If you have more than 1,000 activations, use ``get_all=True`` to automatically
          paginate through all results

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # List activations with default limit (1,000)
            activations = client.list_event_activations()

            # Get ALL activations automatically
            all_activations = client.list_event_activations(get_all=True)
            print(f"Total activations: {len(all_activations.items)}")

            # Get all with filters
            all_critical = client.list_event_activations(
                options=iguazio.schemas.ListEventActivationsOptions(
                    severity=[iguazio.schemas.Severity.CRITICAL]
                ),
                get_all=True
            )

            # Custom pagination control
            options = iguazio.schemas.ListEventActivationsOptions(
                kind="system",
                name="~login",  # Substring match
                mode="minimal",
                offset=0,
                limit=100
            )
            activations = client.list_event_activations(options)

            # List with time range and multi-value filters
            from datetime import datetime, timezone
            options = iguazio.schemas.ListEventActivationsOptions(
                kind="log",
                since=datetime(2024, 12, 31, tzinfo=timezone.utc),  # Upper boundary
                until=datetime(2024, 1, 1, tzinfo=timezone.utc),  # Lower boundary
                severity=[iguazio.schemas.Severity.INFO, iguazio.schemas.Severity.WARNING],
                class_="~authentication",  # Substring match
                source="~api",  # Substring match
                project_name="my-project",  # Exact match
                entity_name="~user"  # Substring match
            )
            activations = client.list_event_activations(options)

        Args:
            options (iguazio.schemas.v1.resources.event_activation.ListEventActivationsOptions, optional):
                Options for listing event activations. If not provided, uses default pagination
                (offset=0, limit=1000). Maximum limit per request is 1,000.
            get_all (bool, optional):
                If True, automatically paginate through all results across multiple requests.
                This is useful when you have more than 1,000 activations. Defaults to False.
            batch_size (int, optional):
                When get_all=True, the number of activations to fetch per request.
                Defaults to 1,000 (maximum). Must be between 1 and 1,000.
                Ignored when get_all=False.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivationList:
                A list of event activations matching the criteria. When get_all=False,
                may contain fewer items than the total available if pagination limit is reached.
                When get_all=True, contains all matching activations.

        Raises:
            ValueError: If get_all=True and batch_size is not between 1 and 1,000.
        """
        # Initialize options if not provided
        options = options or event_activation_schema.ListEventActivationsOptions()
        if get_all:
            # Validate batch_size
            if batch_size < 1 or batch_size > 1000:
                raise ValueError(
                    f"batch_size must be between 1 and 1,000, got {batch_size}"
                )

            # Use the helper to paginate through all results
            all_items = self.fetch_all_pages(
                lambda batch_opts: self.list_event_activations(
                    options=batch_opts, get_all=False
                ),
                options,
                batch_size,
            )

            # Return combined result
            return event_activation_schema.EventActivationList(items=all_items)
        else:
            response = self._request(
                "get",
                "/events/activations",
                params=options.to_query_params(),
                expected_status_codes=[http.HTTPStatus.OK],
            )
            return iguazio.schemas.serializer.deserialize(
                response, event_activation_schema.EventActivationList
            )

    def get_event_activation(
        self,
        options: event_activation_schema.GetEventActivationOptions,
    ) -> event_activation_schema.EventActivation:
        """
        Get a single event activation by ID.

        Args:
            options (iguazio.schemas.v1.resources.event_activation.GetEventActivationOptions):
                Options for getting the event activation, including id.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivation:
                The event activation.
        """
        serialized_options = options.to_dict()
        # Extract id from options for path parameter
        activation_id = serialized_options.pop("id")
        # The gRPC proxy will extract {id} from the path and map it to the proto message
        response = self._request(
            "get",
            f"/events/activations/{activation_id}",
            params=serialized_options if serialized_options else None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivation
        )

    def get_event_activations_summary(
        self,
        options: event_activation_schema.GetEventActivationsSummaryOptions = None,
    ) -> event_activation_schema.EventActivationSummary:
        """
        Get event activations summary grouped by severity for the last 24 hours.

        Returns aggregated counts of event activations grouped by severity level
        (e.g., critical, major, warning, info, debug). Results can be filtered by event kind.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # Get summary for all events
            summary = client.get_event_activations_summary()

            # Get summary for system events only
            options = iguazio.schemas.GetEventActivationsSummaryOptions(
                kind="system"
            )
            summary = client.get_event_activations_summary(options)
            print(summary.status.counters_by_severity)  # {"critical": 5, "major": 10, ...}

        Args:
            options (iguazio.schemas.v1.resources.event_activation.GetEventActivationsSummaryOptions, optional):
                Options for filtering the summary. If not provided, returns summary for all events.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivationSummary:
                Summary with counters_by_severity map.
        """
        if options is None:
            options = event_activation_schema.GetEventActivationsSummaryOptions()
        response = self._request(
            "get",
            "/events/activations-summary",
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivationSummary
        )

    def create_event_config(
        self,
        options: event_config_schema.CreateEventConfigOptions,
    ) -> event_config_schema.EventConfig:
        """
        Create a new user-defined event configuration.

        User-created configs always have revision=0. Creating a config for an already
        predefined event (revision >= 1) or an existing user-created config is rejected
        with a conflict error.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            config = client.create_event_config(
                iguazio.schemas.CreateEventConfigOptions(
                    name="my_custom_event",
                    kind="system",
                    severity=iguazio.schemas.Severity.WARNING,
                    class_="custom",
                    description="My custom event",
                    visibility="external",
                )
            )

            # With threshold
            config = client.create_event_config(
                iguazio.schemas.CreateEventConfigOptions(
                    name="rate_limited_event",
                    kind="system",
                    severity=iguazio.schemas.Severity.MAJOR,
                    details=iguazio.schemas.EventConfigDetails(
                        threshold=iguazio.schemas.EventConfigThreshold(
                            count=10,
                            window="5m",
                        ),
                    ),
                )
            )

        Args:
            options (iguazio.schemas.v1.resources.event_config.CreateEventConfigOptions):
                Options for creating the event config.

        Returns:
            iguazio.schemas.v1.resources.event_config.EventConfig:
                The created event configuration.

        Raises:
            ValueError: If options is empty.
        """
        if not options:
            raise ValueError("options is required")
        response = self._request(
            "post",
            "/events/configs",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_config_schema.EventConfig
        )

    def delete_event_config(
        self,
        options: event_config_schema.DeleteEventConfigOptions,
    ) -> None:
        """
        Delete a user-created event configuration.

        Only user-created configs (revision=0) can be deleted. Attempting to delete
        a predefined config (revision >= 1) results in a bad request error.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.delete_event_config(
                iguazio.schemas.DeleteEventConfigOptions(name="my_custom_event")
            )

        Args:
            options (iguazio.schemas.v1.resources.event_config.DeleteEventConfigOptions):
                Options for deleting the event config, including name.

        Raises:
            ValueError: If options is empty.
        """
        if not options:
            raise ValueError("options is required")
        self._request(
            "delete",
            f"/events/configs/{options.name}",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def update_event_config(
        self,
        options: event_config_schema.UpdateEventConfigOptions,
    ) -> event_config_schema.EventConfig:
        """
        Update user-modifiable fields of an event configuration.

        Supports updating the visibility of an event config ("internal" or "external")
        and optionally setting a threshold. When a threshold is set, rules and
        actions for this config are only triggered once the event count reaches
        the threshold within the given time window.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # Update visibility only
            updated_config = client.update_event_config(
                iguazio.schemas.UpdateEventConfigOptions(
                    name="user_login",
                    visibility="internal",
                )
            )

            # Set a threshold only (without changing visibility)
            updated_config = client.update_event_config(
                iguazio.schemas.UpdateEventConfigOptions(
                    name="user_login",
                    threshold=iguazio.schemas.EventConfigThreshold(
                        count=10,
                        window="1m",
                    ),
                )
            )

        Args:
            options (iguazio.schemas.v1.resources.event_config.UpdateEventConfigOptions):
                Options for updating the event config, including name.

        Returns:
            iguazio.schemas.v1.resources.event_config.EventConfig:
                The updated event configuration.

        Raises:
            ValueError: If options is empty.
        """
        if not options:
            raise ValueError("options is required")
        serialized_options = options.to_dict()
        config_name = serialized_options.pop("name")
        response = self._request(
            "put",
            f"/events/configs/{config_name}",
            json=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_config_schema.EventConfig
        )

    def get_event_config(
        self,
        options: event_config_schema.GetEventConfigOptions,
    ) -> event_config_schema.EventConfig:
        """
        Get a single event configuration by name.

        Args:
            options (iguazio.schemas.v1.resources.event_config.GetEventConfigOptions):
                Options for getting the event config, including name.

        Returns:
            iguazio.schemas.v1.resources.event_config.EventConfig:
                The event configuration.
        """
        serialized_options = options.to_dict()
        config_name = serialized_options.pop("name")
        response = self._request(
            "get",
            f"/events/configs/{config_name}",
            params=serialized_options if serialized_options else None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_config_schema.EventConfig
        )

    def list_event_configs(
        self,
        options: event_config_schema.ListEventConfigsOptions = None,
        get_all: bool = False,
        batch_size: int = 100,
    ) -> event_config_schema.EventConfigList:
        """
        List event configurations in the Iguazio system.

        Event configurations define the catalog of known events, including their kind,
        severity, class, and visibility. Results are filtered by the caller's authorized
        visibilities (internal/external).

        Configurations can be filtered by kind ("audit" or "system") and ordered by
        name, severity, class, created_at, or updated_at.

        **Important: Pagination Limits**

        - Default limit when not specified: 100 configs per request
        - Maximum limit per request: 1,000 configs
        - If you have more than 100 configs, use ``get_all=True`` to automatically
          paginate through all results

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # List configs with default limit (100)
            configs = client.list_event_configs()

            # Get ALL configs automatically
            all_configs = client.list_event_configs(get_all=True)
            print(f"Total configs: {len(all_configs.items)}")

            # Filter by kind
            options = iguazio.schemas.ListEventConfigsOptions(
                kind="system",
                offset=0,
                limit=50,
            )
            configs = client.list_event_configs(options)

            # Custom ordering
            options = iguazio.schemas.ListEventConfigsOptions(
                order_by=[iguazio.schemas.OrderBySpec(
                    field="severity",
                    direction=iguazio.schemas.OrderByDirection.DESC,
                )]
            )
            configs = client.list_event_configs(options)

            # Filter by threshold presence
            configs_with_threshold = client.list_event_configs(
                iguazio.schemas.ListEventConfigsOptions(with_threshold=True)
            )

        Args:
            options (iguazio.schemas.v1.resources.event_config.ListEventConfigsOptions, optional):
                Options for listing event configs. If not provided, uses default pagination
                (offset=0, limit=100). Maximum limit per request is 1,000.
            get_all (bool, optional):
                If True, automatically paginate through all results across multiple requests.
                Defaults to False.
            batch_size (int, optional):
                When get_all=True, the number of configs to fetch per request.
                Defaults to 100. Must be between 1 and 1,000.
                Ignored when get_all=False.

        Returns:
            iguazio.schemas.v1.resources.event_config.EventConfigList:
                A list of event configurations matching the criteria.
        """
        options = options or event_config_schema.ListEventConfigsOptions()
        if get_all:
            if batch_size < 1 or batch_size > 1000:
                raise ValueError(
                    f"batch_size must be between 1 and 1,000, got {batch_size}"
                )

            all_items = self.fetch_all_pages(
                lambda batch_opts: self.list_event_configs(
                    options=batch_opts, get_all=False
                ),
                options,
                batch_size,
            )

            return event_config_schema.EventConfigList(items=all_items)
        else:
            response = self._request(
                "get",
                "/events/configs",
                params=options.to_query_params(),
                expected_status_codes=[http.HTTPStatus.OK],
            )
            return iguazio.schemas.serializer.deserialize(
                response, event_config_schema.EventConfigList
            )

    def get_event_configs_summary(
        self,
        options: event_config_schema.GetEventConfigsSummaryOptions = None,
    ) -> event_config_schema.EventConfigSummary:
        """
        Get event configurations summary with counts grouped by visibility.

        Args:
            options (iguazio.schemas.v1.resources.event_config.GetEventConfigsSummaryOptions, optional):
                Options for filtering the summary (e.g., by kind).

        Returns:
            iguazio.schemas.v1.resources.event_config.EventConfigSummary:
                Summary with counters map (e.g., {"external": 5, "internal": 3}).
        """
        if options is None:
            options = event_config_schema.GetEventConfigsSummaryOptions()
        response = self._request(
            "get",
            "/events/configs-summary",
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_config_schema.EventConfigSummary
        )
