# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.service_health as service_health_schema


class MonitoringClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio monitoring API v1.

    This client provides methods for health checking and monitoring operations.
    """

    def check_health(self) -> service_health_schema.ServiceHealthList:
        """
        Perform a health check on the monitoring service.

        Returns the current status of all monitored services, including their
        health state, group, and resource information.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            response = client.check_health()
            for service in response.items:
                print(f"{service.spec.name}: {service.status.state.value}")

        Returns:
            iguazio.schemas.v1.resources.service_health.ServiceHealthList: The service health list response.
        """
        response = self._request(
            "get",
            "/monitoring/health",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, service_health_schema.ServiceHealthList
        )
