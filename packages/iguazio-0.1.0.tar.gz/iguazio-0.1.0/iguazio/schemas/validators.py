# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


import typing
import re


def validate_email(email: typing.Optional[str] = None) -> None:
    """
    Validate the format of an email address.
    Raises ValueError if the email format is invalid.

    Args:
        email (str, optional): The email address to validate. If None, no validation is performed.

    Raises:
        ValueError: If the email format is invalid.
    """
    email_regex = r"[^@]+@[^@]+\.[^@]+$"
    if email and not bool(re.match(email_regex, email)):
        raise ValueError(f"Invalid email format: {email}")
