# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


import dataclasses
import datetime
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base
import iguazio.schemas.v1.resources.event_activation as event_activation_schema


@igz_schema.igz_dataclass
class EventConfigThreshold(igz_schema.IGZSchema):
    """
    Threshold for an event config.

    When set, rules and actions for this config are only triggered once
    the event count reaches the threshold within the given window.

    Args:
        count (int): Required number of occurrences to trigger rules/actions.
        window (str, optional): Duration string for the time window
            (e.g. "30s", "5m", "1h"). Validated by the backend using
            Go's time.ParseDuration.
    """

    count: int
    window: typing.Optional[str] = None


@igz_schema.igz_dataclass
class EventConfigDetails(igz_schema.IGZSchema):
    """
    Optional structured configuration for an event config.

    Args:
        threshold (EventConfigThreshold, optional): Optional threshold.
    """

    threshold: typing.Optional[EventConfigThreshold] = None


@igz_schema.igz_dataclass
class EventConfigMetadata(base.BaseMetadata):
    """
    Metadata for an event configuration.

    Args:
        name (str): Unique event config name (e.g., "user_login").
    """

    name: str = ""


@igz_schema.igz_dataclass
class EventConfigSpec(base.BaseSpec):
    """
    Specification for an event configuration.

    Args:
        kind (str): Event kind ("audit" or "system").
        severity (Severity): Severity level of the event.
        class_ (str): Event class (e.g., "authentication", "authorization").
        description (str): Human-readable description.
        details (EventConfigDetails, optional): Optional structured configuration.
    """

    kind: str = ""
    severity: event_activation_schema.Severity = (
        event_activation_schema.Severity.UNSPECIFIED
    )
    class_: str = dataclasses.field(default="", metadata={"json_key": "class"})
    description: str = ""
    details: typing.Optional[EventConfigDetails] = None


@igz_schema.igz_dataclass
class EventConfigStatus(base.BaseStatus):
    """
    Status for an event configuration.

    Args:
        revision (int): Version number for tracking config upgrades.
        created_at (datetime.datetime, optional): When the config was created.
        updated_at (datetime.datetime, optional): When the config was last updated.
        visibility (str): Visibility level ("internal" or "external").
    """

    revision: int = 0
    created_at: typing.Optional[datetime.datetime] = None
    updated_at: typing.Optional[datetime.datetime] = None
    visibility: str = ""


@igz_schema.igz_dataclass
class EventConfig(igz_schema.IGZSchema):
    """
    An event configuration in Iguazio.

    Args:
        metadata (EventConfigMetadata): Metadata for the event config, including the name.
        spec (EventConfigSpec): Specification for the event config.
        status (EventConfigStatus, optional): Status of the event config.
    """

    metadata: EventConfigMetadata = dataclasses.field(
        default_factory=EventConfigMetadata
    )
    spec: EventConfigSpec = dataclasses.field(default_factory=EventConfigSpec)
    status: EventConfigStatus = dataclasses.field(default_factory=EventConfigStatus)


@igz_schema.igz_dataclass
class GetEventConfigOptions(igz_schema.IGZSchema):
    """
    Options for getting a single event configuration.

    Args:
        name (str): The unique name of the event configuration.
    """

    name: str = ""


@igz_schema.igz_dataclass
class ListEventConfigsOptions(igz_schema.IGZSchema):
    """
    Options for listing event configurations.

    Args:
        kind (str, optional): Filter by event kind ("audit" or "system").
        offset (int, optional): Starting index (0-based). Defaults to 0.
        limit (int, optional): Maximum results to return. Defaults to 100.
        order_by (list[base.OrderBySpec], optional): List of order by specifications.
            Supports multi-column ordering (e.g., name ASC, created_at DESC).
            If empty, defaults to name ASC.
        name (str, optional): Substring filter on config name. Use "~prefix" for substring match.
        severity (list[Severity], optional): Filter by severity (multi-value). Can specify multiple Severity enum values.
        class_ (str, optional): Substring filter on class. Use "~prefix" for substring match.
        visibility (str, optional): Filter by visibility ("internal" or "external").
        with_threshold (bool, optional): Filter by threshold presence. True returns only configs
            with a threshold configured, False returns only configs without one.
    """

    kind: str = ""
    offset: typing.Optional[int] = None
    limit: typing.Optional[int] = None
    order_by: typing.Optional[list[base.OrderBySpec]] = None
    name: str = ""
    severity: typing.Optional[list[event_activation_schema.Severity]] = None
    class_: str = dataclasses.field(default="", metadata={"json_key": "class"})
    visibility: str = ""
    with_threshold: typing.Optional[bool] = None


@igz_schema.igz_dataclass
class EventConfigListStatus(base.BaseListStatus):
    """
    Status for a list of event configurations.
    """

    pass


@igz_schema.igz_dataclass
class EventConfigList(igz_schema.IGZSchema):
    """
    A list of event configurations in Iguazio.

    Args:
        items (list[EventConfig]): List of event configurations.
        status (EventConfigListStatus): Status of the list response.
    """

    items: typing.List[EventConfig] = dataclasses.field(default_factory=list)
    status: EventConfigListStatus = dataclasses.field(
        default_factory=EventConfigListStatus
    )


@igz_schema.igz_dataclass
class UpdateEventConfigOptions(igz_schema.IGZSchema):
    """
    Options for updating user-modifiable fields of an event configuration.

    Args:
        name (str): The unique name of the event configuration to update.
        visibility (str, optional): New visibility level ("internal" or "external").
        threshold (EventConfigThreshold, optional): Threshold to set.
            When provided, rules and actions for this config are only triggered
            once the event count reaches the threshold within the given window.
    """

    name: str = ""
    visibility: typing.Optional[str] = None
    threshold: typing.Optional[EventConfigThreshold] = None


@igz_schema.igz_dataclass
class CreateEventConfigOptions(igz_schema.IGZSchema):
    """
    Options for creating a new user-defined event configuration.

    User-created configs always have revision=0. Creating a config for an already
    predefined event (revision >= 1) or an existing user-created config is rejected.

    Args:
        name (str): Unique event config name (e.g., "my_custom_event").
        kind (str): Event kind ("audit" or "system").
        severity (Severity): Severity level of the event.
        class_ (str): Event class (e.g., "authentication", "authorization").
        description (str, optional): Human-readable description.
        visibility (str): Visibility level ("internal" or "external"). Defaults to "external".
        details (EventConfigDetails, optional): Optional structured configuration (e.g., thresholds).
    """

    name: str
    kind: str
    severity: event_activation_schema.Severity
    class_: str = dataclasses.field(metadata={"json_key": "class"})
    description: typing.Optional[str] = None
    visibility: str = "external"
    details: typing.Optional[EventConfigDetails] = None


@igz_schema.igz_dataclass
class DeleteEventConfigOptions(igz_schema.IGZSchema):
    """
    Options for deleting a user-created event configuration.

    Only user-created configs (revision=0) can be deleted.
    Predefined configs (revision >= 1) cannot be deleted.

    Args:
        name (str): The unique name of the event configuration to delete.
    """

    name: str


@igz_schema.igz_dataclass
class GetEventConfigsSummaryOptions(igz_schema.IGZSchema):
    """
    Options for getting event configurations summary.

    Args:
        kind (str, optional): Filter by event kind ("audit" or "system").
    """

    kind: str = ""


@igz_schema.igz_dataclass
class EventConfigSummaryStatus(base.BaseStatus):
    """
    Status for event config summary.

    Args:
        counters (dict[str, int]): Counts of configs grouped by visibility.
    """

    counters: typing.Dict[str, int] = dataclasses.field(default_factory=dict)


@igz_schema.igz_dataclass
class EventConfigSummary(igz_schema.IGZSchema):
    """
    Event config counts grouped by visibility.

    Args:
        status (EventConfigSummaryStatus): Status containing counters.
    """

    status: EventConfigSummaryStatus = dataclasses.field(
        default_factory=EventConfigSummaryStatus
    )
