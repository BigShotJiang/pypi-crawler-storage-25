# Copyright © 2026 Iguazio Systems LTD. All rights reserved.


import dataclasses
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base

__override_docs_title__ = "System Info"


class ServingStatus(enum.StrEnum):
    """
    Enum representing the serving status of a service.
    """

    UNKNOWN = "UNKNOWN"
    SERVING = "SERVING"
    NOT_SERVING = "NOT_SERVING"
    SERVICE_UNKNOWN = "SERVICE_UNKNOWN"


@igz_schema.igz_dataclass
class ServiceState(igz_schema.IGZSchema):
    """
    Represents the state of a service.
    This class encapsulates the serving status of a service.

    Args:
        status (ServingStatus): The serving status of the service.
    """

    status: ServingStatus


@igz_schema.igz_dataclass
class SystemVersion(igz_schema.IGZSchema):
    """
    Represents the version information of the system.
    This class encapsulates the version string.

    Args:
        iguazio_version (str): The Iguazio version string.
        build_date (str, optional): The build date of the system.
        branch (str, optional): The branch name of the system.
        commit (str, optional): The commit hash of the system.
        images_config_sha (str, optional): The SHA of the images configuration.
    """

    iguazio_version: str
    build_date: typing.Optional[str] = None
    branch: typing.Optional[str] = None
    commit: typing.Optional[str] = None
    images_config_sha: typing.Optional[str] = None


@igz_schema.igz_dataclass
class KeycloakMetadata(igz_schema.IGZSchema):
    """
    Represents Keycloak metadata information.

    Args:
        host_address (str): The Keycloak host address.
        realm (str): The Keycloak realm.
    """

    host_address: str
    realm: str


@igz_schema.igz_dataclass
class SystemRegistry(igz_schema.IGZSchema):
    """
    Represents the system registry information.

    Args:
        user (str): The user registry url.
        system (str): The system registry url.
    """

    user: str
    system: str


@igz_schema.igz_dataclass
class SystemInfoMetadata(base.BaseMetadata):
    """
    Metadata for System Info in Iguazio.
    This class extends BaseMetadata and can be used to define user-specific metadata attributes.

    Args:
        domain (str): Domain of the system.
        namespace (str): Namespace of the system.
        version (SystemVersion): System version information.
        keycloak (KeycloakMetadata): Keycloak metadata information.
        registry (SystemRegistry): System registry information.
    """

    domain: str
    namespace: str
    version: SystemVersion
    keycloak: KeycloakMetadata
    registry: SystemRegistry


@igz_schema.igz_dataclass
class SystemInfoSpec(base.BaseSpec):
    """
    System Info specification in Iguazio.
    This class defines the configuration required for the System Info.
    """

    pass


@igz_schema.igz_dataclass
class SystemInfoStatus(base.BaseStatus):
    """
    System Info status in Iguazio.
    This class represents the current status of various services in the system.

    Args:
        services (dict[str, ServiceState]): A dictionary mapping service names to their serving state.
    """

    services: dict[str, ServiceState] = dataclasses.field(default_factory=dict)


@igz_schema.igz_dataclass
class SystemInfo(igz_schema.IGZSchema):
    """
    Represents an Iguazio System Info resource.
    This class combines metadata, specification, and status for the System Information.

    Args:
        metadata (SystemInfoMetadata): Metadata for the System Info, encapsulated in SystemInfoMetadata.
        spec (SystemInfoSpec): Specification for the System Info, encapsulated in SystemInfoSpec.
        status (SystemInfoStatus): Status of the System Info, encapsulated in SystemInfoStatus.
        relationships (list[igz_schema.IGZSchema], optional): Optional relationships associated with the System Info.
    """

    metadata: SystemInfoMetadata = dataclasses.field(default_factory=SystemInfoMetadata)
    spec: SystemInfoSpec = dataclasses.field(default_factory=SystemInfoSpec)
    status: SystemInfoStatus = dataclasses.field(default_factory=SystemInfoStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None
