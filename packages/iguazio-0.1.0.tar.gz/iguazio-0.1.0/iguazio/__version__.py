# Copyright © 2026 Iguazio Systems LTD. All rights reserved.

__version__ = "0.1.0"
