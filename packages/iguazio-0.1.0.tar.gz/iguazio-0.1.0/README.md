# iguazio - Management API SDK

Python SDK for Iguazio 4 Management API

## Installation

```console
pip install iguazio
```

## Documentation

[iguazio.github.io/orca/](https://iguazio.github.io/orca/)
