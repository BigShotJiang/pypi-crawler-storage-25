"""Typography components."""

from typing import Any, Literal

from refast.components.base import Component


class Heading(Component):
    """
    Heading component for titles.

    Example:
        ```python
        Heading("Welcome", level=1)
        Heading("Section Title", level=2, class_name="text-blue-500")
        ```
    """

    component_type: str = "Heading"

    def __init__(
        self,
        text: str,
        level: Literal[1, 2, 3, 4, 5, 6] = 1,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.text = text
        self.level = level
        self.style = style

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "level": self.level,
                "class_name": self.class_name,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [self.text],
        }


class Paragraph(Component):
    """Paragraph text component."""

    component_type: str = "Paragraph"

    def __init__(
        self,
        text: str,
        lead: bool = False,
        muted: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.text = text
        self.lead = lead
        self.muted = muted
        self.style = style

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "lead": self.lead,
                "muted": self.muted,
                "class_name": self.class_name,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [self.text],
        }


class Code(Component):
    """Code display component with optional syntax highlighting.

    Args:
        code: The code content to display.
        language: Programming language for syntax highlighting (e.g., 'python', 'javascript').
        inline: If True (default), renders as inline code. If False, renders as a code block.
        id: Optional component ID.
        class_name: Optional CSS class name.
        style: Optional inline styles as a dictionary.
    """

    component_type: str = "Code"

    def __init__(
        self,
        code: str,
        language: str | None = None,
        inline: bool = True,
        show_line_numbers: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.show_line_numbers = show_line_numbers
        self.code = code
        self.language = language
        self.style = style
        self.inline = inline

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "language": self.language,
                "inline": self.inline,
                "show_line_numbers": self.show_line_numbers,
                "class_name": self.class_name,
                "code": self.code,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [],
        }


class Link(Component):
    """Link component for navigation."""

    component_type: str = "Link"

    def __init__(
        self,
        text: str,
        href: str,
        target: Literal["_self", "_blank", "_parent", "_top"] = "_self",
        on_click: Any = None,
        external: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.text = text
        self.href = href
        self.target = target
        self.external = external
        self.style = style
        self.on_click = on_click

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "href": self.href,
                "target": self.target,
                "external": self.external,
                "on_click": self.on_click.serialize() if self.on_click else None,
                "class_name": self.class_name,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [self.text],
        }


class Markdown(Component):
    """
    Markdown component with GitHub Flavored Markdown (GFM) support.

    Renders Markdown content with GFM features including tables,
    strikethrough, task lists, and syntax-highlighted code blocks.

    Example:
        ```python
        Markdown(
            content=\"\"\"
            # Hello World

            This is **bold** and *italic* text.

            ```python
            print("Hello!")
            ```
            \"\"\",
        )
        ```

    Args:
        content: The Markdown content to render.
        allow_html: Whether to allow raw HTML in markdown (default False for security).
        enable_mermaid: Enable Mermaid diagram rendering for fenced ```mermaid blocks.
            The Mermaid library is loaded on demand only when this is True.
        enable_latex: Enable LaTeX / KaTeX math rendering ($..$ and $$..$$).
            The KaTeX library is loaded on demand only when this is True.
    """

    component_type: str = "Markdown"

    def __init__(
        self,
        content: str,
        allow_html: bool = False,
        enable_mermaid: bool = False,
        enable_latex: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.content = content
        self.allow_html = allow_html
        self.enable_mermaid = enable_mermaid
        self.enable_latex = enable_latex
        self.style = style

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "content": self.content,
                "allow_html": self.allow_html,
                "enable_mermaid": self.enable_mermaid,
                "enable_latex": self.enable_latex,
                "class_name": self.class_name,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [],
        }


class BlockQuote(Component):
    """
    Blockquote component for quoted text.

    Example:
        ```python
        BlockQuote("To be or not to be.", cite="Hamlet")
        BlockQuote("Premature optimisation is the root of all evil.")
        ```

    Args:
        text: The quoted text content.
        cite: Optional URL or reference for the quote source.
        id: Optional component ID.
        class_name: Optional CSS class name.
        style: Optional inline styles as a dictionary.
    """

    component_type: str = "BlockQuote"

    def __init__(
        self,
        text: str,
        cite: str | None = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.text = text
        self.cite = cite
        self.style = style

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "cite": self.cite,
                "class_name": self.class_name,
                "style": self.style,
                **self._serialize_extra_props(),
            },
            "children": [self.text],
        }
