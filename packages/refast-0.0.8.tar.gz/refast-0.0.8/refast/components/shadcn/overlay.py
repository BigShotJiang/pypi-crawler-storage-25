"""Overlay components based on shadcn/ui."""

from typing import Any, Literal

from refast.components.base import ChildrenType, Component


class Dialog(Component):
    """
    A modal dialog that interrupts the user with important content.

    Example:
        ```python
        Dialog(
            open=show_dialog,
            on_open_change=ctx.callback(handle_dialog_change),
            children=[
                DialogTrigger(Button("Delete")),
                DialogContent(
                    DialogHeader(
                        DialogTitle("Are you absolutely sure?"),
                        DialogDescription("This action cannot be undone."),
                    ),
                    DialogFooter(
                        DialogCancel("Cancel"),
                        DialogAction("Continue"),
                    ),
                ),
            ]
        )
        ```
    """

    component_type: str = "Dialog"

    def __init__(
        self,
        open: bool | None = None,
        default_open: bool = False,
        on_open_change: Any = None,
        title: str | None = None,
        description: str | None = None,
        confirm_label: str = "Continue",
        cancel_label: str = "Cancel",
        on_confirm: Any = None,
        on_cancel: Any = None,
        trigger: Any = None,
        variant: Literal["default", "destructive"] = "default",
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.default_open = default_open
        self.on_open_change = on_open_change
        self.title = title
        self.description = description
        self.confirm_label = confirm_label
        self.cancel_label = cancel_label
        self.on_confirm = on_confirm
        self.on_cancel = on_cancel
        self.trigger = trigger
        self.variant = variant
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "default_open": self.default_open,
            "confirm_label": self.confirm_label,
            "cancel_label": self.cancel_label,
            "variant": self.variant,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()
        if self.title is not None:
            props["title"] = self.title
        if self.description is not None:
            props["description"] = self.description
        if self.on_confirm:
            props["on_confirm"] = self.on_confirm.serialize()
        if self.on_cancel:
            props["on_cancel"] = self.on_cancel.serialize()
        if self.trigger is not None:
            props["trigger"] = (
                self.trigger.render() if hasattr(self.trigger, "render") else self.trigger
            )

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class DialogTrigger(Component):
    """The button that opens the alert dialog."""

    component_type: str = "DialogTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DialogContent(Component):
    """The content of the alert dialog."""

    component_type: str = "DialogContent"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DialogHeader(Component):
    """The header section of the alert dialog."""

    component_type: str = "DialogHeader"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DialogFooter(Component):
    """The footer section of the alert dialog."""

    component_type: str = "DialogFooter"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DialogTitle(Component):
    """The title of the alert dialog."""

    component_type: str = "DialogTitle"

    def __init__(
        self,
        title: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.title = title

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.title],
        }


class DialogDescription(Component):
    """The description of the alert dialog."""

    component_type: str = "DialogDescription"

    def __init__(
        self,
        description: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.description = description

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.description],
        }


class DialogAction(Component):
    """The confirm action button."""

    component_type: str = "DialogAction"

    def __init__(
        self,
        label: str,
        on_click: Any = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.on_click = on_click

    def render(self) -> dict[str, Any]:
        props = {
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_click:
            props["on_click"] = self.on_click.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class DialogCancel(Component):
    """The cancel action button."""

    component_type: str = "DialogCancel"

    def __init__(
        self,
        label: str = "Cancel",
        on_click: Any = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.on_click = on_click

    def render(self) -> dict[str, Any]:
        props = {
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_click:
            props["on_click"] = self.on_click.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class Sheet(Component):
    """
    A panel that slides out from the edge of the screen.

    Example:
        ```python
        Sheet(
            side="right",
            children=[
                SheetTrigger(Button("Open")),
                SheetContent(
                    SheetHeader(
                        SheetTitle("Edit Profile"),
                        SheetDescription("Make changes to your profile."),
                    ),
                    # Form content
                    SheetFooter(Button("Save changes")),
                ),
            ]
        )
        ```
    """

    component_type: str = "Sheet"

    def __init__(
        self,
        open: bool | None = None,
        default_open: bool = False,
        on_open_change: Any = None,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.default_open = default_open
        self.on_open_change = on_open_change
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "default_open": self.default_open,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class SheetTrigger(Component):
    """The button that opens the sheet."""

    component_type: str = "SheetTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class SheetClose(Component):
    """A button to close the sheet."""

    component_type: str = "SheetClose"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class SheetContent(Component):
    """The content of the sheet."""

    component_type: str = "SheetContent"

    def __init__(
        self,
        children: ChildrenType = None,
        side: Literal["top", "right", "bottom", "left"] = "right",
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.side = side
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "side": self.side,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class SheetHeader(Component):
    """The header section of the sheet."""

    component_type: str = "SheetHeader"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class SheetFooter(Component):
    """The footer section of the sheet."""

    component_type: str = "SheetFooter"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class SheetTitle(Component):
    """The title of the sheet."""

    component_type: str = "SheetTitle"

    def __init__(
        self,
        title: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.title = title

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.title],
        }


class SheetDescription(Component):
    """The description of the sheet."""

    component_type: str = "SheetDescription"

    def __init__(
        self,
        description: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.description = description

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.description],
        }


class Popover(Component):
    """
    Displays rich content in a portal, triggered by a button.

    Example:
        ```python
        Popover(
            children=[
                PopoverTrigger(Button("Open popover")),
                PopoverContent(
                    Heading("Dimensions", level=4),
                    Paragraph("Set the dimensions."),
                ),
            ]
        )
        ```
    """

    component_type: str = "Popover"

    def __init__(
        self,
        open: bool | None = None,
        default_open: bool = False,
        on_open_change: Any = None,
        trigger: Any = None,
        side: Literal["top", "right", "bottom", "left"] = "bottom",
        align: Literal["start", "center", "end"] = "center",
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.default_open = default_open
        self.on_open_change = on_open_change
        self.trigger = trigger
        self.side = side
        self.align = align
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "default_open": self.default_open,
            "side": self.side,
            "align": self.align,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()
        if self.trigger is not None:
            props["trigger"] = (
                self.trigger.render() if hasattr(self.trigger, "render") else self.trigger
            )

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class PopoverTrigger(Component):
    """The button that opens the popover."""

    component_type: str = "PopoverTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class PopoverContent(Component):
    """The content of the popover."""

    component_type: str = "PopoverContent"

    def __init__(
        self,
        children: ChildrenType = None,
        side: Literal["top", "right", "bottom", "left"] = "bottom",
        side_offset: int = 4,
        align: Literal["start", "center", "end"] = "center",
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.side = side
        self.side_offset = side_offset
        self.align = align
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "side": self.side,
                "side_offset": self.side_offset,
                "align": self.align,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class HoverCard(Component):
    """
    For sighted users to preview content behind a link.

    Example:
        ```python
        HoverCard(
            children=[
                HoverCardTrigger(Link("@shadcn", href="#")),
                HoverCardContent(
                    Avatar(src="...", alt="@shadcn"),
                ),
            ]
        )
        ```
    """

    component_type: str = "HoverCard"

    def __init__(
        self,
        open: bool | None = None,
        default_open: bool = False,
        on_open_change: Any = None,
        open_delay: int = 700,
        close_delay: int = 300,
        trigger: Any = None,
        side: Literal["top", "right", "bottom", "left"] = "bottom",
        align: Literal["start", "center", "end"] = "center",
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.default_open = default_open
        self.on_open_change = on_open_change
        self.open_delay = open_delay
        self.close_delay = close_delay
        self.trigger = trigger
        self.side = side
        self.align = align
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "default_open": self.default_open,
            "open_delay": self.open_delay,
            "close_delay": self.close_delay,
            "side": self.side,
            "align": self.align,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()
        if self.trigger is not None:
            props["trigger"] = (
                self.trigger.render() if hasattr(self.trigger, "render") else self.trigger
            )

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class HoverCardTrigger(Component):
    """The element that triggers the hover card."""

    component_type: str = "HoverCardTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class HoverCardContent(Component):
    """The content of the hover card."""

    component_type: str = "HoverCardContent"

    def __init__(
        self,
        children: ChildrenType = None,
        side: Literal["top", "right", "bottom", "left"] = "bottom",
        side_offset: int = 4,
        align: Literal["start", "center", "end"] = "center",
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.side = side
        self.side_offset = side_offset
        self.align = align
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "side": self.side,
                "side_offset": self.side_offset,
                "align": self.align,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DropdownMenu(Component):
    """
    Displays a menu to the user, triggered by a button.

    Example:
        ```python
        DropdownMenu(
            children=[
                DropdownMenuTrigger(Button("Open")),
                DropdownMenuContent(
                    DropdownMenuLabel("My Account"),
                    DropdownMenuSeparator(),
                    DropdownMenuItem("Profile", shortcut="⇧⌘P"),
                ),
            ]
        )
        ```
    """

    component_type: str = "DropdownMenu"

    def __init__(
        self,
        open: bool | None = None,
        default_open: bool = False,
        on_open_change: Any = None,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.default_open = default_open
        self.on_open_change = on_open_change
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "default_open": self.default_open,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class DropdownMenuTrigger(Component):
    """The button that opens the dropdown menu."""

    component_type: str = "DropdownMenuTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DropdownMenuContent(Component):
    """The content of the dropdown menu."""

    component_type: str = "DropdownMenuContent"

    def __init__(
        self,
        children: ChildrenType = None,
        side: Literal["top", "right", "bottom", "left"] = "bottom",
        side_offset: int = 4,
        align: Literal["start", "center", "end"] = "start",
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.side = side
        self.side_offset = side_offset
        self.align = align
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "side": self.side,
                "side_offset": self.side_offset,
                "align": self.align,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DropdownMenuItem(Component):
    """A menu item in the dropdown."""

    component_type: str = "DropdownMenuItem"

    def __init__(
        self,
        label: str,
        icon: str | None = None,
        shortcut: str | None = None,
        disabled: bool = False,
        on_select: Any = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.icon = icon
        self.shortcut = shortcut
        self.disabled = disabled
        self.on_select = on_select

    def render(self) -> dict[str, Any]:
        props = {
            "icon": self.icon,
            "shortcut": self.shortcut,
            "disabled": self.disabled,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_select:
            props["on_select"] = self.on_select.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class DropdownMenuLabel(Component):
    """A label in the dropdown menu."""

    component_type: str = "DropdownMenuLabel"

    def __init__(
        self,
        label: str,
        inset: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.inset = inset

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "inset": self.inset,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.label],
        }


class DropdownMenuSeparator(Component):
    """A separator line in the dropdown menu."""

    component_type: str = "DropdownMenuSeparator"

    def __init__(
        self,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [],
        }


class DropdownMenuCheckboxItem(Component):
    """A checkbox item in the dropdown menu."""

    component_type: str = "DropdownMenuCheckboxItem"

    def __init__(
        self,
        label: str,
        checked: bool = False,
        on_checked_change: Any = None,
        disabled: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.checked = checked
        self.on_checked_change = on_checked_change
        self.disabled = disabled

    def render(self) -> dict[str, Any]:
        props = {
            "checked": self.checked,
            "disabled": self.disabled,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_checked_change:
            props["on_checked_change"] = self.on_checked_change.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class DropdownMenuRadioGroup(Component):
    """A group of radio items in the dropdown menu."""

    component_type: str = "DropdownMenuRadioGroup"

    def __init__(
        self,
        value: str = "",
        on_value_change: Any = None,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.value = value
        self.on_value_change = on_value_change
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "value": self.value,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_value_change:
            props["on_value_change"] = self.on_value_change.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class DropdownMenuRadioItem(Component):
    """A radio item in the dropdown menu."""

    component_type: str = "DropdownMenuRadioItem"

    def __init__(
        self,
        label: str,
        value: str = "",
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.value = value

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "value": self.value,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.label],
        }


class DropdownMenuSub(Component):
    """A submenu container."""

    component_type: str = "DropdownMenuSub"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DropdownMenuSubTrigger(Component):
    """A trigger for a submenu."""

    component_type: str = "DropdownMenuSubTrigger"

    def __init__(
        self,
        label: str,
        icon: str | None = None,
        inset: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.icon = icon
        self.inset = inset

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "icon": self.icon,
                "inset": self.inset,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.label],
        }


class DropdownMenuSubContent(Component):
    """The content of a submenu."""

    component_type: str = "DropdownMenuSubContent"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class ContextMenu(Component):
    """
    Displays a menu on right-click.

    Example:
        ```python
        ContextMenu(
            children=[
                ContextMenuTrigger(
                    Container("Right click here", class_name="border p-10")
                ),
                ContextMenuContent(
                    ContextMenuItem("Back"),
                    ContextMenuItem("Forward"),
                ),
            ]
        )
        ```
    """

    component_type: str = "ContextMenu"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class ContextMenuTrigger(Component):
    """The element that triggers the context menu on right-click."""

    component_type: str = "ContextMenuTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class ContextMenuContent(Component):
    """The content of the context menu."""

    component_type: str = "ContextMenuContent"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class ContextMenuItem(Component):
    """A menu item in the context menu."""

    component_type: str = "ContextMenuItem"

    def __init__(
        self,
        label: str,
        icon: str | None = None,
        shortcut: str | None = None,
        disabled: bool = False,
        on_select: Any = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.icon = icon
        self.shortcut = shortcut
        self.disabled = disabled
        self.on_select = on_select

    def render(self) -> dict[str, Any]:
        props = {
            "icon": self.icon,
            "shortcut": self.shortcut,
            "disabled": self.disabled,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_select:
            props["on_select"] = self.on_select.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class ContextMenuSeparator(Component):
    """A separator in the context menu."""

    component_type: str = "ContextMenuSeparator"

    def __init__(
        self,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [],
        }


class ContextMenuCheckboxItem(Component):
    """A checkbox item in the context menu."""

    component_type: str = "ContextMenuCheckboxItem"

    def __init__(
        self,
        label: str,
        checked: bool = False,
        on_checked_change: Any = None,
        disabled: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.label = label
        self.checked = checked
        self.on_checked_change = on_checked_change
        self.disabled = disabled

    def render(self) -> dict[str, Any]:
        props = {
            "checked": self.checked,
            "disabled": self.disabled,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.on_checked_change:
            props["on_checked_change"] = self.on_checked_change.serialize()

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": [self.label],
        }


class Drawer(Component):
    """
    A drawer component for mobile (using Vaul).

    Example:
        ```python
        Drawer(
            children=[
                DrawerTrigger(Button("Open Drawer")),
                DrawerContent(
                    DrawerHeader(
                        DrawerTitle("Move Goal"),
                        DrawerDescription("Set your daily goal."),
                    ),
                    DrawerFooter(Button("Submit")),
                ),
            ]
        )
        ```
    """

    component_type: str = "Drawer"

    def __init__(
        self,
        open: bool | None = None,
        on_open_change: Any = None,
        should_scale_background: bool = True,
        title: str | None = None,
        description: str | None = None,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.open = open
        self.on_open_change = on_open_change
        self.should_scale_background = should_scale_background
        self.title = title
        self.description = description
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        props = {
            "should_scale_background": self.should_scale_background,
            "class_name": self.class_name,
            **self._serialize_extra_props(),
        }

        if self.open is not None:
            props["open"] = self.open
        if self.on_open_change:
            props["on_open_change"] = self.on_open_change.serialize()
        if self.title is not None:
            props["title"] = self.title
        if self.description is not None:
            props["description"] = self.description

        return {
            "type": self.component_type,
            "id": self.id,
            "props": props,
            "children": self._render_children(),
        }


class DrawerTrigger(Component):
    """The button that opens the drawer."""

    component_type: str = "DrawerTrigger"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DrawerContent(Component):
    """The content of the drawer."""

    component_type: str = "DrawerContent"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DrawerHeader(Component):
    """The header of the drawer."""

    component_type: str = "DrawerHeader"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DrawerFooter(Component):
    """The footer of the drawer."""

    component_type: str = "DrawerFooter"

    def __init__(
        self,
        children: ChildrenType = None,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }


class DrawerTitle(Component):
    """The title of the drawer."""

    component_type: str = "DrawerTitle"

    def __init__(
        self,
        title: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.title = title

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.title],
        }


class DrawerDescription(Component):
    """The description of the drawer."""

    component_type: str = "DrawerDescription"

    def __init__(
        self,
        description: str,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.description = description

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": [self.description],
        }


class DrawerClose(Component):
    """A button to close the drawer."""

    component_type: str = "DrawerClose"

    def __init__(
        self,
        children: ChildrenType = None,
        as_child: bool = False,
        id: str | None = None,
        class_name: str = "",
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(
            id=id,
            class_name=class_name,
            style=style,
            parent_style=parent_style,
            extra_props=extra_props,
        )
        self.as_child = as_child
        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "as_child": self.as_child,
                "class_name": self.class_name,
                **self._serialize_extra_props(),
            },
            "children": self._render_children(),
        }
