"""Radar chart components."""

from typing import Any

from refast.components.base import ChildrenType, Component


class RadarChart(Component):
    """
    Radar chart component.

    Example:
        ```python
        RadarChart(
            data=data,
            Radar(data_key="value", fill="hsl(var(--chart-1))"),
        )
        ```
    """

    component_type: str = "RadarChart"

    def __init__(
        self,
        data: list[dict[str, Any]],
        margin: dict[str, int] | None = None,
        cx: str | int = "50%",
        cy: str | int = "50%",
        inner_radius: int | str | None = None,
        outer_radius: int | str = "80%",
        start_angle: int = 90,
        end_angle: int = -270,
        children: ChildrenType = None,
        id: str | None = None,
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(id=id, extra_props=extra_props)
        self.data = data
        self.margin = margin or {"top": 0, "right": 0, "left": 0, "bottom": 0}
        self.cx = cx
        self.cy = cy
        self.inner_radius = inner_radius
        self.outer_radius = outer_radius
        self.start_angle = start_angle
        self.end_angle = end_angle

        self.add_children(children)

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "data": self.data,
                "margin": self.margin,
                "cx": self.cx,
                "cy": self.cy,
                "inner_radius": self.inner_radius,
                "outer_radius": self.outer_radius,
                "start_angle": self.start_angle,
                "end_angle": self.end_angle,
            },
            "children": self._render_children(),
        }


class Radar(Component):
    """
    Radar component for RadarChart.

    Args:
        data_key: Key from data
        fill: Fill color
        fill_opacity: Fill opacity
        stroke: Stroke color
        stroke_width: Stroke width
    """

    component_type: str = "Radar"

    def __init__(
        self,
        data_key: str,
        fill: str = "hsl(var(--chart-1))",
        fill_opacity: float = 0.6,
        stroke: str | None = None,
        stroke_width: int = 2,
        id: str | None = None,
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(id=id, extra_props=extra_props)
        self.data_key = data_key
        self.fill = fill
        self.fill_opacity = fill_opacity
        self.stroke = stroke or fill
        self.stroke_width = stroke_width
        self.props = extra_props or {}

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "data_key": self.data_key,
                "fill": self.fill,
                "fill_opacity": self.fill_opacity,
                "stroke": self.stroke,
                "stroke_width": self.stroke_width,
                **self.props,
            },
        }


class PolarGrid(Component):
    """Polar grid for RadarChart."""

    component_type: str = "PolarGrid"

    def __init__(
        self,
        id: str | None = None,
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(id=id, extra_props=extra_props)
        self.props = extra_props or {}

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": self.props,
        }


class PolarAngleAxis(Component):
    """Polar angle axis for RadarChart."""

    component_type: str = "PolarAngleAxis"

    def __init__(
        self,
        data_key: str | None = None,
        type: str = "category",
        tick: bool | dict[str, Any] = True,
        id: str | None = None,
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(id=id, extra_props=extra_props)
        self.data_key = data_key
        self.type = type
        self.tick = tick
        self.props = extra_props or {}

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "data_key": self.data_key,
                "type": self.type,
                "tick": self.tick,
                **self.props,
            },
        }


class PolarRadiusAxis(Component):
    """Polar radius axis for RadarChart/RadialBarChart."""

    component_type: str = "PolarRadiusAxis"

    def __init__(
        self,
        angle: int = 90,
        type: str = "number",
        tick: bool | dict[str, Any] = True,
        domain: list[int | str] | None = None,
        id: str | None = None,
        style: dict[str, Any] | None = None,
        parent_style: dict[str, Any] | None = None,
        extra_props: dict[str, Any] | None = None,
    ):
        super().__init__(id=id, extra_props=extra_props)
        self.angle = angle
        self.type = type
        self.tick = tick
        self.domain = domain
        self.props = extra_props or {}

    def render(self) -> dict[str, Any]:
        return {
            "type": self.component_type,
            "id": self.id,
            "props": {
                "angle": self.angle,
                "type": self.type,
                "tick": self.tick,
                "domain": self.domain,
                **self.props,
            },
        }
