import { l as a, m as r } from "./refast-charts-Be0RW0P2.js";
const i = a, l = r;
export {
  l as RadialBar,
  i as RadialBarChart
};
