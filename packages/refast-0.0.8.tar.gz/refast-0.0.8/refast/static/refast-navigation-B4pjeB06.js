import { ah as u, ay as r, cT as p, cU as k, cV as _, cW as z, cX as B, cY as I, cZ as y, c_ as E, c$ as T, d0 as W, d1 as D, d2 as P, d3 as G, d4 as R, d5 as O, d6 as H, d7 as A, d8 as K, d9 as V, da as F, db as $, dc as q } from "./refast-vendor-CQOdd5X6.js";
import { c as s, a as S } from "./refast-index-9fBfd4aX.js";
function te({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "nav",
    {
      id: t,
      "aria-label": "breadcrumb",
      className: a,
      "data-refast-id": n,
      children: /* @__PURE__ */ r.jsx("ol", { className: "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5", children: e })
    }
  );
}
function ae({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "ol",
    {
      id: t,
      className: s(
        "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function re({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "li",
    {
      id: t,
      className: s("inline-flex items-center gap-1.5", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function ne({
  id: t,
  className: a,
  href: e = "#",
  onClick: n,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsx(
    "a",
    {
      id: t,
      href: e,
      onClick: (o) => {
        n && (o.preventDefault(), n());
      },
      className: s("transition-colors hover:text-foreground", a),
      "data-refast-id": d,
      children: i
    }
  );
}
function se({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "span",
    {
      id: t,
      role: "link",
      "aria-disabled": "true",
      "aria-current": "page",
      className: s("font-normal text-foreground", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function ie({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "li",
    {
      id: t,
      role: "presentation",
      "aria-hidden": "true",
      className: s("[&>svg]:size-3.5", a),
      "data-refast-id": n,
      children: e || /* @__PURE__ */ r.jsx(
        "svg",
        {
          xmlns: "http://www.w3.org/2000/svg",
          width: "16",
          height: "16",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          children: /* @__PURE__ */ r.jsx("path", { d: "m9 18 6-6-6-6" })
        }
      )
    }
  );
}
function de({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  return /* @__PURE__ */ r.jsxs(
    "span",
    {
      id: t,
      role: "presentation",
      "aria-hidden": "true",
      className: s("flex h-9 w-9 items-center justify-center", a),
      "data-refast-id": e,
      children: [
        /* @__PURE__ */ r.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: [
              /* @__PURE__ */ r.jsx("circle", { cx: "12", cy: "12", r: "1" }),
              /* @__PURE__ */ r.jsx("circle", { cx: "19", cy: "12", r: "1" }),
              /* @__PURE__ */ r.jsx("circle", { cx: "5", cy: "12", r: "1" })
            ]
          }
        ),
        /* @__PURE__ */ r.jsx("span", { className: "sr-only", children: "More" })
      ]
    }
  );
}
function oe({
  id: t,
  className: a,
  orientation: e,
  children: n,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ r.jsxs(
    $,
    {
      id: t,
      orientation: e,
      className: s(
        "relative z-10 flex max-w-max flex-1 items-center justify-center",
        a
      ),
      "data-refast-id": i,
      children: [
        n,
        /* @__PURE__ */ r.jsx(U, {})
      ]
    }
  );
}
function U() {
  return /* @__PURE__ */ r.jsx("div", { className: "absolute left-0 top-full flex justify-center", children: /* @__PURE__ */ r.jsx(
    q,
    {
      className: s(
        "origin-top-center relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-lg",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90",
        "md:w-[var(--radix-navigation-menu-viewport-width)]"
      )
    }
  ) });
}
function le({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    F,
    {
      id: t,
      className: s(
        "group flex flex-1 list-none items-center justify-center space-x-1",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function ce({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    V,
    {
      id: t,
      className: a,
      "data-refast-id": n,
      children: e
    }
  );
}
function ue({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsxs(
    K,
    {
      id: t,
      className: s(
        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors",
        "hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none",
        "disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50",
        a
      ),
      "data-refast-id": n,
      children: [
        e,
        /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "relative top-[1px] ml-1 h-3 w-3 transition duration-200 group-data-[state=open]:rotate-180",
            "aria-hidden": "true",
            children: /* @__PURE__ */ r.jsx("path", { d: "m6 9 6 6 6-6" })
          }
        )
      ]
    }
  );
}
function fe({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    A,
    {
      id: t,
      className: s(
        "left-0 top-0 w-full data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out",
        "data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out",
        "data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52",
        "data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52",
        "md:absolute md:w-auto",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function me({
  id: t,
  className: a,
  href: e = "#",
  active: n,
  onClick: i,
  children: d,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ r.jsx(
    H,
    {
      id: t,
      href: e,
      active: n,
      onClick: (l) => {
        i && (l.preventDefault(), i());
      },
      className: s(
        "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors",
        "hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
        a
      ),
      "data-refast-id": o,
      children: d
    }
  );
}
function xe({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "nav",
    {
      id: t,
      role: "navigation",
      "aria-label": "pagination",
      className: s("mx-auto flex w-full justify-center", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function be({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "ul",
    {
      id: t,
      className: s("flex flex-row items-center gap-1", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function ge({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx("li", { id: t, className: a, "data-refast-id": n, children: e });
}
function pe({
  id: t,
  className: a,
  href: e = "#",
  active: n,
  onClick: i,
  children: d,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ r.jsx(
    "a",
    {
      id: t,
      href: e,
      onClick: (l) => {
        i && (l.preventDefault(), i());
      },
      "aria-current": n ? "page" : void 0,
      className: s(
        "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "h-10 w-10",
        n ? "border border-input bg-background hover:bg-accent hover:text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground",
        a
      ),
      "data-refast-id": o,
      children: d
    }
  );
}
function he({
  id: t,
  className: a,
  href: e = "#",
  onClick: n,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ r.jsxs(
    "a",
    {
      id: t,
      href: e,
      onClick: (d) => {
        n && (d.preventDefault(), n());
      },
      "aria-label": "Go to previous page",
      className: s(
        "inline-flex items-center justify-center gap-1 pl-2.5 pr-4 h-10 rounded-md text-sm font-medium",
        "hover:bg-accent hover:text-accent-foreground transition-colors",
        a
      ),
      "data-refast-id": i,
      children: [
        /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ r.jsx("path", { d: "m15 18-6-6 6-6" })
          }
        ),
        /* @__PURE__ */ r.jsx("span", { children: "Previous" })
      ]
    }
  );
}
function ve({
  id: t,
  className: a,
  href: e = "#",
  onClick: n,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ r.jsxs(
    "a",
    {
      id: t,
      href: e,
      onClick: (d) => {
        n && (d.preventDefault(), n());
      },
      "aria-label": "Go to next page",
      className: s(
        "inline-flex items-center justify-center gap-1 pr-2.5 pl-4 h-10 rounded-md text-sm font-medium",
        "hover:bg-accent hover:text-accent-foreground transition-colors",
        a
      ),
      "data-refast-id": i,
      children: [
        /* @__PURE__ */ r.jsx("span", { children: "Next" }),
        /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ r.jsx("path", { d: "m9 18 6-6-6-6" })
          }
        )
      ]
    }
  );
}
function we({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  return /* @__PURE__ */ r.jsxs(
    "span",
    {
      id: t,
      "aria-hidden": !0,
      className: s("flex h-9 w-9 items-center justify-center", a),
      "data-refast-id": e,
      children: [
        /* @__PURE__ */ r.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: [
              /* @__PURE__ */ r.jsx("circle", { cx: "12", cy: "12", r: "1" }),
              /* @__PURE__ */ r.jsx("circle", { cx: "19", cy: "12", r: "1" }),
              /* @__PURE__ */ r.jsx("circle", { cx: "5", cy: "12", r: "1" })
            ]
          }
        ),
        /* @__PURE__ */ r.jsx("span", { className: "sr-only", children: "More pages" })
      ]
    }
  );
}
function je({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    O,
    {
      id: t,
      className: s(
        "flex h-10 items-center space-x-1 rounded-md border bg-background p-1",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function Ne({
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ r.jsx(R, { "data-refast-id": a, children: t });
}
function ke({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    G,
    {
      id: t,
      className: s(
        "flex cursor-default select-none items-center rounded-sm px-3 py-1.5 text-sm font-medium outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function ye({
  id: t,
  className: a,
  align: e = "start",
  sideOffset: n = 5,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsx(k, { children: /* @__PURE__ */ r.jsx(
    P,
    {
      id: t,
      align: e,
      sideOffset: n,
      className: s(
        "z-50 min-w-[12rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        a
      ),
      "data-refast-id": d,
      children: i
    }
  ) });
}
function Se({
  id: t,
  className: a,
  shortcut: e,
  disabled: n,
  onSelect: i,
  children: d,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ r.jsxs(
    D,
    {
      id: t,
      disabled: n,
      onSelect: i,
      className: s(
        "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      "data-refast-id": o,
      children: [
        d,
        e && /* @__PURE__ */ r.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: e })
      ]
    }
  );
}
function Me({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  return /* @__PURE__ */ r.jsx(
    W,
    {
      id: t,
      className: s("-mx-1 my-1 h-px bg-muted", a),
      "data-refast-id": e
    }
  );
}
function Ce({
  id: t,
  className: a,
  checked: e,
  onCheckedChange: n,
  disabled: i,
  children: d,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ r.jsxs(
    T,
    {
      id: t,
      checked: e,
      onCheckedChange: n,
      disabled: i,
      className: s(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      "data-refast-id": o,
      children: [
        /* @__PURE__ */ r.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ r.jsx(y, { children: /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-4 w-4",
            children: /* @__PURE__ */ r.jsx("polyline", { points: "20 6 9 17 4 12" })
          }
        ) }) }),
        d
      ]
    }
  );
}
function Le({
  id: t,
  className: a,
  value: e,
  onValueChange: n,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsx(
    E,
    {
      id: t,
      value: e,
      onValueChange: n,
      className: a,
      "data-refast-id": d,
      children: i
    }
  );
}
function _e({
  id: t,
  className: a,
  value: e,
  children: n,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ r.jsxs(
    I,
    {
      id: t,
      value: e,
      className: s(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      "data-refast-id": i,
      children: [
        /* @__PURE__ */ r.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ r.jsx(y, { children: /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "h-2 w-2 fill-current",
            children: /* @__PURE__ */ r.jsx("circle", { cx: "12", cy: "12", r: "10" })
          }
        ) }) }),
        n
      ]
    }
  );
}
function ze({
  children: t,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ r.jsx(B, { "data-refast-id": a, children: t });
}
function Be({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsxs(
    z,
    {
      id: t,
      className: s(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        a
      ),
      "data-refast-id": n,
      children: [
        e,
        /* @__PURE__ */ r.jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "ml-auto h-4 w-4",
            children: /* @__PURE__ */ r.jsx("path", { d: "m9 18 6-6-6-6" })
          }
        )
      ]
    }
  );
}
function Ie({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(k, { children: /* @__PURE__ */ r.jsx(
    _,
    {
      id: t,
      className: s(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  ) });
}
function Ee({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    p,
    {
      id: t,
      className: s(
        "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function Te({
  id: t,
  className: a,
  placeholder: e = "Search...",
  value: n,
  onValueChange: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsxs("div", { className: "flex items-center border-b px-3", "cmdk-input-wrapper": "", "data-refast-id": d, children: [
    /* @__PURE__ */ r.jsxs(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "16",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "mr-2 h-4 w-4 shrink-0 opacity-50",
        children: [
          /* @__PURE__ */ r.jsx("circle", { cx: "11", cy: "11", r: "8" }),
          /* @__PURE__ */ r.jsx("path", { d: "m21 21-4.3-4.3" })
        ]
      }
    ),
    /* @__PURE__ */ r.jsx(
      p.Input,
      {
        id: t,
        value: n,
        onValueChange: i,
        placeholder: e,
        className: s(
          "flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none",
          "placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
          a
        )
      }
    )
  ] });
}
function We({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    p.List,
    {
      id: t,
      className: s("max-h-[300px] overflow-y-auto overflow-x-hidden", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function De({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    p.Empty,
    {
      id: t,
      className: s("py-6 text-center text-sm", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function Pe({
  id: t,
  className: a,
  heading: e,
  children: n,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ r.jsx(
    p.Group,
    {
      id: t,
      heading: e,
      className: s(
        "overflow-hidden p-1 text-foreground",
        "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs",
        "[&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
        a
      ),
      "data-refast-id": i,
      children: n
    }
  );
}
function Ge({
  id: t,
  className: a,
  icon: e,
  value: n,
  disabled: i,
  onSelect: d,
  children: o,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ r.jsxs(
    p.Item,
    {
      id: t,
      value: n,
      disabled: i,
      onSelect: d,
      className: s(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "aria-selected:bg-accent aria-selected:text-accent-foreground",
        "data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50",
        a
      ),
      "data-refast-id": l,
      children: [
        e && /* @__PURE__ */ r.jsx(S, { name: e, size: 16, className: "shrink-0" }),
        o
      ]
    }
  );
}
function Re({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  return /* @__PURE__ */ r.jsx(
    p.Separator,
    {
      id: t,
      className: s("-mx-1 h-px bg-border", a),
      "data-refast-id": e
    }
  );
}
function Oe({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "span",
    {
      id: t,
      className: s("ml-auto text-xs tracking-widest text-muted-foreground", a),
      "data-refast-id": n,
      children: e
    }
  );
}
const Y = "16rem", X = "18rem", Z = "3rem", J = "b", j = u.createContext(null);
function He({
  id: t,
  className: a,
  defaultOpen: e = !0,
  open: n,
  onOpenChange: i,
  children: d,
  style: o,
  "data-refast-id": l
}) {
  const [f, b] = u.useState(!1), [x, m] = u.useState(!1), [M, C] = u.useState(e), h = n ?? M, v = u.useCallback(
    (c) => {
      const g = typeof c == "function" ? c(h) : c;
      i ? i(g) : C(g);
    },
    [i, h]
  ), w = u.useCallback(() => f ? m((c) => !c) : v((c) => !c), [f, v, m]);
  u.useEffect(() => {
    const c = () => {
      b(window.innerWidth < 768);
    };
    return c(), window.addEventListener("resize", c), () => window.removeEventListener("resize", c);
  }, []), u.useEffect(() => {
    const c = (g) => {
      g.key === J && (g.metaKey || g.ctrlKey) && (g.preventDefault(), w());
    };
    return window.addEventListener("keydown", c), () => window.removeEventListener("keydown", c);
  }, [w]);
  const N = h ? "expanded" : "collapsed", L = u.useMemo(
    () => ({
      state: N,
      open: h,
      setOpen: v,
      isMobile: f,
      openMobile: x,
      setOpenMobile: m,
      toggleSidebar: w
    }),
    [N, h, v, f, x, m, w]
  );
  return /* @__PURE__ */ r.jsx(j.Provider, { value: L, children: /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      style: {
        "--sidebar-width": Y,
        "--sidebar-width-mobile": X,
        "--sidebar-width-icon": Z,
        ...o
      },
      className: s(
        "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
        a
      ),
      "data-refast-id": l,
      children: d
    }
  ) });
}
function Ae({
  id: t,
  className: a,
  side: e = "left",
  variant: n = "sidebar",
  collapsible: i = "offcanvas",
  children: d,
  "data-refast-id": o
}) {
  const l = u.useContext(j);
  if (!l)
    return /* @__PURE__ */ r.jsx(
      "aside",
      {
        id: t,
        className: s(
          "flex h-full w-64 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border",
          e === "right" && "border-l border-r-0",
          a
        ),
        "data-refast-id": o,
        children: d
      }
    );
  const { isMobile: f, state: b, openMobile: x, setOpenMobile: m } = l;
  return i === "none" ? /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      className: s(
        "flex h-full w-[--sidebar-width] flex-col bg-sidebar text-sidebar-foreground",
        a
      ),
      "data-refast-id": o,
      children: d
    }
  ) : f ? /* @__PURE__ */ r.jsxs(r.Fragment, { children: [
    x && /* @__PURE__ */ r.jsx(
      "div",
      {
        className: "fixed inset-0 z-50 bg-black/80",
        onClick: () => m(!1)
      }
    ),
    /* @__PURE__ */ r.jsx(
      "aside",
      {
        id: t,
        className: s(
          "fixed inset-y-0 z-50 flex h-svh w-[--sidebar-width-mobile] flex-col bg-sidebar text-sidebar-foreground",
          "transition-transform duration-200 ease-in-out",
          e === "left" ? "left-0" : "right-0",
          x ? "translate-x-0" : e === "left" ? "-translate-x-full" : "translate-x-full",
          a
        ),
        "data-refast-id": o,
        children: d
      }
    )
  ] }) : /* @__PURE__ */ r.jsxs(
    "div",
    {
      className: "group peer hidden md:block text-sidebar-foreground",
      "data-state": b,
      "data-collapsible": b === "collapsed" ? i : "",
      "data-variant": n,
      "data-side": e,
      children: [
        /* @__PURE__ */ r.jsx(
          "div",
          {
            className: s(
              "relative h-svh w-[--sidebar-width] bg-transparent transition-[width] duration-200 ease-linear",
              "group-data-[collapsible=offcanvas]:w-0",
              "group-data-[side=right]:rotate-180",
              n === "floating" || n === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]" : "group-data-[collapsible=icon]:w-[--sidebar-width-icon]"
            )
          }
        ),
        /* @__PURE__ */ r.jsx(
          "aside",
          {
            id: t,
            className: s(
              "fixed inset-y-0 z-10 hidden h-svh w-[--sidebar-width] transition-[left,right,width] duration-200 ease-linear md:flex",
              e === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
              "group-data-[collapsible=icon]:w-[--sidebar-width-icon] group-data-[collapsible=icon]:overflow-hidden",
              n === "floating" || n === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]" : "group-data-[side=left]:border-r group-data-[side=right]:border-l border-sidebar-border",
              a
            ),
            "data-refast-id": o,
            children: /* @__PURE__ */ r.jsx(
              "div",
              {
                "data-sidebar": "sidebar",
                className: s(
                  "flex h-full w-full flex-col bg-sidebar",
                  n === "floating" && "rounded-lg border border-sidebar-border shadow",
                  n === "inset" && "rounded-lg border border-sidebar-border shadow"
                ),
                children: d
              }
            )
          }
        )
      ]
    }
  );
}
function Ke({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "main",
    {
      id: t,
      className: s(
        "relative flex min-h-svh flex-1 flex-col bg-background",
        "peer-data-[variant=inset]:min-h-[calc(100svh-theme(spacing.4))] md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function Ve({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "header",
      className: s("flex flex-col gap-2 p-2", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function Fe({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "content",
      className: s(
        "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function $e({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "footer",
      className: s("flex flex-col gap-2 p-2", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function qe({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  return /* @__PURE__ */ r.jsx(
    "hr",
    {
      id: t,
      "data-sidebar": "separator",
      className: s("mx-2 w-auto bg-sidebar-border", a),
      "data-refast-id": e
    }
  );
}
function Ue({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "group",
      className: s("relative flex w-full min-w-0 flex-col p-2", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function Ye({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "group-label",
      className: s(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opa] duration-200 ease-linear",
        "focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function Xe({
  id: t,
  className: a,
  children: e,
  onClick: n,
  title: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsx(
    "button",
    {
      id: t,
      "data-sidebar": "group-action",
      onClick: n,
      title: i,
      className: s(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2",
        "[&>svg]:size-4 [&>svg]:shrink-0",
        "after:absolute after:-inset-2 after:md:hidden",
        "group-data-[collapsible=icon]:hidden",
        a
      ),
      "data-refast-id": d,
      children: e
    }
  );
}
function Ze({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "group-content",
      className: s("w-full text-sm", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function Je({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "ul",
    {
      id: t,
      "data-sidebar": "menu",
      className: s("flex w-full min-w-0 flex-col gap-1", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function Qe({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "li",
    {
      id: t,
      "data-sidebar": "menu-item",
      className: s("group/menu-item relative", a),
      "data-refast-id": n,
      children: e
    }
  );
}
function et({
  id: t,
  className: a,
  icon: e,
  isActive: n = !1,
  variant: i = "default",
  size: d = "default",
  onClick: o,
  href: l,
  children: f,
  "data-refast-id": b
}) {
  const x = s(
    "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground",
    "group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
    i === "outline" && "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]",
    d === "sm" && "h-7 text-xs",
    d === "lg" && "h-12 text-sm group-data-[collapsible=icon]:!p-0",
    a
  ), m = /* @__PURE__ */ r.jsxs(r.Fragment, { children: [
    e && /* @__PURE__ */ r.jsx(S, { name: e, size: 16, className: "shrink-0" }),
    /* @__PURE__ */ r.jsx("span", { className: "truncate", children: f })
  ] });
  return l ? /* @__PURE__ */ r.jsx(
    "a",
    {
      id: t,
      href: l,
      "data-sidebar": "menu-button",
      "data-size": d,
      "data-active": n,
      className: x,
      "data-refast-id": b,
      children: m
    }
  ) : /* @__PURE__ */ r.jsx(
    "button",
    {
      id: t,
      "data-sidebar": "menu-button",
      "data-size": d,
      "data-active": n,
      onClick: o,
      className: x,
      "data-refast-id": b,
      children: m
    }
  );
}
function tt({
  id: t,
  className: a,
  showOnHover: e = !1,
  onClick: n,
  children: i,
  "data-refast-id": d
}) {
  return /* @__PURE__ */ r.jsx(
    "button",
    {
      id: t,
      "data-sidebar": "menu-action",
      onClick: n,
      className: s(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground",
        "[&>svg]:size-4 [&>svg]:shrink-0",
        "after:absolute after:-inset-2 after:md:hidden",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        e && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0",
        a
      ),
      "data-refast-id": d,
      children: i
    }
  );
}
function at({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "div",
    {
      id: t,
      "data-sidebar": "menu-badge",
      className: s(
        "absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground select-none pointer-events-none",
        "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function rt({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "ul",
    {
      id: t,
      "data-sidebar": "menu-sub",
      className: s(
        "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
        "group-data-[collapsible=icon]:hidden",
        a
      ),
      "data-refast-id": n,
      children: e
    }
  );
}
function nt({
  id: t,
  className: a,
  children: e,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ r.jsx(
    "li",
    {
      id: t,
      className: a,
      "data-refast-id": n,
      children: e
    }
  );
}
function st({
  id: t,
  className: a,
  isActive: e = !1,
  size: n = "md",
  href: i,
  onClick: d,
  children: o,
  "data-refast-id": l
}) {
  const f = s(
    "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
    e && "bg-sidebar-accent text-sidebar-accent-foreground",
    n === "sm" && "text-xs",
    n === "md" && "text-sm",
    a
  );
  return i ? /* @__PURE__ */ r.jsx(
    "a",
    {
      id: t,
      href: i,
      "data-sidebar": "menu-sub-button",
      "data-size": n,
      "data-active": e,
      className: f,
      "data-refast-id": l,
      children: o
    }
  ) : /* @__PURE__ */ r.jsx(
    "button",
    {
      id: t,
      "data-sidebar": "menu-sub-button",
      "data-size": n,
      "data-active": e,
      onClick: d,
      className: f,
      "data-refast-id": l,
      children: o
    }
  );
}
function it({
  id: t,
  className: a,
  showIcon: e = !1,
  "data-refast-id": n
}) {
  const i = u.useMemo(() => `${Math.floor(Math.random() * 40) + 50}%`, []);
  return /* @__PURE__ */ r.jsxs(
    "div",
    {
      id: t,
      "data-sidebar": "menu-skeleton",
      className: s("rounded-md h-8 flex gap-2 px-2 items-center", a),
      "data-refast-id": n,
      children: [
        e && /* @__PURE__ */ r.jsx("div", { className: "size-4 rounded-md bg-sidebar-accent animate-pulse" }),
        /* @__PURE__ */ r.jsx(
          "div",
          {
            className: "h-4 flex-1 max-w-[--skeleton-width] rounded-md bg-sidebar-accent animate-pulse",
            style: { "--skeleton-width": i }
          }
        )
      ]
    }
  );
}
function dt({
  id: t,
  className: a,
  "data-refast-id": e
}) {
  const n = u.useContext(j), i = n == null ? void 0 : n.toggleSidebar;
  return /* @__PURE__ */ r.jsx(
    "button",
    {
      id: t,
      "data-sidebar": "rail",
      "aria-label": "Toggle Sidebar",
      tabIndex: -1,
      onClick: i,
      title: "Toggle Sidebar",
      className: s(
        "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex",
        "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize",
        "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
        "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar",
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
        a
      ),
      "data-refast-id": e
    }
  );
}
function ot({
  id: t,
  className: a,
  onClick: e,
  "data-refast-id": n
}) {
  const i = u.useContext(j), d = () => {
    e ? e() : i != null && i.toggleSidebar && i.toggleSidebar();
  };
  return /* @__PURE__ */ r.jsxs(
    "button",
    {
      id: t,
      "data-sidebar": "trigger",
      onClick: d,
      className: s(
        "inline-flex h-7 w-7 items-center justify-center rounded-md text-sm font-medium",
        "ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        a
      ),
      "data-refast-id": n,
      children: [
        /* @__PURE__ */ r.jsxs(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            className: "size-4",
            children: [
              /* @__PURE__ */ r.jsx("rect", { width: "18", height: "18", x: "3", y: "3", rx: "2" }),
              /* @__PURE__ */ r.jsx("path", { d: "M9 3v18" })
            ]
          }
        ),
        /* @__PURE__ */ r.jsx("span", { className: "sr-only", children: "Toggle Sidebar" })
      ]
    }
  );
}
export {
  te as Breadcrumb,
  de as BreadcrumbEllipsis,
  re as BreadcrumbItem,
  ne as BreadcrumbLink,
  ae as BreadcrumbList,
  se as BreadcrumbPage,
  ie as BreadcrumbSeparator,
  Ee as Command,
  De as CommandEmpty,
  Pe as CommandGroup,
  Te as CommandInput,
  Ge as CommandItem,
  We as CommandList,
  Re as CommandSeparator,
  Oe as CommandShortcut,
  je as Menubar,
  Ce as MenubarCheckboxItem,
  ye as MenubarContent,
  Se as MenubarItem,
  Ne as MenubarMenu,
  Le as MenubarRadioGroup,
  _e as MenubarRadioItem,
  Me as MenubarSeparator,
  ze as MenubarSub,
  Ie as MenubarSubContent,
  Be as MenubarSubTrigger,
  ke as MenubarTrigger,
  oe as NavigationMenu,
  fe as NavigationMenuContent,
  ce as NavigationMenuItem,
  me as NavigationMenuLink,
  le as NavigationMenuList,
  ue as NavigationMenuTrigger,
  xe as Pagination,
  be as PaginationContent,
  we as PaginationEllipsis,
  ge as PaginationItem,
  pe as PaginationLink,
  ve as PaginationNext,
  he as PaginationPrevious,
  Ae as Sidebar,
  Fe as SidebarContent,
  $e as SidebarFooter,
  Ue as SidebarGroup,
  Xe as SidebarGroupAction,
  Ze as SidebarGroupContent,
  Ye as SidebarGroupLabel,
  Ve as SidebarHeader,
  Ke as SidebarInset,
  Je as SidebarMenu,
  tt as SidebarMenuAction,
  at as SidebarMenuBadge,
  et as SidebarMenuButton,
  Qe as SidebarMenuItem,
  it as SidebarMenuSkeleton,
  rt as SidebarMenuSub,
  st as SidebarMenuSubButton,
  nt as SidebarMenuSubItem,
  He as SidebarProvider,
  dt as SidebarRail,
  qe as SidebarSeparator,
  ot as SidebarTrigger
};
