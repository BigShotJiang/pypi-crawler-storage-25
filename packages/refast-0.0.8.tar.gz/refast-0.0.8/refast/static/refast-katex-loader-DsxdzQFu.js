import { k as t } from "./refast-katex-B7benO4u.js";
import { a as d, r as o } from "./refast-katex-B7benO4u.js";
if (typeof document < "u" && !document.getElementById("refast-katex-css")) {
  const e = document.createElement("style");
  e.id = "refast-katex-css", e.textContent = t, document.head.appendChild(e);
}
export {
  d as rehypeKatex,
  o as remarkMath
};
