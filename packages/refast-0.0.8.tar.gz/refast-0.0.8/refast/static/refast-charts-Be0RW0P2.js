import { r as l, c as R, g as tr, S as ip, s as op, a as lp, b as up, d as sp, e as cp, f as dp, h as gc, u as vl, w as vp, i as A, j as hn, k as Be, l as fp, m as pp, n as bc, o as mp, p as hp, q as yp, t as gp, v as oe, x as er, y as re, z as Hi, A as Pa, B as bp, C as xp, D as Pp, E as Op, F as wp, G as Ap, H as Ep, I as xc, J as jp, K as Sp, L as Ip, M as kp, N as Cp, O as Dp, P as Q, Q as Rt, R as Yi, T as Tp, U as Pc, V as Oc, W as $p, X as Lp, Y as Mp, Z as _p, _ as Np, $ as Rp, a0 as Bp, a1 as vt, a2 as Jt, a3 as Kp, a4 as zp, a5 as Wp, a6 as Fp, a7 as wc, a8 as Xp } from "./refast-vendor-CQOdd5X6.js";
var Vp = ["dangerouslySetInnerHTML", "onCopy", "onCopyCapture", "onCut", "onCutCapture", "onPaste", "onPasteCapture", "onCompositionEnd", "onCompositionEndCapture", "onCompositionStart", "onCompositionStartCapture", "onCompositionUpdate", "onCompositionUpdateCapture", "onFocus", "onFocusCapture", "onBlur", "onBlurCapture", "onChange", "onChangeCapture", "onBeforeInput", "onBeforeInputCapture", "onInput", "onInputCapture", "onReset", "onResetCapture", "onSubmit", "onSubmitCapture", "onInvalid", "onInvalidCapture", "onLoad", "onLoadCapture", "onError", "onErrorCapture", "onKeyDown", "onKeyDownCapture", "onKeyPress", "onKeyPressCapture", "onKeyUp", "onKeyUpCapture", "onAbort", "onAbortCapture", "onCanPlay", "onCanPlayCapture", "onCanPlayThrough", "onCanPlayThroughCapture", "onDurationChange", "onDurationChangeCapture", "onEmptied", "onEmptiedCapture", "onEncrypted", "onEncryptedCapture", "onEnded", "onEndedCapture", "onLoadedData", "onLoadedDataCapture", "onLoadedMetadata", "onLoadedMetadataCapture", "onLoadStart", "onLoadStartCapture", "onPause", "onPauseCapture", "onPlay", "onPlayCapture", "onPlaying", "onPlayingCapture", "onProgress", "onProgressCapture", "onRateChange", "onRateChangeCapture", "onSeeked", "onSeekedCapture", "onSeeking", "onSeekingCapture", "onStalled", "onStalledCapture", "onSuspend", "onSuspendCapture", "onTimeUpdate", "onTimeUpdateCapture", "onVolumeChange", "onVolumeChangeCapture", "onWaiting", "onWaitingCapture", "onAuxClick", "onAuxClickCapture", "onClick", "onClickCapture", "onContextMenu", "onContextMenuCapture", "onDoubleClick", "onDoubleClickCapture", "onDrag", "onDragCapture", "onDragEnd", "onDragEndCapture", "onDragEnter", "onDragEnterCapture", "onDragExit", "onDragExitCapture", "onDragLeave", "onDragLeaveCapture", "onDragOver", "onDragOverCapture", "onDragStart", "onDragStartCapture", "onDrop", "onDropCapture", "onMouseDown", "onMouseDownCapture", "onMouseEnter", "onMouseLeave", "onMouseMove", "onMouseMoveCapture", "onMouseOut", "onMouseOutCapture", "onMouseOver", "onMouseOverCapture", "onMouseUp", "onMouseUpCapture", "onSelect", "onSelectCapture", "onTouchCancel", "onTouchCancelCapture", "onTouchEnd", "onTouchEndCapture", "onTouchMove", "onTouchMoveCapture", "onTouchStart", "onTouchStartCapture", "onPointerDown", "onPointerDownCapture", "onPointerMove", "onPointerMoveCapture", "onPointerUp", "onPointerUpCapture", "onPointerCancel", "onPointerCancelCapture", "onPointerEnter", "onPointerEnterCapture", "onPointerLeave", "onPointerLeaveCapture", "onPointerOver", "onPointerOverCapture", "onPointerOut", "onPointerOutCapture", "onGotPointerCapture", "onGotPointerCaptureCapture", "onLostPointerCapture", "onLostPointerCaptureCapture", "onScroll", "onScrollCapture", "onWheel", "onWheelCapture", "onAnimationStart", "onAnimationStartCapture", "onAnimationEnd", "onAnimationEndCapture", "onAnimationIteration", "onAnimationIterationCapture", "onTransitionEnd", "onTransitionEndCapture"];
function Ui(e) {
  if (typeof e != "string")
    return !1;
  var r = Vp;
  return r.includes(e);
}
var Gp = [
  "aria-activedescendant",
  "aria-atomic",
  "aria-autocomplete",
  "aria-busy",
  "aria-checked",
  "aria-colcount",
  "aria-colindex",
  "aria-colspan",
  "aria-controls",
  "aria-current",
  "aria-describedby",
  "aria-details",
  "aria-disabled",
  "aria-errormessage",
  "aria-expanded",
  "aria-flowto",
  "aria-haspopup",
  "aria-hidden",
  "aria-invalid",
  "aria-keyshortcuts",
  "aria-label",
  "aria-labelledby",
  "aria-level",
  "aria-live",
  "aria-modal",
  "aria-multiline",
  "aria-multiselectable",
  "aria-orientation",
  "aria-owns",
  "aria-placeholder",
  "aria-posinset",
  "aria-pressed",
  "aria-readonly",
  "aria-relevant",
  "aria-required",
  "aria-roledescription",
  "aria-rowcount",
  "aria-rowindex",
  "aria-rowspan",
  "aria-selected",
  "aria-setsize",
  "aria-sort",
  "aria-valuemax",
  "aria-valuemin",
  "aria-valuenow",
  "aria-valuetext",
  "className",
  "color",
  "height",
  "id",
  "lang",
  "max",
  "media",
  "method",
  "min",
  "name",
  "style",
  /*
   * removed 'type' SVGElementPropKey because we do not currently use any SVG elements
   * that can use it, and it conflicts with the recharts prop 'type'
   * https://github.com/recharts/recharts/pull/3327
   * https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/type
   */
  // 'type',
  "target",
  "width",
  "role",
  "tabIndex",
  "accentHeight",
  "accumulate",
  "additive",
  "alignmentBaseline",
  "allowReorder",
  "alphabetic",
  "amplitude",
  "arabicForm",
  "ascent",
  "attributeName",
  "attributeType",
  "autoReverse",
  "azimuth",
  "baseFrequency",
  "baselineShift",
  "baseProfile",
  "bbox",
  "begin",
  "bias",
  "by",
  "calcMode",
  "capHeight",
  "clip",
  "clipPath",
  "clipPathUnits",
  "clipRule",
  "colorInterpolation",
  "colorInterpolationFilters",
  "colorProfile",
  "colorRendering",
  "contentScriptType",
  "contentStyleType",
  "cursor",
  "cx",
  "cy",
  "d",
  "decelerate",
  "descent",
  "diffuseConstant",
  "direction",
  "display",
  "divisor",
  "dominantBaseline",
  "dur",
  "dx",
  "dy",
  "edgeMode",
  "elevation",
  "enableBackground",
  "end",
  "exponent",
  "externalResourcesRequired",
  "fill",
  "fillOpacity",
  "fillRule",
  "filter",
  "filterRes",
  "filterUnits",
  "floodColor",
  "floodOpacity",
  "focusable",
  "fontFamily",
  "fontSize",
  "fontSizeAdjust",
  "fontStretch",
  "fontStyle",
  "fontVariant",
  "fontWeight",
  "format",
  "from",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyphName",
  "glyphOrientationHorizontal",
  "glyphOrientationVertical",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "hanging",
  "horizAdvX",
  "horizOriginX",
  "href",
  "ideographic",
  "imageRendering",
  "in2",
  "in",
  "intercept",
  "k1",
  "k2",
  "k3",
  "k4",
  "k",
  "kernelMatrix",
  "kernelUnitLength",
  "kerning",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "letterSpacing",
  "lightingColor",
  "limitingConeAngle",
  "local",
  "markerEnd",
  "markerHeight",
  "markerMid",
  "markerStart",
  "markerUnits",
  "markerWidth",
  "mask",
  "maskContentUnits",
  "maskUnits",
  "mathematical",
  "mode",
  "numOctaves",
  "offset",
  "opacity",
  "operator",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "overlinePosition",
  "overlineThickness",
  "paintOrder",
  "panose1",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointerEvents",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "r",
  "radius",
  "refX",
  "refY",
  "renderingIntent",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "restart",
  "result",
  "rotate",
  "rx",
  "ry",
  "seed",
  "shapeRendering",
  "slope",
  "spacing",
  "specularConstant",
  "specularExponent",
  "speed",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stemh",
  "stemv",
  "stitchTiles",
  "stopColor",
  "stopOpacity",
  "strikethroughPosition",
  "strikethroughThickness",
  "string",
  "stroke",
  "strokeDasharray",
  "strokeDashoffset",
  "strokeLinecap",
  "strokeLinejoin",
  "strokeMiterlimit",
  "strokeOpacity",
  "strokeWidth",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textAnchor",
  "textDecoration",
  "textLength",
  "textRendering",
  "to",
  "transform",
  "u1",
  "u2",
  "underlinePosition",
  "underlineThickness",
  "unicode",
  "unicodeBidi",
  "unicodeRange",
  "unitsPerEm",
  "vAlphabetic",
  "values",
  "vectorEffect",
  "version",
  "vertAdvY",
  "vertOriginX",
  "vertOriginY",
  "vHanging",
  "vIdeographic",
  "viewTarget",
  "visibility",
  "vMathematical",
  "widths",
  "wordSpacing",
  "writingMode",
  "x1",
  "x2",
  "x",
  "xChannelSelector",
  "xHeight",
  "xlinkActuate",
  "xlinkArcrole",
  "xlinkHref",
  "xlinkRole",
  "xlinkShow",
  "xlinkTitle",
  "xlinkType",
  "xmlBase",
  "xmlLang",
  "xmlns",
  "xmlnsXlink",
  "xmlSpace",
  "y1",
  "y2",
  "y",
  "yChannelSelector",
  "z",
  "zoomAndPan",
  "ref",
  "key",
  "angle"
], Hp = new Set(Gp);
function Ac(e) {
  return typeof e != "string" ? !1 : Hp.has(e);
}
function Ec(e) {
  return typeof e == "string" && e.startsWith("data-");
}
function G(e) {
  if (typeof e != "object" || e === null)
    return {};
  var r = {};
  for (var t in e)
    Object.prototype.hasOwnProperty.call(e, t) && (Ac(t) || Ec(t)) && (r[t] = e[t]);
  return r;
}
function ze(e) {
  if (e == null)
    return null;
  if (/* @__PURE__ */ l.isValidElement(e) && typeof e.props == "object" && e.props !== null) {
    var r = e.props;
    return G(r);
  }
  return typeof e == "object" && !Array.isArray(e) ? G(e) : null;
}
function le(e) {
  var r = {};
  for (var t in e)
    Object.prototype.hasOwnProperty.call(e, t) && (Ac(t) || Ec(t) || Ui(t)) && (r[t] = e[t]);
  return r;
}
function Yp(e) {
  return e == null ? null : /* @__PURE__ */ l.isValidElement(e) ? le(e.props) : typeof e == "object" && !Array.isArray(e) ? le(e) : null;
}
var Up = ["children", "width", "height", "viewBox", "className", "style", "title", "desc"];
function ci() {
  return ci = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, ci.apply(null, arguments);
}
function Zp(e, r) {
  if (e == null) return {};
  var t, a, n = qp(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function qp(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var Qt = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    children: t,
    width: a,
    height: n,
    viewBox: i,
    className: o,
    style: u,
    title: s,
    desc: c
  } = e, d = Zp(e, Up), v = i || {
    width: a,
    height: n,
    x: 0,
    y: 0
  }, f = R("recharts-surface", o);
  return /* @__PURE__ */ l.createElement("svg", ci({}, le(d), {
    className: f,
    width: a,
    height: n,
    style: u,
    viewBox: "".concat(v.x, " ").concat(v.y, " ").concat(v.width, " ").concat(v.height),
    ref: r
  }), /* @__PURE__ */ l.createElement("title", null, s), /* @__PURE__ */ l.createElement("desc", null, c), t);
}), Jp = ["children", "className"];
function di() {
  return di = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, di.apply(null, arguments);
}
function Qp(e, r) {
  if (e == null) return {};
  var t, a, n = em(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function em(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var _ = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    children: t,
    className: a
  } = e, n = Qp(e, Jp), i = R("recharts-layer", a);
  return /* @__PURE__ */ l.createElement("g", di({
    className: i
  }, le(n), {
    ref: r
  }), t);
}), jc = /* @__PURE__ */ l.createContext(null), rm = () => l.useContext(jc), tm = 4;
function Cr(e) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : tm, t = 10 ** r, a = Math.round(e * t) / t;
  return Object.is(a, -0) ? 0 : a;
}
function ue(e) {
  for (var r = arguments.length, t = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++)
    t[a - 1] = arguments[a];
  return e.reduce((n, i, o) => {
    var u = t[o - 1];
    return typeof u == "string" ? n + u + i : u !== void 0 ? n + Cr(u) + i : n + i;
  }, "");
}
var me = (e) => e === 0 ? 0 : e > 0 ? 1 : -1, De = (e) => typeof e == "number" && e != +e, xr = (e) => typeof e == "string" && e.indexOf("%") === e.length - 1, L = (e) => (typeof e == "number" || e instanceof Number) && !De(e), we = (e) => L(e) || typeof e == "string", am = 0, it = (e) => {
  var r = ++am;
  return "".concat(e || "").concat(r);
}, Ee = function(r, t) {
  var a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  if (!L(r) && typeof r != "string")
    return a;
  var i;
  if (xr(r)) {
    if (t == null)
      return a;
    var o = r.indexOf("%");
    i = t * parseFloat(r.slice(0, o)) / 100;
  } else
    i = +r;
  return De(i) && (i = a), n && t != null && i > t && (i = t), i;
}, Sc = (e) => {
  if (!Array.isArray(e))
    return !1;
  for (var r = e.length, t = {}, a = 0; a < r; a++)
    if (!t[String(e[a])])
      t[String(e[a])] = !0;
    else
      return !0;
  return !1;
};
function N(e, r, t) {
  return L(e) && L(r) ? Cr(e + t * (r - e)) : r;
}
function Ic(e, r, t) {
  if (!(!e || !e.length))
    return e.find((a) => a && (typeof r == "function" ? r(a) : tr(a, r)) === t);
}
var nm = (e) => {
  for (var r = e.length, t = 0, a = 0, n = 0, i = 0, o = 1 / 0, u = -1 / 0, s = 0, c = 0, d = 0; d < r; d++) {
    var v, f;
    s = ((v = e[d]) === null || v === void 0 ? void 0 : v.cx) || 0, c = ((f = e[d]) === null || f === void 0 ? void 0 : f.cy) || 0, t += s, a += c, n += s * c, i += s * s, o = Math.min(o, s), u = Math.max(u, s);
  }
  var p = r * i !== t * t ? (r * n - t * a) / (r * i - t * t) : 0;
  return {
    xmin: o,
    xmax: u,
    a: p,
    b: (a - p * t) / r
  };
}, U = (e) => e === null || typeof e > "u", ea = (e) => U(e) ? e : "".concat(e.charAt(0).toUpperCase()).concat(e.slice(1));
function Zi(e) {
  return e != null;
}
function ft() {
}
var im = ["type", "size", "sizeType"];
function vi() {
  return vi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, vi.apply(null, arguments);
}
function fl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function pl(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? fl(Object(t), !0).forEach(function(a) {
      om(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : fl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function om(e, r, t) {
  return (r = lm(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function lm(e) {
  var r = um(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function um(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function sm(e, r) {
  if (e == null) return {};
  var t, a, n = cm(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function cm(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var kc = {
  symbolCircle: gc,
  symbolCross: dp,
  symbolDiamond: cp,
  symbolSquare: sp,
  symbolStar: up,
  symbolTriangle: lp,
  symbolWye: op
}, dm = Math.PI / 180, vm = (e) => {
  var r = "symbol".concat(ea(e));
  return kc[r] || gc;
}, fm = (e, r, t) => {
  if (r === "area")
    return e;
  switch (t) {
    case "cross":
      return 5 * e * e / 9;
    case "diamond":
      return 0.5 * e * e / Math.sqrt(3);
    case "square":
      return e * e;
    case "star": {
      var a = 18 * dm;
      return 1.25 * e * e * (Math.tan(a) - Math.tan(a * 2) * Math.tan(a) ** 2);
    }
    case "triangle":
      return Math.sqrt(3) * e * e / 4;
    case "wye":
      return (21 - 10 * Math.sqrt(3)) * e * e / 8;
    default:
      return Math.PI * e * e / 4;
  }
}, pm = (e, r) => {
  kc["symbol".concat(ea(e))] = r;
}, yn = (e) => {
  var {
    type: r = "circle",
    size: t = 64,
    sizeType: a = "area"
  } = e, n = sm(e, im), i = pl(pl({}, n), {}, {
    type: r,
    size: t,
    sizeType: a
  }), o = "circle";
  typeof r == "string" && (o = r);
  var u = () => {
    var f = vm(o), p = ip().type(f).size(fm(t, a, o)), m = p();
    if (m !== null)
      return m;
  }, {
    className: s,
    cx: c,
    cy: d
  } = i, v = le(i);
  return L(c) && L(d) && L(t) ? /* @__PURE__ */ l.createElement("path", vi({}, v, {
    className: R("recharts-symbols", s),
    transform: "translate(".concat(c, ", ").concat(d, ")"),
    d: u()
  })) : null;
};
yn.registerSymbol = pm;
var Cc = (e) => "radius" in e && "startAngle" in e && "endAngle" in e, qi = (e, r) => {
  if (!e || typeof e == "function" || typeof e == "boolean")
    return null;
  var t = e;
  if (/* @__PURE__ */ l.isValidElement(e) && (t = e.props), typeof t != "object" && typeof t != "function")
    return null;
  var a = {};
  return Object.keys(t).forEach((n) => {
    Ui(n) && (a[n] = (i) => t[n](t, i));
  }), a;
}, mm = (e, r, t) => (a) => (e(r, t, a), null), Ue = (e, r, t) => {
  if (e === null || typeof e != "object" && typeof e != "function")
    return null;
  var a = null;
  return Object.keys(e).forEach((n) => {
    var i = e[n];
    Ui(n) && typeof i == "function" && (a || (a = {}), a[n] = mm(i, r, t));
  }), a;
}, hm = (e) => Array.isArray(e) && e.length > 0;
function ml(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ym(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ml(Object(t), !0).forEach(function(a) {
      gm(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ml(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function gm(e, r, t) {
  return (r = bm(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function bm(e) {
  var r = xm(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function xm(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function V(e, r) {
  var t = ym({}, e), a = r, n = Object.keys(r), i = n.reduce((o, u) => (o[u] === void 0 && a[u] !== void 0 && (o[u] = a[u]), o), t);
  return i;
}
function Na() {
  return Na = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Na.apply(null, arguments);
}
function hl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Pm(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? hl(Object(t), !0).forEach(function(a) {
      Om(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : hl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Om(e, r, t) {
  return (r = wm(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function wm(e) {
  var r = Am(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Am(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Ve = 32, Em = {
  align: "center",
  iconSize: 14,
  inactiveColor: "#ccc",
  layout: "horizontal",
  verticalAlign: "middle"
};
function jm(e) {
  var {
    data: r,
    iconType: t,
    inactiveColor: a
  } = e, n = Ve / 2, i = Ve / 6, o = Ve / 3, u = r.inactive ? a : r.color, s = t ?? r.type;
  if (s === "none")
    return null;
  if (s === "plainline") {
    var c;
    return /* @__PURE__ */ l.createElement("line", {
      strokeWidth: 4,
      fill: "none",
      stroke: u,
      strokeDasharray: (c = r.payload) === null || c === void 0 ? void 0 : c.strokeDasharray,
      x1: 0,
      y1: n,
      x2: Ve,
      y2: n,
      className: "recharts-legend-icon"
    });
  }
  if (s === "line")
    return /* @__PURE__ */ l.createElement("path", {
      strokeWidth: 4,
      fill: "none",
      stroke: u,
      d: "M0,".concat(n, "h").concat(o, `
            A`).concat(i, ",").concat(i, ",0,1,1,").concat(2 * o, ",").concat(n, `
            H`).concat(Ve, "M").concat(2 * o, ",").concat(n, `
            A`).concat(i, ",").concat(i, ",0,1,1,").concat(o, ",").concat(n),
      className: "recharts-legend-icon"
    });
  if (s === "rect")
    return /* @__PURE__ */ l.createElement("path", {
      stroke: "none",
      fill: u,
      d: "M0,".concat(Ve / 8, "h").concat(Ve, "v").concat(Ve * 3 / 4, "h").concat(-Ve, "z"),
      className: "recharts-legend-icon"
    });
  if (/* @__PURE__ */ l.isValidElement(r.legendIcon)) {
    var d = Pm({}, r);
    return delete d.legendIcon, /* @__PURE__ */ l.cloneElement(r.legendIcon, d);
  }
  return /* @__PURE__ */ l.createElement(yn, {
    fill: u,
    cx: n,
    cy: n,
    size: Ve,
    sizeType: "diameter",
    type: s
  });
}
function Sm(e) {
  var {
    payload: r,
    iconSize: t,
    layout: a,
    formatter: n,
    inactiveColor: i,
    iconType: o
  } = e, u = {
    x: 0,
    y: 0,
    width: Ve,
    height: Ve
  }, s = {
    display: a === "horizontal" ? "inline-block" : "block",
    marginRight: 10
  }, c = {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: 4
  };
  return r.map((d, v) => {
    var f = d.formatter || n, p = R({
      "recharts-legend-item": !0,
      ["legend-item-".concat(v)]: !0,
      inactive: d.inactive
    });
    if (d.type === "none")
      return null;
    var m = d.inactive ? i : d.color, h = f ? f(d.value, d, v) : d.value;
    return /* @__PURE__ */ l.createElement("li", Na({
      className: p,
      style: s,
      key: "legend-item-".concat(v)
    }, Ue(e, d, v)), /* @__PURE__ */ l.createElement(Qt, {
      width: t,
      height: t,
      viewBox: u,
      style: c,
      "aria-label": "".concat(h, " legend icon")
    }, /* @__PURE__ */ l.createElement(jm, {
      data: d,
      iconType: o,
      inactiveColor: i
    })), /* @__PURE__ */ l.createElement("span", {
      className: "recharts-legend-item-text",
      style: {
        color: m
      }
    }, h));
  });
}
var Im = (e) => {
  var r = V(e, Em), {
    payload: t,
    layout: a,
    align: n
  } = r;
  if (!t || !t.length)
    return null;
  var i = {
    padding: 0,
    margin: 0,
    textAlign: a === "horizontal" ? n : "left"
  };
  return /* @__PURE__ */ l.createElement("ul", {
    className: "recharts-default-legend",
    style: i
  }, /* @__PURE__ */ l.createElement(Sm, Na({}, r, {
    payload: t
  })));
};
function Dc(e, r, t) {
  return r === !0 ? vl(e, t) : typeof r == "function" ? vl(e, r) : e;
}
var Ji = /* @__PURE__ */ l.createContext(null), km = (e) => e, F = () => {
  var e = l.useContext(Ji);
  return e ? e.store.dispatch : km;
}, Ta = () => {
}, Cm = () => Ta, Dm = (e, r) => e === r;
function k(e) {
  var r = l.useContext(Ji);
  return vp.useSyncExternalStoreWithSelector(r ? r.subscription.addNestedSub : Cm, r ? r.store.getState : Ta, r ? r.store.getState : Ta, r ? e : Ta, Dm);
}
var Tc = (e) => e.legend.settings, Tm = (e) => e.legend.size, $m = (e) => e.legend.payload, Lm = A([$m, Tc], (e, r) => {
  var {
    itemSorter: t
  } = r, a = e.flat(1);
  return t ? hn(a, t) : a;
});
function Mm() {
  return k(Lm);
}
var Oa = 1;
function $c() {
  var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], [r, t] = l.useState({
    height: 0,
    left: 0,
    top: 0,
    width: 0
  }), a = l.useCallback(
    (n) => {
      if (n != null) {
        var i = n.getBoundingClientRect(), o = {
          height: i.height,
          left: i.left,
          top: i.top,
          width: i.width
        };
        (Math.abs(o.height - r.height) > Oa || Math.abs(o.left - r.left) > Oa || Math.abs(o.top - r.top) > Oa || Math.abs(o.width - r.width) > Oa) && t({
          height: o.height,
          left: o.left,
          top: o.top,
          width: o.width
        });
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [r.width, r.height, r.top, r.left, ...e]
  );
  return [r, a];
}
var _m = {
  layoutType: "horizontal",
  width: 0,
  height: 0,
  margin: {
    top: 5,
    right: 5,
    bottom: 5,
    left: 5
  },
  scale: 1
}, Lc = Be({
  name: "chartLayout",
  initialState: _m,
  reducers: {
    setLayout(e, r) {
      e.layoutType = r.payload;
    },
    setChartSize(e, r) {
      e.width = r.payload.width, e.height = r.payload.height;
    },
    setMargin(e, r) {
      var t, a, n, i;
      e.margin.top = (t = r.payload.top) !== null && t !== void 0 ? t : 0, e.margin.right = (a = r.payload.right) !== null && a !== void 0 ? a : 0, e.margin.bottom = (n = r.payload.bottom) !== null && n !== void 0 ? n : 0, e.margin.left = (i = r.payload.left) !== null && i !== void 0 ? i : 0;
    },
    setScale(e, r) {
      e.scale = r.payload;
    }
  }
}), {
  setMargin: Mc,
  setLayout: Nm,
  setChartSize: Rm,
  setScale: Bm
} = Lc.actions, Km = Lc.reducer;
function _c(e, r, t) {
  return Array.isArray(e) && e && r + t !== 0 ? e.slice(r, t + 1) : e;
}
function q(e) {
  return Number.isFinite(e);
}
function _e(e) {
  return typeof e == "number" && e > 0 && Number.isFinite(e);
}
function yl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function et(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? yl(Object(t), !0).forEach(function(a) {
      zm(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : yl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function zm(e, r, t) {
  return (r = Wm(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Wm(e) {
  var r = Fm(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Fm(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function B(e, r, t) {
  return U(e) || U(r) ? t : we(r) ? tr(e, r, t) : typeof r == "function" ? r(e) : t;
}
var Xm = (e, r, t) => {
  if (r && t) {
    var {
      width: a,
      height: n
    } = t, {
      align: i,
      verticalAlign: o,
      layout: u
    } = r;
    if ((u === "vertical" || u === "horizontal" && o === "middle") && i !== "center" && L(e[i]))
      return et(et({}, e), {}, {
        [i]: e[i] + (a || 0)
      });
    if ((u === "horizontal" || u === "vertical" && i === "center") && o !== "middle" && L(e[o]))
      return et(et({}, e), {}, {
        [o]: e[o] + (n || 0)
      });
  }
  return e;
}, He = (e, r) => e === "horizontal" && r === "xAxis" || e === "vertical" && r === "yAxis" || e === "centric" && r === "angleAxis" || e === "radial" && r === "radiusAxis", Nc = (e, r, t, a) => {
  if (a)
    return e.map((u) => u.coordinate);
  var n, i, o = e.map((u) => (u.coordinate === r && (n = !0), u.coordinate === t && (i = !0), u.coordinate));
  return n || o.push(r), i || o.push(t), o;
}, Rc = (e, r, t) => {
  if (!e)
    return null;
  var {
    duplicateDomain: a,
    type: n,
    range: i,
    scale: o,
    realScaleType: u,
    isCategorical: s,
    categoricalDomain: c,
    tickCount: d,
    ticks: v,
    niceTicks: f,
    axisType: p
  } = e;
  if (!o)
    return null;
  var m = u === "scaleBand" && o.bandwidth ? o.bandwidth() / 2 : 2, h = n === "category" && o.bandwidth ? o.bandwidth() / m : 0;
  if (h = p === "angleAxis" && i && i.length >= 2 ? me(i[0] - i[1]) * 2 * h : h, v || f) {
    var g = (v || f || []).map((y, b) => {
      var x = a ? a.indexOf(y) : y;
      return {
        // If the scaleContent is not a number, the coordinate will be NaN.
        // That could be the case for example with a PointScale and a string as domain.
        coordinate: o(x) + h,
        value: y,
        offset: h,
        index: b
      };
    });
    return g.filter((y) => !De(y.coordinate));
  }
  return s && c ? c.map((y, b) => ({
    coordinate: o(y) + h,
    value: y,
    index: b,
    offset: h
  })) : o.ticks && d != null ? o.ticks(d).map((y, b) => ({
    coordinate: o(y) + h,
    value: y,
    offset: h,
    index: b
  })) : o.domain().map((y, b) => ({
    coordinate: o(y) + h,
    value: a ? a[y] : y,
    index: b,
    offset: h
  }));
}, gl = 1e-4, Vm = (e) => {
  var r = e.domain();
  if (!(!r || r.length <= 2)) {
    var t = r.length, a = e.range(), n = Math.min(a[0], a[1]) - gl, i = Math.max(a[0], a[1]) + gl, o = e(r[0]), u = e(r[t - 1]);
    (o < n || o > i || u < n || u > i) && e.domain([r[0], r[t - 1]]);
  }
}, Bc = (e, r) => {
  if (!r || r.length !== 2 || !L(r[0]) || !L(r[1]))
    return e;
  var t = Math.min(r[0], r[1]), a = Math.max(r[0], r[1]), n = [e[0], e[1]];
  return (!L(e[0]) || e[0] < t) && (n[0] = t), (!L(e[1]) || e[1] > a) && (n[1] = a), n[0] > a && (n[0] = a), n[1] < t && (n[1] = t), n;
}, Gm = (e) => {
  var r, t = e.length;
  if (!(t <= 0)) {
    var a = (r = e[0]) === null || r === void 0 ? void 0 : r.length;
    if (!(a == null || a <= 0))
      for (var n = 0; n < a; ++n)
        for (var i = 0, o = 0, u = 0; u < t; ++u) {
          var s = e[u], c = s == null ? void 0 : s[n];
          if (c != null) {
            var d = c[1], v = c[0], f = De(d) ? v : d;
            f >= 0 ? (c[0] = i, c[1] = i + f, i = d) : (c[0] = o, c[1] = o + f, o = d);
          }
        }
  }
}, Hm = (e) => {
  var r, t = e.length;
  if (!(t <= 0)) {
    var a = (r = e[0]) === null || r === void 0 ? void 0 : r.length;
    if (!(a == null || a <= 0))
      for (var n = 0; n < a; ++n)
        for (var i = 0, o = 0; o < t; ++o) {
          var u = e[o], s = u == null ? void 0 : u[n];
          if (s != null) {
            var c = De(s[1]) ? s[0] : s[1];
            c >= 0 ? (s[0] = i, s[1] = i + c, i = s[1]) : (s[0] = 0, s[1] = 0);
          }
        }
  }
}, Ym = {
  sign: Gm,
  // @ts-expect-error definitelytyped types are incorrect
  expand: yp,
  // @ts-expect-error definitelytyped types are incorrect
  none: bc,
  // @ts-expect-error definitelytyped types are incorrect
  silhouette: hp,
  // @ts-expect-error definitelytyped types are incorrect
  wiggle: mp,
  positive: Hm
}, Um = (e, r, t) => {
  var a, n = (a = Ym[t]) !== null && a !== void 0 ? a : bc, i = fp().keys(r).value((u, s) => Number(B(u, s, 0))).order(pp).offset(n), o = i(e);
  return o.forEach((u, s) => {
    u.forEach((c, d) => {
      var v = B(e[d], r[s], 0);
      Array.isArray(v) && v.length === 2 && L(v[0]) && L(v[1]) && (c[0] = v[0], c[1] = v[1]);
    });
  }), o;
};
function gn(e) {
  return e == null ? void 0 : String(e);
}
function ot(e) {
  var {
    axis: r,
    ticks: t,
    bandSize: a,
    entry: n,
    index: i,
    dataKey: o
  } = e;
  if (r.type === "category") {
    if (!r.allowDuplicatedCategory && r.dataKey && !U(n[r.dataKey])) {
      var u = Ic(t, "value", n[r.dataKey]);
      if (u)
        return u.coordinate + a / 2;
    }
    return t[i] ? t[i].coordinate + a / 2 : null;
  }
  var s = B(n, U(o) ? r.dataKey : o);
  return U(s) ? null : r.scale(s);
}
var Ra = (e) => {
  var {
    axis: r,
    ticks: t,
    offset: a,
    bandSize: n,
    entry: i,
    index: o
  } = e;
  if (r.type === "category")
    return t[o] ? t[o].coordinate + a : null;
  var u = B(i, r.dataKey, r.scale.domain()[o]);
  return U(u) ? null : r.scale(u) - n / 2 + a;
}, Kc = (e) => {
  var {
    numericAxis: r
  } = e, t = r.scale.domain();
  if (r.type === "number") {
    var a = Math.min(t[0], t[1]), n = Math.max(t[0], t[1]);
    return a <= 0 && n >= 0 ? 0 : n < 0 ? n : a;
  }
  return t[0];
}, Zm = (e) => {
  var r = e.flat(2).filter(L);
  return [Math.min(...r), Math.max(...r)];
}, qm = (e) => [e[0] === 1 / 0 ? 0 : e[0], e[1] === -1 / 0 ? 0 : e[1]], Jm = (e, r, t) => {
  if (e != null)
    return qm(Object.keys(e).reduce((a, n) => {
      var i = e[n];
      if (!i)
        return a;
      var {
        stackedData: o
      } = i, u = o.reduce((s, c) => {
        var d = _c(c, r, t), v = Zm(d);
        return !q(v[0]) || !q(v[1]) ? s : [Math.min(s[0], v[0]), Math.max(s[1], v[1])];
      }, [1 / 0, -1 / 0]);
      return [Math.min(u[0], a[0]), Math.max(u[1], a[1])];
    }, [1 / 0, -1 / 0]));
}, bl = /^dataMin[\s]*-[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, xl = /^dataMax[\s]*\+[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, Ne = (e, r, t) => {
  if (e && e.scale && e.scale.bandwidth) {
    var a = e.scale.bandwidth();
    if (!t || a > 0)
      return a;
  }
  if (e && r && r.length >= 2) {
    for (var n = hn(r, (d) => d.coordinate), i = 1 / 0, o = 1, u = n.length; o < u; o++) {
      var s = n[o], c = n[o - 1];
      i = Math.min(((s == null ? void 0 : s.coordinate) || 0) - ((c == null ? void 0 : c.coordinate) || 0), i);
    }
    return i === 1 / 0 ? 0 : i;
  }
  return t ? void 0 : 0;
};
function Pl(e) {
  var {
    tooltipEntrySettings: r,
    dataKey: t,
    payload: a,
    value: n,
    name: i
  } = e;
  return et(et({}, r), {}, {
    dataKey: t,
    payload: a,
    value: n,
    name: i
  });
}
function We(e, r) {
  if (e)
    return String(e);
  if (typeof r == "string")
    return r;
}
var Qm = (e, r) => {
  if (r === "horizontal")
    return e.chartX;
  if (r === "vertical")
    return e.chartY;
}, eh = (e, r) => r === "centric" ? e.angle : e.radius, wr = (e) => e.layout.width, Ar = (e) => e.layout.height, rh = (e) => e.layout.scale, zc = (e) => e.layout.margin, bn = A((e) => e.cartesianAxis.xAxis, (e) => Object.values(e)), xn = A((e) => e.cartesianAxis.yAxis, (e) => Object.values(e)), th = ["#1890FF", "#66B5FF", "#41D9C7", "#2FC25B", "#6EDB8F", "#9AE65C", "#FACC14", "#E6965C", "#57AD71", "#223273", "#738AE6", "#7564CC", "#8543E0", "#A877ED", "#5C8EE6", "#13C2C2", "#70E0E0", "#5CA3E6", "#3436C7", "#8082FF", "#DD81E6", "#F04864", "#FA7D92", "#D598D9"], Qi = "data-recharts-item-index", eo = "data-recharts-item-id", ra = 60;
function Ol(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function wa(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ol(Object(t), !0).forEach(function(a) {
      ah(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ol(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function ah(e, r, t) {
  return (r = nh(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function nh(e) {
  var r = ih(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function ih(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var oh = (e) => e.brush.height;
function lh(e) {
  var r = xn(e);
  return r.reduce((t, a) => {
    if (a.orientation === "left" && !a.mirror && !a.hide) {
      var n = typeof a.width == "number" ? a.width : ra;
      return t + n;
    }
    return t;
  }, 0);
}
function uh(e) {
  var r = xn(e);
  return r.reduce((t, a) => {
    if (a.orientation === "right" && !a.mirror && !a.hide) {
      var n = typeof a.width == "number" ? a.width : ra;
      return t + n;
    }
    return t;
  }, 0);
}
function sh(e) {
  var r = bn(e);
  return r.reduce((t, a) => a.orientation === "top" && !a.mirror && !a.hide ? t + a.height : t, 0);
}
function ch(e) {
  var r = bn(e);
  return r.reduce((t, a) => a.orientation === "bottom" && !a.mirror && !a.hide ? t + a.height : t, 0);
}
var he = A([wr, Ar, zc, oh, lh, uh, sh, ch, Tc, Tm], (e, r, t, a, n, i, o, u, s, c) => {
  var d = {
    left: (t.left || 0) + n,
    right: (t.right || 0) + i
  }, v = {
    top: (t.top || 0) + o,
    bottom: (t.bottom || 0) + u
  }, f = wa(wa({}, v), d), p = f.bottom;
  f.bottom += a, f = Xm(f, s, c);
  var m = e - f.left - f.right, h = r - f.top - f.bottom;
  return wa(wa({
    brushBottom: p
  }, f), {}, {
    // never return negative values for height and width
    width: Math.max(m, 0),
    height: Math.max(h, 0)
  });
}), dh = A(he, (e) => ({
  x: e.left,
  y: e.top,
  width: e.width,
  height: e.height
})), ro = A(wr, Ar, (e, r) => ({
  x: 0,
  y: 0,
  width: e,
  height: r
})), Wc = /* @__PURE__ */ l.createContext(null), te = () => l.useContext(Wc) != null, vh = (e) => {
  var {
    children: r
  } = e;
  return /* @__PURE__ */ l.createElement(Wc.Provider, {
    value: !0
  }, r);
}, Pn = (e) => e.brush, ta = A([Pn, he, zc], (e, r, t) => ({
  height: e.height,
  x: L(e.x) ? e.x : r.left,
  y: L(e.y) ? e.y : r.top + r.height + r.brushBottom - ((t == null ? void 0 : t.bottom) || 0),
  width: L(e.width) ? e.width : r.width
})), Ba = function(r, t) {
  for (var a = arguments.length, n = new Array(a > 2 ? a - 2 : 0), i = 2; i < a; i++)
    n[i - 2] = arguments[i];
  if (typeof console < "u" && console.warn && (t === void 0 && console.warn("LogUtils requires an error message argument"), !r))
    if (t === void 0)
      console.warn("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
    else {
      var o = 0;
      console.warn(t.replace(/%s/g, () => n[o++]));
    }
}, Fc = (e, r, t) => {
  var {
    width: a = "100%",
    height: n = "100%",
    aspect: i,
    maxHeight: o
  } = t, u = xr(a) ? e : Number(a), s = xr(n) ? r : Number(n);
  return i && i > 0 && (u ? s = u / i : s && (u = s * i), o && s != null && s > o && (s = o)), {
    calculatedWidth: u,
    calculatedHeight: s
  };
}, fh = {
  width: 0,
  height: 0,
  overflow: "visible"
}, ph = {
  width: 0,
  overflowX: "visible"
}, mh = {
  height: 0,
  overflowY: "visible"
}, hh = {}, yh = (e) => {
  var {
    width: r,
    height: t
  } = e, a = xr(r), n = xr(t);
  return a && n ? fh : a ? ph : n ? mh : hh;
};
function gh(e) {
  var {
    width: r,
    height: t,
    aspect: a
  } = e, n = r, i = t;
  return n === void 0 && i === void 0 ? (n = "100%", i = "100%") : n === void 0 ? n = a && a > 0 ? void 0 : "100%" : i === void 0 && (i = a && a > 0 ? void 0 : "100%"), {
    width: n,
    height: i
  };
}
function fi() {
  return fi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, fi.apply(null, arguments);
}
function wl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Al(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? wl(Object(t), !0).forEach(function(a) {
      bh(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : wl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function bh(e, r, t) {
  return (r = xh(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function xh(e) {
  var r = Ph(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Ph(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Xc = /* @__PURE__ */ l.createContext({
  width: -1,
  height: -1
});
function Oh(e) {
  return _e(e.width) && _e(e.height);
}
function Vc(e) {
  var {
    children: r,
    width: t,
    height: a
  } = e, n = l.useMemo(() => ({
    width: t,
    height: a
  }), [t, a]);
  return Oh(n) ? /* @__PURE__ */ l.createElement(Xc.Provider, {
    value: n
  }, r) : null;
}
var to = () => l.useContext(Xc), wh = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    aspect: t,
    initialDimension: a = {
      width: -1,
      height: -1
    },
    width: n,
    height: i,
    /*
     * default min-width to 0 if not specified - 'auto' causes issues with flexbox
     * https://github.com/recharts/recharts/issues/172
     */
    minWidth: o = 0,
    minHeight: u,
    maxHeight: s,
    children: c,
    debounce: d = 0,
    id: v,
    className: f,
    onResize: p,
    style: m = {}
  } = e, h = l.useRef(null), g = l.useRef();
  g.current = p, l.useImperativeHandle(r, () => h.current);
  var [y, b] = l.useState({
    containerWidth: a.width,
    containerHeight: a.height
  }), x = l.useCallback((j, S) => {
    b((I) => {
      var D = Math.round(j), C = Math.round(S);
      return I.containerWidth === D && I.containerHeight === C ? I : {
        containerWidth: D,
        containerHeight: C
      };
    });
  }, []);
  l.useEffect(() => {
    if (h.current == null || typeof ResizeObserver > "u")
      return ft;
    var j = (C) => {
      var M, {
        width: T,
        height: $
      } = C[0].contentRect;
      x(T, $), (M = g.current) === null || M === void 0 || M.call(g, T, $);
    };
    d > 0 && (j = gp(j, d, {
      trailing: !0,
      leading: !1
    }));
    var S = new ResizeObserver(j), {
      width: I,
      height: D
    } = h.current.getBoundingClientRect();
    return x(I, D), S.observe(h.current), () => {
      S.disconnect();
    };
  }, [x, d]);
  var {
    containerWidth: O,
    containerHeight: P
  } = y;
  Ba(!t || t > 0, "The aspect(%s) must be greater than zero.", t);
  var {
    calculatedWidth: w,
    calculatedHeight: E
  } = Fc(O, P, {
    width: n,
    height: i,
    aspect: t,
    maxHeight: s
  });
  return Ba(w != null && w > 0 || E != null && E > 0, `The width(%s) and height(%s) of chart should be greater than 0,
       please check the style of container, or the props width(%s) and height(%s),
       or add a minWidth(%s) or minHeight(%s) or use aspect(%s) to control the
       height and width.`, w, E, n, i, o, u, t), /* @__PURE__ */ l.createElement("div", {
    id: v ? "".concat(v) : void 0,
    className: R("recharts-responsive-container", f),
    style: Al(Al({}, m), {}, {
      width: n,
      height: i,
      minWidth: o,
      minHeight: u,
      maxHeight: s
    }),
    ref: h
  }, /* @__PURE__ */ l.createElement("div", {
    style: yh({
      width: n,
      height: i
    })
  }, /* @__PURE__ */ l.createElement(Vc, {
    width: w,
    height: E
  }, c)));
}), NT = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = to();
  if (_e(t.width) && _e(t.height))
    return e.children;
  var {
    width: a,
    height: n
  } = gh({
    width: e.width,
    height: e.height,
    aspect: e.aspect
  }), {
    calculatedWidth: i,
    calculatedHeight: o
  } = Fc(void 0, void 0, {
    width: a,
    height: n,
    aspect: e.aspect,
    maxHeight: e.maxHeight
  });
  return L(i) && L(o) ? /* @__PURE__ */ l.createElement(Vc, {
    width: i,
    height: o
  }, e.children) : /* @__PURE__ */ l.createElement(wh, fi({}, e, {
    width: a,
    height: n,
    ref: r
  }));
});
function Gc(e) {
  if (e)
    return {
      x: e.x,
      y: e.y,
      upperWidth: "upperWidth" in e ? e.upperWidth : e.width,
      lowerWidth: "lowerWidth" in e ? e.lowerWidth : e.width,
      width: e.width,
      height: e.height
    };
}
var pt = () => {
  var e, r = te(), t = k(dh), a = k(ta), n = (e = k(Pn)) === null || e === void 0 ? void 0 : e.padding;
  return !r || !a || !n ? t : {
    width: a.width - n.left - n.right,
    height: a.height - n.top - n.bottom,
    x: n.left,
    y: n.top
  };
}, Ah = {
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  width: 0,
  height: 0,
  brushBottom: 0
}, Hc = () => {
  var e;
  return (e = k(he)) !== null && e !== void 0 ? e : Ah;
}, aa = () => k(wr), na = () => k(Ar), Eh = () => k((e) => e.layout.margin), K = (e) => e.layout.layoutType, Er = () => k(K), jh = () => {
  var e = Er();
  if (e === "horizontal" || e === "vertical")
    return e;
}, Sh = () => {
  var e = Er();
  return e !== void 0;
}, ia = (e) => {
  var r = F(), t = te(), {
    width: a,
    height: n
  } = e, i = to(), o = a, u = n;
  return i && (o = i.width > 0 ? i.width : a, u = i.height > 0 ? i.height : n), l.useEffect(() => {
    !t && _e(o) && _e(u) && r(Rm({
      width: o,
      height: u
    }));
  }, [r, t, o, u]), null;
}, Yc = (e) => {
  var {
    margin: r
  } = e, t = F();
  return l.useEffect(() => {
    t(Mc(r));
  }, [t, r]), null;
}, Ih = {
  settings: {
    layout: "horizontal",
    align: "center",
    verticalAlign: "middle",
    itemSorter: "value"
  },
  size: {
    width: 0,
    height: 0
  },
  payload: []
}, Uc = Be({
  name: "legend",
  initialState: Ih,
  reducers: {
    setLegendSize(e, r) {
      e.size.width = r.payload.width, e.size.height = r.payload.height;
    },
    setLegendSettings(e, r) {
      e.settings.align = r.payload.align, e.settings.layout = r.payload.layout, e.settings.verticalAlign = r.payload.verticalAlign, e.settings.itemSorter = r.payload.itemSorter;
    },
    addLegendPayload: {
      reducer(e, r) {
        e.payload.push(re(r.payload));
      },
      prepare: oe()
    },
    replaceLegendPayload: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload, n = er(e).payload.indexOf(re(t));
        n > -1 && (e.payload[n] = re(a));
      },
      prepare: oe()
    },
    removeLegendPayload: {
      reducer(e, r) {
        var t = er(e).payload.indexOf(re(r.payload));
        t > -1 && e.payload.splice(t, 1);
      },
      prepare: oe()
    }
  }
}), {
  setLegendSize: El,
  setLegendSettings: kh,
  addLegendPayload: Zc,
  replaceLegendPayload: qc,
  removeLegendPayload: Jc
} = Uc.actions, Ch = Uc.reducer, Dh = ["contextPayload"];
function pi() {
  return pi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, pi.apply(null, arguments);
}
function jl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function lt(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? jl(Object(t), !0).forEach(function(a) {
      Th(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : jl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Th(e, r, t) {
  return (r = $h(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function $h(e) {
  var r = Lh(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Lh(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Mh(e, r) {
  if (e == null) return {};
  var t, a, n = _h(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function _h(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Nh(e) {
  return e.value;
}
function Rh(e) {
  var {
    contextPayload: r
  } = e, t = Mh(e, Dh), a = Dc(r, e.payloadUniqBy, Nh), n = lt(lt({}, t), {}, {
    payload: a
  });
  return /* @__PURE__ */ l.isValidElement(e.content) ? /* @__PURE__ */ l.cloneElement(e.content, n) : typeof e.content == "function" ? /* @__PURE__ */ l.createElement(e.content, n) : /* @__PURE__ */ l.createElement(Im, n);
}
function Bh(e, r, t, a, n, i) {
  var {
    layout: o,
    align: u,
    verticalAlign: s
  } = r, c, d;
  return (!e || (e.left === void 0 || e.left === null) && (e.right === void 0 || e.right === null)) && (u === "center" && o === "vertical" ? c = {
    left: ((a || 0) - i.width) / 2
  } : c = u === "right" ? {
    right: t && t.right || 0
  } : {
    left: t && t.left || 0
  }), (!e || (e.top === void 0 || e.top === null) && (e.bottom === void 0 || e.bottom === null)) && (s === "middle" ? d = {
    top: ((n || 0) - i.height) / 2
  } : d = s === "bottom" ? {
    bottom: t && t.bottom || 0
  } : {
    top: t && t.top || 0
  }), lt(lt({}, c), d);
}
function Kh(e) {
  var r = F();
  return l.useEffect(() => {
    r(kh(e));
  }, [r, e]), null;
}
function zh(e) {
  var r = F();
  return l.useEffect(() => (r(El(e)), () => {
    r(El({
      width: 0,
      height: 0
    }));
  }), [r, e]), null;
}
function Wh(e, r, t, a) {
  return e === "vertical" && L(r) ? {
    height: r
  } : e === "horizontal" ? {
    width: t || a
  } : null;
}
var Fh = {
  align: "center",
  iconSize: 14,
  itemSorter: "value",
  layout: "horizontal",
  verticalAlign: "bottom"
};
function Xh(e) {
  var r = V(e, Fh), t = Mm(), a = rm(), n = Eh(), {
    width: i,
    height: o,
    wrapperStyle: u,
    portal: s
  } = r, [c, d] = $c([t]), v = aa(), f = na();
  if (v == null || f == null)
    return null;
  var p = v - ((n == null ? void 0 : n.left) || 0) - ((n == null ? void 0 : n.right) || 0), m = Wh(r.layout, o, i, p), h = s ? u : lt(lt({
    position: "absolute",
    width: (m == null ? void 0 : m.width) || i || "auto",
    height: (m == null ? void 0 : m.height) || o || "auto"
  }, Bh(u, r, n, v, f, c)), u), g = s ?? a;
  if (g == null || t == null)
    return null;
  var y = /* @__PURE__ */ l.createElement("div", {
    className: "recharts-legend-wrapper",
    style: h,
    ref: d
  }, /* @__PURE__ */ l.createElement(Kh, {
    layout: r.layout,
    align: r.align,
    verticalAlign: r.verticalAlign,
    itemSorter: r.itemSorter
  }), !s && /* @__PURE__ */ l.createElement(zh, {
    width: c.width,
    height: c.height
  }), /* @__PURE__ */ l.createElement(Rh, pi({}, r, m, {
    margin: n,
    chartWidth: v,
    chartHeight: f,
    contextPayload: t
  })));
  return /* @__PURE__ */ Hi.createPortal(y, g);
}
Xh.displayName = "Legend";
function mi() {
  return mi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, mi.apply(null, arguments);
}
function Sl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ei(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Sl(Object(t), !0).forEach(function(a) {
      Vh(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Sl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Vh(e, r, t) {
  return (r = Gh(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Gh(e) {
  var r = Hh(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Hh(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Yh(e) {
  return Array.isArray(e) && we(e[0]) && we(e[1]) ? e.join(" ~ ") : e;
}
var Uh = (e) => {
  var {
    separator: r = " : ",
    contentStyle: t = {},
    itemStyle: a = {},
    labelStyle: n = {},
    payload: i,
    formatter: o,
    itemSorter: u,
    wrapperClassName: s,
    labelClassName: c,
    label: d,
    labelFormatter: v,
    accessibilityLayer: f = !1
  } = e, p = () => {
    if (i && i.length) {
      var P = {
        padding: 0,
        margin: 0
      }, w = (u ? hn(i, u) : i).map((E, j) => {
        if (E.type === "none")
          return null;
        var S = E.formatter || o || Yh, {
          value: I,
          name: D
        } = E, C = I, M = D;
        if (S) {
          var T = S(I, D, E, j, i);
          if (Array.isArray(T))
            [C, M] = T;
          else if (T != null)
            C = T;
          else
            return null;
        }
        var $ = ei({
          display: "block",
          paddingTop: 4,
          paddingBottom: 4,
          color: E.color || "#000"
        }, a);
        return /* @__PURE__ */ l.createElement("li", {
          className: "recharts-tooltip-item",
          key: "tooltip-item-".concat(j),
          style: $
        }, we(M) ? /* @__PURE__ */ l.createElement("span", {
          className: "recharts-tooltip-item-name"
        }, M) : null, we(M) ? /* @__PURE__ */ l.createElement("span", {
          className: "recharts-tooltip-item-separator"
        }, r) : null, /* @__PURE__ */ l.createElement("span", {
          className: "recharts-tooltip-item-value"
        }, C), /* @__PURE__ */ l.createElement("span", {
          className: "recharts-tooltip-item-unit"
        }, E.unit || ""));
      });
      return /* @__PURE__ */ l.createElement("ul", {
        className: "recharts-tooltip-item-list",
        style: P
      }, w);
    }
    return null;
  }, m = ei({
    margin: 0,
    padding: 10,
    backgroundColor: "#fff",
    border: "1px solid #ccc",
    whiteSpace: "nowrap"
  }, t), h = ei({
    margin: 0
  }, n), g = !U(d), y = g ? d : "", b = R("recharts-default-tooltip", s), x = R("recharts-tooltip-label", c);
  g && v && i !== void 0 && i !== null && (y = v(d, i));
  var O = f ? {
    role: "status",
    "aria-live": "assertive"
  } : {};
  return /* @__PURE__ */ l.createElement("div", mi({
    className: b,
    style: m
  }, O), /* @__PURE__ */ l.createElement("p", {
    className: x,
    style: h
  }, /* @__PURE__ */ l.isValidElement(y) ? y : "".concat(y)), p());
}, $t = "recharts-tooltip-wrapper", Zh = {
  visibility: "hidden"
};
function qh(e) {
  var {
    coordinate: r,
    translateX: t,
    translateY: a
  } = e;
  return R($t, {
    ["".concat($t, "-right")]: L(t) && r && L(r.x) && t >= r.x,
    ["".concat($t, "-left")]: L(t) && r && L(r.x) && t < r.x,
    ["".concat($t, "-bottom")]: L(a) && r && L(r.y) && a >= r.y,
    ["".concat($t, "-top")]: L(a) && r && L(r.y) && a < r.y
  });
}
function Il(e) {
  var {
    allowEscapeViewBox: r,
    coordinate: t,
    key: a,
    offsetTopLeft: n,
    position: i,
    reverseDirection: o,
    tooltipDimension: u,
    viewBox: s,
    viewBoxDimension: c
  } = e;
  if (i && L(i[a]))
    return i[a];
  var d = t[a] - u - (n > 0 ? n : 0), v = t[a] + n;
  if (r[a])
    return o[a] ? d : v;
  var f = s[a];
  if (f == null)
    return 0;
  if (o[a]) {
    var p = d, m = f;
    return p < m ? Math.max(v, f) : Math.max(d, f);
  }
  if (c == null)
    return 0;
  var h = v + u, g = f + c;
  return h > g ? Math.max(d, f) : Math.max(v, f);
}
function Jh(e) {
  var {
    translateX: r,
    translateY: t,
    useTranslate3d: a
  } = e;
  return {
    transform: a ? "translate3d(".concat(r, "px, ").concat(t, "px, 0)") : "translate(".concat(r, "px, ").concat(t, "px)")
  };
}
function Qh(e) {
  var {
    allowEscapeViewBox: r,
    coordinate: t,
    offsetTopLeft: a,
    position: n,
    reverseDirection: i,
    tooltipBox: o,
    useTranslate3d: u,
    viewBox: s
  } = e, c, d, v;
  return o.height > 0 && o.width > 0 && t ? (d = Il({
    allowEscapeViewBox: r,
    coordinate: t,
    key: "x",
    offsetTopLeft: a,
    position: n,
    reverseDirection: i,
    tooltipDimension: o.width,
    viewBox: s,
    viewBoxDimension: s.width
  }), v = Il({
    allowEscapeViewBox: r,
    coordinate: t,
    key: "y",
    offsetTopLeft: a,
    position: n,
    reverseDirection: i,
    tooltipDimension: o.height,
    viewBox: s,
    viewBoxDimension: s.height
  }), c = Jh({
    translateX: d,
    translateY: v,
    useTranslate3d: u
  })) : c = Zh, {
    cssProperties: c,
    cssClasses: qh({
      translateX: d,
      translateY: v,
      coordinate: t
    })
  };
}
function kl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Aa(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? kl(Object(t), !0).forEach(function(a) {
      hi(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : kl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function hi(e, r, t) {
  return (r = ey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function ey(e) {
  var r = ry(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function ry(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
class ty extends l.PureComponent {
  constructor() {
    super(...arguments), hi(this, "state", {
      dismissed: !1,
      dismissedAtCoordinate: {
        x: 0,
        y: 0
      }
    }), hi(this, "handleKeyDown", (r) => {
      if (r.key === "Escape") {
        var t, a, n, i;
        this.setState({
          dismissed: !0,
          dismissedAtCoordinate: {
            x: (t = (a = this.props.coordinate) === null || a === void 0 ? void 0 : a.x) !== null && t !== void 0 ? t : 0,
            y: (n = (i = this.props.coordinate) === null || i === void 0 ? void 0 : i.y) !== null && n !== void 0 ? n : 0
          }
        });
      }
    });
  }
  componentDidMount() {
    document.addEventListener("keydown", this.handleKeyDown);
  }
  componentWillUnmount() {
    document.removeEventListener("keydown", this.handleKeyDown);
  }
  componentDidUpdate() {
    var r, t;
    this.state.dismissed && (((r = this.props.coordinate) === null || r === void 0 ? void 0 : r.x) !== this.state.dismissedAtCoordinate.x || ((t = this.props.coordinate) === null || t === void 0 ? void 0 : t.y) !== this.state.dismissedAtCoordinate.y) && (this.state.dismissed = !1);
  }
  render() {
    var {
      active: r,
      allowEscapeViewBox: t,
      animationDuration: a,
      animationEasing: n,
      children: i,
      coordinate: o,
      hasPayload: u,
      isAnimationActive: s,
      offset: c,
      position: d,
      reverseDirection: v,
      useTranslate3d: f,
      viewBox: p,
      wrapperStyle: m,
      lastBoundingBox: h,
      innerRef: g,
      hasPortalFromProps: y
    } = this.props, {
      cssClasses: b,
      cssProperties: x
    } = Qh({
      allowEscapeViewBox: t,
      coordinate: o,
      offsetTopLeft: c,
      position: d,
      reverseDirection: v,
      tooltipBox: {
        height: h.height,
        width: h.width
      },
      useTranslate3d: f,
      viewBox: p
    }), O = y ? {} : Aa(Aa({
      transition: s && r ? "transform ".concat(a, "ms ").concat(n) : void 0
    }, x), {}, {
      pointerEvents: "none",
      visibility: !this.state.dismissed && r && u ? "visible" : "hidden",
      position: "absolute",
      top: 0,
      left: 0
    }), P = Aa(Aa({}, O), {}, {
      visibility: !this.state.dismissed && r && u ? "visible" : "hidden"
    }, m);
    return (
      // This element allow listening to the `Escape` key. See https://github.com/recharts/recharts/pull/2925
      /* @__PURE__ */ l.createElement("div", {
        // @ts-expect-error typescript library does not recognize xmlns attribute, but it's required for an HTML chunk inside SVG.
        xmlns: "http://www.w3.org/1999/xhtml",
        tabIndex: -1,
        className: b,
        style: P,
        ref: g
      }, i)
    );
  }
}
var Qc = () => {
  var e;
  return (e = k((r) => r.rootProps.accessibilityLayer)) !== null && e !== void 0 ? e : !0;
};
function yi() {
  return yi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, yi.apply(null, arguments);
}
function Cl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Dl(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Cl(Object(t), !0).forEach(function(a) {
      ay(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Cl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function ay(e, r, t) {
  return (r = ny(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function ny(e) {
  var r = iy(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function iy(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Tl = {
  curveBasisClosed: Dp,
  curveBasisOpen: Cp,
  curveBasis: kp,
  curveBumpX: Ip,
  curveBumpY: Sp,
  curveLinearClosed: jp,
  curveLinear: xc,
  curveMonotoneX: Ep,
  curveMonotoneY: Ap,
  curveNatural: wp,
  curveStep: Op,
  curveStepAfter: Pp,
  curveStepBefore: xp
}, Ka = (e) => q(e.x) && q(e.y), $l = (e) => e.base != null && Ka(e.base) && Ka(e), Lt = (e) => e.x, Mt = (e) => e.y, oy = (e, r) => {
  if (typeof e == "function")
    return e;
  var t = "curve".concat(ea(e));
  return (t === "curveMonotone" || t === "curveBump") && r ? Tl["".concat(t).concat(r === "vertical" ? "Y" : "X")] : Tl[t] || xc;
}, ly = (e) => {
  var {
    type: r = "linear",
    points: t = [],
    baseLine: a,
    layout: n,
    connectNulls: i = !1
  } = e, o = oy(r, n), u = i ? t.filter(Ka) : t, s;
  if (Array.isArray(a)) {
    var c = t.map((p, m) => Dl(Dl({}, p), {}, {
      base: a[m]
    }));
    n === "vertical" ? s = Pa().y(Mt).x1(Lt).x0((p) => p.base.x) : s = Pa().x(Lt).y1(Mt).y0((p) => p.base.y);
    var d = s.defined($l).curve(o), v = i ? c.filter($l) : c;
    return d(v);
  }
  n === "vertical" && L(a) ? s = Pa().y(Mt).x1(Lt).x0(a) : L(a) ? s = Pa().x(Lt).y1(Mt).y0(a) : s = bp().x(Lt).y(Mt);
  var f = s.defined(Ka).curve(o);
  return f(u);
}, zr = (e) => {
  var {
    className: r,
    points: t,
    path: a,
    pathRef: n
  } = e, i = Er();
  if ((!t || !t.length) && !a)
    return null;
  var o = {
    type: e.type,
    points: e.points,
    baseLine: e.baseLine,
    layout: e.layout || i,
    connectNulls: e.connectNulls
  }, u = t && t.length ? ly(o) : a;
  return /* @__PURE__ */ l.createElement("path", yi({}, G(e), qi(e), {
    className: R("recharts-curve", r),
    d: u === null ? void 0 : u,
    ref: n
  }));
}, uy = ["x", "y", "top", "left", "width", "height", "className"];
function gi() {
  return gi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, gi.apply(null, arguments);
}
function Ll(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function sy(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ll(Object(t), !0).forEach(function(a) {
      cy(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ll(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function cy(e, r, t) {
  return (r = dy(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function dy(e) {
  var r = vy(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function vy(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function fy(e, r) {
  if (e == null) return {};
  var t, a, n = py(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function py(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var my = (e, r, t, a, n, i) => "M".concat(e, ",").concat(n, "v").concat(a, "M").concat(i, ",").concat(r, "h").concat(t), hy = (e) => {
  var {
    x: r = 0,
    y: t = 0,
    top: a = 0,
    left: n = 0,
    width: i = 0,
    height: o = 0,
    className: u
  } = e, s = fy(e, uy), c = sy({
    x: r,
    y: t,
    top: a,
    left: n,
    width: i,
    height: o
  }, s);
  return !L(r) || !L(t) || !L(i) || !L(o) || !L(a) || !L(n) ? null : /* @__PURE__ */ l.createElement("path", gi({}, le(c), {
    className: R("recharts-cross", u),
    d: my(r, t, i, o, a, n)
  }));
};
function yy(e, r, t, a) {
  var n = a / 2;
  return {
    stroke: "none",
    fill: "#ccc",
    x: e === "horizontal" ? r.x - n : t.left + 0.5,
    y: e === "horizontal" ? t.top + 0.5 : r.y - n,
    width: e === "horizontal" ? a : t.width - 1,
    height: e === "horizontal" ? t.height - 1 : a
  };
}
function Ml(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function _l(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ml(Object(t), !0).forEach(function(a) {
      gy(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ml(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function gy(e, r, t) {
  return (r = by(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function by(e) {
  var r = xy(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function xy(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Py = (e) => e.replace(/([A-Z])/g, (r) => "-".concat(r.toLowerCase())), ao = (e, r, t) => e.map((a) => "".concat(Py(a), " ").concat(r, "ms ").concat(t)).join(","), Oy = (e, r) => [Object.keys(e), Object.keys(r)].reduce((t, a) => t.filter((n) => a.includes(n))), Wt = (e, r) => Object.keys(r).reduce((t, a) => _l(_l({}, t), {}, {
  [a]: e(a, r[a])
}), {});
function Nl(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function be(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Nl(Object(t), !0).forEach(function(a) {
      wy(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Nl(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function wy(e, r, t) {
  return (r = Ay(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ay(e) {
  var r = Ey(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Ey(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var za = (e, r, t) => e + (r - e) * t, bi = (e) => {
  var {
    from: r,
    to: t
  } = e;
  return r !== t;
}, ed = (e, r, t) => {
  var a = Wt((n, i) => {
    if (bi(i)) {
      var [o, u] = e(i.from, i.to, i.velocity);
      return be(be({}, i), {}, {
        from: o,
        velocity: u
      });
    }
    return i;
  }, r);
  return t < 1 ? Wt((n, i) => bi(i) && a[n] != null ? be(be({}, i), {}, {
    velocity: za(i.velocity, a[n].velocity, t),
    from: za(i.from, a[n].from, t)
  }) : i, r) : ed(e, a, t - 1);
};
function jy(e, r, t, a, n, i) {
  var o, u = a.reduce((f, p) => be(be({}, f), {}, {
    [p]: {
      from: e[p],
      velocity: 0,
      to: r[p]
    }
  }), {}), s = () => Wt((f, p) => p.from, u), c = () => !Object.values(u).filter(bi).length, d = null, v = (f) => {
    o || (o = f);
    var p = f - o, m = p / t.dt;
    u = ed(t, u, m), n(be(be(be({}, e), r), s())), o = f, c() || (d = i.setTimeout(v));
  };
  return () => (d = i.setTimeout(v), () => {
    var f;
    (f = d) === null || f === void 0 || f();
  });
}
function Sy(e, r, t, a, n, i, o) {
  var u = null, s = n.reduce((v, f) => {
    var p = e[f], m = r[f];
    return p == null || m == null ? v : be(be({}, v), {}, {
      [f]: [p, m]
    });
  }, {}), c, d = (v) => {
    c || (c = v);
    var f = (v - c) / a, p = Wt((h, g) => za(...g, t(f)), s);
    if (i(be(be(be({}, e), r), p)), f < 1)
      u = o.setTimeout(d);
    else {
      var m = Wt((h, g) => za(...g, t(1)), s);
      i(be(be(be({}, e), r), m));
    }
  };
  return () => (u = o.setTimeout(d), () => {
    var v;
    (v = u) === null || v === void 0 || v();
  });
}
const Iy = (e, r, t, a, n, i) => {
  var o = Oy(e, r);
  return t == null ? () => (n(be(be({}, e), r)), () => {
  }) : t.isStepper === !0 ? jy(e, r, t, o, n, i) : Sy(e, r, t, a, o, n, i);
};
var Wa = 1e-4, rd = (e, r) => [0, 3 * e, 3 * r - 6 * e, 3 * e - 3 * r + 1], td = (e, r) => e.map((t, a) => t * r ** a).reduce((t, a) => t + a), Rl = (e, r) => (t) => {
  var a = rd(e, r);
  return td(a, t);
}, ky = (e, r) => (t) => {
  var a = rd(e, r), n = [...a.map((i, o) => i * o).slice(1), 0];
  return td(n, t);
}, Cy = (e) => {
  var r, t = e.split("(");
  if (t.length !== 2 || t[0] !== "cubic-bezier")
    return null;
  var a = (r = t[1]) === null || r === void 0 || (r = r.split(")")[0]) === null || r === void 0 ? void 0 : r.split(",");
  if (a == null || a.length !== 4)
    return null;
  var n = a.map((i) => parseFloat(i));
  return [n[0], n[1], n[2], n[3]];
}, Dy = function() {
  for (var r = arguments.length, t = new Array(r), a = 0; a < r; a++)
    t[a] = arguments[a];
  if (t.length === 1)
    switch (t[0]) {
      case "linear":
        return [0, 0, 1, 1];
      case "ease":
        return [0.25, 0.1, 0.25, 1];
      case "ease-in":
        return [0.42, 0, 1, 1];
      case "ease-out":
        return [0.42, 0, 0.58, 1];
      case "ease-in-out":
        return [0, 0, 0.58, 1];
      default: {
        var n = Cy(t[0]);
        if (n)
          return n;
      }
    }
  return t.length === 4 ? t : [0, 0, 1, 1];
}, Ty = (e, r, t, a) => {
  var n = Rl(e, t), i = Rl(r, a), o = ky(e, t), u = (c) => c > 1 ? 1 : c < 0 ? 0 : c, s = (c) => {
    for (var d = c > 1 ? 1 : c, v = d, f = 0; f < 8; ++f) {
      var p = n(v) - d, m = o(v);
      if (Math.abs(p - d) < Wa || m < Wa)
        return i(v);
      v = u(v - p / m);
    }
    return i(v);
  };
  return s.isStepper = !1, s;
}, Bl = function() {
  return Ty(...Dy(...arguments));
}, $y = function() {
  var r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, {
    stiff: t = 100,
    damping: a = 8,
    dt: n = 17
  } = r, i = (o, u, s) => {
    var c = -(o - u) * t, d = s * a, v = s + (c - d) * n / 1e3, f = s * n / 1e3 + o;
    return Math.abs(f - u) < Wa && Math.abs(v) < Wa ? [u, 0] : [f, v];
  };
  return i.isStepper = !0, i.dt = n, i;
}, Ly = (e) => {
  if (typeof e == "string")
    switch (e) {
      case "ease":
      case "ease-in-out":
      case "ease-out":
      case "ease-in":
      case "linear":
        return Bl(e);
      case "spring":
        return $y();
      default:
        if (e.split("(")[0] === "cubic-bezier")
          return Bl(e);
    }
  return typeof e == "function" ? e : null;
};
function My(e) {
  var r, t = () => null, a = !1, n = null, i = (o) => {
    if (!a) {
      if (Array.isArray(o)) {
        if (!o.length)
          return;
        var u = o, [s, ...c] = u;
        if (typeof s == "number") {
          n = e.setTimeout(i.bind(null, c), s);
          return;
        }
        i(s), n = e.setTimeout(i.bind(null, c));
        return;
      }
      typeof o == "string" && (r = o, t(r)), typeof o == "object" && (r = o, t(r)), typeof o == "function" && o();
    }
  };
  return {
    stop: () => {
      a = !0;
    },
    start: (o) => {
      a = !1, n && (n(), n = null), i(o);
    },
    subscribe: (o) => (t = o, () => {
      t = () => null;
    }),
    getTimeoutController: () => e
  };
}
class _y {
  setTimeout(r) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, a = performance.now(), n = null, i = (o) => {
      o - a >= t ? r(o) : typeof requestAnimationFrame == "function" && (n = requestAnimationFrame(i));
    };
    return n = requestAnimationFrame(i), () => {
      n != null && cancelAnimationFrame(n);
    };
  }
}
function Ny() {
  return My(new _y());
}
var Ry = /* @__PURE__ */ l.createContext(Ny);
function ad(e, r) {
  var t = l.useContext(Ry);
  return l.useMemo(() => r ?? t(e), [e, r, t]);
}
var By = () => !(typeof window < "u" && window.document && window.document.createElement && window.setTimeout), mt = {
  isSsr: By()
}, Ky = {
  begin: 0,
  duration: 1e3,
  easing: "ease",
  isActive: !0,
  canBegin: !0,
  onAnimationEnd: () => {
  },
  onAnimationStart: () => {
  }
}, Kl = {
  t: 0
}, ri = {
  t: 1
};
function ir(e) {
  var r = V(e, Ky), {
    isActive: t,
    canBegin: a,
    duration: n,
    easing: i,
    begin: o,
    onAnimationEnd: u,
    onAnimationStart: s,
    children: c
  } = r, d = t === "auto" ? !mt.isSsr : t, v = ad(r.animationId, r.animationManager), [f, p] = l.useState(d ? Kl : ri), m = l.useRef(null);
  return l.useEffect(() => {
    d || p(ri);
  }, [d]), l.useEffect(() => {
    if (!d || !a)
      return ft;
    var h = Iy(Kl, ri, Ly(i), n, p, v.getTimeoutController()), g = () => {
      m.current = h();
    };
    return v.start([s, o, g, n, u]), () => {
      v.stop(), m.current && m.current(), u();
    };
  }, [d, a, n, i, o, s, u, v]), c(f.t);
}
function or(e) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "animation-", t = l.useRef(it(r)), a = l.useRef(e);
  return a.current !== e && (t.current = it(r), a.current = e), t.current;
}
var zy = ["radius"], Wy = ["radius"], zl, Wl, Fl, Xl, Vl, Gl, Hl, Yl, Ul, Zl;
function ql(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Jl(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ql(Object(t), !0).forEach(function(a) {
      Fy(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ql(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Fy(e, r, t) {
  return (r = Xy(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Xy(e) {
  var r = Vy(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Vy(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Fa() {
  return Fa = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Fa.apply(null, arguments);
}
function Ql(e, r) {
  if (e == null) return {};
  var t, a, n = Gy(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function Gy(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Ze(e, r) {
  return r || (r = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(r) } }));
}
var eu = (e, r, t, a, n) => {
  var i = Cr(t), o = Cr(a), u = Math.min(Math.abs(i) / 2, Math.abs(o) / 2), s = o >= 0 ? 1 : -1, c = i >= 0 ? 1 : -1, d = o >= 0 && i >= 0 || o < 0 && i < 0 ? 1 : 0, v;
  if (u > 0 && n instanceof Array) {
    for (var f = [0, 0, 0, 0], p = 0, m = 4; p < m; p++)
      f[p] = n[p] > u ? u : n[p];
    v = ue(zl || (zl = Ze(["M", ",", ""])), e, r + s * f[0]), f[0] > 0 && (v += ue(Wl || (Wl = Ze(["A ", ",", ",0,0,", ",", ",", ""])), f[0], f[0], d, e + c * f[0], r)), v += ue(Fl || (Fl = Ze(["L ", ",", ""])), e + t - c * f[1], r), f[1] > 0 && (v += ue(Xl || (Xl = Ze(["A ", ",", ",0,0,", `,
        `, ",", ""])), f[1], f[1], d, e + t, r + s * f[1])), v += ue(Vl || (Vl = Ze(["L ", ",", ""])), e + t, r + a - s * f[2]), f[2] > 0 && (v += ue(Gl || (Gl = Ze(["A ", ",", ",0,0,", `,
        `, ",", ""])), f[2], f[2], d, e + t - c * f[2], r + a)), v += ue(Hl || (Hl = Ze(["L ", ",", ""])), e + c * f[3], r + a), f[3] > 0 && (v += ue(Yl || (Yl = Ze(["A ", ",", ",0,0,", `,
        `, ",", ""])), f[3], f[3], d, e, r + a - s * f[3])), v += "Z";
  } else if (u > 0 && n === +n && n > 0) {
    var h = Math.min(u, n);
    v = ue(Ul || (Ul = Ze(["M ", ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", `
            L `, ",", `
            A `, ",", ",0,0,", ",", ",", " Z"])), e, r + s * h, h, h, d, e + c * h, r, e + t - c * h, r, h, h, d, e + t, r + s * h, e + t, r + a - s * h, h, h, d, e + t - c * h, r + a, e + c * h, r + a, h, h, d, e, r + a - s * h);
  } else
    v = ue(Zl || (Zl = Ze(["M ", ",", " h ", " v ", " h ", " Z"])), e, r, t, a, -t);
  return v;
}, ru = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  // The radius of border
  // The radius of four corners when radius is a number
  // The radius of left-top, right-top, right-bottom, left-bottom when radius is an array
  radius: 0,
  isAnimationActive: !1,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, oa = (e) => {
  var r = V(e, ru), t = l.useRef(null), [a, n] = l.useState(-1);
  l.useEffect(() => {
    if (t.current && t.current.getTotalLength)
      try {
        var X = t.current.getTotalLength();
        X && n(X);
      } catch {
      }
  }, []);
  var {
    x: i,
    y: o,
    width: u,
    height: s,
    radius: c,
    className: d
  } = r, {
    animationEasing: v,
    animationDuration: f,
    animationBegin: p,
    isAnimationActive: m,
    isUpdateAnimationActive: h
  } = r, g = l.useRef(u), y = l.useRef(s), b = l.useRef(i), x = l.useRef(o), O = l.useMemo(() => ({
    x: i,
    y: o,
    width: u,
    height: s,
    radius: c
  }), [i, o, u, s, c]), P = or(O, "rectangle-");
  if (i !== +i || o !== +o || u !== +u || s !== +s || u === 0 || s === 0)
    return null;
  var w = R("recharts-rectangle", d);
  if (!h) {
    var E = le(r), {
      radius: j
    } = E, S = Ql(E, zy);
    return /* @__PURE__ */ l.createElement("path", Fa({}, S, {
      x: Cr(i),
      y: Cr(o),
      width: Cr(u),
      height: Cr(s),
      radius: typeof c == "number" ? c : void 0,
      className: w,
      d: eu(i, o, u, s, c)
    }));
  }
  var I = g.current, D = y.current, C = b.current, M = x.current, T = "0px ".concat(a === -1 ? 1 : a, "px"), $ = "".concat(a, "px 0px"), W = ao(["strokeDasharray"], f, typeof v == "string" ? v : ru.animationEasing);
  return /* @__PURE__ */ l.createElement(ir, {
    animationId: P,
    key: P,
    canBegin: a > 0,
    duration: f,
    easing: v,
    isActive: h,
    begin: p
  }, (X) => {
    var Z = N(I, u, X), z = N(D, s, X), ne = N(C, i, X), ge = N(M, o, X);
    t.current && (g.current = Z, y.current = z, b.current = ne, x.current = ge);
    var fe;
    m ? X > 0 ? fe = {
      transition: W,
      strokeDasharray: $
    } : fe = {
      strokeDasharray: T
    } : fe = {
      strokeDasharray: $
    };
    var Ke = le(r), {
      radius: je
    } = Ke, Fe = Ql(Ke, Wy);
    return /* @__PURE__ */ l.createElement("path", Fa({}, Fe, {
      radius: typeof c == "number" ? c : void 0,
      className: w,
      d: eu(ne, ge, Z, z, c),
      ref: t,
      style: Jl(Jl({}, fe), r.style)
    }));
  });
};
function tu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function au(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? tu(Object(t), !0).forEach(function(a) {
      Hy(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : tu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Hy(e, r, t) {
  return (r = Yy(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Yy(e) {
  var r = Uy(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Uy(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Xa = Math.PI / 180, Va = (e) => e * Math.PI / 180, Zy = (e) => e * 180 / Math.PI, J = (e, r, t, a) => ({
  x: e + Math.cos(-Xa * a) * t,
  y: r + Math.sin(-Xa * a) * t
}), nd = function(r, t) {
  var a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
  return Math.min(Math.abs(r - (a.left || 0) - (a.right || 0)), Math.abs(t - (a.top || 0) - (a.bottom || 0))) / 2;
}, qy = (e, r) => {
  var {
    x: t,
    y: a
  } = e, {
    x: n,
    y: i
  } = r;
  return Math.sqrt((t - n) ** 2 + (a - i) ** 2);
}, Jy = (e, r) => {
  var {
    x: t,
    y: a
  } = e, {
    cx: n,
    cy: i
  } = r, o = qy({
    x: t,
    y: a
  }, {
    x: n,
    y: i
  });
  if (o <= 0)
    return {
      radius: o,
      angle: 0
    };
  var u = (t - n) / o, s = Math.acos(u);
  return a > i && (s = 2 * Math.PI - s), {
    radius: o,
    angle: Zy(s),
    angleInRadian: s
  };
}, Qy = (e) => {
  var {
    startAngle: r,
    endAngle: t
  } = e, a = Math.floor(r / 360), n = Math.floor(t / 360), i = Math.min(a, n);
  return {
    startAngle: r - i * 360,
    endAngle: t - i * 360
  };
}, eg = (e, r) => {
  var {
    startAngle: t,
    endAngle: a
  } = r, n = Math.floor(t / 360), i = Math.floor(a / 360), o = Math.min(n, i);
  return e + o * 360;
}, rg = (e, r) => {
  var {
    chartX: t,
    chartY: a
  } = e, {
    radius: n,
    angle: i
  } = Jy({
    x: t,
    y: a
  }, r), {
    innerRadius: o,
    outerRadius: u
  } = r;
  if (n < o || n > u || n === 0)
    return null;
  var {
    startAngle: s,
    endAngle: c
  } = Qy(r), d = i, v;
  if (s <= c) {
    for (; d > c; )
      d -= 360;
    for (; d < s; )
      d += 360;
    v = d >= s && d <= c;
  } else {
    for (; d > s; )
      d -= 360;
    for (; d < c; )
      d += 360;
    v = d >= c && d <= s;
  }
  return v ? au(au({}, r), {}, {
    radius: n,
    angle: eg(d, r)
  }) : null;
}, id = (e) => !/* @__PURE__ */ l.isValidElement(e) && typeof e != "function" && typeof e != "boolean" && e != null ? e.className : "";
function od(e) {
  var {
    cx: r,
    cy: t,
    radius: a,
    startAngle: n,
    endAngle: i
  } = e, o = J(r, t, a, n), u = J(r, t, a, i);
  return {
    points: [o, u],
    cx: r,
    cy: t,
    radius: a,
    startAngle: n,
    endAngle: i
  };
}
var nu, iu, ou, lu, uu, su, cu;
function xi() {
  return xi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, xi.apply(null, arguments);
}
function Br(e, r) {
  return r || (r = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(r) } }));
}
var tg = (e, r) => {
  var t = me(r - e), a = Math.min(Math.abs(r - e), 359.999);
  return t * a;
}, Ea = (e) => {
  var {
    cx: r,
    cy: t,
    radius: a,
    angle: n,
    sign: i,
    isExternal: o,
    cornerRadius: u,
    cornerIsExternal: s
  } = e, c = u * (o ? 1 : -1) + a, d = Math.asin(u / c) / Xa, v = s ? n : n + i * d, f = J(r, t, c, v), p = J(r, t, a, v), m = s ? n - i * d : n, h = J(r, t, c * Math.cos(d * Xa), m);
  return {
    center: f,
    circleTangency: p,
    lineTangency: h,
    theta: d
  };
}, ld = (e) => {
  var {
    cx: r,
    cy: t,
    innerRadius: a,
    outerRadius: n,
    startAngle: i,
    endAngle: o
  } = e, u = tg(i, o), s = i + u, c = J(r, t, n, i), d = J(r, t, n, s), v = ue(nu || (nu = Br(["M ", ",", `
    A `, ",", `,0,
    `, ",", `,
    `, ",", `
  `])), c.x, c.y, n, n, +(Math.abs(u) > 180), +(i > s), d.x, d.y);
  if (a > 0) {
    var f = J(r, t, a, i), p = J(r, t, a, s);
    v += ue(iu || (iu = Br(["L ", ",", `
            A `, ",", `,0,
            `, ",", `,
            `, ",", " Z"])), p.x, p.y, a, a, +(Math.abs(u) > 180), +(i <= s), f.x, f.y);
  } else
    v += ue(ou || (ou = Br(["L ", ",", " Z"])), r, t);
  return v;
}, ag = (e) => {
  var {
    cx: r,
    cy: t,
    innerRadius: a,
    outerRadius: n,
    cornerRadius: i,
    forceCornerRadius: o,
    cornerIsExternal: u,
    startAngle: s,
    endAngle: c
  } = e, d = me(c - s), {
    circleTangency: v,
    lineTangency: f,
    theta: p
  } = Ea({
    cx: r,
    cy: t,
    radius: n,
    angle: s,
    sign: d,
    cornerRadius: i,
    cornerIsExternal: u
  }), {
    circleTangency: m,
    lineTangency: h,
    theta: g
  } = Ea({
    cx: r,
    cy: t,
    radius: n,
    angle: c,
    sign: -d,
    cornerRadius: i,
    cornerIsExternal: u
  }), y = u ? Math.abs(s - c) : Math.abs(s - c) - p - g;
  if (y < 0)
    return o ? ue(lu || (lu = Br(["M ", ",", `
        a`, ",", ",0,0,1,", `,0
        a`, ",", ",0,0,1,", `,0
      `])), f.x, f.y, i, i, i * 2, i, i, -i * 2) : ld({
      cx: r,
      cy: t,
      innerRadius: a,
      outerRadius: n,
      startAngle: s,
      endAngle: c
    });
  var b = ue(uu || (uu = Br(["M ", ",", `
    A`, ",", ",0,0,", ",", ",", `
    A`, ",", ",0,", ",", ",", ",", `
    A`, ",", ",0,0,", ",", ",", `
  `])), f.x, f.y, i, i, +(d < 0), v.x, v.y, n, n, +(y > 180), +(d < 0), m.x, m.y, i, i, +(d < 0), h.x, h.y);
  if (a > 0) {
    var {
      circleTangency: x,
      lineTangency: O,
      theta: P
    } = Ea({
      cx: r,
      cy: t,
      radius: a,
      angle: s,
      sign: d,
      isExternal: !0,
      cornerRadius: i,
      cornerIsExternal: u
    }), {
      circleTangency: w,
      lineTangency: E,
      theta: j
    } = Ea({
      cx: r,
      cy: t,
      radius: a,
      angle: c,
      sign: -d,
      isExternal: !0,
      cornerRadius: i,
      cornerIsExternal: u
    }), S = u ? Math.abs(s - c) : Math.abs(s - c) - P - j;
    if (S < 0 && i === 0)
      return "".concat(b, "L").concat(r, ",").concat(t, "Z");
    b += ue(su || (su = Br(["L", ",", `
      A`, ",", ",0,0,", ",", ",", `
      A`, ",", ",0,", ",", ",", ",", `
      A`, ",", ",0,0,", ",", ",", "Z"])), E.x, E.y, i, i, +(d < 0), w.x, w.y, a, a, +(S > 180), +(d > 0), x.x, x.y, i, i, +(d < 0), O.x, O.y);
  } else
    b += ue(cu || (cu = Br(["L", ",", "Z"])), r, t);
  return b;
}, ng = {
  cx: 0,
  cy: 0,
  innerRadius: 0,
  outerRadius: 0,
  startAngle: 0,
  endAngle: 0,
  cornerRadius: 0,
  forceCornerRadius: !1,
  cornerIsExternal: !1
}, ud = (e) => {
  var r = V(e, ng), {
    cx: t,
    cy: a,
    innerRadius: n,
    outerRadius: i,
    cornerRadius: o,
    forceCornerRadius: u,
    cornerIsExternal: s,
    startAngle: c,
    endAngle: d,
    className: v
  } = r;
  if (i < n || c === d)
    return null;
  var f = R("recharts-sector", v), p = i - n, m = Ee(o, p, 0, !0), h;
  return m > 0 && Math.abs(c - d) < 360 ? h = ag({
    cx: t,
    cy: a,
    innerRadius: n,
    outerRadius: i,
    cornerRadius: Math.min(m, p / 2),
    forceCornerRadius: u,
    cornerIsExternal: s,
    startAngle: c,
    endAngle: d
  }) : h = ld({
    cx: t,
    cy: a,
    innerRadius: n,
    outerRadius: i,
    startAngle: c,
    endAngle: d
  }), /* @__PURE__ */ l.createElement("path", xi({}, le(r), {
    className: f,
    d: h
  }));
};
function ig(e, r, t) {
  if (e === "horizontal")
    return [{
      x: r.x,
      y: t.top
    }, {
      x: r.x,
      y: t.top + t.height
    }];
  if (e === "vertical")
    return [{
      x: t.left,
      y: r.y
    }, {
      x: t.left + t.width,
      y: r.y
    }];
  if (Cc(r)) {
    if (e === "centric") {
      var {
        cx: a,
        cy: n,
        innerRadius: i,
        outerRadius: o,
        angle: u
      } = r, s = J(a, n, i, u), c = J(a, n, o, u);
      return [{
        x: s.x,
        y: s.y
      }, {
        x: c.x,
        y: c.y
      }];
    }
    return od(r);
  }
}
var lr = (e) => e.chartData, Lr = A([lr], (e) => {
  var r = e.chartData != null ? e.chartData.length - 1 : 0;
  return {
    chartData: e.chartData,
    computedData: e.computedData,
    dataEndIndex: r,
    dataStartIndex: 0
  };
}), On = (e, r, t, a) => a ? Lr(e) : lr(e), sd = (e, r, t) => t ? Lr(e) : lr(e);
function Dr(e) {
  if (Array.isArray(e) && e.length === 2) {
    var [r, t] = e;
    if (q(r) && q(t))
      return !0;
  }
  return !1;
}
function du(e, r, t) {
  return t ? e : [Math.min(e[0], r[0]), Math.max(e[1], r[1])];
}
function cd(e, r) {
  if (r && typeof e != "function" && Array.isArray(e) && e.length === 2) {
    var [t, a] = e, n, i;
    if (q(t))
      n = t;
    else if (typeof t == "function")
      return;
    if (q(a))
      i = a;
    else if (typeof a == "function")
      return;
    var o = [n, i];
    if (Dr(o))
      return o;
  }
}
function og(e, r, t) {
  if (!(!t && r == null)) {
    if (typeof e == "function" && r != null)
      try {
        var a = e(r, t);
        if (Dr(a))
          return du(a, r, t);
      } catch {
      }
    if (Array.isArray(e) && e.length === 2) {
      var [n, i] = e, o, u;
      if (n === "auto")
        r != null && (o = Math.min(...r));
      else if (L(n))
        o = n;
      else if (typeof n == "function")
        try {
          r != null && (o = n(r == null ? void 0 : r[0]));
        } catch {
        }
      else if (typeof n == "string" && bl.test(n)) {
        var s = bl.exec(n);
        if (s == null || s[1] == null || r == null)
          o = void 0;
        else {
          var c = +s[1];
          o = r[0] - c;
        }
      } else
        o = r == null ? void 0 : r[0];
      if (i === "auto")
        r != null && (u = Math.max(...r));
      else if (L(i))
        u = i;
      else if (typeof i == "function")
        try {
          r != null && (u = i(r == null ? void 0 : r[1]));
        } catch {
        }
      else if (typeof i == "string" && xl.test(i)) {
        var d = xl.exec(i);
        if (d == null || d[1] == null || r == null)
          u = void 0;
        else {
          var v = +d[1];
          u = r[1] + v;
        }
      } else
        u = r == null ? void 0 : r[1];
      var f = [o, u];
      if (Dr(f))
        return r == null ? f : du(f, r, t);
    }
  }
}
var lg = (e) => e, dd = {}, vd = (e) => e === dd, vu = (e) => function r() {
  return arguments.length === 0 || arguments.length === 1 && vd(arguments.length <= 0 ? void 0 : arguments[0]) ? r : e(...arguments);
}, fd = (e, r) => e === 1 ? r : vu(function() {
  for (var t = arguments.length, a = new Array(t), n = 0; n < t; n++)
    a[n] = arguments[n];
  var i = a.filter((o) => o !== dd).length;
  return i >= e ? r(...a) : fd(e - i, vu(function() {
    for (var o = arguments.length, u = new Array(o), s = 0; s < o; s++)
      u[s] = arguments[s];
    var c = a.map((d) => vd(d) ? u.shift() : d);
    return r(...c, ...u);
  }));
}), ug = (e) => fd(e.length, e), Pi = (e, r) => {
  for (var t = [], a = e; a < r; ++a)
    t[a - e] = a;
  return t;
}, sg = ug((e, r) => Array.isArray(r) ? r.map(e) : Object.keys(r).map((t) => r[t]).map(e)), cg = function() {
  for (var r = arguments.length, t = new Array(r), a = 0; a < r; a++)
    t[a] = arguments[a];
  if (!t.length)
    return lg;
  var n = t.reverse(), i = n[0], o = n.slice(1);
  return function() {
    return o.reduce((u, s) => s(u), i(...arguments));
  };
};
function pd(e) {
  var r;
  return e === 0 ? r = 1 : r = Math.floor(new Q(e).abs().log(10).toNumber()) + 1, r;
}
function md(e, r, t) {
  for (var a = new Q(e), n = 0, i = []; a.lt(r) && n < 1e5; )
    i.push(a.toNumber()), a = a.add(t), n++;
  return i;
}
var hd = (e) => {
  var [r, t] = e, [a, n] = [r, t];
  return r > t && ([a, n] = [t, r]), [a, n];
}, yd = (e, r, t) => {
  if (e.lte(0))
    return new Q(0);
  var a = pd(e.toNumber()), n = new Q(10).pow(a), i = e.div(n), o = a !== 1 ? 0.05 : 0.1, u = new Q(Math.ceil(i.div(o).toNumber())).add(t).mul(o), s = u.mul(n);
  return r ? new Q(s.toNumber()) : new Q(Math.ceil(s.toNumber()));
}, dg = (e, r, t) => {
  var a = new Q(1), n = new Q(e);
  if (!n.isint() && t) {
    var i = Math.abs(e);
    i < 1 ? (a = new Q(10).pow(pd(e) - 1), n = new Q(Math.floor(n.div(a).toNumber())).mul(a)) : i > 1 && (n = new Q(Math.floor(e)));
  } else e === 0 ? n = new Q(Math.floor((r - 1) / 2)) : t || (n = new Q(Math.floor(e)));
  var o = Math.floor((r - 1) / 2), u = cg(sg((s) => n.add(new Q(s - o).mul(a)).toNumber()), Pi);
  return u(0, r);
}, gd = function(r, t, a, n) {
  var i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
  if (!Number.isFinite((t - r) / (a - 1)))
    return {
      step: new Q(0),
      tickMin: new Q(0),
      tickMax: new Q(0)
    };
  var o = yd(new Q(t).sub(r).div(a - 1), n, i), u;
  r <= 0 && t >= 0 ? u = new Q(0) : (u = new Q(r).add(t).div(2), u = u.sub(new Q(u).mod(o)));
  var s = Math.ceil(u.sub(r).div(o).toNumber()), c = Math.ceil(new Q(t).sub(u).div(o).toNumber()), d = s + c + 1;
  return d > a ? gd(r, t, a, n, i + 1) : (d < a && (c = t > 0 ? c + (a - d) : c, s = t > 0 ? s : s + (a - d)), {
    step: o,
    tickMin: u.sub(new Q(s).mul(o)),
    tickMax: u.add(new Q(c).mul(o))
  });
}, vg = function(r) {
  var [t, a] = r, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 6, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, o = Math.max(n, 2), [u, s] = hd([t, a]);
  if (u === -1 / 0 || s === 1 / 0) {
    var c = s === 1 / 0 ? [u, ...Pi(0, n - 1).map(() => 1 / 0)] : [...Pi(0, n - 1).map(() => -1 / 0), s];
    return t > a ? c.reverse() : c;
  }
  if (u === s)
    return dg(u, n, i);
  var {
    step: d,
    tickMin: v,
    tickMax: f
  } = gd(u, s, o, i, 0), p = md(v, f.add(new Q(0.1).mul(d)), d);
  return t > a ? p.reverse() : p;
}, fg = function(r, t) {
  var [a, n] = r, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, [o, u] = hd([a, n]);
  if (o === -1 / 0 || u === 1 / 0)
    return [a, n];
  if (o === u)
    return [o];
  var s = Math.max(t, 2), c = yd(new Q(u).sub(o).div(s - 1), i, 0), d = [...md(new Q(o), new Q(u), c), u];
  return i === !1 && (d = d.map((v) => Math.round(v))), a > n ? d.reverse() : d;
}, wn = (e) => e.rootProps.maxBarSize, bd = (e) => e.rootProps.barGap, no = (e) => e.rootProps.barCategoryGap, xd = (e) => e.rootProps.barSize, ht = (e) => e.rootProps.stackOffset, io = (e) => e.rootProps.reverseStackOrder, oo = (e) => e.options.chartName, An = (e) => e.rootProps.syncId, Pd = (e) => e.rootProps.syncMethod, En = (e) => e.options.eventEmitter, pg = (e) => e.rootProps.baseValue, Y = {
  /**
   * CartesianGrid and PolarGrid
   */
  grid: -100,
  /**
   * Background of Bar and RadialBar.
   * This is not visible by default but can be enabled by setting background={true} on Bar or RadialBar.
   */
  barBackground: -50,
  /*
   * other chart elements or custom elements without specific zIndex
   * render in here, at zIndex 0
   */
  /**
   * Area, Pie, Radar, and ReferenceArea
   */
  area: 100,
  /**
   * Cursor is embedded inside Tooltip and controlled by it.
   * The Tooltip itself has a separate portal and is not included in the zIndex system;
   * Cursor is the decoration inside the chart area. CursorRectangle is a rectangle box.
   * It renders below bar so that in a stacked bar chart the cursor rectangle does not hide the other bars.
   */
  cursorRectangle: 200,
  /**
   * Bar and RadialBar
   */
  bar: 300,
  /**
   * Line and ReferenceLine, and ErrorBor
   */
  line: 400,
  /**
   * XAxis and YAxis and PolarAngleAxis and PolarRadiusAxis ticks and lines and children
   */
  axis: 500,
  /**
   * Scatter and ReferenceDot,
   * and Dots of Line and Area and Radar if they have dot=true
   */
  scatter: 600,
  /**
   * Hovering over a Bar or RadialBar renders a highlight rectangle
   */
  activeBar: 1e3,
  /**
   * Cursor is embedded inside Tooltip and controlled by it.
   * The Tooltip itself has a separate portal and is not included in the zIndex system;
   * Cursor is the decoration inside the chart area, usually a cross or a box.
   * CursorLine is a line cursor rendered in Line, Area, Scatter, Radar charts.
   * It renders above the Line and Scatter so that it is always visible.
   * It renders below active dot so that the dot is always visible and shows the current point.
   * We're also assuming that the active dot is small enough that it does not fully cover the cursor line.
   *
   * This also applies to the radial cursor in RadialBarChart.
   */
  cursorLine: 1100,
  /**
   * Hovering over a Point in Line, Area, Scatter, Radar renders a highlight dot
   */
  activeDot: 1200,
  /**
   * LabelList and Label, including Axis labels
   */
  label: 2e3
}, Je = {
  allowDecimals: !1,
  allowDuplicatedCategory: !0,
  // if I set this to false then Tooltip synchronisation stops working in Radar, wtf
  angleAxisId: 0,
  axisLine: !0,
  axisLineType: "polygon",
  cx: 0,
  cy: 0,
  orientation: "outer",
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickLine: !0,
  tickSize: 8,
  type: "category",
  zIndex: Y.axis
}, $e = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: !0,
  angle: 0,
  axisLine: !0,
  includeHidden: !1,
  hide: !1,
  label: !1,
  orientation: "right",
  radiusAxisId: 0,
  reversed: !1,
  scale: "auto",
  stroke: "#ccc",
  tick: !0,
  tickCount: 5,
  type: "number",
  zIndex: Y.axis
}, jn = (e, r) => {
  if (!(!e || !r))
    return e != null && e.reversed ? [r[1], r[0]] : r;
}, mg = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: !1,
  // defaultPolarAngleAxisProps.allowDuplicatedCategory has it set to true but the actual axis rendering ignores the prop because reasons,
  dataKey: void 0,
  domain: void 0,
  id: Je.angleAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: Je.reversed,
  scale: Je.scale,
  tick: Je.tick,
  tickCount: void 0,
  ticks: void 0,
  type: Je.type,
  unit: void 0
}, hg = {
  allowDataOverflow: $e.allowDataOverflow,
  allowDecimals: !1,
  allowDuplicatedCategory: $e.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: $e.radiusAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: $e.scale,
  tick: $e.tick,
  tickCount: $e.tickCount,
  ticks: void 0,
  type: $e.type,
  unit: void 0
}, yg = {
  allowDataOverflow: !1,
  allowDecimals: !1,
  allowDuplicatedCategory: Je.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: Je.angleAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: Je.scale,
  tick: Je.tick,
  tickCount: void 0,
  ticks: void 0,
  type: "number",
  unit: void 0
}, gg = {
  allowDataOverflow: $e.allowDataOverflow,
  allowDecimals: !1,
  allowDuplicatedCategory: $e.allowDuplicatedCategory,
  dataKey: void 0,
  domain: void 0,
  id: $e.radiusAxisId,
  includeHidden: !1,
  name: void 0,
  reversed: !1,
  scale: $e.scale,
  tick: $e.tick,
  tickCount: $e.tickCount,
  ticks: void 0,
  type: "category",
  unit: void 0
}, Yr = (e, r) => e.polarAxis.angleAxis[r] != null ? e.polarAxis.angleAxis[r] : e.layout.layoutType === "radial" ? yg : mg, yt = (e, r) => e.polarAxis.radiusAxis[r] != null ? e.polarAxis.radiusAxis[r] : e.layout.layoutType === "radial" ? gg : hg, Sn = (e) => e.polarOptions, lo = A([wr, Ar, he], nd), Od = A([Sn, lo], (e, r) => {
  if (e != null)
    return Ee(e.innerRadius, r, 0);
}), wd = A([Sn, lo], (e, r) => {
  if (e != null)
    return Ee(e.outerRadius, r, r * 0.8);
}), bg = (e) => {
  if (e == null)
    return [0, 0];
  var {
    startAngle: r,
    endAngle: t
  } = e;
  return [r, t];
}, Ad = A([Sn], bg), xg = A([Yr, Ad], jn), Ed = A([lo, Od, wd], (e, r, t) => {
  if (!(e == null || r == null || t == null))
    return [r, t];
}), Pg = A([yt, Ed], jn), Ur = A([K, Sn, Od, wd, wr, Ar], (e, r, t, a, n, i) => {
  if (!(e !== "centric" && e !== "radial" || r == null || t == null || a == null)) {
    var {
      cx: o,
      cy: u,
      startAngle: s,
      endAngle: c
    } = r;
    return {
      cx: Ee(o, n, n / 2),
      cy: Ee(u, i, i / 2),
      innerRadius: t,
      outerRadius: a,
      startAngle: s,
      endAngle: c,
      clockWise: !1
      // this property look useful, why not use it?
    };
  }
}), ae = (e, r) => r, la = (e, r, t) => t;
function In(e) {
  return e == null ? void 0 : e.id;
}
function uo(e, r, t) {
  var {
    chartData: a = []
  } = r, {
    allowDuplicatedCategory: n,
    dataKey: i
  } = t, o = /* @__PURE__ */ new Map();
  return e.forEach((u) => {
    var s, c = (s = u.data) !== null && s !== void 0 ? s : a;
    if (!(c == null || c.length === 0)) {
      var d = In(u);
      c.forEach((v, f) => {
        var p = i == null || n ? f : String(B(v, i, null)), m = B(v, u.dataKey, 0), h;
        o.has(p) ? h = o.get(p) : h = {}, Object.assign(h, {
          [d]: m
        }), o.set(p, h);
      });
    }
  }), Array.from(o.values());
}
function ua(e) {
  return "stackId" in e && e.stackId != null && e.dataKey != null;
}
var kn = (e, r) => e === r ? !0 : e == null || r == null ? !1 : e[0] === r[0] && e[1] === r[1];
function Cn(e, r) {
  return Array.isArray(e) && Array.isArray(r) && e.length === 0 && r.length === 0 ? !0 : e === r;
}
function Og(e, r) {
  if (e.length === r.length) {
    for (var t = 0; t < e.length; t++)
      if (e[t] !== r[t])
        return !1;
    return !0;
  }
  return !1;
}
var xe = (e) => {
  var r = K(e);
  return r === "horizontal" ? "xAxis" : r === "vertical" ? "yAxis" : r === "centric" ? "angleAxis" : "radiusAxis";
}, gt = (e) => e.tooltip.settings.axisId;
function fu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ga(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? fu(Object(t), !0).forEach(function(a) {
      wg(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : fu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function wg(e, r, t) {
  return (r = Ag(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ag(e) {
  var r = Eg(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Eg(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Oi = [0, "auto"], Pe = {
  allowDataOverflow: !1,
  allowDecimals: !0,
  allowDuplicatedCategory: !0,
  angle: 0,
  dataKey: void 0,
  domain: void 0,
  height: 30,
  hide: !0,
  id: 0,
  includeHidden: !1,
  interval: "preserveEnd",
  minTickGap: 5,
  mirror: !1,
  name: void 0,
  orientation: "bottom",
  padding: {
    left: 0,
    right: 0
  },
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickCount: 5,
  tickFormatter: void 0,
  ticks: void 0,
  type: "category",
  unit: void 0
}, jd = (e, r) => e.cartesianAxis.xAxis[r], ur = (e, r) => {
  var t = jd(e, r);
  return t ?? Pe;
}, Oe = {
  allowDataOverflow: !1,
  allowDecimals: !0,
  allowDuplicatedCategory: !0,
  angle: 0,
  dataKey: void 0,
  domain: Oi,
  hide: !0,
  id: 0,
  includeHidden: !1,
  interval: "preserveEnd",
  minTickGap: 5,
  mirror: !1,
  name: void 0,
  orientation: "left",
  padding: {
    top: 0,
    bottom: 0
  },
  reversed: !1,
  scale: "auto",
  tick: !0,
  tickCount: 5,
  tickFormatter: void 0,
  ticks: void 0,
  type: "number",
  unit: void 0,
  width: ra
}, Sd = (e, r) => e.cartesianAxis.yAxis[r], sr = (e, r) => {
  var t = Sd(e, r);
  return t ?? Oe;
}, yr = {
  domain: [0, "auto"],
  includeHidden: !1,
  reversed: !1,
  allowDataOverflow: !1,
  allowDuplicatedCategory: !1,
  dataKey: void 0,
  id: 0,
  name: "",
  range: [64, 64],
  scale: "auto",
  type: "number",
  unit: ""
}, so = (e, r) => {
  var t = e.cartesianAxis.zAxis[r];
  return t ?? yr;
}, se = (e, r, t) => {
  switch (r) {
    case "xAxis":
      return ur(e, t);
    case "yAxis":
      return sr(e, t);
    case "zAxis":
      return so(e, t);
    case "angleAxis":
      return Yr(e, t);
    case "radiusAxis":
      return yt(e, t);
    default:
      throw new Error("Unexpected axis type: ".concat(r));
  }
}, jg = (e, r, t) => {
  switch (r) {
    case "xAxis":
      return ur(e, t);
    case "yAxis":
      return sr(e, t);
    default:
      throw new Error("Unexpected axis type: ".concat(r));
  }
}, bt = (e, r, t) => {
  switch (r) {
    case "xAxis":
      return ur(e, t);
    case "yAxis":
      return sr(e, t);
    case "angleAxis":
      return Yr(e, t);
    case "radiusAxis":
      return yt(e, t);
    default:
      throw new Error("Unexpected axis type: ".concat(r));
  }
}, Id = (e) => e.graphicalItems.cartesianItems.some((r) => r.type === "bar") || e.graphicalItems.polarItems.some((r) => r.type === "radialBar");
function co(e, r) {
  return (t) => {
    switch (e) {
      case "xAxis":
        return "xAxisId" in t && t.xAxisId === r;
      case "yAxis":
        return "yAxisId" in t && t.yAxisId === r;
      case "zAxis":
        return "zAxisId" in t && t.zAxisId === r;
      case "angleAxis":
        return "angleAxisId" in t && t.angleAxisId === r;
      case "radiusAxis":
        return "radiusAxisId" in t && t.radiusAxisId === r;
      default:
        return !1;
    }
  };
}
var xt = (e) => e.graphicalItems.cartesianItems, Sg = A([ae, la], co), vo = (e, r, t) => e.filter(t).filter((a) => (r == null ? void 0 : r.includeHidden) === !0 ? !0 : !a.hide), sa = A([xt, se, Sg], vo, {
  memoizeOptions: {
    resultEqualityCheck: Cn
  }
}), kd = A([sa], (e) => e.filter((r) => r.type === "area" || r.type === "bar").filter(ua)), Cd = (e) => e.filter((r) => !("stackId" in r) || r.stackId === void 0), Ig = A([sa], Cd), fo = (e) => e.map((r) => r.data).filter(Boolean).flat(1), kg = A([sa], fo, {
  memoizeOptions: {
    resultEqualityCheck: Cn
  }
}), po = (e, r) => {
  var {
    chartData: t = [],
    dataStartIndex: a,
    dataEndIndex: n
  } = r;
  return e.length > 0 ? e : t.slice(a, n + 1);
}, mo = A([kg, On], po), ho = (e, r, t) => (r == null ? void 0 : r.dataKey) != null ? e.map((a) => ({
  value: B(a, r.dataKey)
})) : t.length > 0 ? t.map((a) => a.dataKey).flatMap((a) => e.map((n) => ({
  value: B(n, a)
}))) : e.map((a) => ({
  value: a
})), Dn = A([mo, se, sa], ho);
function Dd(e, r) {
  switch (e) {
    case "xAxis":
      return r.direction === "x";
    case "yAxis":
      return r.direction === "y";
    default:
      return !1;
  }
}
function $a(e) {
  if (we(e) || e instanceof Date) {
    var r = Number(e);
    if (q(r))
      return r;
  }
}
function pu(e) {
  if (Array.isArray(e)) {
    var r = [$a(e[0]), $a(e[1])];
    return Dr(r) ? r : void 0;
  }
  var t = $a(e);
  if (t != null)
    return [t, t];
}
function Pr(e) {
  return e.map($a).filter(Zi);
}
function Cg(e, r, t) {
  return !t || typeof r != "number" || De(r) ? [] : t.length ? Pr(t.flatMap((a) => {
    var n = B(e, a.dataKey), i, o;
    if (Array.isArray(n) ? [i, o] = n : i = o = n, !(!q(i) || !q(o)))
      return [r - i, r + o];
  })) : [];
}
var ye = (e) => {
  var r = xe(e), t = gt(e);
  return bt(e, r, t);
}, ca = A([ye], (e) => e == null ? void 0 : e.dataKey), Dg = A([kd, On, ye], uo), yo = (e, r, t, a) => {
  var n = {}, i = r.reduce((o, u) => {
    if (u.stackId == null)
      return o;
    var s = o[u.stackId];
    return s == null && (s = []), s.push(u), o[u.stackId] = s, o;
  }, n);
  return Object.fromEntries(Object.entries(i).map((o) => {
    var [u, s] = o, c = a ? [...s].reverse() : s, d = c.map(In);
    return [u, {
      // @ts-expect-error getStackedData requires that the input is array of objects, Recharts does not test for that
      stackedData: Um(e, d, t),
      graphicalItems: c
    }];
  }));
}, Ha = A([Dg, kd, ht, io], yo), Td = (e, r, t, a) => {
  var {
    dataStartIndex: n,
    dataEndIndex: i
  } = r;
  if (a == null && t !== "zAxis") {
    var o = Jm(e, n, i);
    if (!(o != null && o[0] === 0 && o[1] === 0))
      return o;
  }
}, Tg = A([se], (e) => e.allowDataOverflow), go = (e) => {
  var r;
  if (e == null || !("domain" in e))
    return Oi;
  if (e.domain != null)
    return e.domain;
  if ("ticks" in e && e.ticks != null) {
    if (e.type === "number") {
      var t = Pr(e.ticks);
      return [Math.min(...t), Math.max(...t)];
    }
    if (e.type === "category")
      return e.ticks.map(String);
  }
  return (r = e == null ? void 0 : e.domain) !== null && r !== void 0 ? r : Oi;
}, bo = A([se], go), xo = A([bo, Tg], cd), $g = A([Ha, lr, ae, xo], Td, {
  memoizeOptions: {
    resultEqualityCheck: kn
  }
}), Tn = (e) => e.errorBars, Lg = (e, r, t) => e.flatMap((a) => r[a.id]).filter(Boolean).filter((a) => Dd(t, a)), Ya = function() {
  for (var r = arguments.length, t = new Array(r), a = 0; a < r; a++)
    t[a] = arguments[a];
  var n = t.filter(Boolean);
  if (n.length !== 0) {
    var i = n.flat(), o = Math.min(...i), u = Math.max(...i);
    return [o, u];
  }
}, Po = (e, r, t, a, n) => {
  var i, o;
  if (t.length > 0 && e.forEach((u) => {
    t.forEach((s) => {
      var c, d, v = (c = a[s.id]) === null || c === void 0 ? void 0 : c.filter((y) => Dd(n, y)), f = B(u, (d = r.dataKey) !== null && d !== void 0 ? d : s.dataKey), p = Cg(u, f, v);
      if (p.length >= 2) {
        var m = Math.min(...p), h = Math.max(...p);
        (i == null || m < i) && (i = m), (o == null || h > o) && (o = h);
      }
      var g = pu(f);
      g != null && (i = i == null ? g[0] : Math.min(i, g[0]), o = o == null ? g[1] : Math.max(o, g[1]));
    });
  }), (r == null ? void 0 : r.dataKey) != null && e.forEach((u) => {
    var s = pu(B(u, r.dataKey));
    s != null && (i = i == null ? s[0] : Math.min(i, s[0]), o = o == null ? s[1] : Math.max(o, s[1]));
  }), q(i) && q(o))
    return [i, o];
}, Mg = A([mo, se, Ig, Tn, ae], Po, {
  memoizeOptions: {
    resultEqualityCheck: kn
  }
});
function _g(e) {
  var {
    value: r
  } = e;
  if (we(r) || r instanceof Date)
    return r;
}
var Ng = (e, r, t) => {
  var a = e.map(_g).filter((n) => n != null);
  return t && (r.dataKey == null || r.allowDuplicatedCategory && Sc(a)) ? Yi(0, e.length) : r.allowDuplicatedCategory ? a : Array.from(new Set(a));
}, $d = (e) => e.referenceElements.dots, Pt = (e, r, t) => e.filter((a) => a.ifOverflow === "extendDomain").filter((a) => r === "xAxis" ? a.xAxisId === t : a.yAxisId === t), Rg = A([$d, ae, la], Pt), Ld = (e) => e.referenceElements.areas, Bg = A([Ld, ae, la], Pt), Md = (e) => e.referenceElements.lines, Kg = A([Md, ae, la], Pt), _d = (e, r) => {
  if (e != null) {
    var t = Pr(e.map((a) => r === "xAxis" ? a.x : a.y));
    if (t.length !== 0)
      return [Math.min(...t), Math.max(...t)];
  }
}, zg = A(Rg, ae, _d), Nd = (e, r) => {
  if (e != null) {
    var t = Pr(e.flatMap((a) => [r === "xAxis" ? a.x1 : a.y1, r === "xAxis" ? a.x2 : a.y2]));
    if (t.length !== 0)
      return [Math.min(...t), Math.max(...t)];
  }
}, Wg = A([Bg, ae], Nd);
function Fg(e) {
  var r;
  if (e.x != null)
    return Pr([e.x]);
  var t = (r = e.segment) === null || r === void 0 ? void 0 : r.map((a) => a.x);
  return t == null || t.length === 0 ? [] : Pr(t);
}
function Xg(e) {
  var r;
  if (e.y != null)
    return Pr([e.y]);
  var t = (r = e.segment) === null || r === void 0 ? void 0 : r.map((a) => a.y);
  return t == null || t.length === 0 ? [] : Pr(t);
}
var Rd = (e, r) => {
  if (e != null) {
    var t = e.flatMap((a) => r === "xAxis" ? Fg(a) : Xg(a));
    if (t.length !== 0)
      return [Math.min(...t), Math.max(...t)];
  }
}, Vg = A([Kg, ae], Rd), Gg = A(zg, Vg, Wg, (e, r, t) => Ya(e, t, r)), Oo = (e, r, t, a, n, i, o, u) => {
  if (t != null)
    return t;
  var s = o === "vertical" && u === "xAxis" || o === "horizontal" && u === "yAxis", c = s ? Ya(a, i, n) : Ya(i, n);
  return og(r, c, e.allowDataOverflow);
}, Hg = A([se, bo, xo, $g, Mg, Gg, K, ae], Oo, {
  memoizeOptions: {
    resultEqualityCheck: kn
  }
}), Yg = [0, 1], wo = (e, r, t, a, n, i, o) => {
  if (!((e == null || t == null || t.length === 0) && o === void 0)) {
    var {
      dataKey: u,
      type: s
    } = e, c = He(r, i);
    if (c && u == null) {
      var d;
      return Yi(0, (d = t == null ? void 0 : t.length) !== null && d !== void 0 ? d : 0);
    }
    return s === "category" ? Ng(a, e, c) : n === "expand" ? Yg : o;
  }
}, Ao = A([se, K, mo, Dn, ht, ae, Hg], wo), Bd = (e, r, t, a, n) => {
  if (e != null) {
    var {
      scale: i,
      type: o
    } = e;
    if (i === "auto")
      return r === "radial" && n === "radiusAxis" ? "band" : r === "radial" && n === "angleAxis" ? "linear" : o === "category" && a && (a.indexOf("LineChart") >= 0 || a.indexOf("AreaChart") >= 0 || a.indexOf("ComposedChart") >= 0 && !t) ? "point" : o === "category" ? "band" : "linear";
    if (typeof i == "string") {
      var u = "scale".concat(ea(i));
      return u in Rt ? u : "point";
    }
  }
}, Mr = A([se, K, Id, oo, ae], Bd);
function Ug(e) {
  if (e != null) {
    if (e in Rt)
      return Rt[e]();
    var r = "scale".concat(ea(e));
    if (r in Rt)
      return Rt[r]();
  }
}
function $n(e, r, t, a) {
  if (!(t == null || a == null)) {
    if (typeof e.scale == "function")
      return e.scale.copy().domain(t).range(a);
    var n = Ug(r);
    if (n != null) {
      var i = n.domain(t).range(a);
      return Vm(i), i;
    }
  }
}
var Eo = (e, r, t) => {
  var a = go(r);
  if (!(t !== "auto" && t !== "linear")) {
    if (r != null && r.tickCount && Array.isArray(a) && (a[0] === "auto" || a[1] === "auto") && Dr(e))
      return vg(e, r.tickCount, r.allowDecimals);
    if (r != null && r.tickCount && r.type === "number" && Dr(e))
      return fg(e, r.tickCount, r.allowDecimals);
  }
}, jo = A([Ao, bt, Mr], Eo), So = (e, r, t, a) => {
  if (
    /*
     * Angle axis for some reason uses nice ticks when rendering axis tick labels,
     * but doesn't use nice ticks for extending domain like all the other axes do.
     * Not really sure why? Is there a good reason,
     * or is it just because someone added support for nice ticks to the other axes and forgot this one?
     */
    a !== "angleAxis" && (e == null ? void 0 : e.type) === "number" && Dr(r) && Array.isArray(t) && t.length > 0
  ) {
    var n = r[0], i = t[0], o = r[1], u = t[t.length - 1];
    return [Math.min(n, i), Math.max(o, u)];
  }
  return r;
}, Zg = A([se, Ao, jo, ae], So), qg = A(Dn, se, (e, r) => {
  if (!(!r || r.type !== "number")) {
    var t = 1 / 0, a = Array.from(Pr(e.map((v) => v.value))).sort((v, f) => v - f), n = a[0], i = a[a.length - 1];
    if (n == null || i == null)
      return 1 / 0;
    var o = i - n;
    if (o === 0)
      return 1 / 0;
    for (var u = 0; u < a.length - 1; u++) {
      var s = a[u], c = a[u + 1];
      if (!(s == null || c == null)) {
        var d = c - s;
        t = Math.min(t, d);
      }
    }
    return t / o;
  }
}), Kd = A(qg, K, no, he, (e, r, t, a, n) => n, (e, r, t, a, n) => {
  if (!q(e))
    return 0;
  var i = r === "vertical" ? a.height : a.width;
  if (n === "gap")
    return e * i / 2;
  if (n === "no-gap") {
    var o = Ee(t, e * i), u = e * i / 2;
    return u - o - (u - o) / i * o;
  }
  return 0;
}), Jg = (e, r, t) => {
  var a = ur(e, r);
  return a == null || typeof a.padding != "string" ? 0 : Kd(e, "xAxis", r, t, a.padding);
}, Qg = (e, r, t) => {
  var a = sr(e, r);
  return a == null || typeof a.padding != "string" ? 0 : Kd(e, "yAxis", r, t, a.padding);
}, eb = A(ur, Jg, (e, r) => {
  var t, a;
  if (e == null)
    return {
      left: 0,
      right: 0
    };
  var {
    padding: n
  } = e;
  return typeof n == "string" ? {
    left: r,
    right: r
  } : {
    left: ((t = n.left) !== null && t !== void 0 ? t : 0) + r,
    right: ((a = n.right) !== null && a !== void 0 ? a : 0) + r
  };
}), rb = A(sr, Qg, (e, r) => {
  var t, a;
  if (e == null)
    return {
      top: 0,
      bottom: 0
    };
  var {
    padding: n
  } = e;
  return typeof n == "string" ? {
    top: r,
    bottom: r
  } : {
    top: ((t = n.top) !== null && t !== void 0 ? t : 0) + r,
    bottom: ((a = n.bottom) !== null && a !== void 0 ? a : 0) + r
  };
}), tb = A([he, eb, ta, Pn, (e, r, t) => t], (e, r, t, a, n) => {
  var {
    padding: i
  } = a;
  return n ? [i.left, t.width - i.right] : [e.left + r.left, e.left + e.width - r.right];
}), ab = A([he, K, rb, ta, Pn, (e, r, t) => t], (e, r, t, a, n, i) => {
  var {
    padding: o
  } = n;
  return i ? [a.height - o.bottom, o.top] : r === "horizontal" ? [e.top + e.height - t.bottom, e.top + t.top] : [e.top + t.top, e.top + e.height - t.bottom];
}), da = (e, r, t, a) => {
  var n;
  switch (r) {
    case "xAxis":
      return tb(e, t, a);
    case "yAxis":
      return ab(e, t, a);
    case "zAxis":
      return (n = so(e, t)) === null || n === void 0 ? void 0 : n.range;
    case "angleAxis":
      return Ad(e);
    case "radiusAxis":
      return Ed(e, t);
    default:
      return;
  }
}, zd = A([se, da], jn), ar = A([se, Mr, Zg, zd], $n);
A([sa, Tn, ae], Lg);
function Wd(e, r) {
  return e.id < r.id ? -1 : e.id > r.id ? 1 : 0;
}
var Ln = (e, r) => r, Mn = (e, r, t) => t, nb = A(bn, Ln, Mn, (e, r, t) => e.filter((a) => a.orientation === r).filter((a) => a.mirror === t).sort(Wd)), ib = A(xn, Ln, Mn, (e, r, t) => e.filter((a) => a.orientation === r).filter((a) => a.mirror === t).sort(Wd)), Fd = (e, r) => ({
  width: e.width,
  height: r.height
}), ob = (e, r) => {
  var t = typeof r.width == "number" ? r.width : ra;
  return {
    width: t,
    height: e.height
  };
}, Xd = A(he, ur, Fd), lb = (e, r, t) => {
  switch (r) {
    case "top":
      return e.top;
    case "bottom":
      return t - e.bottom;
    default:
      return 0;
  }
}, ub = (e, r, t) => {
  switch (r) {
    case "left":
      return e.left;
    case "right":
      return t - e.right;
    default:
      return 0;
  }
}, sb = A(Ar, he, nb, Ln, Mn, (e, r, t, a, n) => {
  var i = {}, o;
  return t.forEach((u) => {
    var s = Fd(r, u);
    o == null && (o = lb(r, a, e));
    var c = a === "top" && !n || a === "bottom" && n;
    i[u.id] = o - Number(c) * s.height, o += (c ? -1 : 1) * s.height;
  }), i;
}), cb = A(wr, he, ib, Ln, Mn, (e, r, t, a, n) => {
  var i = {}, o;
  return t.forEach((u) => {
    var s = ob(r, u);
    o == null && (o = ub(r, a, e));
    var c = a === "left" && !n || a === "right" && n;
    i[u.id] = o - Number(c) * s.width, o += (c ? -1 : 1) * s.width;
  }), i;
}), db = (e, r) => {
  var t = ur(e, r);
  if (t != null)
    return sb(e, t.orientation, t.mirror);
}, vb = A([he, ur, db, (e, r) => r], (e, r, t, a) => {
  if (r != null) {
    var n = t == null ? void 0 : t[a];
    return n == null ? {
      x: e.left,
      y: 0
    } : {
      x: e.left,
      y: n
    };
  }
}), fb = (e, r) => {
  var t = sr(e, r);
  if (t != null)
    return cb(e, t.orientation, t.mirror);
}, pb = A([he, sr, fb, (e, r) => r], (e, r, t, a) => {
  if (r != null) {
    var n = t == null ? void 0 : t[a];
    return n == null ? {
      x: 0,
      y: e.top
    } : {
      x: n,
      y: e.top
    };
  }
}), Vd = A(he, sr, (e, r) => {
  var t = typeof r.width == "number" ? r.width : ra;
  return {
    width: t,
    height: e.height
  };
}), mu = (e, r, t) => {
  switch (r) {
    case "xAxis":
      return Xd(e, t).width;
    case "yAxis":
      return Vd(e, t).height;
    default:
      return;
  }
}, Gd = (e, r, t, a) => {
  if (t != null) {
    var {
      allowDuplicatedCategory: n,
      type: i,
      dataKey: o
    } = t, u = He(e, a), s = r.map((c) => c.value);
    if (o && u && i === "category" && n && Sc(s))
      return s;
  }
}, va = A([K, Dn, se, ae], Gd), Io = (e, r, t, a) => {
  if (!(t == null || t.dataKey == null)) {
    var {
      type: n,
      scale: i
    } = t, o = He(e, a);
    if (o && (n === "number" || i !== "auto"))
      return r.map((u) => u.value);
  }
}, ko = A([K, Dn, bt, ae], Io), hu = A([K, jg, Mr, ar, va, ko, da, jo, ae], (e, r, t, a, n, i, o, u, s) => {
  if (r != null) {
    var c = He(e, s);
    return {
      angle: r.angle,
      interval: r.interval,
      minTickGap: r.minTickGap,
      orientation: r.orientation,
      tick: r.tick,
      tickCount: r.tickCount,
      tickFormatter: r.tickFormatter,
      ticks: r.ticks,
      type: r.type,
      unit: r.unit,
      axisType: s,
      categoricalDomain: i,
      duplicateDomain: n,
      isCategorical: c,
      niceTicks: u,
      range: o,
      realScaleType: t,
      scale: a
    };
  }
}), Hd = (e, r, t, a, n, i, o, u, s) => {
  if (!(r == null || a == null)) {
    var c = He(e, s), {
      type: d,
      ticks: v,
      tickCount: f
    } = r, p = t === "scaleBand" && typeof a.bandwidth == "function" ? a.bandwidth() / 2 : 2, m = d === "category" && a.bandwidth ? a.bandwidth() / p : 0;
    m = s === "angleAxis" && i != null && i.length >= 2 ? me(i[0] - i[1]) * 2 * m : m;
    var h = v || n;
    if (h) {
      var g = h.map((y, b) => {
        var x = o ? o.indexOf(y) : y;
        return {
          index: b,
          // If the scaleContent is not a number, the coordinate will be NaN.
          // That could be the case for example with a PointScale and a string as domain.
          coordinate: a(x) + m,
          value: y,
          offset: m
        };
      });
      return g.filter((y) => q(y.coordinate));
    }
    return c && u ? u.map((y, b) => ({
      coordinate: a(y) + m,
      value: y,
      index: b,
      offset: m
    })).filter((y) => q(y.coordinate)) : a.ticks ? a.ticks(f).map((y) => ({
      coordinate: a(y) + m,
      value: y,
      offset: m
    })) : a.domain().map((y, b) => ({
      coordinate: a(y) + m,
      value: o ? o[y] : y,
      index: b,
      offset: m
    }));
  }
}, Yd = A([K, bt, Mr, ar, jo, da, va, ko, ae], Hd), Ud = (e, r, t, a, n, i, o) => {
  if (!(r == null || t == null || a == null || a[0] === a[1])) {
    var u = He(e, o), {
      tickCount: s
    } = r, c = 0;
    return c = o === "angleAxis" && (a == null ? void 0 : a.length) >= 2 ? me(a[0] - a[1]) * 2 * c : c, u && i ? i.map((d, v) => ({
      coordinate: t(d) + c,
      value: d,
      index: v,
      offset: c
    })) : t.ticks ? t.ticks(s).map((d) => ({
      coordinate: t(d) + c,
      value: d,
      offset: c
    })) : t.domain().map((d, v) => ({
      coordinate: t(d) + c,
      value: n ? n[d] : d,
      index: v,
      offset: c
    }));
  }
}, Ge = A([K, bt, ar, da, va, ko, ae], Ud), Re = A(se, ar, (e, r) => {
  if (!(e == null || r == null))
    return Ga(Ga({}, e), {}, {
      scale: r
    });
}), mb = A([se, Mr, Ao, zd], $n), hb = A((e, r, t) => so(e, t), mb, (e, r) => {
  if (!(e == null || r == null))
    return Ga(Ga({}, e), {}, {
      scale: r
    });
}), yb = A([K, bn, xn], (e, r, t) => {
  switch (e) {
    case "horizontal":
      return r.some((a) => a.reversed) ? "right-to-left" : "left-to-right";
    case "vertical":
      return t.some((a) => a.reversed) ? "bottom-to-top" : "top-to-bottom";
    case "centric":
    case "radial":
      return "left-to-right";
    default:
      return;
  }
}), Zd = (e) => e.options.defaultTooltipEventType, qd = (e) => e.options.validateTooltipEventTypes;
function Jd(e, r, t) {
  if (e == null)
    return r;
  var a = e ? "axis" : "item";
  return t == null ? r : t.includes(a) ? a : r;
}
function Co(e, r) {
  var t = Zd(e), a = qd(e);
  return Jd(r, t, a);
}
function gb(e) {
  return k((r) => Co(r, e));
}
var Qd = (e, r) => {
  var t, a = Number(r);
  if (!(De(a) || r == null))
    return a >= 0 ? e == null || (t = e[a]) === null || t === void 0 ? void 0 : t.value : void 0;
}, bb = (e) => e.tooltip.settings, kr = {
  active: !1,
  index: null,
  dataKey: void 0,
  graphicalItemId: void 0,
  coordinate: void 0
}, xb = {
  itemInteraction: {
    click: kr,
    hover: kr
  },
  axisInteraction: {
    click: kr,
    hover: kr
  },
  keyboardInteraction: kr,
  syncInteraction: {
    active: !1,
    index: null,
    dataKey: void 0,
    label: void 0,
    coordinate: void 0,
    sourceViewBox: void 0,
    graphicalItemId: void 0
  },
  tooltipItemPayloads: [],
  settings: {
    shared: void 0,
    trigger: "hover",
    axisId: 0,
    active: !1,
    defaultIndex: void 0
  }
}, ev = Be({
  name: "tooltip",
  initialState: xb,
  reducers: {
    addTooltipEntrySettings: {
      reducer(e, r) {
        e.tooltipItemPayloads.push(re(r.payload));
      },
      prepare: oe()
    },
    replaceTooltipEntrySettings: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload, n = er(e).tooltipItemPayloads.indexOf(re(t));
        n > -1 && (e.tooltipItemPayloads[n] = re(a));
      },
      prepare: oe()
    },
    removeTooltipEntrySettings: {
      reducer(e, r) {
        var t = er(e).tooltipItemPayloads.indexOf(re(r.payload));
        t > -1 && e.tooltipItemPayloads.splice(t, 1);
      },
      prepare: oe()
    },
    setTooltipSettingsState(e, r) {
      e.settings = r.payload;
    },
    setActiveMouseOverItemIndex(e, r) {
      e.syncInteraction.active = !1, e.keyboardInteraction.active = !1, e.itemInteraction.hover.active = !0, e.itemInteraction.hover.index = r.payload.activeIndex, e.itemInteraction.hover.dataKey = r.payload.activeDataKey, e.itemInteraction.hover.graphicalItemId = r.payload.activeGraphicalItemId, e.itemInteraction.hover.coordinate = r.payload.activeCoordinate;
    },
    mouseLeaveChart(e) {
      e.itemInteraction.hover.active = !1, e.axisInteraction.hover.active = !1;
    },
    mouseLeaveItem(e) {
      e.itemInteraction.hover.active = !1;
    },
    setActiveClickItemIndex(e, r) {
      e.syncInteraction.active = !1, e.itemInteraction.click.active = !0, e.keyboardInteraction.active = !1, e.itemInteraction.click.index = r.payload.activeIndex, e.itemInteraction.click.dataKey = r.payload.activeDataKey, e.itemInteraction.click.graphicalItemId = r.payload.activeGraphicalItemId, e.itemInteraction.click.coordinate = r.payload.activeCoordinate;
    },
    setMouseOverAxisIndex(e, r) {
      e.syncInteraction.active = !1, e.axisInteraction.hover.active = !0, e.keyboardInteraction.active = !1, e.axisInteraction.hover.index = r.payload.activeIndex, e.axisInteraction.hover.dataKey = r.payload.activeDataKey, e.axisInteraction.hover.coordinate = r.payload.activeCoordinate;
    },
    setMouseClickAxisIndex(e, r) {
      e.syncInteraction.active = !1, e.keyboardInteraction.active = !1, e.axisInteraction.click.active = !0, e.axisInteraction.click.index = r.payload.activeIndex, e.axisInteraction.click.dataKey = r.payload.activeDataKey, e.axisInteraction.click.coordinate = r.payload.activeCoordinate;
    },
    setSyncInteraction(e, r) {
      e.syncInteraction = r.payload;
    },
    setKeyboardInteraction(e, r) {
      e.keyboardInteraction.active = r.payload.active, e.keyboardInteraction.index = r.payload.activeIndex, e.keyboardInteraction.coordinate = r.payload.activeCoordinate;
    }
  }
}), {
  addTooltipEntrySettings: Pb,
  replaceTooltipEntrySettings: Ob,
  removeTooltipEntrySettings: wb,
  setTooltipSettingsState: Ab,
  setActiveMouseOverItemIndex: Ot,
  mouseLeaveItem: Do,
  mouseLeaveChart: rv,
  setActiveClickItemIndex: _n,
  setMouseOverAxisIndex: tv,
  setMouseClickAxisIndex: Eb,
  setSyncInteraction: wi,
  setKeyboardInteraction: Ai
} = ev.actions, jb = ev.reducer;
function yu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ja(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? yu(Object(t), !0).forEach(function(a) {
      Sb(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : yu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Sb(e, r, t) {
  return (r = Ib(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ib(e) {
  var r = kb(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function kb(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Cb(e, r, t) {
  return r === "axis" ? t === "click" ? e.axisInteraction.click : e.axisInteraction.hover : t === "click" ? e.itemInteraction.click : e.itemInteraction.hover;
}
function Db(e) {
  return e.index != null;
}
var av = (e, r, t, a) => {
  if (r == null)
    return kr;
  var n = Cb(e, r, t);
  if (n == null)
    return kr;
  if (n.active)
    return n;
  if (e.keyboardInteraction.active)
    return e.keyboardInteraction;
  if (e.syncInteraction.active && e.syncInteraction.index != null)
    return e.syncInteraction;
  var i = e.settings.active === !0;
  if (Db(n)) {
    if (i)
      return ja(ja({}, n), {}, {
        active: !0
      });
  } else if (a != null)
    return {
      active: !0,
      coordinate: void 0,
      dataKey: void 0,
      index: a,
      graphicalItemId: void 0
    };
  return ja(ja({}, kr), {}, {
    coordinate: n.coordinate
  });
};
function Tb(e) {
  if (typeof e == "number")
    return Number.isFinite(e) ? e : void 0;
  if (e instanceof Date) {
    var r = e.valueOf();
    return Number.isFinite(r) ? r : void 0;
  }
  var t = Number(e);
  return Number.isFinite(t) ? t : void 0;
}
function $b(e, r) {
  var t = Tb(e), a = r[0], n = r[1];
  if (t === void 0)
    return !1;
  var i = Math.min(a, n), o = Math.max(a, n);
  return t >= i && t <= o;
}
function Lb(e, r, t) {
  if (t == null || r == null)
    return !0;
  var a = B(e, r);
  return a == null || !Dr(t) ? !0 : $b(a, t);
}
var To = (e, r, t, a) => {
  var n = e == null ? void 0 : e.index;
  if (n == null)
    return null;
  var i = Number(n);
  if (!q(i))
    return n;
  var o = 0, u = 1 / 0;
  r.length > 0 && (u = r.length - 1);
  var s = Math.max(o, Math.min(i, u)), c = r[s];
  return c == null || Lb(c, t, a) ? String(s) : null;
}, nv = (e, r, t, a, n, i, o, u) => {
  if (!(i == null || u == null)) {
    var s = o[0], c = s == null ? void 0 : u(s.positions, i);
    if (c != null)
      return c;
    var d = n == null ? void 0 : n[Number(i)];
    if (d)
      switch (t) {
        case "horizontal":
          return {
            x: d.coordinate,
            y: (a.top + r) / 2
          };
        default:
          return {
            x: (a.left + e) / 2,
            y: d.coordinate
          };
      }
  }
}, iv = (e, r, t, a) => {
  if (r === "axis")
    return e.tooltipItemPayloads;
  if (e.tooltipItemPayloads.length === 0)
    return [];
  var n;
  if (t === "hover" ? n = e.itemInteraction.hover.graphicalItemId : n = e.itemInteraction.click.graphicalItemId, n == null && a != null) {
    var i = e.tooltipItemPayloads[0];
    return i != null ? [i] : [];
  }
  return e.tooltipItemPayloads.filter((o) => {
    var u;
    return ((u = o.settings) === null || u === void 0 ? void 0 : u.graphicalItemId) === n;
  });
}, fa = (e) => e.options.tooltipPayloadSearcher, wt = (e) => e.tooltip;
function gu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function bu(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? gu(Object(t), !0).forEach(function(a) {
      Mb(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : gu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Mb(e, r, t) {
  return (r = _b(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function _b(e) {
  var r = Nb(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Nb(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Rb(e, r) {
  return e ?? r;
}
var ov = (e, r, t, a, n, i, o) => {
  if (!(r == null || i == null)) {
    var {
      chartData: u,
      computedData: s,
      dataStartIndex: c,
      dataEndIndex: d
    } = t, v = [];
    return e.reduce((f, p) => {
      var m, {
        dataDefinedOnItem: h,
        settings: g
      } = p, y = Rb(h, u), b = Array.isArray(y) ? _c(y, c, d) : y, x = (m = g == null ? void 0 : g.dataKey) !== null && m !== void 0 ? m : a, O = g == null ? void 0 : g.nameKey, P;
      if (a && Array.isArray(b) && /*
       * findEntryInArray won't work for Scatter because Scatter provides an array of arrays
       * as tooltip payloads and findEntryInArray is not prepared to handle that.
       * Sad but also ScatterChart only allows 'item' tooltipEventType
       * and also this is only a problem if there are multiple Scatters and each has its own data array
       * so let's fix that some other time.
       */
      !Array.isArray(b[0]) && /*
       * If the tooltipEventType is 'axis', we should search for the dataKey in the sliced data
       * because thanks to allowDuplicatedCategory=false, the order of elements in the array
       * no longer matches the order of elements in the original data
       * and so we need to search by the active dataKey + label rather than by index.
       *
       * The same happens if multiple graphical items are present in the chart
       * and each of them has its own data array. Those arrays get concatenated
       * and again the tooltip index no longer matches the original data.
       *
       * On the other hand the tooltipEventType 'item' should always search by index
       * because we get the index from interacting over the individual elements
       * which is always accurate, irrespective of the allowDuplicatedCategory setting.
       */
      o === "axis" ? P = Ic(b, a, n) : P = i(b, r, s, O), Array.isArray(P))
        P.forEach((E) => {
          var j = bu(bu({}, g), {}, {
            // @ts-expect-error we're assuming that item has name and unit properties
            name: E.name,
            // @ts-expect-error we're assuming that item has name and unit properties
            unit: E.unit,
            // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
            color: void 0,
            // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
            fill: void 0
          });
          f.push(Pl({
            tooltipEntrySettings: j,
            // @ts-expect-error we're assuming that item has name and unit properties
            dataKey: E.dataKey,
            // @ts-expect-error we're assuming that item has name and unit properties
            payload: E.payload,
            // @ts-expect-error getValueByDataKey does not validate the output type
            value: B(E.payload, E.dataKey),
            // @ts-expect-error we're assuming that item has name and unit properties
            name: E.name
          }));
        });
      else {
        var w;
        f.push(Pl({
          tooltipEntrySettings: g,
          dataKey: x,
          payload: P,
          // @ts-expect-error getValueByDataKey does not validate the output type
          value: B(P, x),
          // @ts-expect-error getValueByDataKey does not validate the output type
          name: (w = B(P, O)) !== null && w !== void 0 ? w : g == null ? void 0 : g.name
        }));
      }
      return f;
    }, v);
  }
}, $o = A([ye, K, Id, oo, xe], Bd), Bb = A([(e) => e.graphicalItems.cartesianItems, (e) => e.graphicalItems.polarItems], (e, r) => [...e, ...r]), Kb = A([xe, gt], co), At = A([Bb, ye, Kb], vo, {
  memoizeOptions: {
    resultEqualityCheck: Cn
  }
}), zb = A([At], (e) => e.filter(ua)), Wb = A([At], fo, {
  memoizeOptions: {
    resultEqualityCheck: Cn
  }
}), Et = A([Wb, lr], po), Fb = A([zb, lr, ye], uo), Lo = A([Et, ye, At], ho), lv = A([ye], go), Xb = A([ye], (e) => e.allowDataOverflow), uv = A([lv, Xb], cd), Vb = A([At], (e) => e.filter(ua)), Gb = A([Fb, Vb, ht, io], yo), Hb = A([Gb, lr, xe, uv], Td), Yb = A([At], Cd), Ub = A([Et, ye, Yb, Tn, xe], Po, {
  memoizeOptions: {
    resultEqualityCheck: kn
  }
}), Zb = A([$d, xe, gt], Pt), qb = A([Zb, xe], _d), Jb = A([Ld, xe, gt], Pt), Qb = A([Jb, xe], Nd), ex = A([Md, xe, gt], Pt), rx = A([ex, xe], Rd), tx = A([qb, rx, Qb], Ya), ax = A([ye, lv, uv, Hb, Ub, tx, K, xe], Oo), pa = A([ye, K, Et, Lo, ht, xe, ax], wo), nx = A([pa, ye, $o], Eo), ix = A([ye, pa, nx, xe], So), sv = (e) => {
  var r = xe(e), t = gt(e), a = !1;
  return da(e, r, t, a);
}, cv = A([ye, sv], jn), dv = A([ye, $o, ix, cv], $n), ox = A([K, Lo, ye, xe], Gd), lx = A([K, Lo, ye, xe], Io), ux = (e, r, t, a, n, i, o, u) => {
  if (r) {
    var {
      type: s
    } = r, c = He(e, u);
    if (a) {
      var d = t === "scaleBand" && a.bandwidth ? a.bandwidth() / 2 : 2, v = s === "category" && a.bandwidth ? a.bandwidth() / d : 0;
      return v = u === "angleAxis" && n != null && (n == null ? void 0 : n.length) >= 2 ? me(n[0] - n[1]) * 2 * v : v, c && o ? o.map((f, p) => ({
        coordinate: a(f) + v,
        value: f,
        index: p,
        offset: v
      })) : a.domain().map((f, p) => ({
        coordinate: a(f) + v,
        value: i ? i[f] : f,
        index: p,
        offset: v
      }));
    }
  }
}, jr = A([K, ye, $o, dv, sv, ox, lx, xe], ux), Mo = A([Zd, qd, bb], (e, r, t) => Jd(t.shared, e, r)), vv = (e) => e.tooltip.settings.trigger, _o = (e) => e.tooltip.settings.defaultIndex, ma = A([wt, Mo, vv, _o], av), nr = A([ma, Et, ca, pa], To), fv = A([jr, nr], Qd), No = A([ma], (e) => {
  if (e)
    return e.dataKey;
}), sx = A([ma], (e) => {
  if (e)
    return e.graphicalItemId;
}), pv = A([wt, Mo, vv, _o], iv), cx = A([wr, Ar, K, he, jr, _o, pv, fa], nv), dx = A([ma, cx], (e, r) => e != null && e.coordinate ? e.coordinate : r), vx = A([ma], (e) => {
  var r;
  return (r = e == null ? void 0 : e.active) !== null && r !== void 0 ? r : !1;
}), fx = A([pv, nr, lr, ca, fv, fa, Mo], ov), px = A([fx], (e) => {
  if (e != null) {
    var r = e.map((t) => t.payload).filter((t) => t != null);
    return Array.from(new Set(r));
  }
});
function xu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Pu(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? xu(Object(t), !0).forEach(function(a) {
      mx(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : xu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function mx(e, r, t) {
  return (r = hx(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function hx(e) {
  var r = yx(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function yx(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var gx = () => k(ye), bx = () => {
  var e = gx(), r = k(jr), t = k(dv);
  return Ne(!e || !t ? void 0 : Pu(Pu({}, e), {}, {
    scale: t
  }), r);
};
function Ou(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Jr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ou(Object(t), !0).forEach(function(a) {
      xx(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ou(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function xx(e, r, t) {
  return (r = Px(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Px(e) {
  var r = Ox(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Ox(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var wx = (e, r, t, a) => {
  var n = r.find((i) => i && i.index === t);
  if (n) {
    if (e === "horizontal")
      return {
        x: n.coordinate,
        y: a.chartY
      };
    if (e === "vertical")
      return {
        x: a.chartX,
        y: n.coordinate
      };
  }
  return {
    x: 0,
    y: 0
  };
}, Ax = (e, r, t, a) => {
  var n = r.find((c) => c && c.index === t);
  if (n) {
    if (e === "centric") {
      var i = n.coordinate, {
        radius: o
      } = a;
      return Jr(Jr(Jr({}, a), J(a.cx, a.cy, o, i)), {}, {
        angle: i,
        radius: o
      });
    }
    var u = n.coordinate, {
      angle: s
    } = a;
    return Jr(Jr(Jr({}, a), J(a.cx, a.cy, u, s)), {}, {
      angle: s,
      radius: u
    });
  }
  return {
    angle: 0,
    clockWise: !1,
    cx: 0,
    cy: 0,
    endAngle: 0,
    innerRadius: 0,
    outerRadius: 0,
    radius: 0,
    startAngle: 0,
    x: 0,
    y: 0
  };
};
function Ex(e, r) {
  var {
    chartX: t,
    chartY: a
  } = e;
  return t >= r.left && t <= r.left + r.width && a >= r.top && a <= r.top + r.height;
}
var mv = (e, r, t, a, n) => {
  var i, o = (i = r == null ? void 0 : r.length) !== null && i !== void 0 ? i : 0;
  if (o <= 1 || e == null)
    return 0;
  if (a === "angleAxis" && n != null && Math.abs(Math.abs(n[1] - n[0]) - 360) <= 1e-6)
    for (var u = 0; u < o; u++) {
      var s, c, d, v, f, p = u > 0 ? (s = t[u - 1]) === null || s === void 0 ? void 0 : s.coordinate : (c = t[o - 1]) === null || c === void 0 ? void 0 : c.coordinate, m = (d = t[u]) === null || d === void 0 ? void 0 : d.coordinate, h = u >= o - 1 ? (v = t[0]) === null || v === void 0 ? void 0 : v.coordinate : (f = t[u + 1]) === null || f === void 0 ? void 0 : f.coordinate, g = void 0;
      if (!(p == null || m == null || h == null))
        if (me(m - p) !== me(h - m)) {
          var y = [];
          if (me(h - m) === me(n[1] - n[0])) {
            g = h;
            var b = m + n[1] - n[0];
            y[0] = Math.min(b, (b + p) / 2), y[1] = Math.max(b, (b + p) / 2);
          } else {
            g = p;
            var x = h + n[1] - n[0];
            y[0] = Math.min(m, (x + m) / 2), y[1] = Math.max(m, (x + m) / 2);
          }
          var O = [Math.min(m, (g + m) / 2), Math.max(m, (g + m) / 2)];
          if (e > O[0] && e <= O[1] || e >= y[0] && e <= y[1]) {
            var P;
            return (P = t[u]) === null || P === void 0 ? void 0 : P.index;
          }
        } else {
          var w = Math.min(p, h), E = Math.max(p, h);
          if (e > (w + m) / 2 && e <= (E + m) / 2) {
            var j;
            return (j = t[u]) === null || j === void 0 ? void 0 : j.index;
          }
        }
    }
  else if (r)
    for (var S = 0; S < o; S++) {
      var I = r[S];
      if (I != null) {
        var D = r[S + 1], C = r[S - 1];
        if (S === 0 && D != null && e <= (I.coordinate + D.coordinate) / 2 || S === o - 1 && C != null && e > (I.coordinate + C.coordinate) / 2 || S > 0 && S < o - 1 && C != null && D != null && e > (I.coordinate + C.coordinate) / 2 && e <= (I.coordinate + D.coordinate) / 2)
          return I.index;
      }
    }
  return -1;
}, hv = () => k(oo), Ro = (e, r) => r, yv = (e, r, t) => t, Bo = (e, r, t, a) => a, jx = A(jr, (e) => hn(e, (r) => r.coordinate)), Ko = A([wt, Ro, yv, Bo], av), Nn = A([Ko, Et, ca, pa], To), Sx = (e, r, t) => {
  if (r != null) {
    var a = wt(e);
    return r === "axis" ? t === "hover" ? a.axisInteraction.hover.dataKey : a.axisInteraction.click.dataKey : t === "hover" ? a.itemInteraction.hover.dataKey : a.itemInteraction.click.dataKey;
  }
}, gv = A([wt, Ro, yv, Bo], iv), Ua = A([wr, Ar, K, he, jr, Bo, gv, fa], nv), Ix = A([Ko, Ua], (e, r) => {
  var t;
  return (t = e.coordinate) !== null && t !== void 0 ? t : r;
}), bv = A([jr, Nn], Qd), kx = A([gv, Nn, lr, ca, bv, fa, Ro], ov), Cx = A([Ko, Nn], (e, r) => ({
  isActive: e.active && r != null,
  activeIndex: r
})), Dx = (e, r, t, a, n, i, o) => {
  if (!(!e || !t || !a || !n) && Ex(e, o)) {
    var u = Qm(e, r), s = mv(u, i, n, t, a), c = wx(r, n, s, e);
    return {
      activeIndex: String(s),
      activeCoordinate: c
    };
  }
}, Tx = (e, r, t, a, n, i, o) => {
  if (!(!e || !a || !n || !i || !t)) {
    var u = rg(e, t);
    if (u) {
      var s = eh(u, r), c = mv(s, o, i, a, n), d = Ax(r, i, c, u);
      return {
        activeIndex: String(c),
        activeCoordinate: d
      };
    }
  }
}, $x = (e, r, t, a, n, i, o, u) => {
  if (!(!e || !r || !a || !n || !i))
    return r === "horizontal" || r === "vertical" ? Dx(e, r, a, n, i, o, u) : Tx(e, r, t, a, n, i, o);
}, Lx = A((e) => e.zIndex.zIndexMap, (e, r) => r, (e, r, t) => t, (e, r, t) => {
  if (r != null) {
    var a = e[r];
    if (a != null)
      return t ? a.panoramaElement : a.element;
  }
}), Mx = A((e) => e.zIndex.zIndexMap, (e) => {
  var r = Object.keys(e).map((a) => parseInt(a, 10)).concat(Object.values(Y)), t = Array.from(new Set(r));
  return t.sort((a, n) => a - n);
}, {
  memoizeOptions: {
    resultEqualityCheck: Og
  }
});
function wu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Au(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? wu(Object(t), !0).forEach(function(a) {
      _x(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : wu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function _x(e, r, t) {
  return (r = Nx(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Nx(e) {
  var r = Rx(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Rx(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Bx = {}, Kx = {
  zIndexMap: Object.values(Y).reduce((e, r) => Au(Au({}, e), {}, {
    [r]: {
      element: void 0,
      panoramaElement: void 0,
      consumers: 0
    }
  }), Bx)
}, zx = new Set(Object.values(Y));
function Wx(e) {
  return zx.has(e);
}
var xv = Be({
  name: "zIndex",
  initialState: Kx,
  reducers: {
    registerZIndexPortal: {
      reducer: (e, r) => {
        var {
          zIndex: t
        } = r.payload;
        e.zIndexMap[t] ? e.zIndexMap[t].consumers += 1 : e.zIndexMap[t] = {
          consumers: 1,
          element: void 0,
          panoramaElement: void 0
        };
      },
      prepare: oe()
    },
    unregisterZIndexPortal: {
      reducer: (e, r) => {
        var {
          zIndex: t
        } = r.payload;
        e.zIndexMap[t] && (e.zIndexMap[t].consumers -= 1, e.zIndexMap[t].consumers <= 0 && !Wx(t) && delete e.zIndexMap[t]);
      },
      prepare: oe()
    },
    registerZIndexPortalElement: {
      reducer: (e, r) => {
        var {
          zIndex: t,
          element: a,
          isPanorama: n
        } = r.payload;
        e.zIndexMap[t] ? n ? e.zIndexMap[t].panoramaElement = re(a) : e.zIndexMap[t].element = re(a) : e.zIndexMap[t] = {
          consumers: 0,
          element: n ? void 0 : re(a),
          panoramaElement: n ? re(a) : void 0
        };
      },
      prepare: oe()
    },
    unregisterZIndexPortalElement: {
      reducer: (e, r) => {
        var {
          zIndex: t
        } = r.payload;
        e.zIndexMap[t] && (r.payload.isPanorama ? e.zIndexMap[t].panoramaElement = void 0 : e.zIndexMap[t].element = void 0);
      },
      prepare: oe()
    }
  }
}), {
  registerZIndexPortal: Fx,
  unregisterZIndexPortal: Xx,
  registerZIndexPortalElement: Vx,
  unregisterZIndexPortalElement: Gx
} = xv.actions, Hx = xv.reducer;
function ee(e) {
  var {
    zIndex: r,
    children: t
  } = e, a = Sh(), n = a && r !== void 0 && r !== 0, i = te(), o = F();
  l.useLayoutEffect(() => n ? (o(Fx({
    zIndex: r
  })), () => {
    o(Xx({
      zIndex: r
    }));
  }) : ft, [o, r, n]);
  var u = k((s) => Lx(s, r, i));
  return n ? u ? /* @__PURE__ */ Hi.createPortal(t, u) : null : t;
}
function Ei() {
  return Ei = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ei.apply(null, arguments);
}
function Eu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Sa(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Eu(Object(t), !0).forEach(function(a) {
      Yx(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Eu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Yx(e, r, t) {
  return (r = Ux(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ux(e) {
  var r = Zx(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Zx(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function qx(e) {
  var {
    cursor: r,
    cursorComp: t,
    cursorProps: a
  } = e;
  return /* @__PURE__ */ l.isValidElement(r) ? /* @__PURE__ */ l.cloneElement(r, a) : /* @__PURE__ */ l.createElement(t, a);
}
function Jx(e) {
  var r, {
    coordinate: t,
    payload: a,
    index: n,
    offset: i,
    tooltipAxisBandSize: o,
    layout: u,
    cursor: s,
    tooltipEventType: c,
    chartName: d
  } = e, v = t, f = a, p = n;
  if (!s || !v || d !== "ScatterChart" && c !== "axis")
    return null;
  var m, h, g;
  if (d === "ScatterChart")
    m = v, h = hy, g = Y.cursorLine;
  else if (d === "BarChart")
    m = yy(u, v, i, o), h = oa, g = Y.cursorRectangle;
  else if (u === "radial" && Cc(v)) {
    var {
      cx: y,
      cy: b,
      radius: x,
      startAngle: O,
      endAngle: P
    } = od(v);
    m = {
      cx: y,
      cy: b,
      startAngle: O,
      endAngle: P,
      innerRadius: x,
      outerRadius: x
    }, h = ud, g = Y.cursorLine;
  } else
    m = {
      points: ig(u, v, i)
    }, h = zr, g = Y.cursorLine;
  var w = typeof s == "object" && "className" in s ? s.className : void 0, E = Sa(Sa(Sa(Sa({
    stroke: "#ccc",
    pointerEvents: "none"
  }, i), m), ze(s)), {}, {
    payload: f,
    payloadIndex: p,
    className: R("recharts-tooltip-cursor", w)
  });
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: (r = e.zIndex) !== null && r !== void 0 ? r : g
  }, /* @__PURE__ */ l.createElement(qx, {
    cursor: s,
    cursorComp: h,
    cursorProps: E
  }));
}
function Qx(e) {
  var r = bx(), t = Hc(), a = Er(), n = hv();
  return r == null || t == null || a == null || n == null ? null : /* @__PURE__ */ l.createElement(Jx, Ei({}, e, {
    offset: t,
    layout: a,
    tooltipAxisBandSize: r,
    chartName: n
  }));
}
var Rn = /* @__PURE__ */ l.createContext(null), eP = () => l.useContext(Rn), ut = new Tp(), ji = "recharts.syncEvent.tooltip", Si = "recharts.syncEvent.brush";
function Sr(e, r) {
  if (r) {
    var t = Number.parseInt(r, 10);
    if (!De(t))
      return e == null ? void 0 : e[t];
  }
}
var rP = {
  chartName: "",
  tooltipPayloadSearcher: void 0,
  eventEmitter: void 0,
  defaultTooltipEventType: "axis"
}, Pv = Be({
  name: "options",
  initialState: rP,
  reducers: {
    createEventEmitter: (e) => {
      e.eventEmitter == null && (e.eventEmitter = Symbol("rechartsEventEmitter"));
    }
  }
}), tP = Pv.reducer, {
  createEventEmitter: aP
} = Pv.actions;
function nP(e) {
  return e.tooltip.syncInteraction;
}
var iP = {
  chartData: void 0,
  computedData: void 0,
  dataStartIndex: 0,
  dataEndIndex: 0
}, Ov = Be({
  name: "chartData",
  initialState: iP,
  reducers: {
    setChartData(e, r) {
      if (e.chartData = r.payload, r.payload == null) {
        e.dataStartIndex = 0, e.dataEndIndex = 0;
        return;
      }
      r.payload.length > 0 && e.dataEndIndex !== r.payload.length - 1 && (e.dataEndIndex = r.payload.length - 1);
    },
    setComputedData(e, r) {
      e.computedData = r.payload;
    },
    setDataStartEndIndexes(e, r) {
      var {
        startIndex: t,
        endIndex: a
      } = r.payload;
      t != null && (e.dataStartIndex = t), a != null && (e.dataEndIndex = a);
    }
  }
}), {
  setChartData: Ii,
  setDataStartEndIndexes: ki,
  setComputedData: oP
} = Ov.actions, lP = Ov.reducer, uP = ["x", "y"];
function ju(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Qr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ju(Object(t), !0).forEach(function(a) {
      sP(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ju(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function sP(e, r, t) {
  return (r = cP(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function cP(e) {
  var r = dP(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function dP(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function vP(e, r) {
  if (e == null) return {};
  var t, a, n = fP(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function fP(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function pP() {
  var e = k(An), r = k(En), t = F(), a = k(Pd), n = k(jr), i = Er(), o = pt(), u = k((s) => s.rootProps.className);
  l.useEffect(() => {
    if (e == null)
      return ft;
    var s = (c, d, v) => {
      if (r !== v && e === c) {
        if (a === "index") {
          var f;
          if (o && d !== null && d !== void 0 && (f = d.payload) !== null && f !== void 0 && f.coordinate && d.payload.sourceViewBox) {
            var p = d.payload.coordinate, {
              x: m,
              y: h
            } = p, g = vP(p, uP), {
              x: y,
              y: b,
              width: x,
              height: O
            } = d.payload.sourceViewBox, P = Qr(Qr({}, g), {}, {
              x: o.x + (x ? (m - y) / x : 0) * o.width,
              y: o.y + (O ? (h - b) / O : 0) * o.height
            });
            t(Qr(Qr({}, d), {}, {
              payload: Qr(Qr({}, d.payload), {}, {
                coordinate: P
              })
            }));
          } else
            t(d);
          return;
        }
        if (n != null) {
          var w;
          if (typeof a == "function") {
            var E = {
              activeTooltipIndex: d.payload.index == null ? void 0 : Number(d.payload.index),
              isTooltipActive: d.payload.active,
              activeIndex: d.payload.index == null ? void 0 : Number(d.payload.index),
              activeLabel: d.payload.label,
              activeDataKey: d.payload.dataKey,
              activeCoordinate: d.payload.coordinate
            }, j = a(n, E);
            w = n[j];
          } else a === "value" && (w = n.find((W) => String(W.value) === d.payload.label));
          var {
            coordinate: S
          } = d.payload;
          if (w == null || d.payload.active === !1 || S == null || o == null) {
            t(wi({
              active: !1,
              coordinate: void 0,
              dataKey: void 0,
              index: null,
              label: void 0,
              sourceViewBox: void 0,
              graphicalItemId: void 0
            }));
            return;
          }
          var {
            x: I,
            y: D
          } = S, C = Math.min(I, o.x + o.width), M = Math.min(D, o.y + o.height), T = {
            x: i === "horizontal" ? w.coordinate : C,
            y: i === "horizontal" ? M : w.coordinate
          }, $ = wi({
            active: d.payload.active,
            coordinate: T,
            dataKey: d.payload.dataKey,
            index: String(w.index),
            label: d.payload.label,
            sourceViewBox: d.payload.sourceViewBox,
            graphicalItemId: d.payload.graphicalItemId
          });
          t($);
        }
      }
    };
    return ut.on(ji, s), () => {
      ut.off(ji, s);
    };
  }, [u, t, r, e, a, n, i, o]);
}
function mP() {
  var e = k(An), r = k(En), t = F();
  l.useEffect(() => {
    if (e == null)
      return ft;
    var a = (n, i, o) => {
      r !== o && e === n && t(ki(i));
    };
    return ut.on(Si, a), () => {
      ut.off(Si, a);
    };
  }, [t, r, e]);
}
function hP() {
  var e = F();
  l.useEffect(() => {
    e(aP());
  }, [e]), pP(), mP();
}
function yP(e, r, t, a, n, i) {
  var o = k((p) => Sx(p, e, r)), u = k(En), s = k(An), c = k(Pd), d = k(nP), v = d == null ? void 0 : d.active, f = pt();
  l.useEffect(() => {
    if (!v && s != null && u != null) {
      var p = wi({
        active: i,
        coordinate: t,
        dataKey: o,
        index: n,
        label: typeof a == "number" ? String(a) : a,
        sourceViewBox: f,
        graphicalItemId: void 0
      });
      ut.emit(ji, s, p, u);
    }
  }, [v, t, o, n, a, u, s, c, i, f]);
}
function gP() {
  var e = k(An), r = k(En), t = k((n) => n.chartData.dataStartIndex), a = k((n) => n.chartData.dataEndIndex);
  l.useEffect(() => {
    if (!(e == null || t == null || a == null || r == null)) {
      var n = {
        startIndex: t,
        endIndex: a
      };
      ut.emit(Si, e, n, r);
    }
  }, [a, t, r, e]);
}
function Su(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Iu(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Su(Object(t), !0).forEach(function(a) {
      bP(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Su(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function bP(e, r, t) {
  return (r = xP(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function xP(e) {
  var r = PP(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function PP(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function OP(e) {
  return e.dataKey;
}
function wP(e, r) {
  return /* @__PURE__ */ l.isValidElement(e) ? /* @__PURE__ */ l.cloneElement(e, r) : typeof e == "function" ? /* @__PURE__ */ l.createElement(e, r) : /* @__PURE__ */ l.createElement(Uh, r);
}
var ku = [], AP = {
  allowEscapeViewBox: {
    x: !1,
    y: !1
  },
  animationDuration: 400,
  animationEasing: "ease",
  axisId: 0,
  contentStyle: {},
  cursor: !0,
  filterNull: !0,
  includeHidden: !1,
  isAnimationActive: "auto",
  itemSorter: "name",
  itemStyle: {},
  labelStyle: {},
  offset: 10,
  reverseDirection: {
    x: !1,
    y: !1
  },
  separator: " : ",
  trigger: "hover",
  useTranslate3d: !1,
  wrapperStyle: {}
};
function RT(e) {
  var r, t, a = V(e, AP), {
    active: n,
    allowEscapeViewBox: i,
    animationDuration: o,
    animationEasing: u,
    content: s,
    filterNull: c,
    isAnimationActive: d,
    offset: v,
    payloadUniqBy: f,
    position: p,
    reverseDirection: m,
    useTranslate3d: h,
    wrapperStyle: g,
    cursor: y,
    shared: b,
    trigger: x,
    defaultIndex: O,
    portal: P,
    axisId: w
  } = a, E = F(), j = typeof O == "number" ? String(O) : O;
  l.useEffect(() => {
    E(Ab({
      shared: b,
      trigger: x,
      axisId: w,
      active: n,
      defaultIndex: j
    }));
  }, [E, b, x, w, n, j]);
  var S = pt(), I = Qc(), D = gb(b), {
    activeIndex: C,
    isActive: M
  } = (r = k((ce) => Cx(ce, D, x, j))) !== null && r !== void 0 ? r : {}, T = k((ce) => kx(ce, D, x, j)), $ = k((ce) => bv(ce, D, x, j)), W = k((ce) => Ix(ce, D, x, j)), X = T, Z = eP(), z = (t = n ?? M) !== null && t !== void 0 ? t : !1, [ne, ge] = $c([X, z]), fe = D === "axis" ? $ : void 0;
  yP(D, x, W, fe, C, z);
  var Ke = P ?? Z;
  if (Ke == null || S == null || D == null)
    return null;
  var je = X ?? ku;
  z || (je = ku), c && je.length && (je = Dc(je.filter((ce) => ce.value != null && (ce.hide !== !0 || a.includeHidden)), f, OP));
  var Fe = je.length > 0, pr = /* @__PURE__ */ l.createElement(ty, {
    allowEscapeViewBox: i,
    animationDuration: o,
    animationEasing: u,
    isAnimationActive: d,
    active: z,
    coordinate: W,
    hasPayload: Fe,
    offset: v,
    position: p,
    reverseDirection: m,
    useTranslate3d: h,
    viewBox: S,
    wrapperStyle: g,
    lastBoundingBox: ne,
    innerRef: ge,
    hasPortalFromProps: !!P
  }, wP(s, Iu(Iu({}, a), {}, {
    payload: je,
    label: fe,
    active: z,
    activeIndex: C,
    coordinate: W,
    accessibilityLayer: I
  })));
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ Hi.createPortal(pr, Ke), z && /* @__PURE__ */ l.createElement(Qx, {
    cursor: y,
    tooltipEventType: D,
    coordinate: W,
    payload: je,
    index: C
  }));
}
var Zr = (e) => null;
Zr.displayName = "Cell";
function EP(e, r, t) {
  return (r = jP(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function jP(e) {
  var r = SP(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function SP(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
class IP {
  constructor(r) {
    EP(this, "cache", /* @__PURE__ */ new Map()), this.maxSize = r;
  }
  get(r) {
    var t = this.cache.get(r);
    return t !== void 0 && (this.cache.delete(r), this.cache.set(r, t)), t;
  }
  set(r, t) {
    if (this.cache.has(r))
      this.cache.delete(r);
    else if (this.cache.size >= this.maxSize) {
      var a = this.cache.keys().next().value;
      a != null && this.cache.delete(a);
    }
    this.cache.set(r, t);
  }
  clear() {
    this.cache.clear();
  }
  size() {
    return this.cache.size;
  }
}
function Cu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function kP(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Cu(Object(t), !0).forEach(function(a) {
      CP(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Cu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function CP(e, r, t) {
  return (r = DP(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function DP(e) {
  var r = TP(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function TP(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var $P = {
  cacheSize: 2e3,
  enableCache: !0
}, wv = kP({}, $P), Du = new IP(wv.cacheSize), LP = {
  position: "absolute",
  top: "-20000px",
  left: 0,
  padding: 0,
  margin: 0,
  border: "none",
  whiteSpace: "pre"
}, Tu = "recharts_measurement_span";
function MP(e, r) {
  var t = r.fontSize || "", a = r.fontFamily || "", n = r.fontWeight || "", i = r.fontStyle || "", o = r.letterSpacing || "", u = r.textTransform || "";
  return "".concat(e, "|").concat(t, "|").concat(a, "|").concat(n, "|").concat(i, "|").concat(o, "|").concat(u);
}
var $u = (e, r) => {
  try {
    var t = document.getElementById(Tu);
    t || (t = document.createElement("span"), t.setAttribute("id", Tu), t.setAttribute("aria-hidden", "true"), document.body.appendChild(t)), Object.assign(t.style, LP, r), t.textContent = "".concat(e);
    var a = t.getBoundingClientRect();
    return {
      width: a.width,
      height: a.height
    };
  } catch {
    return {
      width: 0,
      height: 0
    };
  }
}, nt = function(r) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  if (r == null || mt.isSsr)
    return {
      width: 0,
      height: 0
    };
  if (!wv.enableCache)
    return $u(r, t);
  var a = MP(r, t), n = Du.get(a);
  if (n)
    return n;
  var i = $u(r, t);
  return Du.set(a, i), i;
}, Av;
function _P(e, r, t) {
  return (r = NP(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function NP(e) {
  var r = RP(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function RP(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Lu = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([*/])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, Mu = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([+-])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, BP = /^px|cm|vh|vw|em|rem|%|mm|in|pt|pc|ex|ch|vmin|vmax|Q$/, KP = /(-?\d+(?:\.\d+)?)([a-zA-Z%]+)?/, zP = {
  cm: 96 / 2.54,
  mm: 96 / 25.4,
  pt: 96 / 72,
  pc: 96 / 6,
  in: 96,
  Q: 96 / (2.54 * 40),
  px: 1
}, WP = ["cm", "mm", "pt", "pc", "in", "Q", "px"];
function FP(e) {
  return WP.includes(e);
}
var rt = "NaN";
function XP(e, r) {
  return e * zP[r];
}
class Ae {
  static parse(r) {
    var t, [, a, n] = (t = KP.exec(r)) !== null && t !== void 0 ? t : [];
    return a == null ? Ae.NaN : new Ae(parseFloat(a), n ?? "");
  }
  constructor(r, t) {
    this.num = r, this.unit = t, this.num = r, this.unit = t, De(r) && (this.unit = ""), t !== "" && !BP.test(t) && (this.num = NaN, this.unit = ""), FP(t) && (this.num = XP(r, t), this.unit = "px");
  }
  add(r) {
    return this.unit !== r.unit ? new Ae(NaN, "") : new Ae(this.num + r.num, this.unit);
  }
  subtract(r) {
    return this.unit !== r.unit ? new Ae(NaN, "") : new Ae(this.num - r.num, this.unit);
  }
  multiply(r) {
    return this.unit !== "" && r.unit !== "" && this.unit !== r.unit ? new Ae(NaN, "") : new Ae(this.num * r.num, this.unit || r.unit);
  }
  divide(r) {
    return this.unit !== "" && r.unit !== "" && this.unit !== r.unit ? new Ae(NaN, "") : new Ae(this.num / r.num, this.unit || r.unit);
  }
  toString() {
    return "".concat(this.num).concat(this.unit);
  }
  isNaN() {
    return De(this.num);
  }
}
Av = Ae;
_P(Ae, "NaN", new Av(NaN, ""));
function Ev(e) {
  if (e == null || e.includes(rt))
    return rt;
  for (var r = e; r.includes("*") || r.includes("/"); ) {
    var t, [, a, n, i] = (t = Lu.exec(r)) !== null && t !== void 0 ? t : [], o = Ae.parse(a ?? ""), u = Ae.parse(i ?? ""), s = n === "*" ? o.multiply(u) : o.divide(u);
    if (s.isNaN())
      return rt;
    r = r.replace(Lu, s.toString());
  }
  for (; r.includes("+") || /.-\d+(?:\.\d+)?/.test(r); ) {
    var c, [, d, v, f] = (c = Mu.exec(r)) !== null && c !== void 0 ? c : [], p = Ae.parse(d ?? ""), m = Ae.parse(f ?? ""), h = v === "+" ? p.add(m) : p.subtract(m);
    if (h.isNaN())
      return rt;
    r = r.replace(Mu, h.toString());
  }
  return r;
}
var _u = /\(([^()]*)\)/;
function VP(e) {
  for (var r = e, t; (t = _u.exec(r)) != null; ) {
    var [, a] = t;
    r = r.replace(_u, Ev(a));
  }
  return r;
}
function GP(e) {
  var r = e.replace(/\s+/g, "");
  return r = VP(r), r = Ev(r), r;
}
function HP(e) {
  try {
    return GP(e);
  } catch {
    return rt;
  }
}
function ti(e) {
  var r = HP(e.slice(5, -1));
  return r === rt ? "" : r;
}
var YP = ["x", "y", "lineHeight", "capHeight", "fill", "scaleToFit", "textAnchor", "verticalAnchor"], UP = ["dx", "dy", "angle", "className", "breakAll"];
function Ci() {
  return Ci = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ci.apply(null, arguments);
}
function Nu(e, r) {
  if (e == null) return {};
  var t, a, n = ZP(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function ZP(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var jv = /[ \f\n\r\t\v\u2028\u2029]+/, Sv = (e) => {
  var {
    children: r,
    breakAll: t,
    style: a
  } = e;
  try {
    var n = [];
    U(r) || (t ? n = r.toString().split("") : n = r.toString().split(jv));
    var i = n.map((u) => ({
      word: u,
      width: nt(u, a).width
    })), o = t ? 0 : nt(" ", a).width;
    return {
      wordsWithComputedWidth: i,
      spaceWidth: o
    };
  } catch {
    return null;
  }
};
function qP(e) {
  return e === "start" || e === "middle" || e === "end" || e === "inherit";
}
var Iv = (e, r, t, a) => e.reduce((n, i) => {
  var {
    word: o,
    width: u
  } = i, s = n[n.length - 1];
  if (s && u != null && (r == null || a || s.width + u + t < Number(r)))
    s.words.push(o), s.width += u + t;
  else {
    var c = {
      words: [o],
      width: u
    };
    n.push(c);
  }
  return n;
}, []), kv = (e) => e.reduce((r, t) => r.width > t.width ? r : t), JP = "…", Ru = (e, r, t, a, n, i, o, u) => {
  var s = e.slice(0, r), c = Sv({
    breakAll: t,
    style: a,
    children: s + JP
  });
  if (!c)
    return [!1, []];
  var d = Iv(c.wordsWithComputedWidth, i, o, u), v = d.length > n || kv(d).width > Number(i);
  return [v, d];
}, QP = (e, r, t, a, n) => {
  var {
    maxLines: i,
    children: o,
    style: u,
    breakAll: s
  } = e, c = L(i), d = String(o), v = Iv(r, a, t, n);
  if (!c || n)
    return v;
  var f = v.length > i || kv(v).width > Number(a);
  if (!f)
    return v;
  for (var p = 0, m = d.length - 1, h = 0, g; p <= m && h <= d.length - 1; ) {
    var y = Math.floor((p + m) / 2), b = y - 1, [x, O] = Ru(d, b, s, u, i, a, t, n), [P] = Ru(d, y, s, u, i, a, t, n);
    if (!x && !P && (p = y + 1), x && P && (m = y - 1), !x && P) {
      g = O;
      break;
    }
    h++;
  }
  return g || v;
}, Bu = (e) => {
  var r = U(e) ? [] : e.toString().split(jv);
  return [{
    words: r,
    width: void 0
  }];
}, eO = (e) => {
  var {
    width: r,
    scaleToFit: t,
    children: a,
    style: n,
    breakAll: i,
    maxLines: o
  } = e;
  if ((r || t) && !mt.isSsr) {
    var u, s, c = Sv({
      breakAll: i,
      children: a,
      style: n
    });
    if (c) {
      var {
        wordsWithComputedWidth: d,
        spaceWidth: v
      } = c;
      u = d, s = v;
    } else
      return Bu(a);
    return QP({
      breakAll: i,
      children: a,
      maxLines: o,
      style: n
    }, u, s, r, !!t);
  }
  return Bu(a);
}, Cv = "#808080", rO = {
  angle: 0,
  breakAll: !1,
  // Magic number from d3
  capHeight: "0.71em",
  fill: Cv,
  lineHeight: "1em",
  scaleToFit: !1,
  textAnchor: "start",
  // Maintain compat with existing charts / default SVG behavior
  verticalAnchor: "end",
  x: 0,
  y: 0
}, Tr = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = V(e, rO), {
    x: a,
    y: n,
    lineHeight: i,
    capHeight: o,
    fill: u,
    scaleToFit: s,
    textAnchor: c,
    verticalAnchor: d
  } = t, v = Nu(t, YP), f = l.useMemo(() => eO({
    breakAll: v.breakAll,
    children: v.children,
    maxLines: v.maxLines,
    scaleToFit: s,
    style: v.style,
    width: v.width
  }), [v.breakAll, v.children, v.maxLines, s, v.style, v.width]), {
    dx: p,
    dy: m,
    angle: h,
    className: g,
    breakAll: y
  } = v, b = Nu(v, UP);
  if (!we(a) || !we(n) || f.length === 0)
    return null;
  var x = Number(a) + (L(p) ? p : 0), O = Number(n) + (L(m) ? m : 0);
  if (!q(x) || !q(O))
    return null;
  var P;
  switch (d) {
    case "start":
      P = ti("calc(".concat(o, ")"));
      break;
    case "middle":
      P = ti("calc(".concat((f.length - 1) / 2, " * -").concat(i, " + (").concat(o, " / 2))"));
      break;
    default:
      P = ti("calc(".concat(f.length - 1, " * -").concat(i, ")"));
      break;
  }
  var w = [];
  if (s) {
    var E = f[0].width, {
      width: j
    } = v;
    w.push("scale(".concat(L(j) && L(E) ? j / E : 1, ")"));
  }
  return h && w.push("rotate(".concat(h, ", ").concat(x, ", ").concat(O, ")")), w.length && (b.transform = w.join(" ")), /* @__PURE__ */ l.createElement("text", Ci({}, le(b), {
    ref: r,
    x,
    y: O,
    className: R("recharts-text", g),
    textAnchor: c,
    fill: u.includes("url") ? Cv : u
  }), f.map((S, I) => {
    var D = S.words.join(y ? "" : " ");
    return (
      // duplicate words will cause duplicate keys which is why we add the array index here
      /* @__PURE__ */ l.createElement("tspan", {
        x,
        dy: I === 0 ? P : i,
        key: "".concat(D, "-").concat(I)
      }, D)
    );
  }));
});
Tr.displayName = "Text";
var tO = ["labelRef"], aO = ["content"];
function Ku(e, r) {
  if (e == null) return {};
  var t, a, n = nO(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function nO(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function zu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ve(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? zu(Object(t), !0).forEach(function(a) {
      iO(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : zu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function iO(e, r, t) {
  return (r = oO(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function oO(e) {
  var r = lO(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function lO(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function hr() {
  return hr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, hr.apply(null, arguments);
}
var Dv = /* @__PURE__ */ l.createContext(null), Bn = (e) => {
  var {
    x: r,
    y: t,
    upperWidth: a,
    lowerWidth: n,
    width: i,
    height: o,
    children: u
  } = e, s = l.useMemo(() => ({
    x: r,
    y: t,
    upperWidth: a,
    lowerWidth: n,
    width: i,
    height: o
  }), [r, t, a, n, i, o]);
  return /* @__PURE__ */ l.createElement(Dv.Provider, {
    value: s
  }, u);
}, Tv = () => {
  var e = l.useContext(Dv), r = pt();
  return e || Gc(r);
}, $v = /* @__PURE__ */ l.createContext(null), uO = (e) => {
  var {
    cx: r,
    cy: t,
    innerRadius: a,
    outerRadius: n,
    startAngle: i,
    endAngle: o,
    clockWise: u,
    children: s
  } = e, c = l.useMemo(() => ({
    cx: r,
    cy: t,
    innerRadius: a,
    outerRadius: n,
    startAngle: i,
    endAngle: o,
    clockWise: u
  }), [r, t, a, n, i, o, u]);
  return /* @__PURE__ */ l.createElement($v.Provider, {
    value: c
  }, s);
}, Lv = () => {
  var e = l.useContext($v), r = k(Ur);
  return e || r;
}, sO = (e) => {
  var {
    value: r,
    formatter: t
  } = e, a = U(e.children) ? r : e.children;
  return typeof t == "function" ? t(a) : a;
}, zo = (e) => e != null && typeof e == "function", cO = (e, r) => {
  var t = me(r - e), a = Math.min(Math.abs(r - e), 360);
  return t * a;
}, dO = (e, r, t, a, n) => {
  var {
    offset: i,
    className: o
  } = e, {
    cx: u,
    cy: s,
    innerRadius: c,
    outerRadius: d,
    startAngle: v,
    endAngle: f,
    clockWise: p
  } = n, m = (c + d) / 2, h = cO(v, f), g = h >= 0 ? 1 : -1, y, b;
  switch (r) {
    case "insideStart":
      y = v + g * i, b = p;
      break;
    case "insideEnd":
      y = f - g * i, b = !p;
      break;
    case "end":
      y = f + g * i, b = p;
      break;
    default:
      throw new Error("Unsupported position ".concat(r));
  }
  b = h <= 0 ? b : !b;
  var x = J(u, s, m, y), O = J(u, s, m, y + (b ? 1 : -1) * 359), P = "M".concat(x.x, ",").concat(x.y, `
    A`).concat(m, ",").concat(m, ",0,1,").concat(b ? 0 : 1, `,
    `).concat(O.x, ",").concat(O.y), w = U(e.id) ? it("recharts-radial-line-") : e.id;
  return /* @__PURE__ */ l.createElement("text", hr({}, a, {
    dominantBaseline: "central",
    className: R("recharts-radial-bar-label", o)
  }), /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement("path", {
    id: w,
    d: P
  })), /* @__PURE__ */ l.createElement("textPath", {
    xlinkHref: "#".concat(w)
  }, t));
}, vO = (e, r, t) => {
  var {
    cx: a,
    cy: n,
    innerRadius: i,
    outerRadius: o,
    startAngle: u,
    endAngle: s
  } = e, c = (u + s) / 2;
  if (t === "outside") {
    var {
      x: d,
      y: v
    } = J(a, n, o + r, c);
    return {
      x: d,
      y: v,
      textAnchor: d >= a ? "start" : "end",
      verticalAnchor: "middle"
    };
  }
  if (t === "center")
    return {
      x: a,
      y: n,
      textAnchor: "middle",
      verticalAnchor: "middle"
    };
  if (t === "centerTop")
    return {
      x: a,
      y: n,
      textAnchor: "middle",
      verticalAnchor: "start"
    };
  if (t === "centerBottom")
    return {
      x: a,
      y: n,
      textAnchor: "middle",
      verticalAnchor: "end"
    };
  var f = (i + o) / 2, {
    x: p,
    y: m
  } = J(a, n, f, c);
  return {
    x: p,
    y: m,
    textAnchor: "middle",
    verticalAnchor: "middle"
  };
}, Di = (e) => "cx" in e && L(e.cx), fO = (e, r) => {
  var {
    parentViewBox: t,
    offset: a,
    position: n
  } = e, i;
  t != null && !Di(t) && (i = t);
  var {
    x: o,
    y: u,
    upperWidth: s,
    lowerWidth: c,
    height: d
  } = r, v = o, f = o + (s - c) / 2, p = (v + f) / 2, m = (s + c) / 2, h = v + s / 2, g = d >= 0 ? 1 : -1, y = g * a, b = g > 0 ? "end" : "start", x = g > 0 ? "start" : "end", O = s >= 0 ? 1 : -1, P = O * a, w = O > 0 ? "end" : "start", E = O > 0 ? "start" : "end";
  if (n === "top") {
    var j = {
      x: v + s / 2,
      y: u - y,
      textAnchor: "middle",
      verticalAnchor: b
    };
    return ve(ve({}, j), i ? {
      height: Math.max(u - i.y, 0),
      width: s
    } : {});
  }
  if (n === "bottom") {
    var S = {
      x: f + c / 2,
      y: u + d + y,
      textAnchor: "middle",
      verticalAnchor: x
    };
    return ve(ve({}, S), i ? {
      height: Math.max(i.y + i.height - (u + d), 0),
      width: c
    } : {});
  }
  if (n === "left") {
    var I = {
      x: p - P,
      y: u + d / 2,
      textAnchor: w,
      verticalAnchor: "middle"
    };
    return ve(ve({}, I), i ? {
      width: Math.max(I.x - i.x, 0),
      height: d
    } : {});
  }
  if (n === "right") {
    var D = {
      x: p + m + P,
      y: u + d / 2,
      textAnchor: E,
      verticalAnchor: "middle"
    };
    return ve(ve({}, D), i ? {
      width: Math.max(i.x + i.width - D.x, 0),
      height: d
    } : {});
  }
  var C = i ? {
    width: m,
    height: d
  } : {};
  return n === "insideLeft" ? ve({
    x: p + P,
    y: u + d / 2,
    textAnchor: E,
    verticalAnchor: "middle"
  }, C) : n === "insideRight" ? ve({
    x: p + m - P,
    y: u + d / 2,
    textAnchor: w,
    verticalAnchor: "middle"
  }, C) : n === "insideTop" ? ve({
    x: v + s / 2,
    y: u + y,
    textAnchor: "middle",
    verticalAnchor: x
  }, C) : n === "insideBottom" ? ve({
    x: f + c / 2,
    y: u + d - y,
    textAnchor: "middle",
    verticalAnchor: b
  }, C) : n === "insideTopLeft" ? ve({
    x: v + P,
    y: u + y,
    textAnchor: E,
    verticalAnchor: x
  }, C) : n === "insideTopRight" ? ve({
    x: v + s - P,
    y: u + y,
    textAnchor: w,
    verticalAnchor: x
  }, C) : n === "insideBottomLeft" ? ve({
    x: f + P,
    y: u + d - y,
    textAnchor: E,
    verticalAnchor: b
  }, C) : n === "insideBottomRight" ? ve({
    x: f + c - P,
    y: u + d - y,
    textAnchor: w,
    verticalAnchor: b
  }, C) : n && typeof n == "object" && (L(n.x) || xr(n.x)) && (L(n.y) || xr(n.y)) ? ve({
    x: o + Ee(n.x, m),
    y: u + Ee(n.y, d),
    textAnchor: "end",
    verticalAnchor: "end"
  }, C) : ve({
    x: h,
    y: u + d / 2,
    textAnchor: "middle",
    verticalAnchor: "middle"
  }, C);
}, pO = {
  angle: 0,
  offset: 5,
  zIndex: Y.label,
  position: "middle",
  textBreakAll: !1
};
function Ir(e) {
  var r = V(e, pO), {
    viewBox: t,
    position: a,
    value: n,
    children: i,
    content: o,
    className: u = "",
    textBreakAll: s,
    labelRef: c
  } = r, d = Lv(), v = Tv(), f = a === "center" ? v : d ?? v, p, m, h;
  if (t == null ? p = f : Di(t) ? p = t : p = Gc(t), !p || U(n) && U(i) && !/* @__PURE__ */ l.isValidElement(o) && typeof o != "function")
    return null;
  var g = ve(ve({}, r), {}, {
    viewBox: p
  });
  if (/* @__PURE__ */ l.isValidElement(o)) {
    var {
      labelRef: y
    } = g, b = Ku(g, tO);
    return /* @__PURE__ */ l.cloneElement(o, b);
  }
  if (typeof o == "function") {
    var {
      content: x
    } = g, O = Ku(g, aO);
    if (m = /* @__PURE__ */ l.createElement(o, O), /* @__PURE__ */ l.isValidElement(m))
      return m;
  } else
    m = sO(r);
  var P = le(r);
  if (Di(p)) {
    if (a === "insideStart" || a === "insideEnd" || a === "end")
      return dO(r, a, m, P, p);
    h = vO(p, r.offset, r.position);
  } else
    h = fO(r, p);
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: r.zIndex
  }, /* @__PURE__ */ l.createElement(Tr, hr({
    ref: c,
    className: R("recharts-label", u)
  }, P, h, {
    /*
     * textAnchor is decided by default based on the `position`
     * but we allow overriding via props for precise control.
     */
    textAnchor: qP(P.textAnchor) ? P.textAnchor : h.textAnchor,
    breakAll: s
  }), m));
}
Ir.displayName = "Label";
var Mv = (e, r, t) => {
  if (!e)
    return null;
  var a = {
    viewBox: r,
    labelRef: t
  };
  return e === !0 ? /* @__PURE__ */ l.createElement(Ir, hr({
    key: "label-implicit"
  }, a)) : we(e) ? /* @__PURE__ */ l.createElement(Ir, hr({
    key: "label-implicit",
    value: e
  }, a)) : /* @__PURE__ */ l.isValidElement(e) ? e.type === Ir ? /* @__PURE__ */ l.cloneElement(e, ve({
    key: "label-implicit"
  }, a)) : /* @__PURE__ */ l.createElement(Ir, hr({
    key: "label-implicit",
    content: e
  }, a)) : zo(e) ? /* @__PURE__ */ l.createElement(Ir, hr({
    key: "label-implicit",
    content: e
  }, a)) : e && typeof e == "object" ? /* @__PURE__ */ l.createElement(Ir, hr({}, e, {
    key: "label-implicit"
  }, a)) : null;
};
function Kn(e) {
  var {
    label: r,
    labelRef: t
  } = e, a = Tv();
  return Mv(r, a, t) || null;
}
function mO(e) {
  var {
    label: r
  } = e, t = Lv();
  return Mv(r, t) || null;
}
var hO = ["valueAccessor"], yO = ["dataKey", "clockWise", "id", "textBreakAll", "zIndex"];
function Za() {
  return Za = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Za.apply(null, arguments);
}
function Wu(e, r) {
  if (e == null) return {};
  var t, a, n = gO(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function gO(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var bO = (e) => Array.isArray(e.value) ? Pc(e.value) : e.value, _v = /* @__PURE__ */ l.createContext(void 0), jt = _v.Provider, Nv = /* @__PURE__ */ l.createContext(void 0), Rv = Nv.Provider;
function xO() {
  return l.useContext(_v);
}
function PO() {
  return l.useContext(Nv);
}
function La(e) {
  var {
    valueAccessor: r = bO
  } = e, t = Wu(e, hO), {
    dataKey: a,
    clockWise: n,
    id: i,
    textBreakAll: o,
    zIndex: u
  } = t, s = Wu(t, yO), c = xO(), d = PO(), v = c || d;
  return !v || !v.length ? null : /* @__PURE__ */ l.createElement(ee, {
    zIndex: u ?? Y.label
  }, /* @__PURE__ */ l.createElement(_, {
    className: "recharts-label-list"
  }, v.map((f, p) => {
    var m, h = U(a) ? r(f, p) : B(f && f.payload, a), g = U(i) ? {} : {
      id: "".concat(i, "-").concat(p)
    };
    return /* @__PURE__ */ l.createElement(Ir, Za({
      key: "label-".concat(p)
    }, le(f), s, g, {
      /*
       * Prefer to use the explicit fill from LabelList props.
       * Only in an absence of that, fall back to the fill of the entry.
       * The entry fill can be quite difficult to see especially in Bar, Pie, RadialBar in inside positions.
       * On the other hand it's quite convenient in Scatter, Line, or when the position is outside the Bar, Pie filled shapes.
       */
      fill: (m = t.fill) !== null && m !== void 0 ? m : f.fill,
      parentViewBox: f.parentViewBox,
      value: h,
      textBreakAll: o,
      viewBox: f.viewBox,
      index: p,
      zIndex: 0
    }));
  })));
}
La.displayName = "LabelList";
function _r(e) {
  var {
    label: r
  } = e;
  return r ? r === !0 ? /* @__PURE__ */ l.createElement(La, {
    key: "labelList-implicit"
  }) : /* @__PURE__ */ l.isValidElement(r) || zo(r) ? /* @__PURE__ */ l.createElement(La, {
    key: "labelList-implicit",
    content: r
  }) : typeof r == "object" ? /* @__PURE__ */ l.createElement(La, Za({
    key: "labelList-implicit"
  }, r, {
    type: String(r.type)
  })) : null : null;
}
var OO = ["points", "className", "baseLinePoints", "connectNulls"], Fu;
function tt() {
  return tt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, tt.apply(null, arguments);
}
function wO(e, r) {
  if (e == null) return {};
  var t, a, n = AO(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function AO(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function EO(e, r) {
  return r || (r = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(r) } }));
}
var Xu = (e) => e && e.x === +e.x && e.y === +e.y, jO = function() {
  var r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], t = [[]];
  return r.forEach((a) => {
    Xu(a) ? t[t.length - 1].push(a) : t[t.length - 1].length > 0 && t.push([]);
  }), Xu(r[0]) && t[t.length - 1].push(r[0]), t[t.length - 1].length <= 0 && (t = t.slice(0, -1)), t;
}, Bt = (e, r) => {
  var t = jO(e);
  r && (t = [t.reduce((n, i) => [...n, ...i], [])]);
  var a = t.map((n) => n.reduce((i, o, u) => ue(Fu || (Fu = EO(["", "", "", ",", ""])), i, u === 0 ? "M" : "L", o.x, o.y), "")).join("");
  return t.length === 1 ? "".concat(a, "Z") : a;
}, SO = (e, r, t) => {
  var a = Bt(e, t);
  return "".concat(a.slice(-1) === "Z" ? a.slice(0, -1) : a, "L").concat(Bt(Array.from(r).reverse(), t).slice(1));
}, Wo = (e) => {
  var {
    points: r,
    className: t,
    baseLinePoints: a,
    connectNulls: n
  } = e, i = wO(e, OO);
  if (!r || !r.length)
    return null;
  var o = R("recharts-polygon", t);
  if (a && a.length) {
    var u = i.stroke && i.stroke !== "none", s = SO(r, a, n);
    return /* @__PURE__ */ l.createElement("g", {
      className: o
    }, /* @__PURE__ */ l.createElement("path", tt({}, le(i), {
      fill: s.slice(-1) === "Z" ? i.fill : "none",
      stroke: "none",
      d: s
    })), u ? /* @__PURE__ */ l.createElement("path", tt({}, le(i), {
      fill: "none",
      d: Bt(r, n)
    })) : null, u ? /* @__PURE__ */ l.createElement("path", tt({}, le(i), {
      fill: "none",
      d: Bt(a, n)
    })) : null);
  }
  var c = Bt(r, n);
  return /* @__PURE__ */ l.createElement("path", tt({}, le(i), {
    fill: c.slice(-1) === "Z" ? i.fill : "none",
    className: o,
    d: c
  }));
};
function Ti() {
  return Ti = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ti.apply(null, arguments);
}
var zn = (e) => {
  var {
    cx: r,
    cy: t,
    r: a,
    className: n
  } = e, i = R("recharts-dot", n);
  return L(r) && L(t) && L(a) ? /* @__PURE__ */ l.createElement("circle", Ti({}, G(e), qi(e), {
    className: i,
    cx: r,
    cy: t,
    r: a
  })) : null;
}, ha = (e) => e.graphicalItems.polarItems, IO = A([ae, la], co), ya = A([ha, se, IO], vo), kO = A([ya], fo), Wn = A([kO, Lr], po), Bv = A([Wn, se, ya], ho);
A([Wn, se, ya], (e, r, t) => t.length > 0 ? e.flatMap((a) => t.flatMap((n) => {
  var i, o = B(a, (i = r.dataKey) !== null && i !== void 0 ? i : n.dataKey);
  return {
    value: o,
    errorDomain: []
    // polar charts do not have error bars
  };
})).filter(Boolean) : (r == null ? void 0 : r.dataKey) != null ? e.map((a) => ({
  value: B(a, r.dataKey),
  errorDomain: []
})) : e.map((a) => ({
  value: a,
  errorDomain: []
})));
var Vu = () => {
}, CO = A([Wn, se, ya, Tn, ae], Po), DO = A([se, bo, xo, Vu, CO, Vu, K, ae], Oo), Kv = A([se, K, Wn, Bv, ht, ae, DO], wo), zv = A([Kv, se, Mr], Eo), TO = A([se, Kv, zv, ae], So), Fo = (e, r, t) => {
  switch (r) {
    case "angleAxis":
      return Yr(e, t);
    case "radiusAxis":
      return yt(e, t);
    default:
      throw new Error("Unexpected axis type: ".concat(r));
  }
}, Xo = (e, r, t) => {
  switch (r) {
    case "angleAxis":
      return xg(e, t);
    case "radiusAxis":
      return Pg(e, t);
    default:
      throw new Error("Unexpected axis type: ".concat(r));
  }
}, Nr = A([Fo, Mr, TO, Xo], $n), Wv = A([K, Bv, bt, ae], Io), qr = A([K, Fo, Mr, Nr, zv, Xo, va, Wv, ae], Hd), $O = A([qr], (e) => {
  if (e) {
    var r = /* @__PURE__ */ new Map();
    return e.forEach((t) => {
      var a = (t.coordinate + 360) % 360;
      r.has(a) || r.set(a, t);
    }), Array.from(r.values());
  }
}), LO = A([K, Fo, Nr, Xo, va, Wv, ae], Ud), MO = (e, r) => qr(e, "angleAxis", r, !1), _O = A([MO], (e) => {
  if (e)
    return e.map((r) => r.coordinate);
}), NO = (e, r) => qr(e, "radiusAxis", r, !1), RO = A([NO], (e) => {
  if (e)
    return e.map((r) => r.coordinate);
}), BO = ["gridType", "radialLines", "angleAxisId", "radiusAxisId", "cx", "cy", "innerRadius", "outerRadius", "polarAngles", "polarRadius"];
function KO(e, r) {
  if (e == null) return {};
  var t, a, n = zO(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function zO(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Ye() {
  return Ye = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ye.apply(null, arguments);
}
function Gu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ft(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Gu(Object(t), !0).forEach(function(a) {
      WO(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Gu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function WO(e, r, t) {
  return (r = FO(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function FO(e) {
  var r = XO(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function XO(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var VO = (e, r, t, a) => {
  var n = "";
  return a.forEach((i, o) => {
    var u = J(r, t, e, i);
    o ? n += "L ".concat(u.x, ",").concat(u.y) : n += "M ".concat(u.x, ",").concat(u.y);
  }), n += "Z", n;
}, GO = (e) => {
  var {
    cx: r,
    cy: t,
    innerRadius: a,
    outerRadius: n,
    polarAngles: i,
    radialLines: o
  } = e;
  if (!i || !i.length || !o)
    return null;
  var u = Ft({
    stroke: "#ccc"
  }, G(e));
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-polar-grid-angle"
  }, i.map((s) => {
    var c = J(r, t, a, s), d = J(r, t, n, s);
    return /* @__PURE__ */ l.createElement("line", Ye({
      key: "line-".concat(s)
    }, u, {
      x1: c.x,
      y1: c.y,
      x2: d.x,
      y2: d.y
    }));
  }));
}, Hu = (e) => {
  var {
    cx: r,
    cy: t,
    radius: a
  } = e, n = Ft({
    stroke: "#ccc",
    fill: "none"
  }, G(e));
  return (
    // @ts-expect-error wrong SVG element type
    /* @__PURE__ */ l.createElement("circle", Ye({}, n, {
      className: R("recharts-polar-grid-concentric-circle", e.className),
      cx: r,
      cy: t,
      r: a
    }))
  );
}, Yu = (e) => {
  var {
    radius: r
  } = e, t = Ft({
    stroke: "#ccc",
    fill: "none"
  }, G(e));
  return /* @__PURE__ */ l.createElement("path", Ye({}, t, {
    className: R("recharts-polar-grid-concentric-polygon", e.className),
    d: VO(r, e.cx, e.cy, e.polarAngles)
  }));
}, HO = (e) => {
  var {
    polarRadius: r,
    gridType: t
  } = e;
  if (!r || !r.length)
    return null;
  var a = Math.max(...r), n = e.fill && e.fill !== "none";
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-polar-grid-concentric"
  }, n && t === "circle" && /* @__PURE__ */ l.createElement(Hu, Ye({}, e, {
    radius: a
  })), n && t !== "circle" && /* @__PURE__ */ l.createElement(Yu, Ye({}, e, {
    radius: a
  })), r.map((i, o) => {
    var u = o;
    return t === "circle" ? /* @__PURE__ */ l.createElement(Hu, Ye({
      key: u
    }, e, {
      fill: "none",
      radius: i
    })) : /* @__PURE__ */ l.createElement(Yu, Ye({
      key: u
    }, e, {
      fill: "none",
      radius: i
    }));
  }));
}, YO = (e) => {
  var r, t, a, n, i, o, u, s, c, {
    gridType: d = "polygon",
    radialLines: v = !0,
    angleAxisId: f = 0,
    radiusAxisId: p = 0,
    cx: m,
    cy: h,
    innerRadius: g,
    outerRadius: y,
    polarAngles: b,
    polarRadius: x
  } = e, O = KO(e, BO), P = k(Ur), w = k((C) => _O(C, f)), E = k((C) => RO(C, p)), j = Array.isArray(b) ? b : w, S = Array.isArray(x) ? x : E;
  if (j == null || S == null)
    return null;
  var I = Ft(Ft({
    cx: (r = (t = P == null ? void 0 : P.cx) !== null && t !== void 0 ? t : m) !== null && r !== void 0 ? r : 0,
    cy: (a = (n = P == null ? void 0 : P.cy) !== null && n !== void 0 ? n : h) !== null && a !== void 0 ? a : 0,
    innerRadius: (i = (o = P == null ? void 0 : P.innerRadius) !== null && o !== void 0 ? o : g) !== null && i !== void 0 ? i : 0,
    outerRadius: (u = (s = P == null ? void 0 : P.outerRadius) !== null && s !== void 0 ? s : y) !== null && u !== void 0 ? u : 0,
    polarAngles: j,
    polarRadius: S
  }, O), {}, {
    zIndex: (c = O.zIndex) !== null && c !== void 0 ? c : Y.grid
  }), {
    outerRadius: D
  } = I;
  return D <= 0 ? null : /* @__PURE__ */ l.createElement(ee, {
    zIndex: I.zIndex
  }, /* @__PURE__ */ l.createElement("g", {
    className: "recharts-polar-grid"
  }, /* @__PURE__ */ l.createElement(HO, Ye({
    gridType: d,
    radialLines: v
  }, I, {
    polarAngles: j,
    polarRadius: S
  })), /* @__PURE__ */ l.createElement(GO, Ye({
    gridType: d,
    radialLines: v
  }, I, {
    polarAngles: j,
    polarRadius: S
  }))));
};
YO.displayName = "PolarGrid";
var UO = {
  radiusAxis: {},
  angleAxis: {}
}, Fv = Be({
  name: "polarAxis",
  initialState: UO,
  reducers: {
    addRadiusAxis(e, r) {
      e.radiusAxis[r.payload.id] = re(r.payload);
    },
    removeRadiusAxis(e, r) {
      delete e.radiusAxis[r.payload.id];
    },
    addAngleAxis(e, r) {
      e.angleAxis[r.payload.id] = re(r.payload);
    },
    removeAngleAxis(e, r) {
      delete e.angleAxis[r.payload.id];
    }
  }
}), {
  addRadiusAxis: ZO,
  removeRadiusAxis: qO,
  addAngleAxis: JO,
  removeAngleAxis: QO
} = Fv.actions, e0 = Fv.reducer, r0 = ["cx", "cy", "angle", "axisLine"], t0 = ["angle", "tickFormatter", "stroke", "tick"];
function Xt() {
  return Xt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Xt.apply(null, arguments);
}
function Uu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function gr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Uu(Object(t), !0).forEach(function(a) {
      a0(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Uu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function a0(e, r, t) {
  return (r = n0(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function n0(e) {
  var r = i0(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function i0(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Xv(e, r) {
  if (e == null) return {};
  var t, a, n = o0(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function o0(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var l0 = "radiusAxis";
function u0(e) {
  var r = F();
  return l.useEffect(() => (r(ZO(e)), () => {
    r(qO(e));
  })), null;
}
var s0 = (e, r, t, a) => {
  var {
    coordinate: n
  } = e;
  return J(t, a, n, r);
}, c0 = (e) => {
  var r;
  switch (e) {
    case "left":
      r = "end";
      break;
    case "right":
      r = "start";
      break;
    default:
      r = "middle";
      break;
  }
  return r;
}, d0 = (e, r, t, a) => {
  var n = Oc(a, (o) => o.coordinate || 0), i = $p(a, (o) => o.coordinate || 0);
  return {
    cx: r,
    cy: t,
    startAngle: e,
    endAngle: e,
    innerRadius: (i == null ? void 0 : i.coordinate) || 0,
    outerRadius: (n == null ? void 0 : n.coordinate) || 0,
    clockWise: !1
  };
}, v0 = (e, r) => {
  var {
    cx: t,
    cy: a,
    angle: n,
    axisLine: i
  } = e, o = Xv(e, r0), u = r.reduce((v, f) => [Math.min(v[0], f.coordinate), Math.max(v[1], f.coordinate)], [1 / 0, -1 / 0]), s = J(t, a, u[0], n), c = J(t, a, u[1], n), d = gr(gr(gr({}, G(o)), {}, {
    fill: "none"
  }, G(i)), {}, {
    x1: s.x,
    y1: s.y,
    x2: c.x,
    y2: c.y
  });
  return /* @__PURE__ */ l.createElement("line", Xt({
    className: "recharts-polar-radius-axis-line"
  }, d));
}, f0 = (e, r, t) => {
  var a;
  return /* @__PURE__ */ l.isValidElement(e) ? a = /* @__PURE__ */ l.cloneElement(e, r) : typeof e == "function" ? a = e(r) : a = /* @__PURE__ */ l.createElement(Tr, Xt({}, r, {
    className: "recharts-polar-radius-axis-tick-value"
  }), t), a;
}, p0 = (e, r) => {
  var {
    angle: t,
    tickFormatter: a,
    stroke: n,
    tick: i
  } = e, o = Xv(e, t0), u = c0(e.orientation), s = G(o), c = ze(i), d = r.map((v, f) => {
    var p = s0(v, e.angle, e.cx, e.cy), m = gr(gr(gr(gr({
      textAnchor: u,
      transform: "rotate(".concat(90 - t, ", ").concat(p.x, ", ").concat(p.y, ")")
    }, s), {}, {
      stroke: "none",
      fill: n
    }, c), {}, {
      index: f
    }, p), {}, {
      payload: v
    });
    return /* @__PURE__ */ l.createElement(_, Xt({
      className: R("recharts-polar-radius-axis-tick", id(i)),
      key: "tick-".concat(v.coordinate)
    }, Ue(e, v, f)), f0(i, m, a ? a(v.value, f) : v.value));
  });
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-polar-radius-axis-ticks"
  }, d);
}, m0 = (e) => {
  var {
    radiusAxisId: r
  } = e, t = k(Ur), a = k((s) => Nr(s, "radiusAxis", r)), n = k((s) => qr(s, "radiusAxis", r, !1));
  if (t == null || !n || !n.length || a == null)
    return null;
  var i = gr(gr({}, e), {}, {
    scale: a
  }, t), {
    tick: o,
    axisLine: u
  } = i;
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: i.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-polar-radius-axis", l0, i.className)
  }, u && v0(i, n), o && p0(i, n), /* @__PURE__ */ l.createElement(uO, d0(i.angle, i.cx, i.cy, n), /* @__PURE__ */ l.createElement(mO, {
    label: i.label
  }), i.children)));
};
function h0(e) {
  var r = V(e, $e);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(u0, {
    domain: r.domain,
    id: r.radiusAxisId,
    scale: r.scale,
    type: r.type,
    dataKey: r.dataKey,
    unit: void 0,
    name: r.name,
    allowDuplicatedCategory: r.allowDuplicatedCategory,
    allowDataOverflow: r.allowDataOverflow,
    reversed: r.reversed,
    includeHidden: r.includeHidden,
    allowDecimals: r.allowDecimals,
    ticks: r.ticks,
    tickCount: r.tickCount,
    tick: r.tick
  }), /* @__PURE__ */ l.createElement(m0, r));
}
h0.displayName = "PolarRadiusAxis";
var y0 = ["children"];
function Fr() {
  return Fr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Fr.apply(null, arguments);
}
function Zu(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Qe(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Zu(Object(t), !0).forEach(function(a) {
      g0(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Zu(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function g0(e, r, t) {
  return (r = b0(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function b0(e) {
  var r = x0(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function x0(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function P0(e, r) {
  if (e == null) return {};
  var t, a, n = O0(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function O0(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var qu = 1e-5, w0 = Math.cos(Va(45)), A0 = "angleAxis";
function E0(e) {
  var r = F(), t = l.useMemo(() => {
    var {
      children: i
    } = e, o = P0(e, y0);
    return o;
  }, [e]), a = k((i) => Yr(i, t.id)), n = t === a;
  return l.useEffect(() => (r(JO(t)), () => {
    r(QO(t));
  }), [r, t]), n ? e.children : null;
}
var j0 = (e, r) => {
  var {
    cx: t,
    cy: a,
    radius: n,
    orientation: i,
    tickSize: o
  } = r, u = o || 8, s = J(t, a, n, e.coordinate), c = J(t, a, n + (i === "inner" ? -1 : 1) * u, e.coordinate);
  return {
    x1: s.x,
    y1: s.y,
    x2: c.x,
    y2: c.y
  };
}, S0 = (e, r) => {
  var t = Math.cos(Va(-e.coordinate));
  return t > qu ? r === "outer" ? "start" : "end" : t < -qu ? r === "outer" ? "end" : "start" : "middle";
}, I0 = (e) => {
  var r = Math.cos(Va(-e.coordinate)), t = Math.sin(Va(-e.coordinate));
  return Math.abs(r) <= w0 ? t > 0 ? "start" : "end" : "middle";
}, k0 = (e) => {
  var {
    cx: r,
    cy: t,
    radius: a,
    axisLineType: n,
    axisLine: i,
    ticks: o
  } = e;
  if (!i)
    return null;
  var u = Qe(Qe({}, G(e)), {}, {
    fill: "none"
  }, G(i));
  if (n === "circle")
    return /* @__PURE__ */ l.createElement(zn, Fr({
      className: "recharts-polar-angle-axis-line"
    }, u, {
      cx: r,
      cy: t,
      r: a
    }));
  var s = o.map((c) => J(r, t, a, c.coordinate));
  return /* @__PURE__ */ l.createElement(Wo, Fr({
    className: "recharts-polar-angle-axis-line"
  }, u, {
    points: s
  }));
}, C0 = (e) => {
  var {
    tick: r,
    tickProps: t,
    value: a
  } = e;
  return r ? /* @__PURE__ */ l.isValidElement(r) ? /* @__PURE__ */ l.cloneElement(r, t) : typeof r == "function" ? r(t) : /* @__PURE__ */ l.createElement(Tr, Fr({}, t, {
    className: "recharts-polar-angle-axis-tick-value"
  }), a) : null;
}, D0 = (e) => {
  var {
    tick: r,
    tickLine: t,
    tickFormatter: a,
    stroke: n,
    ticks: i
  } = e, o = G(e), u = ze(r), s = Qe(Qe({}, o), {}, {
    fill: "none"
  }, G(t)), c = i.map((d, v) => {
    var f = j0(d, e), p = S0(d, e.orientation), m = I0(d), h = Qe(Qe(Qe({}, o), {}, {
      // @ts-expect-error customTickProps is contributing unknown props
      textAnchor: p,
      verticalAnchor: m,
      // @ts-expect-error customTickProps is contributing unknown props
      stroke: "none",
      // @ts-expect-error customTickProps is contributing unknown props
      fill: n
    }, u), {}, {
      index: v,
      payload: d,
      x: f.x2,
      y: f.y2
    });
    return /* @__PURE__ */ l.createElement(_, Fr({
      className: R("recharts-polar-angle-axis-tick", id(r)),
      key: "tick-".concat(d.coordinate)
    }, Ue(e, d, v)), t && /* @__PURE__ */ l.createElement("line", Fr({
      className: "recharts-polar-angle-axis-tick-line"
    }, s, f)), /* @__PURE__ */ l.createElement(C0, {
      tick: r,
      tickProps: h,
      value: a ? a(d.value, v) : d.value
    }));
  });
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-polar-angle-axis-ticks"
  }, c);
}, T0 = (e) => {
  var {
    angleAxisId: r
  } = e, t = k(Ur), a = k((u) => Nr(u, "angleAxis", r)), n = te(), i = k((u) => $O(u, "angleAxis", r, n));
  if (t == null || !i || !i.length || a == null)
    return null;
  var o = Qe(Qe(Qe({}, e), {}, {
    scale: a
  }, t), {}, {
    radius: t.outerRadius,
    ticks: i
  });
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: o.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-polar-angle-axis", A0, o.className)
  }, /* @__PURE__ */ l.createElement(k0, o), /* @__PURE__ */ l.createElement(D0, o)));
};
function $0(e) {
  var r = V(e, Je);
  return /* @__PURE__ */ l.createElement(E0, {
    id: r.angleAxisId,
    scale: r.scale,
    type: r.type,
    dataKey: r.dataKey,
    unit: void 0,
    name: r.name,
    allowDuplicatedCategory: !1,
    allowDataOverflow: !1,
    reversed: r.reversed,
    includeHidden: !1,
    allowDecimals: r.allowDecimals,
    tickCount: r.tickCount,
    ticks: r.ticks,
    tick: r.tick,
    domain: r.domain
  }, /* @__PURE__ */ l.createElement(T0, r));
}
$0.displayName = "PolarAngleAxis";
function Ju(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Qu(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ju(Object(t), !0).forEach(function(a) {
      L0(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ju(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function L0(e, r, t) {
  return (r = M0(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function M0(e) {
  var r = _0(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function _0(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var N0 = (e, r) => r, Vo = A([ha, N0], (e, r) => e.filter((t) => t.type === "pie").find((t) => t.id === r)), R0 = [], Go = (e, r, t) => (t == null ? void 0 : t.length) === 0 ? R0 : t, Vv = A([Lr, Vo, Go], (e, r, t) => {
  var {
    chartData: a
  } = e;
  if (r != null) {
    var n;
    if ((r == null ? void 0 : r.data) != null && r.data.length > 0 ? n = r.data : n = a, (!n || !n.length) && t != null && (n = t.map((i) => Qu(Qu({}, r.presentationProps), i.props))), n != null)
      return n;
  }
}), B0 = A([Vv, Vo, Go], (e, r, t) => {
  if (!(e == null || r == null))
    return e.map((a, n) => {
      var i, o = B(a, r.nameKey, r.name), u;
      return t != null && (i = t[n]) !== null && i !== void 0 && (i = i.props) !== null && i !== void 0 && i.fill ? u = t[n].props.fill : typeof a == "object" && a != null && "fill" in a ? u = a.fill : u = r.fill, {
        value: We(o, r.dataKey),
        color: u,
        // @ts-expect-error we need a better typing for our data inputs
        payload: a,
        type: r.legendType
      };
    });
}), K0 = A([Vv, Vo, Go, he], (e, r, t, a) => {
  if (!(r == null || e == null))
    return $w({
      offset: a,
      pieSettings: r,
      displayedData: e,
      cells: t
    });
}), es = (e) => typeof e == "string" ? e : e ? e.displayName || e.name || "Component" : "", rs = null, ai = null, Gv = (e) => {
  if (e === rs && Array.isArray(ai))
    return ai;
  var r = [];
  return l.Children.forEach(e, (t) => {
    U(t) || (Lp.isFragment(t) ? r = r.concat(Gv(t.props.children)) : r.push(t));
  }), ai = r, rs = e, r;
};
function St(e, r) {
  var t = [], a = [];
  return Array.isArray(r) ? a = r.map((n) => es(n)) : a = [es(r)], Gv(e).forEach((n) => {
    var i = tr(n, "type.displayName") || tr(n, "type.name");
    i && a.indexOf(i) !== -1 && t.push(n);
  }), t;
}
var Ho = (e) => e && typeof e == "object" && "clipDot" in e ? !!e.clipDot : !0, ts, as, ns, is, os;
function ls(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function us(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ls(Object(t), !0).forEach(function(a) {
      z0(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ls(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function z0(e, r, t) {
  return (r = W0(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function W0(e) {
  var r = F0(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function F0(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function qa() {
  return qa = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, qa.apply(null, arguments);
}
function _t(e, r) {
  return r || (r = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(r) } }));
}
var ss = (e, r, t, a, n) => {
  var i = t - a, o;
  return o = ue(ts || (ts = _t(["M ", ",", ""])), e, r), o += ue(as || (as = _t(["L ", ",", ""])), e + t, r), o += ue(ns || (ns = _t(["L ", ",", ""])), e + t - i / 2, r + n), o += ue(is || (is = _t(["L ", ",", ""])), e + t - i / 2 - a, r + n), o += ue(os || (os = _t(["L ", ",", " Z"])), e, r), o;
}, X0 = {
  x: 0,
  y: 0,
  upperWidth: 0,
  lowerWidth: 0,
  height: 0,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, V0 = (e) => {
  var r = V(e, X0), {
    x: t,
    y: a,
    upperWidth: n,
    lowerWidth: i,
    height: o,
    className: u
  } = r, {
    animationEasing: s,
    animationDuration: c,
    animationBegin: d,
    isUpdateAnimationActive: v
  } = r, f = l.useRef(null), [p, m] = l.useState(-1), h = l.useRef(n), g = l.useRef(i), y = l.useRef(o), b = l.useRef(t), x = l.useRef(a), O = or(e, "trapezoid-");
  if (l.useEffect(() => {
    if (f.current && f.current.getTotalLength)
      try {
        var T = f.current.getTotalLength();
        T && m(T);
      } catch {
      }
  }, []), t !== +t || a !== +a || n !== +n || i !== +i || o !== +o || n === 0 && i === 0 || o === 0)
    return null;
  var P = R("recharts-trapezoid", u);
  if (!v)
    return /* @__PURE__ */ l.createElement("g", null, /* @__PURE__ */ l.createElement("path", qa({}, le(r), {
      className: P,
      d: ss(t, a, n, i, o)
    })));
  var w = h.current, E = g.current, j = y.current, S = b.current, I = x.current, D = "0px ".concat(p === -1 ? 1 : p, "px"), C = "".concat(p, "px 0px"), M = ao(["strokeDasharray"], c, s);
  return /* @__PURE__ */ l.createElement(ir, {
    animationId: O,
    key: O,
    canBegin: p > 0,
    duration: c,
    easing: s,
    isActive: v,
    begin: d
  }, (T) => {
    var $ = N(w, n, T), W = N(E, i, T), X = N(j, o, T), Z = N(S, t, T), z = N(I, a, T);
    f.current && (h.current = $, g.current = W, y.current = X, b.current = Z, x.current = z);
    var ne = T > 0 ? {
      transition: M,
      strokeDasharray: C
    } : {
      strokeDasharray: D
    };
    return /* @__PURE__ */ l.createElement("path", qa({}, le(r), {
      className: P,
      d: ss(Z, z, $, W, X),
      ref: f,
      style: us(us({}, ne), r.style)
    }));
  });
}, G0 = ["option", "shapeType", "activeClassName"];
function H0(e, r) {
  if (e == null) return {};
  var t, a, n = Y0(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function Y0(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function cs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ja(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? cs(Object(t), !0).forEach(function(a) {
      U0(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : cs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function U0(e, r, t) {
  return (r = Z0(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Z0(e) {
  var r = q0(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function q0(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function J0(e, r) {
  return Ja(Ja({}, r), e);
}
function Q0(e, r) {
  return e === "symbols";
}
function ds(e) {
  var {
    shapeType: r,
    elementProps: t
  } = e;
  switch (r) {
    case "rectangle":
      return /* @__PURE__ */ l.createElement(oa, t);
    case "trapezoid":
      return /* @__PURE__ */ l.createElement(V0, t);
    case "sector":
      return /* @__PURE__ */ l.createElement(ud, t);
    case "symbols":
      if (Q0(r))
        return /* @__PURE__ */ l.createElement(yn, t);
      break;
    case "curve":
      return /* @__PURE__ */ l.createElement(zr, t);
    default:
      return null;
  }
}
function ew(e) {
  return /* @__PURE__ */ l.isValidElement(e) ? e.props : e;
}
function Xr(e) {
  var {
    option: r,
    shapeType: t,
    activeClassName: a = "recharts-active-shape"
  } = e, n = H0(e, G0), i;
  if (/* @__PURE__ */ l.isValidElement(r))
    i = /* @__PURE__ */ l.cloneElement(r, Ja(Ja({}, n), ew(r)));
  else if (typeof r == "function")
    i = r(n, n.index);
  else if (Mp(r) && typeof r != "boolean") {
    var o = J0(r, n);
    i = /* @__PURE__ */ l.createElement(ds, {
      shapeType: t,
      elementProps: o
    });
  } else {
    var u = n;
    i = /* @__PURE__ */ l.createElement(ds, {
      shapeType: t,
      elementProps: u
    });
  }
  return n.isActive ? /* @__PURE__ */ l.createElement(_, {
    className: a
  }, i) : i;
}
var It = (e, r, t) => {
  var a = F();
  return (n, i) => (o) => {
    e == null || e(n, i, o), a(Ot({
      activeIndex: String(i),
      activeDataKey: r,
      activeCoordinate: n.tooltipPosition,
      activeGraphicalItemId: t
    }));
  };
}, kt = (e) => {
  var r = F();
  return (t, a) => (n) => {
    e == null || e(t, a, n), r(Do());
  };
}, Ct = (e, r, t) => {
  var a = F();
  return (n, i) => (o) => {
    e == null || e(n, i, o), a(_n({
      activeIndex: String(i),
      activeDataKey: r,
      activeCoordinate: n.tooltipPosition,
      activeGraphicalItemId: t
    }));
  };
};
function cr(e) {
  var {
    tooltipEntrySettings: r
  } = e, t = F(), a = te(), n = l.useRef(null);
  return l.useLayoutEffect(() => {
    a || (n.current === null ? t(Pb(r)) : n.current !== r && t(Ob({
      prev: n.current,
      next: r
    })), n.current = r);
  }, [r, t, a]), l.useLayoutEffect(() => () => {
    n.current && (t(wb(n.current)), n.current = null);
  }, [t]), null;
}
function Fn(e) {
  var {
    legendPayload: r
  } = e, t = F(), a = te(), n = l.useRef(null);
  return l.useLayoutEffect(() => {
    a || (n.current === null ? t(Zc(r)) : n.current !== r && t(qc({
      prev: n.current,
      next: r
    })), n.current = r);
  }, [t, a, r]), l.useLayoutEffect(() => () => {
    n.current && (t(Jc(n.current)), n.current = null);
  }, [t]), null;
}
function Yo(e) {
  var {
    legendPayload: r
  } = e, t = F(), a = k(K), n = l.useRef(null);
  return l.useLayoutEffect(() => {
    a !== "centric" && a !== "radial" || (n.current === null ? t(Zc(r)) : n.current !== r && t(qc({
      prev: n.current,
      next: r
    })), n.current = r);
  }, [t, a, r]), l.useLayoutEffect(() => () => {
    n.current && (t(Jc(n.current)), n.current = null);
  }, [t]), null;
}
var ni, rw = () => {
  var [e] = l.useState(() => it("uid-"));
  return e;
}, tw = (ni = _p.useId) !== null && ni !== void 0 ? ni : rw;
function aw(e, r) {
  var t = tw();
  return r || (e ? "".concat(e, "-").concat(t) : t);
}
var Hv = /* @__PURE__ */ l.createContext(void 0), dr = (e) => {
  var {
    id: r,
    type: t,
    children: a
  } = e, n = aw("recharts-".concat(t), r);
  return /* @__PURE__ */ l.createElement(Hv.Provider, {
    value: n
  }, a(n));
};
function nw() {
  return l.useContext(Hv);
}
var iw = {
  cartesianItems: [],
  polarItems: []
}, Yv = Be({
  name: "graphicalItems",
  initialState: iw,
  reducers: {
    addCartesianGraphicalItem: {
      reducer(e, r) {
        e.cartesianItems.push(re(r.payload));
      },
      prepare: oe()
    },
    replaceCartesianGraphicalItem: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload, n = er(e).cartesianItems.indexOf(re(t));
        n > -1 && (e.cartesianItems[n] = re(a));
      },
      prepare: oe()
    },
    removeCartesianGraphicalItem: {
      reducer(e, r) {
        var t = er(e).cartesianItems.indexOf(re(r.payload));
        t > -1 && e.cartesianItems.splice(t, 1);
      },
      prepare: oe()
    },
    addPolarGraphicalItem: {
      reducer(e, r) {
        e.polarItems.push(re(r.payload));
      },
      prepare: oe()
    },
    removePolarGraphicalItem: {
      reducer(e, r) {
        var t = er(e).polarItems.indexOf(re(r.payload));
        t > -1 && e.polarItems.splice(t, 1);
      },
      prepare: oe()
    }
  }
}), {
  addCartesianGraphicalItem: ow,
  replaceCartesianGraphicalItem: lw,
  removeCartesianGraphicalItem: uw,
  addPolarGraphicalItem: sw,
  removePolarGraphicalItem: cw
} = Yv.actions, dw = Yv.reducer, vw = (e) => {
  var r = F(), t = l.useRef(null);
  return l.useLayoutEffect(() => {
    t.current === null ? r(ow(e)) : t.current !== e && r(lw({
      prev: t.current,
      next: e
    })), t.current = e;
  }, [r, e]), l.useLayoutEffect(() => () => {
    t.current && (r(uw(t.current)), t.current = null);
  }, [r]), null;
}, Xn = /* @__PURE__ */ l.memo(vw);
function Uo(e) {
  var r = F();
  return l.useLayoutEffect(() => (r(sw(e)), () => {
    r(cw(e));
  }), [r, e]), null;
}
var fw = ["key"], pw = ["onMouseEnter", "onClick", "onMouseLeave"], mw = ["id"], hw = ["id"];
function vs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function de(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? vs(Object(t), !0).forEach(function(a) {
      yw(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : vs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function yw(e, r, t) {
  return (r = gw(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function gw(e) {
  var r = bw(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function bw(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function $r() {
  return $r = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, $r.apply(null, arguments);
}
function Vn(e, r) {
  if (e == null) return {};
  var t, a, n = xw(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function xw(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Pw(e) {
  var r = l.useMemo(() => St(e.children, Zr), [e.children]), t = k((a) => B0(a, e.id, r));
  return t == null ? null : /* @__PURE__ */ l.createElement(Yo, {
    legendPayload: t
  });
}
var Ow = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    nameKey: t,
    sectors: a,
    stroke: n,
    strokeWidth: i,
    fill: o,
    name: u,
    hide: s,
    tooltipType: c,
    id: d
  } = e, v = {
    dataDefinedOnItem: a.map((f) => f.tooltipPayload),
    positions: a.map((f) => f.tooltipPosition),
    settings: {
      stroke: n,
      strokeWidth: i,
      fill: o,
      dataKey: r,
      nameKey: t,
      name: We(u, r),
      hide: s,
      type: c,
      color: o,
      unit: "",
      // why doesn't Pie support unit?
      graphicalItemId: d
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: v
  });
}), ww = (e, r) => e > r ? "start" : e < r ? "end" : "middle", Aw = (e, r, t) => Ee(typeof r == "function" ? r(e) : r, t, t * 0.8), Ew = (e, r, t) => {
  var {
    top: a,
    left: n,
    width: i,
    height: o
  } = r, u = nd(i, o), s = n + Ee(e.cx, i, i / 2), c = a + Ee(e.cy, o, o / 2), d = Ee(e.innerRadius, u, 0), v = Aw(t, e.outerRadius, u), f = e.maxRadius || Math.sqrt(i * i + o * o) / 2;
  return {
    cx: s,
    cy: c,
    innerRadius: d,
    outerRadius: v,
    maxRadius: f
  };
}, jw = (e, r) => {
  var t = me(r - e), a = Math.min(Math.abs(r - e), 360);
  return t * a;
};
function Sw(e) {
  return e && typeof e == "object" && "className" in e && typeof e.className == "string" ? e.className : "";
}
var Iw = (e, r) => {
  if (/* @__PURE__ */ l.isValidElement(e))
    return /* @__PURE__ */ l.cloneElement(e, r);
  if (typeof e == "function")
    return e(r);
  var t = R("recharts-pie-label-line", typeof e != "boolean" ? e.className : ""), {
    key: a
  } = r, n = Vn(r, fw);
  return /* @__PURE__ */ l.createElement(zr, $r({}, n, {
    type: "linear",
    className: t
  }));
}, kw = (e, r, t) => {
  if (/* @__PURE__ */ l.isValidElement(e))
    return /* @__PURE__ */ l.cloneElement(e, r);
  var a = t;
  if (typeof e == "function" && (a = e(r), /* @__PURE__ */ l.isValidElement(a)))
    return a;
  var n = R("recharts-pie-label-text", Sw(e));
  return /* @__PURE__ */ l.createElement(Tr, $r({}, r, {
    alignmentBaseline: "middle",
    className: n
  }), a);
};
function Cw(e) {
  var {
    sectors: r,
    props: t,
    showLabels: a
  } = e, {
    label: n,
    labelLine: i,
    dataKey: o
  } = t;
  if (!a || !n || !r)
    return null;
  var u = G(t), s = ze(n), c = ze(i), d = typeof n == "object" && "offsetRadius" in n && typeof n.offsetRadius == "number" && n.offsetRadius || 20, v = r.map((f, p) => {
    var m = (f.startAngle + f.endAngle) / 2, h = J(f.cx, f.cy, f.outerRadius + d, m), g = de(de(de(de({}, u), f), {}, {
      // @ts-expect-error customLabelProps is contributing unknown props
      stroke: "none"
    }, s), {}, {
      index: p,
      textAnchor: ww(h.x, f.cx)
    }, h), y = de(de(de(de({}, u), f), {}, {
      // @ts-expect-error customLabelLineProps is contributing unknown props
      fill: "none",
      // @ts-expect-error customLabelLineProps is contributing unknown props
      stroke: f.fill
    }, c), {}, {
      index: p,
      points: [J(f.cx, f.cy, f.outerRadius, m), h],
      key: "line"
    });
    return /* @__PURE__ */ l.createElement(ee, {
      zIndex: Y.label,
      key: "label-".concat(f.startAngle, "-").concat(f.endAngle, "-").concat(f.midAngle, "-").concat(p)
    }, /* @__PURE__ */ l.createElement(_, null, i && Iw(i, y), kw(n, g, B(f, o))));
  });
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-pie-labels"
  }, v);
}
function Dw(e) {
  var {
    sectors: r,
    props: t,
    showLabels: a
  } = e, {
    label: n
  } = t;
  return typeof n == "object" && n != null && "position" in n ? /* @__PURE__ */ l.createElement(_r, {
    label: n
  }) : /* @__PURE__ */ l.createElement(Cw, {
    sectors: r,
    props: t,
    showLabels: a
  });
}
function Tw(e) {
  var {
    sectors: r,
    activeShape: t,
    inactiveShape: a,
    allOtherPieProps: n,
    shape: i,
    id: o
  } = e, u = k(nr), s = k(No), c = k(sx), {
    onMouseEnter: d,
    onClick: v,
    onMouseLeave: f
  } = n, p = Vn(n, pw), m = It(d, n.dataKey, o), h = kt(f), g = Ct(v, n.dataKey, o);
  return r == null || r.length === 0 ? null : /* @__PURE__ */ l.createElement(l.Fragment, null, r.map((y, b) => {
    if ((y == null ? void 0 : y.startAngle) === 0 && (y == null ? void 0 : y.endAngle) === 0 && r.length !== 1) return null;
    var x = c == null || c === o, O = String(b) === u && (s == null || n.dataKey === s) && x, P = u ? a : null, w = t && O ? t : P, E = de(de({}, y), {}, {
      stroke: y.stroke,
      tabIndex: -1,
      [Qi]: b,
      [eo]: o
    });
    return /* @__PURE__ */ l.createElement(_, $r({
      key: "sector-".concat(y == null ? void 0 : y.startAngle, "-").concat(y == null ? void 0 : y.endAngle, "-").concat(y.midAngle, "-").concat(b),
      tabIndex: -1,
      className: "recharts-pie-sector"
    }, Ue(p, y, b), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: m(y, b),
      onMouseLeave: h(y, b),
      onClick: g(y, b)
    }), /* @__PURE__ */ l.createElement(Xr, $r({
      option: i ?? w,
      index: b,
      shapeType: "sector",
      isActive: O
    }, E)));
  }));
}
function $w(e) {
  var r, {
    pieSettings: t,
    displayedData: a,
    cells: n,
    offset: i
  } = e, {
    cornerRadius: o,
    startAngle: u,
    endAngle: s,
    dataKey: c,
    nameKey: d,
    tooltipType: v
  } = t, f = Math.abs(t.minAngle), p = jw(u, s), m = Math.abs(p), h = a.length <= 1 ? 0 : (r = t.paddingAngle) !== null && r !== void 0 ? r : 0, g = a.filter((w) => B(w, c, 0) !== 0).length, y = (m >= 360 ? g : g - 1) * h, b = m - g * f - y, x = a.reduce((w, E) => {
    var j = B(E, c, 0);
    return w + (L(j) ? j : 0);
  }, 0), O;
  if (x > 0) {
    var P;
    O = a.map((w, E) => {
      var j = B(w, c, 0), S = B(w, d, E), I = Ew(t, i, w), D = (L(j) ? j : 0) / x, C, M = de(de({}, w), n && n[E] && n[E].props);
      E ? C = P.endAngle + me(p) * h * (j !== 0 ? 1 : 0) : C = u;
      var T = C + me(p) * ((j !== 0 ? f : 0) + D * b), $ = (C + T) / 2, W = (I.innerRadius + I.outerRadius) / 2, X = [{
        name: S,
        value: j,
        payload: M,
        dataKey: c,
        type: v,
        graphicalItemId: t.id
      }], Z = J(I.cx, I.cy, W, $);
      return P = de(de(de(de({}, t.presentationProps), {}, {
        percent: D,
        cornerRadius: typeof o == "string" ? parseFloat(o) : o,
        name: S,
        tooltipPayload: X,
        midAngle: $,
        middleRadius: W,
        tooltipPosition: Z
      }, M), I), {}, {
        value: j,
        dataKey: c,
        startAngle: C,
        endAngle: T,
        payload: M,
        paddingAngle: me(p) * h
      }), P;
    });
  }
  return O;
}
function Lw(e) {
  var {
    showLabels: r,
    sectors: t,
    children: a
  } = e, n = l.useMemo(() => !r || !t ? [] : t.map((i) => ({
    value: i.value,
    payload: i.payload,
    clockWise: !1,
    parentViewBox: void 0,
    viewBox: {
      cx: i.cx,
      cy: i.cy,
      innerRadius: i.innerRadius,
      outerRadius: i.outerRadius,
      startAngle: i.startAngle,
      endAngle: i.endAngle,
      clockWise: !1
    },
    fill: i.fill
  })), [t, r]);
  return /* @__PURE__ */ l.createElement(Rv, {
    value: r ? n : void 0
  }, a);
}
function Mw(e) {
  var {
    props: r,
    previousSectorsRef: t,
    id: a
  } = e, {
    sectors: n,
    isAnimationActive: i,
    animationBegin: o,
    animationDuration: u,
    animationEasing: s,
    activeShape: c,
    inactiveShape: d,
    onAnimationStart: v,
    onAnimationEnd: f
  } = r, p = or(r, "recharts-pie-"), m = t.current, [h, g] = l.useState(!1), y = l.useCallback(() => {
    typeof f == "function" && f(), g(!1);
  }, [f]), b = l.useCallback(() => {
    typeof v == "function" && v(), g(!0);
  }, [v]);
  return /* @__PURE__ */ l.createElement(Lw, {
    showLabels: !h,
    sectors: n
  }, /* @__PURE__ */ l.createElement(ir, {
    animationId: p,
    begin: o,
    duration: u,
    isActive: i,
    easing: s,
    onAnimationStart: b,
    onAnimationEnd: y,
    key: p
  }, (x) => {
    var O = [], P = n && n[0], w = P == null ? void 0 : P.startAngle;
    return n == null || n.forEach((E, j) => {
      var S = m && m[j], I = j > 0 ? tr(E, "paddingAngle", 0) : 0;
      if (S) {
        var D = N(S.endAngle - S.startAngle, E.endAngle - E.startAngle, x), C = de(de({}, E), {}, {
          startAngle: w + I,
          endAngle: w + D + I
        });
        O.push(C), w = C.endAngle;
      } else {
        var {
          endAngle: M,
          startAngle: T
        } = E, $ = N(0, M - T, x), W = de(de({}, E), {}, {
          startAngle: w + I,
          endAngle: w + $ + I
        });
        O.push(W), w = W.endAngle;
      }
    }), t.current = O, /* @__PURE__ */ l.createElement(_, null, /* @__PURE__ */ l.createElement(Tw, {
      sectors: O,
      activeShape: c,
      inactiveShape: d,
      allOtherPieProps: r,
      shape: r.shape,
      id: a
    }));
  }), /* @__PURE__ */ l.createElement(Dw, {
    showLabels: !h,
    sectors: n,
    props: r
  }), r.children);
}
var _w = {
  animationBegin: 400,
  animationDuration: 1500,
  animationEasing: "ease",
  cx: "50%",
  cy: "50%",
  dataKey: "value",
  endAngle: 360,
  fill: "#808080",
  hide: !1,
  innerRadius: 0,
  isAnimationActive: "auto",
  label: !1,
  labelLine: !0,
  legendType: "rect",
  minAngle: 0,
  nameKey: "name",
  outerRadius: "80%",
  paddingAngle: 0,
  rootTabIndex: 0,
  startAngle: 0,
  stroke: "#fff",
  zIndex: Y.area
};
function Nw(e) {
  var {
    id: r
  } = e, t = Vn(e, mw), {
    hide: a,
    className: n,
    rootTabIndex: i
  } = e, o = l.useMemo(() => St(e.children, Zr), [e.children]), u = k((d) => K0(d, r, o)), s = l.useRef(null), c = R("recharts-pie", n);
  return a || u == null ? (s.current = null, /* @__PURE__ */ l.createElement(_, {
    tabIndex: i,
    className: c
  })) : /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(Ow, {
    dataKey: e.dataKey,
    nameKey: e.nameKey,
    sectors: u,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    id: r
  }), /* @__PURE__ */ l.createElement(_, {
    tabIndex: i,
    className: c
  }, /* @__PURE__ */ l.createElement(Mw, {
    props: de(de({}, t), {}, {
      sectors: u
    }),
    previousSectorsRef: s,
    id: r
  })));
}
function Rw(e) {
  var r = V(e, _w), {
    id: t
  } = r, a = Vn(r, hw), n = G(a);
  return /* @__PURE__ */ l.createElement(dr, {
    id: t,
    type: "pie"
  }, (i) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Uo, {
    type: "pie",
    id: i,
    data: a.data,
    dataKey: a.dataKey,
    hide: a.hide,
    angleAxisId: 0,
    radiusAxisId: 0,
    name: a.name,
    nameKey: a.nameKey,
    tooltipType: a.tooltipType,
    legendType: a.legendType,
    fill: a.fill,
    cx: a.cx,
    cy: a.cy,
    startAngle: a.startAngle,
    endAngle: a.endAngle,
    paddingAngle: a.paddingAngle,
    minAngle: a.minAngle,
    innerRadius: a.innerRadius,
    outerRadius: a.outerRadius,
    cornerRadius: a.cornerRadius,
    presentationProps: n,
    maxRadius: r.maxRadius
  }), /* @__PURE__ */ l.createElement(Pw, $r({}, a, {
    id: i
  })), /* @__PURE__ */ l.createElement(Nw, $r({}, a, {
    id: i
  }))));
}
Rw.displayName = "Pie";
var Bw = ["points"];
function fs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ii(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? fs(Object(t), !0).forEach(function(a) {
      Kw(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : fs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Kw(e, r, t) {
  return (r = zw(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function zw(e) {
  var r = Ww(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Ww(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Qa() {
  return Qa = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Qa.apply(null, arguments);
}
function Fw(e, r) {
  if (e == null) return {};
  var t, a, n = Xw(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function Xw(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Vw(e) {
  var {
    option: r,
    dotProps: t,
    className: a
  } = e;
  if (/* @__PURE__ */ l.isValidElement(r))
    return /* @__PURE__ */ l.cloneElement(r, t);
  if (typeof r == "function")
    return r(t);
  var n = R(a, typeof r != "boolean" ? r.className : ""), i = t ?? {}, {
    points: o
  } = i, u = Fw(i, Bw);
  return /* @__PURE__ */ l.createElement(zn, Qa({}, u, {
    className: n
  }));
}
function Gw(e, r) {
  return e == null ? !1 : r ? !0 : e.length === 1;
}
function Zo(e) {
  var {
    points: r,
    dot: t,
    className: a,
    dotClassName: n,
    dataKey: i,
    baseProps: o,
    needClip: u,
    clipPathId: s,
    zIndex: c = Y.scatter
  } = e;
  if (!Gw(r, t))
    return null;
  var d = Ho(t), v = Yp(t), f = r.map((m, h) => {
    var g, y, b = ii(ii(ii({
      r: 3
    }, o), v), {}, {
      index: h,
      cx: (g = m.x) !== null && g !== void 0 ? g : void 0,
      cy: (y = m.y) !== null && y !== void 0 ? y : void 0,
      dataKey: i,
      value: m.value,
      payload: m.payload,
      points: r
    });
    return /* @__PURE__ */ l.createElement(Vw, {
      key: "dot-".concat(h),
      option: t,
      dotProps: b,
      className: n
    });
  }), p = {};
  return u && s != null && (p.clipPath = "url(#clipPath-".concat(d ? "" : "dots-").concat(s, ")")), /* @__PURE__ */ l.createElement(ee, {
    zIndex: c
  }, /* @__PURE__ */ l.createElement(_, Qa({
    className: a
  }, p), f));
}
function ps(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ms(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ps(Object(t), !0).forEach(function(a) {
      Hw(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ps(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Hw(e, r, t) {
  return (r = Yw(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Yw(e) {
  var r = Uw(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Uw(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var Uv = 0, Zw = {
  xAxis: {},
  yAxis: {},
  zAxis: {}
}, Zv = Be({
  name: "cartesianAxis",
  initialState: Zw,
  reducers: {
    addXAxis: {
      reducer(e, r) {
        e.xAxis[r.payload.id] = re(r.payload);
      },
      prepare: oe()
    },
    replaceXAxis: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload;
        e.xAxis[t.id] !== void 0 && (t.id !== a.id && delete e.xAxis[t.id], e.xAxis[a.id] = re(a));
      },
      prepare: oe()
    },
    removeXAxis: {
      reducer(e, r) {
        delete e.xAxis[r.payload.id];
      },
      prepare: oe()
    },
    addYAxis: {
      reducer(e, r) {
        e.yAxis[r.payload.id] = re(r.payload);
      },
      prepare: oe()
    },
    replaceYAxis: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload;
        e.yAxis[t.id] !== void 0 && (t.id !== a.id && delete e.yAxis[t.id], e.yAxis[a.id] = re(a));
      },
      prepare: oe()
    },
    removeYAxis: {
      reducer(e, r) {
        delete e.yAxis[r.payload.id];
      },
      prepare: oe()
    },
    addZAxis: {
      reducer(e, r) {
        e.zAxis[r.payload.id] = re(r.payload);
      },
      prepare: oe()
    },
    replaceZAxis: {
      reducer(e, r) {
        var {
          prev: t,
          next: a
        } = r.payload;
        e.zAxis[t.id] !== void 0 && (t.id !== a.id && delete e.zAxis[t.id], e.zAxis[a.id] = re(a));
      },
      prepare: oe()
    },
    removeZAxis: {
      reducer(e, r) {
        delete e.zAxis[r.payload.id];
      },
      prepare: oe()
    },
    updateYAxisWidth(e, r) {
      var {
        id: t,
        width: a
      } = r.payload, n = e.yAxis[t];
      if (n) {
        var i = n.widthHistory || [];
        if (i.length === 3 && i[0] === i[2] && a === i[1] && a !== n.width && Math.abs(a - i[0]) <= 1)
          return;
        var o = [...i, a].slice(-3);
        e.yAxis[t] = ms(ms({}, e.yAxis[t]), {}, {
          width: a,
          widthHistory: o
        });
      }
    }
  }
}), {
  addXAxis: qw,
  replaceXAxis: Jw,
  removeXAxis: Qw,
  addYAxis: eA,
  replaceYAxis: rA,
  removeYAxis: tA,
  addZAxis: aA,
  replaceZAxis: nA,
  removeZAxis: iA,
  updateYAxisWidth: oA
} = Zv.actions, lA = Zv.reducer, uA = A([he], (e) => ({
  top: e.top,
  bottom: e.bottom,
  left: e.left,
  right: e.right
})), sA = A([uA, wr, Ar], (e, r, t) => {
  if (!(!e || r == null || t == null))
    return {
      x: e.left,
      y: e.top,
      width: Math.max(0, r - e.left - e.right),
      height: Math.max(0, t - e.top - e.bottom)
    };
}), cA = (e) => {
  var r = te();
  return k((t) => Re(t, "xAxis", e, r));
}, dA = (e) => {
  var r = te();
  return k((t) => Re(t, "yAxis", e, r));
}, ga = () => k(sA), vA = () => k(px);
function hs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function oi(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? hs(Object(t), !0).forEach(function(a) {
      fA(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : hs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function fA(e, r, t) {
  return (r = pA(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function pA(e) {
  var r = mA(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function mA(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var hA = (e) => {
  var {
    point: r,
    childIndex: t,
    mainColor: a,
    activeDot: n,
    dataKey: i,
    clipPath: o
  } = e;
  if (n === !1 || r.x == null || r.y == null)
    return null;
  var u = {
    index: t,
    dataKey: i,
    cx: r.x,
    cy: r.y,
    r: 4,
    fill: a ?? "none",
    strokeWidth: 2,
    stroke: "#fff",
    payload: r.payload,
    value: r.value
  }, s = oi(oi(oi({}, u), ze(n)), qi(n)), c;
  return /* @__PURE__ */ l.isValidElement(n) ? c = /* @__PURE__ */ l.cloneElement(n, s) : typeof n == "function" ? c = n(s) : c = /* @__PURE__ */ l.createElement(zn, s), /* @__PURE__ */ l.createElement(_, {
    className: "recharts-active-dot",
    clipPath: o
  }, c);
};
function en(e) {
  var {
    points: r,
    mainColor: t,
    activeDot: a,
    itemDataKey: n,
    clipPath: i,
    zIndex: o = Y.activeDot
  } = e, u = k(nr), s = vA();
  if (r == null || s == null)
    return null;
  var c = r.find((d) => s.includes(d.payload));
  return U(c) ? null : /* @__PURE__ */ l.createElement(ee, {
    zIndex: o
  }, /* @__PURE__ */ l.createElement(hA, {
    point: c,
    childIndex: Number(u),
    mainColor: t,
    dataKey: n,
    activeDot: a,
    clipPath: i
  }));
}
function ys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function rn(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ys(Object(t), !0).forEach(function(a) {
      yA(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ys(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function yA(e, r, t) {
  return (r = gA(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function gA(e) {
  var r = bA(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function bA(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var qv = (e, r) => Nr(e, "radiusAxis", r), xA = A([qv], (e) => {
  if (e != null)
    return {
      scale: e
    };
}), PA = A([yt, qv], (e, r) => {
  if (!(e == null || r == null))
    return rn(rn({}, e), {}, {
      scale: r
    });
}), OA = (e, r, t, a) => qr(e, "radiusAxis", r, a), Jv = (e, r, t) => Yr(e, t), Qv = (e, r, t) => Nr(e, "angleAxis", t), wA = A([Jv, Qv], (e, r) => {
  if (!(e == null || r == null))
    return rn(rn({}, e), {}, {
      scale: r
    });
}), AA = (e, r, t, a) => qr(e, "angleAxis", t, a), EA = A([Jv, Qv, Ur], (e, r, t) => {
  if (!(t == null || r == null))
    return {
      scale: r,
      type: e.type,
      dataKey: e.dataKey,
      cx: t.cx,
      cy: t.cy
    };
}), jA = (e, r, t, a, n) => n, SA = A([K, PA, OA, wA, AA], (e, r, t, a, n) => He(e, "radiusAxis") ? Ne(r, t, !1) : Ne(a, n, !1)), IA = A([ha, jA], (e, r) => {
  if (e != null) {
    var t = e.find((a) => a.type === "radar" && r === a.id);
    return t == null ? void 0 : t.dataKey;
  }
}), kA = A([xA, EA, Lr, IA, SA], (e, r, t, a, n) => {
  var {
    chartData: i,
    dataStartIndex: o,
    dataEndIndex: u
  } = t;
  if (!(e == null || r == null || i == null || n == null || a == null)) {
    var s = i.slice(o, u + 1);
    return BA({
      radiusAxis: e,
      angleAxis: r,
      displayedData: s,
      dataKey: a,
      bandSize: n
    });
  }
}), CA = ["id"];
function Vt() {
  return Vt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Vt.apply(null, arguments);
}
function gs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Le(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? gs(Object(t), !0).forEach(function(a) {
      DA(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : gs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function DA(e, r, t) {
  return (r = TA(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function TA(e) {
  var r = $A(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function $A(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function LA(e, r) {
  if (e == null) return {};
  var t, a, n = MA(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function MA(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function qo(e, r) {
  return e && e !== "none" ? e : r;
}
var _A = (e) => {
  var {
    dataKey: r,
    name: t,
    stroke: a,
    fill: n,
    legendType: i,
    hide: o
  } = e;
  return [{
    inactive: o,
    dataKey: r,
    type: i,
    color: qo(a, n),
    value: We(t, r),
    payload: e
  }];
}, NA = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    stroke: t,
    strokeWidth: a,
    fill: n,
    name: i,
    hide: o,
    tooltipType: u,
    id: s
  } = e, c = {
    /*
     * I suppose this here _could_ return props.points
     * because while Radar does not support item tooltip mode, it _could_ support it.
     * But when I actually do return the points here, a defaultIndex test starts failing.
     * So, undefined it is.
     */
    dataDefinedOnItem: void 0,
    positions: void 0,
    settings: {
      stroke: t,
      strokeWidth: a,
      fill: n,
      nameKey: void 0,
      // RadarChart does not have nameKey unfortunately
      dataKey: r,
      name: We(i, r),
      hide: o,
      type: u,
      color: qo(t, n),
      unit: "",
      // why doesn't Radar support unit?
      graphicalItemId: s
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: c
  });
});
function RA(e) {
  var {
    points: r,
    props: t
  } = e, {
    dot: a,
    dataKey: n
  } = t, {
    id: i
  } = t, o = LA(t, CA), u = G(o);
  return /* @__PURE__ */ l.createElement(Zo, {
    points: r,
    dot: a,
    className: "recharts-radar-dots",
    dotClassName: "recharts-radar-dot",
    dataKey: n,
    baseProps: u
  });
}
function BA(e) {
  var {
    radiusAxis: r,
    angleAxis: t,
    displayedData: a,
    dataKey: n,
    bandSize: i
  } = e, {
    cx: o,
    cy: u
  } = t, s = !1, c = [], d = t.type !== "number" ? i ?? 0 : 0;
  a.forEach((f, p) => {
    var m = B(f, t.dataKey, p), h = B(f, n), g = t.scale(m) + d, y = Array.isArray(h) ? Pc(h) : h, b = U(y) ? 0 : r.scale(y);
    Array.isArray(h) && h.length >= 2 && (s = !0), c.push(Le(Le({}, J(o, u, b, g)), {}, {
      // @ts-expect-error getValueByDataKey does not validate the output type
      name: m,
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: h,
      cx: o,
      cy: u,
      radius: b,
      angle: g,
      payload: f
    }));
  });
  var v = [];
  return s && c.forEach((f) => {
    if (Array.isArray(f.value)) {
      var p = f.value[0], m = U(p) ? 0 : r.scale(p);
      v.push(Le(Le({}, f), {}, {
        radius: m
      }, J(o, u, m, f.angle)));
    } else
      v.push(f);
  }), {
    points: c,
    isRange: s,
    baseLinePoints: v
  };
}
function KA(e) {
  var {
    showLabels: r,
    points: t,
    children: a
  } = e, n = t.map((i) => {
    var o, u = {
      x: i.x,
      y: i.y,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return Le(Le({}, u), {}, {
      value: (o = i.value) !== null && o !== void 0 ? o : "",
      payload: i.payload,
      parentViewBox: void 0,
      viewBox: u,
      fill: void 0
    });
  });
  return /* @__PURE__ */ l.createElement(jt, {
    value: r ? n : void 0
  }, a);
}
function zA(e) {
  var {
    points: r,
    baseLinePoints: t,
    props: a
  } = e;
  if (r == null)
    return null;
  var {
    shape: n,
    isRange: i,
    connectNulls: o
  } = a, u = (d) => {
    var {
      onMouseEnter: v
    } = a;
    v && v(a, d);
  }, s = (d) => {
    var {
      onMouseLeave: v
    } = a;
    v && v(a, d);
  }, c;
  return /* @__PURE__ */ l.isValidElement(n) ? c = /* @__PURE__ */ l.cloneElement(n, Le(Le({}, a), {}, {
    points: r
  })) : typeof n == "function" ? c = n(Le(Le({}, a), {}, {
    points: r
  })) : c = /* @__PURE__ */ l.createElement(Wo, Vt({}, le(a), {
    onMouseEnter: u,
    onMouseLeave: s,
    points: r,
    baseLinePoints: i ? t : void 0,
    connectNulls: o
  })), /* @__PURE__ */ l.createElement(_, {
    className: "recharts-radar-polygon"
  }, c, /* @__PURE__ */ l.createElement(RA, {
    props: a,
    points: r
  }));
}
var bs = (e, r, t) => (a, n) => {
  var i = e && e[Math.floor(n * r)];
  return i ? Le(Le({}, a), {}, {
    x: N(i.x, a.x, t),
    y: N(i.y, a.y, t)
  }) : Le(Le({}, a), {}, {
    x: N(a.cx, a.x, t),
    y: N(a.cy, a.y, t)
  });
};
function WA(e) {
  var {
    props: r,
    previousPointsRef: t,
    previousBaseLinePointsRef: a
  } = e, {
    points: n,
    baseLinePoints: i,
    isAnimationActive: o,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    onAnimationEnd: d,
    onAnimationStart: v
  } = r, f = t.current, p = a.current, m = f ? f.length / n.length : 1, h = p ? p.length / i.length : 1, g = or(r, "recharts-radar-"), [y, b] = l.useState(!1), x = !y, O = l.useCallback(() => {
    typeof d == "function" && d(), b(!1);
  }, [d]), P = l.useCallback(() => {
    typeof v == "function" && v(), b(!0);
  }, [v]);
  return /* @__PURE__ */ l.createElement(KA, {
    showLabels: x,
    points: n
  }, /* @__PURE__ */ l.createElement(ir, {
    animationId: g,
    begin: u,
    duration: s,
    isActive: o,
    easing: c,
    key: "radar-".concat(g),
    onAnimationEnd: O,
    onAnimationStart: P
  }, (w) => {
    var E = w === 1 ? n : n.map(bs(f, m, w)), j = w === 1 ? i : i == null ? void 0 : i.map(bs(p, h, w));
    return w > 0 && (t.current = E, a.current = j), /* @__PURE__ */ l.createElement(zA, {
      points: E,
      baseLinePoints: j,
      props: r
    });
  }), /* @__PURE__ */ l.createElement(_r, {
    label: r.label
  }), r.children);
}
function FA(e) {
  var r = l.useRef(void 0), t = l.useRef(void 0);
  return /* @__PURE__ */ l.createElement(WA, {
    props: e,
    previousPointsRef: r,
    previousBaseLinePointsRef: t
  });
}
var XA = {
  activeDot: !0,
  angleAxisId: 0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  dot: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  radiusAxisId: 0,
  zIndex: Y.area
};
function VA(e) {
  var {
    hide: r,
    className: t,
    points: a
  } = e;
  if (r)
    return null;
  var n = R("recharts-radar", t);
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: n
  }, /* @__PURE__ */ l.createElement(FA, e)), /* @__PURE__ */ l.createElement(en, {
    points: a,
    mainColor: qo(e.stroke, e.fill),
    itemDataKey: e.dataKey,
    activeDot: e.activeDot
  }));
}
function GA(e) {
  var r = te(), t = k((a) => kA(a, e.radiusAxisId, e.angleAxisId, r, e.id));
  return (t == null ? void 0 : t.points) == null ? null : /* @__PURE__ */ l.createElement(VA, Vt({}, e, {
    points: t == null ? void 0 : t.points,
    baseLinePoints: t == null ? void 0 : t.baseLinePoints,
    isRange: t == null ? void 0 : t.isRange
  }));
}
function HA(e) {
  var r = V(e, XA);
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "radar"
  }, (t) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Uo, {
    type: "radar",
    id: t,
    data: void 0,
    dataKey: r.dataKey,
    hide: r.hide,
    angleAxisId: r.angleAxisId,
    radiusAxisId: r.radiusAxisId
  }), /* @__PURE__ */ l.createElement(Yo, {
    legendPayload: _A(r)
  }), /* @__PURE__ */ l.createElement(NA, {
    dataKey: r.dataKey,
    stroke: r.stroke,
    strokeWidth: r.strokeWidth,
    fill: r.fill,
    name: r.name,
    hide: r.hide,
    tooltipType: r.tooltipType,
    id: t
  }), /* @__PURE__ */ l.createElement(GA, Vt({}, r, {
    id: t
  }))));
}
HA.displayName = "Radar";
function $i() {
  return $i = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, $i.apply(null, arguments);
}
function ef(e) {
  return typeof e == "string" ? parseInt(e, 10) : e;
}
function Li(e) {
  return /* @__PURE__ */ l.createElement(Xr, $i({
    shapeType: "sector"
  }, e));
}
var xs = (e, r, t) => {
  var a = t ?? e;
  if (!U(a))
    return Ee(a, r, 0);
}, rf = (e, r, t) => {
  var a = {}, n = e.filter(ua), i = e.filter((c) => c.stackId == null), o = n.reduce((c, d) => (c[d.stackId] || (c[d.stackId] = []), c[d.stackId].push(d), c), a), u = Object.entries(o).map((c) => {
    var [d, v] = c, f = v.map((m) => m.dataKey), p = xs(r, t, v[0].barSize);
    return {
      stackId: d,
      dataKeys: f,
      barSize: p
    };
  }), s = i.map((c) => {
    var d = [c.dataKey].filter((f) => f != null), v = xs(r, t, c.barSize);
    return {
      stackId: void 0,
      dataKeys: d,
      barSize: v
    };
  });
  return [...u, ...s];
};
function Ps(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ia(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ps(Object(t), !0).forEach(function(a) {
      YA(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ps(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function YA(e, r, t) {
  return (r = UA(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function UA(e) {
  var r = ZA(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function ZA(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function qA(e, r, t, a, n) {
  var i = a.length;
  if (!(i < 1)) {
    var o = Ee(e, t, 0, !0), u, s = [];
    if (q(a[0].barSize)) {
      var c = !1, d = t / i, v = a.reduce((y, b) => y + (b.barSize || 0), 0);
      v += (i - 1) * o, v >= t && (v -= (i - 1) * o, o = 0), v >= t && d > 0 && (c = !0, d *= 0.9, v = i * d);
      var f = (t - v) / 2 >> 0, p = {
        offset: f - o,
        size: 0
      };
      u = a.reduce((y, b) => {
        var x, O = {
          stackId: b.stackId,
          dataKeys: b.dataKeys,
          position: {
            offset: p.offset + p.size + o,
            size: c ? d : (x = b.barSize) !== null && x !== void 0 ? x : 0
          }
        }, P = [...y, O];
        return p = P[P.length - 1].position, P;
      }, s);
    } else {
      var m = Ee(r, t, 0, !0);
      t - 2 * m - (i - 1) * o <= 0 && (o = 0);
      var h = (t - 2 * m - (i - 1) * o) / i;
      h > 1 && (h >>= 0);
      var g = q(n) ? Math.min(h, n) : h;
      u = a.reduce((y, b, x) => [...y, {
        stackId: b.stackId,
        dataKeys: b.dataKeys,
        position: {
          offset: m + (h + o) * x + (h - g) / 2,
          size: g
        }
      }], s);
    }
    return u;
  }
}
var tf = (e, r, t, a, n, i, o) => {
  var u = U(o) ? r : o, s = qA(t, a, n !== i ? n : i, e, u);
  return n !== i && s != null && (s = s.map((c) => Ia(Ia({}, c), {}, {
    position: Ia(Ia({}, c.position), {}, {
      offset: c.position.offset - n / 2
    })
  }))), s;
}, af = (e, r) => {
  var t = In(r);
  if (!(!e || t == null || r == null)) {
    var {
      stackId: a
    } = r;
    if (a != null) {
      var n = e[a];
      if (n) {
        var {
          stackedData: i
        } = n;
        if (i)
          return i.find((o) => o.key === t);
      }
    }
  }
};
function Os(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function tn(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Os(Object(t), !0).forEach(function(a) {
      JA(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Os(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function JA(e, r, t) {
  return (r = QA(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function QA(e) {
  var r = eE(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function eE(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var rE = (e, r) => yt(e, r), tE = (e, r) => Nr(e, "radiusAxis", r), Gn = A([rE, tE], (e, r) => {
  if (!(e == null || r == null))
    return tn(tn({}, e), {}, {
      scale: r
    });
}), Jo = (e, r, t, a) => LO(e, "radiusAxis", r, a), aE = (e, r, t) => Yr(e, t), nE = (e, r, t) => Nr(e, "angleAxis", t), Hn = A([aE, nE], (e, r) => {
  if (!(e == null || r == null))
    return tn(tn({}, e), {}, {
      scale: r
    });
}), Qo = (e, r, t, a) => qr(e, "angleAxis", t, a), iE = (e, r, t, a) => a, el = A([ha, iE], (e, r) => {
  if (e.some((t) => t.type === "radialBar" && r.dataKey === t.dataKey && r.stackId === t.stackId))
    return r;
}), nf = A([K, Gn, Jo, Hn, Qo], (e, r, t, a, n) => He(e, "radiusAxis") ? Ne(r, t, !1) : Ne(a, n, !1)), oE = A([Hn, Gn, K], (e, r, t) => {
  var a = t === "radial" ? e : r;
  if (!(a == null || a.scale == null))
    return Kc({
      numericAxis: a
    });
}), lE = (e, r, t, a, n) => n, uE = (e, r, t, a, n) => t, sE = (e, r, t, a, n) => r, of = (e, r, t, a, n) => a.maxBarSize, lf = (e) => e.type === "radialBar", cE = A([K, ha, uE, sE], (e, r, t, a) => r.filter((n) => e === "centric" ? n.angleAxisId === t : n.radiusAxisId === a).filter((n) => n.hide === !1).filter(lf)), dE = () => {
}, vE = A([cE, xd, dE], rf), fE = A([K, wn, Hn, Qo, Gn, Jo, of], (e, r, t, a, n, i, o) => {
  var u, s, c = U(o) ? r : o;
  if (e === "centric") {
    var d, v;
    return (d = (v = Ne(t, a, !0)) !== null && v !== void 0 ? v : c) !== null && d !== void 0 ? d : 0;
  }
  return (u = (s = Ne(n, i, !0)) !== null && s !== void 0 ? s : c) !== null && u !== void 0 ? u : 0;
}), pE = A([vE, wn, bd, no, fE, nf, of], tf), mE = A([pE, el], (e, r) => {
  if (!(e == null || r == null)) {
    var t = e.find((a) => a.stackId === r.stackId && r.dataKey != null && a.dataKeys.includes(r.dataKey));
    if (t != null)
      return t.position;
  }
}), uf = A([ya], (e) => e.filter(lf).filter(ua)), hE = A([uf, Lr, ye], uo), ws = A([hE, uf, ht, io], yo), yE = (e, r, t) => {
  var a = K(e);
  return a === "centric" ? ws(e, "radiusAxis", r) : ws(e, "angleAxis", t);
}, gE = A([yE, el], af), bE = A([Hn, Qo, Gn, Jo, lr, el, nf, K, oE, Ur, lE, mE, gE], (e, r, t, a, n, i, o, u, s, c, d, v, f) => {
  var {
    chartData: p,
    dataStartIndex: m,
    dataEndIndex: h
  } = n;
  if (i == null || t == null || e == null || p == null || o == null || v == null || u !== "centric" && u !== "radial" || a == null)
    return [];
  var {
    dataKey: g,
    minPointSize: y
  } = i, {
    cx: b,
    cy: x,
    startAngle: O,
    endAngle: P
  } = c, w = p.slice(m, h + 1), E = u === "centric" ? t : e, j = f ? E.scale.domain() : null;
  return _E({
    angleAxis: e,
    angleAxisTicks: r,
    bandSize: o,
    baseValue: s,
    cells: d,
    cx: b,
    cy: x,
    dataKey: g,
    dataStartIndex: m,
    displayedData: w,
    endAngle: P,
    layout: u,
    minPointSize: y,
    pos: v,
    radiusAxis: t,
    radiusAxisTicks: a,
    stackedData: f,
    stackedDomain: j,
    startAngle: O
  });
}), xE = A([Lr, (e, r) => r], (e, r) => {
  var {
    chartData: t,
    dataStartIndex: a,
    dataEndIndex: n
  } = e;
  if (t == null)
    return [];
  var i = t.slice(a, n + 1);
  return i.length === 0 ? [] : i.map((o) => ({
    type: r,
    // @ts-expect-error we need a better typing for our data inputs
    value: o.name,
    // @ts-expect-error we need a better typing for our data inputs
    color: o.fill,
    // @ts-expect-error we need a better typing for our data inputs
    payload: o
  }));
});
function sf(e, r) {
  return e && typeof e == "object" && "zIndex" in e && typeof e.zIndex == "number" && q(e.zIndex) ? e.zIndex : r;
}
var PE = ["shape", "activeShape", "cornerRadius", "id"], OE = ["onMouseEnter", "onClick", "onMouseLeave"], wE = ["value", "background"];
function st() {
  return st = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, st.apply(null, arguments);
}
function As(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ce(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? As(Object(t), !0).forEach(function(a) {
      AE(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : As(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function AE(e, r, t) {
  return (r = EE(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function EE(e) {
  var r = jE(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function jE(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Mi(e, r) {
  if (e == null) return {};
  var t, a, n = SE(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function SE(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var an = [];
function IE(e) {
  var {
    showLabels: r,
    sectors: t,
    children: a
  } = e, n = t.map((i) => ({
    value: i.value,
    payload: i.payload,
    parentViewBox: void 0,
    clockWise: !1,
    viewBox: {
      cx: i.cx,
      cy: i.cy,
      innerRadius: i.innerRadius,
      outerRadius: i.outerRadius,
      startAngle: i.startAngle,
      endAngle: i.endAngle,
      clockWise: !1
    },
    fill: i.fill
  }));
  return /* @__PURE__ */ l.createElement(Rv, {
    value: r ? n : void 0
  }, a);
}
function kE(e) {
  var {
    sectors: r,
    allOtherRadialBarProps: t,
    showLabels: a
  } = e, {
    shape: n,
    activeShape: i,
    cornerRadius: o,
    id: u
  } = t, s = Mi(t, PE), c = G(s), d = k(nr), {
    onMouseEnter: v,
    onClick: f,
    onMouseLeave: p
  } = t, m = Mi(t, OE), h = It(v, t.dataKey, u), g = kt(p), y = Ct(f, t.dataKey, u);
  return r == null ? null : /* @__PURE__ */ l.createElement(IE, {
    showLabels: a,
    sectors: r
  }, r.map((b, x) => {
    var O = i && d === String(x), P = h(b, x), w = g(b, x), E = y(b, x), j = Ce(Ce(Ce(Ce({}, c), {}, {
      cornerRadius: ef(o)
    }, b), Ue(m, b, x)), {}, {
      onMouseEnter: P,
      onMouseLeave: w,
      onClick: E,
      className: "recharts-radial-bar-sector ".concat(b.className),
      forceCornerRadius: s.forceCornerRadius,
      cornerIsExternal: s.cornerIsExternal,
      isActive: O,
      option: O ? i : n
    });
    return O ? /* @__PURE__ */ l.createElement(ee, {
      zIndex: Y.activeBar,
      key: "sector-".concat(b.cx, "-").concat(b.cy, "-").concat(b.innerRadius, "-").concat(b.outerRadius, "-").concat(b.startAngle, "-").concat(b.endAngle, "-").concat(x)
    }, /* @__PURE__ */ l.createElement(Li, j)) : /* @__PURE__ */ l.createElement(Li, st({
      key: "sector-".concat(b.cx, "-").concat(b.cy, "-").concat(b.innerRadius, "-").concat(b.outerRadius, "-").concat(b.startAngle, "-").concat(b.endAngle, "-").concat(x)
    }, j));
  }), /* @__PURE__ */ l.createElement(_r, {
    label: t.label
  }), t.children);
}
function CE(e) {
  var {
    props: r,
    previousSectorsRef: t
  } = e, {
    data: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u,
    onAnimationEnd: s,
    onAnimationStart: c
  } = r, d = or(r, "recharts-radialbar-"), v = t.current, [f, p] = l.useState(!1), m = l.useCallback(() => {
    typeof s == "function" && s(), p(!1);
  }, [s]), h = l.useCallback(() => {
    typeof c == "function" && c(), p(!0);
  }, [c]);
  return /* @__PURE__ */ l.createElement(ir, {
    animationId: d,
    begin: i,
    duration: o,
    isActive: n,
    easing: u,
    onAnimationStart: h,
    onAnimationEnd: m,
    key: d
  }, (g) => {
    var y = g === 1 ? a : (a ?? an).map((b, x) => {
      var O = v && v[x];
      if (O)
        return Ce(Ce({}, b), {}, {
          startAngle: N(O.startAngle, b.startAngle, g),
          endAngle: N(O.endAngle, b.endAngle, g)
        });
      var {
        endAngle: P,
        startAngle: w
      } = b;
      return Ce(Ce({}, b), {}, {
        endAngle: N(w, P, g)
      });
    });
    return g > 0 && (t.current = y ?? null), /* @__PURE__ */ l.createElement(_, null, /* @__PURE__ */ l.createElement(kE, {
      sectors: y ?? an,
      allOtherRadialBarProps: r,
      showLabels: !f
    }));
  });
}
function DE(e) {
  var r = l.useRef(null);
  return /* @__PURE__ */ l.createElement(CE, {
    props: e,
    previousSectorsRef: r
  });
}
function TE(e) {
  var r = k((t) => xE(t, e.legendType));
  return /* @__PURE__ */ l.createElement(Yo, {
    legendPayload: r ?? []
  });
}
var $E = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    data: t,
    stroke: a,
    strokeWidth: n,
    name: i,
    hide: o,
    fill: u,
    tooltipType: s,
    id: c
  } = e, d = {
    dataDefinedOnItem: t,
    positions: void 0,
    settings: {
      graphicalItemId: c,
      stroke: a,
      strokeWidth: n,
      fill: u,
      nameKey: void 0,
      // RadialBar does not have nameKey, why?
      dataKey: r,
      name: We(i, r),
      hide: o,
      type: s,
      color: u,
      unit: ""
      // Why does RadialBar not support unit?
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: d
  });
});
class LE extends l.PureComponent {
  renderBackground(r) {
    if (r == null)
      return null;
    var {
      cornerRadius: t
    } = this.props, a = ze(this.props.background);
    return /* @__PURE__ */ l.createElement(ee, {
      zIndex: sf(this.props.background, Y.barBackground)
    }, r.map((n, i) => {
      var {
        value: o,
        background: u
      } = n, s = Mi(n, wE);
      if (!u)
        return null;
      var c = Ce(Ce(Ce(Ce(Ce({
        cornerRadius: ef(t)
      }, s), {}, {
        // @ts-expect-error backgroundProps is contributing unknown props
        fill: "#eee"
      }, u), a), Ue(this.props, n, i)), {}, {
        index: i,
        className: R("recharts-radial-bar-background-sector", String(a == null ? void 0 : a.className)),
        option: u,
        isActive: !1
      });
      return /* @__PURE__ */ l.createElement(Li, st({
        key: "background-".concat(s.cx, "-").concat(s.cy, "-").concat(s.innerRadius, "-").concat(s.outerRadius, "-").concat(s.startAngle, "-").concat(s.endAngle, "-").concat(i)
      }, c));
    }));
  }
  render() {
    var {
      hide: r,
      data: t,
      className: a,
      background: n
    } = this.props;
    if (r)
      return null;
    var i = R("recharts-area", a);
    return /* @__PURE__ */ l.createElement(ee, {
      zIndex: this.props.zIndex
    }, /* @__PURE__ */ l.createElement(_, {
      className: i
    }, n && /* @__PURE__ */ l.createElement(_, {
      className: "recharts-radial-bar-background"
    }, this.renderBackground(t)), /* @__PURE__ */ l.createElement(_, {
      className: "recharts-radial-bar-sectors"
    }, /* @__PURE__ */ l.createElement(DE, this.props))));
  }
}
function ME(e) {
  var r, t = St(e.children, Zr), a = {
    data: void 0,
    hide: !1,
    id: e.id,
    dataKey: e.dataKey,
    minPointSize: e.minPointSize,
    stackId: gn(e.stackId),
    maxBarSize: e.maxBarSize,
    barSize: e.barSize,
    type: "radialBar",
    angleAxisId: e.angleAxisId,
    radiusAxisId: e.radiusAxisId
  }, n = (r = k((i) => bE(i, e.radiusAxisId, e.angleAxisId, a, t))) !== null && r !== void 0 ? r : an;
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement($E, {
    dataKey: e.dataKey,
    data: n,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    name: e.name,
    hide: e.hide,
    fill: e.fill,
    tooltipType: e.tooltipType,
    id: e.id
  }), /* @__PURE__ */ l.createElement(LE, st({}, e, {
    data: n
  })));
}
var ka = {
  angleAxisId: 0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  background: !1,
  cornerIsExternal: !1,
  cornerRadius: 0,
  data: [],
  forceCornerRadius: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  minPointSize: 0,
  radiusAxisId: 0,
  zIndex: Y.bar
};
function _E(e) {
  var {
    displayedData: r,
    stackedData: t,
    dataStartIndex: a,
    stackedDomain: n,
    dataKey: i,
    baseValue: o,
    layout: u,
    radiusAxis: s,
    radiusAxisTicks: c,
    bandSize: d,
    pos: v,
    angleAxis: f,
    minPointSize: p,
    cx: m,
    cy: h,
    angleAxisTicks: g,
    cells: y,
    startAngle: b,
    endAngle: x
  } = e;
  return g == null || c == null ? an : (r ?? []).map((O, P) => {
    var w, E, j, S, I, D;
    if (t ? w = Bc(t[a + P], n) : (w = B(O, i), Array.isArray(w) || (w = [o, w])), u === "radial") {
      E = Ra({
        axis: s,
        ticks: c,
        bandSize: d,
        offset: v.offset,
        entry: O,
        index: P
      }), I = f.scale(w[1]), S = f.scale(w[0]), j = (E ?? 0) + v.size;
      var C = I - S;
      if (Math.abs(p) > 0 && Math.abs(C) < Math.abs(p)) {
        var M = me(C || p) * (Math.abs(p) - Math.abs(C));
        I += M;
      }
      D = {
        background: {
          cx: m,
          cy: h,
          innerRadius: E,
          outerRadius: j,
          startAngle: b,
          endAngle: x
        }
      };
    } else {
      E = s.scale(w[0]), j = s.scale(w[1]), S = Ra({
        axis: f,
        ticks: g,
        bandSize: d,
        offset: v.offset,
        entry: O,
        index: P
      }), I = (S ?? 0) + v.size;
      var T = j - E;
      if (Math.abs(p) > 0 && Math.abs(T) < Math.abs(p)) {
        var $ = me(T || p) * (Math.abs(p) - Math.abs(T));
        j += $;
      }
    }
    return Ce(Ce(Ce({}, O), D), {}, {
      payload: O,
      value: t ? w : w[1],
      cx: m,
      cy: h,
      innerRadius: E,
      outerRadius: j,
      startAngle: S,
      endAngle: I
    }, y && y[P] && y[P].props);
  });
}
function NE(e) {
  var r = V(e, ka);
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "radialBar"
  }, (t) => {
    var a, n, i;
    return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Uo, {
      type: "radialBar",
      id: t,
      data: void 0,
      dataKey: r.dataKey,
      hide: (a = r.hide) !== null && a !== void 0 ? a : ka.hide,
      angleAxisId: (n = r.angleAxisId) !== null && n !== void 0 ? n : ka.angleAxisId,
      radiusAxisId: (i = r.radiusAxisId) !== null && i !== void 0 ? i : ka.radiusAxisId,
      stackId: gn(r.stackId),
      barSize: r.barSize,
      minPointSize: r.minPointSize,
      maxBarSize: r.maxBarSize
    }), /* @__PURE__ */ l.createElement(TE, r), /* @__PURE__ */ l.createElement(ME, st({}, r, {
      id: t
    })));
  });
}
NE.displayName = "RadialBar";
function Es(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function js(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Es(Object(t), !0).forEach(function(a) {
      RE(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Es(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function RE(e, r, t) {
  return (r = BE(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function BE(e) {
  var r = KE(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function KE(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var zE = ["Webkit", "Moz", "O", "ms"], WE = (e, r) => {
  var t = e.replace(/(\w)/, (n) => n.toUpperCase()), a = zE.reduce((n, i) => js(js({}, n), {}, {
    [i + t]: r
  }), {});
  return a[e] = r, a;
}, cf = (e) => {
  var {
    chartData: r
  } = e, t = F(), a = te();
  return l.useEffect(() => a ? () => {
  } : (t(Ii(r)), () => {
    t(Ii(void 0));
  }), [r, t, a]), null;
}, FE = (e) => {
  var {
    computedData: r
  } = e, t = F();
  return l.useEffect(() => (t(oP(r)), () => {
    t(Ii(void 0));
  }), [r, t]), null;
}, XE = (e) => e.chartData.chartData, VE = () => k(XE), GE = (e) => {
  var {
    dataStartIndex: r,
    dataEndIndex: t
  } = e.chartData;
  return {
    startIndex: r,
    endIndex: t
  };
}, HE = () => k(GE), YE = /* @__PURE__ */ l.createContext(() => {
}), Ss = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  padding: {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }
}, df = Be({
  name: "brush",
  initialState: Ss,
  reducers: {
    setBrushSettings(e, r) {
      return r.payload == null ? Ss : r.payload;
    }
  }
}), {
  setBrushSettings: Is
} = df.actions, UE = df.reducer;
function Gt() {
  return Gt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Gt.apply(null, arguments);
}
function ks(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Rr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ks(Object(t), !0).forEach(function(a) {
      mr(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ks(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function mr(e, r, t) {
  return (r = ZE(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function ZE(e) {
  var r = qE(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function qE(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function JE(e) {
  var {
    x: r,
    y: t,
    width: a,
    height: n,
    stroke: i
  } = e, o = Math.floor(t + n / 2) - 1;
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement("rect", {
    x: r,
    y: t,
    width: a,
    height: n,
    fill: i,
    stroke: "none"
  }), /* @__PURE__ */ l.createElement("line", {
    x1: r + 1,
    y1: o,
    x2: r + a - 1,
    y2: o,
    fill: "none",
    stroke: "#fff"
  }), /* @__PURE__ */ l.createElement("line", {
    x1: r + 1,
    y1: o + 2,
    x2: r + a - 1,
    y2: o + 2,
    fill: "none",
    stroke: "#fff"
  }));
}
function QE(e) {
  var {
    travellerProps: r,
    travellerType: t
  } = e;
  return /* @__PURE__ */ l.isValidElement(t) ? /* @__PURE__ */ l.cloneElement(t, r) : typeof t == "function" ? t(r) : /* @__PURE__ */ l.createElement(JE, r);
}
function Cs(e) {
  var r, t, {
    otherProps: a,
    travellerX: n,
    id: i,
    onMouseEnter: o,
    onMouseLeave: u,
    onMouseDown: s,
    onTouchStart: c,
    onTravellerMoveKeyboard: d,
    onFocus: v,
    onBlur: f
  } = e, {
    y: p,
    x: m,
    travellerWidth: h,
    height: g,
    traveller: y,
    ariaLabel: b,
    data: x,
    startIndex: O,
    endIndex: P
  } = a, w = Math.max(n, m), E = Rr(Rr({}, G(a)), {}, {
    x: w,
    y: p,
    width: h,
    height: g
  }), j = b || "Min value: ".concat((r = x[O]) === null || r === void 0 ? void 0 : r.name, ", Max value: ").concat((t = x[P]) === null || t === void 0 ? void 0 : t.name);
  return /* @__PURE__ */ l.createElement(_, {
    tabIndex: 0,
    role: "slider",
    "aria-label": j,
    "aria-valuenow": n,
    className: "recharts-brush-traveller",
    onMouseEnter: o,
    onMouseLeave: u,
    onMouseDown: s,
    onTouchStart: c,
    onKeyDown: (S) => {
      ["ArrowLeft", "ArrowRight"].includes(S.key) && (S.preventDefault(), S.stopPropagation(), d(S.key === "ArrowRight" ? 1 : -1, i));
    },
    onFocus: v,
    onBlur: f,
    style: {
      cursor: "col-resize"
    }
  }, /* @__PURE__ */ l.createElement(QE, {
    travellerType: y,
    travellerProps: E
  }));
}
function Ds(e) {
  var {
    index: r,
    data: t,
    tickFormatter: a,
    dataKey: n
  } = e, i = B(t[r], n, r);
  return typeof a == "function" ? a(i, r) : i;
}
function Ts(e, r) {
  for (var t = e.length, a = 0, n = t - 1; n - a > 1; ) {
    var i = Math.floor((a + n) / 2);
    e[i] > r ? n = i : a = i;
  }
  return r >= e[n] ? n : a;
}
function li(e) {
  var {
    startX: r,
    endX: t,
    scaleValues: a,
    gap: n,
    data: i
  } = e, o = i.length - 1, u = Math.min(r, t), s = Math.max(r, t), c = Ts(a, u), d = Ts(a, s);
  return {
    startIndex: c - c % n,
    endIndex: d === o ? o : d - d % n
  };
}
function ej(e) {
  var {
    x: r,
    y: t,
    width: a,
    height: n,
    fill: i,
    stroke: o
  } = e;
  return /* @__PURE__ */ l.createElement("rect", {
    stroke: o,
    fill: i,
    x: r,
    y: t,
    width: a,
    height: n
  });
}
function rj(e) {
  var {
    startIndex: r,
    endIndex: t,
    y: a,
    height: n,
    travellerWidth: i,
    stroke: o,
    tickFormatter: u,
    dataKey: s,
    data: c,
    startX: d,
    endX: v
  } = e, f = 5, p = {
    pointerEvents: "none",
    fill: o
  };
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-brush-texts"
  }, /* @__PURE__ */ l.createElement(Tr, Gt({
    textAnchor: "end",
    verticalAnchor: "middle",
    x: Math.min(d, v) - f,
    y: a + n / 2
  }, p), Ds({
    index: r,
    tickFormatter: u,
    dataKey: s,
    data: c
  })), /* @__PURE__ */ l.createElement(Tr, Gt({
    textAnchor: "start",
    verticalAnchor: "middle",
    x: Math.max(d, v) + i + f,
    y: a + n / 2
  }, p), Ds({
    index: t,
    tickFormatter: u,
    dataKey: s,
    data: c
  })));
}
function tj(e) {
  var {
    y: r,
    height: t,
    stroke: a,
    travellerWidth: n,
    startX: i,
    endX: o,
    onMouseEnter: u,
    onMouseLeave: s,
    onMouseDown: c,
    onTouchStart: d
  } = e, v = Math.min(i, o) + n, f = Math.max(Math.abs(o - i) - n, 0);
  return /* @__PURE__ */ l.createElement("rect", {
    className: "recharts-brush-slide",
    onMouseEnter: u,
    onMouseLeave: s,
    onMouseDown: c,
    onTouchStart: d,
    style: {
      cursor: "move"
    },
    stroke: "none",
    fill: a,
    fillOpacity: 0.2,
    x: v,
    y: r,
    width: f,
    height: t
  });
}
function aj(e) {
  var {
    x: r,
    y: t,
    width: a,
    height: n,
    data: i,
    children: o,
    padding: u
  } = e, s = l.Children.count(o) === 1;
  if (!s)
    return null;
  var c = l.Children.only(o);
  return c ? /* @__PURE__ */ l.cloneElement(c, {
    x: r,
    y: t,
    width: a,
    height: n,
    margin: u,
    compact: !0,
    data: i
  }) : null;
}
var nj = (e) => {
  var {
    data: r,
    startIndex: t,
    endIndex: a,
    x: n,
    width: i,
    travellerWidth: o
  } = e;
  if (!r || !r.length)
    return {};
  var u = r.length, s = Np().domain(Yi(0, u)).range([n, n + i - o]), c = s.domain().map((d) => s(d)).filter(Zi);
  return {
    isTextActive: !1,
    isSlideMoving: !1,
    isTravellerMoving: !1,
    isTravellerFocused: !1,
    startX: s(t),
    endX: s(a),
    scale: s,
    scaleValues: c
  };
}, $s = (e) => e.changedTouches && !!e.changedTouches.length;
class ij extends l.PureComponent {
  constructor(r) {
    super(r), mr(this, "handleDrag", (t) => {
      this.leaveTimer && (clearTimeout(this.leaveTimer), this.leaveTimer = null), this.state.isTravellerMoving ? this.handleTravellerMove(t) : this.state.isSlideMoving && this.handleSlideDrag(t);
    }), mr(this, "handleTouchMove", (t) => {
      t.changedTouches != null && t.changedTouches.length > 0 && this.handleDrag(t.changedTouches[0]);
    }), mr(this, "handleDragEnd", () => {
      this.setState({
        isTravellerMoving: !1,
        isSlideMoving: !1
      }, () => {
        var {
          endIndex: t,
          onDragEnd: a,
          startIndex: n
        } = this.props;
        a == null || a({
          endIndex: t,
          startIndex: n
        });
      }), this.detachDragEndListener();
    }), mr(this, "handleLeaveWrapper", () => {
      (this.state.isTravellerMoving || this.state.isSlideMoving) && (this.leaveTimer = window.setTimeout(this.handleDragEnd, this.props.leaveTimeOut));
    }), mr(this, "handleEnterSlideOrTraveller", () => {
      this.setState({
        isTextActive: !0
      });
    }), mr(this, "handleLeaveSlideOrTraveller", () => {
      this.setState({
        isTextActive: !1
      });
    }), mr(this, "handleSlideDragStart", (t) => {
      var a = $s(t) ? t.changedTouches[0] : t;
      this.setState({
        isTravellerMoving: !1,
        isSlideMoving: !0,
        slideMoveStartX: a.pageX
      }), this.attachDragEndListener();
    }), mr(this, "handleTravellerMoveKeyboard", (t, a) => {
      var {
        data: n,
        gap: i,
        startIndex: o,
        endIndex: u
      } = this.props, {
        scaleValues: s,
        startX: c,
        endX: d
      } = this.state;
      if (s != null) {
        var v = -1;
        if (a === "startX" ? v = o : a === "endX" && (v = u), !(v < 0 || v >= n.length)) {
          var f = v + t;
          if (!(f === -1 || f >= s.length)) {
            var p = s[f];
            a === "startX" && p >= d || a === "endX" && p <= c || this.setState(
              // @ts-expect-error not sure why typescript is not happy with this, partial update is fine in React
              {
                [a]: p
              },
              () => {
                this.props.onChange(li({
                  startX: this.state.startX,
                  endX: this.state.endX,
                  data: n,
                  gap: i,
                  scaleValues: s
                }));
              }
            );
          }
        }
      }
    }), this.travellerDragStartHandlers = {
      startX: this.handleTravellerDragStart.bind(this, "startX"),
      endX: this.handleTravellerDragStart.bind(this, "endX")
    }, this.state = {
      brushMoveStartX: 0,
      movingTravellerId: void 0,
      endX: 0,
      startX: 0,
      slideMoveStartX: 0
    };
  }
  static getDerivedStateFromProps(r, t) {
    var {
      data: a,
      width: n,
      x: i,
      travellerWidth: o,
      startIndex: u,
      endIndex: s,
      startIndexControlledFromProps: c,
      endIndexControlledFromProps: d
    } = r;
    if (a !== t.prevData)
      return Rr({
        prevData: a,
        prevTravellerWidth: o,
        prevX: i,
        prevWidth: n
      }, a && a.length ? nj({
        data: a,
        width: n,
        x: i,
        travellerWidth: o,
        startIndex: u,
        endIndex: s
      }) : {
        scale: void 0,
        scaleValues: void 0
      });
    var v = t.scale;
    if (v && (n !== t.prevWidth || i !== t.prevX || o !== t.prevTravellerWidth)) {
      v.range([i, i + n - o]);
      var f = v.domain().map((p) => v(p)).filter((p) => p != null);
      return {
        prevData: a,
        prevTravellerWidth: o,
        prevX: i,
        prevWidth: n,
        startX: v(r.startIndex),
        endX: v(r.endIndex),
        scaleValues: f
      };
    }
    if (t.scale && !t.isSlideMoving && !t.isTravellerMoving && !t.isTravellerFocused && !t.isTextActive) {
      if (c != null && t.prevStartIndexControlledFromProps !== c)
        return {
          startX: t.scale(c),
          prevStartIndexControlledFromProps: c
        };
      if (d != null && t.prevEndIndexControlledFromProps !== d)
        return {
          endX: t.scale(d),
          prevEndIndexControlledFromProps: d
        };
    }
    return null;
  }
  componentWillUnmount() {
    this.leaveTimer && (clearTimeout(this.leaveTimer), this.leaveTimer = null), this.detachDragEndListener();
  }
  attachDragEndListener() {
    window.addEventListener("mouseup", this.handleDragEnd, !0), window.addEventListener("touchend", this.handleDragEnd, !0), window.addEventListener("mousemove", this.handleDrag, !0);
  }
  detachDragEndListener() {
    window.removeEventListener("mouseup", this.handleDragEnd, !0), window.removeEventListener("touchend", this.handleDragEnd, !0), window.removeEventListener("mousemove", this.handleDrag, !0);
  }
  handleSlideDrag(r) {
    var {
      slideMoveStartX: t,
      startX: a,
      endX: n,
      scaleValues: i
    } = this.state;
    if (i != null) {
      var {
        x: o,
        width: u,
        travellerWidth: s,
        startIndex: c,
        endIndex: d,
        onChange: v,
        data: f,
        gap: p
      } = this.props, m = r.pageX - t;
      m > 0 ? m = Math.min(m, o + u - s - n, o + u - s - a) : m < 0 && (m = Math.max(m, o - a, o - n));
      var h = li({
        startX: a + m,
        endX: n + m,
        data: f,
        gap: p,
        scaleValues: i
      });
      (h.startIndex !== c || h.endIndex !== d) && v && v(h), this.setState({
        startX: a + m,
        endX: n + m,
        slideMoveStartX: r.pageX
      });
    }
  }
  handleTravellerDragStart(r, t) {
    var a = $s(t) ? t.changedTouches[0] : t;
    this.setState({
      isSlideMoving: !1,
      isTravellerMoving: !0,
      movingTravellerId: r,
      brushMoveStartX: a.pageX
    }), this.attachDragEndListener();
  }
  handleTravellerMove(r) {
    var {
      brushMoveStartX: t,
      movingTravellerId: a,
      endX: n,
      startX: i,
      scaleValues: o
    } = this.state;
    if (!(a == null || o == null)) {
      var u = this.state[a], {
        x: s,
        width: c,
        travellerWidth: d,
        onChange: v,
        gap: f,
        data: p
      } = this.props, m = {
        startX: this.state.startX,
        endX: this.state.endX,
        data: p,
        gap: f,
        scaleValues: o
      }, h = r.pageX - t;
      h > 0 ? h = Math.min(h, s + c - d - u) : h < 0 && (h = Math.max(h, s - u)), m[a] = u + h;
      var g = li(m), {
        startIndex: y,
        endIndex: b
      } = g, x = () => {
        var O = p.length - 1;
        return a === "startX" && (n > i ? y % f === 0 : b % f === 0) || n < i && b === O || a === "endX" && (n > i ? b % f === 0 : y % f === 0) || n > i && b === O;
      };
      this.setState(
        // @ts-expect-error not sure why typescript is not happy with this, partial update is fine in React
        {
          [a]: u + h,
          brushMoveStartX: r.pageX
        },
        () => {
          v && x() && v(g);
        }
      );
    }
  }
  render() {
    var {
      data: r,
      className: t,
      children: a,
      x: n,
      y: i,
      dy: o,
      width: u,
      height: s,
      alwaysShowText: c,
      fill: d,
      stroke: v,
      startIndex: f,
      endIndex: p,
      travellerWidth: m,
      tickFormatter: h,
      dataKey: g,
      padding: y
    } = this.props, {
      startX: b,
      endX: x,
      isTextActive: O,
      isSlideMoving: P,
      isTravellerMoving: w,
      isTravellerFocused: E
    } = this.state;
    if (!r || !r.length || !L(n) || !L(i) || !L(u) || !L(s) || u <= 0 || s <= 0)
      return null;
    var j = R("recharts-brush", t), S = WE("userSelect", "none"), I = i + (o ?? 0);
    return /* @__PURE__ */ l.createElement(_, {
      className: j,
      onMouseLeave: this.handleLeaveWrapper,
      onTouchMove: this.handleTouchMove,
      style: S
    }, /* @__PURE__ */ l.createElement(ej, {
      x: n,
      y: I,
      width: u,
      height: s,
      fill: d,
      stroke: v
    }), /* @__PURE__ */ l.createElement(vh, null, /* @__PURE__ */ l.createElement(aj, {
      x: n,
      y: I,
      width: u,
      height: s,
      data: r,
      padding: y
    }, a)), /* @__PURE__ */ l.createElement(tj, {
      y: I,
      height: s,
      stroke: v,
      travellerWidth: m,
      startX: b,
      endX: x,
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.handleSlideDragStart,
      onTouchStart: this.handleSlideDragStart
    }), /* @__PURE__ */ l.createElement(Cs, {
      travellerX: b,
      id: "startX",
      otherProps: Rr(Rr({}, this.props), {}, {
        y: I
      }),
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.travellerDragStartHandlers.startX,
      onTouchStart: this.travellerDragStartHandlers.startX,
      onTravellerMoveKeyboard: this.handleTravellerMoveKeyboard,
      onFocus: () => {
        this.setState({
          isTravellerFocused: !0
        });
      },
      onBlur: () => {
        this.setState({
          isTravellerFocused: !1
        });
      }
    }), /* @__PURE__ */ l.createElement(Cs, {
      travellerX: x,
      id: "endX",
      otherProps: Rr(Rr({}, this.props), {}, {
        y: I
      }),
      onMouseEnter: this.handleEnterSlideOrTraveller,
      onMouseLeave: this.handleLeaveSlideOrTraveller,
      onMouseDown: this.travellerDragStartHandlers.endX,
      onTouchStart: this.travellerDragStartHandlers.endX,
      onTravellerMoveKeyboard: this.handleTravellerMoveKeyboard,
      onFocus: () => {
        this.setState({
          isTravellerFocused: !0
        });
      },
      onBlur: () => {
        this.setState({
          isTravellerFocused: !1
        });
      }
    }), (O || P || w || E || c) && /* @__PURE__ */ l.createElement(rj, {
      startIndex: f,
      endIndex: p,
      y: I,
      height: s,
      travellerWidth: m,
      stroke: v,
      tickFormatter: h,
      dataKey: g,
      data: r,
      startX: b,
      endX: x
    }));
  }
}
function oj(e) {
  var r = F(), t = VE(), a = HE(), n = l.useContext(YE), i = e.onChange, {
    startIndex: o,
    endIndex: u
  } = e;
  l.useEffect(() => {
    r(ki({
      startIndex: o,
      endIndex: u
    }));
  }, [r, u, o]), gP();
  var s = l.useCallback((g) => {
    if (a != null) {
      var {
        startIndex: y,
        endIndex: b
      } = a;
      (g.startIndex !== y || g.endIndex !== b) && (n == null || n(g), i == null || i(g), r(ki(g)));
    }
  }, [i, n, r, a]), c = k(ta);
  if (c == null || a == null || t == null || !t.length)
    return null;
  var {
    startIndex: d,
    endIndex: v
  } = a, {
    x: f,
    y: p,
    width: m
  } = c, h = {
    data: t,
    x: f,
    y: p,
    width: m,
    startIndex: d,
    endIndex: v,
    onChange: s
  };
  return /* @__PURE__ */ l.createElement(ij, Gt({}, e, h, {
    startIndexControlledFromProps: o ?? void 0,
    endIndexControlledFromProps: u ?? void 0
  }));
}
function lj(e) {
  var r = F();
  return l.useEffect(() => (r(Is(e)), () => {
    r(Is(null));
  }), [r, e]), null;
}
var uj = {
  height: 40,
  travellerWidth: 5,
  gap: 1,
  fill: "#fff",
  stroke: "#666",
  padding: {
    top: 1,
    right: 1,
    bottom: 1,
    left: 1
  },
  leaveTimeOut: 1e3,
  alwaysShowText: !1
};
function sj(e) {
  var r = V(e, uj);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(lj, {
    height: r.height,
    x: r.x,
    y: r.y,
    width: r.width,
    padding: r.padding
  }), /* @__PURE__ */ l.createElement(oj, r));
}
sj.displayName = "Brush";
function Ls(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ca(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ls(Object(t), !0).forEach(function(a) {
      vf(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ls(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function vf(e, r, t) {
  return (r = cj(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function cj(e) {
  var r = dj(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function dj(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var ff = (e, r) => {
  var {
    x: t,
    y: a
  } = e, {
    x: n,
    y: i
  } = r;
  return {
    x: Math.min(t, n),
    y: Math.min(a, i),
    width: Math.abs(n - t),
    height: Math.abs(i - a)
  };
}, vj = (e) => {
  var {
    x1: r,
    y1: t,
    x2: a,
    y2: n
  } = e;
  return ff({
    x: r,
    y: t
  }, {
    x: a,
    y: n
  });
};
class Yn {
  static create(r) {
    return new Yn(r);
  }
  constructor(r) {
    this.scale = r;
  }
  get domain() {
    return this.scale.domain;
  }
  get range() {
    return this.scale.range;
  }
  get rangeMin() {
    return this.range()[0];
  }
  get rangeMax() {
    return this.range()[1];
  }
  get bandwidth() {
    return this.scale.bandwidth;
  }
  apply(r) {
    var {
      bandAware: t,
      position: a
    } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (r !== void 0) {
      if (a)
        switch (a) {
          case "start":
            return this.scale(r);
          case "middle": {
            var n = this.bandwidth ? this.bandwidth() / 2 : 0;
            return this.scale(r) + n;
          }
          case "end": {
            var i = this.bandwidth ? this.bandwidth() : 0;
            return this.scale(r) + i;
          }
          default:
            return this.scale(r);
        }
      if (t) {
        var o = this.bandwidth ? this.bandwidth() / 2 : 0;
        return this.scale(r) + o;
      }
      return this.scale(r);
    }
  }
  isInRange(r) {
    var t = this.range(), a = t[0], n = t[t.length - 1];
    return a <= n ? r >= a && r <= n : r >= n && r <= a;
  }
}
vf(Yn, "EPS", 1e-4);
var rl = (e) => {
  var r = Object.keys(e).reduce((t, a) => Ca(Ca({}, t), {}, {
    [a]: Yn.create(e[a])
  }), {});
  return Ca(Ca({}, r), {}, {
    apply(t) {
      var {
        bandAware: a,
        position: n
      } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return Object.fromEntries(Object.entries(t).map((i) => {
        var [o, u] = i;
        return [o, r[o].apply(u, {
          bandAware: a,
          position: n
        })];
      }));
    },
    isInRange(t) {
      return Object.keys(t).every((a) => r[a].isInRange(t[a]));
    }
  });
};
function fj(e) {
  return (e % 180 + 180) % 180;
}
var pj = function(r) {
  var {
    width: t,
    height: a
  } = r, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, i = fj(n), o = i * Math.PI / 180, u = Math.atan(a / t), s = o > u && o < Math.PI - u ? a / Math.sin(o) : t / Math.cos(o);
  return Math.abs(s);
}, mj = {
  dots: [],
  areas: [],
  lines: []
}, pf = Be({
  name: "referenceElements",
  initialState: mj,
  reducers: {
    addDot: (e, r) => {
      e.dots.push(r.payload);
    },
    removeDot: (e, r) => {
      var t = er(e).dots.findIndex((a) => a === r.payload);
      t !== -1 && e.dots.splice(t, 1);
    },
    addArea: (e, r) => {
      e.areas.push(r.payload);
    },
    removeArea: (e, r) => {
      var t = er(e).areas.findIndex((a) => a === r.payload);
      t !== -1 && e.areas.splice(t, 1);
    },
    addLine: (e, r) => {
      e.lines.push(re(r.payload));
    },
    removeLine: (e, r) => {
      var t = er(e).lines.findIndex((a) => a === r.payload);
      t !== -1 && e.lines.splice(t, 1);
    }
  }
}), {
  addDot: hj,
  removeDot: yj,
  addArea: gj,
  removeArea: bj,
  addLine: xj,
  removeLine: Pj
} = pf.actions, Oj = pf.reducer, mf = /* @__PURE__ */ l.createContext(void 0), wj = (e) => {
  var {
    children: r
  } = e, [t] = l.useState("".concat(it("recharts"), "-clip")), a = ga();
  if (a == null)
    return null;
  var {
    x: n,
    y: i,
    width: o,
    height: u
  } = a;
  return /* @__PURE__ */ l.createElement(mf.Provider, {
    value: t
  }, /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement("clipPath", {
    id: t
  }, /* @__PURE__ */ l.createElement("rect", {
    x: n,
    y: i,
    height: u,
    width: o
  }))), r);
}, tl = () => l.useContext(mf);
function Ms(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function _s(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ms(Object(t), !0).forEach(function(a) {
      Aj(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ms(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Aj(e, r, t) {
  return (r = Ej(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ej(e) {
  var r = jj(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function jj(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function nn() {
  return nn = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, nn.apply(null, arguments);
}
var Sj = (e, r) => {
  var t;
  if (/* @__PURE__ */ l.isValidElement(e))
    t = /* @__PURE__ */ l.cloneElement(e, r);
  else if (typeof e == "function")
    t = e(r);
  else {
    if (!q(r.x1) || !q(r.y1) || !q(r.x2) || !q(r.y2))
      return null;
    t = /* @__PURE__ */ l.createElement("line", nn({}, r, {
      className: "recharts-reference-line-line"
    }));
  }
  return t;
}, Ij = (e, r, t, a, n, i) => {
  var {
    x: o,
    width: u
  } = i, s = n.y.apply(e, {
    position: t
  });
  if (De(s) || r === "discard" && !n.y.isInRange(s))
    return null;
  var c = [{
    x: o + u,
    y: s
  }, {
    x: o,
    y: s
  }];
  return a === "left" ? c.reverse() : c;
}, kj = (e, r, t, a, n, i) => {
  var {
    y: o,
    height: u
  } = i, s = n.x.apply(e, {
    position: t
  });
  if (De(s) || r === "discard" && !n.x.isInRange(s))
    return null;
  var c = [{
    x: s,
    y: o + u
  }, {
    x: s,
    y: o
  }];
  return a === "top" ? c.reverse() : c;
}, Cj = (e, r, t, a) => {
  var n = e.map((i) => a.apply(i, {
    position: t
  }));
  return r === "discard" && n.some((i) => !a.isInRange(i)) ? null : n;
}, Dj = (e, r, t, a, n, i) => {
  var {
    x: o,
    y: u,
    segment: s,
    ifOverflow: c
  } = i, d = we(o), v = we(u);
  return v ? Ij(u, c, t, n, e, r) : d ? kj(o, c, t, a, e, r) : s != null && s.length === 2 ? Cj(s, c, t, e) : null;
};
function Tj(e) {
  var r = F();
  return l.useEffect(() => (r(xj(e)), () => {
    r(Pj(e));
  })), null;
}
function $j(e) {
  var {
    xAxisId: r,
    yAxisId: t,
    shape: a,
    className: n,
    ifOverflow: i
  } = e, o = te(), u = tl(), s = k((w) => ur(w, r)), c = k((w) => sr(w, t)), d = k((w) => ar(w, "xAxis", r, o)), v = k((w) => ar(w, "yAxis", t, o)), f = pt();
  if (!u || !f || s == null || c == null || d == null || v == null)
    return null;
  var p = rl({
    x: d,
    y: v
  }), m = Dj(p, f, e.position, s.orientation, c.orientation, e);
  if (!m)
    return null;
  var [{
    x: h,
    y: g
  }, {
    x: y,
    y: b
  }] = m, x = i === "hidden" ? "url(#".concat(u, ")") : void 0, O = _s(_s({
    clipPath: x
  }, le(e)), {}, {
    x1: h,
    y1: g,
    x2: y,
    y2: b
  }), P = vj({
    x1: h,
    y1: g,
    x2: y,
    y2: b
  });
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-reference-line", n)
  }, Sj(a, O), /* @__PURE__ */ l.createElement(Bn, nn({}, P, {
    lowerWidth: P.width,
    upperWidth: P.width
  }), /* @__PURE__ */ l.createElement(Kn, {
    label: e.label
  }), e.children)));
}
var Lj = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  fill: "none",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1,
  position: "middle",
  zIndex: Y.line
};
function Mj(e) {
  var r = V(e, Lj);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Tj, {
    yAxisId: r.yAxisId,
    xAxisId: r.xAxisId,
    ifOverflow: r.ifOverflow,
    x: r.x,
    y: r.y,
    segment: r.segment
  }), /* @__PURE__ */ l.createElement($j, r));
}
Mj.displayName = "ReferenceLine";
function Ns(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Rs(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ns(Object(t), !0).forEach(function(a) {
      _j(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ns(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function _j(e, r, t) {
  return (r = Nj(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Nj(e) {
  var r = Rj(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Rj(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function _i() {
  return _i = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, _i.apply(null, arguments);
}
var Bj = (e, r, t, a, n) => {
  var i = we(e), o = we(r), u = te(), s = k((f) => ar(f, "xAxis", t, u)), c = k((f) => ar(f, "yAxis", a, u));
  if (!i || !o || s == null || c == null)
    return null;
  var d = rl({
    x: s,
    y: c
  }), v = d.apply({
    x: e,
    y: r
  }, {
    bandAware: !0
  });
  return n === "discard" && !d.isInRange(v) ? null : v;
};
function Kj(e) {
  var r = F();
  return l.useEffect(() => (r(hj(e)), () => {
    r(yj(e));
  })), null;
}
var zj = (e, r) => {
  var t;
  return /* @__PURE__ */ l.isValidElement(e) ? t = /* @__PURE__ */ l.cloneElement(e, r) : typeof e == "function" ? t = e(r) : t = /* @__PURE__ */ l.createElement(zn, _i({}, r, {
    cx: r.cx,
    cy: r.cy,
    className: "recharts-reference-dot-dot"
  })), t;
};
function Wj(e) {
  var {
    x: r,
    y: t,
    r: a
  } = e, n = tl(), i = Bj(r, t, e.xAxisId, e.yAxisId, e.ifOverflow);
  if (!i)
    return null;
  var {
    x: o,
    y: u
  } = i, {
    shape: s,
    className: c,
    ifOverflow: d
  } = e, v = d === "hidden" ? "url(#".concat(n, ")") : void 0, f = Rs(Rs({
    clipPath: v
  }, le(e)), {}, {
    cx: o,
    cy: u
  });
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-reference-dot", c)
  }, zj(s, f), /* @__PURE__ */ l.createElement(Bn, {
    x: o - a,
    y: u - a,
    width: 2 * a,
    height: 2 * a,
    upperWidth: 2 * a,
    lowerWidth: 2 * a
  }, /* @__PURE__ */ l.createElement(Kn, {
    label: e.label
  }), e.children)));
}
var Fj = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  r: 10,
  fill: "#fff",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1,
  zIndex: Y.scatter
};
function Xj(e) {
  var r = V(e, Fj), {
    x: t,
    y: a,
    r: n,
    ifOverflow: i,
    yAxisId: o,
    xAxisId: u
  } = r;
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Kj, {
    y: a,
    x: t,
    r: n,
    yAxisId: o,
    xAxisId: u,
    ifOverflow: i
  }), /* @__PURE__ */ l.createElement(Wj, r));
}
Xj.displayName = "ReferenceDot";
function Bs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ks(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Bs(Object(t), !0).forEach(function(a) {
      Vj(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Bs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function Vj(e, r, t) {
  return (r = Gj(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Gj(e) {
  var r = Hj(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Hj(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function on() {
  return on = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, on.apply(null, arguments);
}
var Yj = (e, r, t, a, n, i, o) => {
  var {
    x1: u,
    x2: s,
    y1: c,
    y2: d
  } = o;
  if (n == null || i == null)
    return null;
  var v = rl({
    x: n,
    y: i
  }), f = {
    x: e ? v.x.apply(u, {
      position: "start"
    }) : v.x.rangeMin,
    y: t ? v.y.apply(c, {
      position: "start"
    }) : v.y.rangeMin
  }, p = {
    x: r ? v.x.apply(s, {
      position: "end"
    }) : v.x.rangeMax,
    y: a ? v.y.apply(d, {
      position: "end"
    }) : v.y.rangeMax
  };
  return o.ifOverflow === "discard" && (!v.isInRange(f) || !v.isInRange(p)) ? null : ff(f, p);
}, Uj = (e, r) => {
  var t;
  return /* @__PURE__ */ l.isValidElement(e) ? t = /* @__PURE__ */ l.cloneElement(e, r) : typeof e == "function" ? t = e(r) : t = /* @__PURE__ */ l.createElement(oa, on({}, r, {
    className: "recharts-reference-area-rect"
  })), t;
};
function Zj(e) {
  var r = F();
  return l.useEffect(() => (r(gj(e)), () => {
    r(bj(e));
  })), null;
}
function qj(e) {
  var {
    x1: r,
    x2: t,
    y1: a,
    y2: n,
    className: i,
    shape: o,
    xAxisId: u,
    yAxisId: s
  } = e, c = tl(), d = te(), v = k((O) => ar(O, "xAxis", u, d)), f = k((O) => ar(O, "yAxis", s, d));
  if (v == null || f == null)
    return null;
  var p = we(r), m = we(t), h = we(a), g = we(n);
  if (!p && !m && !h && !g && !o)
    return null;
  var y = Yj(p, m, h, g, v, f, e);
  if (!y && !o)
    return null;
  var b = e.ifOverflow === "hidden", x = b ? "url(#".concat(c, ")") : void 0;
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-reference-area", i)
  }, Uj(o, Ks(Ks({
    clipPath: x
  }, le(e)), y)), y != null && /* @__PURE__ */ l.createElement(Bn, on({}, y, {
    lowerWidth: y.width,
    upperWidth: y.width
  }), /* @__PURE__ */ l.createElement(Kn, {
    label: e.label
  }), e.children)));
}
var Jj = {
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  radius: 0,
  fill: "#ccc",
  fillOpacity: 0.5,
  stroke: "none",
  strokeWidth: 1,
  zIndex: Y.area
};
function Qj(e) {
  var r = V(e, Jj);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Zj, {
    yAxisId: r.yAxisId,
    xAxisId: r.xAxisId,
    ifOverflow: r.ifOverflow,
    x1: r.x1,
    x2: r.x2,
    y1: r.y1,
    y2: r.y2
  }), /* @__PURE__ */ l.createElement(qj, r));
}
Qj.displayName = "ReferenceArea";
function hf(e, r) {
  if (r < 1)
    return [];
  if (r === 1)
    return e;
  for (var t = [], a = 0; a < e.length; a += r) {
    var n = e[a];
    n !== void 0 && t.push(n);
  }
  return t;
}
function eS(e, r, t) {
  var a = {
    width: e.width + r.width,
    height: e.height + r.height
  };
  return pj(a, t);
}
function rS(e, r, t) {
  var a = t === "width", {
    x: n,
    y: i,
    width: o,
    height: u
  } = e;
  return r === 1 ? {
    start: a ? n : i,
    end: a ? n + o : i + u
  } : {
    start: a ? n + o : i + u,
    end: a ? n : i
  };
}
function Ht(e, r, t, a, n) {
  if (e * r < e * a || e * r > e * n)
    return !1;
  var i = t();
  return e * (r - e * i / 2 - a) >= 0 && e * (r + e * i / 2 - n) <= 0;
}
function tS(e, r) {
  return hf(e, r + 1);
}
function aS(e, r, t, a, n) {
  for (var i = (a || []).slice(), {
    start: o,
    end: u
  } = r, s = 0, c = 1, d = o, v = function() {
    var m = a == null ? void 0 : a[s];
    if (m === void 0)
      return {
        v: hf(a, c)
      };
    var h = s, g, y = () => (g === void 0 && (g = t(m, h)), g), b = m.coordinate, x = s === 0 || Ht(e, b, y, d, u);
    x || (s = 0, d = o, c += 1), x && (d = b + e * (y() / 2 + n), s += c);
  }, f; c <= i.length; )
    if (f = v(), f) return f.v;
  return [];
}
function nS(e, r, t, a, n) {
  var i = (a || []).slice(), o = i.length;
  if (o === 0)
    return [];
  for (var {
    start: u,
    end: s
  } = r, c = 1; c <= o; c++) {
    for (var d = (o - 1) % c, v = u, f = !0, p = function() {
      var b = a[m], x = m, O, P = () => (O === void 0 && (O = t(b, x)), O), w = b.coordinate, E = m === d || Ht(e, w, P, v, s);
      if (!E)
        return f = !1, 1;
      E && (v = w + e * (P() / 2 + n));
    }, m = d; m < o && !p(); m += c)
      ;
    if (f) {
      for (var h = [], g = d; g < o; g += c)
        h.push(a[g]);
      return h;
    }
  }
  return [];
}
function zs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Se(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? zs(Object(t), !0).forEach(function(a) {
      iS(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : zs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function iS(e, r, t) {
  return (r = oS(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function oS(e) {
  var r = lS(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function lS(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function uS(e, r, t, a, n) {
  for (var i = (a || []).slice(), o = i.length, {
    start: u
  } = r, {
    end: s
  } = r, c = function(f) {
    var p = i[f], m, h = () => (m === void 0 && (m = t(p, f)), m);
    if (f === o - 1) {
      var g = e * (p.coordinate + e * h() / 2 - s);
      i[f] = p = Se(Se({}, p), {}, {
        tickCoord: g > 0 ? p.coordinate - g * e : p.coordinate
      });
    } else
      i[f] = p = Se(Se({}, p), {}, {
        tickCoord: p.coordinate
      });
    if (p.tickCoord != null) {
      var y = Ht(e, p.tickCoord, h, u, s);
      y && (s = p.tickCoord - e * (h() / 2 + n), i[f] = Se(Se({}, p), {}, {
        isShow: !0
      }));
    }
  }, d = o - 1; d >= 0; d--)
    c(d);
  return i;
}
function sS(e, r, t, a, n, i) {
  var o = (a || []).slice(), u = o.length, {
    start: s,
    end: c
  } = r;
  if (i) {
    var d = a[u - 1], v = t(d, u - 1), f = e * (d.coordinate + e * v / 2 - c);
    if (o[u - 1] = d = Se(Se({}, d), {}, {
      tickCoord: f > 0 ? d.coordinate - f * e : d.coordinate
    }), d.tickCoord != null) {
      var p = Ht(e, d.tickCoord, () => v, s, c);
      p && (c = d.tickCoord - e * (v / 2 + n), o[u - 1] = Se(Se({}, d), {}, {
        isShow: !0
      }));
    }
  }
  for (var m = i ? u - 1 : u, h = function(b) {
    var x = o[b], O, P = () => (O === void 0 && (O = t(x, b)), O);
    if (b === 0) {
      var w = e * (x.coordinate - e * P() / 2 - s);
      o[b] = x = Se(Se({}, x), {}, {
        tickCoord: w < 0 ? x.coordinate - w * e : x.coordinate
      });
    } else
      o[b] = x = Se(Se({}, x), {}, {
        tickCoord: x.coordinate
      });
    if (x.tickCoord != null) {
      var E = Ht(e, x.tickCoord, P, s, c);
      E && (s = x.tickCoord + e * (P() / 2 + n), o[b] = Se(Se({}, x), {}, {
        isShow: !0
      }));
    }
  }, g = 0; g < m; g++)
    h(g);
  return o;
}
function al(e, r, t) {
  var {
    tick: a,
    ticks: n,
    viewBox: i,
    minTickGap: o,
    orientation: u,
    interval: s,
    tickFormatter: c,
    unit: d,
    angle: v
  } = e;
  if (!n || !n.length || !a)
    return [];
  if (L(s) || mt.isSsr) {
    var f;
    return (f = tS(n, L(s) ? s : 0)) !== null && f !== void 0 ? f : [];
  }
  var p = [], m = u === "top" || u === "bottom" ? "width" : "height", h = d && m === "width" ? nt(d, {
    fontSize: r,
    letterSpacing: t
  }) : {
    width: 0,
    height: 0
  }, g = (x, O) => {
    var P = typeof c == "function" ? c(x.value, O) : x.value;
    return m === "width" ? eS(nt(P, {
      fontSize: r,
      letterSpacing: t
    }), h, v) : nt(P, {
      fontSize: r,
      letterSpacing: t
    })[m];
  }, y = n.length >= 2 ? me(n[1].coordinate - n[0].coordinate) : 1, b = rS(i, y, m);
  return s === "equidistantPreserveStart" ? aS(y, b, g, n, o) : s === "equidistantPreserveEnd" ? nS(y, b, g, n, o) : (s === "preserveStart" || s === "preserveStartEnd" ? p = sS(y, b, g, n, o, s === "preserveStartEnd") : p = uS(y, b, g, n, o), p.filter((x) => x.isShow));
}
var cS = (e) => {
  var {
    ticks: r,
    label: t,
    labelGapWithTick: a = 5,
    // Default gap between label and tick
    tickSize: n = 0,
    tickMargin: i = 0
  } = e, o = 0;
  if (r) {
    Array.from(r).forEach((d) => {
      if (d) {
        var v = d.getBoundingClientRect();
        v.width > o && (o = v.width);
      }
    });
    var u = t ? t.getBoundingClientRect().width : 0, s = n + i, c = o + s + u + (t ? a : 0);
    return Math.round(c);
  }
  return 0;
}, dS = ["axisLine", "width", "height", "className", "hide", "ticks", "axisType"];
function vS(e, r) {
  if (e == null) return {};
  var t, a, n = fS(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function fS(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Vr() {
  return Vr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Vr.apply(null, arguments);
}
function Ws(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function pe(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ws(Object(t), !0).forEach(function(a) {
      pS(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ws(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function pS(e, r, t) {
  return (r = mS(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function mS(e) {
  var r = hS(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function hS(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var br = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  viewBox: {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  // The orientation of axis
  orientation: "bottom",
  // The ticks
  ticks: [],
  stroke: "#666",
  tickLine: !0,
  axisLine: !0,
  tick: !0,
  mirror: !1,
  minTickGap: 5,
  // The width or height of tick
  tickSize: 6,
  tickMargin: 2,
  interval: "preserveEnd",
  zIndex: Y.axis
};
function yS(e) {
  var {
    x: r,
    y: t,
    width: a,
    height: n,
    orientation: i,
    mirror: o,
    axisLine: u,
    otherSvgProps: s
  } = e;
  if (!u)
    return null;
  var c = pe(pe(pe({}, s), G(u)), {}, {
    fill: "none"
  });
  if (i === "top" || i === "bottom") {
    var d = +(i === "top" && !o || i === "bottom" && o);
    c = pe(pe({}, c), {}, {
      x1: r,
      y1: t + d * n,
      x2: r + a,
      y2: t + d * n
    });
  } else {
    var v = +(i === "left" && !o || i === "right" && o);
    c = pe(pe({}, c), {}, {
      x1: r + v * a,
      y1: t,
      x2: r + v * a,
      y2: t + n
    });
  }
  return /* @__PURE__ */ l.createElement("line", Vr({}, c, {
    className: R("recharts-cartesian-axis-line", tr(u, "className"))
  }));
}
function gS(e, r, t, a, n, i, o, u, s) {
  var c, d, v, f, p, m, h = u ? -1 : 1, g = e.tickSize || o, y = L(e.tickCoord) ? e.tickCoord : e.coordinate;
  switch (i) {
    case "top":
      c = d = e.coordinate, f = t + +!u * n, v = f - h * g, m = v - h * s, p = y;
      break;
    case "left":
      v = f = e.coordinate, d = r + +!u * a, c = d - h * g, p = c - h * s, m = y;
      break;
    case "right":
      v = f = e.coordinate, d = r + +u * a, c = d + h * g, p = c + h * s, m = y;
      break;
    default:
      c = d = e.coordinate, f = t + +u * n, v = f + h * g, m = v + h * s, p = y;
      break;
  }
  return {
    line: {
      x1: c,
      y1: v,
      x2: d,
      y2: f
    },
    tick: {
      x: p,
      y: m
    }
  };
}
function bS(e, r) {
  switch (e) {
    case "left":
      return r ? "start" : "end";
    case "right":
      return r ? "end" : "start";
    default:
      return "middle";
  }
}
function xS(e, r) {
  switch (e) {
    case "left":
    case "right":
      return "middle";
    case "top":
      return r ? "start" : "end";
    default:
      return r ? "end" : "start";
  }
}
function PS(e) {
  var {
    option: r,
    tickProps: t,
    value: a
  } = e, n, i = R(t.className, "recharts-cartesian-axis-tick-value");
  if (/* @__PURE__ */ l.isValidElement(r))
    n = /* @__PURE__ */ l.cloneElement(r, pe(pe({}, t), {}, {
      className: i
    }));
  else if (typeof r == "function")
    n = r(pe(pe({}, t), {}, {
      className: i
    }));
  else {
    var o = "recharts-cartesian-axis-tick-value";
    typeof r != "boolean" && (o = R(o, r == null ? void 0 : r.className)), n = /* @__PURE__ */ l.createElement(Tr, Vr({}, t, {
      className: o
    }), a);
  }
  return n;
}
var OS = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    ticks: t = [],
    tick: a,
    tickLine: n,
    stroke: i,
    tickFormatter: o,
    unit: u,
    padding: s,
    tickTextProps: c,
    orientation: d,
    mirror: v,
    x: f,
    y: p,
    width: m,
    height: h,
    tickSize: g,
    tickMargin: y,
    fontSize: b,
    letterSpacing: x,
    getTicksConfig: O,
    events: P,
    axisType: w
  } = e, E = al(pe(pe({}, O), {}, {
    ticks: t
  }), b, x), j = bS(d, v), S = xS(d, v), I = G(O), D = ze(a), C = {};
  typeof n == "object" && (C = n);
  var M = pe(pe({}, I), {}, {
    fill: "none"
  }, C), T = E.map((X) => pe({
    entry: X
  }, gS(X, f, p, m, h, d, g, v, y))), $ = T.map((X) => {
    var {
      entry: Z,
      line: z
    } = X;
    return /* @__PURE__ */ l.createElement(_, {
      className: "recharts-cartesian-axis-tick",
      key: "tick-".concat(Z.value, "-").concat(Z.coordinate, "-").concat(Z.tickCoord)
    }, n && /* @__PURE__ */ l.createElement("line", Vr({}, M, z, {
      className: R("recharts-cartesian-axis-tick-line", tr(n, "className"))
    })));
  }), W = T.map((X, Z) => {
    var {
      entry: z,
      tick: ne
    } = X, ge = pe(pe(pe(pe({
      // @ts-expect-error textAnchor from axisProps is typed as `string` but Text wants type `TextAnchor`
      textAnchor: j,
      verticalAnchor: S
    }, I), {}, {
      // @ts-expect-error customTickProps is contributing unknown props
      stroke: "none",
      // @ts-expect-error customTickProps is contributing unknown props
      fill: i
    }, D), ne), {}, {
      index: Z,
      payload: z,
      visibleTicksCount: E.length,
      tickFormatter: o,
      padding: s
    }, c);
    return /* @__PURE__ */ l.createElement(_, Vr({
      className: "recharts-cartesian-axis-tick-label",
      key: "tick-label-".concat(z.value, "-").concat(z.coordinate, "-").concat(z.tickCoord)
    }, Ue(P, z, Z)), a && /* @__PURE__ */ l.createElement(PS, {
      option: a,
      tickProps: ge,
      value: "".concat(typeof o == "function" ? o(z.value, Z) : z.value).concat(u || "")
    }));
  });
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-axis-ticks recharts-".concat(w, "-ticks")
  }, W.length > 0 && /* @__PURE__ */ l.createElement(ee, {
    zIndex: Y.label
  }, /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-axis-tick-labels recharts-".concat(w, "-tick-labels"),
    ref: r
  }, W)), $.length > 0 && /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-axis-tick-lines recharts-".concat(w, "-tick-lines")
  }, $));
}), wS = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    axisLine: t,
    width: a,
    height: n,
    className: i,
    hide: o,
    ticks: u,
    axisType: s
  } = e, c = vS(e, dS), [d, v] = l.useState(""), [f, p] = l.useState(""), m = l.useRef(null);
  l.useImperativeHandle(r, () => ({
    getCalculatedWidth: () => {
      var g;
      return cS({
        ticks: m.current,
        label: (g = e.labelRef) === null || g === void 0 ? void 0 : g.current,
        labelGapWithTick: 5,
        tickSize: e.tickSize,
        tickMargin: e.tickMargin
      });
    }
  }));
  var h = l.useCallback((g) => {
    if (g) {
      var y = g.getElementsByClassName("recharts-cartesian-axis-tick-value");
      m.current = y;
      var b = y[0];
      if (b) {
        var x = window.getComputedStyle(b), O = x.fontSize, P = x.letterSpacing;
        (O !== d || P !== f) && (v(O), p(P));
      }
    }
  }, [d, f]);
  return o || a != null && a <= 0 || n != null && n <= 0 ? null : /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: R("recharts-cartesian-axis", i)
  }, /* @__PURE__ */ l.createElement(yS, {
    x: e.x,
    y: e.y,
    width: a,
    height: n,
    orientation: e.orientation,
    mirror: e.mirror,
    axisLine: t,
    otherSvgProps: G(e)
  }), /* @__PURE__ */ l.createElement(OS, {
    ref: h,
    axisType: s,
    events: c,
    fontSize: d,
    getTicksConfig: e,
    height: e.height,
    letterSpacing: f,
    mirror: e.mirror,
    orientation: e.orientation,
    padding: e.padding,
    stroke: e.stroke,
    tick: e.tick,
    tickFormatter: e.tickFormatter,
    tickLine: e.tickLine,
    tickMargin: e.tickMargin,
    tickSize: e.tickSize,
    tickTextProps: e.tickTextProps,
    ticks: u,
    unit: e.unit,
    width: e.width,
    x: e.x,
    y: e.y
  }), /* @__PURE__ */ l.createElement(Bn, {
    x: e.x,
    y: e.y,
    width: e.width,
    height: e.height,
    lowerWidth: e.width,
    upperWidth: e.width
  }, /* @__PURE__ */ l.createElement(Kn, {
    label: e.label,
    labelRef: e.labelRef
  }), e.children)));
}), nl = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = V(e, br);
  return /* @__PURE__ */ l.createElement(wS, Vr({}, t, {
    ref: r
  }));
});
nl.displayName = "CartesianAxis";
var AS = ["x1", "y1", "x2", "y2", "key"], ES = ["offset"], jS = ["xAxisId", "yAxisId"], SS = ["xAxisId", "yAxisId"];
function Fs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ke(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Fs(Object(t), !0).forEach(function(a) {
      IS(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Fs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function IS(e, r, t) {
  return (r = kS(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function kS(e) {
  var r = CS(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function CS(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Kr() {
  return Kr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Kr.apply(null, arguments);
}
function ln(e, r) {
  if (e == null) return {};
  var t, a, n = DS(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function DS(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var TS = (e) => {
  var {
    fill: r
  } = e;
  if (!r || r === "none")
    return null;
  var {
    fillOpacity: t,
    x: a,
    y: n,
    width: i,
    height: o,
    ry: u
  } = e;
  return /* @__PURE__ */ l.createElement("rect", {
    x: a,
    y: n,
    ry: u,
    width: i,
    height: o,
    stroke: "none",
    fill: r,
    fillOpacity: t,
    className: "recharts-cartesian-grid-bg"
  });
};
function yf(e) {
  var {
    option: r,
    lineItemProps: t
  } = e, a;
  if (/* @__PURE__ */ l.isValidElement(r))
    a = /* @__PURE__ */ l.cloneElement(r, t);
  else if (typeof r == "function")
    a = r(t);
  else {
    var n, {
      x1: i,
      y1: o,
      x2: u,
      y2: s,
      key: c
    } = t, d = ln(t, AS), v = (n = G(d)) !== null && n !== void 0 ? n : {}, {
      offset: f
    } = v, p = ln(v, ES);
    a = /* @__PURE__ */ l.createElement("line", Kr({}, p, {
      x1: i,
      y1: o,
      x2: u,
      y2: s,
      fill: "none",
      key: c
    }));
  }
  return a;
}
function $S(e) {
  var {
    x: r,
    width: t,
    horizontal: a = !0,
    horizontalPoints: n
  } = e;
  if (!a || !n || !n.length)
    return null;
  var {
    xAxisId: i,
    yAxisId: o
  } = e, u = ln(e, jS), s = n.map((c, d) => {
    var v = ke(ke({}, u), {}, {
      x1: r,
      y1: c,
      x2: r + t,
      y2: c,
      key: "line-".concat(d),
      index: d
    });
    return /* @__PURE__ */ l.createElement(yf, {
      key: "line-".concat(d),
      option: a,
      lineItemProps: v
    });
  });
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-grid-horizontal"
  }, s);
}
function LS(e) {
  var {
    y: r,
    height: t,
    vertical: a = !0,
    verticalPoints: n
  } = e;
  if (!a || !n || !n.length)
    return null;
  var {
    xAxisId: i,
    yAxisId: o
  } = e, u = ln(e, SS), s = n.map((c, d) => {
    var v = ke(ke({}, u), {}, {
      x1: c,
      y1: r,
      x2: c,
      y2: r + t,
      key: "line-".concat(d),
      index: d
    });
    return /* @__PURE__ */ l.createElement(yf, {
      option: a,
      lineItemProps: v,
      key: "line-".concat(d)
    });
  });
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-grid-vertical"
  }, s);
}
function MS(e) {
  var {
    horizontalFill: r,
    fillOpacity: t,
    x: a,
    y: n,
    width: i,
    height: o,
    horizontalPoints: u,
    horizontal: s = !0
  } = e;
  if (!s || !r || !r.length || u == null)
    return null;
  var c = u.map((v) => Math.round(v + n - n)).sort((v, f) => v - f);
  n !== c[0] && c.unshift(0);
  var d = c.map((v, f) => {
    var p = !c[f + 1], m = p ? n + o - v : c[f + 1] - v;
    if (m <= 0)
      return null;
    var h = f % r.length;
    return /* @__PURE__ */ l.createElement("rect", {
      key: "react-".concat(f),
      y: v,
      x: a,
      height: m,
      width: i,
      stroke: "none",
      fill: r[h],
      fillOpacity: t,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-gridstripes-horizontal"
  }, d);
}
function _S(e) {
  var {
    vertical: r = !0,
    verticalFill: t,
    fillOpacity: a,
    x: n,
    y: i,
    width: o,
    height: u,
    verticalPoints: s
  } = e;
  if (!r || !t || !t.length)
    return null;
  var c = s.map((v) => Math.round(v + n - n)).sort((v, f) => v - f);
  n !== c[0] && c.unshift(0);
  var d = c.map((v, f) => {
    var p = !c[f + 1], m = p ? n + o - v : c[f + 1] - v;
    if (m <= 0)
      return null;
    var h = f % t.length;
    return /* @__PURE__ */ l.createElement("rect", {
      key: "react-".concat(f),
      x: v,
      y: i,
      width: m,
      height: u,
      stroke: "none",
      fill: t[h],
      fillOpacity: a,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-gridstripes-vertical"
  }, d);
}
var NS = (e, r) => {
  var {
    xAxis: t,
    width: a,
    height: n,
    offset: i
  } = e;
  return Nc(al(ke(ke(ke({}, br), t), {}, {
    ticks: Rc(t),
    viewBox: {
      x: 0,
      y: 0,
      width: a,
      height: n
    }
  })), i.left, i.left + i.width, r);
}, RS = (e, r) => {
  var {
    yAxis: t,
    width: a,
    height: n,
    offset: i
  } = e;
  return Nc(al(ke(ke(ke({}, br), t), {}, {
    ticks: Rc(t),
    viewBox: {
      x: 0,
      y: 0,
      width: a,
      height: n
    }
  })), i.top, i.top + i.height, r);
}, BS = {
  horizontal: !0,
  vertical: !0,
  // The ordinates of horizontal grid lines
  horizontalPoints: [],
  // The abscissas of vertical grid lines
  verticalPoints: [],
  stroke: "#ccc",
  fill: "none",
  // The fill of colors of grid lines
  verticalFill: [],
  horizontalFill: [],
  xAxisId: 0,
  yAxisId: 0,
  syncWithTicks: !1,
  zIndex: Y.grid
};
function KS(e) {
  var r = aa(), t = na(), a = Hc(), n = ke(ke({}, V(e, BS)), {}, {
    x: L(e.x) ? e.x : a.left,
    y: L(e.y) ? e.y : a.top,
    width: L(e.width) ? e.width : a.width,
    height: L(e.height) ? e.height : a.height
  }), {
    xAxisId: i,
    yAxisId: o,
    x: u,
    y: s,
    width: c,
    height: d,
    syncWithTicks: v,
    horizontalValues: f,
    verticalValues: p
  } = n, m = te(), h = k((S) => hu(S, "xAxis", i, m)), g = k((S) => hu(S, "yAxis", o, m));
  if (!_e(c) || !_e(d) || !L(u) || !L(s))
    return null;
  var y = n.verticalCoordinatesGenerator || NS, b = n.horizontalCoordinatesGenerator || RS, {
    horizontalPoints: x,
    verticalPoints: O
  } = n;
  if ((!x || !x.length) && typeof b == "function") {
    var P = f && f.length, w = b({
      yAxis: g ? ke(ke({}, g), {}, {
        ticks: P ? f : g.ticks
      }) : void 0,
      width: r ?? c,
      height: t ?? d,
      offset: a
    }, P ? !0 : v);
    Ba(Array.isArray(w), "horizontalCoordinatesGenerator should return Array but instead it returned [".concat(typeof w, "]")), Array.isArray(w) && (x = w);
  }
  if ((!O || !O.length) && typeof y == "function") {
    var E = p && p.length, j = y({
      xAxis: h ? ke(ke({}, h), {}, {
        ticks: E ? p : h.ticks
      }) : void 0,
      width: r ?? c,
      height: t ?? d,
      offset: a
    }, E ? !0 : v);
    Ba(Array.isArray(j), "verticalCoordinatesGenerator should return Array but instead it returned [".concat(typeof j, "]")), Array.isArray(j) && (O = j);
  }
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: n.zIndex
  }, /* @__PURE__ */ l.createElement("g", {
    className: "recharts-cartesian-grid"
  }, /* @__PURE__ */ l.createElement(TS, {
    fill: n.fill,
    fillOpacity: n.fillOpacity,
    x: n.x,
    y: n.y,
    width: n.width,
    height: n.height,
    ry: n.ry
  }), /* @__PURE__ */ l.createElement(MS, Kr({}, n, {
    horizontalPoints: x
  })), /* @__PURE__ */ l.createElement(_S, Kr({}, n, {
    verticalPoints: O
  })), /* @__PURE__ */ l.createElement($S, Kr({}, n, {
    offset: a,
    horizontalPoints: x,
    xAxis: h,
    yAxis: g
  })), /* @__PURE__ */ l.createElement(LS, Kr({}, n, {
    offset: a,
    verticalPoints: O,
    xAxis: h,
    yAxis: g
  }))));
}
KS.displayName = "CartesianGrid";
var zS = {}, gf = Be({
  name: "errorBars",
  initialState: zS,
  reducers: {
    addErrorBar: (e, r) => {
      var {
        itemId: t,
        errorBar: a
      } = r.payload;
      e[t] || (e[t] = []), e[t].push(a);
    },
    replaceErrorBar: (e, r) => {
      var {
        itemId: t,
        prev: a,
        next: n
      } = r.payload;
      e[t] && (e[t] = e[t].map((i) => i.dataKey === a.dataKey && i.direction === a.direction ? n : i));
    },
    removeErrorBar: (e, r) => {
      var {
        itemId: t,
        errorBar: a
      } = r.payload;
      e[t] && (e[t] = e[t].filter((n) => n.dataKey !== a.dataKey || n.direction !== a.direction));
    }
  }
}), {
  addErrorBar: WS,
  replaceErrorBar: FS,
  removeErrorBar: XS
} = gf.actions, VS = gf.reducer, GS = ["children"];
function HS(e, r) {
  if (e == null) return {};
  var t, a, n = YS(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function YS(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var US = {
  data: [],
  xAxisId: "xAxis-0",
  yAxisId: "yAxis-0",
  dataPointFormatter: () => ({
    x: 0,
    y: 0,
    value: 0
  }),
  errorBarOffset: 0
}, bf = /* @__PURE__ */ l.createContext(US);
function il(e) {
  var {
    children: r
  } = e, t = HS(e, GS);
  return /* @__PURE__ */ l.createElement(bf.Provider, {
    value: t
  }, r);
}
var ZS = () => l.useContext(bf);
function qS(e) {
  var r = F(), t = nw(), a = l.useRef(null);
  return l.useEffect(() => {
    t != null && (a.current === null ? r(WS({
      itemId: t,
      errorBar: e
    })) : a.current !== e && r(FS({
      itemId: t,
      prev: a.current,
      next: e
    })), a.current = e);
  }, [r, t, e]), l.useEffect(() => () => {
    a.current != null && t != null && (r(XS({
      itemId: t,
      errorBar: a.current
    })), a.current = null);
  }, [r, t]), null;
}
function ba(e, r) {
  var t, a, n = k((c) => ur(c, e)), i = k((c) => sr(c, r)), o = (t = n == null ? void 0 : n.allowDataOverflow) !== null && t !== void 0 ? t : Pe.allowDataOverflow, u = (a = i == null ? void 0 : i.allowDataOverflow) !== null && a !== void 0 ? a : Oe.allowDataOverflow, s = o || u;
  return {
    needClip: s,
    needClipX: o,
    needClipY: u
  };
}
function Un(e) {
  var {
    xAxisId: r,
    yAxisId: t,
    clipPathId: a
  } = e, n = ga(), {
    needClipX: i,
    needClipY: o,
    needClip: u
  } = ba(r, t);
  if (!u || !n)
    return null;
  var {
    x: s,
    y: c,
    width: d,
    height: v
  } = n;
  return /* @__PURE__ */ l.createElement("clipPath", {
    id: "clipPath-".concat(a)
  }, /* @__PURE__ */ l.createElement("rect", {
    x: i ? s : s - d / 2,
    y: o ? c : c - v / 2,
    width: i ? d : d * 2,
    height: o ? v : v * 2
  }));
}
var xf = (e, r, t, a) => Re(e, "xAxis", r, a), Pf = (e, r, t, a) => Ge(e, "xAxis", r, a), Of = (e, r, t, a) => Re(e, "yAxis", t, a), wf = (e, r, t, a) => Ge(e, "yAxis", t, a), JS = A([K, xf, Of, Pf, wf], (e, r, t, a, n) => He(e, "xAxis") ? Ne(r, a, !1) : Ne(t, n, !1)), QS = (e, r, t, a, n) => n;
function eI(e) {
  return e.type === "line";
}
var rI = A([xt, QS], (e, r) => e.filter(eI).find((t) => t.id === r)), tI = A([K, xf, Of, Pf, wf, rI, JS, On], (e, r, t, a, n, i, o, u) => {
  var {
    chartData: s,
    dataStartIndex: c,
    dataEndIndex: d
  } = u;
  if (!(i == null || r == null || t == null || a == null || n == null || a.length === 0 || n.length === 0 || o == null || e !== "horizontal" && e !== "vertical")) {
    var {
      dataKey: v,
      data: f
    } = i, p;
    if (f != null && f.length > 0 ? p = f : p = s == null ? void 0 : s.slice(c, d + 1), p != null)
      return AI({
        layout: e,
        xAxis: r,
        yAxis: t,
        xAxisTicks: a,
        yAxisTicks: n,
        dataKey: v,
        bandSize: o,
        displayedData: p
      });
  }
});
function Af(e) {
  var r = ze(e), t = 3, a = 2;
  if (r != null) {
    var {
      r: n,
      strokeWidth: i
    } = r, o = Number(n), u = Number(i);
    return (Number.isNaN(o) || o < 0) && (o = t), (Number.isNaN(u) || u < 0) && (u = a), {
      r: o,
      strokeWidth: u
    };
  }
  return {
    r: t,
    strokeWidth: a
  };
}
var aI = /* @__PURE__ */ new Set([
  "axisLine",
  "tickLine",
  "activeBar",
  "activeDot",
  "activeLabel",
  "activeShape",
  "allowEscapeViewBox",
  "background",
  "cursor",
  "dot",
  "label",
  "line",
  "margin",
  "padding",
  "position",
  "shape",
  "style",
  "tick",
  "wrapperStyle",
  // radius can be an array of 4 numbers, easy to compare shallowly
  "radius"
]);
function nI(e, r) {
  return e == null && r == null ? !0 : typeof e == "number" && typeof r == "number" ? e === r || e !== e && r !== r : e === r;
}
function Dt(e, r) {
  var t = /* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(r)]);
  for (var a of t)
    if (aI.has(a)) {
      if (e[a] == null && r[a] == null)
        continue;
      if (!Rp(e[a], r[a]))
        return !1;
    } else if (!nI(e[a], r[a]))
      return !1;
  return !0;
}
var iI = ["id"], oI = ["type", "layout", "connectNulls", "needClip", "shape"], lI = ["activeDot", "animateNewValues", "animationBegin", "animationDuration", "animationEasing", "connectNulls", "dot", "hide", "isAnimationActive", "label", "legendType", "xAxisId", "yAxisId", "id"];
function Yt() {
  return Yt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Yt.apply(null, arguments);
}
function Xs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function qe(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Xs(Object(t), !0).forEach(function(a) {
      uI(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Xs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function uI(e, r, t) {
  return (r = sI(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function sI(e) {
  var r = cI(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function cI(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function ol(e, r) {
  if (e == null) return {};
  var t, a, n = dI(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function dI(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var vI = (e) => {
  var {
    dataKey: r,
    name: t,
    stroke: a,
    legendType: n,
    hide: i
  } = e;
  return [{
    inactive: i,
    dataKey: r,
    type: n,
    color: a,
    value: We(t, r),
    payload: e
  }];
}, fI = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    data: t,
    stroke: a,
    strokeWidth: n,
    fill: i,
    name: o,
    hide: u,
    unit: s,
    tooltipType: c,
    id: d
  } = e, v = {
    dataDefinedOnItem: t,
    positions: void 0,
    settings: {
      stroke: a,
      strokeWidth: n,
      fill: i,
      dataKey: r,
      nameKey: void 0,
      name: We(o, r),
      hide: u,
      type: c,
      color: a,
      unit: s,
      graphicalItemId: d
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: v
  });
}), Ef = (e, r) => "".concat(r, "px ").concat(e - r, "px");
function pI(e, r) {
  for (var t = e.length % 2 !== 0 ? [...e, 0] : e, a = [], n = 0; n < r; ++n)
    a = [...a, ...t];
  return a;
}
var mI = (e, r, t) => {
  var a = t.reduce((v, f) => v + f);
  if (!a)
    return Ef(r, e);
  for (var n = Math.floor(e / a), i = e % a, o = r - e, u = [], s = 0, c = 0; s < t.length; c += t[s], ++s)
    if (c + t[s] > i) {
      u = [...t.slice(0, s), i - c];
      break;
    }
  var d = u.length % 2 === 0 ? [0, o] : [o];
  return [...pI(t, n), ...u, ...d].map((v) => "".concat(v, "px")).join(", ");
};
function hI(e) {
  var {
    clipPathId: r,
    points: t,
    props: a
  } = e, {
    dot: n,
    dataKey: i,
    needClip: o
  } = a, {
    id: u
  } = a, s = ol(a, iI), c = G(s);
  return /* @__PURE__ */ l.createElement(Zo, {
    points: t,
    dot: n,
    className: "recharts-line-dots",
    dotClassName: "recharts-line-dot",
    dataKey: i,
    baseProps: c,
    needClip: o,
    clipPathId: r
  });
}
function yI(e) {
  var {
    showLabels: r,
    children: t,
    points: a
  } = e, n = l.useMemo(() => a == null ? void 0 : a.map((i) => {
    var o, u, s = {
      x: (o = i.x) !== null && o !== void 0 ? o : 0,
      y: (u = i.y) !== null && u !== void 0 ? u : 0,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return qe(qe({}, s), {}, {
      value: i.value,
      payload: i.payload,
      viewBox: s,
      /*
       * Line is not passing parentViewBox to the LabelList so the labels can escape - looks like a bug, should we pass parentViewBox?
       * Or should this just be the root chart viewBox?
       */
      parentViewBox: void 0,
      fill: void 0
    });
  }), [a]);
  return /* @__PURE__ */ l.createElement(jt, {
    value: r ? n : void 0
  }, t);
}
function Vs(e) {
  var {
    clipPathId: r,
    pathRef: t,
    points: a,
    strokeDasharray: n,
    props: i
  } = e, {
    type: o,
    layout: u,
    connectNulls: s,
    needClip: c,
    shape: d
  } = i, v = ol(i, oI), f = qe(qe({}, le(v)), {}, {
    fill: "none",
    className: "recharts-line-curve",
    clipPath: c ? "url(#clipPath-".concat(r, ")") : void 0,
    points: a,
    type: o,
    layout: u,
    connectNulls: s,
    strokeDasharray: n ?? i.strokeDasharray
  });
  return /* @__PURE__ */ l.createElement(l.Fragment, null, (a == null ? void 0 : a.length) > 1 && /* @__PURE__ */ l.createElement(Xr, Yt({
    shapeType: "curve",
    option: d
  }, f, {
    pathRef: t
  })), /* @__PURE__ */ l.createElement(hI, {
    points: a,
    clipPathId: r,
    props: i
  }));
}
function gI(e) {
  try {
    return e && e.getTotalLength && e.getTotalLength() || 0;
  } catch {
    return 0;
  }
}
function bI(e) {
  var {
    clipPathId: r,
    props: t,
    pathRef: a,
    previousPointsRef: n,
    longestAnimatedLengthRef: i
  } = e, {
    points: o,
    strokeDasharray: u,
    isAnimationActive: s,
    animationBegin: c,
    animationDuration: d,
    animationEasing: v,
    animateNewValues: f,
    width: p,
    height: m,
    onAnimationEnd: h,
    onAnimationStart: g
  } = t, y = n.current, b = or(o, "recharts-line-"), x = l.useRef(b), [O, P] = l.useState(!1), w = !O, E = l.useCallback(() => {
    typeof h == "function" && h(), P(!1);
  }, [h]), j = l.useCallback(() => {
    typeof g == "function" && g(), P(!0);
  }, [g]), S = gI(a.current), I = l.useRef(0);
  x.current !== b && (I.current = i.current, x.current = b);
  var D = I.current;
  return /* @__PURE__ */ l.createElement(yI, {
    points: o,
    showLabels: w
  }, t.children, /* @__PURE__ */ l.createElement(ir, {
    animationId: b,
    begin: c,
    duration: d,
    isActive: s,
    easing: v,
    onAnimationEnd: E,
    onAnimationStart: j,
    key: b
  }, (C) => {
    var M = N(D, S + D, C), T = Math.min(M, S), $;
    if (s)
      if (u) {
        var W = "".concat(u).split(/[,\s]+/gim).map((z) => parseFloat(z));
        $ = mI(T, S, W);
      } else
        $ = Ef(S, T);
    else
      $ = u == null ? void 0 : String(u);
    if (C > 0 && S > 0 && (n.current = o, i.current = Math.max(i.current, T)), y) {
      var X = y.length / o.length, Z = C === 1 ? o : o.map((z, ne) => {
        var ge = Math.floor(ne * X);
        if (y[ge]) {
          var fe = y[ge];
          return qe(qe({}, z), {}, {
            x: N(fe.x, z.x, C),
            y: N(fe.y, z.y, C)
          });
        }
        return f ? qe(qe({}, z), {}, {
          x: N(p * 2, z.x, C),
          y: N(m / 2, z.y, C)
        }) : qe(qe({}, z), {}, {
          x: z.x,
          y: z.y
        });
      });
      return n.current = Z, /* @__PURE__ */ l.createElement(Vs, {
        props: t,
        points: Z,
        clipPathId: r,
        pathRef: a,
        strokeDasharray: $
      });
    }
    return /* @__PURE__ */ l.createElement(Vs, {
      props: t,
      points: o,
      clipPathId: r,
      pathRef: a,
      strokeDasharray: $
    });
  }), /* @__PURE__ */ l.createElement(_r, {
    label: t.label
  }));
}
function xI(e) {
  var {
    clipPathId: r,
    props: t
  } = e, a = l.useRef(null), n = l.useRef(0), i = l.useRef(null);
  return /* @__PURE__ */ l.createElement(bI, {
    props: t,
    clipPathId: r,
    previousPointsRef: a,
    longestAnimatedLengthRef: n,
    pathRef: i
  });
}
var PI = (e, r) => {
  var t, a;
  return {
    x: (t = e.x) !== null && t !== void 0 ? t : void 0,
    y: (a = e.y) !== null && a !== void 0 ? a : void 0,
    value: e.value,
    // @ts-expect-error getValueByDataKey does not validate the output type
    errorVal: B(e.payload, r)
  };
};
class OI extends l.Component {
  render() {
    var {
      hide: r,
      dot: t,
      points: a,
      className: n,
      xAxisId: i,
      yAxisId: o,
      top: u,
      left: s,
      width: c,
      height: d,
      id: v,
      needClip: f,
      zIndex: p
    } = this.props;
    if (r)
      return null;
    var m = R("recharts-line", n), h = v, {
      r: g,
      strokeWidth: y
    } = Af(t), b = Ho(t), x = g * 2 + y, O = f ? "url(#clipPath-".concat(b ? "" : "dots-").concat(h, ")") : void 0;
    return /* @__PURE__ */ l.createElement(ee, {
      zIndex: p
    }, /* @__PURE__ */ l.createElement(_, {
      className: m
    }, f && /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement(Un, {
      clipPathId: h,
      xAxisId: i,
      yAxisId: o
    }), !b && /* @__PURE__ */ l.createElement("clipPath", {
      id: "clipPath-dots-".concat(h)
    }, /* @__PURE__ */ l.createElement("rect", {
      x: s - x / 2,
      y: u - x / 2,
      width: c + x,
      height: d + x
    }))), /* @__PURE__ */ l.createElement(il, {
      xAxisId: i,
      yAxisId: o,
      data: a,
      dataPointFormatter: PI,
      errorBarOffset: 0
    }, /* @__PURE__ */ l.createElement(xI, {
      props: this.props,
      clipPathId: h
    }))), /* @__PURE__ */ l.createElement(en, {
      activeDot: this.props.activeDot,
      points: a,
      mainColor: this.props.stroke,
      itemDataKey: this.props.dataKey,
      clipPath: O
    }));
  }
}
var jf = {
  activeDot: !0,
  animateNewValues: !0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  connectNulls: !1,
  dot: !0,
  fill: "#fff",
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "line",
  stroke: "#3182bd",
  strokeWidth: 1,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: Y.line,
  type: "linear"
};
function wI(e) {
  var r = V(e, jf), {
    activeDot: t,
    animateNewValues: a,
    animationBegin: n,
    animationDuration: i,
    animationEasing: o,
    connectNulls: u,
    dot: s,
    hide: c,
    isAnimationActive: d,
    label: v,
    legendType: f,
    xAxisId: p,
    yAxisId: m,
    id: h
  } = r, g = ol(r, lI), {
    needClip: y
  } = ba(p, m), b = ga(), x = Er(), O = te(), P = k((I) => tI(I, p, m, O, h));
  if (x !== "horizontal" && x !== "vertical" || P == null || b == null)
    return null;
  var {
    height: w,
    width: E,
    x: j,
    y: S
  } = b;
  return /* @__PURE__ */ l.createElement(OI, Yt({}, g, {
    id: h,
    connectNulls: u,
    dot: s,
    activeDot: t,
    animateNewValues: a,
    animationBegin: n,
    animationDuration: i,
    animationEasing: o,
    isAnimationActive: d,
    hide: c,
    label: v,
    legendType: f,
    xAxisId: p,
    yAxisId: m,
    points: P,
    layout: x,
    height: w,
    width: E,
    left: j,
    top: S,
    needClip: y
  }));
}
function AI(e) {
  var {
    layout: r,
    xAxis: t,
    yAxis: a,
    xAxisTicks: n,
    yAxisTicks: i,
    dataKey: o,
    bandSize: u,
    displayedData: s
  } = e;
  return s.map((c, d) => {
    var v = B(c, o);
    if (r === "horizontal") {
      var f = ot({
        axis: t,
        ticks: n,
        bandSize: u,
        entry: c,
        index: d
      }), p = U(v) ? null : a.scale(v);
      return {
        x: f,
        y: p,
        value: v,
        payload: c
      };
    }
    var m = U(v) ? null : t.scale(v), h = ot({
      axis: a,
      ticks: i,
      bandSize: u,
      entry: c,
      index: d
    });
    return m == null || h == null ? null : {
      x: m,
      y: h,
      value: v,
      payload: c
    };
  }).filter(Boolean);
}
function EI(e) {
  var r = V(e, jf), t = te();
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "line"
  }, (a) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Fn, {
    legendPayload: vI(r)
  }), /* @__PURE__ */ l.createElement(fI, {
    dataKey: r.dataKey,
    data: r.data,
    stroke: r.stroke,
    strokeWidth: r.strokeWidth,
    fill: r.fill,
    name: r.name,
    hide: r.hide,
    unit: r.unit,
    tooltipType: r.tooltipType,
    id: a
  }), /* @__PURE__ */ l.createElement(Xn, {
    type: "line",
    id: a,
    data: r.data,
    xAxisId: r.xAxisId,
    yAxisId: r.yAxisId,
    zAxisId: 0,
    dataKey: r.dataKey,
    hide: r.hide,
    isPanorama: t
  }), /* @__PURE__ */ l.createElement(wI, Yt({}, r, {
    id: a
  }))));
}
var jI = /* @__PURE__ */ l.memo(EI, Dt);
jI.displayName = "Line";
function vr(e, r) {
  var t, a;
  return (t = (a = e.graphicalItems.cartesianItems.find((n) => n.id === r)) === null || a === void 0 ? void 0 : a.xAxisId) !== null && t !== void 0 ? t : Uv;
}
function fr(e, r) {
  var t, a;
  return (t = (a = e.graphicalItems.cartesianItems.find((n) => n.id === r)) === null || a === void 0 ? void 0 : a.yAxisId) !== null && t !== void 0 ? t : Uv;
}
var Sf = (e, r, t) => Re(e, "xAxis", vr(e, r), t), If = (e, r, t) => Ge(e, "xAxis", vr(e, r), t), kf = (e, r, t) => Re(e, "yAxis", fr(e, r), t), Cf = (e, r, t) => Ge(e, "yAxis", fr(e, r), t), SI = A([K, Sf, kf, If, Cf], (e, r, t, a, n) => He(e, "xAxis") ? Ne(r, a, !1) : Ne(t, n, !1)), II = (e, r) => r, Df = A([xt, II], (e, r) => e.filter((t) => t.type === "area").find((t) => t.id === r)), Tf = (e) => {
  var r = K(e), t = He(r, "xAxis");
  return t ? "yAxis" : "xAxis";
}, kI = (e, r) => {
  var t = Tf(e);
  return t === "yAxis" ? fr(e, r) : vr(e, r);
}, CI = (e, r, t) => Ha(e, Tf(e), kI(e, r), t), DI = A([Df, CI], (e, r) => {
  var t;
  if (!(e == null || r == null)) {
    var {
      stackId: a
    } = e, n = In(e);
    if (!(a == null || n == null)) {
      var i = (t = r[a]) === null || t === void 0 ? void 0 : t.stackedData, o = i == null ? void 0 : i.find((u) => u.key === n);
      if (o != null)
        return o.map((u) => [u[0], u[1]]);
    }
  }
}), TI = A([K, Sf, kf, If, Cf, DI, sd, SI, Df, pg], (e, r, t, a, n, i, o, u, s, c) => {
  var {
    chartData: d,
    dataStartIndex: v,
    dataEndIndex: f
  } = o;
  if (!(s == null || e !== "horizontal" && e !== "vertical" || r == null || t == null || a == null || n == null || a.length === 0 || n.length === 0 || u == null)) {
    var {
      data: p
    } = s, m;
    if (p && p.length > 0 ? m = p : m = d == null ? void 0 : d.slice(v, f + 1), m != null)
      return qI({
        layout: e,
        xAxis: r,
        yAxis: t,
        xAxisTicks: a,
        yAxisTicks: n,
        dataStartIndex: v,
        areaSettings: s,
        stackedData: i,
        displayedData: m,
        chartBaseValue: c,
        bandSize: u
      });
  }
}), $I = ["id"], LI = ["activeDot", "animationBegin", "animationDuration", "animationEasing", "connectNulls", "dot", "fill", "fillOpacity", "hide", "isAnimationActive", "legendType", "stroke", "xAxisId", "yAxisId"];
function Wr() {
  return Wr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Wr.apply(null, arguments);
}
function $f(e, r) {
  if (e == null) return {};
  var t, a, n = MI(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function MI(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Gs(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function at(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Gs(Object(t), !0).forEach(function(a) {
      _I(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Gs(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function _I(e, r, t) {
  return (r = NI(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function NI(e) {
  var r = RI(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function RI(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function un(e, r) {
  return e && e !== "none" ? e : r;
}
var BI = (e) => {
  var {
    dataKey: r,
    name: t,
    stroke: a,
    fill: n,
    legendType: i,
    hide: o
  } = e;
  return [{
    inactive: o,
    dataKey: r,
    type: i,
    color: un(a, n),
    value: We(t, r),
    payload: e
  }];
}, KI = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    data: t,
    stroke: a,
    strokeWidth: n,
    fill: i,
    name: o,
    hide: u,
    unit: s,
    tooltipType: c,
    id: d
  } = e, v = {
    dataDefinedOnItem: t,
    positions: void 0,
    settings: {
      stroke: a,
      strokeWidth: n,
      fill: i,
      dataKey: r,
      nameKey: void 0,
      name: We(o, r),
      hide: u,
      type: c,
      color: un(a, i),
      unit: s,
      graphicalItemId: d
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: v
  });
});
function zI(e) {
  var {
    clipPathId: r,
    points: t,
    props: a
  } = e, {
    needClip: n,
    dot: i,
    dataKey: o
  } = a, u = G(a);
  return /* @__PURE__ */ l.createElement(Zo, {
    points: t,
    dot: i,
    className: "recharts-area-dots",
    dotClassName: "recharts-area-dot",
    dataKey: o,
    baseProps: u,
    needClip: n,
    clipPathId: r
  });
}
function WI(e) {
  var {
    showLabels: r,
    children: t,
    points: a
  } = e, n = a.map((i) => {
    var o, u, s = {
      x: (o = i.x) !== null && o !== void 0 ? o : 0,
      y: (u = i.y) !== null && u !== void 0 ? u : 0,
      width: 0,
      lowerWidth: 0,
      upperWidth: 0,
      height: 0
    };
    return at(at({}, s), {}, {
      value: i.value,
      payload: i.payload,
      parentViewBox: void 0,
      viewBox: s,
      fill: void 0
    });
  });
  return /* @__PURE__ */ l.createElement(jt, {
    value: r ? n : void 0
  }, t);
}
function Hs(e) {
  var {
    points: r,
    baseLine: t,
    needClip: a,
    clipPathId: n,
    props: i
  } = e, {
    layout: o,
    type: u,
    stroke: s,
    connectNulls: c,
    isRange: d
  } = i, {
    id: v
  } = i, f = $f(i, $I), p = G(f), m = le(f);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, (r == null ? void 0 : r.length) > 1 && /* @__PURE__ */ l.createElement(_, {
    clipPath: a ? "url(#clipPath-".concat(n, ")") : void 0
  }, /* @__PURE__ */ l.createElement(zr, Wr({}, m, {
    id: v,
    points: r,
    connectNulls: c,
    type: u,
    baseLine: t,
    layout: o,
    stroke: "none",
    className: "recharts-area-area"
  })), s !== "none" && /* @__PURE__ */ l.createElement(zr, Wr({}, p, {
    className: "recharts-area-curve",
    layout: o,
    type: u,
    connectNulls: c,
    fill: "none",
    points: r
  })), s !== "none" && d && /* @__PURE__ */ l.createElement(zr, Wr({}, p, {
    className: "recharts-area-curve",
    layout: o,
    type: u,
    connectNulls: c,
    fill: "none",
    points: t
  }))), /* @__PURE__ */ l.createElement(zI, {
    points: r,
    props: f,
    clipPathId: n
  }));
}
function FI(e) {
  var r, t, {
    alpha: a,
    baseLine: n,
    points: i,
    strokeWidth: o
  } = e, u = (r = i[0]) === null || r === void 0 ? void 0 : r.y, s = (t = i[i.length - 1]) === null || t === void 0 ? void 0 : t.y;
  if (!q(u) || !q(s))
    return null;
  var c = a * Math.abs(u - s), d = Math.max(...i.map((v) => v.x || 0));
  return L(n) ? d = Math.max(n, d) : n && Array.isArray(n) && n.length && (d = Math.max(...n.map((v) => v.x || 0), d)), L(d) ? /* @__PURE__ */ l.createElement("rect", {
    x: 0,
    y: u < s ? u : u - c,
    width: d + (o ? parseInt("".concat(o), 10) : 1),
    height: Math.floor(c)
  }) : null;
}
function XI(e) {
  var r, t, {
    alpha: a,
    baseLine: n,
    points: i,
    strokeWidth: o
  } = e, u = (r = i[0]) === null || r === void 0 ? void 0 : r.x, s = (t = i[i.length - 1]) === null || t === void 0 ? void 0 : t.x;
  if (!q(u) || !q(s))
    return null;
  var c = a * Math.abs(u - s), d = Math.max(...i.map((v) => v.y || 0));
  return L(n) ? d = Math.max(n, d) : n && Array.isArray(n) && n.length && (d = Math.max(...n.map((v) => v.y || 0), d)), L(d) ? /* @__PURE__ */ l.createElement("rect", {
    x: u < s ? u : u - c,
    y: 0,
    width: c,
    height: Math.floor(d + (o ? parseInt("".concat(o), 10) : 1))
  }) : null;
}
function VI(e) {
  var {
    alpha: r,
    layout: t,
    points: a,
    baseLine: n,
    strokeWidth: i
  } = e;
  return t === "vertical" ? /* @__PURE__ */ l.createElement(FI, {
    alpha: r,
    points: a,
    baseLine: n,
    strokeWidth: i
  }) : /* @__PURE__ */ l.createElement(XI, {
    alpha: r,
    points: a,
    baseLine: n,
    strokeWidth: i
  });
}
function GI(e) {
  var {
    needClip: r,
    clipPathId: t,
    props: a,
    previousPointsRef: n,
    previousBaselineRef: i
  } = e, {
    points: o,
    baseLine: u,
    isAnimationActive: s,
    animationBegin: c,
    animationDuration: d,
    animationEasing: v,
    onAnimationStart: f,
    onAnimationEnd: p
  } = a, m = l.useMemo(() => ({
    points: o,
    baseLine: u
  }), [o, u]), h = or(m, "recharts-area-"), g = jh(), [y, b] = l.useState(!1), x = !y, O = l.useCallback(() => {
    typeof p == "function" && p(), b(!1);
  }, [p]), P = l.useCallback(() => {
    typeof f == "function" && f(), b(!0);
  }, [f]);
  if (g == null)
    return null;
  var w = n.current, E = i.current;
  return /* @__PURE__ */ l.createElement(WI, {
    showLabels: x,
    points: o
  }, a.children, /* @__PURE__ */ l.createElement(ir, {
    animationId: h,
    begin: c,
    duration: d,
    isActive: s,
    easing: v,
    onAnimationEnd: O,
    onAnimationStart: P,
    key: h
  }, (j) => {
    if (w) {
      var S = w.length / o.length, I = (
        /*
         * Here it is important that at the very end of the animation, on the last frame,
         * we render the original points without any interpolation.
         * This is needed because the code above is checking for reference equality to decide if the animation should run
         * and if we create a new array instance (even if the numbers were the same)
         * then we would break animations.
         */
        j === 1 ? o : o.map((C, M) => {
          var T = Math.floor(M * S);
          if (w[T]) {
            var $ = w[T];
            return at(at({}, C), {}, {
              x: N($.x, C.x, j),
              y: N($.y, C.y, j)
            });
          }
          return C;
        })
      ), D;
      return L(u) ? D = N(E, u, j) : U(u) || De(u) ? D = N(E, 0, j) : D = u.map((C, M) => {
        var T = Math.floor(M * S);
        if (Array.isArray(E) && E[T]) {
          var $ = E[T];
          return at(at({}, C), {}, {
            x: N($.x, C.x, j),
            y: N($.y, C.y, j)
          });
        }
        return C;
      }), j > 0 && (n.current = I, i.current = D), /* @__PURE__ */ l.createElement(Hs, {
        points: I,
        baseLine: D,
        needClip: r,
        clipPathId: t,
        props: a
      });
    }
    return j > 0 && (n.current = o, i.current = u), /* @__PURE__ */ l.createElement(_, null, s && /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement("clipPath", {
      id: "animationClipPath-".concat(t)
    }, /* @__PURE__ */ l.createElement(VI, {
      alpha: j,
      points: o,
      baseLine: u,
      layout: g,
      strokeWidth: a.strokeWidth
    }))), /* @__PURE__ */ l.createElement(_, {
      clipPath: "url(#animationClipPath-".concat(t, ")")
    }, /* @__PURE__ */ l.createElement(Hs, {
      points: o,
      baseLine: u,
      needClip: r,
      clipPathId: t,
      props: a
    })));
  }), /* @__PURE__ */ l.createElement(_r, {
    label: a.label
  }));
}
function HI(e) {
  var {
    needClip: r,
    clipPathId: t,
    props: a
  } = e, n = l.useRef(null), i = l.useRef();
  return /* @__PURE__ */ l.createElement(GI, {
    needClip: r,
    clipPathId: t,
    props: a,
    previousPointsRef: n,
    previousBaselineRef: i
  });
}
class YI extends l.PureComponent {
  render() {
    var {
      hide: r,
      dot: t,
      points: a,
      className: n,
      top: i,
      left: o,
      needClip: u,
      xAxisId: s,
      yAxisId: c,
      width: d,
      height: v,
      id: f,
      baseLine: p,
      zIndex: m
    } = this.props;
    if (r)
      return null;
    var h = R("recharts-area", n), g = f, {
      r: y,
      strokeWidth: b
    } = Af(t), x = Ho(t), O = y * 2 + b, P = u ? "url(#clipPath-".concat(x ? "" : "dots-").concat(g, ")") : void 0;
    return /* @__PURE__ */ l.createElement(ee, {
      zIndex: m
    }, /* @__PURE__ */ l.createElement(_, {
      className: h
    }, u && /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement(Un, {
      clipPathId: g,
      xAxisId: s,
      yAxisId: c
    }), !x && /* @__PURE__ */ l.createElement("clipPath", {
      id: "clipPath-dots-".concat(g)
    }, /* @__PURE__ */ l.createElement("rect", {
      x: o - O / 2,
      y: i - O / 2,
      width: d + O,
      height: v + O
    }))), /* @__PURE__ */ l.createElement(HI, {
      needClip: u,
      clipPathId: g,
      props: this.props
    })), /* @__PURE__ */ l.createElement(en, {
      points: a,
      mainColor: un(this.props.stroke, this.props.fill),
      itemDataKey: this.props.dataKey,
      activeDot: this.props.activeDot,
      clipPath: P
    }), this.props.isRange && Array.isArray(p) && /* @__PURE__ */ l.createElement(en, {
      points: p,
      mainColor: un(this.props.stroke, this.props.fill),
      itemDataKey: this.props.dataKey,
      activeDot: this.props.activeDot,
      clipPath: P
    }));
  }
}
var Lf = {
  activeDot: !0,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease",
  connectNulls: !1,
  dot: !1,
  fill: "#3182bd",
  fillOpacity: 0.6,
  hide: !1,
  isAnimationActive: "auto",
  legendType: "line",
  stroke: "#3182bd",
  strokeWidth: 1,
  type: "linear",
  label: !1,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: Y.area
};
function UI(e) {
  var r, t = V(e, Lf), {
    activeDot: a,
    animationBegin: n,
    animationDuration: i,
    animationEasing: o,
    connectNulls: u,
    dot: s,
    fill: c,
    fillOpacity: d,
    hide: v,
    isAnimationActive: f,
    legendType: p,
    stroke: m,
    xAxisId: h,
    yAxisId: g
  } = t, y = $f(t, LI), b = Er(), x = hv(), {
    needClip: O
  } = ba(h, g), P = te(), {
    points: w,
    isRange: E,
    baseLine: j
  } = (r = k((T) => TI(T, e.id, P))) !== null && r !== void 0 ? r : {}, S = ga();
  if (b !== "horizontal" && b !== "vertical" || S == null || x !== "AreaChart" && x !== "ComposedChart")
    return null;
  var {
    height: I,
    width: D,
    x: C,
    y: M
  } = S;
  return !w || !w.length ? null : /* @__PURE__ */ l.createElement(YI, Wr({}, y, {
    activeDot: a,
    animationBegin: n,
    animationDuration: i,
    animationEasing: o,
    baseLine: j,
    connectNulls: u,
    dot: s,
    fill: c,
    fillOpacity: d,
    height: I,
    hide: v,
    layout: b,
    isAnimationActive: f === "auto" ? !mt.isSsr : f,
    isRange: E,
    legendType: p,
    needClip: O,
    points: w,
    stroke: m,
    width: D,
    left: C,
    top: M,
    xAxisId: h,
    yAxisId: g
  }));
}
var ZI = (e, r, t, a, n) => {
  var i = t ?? r;
  if (L(i))
    return i;
  var o = e === "horizontal" ? n : a, u = o.scale.domain();
  if (o.type === "number") {
    var s = Math.max(u[0], u[1]), c = Math.min(u[0], u[1]);
    return i === "dataMin" ? c : i === "dataMax" || s < 0 ? s : Math.max(Math.min(u[0], u[1]), 0);
  }
  return i === "dataMin" ? u[0] : i === "dataMax" ? u[1] : u[0];
};
function qI(e) {
  var {
    areaSettings: {
      connectNulls: r,
      baseValue: t,
      dataKey: a
    },
    stackedData: n,
    layout: i,
    chartBaseValue: o,
    xAxis: u,
    yAxis: s,
    displayedData: c,
    dataStartIndex: d,
    xAxisTicks: v,
    yAxisTicks: f,
    bandSize: p
  } = e, m = n && n.length, h = ZI(i, o, t, u, s), g = i === "horizontal", y = !1, b = c.map((O, P) => {
    var w, E, j;
    if (m)
      j = n[d + P];
    else {
      var S = B(O, a);
      Array.isArray(S) ? (j = S, y = !0) : j = [h, S];
    }
    var I = (w = (E = j) === null || E === void 0 ? void 0 : E[1]) !== null && w !== void 0 ? w : null, D = I == null || m && !r && B(O, a) == null;
    return g ? {
      x: ot({
        axis: u,
        ticks: v,
        bandSize: p,
        entry: O,
        index: P
      }),
      y: D ? null : s.scale(I),
      value: j,
      payload: O
    } : {
      x: D ? null : u.scale(I),
      y: ot({
        axis: s,
        ticks: f,
        bandSize: p,
        entry: O,
        index: P
      }),
      value: j,
      payload: O
    };
  }), x;
  return m || y ? x = b.map((O) => {
    var P = Array.isArray(O.value) ? O.value[0] : null;
    return g ? {
      x: O.x,
      y: P != null && O.y != null ? s.scale(P) : null,
      payload: O.payload
    } : {
      x: P != null ? u.scale(P) : null,
      y: O.y,
      payload: O.payload
    };
  }) : x = g ? s.scale(h) : u.scale(h), {
    points: b,
    baseLine: x,
    isRange: y
  };
}
function JI(e) {
  var r = V(e, Lf), t = te();
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "area"
  }, (a) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Fn, {
    legendPayload: BI(r)
  }), /* @__PURE__ */ l.createElement(KI, {
    dataKey: r.dataKey,
    data: r.data,
    stroke: r.stroke,
    strokeWidth: r.strokeWidth,
    fill: r.fill,
    name: r.name,
    hide: r.hide,
    unit: r.unit,
    tooltipType: r.tooltipType,
    id: a
  }), /* @__PURE__ */ l.createElement(Xn, {
    type: "area",
    id: a,
    data: r.data,
    dataKey: r.dataKey,
    xAxisId: r.xAxisId,
    yAxisId: r.yAxisId,
    zAxisId: 0,
    stackId: gn(r.stackId),
    hide: r.hide,
    barSize: void 0,
    baseValue: r.baseValue,
    isPanorama: t,
    connectNulls: r.connectNulls
  }), /* @__PURE__ */ l.createElement(UI, Wr({}, r, {
    id: a
  }))));
}
var QI = /* @__PURE__ */ l.memo(JI, Dt);
QI.displayName = "Area";
function Ni() {
  return Ni = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ni.apply(null, arguments);
}
function sn(e) {
  return /* @__PURE__ */ l.createElement(Xr, Ni({
    shapeType: "rectangle",
    activeClassName: "recharts-active-bar"
  }, e));
}
var ek = function(r) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  return (a, n) => {
    if (L(r)) return r;
    var i = L(a) || U(a);
    return i ? r(a, n) : (i || Bp(), t);
  };
}, rk = (e, r, t) => t, tk = (e, r) => r, xa = A([xt, tk], (e, r) => e.filter((t) => t.type === "bar").find((t) => t.id === r)), ak = A([xa], (e) => e == null ? void 0 : e.maxBarSize), nk = (e, r, t, a) => a, ik = A([K, xt, vr, fr, rk], (e, r, t, a, n) => r.filter((i) => e === "horizontal" ? i.xAxisId === t : i.yAxisId === a).filter((i) => i.isPanorama === n).filter((i) => i.hide === !1).filter((i) => i.type === "bar")), ok = (e, r, t) => {
  var a = K(e), n = vr(e, r), i = fr(e, r);
  if (!(n == null || i == null))
    return a === "horizontal" ? Ha(e, "yAxis", i, t) : Ha(e, "xAxis", n, t);
}, lk = (e, r) => {
  var t = K(e), a = vr(e, r), n = fr(e, r);
  if (!(a == null || n == null))
    return t === "horizontal" ? mu(e, "xAxis", a) : mu(e, "yAxis", n);
}, uk = A([ik, xd, lk], rf), sk = (e, r, t) => {
  var a, n, i = xa(e, r);
  if (i != null) {
    var o = vr(e, r), u = fr(e, r);
    if (!(o == null || u == null)) {
      var s = K(e), c = wn(e), {
        maxBarSize: d
      } = i, v = U(d) ? c : d, f, p;
      return s === "horizontal" ? (f = Re(e, "xAxis", o, t), p = Ge(e, "xAxis", o, t)) : (f = Re(e, "yAxis", u, t), p = Ge(e, "yAxis", u, t)), (a = (n = Ne(f, p, !0)) !== null && n !== void 0 ? n : v) !== null && a !== void 0 ? a : 0;
    }
  }
}, Mf = (e, r, t) => {
  var a = K(e), n = vr(e, r), i = fr(e, r);
  if (!(n == null || i == null)) {
    var o, u;
    return a === "horizontal" ? (o = Re(e, "xAxis", n, t), u = Ge(e, "xAxis", n, t)) : (o = Re(e, "yAxis", i, t), u = Ge(e, "yAxis", i, t)), Ne(o, u);
  }
}, ck = A([uk, wn, bd, no, sk, Mf, ak], tf), dk = (e, r, t) => {
  var a = vr(e, r);
  if (a != null)
    return Re(e, "xAxis", a, t);
}, vk = (e, r, t) => {
  var a = fr(e, r);
  if (a != null)
    return Re(e, "yAxis", a, t);
}, fk = (e, r, t) => {
  var a = vr(e, r);
  if (a != null)
    return Ge(e, "xAxis", a, t);
}, pk = (e, r, t) => {
  var a = fr(e, r);
  if (a != null)
    return Ge(e, "yAxis", a, t);
}, mk = A([ck, xa], (e, r) => {
  if (!(e == null || r == null)) {
    var t = e.find((a) => a.stackId === r.stackId && r.dataKey != null && a.dataKeys.includes(r.dataKey));
    if (t != null)
      return t.position;
  }
}), hk = A([ok, xa], af), yk = A([he, ro, dk, vk, fk, pk, mk, K, sd, Mf, hk, xa, nk], (e, r, t, a, n, i, o, u, s, c, d, v, f) => {
  var {
    chartData: p,
    dataStartIndex: m,
    dataEndIndex: h
  } = s;
  if (!(v == null || o == null || r == null || u !== "horizontal" && u !== "vertical" || t == null || a == null || n == null || i == null || c == null)) {
    var {
      data: g
    } = v, y;
    if (g != null && g.length > 0 ? y = g : y = p == null ? void 0 : p.slice(m, h + 1), y != null)
      return Gk({
        layout: u,
        barSettings: v,
        pos: o,
        parentViewBox: r,
        bandSize: c,
        xAxis: t,
        yAxis: a,
        xAxisTicks: n,
        yAxisTicks: i,
        stackedData: d,
        displayedData: y,
        offset: e,
        cells: f,
        dataStartIndex: m
      });
  }
}), gk = ["index"];
function Ri() {
  return Ri = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ri.apply(null, arguments);
}
function bk(e, r) {
  if (e == null) return {};
  var t, a, n = xk(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function xk(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var _f = /* @__PURE__ */ l.createContext(void 0), Pk = (e) => {
  var r = l.useContext(_f);
  if (r != null)
    return r.stackId;
  if (e != null)
    return gn(e);
}, Ok = (e, r) => "recharts-bar-stack-clip-path-".concat(e, "-").concat(r), wk = (e) => {
  var r = l.useContext(_f);
  if (r != null) {
    var {
      stackId: t
    } = r;
    return "url(#".concat(Ok(t, e), ")");
  }
}, Ak = (e) => {
  var {
    index: r
  } = e, t = bk(e, gk), a = wk(r);
  return /* @__PURE__ */ l.createElement(_, Ri({
    className: "recharts-bar-stack-layer",
    clipPath: a
  }, t));
}, Ek = ["onMouseEnter", "onMouseLeave", "onClick"], jk = ["value", "background", "tooltipPosition"], Sk = ["id"], Ik = ["onMouseEnter", "onClick", "onMouseLeave"];
function Or() {
  return Or = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Or.apply(null, arguments);
}
function Ys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Te(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Ys(Object(t), !0).forEach(function(a) {
      kk(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Ys(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function kk(e, r, t) {
  return (r = Ck(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Ck(e) {
  var r = Dk(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function Dk(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function cn(e, r) {
  if (e == null) return {};
  var t, a, n = Tk(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function Tk(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var $k = (e) => {
  var {
    dataKey: r,
    name: t,
    fill: a,
    legendType: n,
    hide: i
  } = e;
  return [{
    inactive: i,
    dataKey: r,
    type: n,
    color: a,
    value: We(t, r),
    payload: e
  }];
}, Lk = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    stroke: t,
    strokeWidth: a,
    fill: n,
    name: i,
    hide: o,
    unit: u,
    tooltipType: s,
    id: c
  } = e, d = {
    dataDefinedOnItem: void 0,
    positions: void 0,
    settings: {
      stroke: t,
      strokeWidth: a,
      fill: n,
      dataKey: r,
      nameKey: void 0,
      name: We(i, r),
      hide: o,
      type: s,
      color: n,
      unit: u,
      graphicalItemId: c
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: d
  });
});
function Mk(e) {
  var r = k(nr), {
    data: t,
    dataKey: a,
    background: n,
    allOtherBarProps: i
  } = e, {
    onMouseEnter: o,
    onMouseLeave: u,
    onClick: s
  } = i, c = cn(i, Ek), d = It(o, a, i.id), v = kt(u), f = Ct(s, a, i.id);
  if (!n || t == null)
    return null;
  var p = ze(n);
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: sf(n, Y.barBackground)
  }, t.map((m, h) => {
    var {
      value: g,
      background: y,
      tooltipPosition: b
    } = m, x = cn(m, jk);
    if (!y)
      return null;
    var O = d(m, h), P = v(m, h), w = f(m, h), E = Te(Te(Te(Te(Te({
      option: n,
      isActive: String(h) === r
    }, x), {}, {
      // @ts-expect-error backgroundProps is contributing unknown props
      fill: "#eee"
    }, y), p), Ue(c, m, h)), {}, {
      onMouseEnter: O,
      onMouseLeave: P,
      onClick: w,
      dataKey: a,
      index: h,
      className: "recharts-bar-background-rectangle"
    });
    return /* @__PURE__ */ l.createElement(sn, Or({
      key: "background-bar-".concat(h)
    }, E));
  }));
}
function _k(e) {
  var {
    showLabels: r,
    children: t,
    rects: a
  } = e, n = a == null ? void 0 : a.map((i) => {
    var o = {
      x: i.x,
      y: i.y,
      width: i.width,
      lowerWidth: i.width,
      upperWidth: i.width,
      height: i.height
    };
    return Te(Te({}, o), {}, {
      value: i.value,
      payload: i.payload,
      parentViewBox: i.parentViewBox,
      viewBox: o,
      fill: i.fill
    });
  });
  return /* @__PURE__ */ l.createElement(jt, {
    value: r ? n : void 0
  }, t);
}
function Nk(e) {
  var {
    shape: r,
    activeBar: t,
    baseProps: a,
    entry: n,
    index: i,
    dataKey: o
  } = e, u = k(nr), s = k(No), c = t && String(i) === u && (s == null || o === s), d = c ? t : r;
  return c ? /* @__PURE__ */ l.createElement(ee, {
    zIndex: Y.activeBar
  }, /* @__PURE__ */ l.createElement(sn, Or({}, a, {
    name: String(a.name)
  }, n, {
    isActive: c,
    option: d,
    index: i,
    dataKey: o
  }))) : /* @__PURE__ */ l.createElement(sn, Or({}, a, {
    name: String(a.name)
  }, n, {
    isActive: c,
    option: d,
    index: i,
    dataKey: o
  }));
}
function Rk(e) {
  var {
    shape: r,
    baseProps: t,
    entry: a,
    index: n,
    dataKey: i
  } = e;
  return /* @__PURE__ */ l.createElement(sn, Or({}, t, {
    name: String(t.name)
  }, a, {
    isActive: !1,
    option: r,
    index: n,
    dataKey: i
  }));
}
function Bk(e) {
  var r, {
    data: t,
    props: a
  } = e, n = (r = G(a)) !== null && r !== void 0 ? r : {}, {
    id: i
  } = n, o = cn(n, Sk), {
    shape: u,
    dataKey: s,
    activeBar: c
  } = a, {
    onMouseEnter: d,
    onClick: v,
    onMouseLeave: f
  } = a, p = cn(a, Ik), m = It(d, s, i), h = kt(f), g = Ct(v, s, i);
  return t ? /* @__PURE__ */ l.createElement(l.Fragment, null, t.map((y, b) => /* @__PURE__ */ l.createElement(Ak, Or({
    index: b,
    key: "rectangle-".concat(y == null ? void 0 : y.x, "-").concat(y == null ? void 0 : y.y, "-").concat(y == null ? void 0 : y.value, "-").concat(b),
    className: "recharts-bar-rectangle"
  }, Ue(p, y, b), {
    // @ts-expect-error BarRectangleItem type definition says it's missing properties, but I can see them present in debugger!
    onMouseEnter: m(y, b),
    onMouseLeave: h(y, b),
    onClick: g(y, b)
  }), c ? /* @__PURE__ */ l.createElement(Nk, {
    shape: u,
    activeBar: c,
    baseProps: o,
    entry: y,
    index: b,
    dataKey: s
  }) : (
    /*
     * If the `activeBar` prop is falsy, then let's call the variant without hooks.
     * Using the `selectActiveTooltipIndex` selector is usually fast
     * but in charts with large-ish amount of data even the few nanoseconds add up to a noticeable jank.
     * If the activeBar is false then we don't need to know which index is active - because we won't use it anyway.
     * So let's just skip the hooks altogether. That way, React can skip rendering the component,
     * and can skip the tree reconciliation for its children too.
     * Because we can't call hooks conditionally, we need to have a separate component for that.
     */
    /* @__PURE__ */ l.createElement(Rk, {
      shape: u,
      baseProps: o,
      entry: y,
      index: b,
      dataKey: s
    })
  )))) : null;
}
function Kk(e) {
  var {
    props: r,
    previousRectanglesRef: t
  } = e, {
    data: a,
    layout: n,
    isAnimationActive: i,
    animationBegin: o,
    animationDuration: u,
    animationEasing: s,
    onAnimationEnd: c,
    onAnimationStart: d
  } = r, v = t.current, f = or(r, "recharts-bar-"), [p, m] = l.useState(!1), h = !p, g = l.useCallback(() => {
    typeof c == "function" && c(), m(!1);
  }, [c]), y = l.useCallback(() => {
    typeof d == "function" && d(), m(!0);
  }, [d]);
  return /* @__PURE__ */ l.createElement(_k, {
    showLabels: h,
    rects: a
  }, /* @__PURE__ */ l.createElement(ir, {
    animationId: f,
    begin: o,
    duration: u,
    isActive: i,
    easing: s,
    onAnimationEnd: g,
    onAnimationStart: y,
    key: f
  }, (b) => {
    var x = b === 1 ? a : a == null ? void 0 : a.map((O, P) => {
      var w = v && v[P];
      if (w)
        return Te(Te({}, O), {}, {
          x: N(w.x, O.x, b),
          y: N(w.y, O.y, b),
          width: N(w.width, O.width, b),
          height: N(w.height, O.height, b)
        });
      if (n === "horizontal") {
        var E = N(0, O.height, b), j = N(O.stackedBarStart, O.y, b);
        return Te(Te({}, O), {}, {
          y: j,
          height: E
        });
      }
      var S = N(0, O.width, b), I = N(O.stackedBarStart, O.x, b);
      return Te(Te({}, O), {}, {
        width: S,
        x: I
      });
    });
    return b > 0 && (t.current = x ?? null), x == null ? null : /* @__PURE__ */ l.createElement(_, null, /* @__PURE__ */ l.createElement(Bk, {
      props: r,
      data: x
    }));
  }), /* @__PURE__ */ l.createElement(_r, {
    label: r.label
  }), r.children);
}
function zk(e) {
  var r = l.useRef(null);
  return /* @__PURE__ */ l.createElement(Kk, {
    previousRectanglesRef: r,
    props: e
  });
}
var Nf = 0, Wk = (e, r) => {
  var t = Array.isArray(e.value) ? e.value[1] : e.value;
  return {
    x: e.x,
    y: e.y,
    value: t,
    // @ts-expect-error getValueByDataKey does not validate the output type
    errorVal: B(e, r)
  };
};
class Fk extends l.PureComponent {
  render() {
    var {
      hide: r,
      data: t,
      dataKey: a,
      className: n,
      xAxisId: i,
      yAxisId: o,
      needClip: u,
      background: s,
      id: c
    } = this.props;
    if (r || t == null)
      return null;
    var d = R("recharts-bar", n), v = c;
    return /* @__PURE__ */ l.createElement(_, {
      className: d,
      id: c
    }, u && /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement(Un, {
      clipPathId: v,
      xAxisId: i,
      yAxisId: o
    })), /* @__PURE__ */ l.createElement(_, {
      className: "recharts-bar-rectangles",
      clipPath: u ? "url(#clipPath-".concat(v, ")") : void 0
    }, /* @__PURE__ */ l.createElement(Mk, {
      data: t,
      dataKey: a,
      background: s,
      allOtherBarProps: this.props
    }), /* @__PURE__ */ l.createElement(zk, this.props)));
  }
}
var Xk = {
  activeBar: !1,
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "ease",
  background: !1,
  hide: !1,
  isAnimationActive: "auto",
  label: !1,
  legendType: "rect",
  minPointSize: Nf,
  xAxisId: 0,
  yAxisId: 0,
  zIndex: Y.bar
};
function Vk(e) {
  var {
    xAxisId: r,
    yAxisId: t,
    hide: a,
    legendType: n,
    minPointSize: i,
    activeBar: o,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    isAnimationActive: d
  } = e, {
    needClip: v
  } = ba(r, t), f = Er(), p = te(), m = St(e.children, Zr), h = k((b) => yk(b, e.id, p, m));
  if (f !== "vertical" && f !== "horizontal")
    return null;
  var g, y = h == null ? void 0 : h[0];
  return y == null || y.height == null || y.width == null ? g = 0 : g = f === "vertical" ? y.height / 2 : y.width / 2, /* @__PURE__ */ l.createElement(il, {
    xAxisId: r,
    yAxisId: t,
    data: h,
    dataPointFormatter: Wk,
    errorBarOffset: g
  }, /* @__PURE__ */ l.createElement(Fk, Or({}, e, {
    layout: f,
    needClip: v,
    data: h,
    xAxisId: r,
    yAxisId: t,
    hide: a,
    legendType: n,
    minPointSize: i,
    activeBar: o,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    isAnimationActive: d
  })));
}
function Gk(e) {
  var {
    layout: r,
    barSettings: {
      dataKey: t,
      minPointSize: a
    },
    pos: n,
    bandSize: i,
    xAxis: o,
    yAxis: u,
    xAxisTicks: s,
    yAxisTicks: c,
    stackedData: d,
    displayedData: v,
    offset: f,
    cells: p,
    parentViewBox: m,
    dataStartIndex: h
  } = e, g = r === "horizontal" ? u : o, y = d ? g.scale.domain() : null, b = Kc({
    numericAxis: g
  }), x = g.scale(b);
  return v.map((O, P) => {
    var w, E, j, S, I, D;
    if (d) {
      var C = d[P + h];
      if (C == null)
        return null;
      w = Bc(C, y);
    } else
      w = B(O, t), Array.isArray(w) || (w = [b, w]);
    var M = ek(a, Nf)(w[1], P);
    if (r === "horizontal") {
      var T, [$, W] = [u.scale(w[0]), u.scale(w[1])];
      E = Ra({
        axis: o,
        ticks: s,
        bandSize: i,
        offset: n.offset,
        entry: O,
        index: P
      }), j = (T = W ?? $) !== null && T !== void 0 ? T : void 0, S = n.size;
      var X = $ - W;
      if (I = De(X) ? 0 : X, D = {
        x: E,
        y: f.top,
        width: S,
        height: f.height
      }, Math.abs(M) > 0 && Math.abs(I) < Math.abs(M)) {
        var Z = me(I || M) * (Math.abs(M) - Math.abs(I));
        j -= Z, I += Z;
      }
    } else {
      var [z, ne] = [o.scale(w[0]), o.scale(w[1])];
      if (E = z, j = Ra({
        axis: u,
        ticks: c,
        bandSize: i,
        offset: n.offset,
        entry: O,
        index: P
      }), S = ne - z, I = n.size, D = {
        x: f.left,
        y: j,
        width: f.width,
        height: I
      }, Math.abs(M) > 0 && Math.abs(S) < Math.abs(M)) {
        var ge = me(S || M) * (Math.abs(M) - Math.abs(S));
        S += ge;
      }
    }
    if (E == null || j == null || S == null || I == null)
      return null;
    var fe = Te(Te({}, O), {}, {
      stackedBarStart: x,
      x: E,
      y: j,
      width: S,
      height: I,
      value: d ? w : w[1],
      payload: O,
      background: D,
      tooltipPosition: {
        x: E + S / 2,
        y: j + I / 2
      },
      parentViewBox: m
    }, p && p[P] && p[P].props);
    return fe;
  }).filter(Boolean);
}
function Hk(e) {
  var r = V(e, Xk), t = Pk(r.stackId), a = te();
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "bar"
  }, (n) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Fn, {
    legendPayload: $k(r)
  }), /* @__PURE__ */ l.createElement(Lk, {
    dataKey: r.dataKey,
    stroke: r.stroke,
    strokeWidth: r.strokeWidth,
    fill: r.fill,
    name: r.name,
    hide: r.hide,
    unit: r.unit,
    tooltipType: r.tooltipType,
    id: n
  }), /* @__PURE__ */ l.createElement(Xn, {
    type: "bar",
    id: n,
    data: void 0,
    xAxisId: r.xAxisId,
    yAxisId: r.yAxisId,
    zAxisId: 0,
    dataKey: r.dataKey,
    stackId: t,
    hide: r.hide,
    barSize: r.barSize,
    minPointSize: r.minPointSize,
    maxBarSize: r.maxBarSize,
    isPanorama: a
  }), /* @__PURE__ */ l.createElement(ee, {
    zIndex: r.zIndex
  }, /* @__PURE__ */ l.createElement(Vk, Or({}, r, {
    id: n
  })))));
}
var Yk = /* @__PURE__ */ l.memo(Hk, Dt);
Yk.displayName = "Bar";
var Uk = ["option", "isActive"];
function Kt() {
  return Kt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Kt.apply(null, arguments);
}
function Zk(e, r) {
  if (e == null) return {};
  var t, a, n = qk(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function qk(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Jk(e) {
  var {
    option: r,
    isActive: t
  } = e, a = Zk(e, Uk);
  return typeof r == "string" ? /* @__PURE__ */ l.createElement(Xr, Kt({
    option: /* @__PURE__ */ l.createElement(yn, Kt({
      type: r
    }, a)),
    isActive: t,
    shapeType: "symbols"
  }, a)) : /* @__PURE__ */ l.createElement(Xr, Kt({
    option: r,
    isActive: t,
    shapeType: "symbols"
  }, a));
}
var Qk = (e, r, t, a, n, i, o) => Re(e, "xAxis", r, o), eC = (e, r, t, a, n, i, o) => Ge(e, "xAxis", r, o), rC = (e, r, t, a, n, i, o) => Re(e, "yAxis", t, o), tC = (e, r, t, a, n, i, o) => Ge(e, "yAxis", t, o), aC = (e, r, t, a) => hb(e, "zAxis", a, !1), nC = (e, r, t, a, n) => n, iC = (e, r, t, a, n, i) => i, oC = (e, r, t, a, n, i, o) => On(e, void 0, void 0, o), lC = A([xt, nC], (e, r) => e.filter((t) => t.type === "scatter").find((t) => t.id === r)), uC = A([oC, Qk, eC, rC, tC, aC, lC, iC], (e, r, t, a, n, i, o, u) => {
  var {
    chartData: s,
    dataStartIndex: c,
    dataEndIndex: d
  } = e;
  if (o != null) {
    var v;
    if ((o == null ? void 0 : o.data) != null && o.data.length > 0 ? v = o.data : v = s == null ? void 0 : s.slice(c, d + 1), !(v == null || r == null || a == null || t == null || n == null || (t == null ? void 0 : t.length) === 0 || (n == null ? void 0 : n.length) === 0))
      return OC({
        displayedData: v,
        xAxis: r,
        yAxis: a,
        zAxis: i,
        scatterSettings: o,
        xAxisTicks: t,
        yAxisTicks: n,
        cells: u
      });
  }
}), sC = ["id"], cC = ["onMouseEnter", "onClick", "onMouseLeave"], dC = ["animationBegin", "animationDuration", "animationEasing", "hide", "isAnimationActive", "legendType", "lineJointType", "lineType", "shape", "xAxisId", "yAxisId", "zAxisId"];
function Bi(e, r) {
  if (e == null) return {};
  var t, a, n = vC(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function vC(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function Gr() {
  return Gr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Gr.apply(null, arguments);
}
function Us(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Me(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Us(Object(t), !0).forEach(function(a) {
      fC(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Us(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function fC(e, r, t) {
  return (r = pC(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function pC(e) {
  var r = mC(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function mC(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var hC = (e) => {
  var {
    dataKey: r,
    name: t,
    fill: a,
    legendType: n,
    hide: i
  } = e;
  return [{
    inactive: i,
    dataKey: r,
    type: n,
    color: a,
    value: We(t, r),
    payload: e
  }];
}, yC = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    points: t,
    stroke: a,
    strokeWidth: n,
    fill: i,
    name: o,
    hide: u,
    tooltipType: s,
    id: c
  } = e, d = {
    dataDefinedOnItem: t == null ? void 0 : t.map((v) => v.tooltipPayload),
    positions: t == null ? void 0 : t.map((v) => v.tooltipPosition),
    settings: {
      stroke: a,
      strokeWidth: n,
      fill: i,
      nameKey: void 0,
      dataKey: r,
      name: We(o, r),
      hide: u,
      type: s,
      color: i,
      unit: "",
      // why doesn't Scatter support unit?
      graphicalItemId: c
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: d
  });
});
function gC(e) {
  var {
    points: r,
    props: t
  } = e, {
    line: a,
    lineType: n,
    lineJointType: i
  } = t;
  if (!a)
    return null;
  var o = G(t), u = ze(a), s, c;
  if (n === "joint")
    s = r.map((g) => {
      var y, b;
      return {
        x: (y = g.cx) !== null && y !== void 0 ? y : null,
        y: (b = g.cy) !== null && b !== void 0 ? b : null
      };
    });
  else if (n === "fitting") {
    var {
      xmin: d,
      xmax: v,
      a: f,
      b: p
    } = nm(r), m = (g) => f * g + p;
    s = [{
      x: d,
      y: m(d)
    }, {
      x: v,
      y: m(v)
    }];
  }
  var h = Me(Me(Me({}, o), {}, {
    // @ts-expect-error customLineProps is contributing unknown props
    fill: "none",
    // @ts-expect-error customLineProps is contributing unknown props
    stroke: o && o.fill
  }, u), {}, {
    // @ts-expect-error linePoints is used before it is assigned (???)
    points: s
  });
  return /* @__PURE__ */ l.isValidElement(a) ? c = /* @__PURE__ */ l.cloneElement(a, h) : typeof a == "function" ? c = a(h) : c = /* @__PURE__ */ l.createElement(zr, Gr({}, h, {
    type: i
  })), /* @__PURE__ */ l.createElement(_, {
    className: "recharts-scatter-line",
    key: "recharts-scatter-line"
  }, c);
}
function bC(e) {
  var {
    showLabels: r,
    points: t,
    children: a
  } = e, n = pt(), i = l.useMemo(() => t == null ? void 0 : t.map((o) => {
    var u, s, c = {
      /*
       * Scatter label uses x and y as the reference point for the label,
       * not cx and cy.
       */
      x: (u = o.x) !== null && u !== void 0 ? u : 0,
      /*
       * Scatter label uses x and y as the reference point for the label,
       * not cx and cy.
       */
      y: (s = o.y) !== null && s !== void 0 ? s : 0,
      width: o.width,
      height: o.height,
      lowerWidth: o.width,
      upperWidth: o.width
    };
    return Me(Me({}, c), {}, {
      /*
       * Here we put undefined because Scatter shows two values usually, one for X and one for Y.
       * LabelList will see this undefined and will use its own `dataKey` prop to determine which value to show,
       * using the payload below.
       */
      value: void 0,
      payload: o.payload,
      viewBox: c,
      parentViewBox: n,
      fill: void 0
    });
  }), [n, t]);
  return /* @__PURE__ */ l.createElement(jt, {
    value: r ? i : void 0
  }, a);
}
function xC(e) {
  var {
    points: r,
    allOtherScatterProps: t
  } = e, {
    shape: a,
    activeShape: n,
    dataKey: i
  } = t, {
    id: o
  } = t, u = Bi(t, sC), s = k(nr), {
    onMouseEnter: c,
    onClick: d,
    onMouseLeave: v
  } = t, f = Bi(t, cC), p = It(c, i, o), m = kt(v), h = Ct(d, i, o);
  if (!hm(r))
    return null;
  var g = G(u);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(gC, {
    points: r,
    props: u
  }), r.map((y, b) => {
    var x = n != null && n !== !1, O = x && s === String(b), P = x && O ? n : a, w = Me(Me(Me({}, g), y), {}, {
      [Qi]: b,
      [eo]: String(o)
    });
    return /* @__PURE__ */ l.createElement(ee, {
      key: "symbol-".concat(y == null ? void 0 : y.cx, "-").concat(y == null ? void 0 : y.cy, "-").concat(y == null ? void 0 : y.size, "-").concat(b),
      zIndex: O ? Y.activeDot : void 0
    }, /* @__PURE__ */ l.createElement(_, Gr({
      className: "recharts-scatter-symbol"
    }, Ue(f, y, b), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: p(y, b),
      onMouseLeave: m(y, b),
      onClick: h(y, b)
    }), /* @__PURE__ */ l.createElement(Jk, Gr({
      option: P,
      isActive: O
    }, w))));
  }));
}
function PC(e) {
  var {
    previousPointsRef: r,
    props: t
  } = e, {
    points: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u
  } = t, s = r.current, c = or(t, "recharts-scatter-"), [d, v] = l.useState(!1), f = l.useCallback(() => {
    v(!1);
  }, []), p = l.useCallback(() => {
    v(!0);
  }, []), m = !d;
  return /* @__PURE__ */ l.createElement(bC, {
    showLabels: m,
    points: a
  }, t.children, /* @__PURE__ */ l.createElement(ir, {
    animationId: c,
    begin: i,
    duration: o,
    isActive: n,
    easing: u,
    onAnimationEnd: f,
    onAnimationStart: p,
    key: c
  }, (h) => {
    var g = h === 1 ? a : a == null ? void 0 : a.map((y, b) => {
      var x = s && s[b];
      return x ? Me(Me({}, y), {}, {
        cx: y.cx == null ? void 0 : N(x.cx, y.cx, h),
        cy: y.cy == null ? void 0 : N(x.cy, y.cy, h),
        size: N(x.size, y.size, h)
      }) : Me(Me({}, y), {}, {
        size: N(0, y.size, h)
      });
    });
    return h > 0 && (r.current = g), /* @__PURE__ */ l.createElement(_, null, /* @__PURE__ */ l.createElement(xC, {
      points: g,
      allOtherScatterProps: t,
      showLabels: m
    }));
  }), /* @__PURE__ */ l.createElement(_r, {
    label: t.label
  }));
}
function OC(e) {
  var {
    displayedData: r,
    xAxis: t,
    yAxis: a,
    zAxis: n,
    scatterSettings: i,
    xAxisTicks: o,
    yAxisTicks: u,
    cells: s
  } = e, c = U(t.dataKey) ? i.dataKey : t.dataKey, d = U(a.dataKey) ? i.dataKey : a.dataKey, v = n && n.dataKey, f = n ? n.range : yr.range, p = f && f[0], m = t.scale.bandwidth ? t.scale.bandwidth() : 0, h = a.scale.bandwidth ? a.scale.bandwidth() : 0;
  return r.map((g, y) => {
    var b = B(g, c), x = B(g, d), O = !U(v) && B(g, v) || "-", P = [{
      name: U(t.dataKey) ? i.name : t.name || String(t.dataKey),
      unit: t.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: b,
      payload: g,
      dataKey: c,
      type: i.tooltipType
    }, {
      name: U(a.dataKey) ? i.name : a.name || String(a.dataKey),
      unit: a.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: x,
      payload: g,
      dataKey: d,
      type: i.tooltipType
    }];
    O !== "-" && P.push({
      // @ts-expect-error name prop should not have dataKey in it
      name: n.name || n.dataKey,
      unit: n.unit || "",
      // @ts-expect-error getValueByDataKey does not validate the output type
      value: O,
      payload: g,
      dataKey: v,
      type: i.tooltipType
    });
    var w = ot({
      axis: t,
      ticks: o,
      bandSize: m,
      entry: g,
      index: y,
      dataKey: c
    }), E = ot({
      axis: a,
      ticks: u,
      bandSize: h,
      entry: g,
      index: y,
      dataKey: d
    }), j = O !== "-" ? n.scale(O) : p, S = Math.sqrt(Math.max(j, 0) / Math.PI);
    return Me(Me({}, g), {}, {
      cx: w,
      cy: E,
      x: w == null ? void 0 : w - S,
      y: E == null ? void 0 : E - S,
      width: 2 * S,
      height: 2 * S,
      size: j,
      node: {
        x: b,
        y: x,
        z: O
      },
      tooltipPayload: P,
      tooltipPosition: {
        x: w,
        y: E
      },
      payload: g
    }, s && s[y] && s[y].props);
  });
}
var wC = (e, r, t) => ({
  x: e.cx,
  y: e.cy,
  value: Number(t === "x" ? e.node.x : e.node.y),
  // @ts-expect-error getValueByDataKey does not validate the output type
  errorVal: B(e, r)
});
function AC(e) {
  var {
    hide: r,
    points: t,
    className: a,
    needClip: n,
    xAxisId: i,
    yAxisId: o,
    id: u
  } = e, s = l.useRef(null);
  if (r)
    return null;
  var c = R("recharts-scatter", a), d = u;
  return /* @__PURE__ */ l.createElement(ee, {
    zIndex: e.zIndex
  }, /* @__PURE__ */ l.createElement(_, {
    className: c,
    clipPath: n ? "url(#clipPath-".concat(d, ")") : void 0,
    id: u
  }, n && /* @__PURE__ */ l.createElement("defs", null, /* @__PURE__ */ l.createElement(Un, {
    clipPathId: d,
    xAxisId: i,
    yAxisId: o
  })), /* @__PURE__ */ l.createElement(il, {
    xAxisId: i,
    yAxisId: o,
    data: t,
    dataPointFormatter: wC,
    errorBarOffset: 0
  }, /* @__PURE__ */ l.createElement(_, {
    key: "recharts-scatter-symbols"
  }, /* @__PURE__ */ l.createElement(PC, {
    props: e,
    previousPointsRef: s
  })))));
}
var Rf = {
  xAxisId: 0,
  yAxisId: 0,
  zAxisId: 0,
  label: !1,
  line: !1,
  legendType: "circle",
  lineType: "joint",
  lineJointType: "linear",
  shape: "circle",
  hide: !1,
  isAnimationActive: "auto",
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "linear",
  zIndex: Y.scatter
};
function EC(e) {
  var r = V(e, Rf), {
    animationBegin: t,
    animationDuration: a,
    animationEasing: n,
    hide: i,
    isAnimationActive: o,
    legendType: u,
    lineJointType: s,
    lineType: c,
    shape: d,
    xAxisId: v,
    yAxisId: f,
    zAxisId: p
  } = r, m = Bi(r, dC), {
    needClip: h
  } = ba(v, f), g = l.useMemo(() => St(e.children, Zr), [e.children]), y = te(), b = k((x) => uC(x, v, f, p, e.id, g, y));
  return h == null || b == null ? null : /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(yC, {
    dataKey: e.dataKey,
    points: b,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    id: e.id
  }), /* @__PURE__ */ l.createElement(AC, Gr({}, m, {
    xAxisId: v,
    yAxisId: f,
    zAxisId: p,
    lineType: c,
    lineJointType: s,
    legendType: u,
    shape: d,
    hide: i,
    isAnimationActive: o,
    animationBegin: t,
    animationDuration: a,
    animationEasing: n,
    points: b,
    needClip: h
  })));
}
function jC(e) {
  var r = V(e, Rf), t = te();
  return /* @__PURE__ */ l.createElement(dr, {
    id: r.id,
    type: "scatter"
  }, (a) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(Fn, {
    legendPayload: hC(r)
  }), /* @__PURE__ */ l.createElement(Xn, {
    type: "scatter",
    id: a,
    data: r.data,
    xAxisId: r.xAxisId,
    yAxisId: r.yAxisId,
    zAxisId: r.zAxisId,
    dataKey: r.dataKey,
    hide: r.hide,
    name: r.name,
    tooltipType: r.tooltipType,
    isPanorama: t
  }), /* @__PURE__ */ l.createElement(EC, Gr({}, r, {
    id: a
  }))));
}
var SC = /* @__PURE__ */ l.memo(jC, Dt);
SC.displayName = "Scatter";
var IC = ["domain", "range"], kC = ["domain", "range"];
function Zs(e, r) {
  if (e == null) return {};
  var t, a, n = CC(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function CC(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function qs(e, r) {
  return e === r ? !0 : Array.isArray(e) && e.length === 2 && Array.isArray(r) && r.length === 2 ? e[0] === r[0] && e[1] === r[1] : !1;
}
function Bf(e, r) {
  if (e === r)
    return !0;
  var {
    domain: t,
    range: a
  } = e, n = Zs(e, IC), {
    domain: i,
    range: o
  } = r, u = Zs(r, kC);
  return !qs(t, i) || !qs(a, o) ? !1 : Dt(n, u);
}
var DC = ["dangerouslySetInnerHTML", "ticks", "scale"], TC = ["id", "scale"];
function Ki() {
  return Ki = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ki.apply(null, arguments);
}
function Js(e, r) {
  if (e == null) return {};
  var t, a, n = $C(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function $C(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function LC(e) {
  var r = F(), t = l.useRef(null);
  return l.useLayoutEffect(() => {
    t.current === null ? r(qw(e)) : t.current !== e && r(Jw({
      prev: t.current,
      next: e
    })), t.current = e;
  }, [e, r]), l.useLayoutEffect(() => () => {
    t.current && (r(Qw(t.current)), t.current = null);
  }, [r]), null;
}
var MC = (e) => {
  var {
    xAxisId: r,
    className: t
  } = e, a = k(ro), n = te(), i = "xAxis", o = k((y) => Yd(y, i, r, n)), u = k((y) => Xd(y, r)), s = k((y) => vb(y, r)), c = k((y) => jd(y, r));
  if (u == null || s == null || c == null)
    return null;
  var {
    dangerouslySetInnerHTML: d,
    ticks: v,
    scale: f
  } = e, p = Js(e, DC), {
    id: m,
    scale: h
  } = c, g = Js(c, TC);
  return /* @__PURE__ */ l.createElement(nl, Ki({}, p, g, {
    x: s.x,
    y: s.y,
    width: u.width,
    height: u.height,
    className: R("recharts-".concat(i, " ").concat(i), t),
    viewBox: a,
    ticks: o,
    axisType: i
  }));
}, _C = {
  allowDataOverflow: Pe.allowDataOverflow,
  allowDecimals: Pe.allowDecimals,
  allowDuplicatedCategory: Pe.allowDuplicatedCategory,
  angle: Pe.angle,
  axisLine: br.axisLine,
  height: Pe.height,
  hide: !1,
  includeHidden: Pe.includeHidden,
  interval: Pe.interval,
  minTickGap: Pe.minTickGap,
  mirror: Pe.mirror,
  orientation: Pe.orientation,
  padding: Pe.padding,
  reversed: Pe.reversed,
  scale: Pe.scale,
  tick: Pe.tick,
  tickCount: Pe.tickCount,
  tickLine: br.tickLine,
  tickSize: br.tickSize,
  type: Pe.type,
  xAxisId: 0
}, NC = (e) => {
  var r = V(e, _C);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(LC, {
    allowDataOverflow: r.allowDataOverflow,
    allowDecimals: r.allowDecimals,
    allowDuplicatedCategory: r.allowDuplicatedCategory,
    angle: r.angle,
    dataKey: r.dataKey,
    domain: r.domain,
    height: r.height,
    hide: r.hide,
    id: r.xAxisId,
    includeHidden: r.includeHidden,
    interval: r.interval,
    minTickGap: r.minTickGap,
    mirror: r.mirror,
    name: r.name,
    orientation: r.orientation,
    padding: r.padding,
    reversed: r.reversed,
    scale: r.scale,
    tick: r.tick,
    tickCount: r.tickCount,
    tickFormatter: r.tickFormatter,
    ticks: r.ticks,
    type: r.type,
    unit: r.unit
  }), /* @__PURE__ */ l.createElement(MC, r));
}, RC = /* @__PURE__ */ l.memo(NC, Bf);
RC.displayName = "XAxis";
var BC = ["dangerouslySetInnerHTML", "ticks", "scale"], KC = ["id", "scale"];
function zi() {
  return zi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, zi.apply(null, arguments);
}
function Qs(e, r) {
  if (e == null) return {};
  var t, a, n = zC(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function zC(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function WC(e) {
  var r = F(), t = l.useRef(null);
  return l.useLayoutEffect(() => {
    t.current === null ? r(eA(e)) : t.current !== e && r(rA({
      prev: t.current,
      next: e
    })), t.current = e;
  }, [e, r]), l.useLayoutEffect(() => () => {
    t.current && (r(tA(t.current)), t.current = null);
  }, [r]), null;
}
var FC = (e) => {
  var {
    yAxisId: r,
    className: t,
    width: a,
    label: n
  } = e, i = l.useRef(null), o = l.useRef(null), u = k(ro), s = te(), c = F(), d = "yAxis", v = k((w) => Vd(w, r)), f = k((w) => pb(w, r)), p = k((w) => Yd(w, d, r, s)), m = k((w) => Sd(w, r));
  if (l.useLayoutEffect(() => {
    if (!(a !== "auto" || !v || zo(n) || /* @__PURE__ */ l.isValidElement(n) || m == null)) {
      var w = i.current;
      if (w) {
        var E = w.getCalculatedWidth();
        Math.round(v.width) !== Math.round(E) && c(oA({
          id: r,
          width: E
        }));
      }
    }
  }, [
    // The dependency on cartesianAxisRef.current is not needed because useLayoutEffect will run after every render.
    // The ref will be populated by then.
    // To re-run this effect when ticks change, we can depend on the ticks array from the store.
    p,
    v,
    c,
    n,
    r,
    a,
    m
  ]), v == null || f == null || m == null)
    return null;
  var {
    dangerouslySetInnerHTML: h,
    ticks: g,
    scale: y
  } = e, b = Qs(e, BC), {
    id: x,
    scale: O
  } = m, P = Qs(m, KC);
  return /* @__PURE__ */ l.createElement(nl, zi({}, b, P, {
    ref: i,
    labelRef: o,
    x: f.x,
    y: f.y,
    tickTextProps: a === "auto" ? {
      width: void 0
    } : {
      width: a
    },
    width: v.width,
    height: v.height,
    className: R("recharts-".concat(d, " ").concat(d), t),
    viewBox: u,
    ticks: p,
    axisType: d
  }));
}, XC = {
  allowDataOverflow: Oe.allowDataOverflow,
  allowDecimals: Oe.allowDecimals,
  allowDuplicatedCategory: Oe.allowDuplicatedCategory,
  angle: Oe.angle,
  axisLine: br.axisLine,
  hide: !1,
  includeHidden: Oe.includeHidden,
  interval: Oe.interval,
  minTickGap: Oe.minTickGap,
  mirror: Oe.mirror,
  orientation: Oe.orientation,
  padding: Oe.padding,
  reversed: Oe.reversed,
  scale: Oe.scale,
  tick: Oe.tick,
  tickCount: Oe.tickCount,
  tickLine: br.tickLine,
  tickSize: br.tickSize,
  type: Oe.type,
  width: Oe.width,
  yAxisId: 0
}, VC = (e) => {
  var r = V(e, XC);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(WC, {
    interval: r.interval,
    id: r.yAxisId,
    scale: r.scale,
    type: r.type,
    domain: r.domain,
    allowDataOverflow: r.allowDataOverflow,
    dataKey: r.dataKey,
    allowDuplicatedCategory: r.allowDuplicatedCategory,
    allowDecimals: r.allowDecimals,
    tickCount: r.tickCount,
    padding: r.padding,
    includeHidden: r.includeHidden,
    reversed: r.reversed,
    ticks: r.ticks,
    width: r.width,
    orientation: r.orientation,
    mirror: r.mirror,
    hide: r.hide,
    unit: r.unit,
    name: r.name,
    angle: r.angle,
    minTickGap: r.minTickGap,
    tick: r.tick,
    tickFormatter: r.tickFormatter
  }), /* @__PURE__ */ l.createElement(FC, r));
}, GC = /* @__PURE__ */ l.memo(VC, Bf);
GC.displayName = "YAxis";
function HC(e) {
  var r = F(), t = l.useRef(null);
  return l.useLayoutEffect(() => {
    t.current === null ? r(aA(e)) : t.current !== e && r(nA({
      prev: t.current,
      next: e
    })), t.current = e;
  }, [e, r]), l.useLayoutEffect(() => () => {
    t.current && (r(iA(t.current)), t.current = null);
  }, [r]), null;
}
var YC = {
  zAxisId: 0,
  range: yr.range,
  scale: yr.scale,
  type: yr.type
};
function UC(e) {
  var r = V(e, YC);
  return /* @__PURE__ */ l.createElement(HC, {
    domain: r.domain,
    id: r.zAxisId,
    dataKey: r.dataKey,
    name: r.name,
    unit: r.unit,
    range: r.range,
    scale: r.scale,
    type: r.type,
    allowDuplicatedCategory: yr.allowDuplicatedCategory,
    allowDataOverflow: yr.allowDataOverflow,
    reversed: yr.reversed,
    includeHidden: yr.includeHidden
  });
}
UC.displayName = "ZAxis";
var ZC = {
  begin: 0,
  duration: 1e3,
  easing: "ease",
  isActive: !0,
  canBegin: !0,
  onAnimationEnd: () => {
  },
  onAnimationStart: () => {
  }
};
function Kf(e) {
  var r = V(e, ZC), {
    animationId: t,
    from: a,
    to: n,
    attributeName: i,
    isActive: o,
    canBegin: u,
    duration: s,
    easing: c,
    begin: d,
    onAnimationEnd: v,
    onAnimationStart: f,
    children: p
  } = r, m = o === "auto" ? !mt.isSsr : o, h = ad(t + i, r.animationManager), [g, y] = l.useState(() => m ? a : n), b = l.useRef(!1), x = l.useCallback(() => {
    y(a), f();
  }, [a, f]);
  if (l.useEffect(() => {
    if (!m || !u)
      return ft;
    b.current = !0;
    var P = h.subscribe(y);
    return h.start([x, d, n, s, v]), () => {
      h.stop(), P && P(), v();
    };
  }, [m, u, s, c, d, x, v, h, n, a]), !m)
    return p({
      [i]: n
    });
  if (!u)
    return p({
      [i]: a
    });
  if (b.current) {
    var O = ao([i], s, c);
    return p({
      transition: O,
      [i]: g
    });
  }
  return p({
    [i]: a
  });
}
var qC = ["direction", "width", "dataKey", "isAnimationActive", "animationBegin", "animationDuration", "animationEasing"];
function Ut() {
  return Ut = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Ut.apply(null, arguments);
}
function ec(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function rc(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? ec(Object(t), !0).forEach(function(a) {
      JC(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ec(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function JC(e, r, t) {
  return (r = QC(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function QC(e) {
  var r = eD(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function eD(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function rD(e, r) {
  if (e == null) return {};
  var t, a, n = tD(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function tD(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function aD(e) {
  var {
    direction: r,
    width: t,
    dataKey: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u
  } = e, s = rD(e, qC), c = G(s), {
    data: d,
    dataPointFormatter: v,
    xAxisId: f,
    yAxisId: p,
    errorBarOffset: m
  } = ZS(), h = cA(f), g = dA(p);
  if ((h == null ? void 0 : h.scale) == null || (g == null ? void 0 : g.scale) == null || d == null || r === "x" && h.type !== "number")
    return null;
  var y = d.map((b, x) => {
    var {
      x: O,
      y: P,
      value: w,
      errorVal: E
    } = v(b, a, r);
    if (!E || O == null || P == null)
      return null;
    var j = [], S, I;
    if (Array.isArray(E)) {
      var [D, C] = E;
      if (D == null || C == null)
        return null;
      S = D, I = C;
    } else
      S = I = E;
    if (r === "x") {
      var {
        scale: M
      } = h, T = P + m, $ = T + t, W = T - t, X = M(w - S), Z = M(w + I);
      j.push({
        x1: Z,
        y1: $,
        x2: Z,
        y2: W
      }), j.push({
        x1: X,
        y1: T,
        x2: Z,
        y2: T
      }), j.push({
        x1: X,
        y1: $,
        x2: X,
        y2: W
      });
    } else if (r === "y") {
      var {
        scale: z
      } = g, ne = O + m, ge = ne - t, fe = ne + t, Ke = z(w - S), je = z(w + I);
      j.push({
        x1: ge,
        y1: je,
        x2: fe,
        y2: je
      }), j.push({
        x1: ne,
        y1: Ke,
        x2: ne,
        y2: je
      }), j.push({
        x1: ge,
        y1: Ke,
        x2: fe,
        y2: Ke
      });
    }
    var Fe = r === "x" ? "scaleX" : "scaleY", pr = "".concat(O + m, "px ").concat(P + m, "px");
    return /* @__PURE__ */ l.createElement(_, Ut({
      className: "recharts-errorBar",
      key: "bar-".concat(O, "-").concat(P, "-").concat(w, "-").concat(x)
    }, c), j.map((ce, Qn) => {
      var H = n ? {
        transformOrigin: pr
      } : void 0;
      return /* @__PURE__ */ l.createElement(Kf, {
        animationId: "error-bar-".concat(r, "_").concat(ce.x1, "-").concat(ce.x2, "-").concat(ce.y1, "-").concat(ce.y2),
        from: "".concat(Fe, "(0)"),
        to: "".concat(Fe, "(1)"),
        attributeName: "transform",
        begin: i,
        easing: u,
        isActive: n,
        duration: o,
        key: "errorbar-".concat(x, "-").concat(ce.x1, "-").concat(ce.y1, "-").concat(ce.x2, "-").concat(ce.y2, "-").concat(Qn)
      }, (np) => /* @__PURE__ */ l.createElement("line", Ut({}, ce, {
        style: rc(rc({}, H), np)
      })));
    }));
  });
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-errorBars"
  }, y);
}
function nD(e) {
  var r = Er();
  return e ?? (r != null && r === "horizontal" ? "y" : "x");
}
var iD = {
  stroke: "black",
  strokeWidth: 1.5,
  width: 5,
  offset: 0,
  isAnimationActive: !0,
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "ease-in-out",
  zIndex: Y.line
};
function oD(e) {
  var r = nD(e.direction), t = V(e, iD), {
    width: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u,
    zIndex: s
  } = t;
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(qS, {
    dataKey: t.dataKey,
    direction: r
  }), /* @__PURE__ */ l.createElement(ee, {
    zIndex: s
  }, /* @__PURE__ */ l.createElement(aD, Ut({}, t, {
    direction: r,
    width: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u
  }))));
}
oD.displayName = "ErrorBar";
var lD = (e, r) => r, ll = A([lD, K, Ur, xe, cv, jr, jx, he], $x), ul = (e) => {
  var r = e.currentTarget.getBoundingClientRect(), t = r.width / e.currentTarget.offsetWidth, a = r.height / e.currentTarget.offsetHeight;
  return {
    /*
     * Here it's important to use:
     * - event.clientX and event.clientY to get the mouse position relative to the viewport, including scroll.
     * - pageX and pageY are not used because they are relative to the whole document, and ignore scroll.
     * - rect.left and rect.top are used to get the position of the chart relative to the viewport.
     * - offsetX and offsetY are not used because they are relative to the offset parent
     *  which may or may not be the same as the clientX and clientY, depending on the position of the chart in the DOM
     *  and surrounding element styles. CSS position: relative, absolute, fixed, will change the offset parent.
     * - scaleX and scaleY are necessary for when the chart element is scaled using CSS `transform: scale(N)`.
     */
    chartX: Math.round((e.clientX - r.left) / t),
    chartY: Math.round((e.clientY - r.top) / a)
  };
}, zf = vt("mouseClick"), Wf = Jt();
Wf.startListening({
  actionCreator: zf,
  effect: (e, r) => {
    var t = e.payload, a = ll(r.getState(), ul(t));
    (a == null ? void 0 : a.activeIndex) != null && r.dispatch(Eb({
      activeIndex: a.activeIndex,
      activeDataKey: void 0,
      activeCoordinate: a.activeCoordinate
    }));
  }
});
var Wi = vt("mouseMove"), Ff = Jt(), Da = null;
Ff.startListening({
  actionCreator: Wi,
  effect: (e, r) => {
    var t = e.payload;
    Da !== null && cancelAnimationFrame(Da);
    var a = ul(t);
    Da = requestAnimationFrame(() => {
      var n = r.getState(), i = Co(n, n.tooltip.settings.shared);
      if (i === "axis") {
        var o = ll(n, a);
        (o == null ? void 0 : o.activeIndex) != null ? r.dispatch(tv({
          activeIndex: o.activeIndex,
          activeDataKey: void 0,
          activeCoordinate: o.activeCoordinate
        })) : r.dispatch(rv());
      }
      Da = null;
    });
  }
});
function uD(e, r) {
  return r instanceof HTMLElement ? "HTMLElement <".concat(r.tagName, ' class="').concat(r.className, '">') : r === window ? "global.window" : e === "children" && typeof r == "object" && r !== null ? "<<CHILDREN>>" : r;
}
var tc = {
  accessibilityLayer: !0,
  barCategoryGap: "10%",
  barGap: 4,
  barSize: void 0,
  className: void 0,
  maxBarSize: void 0,
  stackOffset: "none",
  syncId: void 0,
  syncMethod: "index",
  baseValue: void 0,
  reverseStackOrder: !1
}, Xf = Be({
  name: "rootProps",
  initialState: tc,
  reducers: {
    updateOptions: (e, r) => {
      var t;
      e.accessibilityLayer = r.payload.accessibilityLayer, e.barCategoryGap = r.payload.barCategoryGap, e.barGap = (t = r.payload.barGap) !== null && t !== void 0 ? t : tc.barGap, e.barSize = r.payload.barSize, e.maxBarSize = r.payload.maxBarSize, e.stackOffset = r.payload.stackOffset, e.syncId = r.payload.syncId, e.syncMethod = r.payload.syncMethod, e.className = r.payload.className, e.baseValue = r.payload.baseValue, e.reverseStackOrder = r.payload.reverseStackOrder;
    }
  }
}), sD = Xf.reducer, {
  updateOptions: cD
} = Xf.actions, Vf = Be({
  name: "polarOptions",
  initialState: null,
  reducers: {
    updatePolarOptions: (e, r) => r.payload
  }
}), {
  updatePolarOptions: dD
} = Vf.actions, vD = Vf.reducer, Gf = vt("keyDown"), Hf = vt("focus"), sl = Jt();
sl.startListening({
  actionCreator: Gf,
  effect: (e, r) => {
    var t = r.getState(), a = t.rootProps.accessibilityLayer !== !1;
    if (a) {
      var {
        keyboardInteraction: n
      } = t.tooltip, i = e.payload;
      if (!(i !== "ArrowRight" && i !== "ArrowLeft" && i !== "Enter")) {
        var o = To(n, Et(t), ca(t), pa(t)), u = o == null ? -1 : Number(o);
        if (!(!Number.isFinite(u) || u < 0)) {
          var s = jr(t);
          if (i === "Enter") {
            var c = Ua(t, "axis", "hover", String(n.index));
            r.dispatch(Ai({
              active: !n.active,
              activeIndex: n.index,
              activeCoordinate: c
            }));
            return;
          }
          var d = yb(t), v = d === "left-to-right" ? 1 : -1, f = i === "ArrowRight" ? 1 : -1, p = u + f * v;
          if (!(s == null || p >= s.length || p < 0)) {
            var m = Ua(t, "axis", "hover", String(p));
            r.dispatch(Ai({
              active: !0,
              activeIndex: p.toString(),
              activeCoordinate: m
            }));
          }
        }
      }
    }
  }
});
sl.startListening({
  actionCreator: Hf,
  effect: (e, r) => {
    var t = r.getState(), a = t.rootProps.accessibilityLayer !== !1;
    if (a) {
      var {
        keyboardInteraction: n
      } = t.tooltip;
      if (!n.active && n.index == null) {
        var i = "0", o = Ua(t, "axis", "hover", String(i));
        r.dispatch(Ai({
          active: !0,
          activeIndex: i,
          activeCoordinate: o
        }));
      }
    }
  }
});
var Xe = vt("externalEvent"), Yf = Jt(), ui = /* @__PURE__ */ new Map();
Yf.startListening({
  actionCreator: Xe,
  effect: (e, r) => {
    var {
      handler: t,
      reactEvent: a
    } = e.payload;
    if (t != null) {
      a.persist();
      var n = a.type, i = ui.get(n);
      i !== void 0 && cancelAnimationFrame(i);
      var o = requestAnimationFrame(() => {
        try {
          var u = r.getState(), s = {
            activeCoordinate: dx(u),
            activeDataKey: No(u),
            activeIndex: nr(u),
            activeLabel: fv(u),
            activeTooltipIndex: nr(u),
            isTooltipActive: vx(u)
          };
          t(s, a);
        } finally {
          ui.delete(n);
        }
      });
      ui.set(n, o);
    }
  }
});
var fD = A([wt], (e) => e.tooltipItemPayloads), pD = A([fD, fa, (e, r) => r, (e, r, t) => t], (e, r, t, a) => {
  var n = e.find((u) => u.settings.graphicalItemId === a);
  if (n != null) {
    var {
      positions: i
    } = n;
    if (i != null) {
      var o = r(i, t);
      return o;
    }
  }
}), Uf = vt("touchMove"), Zf = Jt();
Zf.startListening({
  actionCreator: Uf,
  effect: (e, r) => {
    var t = e.payload;
    if (!(t.touches == null || t.touches.length === 0)) {
      var a = r.getState(), n = Co(a, a.tooltip.settings.shared);
      if (n === "axis") {
        var i = t.touches[0];
        if (i == null)
          return;
        var o = ll(a, ul({
          clientX: i.clientX,
          clientY: i.clientY,
          currentTarget: t.currentTarget
        }));
        (o == null ? void 0 : o.activeIndex) != null && r.dispatch(tv({
          activeIndex: o.activeIndex,
          activeDataKey: void 0,
          activeCoordinate: o.activeCoordinate
        }));
      } else if (n === "item") {
        var u, s = t.touches[0];
        if (document.elementFromPoint == null || s == null)
          return;
        var c = document.elementFromPoint(s.clientX, s.clientY);
        if (!c || !c.getAttribute)
          return;
        var d = c.getAttribute(Qi), v = (u = c.getAttribute(eo)) !== null && u !== void 0 ? u : void 0, f = At(a).find((h) => h.id === v);
        if (d == null || f == null || v == null)
          return;
        var {
          dataKey: p
        } = f, m = pD(a, d, v);
        r.dispatch(Ot({
          activeDataKey: p,
          activeIndex: d,
          activeCoordinate: m,
          activeGraphicalItemId: v
        }));
      }
    }
  }
});
var mD = Wp({
  brush: UE,
  cartesianAxis: lA,
  chartData: lP,
  errorBars: VS,
  graphicalItems: dw,
  layout: Km,
  legend: Ch,
  options: tP,
  polarAxis: e0,
  polarOptions: vD,
  referenceElements: Oj,
  rootProps: sD,
  tooltip: jb,
  zIndex: Hx
}), hD = function(r) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Chart";
  return Kp({
    reducer: mD,
    // redux-toolkit v1 types are unhappy with the preloadedState type. Remove the `as any` when bumping to v2
    preloadedState: r,
    // @ts-expect-error redux-toolkit v1 types are unhappy with the middleware array. Remove this comment when bumping to v2
    middleware: (a) => {
      var n;
      return a({
        serializableCheck: !1,
        immutableCheck: !["commonjs", "es6", "production"].includes((n = "es6") !== null && n !== void 0 ? n : "")
      }).concat([Wf.middleware, Ff.middleware, sl.middleware, Yf.middleware, Zf.middleware]);
    },
    /*
     * I can't find out how to satisfy typescript here.
     * We return `EnhancerArray<[StoreEnhancer<{}, {}>, StoreEnhancer]>` from this function,
     * but the types say we should return `EnhancerArray<StoreEnhancer<{}, {}>`.
     * Looks like it's badly inferred generics, but it won't allow me to provide the correct type manually either.
     * So let's just ignore the error for now.
     */
    // @ts-expect-error mismatched generics
    enhancers: (a) => {
      var n = a;
      return typeof a == "function" && (n = a()), n.concat(zp({
        type: "raf"
      }));
    },
    devTools: {
      serialize: {
        replacer: uD
      },
      name: "recharts-".concat(t)
    }
  });
};
function Zn(e) {
  var {
    preloadedState: r,
    children: t,
    reduxStoreName: a
  } = e, n = te(), i = l.useRef(null);
  if (n)
    return t;
  i.current == null && (i.current = hD(r, a));
  var o = Ji;
  return /* @__PURE__ */ l.createElement(Fp, {
    context: o,
    store: i.current
  }, t);
}
function yD(e) {
  var {
    layout: r,
    margin: t
  } = e, a = F(), n = te();
  return l.useEffect(() => {
    n || (a(Nm(r)), a(Mc(t)));
  }, [a, n, r, t]), null;
}
var qf = /* @__PURE__ */ l.memo(yD, Dt);
function Jf(e) {
  var r = F();
  return l.useEffect(() => {
    r(cD(e));
  }, [r, e]), null;
}
function ac(e) {
  var {
    zIndex: r,
    isPanorama: t
  } = e, a = l.useRef(null), n = F();
  return l.useLayoutEffect(() => (a.current && n(Vx({
    zIndex: r,
    element: a.current,
    isPanorama: t
  })), () => {
    n(Gx({
      zIndex: r,
      isPanorama: t
    }));
  }), [n, r, t]), /* @__PURE__ */ l.createElement("g", {
    tabIndex: -1,
    ref: a
  });
}
function nc(e) {
  var {
    children: r,
    isPanorama: t
  } = e, a = k(Mx);
  if (!a || a.length === 0)
    return r;
  var n = a.filter((o) => o < 0), i = a.filter((o) => o > 0);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, n.map((o) => /* @__PURE__ */ l.createElement(ac, {
    key: o,
    zIndex: o,
    isPanorama: t
  })), r, i.map((o) => /* @__PURE__ */ l.createElement(ac, {
    key: o,
    zIndex: o,
    isPanorama: t
  })));
}
var gD = ["children"];
function bD(e, r) {
  if (e == null) return {};
  var t, a, n = xD(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function xD(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function dn() {
  return dn = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, dn.apply(null, arguments);
}
var PD = {
  width: "100%",
  height: "100%",
  /*
   * display: block is necessary here because the default for an SVG is display: inline,
   * which in some browsers (Chrome) adds a little bit of extra space above and below the SVG
   * to make space for the descender of letters like "g" and "y". This throws off the height calculation
   * and causes the container to grow indefinitely on each render with responsive=true.
   * Display: block removes that extra space.
   *
   * Interestingly, Firefox does not have this problem, but it doesn't hurt to add the style anyway.
   */
  display: "block"
}, OD = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = aa(), a = na(), n = Qc();
  if (!_e(t) || !_e(a))
    return null;
  var {
    children: i,
    otherAttributes: o,
    title: u,
    desc: s
  } = e, c, d;
  return o != null && (typeof o.tabIndex == "number" ? c = o.tabIndex : c = n ? 0 : void 0, typeof o.role == "string" ? d = o.role : d = n ? "application" : void 0), /* @__PURE__ */ l.createElement(Qt, dn({}, o, {
    title: u,
    desc: s,
    role: d,
    tabIndex: c,
    width: t,
    height: a,
    style: PD,
    ref: r
  }), i);
}), wD = (e) => {
  var {
    children: r
  } = e, t = k(ta);
  if (!t)
    return null;
  var {
    width: a,
    height: n,
    y: i,
    x: o
  } = t;
  return /* @__PURE__ */ l.createElement(Qt, {
    width: a,
    height: n,
    x: o,
    y: i
  }, r);
}, ic = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    children: t
  } = e, a = bD(e, gD), n = te();
  return n ? /* @__PURE__ */ l.createElement(wD, null, /* @__PURE__ */ l.createElement(nc, {
    isPanorama: !0
  }, t)) : /* @__PURE__ */ l.createElement(OD, dn({
    ref: r
  }, a), /* @__PURE__ */ l.createElement(nc, {
    isPanorama: !1
  }, t));
});
function AD() {
  var e = F(), [r, t] = l.useState(null), a = k(rh);
  return l.useEffect(() => {
    if (r != null) {
      var n = r.getBoundingClientRect(), i = n.width / r.offsetWidth;
      q(i) && i !== a && e(Bm(i));
    }
  }, [r, e, a]), t;
}
function oc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ED(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? oc(Object(t), !0).forEach(function(a) {
      jD(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : oc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function jD(e, r, t) {
  return (r = SD(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function SD(e) {
  var r = ID(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function ID(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Hr() {
  return Hr = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Hr.apply(null, arguments);
}
var kD = () => (hP(), null);
function vn(e) {
  if (typeof e == "number")
    return e;
  if (typeof e == "string") {
    var r = parseFloat(e);
    if (!Number.isNaN(r))
      return r;
  }
  return 0;
}
var CD = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t, a, n = l.useRef(null), [i, o] = l.useState({
    containerWidth: vn((t = e.style) === null || t === void 0 ? void 0 : t.width),
    containerHeight: vn((a = e.style) === null || a === void 0 ? void 0 : a.height)
  }), u = l.useCallback((c, d) => {
    o((v) => {
      var f = Math.round(c), p = Math.round(d);
      return v.containerWidth === f && v.containerHeight === p ? v : {
        containerWidth: f,
        containerHeight: p
      };
    });
  }, []), s = l.useCallback((c) => {
    if (typeof r == "function" && r(c), c != null && typeof ResizeObserver < "u") {
      var {
        width: d,
        height: v
      } = c.getBoundingClientRect();
      u(d, v);
      var f = (m) => {
        var {
          width: h,
          height: g
        } = m[0].contentRect;
        u(h, g);
      }, p = new ResizeObserver(f);
      p.observe(c), n.current = p;
    }
  }, [r, u]);
  return l.useEffect(() => () => {
    var c = n.current;
    c != null && c.disconnect();
  }, [u]), /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(ia, {
    width: i.containerWidth,
    height: i.containerHeight
  }), /* @__PURE__ */ l.createElement("div", Hr({
    ref: s
  }, e)));
}), DD = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    width: t,
    height: a
  } = e, [n, i] = l.useState({
    containerWidth: vn(t),
    containerHeight: vn(a)
  }), o = l.useCallback((s, c) => {
    i((d) => {
      var v = Math.round(s), f = Math.round(c);
      return d.containerWidth === v && d.containerHeight === f ? d : {
        containerWidth: v,
        containerHeight: f
      };
    });
  }, []), u = l.useCallback((s) => {
    if (typeof r == "function" && r(s), s != null) {
      var {
        width: c,
        height: d
      } = s.getBoundingClientRect();
      o(c, d);
    }
  }, [r, o]);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(ia, {
    width: n.containerWidth,
    height: n.containerHeight
  }), /* @__PURE__ */ l.createElement("div", Hr({
    ref: u
  }, e)));
}), TD = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    width: t,
    height: a
  } = e;
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(ia, {
    width: t,
    height: a
  }), /* @__PURE__ */ l.createElement("div", Hr({
    ref: r
  }, e)));
}), $D = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    width: t,
    height: a
  } = e;
  return xr(t) || xr(a) ? /* @__PURE__ */ l.createElement(DD, Hr({}, e, {
    ref: r
  })) : /* @__PURE__ */ l.createElement(TD, Hr({}, e, {
    ref: r
  }));
});
function LD(e) {
  return e === !0 ? CD : $D;
}
var cl = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    children: t,
    className: a,
    height: n,
    onClick: i,
    onContextMenu: o,
    onDoubleClick: u,
    onMouseDown: s,
    onMouseEnter: c,
    onMouseLeave: d,
    onMouseMove: v,
    onMouseUp: f,
    onTouchEnd: p,
    onTouchMove: m,
    onTouchStart: h,
    style: g,
    width: y,
    responsive: b,
    dispatchTouchEvents: x = !0
  } = e, O = l.useRef(null), P = F(), [w, E] = l.useState(null), [j, S] = l.useState(null), I = AD(), D = to(), C = (D == null ? void 0 : D.width) > 0 ? D.width : y, M = (D == null ? void 0 : D.height) > 0 ? D.height : n, T = l.useCallback((H) => {
    I(H), typeof r == "function" && r(H), E(H), S(H), H != null && (O.current = H);
  }, [I, r, E, S]), $ = l.useCallback((H) => {
    P(zf(H)), P(Xe({
      handler: i,
      reactEvent: H
    }));
  }, [P, i]), W = l.useCallback((H) => {
    P(Wi(H)), P(Xe({
      handler: c,
      reactEvent: H
    }));
  }, [P, c]), X = l.useCallback((H) => {
    P(rv()), P(Xe({
      handler: d,
      reactEvent: H
    }));
  }, [P, d]), Z = l.useCallback((H) => {
    P(Wi(H)), P(Xe({
      handler: v,
      reactEvent: H
    }));
  }, [P, v]), z = l.useCallback(() => {
    P(Hf());
  }, [P]), ne = l.useCallback((H) => {
    P(Gf(H.key));
  }, [P]), ge = l.useCallback((H) => {
    P(Xe({
      handler: o,
      reactEvent: H
    }));
  }, [P, o]), fe = l.useCallback((H) => {
    P(Xe({
      handler: u,
      reactEvent: H
    }));
  }, [P, u]), Ke = l.useCallback((H) => {
    P(Xe({
      handler: s,
      reactEvent: H
    }));
  }, [P, s]), je = l.useCallback((H) => {
    P(Xe({
      handler: f,
      reactEvent: H
    }));
  }, [P, f]), Fe = l.useCallback((H) => {
    P(Xe({
      handler: h,
      reactEvent: H
    }));
  }, [P, h]), pr = l.useCallback((H) => {
    x && P(Uf(H)), P(Xe({
      handler: m,
      reactEvent: H
    }));
  }, [P, x, m]), ce = l.useCallback((H) => {
    P(Xe({
      handler: p,
      reactEvent: H
    }));
  }, [P, p]), Qn = LD(b);
  return /* @__PURE__ */ l.createElement(Rn.Provider, {
    value: w
  }, /* @__PURE__ */ l.createElement(jc.Provider, {
    value: j
  }, /* @__PURE__ */ l.createElement(Qn, {
    width: C ?? (g == null ? void 0 : g.width),
    height: M ?? (g == null ? void 0 : g.height),
    className: R("recharts-wrapper", a),
    style: ED({
      position: "relative",
      cursor: "default",
      width: C,
      height: M
    }, g),
    onClick: $,
    onContextMenu: ge,
    onDoubleClick: fe,
    onFocus: z,
    onKeyDown: ne,
    onMouseDown: Ke,
    onMouseEnter: W,
    onMouseLeave: X,
    onMouseMove: Z,
    onMouseUp: je,
    onTouchEnd: ce,
    onTouchMove: pr,
    onTouchStart: Fe,
    ref: T
  }, /* @__PURE__ */ l.createElement(kD, null), t)));
}), MD = ["width", "height", "responsive", "children", "className", "style", "compact", "title", "desc"];
function _D(e, r) {
  if (e == null) return {};
  var t, a, n = ND(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function ND(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var Qf = /* @__PURE__ */ l.forwardRef((e, r) => {
  var {
    width: t,
    height: a,
    responsive: n,
    children: i,
    className: o,
    style: u,
    compact: s,
    title: c,
    desc: d
  } = e, v = _D(e, MD), f = G(v);
  return s ? /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(ia, {
    width: t,
    height: a
  }), /* @__PURE__ */ l.createElement(ic, {
    otherAttributes: f,
    title: c,
    desc: d
  }, i)) : /* @__PURE__ */ l.createElement(cl, {
    className: o,
    style: u,
    width: t,
    height: a,
    responsive: n ?? !1,
    onClick: e.onClick,
    onMouseLeave: e.onMouseLeave,
    onMouseEnter: e.onMouseEnter,
    onMouseMove: e.onMouseMove,
    onMouseDown: e.onMouseDown,
    onMouseUp: e.onMouseUp,
    onContextMenu: e.onContextMenu,
    onDoubleClick: e.onDoubleClick,
    onTouchStart: e.onTouchStart,
    onTouchMove: e.onTouchMove,
    onTouchEnd: e.onTouchEnd
  }, /* @__PURE__ */ l.createElement(ic, {
    otherAttributes: f,
    title: c,
    desc: d,
    ref: r
  }, /* @__PURE__ */ l.createElement(wj, null, i)));
});
function Fi() {
  return Fi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Fi.apply(null, arguments);
}
var RD = {
  top: 5,
  right: 5,
  bottom: 5,
  left: 5
}, BD = {
  accessibilityLayer: !0,
  barCategoryGap: "10%",
  barGap: 4,
  layout: "horizontal",
  margin: RD,
  responsive: !1,
  reverseStackOrder: !1,
  stackOffset: "none",
  syncMethod: "index"
}, Tt = /* @__PURE__ */ l.forwardRef(function(r, t) {
  var a, n = V(r.categoricalChartProps, BD), {
    chartName: i,
    defaultTooltipEventType: o,
    validateTooltipEventTypes: u,
    tooltipPayloadSearcher: s,
    categoricalChartProps: c
  } = r, d = {
    chartName: i,
    defaultTooltipEventType: o,
    validateTooltipEventTypes: u,
    tooltipPayloadSearcher: s,
    eventEmitter: void 0
  };
  return /* @__PURE__ */ l.createElement(Zn, {
    preloadedState: {
      options: d
    },
    reduxStoreName: (a = c.id) !== null && a !== void 0 ? a : i
  }, /* @__PURE__ */ l.createElement(cf, {
    chartData: c.data
  }), /* @__PURE__ */ l.createElement(qf, {
    layout: n.layout,
    margin: n.margin
  }), /* @__PURE__ */ l.createElement(Jf, {
    baseValue: n.baseValue,
    accessibilityLayer: n.accessibilityLayer,
    barCategoryGap: n.barCategoryGap,
    maxBarSize: n.maxBarSize,
    stackOffset: n.stackOffset,
    barGap: n.barGap,
    barSize: n.barSize,
    syncId: n.syncId,
    syncMethod: n.syncMethod,
    className: n.className,
    reverseStackOrder: n.reverseStackOrder
  }), /* @__PURE__ */ l.createElement(Qf, Fi({}, n, {
    ref: t
  })));
}), KD = ["axis"], BT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "LineChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: KD,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
})), zD = ["axis", "item"], KT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "BarChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: zD,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
}));
function WD(e) {
  var r = F();
  return l.useEffect(() => {
    r(dD(e));
  }, [r, e]), null;
}
var FD = ["layout"];
function Xi() {
  return Xi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Xi.apply(null, arguments);
}
function XD(e, r) {
  if (e == null) return {};
  var t, a, n = VD(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function VD(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
var GD = {
  top: 5,
  right: 5,
  bottom: 5,
  left: 5
}, qn = {
  accessibilityLayer: !0,
  stackOffset: "none",
  barCategoryGap: "10%",
  barGap: 4,
  margin: GD,
  reverseStackOrder: !1,
  syncMethod: "index",
  layout: "radial",
  responsive: !1,
  cx: "50%",
  cy: "50%",
  innerRadius: 0,
  outerRadius: "80%"
}, dl = /* @__PURE__ */ l.forwardRef(function(r, t) {
  var a, n = V(r.categoricalChartProps, qn), {
    layout: i
  } = n, o = XD(n, FD), {
    chartName: u,
    defaultTooltipEventType: s,
    validateTooltipEventTypes: c,
    tooltipPayloadSearcher: d
  } = r, v = {
    chartName: u,
    defaultTooltipEventType: s,
    validateTooltipEventTypes: c,
    tooltipPayloadSearcher: d,
    eventEmitter: void 0
  };
  return /* @__PURE__ */ l.createElement(Zn, {
    preloadedState: {
      options: v
    },
    reduxStoreName: (a = n.id) !== null && a !== void 0 ? a : u
  }, /* @__PURE__ */ l.createElement(cf, {
    chartData: n.data
  }), /* @__PURE__ */ l.createElement(qf, {
    layout: i,
    margin: n.margin
  }), /* @__PURE__ */ l.createElement(Jf, {
    baseValue: void 0,
    accessibilityLayer: n.accessibilityLayer,
    barCategoryGap: n.barCategoryGap,
    maxBarSize: n.maxBarSize,
    stackOffset: n.stackOffset,
    barGap: n.barGap,
    barSize: n.barSize,
    syncId: n.syncId,
    syncMethod: n.syncMethod,
    className: n.className,
    reverseStackOrder: n.reverseStackOrder
  }), /* @__PURE__ */ l.createElement(WD, {
    cx: n.cx,
    cy: n.cy,
    startAngle: n.startAngle,
    endAngle: n.endAngle,
    innerRadius: n.innerRadius,
    outerRadius: n.outerRadius
  }), /* @__PURE__ */ l.createElement(Qf, Xi({}, o, {
    ref: t
  })));
});
function lc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function uc(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? lc(Object(t), !0).forEach(function(a) {
      HD(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : lc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function HD(e, r, t) {
  return (r = YD(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function YD(e) {
  var r = UD(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function UD(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var ZD = ["item"], qD = uc(uc({}, qn), {}, {
  layout: "centric",
  startAngle: 0,
  endAngle: 360
}), zT = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = V(e, qD);
  return /* @__PURE__ */ l.createElement(dl, {
    chartName: "PieChart",
    defaultTooltipEventType: "item",
    validateTooltipEventTypes: ZD,
    tooltipPayloadSearcher: Sr,
    categoricalChartProps: t,
    ref: r
  });
}), JD = ["width", "height", "className", "style", "children", "type"];
function QD(e, r) {
  if (e == null) return {};
  var t, a, n = e1(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function e1(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function ct() {
  return ct = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, ct.apply(null, arguments);
}
function sc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function ie(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? sc(Object(t), !0).forEach(function(a) {
      zt(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : sc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function zt(e, r, t) {
  return (r = r1(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function r1(e) {
  var r = t1(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function t1(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var fn = "value", ep = (e, r) => {
  if (!(!e || !r))
    return tr(e, r);
}, a1 = function(r) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
  return "".concat(t, "children[").concat(r, "]");
}, n1 = {
  chartName: "Treemap",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: ["item"],
  tooltipPayloadSearcher: ep,
  eventEmitter: void 0
}, Ma = (e) => {
  var {
    depth: r,
    node: t,
    index: a,
    dataKey: n,
    nameKey: i,
    nestedActiveTooltipIndex: o
  } = e, u = r === 0 ? "" : a1(a, o), {
    children: s
  } = t, c = r + 1, d = s && s.length ? s.map((f, p) => Ma({
    depth: c,
    node: f,
    index: p,
    dataKey: n,
    nameKey: i,
    nestedActiveTooltipIndex: u
  })) : null, v;
  return d && d.length ? v = d.reduce((f, p) => f + p[fn], 0) : v = De(t[n]) || t[n] <= 0 ? 0 : t[n], ie(ie({}, t), {}, {
    children: d,
    // @ts-expect-error getValueByDataKey does not validate the output type
    name: B(t, i, ""),
    [fn]: v,
    depth: r,
    index: a,
    tooltipIndex: u
  });
}, i1 = (e) => ({
  x: e.x,
  y: e.y,
  width: e.width,
  height: e.height
}), o1 = (e, r) => {
  var t = r < 0 ? 0 : r;
  return e.map((a) => {
    var n = a[fn] * t;
    return ie(ie({}, a), {}, {
      area: De(n) || n <= 0 ? 0 : n
    });
  });
}, l1 = (e, r, t) => {
  var a = r * r, n = e.area * e.area, {
    min: i,
    max: o
  } = e.reduce((u, s) => ({
    min: Math.min(u.min, s.area),
    max: Math.max(u.max, s.area)
  }), {
    min: 1 / 0,
    max: 0
  });
  return n ? Math.max(a * o * t / n, n / (a * i * t)) : 1 / 0;
}, u1 = (e, r, t, a) => {
  var n = r ? Math.round(e.area / r) : 0;
  (a || n > t.height) && (n = t.height);
  for (var i = t.x, o, u = 0, s = e.length; u < s; u++)
    o = e[u], o.x = i, o.y = t.y, o.height = n, o.width = Math.min(n ? Math.round(o.area / n) : 0, t.x + t.width - i), i += o.width;
  return o != null && (o.width += t.x + t.width - i), ie(ie({}, t), {}, {
    y: t.y + n,
    height: t.height - n
  });
}, s1 = (e, r, t, a) => {
  var n = r ? Math.round(e.area / r) : 0;
  (a || n > t.width) && (n = t.width);
  for (var i = t.y, o, u = 0, s = e.length; u < s; u++)
    o = e[u], o.x = t.x, o.y = i, o.width = n, o.height = Math.min(n ? Math.round(o.area / n) : 0, t.y + t.height - i), i += o.height;
  return o && (o.height += t.y + t.height - i), ie(ie({}, t), {}, {
    x: t.x + n,
    width: t.width - n
  });
}, cc = (e, r, t, a) => r === t.width ? u1(e, r, t, a) : s1(e, r, t, a), _a = (e, r) => {
  var {
    children: t
  } = e;
  if (t && t.length) {
    var a = i1(e), n = [], i = 1 / 0, o, u, s = Math.min(a.width, a.height), c = o1(t, a.width * a.height / e[fn]), d = c.slice();
    for (n.area = 0; d.length > 0; )
      if (n.push(o = d[0]), n.area += o.area, u = l1(n, s, r), u <= i)
        d.shift(), i = u;
      else {
        var v, f;
        n.area -= (v = (f = n.pop()) === null || f === void 0 ? void 0 : f.area) !== null && v !== void 0 ? v : 0, a = cc(n, s, a, !1), s = Math.min(a.width, a.height), n.length = n.area = 0, i = 1 / 0;
      }
    return n.length && (a = cc(n, s, a, !0), n.length = n.area = 0), ie(ie({}, e), {}, {
      children: c.map((p) => _a(p, r))
    });
  }
  return e;
}, Vi = {
  aspectRatio: 0.5 * (1 + Math.sqrt(5)),
  dataKey: "value",
  nameKey: "name",
  type: "flat",
  isAnimationActive: "auto",
  isUpdateAnimationActive: "auto",
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "linear"
}, c1 = {
  isAnimationFinished: !1,
  formatRoot: null,
  currentRoot: null,
  nestIndex: [],
  prevAspectRatio: Vi.aspectRatio,
  prevDataKey: Vi.dataKey
};
function d1(e) {
  var {
    content: r,
    nodeProps: t,
    type: a,
    colorPanel: n,
    onMouseEnter: i,
    onMouseLeave: o,
    onClick: u
  } = e;
  if (/* @__PURE__ */ l.isValidElement(r))
    return /* @__PURE__ */ l.createElement(_, {
      onMouseEnter: i,
      onMouseLeave: o,
      onClick: u
    }, /* @__PURE__ */ l.cloneElement(r, t));
  if (typeof r == "function")
    return /* @__PURE__ */ l.createElement(_, {
      onMouseEnter: i,
      onMouseLeave: o,
      onClick: u
    }, r(t));
  var {
    x: s,
    y: c,
    width: d,
    height: v,
    index: f
  } = t, p = null;
  d > 10 && v > 10 && t.children && a === "nest" && (p = /* @__PURE__ */ l.createElement(Wo, {
    points: [{
      x: s + 2,
      y: c + v / 2
    }, {
      x: s + 6,
      y: c + v / 2 + 3
    }, {
      x: s + 2,
      y: c + v / 2 + 6
    }]
  }));
  var m = null, h = nt(t.name);
  d > 20 && v > 20 && h.width < d && h.height < v && (m = /* @__PURE__ */ l.createElement("text", {
    x: s + 8,
    y: c + v / 2 + 7,
    fontSize: 14
  }, t.name));
  var g = n || th;
  return /* @__PURE__ */ l.createElement("g", null, /* @__PURE__ */ l.createElement(oa, ct({
    fill: t.depth < 2 ? g[f % g.length] : "rgba(255,255,255,0)",
    stroke: "#fff"
  }, wc(t, ["children"]), {
    onMouseEnter: i,
    onMouseLeave: o,
    onClick: u,
    "data-recharts-item-index": t.tooltipIndex
  })), p, m);
}
function v1(e) {
  var r = F(), t = {
    x: e.nodeProps.x + e.nodeProps.width / 2,
    y: e.nodeProps.y + e.nodeProps.height / 2
  }, a = () => {
    r(Ot({
      activeIndex: e.nodeProps.tooltipIndex,
      activeDataKey: e.dataKey,
      activeCoordinate: t,
      activeGraphicalItemId: e.id
    }));
  }, n = () => {
  }, i = () => {
    r(_n({
      activeIndex: e.nodeProps.tooltipIndex,
      activeDataKey: e.dataKey,
      activeCoordinate: t,
      activeGraphicalItemId: e.id
    }));
  };
  return /* @__PURE__ */ l.createElement(d1, ct({}, e, {
    onMouseEnter: a,
    onMouseLeave: n,
    onClick: i
  }));
}
var f1 = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    nameKey: t,
    stroke: a,
    fill: n,
    currentRoot: i,
    id: o
  } = e, u = {
    dataDefinedOnItem: i,
    positions: void 0,
    // TODO I think Treemap has the capability of computing positions and supporting defaultIndex? Except it doesn't yet
    settings: {
      stroke: a,
      strokeWidth: void 0,
      fill: n,
      dataKey: r,
      nameKey: t,
      name: void 0,
      // Each TreemapNode has its own name
      hide: !1,
      type: void 0,
      color: n,
      unit: "",
      graphicalItemId: o
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: u
  });
}), p1 = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0
};
function m1(e) {
  var {
    content: r,
    nodeProps: t,
    isLeaf: a,
    treemapProps: n,
    onNestClick: i
  } = e, {
    id: o,
    isAnimationActive: u,
    animationBegin: s,
    animationDuration: c,
    animationEasing: d,
    isUpdateAnimationActive: v,
    type: f,
    colorPanel: p,
    dataKey: m,
    onAnimationStart: h,
    onAnimationEnd: g,
    onMouseEnter: y,
    onClick: b,
    onMouseLeave: x
  } = n, {
    width: O,
    height: P,
    x: w,
    y: E
  } = t, j = -w - O, S = 0, I = ($) => {
    (a || f === "nest") && typeof y == "function" && y(t, $);
  }, D = ($) => {
    (a || f === "nest") && typeof x == "function" && x(t, $);
  }, C = () => {
    f === "nest" && i(t), (a || f === "nest") && typeof b == "function" && b(t);
  }, M = l.useCallback(() => {
    typeof g == "function" && g();
  }, [g]), T = l.useCallback(() => {
    typeof h == "function" && h();
  }, [h]);
  return /* @__PURE__ */ l.createElement(Kf, {
    animationId: "treemap-".concat(t.tooltipIndex),
    from: "translate(".concat(j, "px, ").concat(S, "px)"),
    to: "translate(0, 0)",
    attributeName: "transform",
    begin: s,
    easing: d,
    isActive: u,
    duration: c,
    onAnimationStart: T,
    onAnimationEnd: M
  }, ($) => /* @__PURE__ */ l.createElement(_, {
    onMouseEnter: I,
    onMouseLeave: D,
    onClick: C,
    style: ie(ie({}, $), {}, {
      transformOrigin: "".concat(w, " ").concat(E)
    })
  }, /* @__PURE__ */ l.createElement(v1, {
    id: o,
    content: r,
    dataKey: m,
    nodeProps: ie(ie({}, t), {}, {
      isAnimationActive: u,
      isUpdateAnimationActive: !v,
      width: O,
      height: P,
      x: w,
      y: E
    }),
    type: f,
    colorPanel: p
  })));
}
class rp extends l.PureComponent {
  constructor() {
    super(...arguments), zt(this, "state", ie({}, c1)), zt(this, "handleClick", (r) => {
      var {
        onClick: t,
        type: a
      } = this.props;
      if (a === "nest" && r.children) {
        var {
          width: n,
          height: i,
          dataKey: o,
          nameKey: u,
          aspectRatio: s
        } = this.props, c = Ma({
          depth: 0,
          node: ie(ie({}, r), {}, {
            x: 0,
            y: 0,
            width: n,
            height: i
          }),
          index: 0,
          dataKey: o,
          nameKey: u,
          // with Treemap nesting, should this continue nesting the index or start from empty string?
          nestedActiveTooltipIndex: r.tooltipIndex
        }), d = _a(c, s), {
          nestIndex: v
        } = this.state;
        v.push(r), this.setState({
          formatRoot: d,
          currentRoot: c,
          nestIndex: v
        });
      }
      t && t(r);
    }), zt(this, "handleTouchMove", (r) => {
      var t = r.touches[0], a = document.elementFromPoint(t.clientX, t.clientY);
      if (!(!a || !a.getAttribute || this.state.formatRoot == null)) {
        var n = a.getAttribute("data-recharts-item-index"), i = ep(this.state.formatRoot, n);
        if (i) {
          var {
            dataKey: o,
            dispatch: u
          } = this.props, s = {
            x: i.x + i.width / 2,
            y: i.y + i.height / 2
          };
          u(Ot({
            activeIndex: n,
            activeDataKey: o,
            activeCoordinate: s,
            activeGraphicalItemId: this.props.id
          }));
        }
      }
    });
  }
  static getDerivedStateFromProps(r, t) {
    if (r.data !== t.prevData || r.type !== t.prevType || r.width !== t.prevWidth || r.height !== t.prevHeight || r.dataKey !== t.prevDataKey || r.aspectRatio !== t.prevAspectRatio) {
      var a = Ma({
        depth: 0,
        // @ts-expect-error missing properties
        node: {
          children: r.data,
          x: 0,
          y: 0,
          width: r.width,
          height: r.height
        },
        index: 0,
        dataKey: r.dataKey,
        nameKey: r.nameKey
      }), n = _a(a, r.aspectRatio);
      return ie(ie({}, t), {}, {
        formatRoot: n,
        currentRoot: a,
        nestIndex: [a],
        prevAspectRatio: r.aspectRatio,
        prevData: r.data,
        prevWidth: r.width,
        prevHeight: r.height,
        prevDataKey: r.dataKey,
        prevType: r.type
      });
    }
    return null;
  }
  handleNestIndex(r, t) {
    var {
      nestIndex: a
    } = this.state, {
      width: n,
      height: i,
      dataKey: o,
      nameKey: u,
      aspectRatio: s
    } = this.props, c = Ma({
      depth: 0,
      node: ie(ie({}, r), {}, {
        x: 0,
        y: 0,
        width: n,
        height: i
      }),
      index: 0,
      dataKey: o,
      nameKey: u,
      // with Treemap nesting, should this continue nesting the index or start from empty string?
      nestedActiveTooltipIndex: r.tooltipIndex
    }), d = _a(c, s);
    a = a.slice(0, t + 1), this.setState({
      formatRoot: d,
      currentRoot: r,
      nestIndex: a
    });
  }
  renderNode(r, t) {
    var {
      content: a,
      type: n
    } = this.props, i = ie(ie(ie({}, G(this.props)), t), {}, {
      root: r
    }), o = !t.children || !t.children.length, {
      currentRoot: u
    } = this.state, s = ((u == null ? void 0 : u.children) || []).filter((c) => c.depth === t.depth && c.name === t.name);
    return !s.length && r.depth && n === "nest" ? null : /* @__PURE__ */ l.createElement(_, {
      key: "recharts-treemap-node-".concat(i.x, "-").concat(i.y, "-").concat(i.name),
      className: "recharts-treemap-depth-".concat(t.depth)
    }, /* @__PURE__ */ l.createElement(m1, {
      isLeaf: o,
      content: a,
      nodeProps: i,
      treemapProps: this.props,
      onNestClick: this.handleClick
    }), t.children && t.children.length ? t.children.map((c) => this.renderNode(t, c)) : null);
  }
  renderAllNodes() {
    var {
      formatRoot: r
    } = this.state;
    return r ? this.renderNode(r, r) : null;
  }
  // render nest treemap
  renderNestIndex() {
    var {
      nameKey: r,
      nestIndexContent: t
    } = this.props, {
      nestIndex: a
    } = this.state;
    return /* @__PURE__ */ l.createElement("div", {
      className: "recharts-treemap-nest-index-wrapper",
      style: {
        marginTop: "8px",
        textAlign: "center"
      }
    }, a.map((n, i) => {
      var o = tr(n, r, "root"), u;
      return /* @__PURE__ */ l.isValidElement(t) && (u = /* @__PURE__ */ l.cloneElement(t, n, i)), typeof t == "function" ? u = t(n, i) : u = o, // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
      /* @__PURE__ */ l.createElement("div", {
        onClick: this.handleNestIndex.bind(this, n, i),
        key: "nest-index-".concat(it()),
        className: "recharts-treemap-nest-index-box",
        style: {
          cursor: "pointer",
          display: "inline-block",
          padding: "0 7px",
          background: "#000",
          color: "#fff",
          marginRight: "3px"
        }
      }, u);
    }));
  }
  render() {
    var r = this.props, {
      width: t,
      height: a,
      className: n,
      style: i,
      children: o,
      type: u
    } = r, s = QD(r, JD), c = G(s);
    return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(f1, {
      dataKey: this.props.dataKey,
      nameKey: this.props.nameKey,
      stroke: this.props.stroke,
      fill: this.props.fill,
      currentRoot: this.state.currentRoot,
      id: this.props.id
    }), /* @__PURE__ */ l.createElement(Qt, ct({}, c, {
      width: t,
      height: u === "nest" ? a - 30 : a,
      onTouchMove: this.handleTouchMove
    }), this.renderAllNodes(), o), u === "nest" && this.renderNestIndex());
  }
}
zt(rp, "displayName", "Treemap");
function h1(e) {
  var r = F(), t = aa(), a = na();
  if (!_e(t) || !_e(a))
    return null;
  var {
    id: n
  } = e;
  return /* @__PURE__ */ l.createElement(dr, {
    id: n,
    type: "treemap"
  }, (i) => /* @__PURE__ */ l.createElement(rp, ct({}, e, {
    id: i,
    width: t,
    height: a,
    dispatch: r
  })));
}
function WT(e) {
  var r, t = V(e, Vi), {
    className: a,
    style: n,
    width: i,
    height: o
  } = t, [u, s] = l.useState(null);
  return /* @__PURE__ */ l.createElement(Zn, {
    preloadedState: {
      options: n1
    },
    reduxStoreName: (r = t.className) !== null && r !== void 0 ? r : "Treemap"
  }, /* @__PURE__ */ l.createElement(Yc, {
    margin: p1
  }), /* @__PURE__ */ l.createElement(cl, {
    dispatchTouchEvents: !1,
    className: a,
    style: n,
    width: i,
    height: o,
    responsive: !1,
    ref: (c) => {
      u == null && c != null && s(c);
    },
    onMouseEnter: void 0,
    onMouseLeave: void 0,
    onClick: void 0,
    onMouseMove: void 0,
    onMouseDown: void 0,
    onMouseUp: void 0,
    onContextMenu: void 0,
    onDoubleClick: void 0,
    onTouchStart: void 0,
    onTouchMove: void 0,
    onTouchEnd: void 0
  }, /* @__PURE__ */ l.createElement(Rn.Provider, {
    value: u
  }, /* @__PURE__ */ l.createElement(h1, t))));
}
var y1 = ["sourceX", "sourceY", "sourceControlX", "targetX", "targetY", "targetControlX", "linkWidth"], g1 = ["className", "style", "children", "id"];
function dt() {
  return dt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, dt.apply(null, arguments);
}
function tp(e, r) {
  if (e == null) return {};
  var t, a, n = b1(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function b1(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function dc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function rr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? dc(Object(t), !0).forEach(function(a) {
      x1(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : dc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function x1(e, r, t) {
  return (r = P1(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function P1(e) {
  var r = O1(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function O1(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var w1 = (e, r) => {
  var t = +e, a = r - t;
  return (n) => t + a * n;
}, Jn = (e) => e.y + e.dy / 2, Zt = (e) => e && e.value || 0, pn = (e, r) => r.reduce((t, a) => t + Zt(e[a]), 0), A1 = (e, r, t) => t.reduce((a, n) => {
  var i = r[n];
  if (i == null)
    return a;
  var o = e[i.source];
  return o == null ? a : a + Jn(o) * Zt(r[n]);
}, 0), E1 = (e, r, t) => t.reduce((a, n) => {
  var i = r[n];
  if (i == null)
    return a;
  var o = e[i.target];
  return o == null ? a : a + Jn(o) * Zt(r[n]);
}, 0), j1 = (e, r) => e.y - r.y, S1 = (e, r) => {
  for (var t = [], a = [], n = [], i = [], o = 0, u = e.length; o < u; o++) {
    var s = e[o];
    (s == null ? void 0 : s.source) === r && (n.push(s.target), i.push(o)), (s == null ? void 0 : s.target) === r && (t.push(s.source), a.push(o));
  }
  return {
    sourceNodes: t,
    sourceLinks: a,
    targetLinks: i,
    targetNodes: n
  };
}, ap = (e, r) => {
  for (var {
    targetNodes: t
  } = r, a = 0, n = t.length; a < n; a++) {
    var i = t[a];
    if (i != null) {
      var o = e[i];
      o && (o.depth = Math.max(r.depth + 1, o.depth), ap(e, o));
    }
  }
}, I1 = (e, r, t, a) => {
  for (var n, i, {
    nodes: o,
    links: u
  } = e, s = o.map((y, b) => {
    var x = S1(u, b);
    return rr(rr(rr({}, y), x), {}, {
      value: Math.max(pn(u, x.sourceLinks), pn(u, x.targetLinks)),
      depth: 0
    });
  }), c = 0, d = s.length; c < d; c++) {
    var v = s[c];
    v != null && !v.sourceNodes.length && ap(s, v);
  }
  var f = (n = (i = Oc(s, (y) => y.depth)) === null || i === void 0 ? void 0 : i.depth) !== null && n !== void 0 ? n : 0;
  if (f >= 1)
    for (var p = (r - t) / f, m = 0, h = s.length; m < h; m++) {
      var g = s[m];
      g != null && (g.targetNodes.length || a === "justify" && (g.depth = f), g.x = g.depth * p, g.dx = t);
    }
  return {
    tree: s,
    maxDepth: f
  };
}, k1 = (e) => {
  for (var r = [], t = 0, a = e.length; t < a; t++) {
    var n, i = e[t];
    i != null && (r[i.depth] || (r[i.depth] = []), (n = r[i.depth]) === null || n === void 0 || n.push(i));
  }
  return r;
}, C1 = (e, r, t, a, n) => {
  for (var i = Math.min(...e.map((g) => (r - (g.length - 1) * t) / Xp(g, Zt))), o = 0, u = e.length; o < u; o++) {
    var s = e[o];
    if (s != null)
      if (n === "top")
        for (var c = 0, d = 0, v = s.length; d < v; d++) {
          var f = s[d];
          f != null && (f.dy = f.value * i, f.y = c, c += f.dy + t);
        }
      else
        for (var p = 0, m = s.length; p < m; p++) {
          var h = s[p];
          h != null && (h.y = p, h.dy = h.value * i);
        }
  }
  return a.map((g) => rr(rr({}, g), {}, {
    dy: Zt(g) * i
  }));
}, si = function(r, t, a) {
  for (var n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !0, i = 0, o = r.length; i < o; i++) {
    var u = r[i];
    if (u != null) {
      var s = u.length;
      n && u.sort(j1);
      for (var c = 0, d = 0; d < s; d++) {
        var v = u[d];
        if (v != null) {
          var f = c - v.y;
          f > 0 && (v.y += f), c = v.y + v.dy + a;
        }
      }
      c = t + a;
      for (var p = s - 1; p >= 0; p--) {
        var m = u[p];
        if (m != null) {
          var h = m.y + m.dy + a - c;
          if (h > 0)
            m.y -= h, c = m.y;
          else
            break;
        }
      }
    }
  }
}, D1 = (e, r, t, a) => {
  for (var n = 0, i = r.length; n < i; n++) {
    var o = r[n];
    if (o != null)
      for (var u = 0, s = o.length; u < s; u++) {
        var c = o[u];
        if (c != null && c.sourceLinks.length) {
          var d = pn(t, c.sourceLinks), v = A1(e, t, c.sourceLinks), f = v / d;
          c.y += (f - Jn(c)) * a;
        }
      }
  }
}, T1 = (e, r, t, a) => {
  for (var n = r.length - 1; n >= 0; n--) {
    var i = r[n];
    if (i != null)
      for (var o = 0, u = i.length; o < u; o++) {
        var s = i[o];
        if (s != null && s.targetLinks.length) {
          var c = pn(t, s.targetLinks), d = E1(e, t, s.targetLinks), v = d / c;
          s.y += (v - Jn(s)) * a;
        }
      }
  }
}, $1 = (e, r) => {
  for (var t = 0, a = e.length; t < a; t++) {
    var n = e[t];
    if (n != null) {
      var i = 0, o = 0;
      n.targetLinks.sort((h, g) => {
        var y, b, x, O, P = (y = r[h]) === null || y === void 0 ? void 0 : y.target, w = (b = r[g]) === null || b === void 0 ? void 0 : b.target;
        if (P == null || w == null)
          return 0;
        var E = (x = e[P]) === null || x === void 0 ? void 0 : x.y, j = (O = e[w]) === null || O === void 0 ? void 0 : O.y;
        return E == null || j == null ? 0 : E - j;
      }), n.sourceLinks.sort((h, g) => {
        var y, b, x, O, P = (y = r[h]) === null || y === void 0 ? void 0 : y.source, w = (b = r[g]) === null || b === void 0 ? void 0 : b.source;
        if (P == null || w == null)
          return 0;
        var E = (x = e[P]) === null || x === void 0 ? void 0 : x.y, j = (O = e[w]) === null || O === void 0 ? void 0 : O.y;
        return E == null || j == null ? 0 : E - j;
      });
      for (var u = 0, s = n.targetLinks.length; u < s; u++) {
        var c = n.targetLinks[u];
        if (c != null) {
          var d = r[c];
          d && (d.sy = i, i += d.dy);
        }
      }
      for (var v = 0, f = n.sourceLinks.length; v < f; v++) {
        var p = n.sourceLinks[v];
        if (p != null) {
          var m = r[p];
          m && (m.ty = o, o += m.dy);
        }
      }
    }
  }
}, L1 = (e) => {
  var {
    data: r,
    width: t,
    height: a,
    iterations: n,
    nodeWidth: i,
    nodePadding: o,
    sort: u,
    verticalAlign: s,
    align: c
  } = e, {
    links: d
  } = r, {
    tree: v
  } = I1(r, t, i, c), f = k1(v), p = C1(f, a, o, d, s);
  if (si(f, a, o, u), s === "justify")
    for (var m = 1, h = 1; h <= n; h++)
      T1(v, f, p, m *= 0.99), si(f, a, o, u), D1(v, f, p, m), si(f, a, o, u);
  $1(v, p);
  var g = p;
  return {
    nodes: v,
    links: g
  };
}, M1 = (e) => ({
  x: +e.x + +e.width / 2,
  y: +e.y + +e.height / 2
}), _1 = (e) => "sourceX" in e ? {
  x: (e.sourceX + e.targetX) / 2,
  y: (e.sourceY + e.targetY) / 2
} : void 0, N1 = (e, r, t) => {
  var {
    payload: a
  } = e;
  if (r === "node")
    return {
      payload: a,
      name: B(a, t, ""),
      value: B(a, "value")
    };
  if ("source" in a && a.source && a.target) {
    var n = B(a.source, t, ""), i = B(a.target, t, "");
    return {
      payload: a,
      name: "".concat(n, " - ").concat(i),
      value: B(a, "value")
    };
  }
}, R1 = (e, r, t, a) => {
  if (!(r == null || typeof r != "string")) {
    var n = r.split("-"), [i, o] = n, u = tr(t, "".concat(i, "s[").concat(o, "]"));
    if (u) {
      var s = N1(u, i, a);
      return s;
    }
  }
}, B1 = {
  chartName: "Sankey",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: ["item"],
  tooltipPayloadSearcher: R1,
  eventEmitter: void 0
}, K1 = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    nameKey: t,
    stroke: a,
    strokeWidth: n,
    fill: i,
    name: o,
    data: u,
    id: s
  } = e, c = {
    dataDefinedOnItem: u,
    positions: void 0,
    settings: {
      stroke: a,
      strokeWidth: n,
      fill: i,
      dataKey: r,
      name: o,
      nameKey: t,
      hide: !1,
      type: void 0,
      color: i,
      unit: "",
      graphicalItemId: s
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: c
  });
});
function z1(e, r) {
  if (/* @__PURE__ */ l.isValidElement(e))
    return /* @__PURE__ */ l.cloneElement(e, r);
  if (typeof e == "function")
    return e(r);
  var {
    sourceX: t,
    sourceY: a,
    sourceControlX: n,
    targetX: i,
    targetY: o,
    targetControlX: u,
    linkWidth: s
  } = r, c = tp(r, y1);
  return /* @__PURE__ */ l.createElement("path", dt({
    className: "recharts-sankey-link",
    d: `
          M`.concat(t, ",").concat(a, `
          C`).concat(n, ",").concat(a, " ").concat(u, ",").concat(o, " ").concat(i, ",").concat(o, `
        `),
    fill: "none",
    stroke: "#333",
    strokeWidth: s,
    strokeOpacity: "0.2"
  }, G(c)));
}
var W1 = (e) => {
  var {
    link: r,
    nodes: t,
    left: a,
    top: n,
    i,
    linkContent: o,
    linkCurvature: u
  } = e, {
    sy: s,
    ty: c,
    dy: d
  } = r, v = t[r.source], f = t[r.target];
  if (!(v == null || f == null)) {
    var p = v.x + v.dx + a, m = f.x + a, h = w1(p, m), g = h(u), y = h(1 - u), b = v.y + s + d / 2 + n, x = f.y + c + d / 2 + n, O = rr({
      sourceX: p,
      // @ts-expect-error the linkContent from below is contributing unknown props
      targetX: m,
      sourceY: b,
      // @ts-expect-error the linkContent from below is contributing unknown props
      targetY: x,
      sourceControlX: g,
      targetControlX: y,
      sourceRelativeY: s,
      targetRelativeY: c,
      linkWidth: d,
      index: i,
      payload: rr(rr({}, r), {}, {
        source: v,
        target: f
      })
    }, ze(o));
    return O;
  }
};
function F1(e) {
  var {
    graphicalItemId: r,
    props: t,
    i: a,
    linkContent: n,
    onMouseEnter: i,
    onMouseLeave: o,
    onClick: u,
    dataKey: s
  } = e, c = _1(t), d = "link-".concat(a), v = F(), f = {
    onMouseEnter: (p) => {
      v(Ot({
        activeIndex: d,
        activeDataKey: s,
        activeCoordinate: c,
        activeGraphicalItemId: r
      })), i(t, p);
    },
    onMouseLeave: (p) => {
      v(Do()), o(t, p);
    },
    onClick: (p) => {
      v(_n({
        activeIndex: d,
        activeDataKey: s,
        activeCoordinate: c,
        activeGraphicalItemId: r
      })), u(t, p);
    }
  };
  return /* @__PURE__ */ l.createElement(_, f, z1(n, t));
}
function X1(e) {
  var {
    graphicalItemId: r,
    modifiedLinks: t,
    links: a,
    linkContent: n,
    onMouseEnter: i,
    onMouseLeave: o,
    onClick: u,
    dataKey: s
  } = e;
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-sankey-links",
    key: "recharts-sankey-links"
  }, a.map((c, d) => {
    var v = t[d];
    return v == null ? null : /* @__PURE__ */ l.createElement(F1, {
      graphicalItemId: r,
      key: "link-".concat(c.source, "-").concat(c.target, "-").concat(c.value),
      props: v,
      linkContent: n,
      i: d,
      onMouseEnter: i,
      onMouseLeave: o,
      onClick: u,
      dataKey: s
    });
  }));
}
function V1(e, r) {
  return /* @__PURE__ */ l.isValidElement(e) ? /* @__PURE__ */ l.cloneElement(e, r) : typeof e == "function" ? e(r) : (
    // @ts-expect-error recharts radius is not compatible with SVG radius
    /* @__PURE__ */ l.createElement(oa, dt({
      className: "recharts-sankey-node",
      fill: "#0088fe",
      fillOpacity: "0.8"
    }, G(r)))
  );
}
var G1 = (e) => {
  var {
    node: r,
    nodeContent: t,
    top: a,
    left: n,
    i
  } = e, {
    x: o,
    y: u,
    dx: s,
    dy: c
  } = r, d = rr(rr({}, ze(t)), {}, {
    x: o + n,
    y: u + a,
    width: s,
    height: c,
    index: i,
    payload: r
  });
  return d;
};
function H1(e) {
  var {
    graphicalItemId: r,
    props: t,
    nodeContent: a,
    i: n,
    onMouseEnter: i,
    onMouseLeave: o,
    onClick: u,
    dataKey: s
  } = e, c = F(), d = M1(t), v = "node-".concat(n), f = {
    onMouseEnter: (p) => {
      c(Ot({
        activeIndex: v,
        activeDataKey: s,
        activeCoordinate: d,
        activeGraphicalItemId: r
      })), i(t, p);
    },
    onMouseLeave: (p) => {
      c(Do()), o(t, p);
    },
    onClick: (p) => {
      c(_n({
        activeIndex: v,
        activeDataKey: s,
        activeCoordinate: d,
        activeGraphicalItemId: r
      })), u(t, p);
    }
  };
  return /* @__PURE__ */ l.createElement(_, f, V1(a, t));
}
function Y1(e) {
  var {
    graphicalItemId: r,
    modifiedNodes: t,
    nodeContent: a,
    onMouseEnter: n,
    onMouseLeave: i,
    onClick: o,
    dataKey: u
  } = e;
  return /* @__PURE__ */ l.createElement(_, {
    className: "recharts-sankey-nodes",
    key: "recharts-sankey-nodes"
  }, t.map((s, c) => /* @__PURE__ */ l.createElement(H1, {
    graphicalItemId: r,
    key: "node-".concat(s.index, "-").concat(s.x, "-").concat(s.y),
    props: s,
    nodeContent: a,
    i: c,
    onMouseEnter: n,
    onMouseLeave: i,
    onClick: o,
    dataKey: u
  })));
}
var U1 = {
  align: "justify",
  dataKey: "value",
  iterations: 32,
  linkCurvature: 0.5,
  margin: {
    top: 5,
    right: 5,
    bottom: 5,
    left: 5
  },
  nameKey: "name",
  nodePadding: 10,
  nodeWidth: 10,
  sort: !0,
  verticalAlign: "justify"
};
function Z1(e) {
  var {
    className: r,
    style: t,
    children: a,
    id: n
  } = e, i = tp(e, g1), {
    link: o,
    dataKey: u,
    node: s,
    onMouseEnter: c,
    onMouseLeave: d,
    onClick: v,
    data: f,
    iterations: p,
    nodeWidth: m,
    nodePadding: h,
    sort: g,
    linkCurvature: y,
    margin: b,
    verticalAlign: x,
    align: O
  } = e, P = G(i), w = aa(), E = na(), {
    links: j,
    modifiedLinks: S,
    modifiedNodes: I
  } = l.useMemo(() => {
    var T, $, W, X;
    if (!f || !w || !E || w <= 0 || E <= 0)
      return {
        nodes: [],
        links: [],
        modifiedLinks: [],
        modifiedNodes: []
      };
    var Z = w - ((T = b.left) !== null && T !== void 0 ? T : 0) - (($ = b.right) !== null && $ !== void 0 ? $ : 0), z = E - ((W = b.top) !== null && W !== void 0 ? W : 0) - ((X = b.bottom) !== null && X !== void 0 ? X : 0), ne = L1({
      data: f,
      width: Z,
      height: z,
      iterations: p,
      nodeWidth: m,
      nodePadding: h,
      sort: g,
      verticalAlign: x,
      align: O
    }), ge = b.top || 0, fe = b.left || 0, Ke = ne.links.map((Fe, pr) => W1({
      link: Fe,
      nodes: ne.nodes,
      i: pr,
      top: ge,
      left: fe,
      linkContent: o,
      linkCurvature: y
    })).filter(Zi), je = ne.nodes.map((Fe, pr) => G1({
      node: Fe,
      nodeContent: s,
      i: pr,
      top: ge,
      left: fe
    }));
    return {
      nodes: ne.nodes,
      links: ne.links,
      modifiedLinks: Ke,
      modifiedNodes: je
    };
  }, [f, w, E, b, p, m, h, g, o, s, y, O, x]), D = l.useCallback((T, $, W) => {
    c && c(T, $, W);
  }, [c]), C = l.useCallback((T, $, W) => {
    d && d(T, $, W);
  }, [d]), M = l.useCallback((T, $, W) => {
    v && v(T, $, W);
  }, [v]);
  return !_e(w) || !_e(E) || !f || !f.links || !f.nodes ? null : /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(FE, {
    computedData: {
      links: S,
      nodes: I
    }
  }), /* @__PURE__ */ l.createElement(Qt, dt({}, P, {
    width: w,
    height: E
  }), a, /* @__PURE__ */ l.createElement(X1, {
    graphicalItemId: n,
    links: j,
    modifiedLinks: S,
    linkContent: o,
    dataKey: u,
    onMouseEnter: (T, $) => D(T, "link", $),
    onMouseLeave: (T, $) => C(T, "link", $),
    onClick: (T, $) => M(T, "link", $)
  }), /* @__PURE__ */ l.createElement(Y1, {
    graphicalItemId: n,
    modifiedNodes: I,
    nodeContent: s,
    dataKey: u,
    onMouseEnter: (T, $) => D(T, "node", $),
    onMouseLeave: (T, $) => C(T, "node", $),
    onClick: (T, $) => M(T, "node", $)
  })));
}
function q1(e) {
  var r = V(e, U1), {
    width: t,
    height: a,
    style: n,
    className: i,
    id: o
  } = r, [u, s] = l.useState(null);
  return /* @__PURE__ */ l.createElement(Zn, {
    preloadedState: {
      options: B1
    },
    reduxStoreName: i ?? "Sankey"
  }, /* @__PURE__ */ l.createElement(ia, {
    width: t,
    height: a
  }), /* @__PURE__ */ l.createElement(Yc, {
    margin: r.margin
  }), /* @__PURE__ */ l.createElement(cl, {
    className: i,
    style: n,
    width: t,
    height: a,
    responsive: !1,
    ref: (c) => {
      c && !u && s(c);
    },
    onMouseEnter: void 0,
    onMouseLeave: void 0,
    onClick: void 0,
    onMouseMove: void 0,
    onMouseDown: void 0,
    onMouseUp: void 0,
    onContextMenu: void 0,
    onDoubleClick: void 0,
    onTouchStart: void 0,
    onTouchMove: void 0,
    onTouchEnd: void 0
  }, /* @__PURE__ */ l.createElement(Rn.Provider, {
    value: u
  }, /* @__PURE__ */ l.createElement(dr, {
    id: o,
    type: "sankey"
  }, (c) => /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(K1, {
    dataKey: r.dataKey,
    nameKey: r.nameKey,
    stroke: r.stroke,
    strokeWidth: r.strokeWidth,
    fill: r.fill,
    name: r.name,
    data: r.data,
    id: c
  }), /* @__PURE__ */ l.createElement(Z1, dt({}, r, {
    id: c
  })))))));
}
q1.displayName = "Sankey";
function vc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function fc(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? vc(Object(t), !0).forEach(function(a) {
      J1(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : vc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function J1(e, r, t) {
  return (r = Q1(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function Q1(e) {
  var r = eT(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function eT(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var rT = ["axis"], tT = fc(fc({}, qn), {}, {
  layout: "centric",
  startAngle: 90,
  endAngle: -270
}), FT = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = V(e, tT);
  return /* @__PURE__ */ l.createElement(dl, {
    chartName: "RadarChart",
    defaultTooltipEventType: "axis",
    validateTooltipEventTypes: rT,
    tooltipPayloadSearcher: Sr,
    categoricalChartProps: t,
    ref: r
  });
}), aT = ["item"], XT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "ScatterChart",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: aT,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
})), nT = ["axis"], VT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "AreaChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: nT,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
}));
function pc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function mc(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? pc(Object(t), !0).forEach(function(a) {
      iT(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : pc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function iT(e, r, t) {
  return (r = oT(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function oT(e) {
  var r = lT(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function lT(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var uT = ["axis", "item"], sT = mc(mc({}, qn), {}, {
  layout: "radial",
  startAngle: 0,
  endAngle: 360
}), GT = /* @__PURE__ */ l.forwardRef((e, r) => {
  var t = V(e, sT);
  return /* @__PURE__ */ l.createElement(dl, {
    chartName: "RadialBarChart",
    defaultTooltipEventType: "axis",
    validateTooltipEventTypes: uT,
    tooltipPayloadSearcher: Sr,
    categoricalChartProps: t,
    ref: r
  });
}), cT = ["axis"], HT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "ComposedChart",
  defaultTooltipEventType: "axis",
  validateTooltipEventTypes: cT,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
}));
function Gi() {
  return Gi = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, Gi.apply(null, arguments);
}
function dT(e) {
  return /* @__PURE__ */ l.createElement(Xr, Gi({
    shapeType: "trapezoid"
  }, e));
}
function hc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Nt(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? hc(Object(t), !0).forEach(function(a) {
      vT(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : hc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function vT(e, r, t) {
  return (r = fT(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function fT(e) {
  var r = pT(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function pT(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var mT = (e, r) => r, hT = A([he, mT, Lr], (e, r, t) => {
  var {
    data: a,
    dataKey: n,
    nameKey: i,
    tooltipType: o,
    lastShapeType: u,
    reversed: s,
    customWidth: c,
    cells: d,
    presentationProps: v,
    id: f
  } = r, {
    chartData: p
  } = t, m;
  if (a != null && a.length > 0 ? m = a : p != null && p.length > 0 && (m = p), m && m.length)
    m = m.map((h, g) => Nt(Nt(Nt({
      payload: h
    }, v), h), d && d[g] && d[g].props));
  else if (d && d.length)
    m = d.map((h) => Nt(Nt({}, v), h.props));
  else
    return [];
  return $T({
    dataKey: n,
    nameKey: i,
    displayedData: m,
    tooltipType: o,
    lastShapeType: u,
    reversed: s,
    offset: e,
    customWidth: c,
    graphicalItemId: f
  });
}), yT = ["onMouseEnter", "onClick", "onMouseLeave", "shape", "activeShape"], gT = ["id"], bT = ["stroke", "fill", "legendType", "hide", "isAnimationActive", "animationBegin", "animationDuration", "animationEasing", "nameKey", "lastShapeType", "id"], xT = ["id"];
function qt() {
  return qt = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r];
      for (var a in t) ({}).hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, qt.apply(null, arguments);
}
function mn(e, r) {
  if (e == null) return {};
  var t, a, n = PT(e, r);
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e);
    for (a = 0; a < i.length; a++) t = i[a], r.indexOf(t) === -1 && {}.propertyIsEnumerable.call(e, t) && (n[t] = e[t]);
  }
  return n;
}
function PT(e, r) {
  if (e == null) return {};
  var t = {};
  for (var a in e) if ({}.hasOwnProperty.call(e, a)) {
    if (r.indexOf(a) !== -1) continue;
    t[a] = e[a];
  }
  return t;
}
function yc(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    r && (a = a.filter(function(n) {
      return Object.getOwnPropertyDescriptor(e, n).enumerable;
    })), t.push.apply(t, a);
  }
  return t;
}
function Ie(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2 ? yc(Object(t), !0).forEach(function(a) {
      OT(e, a, t[a]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : yc(Object(t)).forEach(function(a) {
      Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(t, a));
    });
  }
  return e;
}
function OT(e, r, t) {
  return (r = wT(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;
}
function wT(e) {
  var r = AT(e, "string");
  return typeof r == "symbol" ? r : r + "";
}
function AT(e, r) {
  if (typeof e != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var a = t.call(e, r);
    if (typeof a != "object") return a;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var ET = /* @__PURE__ */ l.memo((e) => {
  var {
    dataKey: r,
    nameKey: t,
    stroke: a,
    strokeWidth: n,
    fill: i,
    name: o,
    hide: u,
    tooltipType: s,
    data: c,
    trapezoids: d,
    id: v
  } = e, f = {
    dataDefinedOnItem: c,
    positions: d.map((p) => {
      var {
        tooltipPosition: m
      } = p;
      return m;
    }),
    settings: {
      stroke: a,
      strokeWidth: n,
      fill: i,
      dataKey: r,
      name: o,
      nameKey: t,
      hide: u,
      type: s,
      color: i,
      unit: "",
      // Funnel does not have unit, why?
      graphicalItemId: v
    }
  };
  return /* @__PURE__ */ l.createElement(cr, {
    tooltipEntrySettings: f
  });
});
function jT(e) {
  var {
    showLabels: r,
    trapezoids: t,
    children: a
  } = e, n = l.useMemo(() => {
    if (r)
      return t == null ? void 0 : t.map((i) => {
        var o = i.labelViewBox;
        return Ie(Ie({}, o), {}, {
          value: i.name,
          payload: i.payload,
          parentViewBox: i.parentViewBox,
          viewBox: o,
          fill: i.fill
        });
      });
  }, [r, t]);
  return /* @__PURE__ */ l.createElement(jt, {
    value: n
  }, a);
}
function ST(e) {
  var {
    trapezoids: r,
    allOtherFunnelProps: t
  } = e, a = k((p) => Nn(p, "item", p.tooltip.settings.trigger, void 0)), {
    onMouseEnter: n,
    onClick: i,
    onMouseLeave: o,
    shape: u,
    activeShape: s
  } = t, c = mn(t, yT), d = It(n, t.dataKey, t.id), v = kt(o), f = Ct(i, t.dataKey, t.id);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, r.map((p, m) => {
    var h = !!s && a === String(m), g = h ? s : u, y = Ie(Ie({}, p), {}, {
      option: g,
      isActive: h,
      stroke: p.stroke
    }), {
      id: b
    } = y, x = mn(y, gT);
    return /* @__PURE__ */ l.createElement(_, qt({
      key: "trapezoid-".concat(p == null ? void 0 : p.x, "-").concat(p == null ? void 0 : p.y, "-").concat(p == null ? void 0 : p.name, "-").concat(p == null ? void 0 : p.value),
      className: "recharts-funnel-trapezoid"
    }, Ue(c, p, m), {
      // @ts-expect-error the types need a bit of attention
      onMouseEnter: d(p, m),
      onMouseLeave: v(p, m),
      onClick: f(p, m)
    }), /* @__PURE__ */ l.createElement(dT, x));
  }));
}
function IT(e) {
  var {
    previousTrapezoidsRef: r,
    props: t
  } = e, {
    trapezoids: a,
    isAnimationActive: n,
    animationBegin: i,
    animationDuration: o,
    animationEasing: u,
    onAnimationEnd: s,
    onAnimationStart: c
  } = t, d = r.current, [v, f] = l.useState(!1), p = !v, m = or(a, "recharts-funnel-"), h = l.useCallback(() => {
    typeof s == "function" && s(), f(!1);
  }, [s]), g = l.useCallback(() => {
    typeof c == "function" && c(), f(!0);
  }, [c]);
  return /* @__PURE__ */ l.createElement(jT, {
    showLabels: p,
    trapezoids: a
  }, /* @__PURE__ */ l.createElement(ir, {
    animationId: m,
    begin: i,
    duration: o,
    isActive: n,
    easing: u,
    key: m,
    onAnimationStart: g,
    onAnimationEnd: h
  }, (y) => {
    var b = y === 1 ? a : a.map((x, O) => {
      var P = d && d[O];
      return P ? Ie(Ie({}, x), {}, {
        x: N(P.x, x.x, y),
        y: N(P.y, x.y, y),
        upperWidth: N(P.upperWidth, x.upperWidth, y),
        lowerWidth: N(P.lowerWidth, x.lowerWidth, y),
        height: N(P.height, x.height, y)
      }) : Ie(Ie({}, x), {}, {
        x: N(x.x + x.upperWidth / 2, x.x, y),
        y: N(x.y + x.height / 2, x.y, y),
        upperWidth: N(0, x.upperWidth, y),
        lowerWidth: N(0, x.lowerWidth, y),
        height: N(0, x.height, y)
      });
    });
    return y > 0 && (r.current = b), /* @__PURE__ */ l.createElement(_, null, /* @__PURE__ */ l.createElement(ST, {
      trapezoids: b,
      allOtherFunnelProps: t
    }));
  }), /* @__PURE__ */ l.createElement(_r, {
    label: t.label
  }), t.children);
}
function kT(e) {
  var r = l.useRef(void 0);
  return /* @__PURE__ */ l.createElement(IT, {
    props: e,
    previousTrapezoidsRef: r
  });
}
var CT = (e, r) => {
  var {
    width: t,
    height: a,
    left: n,
    top: i
  } = r, o = Ee(e, t, t);
  return {
    realWidth: o,
    realHeight: a,
    offsetX: n,
    offsetY: i
  };
}, DT = {
  animationBegin: 400,
  animationDuration: 1500,
  animationEasing: "ease",
  fill: "#808080",
  hide: !1,
  isAnimationActive: "auto",
  lastShapeType: "triangle",
  legendType: "rect",
  nameKey: "name",
  reversed: !1,
  stroke: "#fff"
};
function TT(e) {
  var r = ga(), {
    stroke: t,
    fill: a,
    legendType: n,
    hide: i,
    isAnimationActive: o,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    nameKey: d,
    lastShapeType: v,
    id: f
  } = e, p = mn(e, bT), m = G(e), h = St(e.children, Zr), g = l.useMemo(() => ({
    dataKey: e.dataKey,
    nameKey: d,
    data: e.data,
    tooltipType: e.tooltipType,
    lastShapeType: v,
    reversed: e.reversed,
    customWidth: e.width,
    cells: h,
    presentationProps: m,
    id: f
  }), [e.dataKey, d, e.data, e.tooltipType, v, e.reversed, e.width, h, m, f]), y = k((P) => hT(P, g));
  if (i || !y || !y.length || !r)
    return null;
  var {
    height: b,
    width: x
  } = r, O = R("recharts-trapezoids", e.className);
  return /* @__PURE__ */ l.createElement(l.Fragment, null, /* @__PURE__ */ l.createElement(ET, {
    dataKey: e.dataKey,
    nameKey: e.nameKey,
    stroke: e.stroke,
    strokeWidth: e.strokeWidth,
    fill: e.fill,
    name: e.name,
    hide: e.hide,
    tooltipType: e.tooltipType,
    data: e.data,
    trapezoids: y,
    id: f
  }), /* @__PURE__ */ l.createElement(_, {
    className: O
  }, /* @__PURE__ */ l.createElement(kT, qt({}, p, {
    id: f,
    stroke: t,
    fill: a,
    nameKey: d,
    lastShapeType: v,
    animationBegin: u,
    animationDuration: s,
    animationEasing: c,
    isAnimationActive: o,
    hide: i,
    legendType: n,
    height: b,
    width: x,
    trapezoids: y
  }))));
}
function $T(e) {
  var {
    dataKey: r,
    nameKey: t,
    displayedData: a,
    tooltipType: n,
    lastShapeType: i,
    reversed: o,
    offset: u,
    customWidth: s,
    graphicalItemId: c
  } = e, {
    realHeight: d,
    realWidth: v,
    offsetX: f,
    offsetY: p
  } = CT(s, u), m = Math.max.apply(null, a.map((x) => B(x, r, 0))), h = a.length, g = d / h, y = {
    x: u.left,
    y: u.top,
    width: u.width,
    height: u.height
  }, b = a.map((x, O) => {
    var P = B(x, r, 0), w = String(B(x, t, O)), E = P, j;
    O !== h - 1 ? (j = B(a[O + 1], r, 0), j instanceof Array && ([E, j] = j)) : P instanceof Array && P.length === 2 ? [E, j] = P : i === "rectangle" ? j = E : j = 0;
    var S = (m - E) * v / (2 * m) + f, I = g * O + p, D = E / m * v, C = j / m * v, M = [{
      name: w,
      value: E,
      payload: x,
      dataKey: r,
      type: n,
      graphicalItemId: c
    }], T = {
      x: S + D / 2,
      y: I + g / 2
    }, $ = {
      x: S,
      y: I,
      upperWidth: D,
      lowerWidth: C,
      width: Math.max(D, C),
      height: g
    };
    return Ie(Ie(Ie({}, $), {}, {
      name: w,
      val: E,
      tooltipPayload: M,
      tooltipPosition: T
    }, wc(x, ["width"])), {}, {
      payload: x,
      parentViewBox: y,
      labelViewBox: $
    });
  });
  return o && (b = b.map((x, O) => {
    var P = {
      x: x.x - (x.lowerWidth - x.upperWidth) / 2,
      y: x.y - O * g + (h - 1 - O) * g,
      upperWidth: x.lowerWidth,
      lowerWidth: x.upperWidth,
      width: Math.max(x.lowerWidth, x.upperWidth),
      height: g
    };
    return Ie(Ie(Ie({}, x), P), {}, {
      tooltipPosition: Ie(Ie({}, x.tooltipPosition), {}, {
        y: x.y - O * g + (h - 1 - O) * g + g / 2
      }),
      labelViewBox: P
    });
  })), b;
}
function LT(e) {
  var r = V(e, DT), {
    id: t
  } = r, a = mn(r, xT);
  return /* @__PURE__ */ l.createElement(dr, {
    id: t,
    type: "funnel"
  }, (n) => /* @__PURE__ */ l.createElement(TT, qt({}, a, {
    id: n
  })));
}
LT.displayName = "Funnel";
var MT = ["item"], YT = /* @__PURE__ */ l.forwardRef((e, r) => /* @__PURE__ */ l.createElement(Tt, {
  chartName: "FunnelChart",
  defaultTooltipEventType: "item",
  validateTooltipEventTypes: MT,
  tooltipPayloadSearcher: Sr,
  categoricalChartProps: e,
  ref: r
}));
export {
  VT as A,
  KT as B,
  HT as C,
  oD as E,
  YT as F,
  Xh as L,
  zT as P,
  NT as R,
  ud as S,
  RT as T,
  RC as X,
  GC as Y,
  UC as Z,
  QI as a,
  Yk as b,
  BT as c,
  jI as d,
  Rw as e,
  Ir as f,
  FT as g,
  HA as h,
  YO as i,
  $0 as j,
  h0 as k,
  GT as l,
  NE as m,
  XT as n,
  SC as o,
  LT as p,
  WT as q,
  q1 as r,
  KS as s,
  Mj as t,
  Qj as u,
  Xj as v,
  sj as w,
  Zr as x,
  La as y
};
