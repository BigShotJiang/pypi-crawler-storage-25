import { ay as e, dd as U, de as F, df as W, dg as E, dh as G, di as q, r as c, dj as C, dk as J, dl as A, dm as K, dn as Q, dp as V, dq as X, dr as M, ds as Y, dt as Z, du as _, dv as O, dw as ee, dx as te, dy as k, dz as se, dA as S, dB as T, dC as I, dD as z, dE as oe, dF as $, dG as L, dH as D, dI as p, dJ as g, dK as h, dL as b, dM as j, dN as v, dO as f, dP as x } from "./refast-vendor-CQOdd5X6.js";
import { c as r, a as N } from "./refast-index-9fBfd4aX.js";
function re({
  open: t,
  defaultOpen: s = !1,
  onOpenChange: o,
  title: a,
  description: n,
  confirmLabel: d = "Continue",
  cancelLabel: i = "Cancel",
  onConfirm: l,
  onCancel: m,
  trigger: u,
  variant: y = "default",
  className: R,
  children: w,
  ...P
}) {
  if (!u && w && c.Children.count(w) > 0)
    return /* @__PURE__ */ e.jsx(x, { open: t, defaultOpen: s, onOpenChange: o, children: w });
  const B = () => {
    l == null || l(), o == null || o(!1);
  }, H = () => {
    m == null || m(), o == null || o(!1);
  };
  return /* @__PURE__ */ e.jsxs(x, { open: t, defaultOpen: s, onOpenChange: o, children: [
    u && /* @__PURE__ */ e.jsx(f, { asChild: !0, children: u }),
    /* @__PURE__ */ e.jsxs(b, { children: [
      /* @__PURE__ */ e.jsx(
        j,
        {
          className: r(
            "fixed inset-0 z-50 bg-black/80",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
          )
        }
      ),
      /* @__PURE__ */ e.jsxs(
        v,
        {
          className: r(
            "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4",
            "border bg-background p-6 shadow-lg duration-200",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
            "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
            "data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%]",
            "data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%]",
            "sm:rounded-lg",
            R
          ),
          ...P,
          children: [
            /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col space-y-2 text-center sm:text-left", children: [
              a && /* @__PURE__ */ e.jsx(h, { className: "text-lg font-semibold", children: a }),
              n && /* @__PURE__ */ e.jsx(g, { className: "text-sm text-muted-foreground", children: n })
            ] }),
            w,
            /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", children: [
              /* @__PURE__ */ e.jsx(
                "button",
                {
                  type: "button",
                  onClick: H,
                  className: r(
                    "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
                    "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
                    "text-sm font-medium ring-offset-background transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    "disabled:pointer-events-none disabled:opacity-50",
                    "mt-2 sm:mt-0"
                  ),
                  children: i
                }
              ),
              /* @__PURE__ */ e.jsx(
                "button",
                {
                  type: "button",
                  onClick: B,
                  className: r(
                    "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
                    "text-sm font-medium ring-offset-background transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    "disabled:pointer-events-none disabled:opacity-50",
                    y === "destructive" ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : "bg-primary text-primary-foreground hover:bg-primary/90"
                  ),
                  children: d
                }
              )
            ] })
          ]
        }
      )
    ] })
  ] });
}
function de({
  asChild: t = !0,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null, d = t && !!n;
  return /* @__PURE__ */ e.jsx(f, { asChild: d, className: s, children: d ? n : o });
}
function ie({
  className: t,
  children: s
}) {
  return /* @__PURE__ */ e.jsxs(b, { children: [
    /* @__PURE__ */ e.jsx(
      j,
      {
        className: r(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ e.jsx(
      v,
      {
        className: r(
          "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4",
          "border bg-background p-6 shadow-lg duration-200",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%]",
          "data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%]",
          "sm:rounded-lg",
          t
        ),
        children: s
      }
    )
  ] });
}
function le({
  className: t,
  children: s
}) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col space-y-2 text-center sm:text-left", t), children: s });
}
function ce({
  className: t,
  children: s
}) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", t), children: s });
}
function ue({
  title: t,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsx(h, { className: r("text-lg font-semibold", s), children: t || o });
}
function me({
  description: t,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsx(g, { className: r("text-sm text-muted-foreground", s), children: t || o });
}
function fe({
  label: t,
  onClick: s,
  className: o,
  children: a
}) {
  return /* @__PURE__ */ e.jsx(
    p,
    {
      onClick: s,
      className: r(
        "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
        "bg-primary text-primary-foreground hover:bg-primary/90",
        "text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        o
      ),
      children: t || a
    }
  );
}
function xe({
  label: t,
  onClick: s,
  className: o,
  children: a
}) {
  return /* @__PURE__ */ e.jsx(
    p,
    {
      onClick: s,
      className: r(
        "inline-flex h-10 items-center justify-center rounded-md px-4 py-2",
        "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        "text-sm font-medium ring-offset-background transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        "mt-2 sm:mt-0",
        o
      ),
      children: t || a
    }
  );
}
function pe({
  open: t,
  defaultOpen: s = !1,
  onOpenChange: o,
  children: a
}) {
  return /* @__PURE__ */ e.jsx(
    x,
    {
      open: t ?? void 0,
      defaultOpen: s,
      onOpenChange: o,
      children: a
    }
  );
}
function ge({
  asChild: t = !1,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null;
  return t && n ? /* @__PURE__ */ e.jsx(f, { asChild: !0, className: s, children: n }) : /* @__PURE__ */ e.jsx(f, { className: r("inline-flex", s), children: o });
}
function he({
  asChild: t = !0,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsx(p, { asChild: t, className: s, children: o });
}
function be({
  side: t = "right",
  className: s,
  children: o
}) {
  const a = {
    top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
    bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
    left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
    right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
  };
  return /* @__PURE__ */ e.jsxs(b, { children: [
    /* @__PURE__ */ e.jsx(
      j,
      {
        className: r(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ e.jsxs(
      v,
      {
        className: r(
          "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:duration-300 data-[state=open]:duration-500",
          a[t],
          s
        ),
        children: [
          o,
          /* @__PURE__ */ e.jsxs(
            p,
            {
              className: r(
                "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity",
                "hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
                "disabled:pointer-events-none data-[state=open]:bg-secondary"
              ),
              children: [
                /* @__PURE__ */ e.jsxs(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "h-4 w-4",
                    children: [
                      /* @__PURE__ */ e.jsx("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
                      /* @__PURE__ */ e.jsx("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
                    ]
                  }
                ),
                /* @__PURE__ */ e.jsx("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function je({
  className: t,
  children: s
}) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col space-y-2 text-center sm:text-left", t), children: s });
}
function ve({
  className: t,
  children: s
}) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", t), children: s });
}
function we({
  title: t,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsx(h, { className: r("text-lg font-semibold text-foreground", s), children: t || o });
}
function ye({
  description: t,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsx(g, { className: r("text-sm text-muted-foreground", s), children: t || o });
}
function Ne({
  open: t,
  onOpenChange: s,
  title: o,
  description: a,
  shouldScaleBackground: n = !0,
  className: d,
  children: i,
  ...l
}) {
  return i && c.Children.count(i) > 0 ? /* @__PURE__ */ e.jsx(x, { open: t, onOpenChange: s, children: i }) : /* @__PURE__ */ e.jsx(x, { open: t, onOpenChange: s, children: /* @__PURE__ */ e.jsxs(b, { children: [
    /* @__PURE__ */ e.jsx(
      j,
      {
        className: r(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ e.jsxs(
      v,
      {
        className: r(
          "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
          d
        ),
        ...l,
        children: [
          /* @__PURE__ */ e.jsx("div", { className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" }),
          /* @__PURE__ */ e.jsxs("div", { className: "p-4", children: [
            o && /* @__PURE__ */ e.jsx(h, { className: "text-lg font-semibold text-foreground", children: o }),
            a && /* @__PURE__ */ e.jsx(g, { className: "text-sm text-muted-foreground", children: a })
          ] }),
          /* @__PURE__ */ e.jsx("div", { className: "p-4", children: i })
        ]
      }
    )
  ] }) });
}
function Ce({
  asChild: t = !0,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null, d = t && !!n;
  return /* @__PURE__ */ e.jsx(f, { asChild: d, className: s, children: d ? n : o });
}
function ke({ className: t, children: s }) {
  return /* @__PURE__ */ e.jsxs(b, { children: [
    /* @__PURE__ */ e.jsx(
      j,
      {
        className: r(
          "fixed inset-0 z-50 bg-black/80",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        )
      }
    ),
    /* @__PURE__ */ e.jsxs(
      v,
      {
        className: r(
          "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
          t
        ),
        children: [
          /* @__PURE__ */ e.jsx("div", { className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" }),
          /* @__PURE__ */ e.jsx("div", { className: "p-4", children: s })
        ]
      }
    )
  ] });
}
function ze({ className: t, children: s }) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col space-y-2 text-center sm:text-left", t), children: s });
}
function De({ className: t, children: s }) {
  return /* @__PURE__ */ e.jsx("div", { className: r("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", t), children: s });
}
function Ae({ title: t, className: s, children: o }) {
  return /* @__PURE__ */ e.jsx(h, { className: r("text-lg font-semibold text-foreground", s), children: t || o });
}
function Me({ description: t, className: s, children: o }) {
  return /* @__PURE__ */ e.jsx(g, { className: r("text-sm text-muted-foreground", s), children: t || o });
}
function Se({ asChild: t = !0, className: s, children: o }) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null, d = t && !!n;
  return /* @__PURE__ */ e.jsx(p, { asChild: d, className: s, children: d ? n : o });
}
function Te({
  open: t,
  defaultOpen: s,
  onOpenChange: o,
  trigger: a,
  openDelay: n = 700,
  closeDelay: d = 300,
  side: i = "bottom",
  align: l = "center",
  className: m,
  children: u,
  ...y
}) {
  return !a && u && c.Children.count(u) > 0 ? /* @__PURE__ */ e.jsx(D, { open: t, defaultOpen: s, onOpenChange: o, openDelay: n, closeDelay: d, children: u }) : /* @__PURE__ */ e.jsxs(D, { open: t, defaultOpen: s, onOpenChange: o, openDelay: n, closeDelay: d, children: [
    /* @__PURE__ */ e.jsx(L, { asChild: !0, children: a }),
    /* @__PURE__ */ e.jsx(
      $,
      {
        side: i,
        align: l,
        sideOffset: 4,
        className: r(
          "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
          "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          m
        ),
        ...y,
        children: u
      }
    )
  ] });
}
function Ie({
  open: t,
  defaultOpen: s,
  onOpenChange: o,
  trigger: a,
  side: n = "bottom",
  align: d = "center",
  className: i,
  children: l,
  ...m
}) {
  return !a && l && c.Children.count(l) > 0 ? /* @__PURE__ */ e.jsx(z, { open: t, defaultOpen: s, onOpenChange: o, children: l }) : /* @__PURE__ */ e.jsxs(z, { open: t, defaultOpen: s, onOpenChange: o, children: [
    /* @__PURE__ */ e.jsx(I, { asChild: !0, children: a }),
    /* @__PURE__ */ e.jsx(S, { children: /* @__PURE__ */ e.jsxs(
      T,
      {
        side: n,
        align: d,
        sideOffset: 4,
        className: r(
          "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
          "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          i
        ),
        ...m,
        children: [
          l,
          /* @__PURE__ */ e.jsx(oe, { className: "fill-popover" })
        ]
      }
    ) })
  ] });
}
function $e({
  asChild: t = !0,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null, d = t && !!n;
  return /* @__PURE__ */ e.jsx(L, { asChild: d, className: s, children: d ? n : o });
}
function Le({
  className: t,
  side: s = "bottom",
  align: o = "center",
  sideOffset: a = 4,
  children: n
}) {
  return /* @__PURE__ */ e.jsx(
    $,
    {
      side: s,
      align: o,
      sideOffset: a,
      className: r(
        "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        t
      ),
      children: n
    }
  );
}
function Re({
  asChild: t = !0,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null, d = t && !!n;
  return /* @__PURE__ */ e.jsx(I, { asChild: d, className: s, children: d ? n : o });
}
function Pe({
  className: t,
  side: s = "bottom",
  align: o = "center",
  sideOffset: a = 4,
  children: n
}) {
  return /* @__PURE__ */ e.jsx(S, { children: /* @__PURE__ */ e.jsx(
    T,
    {
      side: s,
      align: o,
      sideOffset: a,
      className: r(
        "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        t
      ),
      children: n
    }
  ) });
}
function Be({
  open: t,
  defaultOpen: s = !1,
  onOpenChange: o,
  children: a
}) {
  return /* @__PURE__ */ e.jsx(
    se,
    {
      open: t ?? void 0,
      defaultOpen: s,
      onOpenChange: o,
      children: a
    }
  );
}
function He({
  asChild: t = !1,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null;
  return t && n ? /* @__PURE__ */ e.jsx(k, { asChild: !0, className: s, children: n }) : /* @__PURE__ */ e.jsx(k, { className: r("inline-flex", s), children: o });
}
function Ue({
  side: t = "bottom",
  sideOffset: s = 4,
  align: o = "start",
  className: a,
  children: n,
  ...d
}) {
  return /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
    te,
    {
      side: t,
      sideOffset: s,
      align: o,
      className: r(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        a
      ),
      ...d,
      children: n
    }
  ) });
}
function Fe({
  icon: t,
  shortcut: s,
  disabled: o = !1,
  onSelect: a,
  className: n,
  children: d,
  ...i
}) {
  return /* @__PURE__ */ e.jsxs(
    ee,
    {
      disabled: o,
      onSelect: a,
      className: r(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        n
      ),
      ...i,
      children: [
        t && /* @__PURE__ */ e.jsx(N, { name: t, size: 16, className: "shrink-0" }),
        /* @__PURE__ */ e.jsx("span", { className: "flex-1", children: d }),
        s && /* @__PURE__ */ e.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: s })
      ]
    }
  );
}
function We({
  inset: t = !1,
  className: s,
  children: o,
  ...a
}) {
  return /* @__PURE__ */ e.jsx(
    O,
    {
      className: r(
        "px-2 py-1.5 text-sm font-semibold",
        t && "pl-8",
        s
      ),
      ...a,
      children: o
    }
  );
}
function Ee({
  className: t,
  ...s
}) {
  return /* @__PURE__ */ e.jsx(
    _,
    {
      className: r("-mx-1 my-1 h-px bg-muted", t),
      ...s
    }
  );
}
function Ge({
  checked: t = !1,
  onCheckedChange: s,
  disabled: o = !1,
  className: a,
  children: n
}) {
  return /* @__PURE__ */ e.jsxs(
    Z,
    {
      checked: t,
      onCheckedChange: s,
      disabled: o,
      className: r(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      children: [
        /* @__PURE__ */ e.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ e.jsx(M, { children: /* @__PURE__ */ e.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ e.jsx("polyline", { points: "20 6 9 17 4 12" }) }) }) }),
        n
      ]
    }
  );
}
function qe({
  value: t,
  onValueChange: s,
  className: o,
  children: a,
  ...n
}) {
  return /* @__PURE__ */ e.jsx(
    Y,
    {
      value: t,
      onValueChange: s,
      className: o,
      ...n,
      children: a
    }
  );
}
function Je({
  value: t,
  className: s,
  children: o
}) {
  return /* @__PURE__ */ e.jsxs(
    X,
    {
      value: t,
      className: r(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        s
      ),
      children: [
        /* @__PURE__ */ e.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ e.jsx(M, { children: /* @__PURE__ */ e.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "8", height: "8", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ e.jsx("circle", { cx: "12", cy: "12", r: "10" }) }) }) }),
        o
      ]
    }
  );
}
function Ke({
  children: t
}) {
  return /* @__PURE__ */ e.jsx(V, { children: t });
}
function Qe({
  inset: t = !1,
  icon: s,
  className: o,
  children: a,
  ...n
}) {
  return /* @__PURE__ */ e.jsxs(
    Q,
    {
      className: r(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        "focus:bg-accent data-[state=open]:bg-accent",
        t && "pl-8",
        o
      ),
      ...n,
      children: [
        s && /* @__PURE__ */ e.jsx(N, { name: s, size: 16, className: "shrink-0" }),
        a,
        /* @__PURE__ */ e.jsx("svg", { className: "ml-auto h-4 w-4", xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ e.jsx("polyline", { points: "9 18 15 12 9 6" }) })
      ]
    }
  );
}
function Ve({
  className: t,
  children: s,
  ...o
}) {
  return /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
    K,
    {
      className: r(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
        "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        t
      ),
      ...o,
      children: s
    }
  ) });
}
function Xe({
  children: t
}) {
  return /* @__PURE__ */ e.jsx(J, { children: t });
}
function Ye({
  asChild: t = !1,
  className: s,
  children: o
}) {
  const a = c.Children.toArray(o), n = a.length === 1 ? a[0] : null;
  return t && n ? /* @__PURE__ */ e.jsx(C, { asChild: !0, className: s, children: n }) : /* @__PURE__ */ e.jsx(C, { className: s, children: o });
}
function Ze({
  className: t,
  children: s,
  ...o
}) {
  return /* @__PURE__ */ e.jsx(G, { children: /* @__PURE__ */ e.jsx(
    q,
    {
      className: r(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "animate-in fade-in-80 data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        t
      ),
      ...o,
      children: s
    }
  ) });
}
function _e({
  icon: t,
  shortcut: s,
  disabled: o = !1,
  onSelect: a,
  className: n,
  children: d,
  ...i
}) {
  return /* @__PURE__ */ e.jsxs(
    E,
    {
      disabled: o,
      onSelect: a,
      className: r(
        "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        n
      ),
      ...i,
      children: [
        t && /* @__PURE__ */ e.jsx(N, { name: t, size: 16, className: "shrink-0" }),
        /* @__PURE__ */ e.jsx("span", { className: "flex-1", children: d }),
        s && /* @__PURE__ */ e.jsx("span", { className: "ml-auto text-xs tracking-widest text-muted-foreground", children: s })
      ]
    }
  );
}
function Oe({
  className: t,
  ...s
}) {
  return /* @__PURE__ */ e.jsx(
    W,
    {
      className: r("-mx-1 my-1 h-px bg-muted", t),
      ...s
    }
  );
}
function et({
  checked: t = !1,
  onCheckedChange: s,
  disabled: o = !1,
  className: a,
  children: n
}) {
  return /* @__PURE__ */ e.jsxs(
    U,
    {
      checked: t,
      onCheckedChange: s,
      disabled: o,
      className: r(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none",
        "transition-colors focus:bg-accent focus:text-accent-foreground",
        "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        a
      ),
      children: [
        /* @__PURE__ */ e.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ e.jsx(F, { children: /* @__PURE__ */ e.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ e.jsx("polyline", { points: "20 6 9 17 4 12" }) }) }) }),
        n
      ]
    }
  );
}
export {
  Xe as ContextMenu,
  et as ContextMenuCheckboxItem,
  Ze as ContextMenuContent,
  _e as ContextMenuItem,
  Oe as ContextMenuSeparator,
  Ye as ContextMenuTrigger,
  re as Dialog,
  fe as DialogAction,
  xe as DialogCancel,
  ie as DialogContent,
  me as DialogDescription,
  ce as DialogFooter,
  le as DialogHeader,
  ue as DialogTitle,
  de as DialogTrigger,
  Ne as Drawer,
  Se as DrawerClose,
  ke as DrawerContent,
  Me as DrawerDescription,
  De as DrawerFooter,
  ze as DrawerHeader,
  Ae as DrawerTitle,
  Ce as DrawerTrigger,
  Be as DropdownMenu,
  Ge as DropdownMenuCheckboxItem,
  Ue as DropdownMenuContent,
  Fe as DropdownMenuItem,
  We as DropdownMenuLabel,
  qe as DropdownMenuRadioGroup,
  Je as DropdownMenuRadioItem,
  Ee as DropdownMenuSeparator,
  Ke as DropdownMenuSub,
  Ve as DropdownMenuSubContent,
  Qe as DropdownMenuSubTrigger,
  He as DropdownMenuTrigger,
  Te as HoverCard,
  Le as HoverCardContent,
  $e as HoverCardTrigger,
  Ie as Popover,
  Pe as PopoverContent,
  Re as PopoverTrigger,
  pe as Sheet,
  he as SheetClose,
  be as SheetContent,
  ye as SheetDescription,
  ve as SheetFooter,
  je as SheetHeader,
  we as SheetTitle,
  ge as SheetTrigger
};
