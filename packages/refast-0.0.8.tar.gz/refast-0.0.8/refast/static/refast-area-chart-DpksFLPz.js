import { A as a, a as r } from "./refast-charts-Be0RW0P2.js";
const e = a, o = r;
export {
  o as Area,
  e as AreaChart
};
