import { P as e, e as t, S as o, f as a } from "./refast-charts-Be0RW0P2.js";
const r = e, c = t, i = o, P = a;
export {
  c as Pie,
  r as PieChart,
  P as PieLabel,
  i as Sector
};
