import { ay as e, ah as x } from "./refast-vendor-CQOdd5X6.js";
import { c as p } from "./refast-index-9fBfd4aX.js";
import { L as N, T as w, R as k } from "./refast-charts-Be0RW0P2.js";
function L({
  cursor: s = !1,
  content: t,
  ...n
}) {
  return /* @__PURE__ */ e.jsx(
    w,
    {
      content: t || /* @__PURE__ */ e.jsx(T, {}),
      cursor: s,
      ...n
    }
  );
}
const R = N, g = x.createContext(null);
function W() {
  const s = x.useContext(g);
  if (!s)
    throw new Error("useChart must be used within a ChartContainer");
  return s;
}
function z({
  config: s,
  children: t,
  width: n,
  height: r,
  minHeight: d,
  maxHeight: c,
  minWidth: l,
  aspect: o,
  initialDimension: a,
  debounce: m,
  className: f,
  style: i,
  id: v,
  onResize: C
}) {
  const u = x.useMemo(() => {
    const h = {};
    return Object.entries(s).forEach(([b, j]) => {
      j.color && (h[`--color-${b}`] = j.color);
    }), h;
  }, [s]);
  return /* @__PURE__ */ e.jsx(g.Provider, { value: s, children: /* @__PURE__ */ e.jsx(
    k,
    {
      width: n ?? "100%",
      height: r ?? "100%",
      minHeight: d ?? 200,
      maxHeight: c ?? void 0,
      minWidth: l ?? void 0,
      aspect: o ?? void 0,
      initialDimension: a ?? void 0,
      debounce: m ?? void 0,
      className: p("w-full", f),
      id: v,
      style: {
        ...u,
        ...i
      },
      onResize: C ?? void 0,
      children: t
    }
  ) });
}
function T({
  active: s,
  payload: t,
  label: n,
  indicator: r = "dot",
  hideLabel: d = !1,
  hideIndicator: c = !1,
  nameKey: l,
  labelKey: o
}) {
  var m, f;
  const a = x.useContext(g);
  return !s || !(t != null && t.length) ? null : /* @__PURE__ */ e.jsxs("div", { className: "grid items-start gap-2 rounded-lg border border-border bg-background p-2 text-xs shadow-xl", style: { minWidth: "8rem" }, children: [
    !d && n && /* @__PURE__ */ e.jsx("div", { className: "font-medium text-foreground", children: o ? (f = (m = t[0]) == null ? void 0 : m.payload) == null ? void 0 : f[o] : n }),
    /* @__PURE__ */ e.jsx("div", { className: "grid gap-2", children: t.map((i, v) => {
      var h;
      const C = l ? (h = i.payload) == null ? void 0 : h[l] : i.dataKey, u = a == null ? void 0 : a[C];
      return /* @__PURE__ */ e.jsxs("div", { className: "flex w-full flex-wrap items-stretch gap-2", children: [
        !c && /* @__PURE__ */ e.jsx(
          "div",
          {
            className: p(
              "h-2 w-2 shrink-0 rounded-sm",
              r === "dot" && "rounded-full",
              r === "line" && "w-1",
              r === "dashed" && "w-0 border-2 border-dashed bg-transparent"
            ),
            style: {
              backgroundColor: r === "dashed" ? void 0 : i.color,
              borderColor: r === "dashed" ? i.color : void 0
            }
          }
        ),
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-1 justify-between leading-none", children: [
          /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: (u == null ? void 0 : u.label) || C }),
          /* @__PURE__ */ e.jsx("span", { className: "font-medium text-foreground", children: i.value })
        ] })
      ] }, v);
    }) })
  ] });
}
function D({
  payload: s,
  nameKey: t,
  hideIcon: n = !1
}) {
  const r = x.useContext(g);
  return s != null && s.length ? /* @__PURE__ */ e.jsx("div", { className: "flex flex-wrap items-center justify-center gap-4", children: s.map((d, c) => {
    var a;
    const l = t ? (a = d.payload) == null ? void 0 : a[t] : d.dataKey, o = r == null ? void 0 : r[l];
    return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5 text-sm", children: [
      !n && /* @__PURE__ */ e.jsx(
        "div",
        {
          className: "h-2 w-2 rounded-full",
          style: { backgroundColor: d.color }
        }
      ),
      /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: (o == null ? void 0 : o.label) || l })
    ] }, c);
  }) }) : null;
}
L.displayName = "Tooltip";
R.displayName = "Legend";
export {
  z as ChartContainer,
  R as ChartLegend,
  D as ChartLegendContent,
  L as ChartTooltip,
  T as ChartTooltipContent,
  W as useChart
};
