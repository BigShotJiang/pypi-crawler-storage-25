var gr = Object.defineProperty;
var hr = (e, t, r) => t in e ? gr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var V = (e, t, r) => hr(e, typeof t != "symbol" ? t + "" : t, r);
import { r as x, ay as a, c8 as br, c as xr, ah as C, c9 as yr, ca as vr, cb as wr, cc as Me, cd as Cr, ce as kr, cf as jr, cg as Sr, ch as Nr, ci as Mr, cj as Er, ck as Tr, cl as Lr, cm as Ir, cn as Pr, co as Ee, cp as Rr, cq as Et, cr as Tt, cs as Ar, ct as Lt, cu as Dr, cv as _r, cw as zr, cx as Fr, cy as Te, cz as Le, cA as Br, cB as Or, cC as $r, cD as Hr, cE as Gr, cF as re, cG as It, cH as Wr } from "./refast-vendor-CQOdd5X6.js";
import { K as Ur, S as Kr, a as Vr, L as Jr, C as Xr, H as qr, P as Zr, b as Yr, c as Qr, W as en, B as tn, T as rn, d as nn, e as an, f as sn, g as on, R as ln, h as cn, M as dn, i as un, j as Ie, G as fn, k as pn, U as mn, I as gn, l as hn, m as Pe, n as Re, O as bn, o as xn, p as yn, q as vn, r as wn, s as Cn, t as kn, A as Ae, u as De, v as jn, w as _e, x as ze, y as Fe, z as Sn, D as Nn, E as Mn, F as Be, J as Oe, N as $e, Q as He, V as En, X as Ge, Y as We, Z as Tn, _ as Ln, $ as me, a0 as Ue, a1 as Ke, a2 as Ve, a3 as In, a4 as Pn, a5 as Rn, a6 as An, a7 as Je, a8 as Dn, a9 as _n, aa as Xe, ab as zn, ac as Fn, ad as Bn, ae as On, af as $n, ag as qe, ah as Hn, ai as Gn, aj as Wn, ak as Un, al as Kn, am as Ze, an as Vn, ao as Jn, ap as ge, aq as Xn, ar as Ye, as as qn, at as Qe, au as Zn, av as et, aw as tt, ax as Yn, ay as Qn, az as ea, aA as ta, aB as ra, aC as rt, aD as na, aE as aa, aF as sa, aG as oa, aH as ia, aI as la, aJ as nt, aK as at, aL as st, aM as ca, aN as da, aO as ua, aP as fa, aQ as pa, aR as ma, aS as ga, aT as ha, aU as ot, aV as ba, aW as it, aX as xa, aY as ya, aZ as va, a_ as wa, a$ as Ca, b0 as ka, b1 as ja, b2 as lt, b3 as Sa, b4 as Na, b5 as Ma, b6 as Ea, b7 as Ta, b8 as ct, b9 as La, ba as dt, bb as Ia, bc as Pa, bd as Ra, be as Aa, bf as ut, bg as Da, bh as _a, bi as Pt, bj as ft, bk as za, bl as pt, bm as Fa, bn as Ba, bo as Oa, bp as $a, bq as Ha, br as mt, bs as gt, bt as Ga, bu as Wa, bv as Ua, bw as Ka, bx as Va, by as Ja, bz as Xa, bA as qa, bB as Za, bC as Ya, bD as Qa, bE as es, bF as ts, bG as rs, bH as ns, bI as as, bJ as ss, bK as os, bL as is, bM as ls, bN as cs, bO as Rt, bP as ht, bQ as ds, bR as us, bS as fs, bT as ps, bU as bt, bV as ms, bW as gs, bX as hs, bY as bs, bZ as xs, b_ as ys, b$ as vs, c0 as ws, c1 as Cs, c2 as ks, c3 as js, c4 as Ss, c5 as Ns, c6 as Ms, c7 as Es, c8 as Ts, c9 as Ls, ca as Is, cb as Ps, cc as Rs, cd as As, ce as Ds, cf as _s, cg as zs, ch as Fs, ci as Bs, cj as Os, ck as xt, cl as $s, cm as Hs, cn as yt, co as Gs, cp as Ws, cq as Us, cr as Ks, cs as Vs, ct as Js, cu as Xs, cv as ce, cw as At, cx as Dt, cy as qs, cz as Zs, cA as _t, cB as Ys, cC as Qs, cD as eo, cE as to, cF as ro, cG as no, cH as ao, cI as so, cJ as oo, cK as io, cL as lo, cM as co, cN as uo, cO as zt, cP as fo, cQ as po, cR as mo, cS as go, cT as ho } from "./refast-icons-BtQPpLxJ.js";
const Ft = "refast:", ye = `${Ft}local:`, ve = `${Ft}session:`;
function Bt(e, t) {
  const r = [];
  for (let n = 0; n < e.length; n++) {
    const s = e.key(n);
    s && s.startsWith(t) && r.push(s);
  }
  return r;
}
function le(e, t) {
  const r = {}, n = Bt(e, t);
  for (const s of n) {
    const o = s.substring(t.length), c = e.getItem(s);
    c !== null && (r[o] = c);
  }
  return r;
}
function he(e) {
  return e === "local" ? { storage: localStorage, prefix: ye } : { storage: sessionStorage, prefix: ve };
}
class bo {
  constructor() {
    V(this, "websocket", null);
    V(this, "initialized", !1);
    V(this, "onReadyCallback", null);
  }
  /**
   * Set the WebSocket connection to use for communication.
   */
  setWebSocket(t) {
    this.websocket = t, t && t.readyState === WebSocket.OPEN ? this.sendInitialState() : t && t.addEventListener("open", () => {
      this.sendInitialState();
    }, { once: !0 });
  }
  /**
   * Register a callback to be called when store is ready (after init is acknowledged).
   */
  onReady(t) {
    this.onReadyCallback = t;
  }
  /**
   * Called when backend acknowledges store_init.
   */
  handleStoreReady() {
    this.onReadyCallback && this.onReadyCallback();
  }
  /**
   * Check if store has been initialized with backend.
   */
  isInitialized() {
    return this.initialized;
  }
  /**
   * Resync the store state with the backend.
   * This sends the current browser storage state as a store_sync message.
   */
  resyncStore() {
    if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN) {
      console.warn("[Refast] Cannot resync store: WebSocket not connected");
      return;
    }
    const t = {
      local: le(localStorage, ye),
      session: le(sessionStorage, ve)
    };
    this.websocket.send(JSON.stringify({
      type: "store_sync",
      data: t
    }));
  }
  /**
   * Send the current browser storage state to the backend.
   */
  sendInitialState() {
    if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN || this.initialized)
      return;
    const t = {
      local: le(localStorage, ye),
      session: le(sessionStorage, ve)
    };
    this.websocket.send(JSON.stringify({
      type: "store_init",
      data: t,
      path: window.location.pathname + window.location.search
    })), this.initialized = !0;
  }
  /**
   * Handle store updates from the backend.
   */
  handleUpdates(t) {
    for (const r of t)
      this.applyUpdate(r);
  }
  /**
   * Apply a single store update.
   */
  applyUpdate(t) {
    const { storage: r, prefix: n } = he(t.storageType);
    switch (t.operation) {
      case "set":
        if (t.key !== null && t.value !== void 0) {
          const o = t.value;
          typeof o == "string" ? r.setItem(`${n}${t.key}`, o) : r.setItem(`${n}${t.key}`, JSON.stringify(o));
        }
        break;
      case "delete":
        t.key !== null && r.removeItem(`${n}${t.key}`);
        break;
      case "clear":
        const s = Bt(r, n);
        for (const o of s)
          r.removeItem(o);
        break;
    }
  }
  /**
   * Read a value from browser storage directly.
   * Useful for getting initial values before backend sync.
   */
  get(t, r) {
    const { storage: n, prefix: s } = he(t);
    return n.getItem(`${s}${r}`);
  }
  /**
   * Get all values from a storage type.
   */
  getAll(t) {
    const { storage: r, prefix: n } = he(t);
    return le(r, n);
  }
  /**
   * Reset the initialized state (used on reconnect).
   */
  reset() {
    this.initialized = !1;
  }
}
const ne = new bo();
class xo {
  /**
   * Dispatch a typed refast event on the window.
   */
  emit(t, r) {
    window.dispatchEvent(new CustomEvent(t, { detail: r }));
  }
  /**
   * Subscribe to a typed refast event.
   * Returns an unsubscribe function suitable for use as a useEffect cleanup.
   */
  on(t, r) {
    const n = (s) => r(s.detail);
    return window.addEventListener(t, n), () => window.removeEventListener(t, n);
  }
}
const Z = new xo(), Ot = {
  invoke(e, t = {}) {
    if (!e || !e.callbackId) {
      console.warn("[Refast] refast.invoke() called with invalid callback:", e);
      return;
    }
    Z.emit("refast:callback", {
      callbackId: e.callbackId,
      data: { ...e.boundArgs || {}, ...t }
    });
  }
};
let vt = !1;
function yo(e) {
  const t = document.documentElement;
  if (!vt) {
    const d = t.style, u = [];
    for (let f = 0; f < d.length; f++) {
      const m = d[f];
      m.startsWith("--") && u.push(m);
    }
    u.forEach((f) => d.removeProperty(f)), vt = !0;
  }
  const r = document.querySelector("style[data-refast-theme]");
  r && (r.textContent = "");
  let n = document.querySelector("style[data-refast-theme-runtime]");
  n || (n = document.createElement("style"), n.setAttribute("data-refast-theme-runtime", ""), document.head.appendChild(n));
  const s = Object.entries(e.light), o = Object.entries(e.dark);
  e.radius && s.push(["--radius", e.radius]);
  const c = s.map(([d, u]) => `  ${d}: ${u};`).join(`
`), l = o.map(([d, u]) => `  ${d}: ${u};`).join(`
`);
  let i = "";
  c && (i += `:root {
${c}
}
`), l && (i += `.dark {
${l}
}`), n.textContent = i, e.fontFamily ? document.body.style.fontFamily = e.fontFamily : document.body.style.removeProperty("font-family");
}
const $t = x.createContext(null);
function vo({
  children: e,
  websocket: t,
  onComponentUpdate: r
}) {
  const n = x.useRef(/* @__PURE__ */ new Set()), s = x.useRef(t), o = x.useRef(/* @__PURE__ */ new Map());
  x.useEffect(() => {
    s.current = t;
  }, [t]);
  const c = x.useCallback(
    (p, g) => {
      const h = o.current;
      return h.has(p) || h.set(p, /* @__PURE__ */ new Set()), h.get(p).add(g), () => {
        var v;
        return (v = h.get(p)) == null ? void 0 : v.delete(g);
      };
    },
    []
    // stable
  );
  x.useEffect(() => {
    const p = [];
    return p.push(
      c("store_update", (g) => {
        g.updates && ne.handleUpdates(g.updates);
      })
    ), p.push(
      c("store_ready", () => {
        ne.handleStoreReady();
      })
    ), p.push(
      c("js_exec", (g) => {
        if (g.code)
          try {
            new Function("args", "refast", g.code)(g.args || {}, Ot);
          } catch (h) {
            console.error("[Refast] Error executing JavaScript from server:", h), console.error("[Refast] Code:", g.code);
          }
      })
    ), p.push(
      c("bound_method_call", (g) => {
        if (!(!g.targetId || !g.methodName))
          try {
            const h = document.getElementById(g.targetId);
            if (h) {
              const v = h[g.methodName];
              if (typeof v == "function") {
                const y = Array.isArray(g.args) ? g.args : [], S = g.kwargs || {}, j = Object.keys(S).length > 0 ? [...y, S] : y;
                j.length === 0 ? v.call(h) : j.length === 1 ? v.call(h, j[0]) : v.apply(h, j);
              } else
                console.warn(`[Refast] Method '${g.methodName}' not found on element '${g.targetId}'`);
            } else
              console.warn(`[Refast] Element with id '${g.targetId}' not found`);
          } catch (h) {
            console.error("[Refast] Error calling bound method:", h), console.error("[Refast] Target:", g.targetId, "Method:", g.methodName);
          }
      })
    ), p.push(
      c("resync_store", () => {
        ne.resyncStore();
      })
    ), p.push(
      c("theme_update", (g) => {
        g.theme && yo(g.theme);
      })
    ), () => p.forEach((g) => g());
  }, [c]), x.useEffect(() => Z.on("refast:callback", ({ callbackId: p, data: g }) => {
    s.current && s.current.readyState === WebSocket.OPEN ? s.current.send(
      JSON.stringify({ type: "callback", callbackId: p, data: g })
    ) : console.warn("WebSocket not connected, cannot invoke callback");
  }), []), x.useEffect(() => {
    if (!t) return;
    const p = (g) => {
      var h;
      try {
        const v = JSON.parse(g.data);
        n.current.forEach((y) => y(v)), (h = o.current.get(v.type)) == null || h.forEach((y) => y(v));
      } catch (v) {
        console.error("Error parsing WebSocket message:", v);
      }
    };
    return t.addEventListener("message", p), () => t.removeEventListener("message", p);
  }, [t]);
  const l = x.useCallback(
    (p, g, h) => {
      if (!t || t.readyState !== WebSocket.OPEN) {
        console.warn("WebSocket not connected");
        return;
      }
      const v = {
        type: "callback",
        callbackId: p,
        data: g,
        ...h && Object.keys(h).length > 0 ? { eventData: h } : {}
      };
      t.send(JSON.stringify(v));
    },
    [t]
  ), i = x.useCallback(
    (p, g) => {
      if (!t || t.readyState !== WebSocket.OPEN) {
        console.warn("WebSocket not connected");
        return;
      }
      const h = {
        type: "event",
        eventType: p,
        data: g
      };
      t.send(JSON.stringify(h));
    },
    [t]
  ), d = x.useCallback(
    (p) => {
      if (!t || t.readyState !== WebSocket.OPEN) return;
      const g = {
        type: "subscribe",
        eventType: p
      };
      t.send(JSON.stringify(g));
    },
    [t]
  ), u = x.useCallback(
    (p) => {
      if (!t || t.readyState !== WebSocket.OPEN) return;
      const g = {
        type: "unsubscribe",
        eventType: p
      };
      t.send(JSON.stringify(g));
    },
    [t]
  ), f = x.useCallback(
    (p) => (n.current.add(p), () => {
      n.current.delete(p);
    }),
    []
  ), m = x.useMemo(
    () => ({
      invokeCallback: l,
      emitEvent: i,
      subscribe: d,
      unsubscribe: u,
      onUpdate: f,
      registerMessageHandler: c
    }),
    [l, i, d, u, f, c]
  );
  return /* @__PURE__ */ a.jsx($t.Provider, { value: m, children: e });
}
function oe() {
  const e = x.useContext($t);
  if (!e)
    throw new Error("useEventManager must be used within EventManagerProvider");
  return e;
}
function Ml(e, t) {
  const { onUpdate: r } = oe();
  x.useEffect(() => r((n) => {
    n.type === "event" && n.eventType === e && t(n.data);
  }), [e, t, r]);
}
function El(e) {
  const { subscribe: t, unsubscribe: r } = oe();
  x.useEffect(() => (t(e), () => r(e)), [e, t, r]);
}
function b(...e) {
  return br(xr(e));
}
function wo(e, t) {
  let r;
  return (...n) => {
    clearTimeout(r), r = setTimeout(() => e(...n), t);
  };
}
function Co(e, t) {
  let r = 0;
  return (...n) => {
    const s = Date.now();
    s - r >= t && (r = s, e(...n));
  };
}
function Tl(e = "refast") {
  return `${e}-${Math.random().toString(36).substring(2, 11)}`;
}
function wt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
function ko(e, t) {
  const r = { ...e };
  for (const n in t) {
    const s = t[n], o = e[n];
    wt(s) && wt(o) ? r[n] = ko(
      o,
      s
    ) : s !== void 0 && (r[n] = s);
  }
  return r;
}
function jo(e, t) {
  throw new Error(`[Refast] Unhandled case: ${JSON.stringify(e)}`);
}
function So({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s,
  ...o
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("", t),
      style: r,
      "data-refast-id": s,
      ...o,
      children: n
    }
  );
}
function No({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s,
  ...o
}) {
  return /* @__PURE__ */ a.jsx(
    "span",
    {
      id: e,
      className: b("", t),
      style: r,
      "data-refast-id": s,
      ...o,
      children: n
    }
  );
}
function Mo({ children: e }) {
  return /* @__PURE__ */ a.jsx(a.Fragment, { children: e });
}
function Eo({
  id: e,
  className: t,
  justify: r = "start",
  align: n = "start",
  gap: s = 2,
  wrap: o = !1,
  children: c,
  "data-refast-id": l,
  ...i
}) {
  const d = {
    start: "justify-start",
    end: "justify-end",
    center: "justify-center",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly"
  }[r], u = {
    start: "items-start",
    end: "items-end",
    center: "items-center",
    stretch: "items-stretch",
    baseline: "items-baseline"
  }[n];
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(
        "flex flex-row",
        d,
        u,
        o && "flex-wrap",
        t
      ),
      style: { gap: typeof s == "number" ? `${s * 0.25}rem` : s },
      "data-refast-id": l,
      ...i,
      children: c
    }
  );
}
function To({
  id: e,
  className: t,
  justify: r = "start",
  align: n = "stretch",
  gap: s = 2,
  wrap: o = !1,
  children: c,
  "data-refast-id": l,
  ...i
}) {
  const d = {
    start: "justify-start",
    end: "justify-end",
    center: "justify-center",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly"
  }[r], u = {
    start: "items-start",
    end: "items-end",
    center: "items-center",
    stretch: "items-stretch",
    baseline: "items-baseline"
  }[n];
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("flex flex-col", d, u, o && "flex-wrap", t),
      style: { gap: typeof s == "number" ? `${s * 0.25}rem` : s },
      "data-refast-id": l,
      ...i,
      children: c
    }
  );
}
function Lo({
  id: e,
  className: t,
  columns: r = 1,
  rows: n,
  gap: s = 4,
  children: o,
  "data-refast-id": c,
  ...l
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("grid", t),
      style: {
        gridTemplateColumns: typeof r == "number" ? `repeat(${r}, 1fr)` : r,
        gridTemplateRows: n ? typeof n == "number" ? `repeat(${n}, 1fr)` : n : void 0,
        gap: typeof s == "number" ? `${s * 0.25}rem` : s
      },
      "data-refast-id": c,
      ...l,
      children: o
    }
  );
}
function Io({
  id: e,
  className: t,
  direction: r = "row",
  justify: n = "start",
  align: s = "stretch",
  gap: o = 2,
  wrap: c = !1,
  children: l,
  "data-refast-id": i,
  ...d
}) {
  const u = {
    row: "flex-row",
    column: "flex-col",
    "row-reverse": "flex-row-reverse",
    "column-reverse": "flex-col-reverse"
  }[r], f = {
    start: "justify-start",
    end: "justify-end",
    center: "justify-center",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly"
  }[n], m = {
    start: "items-start",
    end: "items-end",
    center: "items-center",
    stretch: "items-stretch",
    baseline: "items-baseline"
  }[s];
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("flex", u, f, m, c && "flex-wrap", t),
      style: { gap: typeof o == "number" ? `${o * 0.25}rem` : o },
      "data-refast-id": i,
      ...d,
      children: l
    }
  );
}
function Po({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n,
  ...s
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("flex items-center justify-center", t),
      "data-refast-id": n,
      ...s,
      children: r
    }
  );
}
const Ro = {
  // Navigation
  home: ho,
  menu: go,
  "chevron-left": mo,
  "chevron-right": po,
  "chevron-up": fo,
  "chevron-down": zt,
  "chevrons-left": uo,
  "chevrons-right": co,
  "chevrons-up": lo,
  "chevrons-down": io,
  "arrow-left": oo,
  "arrow-right": so,
  "arrow-up": ao,
  "arrow-down": no,
  "arrow-up-right": ro,
  "arrow-down-left": to,
  "corner-up-left": eo,
  "corner-up-right": Qs,
  move: Ys,
  "external-link": _t,
  // Actions
  plus: Zs,
  minus: qs,
  x: Dt,
  check: At,
  edit: ce,
  "edit-2": ce,
  "edit-3": ce,
  pencil: ce,
  trash: Xs,
  "trash-2": Js,
  save: Vs,
  copy: Ks,
  clipboard: Us,
  "clipboard-check": Ws,
  paste: Gs,
  cut: yt,
  scissors: yt,
  undo: Hs,
  redo: $s,
  "refresh-cw": xt,
  refresh: xt,
  "rotate-ccw": Os,
  "rotate-cw": Bs,
  // Files
  file: Fs,
  "file-text": zs,
  "file-plus": _s,
  "file-minus": Ds,
  "file-check": As,
  "file-x": Rs,
  folder: Ps,
  "folder-open": Is,
  "folder-plus": Ls,
  "folder-minus": Ts,
  upload: Es,
  "upload-cloud": Ms,
  download: Ns,
  "cloud-off": Ss,
  image: js,
  video: ks,
  music: Cs,
  archive: ws,
  // Documents & Buildings
  book: vs,
  "book-open": ys,
  building: xs,
  "building-2": bs,
  // UI
  search: hs,
  settings: gs,
  "settings-2": ms,
  sliders: bt,
  "sliders-horizontal": bt,
  filter: ps,
  "sort-asc": fs,
  "sort-desc": us,
  "more-horizontal": ht,
  "more-vertical": ds,
  ellipsis: ht,
  "grip-vertical": Rt,
  "grip-horizontal": cs,
  maximize: ls,
  minimize: is,
  "maximize-2": os,
  "minimize-2": ss,
  expand: as,
  shrink: ns,
  eye: rs,
  "eye-off": ts,
  lock: es,
  unlock: Qa,
  key: Ya,
  link: Za,
  "link-2": qa,
  unlink: Xa,
  // Users
  user: Ja,
  users: Va,
  "user-plus": Ka,
  "user-minus": Ua,
  "user-check": Wa,
  "user-x": Ga,
  "log-in": gt,
  "log-out": mt,
  login: gt,
  logout: mt,
  // Status
  "check-circle": Ha,
  "check-circle-2": $a,
  "x-circle": Oa,
  "alert-circle": Ba,
  info: Fa,
  "alert-triangle": pt,
  warning: pt,
  loader: za,
  "loader-2": ft,
  spinner: ft,
  circle: Pt,
  "circle-dot": _a,
  ban: Da,
  // Communication
  mail: ut,
  email: ut,
  "mail-open": Aa,
  send: Ra,
  inbox: Pa,
  "message-circle": dt,
  "message-square": Ia,
  chat: dt,
  bell: ct,
  "bell-off": La,
  notification: ct,
  phone: Ta,
  "phone-call": Ea,
  "phone-off": Ma,
  // Media
  play: Na,
  pause: Sa,
  "stop-circle": lt,
  stop: lt,
  "skip-back": ja,
  "skip-forward": ka,
  "fast-forward": Ca,
  rewind: wa,
  volume: va,
  "volume-1": ya,
  "volume-2": xa,
  "volume-x": it,
  mute: it,
  // Data
  "bar-chart": ba,
  "bar-chart-2": ot,
  chart: ot,
  "line-chart": ha,
  "pie-chart": ga,
  activity: ma,
  "trending-up": pa,
  "trending-down": fa,
  database: ua,
  server: da,
  // Layout
  layout: ca,
  "layout-grid": st,
  grid: st,
  "layout-list": at,
  list: at,
  sidebar: nt,
  "panel-left": nt,
  "panel-right": la,
  "panel-top": ia,
  "panel-bottom": oa,
  columns: sa,
  rows: aa,
  // Misc
  star: na,
  heart: rt,
  like: rt,
  "thumbs-up": ra,
  "thumbs-down": ta,
  bookmark: ea,
  flag: Qn,
  tag: Yn,
  hash: tt,
  hashtag: tt,
  "at-sign": et,
  at: et,
  calendar: Zn,
  clock: Qe,
  time: Qe,
  timer: qn,
  "alarm-clock": Ye,
  alarm: Ye,
  map: Xn,
  "map-pin": ge,
  location: ge,
  pin: ge,
  navigation: Jn,
  compass: Vn,
  globe: Ze,
  world: Ze,
  wifi: Kn,
  "wifi-off": Un,
  bluetooth: Wn,
  battery: Gn,
  power: Hn,
  zap: qe,
  lightning: qe,
  sun: $n,
  moon: On,
  cloud: Bn,
  umbrella: Fn,
  thermometer: zn,
  droplet: Xe,
  water: Xe,
  wind: _n,
  code: Dn,
  terminal: Je,
  console: Je,
  github: An,
  gitlab: Rn,
  package: Pn,
  box: In,
  "shopping-cart": Ve,
  cart: Ve,
  "shopping-bag": Ke,
  bag: Ke,
  "credit-card": Ue,
  card: Ue,
  "dollar-sign": me,
  dollar: me,
  money: me,
  percent: Ln,
  gift: Tn,
  truck: We,
  delivery: We,
  printer: Ge,
  print: Ge,
  camera: En,
  mic: He,
  microphone: He,
  headphones: $e,
  audio: $e,
  monitor: Oe,
  desktop: Oe,
  smartphone: Be,
  mobile: Be,
  tablet: Mn,
  laptop: Nn,
  watch: Sn,
  tv: Fe,
  television: Fe,
  cpu: ze,
  processor: ze,
  "hard-drive": _e,
  hdd: _e,
  shield: De,
  "shield-check": jn,
  security: De,
  award: Ae,
  trophy: Ae,
  target: kn,
  crosshair: Cn,
  layers: wn,
  square: vn,
  triangle: yn,
  hexagon: xn,
  octagon: bn,
  "help-circle": Re,
  help: Re,
  "life-buoy": Pe,
  support: Pe,
  // Text formatting
  bold: hn,
  italic: gn,
  underline: mn,
  // Additional icons for docs & common use
  rocket: pn,
  "grid-3x3": fn,
  "mouse-pointer": Ie,
  cursor: Ie,
  "mouse-pointer-2": un,
  "mouse-pointer-click": dn,
  route: cn,
  radio: ln,
  palette: on,
  component: sn,
  type: an,
  "text-cursor-input": nn,
  table: rn,
  "bar-chart-3": tn,
  wrench: en,
  hammer: Qr,
  puzzle: Yr,
  paintbrush: Zr,
  "hand-metal": qr,
  "check-square": Xr,
  "layout-dashboard": Jr,
  share: Vr,
  "share-2": Kr,
  keyboard: Ur
};
function Y({
  name: e,
  size: t = 16,
  color: r,
  strokeWidth: n = 2,
  className: s,
  "data-refast-id": o
}) {
  const c = Ro[e.toLowerCase()];
  return c ? /* @__PURE__ */ a.jsx(
    c,
    {
      size: t,
      color: r,
      strokeWidth: n,
      className: b("shrink-0", s),
      "data-refast-id": o,
      "aria-hidden": "true"
    }
  ) : /* @__PURE__ */ a.jsx(
    "span",
    {
      className: b("inline-flex shrink-0 items-center justify-center", s),
      style: {
        width: t,
        height: t,
        fontSize: t * 0.875,
        lineHeight: 1
      },
      "data-refast-id": o,
      "aria-hidden": "true",
      children: e
    }
  );
}
const Ht = C.forwardRef(({
  className: e,
  variant: t = "default",
  size: r = "md",
  loading: n = !1,
  icon: s,
  iconPosition: o = "left",
  children: c,
  "data-refast-id": l,
  ...i
}, d) => {
  const u = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    ghost: "hover:bg-accent hover:text-accent-foreground",
    link: "text-primary underline-offset-4 hover:underline"
  }, f = {
    xs: "h-7 px-2 text-xs",
    sm: "h-9 px-3 text-sm",
    md: "h-10 px-4 py-2",
    lg: "h-11 px-8 text-lg",
    xl: "h-12 px-10 text-xl"
  }, p = { xs: 12, sm: 14, md: 16, lg: 20, xl: 24 }[r ?? "md"] ?? 16, g = C.Children.count(c) > 0 || typeof c == "string" && c.length > 0;
  return /* @__PURE__ */ a.jsxs(
    "button",
    {
      ref: d,
      disabled: i.disabled || n,
      className: b(
        "inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        u[t],
        f[r],
        e
      ),
      "data-refast-id": l,
      ...i,
      children: [
        n && /* @__PURE__ */ a.jsx("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }),
        !n && s && o === "left" && /* @__PURE__ */ a.jsx(Y, { name: s, size: p }),
        g && /* @__PURE__ */ a.jsx("span", { children: c }),
        !n && s && o === "right" && /* @__PURE__ */ a.jsx(Y, { name: s, size: p })
      ]
    }
  );
});
Ht.displayName = "Button";
const Gt = C.forwardRef(({
  id: e,
  className: t,
  icon: r,
  variant: n = "ghost",
  size: s = "md",
  disabled: o = !1,
  onClick: c,
  ariaLabel: l,
  "data-refast-id": i,
  ...d
}, u) => {
  const f = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    ghost: "hover:bg-accent hover:text-accent-foreground"
  }, m = {
    xs: "h-7 w-7",
    sm: "h-9 w-9",
    md: "h-10 w-10",
    lg: "h-11 w-11",
    xl: "h-12 w-12"
  }, p = { xs: 12, sm: 14, md: 16, lg: 20, xl: 24 };
  return /* @__PURE__ */ a.jsx(
    "button",
    {
      ref: u,
      id: e,
      disabled: o,
      onClick: c,
      "data-refast-id": i,
      "aria-label": l || r,
      className: b(
        "inline-flex items-center justify-center rounded-md font-medium transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        f[n],
        m[s],
        t
      ),
      ...d,
      children: /* @__PURE__ */ a.jsx(Y, { name: r, size: p[s] ?? 16 })
    }
  );
});
Gt.displayName = "IconButton";
const Ll = yr(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Ao({
  id: e,
  className: t,
  style: r,
  title: n,
  description: s,
  children: o,
  "data-refast-id": c,
  ...l
}) {
  return /* @__PURE__ */ a.jsxs(
    "div",
    {
      id: e,
      className: b(
        "rounded-lg border bg-card text-card-foreground shadow-sm",
        t
      ),
      style: r,
      "data-refast-id": c,
      ...l,
      children: [
        n && /* @__PURE__ */ a.jsx("h3", { className: "text-2xl font-semibold leading-none tracking-tight p-6 pb-0", children: n }),
        s && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground p-6 pt-1 pb-0", children: s }),
        o
      ]
    }
  );
}
function Do({
  id: e,
  className: t,
  style: r,
  title: n,
  description: s,
  children: o,
  "data-refast-id": c
}) {
  return /* @__PURE__ */ a.jsxs(
    "div",
    {
      id: e,
      className: b("flex flex-col space-y-1.5 p-6", t),
      style: r,
      "data-refast-id": c,
      children: [
        n && /* @__PURE__ */ a.jsx("h3", { className: "text-2xl font-semibold leading-none tracking-tight", children: n }),
        s && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: s }),
        o
      ]
    }
  );
}
function _o({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    "h3",
    {
      id: e,
      className: b(
        "text-2xl font-semibold leading-none tracking-tight",
        t
      ),
      style: r,
      "data-refast-id": s,
      children: n
    }
  );
}
function zo({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    "p",
    {
      id: e,
      className: b("text-sm text-muted-foreground", t),
      style: r,
      "data-refast-id": s,
      children: n
    }
  );
}
function Fo({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("p-6 pt-0", t),
      style: r,
      "data-refast-id": s,
      children: n
    }
  );
}
function Bo({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("flex items-center p-6 pt-0", t),
      style: r,
      "data-refast-id": s,
      children: n
    }
  );
}
function pe({
  id: e,
  className: t,
  style: r,
  label: n,
  labelEnd: s,
  description: o,
  required: c = !1,
  error: l,
  children: i,
  "data-refast-id": d
}) {
  return !n && !o && !l ? /* @__PURE__ */ a.jsx("div", { className: t, style: r, "data-input-wrapper": !0, "data-refast-id": d, children: i }) : /* @__PURE__ */ a.jsxs("div", { className: b("mb-2", t), style: r, "data-input-wrapper": !0, "data-refast-id": d, children: [
    n && /* @__PURE__ */ a.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ a.jsxs(
        "label",
        {
          htmlFor: e,
          className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
          children: [
            n,
            c && /* @__PURE__ */ a.jsx("span", { className: "text-destructive ml-1", children: "*" })
          ]
        }
      ),
      s
    ] }),
    o && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: o }),
    /* @__PURE__ */ a.jsx("div", { className: "my-1", children: i }),
    l && /* @__PURE__ */ a.jsx("p", { className: "text-xs text-destructive", children: l })
  ] });
}
const Wt = C.createContext(null);
function Oo({
  id: e,
  className: t,
  style: r,
  label: n,
  description: s,
  type: o = "text",
  placeholder: c,
  value: l,
  defaultValue: i,
  disabled: d = !1,
  required: u = !1,
  readOnly: f = !1,
  error: m,
  name: p,
  debounce: g = 0,
  onChange: h,
  onBlur: v,
  onFocus: y,
  onKeydown: S,
  onKeyup: N,
  onInput: j,
  "data-refast-id": D
}) {
  const [I, P] = C.useState(l !== void 0 ? l : i || ""), T = C.useRef(null), A = C.useRef(h), O = C.useRef(l);
  C.useEffect(() => {
    A.current = h;
  }, [h]), C.useEffect(() => {
    l !== void 0 && l !== O.current && (O.current = l, T.current || P(l));
  }, [l]), C.useEffect(() => Z.on("refast:force-value-sync", ({ targetId: L, value: H }) => {
    L === e && H !== void 0 && (O.current = H, P(H), T.current !== null && (window.clearTimeout(T.current), T.current = null));
  }), [e]), C.useEffect(() => () => {
    T.current !== null && (window.clearTimeout(T.current), T.current = null);
  }, []);
  const $ = C.useCallback(
    (L) => {
      const H = L.target.value;
      if (P(H), !!A.current) {
        if (g > 0) {
          T.current !== null && window.clearTimeout(T.current);
          const M = {
            ...L,
            target: { ...L.target, tagName: L.target.tagName, name: L.target.name, type: L.target.type, value: H },
            currentTarget: { ...L.currentTarget, tagName: L.currentTarget.tagName, name: L.currentTarget.name, type: L.currentTarget.type, value: H }
          };
          T.current = window.setTimeout(() => {
            var E;
            T.current = null, (E = A.current) == null || E.call(A, M);
          }, g);
          return;
        }
        A.current(L);
      }
    },
    [g, p]
  ), k = /* @__PURE__ */ a.jsx(
    "input",
    {
      id: e,
      type: o,
      placeholder: c,
      value: I,
      disabled: d,
      readOnly: f,
      required: u,
      name: p || void 0,
      onChange: $,
      onBlur: v,
      onFocus: y,
      onKeyDown: S,
      onKeyUp: N,
      onInput: j,
      className: b(
        "flex h-10 w-full rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        m ? "border-destructive placeholder:text-destructive" : "border-input placeholder:text-muted-foreground",
        t
      ),
      style: r
    }
  );
  return n || s || m ? /* @__PURE__ */ a.jsx(
    pe,
    {
      id: e,
      label: n,
      description: s,
      required: u,
      error: m,
      "data-refast-id": D,
      children: k
    }
  ) : /* @__PURE__ */ a.jsx("div", { "data-refast-id": D, children: k });
}
function $o({
  id: e,
  className: t,
  style: r,
  label: n,
  description: s,
  required: o = !1,
  error: c,
  placeholder: l,
  value: i,
  defaultValue: d,
  disabled: u = !1,
  rows: f = 3,
  name: m,
  debounce: p = 0,
  onChange: g,
  onBlur: h,
  onFocus: v,
  onKeydown: y,
  onKeyup: S,
  onInput: N,
  "data-refast-id": j
}) {
  const [D, I] = C.useState(i !== void 0 ? i : d || ""), P = C.useRef(null), T = C.useRef(g), A = C.useRef(i);
  C.useEffect(() => {
    T.current = g;
  }, [g]), C.useEffect(() => {
    i !== void 0 && i !== A.current && (A.current = i, P.current || I(i));
  }, [i]), C.useEffect(() => Z.on("refast:force-value-sync", ({ targetId: k, value: L }) => {
    k === e && L !== void 0 && (A.current = L, I(L), P.current !== null && (window.clearTimeout(P.current), P.current = null));
  }), [e]), C.useEffect(() => () => {
    P.current !== null && (window.clearTimeout(P.current), P.current = null);
  }, []);
  const O = C.useCallback(
    (k) => {
      const L = k.target.value;
      if (I(L), !!T.current) {
        if (p > 0) {
          P.current !== null && window.clearTimeout(P.current);
          const H = {
            ...k,
            target: { ...k.target, tagName: k.target.tagName, name: k.target.name, value: L },
            currentTarget: { ...k.currentTarget, tagName: k.currentTarget.tagName, name: k.currentTarget.name, value: L }
          };
          P.current = window.setTimeout(() => {
            var M;
            P.current = null, (M = T.current) == null || M.call(T, H);
          }, p);
          return;
        }
        T.current(k);
      }
    },
    [p, m]
  ), $ = /* @__PURE__ */ a.jsx(
    "textarea",
    {
      id: e,
      placeholder: l,
      value: D,
      disabled: u,
      required: o,
      rows: f,
      name: m || void 0,
      onChange: O,
      onBlur: h,
      onFocus: v,
      onKeyDown: y,
      onKeyUp: S,
      onInput: N,
      className: b(
        "flex min-h-[80px] w-full rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background placeholder:text-muted-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        c ? "border-destructive" : "border-input",
        t
      ),
      style: r
    }
  );
  return n || s || c ? /* @__PURE__ */ a.jsx(
    pe,
    {
      id: e,
      label: n,
      description: s,
      required: o,
      error: c,
      "data-refast-id": j,
      children: $
    }
  ) : /* @__PURE__ */ a.jsx("div", { "data-refast-id": j, children: $ });
}
function Ho({
  id: e,
  className: t,
  style: r,
  label: n,
  description: s,
  required: o = !1,
  error: c,
  placeholder: l,
  value: i,
  defaultValue: d,
  disabled: u = !1,
  name: f,
  options: m,
  onChange: p,
  children: g,
  "data-refast-id": h
}) {
  const [v, y] = C.useState(i !== void 0 ? i : d || "");
  C.useEffect(() => {
    i !== void 0 && y(i);
  }, [i]), C.useEffect(() => Z.on("refast:force-value-sync", ({ targetId: j, value: D }) => {
    j === e && D !== void 0 && y(D);
  }), [e]);
  const S = (j) => {
    y(j.target.value), p && p(j);
  }, N = /* @__PURE__ */ a.jsxs(
    "select",
    {
      id: e,
      value: v,
      disabled: u,
      required: o,
      name: f || void 0,
      onChange: S,
      className: b(
        "flex h-10 w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
        "ring-offset-background placeholder:text-muted-foreground",
        "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        c ? "border-destructive" : "border-input",
        t
      ),
      style: r,
      children: [
        l && /* @__PURE__ */ a.jsx("option", { value: "", disabled: !0, children: l }),
        m == null ? void 0 : m.map((j) => /* @__PURE__ */ a.jsx("option", { value: j.value, disabled: j.disabled, children: j.label }, j.value)),
        g
      ]
    }
  );
  return n || s || c ? /* @__PURE__ */ a.jsx(
    pe,
    {
      id: e,
      label: n,
      description: s,
      required: o,
      error: c,
      "data-refast-id": h,
      children: N
    }
  ) : /* @__PURE__ */ a.jsx("div", { "data-refast-id": h, children: N });
}
function Go({
  value: e,
  disabled: t = !1,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx("option", { value: e, disabled: t, "data-refast-id": n, children: r });
}
function Wo({
  id: e,
  className: t,
  style: r,
  label: n,
  description: s,
  required: o = !1,
  error: c,
  checked: l,
  defaultChecked: i,
  disabled: d = !1,
  name: u,
  value: f,
  onCheckedChange: m,
  "data-refast-id": p
}) {
  const g = C.useId(), h = e || g, v = C.useContext(Wt), y = v !== null && f !== void 0, S = y ? v.groupValue.includes(f) : l, N = y && v.groupDisabled || d, j = y ? v.groupName ?? void 0 : u ?? void 0, [D, I] = C.useState(
    S !== void 0 ? S : i || !1
  );
  C.useEffect(() => {
    S !== void 0 && I(S);
  }, [S]);
  const P = (A) => {
    const O = A === !0;
    y || I(O), y && f !== void 0 ? v.onItemChange(f, O) : m && m(O);
  }, T = /* @__PURE__ */ a.jsxs("div", { className: "flex items-center space-x-2", children: [
    /* @__PURE__ */ a.jsx(
      vr,
      {
        id: h,
        name: j,
        value: f,
        checked: y ? v.groupValue.includes(f) : D,
        defaultChecked: y ? void 0 : i,
        disabled: N,
        onCheckedChange: P,
        className: b(
          "peer h-4 w-4 shrink-0 rounded-sm border ring-offset-background",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          "data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
          c ? "border-destructive" : "border-primary"
        ),
        children: /* @__PURE__ */ a.jsx(wr, { className: b("flex items-center justify-center text-current"), children: /* @__PURE__ */ a.jsx(At, { className: "h-4 w-4" }) })
      }
    ),
    n && /* @__PURE__ */ a.jsxs(
      "label",
      {
        htmlFor: h,
        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        children: [
          n,
          o && /* @__PURE__ */ a.jsx("span", { className: "text-destructive ml-1", children: "*" })
        ]
      }
    )
  ] });
  return s || c ? /* @__PURE__ */ a.jsxs("div", { className: b("space-y-1", t), style: r, "data-refast-id": p, children: [
    T,
    s && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground ml-6", children: s }),
    c && /* @__PURE__ */ a.jsx("p", { className: "text-xs text-destructive ml-6", children: c })
  ] }) : /* @__PURE__ */ a.jsx("div", { className: t, style: r, "data-refast-id": p, children: T });
}
function Uo({
  id: e,
  className: t,
  style: r,
  disabled: n = !1,
  value: s = "",
  label: o,
  description: c,
  required: l,
  error: i,
  children: d,
  "data-refast-id": u
}) {
  const f = e || `radio-${s}`;
  return /* @__PURE__ */ a.jsx("div", { className: b("space-y-1", t), style: r, "data-refast-id": u, children: d ? (
    // Complex option: wrap arbitrary children in the Radix item.
    // w-full h-full lets the item fill whatever size the outer div occupies,
    // so flex-1 / w-* / h-* on the Radio's class_name drives the final size.
    /* @__PURE__ */ a.jsx(
      Me,
      {
        id: f,
        value: s,
        disabled: n,
        className: b(
          "group block w-full h-full rounded-md border-2 border-muted bg-popover p-0 ring-offset-background",
          "hover:border-primary/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          "data-[state=checked]:border-primary",
          i && "border-destructive"
        ),
        children: d
      }
    )
  ) : (
    // Simple option: inline indicator + label
    /* @__PURE__ */ a.jsxs("div", { className: "flex items-start space-x-2", children: [
      /* @__PURE__ */ a.jsx(
        Me,
        {
          id: f,
          value: s,
          disabled: n,
          className: b(
            "mt-0.5 aspect-square h-4 w-4 rounded-full border border-primary text-primary ring-offset-background",
            "focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            i && "border-destructive"
          ),
          children: /* @__PURE__ */ a.jsx(Cr, { className: "flex items-center justify-center", children: /* @__PURE__ */ a.jsx(Pt, { className: "h-2.5 w-2.5 fill-current text-current" }) })
        }
      ),
      /* @__PURE__ */ a.jsxs("div", { className: "grid gap-0.5", children: [
        o && /* @__PURE__ */ a.jsxs(
          "label",
          {
            htmlFor: f,
            className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
            children: [
              o,
              l && /* @__PURE__ */ a.jsx("span", { className: "text-destructive ml-1", children: "*" })
            ]
          }
        ),
        c && !i && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: c }),
        i && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-destructive", children: i })
      ] })
    ] })
  ) });
}
function Ko({
  id: e,
  className: t,
  style: r,
  name: n,
  value: s,
  defaultValue: o,
  disabled: c = !1,
  orientation: l = "vertical",
  label: i,
  description: d,
  required: u,
  error: f,
  onValueChange: m,
  children: p,
  "data-refast-id": g
}) {
  const h = C.useId(), v = e || h, [y, S] = C.useState(s !== void 0 ? s : o || "");
  C.useEffect(() => {
    s !== void 0 && S(s);
  }, [s]), C.useEffect(() => Z.on("refast:force-value-sync", ({ targetId: j, value: D }) => {
    j === e && D !== void 0 && S(D);
  }), [e]);
  const N = (j) => {
    S(j), m && m(j);
  };
  return /* @__PURE__ */ a.jsxs("div", { className: b("space-y-1", t), style: r, "data-refast-id": g, children: [
    i && /* @__PURE__ */ a.jsxs("label", { className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", children: [
      i,
      u && /* @__PURE__ */ a.jsx("span", { className: "text-destructive ml-1", children: "*" })
    ] }),
    d && !f && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: d }),
    /* @__PURE__ */ a.jsx(
      kr,
      {
        className: b(
          "flex",
          l === "vertical" ? "flex-col space-y-2" : "flex-row space-x-4"
        ),
        value: y,
        defaultValue: o,
        disabled: c,
        name: n || void 0,
        onValueChange: N,
        orientation: l,
        id: v,
        children: p
      }
    ),
    f && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-destructive", children: f })
  ] });
}
function Vo({
  id: e,
  className: t,
  style: r,
  name: n,
  value: s,
  defaultValue: o,
  disabled: c = !1,
  orientation: l = "vertical",
  label: i,
  description: d,
  required: u,
  error: f,
  onChange: m,
  children: p,
  "data-refast-id": g
}) {
  const h = C.useId(), v = e || h, [y, S] = C.useState(
    s !== void 0 ? s : o || []
  );
  C.useEffect(() => {
    s !== void 0 && S(s);
  }, [s]);
  const N = C.useCallback((D, I) => {
    S((P) => {
      const T = I ? P.includes(D) ? P : [...P, D] : P.filter((A) => A !== D);
      return m && m(T), T;
    });
  }, [m]), j = C.useMemo(() => ({
    groupValue: y,
    onItemChange: N,
    groupName: n,
    groupDisabled: c
  }), [y, N, n, c]);
  return /* @__PURE__ */ a.jsx(Wt.Provider, { value: j, children: /* @__PURE__ */ a.jsxs(
    "div",
    {
      id: v,
      role: "group",
      className: b("space-y-1", t),
      style: r,
      "data-refast-id": g,
      children: [
        i && /* @__PURE__ */ a.jsxs("label", { className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", children: [
          i,
          u && /* @__PURE__ */ a.jsx("span", { className: "text-destructive ml-1", children: "*" })
        ] }),
        d && !f && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: d }),
        /* @__PURE__ */ a.jsx(
          "div",
          {
            className: b(
              "flex",
              l === "vertical" ? "flex-col space-y-2" : "flex-row space-x-4"
            ),
            children: p
          }
        ),
        f && /* @__PURE__ */ a.jsx("p", { className: "text-sm text-destructive", children: f })
      ]
    }
  ) });
}
function we(e) {
  if (e === 0) return "0 B";
  const t = 1024, r = ["B", "KB", "MB", "GB"], n = Math.floor(Math.log(e) / Math.log(t));
  return `${parseFloat((e / Math.pow(t, n)).toFixed(1))} ${r[n]}`;
}
function de(e) {
  return { name: e.name, size: e.size, type: e.type };
}
let Jo = 0;
function Xo() {
  return `fu-${++Jo}`;
}
function qo(e) {
  const t = document.cookie.match(new RegExp("(?:^|;\\s*)" + e + "=([^;]*)"));
  return t ? decodeURIComponent(t[1]) : null;
}
function Zo(e) {
  try {
    return new URL(e, window.location.origin).origin === window.location.origin;
  } catch {
    return !1;
  }
}
const Yo = ({ entry: e, onRemove: t }) => {
  const r = e.status === "complete", n = e.status === "error", s = e.status === "uploading";
  return /* @__PURE__ */ a.jsxs("div", { className: "flex items-center gap-3 rounded-md border border-border bg-muted/30 px-3 py-2 text-sm", children: [
    /* @__PURE__ */ a.jsx("span", { className: "flex-none text-muted-foreground", children: /* @__PURE__ */ a.jsx(Y, { name: "file", size: 16 }) }),
    /* @__PURE__ */ a.jsxs("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ a.jsx("p", { className: "truncate font-medium text-foreground", children: e.file.name }),
      /* @__PURE__ */ a.jsxs("div", { className: "mt-1 flex items-center gap-2", children: [
        /* @__PURE__ */ a.jsx("span", { className: "text-xs text-muted-foreground", children: we(e.file.size) }),
        s && /* @__PURE__ */ a.jsxs("div", { className: "flex flex-1 items-center gap-2", children: [
          /* @__PURE__ */ a.jsx("div", { className: "h-1.5 flex-1 overflow-hidden rounded-full bg-muted", children: /* @__PURE__ */ a.jsx(
            "div",
            {
              className: "h-full rounded-full bg-primary transition-all duration-150",
              style: { width: `${e.progress}%` }
            }
          ) }),
          /* @__PURE__ */ a.jsxs("span", { className: "text-xs text-muted-foreground", children: [
            e.progress,
            "%"
          ] })
        ] }),
        n && /* @__PURE__ */ a.jsx("span", { className: "text-xs text-destructive", children: e.error })
      ] })
    ] }),
    /* @__PURE__ */ a.jsxs("div", { className: "flex flex-none items-center gap-1", children: [
      r && /* @__PURE__ */ a.jsx("span", { className: "text-success", children: /* @__PURE__ */ a.jsx(Y, { name: "check-circle", size: 16 }) }),
      n && /* @__PURE__ */ a.jsx("span", { className: "text-destructive", children: /* @__PURE__ */ a.jsx(Y, { name: "x-circle", size: 16 }) }),
      s && /* @__PURE__ */ a.jsx("span", { className: "animate-spin text-primary", children: /* @__PURE__ */ a.jsx(Y, { name: "loader-2", size: 16 }) }),
      /* @__PURE__ */ a.jsx(
        "button",
        {
          type: "button",
          onClick: t,
          "aria-label": `Remove ${e.file.name}`,
          className: b(
            "ml-1 rounded p-0.5 text-muted-foreground transition-colors",
            "hover:bg-muted hover:text-foreground",
            "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          ),
          children: /* @__PURE__ */ a.jsx(Y, { name: "x", size: 14 })
        }
      )
    ] })
  ] });
}, Ut = ({
  label: e = "Upload file",
  description: t,
  variant: r = "dropzone",
  disabled: n = !1,
  required: s = !1,
  error: o,
  accept: c,
  multiple: l = !1,
  maxSize: i,
  maxFiles: d,
  dragDrop: u = !0,
  uploadUrl: f = "/api/upload",
  className: m,
  onSelect: p,
  onUploadStart: g,
  onUploadComplete: h,
  onUploadError: v,
  onRemove: y,
  "data-refast-id": S
}) => {
  const [N, j] = x.useState([]), [D, I] = x.useState(!1), [P, T] = x.useState(null), A = x.useRef(null), O = x.useCallback(
    (R, Q = 0) => {
      const U = [];
      let B = R;
      if (d !== void 0) {
        const X = d - Q;
        if (X <= 0)
          return U.push(`Maximum ${d} file${d !== 1 ? "s" : ""} allowed.`), { valid: [], errors: U };
        R.length > X && (U.push(`Maximum ${d} file${d !== 1 ? "s" : ""} allowed.`), B = R.slice(0, X));
      }
      if (i !== void 0) {
        const X = B.filter((ee) => ee.size > i);
        X.length > 0 && (U.push(
          `${X.map((ee) => ee.name).join(", ")} exceed${X.length === 1 ? "s" : ""} the ${we(i)} size limit.`
        ), B = B.filter((ee) => ee.size <= i));
      }
      return { valid: B, errors: U };
    },
    [d, i]
  ), $ = x.useCallback(
    (R) => new Promise((Q, U) => {
      const B = new XMLHttpRequest(), X = new FormData();
      X.append("files", R.file), B.upload.onprogress = (K) => {
        if (K.lengthComputable) {
          const J = Math.round(K.loaded / K.total * 100);
          j(
            (W) => W.map((q) => q.localId === R.localId ? { ...q, progress: J } : q)
          );
        }
      }, B.onload = () => {
        if (B.status >= 200 && B.status < 300)
          try {
            const K = JSON.parse(B.responseText);
            if (!Array.isArray(K.files) || K.files.length === 0)
              throw new Error("Empty files array in server response");
            const J = K.files[0];
            j(
              (W) => W.map(
                (q) => q.localId === R.localId ? { ...q, status: "complete", progress: 100, uploadedInfo: J } : q
              )
            ), Q(J);
          } catch {
            const K = "Invalid server response";
            j(
              (J) => J.map(
                (W) => W.localId === R.localId ? { ...W, status: "error", error: K } : W
              )
            ), U(new Error(K));
          }
        else {
          let K = `Upload failed (${B.status})`;
          try {
            const J = JSON.parse(B.responseText);
            J.error && (K = J.error);
          } catch {
          }
          j(
            (J) => J.map(
              (W) => W.localId === R.localId ? { ...W, status: "error", error: K } : W
            )
          ), U(new Error(K));
        }
      }, B.onerror = () => {
        const K = "Network error during upload";
        j(
          (J) => J.map(
            (W) => W.localId === R.localId ? { ...W, status: "error", error: K } : W
          )
        ), U(new Error(K));
      }, B.open("POST", f);
      const ee = qo("csrf_token");
      ee && B.setRequestHeader("X-CSRF-Token", ee), B.send(X);
    }),
    [f]
  ), k = x.useCallback(
    async (R) => {
      if (n) return;
      if (T(null), !Zo(f)) {
        T("Upload URL is not allowed.");
        return;
      }
      const Q = Array.from(R), { valid: U, errors: B } = O(Q, N.length);
      if (B.length > 0 && (T(B.join(" ")), U.length === 0))
        return;
      const X = U.map((W) => ({
        localId: Xo(),
        file: W,
        status: "pending",
        progress: 0
      })), ee = l ? [...N, ...X] : X;
      if (j(ee), p == null || p({ files: U.map(de) }), U.length === 0) return;
      const K = X.map((W) => ({ ...W, status: "uploading" }));
      j((W) => {
        const q = new Set(K.map((te) => te.localId));
        return W.map((te) => q.has(te.localId) ? { ...te, status: "uploading" } : te);
      }), g == null || g({ files: U.map(de) });
      const J = [];
      for (const W of K)
        try {
          const q = await $(W);
          J.push(q);
        } catch (q) {
          const te = q instanceof Error ? q.message : "Upload failed";
          v == null || v({
            error: te,
            file: de(W.file)
          });
        }
      J.length > 0 && (h == null || h({ files: J }));
    },
    [n, N, l, O, $, p, g, h, v]
  ), L = x.useCallback(
    (R) => {
      j((Q) => Q.filter((U) => U.localId !== R.localId)), y == null || y({ file: de(R.file) });
    },
    [y]
  ), H = x.useCallback(
    (R) => {
      !u || n || (R.preventDefault(), R.stopPropagation(), I(!0));
    },
    [u, n]
  ), M = x.useCallback((R) => {
    R.preventDefault(), R.stopPropagation(), I(!1);
  }, []), E = x.useCallback(
    (R) => {
      R.preventDefault(), R.stopPropagation(), I(!1), !(!u || n) && R.dataTransfer.files.length > 0 && k(R.dataTransfer.files);
    },
    [u, n, k]
  ), _ = x.useCallback(() => {
    var R;
    n || (R = A.current) == null || R.click();
  }, [n]), z = x.useCallback(
    (R) => {
      R.target.files && R.target.files.length > 0 && (k(R.target.files), R.target.value = "");
    },
    [k]
  ), F = P ?? o;
  return /* @__PURE__ */ a.jsxs("div", { className: b("flex flex-col gap-2", m), "data-refast-id": S, children: [
    /* @__PURE__ */ a.jsx(
      "input",
      {
        ref: A,
        type: "file",
        accept: c,
        multiple: l,
        disabled: n,
        required: s,
        className: "sr-only",
        "aria-hidden": "true",
        onChange: z
      }
    ),
    r === "button" && s && /* @__PURE__ */ a.jsxs("span", { className: "text-xs text-muted-foreground", children: [
      "Required ",
      /* @__PURE__ */ a.jsx("span", { className: "text-destructive", children: "*" })
    ] }),
    r === "dropzone" ? /* @__PURE__ */ a.jsxs(
      "div",
      {
        role: "button",
        tabIndex: n ? -1 : 0,
        "aria-disabled": n,
        onKeyDown: (R) => {
          (R.key === "Enter" || R.key === " ") && (R.preventDefault(), _());
        },
        onClick: _,
        onDragOver: H,
        onDragLeave: M,
        onDrop: E,
        className: b(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-6 py-10 text-center transition-colors",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          D && !n ? "border-primary bg-primary/5" : "border-border bg-muted/20 hover:border-primary/50 hover:bg-muted/40",
          n && "cursor-not-allowed opacity-50",
          F && "border-destructive"
        ),
        children: [
          /* @__PURE__ */ a.jsx("span", { className: b("text-muted-foreground", D && "text-primary"), children: /* @__PURE__ */ a.jsx(Y, { name: D ? "download" : "upload-cloud", size: 32 }) }),
          /* @__PURE__ */ a.jsxs("div", { children: [
            /* @__PURE__ */ a.jsxs("p", { className: "font-medium text-foreground", children: [
              e,
              s && /* @__PURE__ */ a.jsx("span", { className: "ml-1 text-destructive", children: "*" })
            ] }),
            t && /* @__PURE__ */ a.jsx("p", { className: "mt-0.5 text-sm text-muted-foreground", children: t }),
            u && /* @__PURE__ */ a.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Drag & drop or click to browse" })
          ] }),
          (c || i || d) && /* @__PURE__ */ a.jsx("p", { className: "text-xs text-muted-foreground/70", children: [
            c && `Accepts: ${c}`,
            i && `Max size: ${we(i)}`,
            d && `Max files: ${d}`
          ].filter(Boolean).join(" · ") })
        ]
      }
    ) : /* @__PURE__ */ a.jsxs(
      "button",
      {
        type: "button",
        disabled: n,
        onClick: _,
        onDragOver: H,
        onDragLeave: M,
        onDrop: E,
        className: b(
          "inline-flex items-center gap-2 rounded-md border border-input bg-background px-4 py-2 text-sm font-medium transition-colors",
          "hover:bg-accent hover:text-accent-foreground",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:pointer-events-none disabled:opacity-50",
          D && "border-primary bg-primary/5",
          F && "border-destructive"
        ),
        children: [
          /* @__PURE__ */ a.jsx(Y, { name: "upload", size: 16 }),
          /* @__PURE__ */ a.jsxs("span", { children: [
            e,
            s && /* @__PURE__ */ a.jsx("span", { className: "ml-1 text-destructive", children: "*" })
          ] })
        ]
      }
    ),
    N.length > 0 && /* @__PURE__ */ a.jsx("div", { className: "flex flex-col gap-1.5", children: N.map((R) => /* @__PURE__ */ a.jsx(
      Yo,
      {
        entry: R,
        onRemove: () => L(R)
      },
      R.localId
    )) }),
    F && /* @__PURE__ */ a.jsxs("p", { role: "alert", className: "flex items-center gap-1 text-sm text-destructive", children: [
      /* @__PURE__ */ a.jsx(Y, { name: "alert-circle", size: 14 }),
      F
    ] })
  ] });
};
Ut.displayName = "FileUploader";
function Qo({
  id: e,
  className: t,
  onSubmit: r,
  children: n,
  "data-refast-id": s,
  ...o
}) {
  const c = (l) => {
    if (l.preventDefault(), r) {
      const i = new FormData(l.currentTarget), d = {};
      i.forEach((u, f) => {
        d[f] = u.toString();
      }), r(d);
    }
  };
  return /* @__PURE__ */ a.jsx(
    "form",
    {
      id: e,
      className: b("space-y-4", t),
      onSubmit: c,
      "data-refast-id": s,
      ...o,
      children: n
    }
  );
}
function ei({
  id: e,
  className: t,
  label: r,
  hint: n,
  error: s,
  required: o = !1,
  children: c,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ a.jsxs("div", { id: e, className: b("space-y-1", t), "data-refast-id": l, children: [
    r && /* @__PURE__ */ a.jsxs("label", { className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", children: [
      r,
      o && /* @__PURE__ */ a.jsx("span", { className: "ml-1 text-destructive", children: "*" })
    ] }),
    n && /* @__PURE__ */ a.jsx("p", { className: "text-xs text-muted-foreground", children: n }),
    c,
    s && /* @__PURE__ */ a.jsx("p", { className: "text-xs text-destructive", children: s })
  ] });
}
function ti({
  id: e,
  name: t,
  fallback: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx("div", { id: e, "data-slot-name": t, "data-refast-id": s, children: n || r || null });
}
function Kt() {
  const [e, t] = C.useState(() => typeof document < "u" && document.documentElement.classList.contains("dark") ? "dark" : "light");
  return C.useEffect(() => {
    if (typeof document > "u") return;
    const r = document.documentElement.classList.contains("dark");
    (r && e === "light" || !r && e === "dark") && t(r ? "dark" : "light");
    const n = new MutationObserver((s) => {
      for (const o of s)
        if (o.type === "attributes" && o.attributeName === "class") {
          const c = document.documentElement.classList.contains("dark");
          t(c ? "dark" : "light");
        }
    });
    return n.observe(document.documentElement, {
      attributes: !0,
      attributeFilter: ["class"]
    }), () => n.disconnect();
  }, []), e;
}
function Vt({
  id: e,
  className: t,
  level: r = 1,
  children: n,
  style: s,
  "data-refast-id": o
}) {
  const c = {
    1: "scroll-m-20 text-4xl font-bold tracking-tight",
    2: "scroll-m-20 text-3xl font-semibold tracking-tight",
    3: "scroll-m-20 text-2xl font-semibold tracking-tight",
    4: "scroll-m-20 text-xl font-semibold tracking-tight",
    5: "scroll-m-20 text-lg font-semibold tracking-tight",
    6: "scroll-m-20 text-base font-semibold tracking-tight"
  }, l = `h${r}`;
  return /* @__PURE__ */ a.jsx(
    l,
    {
      id: e,
      className: b(c[r], t),
      style: s,
      "data-refast-id": o,
      children: n
    }
  );
}
function Jt({
  id: e,
  className: t,
  lead: r = !1,
  muted: n = !1,
  children: s,
  style: o,
  "data-refast-id": c
}) {
  return /* @__PURE__ */ a.jsx(
    "p",
    {
      id: e,
      className: b(
        "leading-7",
        r && "text-xl text-muted-foreground",
        n && "text-sm text-muted-foreground",
        !r && !n && "[&:not(:first-child)]:mt-6",
        t
      ),
      style: o,
      "data-refast-id": c,
      children: s
    }
  );
}
function Xt({
  id: e,
  className: t,
  href: r = "#",
  target: n = "_self",
  external: s = !1,
  onClick: o,
  children: c,
  style: l,
  "data-refast-id": i
}) {
  return /* @__PURE__ */ a.jsxs(
    "a",
    {
      id: e,
      href: r,
      target: s ? "_blank" : n,
      rel: s ? "noopener noreferrer" : void 0,
      onClick: o,
      className: b(
        "font-medium text-primary px-2 hover:bg-accent",
        t
      ),
      style: l,
      "data-refast-id": i,
      children: [
        c,
        s && /* @__PURE__ */ a.jsx(_t, { className: "inline-block ml-1 align-middle", size: 12 })
      ]
    }
  );
}
function qt({
  id: e,
  className: t,
  inline: r = !0,
  showLineNumbers: n = !1,
  language: s,
  code: o,
  children: c,
  style: l,
  "data-refast-id": i
}) {
  const d = Kt(), [u, f] = C.useState(null), [m, p] = C.useState(null), g = C.useMemo(() => {
    if (o) return o;
    const v = (y) => typeof y == "string" ? y : typeof y == "number" ? String(y) : y ? Array.isArray(y) ? y.map(v).join("") : C.isValidElement(y) ? v(y.props.children) : "" : "";
    return v(c);
  }, [c, o]);
  C.useEffect(() => {
    r || (async () => {
      try {
        const [y, S, N] = await Promise.all([
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.p),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.o),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.a)
        ]), j = y.default, [D, I, P, T, A, O, $, k, L, H, M] = await Promise.all([
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.j),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.t),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.b),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.c),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.d),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.e),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.f),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.g),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.s),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.y),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.m)
        ]);
        j.registerLanguage("javascript", D.default), j.registerLanguage("js", D.default), j.registerLanguage("typescript", I.default), j.registerLanguage("ts", I.default), j.registerLanguage("python", P.default), j.registerLanguage("py", P.default), j.registerLanguage("bash", T.default), j.registerLanguage("shell", T.default), j.registerLanguage("sh", T.default), j.registerLanguage("json", A.default), j.registerLanguage("css", O.default), j.registerLanguage("jsx", $.default), j.registerLanguage("tsx", k.default), j.registerLanguage("sql", L.default), j.registerLanguage("yaml", H.default), j.registerLanguage("yml", H.default), j.registerLanguage("markdown", M.default), j.registerLanguage("md", M.default), f(() => j), p({
          light: N.default,
          dark: S.default
        });
      } catch (y) {
        console.error("Failed to load syntax highlighter:", y);
      }
    })();
  }, [r]);
  const h = m ? m[d] : null;
  return r ? /* @__PURE__ */ a.jsx(
    "code",
    {
      id: e,
      className: b(
        "relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm font-semibold",
        t
      ),
      style: l,
      "data-refast-id": i,
      "data-language": s,
      children: g
    }
  ) : u && h ? /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("mb-4 mt-6 overflow-x-auto rounded-lg border", t),
      style: l,
      "data-refast-id": i,
      "data-language": s,
      children: /* @__PURE__ */ a.jsx(
        u,
        {
          language: s || "text",
          style: h,
          customStyle: {
            margin: 0,
            borderRadius: "0.5rem",
            fontSize: "0.875rem"
          },
          showLineNumbers: n,
          children: g
        }
      )
    }
  ) : /* @__PURE__ */ a.jsx(
    "pre",
    {
      id: e,
      className: b(
        "mb-4 mt-6 overflow-x-auto rounded-lg border py-4",
        d === "dark" ? "bg-zinc-950 text-white" : "bg-zinc-100 text-zinc-900",
        t
      ),
      "data-refast-id": i,
      "data-language": s,
      style: l,
      children: /* @__PURE__ */ a.jsx("code", { className: "relative rounded bg-transparent px-4 py-[0.2rem] font-mono text-sm text-inherit", children: g })
    }
  );
}
function Zt({
  id: e,
  className: t,
  style: r,
  cite: n,
  children: s,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ a.jsx(
    "blockquote",
    {
      id: e,
      cite: n,
      className: b(
        "mt-6 border-l-2 pl-6 italic text-muted-foreground",
        t
      ),
      style: r,
      "data-refast-id": o,
      children: s
    }
  );
}
function Yt({
  id: e,
  className: t,
  style: r,
  ordered: n = !1,
  children: s,
  "data-refast-id": o
}) {
  const c = n ? "ol" : "ul", l = C.Children.map(s, (i) => {
    var d, u;
    return C.isValidElement(i) && (i.type === "li" || (u = (d = i.props) == null ? void 0 : d.className) != null && u.includes("list-item")) ? i : /* @__PURE__ */ a.jsx("li", { children: i });
  });
  return /* @__PURE__ */ a.jsx(
    c,
    {
      id: e,
      className: b(
        "my-6 ml-6",
        n ? "list-decimal" : "list-disc",
        "[&>li]:mt-2",
        t
      ),
      style: r,
      "data-refast-id": o,
      children: l
    }
  );
}
function Qt({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx("li", { id: e, className: b("", t), "data-refast-id": s, style: r, children: n });
}
function er({
  id: e,
  className: t,
  htmlFor: r,
  required: n = !1,
  children: s,
  style: o,
  "data-refast-id": c
}) {
  return /* @__PURE__ */ a.jsxs(
    "label",
    {
      id: e,
      htmlFor: r,
      className: b(
        "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        t
      ),
      style: o,
      "data-refast-id": c,
      children: [
        s,
        n && /* @__PURE__ */ a.jsx("span", { className: "ml-1 text-destructive", children: "*" })
      ]
    }
  );
}
function ri({ code: e, theme: t }) {
  const [r, n] = C.useState(""), [s, o] = C.useState(""), [c, l] = C.useState(!0);
  return C.useEffect(() => {
    let i = !1;
    return (async () => {
      try {
        const f = (await import("./refast-mermaid-CT9_HlOM.js")).default;
        f.initialize({
          startOnLoad: !1,
          theme: t === "dark" ? "dark" : "default"
        });
        const m = `mermaid-${Math.random().toString(36).slice(2)}`, { svg: p } = await f.render(m, e);
        i || (n(p), l(!1));
      } catch (u) {
        i || (o(u instanceof Error ? u.message : "Failed to render diagram"), l(!1));
      }
    })(), () => {
      i = !0;
    };
  }, [e, t]), c ? /* @__PURE__ */ a.jsx("div", { className: "flex items-center justify-center p-8 text-muted-foreground text-sm", children: "Loading diagram…" }) : s ? /* @__PURE__ */ a.jsx("div", { className: "rounded border border-destructive p-4 text-destructive text-sm font-mono whitespace-pre-wrap", children: s }) : /* @__PURE__ */ a.jsx(
    "div",
    {
      className: "flex justify-center overflow-auto py-4",
      dangerouslySetInnerHTML: { __html: r }
    }
  );
}
function ni({
  id: e,
  className: t,
  style: r,
  content: n,
  allowHtml: s = !1,
  enableMermaid: o = !1,
  enableLatex: c = !1,
  "data-refast-id": l
}) {
  const i = Kt(), [d, u] = C.useState(null), [f, m] = C.useState(null), [p, g] = C.useState(null), [h, v] = C.useState(null), [y, S] = C.useState(null), [N, j] = C.useState(null), [D, I] = C.useState(null);
  C.useEffect(() => {
    (async () => {
      try {
        const [L, H, M] = await Promise.all([
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.i),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.h),
          import("./refast-markdown-vx_gCmJn.js").then((E) => E.k)
        ]);
        u(() => L.default), m(() => H.default), g(() => M.default);
        try {
          const [E, _, z] = await Promise.all([
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.p),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.o),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.a)
          ]), F = E.default, [R, Q, U, B, X, ee, K, J, W, q, te] = await Promise.all([
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.j),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.t),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.b),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.c),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.d),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.e),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.f),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.g),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.s),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.y),
            import("./refast-markdown-vx_gCmJn.js").then((G) => G.m)
          ]);
          F.registerLanguage("javascript", R.default), F.registerLanguage("js", R.default), F.registerLanguage("typescript", Q.default), F.registerLanguage("ts", Q.default), F.registerLanguage("python", U.default), F.registerLanguage("py", U.default), F.registerLanguage("bash", B.default), F.registerLanguage("shell", B.default), F.registerLanguage("sh", B.default), F.registerLanguage("json", X.default), F.registerLanguage("css", ee.default), F.registerLanguage("jsx", K.default), F.registerLanguage("tsx", J.default), F.registerLanguage("sql", W.default), F.registerLanguage("yaml", q.default), F.registerLanguage("yml", q.default), F.registerLanguage("markdown", te.default), F.registerLanguage("md", te.default), v(() => F), S({
            light: z.default,
            dark: _.default
          });
        } catch (E) {
          console.error("Failed to load syntax highlighter:", E);
        }
        if (c)
          try {
            const { remarkMath: E, rehypeKatex: _ } = await import("./refast-katex-loader-DsxdzQFu.js");
            j(() => E), I(() => _);
          } catch (E) {
            console.error("Failed to load LaTeX plugins:", E);
          }
      } catch (L) {
        console.error("Failed to load markdown libraries:", L);
      }
    })();
  }, [c]);
  const P = C.useMemo(() => ({
    // Headers
    h1: ({ children: k }) => /* @__PURE__ */ a.jsx("h1", { className: "scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl mb-4", children: k }),
    h2: ({ children: k }) => /* @__PURE__ */ a.jsx("h2", { className: "scroll-m-20 border-b pb-2 text-3xl font-semibold tracking-tight first:mt-0 mt-8 mb-4", children: k }),
    h3: ({ children: k }) => /* @__PURE__ */ a.jsx("h3", { className: "scroll-m-20 text-2xl font-semibold tracking-tight mt-6 mb-3", children: k }),
    h4: ({ children: k }) => /* @__PURE__ */ a.jsx("h4", { className: "scroll-m-20 text-xl font-semibold tracking-tight mt-4 mb-2", children: k }),
    // Paragraph
    p: ({ children: k }) => /* @__PURE__ */ a.jsx("p", { className: "leading-7 [&:not(:first-child)]:mt-4", children: k }),
    // Lists
    ul: ({ children: k }) => /* @__PURE__ */ a.jsx("ul", { className: "my-4 ml-6 list-disc [&>li]:mt-2", children: k }),
    ol: ({ children: k }) => /* @__PURE__ */ a.jsx("ol", { className: "my-4 ml-6 list-decimal [&>li]:mt-2", children: k }),
    // Blockquote
    blockquote: ({ children: k }) => /* @__PURE__ */ a.jsx("blockquote", { className: "mt-6 border-l-2 pl-6 italic text-muted-foreground", children: k }),
    // Code with syntax highlighting
    code: ({ className: k, children: L }) => {
      if (!k && !String(L).endsWith(`
`))
        return /* @__PURE__ */ a.jsx("code", { className: "relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm font-semibold", children: L });
      const M = /language-(\w+)/.exec(k || ""), E = M ? M[1] : "text", _ = String(L).replace(/\n$/, "");
      if (o && E === "mermaid")
        return /* @__PURE__ */ a.jsx(ri, { code: _, theme: i });
      const z = y ? y[i] : null;
      return h && z ? /* @__PURE__ */ a.jsx(
        h,
        {
          language: E,
          style: z,
          customStyle: {
            margin: 0,
            borderRadius: "0.5rem",
            fontSize: "0.875rem"
          },
          showLineNumbers: !1,
          children: _
        }
      ) : /* @__PURE__ */ a.jsx("code", { className: "relative rounded bg-transparent font-mono text-sm", children: L });
    },
    pre: ({ children: k }) => {
      const L = y ? y[i] : null;
      return h && L ? /* @__PURE__ */ a.jsx("div", { className: "mb-4 mt-6 overflow-x-auto rounded-lg border", children: k }) : /* @__PURE__ */ a.jsx("pre", { className: b(
        "mb-4 mt-6 overflow-x-auto rounded-lg border py-4 px-4",
        i === "dark" ? "bg-zinc-950 text-white" : "bg-zinc-100 text-zinc-900"
      ), children: k });
    },
    // Links
    a: ({ href: k, children: L }) => /* @__PURE__ */ a.jsx(
      "a",
      {
        href: k,
        className: "font-medium text-primary underline underline-offset-4 hover:no-underline",
        target: k != null && k.startsWith("http") ? "_blank" : void 0,
        rel: k != null && k.startsWith("http") ? "noopener noreferrer" : void 0,
        children: L
      }
    ),
    // Table
    table: ({ children: k }) => /* @__PURE__ */ a.jsx("div", { className: "my-6 w-full overflow-y-auto", children: /* @__PURE__ */ a.jsx("table", { className: "w-full", children: k }) }),
    th: ({ children: k }) => /* @__PURE__ */ a.jsx("th", { className: "border px-4 py-2 text-left font-bold [&[align=center]]:text-center [&[align=right]]:text-right", children: k }),
    td: ({ children: k }) => /* @__PURE__ */ a.jsx("td", { className: "border px-4 py-2 text-left [&[align=center]]:text-center [&[align=right]]:text-right", children: k }),
    // Horizontal rule
    hr: () => /* @__PURE__ */ a.jsx("hr", { className: "my-6 border-muted" })
  }), [i, h, y, o]);
  if (!d)
    return /* @__PURE__ */ a.jsx(
      "div",
      {
        id: e,
        className: b("prose prose-sm dark:prose-invert max-w-none", t),
        style: r,
        "data-refast-id": l,
        children: /* @__PURE__ */ a.jsx("pre", { className: "whitespace-pre-wrap text-sm", children: n })
      }
    );
  const T = [];
  f && T.push(f), c && N && T.push(N);
  const A = [];
  s && p && A.push(p), c && D && A.push(D);
  const $ = `${i}-${!!(h && y) && (!c || !!(N && D))}`;
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("prose prose-sm dark:prose-invert max-w-none", t),
      style: r,
      "data-refast-id": l,
      children: /* @__PURE__ */ a.jsx(
        d,
        {
          remarkPlugins: T,
          rehypePlugins: A.length > 0 ? A : void 0,
          components: P,
          children: n
        }
      )
    },
    $
  );
}
function tr({
  id: e,
  className: t,
  style: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    "kbd",
    {
      id: e,
      className: b(
        "pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground",
        t
      ),
      style: r,
      "data-refast-id": s,
      children: n
    }
  );
}
const ai = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  BlockQuote: Zt,
  Code: qt,
  Heading: Vt,
  Kbd: tr,
  Label: er,
  Link: Xt,
  List: Yt,
  ListItem: Qt,
  Markdown: ni,
  Paragraph: Jt
}, Symbol.toStringTag, { value: "Module" }));
function si({
  id: e,
  className: t,
  variant: r = "default",
  title: n,
  message: s,
  children: o,
  dismissible: c,
  onDismiss: l,
  "data-refast-id": i
}) {
  const [d, u] = x.useState(!0);
  if (!d)
    return null;
  const f = {
    default: "bg-background text-foreground",
    destructive: "bg-destructive text-destructive-foreground [&>svg]:text-destructive-foreground",
    success: "bg-success text-success-foreground [&>svg]:text-success-foreground",
    warning: "bg-warning text-warning-foreground [&>svg]:text-warning-foreground",
    info: "bg-info text-info-foreground [&>svg]:text-info-foreground"
  }, m = (p) => {
    p.stopPropagation(), u(!1), l == null || l();
  };
  return /* @__PURE__ */ a.jsxs(
    "div",
    {
      id: e,
      role: "alert",
      className: b(
        "relative w-full rounded-lg border p-4",
        "[&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px]",
        "[&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",
        f[r],
        t
      ),
      "data-refast-id": i,
      children: [
        c && /* @__PURE__ */ a.jsxs(
          "button",
          {
            onClick: m,
            className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
            children: [
              /* @__PURE__ */ a.jsx(Dt, { className: "h-4 w-4" }),
              /* @__PURE__ */ a.jsx("span", { className: "sr-only", children: "Close" })
            ]
          }
        ),
        n && /* @__PURE__ */ a.jsx(rr, { children: n }),
        s && /* @__PURE__ */ a.jsx(nr, { children: s }),
        o
      ]
    }
  );
}
function rr({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx(
    "h5",
    {
      id: e,
      className: b("mb-1 font-medium leading-none tracking-tight", t),
      "data-refast-id": n,
      children: r
    }
  );
}
function nr({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("text-sm [&_p]:leading-relaxed", t),
      "data-refast-id": n,
      children: r
    }
  );
}
function oi({
  id: e,
  className: t,
  variant: r = "default",
  children: n,
  "data-refast-id": s
}) {
  const o = {
    default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
    secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
    outline: "text-foreground",
    success: "border-transparent bg-green-500 text-white hover:bg-green-600",
    warning: "border-transparent bg-yellow-500 text-white hover:bg-yellow-600"
  };
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors",
        "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        o[r],
        t
      ),
      "data-refast-id": s,
      children: n
    }
  );
}
const ii = ["primary", "secondary", "destructive", "muted", "accent", "popover", "card", "background", "foreground"];
function li({
  id: e,
  className: t,
  value: r = 0,
  max: n = 100,
  label: s,
  showValue: o = !1,
  foregroundColor: c,
  trackColor: l,
  striped: i,
  "data-refast-id": d
}) {
  const u = Math.min(100, Math.max(0, r / n * 100)), f = (v, y) => v ? ii.includes(v) ? { className: `bg-${v}`, style: {} } : { className: "", style: { backgroundColor: v } } : { className: y, style: {} }, m = f(l, "bg-secondary"), p = f(c, "bg-primary"), g = i ? {
    backgroundImage: "linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)",
    backgroundSize: "1rem 1rem"
  } : {}, h = i === "animated" ? "animate-stripes" : "";
  return /* @__PURE__ */ a.jsxs("div", { className: b("relative", t), "data-refast-id": d, children: [
    s && /* @__PURE__ */ a.jsx("div", { className: "mb-1 text-sm font-medium", children: s }),
    /* @__PURE__ */ a.jsx(
      "div",
      {
        id: e,
        role: "progressbar",
        "aria-valuenow": r,
        "aria-valuemin": 0,
        "aria-valuemax": n,
        className: b("relative h-4 w-full overflow-hidden rounded-full", m.className),
        style: m.style,
        children: /* @__PURE__ */ a.jsx(
          "div",
          {
            className: b("h-full transition-all flex-1", p.className, h),
            style: { width: `${u}%`, ...p.style, ...g }
          }
        )
      }
    ),
    o && /* @__PURE__ */ a.jsxs("span", { className: "absolute right-0 top-0 -mt-6 text-sm text-muted-foreground", children: [
      Math.round(u),
      "%"
    ] })
  ] });
}
function ci({
  id: e,
  className: t,
  size: r = "md",
  "data-refast-id": n
}) {
  const s = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8"
  };
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(
        "animate-spin rounded-full border-2 border-current border-t-transparent text-primary",
        s[r],
        t
      ),
      role: "status",
      "aria-label": "Loading",
      "data-refast-id": n,
      children: /* @__PURE__ */ a.jsx("span", { className: "sr-only", children: "Loading..." })
    }
  );
}
function di({
  id: e,
  className: t,
  width: r,
  height: n,
  variant: s = "text",
  circle: o = !1,
  "data-refast-id": c
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(
        "animate-pulse bg-muted",
        o || s === "circular" ? "rounded-full" : "rounded-md",
        t
      ),
      style: {
        width: typeof r == "number" ? `${r}px` : r,
        height: typeof n == "number" ? `${n}px` : n
      },
      "data-refast-id": c
    }
  );
}
function ui({
  id: e,
  className: t,
  childrenConnected: r = [],
  childrenDisconnected: n = [],
  position: s = "bottom-right",
  onDisconnect: o,
  onReconnect: c,
  jsOnDisconnect: l,
  jsOnReconnect: i,
  debounceMs: d = 500,
  "data-refast-id": u
}) {
  const [f, m] = x.useState(!0), [p, g] = x.useState(!1), [h, v] = x.useState(0), y = x.useRef(null), S = x.useRef(null);
  x.useEffect(() => {
    const I = document.querySelector(".refast-app");
    if (!I) return;
    const P = () => {
      if (l != null && l.jsFunction)
        try {
          new Function("args", "event", l.jsFunction)(l.boundArgs || {}, { type: "disconnect" });
        } catch ($) {
          console.error("[ConnectionStatus] Error executing jsOnDisconnect:", $);
        }
      o != null && o.callbackId && Z.emit("refast:callback", {
        callbackId: o.callbackId,
        data: { ...o.boundArgs || {}, event_type: "disconnect" }
      });
    }, T = () => {
      if (i != null && i.jsFunction)
        try {
          new Function("args", "event", i.jsFunction)(i.boundArgs || {}, { type: "reconnect" });
        } catch ($) {
          console.error("[ConnectionStatus] Error executing jsOnReconnect:", $);
        }
      c != null && c.callbackId && Z.emit("refast:callback", {
        callbackId: c.callbackId,
        data: { ...c.boundArgs || {}, event_type: "reconnect" }
      });
    }, A = () => {
      const $ = I.getAttribute("data-connected") === "true", k = I.getAttribute("data-connecting") === "true", L = parseInt(I.getAttribute("data-reconnect-attempts") || "0", 10);
      m($), g(k), v(L), S.current !== null && S.current !== $ && (y.current && clearTimeout(y.current), y.current = setTimeout(() => {
        $ ? T() : P();
      }, d)), S.current = $;
    };
    A();
    const O = new MutationObserver(($) => {
      for (const k of $)
        if (k.type === "attributes" && (k.attributeName === "data-connected" || k.attributeName === "data-connecting" || k.attributeName === "data-reconnect-attempts")) {
          A();
          break;
        }
    });
    return O.observe(I, { attributes: !0 }), () => {
      O.disconnect(), y.current && clearTimeout(y.current);
    };
  }, [d, l, i, o, c]);
  const N = f ? r : n, j = N && N.length > 0, D = {
    "top-left": "fixed top-4 left-4 z-50",
    "top-right": "fixed top-4 right-4 z-50",
    "bottom-left": "fixed bottom-4 left-4 z-50",
    "bottom-right": "fixed bottom-4 right-4 z-50",
    inline: ""
  };
  return j ? /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(D[s], t),
      "data-refast-id": u,
      "data-connected": f,
      "data-connecting": p,
      "data-reconnect-attempts": h,
      children: N.map((I, P) => /* @__PURE__ */ a.jsx(se, { tree: I }, I.id || P))
    }
  ) : !f && n.length === 0 ? /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(D[s], t),
      "data-refast-id": u,
      "data-connected": f,
      "data-connecting": p,
      "data-reconnect-attempts": h,
      children: /* @__PURE__ */ a.jsx(
        "div",
        {
          className: b(
            "flex items-center gap-2 rounded-lg px-3 py-2 shadow-lg",
            p ? "bg-yellow-500 text-white" : "bg-destructive text-destructive-foreground"
          ),
          children: p ? /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
            /* @__PURE__ */ a.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" }),
            /* @__PURE__ */ a.jsxs("span", { children: [
              "Reconnecting... (",
              h,
              ")"
            ] })
          ] }) : /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
            /* @__PURE__ */ a.jsx("div", { className: "h-2 w-2 rounded-full bg-white animate-pulse" }),
            /* @__PURE__ */ a.jsx("span", { children: "Connection lost" })
          ] })
        }
      )
    }
  ) : null;
}
function fi({
  id: e,
  className: t,
  type: r = "single",
  collapsible: n = !0,
  defaultValue: s,
  value: o,
  onValueChange: c,
  children: l,
  "data-refast-id": i
}) {
  return r === "single" ? /* @__PURE__ */ a.jsx(
    Ee,
    {
      id: e,
      type: "single",
      collapsible: n,
      defaultValue: s,
      value: o,
      onValueChange: c,
      className: b("w-full", t),
      "data-refast-id": i,
      children: l
    }
  ) : /* @__PURE__ */ a.jsx(
    Ee,
    {
      id: e,
      type: "multiple",
      defaultValue: s,
      value: o,
      onValueChange: c,
      className: b("w-full", t),
      "data-refast-id": i,
      children: l
    }
  );
}
function pi({
  id: e,
  className: t,
  value: r,
  children: n,
  "data-refast-id": s
}) {
  return /* @__PURE__ */ a.jsx(
    Rr,
    {
      id: e,
      value: r,
      className: b("border-b", t),
      "data-refast-id": s,
      children: n
    }
  );
}
const ar = C.forwardRef(({ id: e, className: t, children: r, "data-refast-id": n }, s) => /* @__PURE__ */ a.jsx(jr, { className: "flex", children: /* @__PURE__ */ a.jsxs(
  Sr,
  {
    ref: s,
    id: e,
    className: b(
      "flex flex-1 items-center justify-between py-4 font-medium transition-all hover:underline [&[data-state=open]>svg]:rotate-180",
      t
    ),
    "data-refast-id": n,
    children: [
      r,
      /* @__PURE__ */ a.jsx(zt, { className: "h-4 w-4 shrink-0 transition-transform duration-200" })
    ]
  }
) }));
ar.displayName = "AccordionTrigger";
const sr = C.forwardRef(({ id: e, className: t, children: r, "data-refast-id": n }, s) => /* @__PURE__ */ a.jsx(
  Nr,
  {
    ref: s,
    id: e,
    className: "overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
    "data-refast-id": n,
    children: /* @__PURE__ */ a.jsx("div", { className: b("pb-4 pt-0", t), children: r })
  }
));
sr.displayName = "AccordionContent";
const or = C.createContext({ striped: !1, hoverable: !0 });
function mi({
  id: e,
  className: t,
  children: r,
  striped: n = !1,
  hoverable: s = !0,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ a.jsx(or.Provider, { value: { striped: n, hoverable: s }, children: /* @__PURE__ */ a.jsx("div", { className: "relative w-full overflow-auto", "data-refast-id": o, children: /* @__PURE__ */ a.jsx(
    "table",
    {
      id: e,
      className: b("w-full caption-bottom text-sm", t),
      children: r
    }
  ) }) });
}
function gi({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx(
    "thead",
    {
      id: e,
      className: b("[&_tr]:border-b", t),
      "data-refast-id": n,
      children: r
    }
  );
}
function hi({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx(
    "tbody",
    {
      id: e,
      className: b("[&_tr:last-child]:border-0", t),
      "data-refast-id": n,
      children: r
    }
  );
}
function bi({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  const { striped: s, hoverable: o } = C.useContext(or);
  return /* @__PURE__ */ a.jsx(
    "tr",
    {
      id: e,
      className: b(
        "border-b transition-colors data-[state=selected]:bg-muted",
        o && "hover:bg-muted/50",
        s && "even:bg-muted/30",
        t
      ),
      "data-refast-id": n,
      children: r
    }
  );
}
function xi({
  id: e,
  className: t,
  children: r,
  "data-refast-id": n
}) {
  return /* @__PURE__ */ a.jsx(
    "th",
    {
      id: e,
      className: b(
        "h-12 px-4 text-left align-middle font-medium text-muted-foreground",
        "[&:has([role=checkbox])]:pr-0",
        t
      ),
      "data-refast-id": n,
      children: r
    }
  );
}
function yi({
  id: e,
  className: t,
  colSpan: r,
  rowSpan: n,
  children: s,
  "data-refast-id": o
}) {
  return /* @__PURE__ */ a.jsx(
    "td",
    {
      id: e,
      colSpan: r,
      rowSpan: n,
      className: b("p-4 align-middle [&:has([role=checkbox])]:pr-0", t),
      "data-refast-id": o,
      children: s
    }
  );
}
function vi({
  id: e,
  className: t,
  columns: r = [],
  data: n = [],
  sortable: s = !0,
  filterable: o = !0,
  paginated: c = !0,
  pageSize: l = 10,
  loading: i = !1,
  emptyMessage: d = "No data available",
  currentPage: u,
  onRowClick: f,
  onSortChange: m,
  onFilterChange: p,
  onPageChange: g,
  "data-refast-id": h
}) {
  const [v, y] = C.useState(""), [S, N] = C.useState(null), [j, D] = C.useState(1), I = u !== void 0 ? u : j, P = C.useMemo(() => {
    if (!v) return n;
    const M = v.toLowerCase();
    return n.filter(
      (E) => Object.values(E).some((_) => String(_ ?? "").toLowerCase().includes(M))
    );
  }, [n, v]), T = C.useMemo(() => S ? [...P].sort((M, E) => {
    const _ = String(M[S.key] ?? ""), z = String(E[S.key] ?? ""), F = _.localeCompare(z);
    return S.direction === "asc" ? F : -F;
  }) : P, [P, S]), A = c ? Math.max(1, Math.ceil(T.length / l)) : 1, O = c ? T.slice((I - 1) * l, I * l) : T, $ = (M) => {
    if (!(M.sortable !== void 0 ? M.sortable : s)) return;
    let _;
    !S || S.key !== M.key ? _ = { key: M.key, direction: "asc" } : S.direction === "asc" ? _ = { key: M.key, direction: "desc" } : _ = null, N(_), m == null || m(_);
  }, k = (M) => {
    y(M), u === void 0 && D(1), p == null || p({ value: M });
  }, L = (M) => {
    u === void 0 && D(M), g == null || g({ page: M });
  }, H = C.useMemo(() => {
    const M = [], E = Math.min(A, 5);
    let _;
    I <= 3 || A <= 5 ? _ = 1 : I >= A - 2 ? _ = A - 4 : _ = I - 2;
    for (let z = 0; z < E; z++) M.push(_ + z);
    return M;
  }, [A, I]);
  return /* @__PURE__ */ a.jsxs("div", { id: e, className: b("w-full space-y-4", t), "data-refast-id": h, children: [
    o && /* @__PURE__ */ a.jsx(
      "input",
      {
        type: "text",
        placeholder: "Filter...",
        value: v,
        onChange: (M) => k(M.target.value),
        className: "flex h-9 w-full max-w-sm rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      }
    ),
    /* @__PURE__ */ a.jsxs("div", { className: "relative w-full overflow-auto rounded-md border", children: [
      i && /* @__PURE__ */ a.jsx("div", { className: "absolute inset-0 z-10 flex items-center justify-center rounded-md bg-background/60", children: /* @__PURE__ */ a.jsx("div", { className: "h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" }) }),
      /* @__PURE__ */ a.jsxs("table", { className: "w-full caption-bottom text-sm", children: [
        /* @__PURE__ */ a.jsx("thead", { className: "[&_tr]:border-b", children: /* @__PURE__ */ a.jsx("tr", { className: "border-b transition-colors", children: r.map((M) => {
          const E = M.sortable !== void 0 ? M.sortable : s, _ = (S == null ? void 0 : S.key) === M.key;
          return /* @__PURE__ */ a.jsx(
            "th",
            {
              style: M.width ? { width: M.width } : void 0,
              className: b(
                "h-10 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0",
                M.align === "center" && "text-center",
                M.align === "right" && "text-right",
                E && "cursor-pointer select-none hover:text-foreground"
              ),
              onClick: () => $(M),
              children: /* @__PURE__ */ a.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                M.header,
                E && /* @__PURE__ */ a.jsx("span", { className: "text-xs opacity-60", children: _ ? (S == null ? void 0 : S.direction) === "asc" ? "↑" : "↓" : "↕" })
              ] })
            },
            M.key
          );
        }) }) }),
        /* @__PURE__ */ a.jsx("tbody", { className: "[&_tr:last-child]:border-0", children: O.length === 0 ? /* @__PURE__ */ a.jsx("tr", { children: /* @__PURE__ */ a.jsx(
          "td",
          {
            colSpan: r.length || 1,
            className: "py-8 text-center text-sm text-muted-foreground",
            children: d
          }
        ) }) : O.map((M, E) => /* @__PURE__ */ a.jsx(
          "tr",
          {
            className: b(
              "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
              f && "cursor-pointer"
            ),
            onClick: () => f == null ? void 0 : f(M),
            children: r.map((_) => /* @__PURE__ */ a.jsx(
              "td",
              {
                className: b(
                  "p-4 align-middle",
                  _.align === "center" && "text-center",
                  _.align === "right" && "text-right"
                ),
                children: String(M[_.key] ?? "")
              },
              _.key
            ))
          },
          E
        )) })
      ] })
    ] }),
    c && A > 1 && /* @__PURE__ */ a.jsxs("div", { className: "flex items-center justify-between text-sm text-muted-foreground", children: [
      /* @__PURE__ */ a.jsxs("span", { children: [
        "Showing ",
        (I - 1) * l + 1,
        "–",
        Math.min(I * l, T.length),
        " of ",
        T.length
      ] }),
      /* @__PURE__ */ a.jsxs("div", { className: "flex gap-1", children: [
        /* @__PURE__ */ a.jsx(
          "button",
          {
            type: "button",
            disabled: I <= 1,
            onClick: () => L(I - 1),
            className: "inline-flex h-8 items-center justify-center rounded-md border px-3 text-sm disabled:opacity-50 hover:bg-accent",
            children: "Previous"
          }
        ),
        H.map((M) => /* @__PURE__ */ a.jsx(
          "button",
          {
            type: "button",
            onClick: () => L(M),
            className: b(
              "inline-flex h-8 w-8 items-center justify-center rounded-md border text-sm",
              I === M ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent"
            ),
            children: M
          },
          M
        )),
        /* @__PURE__ */ a.jsx(
          "button",
          {
            type: "button",
            disabled: I >= A,
            onClick: () => L(I + 1),
            className: "inline-flex h-8 items-center justify-center rounded-md border px-3 text-sm disabled:opacity-50 hover:bg-accent",
            children: "Next"
          }
        )
      ] })
    ] })
  ] });
}
function wi({
  id: e,
  className: t,
  src: r,
  alt: n = "",
  fallback: s,
  size: o = "md",
  "data-refast-id": c
}) {
  const l = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-12 w-12"
  }, [i, d] = C.useState(!1);
  return /* @__PURE__ */ a.jsx(
    "span",
    {
      id: e,
      className: b(
        "relative flex shrink-0 overflow-hidden rounded-full",
        l[o],
        t
      ),
      "data-refast-id": c,
      children: r && !i ? /* @__PURE__ */ a.jsx(
        "img",
        {
          src: r,
          alt: n,
          className: "aspect-square h-full w-full",
          onError: () => d(!0)
        }
      ) : /* @__PURE__ */ a.jsx("span", { className: "flex h-full w-full items-center justify-center rounded-full bg-muted text-sm font-medium uppercase", children: s || (n == null ? void 0 : n.charAt(0)) || "?" })
    }
  );
}
function Ci({
  id: e,
  className: t,
  src: r,
  alt: n = "",
  width: s,
  height: o,
  objectFit: c = "cover",
  loading: l = !1,
  fallbackSrc: i,
  fallback: d,
  "data-refast-id": u
}) {
  const [f, m] = C.useState(l), [p, g] = C.useState(!1), [h, v] = C.useState(r);
  C.useEffect(() => {
    v(r), g(!1), l && m(!0);
  }, [r, l]);
  const y = () => {
    m(!1);
  }, S = () => {
    i && h !== i ? (v(i), g(!1)) : (g(!0), m(!1));
  }, N = {
    width: typeof s == "number" ? `${s}px` : s,
    height: typeof o == "number" ? `${o}px` : o,
    objectFit: c
  };
  return p && d ? /* @__PURE__ */ a.jsx(a.Fragment, { children: d }) : p && !i ? /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b(
        "flex items-center justify-center rounded-md bg-muted text-muted-foreground",
        t
      ),
      style: N,
      "data-refast-id": u,
      children: /* @__PURE__ */ a.jsxs(
        "svg",
        {
          xmlns: "http://www.w3.org/2000/svg",
          width: "24",
          height: "24",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: "opacity-50",
          children: [
            /* @__PURE__ */ a.jsx("rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2" }),
            /* @__PURE__ */ a.jsx("circle", { cx: "9", cy: "9", r: "2" }),
            /* @__PURE__ */ a.jsx("path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" })
          ]
        }
      )
    }
  ) : /* @__PURE__ */ a.jsxs("div", { className: "relative inline-block", style: N, children: [
    f && /* @__PURE__ */ a.jsx(
      "div",
      {
        className: b(
          "absolute inset-0 animate-pulse rounded-md bg-muted",
          t
        ),
        style: N
      }
    ),
    /* @__PURE__ */ a.jsx(
      "img",
      {
        id: e,
        src: h,
        alt: n,
        className: b(
          "rounded-md",
          f && "invisible",
          t
        ),
        style: N,
        onLoad: y,
        onError: S,
        "data-refast-id": u
      }
    )
  ] });
}
function ki({
  id: e,
  className: t,
  content: r,
  side: n = "top",
  sideOffset: s,
  children: o,
  "data-refast-id": c
}) {
  const l = C.Children.count(o) === 1 && C.isValidElement(o) ? C.cloneElement(o, { id: e, "data-refast-id": c }) : /* @__PURE__ */ a.jsx("span", { id: e, "data-refast-id": c, children: o });
  return /* @__PURE__ */ a.jsx(Mr, { children: /* @__PURE__ */ a.jsxs(Er, { children: [
    /* @__PURE__ */ a.jsx(Tr, { asChild: !0, children: l }),
    /* @__PURE__ */ a.jsx(Lr, { children: /* @__PURE__ */ a.jsxs(
      Ir,
      {
        side: n,
        sideOffset: typeof s == "number" ? s : 4,
        className: b(
          "z-50 rounded-md bg-foreground text-background text-sm px-3 py-1.5 shadow-md animate-in fade-in-0 zoom-in-95",
          t
        ),
        children: [
          r,
          /* @__PURE__ */ a.jsx(Pr, { className: "fill-foreground" })
        ]
      }
    ) })
  ] }) });
}
const ji = C.createContext(null);
function Si({
  id: e,
  className: t,
  defaultValue: r = "",
  value: n,
  onValueChange: s,
  children: o,
  "data-refast-id": c
}) {
  const [l, i] = C.useState(n || r), d = C.Children.toArray(o), u = [];
  C.Children.forEach(o, (p) => {
    if (C.isValidElement(p)) {
      const g = p.props;
      let h, v, y, S;
      if ("tree" in g && typeof g.tree == "object" && g.tree !== null) {
        const N = g.tree.props || {};
        h = N.value, v = N.label, y = N.icon, S = N.disabled;
      } else
        h = g.value, v = g.label, y = g.icon, S = g.disabled;
      h !== void 0 && u.push({
        value: String(h || ""),
        label: String(v || h || ""),
        icon: y,
        disabled: !!S
      });
    }
  }), C.useEffect(() => {
    !l && u.length > 0 && i(u[0].value);
  }, [l, u]);
  const f = (p) => {
    i(p), s == null || s(p);
  }, m = C.useMemo(
    () => ({ activeTab: l, setActiveTab: f }),
    [l]
  );
  return /* @__PURE__ */ a.jsx(ji.Provider, { value: m, children: /* @__PURE__ */ a.jsxs("div", { id: e, className: b("w-full", t), "data-refast-id": c, children: [
    /* @__PURE__ */ a.jsx("div", { className: "inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", children: u.map((p) => {
      const g = l === p.value;
      return /* @__PURE__ */ a.jsxs(
        "button",
        {
          type: "button",
          onClick: () => !p.disabled && f(p.value),
          disabled: p.disabled,
          className: b(
            "inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
            g ? "bg-background text-foreground shadow-sm" : "hover:bg-background/50"
          ),
          children: [
            p.icon ? /* @__PURE__ */ a.jsx(Y, { name: p.icon, size: 14 }) : null,
            /* @__PURE__ */ a.jsx("span", { children: p.label })
          ]
        },
        p.value
      );
    }) }),
    /* @__PURE__ */ a.jsx("div", { className: "mt-2", children: d.map((p, g) => {
      if (C.isValidElement(p)) {
        const h = p.props;
        let v;
        "tree" in h && typeof h.tree == "object" && h.tree !== null ? v = (h.tree.props || {}).value : v = h.value;
        const y = String(v || "");
        return y !== l ? null : /* @__PURE__ */ a.jsx(C.Fragment, { children: p }, y || g);
      }
      return null;
    }) })
  ] }) });
}
function Ni({
  id: e,
  className: t,
  value: r,
  label: n,
  icon: s,
  disabled: o = !1,
  children: c,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      id: e,
      className: b("ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", t),
      role: "tabpanel",
      "data-value": r,
      "data-label": n,
      "data-icon": s,
      "data-disabled": o,
      "data-refast-id": l,
      children: c
    }
  );
}
function Mi({
  orientation: e = "horizontal",
  decorative: t = !0,
  className: r,
  ...n
}) {
  return /* @__PURE__ */ a.jsx(
    Dr,
    {
      decorative: t,
      orientation: e,
      className: b(
        "shrink-0 bg-border",
        e === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
        r
      ),
      ...n
    }
  );
}
function Ei({
  ratio: e = 16 / 9,
  className: t,
  children: r,
  ...n
}) {
  return /* @__PURE__ */ a.jsx(_r, { ratio: e, className: t, ...n, children: r });
}
function Ti({
  type: e = "hover",
  scrollHideDelay: t = 600,
  className: r,
  children: n,
  ...s
}) {
  return /* @__PURE__ */ a.jsxs(
    zr,
    {
      type: e,
      scrollHideDelay: t,
      className: b("relative overflow-hidden", r),
      ...s,
      children: [
        /* @__PURE__ */ a.jsx(Fr, { className: "h-full w-full rounded-[inherit]", children: n }),
        /* @__PURE__ */ a.jsx(
          Te,
          {
            orientation: "vertical",
            className: b(
              "flex touch-none select-none transition-colors",
              "h-full w-2.5 border-l border-l-transparent p-[1px]"
            ),
            children: /* @__PURE__ */ a.jsx(
              Le,
              {
                className: b(
                  "relative flex-1 rounded-full bg-foreground/25 hover:bg-foreground/40 transition-colors",
                  "before:absolute before:left-1/2 before:top-1/2",
                  "before:h-full before:min-h-[44px] before:w-full before:min-w-[44px]",
                  'before:-translate-x-1/2 before:-translate-y-1/2 before:content-[""]'
                )
              }
            )
          }
        ),
        /* @__PURE__ */ a.jsx(
          Te,
          {
            orientation: "horizontal",
            className: b(
              "flex touch-none select-none transition-colors",
              "h-2.5 flex-col border-t border-t-transparent p-[1px]"
            ),
            children: /* @__PURE__ */ a.jsx(
              Le,
              {
                className: b(
                  "relative flex-1 rounded-full bg-foreground/25 hover:bg-foreground/40 transition-colors",
                  "before:absolute before:left-1/2 before:top-1/2",
                  "before:h-full before:min-h-[44px] before:w-full before:min-w-[44px]",
                  'before:-translate-x-1/2 before:-translate-y-1/2 before:content-[""]'
                )
              }
            )
          }
        ),
        /* @__PURE__ */ a.jsx(Br, {})
      ]
    }
  );
}
const Li = Ar, ir = x.forwardRef(({ children: e, ...t }, r) => {
  const n = Array.isArray(e) && e.length === 1 ? e[0] : e;
  return /* @__PURE__ */ a.jsx(Et, { ref: r, ...t, children: n });
});
ir.displayName = Et.displayName;
const lr = x.forwardRef(({ className: e, children: t, ...r }, n) => /* @__PURE__ */ a.jsx(
  Tt,
  {
    ref: n,
    className: b(
      "data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden",
      e
    ),
    ...r,
    children: t
  }
));
lr.displayName = Tt.displayName;
const cr = x.createContext(null);
function je() {
  const e = x.useContext(cr);
  if (!e)
    throw new Error("useCarousel must be used within a <Carousel />");
  return e;
}
function Ii({
  orientation: e = "horizontal",
  opts: t,
  loop: r = !1,
  className: n,
  children: s,
  ...o
}) {
  const [c, l] = Or({
    ...t,
    axis: e === "horizontal" ? "x" : "y",
    loop: r
  }), [i, d] = x.useState(!1), [u, f] = x.useState(!1), m = x.useCallback((h) => {
    h && (d(h.canScrollPrev()), f(h.canScrollNext()));
  }, []), p = x.useCallback(() => {
    l == null || l.scrollPrev();
  }, [l]), g = x.useCallback(() => {
    l == null || l.scrollNext();
  }, [l]);
  return x.useEffect(() => {
    if (l)
      return m(l), l.on("reInit", m), l.on("select", m), () => {
        l == null || l.off("select", m);
      };
  }, [l, m]), /* @__PURE__ */ a.jsx(
    cr.Provider,
    {
      value: {
        carouselRef: c,
        api: l,
        scrollPrev: p,
        scrollNext: g,
        canScrollPrev: i,
        canScrollNext: u,
        orientation: e
      },
      children: /* @__PURE__ */ a.jsx(
        "div",
        {
          className: b("relative", e === "vertical" && "min-h-64", n),
          role: "region",
          "aria-roledescription": "carousel",
          ...o,
          children: s
        }
      )
    }
  );
}
function Pi({
  className: e,
  children: t,
  ...r
}) {
  const { carouselRef: n, orientation: s } = je();
  return /* @__PURE__ */ a.jsx("div", { ref: n, className: b("overflow-hidden h-full"), children: /* @__PURE__ */ a.jsx("div", { className: b("flex h-full", s === "vertical" ? "flex-col" : "-ml-4", e), ...r, children: t }) });
}
function Ri({
  className: e,
  children: t,
  ...r
}) {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      role: "group",
      "aria-roledescription": "slide",
      className: b(
        "min-w-0 shrink-0 grow-0 basis-full",
        "h-full flex items-center justify-center",
        e
      ),
      ...r,
      children: t
    }
  );
}
function Ai({
  className: e,
  onClick: t,
  ...r
}) {
  const { scrollPrev: n, canScrollPrev: s, orientation: o } = je();
  return /* @__PURE__ */ a.jsxs(
    "button",
    {
      type: "button",
      className: b(
        "absolute z-10",
        o === "vertical" ? "top-2 left-1/2 -translate-x-1/2" : "left-2 top-1/2 -translate-y-1/2",
        "inline-flex h-8 w-8 items-center justify-center rounded-full",
        "border bg-background shadow-sm",
        "disabled:pointer-events-none disabled:opacity-50",
        "hover:bg-accent hover:text-accent-foreground",
        e
      ),
      disabled: !s,
      onClick: () => {
        n(), t == null || t();
      },
      ...r,
      children: [
        o === "vertical" ? /* @__PURE__ */ a.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "h-4 w-4", children: /* @__PURE__ */ a.jsx("polyline", { points: "18 15 12 9 6 15" }) }) : /* @__PURE__ */ a.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "h-4 w-4", children: /* @__PURE__ */ a.jsx("polyline", { points: "15 18 9 12 15 6" }) }),
        /* @__PURE__ */ a.jsx("span", { className: "sr-only", children: "Previous slide" })
      ]
    }
  );
}
function Di({
  className: e,
  onClick: t,
  ...r
}) {
  const { scrollNext: n, canScrollNext: s, orientation: o } = je();
  return /* @__PURE__ */ a.jsxs(
    "button",
    {
      type: "button",
      className: b(
        "absolute z-10",
        o === "vertical" ? "bottom-2 left-1/2 -translate-x-1/2" : "right-2 top-1/2 -translate-y-1/2",
        "inline-flex h-8 w-8 items-center justify-center rounded-full",
        "border bg-background shadow-sm",
        "disabled:pointer-events-none disabled:opacity-50",
        "hover:bg-accent hover:text-accent-foreground",
        e
      ),
      disabled: !s,
      onClick: () => {
        n(), t == null || t();
      },
      ...r,
      children: [
        o === "vertical" ? /* @__PURE__ */ a.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "h-4 w-4", children: /* @__PURE__ */ a.jsx("polyline", { points: "6 9 12 15 18 9" }) }) : /* @__PURE__ */ a.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className: "h-4 w-4", children: /* @__PURE__ */ a.jsx("polyline", { points: "9 18 15 12 9 6" }) }),
        /* @__PURE__ */ a.jsx("span", { className: "sr-only", children: "Next slide" })
      ]
    }
  );
}
function _i({
  className: e,
  direction: t = "horizontal",
  ...r
}) {
  return /* @__PURE__ */ a.jsx(
    $r,
    {
      className: b(
        "flex h-full w-full data-[panel-group-direction=vertical]:flex-col",
        e
      ),
      direction: t,
      ...r
    }
  );
}
function zi({
  className: e,
  defaultSize: t,
  minSize: r,
  maxSize: n,
  id: s,
  ...o
}) {
  const c = x.useRef(null);
  return x.useEffect(() => {
    if (!s) return;
    const l = document.getElementById(s);
    if (l)
      return l.collapse = () => {
        var i;
        return (i = c.current) == null ? void 0 : i.collapse();
      }, l.expand = (i) => {
        var d;
        return (d = c.current) == null ? void 0 : d.expand(i);
      }, l.resize = (i) => {
        var d;
        return (d = c.current) == null ? void 0 : d.resize(i);
      }, l.getSize = () => {
        var i;
        return (i = c.current) == null ? void 0 : i.getSize();
      }, l.isCollapsed = () => {
        var i;
        return (i = c.current) == null ? void 0 : i.isCollapsed();
      }, l.isExpanded = () => {
        var i;
        return (i = c.current) == null ? void 0 : i.isExpanded();
      }, () => {
        delete l.collapse, delete l.expand, delete l.resize, delete l.getSize, delete l.isCollapsed, delete l.isExpanded;
      };
  }, [s]), /* @__PURE__ */ a.jsx(
    Hr,
    {
      ref: c,
      id: s,
      className: b(e),
      defaultSize: t ?? void 0,
      minSize: r ?? void 0,
      maxSize: n ?? void 0,
      ...o
    }
  );
}
function Fi({
  withHandle: e,
  className: t,
  ...r
}) {
  return /* @__PURE__ */ a.jsx(
    Gr,
    {
      className: b(
        "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
        t
      ),
      ...r,
      children: e && /* @__PURE__ */ a.jsx("div", { className: "z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border", children: /* @__PURE__ */ a.jsx(Rt, { className: "h-2.5 w-2.5" }) })
    }
  );
}
function Bi(e, t) {
  if (!e || typeof window > "u")
    return "bottom";
  const r = e.getBoundingClientRect(), n = window.innerHeight - r.bottom, s = r.top;
  return n < t && s > n ? "top" : "bottom";
}
function be({ className: e }) {
  return /* @__PURE__ */ a.jsxs(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: [
        /* @__PURE__ */ a.jsx("circle", { cx: "12", cy: "12", r: "4" }),
        /* @__PURE__ */ a.jsx("path", { d: "M12 2v2" }),
        /* @__PURE__ */ a.jsx("path", { d: "M12 20v2" }),
        /* @__PURE__ */ a.jsx("path", { d: "m4.93 4.93 1.41 1.41" }),
        /* @__PURE__ */ a.jsx("path", { d: "m17.66 17.66 1.41 1.41" }),
        /* @__PURE__ */ a.jsx("path", { d: "M2 12h2" }),
        /* @__PURE__ */ a.jsx("path", { d: "M20 12h2" }),
        /* @__PURE__ */ a.jsx("path", { d: "m6.34 17.66-1.41 1.41" }),
        /* @__PURE__ */ a.jsx("path", { d: "m19.07 4.93-1.41 1.41" })
      ]
    }
  );
}
function xe({ className: e }) {
  return /* @__PURE__ */ a.jsx(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: /* @__PURE__ */ a.jsx("path", { d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" })
    }
  );
}
function Oi({ className: e }) {
  return /* @__PURE__ */ a.jsxs(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: e,
      children: [
        /* @__PURE__ */ a.jsx("rect", { width: "20", height: "14", x: "2", y: "3", rx: "2" }),
        /* @__PURE__ */ a.jsx("line", { x1: "8", x2: "16", y1: "21", y2: "21" }),
        /* @__PURE__ */ a.jsx("line", { x1: "12", x2: "12", y1: "17", y2: "21" })
      ]
    }
  );
}
function Ce() {
  return typeof window > "u" ? "light" : window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function Ct(e) {
  if (typeof document > "u") return;
  const t = e === "system" ? Ce() : e, r = document.documentElement;
  r.classList.remove("light", "dark"), r.classList.add(t);
}
function $i({
  defaultTheme: e = "system",
  storageKey: t = "refast-theme",
  showSystemOption: r = !0,
  mode: n = "toggle",
  onChange: s,
  className: o,
  ...c
}) {
  const [l, i] = x.useState(() => {
    if (typeof window < "u") {
      const N = localStorage.getItem(t);
      if (N && ["light", "dark", "system"].includes(N))
        return N;
    }
    return e;
  }), [d, u] = x.useState(!1), [f, m] = x.useState(!1), [p, g] = x.useState("bottom"), h = x.useRef(null);
  x.useEffect(() => {
    u(!0), Ct(l);
  }, [l]), x.useEffect(() => {
    if (l !== "system") return;
    const N = window.matchMedia("(prefers-color-scheme: dark)"), j = () => Ct("system");
    return N.addEventListener("change", j), () => N.removeEventListener("change", j);
  }, [l]), x.useEffect(() => {
    if (!f || n !== "dropdown") return;
    const N = () => {
      g(Bi(h.current, 220));
    };
    return N(), window.addEventListener("resize", N), window.addEventListener("scroll", N, !0), () => {
      window.removeEventListener("resize", N), window.removeEventListener("scroll", N, !0);
    };
  }, [f, n]);
  const v = x.useCallback((N) => {
    i(N), typeof window < "u" && localStorage.setItem(t, N), s == null || s(N);
  }, [t, s]), y = x.useCallback(() => {
    const j = (l === "system" ? Ce() : l) === "light" ? "dark" : "light";
    v(j);
  }, [l, v]), S = l === "system" ? Ce() : l;
  return d ? n === "toggle" ? /* @__PURE__ */ a.jsx(
    "button",
    {
      type: "button",
      onClick: y,
      className: b(
        "inline-flex h-10 w-10 items-center justify-center rounded-md bg-background",
        "text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        o
      ),
      "aria-label": `Switch to ${S === "light" ? "dark" : "light"} theme`,
      ...c,
      children: S === "light" ? /* @__PURE__ */ a.jsx(be, { className: "h-5 w-5" }) : /* @__PURE__ */ a.jsx(xe, { className: "h-5 w-5" })
    }
  ) : /* @__PURE__ */ a.jsxs("div", { ref: h, className: b("relative", o), ...c, children: [
    /* @__PURE__ */ a.jsx(
      "button",
      {
        type: "button",
        onClick: () => m(!f),
        className: b(
          "inline-flex h-10 w-10 items-center justify-center rounded-md bg-background",
          "text-sm font-medium ring-offset-background transition-colors",
          "hover:bg-accent hover:text-accent-foreground",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        ),
        "aria-label": "Select theme",
        "aria-expanded": f,
        "aria-haspopup": "menu",
        children: S === "light" ? /* @__PURE__ */ a.jsx(be, { className: "h-5 w-5" }) : /* @__PURE__ */ a.jsx(xe, { className: "h-5 w-5" })
      }
    ),
    f && /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
      /* @__PURE__ */ a.jsx(
        "div",
        {
          className: "fixed inset-0 z-40",
          onClick: () => m(!1)
        }
      ),
      /* @__PURE__ */ a.jsxs(
        "div",
        {
          className: b(
            "absolute right-0 z-50 min-w-[8rem]",
            "rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
            "animate-in fade-in-0 zoom-in-95",
            p === "top" ? "bottom-full mb-2" : "top-full mt-2"
          ),
          role: "menu",
          children: [
            /* @__PURE__ */ a.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  v("light"), m(!1);
                },
                className: b(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  l === "light" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ a.jsx(be, { className: "h-4 w-4" }),
                  "Light"
                ]
              }
            ),
            /* @__PURE__ */ a.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  v("dark"), m(!1);
                },
                className: b(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  l === "dark" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ a.jsx(xe, { className: "h-4 w-4" }),
                  "Dark"
                ]
              }
            ),
            r && /* @__PURE__ */ a.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  v("system"), m(!1);
                },
                className: b(
                  "relative flex w-full cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none",
                  "hover:bg-accent hover:text-accent-foreground",
                  l === "system" && "bg-accent"
                ),
                role: "menuitem",
                children: [
                  /* @__PURE__ */ a.jsx(Oi, { className: "h-4 w-4" }),
                  "System"
                ]
              }
            )
          ]
        }
      )
    ] })
  ] }) : /* @__PURE__ */ a.jsx(
    "button",
    {
      className: b(
        "inline-flex h-10 w-10 items-center justify-center rounded-md bg-background",
        "text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-accent hover:text-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        o
      ),
      disabled: !0,
      ...c,
      children: /* @__PURE__ */ a.jsx("span", { className: "h-5 w-5" })
    }
  );
}
function Hi({
  className: e,
  position: t = "bottom-right",
  expand: r = !1,
  duration: n = 4e3,
  visibleToasts: s = 3,
  closeButton: o = !1,
  richColors: c = !1,
  theme: l = "system",
  offset: i,
  gap: d = 14,
  dir: u = "auto",
  hotkey: f = ["altKey", "KeyT"],
  invert: m = !1
}) {
  return /* @__PURE__ */ a.jsx(
    Lt,
    {
      className: e,
      position: t,
      expand: r,
      duration: n,
      visibleToasts: s,
      closeButton: o,
      richColors: c,
      theme: l,
      offset: i,
      gap: d,
      dir: u,
      hotkey: f,
      invert: m,
      toastOptions: {
        classNames: {
          toast: "group"
        }
      }
    }
  );
}
class Gi {
  constructor() {
    V(this, "store", /* @__PURE__ */ new Map());
    V(this, "listeners", /* @__PURE__ */ new Set());
  }
  /**
   * Set a value in the prop store.
   */
  set(t, r) {
    this.store.set(t, r), this.notifyListeners(t, r);
  }
  /**
   * Get a value from the prop store.
   */
  get(t) {
    return this.store.get(t);
  }
  /**
   * Check if a key exists in the prop store.
   */
  has(t) {
    return this.store.has(t);
  }
  /**
   * Delete a key from the prop store.
   */
  delete(t) {
    this.store.delete(t), this.notifyListeners(t, void 0);
  }
  /**
   * Clear all values from the prop store.
   */
  clear() {
    this.store.clear();
  }
  /**
   * Get all values as a plain object.
   * This is sent to the backend with callback invocations.
   */
  getAll() {
    const t = {};
    return this.store.forEach((r, n) => {
      t[n] = r;
    }), t;
  }
  /**
   * Get all keys in the prop store.
   * Used for regex pattern matching.
   */
  keys() {
    return Array.from(this.store.keys());
  }
  /**
   * Subscribe to prop store changes.
   */
  subscribe(t) {
    return this.listeners.add(t), () => {
      this.listeners.delete(t);
    };
  }
  notifyListeners(t, r) {
    this.listeners.forEach((n) => n(t, r));
  }
}
const ie = new Gi();
function Wi(e, t, r = ie) {
  if (typeof e == "string")
    r.set(e, t.value);
  else if (typeof e == "object")
    for (const [n, s] of Object.entries(e))
      n in t && r.set(s, t[n]);
}
function Se(e) {
  return typeof e == "object" && e !== null && "callbackId" in e;
}
function dr(e) {
  return typeof e == "object" && e !== null && "jsFunction" in e;
}
function ur(e) {
  return typeof e == "object" && e !== null && "boundMethod" in e && typeof e.boundMethod == "object" && "targetId" in e.boundMethod && "methodName" in e.boundMethod;
}
function fr(e) {
  return typeof e == "object" && e !== null && "saveProp" in e;
}
function pr(e) {
  return typeof e == "object" && e !== null && "chain" in e && Array.isArray(e.chain);
}
function Ui(e, t = ie) {
  const r = {}, n = t.keys();
  for (const s of e)
    if (/[\\^$.*+?()[\]{}|]/.test(s))
      try {
        const c = new RegExp(`^${s}$`);
        for (const l of n)
          if (c.test(l)) {
            const i = t.get(l);
            i !== void 0 && (r[l] = i);
          }
      } catch {
        console.warn(`[Refast] Invalid regex pattern in props: ${s}`);
        const c = t.get(s);
        c !== void 0 && (r[s] = c);
      }
    else {
      const c = t.get(s);
      c !== void 0 && (r[s] = c);
    }
  return r;
}
function ue(e, t, r) {
  let n = e;
  return t && t > 0 && (n = wo(n, t)), r && r > 0 && (n = Co(n, r)), n;
}
function fe(e, t, r = ie) {
  if (pr(e))
    return Ki(e, t, r);
  if (fr(e)) {
    const { saveProp: n, debounce: s, throttle: o } = e;
    let c = (l) => {
      Wi(n, l, r);
    };
    return c = ue(c, s, o), async (l) => {
      c(l);
    };
  }
  if (Se(e)) {
    const { callbackId: n, boundArgs: s, props: o, debounce: c, throttle: l } = e;
    let i = (d) => {
      let u = {};
      o && o.length > 0 && (u = Ui(o, r)), t.invokeCallback(n, { ...u, ...s }, d);
    };
    return i = ue(i, c, l), async (d) => {
      i(d);
    };
  }
  if (dr(e)) {
    const { jsFunction: n, boundArgs: s, debounce: o, throttle: c } = e;
    let l = (i, d) => {
      try {
        let u = null;
        d[0] && typeof d[0] == "object" && "target" in d[0] && (u = d[0].target), new Function("event", "args", "element", "refast", n)(i, s, u, Ot);
      } catch (u) {
        console.error("[Refast] Error executing JavaScript callback:", u), console.error("[Refast] Code:", n);
      }
    };
    return l = ue(l, o, c), async (i, d) => {
      l(i, d);
    };
  }
  if (ur(e)) {
    const { boundMethod: n, debounce: s, throttle: o } = e, { targetId: c, methodName: l, args: i = [], kwargs: d = {} } = n;
    let u = () => {
      try {
        const f = document.getElementById(c);
        if (f) {
          const m = f[l];
          if (typeof m == "function") {
            const g = Object.keys(d).length > 0 ? [...i, d] : i;
            g.length === 0 ? m.call(f) : g.length === 1 ? m.call(f, g[0]) : m.apply(f, g);
          } else
            console.warn(`[Refast] Method '${l}' not found on element '${c}'`);
        } else
          console.warn(`[Refast] Element with id '${c}' not found`);
      } catch (f) {
        console.error("[Refast] Error calling bound method:", f), console.error("[Refast] Target:", c, "Method:", l);
      }
    };
    return u = ue(u, s, o), async () => {
      u();
    };
  }
  jo(e);
}
function Ki(e, t, r = ie) {
  const n = e.chain.map(
    (o) => fe(o, t, r)
  ), s = e.mode || "serial";
  return async (o, c) => {
    if (s === "parallel")
      await Promise.all(n.map((l) => l(o, c)));
    else
      for (const l of n)
        await l(o, c);
  };
}
const ae = /* @__PURE__ */ new Map();
function Vi(e, t) {
  ae.has(e) || ae.set(e, []);
  const r = ae.get(e), n = r.findIndex((s) => s.componentId === t.componentId);
  n !== -1 && r.splice(n, 1), r.push(t), r.sort((s, o) => o.priority - s.priority);
}
function kt(e) {
  for (const [t, r] of ae.entries()) {
    const n = r.filter((s) => s.componentId !== e);
    n.length === 0 ? ae.delete(t) : ae.set(t, n);
  }
}
function Ji(e) {
  const t = e.toLowerCase().split("+").map((o) => o.trim()).filter(Boolean), r = /* @__PURE__ */ new Set(), n = [];
  for (const o of t)
    o === "ctrl" || o === "control" ? r.add("ctrl") : o === "shift" ? r.add("shift") : o === "alt" ? r.add("alt") : o === "meta" || o === "cmd" || o === "command" || o === "win" ? r.add("meta") : n.push(o);
  return [...["ctrl", "shift", "alt", "meta"].filter((o) => r.has(o)), ...n].join("+");
}
function Xi(e) {
  const t = [];
  e.ctrlKey && t.push("ctrl"), e.shiftKey && t.push("shift"), e.altKey && t.push("alt"), e.metaKey && t.push("meta");
  const r = e.key.toLowerCase().replace(" ", "space");
  return [...t, r].join("+");
}
let jt = !1;
function qi() {
  jt || (jt = !0, document.addEventListener(
    "keydown",
    (e) => {
      const t = e.target, r = t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement || (t == null ? void 0 : t.isContentEditable), n = e.ctrlKey || e.altKey || e.metaKey;
      if (r && !n) return;
      const s = Xi(e), o = ae.get(s);
      if (!o || o.length === 0) return;
      let c = !1;
      for (const l of o)
        if (l.preventDefault && !c && (e.preventDefault(), c = !0), l.handler(), !l.bubble) break;
    },
    !0
    // capture phase so we run before any React synthetic events
  ));
}
function Zi({
  id: e,
  shortcuts: t,
  priority: r = 0,
  bubble: n = !1,
  preventDefault: s = !0,
  enabled: o = !0
}) {
  const c = oe(), l = x.useRef({ shortcuts: t, priority: r, bubble: n, preventDefault: s, enabled: o, id: e });
  return l.current = { shortcuts: t, priority: r, bubble: n, preventDefault: s, enabled: o, id: e }, x.useEffect(() => {
    qi();
    const i = e ?? crypto.randomUUID();
    if (!o) {
      kt(i);
      return;
    }
    for (const [d, u] of Object.entries(t)) {
      if (!u || !Se(u)) continue;
      const f = Ji(d), m = u.callbackId, p = u.boundArgs ?? {};
      Vi(f, {
        componentId: i,
        priority: r,
        bubble: n,
        preventDefault: s,
        handler: () => {
          c.invokeCallback(m, p, {
            shortcut: d,
            combo: f
          });
        }
      });
    }
    return () => {
      kt(i);
    };
  }, [e, o, r, n, s, JSON.stringify(t)]), null;
}
function Yi({ interval: e = 1e3, enabled: t = !0, onTick: r }) {
  const n = x.useRef(r);
  return x.useEffect(() => {
    n.current = r;
  }), x.useEffect(() => {
    if (!t || !r) return;
    const s = setInterval(() => {
      var o;
      (o = n.current) == null || o.call(n);
    }, e);
    return () => clearInterval(s);
  }, [t, e, r]), null;
}
class Qi {
  constructor() {
    V(this, "components", /* @__PURE__ */ new Map());
    /** Maps component name → the chunk it belongs to (for lazy resolution) */
    V(this, "lazyMap", /* @__PURE__ */ new Map());
    /** Registered chunk loaders */
    V(this, "chunkLoaders", /* @__PURE__ */ new Map());
    /** Cache of resolved lazy components (wrapped in React.lazy) */
    V(this, "lazyCache", /* @__PURE__ */ new Map());
    /** Chunk load promises (so we don't trigger the same import twice) */
    V(this, "chunkPromises", /* @__PURE__ */ new Map());
    /** Which chunks have been fully resolved */
    V(this, "resolvedChunks", /* @__PURE__ */ new Set());
    /** Which feature chunks are allowed to load lazily */
    V(this, "lazyFeatureSet", null);
  }
  // ── Eager registration (unchanged API) ─────────────────────────────
  register(t, r) {
    this.components.set(t, r);
  }
  registerAll(t) {
    for (const [r, n] of Object.entries(t))
      this.register(r, n);
  }
  // ── Lazy registration ──────────────────────────────────────────────
  /**
   * Register a feature chunk whose components will be lazily loaded.
   */
  registerLazyChunk(t) {
    this.chunkLoaders.set(t.name, t.loader);
    for (const r of t.componentNames)
      this.lazyMap.set(r, t.name);
  }
  // ── Component resolution ───────────────────────────────────────────
  /**
   * Get a component by name.
   *
   * 1. If eagerly registered → return immediately.
   * 2. If the component belongs to a lazy chunk → return a `React.lazy()`
   *    wrapper that will trigger the chunk import on first render.
   * 3. Otherwise → return `undefined`.
   */
  get(t) {
    const r = this.components.get(t);
    if (r) return r;
    const n = this.lazyMap.get(t);
    if (!n) return;
    if (this.resolvedChunks.has(n))
      return this.components.get(t);
    let s = this.lazyCache.get(t);
    return s || (s = C.lazy(() => this._loadComponent(t, n)), this.lazyCache.set(t, s)), s;
  }
  has(t) {
    return this.components.has(t) || this.lazyMap.has(t);
  }
  /**
   * Get the chunk name a component belongs to (if any).
   */
  getChunkName(t) {
    return this.lazyMap.get(t);
  }
  /**
   * Check whether a component name is registered as part of a lazy chunk
   * that hasn't been loaded yet.
   */
  isLazy(t) {
    if (this.components.has(t)) return !1;
    const r = this.lazyMap.get(t);
    return r ? !this.resolvedChunks.has(r) : !1;
  }
  list() {
    const t = /* @__PURE__ */ new Set([...this.components.keys(), ...this.lazyMap.keys()]);
    return Array.from(t);
  }
  /**
   * List all registered feature-chunk names.
   */
  listChunks() {
    return Array.from(this.chunkLoaders.keys());
  }
  /**
   * Configure which feature chunks are allowed to load lazily.
   */
  configureLazyFeatures(t) {
    this.lazyFeatureSet = new Set(t);
  }
  _isLazyAllowed(t) {
    return this.lazyFeatureSet === null ? !0 : this.lazyFeatureSet.has(t);
  }
  /**
   * Eagerly load a lazy feature chunk.
   *
   * This resolves and promotes all chunk components to eager registrations
   * before the first render that uses them.
   */
  async preloadChunk(t) {
    if (this.resolvedChunks.has(t))
      return;
    let r = this.chunkPromises.get(t);
    if (!r) {
      const s = this.chunkLoaders.get(t);
      if (!s)
        throw new Error(`No loader for chunk "${t}"`);
      r = s(), this.chunkPromises.set(t, r);
    }
    const n = await r;
    for (const [s, o] of Object.entries(n))
      this.components.set(s, o);
    this.resolvedChunks.add(t);
  }
  /**
   * Eagerly load multiple lazy feature chunks.
   */
  async preloadChunks(t) {
    await Promise.all(t.map((r) => this.preloadChunk(r)));
  }
  // ── Internal ───────────────────────────────────────────────────────
  /**
   * Load a single component from its chunk.  Returns in the shape
   * `{ default: Component }` which `React.lazy()` requires.
   */
  async _loadComponent(t, r) {
    if (!this._isLazyAllowed(r) && !this.resolvedChunks.has(r))
      throw new Error(
        `Chunk "${r}" is configured as non-lazy and must be preloaded at startup.`
      );
    let n = this.chunkPromises.get(r);
    if (!n) {
      const c = this.chunkLoaders.get(r);
      if (!c) throw new Error(`No loader for chunk "${r}"`);
      n = c(), this.chunkPromises.set(r, n);
    }
    const s = await n;
    for (const [c, l] of Object.entries(s))
      this.components.set(c, l);
    this.resolvedChunks.add(r);
    const o = s[t];
    if (!o)
      throw new Error(
        `Component "${t}" not found in chunk "${r}". Available: ${Object.keys(s).join(", ")}`
      );
    return { default: o };
  }
}
const w = new Qi();
w.register("Container", So);
w.register("Text", No);
w.register("Fragment", Mo);
w.register("Slot", ti);
w.register("Row", Eo);
w.register("Column", To);
w.register("Grid", Lo);
w.register("Flex", Io);
w.register("Center", Po);
w.register("Button", Ht);
w.register("IconButton", Gt);
w.register("Card", Ao);
w.register("CardHeader", Do);
w.register("CardContent", Fo);
w.register("CardFooter", Bo);
w.register("CardTitle", _o);
w.register("CardDescription", zo);
w.register("Input", Oo);
w.register("InputWrapper", pe);
w.register("Textarea", $o);
w.register("Select", Ho);
w.register("SelectOption", Go);
w.register("Checkbox", Wo);
w.register("CheckboxGroup", Vo);
w.register("Radio", Uo);
w.register("RadioGroup", Ko);
w.register("FileUploader", Ut);
w.register("Form", Qo);
w.register("FormField", ei);
w.register("Heading", Vt);
w.register("Paragraph", Jt);
w.register("Link", Xt);
w.register("Code", qt);
w.register("BlockQuote", Zt);
w.register("List", Yt);
w.register("ListItem", Qt);
w.register("Label", er);
w.register("Kbd", tr);
w.register("Alert", si);
w.register("AlertTitle", rr);
w.register("AlertDescription", nr);
w.register("Badge", oi);
w.register("Progress", li);
w.register("Spinner", ci);
w.register("Toast", Hi);
w.register("Skeleton", di);
w.register("ConnectionStatus", ui);
w.register("Icon", Y);
w.register("Table", mi);
w.register("TableHeader", gi);
w.register("TableBody", hi);
w.register("TableRow", bi);
w.register("TableHead", xi);
w.register("TableCell", yi);
w.register("DataTable", vi);
w.register("Avatar", wi);
w.register("Image", Ci);
w.register("Tooltip", ki);
w.register("Tabs", Si);
w.register("TabItem", Ni);
w.register("Accordion", fi);
w.register("AccordionItem", pi);
w.register("AccordionTrigger", ar);
w.register("AccordionContent", sr);
w.register("Separator", Mi);
w.register("AspectRatio", Ei);
w.register("ScrollArea", Ti);
w.register("Collapsible", Li);
w.register("CollapsibleTrigger", ir);
w.register("CollapsibleContent", lr);
w.register("Carousel", Ii);
w.register("CarouselContent", Pi);
w.register("CarouselItem", Ri);
w.register("CarouselPrevious", Ai);
w.register("CarouselNext", Di);
w.register("ResizablePanelGroup", _i);
w.register("ResizablePanel", zi);
w.register("ResizableHandle", Fi);
w.register("ThemeSwitcher", $i);
w.register("KeyboardShortcut", Zi);
w.register("Timer", Yi);
w.registerLazyChunk({
  name: "markdown",
  componentNames: ["Markdown"],
  loader: () => Promise.resolve().then(() => ai).then((e) => ({ Markdown: e.Markdown }))
});
w.registerLazyChunk({
  name: "controls",
  componentNames: [
    "Switch",
    "Slider",
    "Toggle",
    "ToggleGroup",
    "ToggleGroupItem",
    "DatePicker",
    "Calendar",
    "Combobox",
    "InputOTP",
    "InputOTPGroup",
    "InputOTPSlot",
    "InputOTPSeparator"
  ],
  loader: () => import("./refast-controls-BHV7rYr-.js").then((e) => ({
    Switch: e.Switch,
    Slider: e.Slider,
    Toggle: e.Toggle,
    ToggleGroup: e.ToggleGroup,
    ToggleGroupItem: e.ToggleGroupItem,
    DatePicker: e.DatePicker,
    Calendar: e.Calendar,
    Combobox: e.Combobox,
    InputOTP: e.InputOTP,
    InputOTPGroup: e.InputOTPGroup,
    InputOTPSlot: e.InputOTPSlot,
    InputOTPSeparator: e.InputOTPSeparator
  }))
});
w.registerLazyChunk({
  name: "navigation",
  componentNames: [
    "Breadcrumb",
    "BreadcrumbList",
    "BreadcrumbItem",
    "BreadcrumbLink",
    "BreadcrumbPage",
    "BreadcrumbSeparator",
    "BreadcrumbEllipsis",
    "NavigationMenu",
    "NavigationMenuList",
    "NavigationMenuItem",
    "NavigationMenuTrigger",
    "NavigationMenuContent",
    "NavigationMenuLink",
    "Pagination",
    "PaginationContent",
    "PaginationItem",
    "PaginationLink",
    "PaginationPrevious",
    "PaginationNext",
    "PaginationEllipsis",
    "Menubar",
    "MenubarMenu",
    "MenubarTrigger",
    "MenubarContent",
    "MenubarItem",
    "MenubarSeparator",
    "MenubarCheckboxItem",
    "MenubarRadioGroup",
    "MenubarRadioItem",
    "MenubarSub",
    "MenubarSubTrigger",
    "MenubarSubContent",
    "Command",
    "CommandInput",
    "CommandList",
    "CommandEmpty",
    "CommandGroup",
    "CommandItem",
    "CommandSeparator",
    "CommandShortcut",
    "SidebarProvider",
    "Sidebar",
    "SidebarInset",
    "SidebarHeader",
    "SidebarContent",
    "SidebarFooter",
    "SidebarSeparator",
    "SidebarGroup",
    "SidebarGroupLabel",
    "SidebarGroupAction",
    "SidebarGroupContent",
    "SidebarMenu",
    "SidebarMenuItem",
    "SidebarMenuButton",
    "SidebarMenuAction",
    "SidebarMenuBadge",
    "SidebarMenuSub",
    "SidebarMenuSubItem",
    "SidebarMenuSubButton",
    "SidebarMenuSkeleton",
    "SidebarRail",
    "SidebarTrigger"
  ],
  loader: () => import("./refast-navigation-B4pjeB06.js").then((e) => ({
    Breadcrumb: e.Breadcrumb,
    BreadcrumbList: e.BreadcrumbList,
    BreadcrumbItem: e.BreadcrumbItem,
    BreadcrumbLink: e.BreadcrumbLink,
    BreadcrumbPage: e.BreadcrumbPage,
    BreadcrumbSeparator: e.BreadcrumbSeparator,
    BreadcrumbEllipsis: e.BreadcrumbEllipsis,
    NavigationMenu: e.NavigationMenu,
    NavigationMenuList: e.NavigationMenuList,
    NavigationMenuItem: e.NavigationMenuItem,
    NavigationMenuTrigger: e.NavigationMenuTrigger,
    NavigationMenuContent: e.NavigationMenuContent,
    NavigationMenuLink: e.NavigationMenuLink,
    Pagination: e.Pagination,
    PaginationContent: e.PaginationContent,
    PaginationItem: e.PaginationItem,
    PaginationLink: e.PaginationLink,
    PaginationPrevious: e.PaginationPrevious,
    PaginationNext: e.PaginationNext,
    PaginationEllipsis: e.PaginationEllipsis,
    Menubar: e.Menubar,
    MenubarMenu: e.MenubarMenu,
    MenubarTrigger: e.MenubarTrigger,
    MenubarContent: e.MenubarContent,
    MenubarItem: e.MenubarItem,
    MenubarSeparator: e.MenubarSeparator,
    MenubarCheckboxItem: e.MenubarCheckboxItem,
    MenubarRadioGroup: e.MenubarRadioGroup,
    MenubarRadioItem: e.MenubarRadioItem,
    MenubarSub: e.MenubarSub,
    MenubarSubTrigger: e.MenubarSubTrigger,
    MenubarSubContent: e.MenubarSubContent,
    Command: e.Command,
    CommandInput: e.CommandInput,
    CommandList: e.CommandList,
    CommandEmpty: e.CommandEmpty,
    CommandGroup: e.CommandGroup,
    CommandItem: e.CommandItem,
    CommandSeparator: e.CommandSeparator,
    CommandShortcut: e.CommandShortcut,
    SidebarProvider: e.SidebarProvider,
    Sidebar: e.Sidebar,
    SidebarInset: e.SidebarInset,
    SidebarHeader: e.SidebarHeader,
    SidebarContent: e.SidebarContent,
    SidebarFooter: e.SidebarFooter,
    SidebarSeparator: e.SidebarSeparator,
    SidebarGroup: e.SidebarGroup,
    SidebarGroupLabel: e.SidebarGroupLabel,
    SidebarGroupAction: e.SidebarGroupAction,
    SidebarGroupContent: e.SidebarGroupContent,
    SidebarMenu: e.SidebarMenu,
    SidebarMenuItem: e.SidebarMenuItem,
    SidebarMenuButton: e.SidebarMenuButton,
    SidebarMenuAction: e.SidebarMenuAction,
    SidebarMenuBadge: e.SidebarMenuBadge,
    SidebarMenuSub: e.SidebarMenuSub,
    SidebarMenuSubItem: e.SidebarMenuSubItem,
    SidebarMenuSubButton: e.SidebarMenuSubButton,
    SidebarMenuSkeleton: e.SidebarMenuSkeleton,
    SidebarRail: e.SidebarRail,
    SidebarTrigger: e.SidebarTrigger
  }))
});
w.registerLazyChunk({
  name: "overlay",
  componentNames: [
    "Dialog",
    "DialogTrigger",
    "DialogContent",
    "DialogHeader",
    "DialogFooter",
    "DialogTitle",
    "DialogDescription",
    "DialogAction",
    "DialogCancel",
    "Drawer",
    "DrawerTrigger",
    "DrawerContent",
    "DrawerHeader",
    "DrawerFooter",
    "DrawerTitle",
    "DrawerDescription",
    "DrawerClose",
    "Sheet",
    "SheetTrigger",
    "SheetContent",
    "SheetHeader",
    "SheetFooter",
    "SheetTitle",
    "SheetDescription",
    "SheetClose",
    "HoverCard",
    "HoverCardTrigger",
    "HoverCardContent",
    "Popover",
    "PopoverTrigger",
    "PopoverContent",
    "DropdownMenu",
    "DropdownMenuTrigger",
    "DropdownMenuContent",
    "DropdownMenuItem",
    "DropdownMenuLabel",
    "DropdownMenuSeparator",
    "DropdownMenuCheckboxItem",
    "DropdownMenuRadioGroup",
    "DropdownMenuRadioItem",
    "DropdownMenuSub",
    "DropdownMenuSubTrigger",
    "DropdownMenuSubContent",
    "ContextMenu",
    "ContextMenuTrigger",
    "ContextMenuContent",
    "ContextMenuItem",
    "ContextMenuSeparator",
    "ContextMenuCheckboxItem"
  ],
  loader: () => import("./refast-overlay-wugLq1nv.js").then((e) => ({
    Dialog: e.Dialog,
    DialogTrigger: e.DialogTrigger,
    DialogContent: e.DialogContent,
    DialogHeader: e.DialogHeader,
    DialogFooter: e.DialogFooter,
    DialogTitle: e.DialogTitle,
    DialogDescription: e.DialogDescription,
    DialogAction: e.DialogAction,
    DialogCancel: e.DialogCancel,
    Drawer: e.Drawer,
    DrawerTrigger: e.DrawerTrigger,
    DrawerContent: e.DrawerContent,
    DrawerHeader: e.DrawerHeader,
    DrawerFooter: e.DrawerFooter,
    DrawerTitle: e.DrawerTitle,
    DrawerDescription: e.DrawerDescription,
    DrawerClose: e.DrawerClose,
    Sheet: e.Sheet,
    SheetTrigger: e.SheetTrigger,
    SheetContent: e.SheetContent,
    SheetHeader: e.SheetHeader,
    SheetFooter: e.SheetFooter,
    SheetTitle: e.SheetTitle,
    SheetDescription: e.SheetDescription,
    SheetClose: e.SheetClose,
    HoverCard: e.HoverCard,
    HoverCardTrigger: e.HoverCardTrigger,
    HoverCardContent: e.HoverCardContent,
    Popover: e.Popover,
    PopoverTrigger: e.PopoverTrigger,
    PopoverContent: e.PopoverContent,
    DropdownMenu: e.DropdownMenu,
    DropdownMenuTrigger: e.DropdownMenuTrigger,
    DropdownMenuContent: e.DropdownMenuContent,
    DropdownMenuItem: e.DropdownMenuItem,
    DropdownMenuLabel: e.DropdownMenuLabel,
    DropdownMenuSeparator: e.DropdownMenuSeparator,
    DropdownMenuCheckboxItem: e.DropdownMenuCheckboxItem,
    DropdownMenuRadioGroup: e.DropdownMenuRadioGroup,
    DropdownMenuRadioItem: e.DropdownMenuRadioItem,
    DropdownMenuSub: e.DropdownMenuSub,
    DropdownMenuSubTrigger: e.DropdownMenuSubTrigger,
    DropdownMenuSubContent: e.DropdownMenuSubContent,
    ContextMenu: e.ContextMenu,
    ContextMenuTrigger: e.ContextMenuTrigger,
    ContextMenuContent: e.ContextMenuContent,
    ContextMenuItem: e.ContextMenuItem,
    ContextMenuSeparator: e.ContextMenuSeparator,
    ContextMenuCheckboxItem: e.ContextMenuCheckboxItem
  }))
});
w.registerLazyChunk({
  name: "charts",
  componentNames: [
    "ChartContainer",
    "ChartTooltip",
    "ChartTooltipContent",
    "ChartLegend",
    "ChartLegendContent",
    "AreaChart",
    "Area",
    "BarChart",
    "Bar",
    "LineChart",
    "Line",
    "PieChart",
    "Pie",
    "PieLabel",
    "Sector",
    "RadarChart",
    "Radar",
    "PolarGrid",
    "PolarAngleAxis",
    "PolarRadiusAxis",
    "RadialBarChart",
    "RadialBar",
    "ScatterChart",
    "Scatter",
    "ZAxis",
    "ComposedChart",
    "FunnelChart",
    "Funnel",
    "Treemap",
    "Sankey",
    "XAxis",
    "YAxis",
    "CartesianGrid",
    "ReferenceLine",
    "ReferenceArea",
    "ReferenceDot",
    "Brush",
    "Cell",
    "LabelList",
    "ChartLabel",
    "ErrorBar"
  ],
  loader: async () => {
    const [e, t, r, n, s, o, c, l, i, d, u, f, m] = await Promise.all([
      import("./refast-chart-Ciz0HtyP.js"),
      import("./refast-area-chart-DpksFLPz.js"),
      import("./refast-bar-chart-DRzDZeSM.js"),
      import("./refast-line-chart-CE4tDPU8.js"),
      import("./refast-pie-chart-D01BauEl.js"),
      import("./refast-radar-chart-BHJkpho0.js"),
      import("./refast-radial-chart-CvUrJR4y.js"),
      import("./refast-scatter-chart-B8fOqgiU.js"),
      import("./refast-composed-chart-9hXOhGYQ.js"),
      import("./refast-funnel-chart-BNidBRoW.js"),
      import("./refast-treemap-E1HSRsAW.js"),
      import("./refast-sankey-CfPToXaE.js"),
      import("./refast-utils-CtLs8n0_.js")
    ]);
    return {
      ChartContainer: e.ChartContainer,
      ChartTooltip: e.ChartTooltip,
      ChartTooltipContent: e.ChartTooltipContent,
      ChartLegend: e.ChartLegend,
      ChartLegendContent: e.ChartLegendContent,
      AreaChart: t.AreaChart,
      Area: t.Area,
      BarChart: r.BarChart,
      Bar: r.Bar,
      LineChart: n.LineChart,
      Line: n.Line,
      PieChart: s.PieChart,
      Pie: s.Pie,
      PieLabel: s.PieLabel,
      Sector: s.Sector,
      RadarChart: o.RadarChart,
      Radar: o.Radar,
      PolarGrid: o.PolarGrid,
      PolarAngleAxis: o.PolarAngleAxis,
      PolarRadiusAxis: o.PolarRadiusAxis,
      RadialBarChart: c.RadialBarChart,
      RadialBar: c.RadialBar,
      ScatterChart: l.ScatterChart,
      Scatter: l.Scatter,
      ZAxis: l.ZAxis,
      ComposedChart: i.ComposedChart,
      FunnelChart: d.FunnelChart,
      Funnel: d.Funnel,
      Treemap: u.Treemap,
      Sankey: f.Sankey,
      XAxis: m.XAxis,
      YAxis: m.YAxis,
      CartesianGrid: m.CartesianGrid,
      ReferenceLine: m.ReferenceLine,
      ReferenceArea: m.ReferenceArea,
      ReferenceDot: m.ReferenceDot,
      Brush: m.Brush,
      Cell: m.Cell,
      LabelList: m.LabelList,
      ChartLabel: m.Label,
      ErrorBar: m.ErrorBar
    };
  }
});
function el(e) {
  return e.replace(/_([a-z])/g, (t, r) => r.toUpperCase());
}
function tl(e, t) {
  return [
    "tickFormatter",
    "tick_formatter",
    "labelFormatter",
    "label_formatter",
    "formatter"
  ].includes(e) && typeof t == "string";
}
function rl(e) {
  const t = {};
  for (const [r, n] of Object.entries(e))
    n !== null && (t[r] = n);
  return t;
}
function nl(e) {
  return (t, r) => {
    try {
      return t == null ? "" : new Function("value", "index", `return ${e}`)(t, r);
    } catch {
      return String(t);
    }
  };
}
function al(e) {
  return Se(e) || dr(e) || ur(e) || fr(e) || pr(e);
}
function sl(e) {
  return typeof e == "object" && e !== null && "type" in e && typeof e.type == "string";
}
function St(e, t = {}) {
  const { id: r, resolveAction: n, resolveComponentTree: s } = t, o = {};
  r !== void 0 && (o.id = r);
  for (const [c, l] of Object.entries(e)) {
    const i = el(c);
    n && al(l) ? o[i] = n(l, i) : tl(c, l) ? o[i] = nl(l) : s && sl(l) ? o[i] = s(l, i) : o[i] = l;
  }
  return rl(o);
}
class ol extends x.Component {
  constructor(t) {
    super(t), this.state = { hasError: !1, errorMessage: "" };
  }
  static getDerivedStateFromError(t) {
    return { hasError: !0, errorMessage: t.message };
  }
  componentDidCatch(t) {
    console.error(`[Refast] Error rendering <${this.props.componentType}>:`, t);
  }
  render() {
    return this.state.hasError ? /* @__PURE__ */ a.jsx(
      "div",
      {
        "data-refast-error": this.props.componentType,
        title: this.state.errorMessage,
        style: {
          display: "inline-block",
          border: "1px dashed #ef4444",
          borderRadius: 4,
          padding: "2px 6px",
          color: "#ef4444",
          fontSize: 11,
          fontFamily: "monospace"
        },
        children: `<${this.props.componentType}>`
      }
    ) : this.props.children;
  }
}
function Nt() {
  return /* @__PURE__ */ a.jsx(
    "div",
    {
      className: "animate-pulse rounded bg-muted/40",
      style: { minHeight: 24, minWidth: 48 }
    }
  );
}
const se = C.forwardRef(({ tree: e, onUpdate: t, ...r }, n) => e ? typeof e == "string" ? /* @__PURE__ */ a.jsx(a.Fragment, { children: e }) : /* @__PURE__ */ a.jsx(mr, { tree: e, onUpdate: t, ref: n, ...r }) : null);
se.displayName = "ComponentRenderer";
const mr = C.forwardRef(({ tree: e, onUpdate: t, ...r }, n) => {
  var L, H;
  const s = oe(), [o, c] = x.useState(
    window.__REFAST_EXTENSIONS_READY__ ?? !0
  ), [l, i] = x.useState(!1), [d, u] = x.useState(0);
  if (x.useEffect(() => {
    if (window.__REFAST_EXTENSIONS_READY__ === !0) {
      c(!0);
      return;
    }
    return Z.on("refast:extensions-ready", () => c(!0));
  }, []), !e)
    return null;
  const { type: f, id: m, props: p, children: g } = e, h = window, v = (L = h.__REFAST_EXTENSION_COMPONENT_MAP__) == null ? void 0 : L[f], y = v ? !!((H = h.__REFAST_EXTENSION_LOADED__) != null && H[v]) : !1, S = x.useMemo(() => w.get(f), [f, d]);
  x.useEffect(() => Z.on("refast:extension-loaded", () => u((M) => M + 1)), []), x.useEffect(() => {
    if (S) {
      i(!1);
      return;
    }
    if (!v || y)
      return;
    const M = h.__REFAST_LOAD_EXTENSION__;
    if (!M)
      return;
    let E = !1;
    return i(!0), M(v).finally(() => {
      E || (i(!1), u((_) => _ + 1));
    }), () => {
      E = !0;
    };
  }, [S, v, y, h.__REFAST_LOAD_EXTENSION__]);
  const N = x.useMemo(() => St(p, {
    id: m,
    resolveAction: (M) => il(M, s)
  }), [p, m, s]), j = x.useMemo(() => {
    if (!g || g.length === 0)
      return null;
    const M = (z) => w.getChunkName(z) === "charts", E = M(f), _ = (z, F) => {
      if (typeof z == "string") return z;
      const R = w.get(z.type);
      if (!R || !M(z.type))
        return /* @__PURE__ */ a.jsx(se, { tree: z, onUpdate: t }, z.id || F);
      const Q = {
        key: z.id || F,
        ...St(z.props || {}, {
          resolveComponentTree: (B) => /* @__PURE__ */ a.jsx(se, { tree: B, onUpdate: t })
        })
      }, U = (z.children || []).filter((B) => B != null && B !== "None").map((B, X) => _(B, X));
      return C.createElement(R, Q, U.length > 0 ? U : void 0);
    };
    return g.filter((z) => z != null && z !== "None").map((z, F) => typeof z == "string" ? z : E && M(z.type) ? _(z, F) : /* @__PURE__ */ a.jsx(
      se,
      {
        tree: z,
        onUpdate: t
      },
      typeof z == "string" ? F : z.id || F
    ));
  }, [g, t, f]);
  if (!S)
    return !o || l || v && !y ? /* @__PURE__ */ a.jsx(Nt, {}) : (console.warn(`Unknown component type: ${f}`), /* @__PURE__ */ a.jsx("div", { "data-unknown-type": f, children: JSON.stringify(e) }));
  const { parentStyle: D, ...I } = N, P = w.isLazy(f), O = !(w.getChunkName(f) === "charts") ? /* @__PURE__ */ a.jsx(S, { ...I, ...r, "data-refast-id": m, ref: n, children: j }) : /* @__PURE__ */ a.jsx(S, { ...I, ...r, "data-refast-id": m, children: j }), $ = P ? /* @__PURE__ */ a.jsx(x.Suspense, { fallback: /* @__PURE__ */ a.jsx(Nt, {}), children: O }) : O, k = /* @__PURE__ */ a.jsx(ol, { componentType: f, children: $ });
  return D ? /* @__PURE__ */ a.jsx(
    "div",
    {
      style: D,
      className: "refast-component-wrapper",
      "data-wrapper-for": m,
      children: k
    }
  ) : k;
});
mr.displayName = "ComponentObjectRenderer";
function il(e, t) {
  const r = fe(e, t);
  return (...n) => {
    const s = ll(n);
    r(s, n);
  };
}
function ll(e) {
  var r;
  if (e.length === 0) return {};
  const t = e[0];
  if (t instanceof Date)
    return {
      value: t.toISOString(),
      date: t.toISOString()
    };
  if (Array.isArray(t))
    return {
      ...t,
      value: t
    };
  if (t && typeof t == "object" && "target" in t) {
    const n = t, s = n.target, o = {}, c = (r = s.tagName) == null ? void 0 : r.toLowerCase();
    if ((c === "input" || c === "select" || c === "textarea") && (o.value = s.value, o.name = s.name, (s.type === "checkbox" || s.type === "radio") && (o.checked = s.checked)), "key" in n) {
      const l = n;
      o.key = l.key, o.code = l.code, l.altKey && (o.altKey = !0), l.ctrlKey && (o.ctrlKey = !0), l.metaKey && (o.metaKey = !0), l.shiftKey && (o.shiftKey = !0), l.repeat && (o.repeat = !0);
    }
    return o;
  }
  return typeof t == "string" || typeof t == "number" || typeof t == "boolean" ? { value: t } : typeof t == "object" ? t : {};
}
function cl(e, t) {
  if (e === t) return !0;
  if (!e || !t) return !1;
  const r = Object.keys(e), n = Object.keys(t);
  if (r.length !== n.length) return !1;
  for (const s of r) {
    const o = e[s], c = t[s];
    if (!((s === "onClick" || s === "onChange" || s === "onSubmit" || s === "onInput") && typeof o == "object" && o !== null && "callbackId" in o && typeof c == "object" && c !== null && "callbackId" in c)) {
      if (typeof o == "object" && typeof c == "object") {
        if (JSON.stringify(o) !== JSON.stringify(c)) return !1;
      } else if (o !== c)
        return !1;
    }
  }
  return !0;
}
function ke(e, t) {
  if (e.type !== t.type)
    return { tree: t, changed: !0 };
  if (e.id !== t.id)
    return ke(e, { ...t, id: e.id });
  const r = !cl(e.props, t.props);
  let n = !1;
  const s = [], o = e.children || [], c = t.children || [], l = Math.max(o.length, c.length);
  for (let i = 0; i < l; i++) {
    const d = o[i], u = c[i];
    if (u === void 0) {
      n = !0;
      continue;
    }
    if (d === void 0) {
      n = !0, s.push(u);
      continue;
    }
    if (typeof u == "string")
      d !== u && (n = !0), s.push(u);
    else if (typeof d == "string")
      n = !0, s.push(u);
    else {
      const f = ke(d, u);
      f.changed && (n = !0), s.push(f.tree);
    }
  }
  return !r && !n ? { tree: e, changed: !1 } : {
    tree: {
      ...t,
      // Keep old props reference if unchanged
      props: r ? t.props : e.props,
      children: s
    },
    changed: !0
  };
}
function dl(e) {
  const [t, r] = x.useState({
    componentTree: e || null,
    appState: {}
  }), n = x.useCallback((i) => {
    r((d) => ({ ...d, componentTree: i }));
  }, []), s = x.useCallback(
    (i, d, u = "replace") => {
      r((f) => {
        if (!f.componentTree) return f;
        const m = Ne(f.componentTree, i, d, u);
        return { ...f, componentTree: m };
      });
    },
    []
  ), o = x.useCallback((i) => {
    r((d) => ({
      ...d,
      appState: { ...d.appState, ...i }
    }));
  }, []), c = x.useCallback(
    (i, d) => t.appState[i] ?? d,
    [t.appState]
  ), l = x.useCallback(
    (i) => {
      var d;
      switch (i.type) {
        case "update":
          if (i.targetId && i.operation) {
            let u = i.component || null;
            i.operation === "update_children" && i.children ? u = { type: "", id: "", props: {}, children: i.children } : i.operation === "update_props" && (i.props || i.children) ? (u = { type: "", id: "", props: i.props || {}, children: i.children || [] }, u.__hasChildren = "children" in i, i.props && "value" in i.props && i.targetId && Z.emit("refast:force-value-sync", {
              targetId: i.targetId,
              value: i.props.value
            })) : i.operation === "append_prop" && i.propName !== void 0 && (u = { type: "", id: "", props: { __propName: i.propName, __value: i.value }, children: [] }), s(
              i.targetId,
              u,
              i.operation
            );
          }
          break;
        case "state_update":
          i.state && o(i.state);
          break;
        case "navigate":
          if (i.path && typeof window < "u") {
            if (i.redirect)
              i.target ? window.open(i.path, i.target) : window.location.href = i.path;
            else if (window.history.pushState({}, "", i.path), Z.emit("refast:navigate", { path: i.path }), i.scroll_to != null) {
              const u = i.scroll_behavior ?? "instant";
              i.scroll_to === "top" ? window.scrollTo({ top: 0, behavior: u }) : (d = document.getElementById(i.scroll_to)) == null || d.scrollIntoView({ behavior: u });
            }
          }
          break;
        case "toast":
          typeof window < "u" && Z.emit("refast:toast", {
            message: i.message,
            variant: i.variant,
            duration: i.duration,
            description: i.description,
            position: i.position,
            dismissible: i.dismissible,
            close_button: i.close_button,
            invert: i.invert,
            icon: i.icon,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            action: i.action,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            cancel: i.cancel,
            id: i.id,
            component: i.component
          });
          break;
        case "refresh":
          typeof window < "u" && (i.component ? r((u) => {
            if (!u.componentTree)
              return { ...u, componentTree: i.component };
            const { tree: f, changed: m } = ke(u.componentTree, i.component);
            return m ? { ...u, componentTree: f } : u;
          }) : Z.emit("refast:refresh", {}));
          break;
      }
    },
    [s, o]
  );
  return {
    componentTree: t.componentTree,
    appState: t.appState,
    setComponentTree: n,
    updateComponent: s,
    setAppState: o,
    getAppState: c,
    handleUpdate: l
  };
}
function ul(e, t) {
  var n, s;
  const r = ((n = e.props) == null ? void 0 : n.on_change) ?? ((s = e.props) == null ? void 0 : s.onChange);
  if (r && typeof r == "object" && "saveProp" in r) {
    const o = r.saveProp;
    if (typeof o == "string")
      ie.set(o, t);
    else if (typeof o == "object" && o !== null) {
      const c = o;
      "value" in c && ie.set(c.value, t);
    }
  }
}
function Ne(e, t, r, n) {
  var l, i;
  if (e.id === t)
    switch (n) {
      case "replace":
        return r || e;
      case "update_props": {
        const d = (r == null ? void 0 : r.props) || {};
        "value" in d && ul(e, d.value);
        const u = {
          ...e,
          props: { ...e.props, ...d }
        };
        return r != null && r.__hasChildren && (u.children = (r == null ? void 0 : r.children) || []), u;
      }
      case "update_children":
        return {
          ...e,
          children: (r == null ? void 0 : r.children) || []
        };
      case "remove":
        return e;
      case "append":
        return r ? {
          ...e,
          children: [...e.children || [], r]
        } : e;
      case "prepend":
        return r ? {
          ...e,
          children: [r, ...e.children || []]
        } : e;
      case "append_prop": {
        const d = (l = r == null ? void 0 : r.props) == null ? void 0 : l.__propName, u = (i = r == null ? void 0 : r.props) == null ? void 0 : i.__value;
        if (!d) return e;
        const f = e.props[d];
        let m;
        return typeof f == "string" && typeof u == "string" ? m = f + u : Array.isArray(f) ? Array.isArray(u) ? m = [...f, ...u] : m = [...f, u] : f == null ? typeof u == "string" || Array.isArray(u) ? m = u : m = [u] : m = u, {
          ...e,
          props: { ...e.props, [d]: m }
        };
      }
      default:
        return e;
    }
  const s = e.children || [];
  let o = !1;
  const c = [];
  for (const d of s) {
    if (typeof d == "string") {
      c.push(d);
      continue;
    }
    if (n === "remove" && d.id === t) {
      o = !0;
      continue;
    }
    const u = Ne(d, t, r, n);
    u !== d && (o = !0), c.push(u);
  }
  return o ? {
    ...e,
    children: c
  } : e;
}
function fl(e, t) {
  if (e.id === t)
    return e;
  for (const r of e.children || [])
    if (typeof r != "string") {
      const n = fl(r, t);
      if (n)
        return n;
    }
  return null;
}
function pl(e, t, r = []) {
  if (e.id === t)
    return [...r, t];
  for (const n of e.children || [])
    if (typeof n != "string") {
      const s = pl(n, t, [...r, e.id]);
      if (s)
        return s;
    }
  return null;
}
function ml({ initialTree: e }) {
  const [t, r] = x.useState(e), n = oe();
  return x.useEffect(() => n.onUpdate((s) => {
    if (s.type === "update" && s.targetId && s.operation) {
      let o = s.component || null;
      s.operation === "update_children" && s.children ? o = { type: "", id: "", props: {}, children: s.children } : s.operation === "update_props" && (s.props || s.children) ? (o = { type: "", id: "", props: s.props || {}, children: s.children || [] }, o.__hasChildren = "children" in s) : s.operation === "append_prop" && s.propName !== void 0 && (o = { type: "", id: "", props: { __propName: s.propName, __value: s.value } }), r((c) => c && Ne(c, s.targetId, o, s.operation));
    }
  }), [n]), /* @__PURE__ */ a.jsx(se, { tree: t });
}
function gl({
  className: e,
  position: t = "bottom-right",
  richColors: r = !0,
  closeButton: n = !0,
  duration: s = 4e3,
  expand: o = !1,
  visibleToasts: c = 3,
  offset: l,
  gap: i = 14,
  dir: d = "auto",
  hotkey: u = ["altKey", "KeyT"],
  invert: f = !1
}) {
  const m = oe(), [p, g] = x.useState(() => typeof document < "u" && document.documentElement.classList.contains("dark") ? "dark" : "light");
  return x.useEffect(() => {
    if (typeof document > "u") return;
    const h = new MutationObserver((v) => {
      for (const y of v)
        if (y.type === "attributes" && y.attributeName === "class") {
          const S = document.documentElement.classList.contains("dark");
          g(S ? "dark" : "light");
        }
    });
    return h.observe(document.documentElement, {
      attributes: !0,
      attributeFilter: ["class"]
    }), () => h.disconnect();
  }, []), x.useEffect(() => Z.on("refast:toast", (h) => {
    const {
      message: v,
      component: y,
      variant: S = "default",
      description: N,
      duration: j,
      position: D,
      dismissible: I = !0,
      close_button: P,
      invert: T,
      action: A,
      cancel: O,
      id: $
    } = h, k = {
      description: N,
      duration: j,
      position: D,
      dismissible: I,
      closeButton: P,
      invert: T,
      id: $
    };
    if (A) {
      const H = fe(A.callback, m);
      k.action = {
        label: A.label,
        onClick: () => {
          H({}, []);
        }
      };
    }
    if (O) {
      const H = fe(O.callback, m);
      k.cancel = {
        label: O.label,
        onClick: () => {
          H({}, []);
        }
      };
    }
    Object.keys(k).forEach((H) => {
      k[H] === void 0 && delete k[H];
    });
    const L = y ? /* @__PURE__ */ a.jsx(ml, { initialTree: y }) : v || "";
    switch (S) {
      case "success":
        re.success(L, k);
        break;
      case "destructive":
      case "error":
        re.error(L, k);
        break;
      case "warning":
        re.warning(L, k);
        break;
      case "info":
        re.info(L, k);
        break;
      case "loading":
        re.loading(L, k);
        break;
      default:
        re(L, k);
        break;
    }
  }), [m]), /* @__PURE__ */ a.jsx(
    Lt,
    {
      className: e,
      position: t,
      richColors: r,
      closeButton: n,
      duration: s,
      expand: o,
      visibleToasts: c,
      theme: p,
      offset: l,
      gap: i,
      dir: d,
      hotkey: u,
      invert: f,
      toastOptions: {
        classNames: {
          toast: "group"
        }
      },
      style: {
        fontFamily: "inherit"
      }
    }
  );
}
function Il(e) {
  re.dismiss(e);
}
function Pl(e, t) {
  return re.promise(e, t), e;
}
function hl(e) {
  const {
    url: t,
    reconnect: r = !0,
    reconnectInterval: n = 3e3,
    maxReconnectAttempts: s = 5,
    onOpen: o,
    onClose: c,
    onError: l
  } = e, [i, d] = x.useState({
    socket: null,
    isConnected: !1,
    isConnecting: !1,
    reconnectAttempts: 0
  }), u = x.useRef(), f = x.useRef(null), m = x.useRef(0), p = x.useRef(!1), g = x.useRef(!1), h = x.useRef(o), v = x.useRef(c), y = x.useRef(l);
  x.useEffect(() => {
    h.current = o, v.current = c, y.current = l;
  }, [o, c, l]);
  const S = x.useCallback(() => {
    var D, I;
    if (p.current && !g.current && ((D = f.current) == null ? void 0 : D.readyState) !== WebSocket.OPEN && ((I = f.current) == null ? void 0 : I.readyState) !== WebSocket.CONNECTING) {
      f.current && (f.current.close(), f.current = null), g.current = !0, d((P) => ({ ...P, isConnecting: !0 }));
      try {
        const P = new WebSocket(t);
        f.current = P, P.onopen = () => {
          var T;
          if (g.current = !1, !p.current) {
            P.close();
            return;
          }
          m.current = 0, d({
            socket: P,
            isConnected: !0,
            isConnecting: !1,
            reconnectAttempts: 0
          }), (T = h.current) == null || T.call(h);
        }, P.onclose = () => {
          var T;
          if (g.current = !1, !!p.current && (d((A) => ({
            ...A,
            socket: null,
            isConnected: !1,
            isConnecting: !1
          })), (T = v.current) == null || T.call(v), r && m.current < s && p.current)) {
            const A = Math.min(n * Math.pow(2, m.current), 3e4);
            u.current = setTimeout(() => {
              p.current && (m.current += 1, d((O) => ({
                ...O,
                reconnectAttempts: m.current
              })), S());
            }, A);
          }
        }, P.onerror = (T) => {
          var A;
          (A = y.current) == null || A.call(y, T);
        };
      } catch (P) {
        g.current = !1, d((T) => ({
          ...T,
          isConnecting: !1
        })), console.error("WebSocket connection error:", P);
      }
    }
  }, [t, r, n, s]), N = x.useCallback(() => {
    u.current && (clearTimeout(u.current), u.current = void 0), f.current && (f.current.close(), f.current = null), g.current = !1, m.current = 0, d({
      socket: null,
      isConnected: !1,
      isConnecting: !1,
      reconnectAttempts: 0
    });
  }, []), j = x.useCallback((D) => {
    var I;
    return ((I = f.current) == null ? void 0 : I.readyState) === WebSocket.OPEN ? (f.current.send(JSON.stringify(D)), !0) : !1;
  }, []);
  return x.useEffect(() => {
    p.current = !0;
    const D = setTimeout(() => {
      p.current && S();
    }, 100);
    return () => {
      p.current = !1, clearTimeout(D), N();
    };
  }, [t]), {
    socket: i.socket,
    isConnected: i.isConnected,
    isConnecting: i.isConnecting,
    reconnectAttempts: i.reconnectAttempts,
    connect: S,
    disconnect: N,
    send: j
  };
}
function bl(e = "/ws") {
  return typeof window > "u" ? `ws://localhost${e}` : `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}${e}`;
}
class Rl {
  constructor(t) {
    V(this, "socket", null);
    V(this, "url");
    V(this, "reconnect");
    V(this, "reconnectInterval");
    V(this, "maxReconnectAttempts");
    V(this, "reconnectAttempts", 0);
    V(this, "reconnectTimeout", null);
    V(this, "messageHandlers", /* @__PURE__ */ new Set());
    V(this, "connectionHandlers", /* @__PURE__ */ new Set());
    this.url = t.url, this.reconnect = t.reconnect ?? !0, this.reconnectInterval = t.reconnectInterval ?? 3e3, this.maxReconnectAttempts = t.maxReconnectAttempts ?? 10;
  }
  connect() {
    this.socket && this.socket.close(), this.socket = new WebSocket(this.url), this.socket.onopen = () => {
      this.reconnectAttempts = 0, this.notifyConnectionChange(!0);
    }, this.socket.onclose = () => {
      this.notifyConnectionChange(!1), this.reconnect && this.reconnectAttempts < this.maxReconnectAttempts && (this.reconnectTimeout = setTimeout(() => {
        this.reconnectAttempts++, this.connect();
      }, this.reconnectInterval));
    }, this.socket.onmessage = (t) => {
      try {
        const r = JSON.parse(t.data);
        this.messageHandlers.forEach((n) => n(r));
      } catch (r) {
        console.error("Error parsing WebSocket message:", r);
      }
    };
  }
  disconnect() {
    this.reconnectTimeout && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null), this.socket && (this.socket.close(), this.socket = null), this.reconnectAttempts = 0;
  }
  send(t) {
    var r;
    return ((r = this.socket) == null ? void 0 : r.readyState) === WebSocket.OPEN ? (this.socket.send(JSON.stringify(t)), !0) : !1;
  }
  onMessage(t) {
    return this.messageHandlers.add(t), () => this.messageHandlers.delete(t);
  }
  onConnectionChange(t) {
    return this.connectionHandlers.add(t), () => this.connectionHandlers.delete(t);
  }
  notifyConnectionChange(t) {
    this.connectionHandlers.forEach((r) => r(t));
  }
  get isConnected() {
    var t;
    return ((t = this.socket) == null ? void 0 : t.readyState) === WebSocket.OPEN;
  }
}
function xl({ initialTree: e, wsUrl: t, className: r }) {
  const n = x.useMemo(() => e || window.__REFAST_INITIAL_DATA__ || null, [e]), s = x.useMemo(() => window.__REFAST_CONFIG__ || {}, []), { socket: o, isConnected: c, isConnecting: l, reconnectAttempts: i } = hl({
    url: t || s.wsUrl || bl("/ws"),
    reconnect: !0,
    maxReconnectAttempts: 10,
    onOpen: () => {
    },
    onClose: () => {
    }
  }), { componentTree: d, setComponentTree: u, updateComponent: f, handleUpdate: m } = dl(n || void 0);
  x.useEffect(() => {
    if (o) {
      ne.setWebSocket(o);
      const h = (v) => {
        try {
          const y = JSON.parse(v.data);
          y.type === "store_ready" && ne.handleStoreReady(), y.type === "store_update" && y.updates && ne.handleUpdates(y.updates), y.type === "page_render" && y.component && u(y.component);
        } catch {
        }
      };
      return o.addEventListener("message", h), () => {
        o.removeEventListener("message", h), ne.reset();
      };
    }
    return () => {
      ne.reset();
    };
  }, [o, u]);
  const p = x.useCallback(async () => {
    try {
      const h = window.location.pathname + window.location.search, v = await fetch(`/api/page?path=${encodeURIComponent(h)}`);
      if (v.ok) {
        const y = await v.json();
        y.component && u(y.component);
      }
    } catch (h) {
      console.error("[Refast] Failed to fetch page:", h);
    }
  }, [u]);
  x.useEffect(() => {
    const h = () => {
      o && o.readyState === WebSocket.OPEN && o.send(
        JSON.stringify({
          type: "navigate",
          path: window.location.pathname + window.location.search
        })
      );
    };
    return window.addEventListener("popstate", h), () => {
      window.removeEventListener("popstate", h);
    };
  }, [o]), x.useEffect(() => Z.on("refast:refresh", () => p()), [p]);
  const g = x.useCallback(
    (h, v, y) => {
      f(h, v, y || "replace");
    },
    [f]
  );
  return x.useEffect(() => {
    if (d) {
      const h = document.getElementById("refast-loading-overlay");
      h && (h.style.display = "none");
    }
  }, [d]), d ? /* @__PURE__ */ a.jsx(
    vo,
    {
      websocket: o,
      onComponentUpdate: g,
      children: /* @__PURE__ */ a.jsx(
        yl,
        {
          tree: d,
          isConnected: c,
          isConnecting: l,
          reconnectAttempts: i,
          onUpdate: m,
          className: r
        }
      )
    }
  ) : null;
}
function yl({
  tree: e,
  isConnected: t,
  isConnecting: r,
  reconnectAttempts: n,
  onUpdate: s,
  className: o
}) {
  const { onUpdate: c } = oe();
  return x.useEffect(() => c(s), [c, s]), /* @__PURE__ */ a.jsxs(
    "div",
    {
      className: `refast-app ${o || ""}`,
      "data-connected": t,
      "data-connecting": r,
      "data-reconnect-attempts": n,
      children: [
        /* @__PURE__ */ a.jsx(se, { tree: e }),
        /* @__PURE__ */ a.jsx(gl, {})
      ]
    }
  );
}
function vl() {
  const e = window.__REFAST_PRELOADED_FEATURES__;
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : [];
}
function wl() {
  const e = window.__REFAST_STARTUP_FEATURES__;
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : vl();
}
function Cl() {
  const e = window.__REFAST_LAZY_FEATURES__;
  return Array.isArray(e) ? e.filter((t) => typeof t == "string") : w.listChunks();
}
async function kl() {
  const e = wl();
  if (e.length === 0)
    return;
  const t = new Set(w.listChunks()), r = e.filter((n) => t.has(n));
  if (r.length !== 0)
    try {
      await w.preloadChunks(r);
    } catch (n) {
      console.error("Failed to preload configured feature chunks:", n);
    }
}
async function Mt() {
  const e = document.getElementById("refast-root");
  e && (w.configureLazyFeatures(Cl()), await kl(), Wr(e).render(C.createElement(xl)));
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", () => {
  Mt();
}) : Mt();
window.RefastClient = {
  componentRegistry: w,
  React: C,
  ReactDOM: It,
  version: "0.1.0"
};
window.React = C;
window.ReactDOM = It;
window.dispatchEvent(new CustomEvent("refast:ready"));
export {
  bi as $,
  Yt as A,
  Ht as B,
  se as C,
  Qt as D,
  er as E,
  Mo as F,
  Lo as G,
  Vt as H,
  pe as I,
  si as J,
  rr as K,
  Xt as L,
  nr as M,
  oi as N,
  li as O,
  Jt as P,
  ci as Q,
  xl as R,
  Ho as S,
  No as T,
  di as U,
  gl as V,
  Il as W,
  Pl as X,
  mi as Y,
  gi as Z,
  hi as _,
  Y as a,
  xi as a0,
  yi as a1,
  wi as a2,
  Ci as a3,
  ki as a4,
  vo as a5,
  oe as a6,
  Ml as a7,
  El as a8,
  hl as a9,
  bl as aa,
  Rl as ab,
  dl as ac,
  fl as ad,
  pl as ae,
  wo as af,
  Co as ag,
  Tl as ah,
  wt as ai,
  ko as aj,
  Ll as b,
  b as c,
  w as d,
  So as e,
  Eo as f,
  To as g,
  Io as h,
  Po as i,
  Gt as j,
  Ao as k,
  Do as l,
  Fo as m,
  Bo as n,
  _o as o,
  zo as p,
  Oo as q,
  Z as r,
  $o as s,
  Go as t,
  Wo as u,
  Uo as v,
  Ko as w,
  ti as x,
  qt as y,
  Zt as z
};
