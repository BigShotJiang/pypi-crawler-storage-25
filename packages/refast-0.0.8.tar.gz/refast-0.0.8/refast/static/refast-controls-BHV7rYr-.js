import { ay as e, ah as s, cI as H, cJ as ee, cK as te, cL as q, cM as re, cN as ne, cO as se, cP as oe, cQ as ae, cR as ie, cS as de } from "./refast-vendor-CQOdd5X6.js";
import { c as r, r as J, I as F, a as K, b as Q, B as le } from "./refast-index-9fBfd4aX.js";
import { cR as ce, cQ as ue, cO as fe } from "./refast-icons-BtQPpLxJ.js";
function be({
  id: n,
  className: m,
  checked: a,
  defaultChecked: l,
  disabled: N = !1,
  name: j,
  onCheckedChange: i,
  "data-refast-id": p
}) {
  return /* @__PURE__ */ e.jsx(
    ie,
    {
      id: n,
      checked: a,
      defaultChecked: l,
      disabled: N,
      name: j,
      onCheckedChange: i,
      className: r(
        "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent",
        "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50",
        "data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
        m
      ),
      "data-refast-id": p,
      children: /* @__PURE__ */ e.jsx(
        de,
        {
          className: r(
            "pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform",
            "data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0"
          )
        }
      )
    }
  );
}
function ve({
  id: n,
  className: m,
  label: a,
  description: l,
  showValue: N = !1,
  required: j = !1,
  error: i,
  value: p,
  defaultValue: z = [0],
  min: A = 0,
  max: h = 100,
  step: w = 1,
  disabled: T = !1,
  orientation: y = "horizontal",
  onValueChange: S,
  onValueCommit: c,
  "data-refast-id": D
}) {
  const k = (d, v) => Array.isArray(d) ? d.length > 0 ? d : v : typeof d == "number" && Number.isFinite(d) ? [d] : v, E = s.useMemo(
    () => k(z, [0]),
    [z]
  ), u = s.useMemo(
    () => p === void 0 ? void 0 : k(p, E),
    [p, E]
  ), b = p !== void 0, [o, x] = s.useState(() => u ?? E);
  s.useEffect(() => {
    b && u !== void 0 && x(u);
  }, [b, u]), s.useEffect(() => {
    b || x(E);
  }, [b, E]);
  const _ = b ? u ?? E : o, C = typeof a == "string" && a.trim().length > 0, O = s.useCallback(
    (d) => {
      b || x(d), S == null || S(d);
    },
    [b, S]
  ), M = s.useCallback(
    (d) => {
      b || x(d), c == null || c(d);
    },
    [b, c]
  ), B = (d) => {
    if (!Number.isFinite(d))
      return "";
    const v = Number(w).toString(), P = v.includes(".") ? v.split(".")[1].length : 0;
    return P > 0 ? d.toFixed(P) : d.toString();
  }, $ = ((d) => {
    if (d.length === 0)
      return "";
    if (d.length === 1)
      return B(d[0]);
    const v = Math.min(...d), P = Math.max(...d);
    return `${B(v)} - ${B(P)}`;
  })(_), g = N ? /* @__PURE__ */ e.jsx(
    "span",
    {
      className: "text-sm text-muted-foreground tabular-nums whitespace-nowrap",
      "data-slider-value-display": !0,
      "data-slider-value-position": C ? "label" : "inline",
      children: $
    }
  ) : null, R = /* @__PURE__ */ e.jsxs(
    ne,
    {
      id: n,
      value: _,
      defaultValue: b ? void 0 : E,
      min: A,
      max: h,
      step: w,
      disabled: T,
      orientation: y,
      onValueChange: O,
      onValueCommit: M,
      className: r(
        "relative flex w-full touch-none select-none items-center",
        y === "vertical" && "flex-col h-full min-h-48 w-auto",
        m
      ),
      children: [
        /* @__PURE__ */ e.jsx(
          se,
          {
            className: r(
              "relative grow overflow-hidden rounded-full bg-secondary",
              y === "horizontal" ? "h-2 w-full" : "h-full w-2"
            ),
            children: /* @__PURE__ */ e.jsx(
              oe,
              {
                className: r(
                  "absolute bg-primary",
                  y === "horizontal" ? "h-full" : "w-full"
                )
              }
            )
          }
        ),
        _.map((d, v) => /* @__PURE__ */ e.jsx(
          ae,
          {
            className: r(
              "block h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background",
              "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
              "disabled:pointer-events-none disabled:opacity-50"
            )
          },
          v
        ))
      ]
    }
  ), t = N && !C ? /* @__PURE__ */ e.jsxs(
    "div",
    {
      className: r(
        "flex gap-3",
        y === "vertical" ? "flex-row items-start h-full" : "flex-row items-center"
      ),
      children: [
        R,
        g
      ]
    }
  ) : R;
  return a || l || i ? /* @__PURE__ */ e.jsx(
    F,
    {
      id: n,
      label: a,
      labelEnd: C ? g : void 0,
      description: l,
      required: j,
      error: i,
      "data-refast-id": D,
      children: t
    }
  ) : /* @__PURE__ */ e.jsx(
    "div",
    {
      className: r(y === "vertical" && "h-full"),
      "data-refast-id": D,
      children: t
    }
  );
}
const U = {
  default: "bg-transparent",
  outline: "border border-input bg-transparent hover:bg-accent hover:text-accent-foreground"
}, X = {
  sm: "h-9 px-2.5",
  md: "h-10 px-3",
  lg: "h-11 px-5"
};
function we({
  id: n,
  className: m,
  label: a,
  icon: l,
  pressed: N,
  defaultPressed: j,
  disabled: i = !1,
  variant: p = "default",
  size: z = "md",
  onPressedChange: A,
  children: h,
  "data-refast-id": w
}) {
  return /* @__PURE__ */ e.jsx(
    re,
    {
      id: n,
      pressed: N,
      defaultPressed: j,
      disabled: i,
      onPressedChange: A,
      className: r(
        "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-2",
        "focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
        "data-[state=on]:bg-accent data-[state=on]:text-accent-foreground",
        U[p],
        X[z],
        m
      ),
      "data-refast-id": w,
      children: h || l && /* @__PURE__ */ e.jsx(K, { name: l, size: z === "lg" ? 20 : z === "sm" ? 14 : 16 }) || a
    }
  );
}
function ye({
  id: n,
  className: m,
  type: a = "single",
  value: l,
  defaultValue: N,
  disabled: j = !1,
  variant: i = "default",
  size: p = "md",
  onValueChange: z,
  children: A,
  "data-refast-id": h
}) {
  const w = l, T = N;
  if (a === "multiple") {
    const y = (S) => {
      if (!z) return;
      const c = /* @__PURE__ */ new Set();
      s.Children.forEach(A, (k) => {
        var b, o;
        if (!s.isValidElement(k)) return;
        const E = k.props, u = ((o = (b = E.tree) == null ? void 0 : b.props) == null ? void 0 : o.value) || E.value;
        u && c.add(u);
      }), S.forEach((k) => c.add(k));
      const D = {};
      c.forEach((k) => {
        D[k] = S.includes(k);
      }), z(D);
    };
    return /* @__PURE__ */ e.jsx(
      q,
      {
        id: n,
        type: "multiple",
        value: w,
        defaultValue: T,
        disabled: j,
        onValueChange: y,
        className: r(
          "inline-flex items-center justify-center gap-1",
          m
        ),
        "data-refast-id": h,
        children: s.Children.map(A, (S) => s.isValidElement(S) ? s.cloneElement(S, {
          variant: i,
          size: p
        }) : S)
      }
    );
  }
  return /* @__PURE__ */ e.jsx(
    q,
    {
      id: n,
      type: "single",
      value: w,
      defaultValue: T,
      disabled: j,
      onValueChange: z,
      className: r(
        "inline-flex items-center justify-center gap-1",
        m
      ),
      "data-refast-id": h,
      children: s.Children.map(A, (y) => s.isValidElement(y) ? s.cloneElement(y, {
        variant: i,
        size: p
      }) : y)
    }
  );
}
function je({
  id: n,
  className: m,
  label: a,
  icon: l,
  value: N,
  disabled: j = !1,
  variant: i = "default",
  size: p = "md",
  children: z,
  "data-refast-id": A
}) {
  return /* @__PURE__ */ e.jsx(
    te,
    {
      id: n,
      value: N,
      disabled: j,
      className: r(
        "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors",
        "hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-2",
        "focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
        "data-[state=on]:bg-accent data-[state=on]:text-accent-foreground",
        U[i],
        X[p],
        m
      ),
      "data-refast-id": A,
      children: z || l && /* @__PURE__ */ e.jsx(K, { name: l, size: p === "lg" ? 20 : p === "sm" ? 14 : 16 }) || a
    }
  );
}
function V(n) {
  if (n) {
    if (n instanceof Date) return n;
    if (typeof n == "string") {
      const m = new Date(n);
      return isNaN(m.getTime()) ? void 0 : m;
    }
  }
}
function me(n) {
  if (n) {
    if (Array.isArray(n))
      return n.length === 0 ? void 0 : {
        from: V(n[0]),
        to: V(n[1])
      };
    if (typeof n == "object" && "from" in n)
      return {
        from: V(n.from),
        to: V(n.to)
      };
  }
}
function Y(n) {
  if (!(!n || !Array.isArray(n)))
    return n.map((m) => V(m)).filter((m) => m !== void 0);
}
function G({
  id: n,
  className: m,
  classNames: a,
  mode: l = "single",
  showOutsideDays: N = !0,
  captionLayout: j = "label",
  buttonVariant: i = "ghost",
  formatters: p,
  components: z,
  selected: A,
  defaultMonth: h,
  disabled: w,
  minDate: T,
  maxDate: y,
  numberOfMonths: S,
  onSelect: c,
  onMonthChange: D,
  showWeekNumber: k,
  ...E
}) {
  const u = H(), b = s.useMemo(() => l === "range" ? me(
    A
  ) : l === "multiple" ? Y(A) : V(A), [l, A]), [o, x] = s.useState(b);
  s.useEffect(() => {
    x(b);
  }, [b]);
  const _ = s.useMemo(() => V(h), [h]), C = s.useMemo(() => V(T), [T]), O = s.useMemo(() => V(y), [y]), M = s.useMemo(() => {
    const g = [];
    return C && g.push({ before: C }), O && g.push({ after: O }), typeof w == "function" ? g.push(w) : w === !0 && g.push(() => !0), g.length > 0 ? g : void 0;
  }, [C, O, w]), B = s.useCallback((g) => {
    if (!g) {
      if (x(void 0), !c) return;
      c(void 0);
      return;
    }
    if (l === "range" && typeof g == "object" && "from" in g) {
      const R = g;
      if (x(R), !c) return;
      c({
        from: R.from,
        to: R.to
      });
      return;
    }
    if (l === "multiple" && Array.isArray(g)) {
      if (x(g), !c) return;
      c(g);
      return;
    }
    x(g), c && c(g);
  }, [l, c]), L = s.useCallback((g) => {
    D && D(g);
  }, [D]), $ = s.useMemo(() => l === "range" ? {
    mode: "range",
    selected: o,
    onSelect: B
  } : l === "multiple" ? {
    mode: "multiple",
    selected: o,
    onSelect: B
  } : {
    mode: "single",
    selected: o,
    onSelect: B
  }, [l, o, B]);
  return /* @__PURE__ */ e.jsx(
    ee,
    {
      showOutsideDays: N,
      className: r(
        "bg-background group/calendar p-3 [--cell-size:2.5rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        m
      ),
      captionLayout: j,
      defaultMonth: _,
      disabled: M,
      numberOfMonths: S,
      onMonthChange: L,
      formatters: {
        formatMonthDropdown: (g) => g.toLocaleString("default", { month: "short" }),
        ...p
      },
      classNames: {
        root: r("w-fit", u.root),
        months: r(
          "flex gap-4 flex-col md:flex-row relative",
          u.months
        ),
        month: r("flex flex-col w-full gap-4", u.month),
        nav: r(
          "flex items-center gap-1 w-full absolute top-0 inset-x-0 justify-between",
          u.nav
        ),
        button_previous: r(
          Q({ variant: i }),
          "size-[var(--cell-size)] aria-disabled:opacity-50 p-0 select-none",
          u.button_previous
        ),
        button_next: r(
          Q({ variant: i }),
          "size-[var(--cell-size)] aria-disabled:opacity-50 p-0 select-none",
          u.button_next
        ),
        month_caption: r(
          "flex items-center justify-center h-[var(--cell-size)] w-full px-[var(--cell-size)]",
          u.month_caption
        ),
        dropdowns: r(
          "w-full flex items-center text-sm font-medium justify-center h-[var(--cell-size)] gap-2",
          u.dropdowns
        ),
        dropdown_root: r(
          "relative",
          u.dropdown_root
        ),
        dropdown: r(
          "absolute inset-0 cursor-pointer opacity-0 z-10 w-full h-full",
          u.dropdown
        ),
        months_dropdown: r(
          "inline-flex items-center justify-center gap-1 rounded-md border border-input bg-background px-3 py-1.5 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
        ),
        years_dropdown: r(
          "inline-flex items-center justify-center gap-1 rounded-md border border-input bg-background px-3 py-1.5 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
        ),
        caption_label: r(
          "select-none font-medium",
          j === "label" ? "text-sm" : "rounded-md px-2 flex items-center gap-1 text-sm h-8 [&>svg]:text-muted-foreground [&>svg]:size-3.5",
          u.caption_label
        ),
        table: "w-full border-collapse",
        weekdays: r("flex", u.weekdays),
        weekday: r(
          "text-muted-foreground rounded-md flex-1 font-normal text-sm select-none w-[var(--cell-size)] h-[var(--cell-size)] flex items-center justify-center",
          u.weekday
        ),
        week: r("flex w-full mt-2", u.week),
        week_number_header: r(
          "select-none w-[var(--cell-size)]",
          u.week_number_header
        ),
        week_number: r(
          "text-sm select-none text-muted-foreground",
          u.week_number
        ),
        day: r(
          "relative w-[var(--cell-size)] h-[var(--cell-size)] p-0 text-center [&:last-child[data-selected=true]_button]:rounded-r-md group/day select-none",
          k ? "[&:nth-child(2)[data-selected=true]_button]:rounded-l-md" : "[&:first-child[data-selected=true]_button]:rounded-l-md",
          u.day
        ),
        range_start: r(
          "rounded-l-md bg-accent",
          u.range_start
        ),
        range_middle: r("rounded-none", u.range_middle),
        range_end: r("rounded-r-md bg-accent", u.range_end),
        today: r(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          u.today
        ),
        outside: r(
          "text-muted-foreground aria-selected:text-muted-foreground",
          u.outside
        ),
        disabled: r(
          "text-muted-foreground opacity-50",
          u.disabled
        ),
        hidden: r("invisible", u.hidden),
        ...a
      },
      components: {
        Root: ({ className: g, rootRef: R, ...t }) => /* @__PURE__ */ e.jsx(
          "div",
          {
            "data-slot": "calendar",
            ref: R,
            className: r(g),
            ...t
          }
        ),
        Chevron: ({ className: g, orientation: R, ...t }) => R === "left" ? /* @__PURE__ */ e.jsx(ce, { className: r("size-4", g), ...t }) : R === "right" ? /* @__PURE__ */ e.jsx(
          ue,
          {
            className: r("size-4", g),
            ...t
          }
        ) : /* @__PURE__ */ e.jsx(fe, { className: r("size-4", g), ...t }),
        DayButton: ge,
        WeekNumber: ({ children: g, ...R }) => /* @__PURE__ */ e.jsx("td", { ...R, children: /* @__PURE__ */ e.jsx("div", { className: "flex size-[var(--cell-size)] items-center justify-center text-center", children: g }) }),
        ...z
      },
      ...$,
      ...E
    }
  );
}
function ge({
  className: n,
  day: m,
  modifiers: a,
  ...l
}) {
  const N = H(), j = s.useRef(null);
  return s.useEffect(() => {
    var i;
    a.focused && ((i = j.current) == null || i.focus());
  }, [a.focused]), /* @__PURE__ */ e.jsx(
    le,
    {
      ref: j,
      variant: "ghost",
      size: "md",
      "data-day": m.date.toLocaleDateString(),
      "data-selected-single": a.selected && !a.range_start && !a.range_end && !a.range_middle,
      "data-range-start": a.range_start,
      "data-range-end": a.range_end,
      "data-range-middle": a.range_middle,
      className: r(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground",
        "data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground",
        "data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground",
        "data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground",
        "group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50",
        "dark:hover:text-accent-foreground",
        "flex size-[var(--cell-size)] items-center justify-center",
        "leading-none font-normal text-sm",
        "group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px]",
        "data-[range-end=true]:rounded-md data-[range-end=true]:rounded-r-md",
        "data-[range-middle=true]:rounded-none",
        "data-[range-start=true]:rounded-md data-[range-start=true]:rounded-l-md",
        N.day,
        n
      ),
      ...l
    }
  );
}
function Z(n, m) {
  if (!n || typeof window > "u")
    return "bottom";
  const a = n.getBoundingClientRect(), l = window.innerHeight - a.bottom, N = a.top;
  return l < m && N > l ? "top" : "bottom";
}
function ke({
  id: n,
  className: m,
  label: a,
  description: l,
  required: N = !1,
  error: j,
  value: i,
  placeholder: p = "Pick a date",
  disabled: z = !1,
  format: A = "PPP",
  mode: h = "single",
  captionLayout: w = "label",
  minDate: T,
  maxDate: y,
  numberOfMonths: S,
  onChange: c,
  "data-refast-id": D
}) {
  const [k, E] = s.useState(!1), [u, b] = s.useState("bottom"), o = s.useRef(null), x = s.useRef(null), _ = s.useMemo(() => {
    if (h === "range")
      return i && typeof i == "object" && ("from" in i || "to" in i) ? {
        from: i.from ? new Date(i.from) : void 0,
        to: i.to ? new Date(i.to) : void 0
      } : void 0;
    if (h === "multiple")
      return i ? Array.isArray(i) ? Y(i) || [] : [] : [];
    if (!i) return;
    if (typeof i == "string") {
      const f = new Date(i);
      return isNaN(f.getTime()) ? void 0 : f;
    }
  }, [h, i]), [C, O] = s.useState(
    h === "single" ? _ : void 0
  ), [M, B] = s.useState(
    h === "range" ? _ : void 0
  ), [L, $] = s.useState(
    h === "multiple" ? _ || [] : []
  );
  s.useEffect(() => {
    h === "single" ? O(_) : h === "range" ? B(_) : $(_ || []);
  }, [h, _]), s.useEffect(() => {
    !k && o.current !== null && (c && c(o.current), o.current = null);
  }, [k, c]), s.useEffect(() => {
    const f = (W) => {
      x.current && !x.current.contains(W.target) && E(!1);
    }, I = (W) => {
      W.key === "Escape" && E(!1);
    };
    return k && (document.addEventListener("mousedown", f), document.addEventListener("keydown", I)), () => {
      document.removeEventListener("mousedown", f), document.removeEventListener("keydown", I);
    };
  }, [k]), s.useEffect(() => {
    if (!k) return;
    const f = () => {
      const I = h === "range" ? 420 : 360;
      b(Z(x.current, I));
    };
    return f(), window.addEventListener("resize", f), window.addEventListener("scroll", f, !0), () => {
      window.removeEventListener("resize", f), window.removeEventListener("scroll", f, !0);
    };
  }, [k, h]);
  const g = s.useMemo(() => h === "range" ? M != null && M.from ? M.to ? `${M.from.toLocaleDateString()} - ${M.to.toLocaleDateString()}` : M.from.toLocaleDateString() : p : h === "multiple" ? L.length ? L.length <= 2 ? L.map((f) => f.toLocaleDateString()).join(", ") : `${L[0].toLocaleDateString()}, ${L[1].toLocaleDateString()} +${L.length - 2} more` : p : C ? C.toLocaleDateString() : p, [h, C, M, L, p]), R = (f) => {
    O(f), E(!1), c && c(f ? f.toISOString() : void 0);
  }, t = (f) => {
    var I, W;
    B(f), f != null && f.from && (f != null && f.to) && f.from.getTime() !== f.to.getTime() && E(!1), c && c(f ? {
      from: (I = f.from) == null ? void 0 : I.toISOString(),
      to: (W = f.to) == null ? void 0 : W.toISOString()
    } : void 0);
  }, d = (f) => {
    const I = f || [];
    $(I), o.current = I.map((W) => W.toISOString());
  }, v = h === "range" ? !!(M != null && M.from) : h === "multiple" ? L.length > 0 : !!C, P = /* @__PURE__ */ e.jsxs("div", { ref: x, className: r("relative", m), children: [
    /* @__PURE__ */ e.jsxs(
      "button",
      {
        id: n,
        type: "button",
        disabled: z,
        onClick: () => E(!k),
        className: r(
          "flex h-10 w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
          "ring-offset-background placeholder:text-muted-foreground",
          "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          j ? "border-destructive" : "border-input",
          !v && "text-muted-foreground"
        ),
        children: [
          /* @__PURE__ */ e.jsx("span", { className: "truncate", children: g }),
          /* @__PURE__ */ e.jsxs(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              width: "16",
              height: "16",
              viewBox: "0 0 24 24",
              fill: "none",
              stroke: "currentColor",
              strokeWidth: "2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              className: "ml-2 h-4 w-4 shrink-0 opacity-50",
              children: [
                /* @__PURE__ */ e.jsx("rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", ry: "2" }),
                /* @__PURE__ */ e.jsx("line", { x1: "16", x2: "16", y1: "2", y2: "6" }),
                /* @__PURE__ */ e.jsx("line", { x1: "8", x2: "8", y1: "2", y2: "6" }),
                /* @__PURE__ */ e.jsx("line", { x1: "3", x2: "21", y1: "10", y2: "10" })
              ]
            }
          )
        ]
      }
    ),
    k && /* @__PURE__ */ e.jsx(
      "div",
      {
        className: r(
          "absolute left-0 z-50 rounded-md border bg-popover p-0 text-popover-foreground shadow-md",
          u === "top" ? "bottom-full mb-2" : "top-full mt-2"
        ),
        children: h === "range" ? /* @__PURE__ */ e.jsx(
          G,
          {
            mode: "range",
            captionLayout: w,
            selected: M,
            onSelect: (f) => t(f),
            minDate: T,
            maxDate: y,
            numberOfMonths: S || 2
          }
        ) : h === "multiple" ? /* @__PURE__ */ e.jsx(
          G,
          {
            mode: "multiple",
            captionLayout: w,
            selected: L,
            onSelect: (f) => d(f),
            minDate: T,
            maxDate: y,
            numberOfMonths: S
          }
        ) : /* @__PURE__ */ e.jsx(
          G,
          {
            mode: "single",
            captionLayout: w,
            selected: C,
            onSelect: (f) => R(f),
            minDate: T,
            maxDate: y
          }
        )
      }
    )
  ] });
  return a || l || j ? /* @__PURE__ */ e.jsx(
    F,
    {
      id: n,
      label: a,
      description: l,
      required: N,
      error: j,
      "data-refast-id": D,
      children: P
    }
  ) : /* @__PURE__ */ e.jsx("div", { "data-refast-id": D, children: P });
}
function Ne({
  id: n,
  className: m,
  label: a,
  description: l,
  required: N = !1,
  error: j,
  options: i = [],
  value: p,
  placeholder: z = "Select...",
  searchPlaceholder: A = "Search...",
  emptyText: h = "No results found.",
  multiselect: w = !1,
  disabled: T = !1,
  onSelect: y,
  "data-refast-id": S
}) {
  const [c, D] = s.useState(!1), [k, E] = s.useState(""), [u, b] = s.useState("bottom"), [o, x] = s.useState(
    p !== void 0 ? p : w ? [] : ""
  ), _ = s.useRef(null), C = s.useRef(null);
  s.useEffect(() => {
    c ? requestAnimationFrame(() => {
      var t;
      return (t = C.current) == null ? void 0 : t.focus();
    }) : E("");
  }, [c]), s.useEffect(() => {
    const t = (v) => {
      _.current && !_.current.contains(v.target) && D(!1);
    }, d = (v) => {
      v.key === "Escape" && D(!1);
    };
    return c && (document.addEventListener("mousedown", t), document.addEventListener("keydown", d)), () => {
      document.removeEventListener("mousedown", t), document.removeEventListener("keydown", d);
    };
  }, [c]), s.useEffect(() => {
    p !== void 0 && x(p);
  }, [p]), s.useEffect(() => {
    if (!c) return;
    const t = () => {
      b(Z(_.current, 340));
    };
    return t(), window.addEventListener("resize", t), window.addEventListener("scroll", t, !0), () => {
      window.removeEventListener("resize", t), window.removeEventListener("scroll", t, !0);
    };
  }, [c]), s.useEffect(() => J.on("refast:force-value-sync", ({ targetId: t, value: d }) => {
    t === n && d !== void 0 && x(d);
  }), [n]), s.useEffect(() => {
    w && !Array.isArray(o) && x(o ? [o] : []);
  }, [w]);
  const O = k.trim().toLowerCase(), M = i.filter((t) => !t || typeof t.label != "string" ? !1 : O ? [t.label, t.description, t.searchText, t.color].filter((v) => typeof v == "string" && v.length > 0).join(" ").toLowerCase().includes(O) : !0), B = (t) => w && Array.isArray(o) ? o.includes(t) : o === t, L = !w && typeof o == "string" ? i.find((t) => t.value === o) : void 0, $ = (t) => {
    const d = i.find((v) => v.value === t);
    if (!(d != null && d.disabled))
      if (w) {
        const v = Array.isArray(o) ? o : [];
        let P;
        v.includes(t) ? P = v.filter((f) => f !== t) : P = [...v, t], x(P), y && y(P);
      } else
        x(t), y && y(t), D(!1);
  }, g = (t, d) => {
    if (t.stopPropagation(), w && Array.isArray(o)) {
      const v = o.filter((P) => P !== d);
      x(v), y && y(v);
    }
  }, R = /* @__PURE__ */ e.jsxs(
    "div",
    {
      ref: _,
      className: r("relative", m),
      children: [
        /* @__PURE__ */ e.jsxs(
          "button",
          {
            id: n,
            type: "button",
            disabled: T,
            onClick: () => D(!c),
            className: r(
              "flex min-h-[2.5rem] w-full items-center justify-between rounded-md border bg-background px-3 py-2 text-sm",
              "ring-offset-background placeholder:text-muted-foreground",
              "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
              "disabled:cursor-not-allowed disabled:opacity-50",
              j ? "border-destructive" : "border-input"
            ),
            children: [
              w && Array.isArray(o) && o.length > 0 ? /* @__PURE__ */ e.jsx("div", { className: "flex flex-wrap gap-1", children: o.map((t) => {
                var v;
                const d = ((v = i.find((P) => P.value === t)) == null ? void 0 : v.label) || t;
                return /* @__PURE__ */ e.jsxs(
                  "div",
                  {
                    className: "flex items-center gap-1 rounded bg-secondary px-1.5 py-0.5 text-xs font-medium text-secondary-foreground",
                    children: [
                      d,
                      /* @__PURE__ */ e.jsx(
                        "div",
                        {
                          role: "button",
                          className: "ml-1 cursor-pointer rounded-full p-0.5 hover:bg-secondary-foreground/20",
                          onClick: (P) => g(P, t),
                          children: /* @__PURE__ */ e.jsxs(
                            "svg",
                            {
                              xmlns: "http://www.w3.org/2000/svg",
                              width: "12",
                              height: "12",
                              viewBox: "0 0 24 24",
                              fill: "none",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              children: [
                                /* @__PURE__ */ e.jsx("path", { d: "M18 6 6 18" }),
                                /* @__PURE__ */ e.jsx("path", { d: "m6 6 12 12" })
                              ]
                            }
                          )
                        }
                      )
                    ]
                  },
                  t
                );
              }) }) : /* @__PURE__ */ e.jsxs("span", { className: r("flex min-w-0 items-center gap-3", !L && "text-muted-foreground"), children: [
                L != null && L.icon ? /* @__PURE__ */ e.jsx(
                  K,
                  {
                    name: L.icon,
                    className: "h-4 w-4 shrink-0",
                    color: L.color
                  }
                ) : null,
                /* @__PURE__ */ e.jsx("span", { className: "truncate", children: (L == null ? void 0 : L.label) || z })
              ] }),
              /* @__PURE__ */ e.jsxs(
                "svg",
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "16",
                  height: "16",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  className: "ml-2 h-4 w-4 shrink-0 opacity-50",
                  children: [
                    /* @__PURE__ */ e.jsx("path", { d: "m7 15 5 5 5-5" }),
                    /* @__PURE__ */ e.jsx("path", { d: "m7 9 5-5 5 5" })
                  ]
                }
              )
            ]
          }
        ),
        c && /* @__PURE__ */ e.jsxs(
          "div",
          {
            className: r(
              "absolute left-0 z-50 w-full rounded-md border bg-popover text-popover-foreground shadow-md",
              u === "top" ? "bottom-full mb-2" : "top-full mt-2"
            ),
            children: [
              /* @__PURE__ */ e.jsxs("div", { className: "flex items-center border-b px-3", children: [
                /* @__PURE__ */ e.jsxs(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "16",
                    height: "16",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "mr-2 h-4 w-4 shrink-0 opacity-50",
                    children: [
                      /* @__PURE__ */ e.jsx("circle", { cx: "11", cy: "11", r: "8" }),
                      /* @__PURE__ */ e.jsx("path", { d: "m21 21-4.3-4.3" })
                    ]
                  }
                ),
                /* @__PURE__ */ e.jsx(
                  "input",
                  {
                    ref: C,
                    type: "text",
                    value: k,
                    onChange: (t) => E(t.target.value),
                    placeholder: A,
                    className: "flex h-10 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
                  }
                )
              ] }),
              /* @__PURE__ */ e.jsx("div", { className: "max-h-[300px] overflow-y-auto p-1", children: M.length === 0 ? /* @__PURE__ */ e.jsx("div", { className: "py-6 text-center text-sm text-muted-foreground", children: h }) : M.map((t) => {
                const d = B(t.value);
                return /* @__PURE__ */ e.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => $(t.value),
                    disabled: t.disabled,
                    className: r(
                      "relative flex w-full select-none items-center rounded-sm pr-2 pl-1.5 py-1.5 text-sm outline-none",
                      "hover:bg-accent hover:text-accent-foreground",
                      d && "bg-accent text-accent-foreground",
                      t.disabled && "cursor-not-allowed opacity-50 hover:bg-transparent hover:text-inherit"
                    ),
                    children: [
                      /* @__PURE__ */ e.jsxs("span", { className: "flex min-w-0 flex-1 items-center gap-3 text-left", children: [
                        t.icon ? /* @__PURE__ */ e.jsx(
                          K,
                          {
                            name: t.icon,
                            className: "h-4 w-4 shrink-0",
                            color: t.color
                          }
                        ) : null,
                        /* @__PURE__ */ e.jsxs("span", { className: "flex min-w-0 flex-col", children: [
                          /* @__PURE__ */ e.jsx("span", { className: "truncate", children: t.label }),
                          t.description ? /* @__PURE__ */ e.jsx("span", { className: "truncate text-xs text-muted-foreground", children: t.description }) : null
                        ] })
                      ] }),
                      w ? /* @__PURE__ */ e.jsx("span", { className: "ml-2 flex h-4 w-4 shrink-0 items-center justify-center", children: d ? /* @__PURE__ */ e.jsx(
                        "svg",
                        {
                          xmlns: "http://www.w3.org/2000/svg",
                          width: "16",
                          height: "16",
                          viewBox: "0 0 24 24",
                          fill: "none",
                          stroke: "currentColor",
                          strokeWidth: "2",
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          className: "h-4 w-4",
                          children: /* @__PURE__ */ e.jsx("polyline", { points: "20 6 9 17 4 12" })
                        }
                      ) : null }) : null
                    ]
                  },
                  t.value
                );
              }) })
            ]
          }
        )
      ]
    }
  );
  return a || l || j ? /* @__PURE__ */ e.jsx(
    F,
    {
      id: n,
      label: a,
      description: l,
      required: N,
      error: j,
      "data-refast-id": S,
      children: R
    }
  ) : /* @__PURE__ */ e.jsx("div", { "data-refast-id": S, children: R });
}
function Se({
  id: n,
  className: m,
  label: a,
  description: l,
  required: N = !1,
  error: j,
  maxLength: i = 6,
  value: p,
  disabled: z = !1,
  pattern: A,
  onChange: h,
  onComplete: w,
  children: T,
  "data-refast-id": y
}) {
  const [S, c] = s.useState(p !== void 0 ? p : ""), D = s.useRef([]);
  s.useEffect(() => {
    p !== void 0 && c(p);
  }, [p]), s.useEffect(() => J.on("refast:force-value-sync", ({ targetId: b, value: o }) => {
    b === n && o !== void 0 && c(o);
  }), [n]);
  const k = (b, o) => {
    var C;
    if (A && o && !new RegExp(A).test(o)) return;
    const x = S.split("");
    x[b] = o;
    const _ = x.join("").slice(0, i);
    c(_), h && h(_), o && b < i - 1 && ((C = D.current[b + 1]) == null || C.focus()), _.length === i && w && w(_);
  }, E = (b, o) => {
    var x;
    o.key === "Backspace" && !S[b] && b > 0 && ((x = D.current[b - 1]) == null || x.focus());
  }, u = T ? /* @__PURE__ */ e.jsx(
    "div",
    {
      id: n,
      className: r("flex items-center gap-2", m),
      children: T
    }
  ) : /* @__PURE__ */ e.jsx(
    "div",
    {
      id: n,
      className: r("flex items-center gap-2", m),
      children: Array.from({ length: i }).map((b, o) => /* @__PURE__ */ e.jsx(
        "input",
        {
          ref: (x) => {
            D.current[o] = x;
          },
          type: "text",
          inputMode: "numeric",
          maxLength: 1,
          value: S[o] || "",
          disabled: z,
          onChange: (x) => k(o, x.target.value),
          onKeyDown: (x) => E(o, x),
          className: r(
            "h-10 w-10 rounded-md border bg-background text-center text-sm",
            "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            j ? "border-destructive" : "border-input"
          )
        },
        o
      ))
    }
  );
  return a || l || j ? /* @__PURE__ */ e.jsx(
    F,
    {
      id: n,
      label: a,
      description: l,
      required: N,
      error: j,
      "data-refast-id": y,
      children: u
    }
  ) : /* @__PURE__ */ e.jsx("div", { "data-refast-id": y, children: u });
}
function Ee({
  id: n,
  className: m,
  children: a,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ e.jsx(
    "div",
    {
      id: n,
      className: r("flex items-center", m),
      "data-refast-id": l,
      children: a
    }
  );
}
function _e({
  id: n,
  className: m,
  index: a,
  "data-refast-id": l
}) {
  return /* @__PURE__ */ e.jsx(
    "div",
    {
      id: n,
      className: r(
        "relative flex h-10 w-10 items-center justify-center border-y border-r border-input text-sm transition-all",
        "first:rounded-l-md first:border-l last:rounded-r-md",
        m
      ),
      "data-refast-id": l,
      children: /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: "-" })
    }
  );
}
function Le({
  id: n,
  className: m,
  "data-refast-id": a
}) {
  return /* @__PURE__ */ e.jsx(
    "div",
    {
      id: n,
      role: "separator",
      className: r("flex items-center justify-center", m),
      "data-refast-id": a,
      children: /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: "-" })
    }
  );
}
export {
  G as Calendar,
  Ne as Combobox,
  ke as DatePicker,
  Se as InputOTP,
  Ee as InputOTPGroup,
  Le as InputOTPSeparator,
  _e as InputOTPSlot,
  ve as Slider,
  be as Switch,
  we as Toggle,
  ye as ToggleGroup,
  je as ToggleGroupItem
};
