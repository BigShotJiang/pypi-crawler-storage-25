import { F as n, p as t } from "./refast-charts-Be0RW0P2.js";
const o = n, r = t;
export {
  r as Funnel,
  o as FunnelChart
};
