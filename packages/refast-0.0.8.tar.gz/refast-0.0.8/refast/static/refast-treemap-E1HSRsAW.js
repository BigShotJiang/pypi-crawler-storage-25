import { q as e } from "./refast-charts-Be0RW0P2.js";
const m = e;
export {
  m as Treemap
};
