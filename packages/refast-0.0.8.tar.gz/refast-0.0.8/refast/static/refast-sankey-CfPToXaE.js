import { r as o } from "./refast-charts-Be0RW0P2.js";
const a = o;
export {
  a as Sankey
};
