import { B as r, b as a } from "./refast-charts-Be0RW0P2.js";
const o = r, B = a;
export {
  B as Bar,
  o as BarChart
};
