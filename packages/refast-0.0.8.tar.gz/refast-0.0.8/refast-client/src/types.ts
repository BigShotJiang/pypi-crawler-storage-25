import React from 'react';

/**
 * Component tree structure from Python backend.
 * Note: children may be undefined for leaf components (e.g., chart elements)
 */
export interface ComponentTree {
  type: string;
  id: string;
  props: Record<string, unknown>;
  children?: (ComponentTree | string)[];
}

/**
 * Props passed to rendered components.
 */
export interface ComponentProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  [key: string]: unknown;
}

/**
 * Callback reference from backend (Python callback).
 */
export interface CallbackRef {
  callbackId: string;
  boundArgs: Record<string, unknown>;
  debounce?: number;
  throttle?: number;
  /**
   * List of prop store keys to include with this callback.
   * Only these values are sent (not the entire store).
   */
  props?: string[];
}

/**
 * JavaScript callback reference from backend (client-side execution).
 */
export interface JsCallbackRef {
  jsFunction: string;
  boundArgs: Record<string, unknown>;
  debounce?: number;
  throttle?: number;
}

/**
 * Bound method callback reference from backend (calls a method on a component).
 */
export interface BoundMethodRef {
  targetId: string;
  methodName: string;
  args: unknown[];
  kwargs: Record<string, unknown>;
}

/**
 * Bound method callback wrapper (for event handlers).
 */
export interface BoundMethodCallbackRef {
  boundMethod: BoundMethodRef;
  debounce?: number;
  throttle?: number;
}

/**
 * Store prop reference — saves event data in the frontend prop store.
 */
export interface SavePropRef {
  saveProp: string | Record<string, string>;
  debounce?: number;
  throttle?: number;
}

/**
 * Chained action reference — composes multiple actions on a single event.
 */
export interface ChainedActionRef {
  chain: AnyActionRef[];
  mode: 'serial' | 'parallel';
}

/**
 * Any single action reference (not chained).
 */
export type SingleActionRef = CallbackRef | JsCallbackRef | BoundMethodCallbackRef | SavePropRef;

/**
 * Combined type for all possible action references, including chains.
 */
export type AnyActionRef = SingleActionRef | ChainedActionRef;

/**
 * @deprecated Use AnyActionRef instead.
 */
export type AnyCallbackRef = AnyActionRef;

/**
 * Update message from backend.
 */
export interface UpdateMessage {
  type: 'update' | 'state_update' | 'navigate' | 'toast' | 'event' | 'refresh' | 'store_update' | 'store_ready' | 'page_render' | 'js_exec' | 'resync_store' | 'bound_method_call' | 'theme_update';
  operation?: 'replace' | 'append' | 'prepend' | 'remove' | 'update_props' | 'update_children' | 'append_prop';
  targetId?: string;
  component?: ComponentTree;
  props?: Record<string, unknown>;
  children?: (ComponentTree | string)[];
  // append_prop specific fields
  propName?: string;
  value?: unknown;
  state?: Record<string, unknown>;
  path?: string;
  redirect?: boolean;
  target?: string;
  scroll_to?: string | null;
  scroll_behavior?: string;
  message?: string;
  variant?: string;
  duration?: number;
  eventType?: string;
  data?: unknown;
  updates?: StoreUpdate[];
  // Toast-specific properties (snake_case from Python backend)
  description?: string;
  position?: string;
  dismissible?: boolean;
  close_button?: boolean;
  invert?: boolean;
  icon?: string;
  action?: { label: string; callback_id: string };
  cancel?: { label: string; callback_id: string };
  id?: string;  // toast_id
  // JS execution properties
  code?: string;
  args?: unknown[] | Record<string, unknown>;  // Array for bound_method_call, Record for js_exec
  // Bound method call properties
  methodName?: string;
  kwargs?: Record<string, unknown>;
  // Theme update properties
  theme?: ThemePayload;
}

/**
 * Theme payload sent from backend for runtime theme updates.
 */
export interface ThemePayload {
  light: Record<string, string>;
  dark: Record<string, string>;
  fontFamily?: string | null;
  radius?: string | null;
  defaultMode?: 'light' | 'dark' | 'system';
}

/**
 * Store update operation from backend.
 */
export interface StoreUpdate {
  storageType: 'local' | 'session';
  operation: 'set' | 'delete' | 'clear';
  key: string | null;
  value?: unknown;
  encrypt?: boolean;
}

/**
 * Event message to backend.
 */
export interface EventMessage {
  type: 'callback' | 'event' | 'subscribe' | 'unsubscribe';
  callbackId?: string;
  eventType?: string;
  /** Bound args + requested prop store values. Passed as **kwargs to the Python callback. */
  data?: Record<string, unknown>;
  /** Raw DOM event data (value, name, checked). Accessible via ctx.event_data on the backend. */
  eventData?: Record<string, unknown>;
  boundArgs?: Record<string, unknown>;
}

/**
 * WebSocket connection state.
 */
export interface WebSocketState {
  socket: WebSocket | null;
  isConnected: boolean;
  isConnecting: boolean;
  reconnectAttempts: number;
}

/**
 * WebSocket connection options.
 */
export interface WebSocketOptions {
  url: string;
  reconnect?: boolean;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
}

/**
 * State manager state.
 */
export interface StateManagerState {
  componentTree: ComponentTree | null;
  appState: Record<string, unknown>;
}
