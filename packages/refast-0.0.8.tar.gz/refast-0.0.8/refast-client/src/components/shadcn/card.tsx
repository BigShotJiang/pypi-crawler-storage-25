import React from 'react';
import { cn } from '../../utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  /** Shorthand title rendered as an <h3> when no CardHeader child is provided. */
  title?: string;
  /** Shorthand description rendered as a <p> when no CardHeader child is provided. */
  description?: string;
  /** Optional click callback — makes the card interactive. */
  onClick?: React.MouseEventHandler<HTMLDivElement>;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * Card component - shadcn-styled card container.
 */
export function Card({
  id,
  className,
  style,
  title,
  description,
  children,
  'data-refast-id': dataRefastId,
  ...props
}: CardProps): React.ReactElement {
  return (
    <div
      id={id}
      className={cn(
        'rounded-lg border bg-card text-card-foreground shadow-sm',
        className
      )}
      style={style}
      data-refast-id={dataRefastId}
      {...props}
    >
      {title && (
        <h3 className="text-2xl font-semibold leading-none tracking-tight p-6 pb-0">{title}</h3>
      )}
      {description && (
        <p className="text-sm text-muted-foreground p-6 pt-1 pb-0">{description}</p>
      )}
      {children}
    </div>
  );
}

interface CardHeaderProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  /** Shorthand title rendered as an <h3> when no CardTitle child is provided. */
  title?: string;
  /** Shorthand description rendered as a <p> when no CardDescription child is provided. */
  description?: string;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * CardHeader component - card header section.
 *
 * Accepts either the convenient `title`/`description` shorthand or explicit
 * `CardTitle` / `CardDescription` children. Both may be combined — shorthand
 * is rendered before any children.
 */
export function CardHeader({
  id,
  className,
  style,
  title,
  description,
  children,
  'data-refast-id': dataRefastId,
}: CardHeaderProps): React.ReactElement {
  return (
    <div
      id={id}
      className={cn('flex flex-col space-y-1.5 p-6', className)}
      style={style}
      data-refast-id={dataRefastId}
    >
      {title && (
        <h3 className="text-2xl font-semibold leading-none tracking-tight">{title}</h3>
      )}
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      {children}
    </div>
  );
}

interface CardTitleProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * CardTitle component - card title text.
 */
export function CardTitle({
  id,
  className,
  style,
  children,
  'data-refast-id': dataRefastId,
}: CardTitleProps): React.ReactElement {
  return (
    <h3
      id={id}
      className={cn(
        'text-2xl font-semibold leading-none tracking-tight',
        className
      )}
      style={style}
      data-refast-id={dataRefastId}
    >
      {children}
    </h3>
  );
}

interface CardDescriptionProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * CardDescription component - card description text.
 */
export function CardDescription({
  id,
  className,
  style,
  children,
  'data-refast-id': dataRefastId,
}: CardDescriptionProps): React.ReactElement {
  return (
    <p
      id={id}
      className={cn('text-sm text-muted-foreground', className)}
      style={style}
      data-refast-id={dataRefastId}
    >
      {children}
    </p>
  );
}

interface CardContentProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * CardContent component - card content section.
 */
export function CardContent({
  id,
  className,
  style,
  children,
  'data-refast-id': dataRefastId,
}: CardContentProps): React.ReactElement {
  return (
    <div
      id={id}
      className={cn('p-6 pt-0', className)}
      style={style}
      data-refast-id={dataRefastId}
    >
      {children}
    </div>
  );
}

interface CardFooterProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  'data-refast-id'?: string;
}

/**
 * CardFooter component - card footer section.
 */
export function CardFooter({
  id,
  className,
  style,
  children,
  'data-refast-id': dataRefastId,
}: CardFooterProps): React.ReactElement {
  return (
    <div
      id={id}
      className={cn('flex items-center p-6 pt-0', className)}
      style={style}
      data-refast-id={dataRefastId}
    >
      {children}
    </div>
  );
}
