"""Refast test suite."""
