from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
from typing import Dict
from urllib.parse import urlparse

from deepline_core.browser import open_url_in_browser
from deepline_core.command_common import EXIT_INTERRUPTED, EXIT_OK, EXIT_SERVER, SHARE_SESSION_USER_PROMPTS_ENV, save_cli_env_values
from deepline_core.commands.backend import start_backend, stop_backend, playground_health
from deepline_core.playground_helpers import playground_default_api

SSE_TIMEOUT_S = 300  # 5 minutes
SSE_RECONNECT_DELAY_S = 0.2
MAX_CONTEXT_LEN = 2000


def _has_claude() -> bool:
    return shutil.which("claude") is not None


def _sanitize(text: str) -> str:
    """Strip control characters and enforce max length on user input."""
    cleaned = re.sub(r'[\x00-\x1f\x7f]', '', text)
    return cleaned[:MAX_CONTEXT_LEN]


def _build_prompt(workflow: str, context: str, csv_file_name: str) -> str:
    from deepline_core.recipes_data import build_prompt

    # Context is JSON with slot values from the inline inputs
    slots: dict[str, str] = {}
    try:
        parsed = json.loads(context)
        if isinstance(parsed, dict):
            slots = {k: _sanitize(str(v)) for k, v in parsed.items()}
    except (json.JSONDecodeError, ValueError):
        # Fallback: treat raw context as freeform
        slots = {"freeform": _sanitize(context.strip())}

    # Add csv_path for waterfall_enrich
    slots.setdefault("csv_path", _sanitize(csv_file_name) or "the imported file")

    return build_prompt(workflow, slots)


def _listen_sse(api_url: str, timeout_s: int = SSE_TIMEOUT_S) -> dict | None:
    """Connect to the playground SSE stream and wait for an onboard-result event."""
    import urllib.request

    parsed = urlparse(api_url)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or 4173
    url = f"http://{host}:{port}/events"
    deadline = time.time() + timeout_s

    while time.time() < deadline:
        remaining_connect = max(0.1, min(deadline - time.time(), timeout_s))
        try:
            resp = urllib.request.urlopen(url, timeout=remaining_connect)
        except Exception:
            if time.time() >= deadline:
                break
            time.sleep(min(SSE_RECONNECT_DELAY_S, max(0.0, deadline - time.time())))
            continue

        buf = ""
        try:
            # Access the underlying socket for timeout control.
            # resp.fp is a BufferedReader over a SocketIO; _sock is the real socket.
            raw_sock = resp.fp.raw._sock

            while time.time() < deadline:
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                raw_sock.settimeout(min(remaining, 30))
                try:
                    chunk = resp.fp.read1(4096)
                except socket.timeout:
                    continue
                except OSError:
                    break
                if not chunk:
                    # Stream ended unexpectedly; reconnect until overall timeout.
                    break
                buf += chunk.decode("utf-8", errors="replace")
                while "\n\n" in buf:
                    event_block, buf = buf.split("\n\n", 1)
                    for line in event_block.split("\n"):
                        if line.startswith("data: "):
                            data_str = line[6:]
                            try:
                                data = json.loads(data_str)
                            except (json.JSONDecodeError, ValueError):
                                continue
                            if isinstance(data, dict) and data.get("type") == "onboard-result":
                                return data
        except Exception:
            pass
        finally:
            resp.close()

        if time.time() < deadline:
            time.sleep(min(SSE_RECONNECT_DELAY_S, max(0.0, deadline - time.time())))
    return None


def handle(base_url: str, _env: Dict[str, str], _args: list[str]) -> int:
    # Force unbuffered stdout so prints appear immediately in terminal
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)

    has_claude = _has_claude()
    api_url = playground_default_api()

    # Restart playground backend fresh to clear stale state
    if playground_health(api_url):
        stop_backend(output_json=False, just_backend=True)
    # Delete persisted session state files so the new backend starts with a clean plan/activity.
    # Only removes JSON state — not SQLite DBs which may be shared with other running sessions.
    import tempfile
    pg_db_dir = os.path.join(tempfile.gettempdir(), "deepline-playground-db")
    for stale_file in ("cli-event-state.json", "agent-plan-state.json"):
        try:
            os.remove(os.path.join(pg_db_dir, stale_file))
        except FileNotFoundError:
            pass
    rc = start_backend(base_url, str(urlparse(api_url).port or 4173), False, "auto")
    if rc != EXIT_OK:
        print("Could not start playground backend. Retry: deepline quickstart")
        return EXIT_SERVER

    # Open browser to onboard view — always open a fresh tab via `open` command
    # rather than retargeting, since existing tabs may be on localhost:3000 vs 127.0.0.1
    onboard_url = f"{api_url}/quickstart?view=onboard"
    subprocess.Popen(["open", onboard_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"  • If the browser didn't open, cmd+click: {onboard_url}")

    # Print Claude install hint early so user can install in parallel
    if not has_claude:
        print()
        print("  • Claude Code is not installed. Install it while you browse:")
        print("    npm install -g @anthropic-ai/claude-code")
        print()

    # Wait for user to pick a workflow via SSE
    print("⏳ Pick a workflow in the browser. Press Ctrl+C to skip.")
    try:
        result = _listen_sse(api_url)
    except KeyboardInterrupt:
        print()
        return EXIT_INTERRUPTED

    if not result:
        print()
        print("No workflow selected (timed out after 5 minutes).")
        print("Run `deepline quickstart` to try again.")
        return EXIT_OK

    workflow = result.get("workflow", "chat")
    context = result.get("context", "")
    csv_file_name = result.get("csvFileName", "")
    share_session_prompts = result.get("share_session_prompts")

    if isinstance(share_session_prompts, bool):
        save_cli_env_values(
            {
                SHARE_SESSION_USER_PROMPTS_ENV: "true" if share_session_prompts else "false",
            },
            base_url,
        )

    full_command = _build_prompt(workflow, context, csv_file_name)

    # Re-check claude availability (user may have installed while browsing)
    has_claude = _has_claude()

    if has_claude:
        print()
        print("Launching Claude...")
        # Redirect the existing browser tab from onboard view to the session UI
        try:
            open_url_in_browser(f"{api_url}/", force_focus=True)
        except Exception:
            pass
        os.execvp("claude", ["claude", full_command])
        # execvp replaces the process — this line is unreachable
    else:
        print()
        print("Claude Code is not installed. To continue, install it and run:")
        print()
        print(f'  claude "{full_command}"')
        print()
        print("Install Claude Code: npm install -g @anthropic-ai/claude-code")

    return EXIT_OK
