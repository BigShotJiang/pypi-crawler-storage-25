from __future__ import annotations

import os
import platform
import subprocess
import sys
from dataclasses import dataclass
from typing import Dict

from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.command_common import require_api_key, usage_provide_feedback
from deepline_core.command_common import EXIT_AUTH, EXIT_OK, EXIT_SERVER, EXIT_USAGE, EXIT_VALIDATION
from deepline_core.http import http_request

router = SubcommandRouter()


def _collect_env_info() -> Dict[str, str]:
    """Collect local environment info to attach to feedback."""
    info: Dict[str, str] = {}
    info["os"] = f"{platform.system()} {platform.release()}"
    info["terminal"] = os.environ.get("TERM_PROGRAM", "unknown")
    term_ver = os.environ.get("TERM_PROGRAM_VERSION", "")
    if term_ver:
        info["terminal"] += f" {term_ver}"
    try:
        result = subprocess.run(
            ["deepline", "--version"],
            capture_output=True, text=True, timeout=5,
        )
        info["cli_version"] = result.stdout.strip() if result.returncode == 0 else "unknown"
    except Exception:
        info["cli_version"] = "unknown"
    return info


@dataclass(frozen=True)
class FeedbackParams:
    text: str
    output_json: bool
    command: str | None
    payload: str | None


def usage_feedback_computed() -> list[str]:
    lines = usage_provide_feedback()
    lines.append("  deepline feedback --text \"Detailed feedback\" [--json]")
    lines.append('  deepline feedback --text "..." --command "deepline enrich ..." --payload \'{"alias":"job_listings"}\'')
    lines.append("  deepline provide-feedback --text \"Detailed feedback\" [--json]")
    lines.append('  deepline provide-feedback --text "..." --command "deepline enrich ..." --payload \'{"alias":"job_listings"}\'')
    return lines


def build_feedback_params(parsed: ParsedRouteOptions) -> FeedbackParams:
    text = str(parsed.options.get("text") or "").strip()
    if not text:
        raise ValueError("Feedback text is required.")
    command = str(parsed.options.get("command") or "").strip() or None
    payload = str(parsed.options.get("payload") or "").strip() or None
    return FeedbackParams(
        text=text,
        output_json=bool(parsed.options.get("json")),
        command=command,
        payload=payload,
    )


@router.route_typed(
    "submit",
    summary="Submit user feedback to Deepline backend.",
    options=[
        OptionSpec("--text", "Feedback content.", takes_value=True, value_name="TEXT", key="text"),
        OptionSpec("--command", "Command that reproduced the issue.", takes_value=True, value_name="CMD", key="command"),
        OptionSpec("--payload", "JSON or text payload for the repro.", takes_value=True, value_name="PAYLOAD", key="payload"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=build_feedback_params,
)
def handle_submit(base_url: str, env: Dict[str, str], params: FeedbackParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    env_info = _collect_env_info()
    request_body = {"text": params.text, "environment": env_info}
    if params.command:
        request_body["command"] = params.command
    if params.payload:
        request_body["payload"] = params.payload
    status, body = http_request("POST", f"{base_url}/api/v2/cli/feedback", env.get("DEEPLINE_API_KEY"), request_body)
    if status >= 400:
        if status in (401, 403):
            print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.", file=sys.stderr)
            return EXIT_AUTH
        if status in (400, 422):
            print(f"Feedback submission failed (status {status}).", file=sys.stderr)
            if body.strip():
                print(body.strip(), file=sys.stderr)
            return EXIT_VALIDATION
        print(f"Feedback submission failed (status {status}).", file=sys.stderr)
        if body.strip():
            print(body.strip(), file=sys.stderr)
        return EXIT_SERVER
    if params.output_json:
        print(body)
    else:
        print("Feedback submitted. Thank you.")
    return EXIT_OK


def _feedback_unknown(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    # Legacy shape: deepline provide-feedback "text" [--json]
    if args and not args[0].startswith("--"):
        output_json = "--json" in args
        text = " ".join([a for a in args if a != "--json"]).strip()
        params = FeedbackParams(text=text, output_json=output_json, command=None, payload=None)
        return handle_submit(base_url, env, params)
    # New explicit shape: deepline provide-feedback submit --text "..."
    routed = router.dispatch(args[0], base_url, env, args[1:])
    if routed is not None:
        return routed
    # Compact shape: deepline provide-feedback --text "...".
    parsed = router.parse_options("submit", args)
    if parsed.errors:
        print(parsed.errors[0], file=sys.stderr)
        return EXIT_USAGE
    try:
        params = build_feedback_params(parsed)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return EXIT_USAGE
    return handle_submit(base_url, env, params)


handle = build_command_handler(
    command_name="provide-feedback",
    router=router,
    usage_factory=usage_feedback_computed,
    on_unknown=_feedback_unknown,
)
