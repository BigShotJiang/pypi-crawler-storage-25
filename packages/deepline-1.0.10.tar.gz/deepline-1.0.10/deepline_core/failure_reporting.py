from __future__ import annotations

import os
import platform
import re
import sys
import traceback
from collections import deque
from pathlib import Path
from typing import Any, Iterable, Mapping

FAILURE_REPORT_DISABLE_ENV = "DEEPLINE_DISABLE_FAILURE_REPORTING"
MAX_FAILURE_TEXT_CHARS = 4000
MAX_LOG_TAIL_LINES = 40
MAX_COMMAND_TOKENS = 3

_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_ASSIGNMENT_SECRET_RE = re.compile(
    r"(?i)\b("
    r"access[_-]?token|api[_-]?key|apikey|auth(?:orization)?|bearer|password|secret|session"
    r")\b(\s*[:=]\s*)([^\s,;]+)"
)
_BEARER_SECRET_RE = re.compile(r"(?i)\b(bearer)\s+([A-Za-z0-9._\-]+)")
_GENERIC_TOKEN_RE = re.compile(r"\b(?:dlp|sk|ghp|xox[baprs])[-_A-Za-z0-9]{8,}\b")
_CLI_FAILURE_CONTEXT: dict[str, Any] | None = None


def is_failure_reporting_disabled(env: Mapping[str, str] | None = None) -> bool:
    source = env if env is not None else os.environ
    raw = str(source.get(FAILURE_REPORT_DISABLE_ENV, "")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def sanitize_command(argv: list[str], *, prefix: str = "deepline") -> str:
    tokens: list[str] = []
    for arg in argv:
        value = str(arg or "").strip()
        if not value or value.startswith("-"):
            continue
        tokens.append(value)
        if len(tokens) >= MAX_COMMAND_TOKENS:
            break
    if not tokens:
        return prefix
    return " ".join([prefix, *tokens])


def redact_failure_text(value: str | None, *, max_chars: int = MAX_FAILURE_TEXT_CHARS) -> str:
    text = str(value or "")
    if not text:
        return ""
    home_dir = str(Path.home())
    if home_dir and home_dir != "/":
        text = text.replace(home_dir, "~")
    text = _EMAIL_RE.sub("[redacted-email]", text)
    text = _ASSIGNMENT_SECRET_RE.sub(r"\1\2[redacted-secret]", text)
    text = _BEARER_SECRET_RE.sub(r"\1 [redacted-secret]", text)
    text = _GENERIC_TOKEN_RE.sub("[redacted-secret]", text)
    if len(text) > max_chars:
        return text[:max_chars]
    return text


def build_environment_context() -> dict[str, str]:
    return {
        "os": platform.system() or "(unknown)",
        "os_release": platform.release() or "(unknown)",
        "platform": platform.platform() or "(unknown)",
        "python_version": platform.python_version(),
        "runtime": platform.python_implementation() or "Python",
    }


def clear_cli_failure_context() -> None:
    global _CLI_FAILURE_CONTEXT
    _CLI_FAILURE_CONTEXT = None


def get_cli_failure_context() -> dict[str, Any] | None:
    if not isinstance(_CLI_FAILURE_CONTEXT, dict):
        return None
    return dict(_CLI_FAILURE_CONTEXT)


def set_cli_failure_context(
    *,
    failure_code: str,
    failure_stage: str,
    failure_message: str,
    log_source: str | None = None,
    log_tail: str | None = None,
    extra_context: Mapping[str, Any] | None = None,
) -> None:
    global _CLI_FAILURE_CONTEXT
    payload: dict[str, Any] = {
        "failure_code": redact_failure_text(failure_code, max_chars=200),
        "failure_stage": redact_failure_text(failure_stage, max_chars=200),
        "failure_message": redact_failure_text(failure_message),
    }
    if log_source:
        payload["log_source"] = redact_failure_text(log_source, max_chars=200)
    if log_tail:
        payload["log_tail"] = redact_failure_text(log_tail)
    if extra_context:
        for key, value in extra_context.items():
            if value is None:
                continue
            if isinstance(value, str):
                payload[str(key)] = redact_failure_text(value)
            elif isinstance(value, Mapping):
                payload[str(key)] = {
                    str(inner_key): redact_failure_text(str(inner_value))
                    for inner_key, inner_value in value.items()
                    if inner_value is not None
                }
            elif isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
                payload[str(key)] = [redact_failure_text(str(item)) for item in value]
            else:
                payload[str(key)] = value
    _CLI_FAILURE_CONTEXT = payload


def format_exception_message(exc: BaseException) -> str:
    return redact_failure_text(f"{exc.__class__.__name__}: {exc}")


def format_exception_stack(exc: BaseException) -> str:
    stack = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    return redact_failure_text(stack)


def read_log_tail(log_path: str | Path | None, *, max_lines: int = MAX_LOG_TAIL_LINES) -> str:
    if not log_path:
        return ""
    path = Path(str(log_path)).expanduser()
    if not path.is_file():
        return ""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            lines = deque(handle, maxlen=max_lines)
    except Exception:
        return ""
    return redact_failure_text("".join(lines).strip())


def build_failure_context(
    *,
    argv: list[str],
    base_url: str,
    exit_code: int | None,
    duration_ms: int | None,
    failure_kind: str,
    log_path: str | Path | None = None,
    extra_context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    context: dict[str, Any] = {
        "base_url": redact_failure_text(base_url, max_chars=400),
        "command_summary": sanitize_command(argv),
        "environment": build_environment_context(),
        "failure_kind": failure_kind,
    }
    if exit_code is not None:
        context["exit_code"] = int(exit_code)
    if duration_ms is not None:
        context["duration_ms"] = int(max(0, duration_ms))
    if log_path:
        tail = read_log_tail(log_path)
        if tail:
            context["log_source"] = Path(str(log_path)).name
            context["log_tail"] = tail
    if extra_context:
        for key, value in extra_context.items():
            if value is None:
                continue
            if isinstance(value, str):
                context[key] = redact_failure_text(value)
            elif isinstance(value, Mapping):
                context[key] = {
                    str(inner_key): redact_failure_text(str(inner_value))
                    for inner_key, inner_value in value.items()
                    if inner_value is not None
                }
            elif isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
                context[key] = [redact_failure_text(str(item)) for item in value]
            else:
                context[key] = value
    return context


def write_uncaught_exception_stderr(exc: BaseException) -> None:
    message = format_exception_stack(exc)
    if not message:
        return
    print(message, file=sys.stderr, flush=True)
