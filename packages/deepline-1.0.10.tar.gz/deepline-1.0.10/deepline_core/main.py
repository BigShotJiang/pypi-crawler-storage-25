from __future__ import annotations

import argparse
import contextlib
import difflib
import json
import uuid
import io
import os
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse
import time

from .commands import auth
from .commands import backend
from .commands import billing
from .commands import csv
from .commands import db
from .commands import enrich
from .commands import events
from .commands import feedback
from .commands import onboard
from .commands import org
from .commands import session
from .commands import tools
from .commands import workflows
from deepline_core.command_common import (
    VERSION,
    install_component_version_path,
    load_cli_env,
    resolved_cli_version,
    resolve_base_url,
    resolve_base_url_early,
    write_install_component_version,
)
from deepline_core.command_common import EXIT_NETWORK, EXIT_OK, EXIT_SERVER, EXIT_UNKNOWN_COMMAND
from deepline_core.cli_events import append_cli_event, update_cli_event
from deepline_core.failure_reporting import (
    build_failure_context,
    clear_cli_failure_context,
    format_exception_message,
    format_exception_stack,
    get_cli_failure_context,
    is_failure_reporting_disabled,
    sanitize_command,
)
from deepline_core.http import http_request, is_network_runtime_error, report_failure
from deepline_core.playground_helpers import playground_default_api, playground_read_state
from deepline_core.self_update import force_self_update, maybe_self_update



def _version_env_prefix(base_url: str) -> str:
    try:
        parsed = urlparse(base_url)
        host = (parsed.hostname or "").lower()
    except Exception:
        host = ""
    if host in {"localhost", "127.0.0.1", "::1"} or host.endswith(".local"):
        return "dev"
    return "prod"


def _version_label(base_url: str) -> str:
    version = resolved_cli_version()
    prefix = _version_env_prefix(base_url)
    if not version:
        return prefix
    if version == prefix:
        return prefix
    if version.startswith(f"{prefix}-"):
        return version
    return f"{prefix}-{version}"


def _is_localhost_host(base_url: str) -> bool:
    try:
        parsed = urlparse(base_url)
        host = (parsed.hostname or "").lower()
    except Exception:
        return False
    return host == "localhost" or host.startswith("127.") or host == "0.0.0.0"


def _print_dev_mode_banner(base_url: str, argv: list[str]) -> None:
    if "--json" in argv:
        return
    if str(os.environ.get("DEEPLINE_INSTALLER_MODE", "")).strip().lower() == "true":
        return
    if not _is_localhost_host(base_url):
        return
    if not sys.stderr.isatty():
        return
    print("You are in dev mode, reading from localhost.", file=sys.stderr)


def _self_update_disabled(parsed: argparse.Namespace) -> bool:
    if getattr(parsed, "skip_self_update", False):
        return True
    raw = str(os.environ.get("DEEPLINE_SKIP_SELF_UPDATE", "")).strip()
    return raw.lower() in {"1", "true", "yes", "on"}


def _print_host_metadata(base_url: str, *, fetch_remote: bool = False) -> None:
    print("Installed at: (python)")
    print(f"Host: {base_url}")

    if not fetch_remote:
        print("Host status: (unknown)")
        print("Host version: (unknown)")
        print(f"CLI version: {_version_label(base_url)}")
        return

    status, body = 0, ""
    for path in ("/api/v2/host/info", "/api/v2/health"):
        try:
            status, body = http_request("GET", f"{base_url}{path}", None)
        except RuntimeError:
            status, body = 0, ""
        if status == 200:
            break
    if status == 200:
        try:
            payload = json.loads(body or "{}")
        except Exception:
            payload = {}
        print(f"Host status: {payload.get('status') or 'ok'}")
        print(f"Host version: {payload.get('version') or '(unknown)'}")
    else:
        print("Host status: (unknown)")
        print("Host version: (unknown)")
    print(f"CLI version: {_version_label(base_url)}")


def _skills_url(base_url: str) -> str:
    explicit = os.environ.get("DEEPLINE_SKILLS_URL", "").strip()
    if explicit:
        return explicit
    return f"{base_url.rstrip('/')}/.well-known/skills/index.json"


def _skills_url_candidates(base_url: str) -> list[str]:
    explicit = os.environ.get("DEEPLINE_SKILLS_URL", "").strip()
    if explicit:
        return [explicit]
    normalized = base_url.rstrip("/")
    return [
        f"{normalized}/.well-known/skills/index.json",
        f"{normalized}/api/v2/skills/manifest",
    ]


def _fetch_skills_index(base_url: str) -> tuple[str | None, int, str]:
    last_status = 0
    last_body = ""
    for skills_url in _skills_url_candidates(base_url):
        status, body = http_request("GET", skills_url, None)
        if status == 200 and body:
            return skills_url, status, body
        last_status = status
        last_body = body
    return None, last_status, last_body


def _as_dict(value: object) -> dict[str, object]:
    return value if isinstance(value, dict) else {}


def _as_list(value: object) -> list[object]:
    return value if isinstance(value, list) else []


def _get_stale_skills(index_json: dict[str, object], lock_data: dict[str, object]) -> list[str]:
    """Return well-known skill names present in the lock file but absent from the index."""
    index_names: set[str] = set()
    for skill in _as_list(index_json.get("skills")):
        skill_obj = _as_dict(skill)
        name = str(skill_obj.get("name", "")).strip()
        if name:
            index_names.add(name)

    stale: list[str] = []
    for name, entry in _as_dict(lock_data.get("skills")).items():
        entry_obj = _as_dict(entry)
        if entry_obj.get("sourceType") == "well-known" and name not in index_names:
            stale.append(name)
    return sorted(stale)


def _get_resettable_well_known_skills(status: dict[str, object], lock_data: dict[str, object]) -> list[str]:
    """Return well-known skills that should be removed before reinstalling."""
    resettable: list[str] = []
    lock_skills = _as_dict(lock_data.get("skills"))
    for name, info in _as_dict(status.get("skills")).items():
        if _as_dict(lock_skills.get(name)).get("sourceType") != "well-known":
            continue
        if _as_dict(info).get("status") in {"drift", "stale"}:
            resettable.append(name)
    return sorted(resettable)


def _extract_skills_version(body: str) -> str:
    try:
        payload = json.loads(body or "{}")
    except Exception:
        return ""
    if not isinstance(payload, dict):
        return ""
    version = payload.get("version")
    if isinstance(version, str):
        return version.strip()
    if isinstance(version, (int, float)) and not isinstance(version, bool):
        return str(version).strip()
    return ""


def _write_local_skills_version(base_url: str, version: str) -> None:
    normalized_version = str(version or "").strip()
    if not normalized_version:
        return
    try:
        write_install_component_version(base_url, "skills", normalized_version)
    except Exception as exc:
        version_path = install_component_version_path(str(Path.home()), base_url, "skills")
        print(
            f"Failed to write local skills version file {version_path}: {exc}",
            file=sys.stderr,
        )


def _cleanup_stale_skills(base_url: str) -> None:
    """Remove well-known skills that no longer appear in the remote index."""
    try:
        _skills_url_used, status, body = _fetch_skills_index(base_url)
        if not body or status != 200:
            return
        index_json = json.loads(body)

        lock_path = os.path.expanduser("~/.agents/.skill-lock.json")
        if not os.path.isfile(lock_path):
            return
        with open(lock_path, "r") as f:
            lock_data = json.load(f)

        stale = _get_stale_skills(index_json, lock_data)
        if not stale:
            return

        if shutil.which("npx") is None:
            return

        result = subprocess.run(
            ["npx", "skills", "remove", "--global", "-y", *stale],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode == 0:
            print(f"Removed stale skills: {', '.join(stale)}", file=sys.stderr)
        else:
            print(f"Failed to remove stale skills: {', '.join(stale)}", file=sys.stderr)
    except Exception:
        pass


def _load_skill_lock_data() -> dict[str, object]:
    lock_path = os.path.expanduser("~/.agents/.skill-lock.json")
    if not os.path.isfile(lock_path):
        return {}
    with open(lock_path, "r") as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def check_skills_status(base_url: str) -> dict[str, object]:
    """Compare installed skills against the remote index. Returns a status dict."""
    skills_dir = os.path.expanduser("~/.agents/skills")
    lock_path = os.path.expanduser("~/.agents/.skill-lock.json")

    result: dict = {"ok": True, "skills": {}, "error": None}

    try:
        _skills_url_used, status, body = _fetch_skills_index(base_url)
        if status != 200 or not body:
            result["ok"] = False
            result["error"] = f"Failed to fetch index.json (status {status})"
            return result
        index_json = json.loads(body)
    except Exception as e:
        result["ok"] = False
        result["error"] = f"Failed to fetch index.json: {e}"
        return result

    lock_data: dict = {}
    if os.path.isfile(lock_path):
        with open(lock_path, "r") as f:
            lock_data = json.load(f)

    # Build expected state from index
    expected: dict[str, list[str]] = {}
    for skill in index_json.get("skills", []):
        name = skill.get("name", "").strip()
        if name:
            expected[name] = sorted(skill.get("files", []))

    # Check expected skills
    for name, expected_files in expected.items():
        skill_path = os.path.join(skills_dir, name)
        entry: dict = {"status": "ok", "missing_files": [], "extra_files": []}

        if name not in lock_data.get("skills", {}):
            entry["status"] = "not_installed"
            result["ok"] = False
            result["skills"][name] = entry
            continue

        if not os.path.isdir(skill_path):
            entry["status"] = "not_installed"
            result["ok"] = False
            result["skills"][name] = entry
            continue

        # Walk actual files on disk
        actual_files: set[str] = set()
        for root, _dirs, files in os.walk(skill_path):
            for fname in files:
                rel = os.path.relpath(os.path.join(root, fname), skill_path)
                actual_files.add(rel)

        expected_set = set(expected_files)
        missing = sorted(expected_set - actual_files)
        extra = sorted(actual_files - expected_set)

        if missing:
            entry["status"] = "drift"
            entry["missing_files"] = missing
            result["ok"] = False
        if extra:
            if entry["status"] == "ok":
                entry["status"] = "drift"
            entry["extra_files"] = extra
            result["ok"] = False

        result["skills"][name] = entry

    # Check for stale well-known skills
    for name, lock_entry in lock_data.get("skills", {}).items():
        if lock_entry.get("sourceType") == "well-known" and name not in expected:
            result["skills"][name] = {"status": "stale"}
            result["ok"] = False

    return result


def print_skills_status(base_url: str) -> None:
    """Print skill health to stdout."""
    status = check_skills_status(base_url)
    if status.get("error"):
        print(f"Skills: error ({status['error']})")
        return
    status_skills = _as_dict(status.get("skills"))
    if not status_skills:
        print("Skills: no skills in index")
        return

    # Categorize skills by status
    categories: dict[str, list[str]] = {
        "ok": [],
        "stale": [],
        "drift": [],
        "not_installed": [],
    }
    for name, info in sorted(status_skills.items()):
        info_obj = _as_dict(info)
        cat = str(info_obj.get("status", ""))
        if cat not in categories:
            cat = "drift"
        categories[cat].append(name)

    total = len(status_skills)
    issues = total - len(categories["ok"])

    all_names = ", ".join(sorted(status_skills.keys()))

    if issues == 0:
        print(f"Skills: {total} installed, all synced")
        print(f"  {all_names}")
        return

    installed = total - len(categories["not_installed"])
    print(f"Skills: {installed} installed, {issues} need sync")
    labels = [
        ("stale", "Stale"),
        ("drift", "Out of sync"),
        ("not_installed", "Missing"),
    ]
    for key, label in labels:
        if categories[key]:
            print(f"  {label}: {', '.join(categories[key])}")
    print("  Run `deepline update` to fix")


def _sync_agent_skill(base_url: str) -> None:
    if shutil.which("npx") is None:
        print("npx not found. Skipping agent skill sync.", file=sys.stderr)
        return

    agents = ["codex", "claude-code", "cursor"]
    print("Refreshing Deepline agent skills package...", file=sys.stderr)
    skills_url = _skills_url(base_url)
    remote_skills_version = ""
    try:
        resolved_skills_url, _status, body = _fetch_skills_index(base_url)
        if resolved_skills_url:
            skills_url = resolved_skills_url
        remote_skills_version = _extract_skills_version(body)
        status = check_skills_status(base_url)
        lock_data = _load_skill_lock_data()
        skills_to_reset = _get_resettable_well_known_skills(status, lock_data)
    except Exception:
        skills_to_reset = []

    if skills_to_reset:
        try:
            reset_result = subprocess.run(
                ["npx", "skills", "remove", "--global", "-y", *skills_to_reset],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            if reset_result.returncode == 0:
                print(
                    f"Resetting drifted Deepline skills before refresh: {', '.join(skills_to_reset)}",
                    file=sys.stderr,
                )
            else:
                print(
                    f"Failed to reset drifted Deepline skills before refresh: {', '.join(skills_to_reset)}",
                    file=sys.stderr,
                )
        except Exception:
            pass

    try:
        result = subprocess.run(
            [
                "npx",
                "skills",
                "add",
                skills_url,
                "--agents",
                *agents,
                "--global",
                "--yes",
                "--skill",
                "*",
                "--full-depth",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except Exception:
        result = None
    if result and result.returncode == 0:
        _write_local_skills_version(base_url, remote_skills_version)
        print("Deepline agent skills refreshed.", file=sys.stderr)
    else:
        print(
            f"Agent skill refresh failed. Run manually: npx skills add {skills_url} --agents {' '.join(agents)} --global --yes --skill '*' --full-depth",
            file=sys.stderr,
        )


def print_main_help_dynamic(base_url: str) -> None:
    print("Deepline CLI (python)\n")
    _print_host_metadata(base_url)
    print("")
    print("Usage:")
    for provider in (
        org.usage_org_computed,
        auth.usage_auth_computed,
        db.usage_db_computed,
        billing.usage_billing_computed,
        feedback.usage_feedback_computed,
        session.usage_session_computed,
        workflows.usage_workflows_computed,
        events.usage_events_computed,
        backend.usage_backend_computed,
        csv.usage_csv_computed,
        tools.usage_tools_computed,
        enrich.usage_enrich_computed,
    ):
        for line in provider():
            if line.startswith("  deepline "):
                print(line)
    print("  deepline update                         Check for and apply CLI updates.")
    print("  deepline update --status                Show update check details (cli/playground/skills).")
    print("")
    print("Tips:")
    print("  Tool IDs are provider-prefixed (example: dropleads_search_people).")
    print("  Pass --payload as strict JSON; easiest pattern is single-quoted JSON:")
    print("    deepline tools execute run_javascript --payload '{\"code\":\"return row;\"}' --json")
    print("  For enrich waterfalls, use --with-waterfall plus JSON --with specs, for example:")
    print("    deepline enrich --input file.csv --with-waterfall email --with '{\"alias\":\"email_step\",\"tool\":\"apollo_people_match\",\"payload\":{...},\"extract_js\":\"(data) => extract(\\\"apollo_people_match\\\", data, \\\"email\\\")\"}' --end-waterfall")
    print("  Prefer --in-place for iterative enrich reruns; use --with-force to selectively recompute columns.")
    print("")
    print("Global options (place before the command):")
    print("  --timeout SECONDS      Request timeout.")
    print("  --wait                 Wait for terminal status (provider/tool dependent).")
    print("  --debug                Wait mode plus status output (provider/tool dependent).")
    print("  --wait-timeout SECONDS Max seconds to wait in --wait mode (default: 300).")
    print("  --poll-interval SECONDS Poll interval in --wait mode (default: 2).")


def _top_level_commands() -> list[str]:
    return [
        "org",
        "auth",
        "billing",
        "customer-db",
        "feedback",
        "provide-feedback",
        "session",
        "backend",
        "csv",
        "workflows",
        "events",
        "tools",
        "list",
        "get",
        "enrich",
        "quickstart",
        "redeem-code",
        "inspect",
        "wait",
        "update",
        "version",
    ]


def _extract_csv_path_from_args(args: list[str]) -> str | None:
    keys = {"--csv", "--input"}
    for idx, arg in enumerate(args):
        if arg in keys and idx + 1 < len(args):
            value = str(args[idx + 1]).strip()
            if value:
                return value
        if arg.startswith("--csv=") or arg.startswith("--input="):
            _, value = arg.split("=", 1)
            value = value.strip()
            if value:
                return value
    return None



def _emit_cli_event(
    *,
    base_url: str,
    run_id: str | None = None,
    command: str,
    status: str,
    title: str,
    detail: str = "",
    exit_code: int | None = None,
    duration_ms: int | None = None,
    csv_path: str | None = None,
    response: str | None = None,
) -> None:
    update_meta: dict[str, object] = {}
    append_meta: dict[str, object] = {}
    if exit_code is not None:
        update_meta["exit_code"] = int(exit_code)
        append_meta["exit_code"] = int(exit_code)
    if duration_ms is not None:
        update_meta["duration_ms"] = int(max(0, duration_ms))
        append_meta["duration_ms"] = int(max(0, duration_ms))
    update_cli_event(
        source="cli_main",
        status=status,
        title=title,
        detail=detail,
        command=command,
        csv_path=csv_path,
        run_id=run_id,
        response=response,
        meta=update_meta or None,
    )
    # Don't send response on append_event — it can be huge (e.g. tools list 400KB).
    # The update action already set cliEventState.response; backend copies it to the event entry.
    # UI fetches full response on click via /api/cli-event-entry.
    append_cli_event(
        source="cli_main",
        status=status,
        level="error" if status == "failed" else "info",
        message=f"{title}{f' - {detail}' if detail else ''}",
        command=command,
        csv_path=csv_path,
        run_id=run_id,
        meta=append_meta or None,
    )


def _should_capture_activity_response(argv: list[str]) -> bool:
    return "--json" not in argv


_REPORTABLE_EXIT_CODES = {EXIT_NETWORK, EXIT_SERVER}
def _resolve_failure_log_path(command: str) -> str | None:
    try:
        state = playground_read_state()
    except Exception:
        state = {}
    candidates: list[str] = []
    state_log_path = str(state.get("log_path") or "").strip()
    if state_log_path:
        candidates.append(state_log_path)
    candidates.append(str(Path.home() / ".local" / "deepline" / "playground-backend-python.log"))
    for candidate in candidates:
        if candidate and Path(candidate).expanduser().is_file():
            return candidate
    return candidates[0] if candidates else None


def _report_cli_failure(
    *,
    base_url: str,
    env: dict[str, str],
    argv: list[str],
    run_id: str | None,
    command: str,
    exit_code: int | None,
    duration_ms: int | None,
    failure_kind: str,
    exc: BaseException | None = None,
    extra_context: dict[str, object] | None = None,
) -> None:
    if is_failure_reporting_disabled(env):
        return
    token = env.get("DEEPLINE_API_KEY")
    stored_context = get_cli_failure_context()
    context_log_source = str(stored_context.get("log_source") or "").strip() if stored_context else ""
    context_log_tail = str(stored_context.get("log_tail") or "").strip() if stored_context else ""
    log_path = None if (context_log_source and context_log_tail) else _resolve_failure_log_path(command)
    context = build_failure_context(
        argv=argv,
        base_url=base_url,
        exit_code=exit_code,
        duration_ms=duration_ms,
        failure_kind=failure_kind,
        log_path=log_path,
        extra_context=extra_context,
    )
    if stored_context:
        context.update({key: value for key, value in stored_context.items() if value is not None})
    failure_message = str(context.get("failure_message") or "").strip() or None
    failure_code = str(context.get("failure_code") or "").strip() or None
    failure_stage = str(context.get("failure_stage") or "").strip() or None
    report_failure(
        base_url,
        token,
        command=sanitize_command(argv),
        run_id=run_id,
        error_status=exit_code,
        error_body=format_exception_message(exc) if exc is not None else failure_message,
        exit_code=exit_code,
        duration_ms=duration_ms,
        error_class=exc.__class__.__name__ if exc is not None else None,
        stack_trace=format_exception_stack(exc) if exc is not None else None,
        subcommand=command,
        log_source=str(context.get("log_source") or "") or None,
        log_tail=str(context.get("log_tail") or "") or None,
        failure_kind=failure_kind,
        failure_code=failure_code,
        failure_stage=failure_stage,
        context=context,
    )


def run(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    top = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    top.add_argument("--api-base-url")
    top.add_argument("--version", action="store_true")
    top.add_argument("--timeout", type=int)
    top.add_argument("--self-update-url")
    top.add_argument("--skip-self-update", action="store_true", help=argparse.SUPPRESS)
    parsed, passthrough = top.parse_known_args(argv)

    # Parsed for parity; actual timeout handling remains command-specific.
    _ = parsed.timeout

    base_url = resolve_base_url_early(parsed.api_base_url)
    if parsed.version:
        print(f"deepline {_version_label(base_url)}")
        return EXIT_OK

    if not passthrough or passthrough[0] in {"-h", "--help", "help"}:
        print_main_help_dynamic(base_url)
        return EXIT_OK

    cmd = passthrough[0]
    cmd_args = passthrough[1:]
    if any(arg in {"-h", "--help"} for arg in cmd_args):
        handlers = {
            "org": lambda: org.handle(base_url, {}, cmd_args),
            "auth": lambda: auth.handle(base_url, {}, cmd_args),
            "billing": lambda: billing.handle(base_url, {}, cmd_args),
            "feedback": lambda: feedback.handle(base_url, {}, cmd_args),
            "provide-feedback": lambda: feedback.handle(base_url, {}, cmd_args),
            "session": lambda: session.handle(base_url, {}, cmd_args),
            "backend": lambda: backend.handle(base_url, {}, cmd_args),
            "csv": lambda: csv.handle(base_url, {}, cmd_args),
            "workflows": lambda: workflows.handle(base_url, {}, cmd_args),
            "events": lambda: events.handle(base_url, {}, cmd_args),
            "customer-db": lambda: db.handle(base_url, {}, cmd_args),
            "tools": lambda: tools.handle(base_url, {}, cmd_args),
            "list": lambda: tools.handle(base_url, {}, ["list", *cmd_args]),
            "get": lambda: tools.handle(base_url, {}, ["get", *cmd_args]),
            "enrich": lambda: enrich.handle(base_url, {}, cmd_args),
            "quickstart": lambda: onboard.handle(base_url, {}, cmd_args),
            "redeem-code": lambda: billing.handle(base_url, {}, ["redeem-code", *cmd_args]),
            "update": lambda: force_self_update(
                base_url=base_url,
                current_version=VERSION,
                passthrough_args=passthrough,
                check_only=bool("--status" in cmd_args),
            ),
        }
        if cmd in handlers:
            return handlers[cmd]()

    env = load_cli_env(base_url)
    # Allow config-file override if early resolution only got the placeholder
    base_url = resolve_base_url(parsed.api_base_url, env)
    is_update_status = bool(passthrough and passthrough[0] == "update" and "--status" in passthrough[1:])
    _skip_skills_raw = str(os.environ.get("DEEPLINE_SKIP_SKILLS_SYNC", "")).strip().lower()
    _skip_skills = _skip_skills_raw in {"1", "true", "yes", "on"}
    _print_dev_mode_banner(base_url, argv)
    update_check = maybe_self_update(
        base_url=base_url,
        passthrough_args=argv,
        current_version=VERSION,
        override_url=parsed.self_update_url,
        timeout=parsed.timeout if parsed.timeout and parsed.timeout > 0 else 20,
        skip_forced_update_check=is_update_status,
        disabled=_self_update_disabled(parsed),
    )

    if (
        update_check.get("needs_skills_update", False)
        and not is_update_status
        and not _skip_skills
    ):
        _sync_agent_skill(base_url)
        _cleanup_stale_skills(base_url)

    full_command = "deepline " + " ".join(passthrough)
    csv_path = _extract_csv_path_from_args(passthrough)

    handlers = {
        "org": lambda: org.handle(base_url, env, cmd_args),
        "auth": lambda: auth.handle(base_url, env, cmd_args),
        "billing": lambda: billing.handle(base_url, env, cmd_args),
        "feedback": lambda: feedback.handle(base_url, env, cmd_args),
        "provide-feedback": lambda: feedback.handle(base_url, env, cmd_args),
        "session": lambda: session.handle(base_url, env, cmd_args),
        "backend": lambda: backend.handle(base_url, env, cmd_args),
        "csv": lambda: csv.handle(base_url, env, cmd_args),
        "workflows": lambda: workflows.handle(base_url, env, cmd_args),
        "events": lambda: events.handle(base_url, env, cmd_args),
        "customer-db": lambda: db.handle(base_url, env, cmd_args),
        "tools": lambda: tools.handle(base_url, env, cmd_args),
        "list": lambda: tools.handle(base_url, env, ["list", *cmd_args]),
        "get": lambda: tools.handle(base_url, env, ["get", *cmd_args]),
        "enrich": lambda: enrich.handle(base_url, env, cmd_args),
        "quickstart": lambda: onboard.handle(base_url, env, cmd_args),
        "redeem-code": lambda: billing.handle(base_url, env, ["redeem-code", *cmd_args]),
        "update": lambda: force_self_update(
            base_url=base_url,
            current_version=VERSION,
            passthrough_args=passthrough,
            check_only=is_update_status,
        ),
    }

    if cmd in {"version", "-v", "--version"}:
        print(f"deepline {_version_label(base_url)}")
        return EXIT_OK
    if cmd in handlers:
        # Don't emit events for housekeeping commands — they're noise in the activity log.
        # `tools execute` emits its own structured events via _emit_tool_execute_event.
        silent_cmds = {"backend", "auth", "org", "session", "update", "quickstart"}
        if cmd == "tools" and cmd_args and cmd_args[0] == "execute":
            silent_cmds = silent_cmds | {"tools"}
        suppress_activity = (
            str(os.environ.get("DEEPLINE_SUPPRESS_ACTIVITY_EVENTS", ""))
            .strip()
            .lower()
            in {"1", "true", "yes", "on"}
        )
        capture_activity_response = _should_capture_activity_response(passthrough)
        started_at = int(time.time() * 1000)
        run_id = uuid.uuid4().hex
        clear_cli_failure_context()
        if cmd not in silent_cmds and not suppress_activity:
            _emit_cli_event(
                base_url=base_url,
                run_id=run_id,
                command=full_command,
                status="running",
                title=f"Running {cmd}",
                detail="Command started",
                csv_path=csv_path,
                response="",
            )
        captured_output: str | None = None
        exit_code = EXIT_SERVER
        try:
            if cmd not in silent_cmds and not suppress_activity and capture_activity_response:
                buf = io.StringIO()
                try:
                    with contextlib.redirect_stdout(buf):
                        exit_code = handlers[cmd]()
                finally:
                    captured_output = buf.getvalue()
                    if captured_output:
                        sys.stdout.write(captured_output)
            else:
                exit_code = handlers[cmd]()
        except KeyboardInterrupt:
            raise
        except SystemExit:
            raise
        except Exception as exc:
            finished_at = int(time.time() * 1000)
            duration_ms = max(0, finished_at - started_at)
            if is_network_runtime_error(exc):
                _report_cli_failure(
                    base_url=base_url,
                    env=env,
                    argv=passthrough,
                    run_id=run_id,
                    command=cmd,
                    exit_code=EXIT_NETWORK,
                    duration_ms=duration_ms,
                    failure_kind="command_exit",
                    exc=exc,
                )
                print(str(exc), file=sys.stderr)
                clear_cli_failure_context()
                return EXIT_NETWORK
            if cmd not in silent_cmds and not suppress_activity:
                _emit_cli_event(
                    base_url=base_url,
                    run_id=run_id,
                    command=full_command,
                    status="failed",
                    title=f"{cmd} failed",
                    detail=f"Unhandled {exc.__class__.__name__}",
                    exit_code=EXIT_SERVER,
                    duration_ms=duration_ms,
                    csv_path=csv_path,
                    response=captured_output or None,
                )
            _report_cli_failure(
                base_url=base_url,
                env=env,
                argv=passthrough,
                run_id=run_id,
                command=cmd,
                exit_code=EXIT_SERVER,
                duration_ms=duration_ms,
                failure_kind="uncaught_exception",
                exc=exc,
            )
            print(
                f"Unexpected {exc.__class__.__name__}: {format_exception_message(exc).split(': ', 1)[-1]}",
                file=sys.stderr,
            )
            return EXIT_SERVER
        finished_at = int(time.time() * 1000)
        duration_ms = max(0, finished_at - started_at)
        if exit_code in _REPORTABLE_EXIT_CODES and (
            exit_code == EXIT_NETWORK or get_cli_failure_context() is not None
        ):
            _report_cli_failure(
                base_url=base_url,
                env=env,
                argv=passthrough,
                run_id=run_id,
                command=cmd,
                exit_code=exit_code,
                duration_ms=duration_ms,
                failure_kind="command_exit",
            )
        if cmd not in silent_cmds and not suppress_activity:
            _emit_cli_event(
                base_url=base_url,
                run_id=run_id,
                command=full_command,
                status="completed" if exit_code == EXIT_OK else "failed",
                title=f"{cmd} completed" if exit_code == EXIT_OK else f"{cmd} failed",
                detail=f"Exit code {exit_code}",
                exit_code=exit_code,
                duration_ms=duration_ms,
                csv_path=csv_path,
                response=captured_output or None,
            )
        clear_cli_failure_context()
        return exit_code
    if cmd == "wait":
        print("Unknown command: wait", file=sys.stderr)
        print("Did you mean: deepline auth wait", file=sys.stderr)
        print("Run: deepline --help", file=sys.stderr)
        print_main_help_dynamic(base_url)
        return EXIT_UNKNOWN_COMMAND
    if cmd == "inspect":
        print("Command removed:", file=sys.stderr)
        print("  deepline inspect is no longer supported.", file=sys.stderr)
        return EXIT_UNKNOWN_COMMAND

    print(f"Unknown command: {cmd}", file=sys.stderr)
    suggestion = difflib.get_close_matches(cmd, _top_level_commands(), n=1, cutoff=0.55)
    if suggestion:
        if suggestion[0] == "wait":
            print("Did you mean: deepline auth wait", file=sys.stderr)
        else:
            print(f"Did you mean: deepline {suggestion[0]}", file=sys.stderr)
    print("Run: deepline --help", file=sys.stderr)
    print_main_help_dynamic(base_url)
    return EXIT_UNKNOWN_COMMAND
