from __future__ import annotations

import os
import re
import sys
from importlib import metadata
from pathlib import Path
from typing import Dict
from urllib.parse import urlparse

_DEV_SERVER_URL = "http://localhost:3000"
_PROD_SERVER_URL = "https://code.deepline.com"

BASE_URL_PLACEHOLDER = "__DEEPLINE_PY_API_BASE_URL__"
VERSION = "__DEEPLINE_PY_CLI_VERSION__"
SHARE_SESSION_USER_PROMPTS_ENV = "DEEPLINE_SHARE_SESSION_USER_PROMPTS"
PACKAGE_DISTRIBUTION_NAMES = ("deepline", "deepline-cli", "deepline-cli-python")
EXIT_OK = 0
EXIT_UNKNOWN_COMMAND = 1
EXIT_USAGE = 2
EXIT_AUTH = 3
EXIT_NETWORK = 4
EXIT_SERVER = 5
EXIT_NOT_FOUND = 6
EXIT_VALIDATION = 7
EXIT_INTERRUPTED = 130


def _looks_like_placeholder(value: str) -> bool:
    return value.startswith("__") and value.endswith("__")


def installed_package_version() -> str:
    for distribution_name in PACKAGE_DISTRIBUTION_NAMES:
        try:
            resolved = metadata.version(distribution_name).strip()
        except metadata.PackageNotFoundError:
            continue
        except Exception:
            continue
        if resolved:
            return resolved
    return ""


def resolved_cli_version() -> str:
    raw_version = (VERSION or "").strip()
    if raw_version and not _looks_like_placeholder(raw_version):
        return raw_version
    return installed_package_version()


def print_lines(lines: list[str]) -> None:
    for line in lines:
        print(line)


def log(message: str, *, err: bool = False) -> None:
    print(message, file=sys.stderr if err else sys.stdout)


def usage_provide_feedback() -> list[str]:
    return [
        "Usage:",
        '  deepline feedback "Detailed feedback message" [--json]',
        '  deepline provide-feedback "Detailed feedback message" [--json]',
        "",
        "Tip:",
        "  Include repro steps, expected vs actual behavior, and command output snippets.",
    ]


def usage_enrich() -> list[str]:
    return [
        "Usage:",
        "  deepline enrich --input /path/to/file.csv --in-place --with '{\"alias\":\"result\",\"tool\":\"run_javascript\",\"payload\":{\"code\":\"return row;\"},\"run_if_js\":\"return Boolean(row.email);\"}' [--json]",
        "  deepline enrich --input /path/to/file.csv --output /path/to/output.csv --with '{\"alias\":\"result\",\"tool\":\"run_javascript\",\"payload\":{\"code\":\"return row;\"}}' [--json]",
        "  deepline enrich --input /path/to/file.csv --config /path/to/enrich.jsonc [--rows START:END] [--json]",
        "",
        "Options:",
        "  --input PATH              Input CSV path.",
        "  --output PATH             Output CSV path.",
        "  --in-place                Write changes back to the input CSV.",
        "  --config PATH             Run a saved compiled enrich config JSONC file.",
        "  --with SPEC               JSON spec with alias, tool, payload, optional extract_js, optional run_if_js.",
        "  --with-force ALIASES      Recompute selected aliases even if values already exist.",
        "  --with-waterfall GROUP    Start a waterfall group.",
        "  --min-results N           For list waterfalls, stop after at least N results.",
        "  --end-waterfall           Close the current waterfall group.",
        "  --rows START:END          Restrict execution to a row range.",
        "  --all                     Run all rows.",
        "  --dry-run                 Compile and validate without executing tools.",
        "  --json                    Emit JSON summary output.",
        "",
        "Tips:",
        "  Prefer --in-place for iterative reruns; use --with-force to selectively recompute.",
        "  For waterfall blocks, use JSON --with specs with extract_js, e.g. --with '{\"alias\":\"email_step\",\"tool\":\"apollo_people_match\",\"payload\":{...},\"extract_js\":\"(data) => extract(\\\"apollo_people_match\\\", data, \\\"email\\\")\"}' and close with --end-waterfall.",
        "  Inspect tool input/output schemas with `deepline tools get <tool_id> --json`.",
    ]


def _base_url_slug(base_url: str) -> str:
    """Derive a filesystem-safe slug from a base URL for per-environment config dirs.

    Examples:
        https://code.deepline.com  -> code-deepline-com
        http://localhost:3000      -> localhost-3000
        http://localhost:3010      -> localhost-3010
    """
    parsed = urlparse(base_url)
    host = parsed.hostname or "unknown"
    port = parsed.port
    slug = re.sub(r"[^a-zA-Z0-9]", "-", host)
    if port and port not in (80, 443):
        slug = f"{slug}-{port}"
    return slug.lower().strip("-")


def _deepline_config_root(home_dir: str) -> Path:
    return Path(home_dir) / ".local" / "deepline"


def install_component_version_path(home_dir: str, base_url: str, component: str) -> Path:
    normalized_component = component.strip().lower()
    if not normalized_component:
        raise ValueError("component is required")
    return _deepline_config_root(home_dir) / _base_url_slug(base_url) / normalized_component / ".version"


def read_install_component_version(
    base_url: str,
    component: str,
    home_dir: str | None = None,
) -> str:
    resolved_home_dir = home_dir or os.environ.get("HOME", str(Path.home()))
    version_path = install_component_version_path(resolved_home_dir, base_url, component)
    try:
        return version_path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def write_install_component_version(
    base_url: str,
    component: str,
    version: str,
    home_dir: str | None = None,
) -> Path:
    normalized_version = str(version or "").strip()
    if not normalized_version:
        raise ValueError("version is required")
    resolved_home_dir = home_dir or os.environ.get("HOME", str(Path.home()))
    version_path = install_component_version_path(resolved_home_dir, base_url, component)
    version_path.parent.mkdir(parents=True, exist_ok=True)
    version_path.write_text(f"{normalized_version}\n", encoding="utf-8")
    return version_path


from deepline_core.install_info import INSTALL_METHODS as VALID_INSTALL_METHODS


def install_method_path(home_dir: str, base_url: str) -> Path:
    return _deepline_config_root(home_dir) / _base_url_slug(base_url) / "cli" / ".install-method"


def read_install_method(base_url: str, home_dir: str | None = None) -> str:
    resolved = home_dir or os.environ.get("HOME", str(Path.home()))
    path = install_method_path(resolved, base_url)
    try:
        value = path.read_text(encoding="utf-8").strip()
        return value if value in VALID_INSTALL_METHODS else ""
    except Exception:
        return ""


def write_install_method(base_url: str, method: str, home_dir: str | None = None) -> Path:
    normalized = method.strip().lower()
    if normalized not in VALID_INSTALL_METHODS:
        raise ValueError(f"invalid install method: {method!r}")
    resolved = home_dir or os.environ.get("HOME", str(Path.home()))
    path = install_method_path(resolved, base_url)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{normalized}\n", encoding="utf-8")
    return path


def env_file_path(home_dir: str, base_url: str | None = None, *, write: bool = False) -> Path:
    """Return the per-environment config file path.

    If base_url is provided, config is namespaced under a slug subdir.
    For reads: falls back to the legacy flat path if the slug path doesn't exist yet.
    For writes: always uses the slug path (never clobber the shared flat file).
    """
    root = _deepline_config_root(home_dir)
    if base_url:
        slug = _base_url_slug(base_url)
        slug_path = root / slug / ".env"
        if write or slug_path.exists():
            return slug_path
        # Fall back to flat path for reads (pre-migration installs)
        flat_path = root / ".env"
        if flat_path.exists():
            return flat_path
        # Neither exists — return slug path
        return slug_path
    return root / ".env"


def read_env_file(env_path: Path) -> Dict[str, str]:
    if not env_path.exists():
        return {}
    values: Dict[str, str] = {}
    for raw_line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def write_env_file(env_path: Path, values: Dict[str, str]) -> None:
    env_path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    if env_path.exists():
        raw = env_path.read_text(encoding="utf-8", errors="replace").splitlines()
        by_key = {}
        for line in raw:
            if line.startswith("#") or "=" not in line:
                lines.append(line)
                continue
            key, _ = line.split("=", 1)
            by_key[key] = line
        for key in sorted(values.keys()):
            by_key[key] = f"{key}={values[key]}"
        if by_key:
            replaced = []
            keep = set()
            for line in raw:
                if "=" in line:
                    key = line.split("=", 1)[0]
                    if key in by_key:
                        if key not in keep:
                            replaced.append(by_key[key])
                            keep.add(key)
                    else:
                        replaced.append(line)
                else:
                    replaced.append(line)
            for key in by_key:
                if key not in keep:
                    replaced.append(by_key[key])
            lines = replaced
    else:
        lines = [f"{key}={values[key]}" for key in sorted(values.keys())]

    # Fill missing values.
    current_keys = {line.split("=", 1)[0] for line in lines if "=" in line}
    for key, value in sorted(values.items()):
        if key not in current_keys:
            lines.append(f"{key}={value}")

    env_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def cli_env(home_dir: str, base_url: str | None = None) -> Dict[str, str]:
    return read_env_file(env_file_path(home_dir, base_url))


def save_cli_env_values(values: Dict[str, str], base_url: str | None = None) -> Path:
    home_dir = os.environ.get("HOME", str(Path.home()))
    path = env_file_path(home_dir, base_url, write=True)
    write_env_file(path, values)
    return path


def parse_cli_bool(value: object) -> bool | None:
    if value is None:
        return None
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on", "y"}:
        return True
    if normalized in {"0", "false", "no", "off", "n"}:
        return False
    return None


def resolve_base_url_early(cli_base_url: str | None) -> str:
    """Resolve base URL from CLI arg, env var, or baked-in placeholder (no config file needed)."""
    if cli_base_url:
        return cli_base_url.strip()
    env_base = os.environ.get("DEEPLINE_API_BASE_URL", "").strip()
    if env_base:
        return env_base
    # After build, BASE_URL_PLACEHOLDER is a real URL (e.g. http://localhost:3000).
    # For unbuilt source, it's the raw placeholder string — env_file_path handles
    # this by slugifying whatever it gets, which is harmless.
    if not _looks_like_placeholder(BASE_URL_PLACEHOLDER):
        return BASE_URL_PLACEHOLDER
    return _PROD_SERVER_URL


def load_cli_env(base_url: str | None = None) -> Dict[str, str]:
    home_dir = os.environ.get("HOME", str(Path.home()))
    merged = cli_env(home_dir, base_url)
    for key, value in os.environ.items():
        if not isinstance(key, str):
            continue
        if not key.startswith("DEEPLINE_"):
            continue
        merged[key] = str(value)
    return merged


def resolve_base_url(cli_base_url: str | None, env: Dict[str, str]) -> str:
    """Full resolution including config file fallback (kept for backward compat)."""
    if cli_base_url:
        return cli_base_url.strip()
    env_base = os.environ.get("DEEPLINE_API_BASE_URL", "").strip()
    if env_base:
        return env_base
    declared = env.get("DEEPLINE_API_BASE_URL", "").strip()
    if declared:
        return declared
    if not _looks_like_placeholder(BASE_URL_PLACEHOLDER):
        return BASE_URL_PLACEHOLDER
    return _PROD_SERVER_URL


def require_api_key(env: Dict[str, str]) -> int | None:
    if env.get("DEEPLINE_API_KEY"):
        return None
    print("Missing DEEPLINE_API_KEY. Run: deepline auth register")
    return EXIT_AUTH
