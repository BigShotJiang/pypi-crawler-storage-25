from __future__ import annotations

import csv
import contextlib
import io
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import zipfile
import http.client
from pathlib import Path
from urllib.parse import quote, urlparse
import urllib.request
from typing import Any, Dict

_IS_WINDOWS = sys.platform == "win32"
_CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

from deepline_core.command_common import (
    _base_url_slug,
    _deepline_config_root,
    resolve_base_url_early,
)
from deepline_core.http import HttpResponse, http_request, http_request_with_headers


def _resolved_home_dir(home_dir: str | None = None) -> str:
    return home_dir or os.environ.get("HOME", str(Path.home()))


def _legacy_env_dir(home_dir: str | None = None) -> Path:
    return _deepline_config_root(_resolved_home_dir(home_dir))


def _scoped_env_dir(home_dir: str | None = None, base_url: str | None = None) -> Path:
    resolved_base_url = resolve_base_url_early(base_url)
    return _legacy_env_dir(home_dir) / _base_url_slug(resolved_base_url)


def env_dir(
    home_dir: str | None = None,
    base_url: str | None = None,
    *,
    write: bool = False,
) -> Path:
    scoped = _scoped_env_dir(home_dir, base_url)
    if write or scoped.exists():
        return scoped
    return scoped


def runtime_dir(base_url: str | None = None, *, write: bool = False) -> Path:
    scoped = env_dir(base_url=base_url, write=write) / "runtime"
    if write or scoped.exists():
        return scoped
    legacy = _legacy_env_dir() / "runtime"
    if legacy.exists():
        return legacy
    return scoped


def runtime_playground_dir(base_url: str | None = None, *, write: bool = False) -> Path:
    scoped = runtime_dir(base_url=base_url, write=write) / "playground"
    if write or scoped.exists():
        return scoped
    legacy = _legacy_env_dir() / "runtime" / "playground"
    if legacy.exists():
        return legacy
    return scoped


def runtime_playground_dependency_root(
    runtime_pg_dir: Path | None = None,
    *,
    base_url: str | None = None,
) -> Path:
    playground_dir = runtime_pg_dir or runtime_playground_dir(base_url=base_url)
    return playground_dir.parent


def playground_state_path(base_url: str | None = None, *, write: bool = False) -> Path:
    scoped = env_dir(base_url=base_url, write=write) / "runtime" / "state" / "playground-active.json"
    if write or scoped.exists():
        return scoped
    legacy = _legacy_env_dir() / "runtime" / "state" / "playground-active.json"
    if legacy.exists():
        return legacy
    return scoped


def _legacy_python_state_path() -> Path:
    return _legacy_env_dir() / "playground-python.json"


_DEFAULT_BACKEND_URL = "http://127.0.0.1:4173"


def playground_default_api() -> str:
    env_url = (
        os.environ.get("DEEPLINE_TEST_API_URL")
        or os.environ.get("DEEPLINE_PLAYGROUND_API_URL")
        or ""
    ).strip()
    if env_url:
        return env_url

    # Check state file for a running backend on a non-default port.
    state_url = str(playground_read_state().get("backend_api_url") or "").strip()
    if state_url and state_url != _DEFAULT_BACKEND_URL:
        return state_url

    return _DEFAULT_BACKEND_URL


_DEFAULT_BACKEND_PORT = "4173"


def is_local_playground_api(api_url: str) -> bool:
    try:
        parsed = urlparse(api_url)
        host = (parsed.hostname or "").lower()
    except Exception:
        return False
    return host in {"localhost", "0.0.0.0", "::1"} or host.startswith("127.")


def backend_port_from_api_url(api_url: str) -> str:
    try:
        parsed = urlparse(api_url)
        if parsed.port:
            return str(parsed.port)
    except Exception:
        pass
    return _DEFAULT_BACKEND_PORT


def resolve_backend_port() -> str:
    """Extract the port from ``playground_default_api()``."""
    return backend_port_from_api_url(playground_default_api())


def ensure_local_playground_backend(
    base_url: str,
    install_mode: str = "auto",
    quiet: bool = False,
) -> tuple[int, str]:
    from deepline_core.command_common import EXIT_OK
    from deepline_core.commands import backend as backend_commands

    state = playground_read_state()
    playground_api = str(state.get("backend_api_url") or playground_default_api()).strip()
    if not playground_api or not is_local_playground_api(playground_api):
        return EXIT_OK, playground_api

    # Eval / parallel-harness short-circuit: skip the heavyweight
    # start_backend path (which kills sibling run.cjs processes as "stray"
    # runners under concurrent callers). The caller is responsible for
    # pre-warming the backend before kicking off parallel subprocesses.
    # Subsequent playground_api_request calls will surface any backend
    # unavailability themselves with graceful per-command degradation.
    _assume_ready_raw = str(os.environ.get("DEEPLINE_ASSUME_BACKEND_READY", "")).strip().lower()
    if _assume_ready_raw in {"1", "true", "yes", "on"}:
        return EXIT_OK, playground_api

    was_alive = backend_commands.playground_health(playground_api)
    prior_pid = state.get("backend_pid") if isinstance(state.get("backend_pid"), int) else None
    captured_stdout = ""
    if quiet:
        output_buffer = io.StringIO()
        with contextlib.redirect_stdout(output_buffer):
            start_code = backend_commands.start_backend(
                base_url,
                backend_port_from_api_url(playground_api),
                False,
                install_mode,
            )
        captured_stdout = output_buffer.getvalue()
    else:
        start_code = backend_commands.start_backend(
            base_url,
            backend_port_from_api_url(playground_api),
            False,
            install_mode,
        )
    if start_code != EXIT_OK:
        if quiet and captured_stdout.strip():
            print(captured_stdout.rstrip(), file=sys.stderr)
        return start_code, playground_api

    refreshed_state = playground_read_state()
    refreshed_api = str(refreshed_state.get("backend_api_url") or playground_api).strip()
    refreshed_pid = refreshed_state.get("backend_pid") if isinstance(refreshed_state.get("backend_pid"), int) else None
    if quiet:
        emitted_restart_notice = False
        if was_alive:
            if "restarting backend" in captured_stdout.lower():
                print("Session UI backend restarted to apply runtime update.")
                emitted_restart_notice = True
        else:
            started_url = refreshed_api or playground_api
            if isinstance(refreshed_pid, int):
                print(f"Session UI backend started (pid {refreshed_pid}, {started_url}).")
            else:
                print(f"Session UI backend started ({started_url}).")
        # Keep restart signal if PID changed while staying healthy even if the
        # backend message text changes.
        if (
            was_alive
            and not emitted_restart_notice
            and isinstance(prior_pid, int)
            and isinstance(refreshed_pid, int)
            and prior_pid != refreshed_pid
        ):
            print("Session UI backend restarted to apply runtime update.")
    return EXIT_OK, refreshed_api or playground_api


def playground_read_state(base_url: str | None = None) -> Dict[str, Any]:
    p = playground_state_path(base_url=base_url)
    data: Dict[str, Any] = {}
    if p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    if data:
        return data
    legacy = _legacy_python_state_path()
    if legacy.is_file():
        try:
            merged = json.loads(legacy.read_text(encoding="utf-8"))
            if isinstance(merged, dict):
                data = merged
        except Exception:
            pass
    return data


def playground_write_state(data: Dict[str, Any], base_url: str | None = None) -> None:
    p = playground_state_path(base_url=base_url, write=True)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data), encoding="utf-8")


def _is_transient_disconnect_error(message: str) -> bool:
    lowered = str(message or "").strip().lower()
    if not lowered:
        return False
    markers = (
        "remotedisconnected",
        "remote end closed connection",
        "connection reset by peer",
        "broken pipe",
        "connection aborted",
        "connection unexpectedly closed",
        "winerror 10053",
        "winerror 10054",
        "connection refused",
        "winerror 10061",
    )
    return any(marker in lowered for marker in markers)


def playground_api_request(
    method: str,
    api_url: str,
    path: str,
    payload: Dict[str, Any] | None = None,
    csv_path: str = "",
    timeout: int = 30,
) -> tuple[int, str]:
    url = f"{api_url.rstrip('/')}{path}"
    if csv_path:
        sep = "&" if "?" in url else "?"
        # Shell playground API uses `csv` query key for CSV context.
        url = f"{url}{sep}csv={quote(csv_path, safe='')}"
    max_attempts = 4 if _IS_WINDOWS else 2
    for attempt in range(max_attempts):
        try:
            return http_request(method, url, None, payload, timeout=timeout)
        except (RuntimeError, http.client.RemoteDisconnected, ConnectionResetError, BrokenPipeError) as exc:
            err_text = str(exc)
            should_retry = _is_transient_disconnect_error(err_text) and (attempt + 1) < max_attempts
            if should_retry:
                time.sleep(0.5 * float(attempt + 1))
                continue
            return 599, err_text
    return 599, "Failed to reach playground API."


def playground_api_request_with_headers(
    method: str,
    api_url: str,
    path: str,
    payload: Dict[str, Any] | None = None,
    csv_path: str = "",
    timeout: int = 30,
) -> HttpResponse:
    url = f"{api_url.rstrip('/')}{path}"
    if csv_path:
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}csv={quote(csv_path, safe='')}"
    max_attempts = 2
    for attempt in range(max_attempts):
        try:
            return http_request_with_headers(method, url, None, payload, timeout=timeout)
        except (RuntimeError, http.client.RemoteDisconnected, ConnectionResetError, BrokenPipeError) as exc:
            err_text = str(exc)
            should_retry = _is_transient_disconnect_error(err_text) and (attempt + 1) < max_attempts
            if should_retry:
                time.sleep(0.35 * float(attempt + 1))
                continue
            return HttpResponse(status=599, body=err_text, headers={})
    return HttpResponse(status=599, body="Failed to reach playground API.", headers={})


def terminate_pid(pid: int) -> bool:
    target = int(pid)
    if target <= 0:
        return False

    def _process_is_zombie(value: int) -> bool:
        if _IS_WINDOWS:
            return False
        try:
            result = subprocess.run(
                ["ps", "-o", "stat=", "-p", str(value)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
            )
        except Exception:
            return False
        if result.returncode != 0:
            return False
        status = (result.stdout or "").strip()
        return "Z" in status

    def _pid_exists(value: int) -> bool:
        if _IS_WINDOWS:
            try:
                result = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {value}", "/NH"],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    check=False,
                    creationflags=_CREATE_NO_WINDOW,
                )
                return str(value) in (result.stdout or "")
            except Exception:
                return False
        try:
            os.kill(value, 0)
            if _process_is_zombie(value):
                return False
            return True
        except ProcessLookupError:
            return False
        except Exception:
            return True

    if _IS_WINDOWS:
        # taskkill /T handles the full process tree in one call.
        try:
            subprocess.run(
                ["taskkill", "/PID", str(target), "/F", "/T"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                creationflags=_CREATE_NO_WINDOW,
            )
        except Exception:
            return False
        for _ in range(20):
            if not _pid_exists(target):
                return True
            time.sleep(0.1)
        return not _pid_exists(target)

    def _descendants(root_pid: int) -> list[int]:
        # `ps` is available in macOS/Linux and avoids extra Python deps.
        try:
            result = subprocess.run(
                ["ps", "-axo", "pid=,ppid="],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
            )
        except Exception:
            return []
        if result.returncode != 0:
            return []

        children_by_parent: Dict[int, list[int]] = {}
        for raw in (result.stdout or "").splitlines():
            line = raw.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) != 2:
                continue
            if not parts[0].isdigit() or not parts[1].isdigit():
                continue
            child_pid = int(parts[0])
            parent_pid = int(parts[1])
            children_by_parent.setdefault(parent_pid, []).append(child_pid)

        ordered: list[int] = []
        queue: list[int] = [root_pid]
        seen: set[int] = set()
        while queue:
            parent = queue.pop(0)
            for child in children_by_parent.get(parent, []):
                if child in seen:
                    continue
                seen.add(child)
                ordered.append(child)
                queue.append(child)
        return ordered

    targets = _descendants(target)
    targets.append(target)

    for value in targets:
        try:
            os.kill(value, signal.SIGTERM)
        except ProcessLookupError:
            continue
        except Exception:
            return False

    for _ in range(20):
        if all(not _pid_exists(value) for value in targets):
            return True
        time.sleep(0.1)

    for value in targets:
        if not _pid_exists(value):
            continue
        try:
            os.kill(value, signal.SIGKILL)
        except ProcessLookupError:
            continue
        except Exception:
            return False

    for _ in range(20):
        if all(not _pid_exists(value) for value in targets):
            return True
        time.sleep(0.1)
    return all(not _pid_exists(value) for value in targets)


def compact_text(value: str, width: int) -> str:
    text = " ".join(str(value or "").replace("\t", " ").replace("\r", " ").replace("\n", " ").split())
    return text if len(text) <= width else f"{text[: max(0, width - 3)]}..."


def render_ascii(headers: list[str], rows: list[list[str]]) -> str:
    if not headers:
        headers = []
    row = ["" for _ in headers] if not rows else rows[0]
    widths = [
        max(
            len(str(headers[idx])) if idx < len(headers) else 0,
            len(compact_text(row[idx] if idx < len(row) else "", 28)),
        )
        for idx in range(len(headers))
    ]
    widths = [max(w, 1) for w in widths]

    def border() -> str:
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def render(values: list[str]) -> str:
        return "|" + "|".join(" " + compact_text(values[idx] if idx < len(values) else "", widths[idx]).ljust(widths[idx]) + " " for idx in range(len(widths))) + "|"

    lines = [border(), render([str(value) for value in headers]), border()]
    for row_values in rows:
        lines.append(render([str(value) for value in row_values]))
    lines.append(border())
    return "\n".join(lines)


def read_csv_window(csv_path: str, row_start: int, row_end: int) -> tuple[list[str], list[list[str]]]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        all_rows = list(reader)
    if not all_rows:
        return [], []
    headers = [str(h) for h in all_rows[0]]
    data_rows = all_rows[1:]
    if row_start < 0:
        row_start = 0
    if row_end < row_start:
        return headers, []
    return headers, data_rows[row_start : row_end + 1]


def ensure_runtime_playground(base_url: str) -> Path:
    target_dir = runtime_playground_dir()
    run_js = target_dir / "run.cjs"
    dist_dir = target_dir / "dist"
    package_json = target_dir / "package.json"
    package_backend_json = target_dir / "package.backend.json"

    has_package = package_json.is_file() or package_backend_json.is_file()
    if run_js.is_file() and dist_dir.is_dir() and has_package:
        return target_dir

    raise RuntimeError(
        "Local playground runtime is missing. Refresh the CLI/runtime via the update flow and retry."
    )


def _runtime_files_ready(root: Path) -> bool:
    return (root / "run.cjs").is_file() and (root / "dist").is_dir()


def _copy_runtime_contents(src_dir: Path, dst_dir: Path) -> None:
    dst_dir.mkdir(parents=True, exist_ok=True)
    for entry in src_dir.iterdir():
        destination = dst_dir / entry.name
        if entry.is_dir():
            shutil.copytree(entry, destination, dirs_exist_ok=True)
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(entry, destination)


def _promote_nested_runtime_if_present(target_dir: Path) -> bool:
    if not target_dir.is_dir():
        return False
    candidates: list[Path] = []
    for entry in target_dir.iterdir():
        if not entry.is_dir() or not entry.name.startswith("playground.tmp."):
            continue
        if _runtime_files_ready(entry):
            candidates.append(entry)
    if not candidates:
        return False
    candidates.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    _copy_runtime_contents(candidates[0], target_dir)
    return _runtime_files_ready(target_dir)


def refresh_runtime_playground(base_url: str) -> Path:
    target_dir = runtime_playground_dir(base_url=base_url, write=True)
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    version_file = target_dir / ".version"
    run_js = target_dir / "run.cjs"
    dist_dir = target_dir / "dist"
    cached_ready = _runtime_files_ready(target_dir)
    current_version = version_file.read_text(encoding="utf-8").strip() if version_file.is_file() else ""

    manifest_url = f"{base_url.rstrip('/')}/api/v2/cli/playground?meta=1"
    status, raw = http_request("GET", manifest_url, None, None, timeout=20)
    if status != 200:
        if cached_ready:
            return target_dir
        raise RuntimeError(f"Runtime playground API failed (status {status}).")

    try:
        data = json.loads(raw or "{}")
    except Exception as exc:
        if cached_ready:
            return target_dir
        raise RuntimeError("Invalid runtime playground manifest.") from exc

    version = str(data.get("version") or "").strip()
    if not version:
        if cached_ready:
            return target_dir
        raise RuntimeError("Invalid runtime playground manifest.")

    if current_version == version and cached_ready:
        return target_dir

    tmp_dir = target_dir.parent / f"playground.tmp.{os.getpid()}"
    shutil.rmtree(tmp_dir, ignore_errors=True)
    tmp_dir.mkdir(parents=True, exist_ok=True)
    try:
        archive_url = f"{base_url.rstrip('/')}/api/v2/cli/playground"
        archive_request = urllib.request.Request(
            archive_url,
            headers={"Accept": "application/zip"},
        )
        with urllib.request.urlopen(archive_request, timeout=30) as response:
            archive_path = tmp_dir / "playground.zip"
            raw_bytes = response.read()
            content_type = response.headers.get("Content-Type", "")
            archive_path.write_bytes(raw_bytes)
        if not raw_bytes or len(raw_bytes) < 100:
            raise RuntimeError(
                f"Playground archive response too small ({len(raw_bytes)} bytes, "
                f"content-type={content_type!r}); server may have returned an error."
            )
        with zipfile.ZipFile(archive_path, mode="r") as archive:
            archive.extractall(tmp_dir)
        archive_path.unlink(missing_ok=True)
        runtime_run_path = tmp_dir / "runtime-run.cjs"
        if runtime_run_path.is_file():
            runtime_run_path.rename(tmp_dir / "run.cjs")
        (tmp_dir / ".version").write_text(version, encoding="utf-8")
        deployed_in_place = False
        aside: Path | None = None
        if target_dir.is_dir():
            # Rename aside first to avoid lock failures on Windows.
            aside = target_dir.parent / f"playground.old.{os.getpid()}"
            try:
                os.rename(str(target_dir), str(aside))
            except OSError:
                shutil.rmtree(target_dir, ignore_errors=True)
                if target_dir.exists():
                    # If the directory itself is locked on Windows, avoid nesting tmp
                    # dirs by copying the prepared runtime files in place.
                    _copy_runtime_contents(tmp_dir, target_dir)
                    shutil.rmtree(tmp_dir, ignore_errors=True)
                    deployed_in_place = True
                    aside = None
        if not deployed_in_place:
            # Use shutil.move to handle cross-drive moves on Windows.
            shutil.move(str(tmp_dir), str(target_dir))
        if aside is not None and aside.exists():
            shutil.rmtree(aside, ignore_errors=True)
    except Exception as exc:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        if cached_ready:
            return target_dir
        raise RuntimeError(f"Failed to prepare runtime playground files: {exc}") from exc

    if not _runtime_files_ready(target_dir) and _promote_nested_runtime_if_present(target_dir):
        return target_dir
    if not _runtime_files_ready(target_dir):
        # Log what's actually present to help diagnose missing-file issues.
        try:
            contents = sorted(p.name for p in target_dir.iterdir()) if target_dir.is_dir() else []
        except OSError:
            contents = ["<unreadable>"]
        print(
            f"Runtime validation failed: run.cjs={run_js.is_file()}, dist/={dist_dir.is_dir()}, "
            f"target={target_dir}, contents={contents}",
            file=sys.stderr,
        )
        if cached_ready:
            return target_dir
        raise RuntimeError("Runtime playground missing required files.")
    return target_dir


def find_node_bin() -> str | None:
    return shutil.which("node")


def _run_npm_with_runtime_node(workdir: Path, node_bin: str, args: list[str]) -> None:
    npm_cli_candidate = Path(node_bin).resolve().parent.parent / "lib" / "node_modules" / "npm" / "bin" / "npm-cli.js"
    if npm_cli_candidate.is_file():
        cmd = [node_bin, str(npm_cli_candidate), *args]
    else:
        npm_bin = shutil.which("npm")
        if not npm_bin:
            raise RuntimeError("Missing npm executable for playground dependency operations.")
        cmd = [npm_bin, *args]
    result = subprocess.run(
        cmd,
        cwd=str(workdir),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"npm command failed in {workdir}")


def install_playground_dependencies(runtime_pg_dir: Path, node_bin: str) -> None:
    dependency_root = runtime_playground_dependency_root(runtime_pg_dir)
    package_json = dependency_root / "package.json"
    package_backend_json = dependency_root / "package.backend.json"
    fallback_backend_json = runtime_pg_dir / "package.backend.json"
    if not package_backend_json.is_file() and fallback_backend_json.is_file():
        shutil.copyfile(fallback_backend_json, package_backend_json)
    if not package_json.is_file() and package_backend_json.is_file():
        shutil.copyfile(package_backend_json, package_json)
    if not package_json.is_file():
        raise RuntimeError(f"Missing runtime package.json at {package_json}")
    _run_npm_with_runtime_node(dependency_root, node_bin, ["install", "--omit=dev"])


def ensure_playground_native_modules(runtime_pg_dir: Path, node_bin: str) -> None:
    dependency_root = runtime_playground_dependency_root(runtime_pg_dir)
    better_sqlite3_dir = dependency_root / "node_modules" / "better-sqlite3"
    if not better_sqlite3_dir.is_dir():
        return

    def _module_loads() -> bool:
        result = subprocess.run(
            [
                node_bin,
                "-e",
                'const Database = require("better-sqlite3"); const db = new Database(":memory:"); db.prepare("select 1").get(); db.close();',
            ],
            cwd=str(dependency_root),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        return result.returncode == 0

    if _module_loads():
        return

    try:
        _run_npm_with_runtime_node(dependency_root, node_bin, ["rebuild", "better-sqlite3", "--build-from-source"])
    except RuntimeError:
        install_playground_dependencies(runtime_pg_dir, node_bin)

    if not _module_loads():
        raise RuntimeError("Playground dependency check failed: better-sqlite3 is not compatible with the current Node.js runtime.")
