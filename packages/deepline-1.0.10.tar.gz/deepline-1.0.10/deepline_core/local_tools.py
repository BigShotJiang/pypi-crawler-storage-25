from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from subprocess import run as subprocess_run
from typing import Any, Dict, Tuple

from deepline_core.command_common import EXIT_NOT_FOUND, EXIT_SERVER, EXIT_VALIDATION


def _is_usable_directory(candidate: str) -> bool:
    value = str(candidate or "").strip()
    if not value:
        return False
    try:
        return os.path.isdir(value)
    except Exception:
        return False


def _resolve_execution_cwd(cwd_hint: str) -> str:
    hint = str(cwd_hint or "").strip()
    if hint and _is_usable_directory(hint):
        return hint
    try:
        current = os.getcwd()
    except Exception:
        current = ""
    if current and _is_usable_directory(current):
        return current
    home_dir = os.path.expanduser("~")
    if _is_usable_directory(home_dir):
        return home_dir
    return "/"


def execute_read_file(payload: Dict[str, Any]) -> tuple[int, str]:
    if not payload.get("path"):
        return EXIT_VALIDATION, json.dumps({"error": 'Missing required string field "path".'})
    path = str(payload["path"])
    max_bytes = payload.get("max_bytes", 200000)
    if payload.get("max_bytes") is not None:
        if isinstance(max_bytes, bool) or not isinstance(max_bytes, (int, float)) or int(max_bytes) <= 0:
            return EXIT_VALIDATION, json.dumps({"error": 'Field "max_bytes" must be a number when provided.'})
    if not (shutil.which("python3") or shutil.which("python")):
        return EXIT_SERVER, json.dumps({"error": "python3 is required for read_file"})

    script = r'''
import json
import os
import sys

payload = json.loads(sys.argv[1] if len(sys.argv) > 1 else "{}")
path = payload.get("path")
if not isinstance(path, str) or not path.strip():
    raise SystemExit(json.dumps({"error": 'Missing required string field "path".'}))

max_bytes = payload.get("max_bytes", 200000)
if max_bytes is not None:
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, (int, float)):
        raise SystemExit(json.dumps({"error": 'Field "max_bytes" must be a number when provided.'}))
    max_bytes = int(max_bytes)
    if max_bytes <= 0:
        raise SystemExit(json.dumps({"error": 'Field "max_bytes" must be greater than 0.'}))

resolved = os.path.abspath(path)
try:
    with open(resolved, "rb") as handle:
        data = handle.read(max_bytes + 1)
except FileNotFoundError:
    raise SystemExit(json.dumps({"error": f"File not found: {path}", "meta": {"path": path, "resolved_path": resolved}}))
except IsADirectoryError:
    raise SystemExit(json.dumps({"error": f"Path is a directory: {path}", "meta": {"path": path, "resolved_path": resolved}}))

truncated = len(data) > int(max_bytes)
if truncated:
    data = data[: max_bytes]
content = data.decode('utf-8', errors='replace')
print(json.dumps({
    "status": "completed",
    "result": {
        "path": path,
        "resolved_path": resolved,
        "encoding": "utf-8",
        "bytes": len(data),
        "truncated": truncated,
        "content": content,
    },
    "meta": {"executor": "read_file"},
}))
'''

    interpreter = shutil.which("python3") or shutil.which("python")
    if interpreter is None:
        return EXIT_SERVER, json.dumps({"error": "python3 is required for read_file"})
    proc = subprocess_run([interpreter, "-", json.dumps(payload)], input=script, text=True, capture_output=True)
    if proc.returncode != 0:
        out = proc.stderr.strip() or proc.stdout.strip() or "read_file failed"
        if out.startswith("{"):
            return (EXIT_VALIDATION if "path" in out or "max_bytes" in out or "File not found" in out else EXIT_SERVER), out
        return EXIT_SERVER, json.dumps({"error": out})

    output = proc.stdout.strip()
    if not output:
        return EXIT_SERVER, json.dumps({"error": "read_file failed with no output"})
    return 0, output


def execute_run_javascript(payload: Dict[str, Any]) -> tuple[int, str]:
    if not shutil.which("node"):
        return EXIT_SERVER, json.dumps({"error": "node is required for run_javascript"})

    script = r'''
const fs = require("node:fs");
const payloadPath = process.env.DEEPLINE_RUN_JAVASCRIPT_PAYLOAD_PATH || "";
const rawPayload = payloadPath ? fs.readFileSync(payloadPath, "utf8") : "{}";

async function main() {
  let payload;
  try {
    payload = JSON.parse(rawPayload);
  } catch (err) {
    throw new Error(`Invalid payload JSON: ${err.message}`);
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Payload must be an object.");
  }

  const code = typeof payload.code === "string" ? payload.code : "";
  if (!code.trim()) {
    throw new Error('Missing required string field "code".');
  }

  const row = payload.row ?? null;
  const context = payload.context ?? null;

  function normalizePath(raw) {
    return String(raw || "")
      .trim()
      .replace(/\[(\d+)\]/g, ".$1")
      .replace(/\[\*\]/g, ".*")
      .replace(/^\./, "");
  }

  function normalizeContextKey(value) {
    return String(value || "")
      .trim()
      .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");
  }

  function resolveObjectValue(record, lookupKey) {
    if (Object.prototype.hasOwnProperty.call(record, lookupKey)) {
      return record[lookupKey];
    }
    const normalizedLookup = normalizeContextKey(lookupKey);
    if (!normalizedLookup) return null;
    for (const [candidateKey, candidateValue] of Object.entries(record)) {
      if (normalizeContextKey(candidateKey) === normalizedLookup) {
        return candidateValue;
      }
    }
    return null;
  }

  function getByPath(value, rawPath) {
    const path = normalizePath(rawPath);
    if (!path) return value;
    const parts = path.split(".").filter(Boolean);
    let node = value;
    for (const part of parts) {
      if (node == null) return null;
      if (Array.isArray(node)) {
        if (part === "*") {
          if (node.length === 0) return null;
          node = node[0];
          continue;
        }
        const idx = Number(part);
        if (!Number.isInteger(idx) || idx < 0 || idx >= node.length) return null;
        node = node[idx];
        continue;
      }
      if (!node || typeof node !== "object") return null;
      const direct = resolveObjectValue(node, part);
      if (direct !== null && direct !== undefined) {
        node = direct;
        continue;
      }
      const dataNode = node.data;
      if (dataNode && typeof dataNode === "object" && !Array.isArray(dataNode)) {
        const fromData = resolveObjectValue(dataNode, part);
        if (fromData !== null && fromData !== undefined) {
          node = fromData;
          continue;
        }
      }
      return null;
    }
    return node;
  }

  function hasMeaningfulTargetValue(value) {
    if (value == null) return false;
    if (typeof value === "string") return value.trim().length > 0;
    if (Array.isArray(value)) return value.length > 0;
    return true;
  }

  function normalizeListPath(raw) {
    const path = normalizePath(raw);
    if (!path) return path;
    const parts = path.split(".").filter(Boolean);
    const wildcardIndex = parts.indexOf("*");
    if (wildcardIndex === -1) return path;
    return parts.slice(0, wildcardIndex).join(".");
  }

  function firstMeaningfulValue(payloadValue, paths) {
    for (const rawPath of Array.isArray(paths) ? paths : []) {
      const value = getByPath(payloadValue, rawPath);
      if (hasMeaningfulTargetValue(value)) {
        return value;
      }
    }
    return null;
  }

  function resolveList(payloadValue, candidatePaths) {
    const paths = Array.isArray(candidatePaths) ? candidatePaths.map(normalizeListPath) : [];
    if (Array.isArray(payloadValue) && paths.length === 0) {
      return { rows: payloadValue, path: "" };
    }
    for (const path of paths) {
      const value = getByPath(payloadValue, path);
      if (Array.isArray(value)) {
        return { rows: value, path };
      }
    }
    return { rows: [], path: "" };
  }

  function listPathsFromGetterPaths(paths) {
    const out = new Set();
    for (const rawPath of Array.isArray(paths) ? paths : []) {
      const normalized = normalizePath(rawPath);
      if (!normalized) continue;
      const segments = normalized.split(".").filter(Boolean);
      if (segments.length === 0) continue;
      const wildcardIndex = segments.indexOf("*");
      if (wildcardIndex > 0) {
        out.add(normalizeListPath(segments.slice(0, wildcardIndex).join(".")));
        continue;
      }
      const numericIndex = segments.findIndex((segment) => /^\d+$/.test(segment));
      if (numericIndex > 0) {
        out.add(normalizeListPath(segments.slice(0, numericIndex).join(".")));
      }
    }
    return [...out];
  }

  function listPathsFromTargetGetterMap(targetGetterMap, selectedTargets) {
    const sourceTargets = Array.isArray(selectedTargets)
      ? selectedTargets
      : Object.keys(targetGetterMap || {});
    const out = new Set();
    for (const target of sourceTargets) {
      const getterPaths = Array.isArray(targetGetterMap?.[target]) ? targetGetterMap[target] : [];
      for (const listPath of listPathsFromGetterPaths(getterPaths)) {
        if (listPath) out.add(listPath);
      }
    }
    return [...out];
  }

  function availableTargetKeys(targetGetterMap) {
    return Object.entries(targetGetterMap || {})
      .filter(([, paths]) => Array.isArray(paths) && paths.length > 0)
      .map(([key]) => String(key))
      .sort();
  }

  function normalizeExtractKeysSelector(selector) {
    if (!selector || typeof selector !== "object" || Array.isArray(selector)) {
      return null;
    }
    const keys = selector.keys;
    if (!Array.isArray(keys) || keys.length === 0) {
      return null;
    }
    const normalized = [];
    for (const key of keys) {
      if (typeof key !== "string") {
        throw new Error('extract(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
      }
      const normalizedKey = normalizePath(key);
      if (!normalizedKey) {
        throw new Error('extract(tool, data, { keys: [...] }) cannot include empty target keys.');
      }
      normalized.push(normalizedKey);
    }
    return normalized;
  }

  function normalizeExtractListKeysSelector(selector) {
    if (!selector || typeof selector !== "object" || Array.isArray(selector)) {
      return null;
    }
    const keys = selector.keys;
    if (!Array.isArray(keys) || keys.length === 0) {
      throw new Error('extractList(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
    }
    const normalizedKeys = [];
    for (const key of keys) {
      if (typeof key !== "string") {
        throw new Error('extractList(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
      }
      normalizedKeys.push(normalizePath(key));
    }
    return normalizedKeys;
  }

  function relativeGetterPathsForList(getterPaths, listPath) {
    const normalizedListPath = normalizeListPath(listPath || "");
    const out = [];
    for (const rawPath of Array.isArray(getterPaths) ? getterPaths : []) {
      const normalized = normalizePath(rawPath);
      if (!normalized) continue;
      const segments = normalized.split(".").filter(Boolean);
      if (segments.length === 0) continue;
      const wildcardIndex = segments.indexOf("*");
      if (wildcardIndex === -1) continue;
      const prefix = normalizeListPath(segments.slice(0, wildcardIndex).join("."));
      if (!prefix || (normalizedListPath && prefix !== normalizedListPath)) continue;
      out.push(segments.slice(wildcardIndex + 1).join("."));
    }
    return [...new Set(out)];
  }

  function buildDerivedFullName(value, targetGetterMap, listPath, payloadValue) {
    const firstGetterPaths = Array.isArray(targetGetterMap?.first_name) ? targetGetterMap.first_name : [];
    const lastGetterPaths = Array.isArray(targetGetterMap?.last_name) ? targetGetterMap.last_name : [];
    let firstName = null;
    let lastName = null;

    for (const relativePath of relativeGetterPathsForList(firstGetterPaths, listPath)) {
      const candidate = relativePath ? getByPath(value, relativePath) : value;
      if (hasMeaningfulTargetValue(candidate)) {
        firstName = candidate;
        break;
      }
    }
    for (const relativePath of relativeGetterPathsForList(lastGetterPaths, listPath)) {
      const candidate = relativePath ? getByPath(value, relativePath) : value;
      if (hasMeaningfulTargetValue(candidate)) {
        lastName = candidate;
        break;
      }
    }

    if (listPath && !hasMeaningfulTargetValue(firstName)) {
      firstName = firstMeaningfulValue(value, firstGetterPaths);
    }
    if (listPath && !hasMeaningfulTargetValue(lastName)) {
      lastName = firstMeaningfulValue(value, lastGetterPaths);
    }

    if (!listPath && !hasMeaningfulTargetValue(firstName)) {
      firstName = firstMeaningfulValue(payloadValue, firstGetterPaths);
    }
    if (!listPath && !hasMeaningfulTargetValue(lastName)) {
      lastName = firstMeaningfulValue(payloadValue, lastGetterPaths);
    }

    const parts = [firstName, lastName]
      .filter((part) => typeof part === "string")
      .map((part) => part.trim())
      .filter(Boolean);
    return parts.length > 0 ? parts.join(" ") : null;
  }

  function deriveTargetValue({ key, value, targetGetterMap, listPath, payloadValue }) {
    if (key === "full_name") {
      return buildDerivedFullName(value, targetGetterMap, listPath, payloadValue);
    }
    return null;
  }

  function projectRowsByTargets({ rows, listPath, payloadValue, keys, targetGetterMap }) {
    if (!Array.isArray(rows) || rows.length === 0) {
      return [];
    }
    return rows
      .map((rowValue) => {
        const out = {};
        for (const key of keys) {
          const getterPaths = Array.isArray(targetGetterMap?.[key]) ? targetGetterMap[key] : [];
          const relativePaths = relativeGetterPathsForList(getterPaths, listPath);
          let value = null;
          for (const relativePath of relativePaths) {
            const candidate = relativePath ? getByPath(rowValue, relativePath) : rowValue;
            if (hasMeaningfulTargetValue(candidate)) {
              value = candidate;
              break;
            }
          }
          if (!hasMeaningfulTargetValue(value) && listPath) {
            value = firstMeaningfulValue(rowValue, getterPaths);
          }
          if (!hasMeaningfulTargetValue(value)) {
            value = firstMeaningfulValue(payloadValue, getterPaths);
          }
          if (!hasMeaningfulTargetValue(value)) {
            value = deriveTargetValue({
              key,
              value: rowValue,
              targetGetterMap,
              listPath,
              payloadValue,
            });
          }
          out[key] = value == null ? null : value;
        }
        return out;
      })
      .filter((rowValue) =>
        Object.values(rowValue).some((value) => hasMeaningfulTargetValue(value)),
      );
  }

  function normalizeToolConfig(toolOrConfig) {
    if (toolOrConfig && typeof toolOrConfig === "object" && !Array.isArray(toolOrConfig)) {
      const targetGetterMap =
        toolOrConfig.targetGetterMap && typeof toolOrConfig.targetGetterMap === "object" && !Array.isArray(toolOrConfig.targetGetterMap)
          ? toolOrConfig.targetGetterMap
          : toolOrConfig.targetGetters && typeof toolOrConfig.targetGetters === "object" && !Array.isArray(toolOrConfig.targetGetters)
            ? toolOrConfig.targetGetters
            : {};
      const defaultListExtractorPaths = Array.isArray(toolOrConfig.defaultListExtractorPaths)
        ? toolOrConfig.defaultListExtractorPaths
        : Array.isArray(toolOrConfig.listExtractorPaths)
          ? toolOrConfig.listExtractorPaths
          : [];
      const toolId = typeof toolOrConfig.toolId === "string" ? toolOrConfig.toolId.trim() : "";
      return { toolId, targetGetterMap, defaultListExtractorPaths };
    }

    const toolId = typeof toolOrConfig === "string" ? toolOrConfig.trim() : "";
    const registryCandidates = [
      payload.toolMetadata,
      payload.toolCatalog,
      context?.toolMetadata,
      context?.toolCatalog,
    ];
    for (const registry of registryCandidates) {
      if (!registry || typeof registry !== "object" || Array.isArray(registry)) continue;
      const entry = registry[toolId];
      if (entry && typeof entry === "object" && !Array.isArray(entry)) {
        return normalizeToolConfig({ toolId, ...entry });
      }
    }

    return { toolId, targetGetterMap: {}, defaultListExtractorPaths: [] };
  }

  function extract(toolOrConfig, dataValue, selector) {
    const toolConfig = normalizeToolConfig(toolOrConfig);
    const target = (name) => {
      if (typeof name !== "string") {
        throw new Error("extract(tool, data, selector): selector target names must be strings.");
      }
      return firstMeaningfulValue(dataValue, toolConfig.targetGetterMap[String(name).trim()] || []);
    };
    const pick = (paths) => {
      if (!Array.isArray(paths)) return null;
      return firstMeaningfulValue(dataValue, paths);
    };
    const get = (path) => getByPath(dataValue, path);

    if (selector === undefined) {
      return dataValue;
    }
    const keysSelector = normalizeExtractKeysSelector(selector);
    if (keysSelector) {
      const out = {};
      const availableTargets = availableTargetKeys(toolConfig.targetGetterMap);
      for (const key of keysSelector) {
        const getterPaths = Array.isArray(toolConfig.targetGetterMap?.[key]) ? toolConfig.targetGetterMap[key] : [];
        if (getterPaths.length === 0) {
          throw new Error(
            `No registered getter paths exist for target "${key}" on tool "${toolConfig.toolId || "<unknown>"}".` +
              (availableTargets.length > 0
                ? ` Available target keys: ${availableTargets.join(", ")}.`
                : ""),
          );
        }
        out[key] = target(key) ?? null;
      }
      return out;
    }
    if (Array.isArray(selector)) {
      return pick(selector);
    }
    if (typeof selector === "string") {
      return target(selector) ?? get(selector);
    }
    return selector;
  }

  function extractList(toolOrConfig, dataValue, selector) {
    const toolConfig = normalizeToolConfig(toolOrConfig);
    const defaultListPaths = [
      ...toolConfig.defaultListExtractorPaths,
      ...listPathsFromTargetGetterMap(toolConfig.targetGetterMap),
    ];
    if (selector === undefined) {
      return resolveList(dataValue, defaultListPaths).rows;
    }
    const keysSelector = normalizeExtractListKeysSelector(selector);
    if (keysSelector) {
      const availableTargets = availableTargetKeys(toolConfig.targetGetterMap);
      for (const key of keysSelector) {
        const getterPaths = Array.isArray(toolConfig.targetGetterMap?.[key]) ? toolConfig.targetGetterMap[key] : [];
        if (getterPaths.length === 0) {
          throw new Error(
            `No registered getter paths exist for target "${key}" on tool "${toolConfig.toolId || "<unknown>"}".` +
              (availableTargets.length > 0
                ? ` Available target keys: ${availableTargets.join(", ")}.`
                : ""),
          );
        }
      }
      const selectedListPaths = [
        ...defaultListPaths,
        ...listPathsFromTargetGetterMap(toolConfig.targetGetterMap, keysSelector),
      ];
      const resolved = resolveList(dataValue, selectedListPaths);
      return projectRowsByTargets({
        rows: resolved.rows,
        listPath: resolved.path,
        payloadValue: dataValue,
        keys: keysSelector,
        targetGetterMap: toolConfig.targetGetterMap,
      });
    }
    if (Array.isArray(selector)) {
      return resolveList(dataValue, selector).rows;
    }
    if (typeof selector === "string") {
      return resolveList(dataValue, [selector]).rows;
    }
    return [];
  }

  let runner;
  try {
    runner = new Function(
      "input",
      "context",
      "row",
      "extract",
      "extractList",
      `"use strict";\n${code}`,
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const firstLine = String(code).split(/\\r?\\n/, 1)[0] || "";
    const snippet = firstLine.length > 120 ? `${firstLine.slice(0, 117)}...` : firstLine;
    throw new Error(`JavaScript syntax error: ${msg}. First line: ${snippet}`);
  }

  try {
    const result = await runner(payload, context, row, extract, extractList);
    process.stdout.write(JSON.stringify({
      status: "completed",
      result: result === undefined ? null : result,
      meta: { executor: "run_javascript" },
    }));
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new Error(msg);
  }
}

main().catch((err) => {
  const msg = err instanceof Error ? err.message : String(err);
  process.stderr.write(msg + "\\n");
  process.exit(7);
});
'''

    payload_file_path = ""
    try:
        with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as payload_file:
            json.dump(payload, payload_file)
            payload_file_path = payload_file.name
        proc = subprocess_run(
            ["node", "-"],
            input=script,
            text=True,
            capture_output=True,
            env={**os.environ, "DEEPLINE_RUN_JAVASCRIPT_PAYLOAD_PATH": payload_file_path},
        )
        if proc.returncode != 0:
            details = proc.stderr.strip() or proc.stdout.strip()
            if "code" in (details or "") or "payload" in (details or ""):
                msg = details or "run_javascript execution failed"
                if "run_javascript" not in msg:
                    msg = f"run_javascript: {msg}"
                return EXIT_VALIDATION, json.dumps({"error": msg})
            msg = details or "run_javascript execution failed"
            if "run_javascript" not in msg:
                msg = f"run_javascript: {msg}"
            return EXIT_SERVER, json.dumps({"error": msg})
        output = proc.stdout.strip()
        if not output:
            return EXIT_SERVER, json.dumps({"error": "run_javascript execution failed"})
        return 0, output
    finally:
        if payload_file_path:
            try:
                os.unlink(payload_file_path)
            except OSError:
                pass


def evaluate_extract_javascript(payload: Dict[str, Any]) -> tuple[int, str]:
    if not shutil.which("node"):
        return EXIT_SERVER, json.dumps({"error": "node is required for extract_js evaluation"})

    script = r'''
const vm = require("node:vm");
const rawPayload = process.argv[2] || "{}";

function normalizePath(raw) {
  return String(raw || "")
    .trim()
    .replace(/\[(\d+)\]/g, ".$1")
    .replace(/\[\*\]/g, ".*")
    .replace(/^\./, "");
}

function normalizeContextKey(value) {
  return String(value || "")
    .trim()
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function resolveObjectValue(record, lookupKey) {
  if (Object.prototype.hasOwnProperty.call(record, lookupKey)) {
    return record[lookupKey];
  }
  const normalizedLookup = normalizeContextKey(lookupKey);
  if (!normalizedLookup) return null;
  for (const [candidateKey, candidateValue] of Object.entries(record)) {
    if (normalizeContextKey(candidateKey) === normalizedLookup) {
      return candidateValue;
    }
  }
  return null;
}

function getByPath(value, rawPath) {
  const path = normalizePath(rawPath);
  if (!path) return value;
  const parts = path.split(".").filter(Boolean);
  let node = value;
  for (const part of parts) {
    if (node == null) return null;
    if (Array.isArray(node)) {
      if (part === "*") {
        if (node.length === 0) return null;
        node = node[0];
        continue;
      }
      const idx = Number(part);
      if (!Number.isInteger(idx) || idx < 0 || idx >= node.length) return null;
      node = node[idx];
      continue;
    }
    if (!node || typeof node !== "object") return null;
    const direct = resolveObjectValue(node, part);
    if (direct !== null && direct !== undefined) {
      node = direct;
      continue;
    }
    const dataNode = node.data;
    if (dataNode && typeof dataNode === "object" && !Array.isArray(dataNode)) {
      const fromData = resolveObjectValue(dataNode, part);
      if (fromData !== null && fromData !== undefined) {
        node = fromData;
        continue;
      }
    }
    return null;
  }
  return node;
}

function hasMeaningfulTargetValue(value) {
  if (value == null) return false;
  if (typeof value === "string") return value.trim().length > 0;
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

function buildExtractorBindingPayload(payload) {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return { result: payload };
  }
  const unwrappedResult =
    payload.result && typeof payload.result === "object" && !Array.isArray(payload.result)
      ? payload.result
      : null;

  if (unwrappedResult && !Object.prototype.hasOwnProperty.call(payload, "data")) {
    const normalizedData =
      unwrappedResult.data &&
      typeof unwrappedResult.data === "object" &&
      !Array.isArray(unwrappedResult.data)
        ? unwrappedResult.data
        : unwrappedResult;
    return {
      ...payload,
      data: normalizedData,
      result: {
        data: normalizedData,
      },
    };
  }

  return {
    ...payload,
    result: payload,
  };
}

function normalizeListPath(raw) {
  const path = normalizePath(raw);
  if (!path) return path;
  const parts = path.split(".").filter(Boolean);
  const wildcardIndex = parts.indexOf("*");
  if (wildcardIndex === -1) return path;
  return parts.slice(0, wildcardIndex).join(".");
}

function firstMeaningfulValue(payload, paths) {
  for (const rawPath of Array.isArray(paths) ? paths : []) {
    const value = getByPath(payload, rawPath);
    if (hasMeaningfulTargetValue(value)) {
      return value;
    }
  }
  return null;
}

function resolveList(payload, candidatePaths) {
  const paths = Array.isArray(candidatePaths) ? candidatePaths.map(normalizeListPath) : [];
  if (Array.isArray(payload) && paths.length === 0) {
    return { rows: payload, path: "" };
  }
  for (const path of paths) {
    const value = getByPath(payload, path);
    if (Array.isArray(value)) {
      return { rows: value, path };
    }
  }
  return { rows: [], path: "" };
}

function listPathsFromGetterPaths(paths) {
  const out = new Set();
  for (const rawPath of Array.isArray(paths) ? paths : []) {
    const normalized = normalizePath(rawPath);
    if (!normalized) continue;
    const segments = normalized.split(".").filter(Boolean);
    if (segments.length === 0) continue;
    const wildcardIndex = segments.indexOf("*");
    if (wildcardIndex > 0) {
      out.add(normalizeListPath(segments.slice(0, wildcardIndex).join(".")));
      continue;
    }
    const numericIndex = segments.findIndex((segment) => /^\d+$/.test(segment));
    if (numericIndex > 0) {
      out.add(normalizeListPath(segments.slice(0, numericIndex).join(".")));
    }
  }
  return [...out];
}

function listPathsFromTargetGetterMap(targetGetterMap, selectedTargets) {
  const sourceTargets = Array.isArray(selectedTargets)
    ? selectedTargets
    : Object.keys(targetGetterMap || {});
  const out = new Set();
  for (const target of sourceTargets) {
    const getterPaths = Array.isArray(targetGetterMap?.[target]) ? targetGetterMap[target] : [];
    for (const listPath of listPathsFromGetterPaths(getterPaths)) {
      if (listPath) out.add(listPath);
    }
  }
  return [...out];
}

function availableTargetKeys(targetGetterMap) {
  return Object.entries(targetGetterMap || {})
    .filter(([, paths]) => Array.isArray(paths) && paths.length > 0)
    .map(([key]) => String(key))
    .sort();
}

function normalizeExtractKeysSelector(selector) {
  if (!selector || typeof selector !== "object" || Array.isArray(selector)) {
    return null;
  }
  const keys = selector.keys;
  if (!Array.isArray(keys) || keys.length === 0) {
    return null;
  }
  const normalized = [];
  for (const key of keys) {
    if (typeof key !== "string") {
      throw new Error('extract(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
    }
    const normalizedKey = normalizePath(key);
    if (!normalizedKey) {
      throw new Error('extract(tool, data, { keys: [...] }) cannot include empty target keys.');
    }
    normalized.push(normalizedKey);
  }
  return normalized;
}

function normalizeExtractListKeysSelector(selector) {
  if (!selector || typeof selector !== "object" || Array.isArray(selector)) {
    return null;
  }
  const keys = selector.keys;
  if (!Array.isArray(keys) || keys.length === 0) {
    throw new Error('extractList(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
  }
  const normalizedKeys = [];
  for (const key of keys) {
    if (typeof key !== "string") {
      throw new Error('extractList(tool, data, { keys: [...] }) expects a non-empty "keys" string array.');
    }
    normalizedKeys.push(normalizePath(key));
  }
  return normalizedKeys;
}

function relativeGetterPathsForList(getterPaths, listPath) {
  const normalizedListPath = normalizeListPath(listPath || "");
  const out = [];
  for (const rawPath of Array.isArray(getterPaths) ? getterPaths : []) {
    const normalized = normalizePath(rawPath);
    if (!normalized) continue;
    const segments = normalized.split(".").filter(Boolean);
    if (segments.length === 0) continue;
    const wildcardIndex = segments.indexOf("*");
    if (wildcardIndex === -1) continue;
    const prefix = normalizeListPath(segments.slice(0, wildcardIndex).join("."));
    if (!prefix || (normalizedListPath && prefix !== normalizedListPath)) continue;
    out.push(segments.slice(wildcardIndex + 1).join("."));
  }
  return [...new Set(out)];
}

function buildDerivedFullName(value, targetGetterMap, listPath, payload) {
  const firstGetterPaths = Array.isArray(targetGetterMap?.first_name) ? targetGetterMap.first_name : [];
  const lastGetterPaths = Array.isArray(targetGetterMap?.last_name) ? targetGetterMap.last_name : [];
  let firstName = null;
  let lastName = null;

  for (const relativePath of relativeGetterPathsForList(firstGetterPaths, listPath)) {
    const candidate = relativePath ? getByPath(value, relativePath) : value;
    if (hasMeaningfulTargetValue(candidate)) {
      firstName = candidate;
      break;
    }
  }
  for (const relativePath of relativeGetterPathsForList(lastGetterPaths, listPath)) {
    const candidate = relativePath ? getByPath(value, relativePath) : value;
    if (hasMeaningfulTargetValue(candidate)) {
      lastName = candidate;
      break;
    }
  }

  if (listPath && !hasMeaningfulTargetValue(firstName)) {
    firstName = firstMeaningfulValue(value, firstGetterPaths);
  }
  if (listPath && !hasMeaningfulTargetValue(lastName)) {
    lastName = firstMeaningfulValue(value, lastGetterPaths);
  }

  if (!listPath && !hasMeaningfulTargetValue(firstName)) {
    firstName = firstMeaningfulValue(payload, firstGetterPaths);
  }
  if (!listPath && !hasMeaningfulTargetValue(lastName)) {
    lastName = firstMeaningfulValue(payload, lastGetterPaths);
  }

  const parts = [firstName, lastName]
    .filter((part) => typeof part === "string")
    .map((part) => part.trim())
    .filter(Boolean);
  return parts.length > 0 ? parts.join(" ") : null;
}

function deriveTargetValue({ key, value, targetGetterMap, listPath, payload }) {
  if (key === "full_name") {
    return buildDerivedFullName(value, targetGetterMap, listPath, payload);
  }
  return null;
}

function projectRowsByTargets({ rows, listPath, payload, keys, targetGetterMap }) {
  if (!Array.isArray(rows) || rows.length === 0) {
    return [];
  }
  return rows
    .map((row) => {
    const out = {};
    for (const key of keys) {
      const getterPaths = Array.isArray(targetGetterMap?.[key]) ? targetGetterMap[key] : [];
      const relativePaths = relativeGetterPathsForList(getterPaths, listPath);
      let value = null;
      for (const relativePath of relativePaths) {
        const candidate = relativePath ? getByPath(row, relativePath) : row;
        if (hasMeaningfulTargetValue(candidate)) {
          value = candidate;
          break;
        }
      }
      if (!hasMeaningfulTargetValue(value) && listPath) {
        value = firstMeaningfulValue(row, getterPaths);
      }
      if (!hasMeaningfulTargetValue(value)) {
        value = firstMeaningfulValue(payload, getterPaths);
      }
      if (!hasMeaningfulTargetValue(value)) {
        value = deriveTargetValue({
          key,
          value: row,
          targetGetterMap,
          listPath,
          payload,
        });
      }
      out[key] = value == null ? null : value;
    }
    return out;
  })
    .filter((row) =>
      Object.values(row).some((value) => hasMeaningfulTargetValue(value)),
    );
}

async function main() {
  let payload;
  try {
    payload = JSON.parse(rawPayload);
  } catch (err) {
    throw new Error(`Invalid payload JSON: ${err.message}`);
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Payload must be an object.");
  }

  const source = typeof payload.source === "string" ? payload.source.trim() : "";
  if (!source) {
    throw new Error('Missing required string field "source".');
  }

  const rawResultPayload = payload.resultPayload ?? null;
  const resultPayload = buildExtractorBindingPayload(rawResultPayload);
  const bindingPayload = { result: rawResultPayload };
  const rowContext = payload.rowContext ?? null;
  const defaultListExtractorPaths = Array.isArray(payload.defaultListExtractorPaths)
    ? payload.defaultListExtractorPaths
    : [];
  const targetGetterMap =
    payload.targetGetterMap && typeof payload.targetGetterMap === "object" && !Array.isArray(payload.targetGetterMap)
      ? payload.targetGetterMap
      : {};
  const defaultListPaths = [
    ...defaultListExtractorPaths,
    ...listPathsFromTargetGetterMap(targetGetterMap),
  ];

  const toolConfig = {
    toolId: typeof payload.toolId === "string" ? payload.toolId.trim() : "",
    targetGetterMap,
    defaultListExtractorPaths,
  };

  const target = (name) => {
    if (typeof name !== "string") {
      throw new Error("target(...) expects a string target name.");
    }
    return firstMeaningfulValue(
      resultPayload,
      targetGetterMap[String(name).trim()] || [],
    );
  };

  const pick = (paths) => {
    if (!Array.isArray(paths)) return null;
    return firstMeaningfulValue(resultPayload, paths);
  };

  const get = (path) => getByPath(resultPayload, path);

  function resolveInlineToolConfig(toolOrConfig) {
    if (toolOrConfig && typeof toolOrConfig === "object" && !Array.isArray(toolOrConfig)) {
      return {
        toolId: typeof toolOrConfig.toolId === "string" ? toolOrConfig.toolId.trim() : toolConfig.toolId,
        targetGetterMap:
          toolOrConfig.targetGetterMap && typeof toolOrConfig.targetGetterMap === "object" && !Array.isArray(toolOrConfig.targetGetterMap)
            ? toolOrConfig.targetGetterMap
            : toolOrConfig.targetGetters && typeof toolOrConfig.targetGetters === "object" && !Array.isArray(toolOrConfig.targetGetters)
              ? toolOrConfig.targetGetters
              : targetGetterMap,
        defaultListExtractorPaths: Array.isArray(toolOrConfig.defaultListExtractorPaths)
          ? toolOrConfig.defaultListExtractorPaths
          : Array.isArray(toolOrConfig.listExtractorPaths)
            ? toolOrConfig.listExtractorPaths
            : defaultListExtractorPaths,
      };
    }
    return toolConfig;
  }

  function extract(toolOrConfig, dataValue, selector) {
    const hasExplicitTool = arguments.length >= 3;
    const resolvedData = resultPayload;
    const resolvedSelector = hasExplicitTool ? selector : dataValue;
    const resolvedToolConfig = hasExplicitTool
      ? resolveInlineToolConfig(toolOrConfig)
      : toolConfig;

    const targetForData = (name) => {
      if (typeof name !== "string") {
        throw new Error("extract(...) expects a string target name.");
      }
      return firstMeaningfulValue(
        resolvedData,
        resolvedToolConfig.targetGetterMap[String(name).trim()] || [],
      );
    };

    if (resolvedSelector === undefined) {
      return resolvedData;
    }
    const keysSelector = normalizeExtractKeysSelector(resolvedSelector);
    if (keysSelector) {
      const out = {};
      const availableTargets = availableTargetKeys(resolvedToolConfig.targetGetterMap);
      for (const key of keysSelector) {
        const getterPaths = Array.isArray(resolvedToolConfig.targetGetterMap[key]) ? resolvedToolConfig.targetGetterMap[key] : [];
        if (getterPaths.length === 0) {
          throw new Error(
            `No registered getter paths exist for target "${key}" on tool "${resolvedToolConfig.toolId || "<unknown>"}".` +
              (availableTargets.length > 0
                ? ` Available target keys: ${availableTargets.join(", ")}.`
                : ""),
          );
        }
        out[key] = targetForData(key) ?? null;
      }
      return out;
    }
    if (Array.isArray(resolvedSelector)) {
      return firstMeaningfulValue(resolvedData, resolvedSelector);
    }
    if (typeof resolvedSelector === "string") {
      return targetForData(resolvedSelector) ?? getByPath(resolvedData, resolvedSelector);
    }
    return resolvedSelector;
  }

  function extractList(toolOrConfig, dataValue, selector) {
    const hasExplicitTool = arguments.length >= 3;
    const resolvedData = resultPayload;
    const resolvedSelector = hasExplicitTool ? selector : dataValue;
    const resolvedToolConfig = hasExplicitTool
      ? resolveInlineToolConfig(toolOrConfig)
      : toolConfig;
    const resolvedDefaultListPaths = [
      ...resolvedToolConfig.defaultListExtractorPaths,
      ...listPathsFromTargetGetterMap(resolvedToolConfig.targetGetterMap),
    ];

    if (resolvedSelector === undefined) {
      return resolveList(resolvedData, resolvedDefaultListPaths).rows;
    }
    const keysSelector = normalizeExtractListKeysSelector(resolvedSelector);
    if (keysSelector) {
      const availableTargets = availableTargetKeys(resolvedToolConfig.targetGetterMap);
      for (const key of keysSelector) {
        const getterPaths = Array.isArray(resolvedToolConfig.targetGetterMap[key]) ? resolvedToolConfig.targetGetterMap[key] : [];
        if (getterPaths.length === 0) {
          throw new Error(
            `No registered getter paths exist for target "${key}" on tool "${resolvedToolConfig.toolId || "<unknown>"}".` +
              (availableTargets.length > 0
                ? ` Available target keys: ${availableTargets.join(", ")}.`
                : ""),
          );
        }
      }
      const selectedListPaths = [
        ...resolvedDefaultListPaths,
        ...listPathsFromTargetGetterMap(resolvedToolConfig.targetGetterMap, keysSelector),
      ];
      const resolved = resolveList(resolvedData, selectedListPaths);
      return projectRowsByTargets({
        rows: resolved.rows,
        listPath: resolved.path,
        payload: resolvedData,
        keys: keysSelector,
        targetGetterMap: resolvedToolConfig.targetGetterMap,
      });
    }
    if (Array.isArray(resolvedSelector)) {
      return resolveList(resolvedData, resolvedSelector).rows;
    }
    if (typeof resolvedSelector === "string") {
      return resolveList(resolvedData, [resolvedSelector]).rows;
    }
    return [];
  }

  const sandbox = {
    result: bindingPayload,
    out: bindingPayload,
    output_data: bindingPayload,
    row: rowContext,
    extract,
    extractList,
    target,
    pick,
    get,
    Array,
    Boolean,
    JSON,
    Math,
    Number,
    Object,
    String,
  };

  const EXTRACT_JS_VALIDATION_TIMEOUT_MS = 1000;
  const script = new vm.Script(`(() => (${source}))()`);
  const evaluated = script.runInNewContext(sandbox, {
    timeout: EXTRACT_JS_VALIDATION_TIMEOUT_MS,
  });
  const value =
    typeof evaluated === "function"
      ? await evaluated(bindingPayload, rowContext)
      : evaluated;

  process.stdout.write(
    JSON.stringify({
      status: "completed",
      result: value === undefined ? null : value,
      meta: { executor: "extract_js" },
    }),
  );
}

main().catch((err) => {
  const msg = err instanceof Error ? err.message : String(err);
  process.stderr.write(msg + "\n");
  process.exit(7);
});
'''

    proc = subprocess_run(["node", "-", json.dumps(payload)], input=script, text=True, capture_output=True)
    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip() or "extract_js evaluation failed"
        return EXIT_VALIDATION, json.dumps({"error": msg})
    output = proc.stdout.strip()
    if not output:
        return EXIT_SERVER, json.dumps({"error": "extract_js evaluation failed"})
    return 0, output


_EFFORT_PROMPT_PREFIXES: Dict[str, str] = {
    "high": "think hard\n\n",
    "max": "ultrathink\n\n",
}

_EFFORT_SYSTEM_DIRECTIVES: Dict[str, str] = {
    "low": "Respond concisely and directly. Minimize verbose reasoning.",
}

_CODEX_REASONING_EFFORT = "high"


def execute_local_ai_cli(payload: Dict[str, Any], *, executor: str = "local_ai") -> tuple[int, str]:
    if not isinstance(payload, dict):
        return EXIT_VALIDATION, json.dumps({"error": "Payload must be a JSON object"})
    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return EXIT_VALIDATION, json.dumps({"error": 'Missing required string field "prompt".'})
    agent = payload.get("agent")
    if not isinstance(agent, str):
        agent = ""
    model = payload.get("model")
    if not isinstance(model, str):
        model = ""
    effort = ""
    system_prompt = payload.get("system")
    if not isinstance(system_prompt, str):
        system_prompt = ""
    cwd = payload.get("cwd")
    if not isinstance(cwd, str):
        cwd = ""
    execution_cwd = _resolve_execution_cwd(cwd)

    json_mode_raw = payload.get("json_mode")
    if json_mode_raw is None and "json_schema" in payload:
        json_mode_raw = payload.get("json_schema")
    json_schema: dict[str, Any] | None = None
    if isinstance(json_mode_raw, dict):
        json_schema = json_mode_raw
    elif isinstance(json_mode_raw, str):
        stripped = json_mode_raw.strip()
        if stripped:
            try:
                parsed = json.loads(stripped)
            except Exception as exc:
                return EXIT_VALIDATION, json.dumps({"error": f'Field "json_mode" string must contain valid JSON schema: {exc}'})
            if not isinstance(parsed, dict):
                return EXIT_VALIDATION, json.dumps({"error": 'Field "json_mode" must resolve to a JSON object schema.'})
            json_schema = parsed
    elif json_mode_raw is True:
        # Accept boolean true as "return any valid JSON object"
        json_schema = {"type": "object"}
    elif json_mode_raw is not None:
        return EXIT_VALIDATION, json.dumps({"error": 'Field "json_mode" must be a JSON object schema, a JSON string, or true.'})
    json_mode_enabled = json_schema is not None

    allowed_tools = payload.get("allowed_tools")
    if allowed_tools is None:
        allowed_tools = payload.get("allowedTools")
    if isinstance(allowed_tools, list):
        normalized: list[str] = []
        for item in allowed_tools:
            if not isinstance(item, str):
                return EXIT_VALIDATION, json.dumps({"error": 'Field "allowed_tools" array entries must be strings.'})
            value = item.strip()
            if value:
                normalized.append(value)
        allowed_tools = ",".join(normalized)
    elif isinstance(allowed_tools, str):
        allowed_tools = allowed_tools.strip()
    elif allowed_tools is None:
        allowed_tools = ""
    else:
        return EXIT_VALIDATION, json.dumps({"error": 'Field "allowed_tools" must be a string or string array.'})

    has_codex = shutil.which("codex") is not None
    has_claude = shutil.which("claude") is not None
    requested = agent.strip() if isinstance(agent, str) else ""
    if not requested or requested == "auto":
        requested = "auto"

    if executor == "call_local_claude_code":
        requested = "claude"
    elif executor == "call_local_codex":
        requested = "codex"

    selected_agent = ""
    if requested == "codex":
        if has_codex:
            selected_agent = "codex"
    elif requested == "claude":
        if has_claude:
            selected_agent = "claude"
    else:
        if has_claude:
            selected_agent = "claude"
        elif has_codex:
            selected_agent = "codex"
    if not selected_agent:
        return EXIT_NOT_FOUND, json.dumps({"error": "No supported AI CLI found. Install `codex` or `claude`."})

    if selected_agent == "claude":
        effort = "low"

    if not model:
        if selected_agent == "claude":
            model = "haiku"
        else:
            model = ""

    if json_mode_enabled and isinstance(json_schema, dict):
        schema_pretty = json.dumps(json_schema, ensure_ascii=False, indent=2)
        json_mode_system_prompt = (
            "<important>\n"
            "STRICT JSON OUTPUT REQUIRED.\n"
            "Return exactly one JSON object that matches this JSON Schema:\n"
            f"{schema_pretty}\n"
            "Do not include markdown, code fences, or explanatory text.\n"
            "Do not include keys that are not allowed by the schema.\n"
            "</important>"
        )
        if system_prompt:
            system_prompt = f"{system_prompt}\n\n{json_mode_system_prompt}"
        else:
            system_prompt = json_mode_system_prompt

    claude_research_system_prompt_shim = (
        "You are running inside Deepline with Bash and web search tools available.\n"
        "For company/contact/web research tasks, use web providers aggressively and in parallel.\n"
        "Query strategy:\n"
        "1) Generate multiple query variants before deciding (name+company, role+company, site:linkedin.com/in, domain variants, and spelling variants).\n"
        "2) Run these tools via Bash and compare overlap:\n"
        "   - deepline tools execute serper_google_search --payload '{\"query\":\"...\",\"num\":5,\"gl\":\"us\",\"hl\":\"en\"}' --json\n"
        "   - deepline tools execute exa_search --payload '{\"query\":\"...\",\"numResults\":5,\"type\":\"fast\"}' --json\n"
        "   - deepline tools execute parallel_search --payload '{\"objective\":\"...\",\"max_results\":5}' --json\n"
        "3) Prefer answers supported by multiple sources.\n"
        "4) Always return source links, and explicitly state uncertainty if evidence conflicts."
    )
    if selected_agent == "claude":
        if not allowed_tools:
            allowed_tools = str(os.environ.get("DEEPLINE_CLAUDE_ALLOWED_TOOLS") or "WebSearch,Bash")
        if system_prompt:
            system_prompt = f"{claude_research_system_prompt_shim}\n\nAdditional user system instructions:\n{system_prompt}"
        else:
            system_prompt = claude_research_system_prompt_shim
        if effort:
            effort_directive = _EFFORT_SYSTEM_DIRECTIVES.get(effort, "")
            if effort_directive:
                system_prompt = f"{effort_directive}\n\n{system_prompt}"
            effort_prefix = _EFFORT_PROMPT_PREFIXES.get(effort, "")
            if effort_prefix:
                prompt = effort_prefix + prompt

    # Build command args per agent, then run through a shared subprocess call
    # that isolates env (CLAUDECODE) and stdin (/dev/null) — mirroring the
    # playground backend's spawn config in 40-block-execution.ts.
    try:
        if selected_agent == "codex":
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"System instructions:\n{system_prompt}\n\nUser prompt:\n{prompt}"
            args = ["codex", "exec", "--skip-git-repo-check", "--color", "never"]
            args.extend(["-c", f'model_reasoning_effort="{_CODEX_REASONING_EFFORT}"'])
            if model:
                args.extend(["-m", model])
            if execution_cwd:
                args.extend(["-C", execution_cwd])
            args.append(full_prompt)
        else:
            args = ["claude", "-p"]
            if allowed_tools:
                args.extend(["--allowedTools", allowed_tools])
            if system_prompt:
                args.extend(["--system-prompt", system_prompt])
            if model:
                args.extend(["--model", model])
            args.append(prompt)
            timeout_cmd = shutil.which("gtimeout") or shutil.which("timeout")
            if timeout_cmd:
                args = [timeout_cmd, "120"] + args

        # Shared subprocess call: clear CLAUDECODE to prevent nested-session
        # rejection, close stdin so the child doesn't hang on an inherited pipe.
        spawn_env = {**os.environ, "CLAUDECODE": ""}
        proc = subprocess_run(args, text=True, capture_output=True, cwd=execution_cwd, env=spawn_env, stdin=subprocess.DEVNULL)
        call_output = (proc.stdout or "").rstrip("\n")
        call_status = proc.returncode
        stderr_text = proc.stderr or ""

        if selected_agent != "codex" and call_status in (124, 142):
            return EXIT_SERVER, json.dumps(
                {
                    "error": "call_local_claude_code timed out after 120 seconds.",
                    "meta": {"selected_agent": selected_agent, "exit_status": str(call_status)},
                }
            )
    except Exception as exc:
        return EXIT_SERVER, json.dumps({"error": f"AI CLI execution failed: {exc}", "meta": {"selected_agent": selected_agent}})

    if call_status != 0:
        error_text = stderr_text.strip() or call_output.strip() or f"AI CLI exited with status {call_status}."
        return EXIT_SERVER, json.dumps({"error": error_text, "meta": {"selected_agent": selected_agent, "exit_status": str(call_status)}})

    if json_mode_enabled and isinstance(json_schema, dict):
        value = (call_output or "").strip()
        if value.startswith("```"):
            value = re.sub(r"^\s*```(?:json)?\s*", "", value, flags=re.IGNORECASE)
            value = re.sub(r"\s*```\s*$", "", value, flags=re.IGNORECASE).strip()

        def first_valid_json_candidate(text: str) -> str:
            starts: list[tuple[int, str]] = []
            for ch in ("{", "["):
                idx = text.find(ch)
                if idx != -1:
                    starts.append((idx, ch))
            starts.sort(key=lambda item: item[0])
            for idx, ch in starts:
                closing = "}" if ch == "{" else "]"
                end = text.rfind(closing)
                if end == -1 or end < idx:
                    continue
                candidate = text[idx : end + 1].strip()
                try:
                    json.loads(candidate)
                    return candidate
                except Exception:
                    continue
            return text.strip()

        json_candidate = first_valid_json_candidate(value)
        try:
            parsed_output = json.loads(json_candidate)
        except Exception as exc:
            return EXIT_SERVER, json.dumps({"error": f"Model output is not valid JSON: {exc}", "meta": {"selected_agent": selected_agent}})
        if not isinstance(parsed_output, dict):
            return EXIT_SERVER, json.dumps({"error": "Model output must be a JSON object in json_mode.", "meta": {"selected_agent": selected_agent}})

        def validate_subset(instance: Any, schema: dict[str, Any], path: str = "$") -> None:
            schema_type = schema.get("type")
            if isinstance(schema_type, str):
                if schema_type == "object" and not isinstance(instance, dict):
                    raise ValueError(f"{path}: expected object, got {type(instance).__name__}")
                if schema_type == "array" and not isinstance(instance, list):
                    raise ValueError(f"{path}: expected array, got {type(instance).__name__}")
                if schema_type == "string" and not isinstance(instance, str):
                    raise ValueError(f"{path}: expected string, got {type(instance).__name__}")
                if schema_type == "number" and (not isinstance(instance, (int, float)) or isinstance(instance, bool)):
                    raise ValueError(f"{path}: expected number, got {type(instance).__name__}")
                if schema_type == "integer" and (not isinstance(instance, int) or isinstance(instance, bool)):
                    raise ValueError(f"{path}: expected integer, got {type(instance).__name__}")
                if schema_type == "boolean" and not isinstance(instance, bool):
                    raise ValueError(f"{path}: expected boolean, got {type(instance).__name__}")
                if schema_type == "null" and instance is not None:
                    raise ValueError(f"{path}: expected null, got {type(instance).__name__}")
            enum_values = schema.get("enum")
            if isinstance(enum_values, list) and instance not in enum_values:
                raise ValueError(f"{path}: value not in enum {enum_values}")
            if isinstance(instance, dict):
                required = schema.get("required")
                if isinstance(required, list):
                    for key in required:
                        if isinstance(key, str) and key not in instance:
                            raise ValueError(f'{path}: missing required field "{key}"')
                properties = schema.get("properties")
                props = properties if isinstance(properties, dict) else {}
                if schema.get("additionalProperties") is False:
                    for key in instance.keys():
                        if key not in props:
                            raise ValueError(f'{path}: unexpected field "{key}"')
                for key, prop_schema in props.items():
                    if key in instance and isinstance(prop_schema, dict):
                        validate_subset(instance[key], prop_schema, f"{path}.{key}")
            if isinstance(instance, list):
                items_schema = schema.get("items")
                if isinstance(items_schema, dict):
                    for idx, item in enumerate(instance):
                        validate_subset(item, items_schema, f"{path}[{idx}]")

        try:
            validate_subset(parsed_output, json_schema)
        except Exception as exc:
            return EXIT_SERVER, json.dumps({"error": f"Model JSON does not match json_mode schema: {exc}", "meta": {"selected_agent": selected_agent}})
        call_output = json.dumps(parsed_output, ensure_ascii=False)

    return 0, json.dumps(
        {
            "status": "completed",
            "result": {"output": call_output},
            "meta": {
                "selected_agent": selected_agent,
                "model": model or None,
                "json_mode": json_mode_enabled,
                "json_schema": json_schema if json_mode_enabled else None,
            },
        },
        ensure_ascii=False,
    )
