"""Canonical install-method and binary-path detection for the Deepline CLI.

Every caller that needs to know *how* the CLI was installed or *where* the
binary lives should go through ``detect()``.  The result is a lightweight
``InstallInfo`` value object that carries both pieces of information.

Adding a new install method (e.g. ``brew``, ``npm``) is a two-step change:
  1. Add the literal to ``InstallMethod``.
  2. Add a detection branch in ``_detect_method()``.
"""
from __future__ import annotations

import os
import shutil
import sys
import zipfile
from dataclasses import dataclass
from typing import Literal

# ── Supported install methods ───────────────────────────────────────────────
# Extend this union + INSTALL_METHODS tuple when adding a new distribution
# channel.  The rest of the module (and callers) key off these values.

InstallMethod = Literal["shiv", "pip", "pipx"]
INSTALL_METHODS: tuple[InstallMethod, ...] = ("shiv", "pip", "pipx")


@dataclass(frozen=True)
class InstallInfo:
    """Immutable snapshot of how the running CLI was installed."""

    method: InstallMethod
    """How the CLI was installed (shiv zipapp, pip, or pipx)."""

    binary_path: str | None
    """Resolved absolute path to the running CLI binary, or *None* when it
    cannot be determined (e.g. invoked via ``python -m``)."""

    @property
    def is_shiv(self) -> bool:
        return self.method == "shiv"

    @property
    def is_pip(self) -> bool:
        return self.method in ("pip", "pipx")

    @property
    def update_command(self) -> str:
        """Human-readable command to run for a manual upgrade."""
        if self.method == "pipx":
            return "pipx upgrade deepline"
        if self.method == "pip":
            return "pip install --upgrade deepline"
        return "deepline update"


# ── Detection helpers ───────────────────────────────────────────────────────

def _resolve_binary_path() -> str | None:
    """Best-effort resolution of the running CLI binary's absolute path."""
    argv0 = sys.argv[0] if sys.argv else ""
    if not argv0:
        return None
    candidate = argv0
    if not os.path.isabs(candidate):
        resolved = shutil.which(candidate)
        if resolved:
            candidate = resolved
    candidate = os.path.realpath(candidate)
    if not os.path.isfile(candidate):
        return None
    return candidate


def _is_zipapp(path: str | None) -> bool:
    """True when *path* is a shiv / zipapp archive."""
    if not path:
        return False
    try:
        return zipfile.is_zipfile(path)
    except Exception:
        return False


def _detect_method(binary_path: str | None) -> InstallMethod:
    """Determine install method from runtime signals.

    Resolution order (first match wins):

    1. ``DEEPLINE_INSTALL_METHOD`` env-var override.
    2. Binary is a zipapp → ``shiv``.
    3. ``sys.prefix`` / ``sys.argv[0]`` contain "pipx" → ``pipx``.
    4. Fallback → ``pip``.
    """
    env = (os.environ.get("DEEPLINE_INSTALL_METHOD") or "").strip().lower()
    if env in INSTALL_METHODS:
        return env  # type: ignore[return-value]

    if _is_zipapp(binary_path):
        return "shiv"

    prefix = (getattr(sys, "prefix", "") or "").lower()
    exe = (sys.argv[0] if sys.argv else "").lower()
    if "pipx" in prefix or "pipx" in exe:
        return "pipx"

    return "pip"


# ── Public API ──────────────────────────────────────────────────────────────

def detect() -> InstallInfo:
    """Detect install method and binary path for the running CLI process.

    This is the **single entry-point** the rest of the codebase should use.
    It is intentionally stateless — it never reads or writes the persisted
    ``.install-method`` marker; the caller (self-update) owns persistence.
    """
    binary_path = _resolve_binary_path()
    method = _detect_method(binary_path)
    return InstallInfo(method=method, binary_path=binary_path)
