"""Dynamic loading of Service instances from entrypoint strings."""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

from uniac.service import FastAPIService, Service


class LoadError(Exception):
    """Failed to load the user's Service."""


def setup_import_path(project_dir: str = ".", deps_dir: str = "deps") -> None:
    """Configure sys.path so user code and bundled dependencies are importable.

    This must be called before any attempt to import user modules.

    Args:
        project_dir: Root directory containing user code.
        deps_dir: Subdirectory name for pre-bundled pip dependencies.
    """
    project = str(Path(project_dir).resolve())
    deps = str((Path(project_dir).resolve() / deps_dir))

    if deps not in sys.path:
        sys.path.insert(0, deps)
    if project not in sys.path:
        sys.path.insert(0, project)


def load_service(entrypoint: str) -> Service:
    """Import and return a Service instance from an entrypoint string.

    Args:
        entrypoint: ``module:object`` (e.g. ``app:app``).
            The object may be a Service instance (returned directly)
            or a Service subclass (instantiated and returned).

    Returns:
        A Service instance.

    Raises:
        LoadError: if the module cannot be imported, the attribute is missing,
                   or it is not a Service instance or subclass.
    """
    if ":" not in entrypoint:
        raise LoadError(
            f"Invalid entrypoint {entrypoint!r}: expected 'module:object' format"
        )

    module_name, attr_name = entrypoint.split(":", 1)
    if not module_name or not attr_name:
        raise LoadError(
            f"Invalid entrypoint {entrypoint!r}: module and object must be non-empty"
        )

    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        raise LoadError(f"Cannot import module {module_name!r}: {exc}") from exc

    obj = getattr(mod, attr_name, None)
    if obj is None:
        raise LoadError(
            f"Module {module_name!r} has no attribute {attr_name!r}"
        )

    # Instance — return directly.
    if isinstance(obj, Service):
        return obj

    # Class — instantiate and return.
    if isinstance(obj, type) and issubclass(obj, Service):
        return obj()

    raise LoadError(
        f"{module_name}:{attr_name} is not a Service instance or subclass"
    )
