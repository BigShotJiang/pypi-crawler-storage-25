"""Tests for uniac_runtime.server."""
import asyncio

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel

from uniac import FastAPIService
from uniac_runtime.server import (
    StartupTimeline,
    create_app,
    readiness_target_from_env,
    send_ready_callback,
)


# -- Test services ----------------------------------------------------------


class _GreetBody(BaseModel):
    name: str


class _AddBody(BaseModel):
    a: int
    b: int


class GreetService(FastAPIService):
    def build_app(self) -> FastAPI:
        api = FastAPI()

        @api.get("/greet")
        def greet(name: str):
            return {"message": f"Hello {name}"}

        @api.post("/greet")
        def greet_post(body: _GreetBody):
            return {"message": f"Hello {body.name}"}

        return api


class MathService(FastAPIService):
    def build_app(self) -> FastAPI:
        api = FastAPI()

        @api.get("/add")
        def add(a: int, b: int):
            return {"result": a + b}

        @api.post("/add")
        def add_post(body: _AddBody):
            return {"result": body.a + body.b}

        return api


class MultiService(FastAPIService):
    def build_app(self) -> FastAPI:
        api = FastAPI()

        @api.get("/greet")
        def greet(name: str):
            return {"message": f"Hello {name}"}

        @api.get("/health")
        def health():
            return {"status": "ok"}

        return api


class NotAService:
    pass


# -- Fixtures ---------------------------------------------------------------


@pytest.fixture()
def greet_client():
    return TestClient(create_app(GreetService()))


@pytest.fixture()
def multi_client():
    return TestClient(create_app(MultiService()))


@pytest.fixture()
def math_client():
    return TestClient(create_app(MathService()))


# -- create_app type guard --------------------------------------------------


class TestCreateApp:

    def test_rejects_non_service(self):
        with pytest.raises(TypeError, match="FastAPIService"):
            create_app(NotAService())

    def test_returns_fastapi_instance(self):
        app = create_app(GreetService())
        assert isinstance(app, FastAPI)

    def test_delegates_to_build_app(self):
        """create_app() must return the exact FastAPI instance from build_app()."""
        svc = GreetService()
        expected = svc.build_app()
        # Each call to build_app() returns a new instance; verify create_app
        # produces a valid FastAPI app with the same routes.
        result = create_app(GreetService())
        assert isinstance(result, FastAPI)


class TestReadinessHelpers:

    def test_readiness_target_from_env(self):
        target = readiness_target_from_env(
            {
                "UNIAC_READY_URL": "http://172.16.0.1:8080/internal/runtimes/ready",
                "UNIAC_READY_TOKEN": "secret-token",
            }
        )

        assert target == (
            "http://172.16.0.1:8080/internal/runtimes/ready",
            "secret-token",
        )

    def test_startup_timeline_only_emits_available_timings(self):
        timeline = StartupTimeline(process_entry=10.0)
        timeline.import_path_ready = 10.100
        timeline.service_loaded = 10.250
        timeline.app_built = 10.400
        timeline.server_started = 11.000

        assert timeline.as_timings() == {
            "process_entry_to_import_path": 0.1,
            "import_path_to_service_load": 0.15,
            "service_load_to_app_build": 0.15,
            "app_build_to_server_started": 0.6,
            "process_entry_to_server_started": 1.0,
        }

    def test_send_ready_callback_includes_timings(self, monkeypatch):
        captured: dict[str, object] = {}

        class _Response:
            status = 200

            def read(self):
                return b""

            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return None

        def fake_urlopen(request, timeout):
            captured["url"] = request.full_url
            captured["body"] = request.data.decode("utf-8")
            captured["timeout"] = timeout
            return _Response()

        monkeypatch.setattr("uniac_runtime.server.urllib.request.urlopen", fake_urlopen)

        status = asyncio.run(
            send_ready_callback(
                "http://172.16.0.1:8080/internal/runtimes/ready",
                "secret-token",
                {"process_entry_to_server_started": 0.123},
            )
        )

        assert status == 200
        assert captured == {
            "url": "http://172.16.0.1:8080/internal/runtimes/ready",
            "body": (
                '{"token": "secret-token", "timings": '
                '{"process_entry_to_server_started": 0.123}}'
            ),
            "timeout": 5,
        }


# -- FastAPI app tests (using TestClient) -----------------------------------


class TestAppRoutes:

    def test_get_route_with_query_params(self, greet_client):
        resp = greet_client.get("/greet", params={"name": "Alice"})
        assert resp.status_code == 200
        assert resp.json() == {"message": "Hello Alice"}

    def test_post_route_with_json_body(self, greet_client):
        resp = greet_client.post("/greet", json={"name": "Bob"})
        assert resp.status_code == 200
        assert resp.json() == {"message": "Hello Bob"}

    def test_unknown_route_returns_404(self, greet_client):
        resp = greet_client.get("/nonexistent")
        assert resp.status_code == 404

    def test_health_route(self, multi_client):
        resp = multi_client.get("/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    def test_multiple_routes(self, multi_client):
        resp = multi_client.get("/greet", params={"name": "X"})
        assert resp.status_code == 200

        resp = multi_client.get("/health")
        assert resp.status_code == 200

    def test_integer_query_params(self, math_client):
        resp = math_client.get("/add", params={"a": 2, "b": 3})
        assert resp.status_code == 200
        assert resp.json() == {"result": 5}

    def test_integer_post_params(self, math_client):
        resp = math_client.post("/add", json={"a": 2, "b": 3})
        assert resp.status_code == 200
        assert resp.json() == {"result": 5}
