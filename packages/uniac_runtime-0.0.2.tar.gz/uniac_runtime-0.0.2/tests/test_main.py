"""Tests for ``uniac_runtime.__main__._serve_app``.

The critical invariant exercised here is the readiness-callback ordering:
the host (NodeManager) treats the ``UNIAC_READY_URL`` POST as
"the guest is ready to take requests" and acts on it immediately by
registering Caddy + Consul.  If the callback fires before the listening
socket has called ``listen()``, Caddy's first connect 502s.

The runtime binds + listens the socket itself (then hands the fd to
uvicorn), so the readiness signal is the kernel's listen syscall return
— not a polled flag, not a self-probe. Once ``listen()`` returns the
kernel completes TCP handshakes into the accept queue, so connections
succeed even before uvicorn enters its accept loop.
"""
from __future__ import annotations

import asyncio
import socket
import sys
import types
from dataclasses import dataclass

import pytest


def _free_port() -> int:
    """Grab a free TCP port for the runtime to bind."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


@dataclass
class _FakeTimeline:
    """Tiny stand-in for ``StartupTimeline`` recording only marks."""

    marks: list[str]

    def mark(self, name: str) -> None:
        self.marks.append(name)

    def as_timings(self) -> dict[str, float]:
        return {}


class _FakeServer:
    """Stand-in for ``uvicorn.Server``.

    Receives the pre-bound socket via ``serve(sockets=[...])`` (matching
    real uvicorn's signature) and just holds it open until ``should_exit``
    flips. The fact that the socket is already in LISTEN state when ``serve``
    is called is the contract under test.
    """

    def __init__(self) -> None:
        self.should_exit = False
        self.received_sockets: list[socket.socket] = []

    async def serve(self, sockets: list[socket.socket] | None = None) -> None:
        self.received_sockets = list(sockets or [])
        while not self.should_exit:
            await asyncio.sleep(0.005)


def _install_fake_uvicorn(monkeypatch: pytest.MonkeyPatch, server: _FakeServer) -> None:
    """Inject a fake ``uvicorn`` module so ``import uvicorn`` inside
    ``_serve_app`` resolves to our stub.
    """

    fake = types.ModuleType("uvicorn")

    class _Config:
        def __init__(self, app, log_level=None, **_kwargs):  # noqa: D401 - stub
            self.app = app
            self.log_level = log_level

    def _server_factory(_config: _Config) -> _FakeServer:
        return server

    fake.Config = _Config  # type: ignore[attr-defined]
    fake.Server = _server_factory  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "uvicorn", fake)


def _connect_works(port: int, *, timeout: float = 0.05) -> bool:
    """Synchronous TCP probe: does a connect to 127.0.0.1:port succeed?"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


@pytest.mark.asyncio
async def test_callback_fires_after_listener_accepts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The readiness callback must observe a listening socket.

    Regression: previous implementations either fired the callback before
    binding (Caddy 502s), or polled ``Server.started`` and a self-probe
    that could time out and fire anyway. The fix is to bind+listen first,
    then fire the callback — making the kernel's listen syscall the
    synchronization primitive. This test asserts an external TCP connect
    to the port succeeds at the moment the callback fires.
    """
    from uniac_runtime import __main__ as runtime_main

    port = _free_port()
    server = _FakeServer()
    _install_fake_uvicorn(monkeypatch, server)

    callback_listener_open: list[bool] = []

    async def _fake_send(url: str, token: str, timings):
        callback_listener_open.append(_connect_works(port))
        return 200

    monkeypatch.setattr(runtime_main, "send_ready_callback", _fake_send)

    timeline = _FakeTimeline(marks=[])

    async def _watchdog() -> None:
        while not callback_listener_open:
            await asyncio.sleep(0.01)
        await asyncio.sleep(0.01)
        server.should_exit = True

    serve_coro = runtime_main._serve_app(
        app=object(),
        host="0.0.0.0",
        port=port,
        entrypoint="app:service",
        ready_target=("http://host:9/ready", "tok"),
        timeline=timeline,
    )

    await asyncio.gather(serve_coro, _watchdog())

    assert callback_listener_open == [True], (
        "Readiness callback fired before the listener accepted connections; "
        f"observed: {callback_listener_open}"
    )
    # The timeline must record server_started and callback_started in order.
    assert "server_started" in timeline.marks
    assert "callback_started" in timeline.marks
    assert timeline.marks.index("server_started") < timeline.marks.index(
        "callback_started"
    ), f"timeline order wrong: {timeline.marks}"


@pytest.mark.asyncio
async def test_no_callback_fires_when_ready_target_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When ``UNIAC_READY_URL`` is unset the callback path is skipped.

    The startup must still bind+listen and run uvicorn.
    """
    from uniac_runtime import __main__ as runtime_main

    port = _free_port()
    server = _FakeServer()
    _install_fake_uvicorn(monkeypatch, server)

    callback_calls = 0

    async def _fake_send(url, token, timings):
        nonlocal callback_calls
        callback_calls += 1
        return 200

    monkeypatch.setattr(runtime_main, "send_ready_callback", _fake_send)

    timeline = _FakeTimeline(marks=[])

    async def _watchdog() -> None:
        # Wait until the runtime hands the socket to the fake server,
        # then nudge it to exit so the test ends.
        while not server.received_sockets:
            await asyncio.sleep(0.005)
        await asyncio.sleep(0.01)
        server.should_exit = True

    serve_coro = runtime_main._serve_app(
        app=object(),
        host="0.0.0.0",
        port=port,
        entrypoint="app:service",
        ready_target=None,
        timeline=timeline,
    )

    await asyncio.gather(serve_coro, _watchdog())

    assert callback_calls == 0
    assert "server_started" in timeline.marks
    assert "callback_started" not in timeline.marks
    # The pre-bound socket was actually handed to uvicorn.
    assert len(server.received_sockets) == 1


@pytest.mark.asyncio
async def test_socket_passed_to_uvicorn_is_listening(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Sanity check: the socket _serve_app hands to uvicorn is in LISTEN state."""
    from uniac_runtime import __main__ as runtime_main

    port = _free_port()
    server = _FakeServer()
    _install_fake_uvicorn(monkeypatch, server)

    async def _fake_send(url, token, timings):
        return 200

    monkeypatch.setattr(runtime_main, "send_ready_callback", _fake_send)

    timeline = _FakeTimeline(marks=[])

    socket_state: dict = {}

    async def _watchdog() -> None:
        while not server.received_sockets:
            await asyncio.sleep(0.005)
        # Capture state before _serve_app's finally-block closes the socket.
        socket_state["external_connect_works"] = _connect_works(port)
        server.should_exit = True

    await asyncio.gather(
        runtime_main._serve_app(
            app=object(),
            host="0.0.0.0",
            port=port,
            entrypoint="app:service",
            ready_target=("http://host:9/ready", "tok"),
            timeline=timeline,
        ),
        _watchdog(),
    )

    assert len(server.received_sockets) == 1
    # External TCP connect at the moment the socket is handed to uvicorn
    # must succeed — proves the kernel is in LISTEN state.
    assert socket_state["external_connect_works"] is True
