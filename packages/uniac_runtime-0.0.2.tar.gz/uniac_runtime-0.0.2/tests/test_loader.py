"""Tests for uniac_runtime.loader."""
import sys
import textwrap
from pathlib import Path

import pytest

from uniac.service import FastAPIService
from uniac_runtime.loader import LoadError, load_service, setup_import_path


@pytest.fixture()
def tmp_project(tmp_path: Path):
    """Create a minimal FastAPIService in a temp directory."""
    code = textwrap.dedent("""\
        from fastapi import FastAPI
        from uniac import FastAPIService

        class HelloService(FastAPIService):
            def build_app(self):
                api = FastAPI()

                @api.get("/hello")
                def hello():
                    return {"message": "hi"}

                return api

        hello = HelloService()
    """)
    (tmp_path / "app.py").write_text(code)
    return tmp_path


class TestSetupImportPath:

    def test_adds_project_dir(self, tmp_path: Path):
        project = str(tmp_path)
        setup_import_path(str(tmp_path))
        assert project in sys.path

    def test_adds_deps_dir(self, tmp_path: Path):
        deps = str(tmp_path / "deps")
        setup_import_path(str(tmp_path))
        assert deps in sys.path

    def test_idempotent(self, tmp_path: Path):
        setup_import_path(str(tmp_path))
        before = list(sys.path)
        setup_import_path(str(tmp_path))
        assert sys.path == before


class TestLoadService:

    def test_valid_instance(self, tmp_project: Path):
        """When the entrypoint points to an instance, it is returned directly."""
        setup_import_path(str(tmp_project))
        try:
            result = load_service("app:hello")
            assert isinstance(result, FastAPIService)
            assert type(result).__name__ == "HelloService"
        finally:
            sys.modules.pop("app", None)

    def test_valid_class(self, tmp_project: Path):
        """When the entrypoint points to a class, it is instantiated."""
        setup_import_path(str(tmp_project))
        try:
            result = load_service("app:HelloService")
            assert isinstance(result, FastAPIService)
            assert type(result).__name__ == "HelloService"
        finally:
            sys.modules.pop("app", None)

    def test_instance_is_same_object(self, tmp_project: Path):
        """Loading an instance returns the exact same object."""
        setup_import_path(str(tmp_project))
        try:
            import importlib
            mod = importlib.import_module("app")
            original = mod.hello
            result = load_service("app:hello")
            assert result is original
        finally:
            sys.modules.pop("app", None)

    def test_missing_colon(self):
        with pytest.raises(LoadError, match="expected 'module:object'"):
            load_service("appHelloService")

    def test_empty_module(self):
        with pytest.raises(LoadError, match="must be non-empty"):
            load_service(":HelloService")

    def test_empty_object(self):
        with pytest.raises(LoadError, match="must be non-empty"):
            load_service("app:")

    def test_module_not_found(self, tmp_path: Path):
        setup_import_path(str(tmp_path))
        with pytest.raises(LoadError, match="Cannot import module"):
            load_service("nonexistent_module:Foo")

    def test_attribute_not_found(self, tmp_project: Path):
        setup_import_path(str(tmp_project))
        try:
            with pytest.raises(LoadError, match="has no attribute"):
                load_service("app:DoesNotExist")
        finally:
            sys.modules.pop("app", None)

    def test_not_a_service(self, tmp_path: Path):
        (tmp_path / "bad.py").write_text("class Foo: pass\n")
        setup_import_path(str(tmp_path))
        try:
            with pytest.raises(LoadError, match="not a Service instance or subclass"):
                load_service("bad:Foo")
        finally:
            sys.modules.pop("bad", None)
