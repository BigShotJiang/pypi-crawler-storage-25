"""Shared fixtures for PyOrleans tests."""
import pytest
import asyncio

from pyorleans import Silo, GrainFactory, LocalMemoryStorage


@pytest.fixture
def silo():
    """Create a fresh Silo with in-memory storage."""
    s = Silo(max_workers=4, idle_timeout_seconds=300.0)
    s.register_storage(LocalMemoryStorage())
    return s


@pytest.fixture
def factory(silo):
    """Create a GrainFactory bound to the test silo."""
    return GrainFactory(silo)
