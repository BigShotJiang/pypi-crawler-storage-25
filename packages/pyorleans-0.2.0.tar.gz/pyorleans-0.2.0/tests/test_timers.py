"""Tests for grain timers."""
import pytest
import time
import threading

from pyorleans.timers import GrainTimer, GrainTimerOptions


def test_timer_fires_callback():
    """Test that a timer fires the callback after due_time."""
    results = []

    def callback():
        results.append(time.monotonic())

    options = GrainTimerOptions(due_time=0.1, period=0.0)  # One-shot
    timer = GrainTimer(activation=None, callback=callback, state=None, options=options)
    timer.start()

    time.sleep(0.3)
    timer.stop()

    assert len(results) == 1, f"Expected 1 tick, got {len(results)}"


def test_timer_periodic_callback():
    """Test that a periodic timer fires multiple times."""
    results = []

    def callback():
        results.append(1)

    options = GrainTimerOptions(due_time=0.05, period=0.05)
    timer = GrainTimer(activation=None, callback=callback, state=None, options=options)
    timer.start()

    time.sleep(0.35)
    timer.stop()

    # Should have fired approximately 5-7 times
    assert len(results) >= 3, f"Expected at least 3 ticks, got {len(results)}"


def test_timer_stop_prevents_future_ticks():
    """Test that stopping a timer prevents further callbacks."""
    results = []

    def callback():
        results.append(1)

    options = GrainTimerOptions(due_time=0.05, period=0.05)
    timer = GrainTimer(activation=None, callback=callback, state=None, options=options)
    timer.start()

    time.sleep(0.15)
    timer.stop()
    count_at_stop = len(results)

    time.sleep(0.2)
    assert len(results) == count_at_stop, "Timer fired after being stopped!"


def test_timer_with_state():
    """Test that timer correctly passes state to callback."""
    results = []

    def callback(state):
        results.append(state)

    options = GrainTimerOptions(due_time=0.05, period=0.0)
    timer = GrainTimer(activation=None, callback=callback, state="hello", options=options)
    timer.start()

    time.sleep(0.2)
    timer.stop()

    assert results == ["hello"]


def test_timer_callback_exception_does_not_stop_timer():
    """Test that exceptions in callback don't prevent next tick."""
    call_count = []

    def callback():
        call_count.append(1)
        if len(call_count) == 1:
            raise ValueError("Intentional error")

    options = GrainTimerOptions(due_time=0.05, period=0.05)
    timer = GrainTimer(activation=None, callback=callback, state=None, options=options)
    timer.start()

    time.sleep(0.25)
    timer.stop()

    assert len(call_count) >= 2, "Timer should continue after exception"
