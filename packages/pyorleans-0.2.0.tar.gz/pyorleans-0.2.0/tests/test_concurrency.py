"""Tests for concurrency: turn-based execution and multi-thread safety."""
import pytest
import asyncio
from dataclasses import dataclass

from pyorleans import Grain, Silo, GrainFactory, LocalMemoryStorage, stateful


@dataclass
class BankState:
    balance: int = 0


@stateful(BankState)
class BankAccountGrain(Grain):
    def deposit(self, amount: int):
        self.state.balance += amount
        return self.state.balance

    def withdraw(self, amount: int):
        if self.state.balance < amount:
            raise ValueError("Insufficient funds")
        self.state.balance -= amount
        return self.state.balance

    def get_balance(self):
        return self.state.balance


@pytest.mark.asyncio
async def test_concurrent_calls_are_serialized():
    """
    Test that 100 concurrent deposits to the same grain produce a correct total.

    This validates the turn-based scheduling: even though calls arrive
    concurrently, they are executed one at a time inside the grain.
    """
    silo = Silo(max_workers=8)
    silo.register_storage(LocalMemoryStorage())
    silo.register_grain_class(BankAccountGrain)
    await silo.start()

    try:
        factory = GrainFactory(silo)
        ref = factory.get_grain(BankAccountGrain, "account_1")

        # Fire 100 concurrent deposits of 10 each
        tasks = [ref.deposit(10) for _ in range(100)]
        results = await asyncio.gather(*tasks)

        # The final balance must be exactly 1000
        balance = await ref.get_balance()
        assert balance == 1000, f"Expected 1000, got {balance}"

        # All intermediate results should be monotonically increasing
        sorted_results = sorted(results)
        assert sorted_results == list(range(10, 1010, 10))
    finally:
        await silo.stop()


@pytest.mark.asyncio
async def test_different_grains_execute_in_parallel():
    """
    Test that calls to *different* grains can execute concurrently.

    This validates that the turn-based constraint is per-grain, not global.
    """
    silo = Silo(max_workers=8)
    silo.register_storage(LocalMemoryStorage())
    silo.register_grain_class(BankAccountGrain)
    await silo.start()

    try:
        factory = GrainFactory(silo)

        # Create 10 different grains, each gets 10 deposits
        tasks = []
        for i in range(10):
            ref = factory.get_grain(BankAccountGrain, f"parallel_{i}")
            for _ in range(10):
                tasks.append(ref.deposit(100))

        await asyncio.gather(*tasks)

        # Each grain should have 1000
        for i in range(10):
            ref = factory.get_grain(BankAccountGrain, f"parallel_{i}")
            balance = await ref.get_balance()
            assert balance == 1000, f"Grain parallel_{i} has {balance}, expected 1000"
    finally:
        await silo.stop()
