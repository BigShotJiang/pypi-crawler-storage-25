"""Tests for the state management system."""
import pytest
from dataclasses import dataclass

from pyorleans.state import LocalMemoryStorage, GrainStateManager
from pyorleans.exceptions import ETagMismatchError


@dataclass
class SampleState:
    name: str = "default"
    score: int = 0


@pytest.mark.asyncio
async def test_read_write_state():
    """Test basic state read and write."""
    storage = LocalMemoryStorage()
    mgr = GrainStateManager("TestGrain", "id1", storage)
    state = SampleState()

    # Initially nothing in storage
    await mgr.read(state)
    assert not mgr.record_exists
    assert state.name == "default"

    # Write and read back
    state.name = "Alice"
    state.score = 42
    await mgr.write(state)
    assert mgr.record_exists
    assert mgr.etag is not None

    # Read into a fresh state object
    state2 = SampleState()
    mgr2 = GrainStateManager("TestGrain", "id1", storage)
    await mgr2.read(state2)
    assert state2.name == "Alice"
    assert state2.score == 42


@pytest.mark.asyncio
async def test_etag_concurrency():
    """Test that concurrent writes with stale ETags are rejected."""
    storage = LocalMemoryStorage()

    # First, establish some state in storage
    initial_mgr = GrainStateManager("TestGrain", "etag1", storage)
    initial_state = SampleState(name="Initial")
    await initial_mgr.write(initial_state)

    # Now two managers read the same state
    mgr1 = GrainStateManager("TestGrain", "etag1", storage)
    mgr2 = GrainStateManager("TestGrain", "etag1", storage)

    state1 = SampleState()
    state2 = SampleState()

    await mgr1.read(state1)
    await mgr2.read(state2)

    # Both should have the same etag
    assert mgr1.etag == mgr2.etag
    assert mgr1.etag is not None

    # Writer1 writes first — gets a new etag
    state1.name = "Writer1_updated"
    await mgr1.write(state1)

    # Writer2 tries to write with stale etag — should fail
    state2.name = "Writer2_updated"
    with pytest.raises(ETagMismatchError):
        await mgr2.write(state2)


@pytest.mark.asyncio
async def test_clear_state():
    """Test clearing state from storage."""
    storage = LocalMemoryStorage()
    mgr = GrainStateManager("TestGrain", "clear1", storage)
    state = SampleState(name="ToBeCleared", score=99)

    await mgr.write(state)
    assert mgr.record_exists

    await mgr.clear()
    assert not mgr.record_exists
    assert mgr.etag is None

    # Verify it's gone from storage
    data, etag = await storage.read_state("TestGrain", "clear1")
    assert data is None
