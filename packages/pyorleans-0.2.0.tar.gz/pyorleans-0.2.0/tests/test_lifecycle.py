"""Tests for grain lifecycle, activation, and deactivation."""
import pytest
from dataclasses import dataclass

from pyorleans import (
    Grain, Silo, GrainFactory, LocalMemoryStorage, stateful,
    ActivationState, DeactivationReason, DeactivationReasonCode,
)


@dataclass
class CounterState:
    value: int = 0


@stateful(CounterState)
class CounterGrain(Grain):
    def __init__(self):
        super().__init__()
        self.activated = False
        self.deactivated = False
        self.deactivation_reason = None

    def on_activate(self):
        self.activated = True

    def on_deactivate(self, reason):
        self.deactivated = True
        self.deactivation_reason = reason

    def increment(self):
        self.state.value += 1
        return self.state.value

    def get_value(self):
        return self.state.value


class FailingGrain(Grain):
    def on_activate(self):
        raise RuntimeError("Activation failed intentionally")


@pytest.mark.asyncio
async def test_grain_activation_and_invocation(silo):
    """Test that a grain is lazily activated and methods work correctly."""
    silo.register_grain_class(CounterGrain)
    await silo.start()

    try:
        factory = GrainFactory(silo)
        ref = factory.get_grain(CounterGrain, "counter_1")

        result = await ref.increment()
        assert result == 1

        result = await ref.increment()
        assert result == 2

        result = await ref.get_value()
        assert result == 2
    finally:
        await silo.stop()


@pytest.mark.asyncio
async def test_activation_state_transitions(silo):
    """Test that activation goes through Creating → Activating → Valid."""
    silo.register_grain_class(CounterGrain)
    await silo.start()

    try:
        activation = await silo.get_or_create_activation("CounterGrain", "test_1")
        assert activation.state == ActivationState.VALID
        assert activation.grain_instance.activated is True
    finally:
        await silo.stop()


@pytest.mark.asyncio
async def test_deactivation_calls_on_deactivate(silo):
    """Test that deactivation triggers on_deactivate with reason."""
    silo.register_grain_class(CounterGrain)
    await silo.start()

    try:
        activation = await silo.get_or_create_activation("CounterGrain", "test_2")
        grain = activation.grain_instance

        reason = DeactivationReason(
            code=DeactivationReasonCode.APPLICATION_REQUESTED,
            description="Test deactivation",
        )
        await silo.deactivate_grain(activation, reason)

        assert grain.deactivated is True
        assert grain.deactivation_reason.code == DeactivationReasonCode.APPLICATION_REQUESTED
        assert activation.state == ActivationState.INVALID
    finally:
        await silo.stop()


@pytest.mark.asyncio
async def test_grain_state_persistence(silo):
    """Test that state is saved and restored via Write-Behind."""
    silo.register_grain_class(CounterGrain)
    await silo.start()

    try:
        factory = GrainFactory(silo)
        ref = factory.get_grain(CounterGrain, "persist_1")

        await ref.increment()
        await ref.increment()
        await ref.increment()

        # Give Write-Behind time to flush
        import asyncio
        await asyncio.sleep(0.3)

        # Verify storage has the state
        storage = silo._storage
        data, etag = await storage.read_state("CounterGrain", "persist_1")
        assert data is not None
        assert data["value"] == 3
    finally:
        await silo.stop()


@pytest.mark.asyncio
async def test_activation_failure_returns_invalid():
    """Test that a grain that fails to activate is cleaned up."""
    silo = Silo(max_workers=2)
    silo.register_grain_class(FailingGrain)
    await silo.start()

    try:
        from pyorleans.exceptions import GrainActivationError
        with pytest.raises(GrainActivationError):
            await silo.get_or_create_activation("FailingGrain", "fail_1")

        # The activation should not be in the directory
        from pyorleans.ids import GrainId
        grain_id = GrainId.create("FailingGrain", "fail_1")
        assert grain_id not in silo.activation_directory
    finally:
        await silo.stop()
