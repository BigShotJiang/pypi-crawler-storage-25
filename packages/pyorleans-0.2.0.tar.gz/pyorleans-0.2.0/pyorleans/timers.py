"""
Grain Timers — periodic callbacks tied to a grain's lifecycle.

Modeled after Orleans' ``IGrainTimer`` / ``GrainTimerCreationOptions``.
Timers are automatically cancelled when the grain deactivates, and
their callbacks are submitted through the grain's ``WorkItemQueue``
to maintain turn-based safety.
"""
from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from pyorleans.activation import ActivationData

log = logging.getLogger(__name__)


@dataclass
class GrainTimerOptions:
    """Options for creating a grain timer (mirrors Orleans GrainTimerCreationOptions)."""

    due_time: float = 0.0
    """Seconds to wait before the first tick. 0 = immediate."""

    period: float = 1.0
    """Seconds between subsequent ticks. <= 0 disables periodic ticking."""

    interleave: bool = True
    """Whether timer callbacks can interleave with other grain calls."""

    keep_alive: bool = False
    """Whether timer ticks should extend the grain's activation lifetime."""


class GrainTimer:
    """
    A timer bound to a grain activation.

    Important behaviors (matching Orleans):
    - Timer callbacks are **never concurrent with themselves**. The next tick
      is only scheduled after the current callback completes.
    - When a grain deactivates, all its timers are automatically stopped.
    - Exceptions in the callback are logged but do NOT prevent the next tick.
    """

    def __init__(
        self,
        activation: ActivationData | None,
        callback: Callable,
        state: Any,
        options: GrainTimerOptions,
    ):
        self._activation = activation
        self._callback = callback
        self._state = state
        self._options = options
        self._timer: threading.Timer | None = None
        self._stopped = False
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start the timer with the configured due_time."""
        if self._stopped:
            return
        self._schedule(self._options.due_time)

    def stop(self) -> None:
        """Cancel the timer. No further ticks will fire."""
        with self._lock:
            self._stopped = True
            if self._timer:
                self._timer.cancel()
                self._timer = None

    def change(self, due_time: float, period: float) -> None:
        """Update the timer's due time and period (matching Orleans IGrainTimer.Change)."""
        with self._lock:
            self._options.due_time = due_time
            self._options.period = period
            if self._timer:
                self._timer.cancel()
            if not self._stopped:
                self._schedule(due_time)

    def _schedule(self, delay: float) -> None:
        """Schedule the next tick."""
        with self._lock:
            if self._stopped:
                return
            self._timer = threading.Timer(delay, self._on_tick)
            self._timer.daemon = True
            self._timer.start()

    def _on_tick(self) -> None:
        """Called when the timer fires. Executes callback and reschedules."""
        if self._stopped:
            return

        # Extend activation lifetime if configured
        if self._options.keep_alive and self._activation:
            self._activation.touch()

        try:
            if self._state is not None:
                self._callback(self._state)
            else:
                self._callback()
        except Exception:
            log.exception(
                "Timer callback raised an exception (grain=%s). Timer will continue.",
                self._activation.grain_id if self._activation else "unknown",
            )

        # Schedule next tick (only if period > 0)
        if not self._stopped and self._options.period > 0:
            self._schedule(self._options.period)

    def __del__(self) -> None:
        self.stop()
