"""
Placement strategies — deciding where to activate a grain.

Modeled after Orleans' ``PlacementStrategy`` hierarchy. In single-silo mode
only ``PreferLocalPlacement`` matters. The framework is extensible for
multi-silo deployment with Random, HashBased, etc.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyorleans.ids import GrainId

log = logging.getLogger(__name__)


class PlacementStrategy:
    """
    Abstract base for all placement strategies.

    A placement strategy decides which silo should host a new grain activation.
    Each grain type can declare its preferred strategy via a decorator.
    """

    @property
    def is_using_grain_directory(self) -> bool:
        """Whether activations using this strategy are registered in the directory."""
        return True

    def __repr__(self) -> str:
        return type(self).__name__


class RandomPlacement(PlacementStrategy):
    """Pick a random silo from the cluster."""
    pass


class PreferLocalPlacement(PlacementStrategy):
    """Activate on the local silo if possible (default strategy)."""
    pass


class HashBasedPlacement(PlacementStrategy):
    """Use a consistent hash of the GrainId to pick a silo."""
    pass


class ActivationCountPlacement(PlacementStrategy):
    """Pick the silo with the fewest activations (load balancing)."""
    pass


class StatelessWorkerPlacement(PlacementStrategy):
    """
    Special placement for stateless workers.

    Multiple activations can exist on the same silo, and the directory is not used.
    """

    def __init__(self, max_local_workers: int = -1):
        self.max_local_workers = max_local_workers

    @property
    def is_using_grain_directory(self) -> bool:
        return False


# ─── Decorator for Grain Classes ─────────────────────────────────────


def placement(strategy: PlacementStrategy):
    """
    Decorator to assign a placement strategy to a grain class.

    Usage::

        @placement(HashBasedPlacement())
        class MyGrain(Grain):
            ...
    """
    def decorator(cls):
        cls.__placement_strategy__ = strategy
        return cls
    return decorator
