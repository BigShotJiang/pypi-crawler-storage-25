"""
Grain call filters (interceptors / middleware pipeline).

Modeled after Orleans' ``IIncomingGrainCallFilter`` / ``IOutgoingGrainCallFilter``.
Filters allow you to add cross-cutting concerns like logging, authorization,
metrics, and error handling to every grain call.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from pyorleans.ids import GrainId

log = logging.getLogger(__name__)


@dataclass
class GrainCallContext:
    """
    Context object passed through the filter pipeline for each grain call.

    Mirrors Orleans' ``IGrainCallContext`` with source/target IDs, method info, etc.
    """

    grain_type: str
    """Name of the grain class being called."""

    grain_id: GrainId | None
    """Full identity of the target grain."""

    method_name: str
    """Name of the method being invoked."""

    arguments: tuple
    """Positional arguments to the method."""

    keyword_arguments: dict = field(default_factory=dict)
    """Keyword arguments to the method."""

    source_id: GrainId | None = None
    """Identity of the calling grain (None if called from client)."""

    result: Any = None
    """The result of the invocation (set after ``invoke()`` completes)."""

    exception: Exception | None = None
    """Any exception raised during invocation."""

    _invoke_func: Callable | None = None
    """Internal: the actual method to call."""

    async def invoke(self) -> Any:
        """Execute the next filter in the pipeline, or the actual grain method."""
        if self._invoke_func:
            self.result = self._invoke_func(*self.arguments, **self.keyword_arguments)
            return self.result


# ─── Filter Types ────────────────────────────────────────────────────

# A filter is simply a callable: (context, next) -> None
IncomingFilter = Callable[[GrainCallContext, Callable], Any]
OutgoingFilter = Callable[[GrainCallContext, Callable], Any]


class FilterPipeline:
    """
    Manages the chain of incoming and outgoing grain call filters.

    Usage::

        pipeline = FilterPipeline()

        @pipeline.incoming
        def log_calls(context, next_filter):
            print(f"Calling {context.method_name}")
            next_filter()
            print(f"Result: {context.result}")

    """

    def __init__(self) -> None:
        self._incoming_filters: list[IncomingFilter] = []
        self._outgoing_filters: list[OutgoingFilter] = []

    def add_incoming(self, filter_func: IncomingFilter) -> None:
        """Register an incoming (server-side) filter."""
        self._incoming_filters.append(filter_func)

    def add_outgoing(self, filter_func: OutgoingFilter) -> None:
        """Register an outgoing (client-side) filter."""
        self._outgoing_filters.append(filter_func)

    def incoming(self, func: IncomingFilter) -> IncomingFilter:
        """Decorator to register an incoming filter."""
        self.add_incoming(func)
        return func

    def outgoing(self, func: OutgoingFilter) -> OutgoingFilter:
        """Decorator to register an outgoing filter."""
        self.add_outgoing(func)
        return func

    def execute_incoming(self, context: GrainCallContext, final: Callable) -> Any:
        """Execute the incoming filter pipeline, then call the grain method."""
        chain = list(reversed(self._incoming_filters))

        def build_chain(filters, final_func):
            if not filters:
                return final_func

            current_filter = filters[0]
            rest = filters[1:]

            def next_step():
                inner = build_chain(rest, final_func)
                return inner()

            def step():
                return current_filter(context, next_step)

            return step

        executor = build_chain(chain, final)
        return executor()

    def execute_outgoing(self, context: GrainCallContext, final: Callable) -> Any:
        """Execute the outgoing filter pipeline."""
        chain = list(reversed(self._outgoing_filters))

        def build_chain(filters, final_func):
            if not filters:
                return final_func

            current_filter = filters[0]
            rest = filters[1:]

            def next_step():
                inner = build_chain(rest, final_func)
                return inner()

            def step():
                return current_filter(context, next_step)

            return step

        executor = build_chain(chain, final)
        return executor()
