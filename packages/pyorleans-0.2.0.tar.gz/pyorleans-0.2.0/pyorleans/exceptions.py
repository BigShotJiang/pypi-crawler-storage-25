"""PyOrleans custom exceptions."""
from __future__ import annotations


class PyOrleansError(Exception):
    """Base exception for all PyOrleans errors."""


class GrainNotRegisteredError(PyOrleansError):
    """Raised when a grain type is not registered in the Silo."""

    def __init__(self, grain_type: str):
        super().__init__(f"Grain type '{grain_type}' is not registered in the Silo.")
        self.grain_type = grain_type


class GrainActivationError(PyOrleansError):
    """Raised when a grain fails to activate."""

    def __init__(self, grain_type: str, identity: str, cause: Exception | None = None):
        msg = f"Failed to activate grain '{grain_type}:{identity}'"
        if cause:
            msg += f": {cause}"
        super().__init__(msg)
        self.grain_type = grain_type
        self.identity = identity
        self.__cause__ = cause


class GrainDeactivatedError(PyOrleansError):
    """Raised when trying to invoke a method on a deactivated grain."""

    def __init__(self, grain_type: str, identity: str):
        super().__init__(
            f"Grain '{grain_type}:{identity}' is deactivated and cannot process requests."
        )


class InvalidActivationStateError(PyOrleansError):
    """Raised when an activation is in an unexpected state."""


class StorageError(PyOrleansError):
    """Raised when a storage operation fails."""


class ETagMismatchError(StorageError):
    """Raised when an ETag conflict occurs during a write operation."""

    def __init__(self, expected: str | None, actual: str | None):
        super().__init__(
            f"ETag mismatch: expected '{expected}', got '{actual}'. "
            "Another process may have modified the state."
        )
        self.expected = expected
        self.actual = actual


class SiloNotRunningError(PyOrleansError):
    """Raised when an operation is attempted on a Silo that is not running."""
