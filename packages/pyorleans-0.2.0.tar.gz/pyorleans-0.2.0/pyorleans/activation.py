"""
ActivationData — the runtime wrapper around a Grain instance.

Modeled after Orleans' ActivationData + ActivationState. Tracks the grain's
lifecycle state machine, its work queue, timers, and activity timestamps.
"""
from __future__ import annotations

import enum
import time
import logging
from typing import Any, TYPE_CHECKING

from pyorleans.ids import GrainId, ActivationId, GrainAddress
from pyorleans.scheduler import WorkItemQueue

if TYPE_CHECKING:
    from pyorleans.grain import Grain

log = logging.getLogger(__name__)


class ActivationState(enum.Enum):
    """
    Lifecycle states for a grain activation.

    Mirrors Orleans' ActivationState:
        Creating → Activating → Valid → Deactivating → Invalid
    """

    CREATING = "creating"
    ACTIVATING = "activating"
    VALID = "valid"
    DEACTIVATING = "deactivating"
    INVALID = "invalid"


class ActivationData:
    """
    Runtime wrapper that holds a Grain, its activation state, scheduler queue,
    and metadata. This is what the Silo actually manages.

    Equivalent to Orleans' massive ActivationData class (~108KB), simplified
    for the Python runtime.
    """

    __slots__ = (
        "grain_id",
        "activation_id",
        "address",
        "grain_instance",
        "state",
        "work_queue",
        "timers",
        "last_activity_time",
        "keep_alive_until",
        "created_at",
        "_grain_class_name",
    )

    def __init__(
        self,
        grain_id: GrainId,
        grain_instance: Grain,
        silo_address: str = "local",
    ):
        self.grain_id = grain_id
        self.activation_id = ActivationId.new()
        self.address = GrainAddress(
            grain_id=grain_id,
            activation_id=self.activation_id,
            silo_address=silo_address,
        )
        self.grain_instance = grain_instance
        self.state = ActivationState.CREATING
        self.work_queue = WorkItemQueue()
        self.timers: list[Any] = []  # Will hold GrainTimer instances
        self.last_activity_time: float = time.monotonic()
        self.keep_alive_until: float | None = None
        self.created_at: float = time.monotonic()
        self._grain_class_name = type(grain_instance).__name__

    def touch(self) -> None:
        """Record activity — resets the idle timer for the collector."""
        self.last_activity_time = time.monotonic()

    def get_idleness(self) -> float:
        """Return how many seconds this activation has been idle."""
        return time.monotonic() - self.last_activity_time

    def delay_deactivation(self, seconds: float) -> None:
        """
        Prevent this activation from being collected for at least ``seconds``.

        Pass a negative value to cancel a previous delay.
        """
        if seconds < 0:
            self.keep_alive_until = None
        else:
            self.keep_alive_until = time.monotonic() + seconds

    def cancel_all_timers(self) -> None:
        """Called during deactivation to stop all grain timers."""
        for timer in self.timers:
            try:
                timer.stop()
            except Exception:
                log.exception("Error stopping timer on %s", self.grain_id)
        self.timers.clear()

    def __repr__(self) -> str:
        return (
            f"ActivationData({self.grain_id}, state={self.state.value}, "
            f"pending_work={self.work_queue.pending_count})"
        )
