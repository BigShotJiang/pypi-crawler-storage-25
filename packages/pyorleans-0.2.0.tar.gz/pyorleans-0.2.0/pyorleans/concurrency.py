"""
Concurrency decorators for grain classes and methods.

Modeled after Orleans' concurrency attributes:
- ``[Reentrant]`` → ``@reentrant``
- ``[ReadOnly]`` → ``@read_only``
- ``[AlwaysInterleave]`` → ``@always_interleave``
- ``[OneWay]`` → ``@one_way``
- ``[StatelessWorker]`` → ``@stateless_worker``
"""
from __future__ import annotations

from typing import TypeVar, Callable

T = TypeVar("T")


# ─── Class-Level Decorators (applied to Grain classes) ───────────────


def reentrant(cls: type[T]) -> type[T]:
    """
    Marks a grain class as reentrant, allowing request interleaving.

    When a grain is reentrant, multiple requests can execute concurrently
    within the grain's activation. This is useful for grains that do not
    mutate state or that manage their own concurrency.

    Usage::

        @reentrant
        class MyGrain(Grain):
            ...
    """
    cls.__reentrant__ = True  # type: ignore[attr-defined]
    return cls


def stateless_worker(max_local_workers: int = -1):
    """
    Marks a grain class as a stateless worker.

    Stateless workers can have multiple activations on the same silo,
    and calls are load-balanced across them. They do not have persistent state.

    Args:
        max_local_workers: Maximum number of concurrent activations (-1 = unlimited).

    Usage::

        @stateless_worker(max_local_workers=4)
        class MyWorker(Grain):
            ...
    """
    def decorator(cls: type[T]) -> type[T]:
        cls.__stateless_worker__ = True  # type: ignore[attr-defined]
        cls.__max_local_workers__ = max_local_workers  # type: ignore[attr-defined]
        return cls

    return decorator


# ─── Method-Level Decorators (applied to grain methods) ──────────────


def read_only(method: Callable[..., T]) -> Callable[..., T]:
    """
    Marks a grain method as read-only (does not modify state).

    Read-only methods can be interleaved with other read-only methods,
    enabling significant performance optimizations.

    Usage::

        class MyGrain(Grain):
            @read_only
            def get_value(self) -> int:
                return self.state.value
    """
    method.__read_only__ = True  # type: ignore[attr-defined]
    return method


def always_interleave(method: Callable[..., T]) -> Callable[..., T]:
    """
    Marks a method that can always interleave, even on non-reentrant grains.

    Usage::

        class MyGrain(Grain):
            @always_interleave
            def get_status(self) -> str:
                return "ok"
    """
    method.__always_interleave__ = True  # type: ignore[attr-defined]
    return method


def one_way(method: Callable[..., T]) -> Callable[..., T]:
    """
    Marks a method as fire-and-forget — no response is sent to the caller.

    Usage::

        class MyGrain(Grain):
            @one_way
            def log_event(self, event: str):
                ...
    """
    method.__one_way__ = True  # type: ignore[attr-defined]
    return method
