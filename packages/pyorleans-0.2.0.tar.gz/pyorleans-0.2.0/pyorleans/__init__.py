"""
PyOrleans — A Virtual Actor framework for Python 3.14 (Free-Threaded).

Inspired by Microsoft Orleans (.NET), PyOrleans provides:
- **Virtual Actors (Grains)**: Always-available actors with transparent lifecycle
- **Turn-Based Concurrency**: Single-threaded execution per grain, no locks needed
- **Automatic Persistence**: Write-Behind state management with ETag concurrency
- **Grain Timers & Reminders**: Periodic and persistent callbacks
- **Call Filters**: Middleware pipeline for cross-cutting concerns
- **Free-Threaded Execution**: Leverages Python 3.14's no-GIL for real parallelism
"""

__version__ = "0.2.0"

# ── Core ──
from pyorleans.grain import Grain
from pyorleans.silo import Silo
from pyorleans.factory import GrainFactory, GrainReference

# ── Identity ──
from pyorleans.ids import GrainId, GrainType, ActivationId, GrainAddress

# ── Activation & Scheduling ──
from pyorleans.activation import ActivationData, ActivationState

# ── State & Persistence ──
from pyorleans.state import (
    StorageProvider,
    LocalMemoryStorage,
    GrainStateManager,
    stateful,
)

# ── Timers & Reminders ──
from pyorleans.timers import GrainTimer, GrainTimerOptions
from pyorleans.reminders import ReminderRegistry, Remindable, ReminderEntry

# ── Concurrency ──
from pyorleans.concurrency import (
    reentrant,
    stateless_worker,
    read_only,
    always_interleave,
    one_way,
)

# ── Lifecycle, Filters, Observers ──
from pyorleans.lifecycle import SiloLifecycle, SiloLifecycleStage
from pyorleans.filters import FilterPipeline, GrainCallContext
from pyorleans.observers import GrainObserver, ObserverManager
from pyorleans.deactivation import DeactivationReason, DeactivationReasonCode

# ── Placement ──
from pyorleans.placement import (
    PlacementStrategy,
    RandomPlacement,
    PreferLocalPlacement,
    HashBasedPlacement,
    ActivationCountPlacement,
    StatelessWorkerPlacement,
    placement,
)

# ── Directory ──
from pyorleans.directory import GrainDirectory, InMemoryGrainDirectory

# ── Exceptions ──
from pyorleans.exceptions import (
    PyOrleansError,
    GrainNotRegisteredError,
    GrainActivationError,
    GrainDeactivatedError,
    StorageError,
    ETagMismatchError,
    SiloNotRunningError,
)

__all__ = [
    # Core
    "Grain",
    "Silo",
    "GrainFactory",
    "GrainReference",
    # Identity
    "GrainId",
    "GrainType",
    "ActivationId",
    "GrainAddress",
    # Activation
    "ActivationData",
    "ActivationState",
    # State
    "StorageProvider",
    "LocalMemoryStorage",
    "GrainStateManager",
    "stateful",
    # Timers & Reminders
    "GrainTimer",
    "GrainTimerOptions",
    "ReminderRegistry",
    "Remindable",
    "ReminderEntry",
    # Concurrency
    "reentrant",
    "stateless_worker",
    "read_only",
    "always_interleave",
    "one_way",
    # Lifecycle
    "SiloLifecycle",
    "SiloLifecycleStage",
    # Filters
    "FilterPipeline",
    "GrainCallContext",
    # Observers
    "GrainObserver",
    "ObserverManager",
    # Deactivation
    "DeactivationReason",
    "DeactivationReasonCode",
    # Placement
    "PlacementStrategy",
    "RandomPlacement",
    "PreferLocalPlacement",
    "HashBasedPlacement",
    "ActivationCountPlacement",
    "StatelessWorkerPlacement",
    "placement",
    # Directory
    "GrainDirectory",
    "InMemoryGrainDirectory",
    # Exceptions
    "PyOrleansError",
    "GrainNotRegisteredError",
    "GrainActivationError",
    "GrainDeactivatedError",
    "StorageError",
    "ETagMismatchError",
    "SiloNotRunningError",
]
