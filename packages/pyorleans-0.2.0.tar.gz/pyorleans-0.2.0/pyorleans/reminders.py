"""
Reminders — persistent, durable timers that survive grain deactivation.

Modeled after Orleans' ``IRemindable`` / ``IReminderRegistry``.
Unlike Grain Timers (in-memory), Reminders are persisted and will
re-activate the grain when they fire, even after a silo restart.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Protocol

log = logging.getLogger(__name__)


class Remindable(Protocol):
    """
    Protocol for grains that want to receive reminder callbacks.

    Implement ``receive_reminder(name, status)`` in your grain class.
    """

    def receive_reminder(self, reminder_name: str, status: dict) -> None:
        """Called when a reminder fires."""
        ...


@dataclass
class ReminderEntry:
    """Persistent record of a reminder."""

    grain_type: str
    grain_identity: str
    reminder_name: str
    due_time: float  # seconds from now for first fire
    period: float  # seconds between fires
    created_at: float = field(default_factory=time.time)
    last_fired_at: Optional[float] = None
    etag: str = ""


class ReminderRegistry:
    """
    Manages persistent reminders.

    In a production deployment, this would be backed by a database
    (Postgres, Redis, etc.). This implementation uses in-memory storage
    for development.
    """

    def __init__(self) -> None:
        self._reminders: Dict[str, ReminderEntry] = {}
        self._tasks: Dict[str, asyncio.Task] = {}
        self._silo = None

    def attach(self, silo) -> None:
        self._silo = silo

    def _make_key(self, grain_type: str, identity: str, name: str) -> str:
        return f"{grain_type}:{identity}:{name}"

    async def register_or_update(
        self,
        grain_type: str,
        grain_identity: str,
        reminder_name: str,
        due_time: float,
        period: float,
    ) -> ReminderEntry:
        """
        Register or update a persistent reminder.

        If a reminder with the same name already exists for this grain,
        it is replaced.
        """
        key = self._make_key(grain_type, grain_identity, reminder_name)

        # Cancel existing task if any
        if key in self._tasks:
            self._tasks[key].cancel()

        entry = ReminderEntry(
            grain_type=grain_type,
            grain_identity=grain_identity,
            reminder_name=reminder_name,
            due_time=due_time,
            period=period,
        )
        self._reminders[key] = entry

        # Start the reminder loop
        self._tasks[key] = asyncio.create_task(self._reminder_loop(key, entry))
        log.info("Reminder registered: %s (due=%.1fs, period=%.1fs)", key, due_time, period)
        return entry

    async def unregister(self, grain_type: str, grain_identity: str, reminder_name: str) -> None:
        """Cancel and remove a reminder."""
        key = self._make_key(grain_type, grain_identity, reminder_name)
        if key in self._tasks:
            self._tasks[key].cancel()
            del self._tasks[key]
        self._reminders.pop(key, None)
        log.info("Reminder unregistered: %s", key)

    async def get_reminder(
        self, grain_type: str, grain_identity: str, reminder_name: str
    ) -> Optional[ReminderEntry]:
        key = self._make_key(grain_type, grain_identity, reminder_name)
        return self._reminders.get(key)

    async def get_reminders(self, grain_type: str, grain_identity: str) -> list[ReminderEntry]:
        prefix = f"{grain_type}:{grain_identity}:"
        return [v for k, v in self._reminders.items() if k.startswith(prefix)]

    async def _reminder_loop(self, key: str, entry: ReminderEntry) -> None:
        """Background task that fires the reminder at the configured intervals."""
        try:
            await asyncio.sleep(entry.due_time)
            while True:
                entry.last_fired_at = time.time()
                await self._fire_reminder(entry)
                if entry.period <= 0:
                    break
                await asyncio.sleep(entry.period)
        except asyncio.CancelledError:
            pass

    async def _fire_reminder(self, entry: ReminderEntry) -> None:
        """Activate the grain (if needed) and deliver the reminder."""
        if self._silo is None:
            return

        try:
            # This will create/activate the grain if it's not in memory
            await self._silo.invoke_method(
                entry.grain_type,
                entry.grain_identity,
                "receive_reminder",
                entry.reminder_name,
                {"last_fired_at": entry.last_fired_at},
            )
        except Exception:
            log.exception("Failed to deliver reminder %s:%s", entry.grain_type, entry.reminder_name)

    async def stop(self) -> None:
        """Cancel all reminder tasks."""
        for task in self._tasks.values():
            task.cancel()
        self._tasks.clear()
        log.info("All reminders stopped.")
