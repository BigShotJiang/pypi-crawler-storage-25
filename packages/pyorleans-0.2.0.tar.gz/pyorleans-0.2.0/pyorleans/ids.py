"""Structured identity types for grains, modeled after Orleans GrainId/GrainType."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Union


@dataclass(frozen=True)
class GrainType:
    """Identifies the *type* of a grain (e.g. 'UserGrain', 'OrderGrain')."""

    name: str

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class GrainId:
    """
    A compound identity for a grain, composed of a GrainType + a primary key.

    This mirrors the Orleans ``GrainId = GrainType + IdSpan`` pattern, supporting
    string, int, and UUID keys.
    """

    grain_type: GrainType
    key: Union[str, int, uuid.UUID]

    def __str__(self) -> str:
        return f"{self.grain_type.name}/{self.key}"

    def __hash__(self) -> int:
        return hash((self.grain_type.name, str(self.key)))

    @classmethod
    def create(cls, grain_class_name: str, key: Union[str, int, uuid.UUID]) -> GrainId:
        """Convenience factory: ``GrainId.create('UserGrain', 'user_123')``."""
        return cls(grain_type=GrainType(grain_class_name), key=key)


@dataclass(frozen=True)
class ActivationId:
    """
    Uniquely identifies one *activation* (in-memory instance) of a grain.

    A single GrainId may have at most one activation in a single-silo deployment.
    In multi-silo, the ActivationId distinguishes between stale and current activations.
    """

    value: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    def __str__(self) -> str:
        return self.value

    @classmethod
    def new(cls) -> ActivationId:
        return cls()


@dataclass(frozen=True)
class GrainAddress:
    """
    Full address of a grain activation, used in the Grain Directory.

    Contains the GrainId, ActivationId, and which silo hosts the activation.
    """

    grain_id: GrainId
    activation_id: ActivationId
    silo_address: str = "local"  # For single-silo, this is always "local"

    def __str__(self) -> str:
        return f"{self.grain_id}@{self.silo_address}#{self.activation_id}"
