"""
GrainFactory and GrainReference — typed proxies for grain invocation.

The Factory returns a ``GrainReference`` proxy. Calls on the proxy are
transparently routed through the Silo's invocation pipeline.
"""
from __future__ import annotations

from typing import Type, Any

from pyorleans.grain import Grain


class GrainReference:
    """
    A proxy to a virtual actor that intercepts method calls.

    When you call ``ref.some_method(args)`` the proxy routes the call through
    the Silo's ``invoke_method`` pipeline, ensuring proper activation,
    turn-based scheduling, filter pipeline, and Write-Behind persistence.
    """

    def __init__(self, silo, grain_type_name: str, identity: str | int):
        # Use object.__setattr__ to avoid triggering __getattr__
        object.__setattr__(self, "_silo", silo)
        object.__setattr__(self, "_grain_type_name", grain_type_name)
        object.__setattr__(self, "_identity", identity)

    def __getattr__(self, name: str) -> Any:
        """Intercept attribute access and return an async invoker."""
        silo = object.__getattribute__(self, "_silo")
        grain_type_name = object.__getattribute__(self, "_grain_type_name")
        identity = object.__getattribute__(self, "_identity")

        async def _invoke_method(*args, **kwargs) -> Any:
            return await silo.invoke_method(
                grain_type_name, identity, name, *args, **kwargs
            )

        return _invoke_method

    def __repr__(self) -> str:
        return (
            f"GrainReference({self._grain_type_name}/{self._identity})"
        )


class GrainFactory:
    """
    The entry point for resolving grain references.

    Usage::

        factory = GrainFactory(silo)
        user_ref = factory.get_grain(UserGrain, "user_123")
        points = await user_ref.add_points(50)  # Transparent RPC
    """

    def __init__(self, silo):
        self._silo = silo

    def get_grain(self, grain_class: Type[Grain], identity: str | int) -> GrainReference:
        """
        Get a reference (proxy) to a virtual actor.

        This does NOT activate the grain immediately. The grain is activated
        lazily when the first method is called on the reference.
        """
        return GrainReference(self._silo, grain_class.__name__, identity)
