"""
Deactivation reasons and activation collection (garbage collection for idle grains).

Modeled after Orleans' DeactivationReason / DeactivationReasonCode / ActivationCollector.
"""
from __future__ import annotations

import enum
import logging
import asyncio
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass  # avoid circular — types used only in annotations

log = logging.getLogger(__name__)


class DeactivationReasonCode(enum.Enum):
    """Informational reason code for deactivation (mirrors Orleans enum)."""

    NONE = "none"
    SHUTTING_DOWN = "shutting_down"
    ACTIVATION_FAILED = "activation_failed"
    ACTIVATION_IDLE = "activation_idle"
    ACTIVATION_UNRESPONSIVE = "activation_unresponsive"
    DUPLICATE_ACTIVATION = "duplicate_activation"
    APPLICATION_ERROR = "application_error"
    APPLICATION_REQUESTED = "application_requested"
    MIGRATING = "migrating"
    RUNTIME_REQUESTED = "runtime_requested"
    HIGH_MEMORY_PRESSURE = "high_memory_pressure"


@dataclass(frozen=True)
class DeactivationReason:
    """Represents a reason for initiating grain deactivation."""

    code: DeactivationReasonCode
    description: str = ""
    exception: Exception | None = None

    def __str__(self) -> str:
        parts = [f"{self.code.value}: {self.description}"]
        if self.exception:
            parts.append(f" Exception: {self.exception}")
        return "".join(parts)


class ActivationCollector:
    """
    Background task that scans for idle grain activations and deactivates them.

    Modeled after Orleans' ActivationCollector. Periodically sweeps through all
    active grains and marks those that have been idle longer than their
    ``collection_age_limit`` for deactivation.
    """

    def __init__(
        self,
        scan_interval_seconds: float = 60.0,
        default_idle_timeout_seconds: float = 120.0,
    ):
        self._scan_interval = scan_interval_seconds
        self._default_idle_timeout = default_idle_timeout_seconds
        self._task: asyncio.Task | None = None
        self._silo = None  # set by Silo.start()

    def attach(self, silo) -> None:
        self._silo = silo

    async def start(self) -> None:
        self._task = asyncio.create_task(self._scan_loop())
        log.info(
            "ActivationCollector started (scan_interval=%.1fs, idle_timeout=%.1fs)",
            self._scan_interval,
            self._default_idle_timeout,
        )

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("ActivationCollector stopped.")

    async def _scan_loop(self) -> None:
        while True:
            await asyncio.sleep(self._scan_interval)
            try:
                await self._collect_idle()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("ActivationCollector scan failed")

    async def _collect_idle(self) -> None:
        if self._silo is None:
            return

        from pyorleans.activation import ActivationState

        now = time.monotonic()
        reason = DeactivationReason(
            code=DeactivationReasonCode.ACTIVATION_IDLE,
            description="Grain idle timeout exceeded.",
        )

        to_deactivate = []
        for activation in list(self._silo.activation_directory.values()):
            if activation.state != ActivationState.VALID:
                continue

            # Respect keep-alive override
            idle_timeout = activation.keep_alive_until or self._default_idle_timeout
            if isinstance(idle_timeout, (int, float)):
                idle_seconds = now - activation.last_activity_time
                if idle_seconds > idle_timeout:
                    to_deactivate.append(activation)

        if to_deactivate:
            log.info("ActivationCollector: deactivating %d idle grain(s).", len(to_deactivate))

        for activation in to_deactivate:
            await self._silo.deactivate_grain(activation, reason)
