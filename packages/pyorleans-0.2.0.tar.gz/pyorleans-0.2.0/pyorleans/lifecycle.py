"""
Silo Lifecycle — staged boot and shutdown sequence.

Modeled after Orleans' ``ISiloLifecycle``. The lifecycle is divided into
numbered stages that execute in order during startup and in reverse during
shutdown. Participants can register callbacks at specific stages.
"""
from __future__ import annotations

import enum
import logging
import asyncio
from typing import Callable, Awaitable

log = logging.getLogger(__name__)


class SiloLifecycleStage(enum.IntEnum):
    """
    Well-known lifecycle stages (mirrors Orleans SiloLifecycleStage).

    Lower numbers execute first during startup and last during shutdown.
    """

    FIRST = 0
    RUNTIME_SERVICES = 2000
    RUNTIME_STORAGE = 4000
    RUNTIME_GRAIN_SERVICES = 6000
    APPLICATION_SERVICES = 8000
    BECOME_ACTIVE = 10000
    ACTIVE = 12000
    LAST = 2**31


class SiloLifecycle:
    """
    Manages the staged lifecycle of a Silo.

    Participants register callbacks at specific stages. During startup,
    stages are executed in ascending order. During shutdown, in descending.
    """

    def __init__(self) -> None:
        self._participants: dict[int, list[tuple[str, Callable, Callable | None]]] = {}

    def subscribe(
        self,
        name: str,
        stage: int | SiloLifecycleStage,
        on_start: Callable[[], Awaitable[None] | None] | None = None,
        on_stop: Callable[[], Awaitable[None] | None] | None = None,
    ) -> None:
        """
        Register a participant at a specific lifecycle stage.

        Args:
            name: Descriptive name for logging.
            stage: The lifecycle stage number.
            on_start: Async or sync callback for startup.
            on_stop: Async or sync callback for shutdown.
        """
        stage_int = int(stage)
        if stage_int not in self._participants:
            self._participants[stage_int] = []
        self._participants[stage_int].append((name, on_start, on_stop))

    async def start(self) -> None:
        """Execute all startup callbacks in ascending stage order."""
        for stage in sorted(self._participants.keys()):
            for name, on_start, _ in self._participants[stage]:
                if on_start:
                    log.info("Lifecycle [STARTUP] stage=%d: %s", stage, name)
                    result = on_start()
                    if asyncio.iscoroutine(result):
                        await result

    async def stop(self) -> None:
        """Execute all shutdown callbacks in descending stage order."""
        for stage in sorted(self._participants.keys(), reverse=True):
            for name, _, on_stop in self._participants[stage]:
                if on_stop:
                    log.info("Lifecycle [SHUTDOWN] stage=%d: %s", stage, name)
                    try:
                        result = on_stop()
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception:
                        log.exception("Error during shutdown stage %d: %s", stage, name)
