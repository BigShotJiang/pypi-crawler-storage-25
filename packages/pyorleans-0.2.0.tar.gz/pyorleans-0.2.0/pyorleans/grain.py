"""
Base class for all virtual actors (Grains).

Modeled after Orleans' ``Grain`` / ``Grain<TGrainState>`` classes.
The Grain class no longer owns a threading lock — concurrency is managed
by the per-grain ``WorkItemQueue`` inside ``ActivationData``.
"""
from __future__ import annotations

import logging
from typing import Any, TYPE_CHECKING

from pyorleans.ids import GrainId
from pyorleans.deactivation import DeactivationReason, DeactivationReasonCode

if TYPE_CHECKING:
    from pyorleans.activation import ActivationData
    from pyorleans.silo import Silo

log = logging.getLogger(__name__)


class Grain:
    """
    Abstract base class for all grain implementations.

    Lifecycle hooks (override in your grain):
        - ``on_activate()``: called when the grain is loaded into memory.
        - ``on_deactivate(reason)``: called when the grain is being evicted.

    Accessing the runtime from within a grain:
        - ``self.identity`` — the grain's full ``GrainId``
        - ``self.primary_key`` — shortcut to the key portion of the identity
        - ``self.grain_factory`` — to get references to other grains
        - ``self.register_timer(...)`` — to schedule periodic callbacks
        - ``self.deactivate_on_idle()`` — request self-deactivation
        - ``self.delay_deactivation(seconds)`` — delay garbage collection
    """

    def __init__(self) -> None:
        # These are set by the Silo during activation, not by the user.
        self._grain_id: GrainId | None = None
        self._activation: ActivationData | None = None
        self._silo: Silo | None = None

    # ─── Identity Properties ─────────────────────────────────────────

    @property
    def identity(self) -> GrainId:
        """The full compound identity (GrainType + key) of this grain."""
        assert self._grain_id is not None, "Grain has not been activated yet."
        return self._grain_id

    @property
    def primary_key(self) -> str | int:
        """Shortcut to the key portion of the grain identity."""
        return self.identity.key

    @property
    def grain_factory(self):
        """Access the GrainFactory from within this grain to call other grains."""
        assert self._silo is not None, "Grain is not attached to a Silo."
        from pyorleans.factory import GrainFactory
        return GrainFactory(self._silo)

    # ─── Lifecycle Hooks ─────────────────────────────────────────────

    def on_activate(self) -> None:
        """
        Called when the grain is instantiated and loaded into memory.

        Override this in your grain to initialize resources, load external data, etc.
        This is called *after* the state has been hydrated from storage (if stateful).
        """

    def on_deactivate(self, reason: DeactivationReason) -> None:
        """
        Called when the grain is about to be removed from memory.

        Override this to flush resources, close connections, etc.

        Args:
            reason: Why the grain is being deactivated (idle, shutdown, error, etc.)
        """

    # ─── Runtime Actions ─────────────────────────────────────────────

    def deactivate_on_idle(self) -> None:
        """Request that this grain be deactivated after the current call completes."""
        if self._silo and self._activation:
            from pyorleans.activation import ActivationState
            reason = DeactivationReason(
                code=DeactivationReasonCode.APPLICATION_REQUESTED,
                description="deactivate_on_idle() was called.",
            )
            # Schedule deactivation after current turn
            import asyncio
            loop = asyncio.get_event_loop()
            loop.call_soon_threadsafe(
                asyncio.ensure_future,
                self._silo.deactivate_grain(self._activation, reason),
            )

    def delay_deactivation(self, seconds: float) -> None:
        """
        Prevent this grain from being garbage-collected for at least ``seconds``.

        Pass a negative value to cancel a previous delay.
        """
        if self._activation:
            self._activation.delay_deactivation(seconds)

    def register_timer(
        self,
        callback,
        due_time: float,
        period: float,
        state: Any = None,
        interleave: bool = True,
        keep_alive: bool = False,
    ):
        """
        Register a periodic timer on this grain.

        Args:
            callback: The function to call on each tick.
            due_time: Seconds to wait before the first tick.
            period: Seconds between subsequent ticks.
            state: Optional state object passed to the callback.
            interleave: If True, timer ticks can interleave with other calls.
            keep_alive: If True, timer ticks extend the grain's lifetime.

        Returns:
            A ``GrainTimer`` handle that can be used to stop the timer.
        """
        from pyorleans.timers import GrainTimer, GrainTimerOptions

        options = GrainTimerOptions(
            due_time=due_time,
            period=period,
            interleave=interleave,
            keep_alive=keep_alive,
        )
        timer = GrainTimer(
            activation=self._activation,
            callback=callback,
            state=state,
            options=options,
        )
        if self._activation:
            self._activation.timers.append(timer)
        timer.start()
        return timer

    # ─── Internal (set by Silo) ──────────────────────────────────────

    def _set_context(self, grain_id: GrainId, activation: ActivationData, silo: Silo) -> None:
        """Called by the Silo during activation. Not for public use."""
        self._grain_id = grain_id
        self._activation = activation
        self._silo = silo
