"""
Grain Observers — publish/subscribe pattern for grain-to-grain notifications.

Modeled after Orleans' ``IGrainObserver``. Observers allow a grain (or client)
to register a callback reference with another grain, which then sends
notifications back.
"""
from __future__ import annotations

import logging
import weakref
from typing import Any, Callable, Set

log = logging.getLogger(__name__)


class GrainObserver:
    """
    Base class for observer implementations.

    An observer is a lightweight object that receives notifications from
    a grain. Unlike grains, observers are not virtual actors — they must
    be explicitly created and registered.

    Usage::

        class ChatObserver(GrainObserver):
            def on_message(self, sender: str, text: str):
                print(f"{sender}: {text}")

        # In a grain:
        def subscribe(self, observer: GrainObserver):
            self._observers.add(observer)
    """

    pass


class ObserverManager:
    """
    Manages a set of observers for a grain, with automatic cleanup of dead references.

    Usage inside a Grain::

        class ChatRoomGrain(Grain):
            def on_activate(self):
                self._observers = ObserverManager()

            def subscribe(self, observer):
                self._observers.add(observer)

            def send_message(self, sender: str, text: str):
                self._observers.notify("on_message", sender, text)
    """

    def __init__(self) -> None:
        self._observers: Set[Any] = set()

    def add(self, observer: Any) -> None:
        """Register an observer."""
        self._observers.add(observer)
        log.debug("Observer added. Total: %d", len(self._observers))

    def remove(self, observer: Any) -> None:
        """Unregister an observer."""
        self._observers.discard(observer)

    def clear(self) -> None:
        """Remove all observers."""
        self._observers.clear()

    @property
    def count(self) -> int:
        return len(self._observers)

    def notify(self, method_name: str, *args, **kwargs) -> int:
        """
        Call ``method_name`` on all registered observers.

        Returns the number of observers that were successfully notified.
        Observers that raise exceptions are logged and removed.
        """
        failed = []
        notified = 0

        for observer in list(self._observers):
            try:
                method = getattr(observer, method_name, None)
                if method and callable(method):
                    method(*args, **kwargs)
                    notified += 1
                else:
                    log.warning(
                        "Observer %s does not have method '%s'",
                        type(observer).__name__,
                        method_name,
                    )
            except Exception:
                log.exception(
                    "Observer %s.%s() failed, removing from list.",
                    type(observer).__name__,
                    method_name,
                )
                failed.append(observer)

        for obs in failed:
            self._observers.discard(obs)

        return notified
