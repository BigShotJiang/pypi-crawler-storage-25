"""
The Silo — the host runtime for PyOrleans grains (virtual actors).

This is the completely rewritten Silo that integrates all Orleans paradigms:
- Activation lifecycle state machine
- Turn-based scheduling via WorkItemQueue
- Write-Behind persistence
- ActivationCollector for idle grain GC
- SiloLifecycle staged boot/shutdown
- GrainDirectory for activation lookup
- Filter pipeline for call interception
- GIL detection for Free-Threaded Python 3.14
"""
from __future__ import annotations

import sys
import logging
import asyncio
import dataclasses
import copy
import inspect
import threading
import concurrent.futures
import time
from typing import Dict, Type, Any, Optional

from pyorleans.grain import Grain
from pyorleans.ids import GrainId, GrainType
from pyorleans.activation import ActivationData, ActivationState
from pyorleans.scheduler import WorkItemQueue, WorkItem
from pyorleans.deactivation import (
    DeactivationReason,
    DeactivationReasonCode,
    ActivationCollector,
)
from pyorleans.state import StorageProvider, GrainStateManager
from pyorleans.directory import GrainDirectory, InMemoryGrainDirectory
from pyorleans.lifecycle import SiloLifecycle, SiloLifecycleStage
from pyorleans.filters import FilterPipeline, GrainCallContext
from pyorleans.reminders import ReminderRegistry
from pyorleans.exceptions import (
    GrainNotRegisteredError,
    GrainActivationError,
    GrainDeactivatedError,
    SiloNotRunningError,
)

log = logging.getLogger(__name__)


class Silo:
    """
    The host environment for PyOrleans Grains (Virtual Actors).

    This is the Python equivalent of Orleans' ``Silo`` class. It manages:
    - A thread pool for grain computation (Free-Threaded Python 3.14)
    - An asyncio event loop for network I/O and orchestration
    - A grain directory for activation lookup
    - An activation collector for idle grain GC
    - A write-behind queue for automatic state persistence
    - A filter pipeline for call interception
    """

    def __init__(
        self,
        max_workers: int | None = None,
        idle_timeout_seconds: float = 120.0,
        collection_interval_seconds: float = 60.0,
    ):
        # ── Thread Pool ──
        self._max_workers = max_workers
        self._thread_pool: concurrent.futures.ThreadPoolExecutor | None = None

        # ── Grain Registry ──
        self._grain_classes: Dict[str, Type[Grain]] = {}

        # ── Activation Directory (GrainId → ActivationData) ──
        self._activations: Dict[GrainId, ActivationData] = {}
        # asyncio.Lock for activation creation (called from single silo event loop)
        self._activation_locks: Dict[GrainId, asyncio.Lock] = {}

        # ── Sub-Systems ──
        self._storage: StorageProvider | None = None
        self._grain_directory: GrainDirectory = InMemoryGrainDirectory()
        self._collector = ActivationCollector(
            scan_interval_seconds=collection_interval_seconds,
            default_idle_timeout_seconds=idle_timeout_seconds,
        )
        self._lifecycle = SiloLifecycle()
        self._filter_pipeline = FilterPipeline()
        self._reminder_registry = ReminderRegistry()

        # ── Write-Behind ──
        self._write_behind_queue: asyncio.Queue | None = None
        self._write_behind_task: asyncio.Task | None = None

        # ── State ──
        self._running = False

        # ── GIL Check ──
        self._check_free_threaded_environment()

    # ─── Properties ──────────────────────────────────────────────────

    @property
    def activation_directory(self) -> Dict[GrainId, ActivationData]:
        return self._activations

    @property
    def filter_pipeline(self) -> FilterPipeline:
        return self._filter_pipeline

    @property
    def reminder_registry(self) -> ReminderRegistry:
        return self._reminder_registry

    @property
    def is_running(self) -> bool:
        return self._running

    # ─── Configuration ───────────────────────────────────────────────

    def register_grain_class(self, grain_class: Type[Grain]) -> None:
        """Register a grain type in this Silo."""
        name = grain_class.__name__
        self._grain_classes[name] = grain_class
        log.info("Registered grain type: %s", name)

    def register_storage(self, storage_provider: StorageProvider) -> None:
        """Set the storage backend for @stateful grains."""
        self._storage = storage_provider
        log.info("Storage provider registered: %s", type(storage_provider).__name__)

    def set_grain_directory(self, directory: GrainDirectory) -> None:
        """Replace the default in-memory grain directory."""
        self._grain_directory = directory

    # ─── Lifecycle ───────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the Silo and all sub-systems."""
        self._thread_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=self._max_workers
        )
        log.info(
            "Silo starting with ThreadPoolExecutor (max_workers=%s).",
            self._thread_pool._max_workers,
        )

        # Write-Behind
        self._write_behind_queue = asyncio.Queue()
        self._write_behind_task = asyncio.create_task(self._write_behind_loop())

        # Activation Collector
        self._collector.attach(self)
        await self._collector.start()

        # Reminders
        self._reminder_registry.attach(self)

        # Staged lifecycle
        await self._lifecycle.start()

        self._running = True
        log.info("Silo is ACTIVE.")

    async def stop(self) -> None:
        """Gracefully stop the Silo."""
        log.info("Silo shutting down...")
        self._running = False

        # Stop collector
        await self._collector.stop()

        # Deactivate all grains
        reason = DeactivationReason(
            code=DeactivationReasonCode.SHUTTING_DOWN,
            description="Silo is shutting down.",
        )
        for activation in list(self._activations.values()):
            await self.deactivate_grain(activation, reason)

        # Stop reminders
        await self._reminder_registry.stop()

        # Stop write-behind
        if self._write_behind_queue:
            self._write_behind_queue.put_nowait(None)
        if self._write_behind_task:
            await self._write_behind_task

        # Staged lifecycle shutdown
        await self._lifecycle.stop()

        # Thread pool
        if self._thread_pool:
            self._thread_pool.shutdown(wait=True)

        log.info("Silo stopped.")

    # ─── Grain Activation ────────────────────────────────────────────

    async def get_or_create_activation(
        self, grain_type_name: str, identity: str | int
    ) -> ActivationData:
        """
        Find an existing activation or create a new one (lazy loading).

        Uses per-grain asyncio.Lock to prevent duplicate activations when
        many concurrent calls arrive for the same grain simultaneously.
        """
        if grain_type_name not in self._grain_classes:
            raise GrainNotRegisteredError(grain_type_name)

        grain_id = GrainId.create(grain_type_name, identity)

        # Fast path: already active
        existing = self._activations.get(grain_id)
        if existing and existing.state == ActivationState.VALID:
            return existing

        # Slow path: asyncio.Lock per grain prevents duplicate activations.
        # This runs on the silo's event loop so asyncio.Lock is correct here.
        # The threading.Lock in WorkItemQueue handles cross-thread parallelism.
        if grain_id not in self._activation_locks:
            self._activation_locks[grain_id] = asyncio.Lock()

        async with self._activation_locks[grain_id]:
            # Double-check after acquiring lock
            existing = self._activations.get(grain_id)
            if existing and existing.state == ActivationState.VALID:
                return existing

            result = await self._create_activation(grain_id, grain_type_name)
            self._activation_locks.pop(grain_id, None)
            return result

    async def _create_activation(
        self, grain_id: GrainId, grain_type_name: str
    ) -> ActivationData:
        """Create, hydrate, and activate a new grain instance."""
        grain_cls = self._grain_classes[grain_type_name]

        # 1. CREATING
        grain_instance = grain_cls()
        activation = ActivationData(grain_id=grain_id, grain_instance=grain_instance)
        grain_instance._set_context(grain_id, activation, self)

        self._activations[grain_id] = activation
        log.info("Activating grain: %s", grain_id)

        # 2. ACTIVATING
        activation.state = ActivationState.ACTIVATING

        try:
            # 2a. Hydrate state from storage (if @stateful)
            if getattr(grain_cls, "__has_stateful__", False) and self._storage:
                state_mgr = GrainStateManager(
                    grain_type=grain_type_name,
                    identity=str(grain_id.key),
                    storage=self._storage,
                )
                grain_instance._state_manager = state_mgr
                await state_mgr.read(grain_instance.state)

            # 2b. Register in Grain Directory
            await self._grain_directory.register(activation.address)

            # 2c. Call user's on_activate hook (in thread pool)
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                self._thread_pool, grain_instance.on_activate
            )

            # 3. VALID — ready to receive messages
            activation.state = ActivationState.VALID
            activation.touch()

        except Exception as exc:
            activation.state = ActivationState.INVALID
            self._activations.pop(grain_id, None)
            raise GrainActivationError(grain_type_name, str(grain_id.key), exc)

        return activation

    # ─── Grain Deactivation ──────────────────────────────────────────

    async def deactivate_grain(
        self, activation: ActivationData, reason: DeactivationReason
    ) -> None:
        """Deactivate a grain: call on_deactivate, flush state, clean up."""
        if activation.state in (ActivationState.DEACTIVATING, ActivationState.INVALID):
            return

        activation.state = ActivationState.DEACTIVATING
        grain = activation.grain_instance
        log.info("Deactivating grain: %s (reason=%s)", activation.grain_id, reason)

        try:
            # Cancel all timers
            activation.cancel_all_timers()

            # Stop the work queue
            activation.work_queue.stop()

            # Flush state one last time
            if getattr(type(grain), "__has_stateful__", False) and grain._state_manager:
                await grain._state_manager.write(grain.state)

            # Call user's on_deactivate hook
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                self._thread_pool,
                grain.on_deactivate,
                reason,
            )
        except Exception:
            log.exception("Error during deactivation of %s", activation.grain_id)
        finally:
            activation.state = ActivationState.INVALID
            self._activations.pop(activation.grain_id, None)
            await self._grain_directory.unregister(activation.address)

    # ─── Method Invocation ───────────────────────────────────────────

    async def invoke_method(
        self,
        grain_type_name: str,
        identity: str | int,
        method_name: str,
        *args,
        **kwargs,
    ) -> Any:
        """
        Invoke a method on a grain, ensuring turn-based execution.

        Uses the grain's ``WorkItemQueue`` (backed by an asyncio.Lock) to
        guarantee that only one method executes at a time per grain, while
        running the actual computation in the thread pool.
        """
        activation = await self.get_or_create_activation(grain_type_name, identity)

        if activation.state != ActivationState.VALID:
            raise GrainDeactivatedError(grain_type_name, str(identity))

        grain = activation.grain_instance
        method = getattr(grain, method_name, None)
        if not method or not callable(method):
            raise AttributeError(
                f"Method '{method_name}' not found on grain '{grain_type_name}'"
            )

        loop = asyncio.get_running_loop()

        # Build the call context for the filter pipeline
        call_context = GrainCallContext(
            grain_type=grain_type_name,
            grain_id=activation.grain_id,
            method_name=method_name,
            arguments=args,
            keyword_arguments=kwargs,
        )

        def _execute():
            """Runs inside the thread pool under the per-grain threading.Lock."""

            def _invoke():
                result = method(*args, **kwargs)

                # If the grain method is async, execute it in a fresh event loop
                # bound to this thread. This is safe because we're already in the
                # thread pool; asyncio.run() creates a new loop for this call only.
                if inspect.iscoroutine(result):
                    result_val = asyncio.run(result)
                else:
                    result_val = result

                call_context.result = result_val

                # Write-Behind: queue state for persistence
                if getattr(type(grain), "__has_stateful__", False):
                    self._enqueue_write_behind(grain_type_name, identity, grain)

                activation.touch()
                return result_val

            # Run through filter pipeline
            try:
                return self._filter_pipeline.execute_incoming(call_context, _invoke)
            except Exception as exc:
                call_context.exception = exc
                raise

        # Submit through the per-grain threading.Lock → thread pool pipeline.
        # Different grains execute on different pool threads in TRUE PARALLEL.
        # Same grain: serialized by threading.Lock inside WorkItemQueue.
        return await activation.work_queue.submit(
            _execute, self._thread_pool, loop
        )

    # ─── Write-Behind ────────────────────────────────────────────────

    def _enqueue_write_behind(self, grain_type: str, identity: str | int, grain: Grain) -> None:
        """Queue a state snapshot for async persistence."""
        if not self._write_behind_queue:
            return

        state_data = {}
        if dataclasses.is_dataclass(grain.state):
            state_data = dataclasses.asdict(grain.state)
        elif hasattr(grain.state, "__dict__"):
            state_data = dict(grain.state.__dict__)

        self._write_behind_queue.put_nowait((
            grain_type,
            str(identity),
            copy.deepcopy(state_data),
        ))

    async def _write_behind_loop(self) -> None:
        """Background task that persists queued state changes."""
        log.info("Write-Behind manager started.")
        while True:
            try:
                item = await self._write_behind_queue.get()
                if item is None:
                    break

                grain_type, identity, state_data = item
                if self._storage:
                    await self._storage.write_state(grain_type, identity, state_data)

            except Exception:
                log.exception("Write-Behind flush failed")
            finally:
                self._write_behind_queue.task_done()

    # ─── GIL Check ───────────────────────────────────────────────────

    def _check_free_threaded_environment(self) -> None:
        """Detect and warn about GIL status on Python 3.13+."""
        if hasattr(sys, "_is_gil_enabled"):
            if sys._is_gil_enabled():
                log.warning(
                    "⚠️  Python GIL is ACTIVE. Multi-core performance is severely limited! "
                    "Use python3.14t (Free-Threaded) for full performance."
                )
            else:
                log.info("✅ Running in Free-Threaded mode (no GIL). Maximum performance enabled!")
        else:
            log.warning(
                "sys._is_gil_enabled not found. Cannot verify Free-Threaded mode."
            )
