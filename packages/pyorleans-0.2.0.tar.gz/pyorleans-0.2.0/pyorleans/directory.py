"""
Grain Directory — a registry that maps GrainId → GrainAddress.

Modeled after Orleans' ``IGrainDirectory``. In a single-silo deployment,
the directory is an in-memory dictionary. In multi-silo, it would be
backed by Redis, Consul, Etcd, or a distributed hash table.
"""
from __future__ import annotations

import logging
from typing import Optional, Dict

from pyorleans.ids import GrainId, GrainAddress

log = logging.getLogger(__name__)


class GrainDirectory:
    """
    Abstract base for grain directory implementations.

    A grain directory maintains a mapping of ``GrainId → GrainAddress``
    so that any silo can find where a given grain is currently activated.
    """

    async def register(self, address: GrainAddress) -> Optional[GrainAddress]:
        """
        Register an activation in the directory.

        If an activation for the same GrainId already exists, the existing
        address is returned and the new one is NOT registered.

        Returns:
            The registered GrainAddress (either the new one or the existing one).
        """
        raise NotImplementedError

    async def unregister(self, address: GrainAddress) -> None:
        """Remove an activation from the directory."""
        raise NotImplementedError

    async def lookup(self, grain_id: GrainId) -> Optional[GrainAddress]:
        """Find where a grain is currently activated."""
        raise NotImplementedError


class InMemoryGrainDirectory(GrainDirectory):
    """
    In-memory grain directory for single-silo deployments.

    Thread-safety note: in Free-Threaded Python 3.14, dict operations
    on separate keys are safe. We use a single dict here since all
    directory mutations happen on the Silo's asyncio thread.
    """

    def __init__(self) -> None:
        self._entries: Dict[GrainId, GrainAddress] = {}

    async def register(self, address: GrainAddress) -> Optional[GrainAddress]:
        existing = self._entries.get(address.grain_id)
        if existing is not None:
            return existing

        self._entries[address.grain_id] = address
        log.debug("Directory: registered %s", address)
        return address

    async def unregister(self, address: GrainAddress) -> None:
        removed = self._entries.pop(address.grain_id, None)
        if removed:
            log.debug("Directory: unregistered %s", address)

    async def lookup(self, grain_id: GrainId) -> Optional[GrainAddress]:
        return self._entries.get(grain_id)

    @property
    def count(self) -> int:
        return len(self._entries)
