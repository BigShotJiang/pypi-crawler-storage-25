"""
Turn-based scheduler — the heart of per-grain concurrency in PyOrleans.

Redesigned for true multi-core parallelism with Python 3.13+ Free-Threading (NoGIL).

Key architectural change from v1:
- v1 used asyncio.Lock → serialized ALL grain calls to a single event loop thread
- v2 uses threading.Lock → allows DIFFERENT grains to execute in PARALLEL across
  real OS threads, while SAME grain is still serialized (turn-based invariant held)

With PYTHON_GIL=0 + Granian --runtime-mode mt:
  GrainA["user-1"] runs on Thread-P1  ──┐
  GrainB["user-2"] runs on Thread-P2  ──┤ TRUE PARALLEL (no GIL!)
  GrainC["user-3"] runs on Thread-P3  ──┘

  GrainA["user-1"] call #1 → then call #2  (serialized by threading.Lock)
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable

log = logging.getLogger(__name__)


class WorkItemQueue:
    """
    Per-grain work queue ensuring single-threaded, turn-based execution.

    Uses a threading.Lock (NOT asyncio.Lock) so it works correctly across
    multiple event loops — essential for Granian's multi-thread mode where
    each worker thread has its own independent event loop.

    Execution model:
      1. Caller (any event loop / thread) calls await submit(coro_fn, ...)
      2. submit() dispatches to the shared ThreadPoolExecutor via run_in_executor
      3. Inside the pool thread: acquire threading.Lock → run coro in asyncio.run()
      4. Result is returned to the caller's event loop via Future

    This means:
      - Different grains: rodam em threads paralelas → exploram NoGIL
      - Same grain: serializado pelo threading.Lock → invariante Orleans mantida
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()   # per-grain, NOT asyncio
        self._stopped = False

    @property
    def is_running(self) -> bool:
        return self._lock.locked()

    @property
    def pending_count(self) -> int:
        return 0  # not tracked in this model

    async def submit(
        self,
        func: Callable,
        executor: ThreadPoolExecutor,
        loop: asyncio.AbstractEventLoop,
    ) -> Any:
        """
        Submit work for turn-based execution across thread boundaries.

        `func` must be a zero-argument callable that may return either a plain
        value or a coroutine. Coroutines are executed via asyncio.run() inside
        the pool thread (each gets its own temporary event loop).
        """
        if self._stopped:
            raise RuntimeError("WorkItemQueue has been stopped")

        def _thread_worker() -> Any:
            """Runs inside the thread pool. Acquires per-grain lock."""
            with self._lock:
                if self._stopped:
                    raise RuntimeError("WorkItemQueue has been stopped")
                result = func()
                # If the grain method was async, run() it on a fresh event loop
                # tied to THIS thread (not the caller's event loop).
                if inspect.iscoroutine(result):
                    return asyncio.run(result)
                return result

        return await loop.run_in_executor(executor, _thread_worker)

    def stop(self) -> None:
        """Mark the queue as stopped — future submissions will raise."""
        self._stopped = True


# ── Backwards-compat shim (tests import WorkItem) ────────────────────────────
from dataclasses import dataclass, field

@dataclass
class WorkItem:
    """Legacy shim kept for test compatibility."""
    func: Callable
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)
    future: Any = None
