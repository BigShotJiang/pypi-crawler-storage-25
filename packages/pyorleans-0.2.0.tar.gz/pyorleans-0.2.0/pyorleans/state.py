"""
State management and persistence for grains.

Modeled after Orleans' ``IStorage<T>`` with ETag-based optimistic concurrency,
explicit Read/Write/Clear operations, and Write-Behind automatic persistence.
"""
from __future__ import annotations

import copy
import logging
import uuid
from typing import Any, Dict, Optional, Type

log = logging.getLogger(__name__)


class StorageProvider:
    """
    Abstract base for storage backends.

    Mirrors Orleans' ``IGrainStorage`` with ETag support for optimistic concurrency.
    """

    async def read_state(
        self, grain_type: str, identity: str
    ) -> tuple[Optional[Dict[str, Any]], Optional[str]]:
        """
        Read state from storage.

        Returns:
            A tuple of (state_dict, etag). Returns (None, None) if no state exists.
        """
        raise NotImplementedError

    async def write_state(
        self, grain_type: str, identity: str, state_data: Dict[str, Any], etag: Optional[str] = None
    ) -> str:
        """
        Write state to storage.

        Args:
            etag: If provided, the write will only succeed if the stored ETag matches.

        Returns:
            The new ETag after the write.

        Raises:
            ETagMismatchError: If the ETag doesn't match (concurrent modification).
        """
        raise NotImplementedError

    async def clear_state(
        self, grain_type: str, identity: str, etag: Optional[str] = None
    ) -> None:
        """
        Clear (delete) the grain's state from storage.

        Args:
            etag: If provided, only clear if the ETag matches.
                  Pass None to force-clear regardless.
        """
        raise NotImplementedError


class LocalMemoryStorage(StorageProvider):
    """In-memory storage provider for development and testing."""

    def __init__(self) -> None:
        self._store: Dict[str, tuple[Dict[str, Any], str]] = {}

    async def read_state(
        self, grain_type: str, identity: str
    ) -> tuple[Optional[Dict[str, Any]], Optional[str]]:
        key = f"{grain_type}:{identity}"
        entry = self._store.get(key)
        if entry is None:
            return None, None
        state_data, etag = entry
        return copy.deepcopy(state_data), etag

    async def write_state(
        self, grain_type: str, identity: str, state_data: Dict[str, Any], etag: Optional[str] = None
    ) -> str:
        key = f"{grain_type}:{identity}"
        existing = self._store.get(key)

        if etag is not None and existing is not None:
            _, stored_etag = existing
            if stored_etag != etag:
                from pyorleans.exceptions import ETagMismatchError
                raise ETagMismatchError(expected=etag, actual=stored_etag)

        new_etag = uuid.uuid4().hex[:8]
        self._store[key] = (copy.deepcopy(state_data), new_etag)
        log.debug("[Storage] Saved %s (etag=%s)", key, new_etag)
        return new_etag

    async def clear_state(
        self, grain_type: str, identity: str, etag: Optional[str] = None
    ) -> None:
        key = f"{grain_type}:{identity}"
        existing = self._store.get(key)

        if etag is not None and existing is not None:
            _, stored_etag = existing
            if stored_etag != etag:
                from pyorleans.exceptions import ETagMismatchError
                raise ETagMismatchError(expected=etag, actual=stored_etag)

        self._store.pop(key, None)
        log.debug("[Storage] Cleared %s", key)


class GrainStateManager:
    """
    Per-grain state adapter that wraps a StorageProvider.

    This is injected into stateful grains and provides ``read()``, ``write()``,
    ``clear()`` methods. The grain can also rely on the Silo's Write-Behind
    for automatic persistence after each method call.
    """

    def __init__(
        self,
        grain_type: str,
        identity: str,
        storage: StorageProvider,
    ):
        self._grain_type = grain_type
        self._identity = identity
        self._storage = storage
        self.etag: Optional[str] = None
        self.record_exists: bool = False

    async def read(self, state_obj: Any) -> None:
        """Read state from storage and populate the grain's state object."""
        data, etag = await self._storage.read_state(self._grain_type, self._identity)
        self.etag = etag
        self.record_exists = data is not None

        if data is not None:
            for k, v in data.items():
                if hasattr(state_obj, k):
                    setattr(state_obj, k, v)

    async def write(self, state_obj: Any) -> None:
        """Write the grain's current state to storage."""
        import dataclasses

        if dataclasses.is_dataclass(state_obj):
            state_data = dataclasses.asdict(state_obj)
        elif hasattr(state_obj, "__dict__"):
            state_data = dict(state_obj.__dict__)
        else:
            state_data = {}

        self.etag = await self._storage.write_state(
            self._grain_type, self._identity, state_data, self.etag
        )
        self.record_exists = True

    async def clear(self) -> None:
        """Clear/delete the grain's state from storage."""
        await self._storage.clear_state(self._grain_type, self._identity, self.etag)
        self.etag = None
        self.record_exists = False


def stateful(schema_cls: Type):
    """
    Decorator for Grain classes.

    Injects a state schema instance and marks it for automatic persistence
    (Write-Behind) after each method invocation.

    Usage::

        @dataclass
        class UserState:
            points: int = 0
            name: str = "Unknown"

        @stateful(UserState)
        class UserGrain(Grain):
            def add_points(self, amount: int):
                self.state.points += amount

    The ``self.state`` attribute is automatically populated from storage
    on activation and saved back after each method call.
    """

    def wrapper(grain_cls: Type) -> Type:
        grain_cls.__has_stateful__ = True
        grain_cls.__state_schema__ = schema_cls

        original_init = grain_cls.__init__

        def new_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            self.state = schema_cls()
            self._state_manager: Optional[GrainStateManager] = None

        grain_cls.__init__ = new_init
        return grain_cls

    return wrapper
