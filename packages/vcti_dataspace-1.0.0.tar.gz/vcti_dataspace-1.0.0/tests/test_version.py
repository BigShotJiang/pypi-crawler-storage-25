# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Version tests for vcti-dataspace."""

import re

import vcti.dataspace


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.dataspace, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.dataspace.__version__)
