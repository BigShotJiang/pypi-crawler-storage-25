# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for DataSpace, Workspace, PathSource, and FilesProject."""

from pathlib import Path
from typing import Any

import numpy as np
import pytest
from vcti.arraytree import DataNode

from vcti.dataspace import (
    DataSpace,
    DataSpaceError,
    DuplicateNameError,
    FilesProject,
    ImmutableDataSpaceError,
    InvalidDataError,
    LazyDatasetReference,
    NodeNameError,
    NodeNotDatasetError,
    NodeNotFoundError,
    PathSource,
    Workspace,
)
from vcti.dataspace.dataspace import MAX_NODE_NAME_BYTES, NODE_INFO_DTYPE, TREE_DTYPE
from vcti.dataspace.errors import FormatDetectionError, LoaderError

# -- Mock loader for testing --------------------------------------------------


class MockLoader:
    id = "mock-loader"
    validator = None
    setup = None

    def load(self, path: Path, **options: Any) -> dict:
        return {"path": str(path)}

    def unload(self, data: Any) -> None:
        pass

    def can_load(self, path: Path) -> bool:
        return path.suffix == ".mock"

    def load_tree(self, data: Any) -> np.ndarray:
        return np.array(
            [(1, 0, 2, 0, 0), (2, 1, 0, 0, 0)],
            dtype=TREE_DTYPE,
        )

    def load_node_info(self, data: Any) -> np.ndarray:
        return np.array(
            [(1, b"root", 0, 0), (2, b"data", 1, 24)],
            dtype=NODE_INFO_DTYPE,
        )

    def load_attributes(self, data: Any, node_ids: np.ndarray | None = None) -> dict:
        return {1: {"type": "root"}, 2: {"units": "mm"}}

    def load_dataset(self, data: Any, node_id: int) -> DataNode:
        return DataNode(data=np.array([1.0, 2.0, 3.0]), attributes={"node_id": node_id})


# -- DataSpace User tests -----------------------------------------------------


class TestDataSpaceUser:
    def test_create_empty(self):
        space = DataSpace()
        assert not space.is_source
        assert len(space.tree) == 0

    def test_create_group(self):
        space = DataSpace()
        gid = space.create_group("results")
        assert gid == 1
        info = space.get_node_info(gid)
        assert info is not None
        assert info["name"] == b"results"

    def test_create_dataset(self):
        space = DataSpace()
        did = space.create_dataset("stress", np.array([1.0, 2.0]))
        assert did == 1
        ds = space.get_dataset(did)
        assert np.array_equal(ds.data, [1.0, 2.0])

    def test_create_nested(self):
        space = DataSpace()
        gid = space.create_group("results")
        did = space.create_dataset("stress", np.array([1.0]), parent_id=gid)
        children = space._get_children(gid)
        assert did in children

    def test_source_immutable_group(self):
        space = DataSpace(is_source=True)
        with pytest.raises(ImmutableDataSpaceError, match="Cannot modify"):
            space.create_group("test")

    def test_source_immutable_dataset(self):
        space = DataSpace(is_source=True)
        with pytest.raises(ImmutableDataSpaceError, match="Cannot modify"):
            space.create_dataset("test", np.array([1.0]))

    def test_get_missing_dataset_raises(self):
        space = DataSpace()
        with pytest.raises(NodeNotDatasetError, match="not a dataset"):
            space.get_dataset(999)

    def test_get_missing_node_info(self):
        space = DataSpace()
        assert space.get_node_info(999) is None

    def test_repr(self):
        space = DataSpace()
        assert "user" in repr(space)

    def test_attributes(self):
        space = DataSpace()
        space.create_group("grp", attributes={"key": "val"})
        assert space.attributes[1]["key"] == "val"

    def test_multiple_root_nodes(self):
        space = DataSpace()
        g1 = space.create_group("a")
        g2 = space.create_group("b")
        g3 = space.create_group("c")
        # All should be in tree with parent_id=0
        assert len(space.tree) == 3
        for nid in (g1, g2, g3):
            mask = space.tree["id"] == nid
            assert int(space.tree[mask][0]["parent_id"]) == 0

    def test_multiple_children_under_group(self):
        space = DataSpace()
        gid = space.create_group("parent")
        c1 = space.create_dataset("a", np.array([1.0]), parent_id=gid)
        c2 = space.create_dataset("b", np.array([2.0]), parent_id=gid)
        c3 = space.create_dataset("c", np.array([3.0]), parent_id=gid)
        children = space._get_children(gid)
        assert children == [c1, c2, c3]

    def test_create_dataset_non_array_raises(self):
        space = DataSpace()
        with pytest.raises(InvalidDataError, match="numpy array"):
            space.create_dataset("bad", [1, 2, 3])  # type: ignore[arg-type]

    def test_create_group_invalid_parent_raises(self):
        space = DataSpace()
        with pytest.raises(NodeNotFoundError, match="not found"):
            space.create_group("child", parent_id=999)


# -- Node name validation tests -----------------------------------------------


class TestNodeNameValidation:
    def test_empty_name_raises(self):
        space = DataSpace()
        with pytest.raises(NodeNameError, match="must not be empty"):
            space.create_group("")

    def test_empty_name_dataset_raises(self):
        space = DataSpace()
        with pytest.raises(NodeNameError, match="must not be empty"):
            space.create_dataset("", np.array([1.0]))

    def test_long_name_raises(self):
        space = DataSpace()
        long_name = "x" * (MAX_NODE_NAME_BYTES + 1)
        with pytest.raises(NodeNameError, match="exceeds"):
            space.create_group(long_name)

    def test_max_length_name_succeeds(self):
        space = DataSpace()
        name = "x" * MAX_NODE_NAME_BYTES  # exactly at limit (ASCII)
        gid = space.create_group(name)
        assert gid == 1

    def test_unicode_name(self):
        space = DataSpace()
        gid = space.create_group("résultats")
        info = space.get_node_info(gid)
        assert info["name"].decode("utf-8") == "résultats"

    def test_unicode_multibyte_overflow_raises(self):
        """Multi-byte UTF-8 characters can exceed byte limit even if char count is within limit."""
        space = DataSpace()
        # Each emoji is 4 bytes in UTF-8
        name = "\U0001f600" * (MAX_NODE_NAME_BYTES // 4 + 1)
        with pytest.raises(NodeNameError, match="exceeds"):
            space.create_group(name)


# -- Node deletion tests ------------------------------------------------------


class TestDeleteNode:
    def test_delete_leaf(self):
        space = DataSpace()
        gid = space.create_group("parent")
        did = space.create_dataset("child", np.array([1.0]), parent_id=gid)
        space.delete_node(did)
        assert space.get_node_info(did) is None
        assert space._get_children(gid) == []

    def test_delete_group_recursive(self):
        space = DataSpace()
        gid = space.create_group("parent")
        d1 = space.create_dataset("a", np.array([1.0]), parent_id=gid)
        d2 = space.create_dataset("b", np.array([2.0]), parent_id=gid)
        space.delete_node(gid, recursive=True)
        assert space.get_node_info(gid) is None
        assert space.get_node_info(d1) is None
        assert space.get_node_info(d2) is None
        assert len(space.tree) == 0

    def test_delete_non_recursive_with_children_raises(self):
        space = DataSpace()
        gid = space.create_group("parent")
        space.create_dataset("child", np.array([1.0]), parent_id=gid)
        with pytest.raises(DataSpaceError, match=r"has .* children"):
            space.delete_node(gid, recursive=False)

    def test_delete_missing_raises(self):
        space = DataSpace()
        with pytest.raises(NodeNotFoundError, match="not found"):
            space.delete_node(999)

    def test_delete_on_source_raises(self):
        space = DataSpace(is_source=True)
        space.build_from_loader(MockLoader(), {})
        with pytest.raises(ImmutableDataSpaceError, match="Cannot modify"):
            space.delete_node(1)

    def test_delete_middle_sibling(self):
        """Deleting a middle sibling correctly relinks prev and next."""
        space = DataSpace()
        gid = space.create_group("parent")
        c1 = space.create_dataset("a", np.array([1.0]), parent_id=gid)
        c2 = space.create_dataset("b", np.array([2.0]), parent_id=gid)
        c3 = space.create_dataset("c", np.array([3.0]), parent_id=gid)
        space.delete_node(c2)
        children = space._get_children(gid)
        assert children == [c1, c3]

    def test_delete_first_sibling(self):
        """Deleting the first child updates parent's first_child_id."""
        space = DataSpace()
        gid = space.create_group("parent")
        c1 = space.create_dataset("a", np.array([1.0]), parent_id=gid)
        c2 = space.create_dataset("b", np.array([2.0]), parent_id=gid)
        space.delete_node(c1)
        children = space._get_children(gid)
        assert children == [c2]

    def test_delete_cleans_up_datasets_and_attributes(self):
        space = DataSpace()
        did = space.create_dataset("data", np.array([1.0]), attributes={"key": "val"})
        assert did in space.datasets
        assert did in space.attributes
        space.delete_node(did)
        assert did not in space.datasets
        assert did not in space.attributes

    def test_delete_deep_recursive(self):
        """Deleting a 3-level hierarchy (group > group > dataset) must not corrupt the index."""
        space = DataSpace()
        g1 = space.create_group("level1")
        g2 = space.create_group("level2", parent_id=g1)
        d1 = space.create_dataset("leaf", np.array([1.0, 2.0]), parent_id=g2)
        assert space.node_count == 3

        space.delete_node(g1, recursive=True)
        assert space.node_count == 0
        assert space.get_node_info(g1) is None
        assert space.get_node_info(g2) is None
        assert space.get_node_info(d1) is None

    def test_delete_deep_mixed_siblings(self):
        """Delete a group that has both group-children and dataset-children nested 3 deep."""
        space = DataSpace()
        root = space.create_group("root")
        child_g = space.create_group("child_group", parent_id=root)
        child_d = space.create_dataset("child_data", np.array([1.0]), parent_id=root)
        grandchild = space.create_dataset("grandchild", np.array([2.0]), parent_id=child_g)

        space.delete_node(root, recursive=True)
        assert space.node_count == 0
        for nid in (root, child_g, child_d, grandchild):
            assert space.get_node_info(nid) is None


# -- DataSpace properties tests -----------------------------------------------


class TestDataSpaceProperties:
    def test_node_count(self):
        space = DataSpace()
        assert space.node_count == 0
        space.create_group("a")
        assert space.node_count == 1
        space.create_group("b")
        assert space.node_count == 2

    def test_dataset_count(self):
        space = DataSpace()
        assert space.dataset_count == 0
        space.create_dataset("d", np.array([1.0]))
        assert space.dataset_count == 1
        space.create_group("g")
        assert space.dataset_count == 1  # groups don't count


# -- Index integrity tests ----------------------------------------------------


class TestVerifyIndex:
    def test_verify_index_after_mutations(self):
        space = DataSpace()
        g = space.create_group("a")
        space.create_dataset("d", np.array([1.0]), parent_id=g)
        assert space.verify_index() is True

    def test_verify_index_after_delete(self):
        space = DataSpace()
        g = space.create_group("a")
        d = space.create_dataset("d", np.array([1.0]), parent_id=g)
        space.delete_node(d)
        assert space.verify_index() is True

    def test_verify_index_detects_corruption(self):
        space = DataSpace()
        space.create_group("a")
        # Manually corrupt the index
        space._index[999] = 42
        with pytest.raises(DataSpaceError, match="Index integrity check failed"):
            space.verify_index()


# -- DataSpace Source tests ---------------------------------------------------


class TestDataSpaceSource:
    def test_build_from_loader(self):
        space = DataSpace(is_source=True)
        loader = MockLoader()
        space.build_from_loader(loader, {})

        assert len(space.tree) == 2
        assert len(space.node_info) == 2
        assert 2 in space.datasets  # dataset node

    def test_lazy_dataset(self):
        space = DataSpace(is_source=True)
        loader = MockLoader()
        space.build_from_loader(loader, {})

        ds = space.get_dataset(2)
        assert isinstance(ds, DataNode)
        assert np.array_equal(ds.data, [1.0, 2.0, 3.0])

    def test_clear_cache(self):
        space = DataSpace(is_source=True)
        loader = MockLoader()
        space.build_from_loader(loader, {})

        space.get_dataset(2)  # populate cache
        space.clear_dataset_cache()
        # Should be able to reload
        ds = space.get_dataset(2)
        assert ds.data is not None

    def test_build_on_user_raises(self):
        space = DataSpace()
        with pytest.raises(ImmutableDataSpaceError, match="source DataSpaces"):
            space.build_from_loader(MockLoader(), {})

    def test_repr_source(self):
        space = DataSpace(is_source=True)
        assert "source" in repr(space)

    def test_clear_cache_on_user_is_noop(self):
        space = DataSpace()
        space.create_dataset("d", np.array([1.0]))
        space.clear_dataset_cache()  # should not raise
        assert len(space.datasets) == 1

    def test_index_rebuilt_after_build(self):
        space = DataSpace(is_source=True)
        space.build_from_loader(MockLoader(), {})
        assert 1 in space._index
        assert 2 in space._index


# -- Copy node tests ----------------------------------------------------------


class TestCopyNode:
    def test_copy_dataset(self):
        src = DataSpace(is_source=True)
        src.build_from_loader(MockLoader(), {})

        dst = DataSpace()
        new_id = dst.copy_node_from(src, node_id=2)
        ds = dst.get_dataset(new_id)
        assert np.array_equal(ds.data, [1.0, 2.0, 3.0])

    def test_copy_group_recursive(self):
        """Copy a group with children — all children should be copied."""
        src = DataSpace(is_source=True)
        src.build_from_loader(MockLoader(), {})

        dst = DataSpace()
        new_id = dst.copy_node_from(src, node_id=1, recursive=True)
        # Root group copied, plus its child dataset
        assert len(dst.tree) == 2
        children = dst._get_children(new_id)
        assert len(children) == 1
        ds = dst.get_dataset(children[0])
        assert np.array_equal(ds.data, [1.0, 2.0, 3.0])

    def test_copy_missing_raises(self):
        src = DataSpace(is_source=True)
        src.build_from_loader(MockLoader(), {})

        dst = DataSpace()
        with pytest.raises(NodeNotFoundError, match="not found"):
            dst.copy_node_from(src, node_id=999)

    def test_copy_on_source_raises(self):
        src = DataSpace(is_source=True)
        src.build_from_loader(MockLoader(), {})

        dst = DataSpace(is_source=True)
        with pytest.raises(ImmutableDataSpaceError, match="Cannot modify"):
            dst.copy_node_from(src, node_id=2)


# -- HDF5 export tests --------------------------------------------------------


class TestExportHdf5:
    def test_export_basic(self, tmp_path: Path):
        space = DataSpace()
        gid = space.create_group("results")
        space.create_dataset("values", np.array([1.0, 2.0, 3.0]), parent_id=gid)

        out = tmp_path / "output.h5"
        space.export_hdf5(out)
        assert out.exists()

        import h5py

        with h5py.File(out, "r") as f:
            assert "results" in f
            assert "values" in f["results"]
            assert np.array_equal(f["results"]["values"][:], [1.0, 2.0, 3.0])

    def test_export_with_attributes(self, tmp_path: Path):
        space = DataSpace()
        gid = space.create_group("grp", attributes={"group_attr": "gval"})
        space.create_dataset("ds", np.array([10.0]), parent_id=gid, attributes={"ds_attr": "dval"})

        out = tmp_path / "attrs.h5"
        space.export_hdf5(out)

        import h5py

        with h5py.File(out, "r") as f:
            assert f["grp"].attrs["group_attr"] == "gval"
            assert f["grp"]["ds"].attrs["ds_attr"] == "dval"

    def test_export_empty_dataspace(self, tmp_path: Path):
        space = DataSpace()
        out = tmp_path / "empty.h5"
        space.export_hdf5(out)
        assert out.exists()

        import h5py

        with h5py.File(out, "r") as f:
            assert len(f.keys()) == 0

    def test_export_multiple_roots(self, tmp_path: Path):
        space = DataSpace()
        space.create_group("group_a")
        space.create_group("group_b")

        out = tmp_path / "multi.h5"
        space.export_hdf5(out)

        import h5py

        with h5py.File(out, "r") as f:
            assert "group_a" in f
            assert "group_b" in f

    def test_export_string_path(self, tmp_path: Path):
        space = DataSpace()
        space.create_group("grp")
        out = str(tmp_path / "str_path.h5")
        space.export_hdf5(out)
        assert Path(out).exists()

    def test_export_deep_nested(self, tmp_path: Path):
        """Export a 3-level nested structure: group > group > dataset with attributes."""
        space = DataSpace()
        g1 = space.create_group("level1", attributes={"depth": 1})
        g2 = space.create_group("level2", parent_id=g1, attributes={"depth": 2})
        space.create_dataset(
            "leaf", np.array([10.0, 20.0]), parent_id=g2, attributes={"units": "mm"}
        )
        # Also add a sibling dataset at level1
        space.create_dataset("side", np.array([99.0]), parent_id=g1)

        out = tmp_path / "deep.h5"
        space.export_hdf5(out)

        import h5py

        with h5py.File(out, "r") as f:
            assert "level1" in f
            assert f["level1"].attrs["depth"] == 1
            assert "level2" in f["level1"]
            assert f["level1/level2"].attrs["depth"] == 2
            assert "leaf" in f["level1/level2"]
            assert np.array_equal(f["level1/level2/leaf"][:], [10.0, 20.0])
            assert f["level1/level2/leaf"].attrs["units"] == "mm"
            assert "side" in f["level1"]
            assert np.array_equal(f["level1/side"][:], [99.0])

    def test_export_truncates_existing_file(self, tmp_path: Path):
        """Exporting to an existing file overwrites it."""
        space1 = DataSpace()
        space1.create_group("old_data")
        out = tmp_path / "overwrite.h5"
        space1.export_hdf5(out)

        space2 = DataSpace()
        space2.create_group("new_data")
        space2.export_hdf5(out)

        import h5py

        with h5py.File(out, "r") as f:
            assert "new_data" in f
            assert "old_data" not in f


# -- LazyDatasetReference tests ------------------------------------------------


class TestLazyDatasetReference:
    def test_caching(self):
        loader = MockLoader()
        ref = LazyDatasetReference(loader, {}, 2)
        ds1 = ref.get_dataset()
        ds2 = ref.get_dataset()
        assert ds1 is ds2

    def test_clear_cache(self):
        loader = MockLoader()
        ref = LazyDatasetReference(loader, {}, 2)
        ref.get_dataset()
        ref.clear_cache()
        assert ref._cached_dataset is None


# -- Workspace tests ----------------------------------------------------------


class TestWorkspace:
    def test_create_dataspace(self):
        ws = Workspace()
        space = ws.create_dataspace("results")
        assert isinstance(space, DataSpace)
        assert not space.is_source

    def test_duplicate_raises(self):
        ws = Workspace()
        ws.create_dataspace("results")
        with pytest.raises(DuplicateNameError, match="already exists"):
            ws.create_dataspace("results")

    def test_get_dataspace(self):
        ws = Workspace()
        ws.create_dataspace("results")
        assert ws.get_dataspace("results") is not None
        assert ws.get_dataspace("missing") is None

    def test_remove_dataspace(self):
        ws = Workspace()
        ws.create_dataspace("results")
        ws.remove_dataspace("results")
        assert ws.get_dataspace("results") is None

    def test_remove_nonexistent_is_noop(self):
        ws = Workspace()
        ws.remove_dataspace("nonexistent")  # should not raise

    def test_clear(self):
        ws = Workspace()
        ws.create_dataspace("a")
        ws.create_dataspace("b")
        ws.clear()
        assert len(ws.dataspaces) == 0

    def test_repr(self):
        assert "Workspace" in repr(Workspace())


# -- PathSource tests ---------------------------------------------------------


class TestPathSource:
    def test_create_with_loader(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        assert source.name == "sim"
        assert source.path == Path("data.mock")
        assert source.loader is loader
        assert not source.is_loaded

    def test_load_unload(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        source.load()
        assert source.is_loaded
        assert source.dataspace is not None
        assert len(source.dataspace.tree) == 2

        source.unload()
        assert not source.is_loaded
        assert source.dataspace is None
        assert source.handle is None

    def test_reload(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        source.load()
        first_ds = source.dataspace
        source.reload()
        assert source.is_loaded
        assert source.dataspace is not first_ds  # new instance

    def test_load_idempotent(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        source.load()
        ds = source.dataspace
        source.load()  # second call should be no-op
        assert source.dataspace is ds

    def test_load_no_loader_raises(self):
        source = PathSource(name="sim", path=Path("data.mock"))
        with pytest.raises(LoaderError, match="No loader configured"):
            source.load()

    def test_unload_when_not_loaded_is_noop(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        source.unload()  # should not raise

    def test_repr_unloaded(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        r = repr(source)
        assert "unloaded" in r
        assert "sim" in r

    def test_repr_loaded(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        source.load()
        assert "loaded" in repr(source)

    def test_unknown_format_raises(self):
        with pytest.raises(FormatDetectionError, match="Could not detect format"):
            # Passing a mock registry to trigger detection
            PathSource(name="sim", path=Path("data.xyz"), registry=_MockRegistry())

    def test_metadata(self):
        loader = MockLoader()
        source = PathSource(
            name="sim", path=Path("data.mock"), loader=loader, metadata={"key": "val"}
        )
        assert source.metadata["key"] == "val"

    def test_metadata_default_empty(self):
        loader = MockLoader()
        source = PathSource(name="sim", path=Path("data.mock"), loader=loader)
        assert source.metadata == {}

    def test_string_path_converted(self):
        loader = MockLoader()
        source = PathSource(name="sim", path="data.mock", loader=loader)
        assert isinstance(source.path, Path)


class _MockRegistry:
    """Minimal mock to trigger format detection path."""

    def get(self, format_id: str) -> Any:
        raise KeyError(f"No loader for {format_id}")


# -- FilesProject tests -------------------------------------------------------


class TestFilesProject:
    def test_context_manager(self):
        with FilesProject("test") as p:
            assert p.name == "test"

    def test_open_workspace(self):
        p = FilesProject("test")
        ws = p.open_workspace()
        assert isinstance(ws, Workspace)
        assert p.open_workspace() is ws  # same instance

    def test_open_multiple_workspaces(self):
        p = FilesProject("test")
        ws1 = p.open_workspace("analysis")
        ws2 = p.open_workspace("report")
        assert ws1 is not ws2
        assert ws1.name == "analysis"
        assert ws2.name == "report"
        # Same name returns same instance
        assert p.open_workspace("analysis") is ws1

    def test_multiple_workspaces_are_independent(self):
        p = FilesProject("test")
        ws1 = p.open_workspace("a")
        ws2 = p.open_workspace("b")
        ws1.create_dataspace("d1")
        assert ws2.get_dataspace("d1") is None  # should not leak

    def test_close_workspace(self):
        p = FilesProject("test")
        p.open_workspace("ws1")
        p.close_workspace("ws1")
        # Opening again creates a new instance
        ws2 = p.open_workspace("ws1")
        assert ws2 is not None

    def test_repr(self):
        p = FilesProject("test")
        assert "FilesProject" in repr(p)
        assert "test" in repr(p)

    def test_close(self):
        p = FilesProject("test")
        p.open_workspace()
        p.close()
        assert len(p._workspaces) == 0

    def test_add_path_source_with_loader(self):
        p = FilesProject("test")
        source = p.add_path_source("sim", Path("data.mock"), loader=MockLoader())
        assert source.is_loaded
        assert p.get_path_source("sim") is source

    def test_add_path_source_no_auto_load(self):
        p = FilesProject("test")
        source = p.add_path_source("sim", Path("data.mock"), loader=MockLoader(), auto_load=False)
        assert not source.is_loaded

    def test_add_duplicate_source_raises(self):
        p = FilesProject("test")
        p.add_path_source("sim", Path("data.mock"), loader=MockLoader())
        with pytest.raises(DuplicateNameError, match="already exists"):
            p.add_path_source("sim", Path("other.mock"), loader=MockLoader())

    def test_remove_path_source(self):
        p = FilesProject("test")
        p.add_path_source("sim", Path("data.mock"), loader=MockLoader())
        p.remove_path_source("sim")
        assert p.get_path_source("sim") is None

    def test_remove_nonexistent_source_is_noop(self):
        p = FilesProject("test")
        p.remove_path_source("nonexistent")  # should not raise

    def test_get_path_source_missing(self):
        p = FilesProject("test")
        assert p.get_path_source("nonexistent") is None

    def test_list_path_sources(self):
        p = FilesProject("test")
        assert p.list_path_sources() == []
        p.add_path_source("sim", Path("data.mock"), loader=MockLoader())
        p.add_path_source("exp", Path("exp.mock"), loader=MockLoader())
        assert p.list_path_sources() == ["sim", "exp"]

    def test_close_unloads_sources(self):
        p = FilesProject("test")
        source = p.add_path_source("sim", Path("data.mock"), loader=MockLoader())
        assert source.is_loaded
        p.close()
        assert not source.is_loaded
