# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Custom exceptions for vcti.dataspace."""


class DataSpaceError(Exception):
    """Base exception for all DataSpace errors."""


class ImmutableDataSpaceError(DataSpaceError):
    """Raised when attempting to modify a source (immutable) DataSpace."""


class NodeNotFoundError(DataSpaceError, KeyError):
    """Raised when a referenced node does not exist."""


class NodeNotDatasetError(DataSpaceError, KeyError):
    """Raised when a node is not a dataset."""


class DuplicateNameError(DataSpaceError, ValueError):
    """Raised when a name already exists in a given scope."""


class NodeNameError(DataSpaceError, ValueError):
    """Raised when a node name is invalid (empty, too long, etc.)."""


class LoaderError(DataSpaceError):
    """Raised for errors related to file loading."""


class FormatDetectionError(LoaderError, ValueError):
    """Raised when file format cannot be detected."""


class InvalidDataError(DataSpaceError, TypeError):
    """Raised when data passed to a DataSpace operation has an invalid type."""


class ExportError(DataSpaceError):
    """Raised for errors during data export."""
