# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Workspace — session environment for data manipulation."""

from typing import Any

from .dataspace import DataSpace
from .errors import DuplicateNameError


class Workspace:
    """Working environment for data manipulation sessions.

    Manages user-created DataSpaces. Source DataSpaces are accessed
    via PathSource.dataspace in the project.

    Example:
        >>> ws = Workspace("analysis")
        >>> space = ws.create_dataspace("results")
        >>> space.create_group("stress_analysis")
    """

    def __init__(self, name: str = "Default") -> None:
        self.name = name
        self.dataspaces: dict[str, DataSpace] = {}
        self.metadata: dict[str, Any] = {}

    def create_dataspace(self, name: str) -> DataSpace:
        """Create a new user DataSpace.

        Raises:
            DuplicateNameError: If name already exists.
        """
        if name in self.dataspaces:
            raise DuplicateNameError(f"DataSpace '{name}' already exists")
        space = DataSpace(is_source=False)
        self.dataspaces[name] = space
        return space

    def get_dataspace(self, name: str) -> DataSpace | None:
        """Get a user DataSpace by name."""
        return self.dataspaces.get(name)

    def remove_dataspace(self, name: str) -> None:
        """Remove a user DataSpace."""
        self.dataspaces.pop(name, None)

    def clear(self) -> None:
        """Clear all user DataSpaces."""
        self.dataspaces.clear()

    def __repr__(self) -> str:
        return f"Workspace(name={self.name!r}, user_dataspaces={len(self.dataspaces)})"
