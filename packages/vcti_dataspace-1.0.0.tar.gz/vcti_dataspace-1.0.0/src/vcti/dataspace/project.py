# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Project classes for managing data analysis sessions."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from vcti.fileloader import Loader, LoaderRegistry

from .errors import DuplicateNameError
from .path_source import PathSource
from .workspace import Workspace

logger = logging.getLogger(__name__)


class Project(ABC):
    """Abstract base class for projects."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.metadata: dict[str, Any] = {}

    @abstractmethod
    def open_workspace(self, name: str = "Default") -> Workspace:
        """Open or create a workspace."""


class FilesProject(Project):
    """Project based on file/directory path sources.

    Manages PathSources (files), each with its own source DataSpace.
    Opens workspaces where users can create custom DataSpaces.

    Example:
        >>> with FilesProject("Analysis", registry=registry) as project:
        ...     project.add_path_source("sim", Path("data.h5"))
        ...     ws = project.open_workspace()
        ...     user_space = ws.create_dataspace("results")
    """

    def __init__(self, name: str, registry: LoaderRegistry | None = None) -> None:
        super().__init__(name)
        self.registry = registry
        self.path_sources: list[PathSource] = []
        self._workspaces: dict[str, Workspace] = {}

    def add_path_source(
        self,
        name: str,
        path: str | Path,
        format_id: str | None = None,
        loader: Loader | None = None,
        auto_load: bool = True,
        **load_options: Any,
    ) -> PathSource:
        """Add a path source. Auto-loads and creates source DataSpace.

        Raises:
            DuplicateNameError: If a source with this name already exists.
        """
        if self.get_path_source(name) is not None:
            raise DuplicateNameError(f"Path source '{name}' already exists")

        source = PathSource(
            name=name,
            path=path,
            format_id=format_id,
            loader=loader,
            registry=self.registry,
            **load_options,
        )
        if auto_load:
            source.load()
        self.path_sources.append(source)
        logger.info("Added path source '%s' from %s", name, path)
        return source

    def get_path_source(self, name: str) -> PathSource | None:
        """Get a path source by name."""
        for source in self.path_sources:
            if source.name == name:
                return source
        return None

    def list_path_sources(self) -> list[str]:
        """Return names of all registered path sources."""
        return [s.name for s in self.path_sources]

    def remove_path_source(self, name: str) -> None:
        """Remove and unload a path source."""
        source = self.get_path_source(name)
        if source:
            source.unload()
            self.path_sources.remove(source)
            logger.info("Removed path source '%s'", name)

    def open_workspace(self, name: str = "Default") -> Workspace:
        """Open or get a workspace by name.

        Creates the workspace if it doesn't exist yet. Returns
        the existing workspace if one with the given name is open.
        """
        if name not in self._workspaces:
            self._workspaces[name] = Workspace(name)
            logger.debug("Opened workspace '%s'", name)
        return self._workspaces[name]

    def close_workspace(self, name: str) -> None:
        """Close and remove a specific workspace."""
        ws = self._workspaces.pop(name, None)
        if ws:
            ws.clear()
            logger.debug("Closed workspace '%s'", name)

    def close(self) -> None:
        """Close project — unload all sources and clear workspaces."""
        for source in self.path_sources:
            source.unload()
        for ws in self._workspaces.values():
            ws.clear()
        self._workspaces.clear()
        logger.info("Closed project '%s'", self.name)

    def __enter__(self) -> FilesProject:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        n_loaded = sum(1 for s in self.path_sources if s.is_loaded)
        return (
            f"FilesProject(name={self.name!r}, sources={len(self.path_sources)}, "
            f"loaded={n_loaded}, workspaces={len(self._workspaces)})"
        )
