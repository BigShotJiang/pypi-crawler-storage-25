# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""DataSpace — hierarchical tree structure for datasets.

Two types:
- Source DataSpace: Built from file loaders, immutable, mirrors file structure
- User DataSpace: Created empty, mutable, supports custom groups/datasets
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from .errors import (
    DataSpaceError,
    ExportError,
    ImmutableDataSpaceError,
    InvalidDataError,
    NodeNameError,
    NodeNotDatasetError,
    NodeNotFoundError,
)

if TYPE_CHECKING:
    from vcti.arraytree import DataNode
    from vcti.fileloader import Loader

logger = logging.getLogger(__name__)

MAX_NODE_NAME_BYTES = 256


class LazyDatasetReference:
    """Deferred loading reference for datasets from source files."""

    def __init__(self, loader: Loader, handle: Any, source_node_id: int) -> None:
        self.loader = loader
        self.handle = handle
        self.source_node_id = source_node_id
        self._cached_dataset: DataNode | None = None

    def get_dataset(self) -> DataNode:
        """Load dataset (with caching)."""
        if self._cached_dataset is None:
            self._cached_dataset = self.loader.load_dataset(self.handle, self.source_node_id)
        return self._cached_dataset

    def clear_cache(self) -> None:
        """Clear cached dataset to free memory."""
        self._cached_dataset = None


TREE_DTYPE = np.dtype(
    [
        ("id", "u4"),
        ("parent_id", "u4"),
        ("first_child_id", "u4"),
        ("prev_sibling_id", "u4"),
        ("next_sibling_id", "u4"),
    ]
)

NODE_INFO_DTYPE = np.dtype(
    [
        ("id", "u4"),
        ("name", "S256"),
        ("type", "u1"),  # 0=group, 1=dataset
        ("size", "u8"),
    ]
)


def _validate_node_name(name: str) -> bytes:
    """Validate and encode a node name.

    Raises:
        NodeNameError: If name is empty or exceeds MAX_NODE_NAME_BYTES.
    """
    if not name:
        raise NodeNameError("Node name must not be empty")
    encoded = name.encode("utf-8")
    if len(encoded) > MAX_NODE_NAME_BYTES:
        raise NodeNameError(
            f"Node name exceeds {MAX_NODE_NAME_BYTES} bytes ({len(encoded)} bytes): {name!r}"
        )
    return encoded


class DataSpace:
    """Hierarchical tree structure for managing datasets.

    Source DataSpaces are immutable and built from file loaders.
    User DataSpaces are mutable and support custom groups/datasets.

    Example:
        >>> space = DataSpace()
        >>> grp = space.create_group("results")
        >>> space.create_dataset("stress", np.array([1.0, 2.0]), parent_id=grp)
    """

    def __init__(self, is_source: bool = False) -> None:
        self.is_source = is_source
        self.tree: np.ndarray = np.zeros(0, dtype=TREE_DTYPE)
        self.node_info: np.ndarray = np.zeros(0, dtype=NODE_INFO_DTYPE)
        # Attributes are stored in a separate dict (keyed by node_id) rather than
        # in the structured arrays because they are variable-size dicts of arbitrary
        # types — not suited for fixed-dtype NumPy arrays. Consistency with the tree
        # is maintained by delete_node, which cleans up attributes alongside the
        # tree and node_info arrays.
        self.attributes: dict[int, dict[str, Any]] = {}
        self.datasets: dict[int, Any] = {}  # DataNode or LazyDatasetReference
        self._next_id = 1
        self._index: dict[int, int] = {}  # node_id -> array index

    def _ensure_mutable(self) -> None:
        """Raise if this is a source (immutable) DataSpace."""
        if self.is_source:
            raise ImmutableDataSpaceError("Cannot modify source DataSpace")

    def _rebuild_index(self) -> None:
        """Rebuild the node_id -> array index mapping from the tree array."""
        self._index = {int(row["id"]): i for i, row in enumerate(self.tree)}

    def _get_index(self, node_id: int) -> int:
        """Get array index for a node ID.

        Raises:
            NodeNotFoundError: If node_id is not in the tree.
        """
        idx = self._index.get(node_id)
        if idx is None:
            raise NodeNotFoundError(f"Node {node_id} not found")
        return idx

    def verify_index(self) -> bool:
        """Verify that the _index dict is consistent with the tree array.

        Returns True if consistent, raises DataSpaceError with details if not.
        Intended for debugging and testing — not called in normal operation.

        Raises:
            DataSpaceError: If index is out of sync with the tree array.
        """
        expected = {int(row["id"]): i for i, row in enumerate(self.tree)}
        if self._index != expected:
            missing = set(expected) - set(self._index)
            extra = set(self._index) - set(expected)
            stale = {k for k in set(self._index) & set(expected) if self._index[k] != expected[k]}
            parts = []
            if missing:
                parts.append(f"missing from index: {missing}")
            if extra:
                parts.append(f"extra in index: {extra}")
            if stale:
                parts.append(f"stale indices: {stale}")
            raise DataSpaceError(f"Index integrity check failed: {'; '.join(parts)}")
        return True

    def build_from_loader(self, loader: Loader, handle: Any) -> None:
        """Build source DataSpace from a file loader.

        Args:
            loader: Loader instance.
            handle: File handle from loader.load().

        Raises:
            ImmutableDataSpaceError: If called on a non-source DataSpace.
        """
        if not self.is_source:
            raise ImmutableDataSpaceError(
                "build_from_loader() can only be called on source DataSpaces"
            )

        self.tree = loader.load_tree(handle)
        self.node_info = loader.load_node_info(handle)
        self.attributes = loader.load_attributes(handle)
        self._rebuild_index()

        for node in self.node_info:
            node_id = int(node["id"])
            node_type = int(node["type"])
            if node_type == 1:  # Dataset
                self.datasets[node_id] = LazyDatasetReference(
                    loader=loader, handle=handle, source_node_id=node_id
                )

        logger.debug("Built source DataSpace: %d nodes", len(self.tree))

    def get_node_info_all(self) -> np.ndarray:
        """Get node info for all nodes."""
        return self.node_info

    @property
    def node_count(self) -> int:
        """Total number of nodes in the tree."""
        return len(self.tree)

    @property
    def dataset_count(self) -> int:
        """Number of dataset entries."""
        return len(self.datasets)

    def get_node_info(self, node_id: int) -> np.ndarray | None:
        """Get node info for a specific node.

        Complexity: O(1) via _index fast-path, then O(n) mask on node_info.
        """
        if self._index.get(node_id) is None:
            return None
        mask = self.node_info["id"] == node_id
        if not np.any(mask):
            return None
        return self.node_info[mask][0]

    def get_dataset(self, node_id: int) -> DataNode:
        """Get dataset for a node (lazy-loads for source DataSpaces).

        Raises:
            NodeNotDatasetError: If node is not a dataset.
        """
        if node_id not in self.datasets:
            raise NodeNotDatasetError(f"Node {node_id} is not a dataset")

        entry = self.datasets[node_id]
        if isinstance(entry, LazyDatasetReference):
            return entry.get_dataset()
        return entry

    def create_group(
        self, name: str, parent_id: int = 0, attributes: dict[str, Any] | None = None
    ) -> int:
        """Create a group node (user DataSpace only).

        Returns:
            New node ID.

        Raises:
            ImmutableDataSpaceError: If called on a source DataSpace.
            NodeNameError: If name is empty or too long.
            NodeNotFoundError: If parent_id does not exist.
        """
        self._ensure_mutable()
        encoded_name = _validate_node_name(name)

        node_id = self._next_id
        self._next_id += 1

        self._add_node_to_tree(node_id, parent_id)

        new_info = np.array([(node_id, encoded_name, 0, 0)], dtype=NODE_INFO_DTYPE)
        self.node_info = np.concatenate([self.node_info, new_info])

        if attributes:
            self.attributes[node_id] = attributes.copy()

        logger.debug("Created group '%s' (id=%d, parent=%d)", name, node_id, parent_id)
        return node_id

    def create_dataset(
        self,
        name: str,
        data: np.ndarray,
        parent_id: int = 0,
        attributes: dict[str, Any] | None = None,
    ) -> int:
        """Create a dataset node (user DataSpace only).

        Returns:
            New node ID.

        Raises:
            ImmutableDataSpaceError: If called on a source DataSpace.
            NodeNameError: If name is empty or too long.
            NodeNotFoundError: If parent_id does not exist.
            InvalidDataError: If data is not a numpy array.
        """
        self._ensure_mutable()
        encoded_name = _validate_node_name(name)

        if not isinstance(data, np.ndarray):
            raise InvalidDataError(f"data must be a numpy array, got {type(data).__name__}")

        from vcti.arraytree import DataNode

        node_id = self._next_id
        self._next_id += 1

        self._add_node_to_tree(node_id, parent_id)

        size = data.nbytes
        new_info = np.array([(node_id, encoded_name, 1, size)], dtype=NODE_INFO_DTYPE)
        self.node_info = np.concatenate([self.node_info, new_info])

        self.datasets[node_id] = DataNode(data=data, attributes=attributes or {})

        if attributes:
            self.attributes[node_id] = attributes.copy()

        logger.debug(
            "Created dataset '%s' (id=%d, parent=%d, %d bytes)",
            name,
            node_id,
            parent_id,
            size,
        )
        return node_id

    def delete_node(self, node_id: int, recursive: bool = True) -> None:
        """Delete a node from a user DataSpace.

        Uses iterative post-order traversal to avoid Python's recursion limit
        (~1,000 frames) on deeply nested trees.

        Complexity: O(n) where n = number of nodes in the subtree.

        Args:
            node_id: The node to delete.
            recursive: If True, delete all children first. If False, raise
                if the node has children.

        Raises:
            ImmutableDataSpaceError: If called on a source DataSpace.
            NodeNotFoundError: If node_id does not exist.
            DataSpaceError: If recursive is False and node has children.
        """
        self._ensure_mutable()
        self._get_index(node_id)  # validate existence

        children = self._get_children(node_id)
        if children and not recursive:
            raise DataSpaceError(
                f"Node {node_id} has {len(children)} children. Use recursive=True to delete them."
            )

        # Collect all nodes in post-order (children before parents) using
        # an iterative traversal so we don't hit Python's recursion limit.
        to_delete: list[int] = []
        stack = [node_id]
        while stack:
            nid = stack.pop()
            to_delete.append(nid)
            stack.extend(self._get_children(nid))
        to_delete.reverse()  # post-order: leaves first, root last

        for nid in to_delete:
            self._remove_single_node(nid)

        logger.debug(
            "Deleted node %d (recursive=%s, total=%d)", node_id, recursive, len(to_delete)
        )

    def _remove_single_node(self, node_id: int) -> None:
        """Remove a single leaf node from the tree (no children expected)."""
        idx = self._get_index(node_id)

        # Unlink from sibling list
        parent_id = int(self.tree[idx]["parent_id"])
        prev_id = int(self.tree[idx]["prev_sibling_id"])
        next_id = int(self.tree[idx]["next_sibling_id"])

        if prev_id != 0:
            prev_idx = self._get_index(prev_id)
            self.tree[prev_idx]["next_sibling_id"] = next_id
        elif parent_id != 0:
            parent_idx = self._get_index(parent_id)
            self.tree[parent_idx]["first_child_id"] = next_id

        if next_id != 0:
            next_idx = self._get_index(next_id)
            self.tree[next_idx]["prev_sibling_id"] = prev_id

        # Remove from arrays
        self.tree = self.tree[self.tree["id"] != node_id]
        self.node_info = self.node_info[self.node_info["id"] != node_id]

        # Clean up datasets and attributes
        self.datasets.pop(node_id, None)
        self.attributes.pop(node_id, None)

        self._rebuild_index()

    def copy_node_from(
        self,
        source_space: DataSpace,
        node_id: int,
        new_parent_id: int = 0,
        recursive: bool = True,
    ) -> int:
        """Copy a node from another DataSpace (user DataSpace only).

        Uses iterative BFS to avoid Python's recursion limit (~1,000 frames)
        on deeply nested source trees.

        Complexity: O(n) where n = number of nodes in the source subtree.

        Returns:
            New node ID of the root of the copied subtree.

        Raises:
            ImmutableDataSpaceError: If called on a source DataSpace.
            NodeNotFoundError: If source node not found.
        """
        self._ensure_mutable()

        src_info = source_space.get_node_info(node_id)
        if src_info is None:
            raise NodeNotFoundError(f"Node {node_id} not found in source space")

        root_new_id = self._copy_single_node(source_space, node_id, new_parent_id)

        if recursive:
            # BFS: queue holds (source_node_id, new_parent_id) pairs
            queue: list[tuple[int, int]] = []
            for child_id in source_space._get_children(node_id):
                queue.append((child_id, root_new_id))

            while queue:
                src_id, dst_parent = queue.pop(0)
                new_id = self._copy_single_node(source_space, src_id, dst_parent)
                for child_id in source_space._get_children(src_id):
                    queue.append((child_id, new_id))

        return root_new_id

    def _copy_single_node(self, source_space: DataSpace, node_id: int, parent_id: int) -> int:
        """Copy a single node (no children) from source_space into this space."""
        src_info = source_space.get_node_info(node_id)
        if src_info is None:
            raise NodeNotFoundError(f"Node {node_id} not found in source space")

        name = src_info["name"].decode("utf-8")
        node_type = int(src_info["type"])
        src_attrs = source_space.attributes.get(node_id, {})

        if node_type == 0:  # Group
            return self.create_group(name, parent_id=parent_id, attributes=src_attrs)
        else:  # Dataset
            src_dataset = source_space.get_dataset(node_id)
            return self.create_dataset(
                name, src_dataset.data, parent_id=parent_id, attributes=src_attrs
            )

    def export_hdf5(self, output_path: str | Path) -> None:
        """Export DataSpace to HDF5 file.

        The file is opened in write mode ("w"), which creates a new file or
        truncates an existing one. Any previous contents at output_path will
        be overwritten.

        Requires h5py (install via vcti-dataspace[hdf5-export]).

        Raises:
            ExportError: If export fails.
            ImportError: If h5py is not installed.
        """
        try:
            import h5py
        except ImportError as exc:
            raise ImportError(
                "h5py is required for HDF5 export. Install via: pip install h5py"
            ) from exc

        output_path = Path(output_path)
        logger.info("Exporting DataSpace to %s", output_path)

        try:
            with h5py.File(output_path, "w") as f:
                if len(self.tree) > 0:
                    self._export_nodes_to_hdf5(f)
        except ImportError:
            raise
        except Exception as exc:
            raise ExportError(f"HDF5 export failed: {exc}") from exc

        logger.info("Export complete: %s", output_path)

    def clear_dataset_cache(self) -> None:
        """Clear cached datasets in lazy references (source DataSpace only)."""
        if not self.is_source:
            return
        for entry in self.datasets.values():
            if isinstance(entry, LazyDatasetReference):
                entry.clear_cache()
        logger.debug("Cleared dataset cache")

    def _add_node_to_tree(self, node_id: int, parent_id: int) -> None:
        prev_sibling_id = 0

        if parent_id != 0:
            parent_idx = self._get_index(parent_id)
            first_child_id = int(self.tree[parent_idx]["first_child_id"])

            if first_child_id == 0:
                self.tree[parent_idx]["first_child_id"] = node_id
            else:
                current_id = first_child_id
                while True:
                    current_idx = self._get_index(current_id)
                    next_id = int(self.tree[current_idx]["next_sibling_id"])
                    if next_id == 0:
                        self.tree[current_idx]["next_sibling_id"] = node_id
                        prev_sibling_id = current_id
                        break
                    current_id = next_id

        new_entry = np.array([(node_id, parent_id, 0, prev_sibling_id, 0)], dtype=TREE_DTYPE)
        self.tree = np.concatenate([self.tree, new_entry])
        self._index[node_id] = len(self.tree) - 1

    def _get_children(self, node_id: int) -> list[int]:
        children = []
        idx = self._index.get(node_id)
        if idx is None:
            return children

        first_child_id = int(self.tree[idx]["first_child_id"])
        if first_child_id == 0:
            return children

        current_id = first_child_id
        while current_id != 0:
            children.append(current_id)
            current_idx = self._index.get(current_id)
            if current_idx is None:
                break
            current_id = int(self.tree[current_idx]["next_sibling_id"])

        return children

    def _export_nodes_to_hdf5(self, h5_root: Any) -> None:
        """Export all nodes to an HDF5 file/group using iterative BFS."""
        root_ids = self.tree[self.tree["parent_id"] == 0]["id"]

        # BFS queue: (node_id, h5_parent_group)
        queue: list[tuple[int, Any]] = [(int(rid), h5_root) for rid in root_ids]

        while queue:
            node_id, h5_parent = queue.pop(0)
            node_info = self.get_node_info(node_id)
            if node_info is None:
                continue

            name = node_info["name"].decode("utf-8")
            node_type = int(node_info["type"])
            node_attrs = self.attributes.get(node_id, {})

            if node_type == 0:  # Group
                grp = h5_parent.create_group(name)
                for key, value in node_attrs.items():
                    grp.attrs[key] = value
                for child_id in self._get_children(node_id):
                    queue.append((child_id, grp))
            else:  # Dataset
                dataset = self.get_dataset(node_id)
                if dataset.data is not None:
                    ds = h5_parent.create_dataset(name, data=dataset.data)
                    for key, value in node_attrs.items():
                        ds.attrs[key] = value

    def __repr__(self) -> str:
        space_type = "source" if self.is_source else "user"
        return (
            f"DataSpace(type={space_type}, nodes={len(self.tree)}, datasets={len(self.datasets)})"
        )
