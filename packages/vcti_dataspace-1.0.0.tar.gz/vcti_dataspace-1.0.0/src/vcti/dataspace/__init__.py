# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.dataspace — Data space for organizing and working with hierarchical data."""

from importlib.metadata import version

from .dataspace import DataSpace, LazyDatasetReference
from .errors import (
    DataSpaceError,
    DuplicateNameError,
    ExportError,
    FormatDetectionError,
    ImmutableDataSpaceError,
    InvalidDataError,
    LoaderError,
    NodeNameError,
    NodeNotDatasetError,
    NodeNotFoundError,
)
from .path_source import PathSource
from .project import FilesProject, Project
from .workspace import Workspace

__version__ = version("vcti-dataspace")

__all__ = [
    "DataSpace",
    "DataSpaceError",
    "DuplicateNameError",
    "ExportError",
    "FilesProject",
    "FormatDetectionError",
    "ImmutableDataSpaceError",
    "InvalidDataError",
    "LazyDatasetReference",
    "LoaderError",
    "NodeNameError",
    "NodeNotDatasetError",
    "NodeNotFoundError",
    "PathSource",
    "Project",
    "Workspace",
    "__version__",
]
