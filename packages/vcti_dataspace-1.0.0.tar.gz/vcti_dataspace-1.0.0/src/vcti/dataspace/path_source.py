# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""PathSource — represents a file/directory data source."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from vcti.fileloader import Loader, LoaderRegistry

from .dataspace import DataSpace
from .errors import FormatDetectionError, LoaderError

logger = logging.getLogger(__name__)


class PathSource:
    """Represents a path-based data source (file or directory).

    Encapsulates path, format, loader, handle, and source DataSpace.

    Example:
        >>> source = PathSource(name="sim", path=Path("data.h5"), registry=registry)
        >>> source.load()
        >>> tree = source.dataspace.tree
    """

    def __init__(
        self,
        name: str,
        path: str | Path,
        format_id: str | None = None,
        loader: Loader | None = None,
        registry: LoaderRegistry | None = None,
        metadata: dict[str, Any] | None = None,
        **load_options: Any,
    ) -> None:
        self.name = name
        self.path = Path(path) if isinstance(path, str) else path
        self.format_id = format_id
        self.loader = loader
        self.registry = registry
        self.metadata = metadata or {}
        self.handle: Any = None
        self.dataspace: DataSpace | None = None
        self.is_loaded = False
        self._load_options = load_options

        if self.format_id is None and self.registry is not None:
            self._detect_format()

        if self.loader is None and self.format_id is not None and self.registry is not None:
            self._get_loader()

    def _detect_format(self) -> None:
        suffix = self.path.suffix.lower()
        format_map = {
            ".h5": "hdf5-h5py-loader",
            ".hdf5": "hdf5-h5py-loader",
            ".he5": "hdf5-h5py-loader",
            ".cax": "cax-caxlib-loader",
        }
        self.format_id = format_map.get(suffix)
        if self.format_id is None:
            raise FormatDetectionError(
                f"Could not detect format for {self.path}. Specify format_id explicitly."
            )

    def _get_loader(self) -> None:
        if self.registry is None:
            raise LoaderError("Registry required to get loader")
        descriptor = self.registry.get(self.format_id)
        self.loader = descriptor.loader

    def load(self) -> None:
        """Load the source — creates handle and source DataSpace.

        Raises:
            LoaderError: If no loader is configured.
        """
        if self.is_loaded:
            return
        if self.loader is None:
            raise LoaderError(f"No loader configured for {self.name}")

        self.handle = self.loader.load(self.path, **self._load_options)
        self.dataspace = DataSpace(is_source=True)
        self.dataspace.build_from_loader(self.loader, self.handle)
        self.is_loaded = True
        logger.info("Loaded source '%s' from %s", self.name, self.path)

    def unload(self) -> None:
        """Unload to free resources."""
        if self.is_loaded and self.loader is not None:
            self.loader.unload(self.handle)
            self.handle = None
            self.dataspace = None
            self.is_loaded = False
            logger.info("Unloaded source '%s'", self.name)

    def reload(self) -> None:
        """Reload the source."""
        self.unload()
        self.load()

    def __repr__(self) -> str:
        status = "loaded" if self.is_loaded else "unloaded"
        return (
            f"PathSource(name={self.name!r}, path={self.path}, format={self.format_id}, {status})"
        )
