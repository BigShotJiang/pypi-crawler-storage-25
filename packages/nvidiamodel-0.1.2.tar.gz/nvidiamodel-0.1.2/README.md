# nvidiamodel

A Python library for interacting with NVIDIA API through OpenAI-compatible interface.

## Installation

```bash
pip install nvidiamodel
```

## Usage

```python
from nvidiamodel import answer

# Use the API
response = answer(
    API="your-api-key",
    MODEL="nvidia/llama-3.1-8b-instruct",
    PROMPT="Your prompt here"
)
```