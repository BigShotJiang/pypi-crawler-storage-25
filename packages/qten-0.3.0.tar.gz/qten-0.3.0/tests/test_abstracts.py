import pytest
from dataclasses import dataclass
from qten.abstracts import (
    Convertible,
    Functional,
    Operable,
    Span,
    Updatable,
)


@dataclass(frozen=True)
class MockOperable(Operable):
    pass


@dataclass(frozen=True)
class MockUpdatable(Updatable["MockUpdatable"]):
    val: int = 0

    def _updated(self, **kwargs) -> "Updatable":
        new_val = kwargs.get("val", self.val)
        return MockUpdatable(val=new_val)


@dataclass(frozen=True)
class BadUpdatable(Updatable["BadUpdatable"]):
    def _updated(self, **kwargs):
        return self


class _BaseInput:
    pass


class _DerivedInput(_BaseInput):
    pass


@dataclass(frozen=True)
class _MockFunctional(Functional):
    pass


@dataclass(frozen=True)
class _DerivedFunctional(_MockFunctional):
    pass


@dataclass(frozen=True)
class MockSpan(Span[int]):
    values: tuple[int, ...]

    def elements(self) -> tuple[int, ...]:
        return self.values


@dataclass(frozen=True)
class MockConvertibleToSpan(Convertible):
    values: tuple[int, ...]


@MockConvertibleToSpan.add_conversion(MockSpan)
def _mock_convertible_to_span(v: MockConvertibleToSpan) -> MockSpan:
    return MockSpan(v.values)


@_MockFunctional.register(_BaseInput)
def _apply_mock_functional_base(functional: _MockFunctional, obj: _BaseInput) -> str:
    return "base"


def test_operable_unimplemented():
    a = MockOperable()
    b = MockOperable()

    # Test all default implementations raise NotImplementedError

    with pytest.raises(NotImplementedError):
        _ = b in a

    # Arithmetics
    with pytest.raises(NotImplementedError):
        _ = a + b

    with pytest.raises(NotImplementedError):
        _ = -a

    # a - b calls a + (-b). Since -b raises error, this should raise error too.
    with pytest.raises(NotImplementedError):
        _ = a - b

    with pytest.raises(NotImplementedError):
        _ = a * b

    with pytest.raises(NotImplementedError):
        _ = a @ b

    with pytest.raises(NotImplementedError):
        _ = a / b

    with pytest.raises(NotImplementedError):
        _ = a // b

    with pytest.raises(NotImplementedError):
        _ = a**b

    # Comparisons
    # Note: MockOperable is a dataclass, so it implements __eq__ automatically.
    # a == b will return True, not raise NotImplementedError.
    # So we skip testing '==' here or test Operable.__eq__ directly.
    with pytest.raises(NotImplementedError):
        Operable.__eq__(a, b)

    with pytest.raises(NotImplementedError):
        _ = a < b

    with pytest.raises(NotImplementedError):
        _ = a <= b

    with pytest.raises(NotImplementedError):
        _ = a > b

    with pytest.raises(NotImplementedError):
        _ = a >= b

    # Logical
    with pytest.raises(NotImplementedError):
        _ = a & b

    with pytest.raises(NotImplementedError):
        _ = a | b


def test_span_contains_uses_dunder_contains():
    sup = MockSpan((1, 2, 3))
    sub = MockSpan((1, 3))

    assert sub in sup


def test_span_contains_converts_convertible_queries():
    sup = MockSpan((1, 2, 3))

    assert MockConvertibleToSpan((2, 3)) in sup


def test_span_contains_rejects_non_convertible_queries():
    sup = MockSpan((1, 2, 3))

    with pytest.raises(ValueError, match="Cannot convert str to MockSpan"):
        _ = "x" in sup


def test_updatable_correct():
    u = MockUpdatable(val=1)
    u2 = u.update(val=2)
    assert u2.val == 2
    assert u2 is not u


def test_updatable_bad_implementation():
    b = BadUpdatable()
    with pytest.raises(RuntimeError, match="must not return self"):
        b.update(foo="bar")


def test_functional_targeted_cache_invalidation():
    functional = _MockFunctional()
    obj = _DerivedInput()

    assert functional(obj) == "base"
    assert (
        _MockFunctional._resolved_methods[(type(obj), type(functional))](
            functional, obj
        )
        == "base"
    )

    @_MockFunctional.register(_DerivedInput)
    def _apply_mock_functional_derived(
        functional: _MockFunctional, obj: _DerivedInput
    ) -> str:
        return "derived"

    assert functional(obj) == "derived"


def test_functional_inherits_superclass_registration():
    functional = _DerivedFunctional()
    obj = _BaseInput()

    assert functional(obj) == "base"
    assert (
        Functional._resolved_methods[(type(obj), type(functional))](functional, obj)
        == "base"
    )


def test_functional_inherited_cache_invalidation():
    functional = _DerivedFunctional()
    obj = _DerivedInput()

    assert functional(obj) == "derived"

    @_MockFunctional.register(_DerivedInput)
    def _apply_mock_functional_derived_v2(
        functional: _MockFunctional, obj: _DerivedInput
    ) -> str:
        return "derived-v2"

    assert functional(obj) == "derived-v2"
