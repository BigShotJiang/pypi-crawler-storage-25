import math
import numpy as np
from .helicity import (
    _boost_to_rest_frame,
)  # uses p4_to_boost, rest_frame_p4 -> spatial (3,)


def _unit(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    if n < 1e-14:
        return np.array([0.0, 0.0, 1.0], dtype=float)
    return v / n


from datetime import datetime

from physics.spin import SpinState
from .particles import Particle
from .decay_selector import choose_decay_mode, get_decay_modes, get_decay_products
from .phase_space import generate_three_body_decay
from db import get_conn
from .breit_wigner import sample_relativistic_bw  # NEW
from .detector import apply_detector


def _conn():
    return get_conn()


# ========== CACHES (computed once, reused forever) ==========
_PARTICLE_CACHE = {}
_PDG_CACHE = {}


def get_particle(name: str) -> dict:
    """Cache particle properties (mass, width, name) to avoid repeated Particle() construction."""
    if name not in _PARTICLE_CACHE:
        p = Particle(name)
        # Fetch width (MeV) from DB; default 0.0 if NULL
        with _conn() as conn, conn.cursor() as cur:
            cur.execute(
                'SELECT "Width Γ (MeV)" FROM particles '
                'WHERE LOWER("Name")=LOWER(%s) OR LOWER("Symbol")=LOWER(%s) '
                "LIMIT 1",
                (name, name),
            )
            row = cur.fetchone()
        width_mev = float(row[0]) if (row and row[0] is not None) else 0.0
        _PARTICLE_CACHE[name] = {
            "mass": p.mass,  # MeV
            "width": width_mev,  # MeV
            "name": p.name,
        }
    return _PARTICLE_CACHE[name]


def get_pdg_id_cached(particle_name: str) -> int | None:
    """Cache PDG ID lookups."""
    if particle_name not in _PDG_CACHE:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute(
                """SELECT "PDG ID" FROM particles
                   WHERE LOWER("Name") = LOWER(%s) OR LOWER("Symbol") = LOWER(%s)
                   LIMIT 1""",
                (particle_name, particle_name),
            )
            row = cur.fetchone()
        _PDG_CACHE[particle_name] = int(row[0]) if row else None
    return _PDG_CACHE[particle_name]


def p4(E: float, px: float, py: float, pz: float) -> tuple:
    """4-vector as tuple (E, px, py, pz) - no NumPy overhead."""
    return (E, px, py, pz)


def _reorder_daughters_for_matrix_element(
    daughter_names: list[str], p4s: list[tuple], parent_pdg: int
) -> list[tuple]:
    """
    Reorder daughter momenta to match matrix element expectations.

    For weak V-A decays: [charged_lepton, antineutrino, neutrino]

    Args:
        daughter_names: Particle names in generation order
        p4s: 4-momenta in same order as daughter_names
        parent_pdg: Parent PDG ID (for context)

    Returns:
        Reordered list of 4-momenta matching matrix element conventions
    """
    # Get PDG IDs for all daughters
    daughter_pdgs = [get_pdg_id_cached(name) for name in daughter_names]

    # Build (pdg, p4, name) tuples
    daughters = list(zip(daughter_pdgs, p4s, daughter_names))

    # For 3-body leptonic decays, enforce V-A ordering
    if len(daughters) == 3:
        charged_minus_p4 = None
        charged_plus_p4 = None
        antineutrino_p4 = None
        neutrino_p4 = None

        for pdg, p4, name in daughters:
            # Charged leptons: e-, mu-, tau- (PDG: 11, 13, 15)
            if pdg in [11, 13, 15]:
                charged_minus_p4 = p4
            # Charged antileptons: e+, mu+, tau+ (PDG: -11, -13, -15)
            elif pdg in [-11, -13, -15]:
                charged_plus_p4 = p4
            # Antineutrinos: nu_e_bar, nu_mu_bar, nu_tau_bar (PDG: -12, -14, -16)
            elif pdg in [-12, -14, -16]:
                antineutrino_p4 = p4
            # Neutrinos: nu_e, nu_mu, nu_tau (PDG: 12, 14, 16)
            elif pdg in [12, 14, 16]:
                neutrino_p4 = p4

        # Parent particle (e.g. mu-, tau-) convention: [l-, nubar, nu]
        if (
            parent_pdg > 0
            and charged_minus_p4 is not None
            and antineutrino_p4 is not None
            and neutrino_p4 is not None
        ):
            return [charged_minus_p4, antineutrino_p4, neutrino_p4]

        # Parent antiparticle (e.g. mu+, tau+) convention: [l+, nu, nubar]
        if (
            parent_pdg < 0
            and charged_plus_p4 is not None
            and neutrino_p4 is not None
            and antineutrino_p4 is not None
        ):
            return [charged_plus_p4, neutrino_p4, antineutrino_p4]

        # Fallback for legacy or incomplete PDG metadata
        charged_lepton_p4 = (
            charged_minus_p4 if charged_minus_p4 is not None else charged_plus_p4
        )
        if (
            charged_lepton_p4 is not None
            and antineutrino_p4 is not None
            and neutrino_p4 is not None
        ):
            return [charged_lepton_p4, antineutrino_p4, neutrino_p4]

    # Fallback: return original order
    # WARNING: Only FlatMatrixElement tolerates ambiguous ordering.
    # If you add a physics-sensitive ME that doesn't enforce ordering, it will silently fail.

    # neutron beta decay: n(2112) -> p(2212) + e-(11) + nu_e_bar(-12)
    if parent_pdg == 2112 and len(daughter_names) == 3:
        i_lep = next(
            (i for i, pdg in enumerate(daughter_pdgs) if pdg in {11, 13, 15}), None
        )
        i_anu = next(
            (i for i, pdg in enumerate(daughter_pdgs) if pdg in {-12, -14, -16}), None
        )
        i_p = next((i for i, pdg in enumerate(daughter_pdgs) if pdg in {2212}), None)

        if None not in (i_lep, i_anu, i_p):
            return [p4s[i_lep], p4s[i_anu], p4s[i_p]]

    return p4s


def validate_event_inline(
    parent_E: float, final_states: list, tol: float = 1e-6
) -> bool:
    """Inlined conservation check (faster, no tuple unpacking)."""
    E_f = sum(p[0] for p in final_states)
    px_f = sum(p[1] for p in final_states)
    py_f = sum(p[2] for p in final_states)
    pz_f = sum(p[3] for p in final_states)

    # Parent is at rest: px=py=pz=0
    return (
        abs(parent_E - E_f) < tol
        and abs(px_f) < tol
        and abs(py_f) < tol
        and abs(pz_f) < tol
    )


def init_event_db():
    """Initialize tables for event storage (Postgres)."""
    with _conn() as conn, conn.cursor() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS events(
                id SERIAL PRIMARY KEY,
                parent TEXT,
                decay_mode TEXT,
                energy DOUBLE PRECISION,
                timestamp TEXT,
                event_weight DOUBLE PRECISION,
                phase_space_weight DOUBLE PRECISION
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS final_states(
                id SERIAL PRIMARY KEY,
                event_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
                particle TEXT,
                px DOUBLE PRECISION,
                py DOUBLE PRECISION,
                pz DOUBLE PRECISION,
                E DOUBLE PRECISION
            )
        """)
        conn.commit()


def get_pdg_id(particle_name: str) -> int | None:
    """Resolve PDG ID from particle name."""
    with _conn() as conn, conn.cursor() as cur:
        cur.execute(
            """
            SELECT "PDG ID" FROM particles
            WHERE LOWER("Name") = LOWER(%s) OR LOWER("Symbol") = LOWER(%s)
            LIMIT 1
        """,
            (particle_name, particle_name),
        )
        row = cur.fetchone()
    return int(row[0]) if row else None


def _is_kinematically_allowed(parent_mass: float, daughter_names: list[str]) -> bool:
    """Check m_parent >= sum m_daughters (using cached masses)."""
    try:
        masses = [get_particle(name)["mass"] for name in daughter_names]
    except Exception:
        return False
    return parent_mass + 1e-9 >= sum(masses)


def random_unit_vector(rng: np.random.Generator) -> np.ndarray:
    """Generate a random unit vector uniformly on the sphere."""
    cos_theta = rng.uniform(-1, 1)
    phi = rng.uniform(0, 2 * np.pi)
    sin_theta = np.sqrt(1 - cos_theta**2)
    return np.array([sin_theta * np.cos(phi), sin_theta * np.sin(phi), cos_theta])


def _generate_decay_fourvectors(
    parent_mass: float,
    daughter_names: list[str],
    rng: np.random.Generator,
    apply_weights: bool = True,
    parent_pdg: int = 0,
    afb: float = 0.0,
):
    """
    Generate decay in rest frame. Returns (list of p4 tuples, total weight).

    Clean architecture:
        1. Phase space generation (kinematic sampling)
        2. Matrix element lookup (physics weighting)
        3. Total weight = ps_weight * |M|²

    No physics hacks. No special cases. Pure pipeline.
    """
    from .matrix_elements import get_matrix_element

    masses = [get_particle(name)["mass"] for name in daughter_names]
    N = len(masses)

    # Get PDG IDs for matrix element lookup
    # NOTE: Sorting PDGs prevents combinatorial key explosion.
    # Daughter ordering is preserved separately via _reorder_daughters_for_matrix_element().
    # Future: If CP-violating or ordering-sensitive decays needed, may need frozenset(daughter_pdgs) instead.
    daughter_pdgs = tuple(
        sorted([get_pdg_id_cached(name) or 0 for name in daughter_names])
    )
    decay_key = (parent_pdg, daughter_pdgs)

    # General 2-body decay
    if N == 2:
        m1, m2 = masses
        if parent_mass <= 0 or parent_mass + 1e-9 < (m1 + m2):
            raise ValueError("Kinematically forbidden 2-body decay")

        term1 = parent_mass**2 - (m1 + m2) ** 2
        term2 = parent_mass**2 - (m1 - m2) ** 2
        p_star = (
            math.sqrt(max(term1 * term2, 0.0)) / (2 * parent_mass)
            if parent_mass > 0
            else 0.0
        )

        E1 = math.sqrt(m1**2 + p_star**2)
        E2 = math.sqrt(m2**2 + p_star**2)

        # NEW: Random isotropic direction
        direction = random_unit_vector(rng)
        p_vec = p_star * direction

        d1 = p4(E1, p_vec[0], p_vec[1], p_vec[2])
        d2 = p4(E2, -p_vec[0], -p_vec[1], -p_vec[2])
        return [d1, d2], 1.0

    # General 3-body decay
    elif N == 3:
        p4s_rest, ps_weight = generate_three_body_decay(parent_mass, masses, rng)

        if apply_weights:
            parent_p4 = (parent_mass, 0.0, 0.0, 0.0)
            me = get_matrix_element(decay_key)

            # CRITICAL: Reorder daughters to match matrix element expectations
            # V-A expects: [charged_lepton, antineutrino, neutrino]
            ordered_p4s = _reorder_daughters_for_matrix_element(
                daughter_names, p4s_rest, parent_pdg
            )

            M2 = me.M2(parent_p4, ordered_p4s, context={"afb": afb})
            total_weight = ps_weight * M2
        else:
            total_weight = ps_weight

        return p4s_rest, total_weight

    else:
        raise NotImplementedError("Only 2- and 3-body decays supported")


def _simulate_event_inmemory(
    parent_name: str,
    parent_mass: float,
    parent_pdg: int,
    fixed_decay_mode: str | None,
    event_weight: float,
    rng: np.random.Generator,
    M2_max: dict,
    event_index: int = 0,
    use_accept_reject: bool = False,  # NEW
    warmup_events: int = 500,
    run_timestamp: str = "",
    ar_inflate: float = 1.2,
    afb: float = 0.0,
):  # NEW PARAMETER
    """
    Generate one event. Supports warm-up (M² max learning) and accept–reject.
    Returns:
      - ("WARMUP", None) during warm-up
      - ("REJECTED", None) when A/R rejects
      - ("ACCEPTED", (event_row, final_state_rows)) on success
      - ("FAILED", None) on failure
    """
    decay_mode = fixed_decay_mode or choose_decay_mode(parent_pdg, rng)
    if decay_mode == "stable":
        return ("FAILED", None)

    # Resolve daughters
    try:
        daughters = get_decay_products(parent_pdg, decay_mode)
    except Exception:
        return ("FAILED", None)

    if not _is_kinematically_allowed(parent_mass, daughters):
        return ("FAILED", None)

    # Phase space only (no ME yet)
    try:
        apply_weights_flag = False
        p4s_rest, ps_weight = _generate_decay_fourvectors(
            parent_mass,
            daughters,
            rng,
            apply_weights=apply_weights_flag,
            parent_pdg=parent_pdg,
            afb=afb,
        )
        assert (
            not apply_weights_flag
        ), "Phase-space weight must be applied exactly once (generator multiplies ps_weight * M2)."
    except Exception:
        return ("FAILED", None)

    # Compute |M|^2
    from .matrix_elements import get_matrix_element

    parent_p4 = (parent_mass, 0.0, 0.0, 0.0)
    daughter_pdgs = tuple(sorted([get_pdg_id_cached(n) or 0 for n in daughters]))
    decay_key = (parent_pdg, daughter_pdgs)

    ordered_p4s = _reorder_daughters_for_matrix_element(daughters, p4s_rest, parent_pdg)
    me = get_matrix_element(decay_key)
    M2 = float(me.M2(parent_p4, ordered_p4s, context={"afb": afb}))

    # ---------- Warm-up: learn M²_max, skip storage ----------
    # NOTE: Assumes stationary M² distribution (rest-frame parent).
    # Frame-dependent: if parent is boosted (collider frame, ISR/FSR), M² envelope changes.
    # Current scope: rest-frame decays only. Future: redesign for scattering processes.
    if use_accept_reject and event_index < warmup_events:
        M2_max[decay_key] = max(M2_max.get(decay_key, 0.0), M2)
        return ("WARMUP", None)

    # ---------- Accept–reject (unweighted) ----------
    if use_accept_reject:
        wmax = M2_max.get(decay_key, 0.0)
        if wmax <= 0.0:
            raise RuntimeError(
                f"Accept–reject enabled but no M²_max learned for decay {decay_key}. "
                f"Warm-up may be too short or decay mode not sampled. Fail loudly to prevent silent bias."
            )
        wmax *= ar_inflate  # safety margin
        accept_prob = min(1.0, M2 / wmax)
        if rng.random() > accept_prob:
            return ("REJECTED", None)

        stored_weight = 1.0
        phase_space_weight = 1.0
    else:
        # Weighted path (ps_weight applied exactly once)
        stored_weight = event_weight * (ps_weight * M2)
        phase_space_weight = ps_weight

    event_row = (
        parent_name,
        decay_mode,
        parent_mass,
        run_timestamp,
        stored_weight,
        phase_space_weight,
    )
    final_state_rows = [
        (name, float(fv[1]), float(fv[2]), float(fv[3]), float(fv[0]))
        for name, fv in zip(daughters, p4s_rest)
    ]

    detector_input = [
        {"name": name, "p4": (float(fv[0]), float(fv[1]), float(fv[2]), float(fv[3]))}
        for name, fv in zip(daughters, p4s_rest)
    ]
    detector = apply_detector(detector_input)

    return ("ACCEPTED", (event_row, final_state_rows, detector))


def _flush_batch(event_rows, final_state_groups, batch_size: int = 5000):
    """
    Bulk insert events and their final states in safe batches.
    batch_size: Max events per transaction (Postgres handles 5k-20k easily)
    final_state_groups: list of lists, one per event.
    """
    if not event_rows:
        return

    total_events = len(event_rows)

    try:
        for batch_start in range(0, total_events, batch_size):
            batch_end = min(batch_start + batch_size, total_events)
            batch_events = event_rows[batch_start:batch_end]
            batch_final_states = final_state_groups[batch_start:batch_end]

            with _conn() as conn, conn.cursor() as cur:
                cur.execute("""
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_name = 'events'
                    """)
                event_columns = {row[0] for row in cur.fetchall()}
                has_legacy_weight = "weight" in event_columns

                if has_legacy_weight:
                    insert_sql = (
                        "INSERT INTO events(parent, decay_mode, energy, timestamp, event_weight, phase_space_weight, weight) "
                        "VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id"
                    )
                else:
                    insert_sql = (
                        "INSERT INTO events(parent, decay_mode, energy, timestamp, event_weight, phase_space_weight) "
                        "VALUES (%s, %s, %s, %s, %s, %s) RETURNING id"
                    )

                # Insert events and collect IDs
                event_ids = []
                for row in batch_events:
                    event_row = (*row, row[4]) if has_legacy_weight else row
                    cur.execute(insert_sql, event_row)
                    event_ids.append(cur.fetchone()[0])

                # Build final_states with correct FK linkage
                fs_rows = []
                for event_id, fs_group in zip(event_ids, batch_final_states):
                    for name, px, py, pz, E in fs_group:
                        fs_rows.append((event_id, name, px, py, pz, E))

                # Bulk insert final_states
                if fs_rows:
                    cur.executemany(
                        "INSERT INTO final_states(event_id, particle, px, py, pz, E) "
                        "VALUES (%s, %s, %s, %s, %s, %s)",
                        fs_rows,
                    )

                conn.commit()
    except Exception as e:
        print(f"[ERROR] Batch flush failed: {e}")


def _assign_daughter_spins(
    daughter_names: list,
    p4s: list,
    parent_pdg: int,
    rng: np.random.Generator,
    parent_p4: tuple = (0.0, 0.0, 0.0, 0.0),
    afb: float = 0.0,
) -> list:
    """
    Assign SpinState to each daughter based on parent decay.
    """
    from .helicity import compute_tau_helicity

    TAU_PDGS = {15, -15}
    spins = []

    if parent_pdg == 23:
        tau_minus_index = None
        tau_plus_index = None
        for index, name in enumerate(daughter_names):
            pdg = get_pdg_id_cached(name)
            if pdg == 15:
                tau_minus_index = index
            elif pdg == -15:
                tau_plus_index = index

        if tau_minus_index is not None and tau_plus_index is not None:
            tau_minus_spin = compute_tau_helicity(
                tau_p4=p4s[tau_minus_index],
                parent_p4=parent_p4,
                rng=rng,
                afb=afb,
            )

            tau_plus_axis_rf = _boost_to_rest_frame(p4s[tau_plus_index], parent_p4)
            tau_plus_axis = _unit(tau_plus_axis_rf)
            tau_plus_spin = SpinState(
                helicity=-tau_minus_spin.helicity,
                quantization_axis=tau_plus_axis,
            )

            for index, name in enumerate(daughter_names):
                pdg = get_pdg_id_cached(name)
                if index == tau_minus_index:
                    spins.append(tau_minus_spin)
                elif index == tau_plus_index:
                    spins.append(tau_plus_spin)
                elif pdg in TAU_PDGS:
                    spins.append(SpinState.unpolarized())
                else:
                    spins.append(SpinState.unpolarized())
            return spins

    for name, p4 in zip(daughter_names, p4s):
        pdg = get_pdg_id_cached(name)

        if pdg in TAU_PDGS and parent_pdg == 23:
            spin = compute_tau_helicity(
                tau_p4=p4, parent_p4=parent_p4, rng=rng, afb=afb
            )

            if pdg == -15:
                spin = SpinState(
                    helicity=-spin.helicity, quantization_axis=spin.quantization_axis
                )
        else:
            spin = SpinState.unpolarized()

        spins.append(spin)

    return spins


def _decay_particle_recursive(
    particle_name: str,
    p4: tuple,
    spin: "SpinState | None",
    rng: np.random.Generator,
    depth: int = 0,
    max_depth: int = 4,
    afb: float = 0.0,
    force_tau_pion_only: bool = False,
    fixed_decay_mode: str | None = None,
) -> list:
    from .spin import SpinState
    from .matrix_elements import get_matrix_element

    STABLE = {
        "Electron",
        "Positron",
        "Photon",
        "Proton",
        "Antiproton",
        "Electron neutrino",
        "Electron antineutrino",
        "Muon neutrino",
        "Muon antineutrino",
        "Tau neutrino",
        "Tau antineutrino",
        "Gluon",
    }

    if particle_name in STABLE or depth >= max_depth:
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    pdg = get_pdg_id_cached(particle_name)
    if pdg is None:
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    modes = get_decay_modes(pdg)
    if not modes:
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    if depth == 0 and fixed_decay_mode is not None:
        decay_mode = fixed_decay_mode
    elif force_tau_pion_only and pdg == 15:
        decay_mode = "π⁻ ντ"
    elif force_tau_pion_only and pdg == -15:
        decay_mode = "π⁺ ν̄τ"
    else:
        decay_mode = choose_decay_mode(pdg, rng)
    if decay_mode == "stable":
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    try:
        daughters = get_decay_products(pdg, decay_mode)
    except Exception:
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    if not _is_kinematically_allowed(get_particle(particle_name)["mass"], daughters):
        return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

    parent_mass = get_particle(particle_name)["mass"]
    daughter_pdgs = tuple(sorted([get_pdg_id_cached(n) or 0 for n in daughters]))
    decay_key = (pdg, daughter_pdgs)

    if spin is None:
        spin = SpinState.unpolarized()

    me = get_matrix_element(decay_key)
    context = {"spin_state": spin, "afb": afb}

    # For polarized tau 2-body decays, sample directions with M2 accept-reject.
    # This is required to imprint the helicity-dependent angular shape.
    is_polarized_tau_2body = (
        pdg in (15, -15)
        and len(daughters) == 2
        and spin is not None
        and spin.is_polarized
    )

    p4s = None
    ps_weight = 1.0
    M2 = 1.0

    if is_polarized_tau_2body:
        accepted = False
        m2_max = 2.0  # for M2 = 1 + h*cos(theta), with h in {-1,+1}
        for _ in range(32):
            try:
                cand_p4s, cand_ps_weight = _generate_decay_fourvectors(
                    parent_mass,
                    daughters,
                    rng,
                    apply_weights=False,
                    parent_pdg=pdg,
                    afb=afb,
                )
            except Exception:
                return [
                    {"name": particle_name, "p4": p4, "depth": depth, "parent": None}
                ]

            ordered = _reorder_daughters_for_matrix_element(daughters, cand_p4s, pdg)
            cand_M2 = float(me.M2((parent_mass, 0.0, 0.0, 0.0), ordered, context))
            accept_prob = min(1.0, max(0.0, cand_M2 / m2_max))
            if rng.random() <= accept_prob:
                p4s = cand_p4s
                ps_weight = cand_ps_weight
                M2 = cand_M2
                accepted = True
                break

        if not accepted:
            # Numerical fallback: use one sampled candidate even if A/R was unlucky.
            p4s = cand_p4s
            ps_weight = cand_ps_weight
            M2 = cand_M2
    else:
        try:
            p4s, ps_weight = _generate_decay_fourvectors(
                parent_mass,
                daughters,
                rng,
                apply_weights=False,
                parent_pdg=pdg,
                afb=afb,
            )
        except Exception:
            return [{"name": particle_name, "p4": p4, "depth": depth, "parent": None}]

        ordered = _reorder_daughters_for_matrix_element(daughters, p4s, pdg)
        M2 = float(me.M2((parent_mass, 0.0, 0.0, 0.0), ordered, context))

    _ = (M2, ps_weight)

    daughter_spins = _assign_daughter_spins(
        daughters,
        p4s,
        pdg,
        rng,
        parent_p4=(parent_mass, 0.0, 0.0, 0.0),
        afb=afb,
    )

    E_par, px_par, py_par, pz_par = p4
    beta = np.array([px_par, py_par, pz_par]) / E_par if E_par > 0 else np.zeros(3)
    beta_mag_sq = float(np.dot(beta, beta))

    boosted_p4s = []
    for fv in p4s:
        if beta_mag_sq > 1e-18:
            from .kinematics import FourVector

            bfv = FourVector(*fv).boost(beta)
            boosted_p4s.append((bfv.E, bfv.px, bfv.py, bfv.pz))
        else:
            boosted_p4s.append(fv)

    final_states = []
    for name, bp4, dspin in zip(daughters, boosted_p4s, daughter_spins):
        children = _decay_particle_recursive(
            name,
            bp4,
            dspin,
            rng,
            depth + 1,
            max_depth,
            afb=afb,
            force_tau_pion_only=force_tau_pion_only,
            fixed_decay_mode=fixed_decay_mode,
        )

        # Attach immediate parent truth metadata (needed for tau-rest-frame observables)
        for child in children:
            if child.get("parent") is None:
                child["parent"] = particle_name
                child["parent_p4"] = p4
                child["parent_pdg"] = pdg

        final_states.extend(children)

    return final_states


def simulate_events(
    parent_name: str,
    events: int = 10,
    n_events: int | None = None,
    seed: int | None = None,
    parent_energy: float | None = None,
    event_weight: float = 1.0,
    verbose: bool = False,
    warmup_events: int = 500,
    use_accept_reject: bool = False,
    store_neutrinos: bool = False,
    ar_inflate: float = 1.2,
    fixed_decay_mode: str | None = None,
    use_breit_wigner: bool = False,
    bw_window: float = 10.0,
    afb: float = 0.0,
) -> dict:
    """
    High-performance batch event generator: pure RAM generation → single DB dump.
    """
    if use_accept_reject and use_breit_wigner:
        raise RuntimeError(
            "Accept-reject cannot be used with Breit-Wigner mass smearing. "
            "Use weighted events (use_accept_reject=False) or disable Breit-Wigner. "
            "Reason: M² envelope depends on parent mass, which varies event-by-event."
        )

    if verbose:
        assert events <= 100, "Verbose mode only for debugging (≤100 events)"

    total = n_events if n_events is not None else events
    rng = np.random.default_rng(seed)

    print(f"\n[SETUP] Resolving {parent_name}...")
    parent_info = get_particle(parent_name)
    parent_mass = parent_info["mass"]
    parent_width = parent_info.get("width", 0.0)

    if parent_energy is not None:
        if parent_energy <= 0.0:
            raise ValueError("parent_energy must be positive")
        parent_mass = float(parent_energy)

    parent_pdg = get_pdg_id_cached(parent_name)
    if parent_pdg is None:
        raise RuntimeError(f"Unknown particle: {parent_name}")

    if fixed_decay_mode:
        decay_modes = [(fixed_decay_mode, 1.0)]
        print(f"[SETUP] Forced decay mode: {fixed_decay_mode}")
    else:
        decay_modes = get_decay_modes(parent_pdg)
        if len(decay_modes) == 1:
            fixed_decay_mode = decay_modes[0][0]
            print(f"[SETUP] Single decay mode: {fixed_decay_mode}")
        else:
            print(f"[SETUP] {len(decay_modes)} decay modes available")

    run_timestamp = datetime.utcnow().isoformat()

    success = 0
    failed = 0
    rejected = 0

    events_out = []
    final_states_out = []
    M2_max = {}

    show_progress = total > 100
    last_progress = 0

    print(f"[GEN] Generating {total} events for {parent_name}...")
    start_gen = datetime.now()

    for i in range(total):
        if use_breit_wigner and parent_width > 0:
            m_min = max(0.0, parent_mass - bw_window * parent_width)
            m_max = parent_mass + bw_window * parent_width
            m_event = float(
                sample_relativistic_bw(
                    m0=parent_mass,
                    gamma=parent_width,
                    rng=rng,
                    m_min=m_min,
                    m_max=m_max,
                )
            )
        else:
            m_event = parent_mass

        status, payload = _simulate_event_inmemory(
            parent_name,
            m_event,
            parent_pdg,
            fixed_decay_mode,
            event_weight,
            rng,
            M2_max,
            event_index=i,
            use_accept_reject=use_accept_reject,
            warmup_events=warmup_events,
            run_timestamp=run_timestamp,
            ar_inflate=ar_inflate,
            afb=afb,
        )

        if status == "ACCEPTED":
            event_row, final_state_rows, detector = payload
            events_out.append(event_row)
            final_states_out.append(final_state_rows)
            success += 1
        elif status == "WARMUP":
            pass
        elif status == "REJECTED":
            rejected += 1
        else:
            failed += 1

        if show_progress:
            progress_pct = (i + 1) / total
            if progress_pct - last_progress >= 0.05:
                print(
                    f"[GEN] {i+1:6d}/{total} ({progress_pct*100:5.1f}%) | Success: {success:6d}"
                )
                last_progress = progress_pct

    gen_time = (datetime.now() - start_gen).total_seconds()
    print(
        f"[GEN] ✓ Complete: {success} events in {gen_time:.2f}s ({success/gen_time:.0f} evt/sec)"
    )

    store_time = 0.0
    if events_out:
        print(
            f"\n[STORE] Writing {success} events + {sum(len(fs) for fs in final_states_out)} particles..."
        )
        start_store = datetime.now()
        _flush_batch(events_out, final_states_out)
        store_time = (datetime.now() - start_store).total_seconds()
        print(f"[STORE] ✓ Complete in {store_time:.2f}s")

    if use_accept_reject and M2_max:
        print("\n[ACCEPT–REJECT] Learned M² maxima:")
        for k, v in M2_max.items():
            print(f"  {k}: {v:.3e}")

    return {
        "success": success,
        "failed": failed,
        "rejected": rejected,
        "total": total,
        "gen_time": gen_time,
        "store_time": store_time,
        "run_timestamp": run_timestamp,
    }


def simulate_chain(
    parent_name: str,
    n_events: int = 1000,
    seed: int | None = None,
    afb: float = 0.0,
    fixed_decay_mode: str | None = None,
    verbose: bool = False,
    force_tau_pion_only: bool = False,
) -> dict:
    rng = np.random.default_rng(seed)
    run_timestamp = datetime.utcnow().isoformat()

    parent_info = get_particle(parent_name)
    parent_mass = parent_info["mass"]
    parent_pdg = get_pdg_id_cached(parent_name)

    if parent_pdg is None:
        raise RuntimeError(f"Unknown particle: {parent_name}")

    if not fixed_decay_mode:
        modes = get_decay_modes(parent_pdg)
        if len(modes) == 1:
            fixed_decay_mode = modes[0][0]

    events_out = []
    final_states_out = []
    success = 0
    failed = 0

    start = datetime.now()
    parent_spin = SpinState.unpolarized()

    all_tau_pion_cos = []
    tau_pion_by_charge = {"Pion-": [], "Pion+": []}

    for i in range(n_events):
        parent_p4 = (parent_mass, 0.0, 0.0, 0.0)

        try:
            final_states = _decay_particle_recursive(
                particle_name=parent_name,
                p4=parent_p4,
                spin=parent_spin,
                rng=rng,
                depth=0,
                max_depth=4,
                afb=afb,
                force_tau_pion_only=force_tau_pion_only,
                fixed_decay_mode=fixed_decay_mode,
            )
        except Exception as e:
            if verbose:
                print(f"[CHAIN] Event {i} failed: {e}")
            failed += 1
            continue

        if not final_states:
            failed += 1
            continue

        # Compute truth-level cos(theta_pi) in tau rest frame
        for fs in final_states:
            if fs.get("name") not in {"Pion-", "Pion+"}:
                continue
            parent_pdg_fs = fs.get("parent_pdg")
            if parent_pdg_fs is None or abs(int(parent_pdg_fs)) != 15:
                continue
            parent_p4_fs = fs.get("parent_p4")
            if parent_p4_fs is None:
                continue

            p_pi_rf = _boost_to_rest_frame(fs["p4"], parent_p4_fs)
            p_mag = float(np.linalg.norm(p_pi_rf))
            if p_mag < 1e-14:
                continue

            axis = _unit(
                np.array(parent_p4_fs[1:], dtype=float)
            )  # tau direction in Z frame
            cos_theta = float(np.dot(p_pi_rf / p_mag, axis))
            cos_theta = max(-1.0, min(1.0, cos_theta))

            pion_name = fs.get("name")
            if pion_name in tau_pion_by_charge:
                tau_pion_by_charge[pion_name].append(cos_theta)

            # align both charges to tau- convention
            if pion_name == "Pion+":
                cos_theta = -cos_theta

            all_tau_pion_cos.append(cos_theta)

        decay_mode = fixed_decay_mode or "chain"
        event_row = (parent_name, decay_mode, parent_mass, run_timestamp, 1.0, 1.0)

        fs_rows = [
            (
                fs["name"],
                float(fs["p4"][1]),
                float(fs["p4"][2]),
                float(fs["p4"][3]),
                float(fs["p4"][0]),
            )
            for fs in final_states
        ]

        events_out.append(event_row)
        final_states_out.append(fs_rows)
        success += 1

        if verbose and (i + 1) % 100 == 0:
            print(f"[CHAIN] {i+1}/{n_events} | success: {success}")

    gen_time = (datetime.now() - start).total_seconds()

    store_time = 0.0
    if events_out:
        start_store = datetime.now()
        _flush_batch(events_out, final_states_out)
        store_time = (datetime.now() - start_store).total_seconds()

    rate = (success / gen_time) if gen_time > 0 else 0.0
    print(
        f"[CHAIN] Done: {success}/{n_events} in {gen_time:.2f}s "
        f"({rate:.0f} evt/sec) | store: {store_time:.2f}s"
    )

    return {
        "success": success,
        "failed": failed,
        "total": n_events,
        "gen_time": gen_time,
        "store_time": store_time,
        "run_timestamp": run_timestamp,
        "tau_pion_cos_theta": all_tau_pion_cos,
        "tau_pion_by_charge": tau_pion_by_charge,
    }
