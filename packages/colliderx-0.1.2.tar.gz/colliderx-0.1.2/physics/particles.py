from db import get_conn
from .kinematics import FourVector


class Particle:
    """
    Particle interface that integrates with the colliderx.db PDG-style schema.
    Includes in-memory caching for fast lookups.
    """

    _cache = {}  # Cache particle data to avoid repeated DB reads

    def __init__(self, name_or_symbol: str, px=0.0, py=0.0, pz=0.0):
        data = self.lookup_particle(name_or_symbol)
        self.pdg_id = data.get("PDG ID")
        self.name = data["Name"]
        self.symbol = data.get("Symbol", "")
        self.mass = data.get("Mass (MeV/c^2)", 0.0)
        self.charge = data.get("Charge (e)", 0.0)
        self.spin = data.get("Spin", 0.0)
        self.quantum_numbers = {
            "Baryon Number": data.get("Baryon Number", 0),
            "Le": data.get("Le", 0),
            "Lmu": data.get("Lmu", 0),
            "Ltau": data.get("Ltau", 0),
            "Strangeness": data.get("Strangeness", 0),
            "Charm": data.get("Charm", 0),
            "Bottomness": data.get("Bottomness", 0),
            "Topness": data.get("Topness", 0),
        }

        self.fourvec = self.make_fourvector(px, py, pz)

    # -------------------- Database Lookup --------------------

    @classmethod
    def lookup_particle(cls, name_or_symbol: str) -> dict:
        """Fetch all particle info from cache or DB by name or symbol."""
        key = name_or_symbol.lower()

        # Use cache if available
        if key in cls._cache:
            return cls._cache[key]

        with get_conn() as conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT "PDG ID", "Name", "Symbol", "Mass (MeV/c^2)", "Charge (e)", "Spin",
                       "Baryon Number", "Le", "Lmu", "Ltau", "Strangeness",
                       "Charm", "Bottomness", "Topness"
                FROM particles
                WHERE LOWER("Name") = LOWER(%s) OR LOWER("Symbol") = LOWER(%s)
                LIMIT 1
                """,
                (name_or_symbol, name_or_symbol),
            )
            row = cur.fetchone()
            columns = [desc[0] for desc in cur.description] if cur.description else []

        if not row:
            raise ValueError(f"❌ Particle '{name_or_symbol}' not found in database")

        data = dict(zip(columns, row))
        cls._cache[key] = data  # Store in cache
        return data

    # -------------------- Physics Methods --------------------

    def make_fourvector(self, px, py, pz) -> FourVector:
        """Construct a FourVector using rest mass and momentum components."""
        E = (self.mass**2 + px**2 + py**2 + pz**2) ** 0.5
        return FourVector(E, px, py, pz)

    # -------------------- Representation --------------------

    def __repr__(self):
        qnums = ", ".join(f"{k}={v}" for k, v in self.quantum_numbers.items() if v != 0)
        return (
            f"Particle(name={self.name}, symbol={self.symbol}, mass={self.mass:.2f} MeV/c², "
            f"charge={self.charge:+.0f}e, spin={self.spin}, {qnums}, fv={self.fourvec})"
        )
