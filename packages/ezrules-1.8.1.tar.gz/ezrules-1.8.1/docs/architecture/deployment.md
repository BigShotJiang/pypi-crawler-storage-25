# Deployment Guide (Local Runbook)

This runbook covers local deployment. Two local deployment modes are supported.

For system boundaries and design rationale, use [Architecture Overview](overview.md).
For environment variable details, use [Configuration](../getting-started/configuration.md).

---

## Scope

In scope:

- single-host local setup, both deployment modes
- API service startup and verification
- backtesting worker readiness

Out of scope:

- production topology design
- cloud platform-specific deployment automation

---

## Deployment Modes

### Mode 1 — Full Docker (demo or production)

Everything runs inside Docker. No local Python or Node required.

| Container | What it does |
|---|---|
| `postgres` | Database (`5432` not exposed to host by default) |
| `redis` | Celery broker plus async observation/shadow queue backing store (`6379` not exposed to host by default) |
| `init` | One-shot: creates DB schema, admin user, optional seed data |
| `api` | FastAPI service on `localhost:8888` |
| `worker` | Celery worker/beat process for backtesting and async queue drains |
| `frontend` | nginx serving the Angular SPA on `localhost:4200` |

**Demo** (pre-seeded with sample rules and events):

```bash
docker compose -f docker-compose.demo.yml up --build
```

Re-running that command recreates the demo database from scratch so older persisted schemas do not break the stack.

**Production** (empty database, credentials from `.env`):

```bash
cp .env.example .env   # fill in EZRULES_APP_SECRET, EZRULES_ORG_NAME, EZRULES_ADMIN_EMAIL, EZRULES_ADMIN_PASSWORD
docker compose -f docker-compose.prod.yml up --build
```

Re-running that command with the existing production volume intact keeps the data and applies pending migrations before services start.

Verify:

```bash
curl http://localhost:8888/ping        # → {"status":"ok"}
# open http://localhost:4200 in a browser
```

Stop containers:

```bash
docker compose -f docker-compose.demo.yml down
# or
docker compose -f docker-compose.prod.yml down
```

For the production stack, that keeps the Docker volume data intact.
For the demo stack, the next `up --build` run reseeds the database from scratch.

Stop and delete all data:

```bash
docker compose -f docker-compose.demo.yml down -v
# or
docker compose -f docker-compose.prod.yml down -v
```

---

### Mode 2 — Development (infrastructure in Docker, services local)

PostgreSQL, Redis, and the Celery worker run in Docker. The API and Angular dev server run as local processes, enabling hot-reload and debugger attachment.

**What runs where:**

- Docker: PostgreSQL (`localhost:5432`), Redis (`localhost:6379`), Celery worker
- Local: FastAPI (`localhost:8888`), Angular dev server (`localhost:4200`)

**Preflight:** Docker, Python 3.12+, `uv`, Node 20+, ports `5432 6379 8888 4200` free.

#### 1. Start infrastructure

```bash
docker compose up -d
```

Expected: `docker compose ps` shows postgres, redis, worker as `Up`.

Rollback:

```bash
docker compose down        # keep volumes
docker compose down -v     # remove volumes
```

#### 2. Install dependencies

```bash
uv sync
```

#### 3. Initialize database

```bash
uv run ezrules init-db
uv run ezrules bootstrap-org --name your-org --admin-email admin@example.com --admin-password admin
```

`init-db` performs database creation (if needed), Alembic migration to head, and initialization of the global action catalogue.
`bootstrap-org` creates the organisation, seeds default roles and user lists, and ensures the initial admin user exists.
Outcomes and labels remain empty until you create them through the UI or API.

Requires `settings.env` with `EZRULES_DB_ENDPOINT` and `EZRULES_APP_SECRET`.

#### 4. Run API

--8<-- "snippets/start-api.md"

Optional (with auto-reload):

```bash
uv run ezrules api --port 8888 --reload
```

Expected: `http://localhost:8888/ping` responds.

#### 5. Run frontend

```bash
cd ezrules/frontend
npm install
npm start
```

Expected: `http://localhost:4200` loads login page.

#### 6. Verify

- Health check: `http://localhost:8888/ping`
- OpenAPI: `http://localhost:8888/docs`
- Frontend: `http://localhost:4200`

#### Clean shutdown

Stop local processes, then:

```bash
docker compose down
```

---

## Common Failure Modes

| Symptom | Likely Cause | Action |
|---|---|---|
| `init` container exits non-zero | DB not ready or env var missing | Check `docker compose logs init` |
| API fails to start | DB endpoint invalid or DB down | Check `settings.env`, then `docker compose ps` |
| Port `8888` or `4200` conflict | Another process holds the port | `lsof -i :8888` to identify, then stop it |
| Backtests stay `PENDING` or shadow stats stop updating | Worker or Redis unavailable | `docker compose ps` — confirm worker and redis are `Up` |
| Frontend cannot log in | API not reachable or no admin user | Verify `/ping`, re-run `add-user` |

---

## Backtesting Notes

- Backtesting enqueues Celery tasks via Redis
- Worker must be running or tasks remain `PENDING` indefinitely
- All three deployment modes include a running worker

## Async Queue Notes

- Live field observations and live shadow evaluation both rely on Redis-backed queues by default
- Those queues reuse `EZRULES_CELERY_BROKER_URL` unless you explicitly set `EZRULES_OBSERVATION_QUEUE_REDIS_URL` or `EZRULES_SHADOW_EVALUATION_QUEUE_REDIS_URL`
- The periodic drain cadence is controlled by the corresponding `*_DRAIN_INTERVAL_SECONDS`, `*_DRAIN_BATCH_SIZE`, and `*_MAX_BATCHES_PER_DRAIN` settings
- If Celery beat is not running, shadow results and buffered field observations will lag even though `/api/v2/evaluate` still succeeds

---

## Common Development Commands

```bash
docker compose up -d
uv run ezrules api --port 8888
uv run poe check
EZRULES_DB_ENDPOINT=postgresql://postgres:root@localhost:5432/tests_e2e_local \
EZRULES_TESTING=true \
EZRULES_APP_SECRET=test-secret \
EZRULES_ORG_ID=1 \
uv run pytest --cov=ezrules.backend --cov=ezrules.core --cov-report=term-missing --cov-report=xml tests
```
