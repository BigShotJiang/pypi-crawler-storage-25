"""
Typed errors thrown by the Nexus Legal SDK.

All inherit from `NexusAPIError`. Branch on subclass:

    try:
        nexus.analyze(text="...", jurisdiction="ES")
    except InsufficientCreditsError as e:
        print(f"Need {e.required}, have {e.balance}")
    except RateLimitError as e:
        time.sleep(e.retry_after)
"""

from __future__ import annotations

from typing import Any, Optional


class NexusAPIError(Exception):
    """Base class for any error returned by the Nexus API."""

    def __init__(
        self,
        message: str,
        status: int,
        code: Optional[str] = None,
        body: Any = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.body = body
        self.request_id = request_id


class AuthenticationError(NexusAPIError):
    """401 / 403 — invalid, expired or scope-insufficient API key."""


class InsufficientCreditsError(NexusAPIError):
    """402 — account out of credits. Includes `balance` and `required` if present."""

    def __init__(
        self,
        message: str,
        status: int,
        code: Optional[str] = None,
        body: Any = None,
        balance: Optional[int] = None,
        required: Optional[int] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, status, code, body, request_id)
        self.balance = balance
        self.required = required


class IdempotencyConflictError(NexusAPIError):
    """409 — same Idempotency-Key reused with a different request body."""


class ValidationError(NexusAPIError):
    """400 / 422 — malformed payload, text out of range, bad jurisdiction."""


class RateLimitError(NexusAPIError):
    """429 — rate limit exceeded. `retry_after` from `Retry-After` header."""

    def __init__(
        self,
        message: str,
        status: int,
        retry_after: int,
        code: Optional[str] = None,
        body: Any = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, status, code, body, request_id)
        self.retry_after = retry_after


class ServerError(NexusAPIError):
    """500-599 — internal error or upstream LLM degraded."""


class NetworkError(Exception):
    """Network failure before the response was received."""

    def __init__(self, message: str, cause: Optional[BaseException] = None) -> None:
        super().__init__(message)
        self.cause = cause


class TimeoutError(Exception):  # noqa: A001 - intentional shadowing for symmetry
    """Local timeout before the response arrived."""

    def __init__(self, timeout: float) -> None:
        super().__init__(f"Request timed out after {timeout}s")
        self.timeout = timeout


# ─── Helper ─────────────────────────────────────────────────────────────────


def build_api_error(
    *,
    status: int,
    body: Any,
    retry_after: Optional[int] = None,
    request_id: Optional[str] = None,
) -> NexusAPIError:
    """Map an HTTP response into the right error subclass."""

    if isinstance(body, dict):
        message = body.get("error") or f"Nexus API responded {status}"
        code = body.get("code")
    else:
        message = f"Nexus API responded {status}"
        code = None

    if status in (401, 403):
        return AuthenticationError(message, status, code, body, request_id)
    if status == 402:
        return InsufficientCreditsError(
            message,
            status,
            code,
            body,
            balance=body.get("balance") if isinstance(body, dict) else None,
            required=body.get("required") if isinstance(body, dict) else None,
            request_id=request_id,
        )
    if status == 409:
        return IdempotencyConflictError(message, status, code, body, request_id)
    if status in (400, 422):
        return ValidationError(message, status, code, body, request_id)
    if status == 429:
        return RateLimitError(
            message,
            status,
            retry_after=retry_after if retry_after is not None else 1,
            code=code,
            body=body,
            request_id=request_id,
        )
    if status >= 500:
        return ServerError(message, status, code, body, request_id)
    return NexusAPIError(message, status, code, body, request_id)
