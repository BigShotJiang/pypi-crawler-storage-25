"""
NexusClient — Python SDK for the Nexus Legal API v1.

Usage::

    from nexus_legal import NexusClient

    nexus = NexusClient(api_key=os.environ["NEXUS_API_KEY"])

    result = nexus.analyze(
        text="Por el presente contrato, el arrendador cede el uso...",
        jurisdiction="ES",
        legal_branch="civil",
    )
    print(result["analysis"])

Features:
    - Auto Idempotency-Key (UUID4) on every POST, reused across retries.
    - Exponential backoff + jitter for 429 / 5xx, honoring Retry-After.
    - Typed errors (RateLimitError, InsufficientCreditsError, ...).
    - Rate-limit headers parsed into `result["rate_limit"]`.
"""

from __future__ import annotations

import json as _json
import time
import uuid
from typing import Any, Dict, List, Optional, Union

import requests
from requests.adapters import HTTPAdapter

from . import __version__
from ._errors import (
    NetworkError,
    NexusAPIError,
    TimeoutError as _TimeoutError,
    build_api_error,
)
from ._retry import compute_backoff, parse_retry_after, should_retry

DEFAULT_BASE_URL = "https://legal.nexusquantum.legal"
DEFAULT_TIMEOUT_SEC = 120.0
DEFAULT_MAX_RETRIES = 3


class NexusClient:
    """Synchronous Python SDK for the Nexus Legal API v1."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SEC,
        max_retries: int = DEFAULT_MAX_RETRIES,
        auto_idempotency: bool = True,
        session: Optional[requests.Session] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        if not isinstance(api_key, str) or not api_key:
            raise TypeError("NexusClient: `api_key` is required.")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.auto_idempotency = auto_idempotency
        suffix = f" {user_agent}" if user_agent else ""
        self.user_agent = f"nexus-legal-sdk-py/{__version__}{suffix}"
        self._session = session or self._default_session()

        # Resource handles
        self.sandbox = SandboxResource(self)
        self.jurisprudencia = JurisprudenciaResource(self)
        self.jurisdictions = JurisdictionsResource(self)
        self.usage = UsageResource(self)
        self.jobs = JobsResource(self)
        self.webhooks = WebhooksResource(self)
        self.organizations = OrganizationsResource(self)

    @staticmethod
    def _default_session() -> requests.Session:
        s = requests.Session()
        # Pool sizes generous — Python apps often share a single client.
        adapter = HTTPAdapter(pool_connections=20, pool_maxsize=50, max_retries=0)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        return s

    # ── Top-level: POST /api/v1/analyze ────────────────────────────────────

    def analyze(
        self,
        *,
        text: str,
        jurisdiction: str,
        legal_branch: Optional[str] = None,
        language: Optional[str] = None,
        mode: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> Dict[str, Any]:
        """POST /api/v1/analyze — analyze a legal document. Returns parsed JSON
        with extra `rate_limit` and `idempotency_replayed` fields."""
        body: Dict[str, Any] = {"text": text, "jurisdiction": jurisdiction}
        if legal_branch is not None:
            body["legalBranch"] = legal_branch
        if language is not None:
            body["language"] = language
        if mode is not None:
            body["mode"] = mode

        data, headers, idem = self._request(
            "POST",
            "/api/v1/analyze",
            body=body,
            idempotency_key=idempotency_key,
            timeout=timeout,
            max_retries=max_retries,
        )
        data["rate_limit"] = _parse_rate_limit(headers)
        data["idempotency_replayed"] = headers.get("idempotency-replayed") == "true"
        if idem:
            data["idempotency_key"] = idem
        return data

    # ── Top-level: POST /api/v1/analyze/batch ──────────────────────────────

    def analyze_batch(
        self,
        *,
        documents: List[Dict[str, Any]],
        mode: Optional[str] = None,
        concurrency: Optional[int] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"documents": documents}
        if mode is not None:
            body["mode"] = mode
        if concurrency is not None:
            body["concurrency"] = concurrency

        data, headers, idem = self._request(
            "POST",
            "/api/v1/analyze/batch",
            body=body,
            idempotency_key=idempotency_key,
            timeout=timeout,
            max_retries=max_retries,
        )
        data["rate_limit"] = _parse_rate_limit(headers)
        data["idempotency_replayed"] = headers.get("idempotency-replayed") == "true"
        if idem:
            data["idempotency_key"] = idem
        return data

    # ── Internal request engine ────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        query: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        as_text: bool = False,
    ):
        url = self._build_url(path, query)
        effective_timeout = timeout if timeout is not None else self.timeout
        effective_retries = max_retries if max_retries is not None else self.max_retries

        # Idempotency-Key auto-generation
        idem = idempotency_key
        if idem is None and method.upper() == "POST" and self.auto_idempotency:
            idem = str(uuid.uuid4())

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": self.user_agent,
            "Accept": "text/csv,*/*" if as_text else "application/json",
        }
        if body is not None:
            headers["Content-Type"] = "application/json"
        if idem:
            headers["Idempotency-Key"] = idem

        last_exc: Optional[BaseException] = None
        for attempt in range(effective_retries + 1):
            try:
                resp = self._session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    data=_json.dumps(body) if body is not None else None,
                    timeout=effective_timeout,
                )
            except requests.Timeout as e:
                last_exc = _TimeoutError(effective_timeout)
                if attempt < effective_retries:
                    time.sleep(compute_backoff(attempt))
                    continue
                raise last_exc from e
            except requests.RequestException as e:
                last_exc = NetworkError(str(e), e)
                if attempt < effective_retries:
                    time.sleep(compute_backoff(attempt))
                    continue
                raise last_exc

            request_id = resp.headers.get("x-request-id") or resp.headers.get(
                "x-correlation-id"
            )

            if resp.status_code >= 400:
                err_body = _decode(resp, as_text=False)
                api_err = build_api_error(
                    status=resp.status_code,
                    body=err_body,
                    retry_after=parse_retry_after(resp.headers.get("retry-after")),
                    request_id=request_id,
                )
                if should_retry(resp.status_code) and attempt < effective_retries:
                    retry_after = (
                        getattr(api_err, "retry_after", None)
                        if isinstance(api_err, NexusAPIError)
                        else None
                    )
                    time.sleep(compute_backoff(attempt, retry_after))
                    continue
                raise api_err

            data = _decode(resp, as_text=as_text)
            return data, resp.headers, idem

        # Shouldn't reach here
        if last_exc:
            raise last_exc
        raise RuntimeError("Retry loop exhausted unexpectedly")

    def _build_url(self, path: str, query: Optional[Dict[str, Any]] = None) -> str:
        base = self.base_url + (path if path.startswith("/") else f"/{path}")
        if not query:
            return base
        from urllib.parse import urlencode

        pairs = {k: v for k, v in query.items() if v is not None}
        return f"{base}?{urlencode(pairs)}" if pairs else base


# ─── Resources ──────────────────────────────────────────────────────────────


class SandboxResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def analyze(
        self,
        *,
        sample: Optional[str] = None,
        text: Optional[str] = None,
        jurisdiction: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if sample is not None:
            body["sample"] = sample
        if text is not None:
            body["text"] = text
        if jurisdiction is not None:
            body["jurisdiction"] = jurisdiction
        data, headers, idem = self._client._request(
            "POST", "/api/v1/sandbox/analyze", body=body, timeout=timeout
        )
        data["rate_limit"] = _parse_rate_limit(headers)
        data["idempotency_replayed"] = headers.get("idempotency-replayed") == "true"
        if idem:
            data["idempotency_key"] = idem
        return data

    def metadata(self) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", "/api/v1/sandbox/analyze")
        return data


class JurisprudenciaResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def search(
        self,
        *,
        query: str,
        jurisdiction: str,
        top_k: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"query": query, "jurisdiction": jurisdiction}
        if top_k is not None:
            body["top_k"] = top_k
        data, headers, _ = self._client._request(
            "POST", "/api/v1/jurisprudencia/search", body=body, timeout=timeout
        )
        data["rate_limit"] = _parse_rate_limit(headers)
        return data


class JurisdictionsResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def list(self) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", "/api/v1/jurisdictions")
        return data


class UsageResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def get(
        self,
        *,
        from_: Optional[str] = None,
        to: Optional[str] = None,
        granularity: Optional[str] = None,
        api_key_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        endpoint: Optional[str] = None,
    ) -> Dict[str, Any]:
        query: Dict[str, Any] = {
            "from": from_,
            "to": to,
            "granularity": granularity,
            "api_key_id": api_key_id,
            "organization_id": organization_id,
            "endpoint": endpoint,
        }
        data, _, _ = self._client._request("GET", "/api/v1/usage", query=query)
        return data

    def csv(
        self,
        *,
        from_: Optional[str] = None,
        to: Optional[str] = None,
        granularity: Optional[str] = None,
        api_key_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        endpoint: Optional[str] = None,
    ) -> str:
        query: Dict[str, Any] = {
            "from": from_,
            "to": to,
            "granularity": granularity,
            "api_key_id": api_key_id,
            "organization_id": organization_id,
            "endpoint": endpoint,
            "format": "csv",
        }
        data, _, _ = self._client._request(
            "GET", "/api/v1/usage", query=query, as_text=True
        )
        return data  # type: ignore[return-value]


class JobsResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def create(
        self,
        *,
        kind: str,
        payload: Dict[str, Any],
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        body = {"kind": kind, "payload": payload}
        data, headers, idem = self._client._request(
            "POST", "/api/v1/jobs", body=body, idempotency_key=idempotency_key
        )
        data["idempotency_replayed"] = headers.get("idempotency-replayed") == "true"
        if idem:
            data["idempotency_key"] = idem
        return data

    def get(self, job_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", f"/api/v1/jobs/{job_id}")
        return data

    def list(
        self, *, status: Optional[str] = None, limit: Optional[int] = None
    ) -> Dict[str, Any]:
        query: Dict[str, Any] = {"status": status, "limit": limit}
        data, _, _ = self._client._request("GET", "/api/v1/jobs", query=query)
        return data

    def cancel(self, job_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request("DELETE", f"/api/v1/jobs/{job_id}")
        return data

    def run(
        self,
        *,
        kind: str,
        payload: Dict[str, Any],
        interval_sec: float = 2.0,
        timeout_sec: float = 300.0,
    ) -> Dict[str, Any]:
        """Encola el job + poll hasta terminar. Conveniente para integraciones
        que prefieren la robustez del worker en background pero quieren un
        await sincrónico sobre el resultado."""
        accepted = self.create(kind=kind, payload=payload)
        job_id = accepted["jobId"]
        start = time.monotonic()
        while time.monotonic() - start < timeout_sec:
            snap = self.get(job_id)
            if snap.get("status") in ("completed", "failed", "cancelled"):
                return snap
            time.sleep(interval_sec)
        raise _TimeoutError(timeout_sec)


class WebhooksResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    def create(
        self,
        *,
        url: str,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        if description is not None:
            body["description"] = description
        data, _, _ = self._client._request("POST", "/api/v1/webhooks", body=body)
        return data

    def list(self) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", "/api/v1/webhooks")
        return data

    def get(self, webhook_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request(
            "GET", f"/api/v1/webhooks/{webhook_id}"
        )
        return data

    def update(
        self,
        webhook_id: str,
        *,
        active: Optional[bool] = None,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if active is not None:
            body["active"] = active
        if events is not None:
            body["events"] = events
        if description is not None:
            body["description"] = description
        data, _, _ = self._client._request(
            "PATCH", f"/api/v1/webhooks/{webhook_id}", body=body
        )
        return data

    def delete(self, webhook_id: str) -> None:
        self._client._request("DELETE", f"/api/v1/webhooks/{webhook_id}")


class OrganizationsResource:
    def __init__(self, client: NexusClient) -> None:
        self._client = client

    # Org-level

    def create(
        self, *, name: str, description: Optional[str] = None
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        data, _, _ = self._client._request("POST", "/api/v1/organizations", body=body)
        return data

    def list(self) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", "/api/v1/organizations")
        return data

    def get(self, org_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request("GET", f"/api/v1/organizations/{org_id}")
        return data

    def update(
        self,
        org_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        data, _, _ = self._client._request(
            "PATCH", f"/api/v1/organizations/{org_id}", body=body
        )
        return data

    def delete(self, org_id: str) -> None:
        self._client._request("DELETE", f"/api/v1/organizations/{org_id}")

    # Sub-keys

    def create_key(
        self,
        org_id: str,
        *,
        child_label: str,
        scopes: Optional[List[str]] = None,
        expires_in_days: Optional[int] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"childLabel": child_label}
        if scopes is not None:
            body["scopes"] = scopes
        if expires_in_days is not None:
            body["expiresInDays"] = expires_in_days
        data, _, _ = self._client._request(
            "POST", f"/api/v1/organizations/{org_id}/keys", body=body
        )
        return data

    def list_keys(self, org_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request(
            "GET", f"/api/v1/organizations/{org_id}/keys"
        )
        return data

    def update_key(
        self,
        org_id: str,
        key_id: str,
        *,
        active: Optional[bool] = None,
        scopes: Optional[List[str]] = None,
        child_label: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if active is not None:
            body["active"] = active
        if scopes is not None:
            body["scopes"] = scopes
        if child_label is not None:
            body["childLabel"] = child_label
        data, _, _ = self._client._request(
            "PATCH",
            f"/api/v1/organizations/{org_id}/keys/{key_id}",
            body=body,
        )
        return data

    def revoke_key(self, org_id: str, key_id: str) -> Dict[str, Any]:
        data, _, _ = self._client._request(
            "DELETE", f"/api/v1/organizations/{org_id}/keys/{key_id}"
        )
        return data


# ─── Helpers ────────────────────────────────────────────────────────────────


def _parse_rate_limit(headers) -> Dict[str, int]:
    return {
        "limit": _to_int(headers.get("x-ratelimit-limit")),
        "remaining": _to_int(headers.get("x-ratelimit-remaining")),
        "reset": _to_int(headers.get("x-ratelimit-reset")),
    }


def _to_int(v: Union[str, None]) -> int:
    if v is None:
        return 0
    try:
        return int(v)
    except (ValueError, TypeError):
        return 0


def _decode(resp: requests.Response, *, as_text: bool):
    if as_text:
        return resp.text
    content_type = resp.headers.get("content-type", "")
    if "application/json" in content_type:
        try:
            return resp.json()
        except ValueError:
            return None
    text = resp.text
    if not text:
        return None
    try:
        return _json.loads(text)
    except ValueError:
        return text
