"""
nexus-legal — Official Python SDK for the Nexus Legal API v1.

Quick start::

    from nexus_legal import NexusClient

    nexus = NexusClient(api_key=os.environ["NEXUS_API_KEY"])

    result = nexus.analyze(
        text="Por el presente contrato, el arrendador cede el uso...",
        jurisdiction="ES",
        legal_branch="civil",
    )
    print(result["analysis"])
    print("Rate limit remaining:", result["rate_limit"]["remaining"])

Full docs: https://legal.nexusquantum.legal/developers/docs
"""

__version__ = "0.1.1"

from ._audit_trail import ParsedAuditTrail, extract_audit_trail
from ._errors import (
    AuthenticationError,
    IdempotencyConflictError,
    InsufficientCreditsError,
    NetworkError,
    NexusAPIError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from ._webhooks import verify_webhook_signature
from .client import (
    JobsResource,
    JurisdictionsResource,
    JurisprudenciaResource,
    NexusClient,
    OrganizationsResource,
    SandboxResource,
    UsageResource,
    WebhooksResource,
)

__all__ = [
    "__version__",
    # Client
    "NexusClient",
    "JobsResource",
    "JurisdictionsResource",
    "JurisprudenciaResource",
    "OrganizationsResource",
    "SandboxResource",
    "UsageResource",
    "WebhooksResource",
    # Errors
    "NexusAPIError",
    "AuthenticationError",
    "IdempotencyConflictError",
    "InsufficientCreditsError",
    "NetworkError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
    "ValidationError",
    # Helpers
    "extract_audit_trail",
    "ParsedAuditTrail",
    "verify_webhook_signature",
]
