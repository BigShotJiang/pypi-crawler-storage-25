"""
Backoff helpers — exponential with jitter, honoring `Retry-After`.
"""

from __future__ import annotations

import random
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Optional


def should_retry(status: int) -> bool:
    return status == 429 or 500 <= status <= 599


def compute_backoff(attempt: int, retry_after_sec: Optional[float] = None) -> float:
    """Seconds to sleep before the next attempt (0-based attempt index)."""
    if retry_after_sec is not None and retry_after_sec >= 0:
        return min(retry_after_sec, 60.0) + random.uniform(0, 0.25)
    base = min(2.0 ** attempt, 30.0)
    return base + random.uniform(0, 1.0)


def parse_retry_after(value: Optional[str]) -> Optional[float]:
    """Parse `Retry-After` header (RFC 7231): seconds or HTTP date."""
    if not value:
        return None
    try:
        n = float(value)
        if n >= 0:
            return n
    except ValueError:
        pass
    try:
        dt = parsedate_to_datetime(value)
        if dt is not None:
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            delta = (dt - datetime.now(timezone.utc)).total_seconds()
            return max(0.0, delta)
    except (TypeError, ValueError):
        pass
    return None
