"""
Helper for integrators to verify the `X-Nexus-Signature` header on
webhook deliveries. Mirrors `sdk-js/src/webhooks.ts`.

Convention (Stripe-style):
    Header: X-Nexus-Signature: t=<unix-ts>,v1=<hex-digest>
    Digest: HMAC-SHA256(secret, f"{unix-ts}.{raw_body}")

Usage in a Flask / FastAPI / Django handler::

    from nexus_legal import verify_webhook_signature

    @app.post("/nexus-webhook")
    def webhook(request):
        raw = request.body          # bytes — pre-parse
        sig = request.headers.get("X-Nexus-Signature")
        if not verify_webhook_signature(
            raw_body=raw,
            signature=sig,
            secret=os.environ["WEBHOOK_SECRET"],
        ):
            return Response(status=401)
        payload = json.loads(raw)
        ...
"""

from __future__ import annotations

import hmac
import time
from hashlib import sha256
from typing import Optional, Union


def verify_webhook_signature(
    *,
    raw_body: Union[str, bytes],
    signature: Optional[str],
    secret: str,
    tolerance_sec: int = 300,
) -> bool:
    """Verify a `X-Nexus-Signature` header. Returns True if valid AND fresh."""
    if not signature or not secret:
        return False

    parsed = _parse_header(signature)
    if not parsed:
        return False
    t, v1 = parsed

    if abs(int(time.time()) - t) > tolerance_sec:
        return False

    body_bytes = raw_body.encode("utf-8") if isinstance(raw_body, str) else raw_body
    expected = hmac.new(
        secret.encode("utf-8"),
        f"{t}.".encode("utf-8") + body_bytes,
        sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, v1)


def _parse_header(h: str):
    parts = {}
    for part in h.split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            parts[k.strip()] = v.strip()
    try:
        t = int(parts.get("t", ""))
    except ValueError:
        return None
    v1 = parts.get("v1")
    if not v1:
        return None
    return t, v1
