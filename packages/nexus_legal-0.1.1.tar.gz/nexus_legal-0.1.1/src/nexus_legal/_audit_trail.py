"""
Narrow parser for the `NEXUS-AUDIT-TRAIL-BEGIN…END` block embedded at
the end of every `/api/v1/analyze` response.

Intentionally narrow — no YAML dependency. Handles the fields documented
in `/developers/docs §5`. For arbitrary YAML, parse `raw` with PyYAML.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, TypedDict


class ParsedAuditTrail(TypedDict, total=False):
    jurisdiction: str
    mode: str
    modules_active: List[str]
    levels_emitted: Dict[str, int]
    rag_sources: Dict[str, int]
    kill_switches_triggered: List[str]
    review_flags: List[str]
    executive_summary: str
    raw: str


_RE = re.compile(r"NEXUS-AUDIT-TRAIL-BEGIN\s*\n([\s\S]*?)\nNEXUS-AUDIT-TRAIL-END")
_KEY_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def extract_audit_trail(analysis: str) -> Optional[ParsedAuditTrail]:
    """Locate and parse the audit-trail block. Returns None if absent."""
    match = _RE.search(analysis)
    if not match:
        return None
    raw = match.group(1)
    return _parse(raw)


def _parse(raw: str) -> ParsedAuditTrail:
    lines = raw.split("\n")
    out: ParsedAuditTrail = {
        "levels_emitted": {},
        "review_flags": [],
        "raw": raw,
    }

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        indent = len(line) - len(line.lstrip())
        kv = _match_key(stripped)
        if not kv:
            i += 1
            continue
        key, value = kv

        if value:
            value = _strip_comment(value)
            if key == "jurisdiction":
                out["jurisdiction"] = value
            elif key == "mode":
                out["mode"] = value
            elif key == "modules_active":
                out["modules_active"] = _parse_inline_list(value)
            elif key == "kill_switches_triggered":
                out["kill_switches_triggered"] = _parse_inline_list(value)
            elif key == "review_flags":
                out["review_flags"] = _parse_inline_list(value)
            elif key == "executive_summary":
                out["executive_summary"] = value
            i += 1
            continue

        # Block (no inline value)
        if key in ("levels_emitted", "rag_sources"):
            sub_map: Dict[str, int] = {}
            i += 1
            while i < len(lines):
                sub = lines[i]
                sub_strip = sub.strip()
                if not sub_strip:
                    i += 1
                    continue
                sub_indent = len(sub) - len(sub.lstrip())
                if sub_indent <= indent:
                    break
                sub_kv = _match_key(sub_strip)
                if sub_kv and sub_kv[1]:
                    try:
                        sub_map[sub_kv[0]] = int(_strip_comment(sub_kv[1]))
                    except ValueError:
                        pass
                i += 1
            if key == "levels_emitted":
                out["levels_emitted"] = sub_map
            else:
                out["rag_sources"] = sub_map
            continue

        if key in ("review_flags", "modules_active", "kill_switches_triggered"):
            arr: List[str] = []
            i += 1
            while i < len(lines):
                sub = lines[i]
                sub_strip = sub.strip()
                if not sub_strip:
                    i += 1
                    continue
                sub_indent = len(sub) - len(sub.lstrip())
                if sub_indent <= indent:
                    break
                if sub_strip.startswith("- "):
                    arr.append(_strip_comment(sub_strip[2:].strip()))
                i += 1
            if key == "review_flags":
                out["review_flags"] = arr
            elif key == "modules_active":
                out["modules_active"] = arr
            else:
                out["kill_switches_triggered"] = arr
            continue

        if key == "executive_summary":
            buf: List[str] = []
            i += 1
            while i < len(lines):
                sub = lines[i]
                if not sub.strip():
                    buf.append("")
                    i += 1
                    continue
                sub_indent = len(sub) - len(sub.lstrip())
                if sub_indent <= indent:
                    break
                buf.append(sub[indent + 2 :])
                i += 1
            out["executive_summary"] = "\n".join(buf).rstrip()
            continue

        i += 1

    return out


def _match_key(line: str):
    idx = line.find(":")
    if idx < 0:
        return None
    key = line[:idx].strip()
    if not _KEY_RE.match(key):
        return None
    value = line[idx + 1 :].strip()
    if value == "|":
        value = ""
    return key, value


def _strip_comment(value: str) -> str:
    idx = value.find(" #")
    return value[:idx].strip() if idx >= 0 else value.strip()


def _parse_inline_list(value: str) -> List[str]:
    v = _strip_comment(value)
    if v.startswith("[") and v.endswith("]"):
        return [s.strip() for s in v[1:-1].split(",") if s.strip()]
    return []
