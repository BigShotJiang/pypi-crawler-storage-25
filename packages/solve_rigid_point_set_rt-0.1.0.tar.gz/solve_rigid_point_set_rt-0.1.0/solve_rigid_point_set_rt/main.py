import numpy as np

def compute_best_rigid_transform(P: np.ndarray, Q: np.ndarray, assume_p_center_zero:bool=False):
    """
    Compute the optimal 3D rotation matrix R and translation vector t
    that satisfies: Q = R @ P + t (minimum mean square error)
    Parameters:
        P: Source point set, shape (N, 3), N is the number of points
        Q: Target point set, shape (N, 3), in one-to-one correspondence with P
    Returns:
        R: 3x3 optimal rotation matrix
        t: 3x1 optimal translation vector
    """
    # 1. Validate input
    assert P.shape == Q.shape, "The number and dimensions of the two point sets must be identical!"
    assert P.shape[1] == 3, "Must be 3D point coordinates (x,y,z)"
    
    # 2. Compute centroids of the two point sets
    if assume_p_center_zero:
        centroid_P = np.array([0, 0, 0])
    else:
        centroid_P = np.mean(P, axis=0)
    centroid_Q = np.mean(Q, axis=0)
    
    # 3. Center the points (subtract centroids to eliminate translation effect)
    P_centered = P - centroid_P
    Q_centered = Q - centroid_Q
    
    # 4. Compute covariance matrix H (3x3)
    H = P_centered.T @ Q_centered
    
    # 5. Perform SVD to solve for optimal rotation
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    
    # Correction: Ensure rotation matrix is right-handed (avoid reflection transformation)
    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T
    
    # 6. Compute optimal translation vector
    t = centroid_Q - R @ centroid_P
    
    return R, t

def apply_transform(P: np.ndarray, R: np.ndarray, t: np.ndarray):
    """Apply rotation and translation to the source point set to get transformed points"""
    return (R @ P.T).T + t

def calculate_error(transformed_P: np.ndarray, Q: np.ndarray):
    """Calculate Root Mean Square Error (RMSE) and mean distance to evaluate registration accuracy"""
    errors = np.linalg.norm(transformed_P - Q, axis=1)  # Euclidean distance for each point
    rmse = np.sqrt(np.mean(errors ** 2))
    mean_dist = np.mean(errors)
    return rmse, mean_dist, errors
