from .hackers_manifesto import *

__doc__ = hackers_manifesto.__doc__
if hasattr(hackers_manifesto, "__all__"):
    __all__ = hackers_manifesto.__all__