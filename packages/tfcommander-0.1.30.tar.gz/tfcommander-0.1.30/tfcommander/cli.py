#!/usr/bin/env python3
import argparse
import sys

from tfcommander.__about__ import __version__
from tfcommander.checker import check_service
from tfcommander.config import add_alias, list_aliases, remove_alias
from tfcommander.consul import deregister_service, list_services, register_service
from tfcommander.exceptions import TFCommanderError
from tfcommander.traefik import list_middlewares, list_routers

EXIT_OK = 0
EXIT_GENERAL = 1
EXIT_VALIDATION = 2


def _build_parser() -> argparse.ArgumentParser:
    epilog_text = """
Examples:
  # Alias Management
  tf alias list                           # Show all configured server aliases
  tf alias add jim 192.168.19.7           # Create alias 'jim' for server at 192.168.19.7
  tf alias remove jim                     # Remove the 'jim' alias

  # Service Listing
  tf list jim                             # List all Consul services on 'jim' server
  tf list-traefik jim                     # List all Traefik routers on 'jim' server
  tf list-middlewares jim                 # List all Traefik middlewares on 'jim' server

  # Service Health Check
  tf check zacekj.cz                      # Verify complete routing path from DNS to backend
    # Checks: DNS resolution → Host reachability → SSL cert → Traefik proxy → Backend response

  # Basic Service Registration
  tf register jim www-zacekj-cz WebZacekCZ 192.168.19.4 3000 zacekj.cz
    # Registers 'www-zacekj-cz' service running at 192.168.19.4:3000, accessible via zacekj.cz

  # With Authentication Middleware (first check available middlewares with 'tf list-middlewares jim')
  tf register jim api-zacekj APIService 192.168.19.4 8080 api.zacekj.cz --middlewares auth@file
    # Adds Traefik authentication middleware to protect the API endpoint

  # Self-Signed Certificate Backend (like Proxmox)
  tf register jim proxmox Proxmox 192.168.19.10 8006 prox.example.com --https-insecure
    # Backend uses HTTPS with self-signed cert - skips certificate verification

  # Plain HTTP Backend
  tf register jim app WebApp 192.168.19.10 8080 app.example.com --disable-tls
    # Backend service uses plain HTTP (not HTTPS)

  # Custom Upload Transport (for large file uploads)
  tf register jim uploads Chibisafe 192.168.6.3 24424 files.domain.tld --servers-transport long-upload@file
    # Uses custom serversTransport with extended timeouts for file uploads

  # Custom Certificate Resolver (Let's Encrypt staging)
  tf register jim www-zacekj-cz WebZacekCZ 192.168.19.4 3000 zacekj.cz --resolver letsencrypt-staging
    # Uses 'letsencrypt-staging' resolver instead of default 'myresolver'

  # Custom Routing Rule (path-based routing)
  tf register jim api APIService 192.168.19.4 3000 --custom-rule "PathPrefix(\\`/api\\`)"
    # Routes only requests with /api prefix to this service

  # Multiple Domains
  tf register jim web-zacekj WebApp 192.168.19.4 3000 zacekj.cz www.zacekj.cz
    # Service accessible via multiple domains

  # Multiple Middlewares
  tf register jim api-zacekj APIService 192.168.19.4 8080 api.zacekj.cz --middlewares auth@file cors@file rate-limit@file
    # Chains multiple middlewares: authentication, CORS headers, and rate limiting

  # Deregister Service
  tf deregister jim www-zacekj-cz         # Removes 'www-zacekj-cz' service from Consul
"""

    parser = argparse.ArgumentParser(
        description="Consul-Traefik Management CLI.",
        epilog=epilog_text,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command")

    reg_parser = subparsers.add_parser("register", help="Register a service with Consul and configure Traefik routing")
    reg_parser.add_argument(
        "public_ip",
        help="Alias (configured via 'tf alias add') or IP address of the Consul/Traefik server. Example: 'prod' or '192.168.1.100'",
    )
    reg_parser.add_argument(
        "service_id",
        help="Unique identifier for the service in Consul (must be unique per Consul instance). Example: 'webapp-api' or 'db-primary'",
    )
    reg_parser.add_argument(
        "service_name",
        help="Human-readable service name displayed in Consul UI and used for Traefik router naming. Example: 'WebApp API' or 'PostgreSQL'",
    )
    reg_parser.add_argument(
        "address",
        help="IP address or hostname where your backend service is actually running. Example: '10.0.1.50' or 'internal-api.local'",
    )
    reg_parser.add_argument(
        "port",
        type=int,
        help="TCP port number where your backend service listens for connections. Example: 8080, 3000, 5432",
    )
    reg_parser.add_argument(
        "domains",
        nargs="*",
        help="One or more domain names that Traefik will route to this service. Creates Host() rules. Example: 'api.example.com' or 'app.example.com admin.example.com'",
    )
    reg_parser.add_argument(
        "--middlewares",
        nargs="*",
        help="Space-separated list of Traefik middleware references to apply (authentication, rate limiting, headers, etc.). "
        "Format: 'name@provider' where provider is typically 'file'. "
        "Example: 'auth@file cors-headers@file rate-limit@file'. "
        "Use 'tf list-middlewares jim' to see all available middlewares on your Traefik instance.",
    )
    reg_parser.add_argument(
        "--https-insecure",
        action="store_true",
        help="Skip TLS certificate verification when Traefik connects to your backend service. "
        "Use this when your backend has a self-signed certificate or internal CA. "
        "Sets Traefik's insecureSkipVerify=true for this service's serversTransport. "
        "Example use case: connecting to Proxmox with self-signed cert",
    )
    reg_parser.add_argument(
        "--disable-tls",
        action="store_true",
        help="Connect to backend service via HTTP instead of HTTPS",
    )
    reg_parser.add_argument("--custom-rule", help="Custom Traefik routing rule (e.g., 'PathPrefix(`/api`)' or 'Host(`example.com`) && PathPrefix(`/api`)')")
    reg_parser.add_argument(
        "--servers-transport",
        help="Traefik serversTransport reference for custom transport settings (e.g., large-upload-transport@file for increased timeouts)",
    )
    reg_parser.add_argument(
        "--resolver",
        help="TLS certificate resolver name for Let's Encrypt or other ACME provider. Defaults to 'myresolver' if not specified.",
    )
    reg_parser.add_argument(
        "--traefik-port",
        type=int,
        default=None,
        help="Traefik API port (default: 8087)",
    )

    dereg_parser = subparsers.add_parser("deregister", help="Remove a service from Consul")
    dereg_parser.add_argument("public_ip", help="Alias or IP address of the Consul server")
    dereg_parser.add_argument("service_id", help="Service identifier to deregister")

    list_parser = subparsers.add_parser("list", help="List all services registered in Consul")
    list_parser.add_argument("public_ip", help="Alias or IP address of the Consul server")

    list_tr_parser = subparsers.add_parser(
        "list-traefik", help="List all Traefik routers and their configurations"
    )
    list_tr_parser.add_argument("public_ip", help="Alias or IP address of the Traefik server")
    list_tr_parser.add_argument(
        "--traefik-port",
        type=int,
        default=None,
        help="Traefik API port (default: 8087)",
    )

    list_mw_parser = subparsers.add_parser(
        "list-middlewares", help="List all available Traefik middlewares (auth, cors, rate-limiting, etc.)"
    )
    list_mw_parser.add_argument("public_ip", help="Alias or IP address of the Traefik server")
    list_mw_parser.add_argument(
        "--traefik-port",
        type=int,
        default=None,
        help="Traefik API port (default: 8087)",
    )

    alias_parser = subparsers.add_parser("alias", help="Manage server IP aliases for easier command usage")
    alias_sub = alias_parser.add_subparsers(dest="alias_command")
    alias_add = alias_sub.add_parser("add", help="Add a new alias for a server IP")
    alias_add.add_argument("name", help="Alias name (e.g., 'prod', 'staging')")
    alias_add.add_argument("ip", help="IP address to associate with the alias")
    alias_rm = alias_sub.add_parser("remove", help="Remove an existing alias")
    alias_rm.add_argument("name", help="Alias name to remove")
    alias_sub.add_parser("list", help="Show all configured aliases")

    check_parser = subparsers.add_parser("check", help="Check service routing path from DNS to backend")
    check_parser.add_argument("domain", help="Domain name to check (e.g., api.example.com)")

    subparsers.add_parser("version", help="Show version")

    return parser


def _handle_alias(args: argparse.Namespace) -> int:
    if args.alias_command == "add":
        add_alias(args.name, args.ip)
    elif args.alias_command == "remove":
        try:
            remove_alias(args.name)
        except KeyError as e:
            print(e)
            return EXIT_GENERAL
    elif args.alias_command == "list":
        list_aliases()
    else:
        print("Invalid alias subcommand. Use: add, remove, or list.")
        return EXIT_GENERAL
    return EXIT_OK


def _handle_register(args: argparse.Namespace) -> int:
    if not args.domains and not args.custom_rule:
        print("Error: Must provide at least one domain or --custom-rule.")
        return EXIT_VALIDATION

    register_service(
        public_ip=args.public_ip,
        service_id=args.service_id,
        service_name=args.service_name,
        address=args.address,
        port=args.port,
        domains=args.domains,
        middlewares=args.middlewares,
        https_insecure=args.https_insecure,
        custom_rule=args.custom_rule,
        disable_tls=args.disable_tls,
        servers_transport=args.servers_transport,
        resolver=args.resolver,
    )
    return EXIT_OK


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(EXIT_GENERAL)

    try:
        if args.command == "version":
            print(f"version: {__version__}")
            sys.exit(EXIT_OK)

        if args.command == "alias":
            sys.exit(_handle_alias(args))

        if args.command == "register":
            sys.exit(_handle_register(args))

        if args.command == "deregister":
            deregister_service(args.public_ip, args.service_id)

        if args.command == "list":
            list_services(args.public_ip)

        if args.command == "list-traefik":
            port_kwargs = {}
            if getattr(args, "traefik_port", None):
                port_kwargs["api_port"] = args.traefik_port
            list_routers(args.public_ip, **port_kwargs)

        if args.command == "list-middlewares":
            port_kwargs = {}
            if getattr(args, "traefik_port", None):
                port_kwargs["api_port"] = args.traefik_port
            list_middlewares(args.public_ip, **port_kwargs)

        if args.command == "check":
            check_service(args.domain)

    except TFCommanderError as e:
        print(f"Error: {e}")
        sys.exit(EXIT_GENERAL)
    except KeyboardInterrupt:
        print("\nAborted.")
        sys.exit(130)


if __name__ == "__main__":
    main()
