"""Gateway channel adapters."""
