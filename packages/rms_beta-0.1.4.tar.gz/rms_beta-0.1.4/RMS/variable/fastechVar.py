import sys
import os
import platform
import time

from ..cdrutils.log import CDRLog 
from ..const.event import Event
from typing import Callable, Any
from ..data.mainData import MainData

from ..variable.include_x64.FAS_EziMOTIONPlusE import *
from ..variable.include_x64.MOTION_DEFINE import *
from ..variable.include_x64.ReturnCodes_Define import *
from ..variable.include_x64.MOTION_EziSERVO2_DEFINE import *

import threading

class FastechVar:

    def __init__(self, eventCallback:Callable[[int, Any], None], nBdID=1, name=None) :

        self.__eventCallback    :Callable[[int], None]  = eventCallback
        self.BoardID = nBdID
        self.name = name
        self.ip_addr: str | None = None
        self.EZI_AXISSTATUS = None
        
        # --- 추가: 소켓/DLL 호출 직렬화용 락 251021
        self.__io_lock = threading.RLock()
        #self.__is_connected = False
        
    def __del__(self) :
        self.moveStop()  # 축의 이동을 중지
        self.setServoOff()  # 서보를 끔
        self.close()
        CDRLog.print('FastechVar instance is deleted.')
        
    

    def connect(self, addr : str, Id : int, boardType : str = 'MOTION2') -> bool:
        bSuccess = True
        self.ip_addr = addr
        self.BoardID = Id
        if boardType == 'MOTION2':
            self.EZI_AXISSTATUS = EZISERVO2_AXISSTATUS
            
        byIP = [int(x) for x in addr.split('.')]
        with self.__io_lock:
            if FAS_Connect(byIP[0], byIP[1], byIP[2], byIP[3], self.BoardID) == 0:
                CDRLog.print("FASTECH Connection Fail!")
                bSuccess = False


            if bSuccess:
                #FAS_SetAutoReconnect(True) #251022 mini 자동 재접속 설정
                CDRLog.print("FASTECH Connected successfully.")
            return bSuccess


    def setServoOn(self) -> bool:
        with self.__io_lock:
            status_result, axis_status = FAS_GetAxisStatus(self.BoardID)
            if status_result != FMM_OK:
                CDRLog.print("Function(FAS_GetAxisStatus) was failed.")
                return False

            if (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) == 0:
                if FAS_ServoEnable(self.BoardID, 1) != FMM_OK:
                    CDRLog.print("Function(FAS_ServoEnable) was failed.")
                    return False

                while (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) == 0:
                    time.sleep(0.001)
                    status_result, axis_status = FAS_GetAxisStatus(self.BoardID)
                    if status_result != FMM_OK:
                        CDRLog.print("Function(FAS_GetAxisStatus) was failed.")
                        return False
                    if (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) != 0:
                        CDRLog.print("Servo ON")
            else:
                CDRLog.print("Servo is already ON")
            return True

    def setServoOff(self) -> bool:
        with self.__io_lock:
            status_result, axis_status = FAS_GetAxisStatus(self.BoardID)
            if status_result != FMM_OK:
                CDRLog.print("Function(FAS_GetAxisStatus) was failed.")
                return False

            if (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) != 0:
                if FAS_ServoEnable(self.BoardID, 0) != FMM_OK:
                    CDRLog.print("Function(FAS_ServoEnable) was failed.")
                    return False

                while (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) != 0:
                    time.sleep(0.001)
                    status_result, axis_status = FAS_GetAxisStatus(self.BoardID)
                    if status_result != FMM_OK:
                        CDRLog.print("Function(FAS_GetAxisStatus) was failed.")
                        return False
                    if (axis_status & self.EZI_AXISSTATUS.FFLAG_SERVOON) == 0:
                        CDRLog.print("Servo OFF")
            else:
                CDRLog.print("Servo is already OFF")
            return True
    def moveIncPos(self, pulse : int , velocity : int) -> bool:
        """
        축을 지정된 펄스만큼 이동. (상대 위치 이동)
        :param pulse: 이동할 펄스 수
        :param velocity: 이동 속도 (양수)
        """
        nIncPos = pulse
        nVelocity = velocity
        with self.__io_lock:
            if FAS_MoveSingleAxisIncPos(self.BoardID, nIncPos, nVelocity) != FMM_OK:
                CDRLog.print("Function(FAS_MoveSingleAxisIncPos) was failed.")
                return False

            CDRLog.print(f"Move Inc Pos : {nIncPos} / {nVelocity}")
            return True
    
    def moveAbsPos(self, TargetPos : int , TargetVeloc : int) -> bool:
        """
        축을 지정된 절대 위치로 이동
        :param TargetPos: 목표 위치 (절대 위치, 펄스)
        :param TargetVeloc: 목표 속도 (양수)
        """
        nTargetPos : int = int(round(TargetPos))
        nTargetVeloc : int = int(round(TargetVeloc))
        with self.__io_lock:
            if FAS_MoveSingleAxisAbsPos(self.BoardID, nTargetPos, nTargetVeloc) != FMM_OK:
                CDRLog.print("Function(FAS_MoveSingleAxisAbsPos) was failed.")
                return False
            
    

            #CDRLog.print(f"Move Abs Pos : {nTargetPos} / {nTargetVeloc}")
            return True
    
    def moveVelocity(self, Dir: int, TargetVeloc : int) -> bool:
        """
        축을 지정된 속도로 이동
        :param Dir: 이동 방향 (1: 양방향, 0: 음방향)
        :param TargetVeloc: 목표 속도 (양수)
        """
        nTargetVeloc = TargetVeloc
        nDirect = Dir
        with self.__io_lock:
            if FAS_MoveVelocity(self.BoardID, nTargetVeloc, nDirect) != FMM_OK:
                CDRLog.print("Function(FAS_MoveVelocity) was failed.")
                return False

            CDRLog.print(f"Move Velocity : {nTargetVeloc} / {nDirect}")

            return True
    
    def moveStop(self) -> bool:
        """
        축의 이동을 중지
        """
        with self.__io_lock:
            if FAS_MoveStop(self.BoardID) != FMM_OK:
                CDRLog.print("Function(FAS_MoveStop) was failed.")

                return False
            # while True:
            #     time.sleep(0.001)
            #     status_result, axis_status = FAS_GetAxisStatus(self.BoardID)
            #     if status_result == FMM_OK and axis_status & self.EZI_AXISSTATUS.FFLAG_MOTIONING == 0:
            #         CDRLog.print("Move Stop!")
            #         break
            return True
        
    def emgStop(self) -> bool:
        """
        축의 비상 정지
        """
        with self.__io_lock:
            if FAS_EmergencyStop(self.BoardID) != FMM_OK:
                CDRLog.print("Function(FAS_EmergencyStop) was failed.")
                return False
            return True

    
    def moveOrigin(self) -> bool:
        """
        축을 원점(Origin)으로 이동
        :return: 성공 시 True, 실패 시 False
        """
        with self.__io_lock:
            if FAS_MoveOriginSingleAxis(self.BoardID) != FMM_OK:
                CDRLog.print("Function(FAS_MoveOriginSingleAxis) was failed.")
                return False
            return True
        
    def setIOOutput(self, Index : int, OnOff : int) -> bool:
        """
        출력 포트 상태를 설정
        :param Index: 출력 포트 인덱스 (1~8)
        :param OnOff: 출력 상태 (1: ON, 0: OFF)
        :return: 성공 시 True, 실패 시 False
 
        """
        if Index == 1:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT0
        elif Index == 2:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT1
        elif Index == 3:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT2
        elif Index == 4:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT3
        elif Index == 5:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT4
        elif Index == 6:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT5
        elif Index == 7:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT6
        elif Index == 8:
            dwOutputMask = SERVO2_OUT_BITMASK_USEROUT7
            
        else:
            CDRLog.print("setIOOutput - Invalid Index")
            return False
        
        
        with self.__io_lock:
            if FAS_SetIOOutput(self.BoardID, dwOutputMask, OnOff) != FMM_OK:
                CDRLog.print(f"Function(FAS_SetIOOutput) was failed. BoardID: {self.BoardID}, Index: {Index}, OnOff: {OnOff}")

    def getIoInput(self,Index : int) -> int | None:
        """
        입력 포트 상태를 읽어옴
        :return: 입력 포트 상태 (int), 실패 시 None
        
        SERVO2_IN_BITMASK_LIMITP = 0x00000001  #Limit +
        SERVO2_IN_BITMASK_LIMITN = 0x00000002  #Limit -
        SERVO2_IN_BITMASK_ORIGIN = 0x00000004  #Origin
        """
        if Index == 1:
            dwInputMask = SERVO2_IN_BITMASK_LIMITP
        elif Index == 2:
            dwInputMask = SERVO2_IN_BITMASK_LIMITN
        elif Index == 3:
            dwInputMask = SERVO2_IN_BITMASK_ORIGIN
        elif Index == 10: #260303
            dwInputMask = SERVO2_IN_BITMASK_USERIN0
        elif Index == 11:
            dwInputMask = SERVO2_IN_BITMASK_USERIN1
        elif Index == 12:
            dwInputMask = SERVO2_IN_BITMASK_USERIN2
        elif Index == 13:
            dwInputMask = SERVO2_IN_BITMASK_USERIN3
        elif Index == 14:
            dwInputMask = SERVO2_IN_BITMASK_USERIN4
        elif Index == 15:
            dwInputMask = SERVO2_IN_BITMASK_USERIN5
        elif Index == 16:
            dwInputMask = SERVO2_IN_BITMASK_USERIN6
        elif Index == 17:
            dwInputMask = SERVO2_IN_BITMASK_USERIN7
        elif Index == 18:
            dwInputMask = SERVO2_IN_BITMASK_USERIN8
            
        else:
            CDRLog.print("getIoInput - Invalid Index")
            return None
        with self.__io_lock:
            status_result, io_input = FAS_GetIOInput(self.BoardID)
            if status_result != FMM_OK:
                CDRLog.print(f"Function(FAS_GetIOInput) was failed. BoardID: {self.BoardID}")
                return None

            if io_input & dwInputMask:
                #print("INPUT PIN DETECTED.")
                return 1 #True
            else:
                #print("INPUT PIN NOT DETECTED.")
                return 0 #False
        
    def getAxisStatus(self) -> int | None:
        """
        축의 상태를 읽어옴
        :return: 축의 상태 (int), 실패 시 None
        """
        with self.__io_lock:
            try:
                result, axis_status = FAS_GetAxisStatus(self.BoardID)
                if result != FMM_OK:
                    CDRLog.print(f"Function(FAS_GetAxisStatus) was failed. BoardID: {self.BoardID}")
                return (result, axis_status)
            except Exception as e:
                CDRLog.print(f"getAxisStatus exception: {e}")
                return (None, None)
        
    def getActualPos(self) -> int | None:
        """
        축의 실제 위치를 읽어옴
        :return: 축의 실제 위치 (int), 실패 시 None
        """
        with self.__io_lock:
            try:
                result, actual_pos = FAS_GetActualPos(self.BoardID)
                if result != FMM_OK:
                    CDRLog.print(f"Function(FAS_GetActualPos) was failed. BoardID: {self.BoardID}")
                    
                    return None
                return actual_pos
            except Exception as e:
                CDRLog.print(f"getActualPos exception: {e}")
                return None
        
    def getActualVelocity(self) -> int | None:
        """
        축의 실제 속도를 읽어옴
        :return: 축의 실제 속도 (int), 실패 시 None
        """
        with self.__io_lock:
            try:
                result, actual_velocity = FAS_GetActualVel(self.BoardID)
                if result != FMM_OK:
                    CDRLog.print(f"Function(FAS_GetActualVelocity) was failed. BoardID: {self.BoardID}")
                    return None
                return actual_velocity
            except Exception as e:
                CDRLog.print(f"getActualVelocity exception: {e}")
                return None
        
    

    
    def clearPosition(self, ensure_stopped: bool = True, verify: bool = True) -> bool:
        """
        현재 축의 위치를 0으로 초기화 (명령/실제 위치 모두)
        :param ensure_stopped: 초기화 전에 모션 정지 여부
        :param verify: 초기화 후 0으로 되었는지 확인
        :return: 성공 시 True, 실패 시 False
        """
        with self.__io_lock:
            try:
                # 1) 필요하면 먼저 정지
                if ensure_stopped:
                    self.moveStop()

                # 2) ClearPosition 실행
                result = FAS_ClearPosition(self.BoardID)
                if result != FMM_OK:
                    CDRLog.print("Function(FAS_ClearPosition) was failed.")
                    return False

                # 3) (선택) 검증 및 보정
                if verify:
                    r1, cmd = FAS_GetCommandPos(self.BoardID)
                    r2, act = FAS_GetActualPos(self.BoardID)

                    if r1 == FMM_OK and r2 == FMM_OK and (cmd != 0 or act != 0):
                        # 일부 드라이브에서 즉시 반영이 안 될 수 있어 보정
                        FAS_SetCommandPos(self.BoardID, 0)
                        FAS_SetActualPos(self.BoardID, 0)
                return True

            except Exception as e:
                CDRLog.print(f"clearPosition exception: {e}. boardID: {self.BoardID}")
                return False
        
    def servoAlarmReset(self) -> int:
        """
        서보 알람 리셋 원시 호출 (리턴코드 그대로 반환)
        :return: DLL 리턴코드 (FMM_OK==0)
        """
        with self.__io_lock:
            return FAS_ServoAlarmReset(self.BoardID)  # 원시 호출
        
        
        
    def waitForMotionDone(self, timeout_ms: int = 10000) -> bool:
        """
        모션 완료 대기 (지정된 시간 내에 모션이 완료되면 True, 그렇지 않으면 False)
        :param timeout_ms: 타임아웃 시간 (밀리초)
        :return: 모션 완료 여부 (True/False)
        """
        start_time = time.time()
        while True:
            time.sleep(0.01)  # 10ms 간격으로 상태 확인
            status_result, axis_status = self.getAxisStatus()
            if status_result == FMM_OK :
                if not (axis_status & self.EZI_AXISSTATUS.FFLAG_MOTIONING) and (
                    axis_status & self.EZI_AXISSTATUS.FFLAG_INPOSITION):
                    CDRLog.print("Motion Done!")
                    return True  # 모션 완료
            if (time.time() - start_time) * 1000 > timeout_ms:
                CDRLog.print("Motion wait timeout!")
                return False  # 타임아웃

    def close(self):
        """
        FastechVar 객체를 닫고 연결을 종료
        """
        CDRLog.print("FastechVar close")
        FAS_Close(self.BoardID)


    # def check_drive_err(self) -> bool:
    #     status_result, axis_status = FAS_GetAxisStatus(self.nBdID)
    #     if status_result != FMM_OK:
    #         print("Function(FAS_GetAxisStatus) was failed.")
    #         return False

    #     if axis_status & EZISERVO2_AXISSTATUS.FFLAG_ERRORALL:
    #         if FAS_ServoAlarmReset(self.nBdID) != FMM_OK:
    #             print("Function(FAS_ServoAlarmReset) was failed.")
    #             return False
    #     return True