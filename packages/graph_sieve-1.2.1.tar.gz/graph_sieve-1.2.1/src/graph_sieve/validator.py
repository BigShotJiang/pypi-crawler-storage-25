import re
from typing import List, Dict, Any, Optional
import difflib
from difflib import SequenceMatcher
from .llm_client import get_llm_client
from .prompts import VALIDATOR_SYSTEM_TEMPLATE

def normalize_text_for_comparison(text: str) -> str:
    """
    Standardizes text to handle OCR noise and formatting differences.
    Now includes Hebrew-specific normalization for Sofit letters.
    """
    if not text:
        return ""
    
    # Lowercase for case-insensitive matching (English)
    text = text.lower()
    
    # 1. Standardize quotes and other symbols
    text = text.replace('"', "'").replace("`", "'").replace("“", "'").replace("”", "'").replace("‘", "'").replace("’", "'")
    
    # 2. Handle common OCR swaps
    ocr_map = {
        '0': 'o',
        '1': 'l',
        'i': 'l',
        '5': 's',
        '8': 'b',
        '2': 'z',
        '9': 'g',
    }
    for char, replacement in ocr_map.items():
        text = text.replace(char, replacement)
        
    # 3. Hebrew Sofit (Final letters) normalization
    # Map final letters to their non-final counterparts to handle LLM/OCR confusion
    sofit_map = {
        'ך': 'כ',
        'ם': 'מ',
        'ן': 'נ',
        'ף': 'פ',
        'ץ': 'צ',
    }
    for char, replacement in sofit_map.items():
        text = text.replace(char, replacement)
    
    # 4. Normalize whitespace: collapse all whitespace (including newlines) to single spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def verify_anchor_exists(raw_text: str, anchor: str, threshold: float = 0.7) -> bool:
    """
    Deterministic hard-check to ensure the anchor exists in the raw text.
    Handles minor OCR noise and BIDI issues (Visual vs Logical order).
    """
    if not anchor:
        return False
    
    clean_anchor = anchor.strip()
    
    # 1. Exact match (Logical)
    if clean_anchor in raw_text:
        return True
    
    # 2. Visual-Order Check for Hebrew (Pitfall Fix)
    # If the source text is in visual order, searching for a logical anchor will fail.
    # We try both word-level reversal and full-string reversal.
    from .hebrew_utils import is_hebrew, normalize_rtl_text
    if is_hebrew(clean_anchor):
        # Word-level reversal (e.g. "הפרויקט שלנו" -> "טקיורפה ונלש")
        visual_anchor_words = normalize_rtl_text(clean_anchor, for_llm=False)
        if visual_anchor_words in raw_text:
            return True
            
        # Full-string reversal (e.g. "הפרויקט שלנו" -> "ונלש טקיורפה")
        visual_anchor_full = clean_anchor[::-1]
        if visual_anchor_full in raw_text:
            return True
    
    # 3. Normalization-based check (Handles OCR noise and Sofit letters)
    norm_anchor = normalize_text_for_comparison(clean_anchor)
    norm_text = normalize_text_for_comparison(raw_text)
    
    if norm_anchor in norm_text:
        return True
    
    # 4. Visual-Order Normalization Check
    if is_hebrew(clean_anchor):
        # Try normalization on the reversed versions too
        visual_norm_words = normalize_text_for_comparison(normalize_rtl_text(clean_anchor, for_llm=False))
        if visual_norm_words in norm_text:
            return True
            
        visual_norm_full = normalize_text_for_comparison(clean_anchor[::-1])
        if visual_norm_full in norm_text:
            return True
    
    # 5. Fuzzy fallback with sliding window on normalized text
    anchor_len = len(norm_anchor)
    window_size = int(anchor_len * 1.2)
    step = max(1, anchor_len // 4)
    
    for i in range(0, len(norm_text) - anchor_len + 1, step):
        window = norm_text[i : i + window_size]
        s = SequenceMatcher(None, norm_anchor, window)
        if s.ratio() >= threshold:
            return True
            
    return False

def validate_with_llm(raw_text: str, extraction: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates an extraction using a local LLM with an initial hard-anchor check.
    """
    anchor = extraction.get("anchor", "")
    
    # 1. Hard-Anchor Verification (Pitfall 1 Fix)
    if not verify_anchor_exists(raw_text, anchor):
        return {
            "is_valid": False,
            "confidence_level": "PENDING",
            "status": "HALLUCINATION",
            "reasoning": "Hard-Anchor Verification Failed: The provided quote does not exist in the source text.",
            "suggested_fix": None
        }

    # 2. LLM Logical Validation
    client = get_llm_client()
    messages = [
        {"role": "system", "content": VALIDATOR_SYSTEM_TEMPLATE},
        {"role": "user", "content": f"Raw Context:\n{raw_text}\n\nProposed Extraction:\n{extraction}"}
    ]
    
    return client.chat(messages, json_mode=True)

def batch_validate_with_llm(raw_text: str, extractions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Validates multiple extractions in parallel.
    Performs hard-anchor check first, then batches LLM calls.
    """
    if not extractions:
        return []

    from .llm_client import get_llm_client
    from .prompts import VALIDATOR_SYSTEM_TEMPLATE
    
    results = [None] * len(extractions)
    llm_indices = []
    llm_messages = []
    
    # 1. Hard-Anchor Verification (Parallelizable if needed, but fast enough sync)
    for i, extraction in enumerate(extractions):
        anchor = extraction.get("anchor", "")
        if not verify_anchor_exists(raw_text, anchor):
            results[i] = {
                "is_valid": False,
                "confidence_level": "PENDING",
                "status": "HALLUCINATION",
                "reasoning": "Hard-Anchor Verification Failed: The provided quote does not exist in the source text.",
                "suggested_fix": None
            }
        else:
            llm_indices.append(i)
            llm_messages.append([
                {"role": "system", "content": VALIDATOR_SYSTEM_TEMPLATE},
                {"role": "user", "content": f"Raw Context:\n{raw_text}\n\nProposed Extraction:\n{extraction}"}
            ])
            
    # 2. Batch LLM Logical Validation
    if llm_messages:
        client = get_llm_client()
        batch_results = client.batch_chat_sync(llm_messages, json_mode=True)
        for i, res in enumerate(batch_results):
            results[llm_indices[i]] = res
            
    return results
