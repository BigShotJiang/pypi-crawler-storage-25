import hashlib
import json
import os
from typing import Dict
from .config import settings

class HashStore:
    """
    Stores SHA-256 hashes of processed files to prevent redundant LLM calls.
    """
    def __init__(self, file_path: str = None):
        if file_path is None:
            settings.ensure_dirs()
            file_path = str(settings.hashes_path)
        self.file_path = file_path
        self.hashes: Dict[str, str] = self._load()

    def _load(self) -> Dict[str, str]:
        if not os.path.exists(self.file_path):
            os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
            return {}
        with open(self.file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save(self):
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(self.hashes, f, indent=2)

    def get_hash(self, file_path: str) -> str:
        """
        Calculates SHA-256 hash of a file.
        """
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def has_changed(self, file_path: str) -> bool:
        """
        Returns True if the file has changed or is new.
        Uses a 'soft' check (mtime + size) before calculating the full SHA-256 hash.
        """
        if not os.path.exists(file_path):
            return False
            
        stats = os.stat(file_path)
        # Soft key combines path, size, and modification time
        soft_key = f"{file_path}|{stats.st_size}|{stats.st_mtime}"
        
        # We store the soft key in a separate dict to avoid full hash calculation
        if not hasattr(self, '_soft_hashes'):
            self._soft_hashes = {}
            
        if self._soft_hashes.get(file_path) == soft_key:
            return False
            
        # If soft check fails, calculate full hash
        current_hash = self.get_hash(file_path)
        old_hash = self.hashes.get(file_path)
        
        if current_hash != old_hash:
            # We don't update self.hashes here anymore; 
            # we let the agent update it after successful processing.
            self._soft_hashes[file_path] = soft_key
            return True
            
        # If full hash matches but soft check failed (e.g. mtime changed but content didn't),
        # update soft key and return False.
        self._soft_hashes[file_path] = soft_key
        return False

    def update_hash(self, file_path: str):
        """
        Updates the stored hash for a file. 
        Should be called after successful processing.
        """
        if os.path.exists(file_path):
            self.hashes[file_path] = self.get_hash(file_path)

def calculate_chunk_hash(text: str) -> str:
    """
    Calculates SHA-256 hash of a text chunk.
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
