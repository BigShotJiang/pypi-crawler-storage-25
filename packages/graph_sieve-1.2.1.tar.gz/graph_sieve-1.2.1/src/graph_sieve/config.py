import os
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from platformdirs import user_data_dir

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", 
        env_file_encoding="utf-8", 
        extra="ignore"
    )

    # LLM Settings
    llm_provider: str = "openai"  # openai, ollama, vllm
    openai_api_key: Optional[str] = None
    ollama_base_url: str = "http://localhost:11434"
    model_name: str = "gpt-4o-mini"
    embedding_model: str = "text-embedding-3-small"
    max_parallel_requests: int = 5

    # Storage Settings
    storage_dir: Path = Path(user_data_dir("graph-sieve", "graph-sieve"))

    @property
    def hashes_path(self) -> Path:
        return self.storage_dir / "hashes.json"

    @property
    def db_path(self) -> Path:
        return self.storage_dir / "graph_sieve.db"

    def ensure_dirs(self):
        """Ensure that the storage directory exists."""
        self.storage_dir.mkdir(parents=True, exist_ok=True)

settings = Settings()
