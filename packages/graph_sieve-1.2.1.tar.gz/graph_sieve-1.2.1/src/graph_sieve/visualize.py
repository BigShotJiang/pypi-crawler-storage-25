import sys
import os
import argparse
from .storage_sqlite import SQLiteStorage
from .graph_engine import GraphKnowledgeEngine

def main():
    parser = argparse.ArgumentParser(description="Generate an interactive visualization of the knowledge graph.")
    parser.add_argument("--db", help="Path to the SQLite database. If not provided, uses the default from settings.")
    parser.add_argument("--output", help="Path to the output HTML file. Default: graph.html in storage directory.")

    args = parser.parse_args()

    print(f"Connecting to database...")
    storage = SQLiteStorage(db_path=args.db) if args.db else SQLiteStorage()
    
    print("Initializing Graph Engine...")
    engine = GraphKnowledgeEngine(storage=storage)
    
    print("Generating interactive visualization...")
    engine.visualize_graph(args.output)

if __name__ == "__main__":
    main()
