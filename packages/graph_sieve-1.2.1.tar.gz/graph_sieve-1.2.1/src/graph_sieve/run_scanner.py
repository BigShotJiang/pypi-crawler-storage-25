import argparse
import os
import json
import sys
from graph_sieve.agent import DictionaryAgent
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.llm_client import LLMClientError

def run_local_agent(scan_path: str, db_path: str = None, 
                    seed_path: str = None, whitelist_path: str = None, 
                    retry_failed: bool = False):
    """
    Runs the full Selective Knowledge Pipeline on a local directory.
    """
    if scan_path and not os.path.exists(scan_path):
        print(f"Error: Scan path '{scan_path}' does not exist.")
        return

    # Load whitelist if provided
    whitelist = []
    if whitelist_path and os.path.exists(whitelist_path):
        with open(whitelist_path, "r", encoding="utf-8") as f:
            whitelist = [line.strip() for line in f if line.strip()]

    # Initialize Agent
    storage = SQLiteStorage(db_path=db_path) if db_path else SQLiteStorage()
    agent = DictionaryAgent(
        storage=storage,
        whitelist=whitelist,
        seed_paths=[seed_path] if seed_path else []
    )

    if retry_failed:
        print("--- Retrying Failed Chunks from DLQ ---")
        success = agent.retry_failed_chunks()
        print(f"Successfully processed {success} chunks from DLQ.")
        if not scan_path:
            return

    print(f"--- Starting Dictionary Agent ---")
    print(f"Target: {scan_path}")
    print(f"Database: {db_path or 'Default'}")
    if seed_path:
        print(f"Seeds: {seed_path}")

    # Process
    added_terms = agent.process_directory(scan_path)

    # Final summary of dictionary
    print(agent.generate_summary())
    print(f"Extraction complete.")

def main():
    parser = argparse.ArgumentParser(description="Run the Selective Knowledge Dictionary Agent locally.")
    parser.add_argument("path", nargs="?", help="Path to the directory to scan.")
    parser.add_argument("--db", help="Path to the SQLite database.")
    parser.add_argument("--seed", help="Optional path to 'Seed' documents (high-authority).")
    parser.add_argument("--whitelist", help="Optional path to a whitelist of terms to always include.")
    parser.add_argument("--retry-failed", action="store_true", help="Retry processing failed chunks from the Dead Letter Queue.")

    args = parser.parse_args()

    if not args.path and not args.retry_failed:
        parser.error("Must provide 'path' or use '--retry-failed'.")

    try:
        run_local_agent(args.path, args.db, args.seed, args.whitelist, args.retry_failed)
    except LLMClientError as e:
        print(f"\nConfiguration Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
