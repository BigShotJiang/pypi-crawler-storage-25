import os
import chardet
from typing import List, Iterable, Iterator
from markitdown import MarkItDown
from pyOneNote.OneDocument import OneDocment
from .hebrew_utils import normalize_rtl_text
from .llm_client import get_vlm_client_for_markitdown

def extract_text_from_one(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"OneNote file not found: {file_path}")
        
    text_parts = []
    try:
        with open(file_path, "rb") as file:
            document = OneDocment(file)
            data = document.get_json()
            
            if "properties" in data:
                for propertySet in data["properties"]:
                    if "val" in propertySet:
                        vals = propertySet["val"]
                        
                        # Extract common text properties
                        for key in ["CachedTitleString", "CachedTitleStringFromPage", "RichEditTextUnicode", "TextExtendedAscii"]:
                            if key in vals:
                                val = vals[key]
                                if val and isinstance(val, str):
                                    text_parts.append(val)
    except Exception as e:
        print(f"Debug: pyOneNote extraction failed for {file_path} - {str(e)}")
        return f"[Error extracting {file_path}: {str(e)}]"
        
    if not text_parts:
        return ""
        
    return "\n\n".join(text_parts)


def extract_text_from_txt(file_path: str, chunk_read_size: int = 65536) -> Iterator[str]:
    """
    Reads text file in chunks to avoid loading everything at once.
    Yields blocks of text.
    """
    print(f"Debug: Entering extract_text_from_txt for {file_path}")
    
    # Check encoding once
    with open(file_path, "rb") as f:
        raw_header = f.read(4096)
    
    encoding = 'utf-8'
    for enc in ['utf-8', 'windows-1255', 'iso-8859-8']:
        try:
            raw_header.decode(enc)
            encoding = enc
            break
        except UnicodeDecodeError:
            continue
            
    if encoding == 'utf-8':
        try:
            detected = chardet.detect(raw_header)
            encoding = detected['encoding'] or 'utf-8'
        except:
            pass

    with open(file_path, "r", encoding=encoding, errors='replace') as f:
        while True:
            data = f.read(chunk_read_size)
            if not data:
                break
            yield data


def chunk_text_stream(text_stream: Iterable[str], file_path: str, 
                      chunk_size: int = 1200, overlap: int = 200) -> Iterator[str]:
    """
    Consumes an iterator of text blocks and yields chunks of roughly `chunk_size`.
    Maintains overlap to preserve relationships across boundaries.
    """
    filename = os.path.basename(file_path)
    metadata = f"[Context: Source File: {filename}]\n\n"
    
    buffer = ""
    for block in text_stream:
        buffer += block
        
        # Process buffer while it has enough data for a chunk plus lookahead
        # We need a bit more than chunk_size to find a good break point
        while len(buffer) >= chunk_size + overlap:
            # Find natural break point (paragraph or sentence) within the chunk_size limit
            end = chunk_size
            
            # Look for last paragraph break in the window
            last_break = buffer.rfind('\n\n', 0, end)
            if last_break != -1 and last_break >= (chunk_size // 2):
                end = last_break + 2
            else:
                # Look for last sentence break (. , ? , ! )
                last_sentence = -1
                for terminator in ['. ', '? ', '! ']:
                    pos = buffer.rfind(terminator, 0, end)
                    if pos > last_sentence:
                        last_sentence = pos
                
                if last_sentence != -1 and last_sentence >= (chunk_size // 2):
                    end = last_sentence + 2
                else:
                    # Fallback: Look for last whitespace to avoid splitting words
                    last_space = buffer.rfind(' ', 0, end)
                    if last_space != -1 and last_space >= (chunk_size // 2):
                        end = last_space + 1
            
            chunk_content = buffer[:end].strip()
            if chunk_content:
                yield metadata + chunk_content
            
            # Keep the overlap part in the buffer
            buffer = buffer[end - overlap:]
            
    # Yield remaining content
    if buffer.strip():
        yield metadata + buffer.strip()

def extract_all(file_path: str) -> Iterator[str]:
    """Unified interface returning an iterator of extracted text blocks."""
    if not os.path.exists(file_path):
        yield f"[Error: File not found {file_path}]"
        return

    ext = os.path.splitext(file_path)[1].lower()
    
    # Handle specific formats that might need special care
    if ext == ".one":
        yield normalize_rtl_text(extract_text_from_one(file_path))
        return
    elif ext == ".txt" or ext == ".log": # Handle plain text formats with streaming
        try:
            # Note: normalize_rtl_text currently expects the whole string.
            # For streaming, we yield chunks. If for_llm=True (default), it's a no-op anyway.
            # If we ever need visual normalization for streaming, we'd need a more complex approach.
            for chunk in extract_text_from_txt(file_path):
                yield normalize_rtl_text(chunk)
            return
        except Exception as e:
            print(f"Debug: Custom text extraction failed for {file_path} - {str(e)}")
            # Fall through to MarkItDown if custom extraction fails

    # List of common extensions supported by MarkItDown
    supported_extensions = {
        '.pdf', '.docx', '.doc', '.pptx', '.ppt', '.xlsx', '.xls', 
        '.msg', '.html', '.htm', '.csv', '.json', '.xml', 
        '.txt', '.log', '.md', '.rtf'
    }

    if ext not in supported_extensions:
        print(f"Debug: Skipping unsupported file format: {ext} ({file_path})")
        return

    # Initialize MarkItDown with VLM support
    vlm_client = get_vlm_client_for_markitdown()
    vlm_model = os.getenv("VLLM_VLM_MODEL", "pixtral-12b")
    md = MarkItDown(llm_client=vlm_client, llm_model=vlm_model)

    try:
        result = md.convert(file_path)
        yield normalize_rtl_text(result.text_content)
    except Exception as e:
        # Fallback for plain text or unsupported types if md fails
        try:
            for chunk in extract_text_from_txt(file_path):
                yield normalize_rtl_text(chunk)
        except Exception:
            print(f"Debug: Extraction failed for {ext} ({file_path}) - {str(e)}")
            return
