import sqlite3
import json
from pathlib import Path
from contextlib import closing
from typing import List, Optional, Dict, Any
from .models import (
    DictionaryEntry, 
    GraphTriplet, 
    CommunityReport, 
    GlobalReport, 
    UsageExample,
    LLMLogEntry
)
from .config import settings

class SQLiteStorage:
    """
    Relational storage for graph-sieve data using SQLite.
    Handles table creation and low-level SQL operations with JSON support.
    """
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or settings.db_path
        self._init_db()

    def _get_connection(self):
        """Get a SQLite connection with row factory for dictionary access."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_db(self):
        """Initialize the database schema with WAL mode and necessary tables."""
        settings.ensure_dirs()
        with closing(self._get_connection()) as conn:
            # Enable WAL mode for better concurrency and performance
            conn.execute("PRAGMA journal_mode=WAL;")
            
            with conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS entries (
                        term TEXT PRIMARY KEY,
                        canonical_id TEXT,
                        overview TEXT,
                        deep_dive TEXT,
                        entity_type TEXT,
                        related_terms TEXT,  -- JSON
                        is_golden BOOLEAN,
                        status TEXT,
                        authority_level TEXT,
                        confidence_level TEXT,
                        last_seen TEXT,
                        document_count INTEGER,
                        is_bounty BOOLEAN
                    )
                """)
                # Migration: Add canonical_id if it doesn't exist
                cursor = conn.execute("PRAGMA table_info(entries)")
                columns = [row['name'] for row in cursor.fetchall()]
                if 'canonical_id' not in columns:
                    conn.execute("ALTER TABLE entries ADD COLUMN canonical_id TEXT")
                
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS usage_examples (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        term TEXT,
                        source_file TEXT,
                        context TEXT,
                        date_added TEXT,
                        FOREIGN KEY(term) REFERENCES entries(term) ON DELETE CASCADE
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_term ON usage_examples (term)")

                conn.execute("""
                    CREATE TABLE IF NOT EXISTS relationships (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        subject TEXT,
                        relationship TEXT,
                        object TEXT,
                        weight REAL,
                        date_added TEXT,
                        status TEXT,
                        UNIQUE(subject, relationship, object)
                    )
                """)

                conn.execute("""
                    CREATE TABLE IF NOT EXISTS relationship_evidence (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        relationship_id INTEGER,
                        source_file TEXT,
                        anchor TEXT,
                        date_added TEXT,
                        FOREIGN KEY(relationship_id) REFERENCES relationships(id) ON DELETE CASCADE
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_rel_evidence_id ON relationship_evidence (relationship_id)")
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS community_reports (
                        community_id TEXT PRIMARY KEY,
                        title TEXT,
                        summary TEXT,
                        nodes TEXT, -- JSON
                        last_updated TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS global_report (
                        id INTEGER PRIMARY KEY CHECK (id = 1),
                        summary TEXT,
                        key_themes TEXT, -- JSON
                        last_updated TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS chunk_cache (
                        chunk_hash TEXT PRIMARY KEY,
                        extracted_data TEXT, -- JSON representation
                        date_added TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS aliases (
                        alias TEXT PRIMARY KEY,
                        canonical_id TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS dlq_failed_chunks (
                        chunk_hash TEXT PRIMARY KEY,
                        chunk_data TEXT,
                        error_reason TEXT,
                        retries INTEGER DEFAULT 0,
                        date_added TEXT,
                        source_file TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS llm_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT,
                        provider TEXT,
                        model TEXT,
                        endpoint TEXT,
                        prompt TEXT,
                        response TEXT,
                        latency_ms REAL,
                        prompt_tokens INTEGER,
                        completion_tokens INTEGER,
                        total_tokens INTEGER,
                        cost REAL,
                        status TEXT,
                        error_message TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS file_cache (
                        file_hash TEXT PRIMARY KEY,
                        extracted_text TEXT,
                        date_added TEXT
                    )
                """)
                # Create indexes for relationships
                conn.execute("CREATE INDEX IF NOT EXISTS idx_rel_subject ON relationships (subject)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_rel_object ON relationships (object)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_llm_logs_timestamp ON llm_logs (timestamp)")

    def _row_to_entry(self, row: sqlite3.Row, conn: Optional[sqlite3.Connection] = None) -> DictionaryEntry:
        """Convert a database row to a DictionaryEntry, optionally fetching usage examples."""
        data = dict(row)
        term = data['term']
        
        # Fetch usage examples from the relational table
        if conn:
            usage_rows = conn.execute(
                "SELECT context, source_file, date_added FROM usage_examples WHERE term = ?",
                (term,)
            ).fetchall()
        else:
            with closing(self._get_connection()) as new_conn:
                usage_rows = new_conn.execute(
                    "SELECT context, source_file, date_added FROM usage_examples WHERE term = ?",
                    (term,)
                ).fetchall()
                
        data['usage_examples'] = [
            UsageExample(context=r['context'], source=r['source_file'], date_added=r['date_added'])
            for r in usage_rows
        ]

        data['related_terms'] = json.loads(data['related_terms'] or '[]')
        data['is_golden'] = bool(data['is_golden'])
        data['is_bounty'] = bool(data['is_bounty'])
        return DictionaryEntry(**data)

    def _row_to_triplet(self, row: sqlite3.Row, conn: Optional[sqlite3.Connection] = None, 
                        evidence_map: Optional[Dict[int, List[Dict[str, Any]]]] = None) -> GraphTriplet:
        """Convert a database row to a GraphTriplet, including evidence."""
        data = dict(row)
        rel_id = data['id']
        
        if evidence_map is not None:
            data['evidence'] = evidence_map.get(rel_id, [])
        else:
            # Fetch evidence from the relational table if not provided
            if conn:
                evidence_rows = conn.execute(
                    "SELECT source_file, anchor, date_added FROM relationship_evidence WHERE relationship_id = ?",
                    (rel_id,)
                ).fetchall()
            else:
                with closing(self._get_connection()) as new_conn:
                    evidence_rows = new_conn.execute(
                        "SELECT source_file, anchor, date_added FROM relationship_evidence WHERE relationship_id = ?",
                        (rel_id,)
                    ).fetchall()
            data['evidence'] = [dict(r) for r in evidence_rows]
            
        return GraphTriplet(**data)

    def _row_to_community_report(self, row: sqlite3.Row) -> CommunityReport:
        """Convert a database row to a CommunityReport."""
        data = dict(row)
        data['nodes'] = json.loads(data['nodes'] or '[]')
        return CommunityReport(**data)

    def _row_to_global_report(self, row: sqlite3.Row) -> GlobalReport:
        """Convert a database row to a GlobalReport."""
        data = dict(row)
        data.pop('id', None)
        data['key_themes'] = json.loads(data['key_themes'] or '[]')
        return GlobalReport(**data)

    def log_llm_interaction(self, entry: LLMLogEntry):
        """Save an LLM interaction log to the database."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT INTO llm_logs (
                        timestamp, provider, model, endpoint, prompt, response,
                        latency_ms, prompt_tokens, completion_tokens, total_tokens,
                        cost, status, error_message
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.timestamp,
                    entry.provider,
                    entry.model,
                    entry.endpoint,
                    entry.prompt,
                    entry.response,
                    entry.latency_ms,
                    entry.prompt_tokens,
                    entry.completion_tokens,
                    entry.total_tokens,
                    entry.cost,
                    entry.status,
                    entry.error_message
                ))

    def upsert_entry(self, entry: DictionaryEntry):
        """Insert or update a dictionary entry (usage_examples handled separately)."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT INTO entries (
                        term, canonical_id, overview, deep_dive, entity_type,
                        related_terms, is_golden, status,
                        authority_level, confidence_level, last_seen,
                        document_count, is_bounty
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(term) DO UPDATE SET
                        canonical_id = excluded.canonical_id,
                        overview = excluded.overview,
                        deep_dive = excluded.deep_dive,
                        entity_type = excluded.entity_type,
                        related_terms = excluded.related_terms,
                        is_golden = excluded.is_golden,
                        status = excluded.status,
                        authority_level = excluded.authority_level,
                        confidence_level = excluded.confidence_level,
                        last_seen = excluded.last_seen,
                        document_count = excluded.document_count,
                        is_bounty = excluded.is_bounty
                """, (
                    entry.term,
                    entry.canonical_id,
                    entry.overview,
                    entry.deep_dive,
                    entry.entity_type,
                    json.dumps(entry.related_terms),
                    1 if entry.is_golden else 0,
                    entry.status,
                    entry.authority_level,
                    entry.confidence_level,
                    entry.last_seen,
                    entry.document_count,
                    1 if entry.is_bounty else 0
                ))

    def add_usage_example(self, term: str, source_file: str, context: str):
        """Add a usage example for a term."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT INTO usage_examples (term, source_file, context, date_added)
                    VALUES (?, ?, ?, ?)
                """, (term, source_file, context, datetime.now().isoformat()))

    def get_entry(self, term: str) -> Optional[DictionaryEntry]:
        """Retrieve a dictionary entry by term."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM entries WHERE term = ?", (term,)).fetchone()
            if not row:
                return None
            return self._row_to_entry(row, conn=conn)

    def get_term_exists(self, term: str) -> bool:
        """Check if a term exists in the entries table."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT 1 FROM entries WHERE term = ?", (term,)).fetchone()
            return row is not None

    def get_bounty_candidates(self, limit: int = 10) -> List[DictionaryEntry]:
        """Retrieve entries marked as bounty candidates."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute(
                "SELECT * FROM entries WHERE is_bounty = 1 LIMIT ?", 
                (limit,)
            ).fetchall()
            return [self._row_to_entry(row, conn=conn) for row in rows]

    def get_active_terms_count(self) -> int:
        """Count terms with 'ACTIVE' status."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT COUNT(*) FROM entries WHERE status = 'ACTIVE'").fetchone()
            return row[0] if row else 0

    def list_entries(self) -> List[DictionaryEntry]:
        """Retrieve all dictionary entries."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM entries").fetchall()
            return [self._row_to_entry(row, conn=conn) for row in rows]

    def get_all_aliases(self) -> Dict[str, str]:
        """Retrieve all explicit alias mappings from the aliases table."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT alias, canonical_id FROM aliases").fetchall()
            return {r['alias']: r['canonical_id'] for r in rows}

    def link_alias(self, alias_term: str, canonical_term: str):
        """
        Updates the entries table to set canonical_id for the alias,
        inserts into the aliases table,
        and inserts an ALIAS_OF triplet into the relationships table with evidence.
        """
        with closing(self._get_connection()) as conn:
            with conn:
                # 1. Update entries table (if entry exists)
                conn.execute(
                    "UPDATE entries SET canonical_id = ? WHERE term = ?",
                    (canonical_term, alias_term)
                )

                # 2. Update/Insert into aliases table
                conn.execute(
                    "INSERT OR REPLACE INTO aliases (alias, canonical_id) VALUES (?, ?)",
                    (alias_term, canonical_term)
                )
                
                # 3. Insert ALIAS_OF triplet
                from .models import GraphTriplet
                triplet = GraphTriplet(
                    subject=alias_term,
                    relationship="ALIAS_OF",
                    object=canonical_term,
                    weight=1.0
                )
                
                # Inline add_relationship logic to avoid nested connections
                cursor = conn.execute("""
                    INSERT OR REPLACE INTO relationships (
                        subject, relationship, object,
                        weight, date_added, status
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    triplet.subject,
                    triplet.relationship,
                    triplet.object,
                    triplet.weight,
                    triplet.date_added,
                    triplet.status
                ))
                rel_id = cursor.lastrowid
                
                # Inline add_relationship_evidence logic
                from datetime import datetime
                conn.execute("""
                    INSERT INTO relationship_evidence (relationship_id, source_file, anchor, date_added)
                    VALUES (?, ?, ?, ?)
                """, (
                    rel_id, 
                    "semantic_resolver", 
                    f"Semantic resolution: {alias_term} is an alias of {canonical_term}",
                    datetime.now().isoformat()
                ))

    def add_relationship(self, triplet: GraphTriplet) -> int:
        """Add a new relationship triplet and return its ID."""
        with closing(self._get_connection()) as conn:
            with conn:
                cursor = conn.execute("""
                    INSERT INTO relationships (
                        subject, relationship, object,
                        weight, date_added, status
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(subject, relationship, object) DO UPDATE SET
                        weight = excluded.weight,
                        status = excluded.status
                """, (
                    triplet.subject,
                    triplet.relationship,
                    triplet.object,
                    triplet.weight,
                    triplet.date_added,
                    triplet.status
                ))
                if cursor.rowcount > 0 and cursor.lastrowid:
                    return cursor.lastrowid
                else:
                    # If conflict occurred and no row was inserted, fetch the ID
                    row = conn.execute(
                        "SELECT id FROM relationships WHERE subject = ? AND relationship = ? AND object = ?",
                        (triplet.subject, triplet.relationship, triplet.object)
                    ).fetchone()
                    return row[0]

    def add_relationship_evidence(self, relationship_id: int, source_file: str, anchor: str):
        """Add evidence (source/anchor) for a relationship."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT INTO relationship_evidence (relationship_id, source_file, anchor, date_added)
                    VALUES (?, ?, ?, ?)
                """, (relationship_id, source_file, anchor, datetime.now().isoformat()))

    def get_relationships_count(self) -> int:
        """Count total relationships."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT COUNT(*) FROM relationships").fetchone()
            return row[0] if row else 0

    def get_relationships(self, subject: Optional[str] = None, object: Optional[str] = None) -> List[GraphTriplet]:
        """Retrieve relationships, optionally filtering by subject or object."""
        query = "SELECT * FROM relationships"
        params = []
        conditions = []
        if subject:
            conditions.append("subject = ?")
            params.append(subject)
        if object:
            conditions.append("object = ?")
            params.append(object)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        with closing(self._get_connection()) as conn:
            rows = conn.execute(query, params).fetchall()
            if not rows:
                return []
            
            # Batch fetch evidence
            rel_ids = [row['id'] for row in rows]
            placeholders = ",".join(["?"] * len(rel_ids))
            evidence_rows = conn.execute(
                f"SELECT relationship_id, source_file, anchor, date_added FROM relationship_evidence WHERE relationship_id IN ({placeholders})",
                rel_ids
            ).fetchall()
            
            evidence_map = {}
            for er in evidence_rows:
                rid = er['relationship_id']
                if rid not in evidence_map:
                    evidence_map[rid] = []
                evidence_map[rid].append({
                    'source_file': er['source_file'],
                    'anchor': er['anchor'],
                    'date_added': er['date_added']
                })
                
            return [self._row_to_triplet(row, conn=conn, evidence_map=evidence_map) for row in rows]


    def get_relationships_for_nodes(self, nodes: List[str]) -> List[GraphTriplet]:
        """
        Optimized retrieval of all relationships where BOTH subject and object 
        belong to the provided list of nodes.
        """
        if not nodes:
            return []
        
        placeholders = ",".join(["?"] * len(nodes))
        query = f"SELECT * FROM relationships WHERE subject IN ({placeholders}) AND object IN ({placeholders})"
        params = nodes + nodes
        
        with closing(self._get_connection()) as conn:
            rows = conn.execute(query, params).fetchall()
            if not rows:
                return []
                
            # Batch fetch evidence
            rel_ids = [row['id'] for row in rows]
            id_placeholders = ",".join(["?"] * len(rel_ids))
            evidence_rows = conn.execute(
                f"SELECT relationship_id, source_file, anchor, date_added FROM relationship_evidence WHERE relationship_id IN ({id_placeholders})",
                rel_ids
            ).fetchall()
            
            evidence_map = {}
            for er in evidence_rows:
                rid = er['relationship_id']
                if rid not in evidence_map:
                    evidence_map[rid] = []
                evidence_map[rid].append({
                    'source_file': er['source_file'],
                    'anchor': er['anchor'],
                    'date_added': er['date_added']
                })
                
            return [self._row_to_triplet(row, conn=conn, evidence_map=evidence_map) for row in rows]

    def upsert_community_report(self, report: CommunityReport):
        """Insert or update a community report."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO community_reports (
                        community_id, title, summary, nodes, last_updated
                    ) VALUES (?, ?, ?, ?, ?)
                """, (
                    report.community_id,
                    report.title,
                    report.summary,
                    json.dumps(report.nodes),
                    report.last_updated
                ))

    def get_community_report(self, community_id: str) -> Optional[CommunityReport]:
        """Retrieve a community report by ID."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM community_reports WHERE community_id = ?", (community_id,)).fetchone()
            if not row:
                return None
            return self._row_to_community_report(row)

    def get_all_community_reports(self) -> List[CommunityReport]:
        """Retrieve all community reports."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM community_reports").fetchall()
            return [self._row_to_community_report(row) for row in rows]

    def upsert_global_report(self, report: GlobalReport):
        """Insert or update the global report."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO global_report (
                        id, summary, key_themes, last_updated
                    ) VALUES (1, ?, ?, ?)
                """, (
                    report.summary,
                    json.dumps(report.key_themes),
                    report.last_updated
                ))

    def get_global_report(self) -> Optional[GlobalReport]:
        """Retrieve the global report."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM global_report WHERE id = 1").fetchone()
            if not row:
                return None
            return self._row_to_global_report(row)

    def upsert_chunk_cache(self, chunk_hash: str, extracted_data: List[Dict[str, Any]]):
        """Insert or update a chunk extraction cache."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT OR REPLACE INTO chunk_cache (
                        chunk_hash, extracted_data, date_added
                    ) VALUES (?, ?, ?)
                """, (
                    chunk_hash,
                    json.dumps(extracted_data),
                    datetime.now().isoformat()
                ))

    def get_chunk_cache(self, chunk_hash: str) -> Optional[List[Dict[str, Any]]]:
        """Retrieve cached extraction data for a chunk."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT extracted_data FROM chunk_cache WHERE chunk_hash = ?", (chunk_hash,)).fetchone()
            if not row:
                return None
            return json.loads(row['extracted_data'] or '[]')

    def push_to_dlq(self, chunk_hash: str, chunk_data: str, error_reason: str, source_file: str):
        """Push a failed chunk to the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT INTO dlq_failed_chunks (
                        chunk_hash, chunk_data, error_reason, retries, date_added, source_file
                    ) VALUES (?, ?, ?, 0, ?, ?)
                    ON CONFLICT(chunk_hash) DO UPDATE SET
                        error_reason = excluded.error_reason,
                        retries = retries + 1,
                        date_added = excluded.date_added
                """, (
                    chunk_hash,
                    chunk_data,
                    error_reason,
                    datetime.now().isoformat(),
                    source_file
                ))

    def get_all_dlq_items(self) -> List[Dict[str, Any]]:
        """Retrieve all items from the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM dlq_failed_chunks").fetchall()
            return [dict(row) for row in rows]

    def upsert_file_cache(self, file_hash: str, extracted_text: str):
        """Insert or update extracted text for a file hash."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT OR REPLACE INTO file_cache (
                        file_hash, extracted_text, date_added
                    ) VALUES (?, ?, ?)
                """, (
                    file_hash,
                    extracted_text,
                    datetime.now().isoformat()
                ))

    def get_file_cache(self, file_hash: str) -> Optional[str]:
        """Retrieve cached extracted text for a file hash."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT extracted_text FROM file_cache WHERE file_hash = ?", (file_hash,)).fetchone()
            if not row:
                return None
            return row['extracted_text']

    def remove_from_dlq(self, chunk_hash: str):
        """Remove a chunk from the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("DELETE FROM dlq_failed_chunks WHERE chunk_hash = ?", (chunk_hash,))
