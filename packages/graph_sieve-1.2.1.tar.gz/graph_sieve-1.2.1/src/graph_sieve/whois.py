import sys
import os
import argparse
from .storage_sqlite import SQLiteStorage
from .graph_engine import GraphKnowledgeEngine

def get_expert_info(term: str, db_path: str = None) -> str:
    storage = SQLiteStorage(db_path=db_path) if db_path else SQLiteStorage()
    
    # We can just fetch relationships directly from storage for performance
    # or use graph_engine. Graph engine encapsulates both directions
    engine = GraphKnowledgeEngine(storage=storage)
    neighbors = engine.get_neighbors(term)
    
    experts = []
    managers = []
    orgs = []
    
    for r in neighbors:
        if r.relationship == "HAS_EXPERT":
            experts.append(r.object)
        elif r.relationship == "IS_EXPERT_OF": # Term perspective: Person IS_EXPERT_OF Term
            experts.append(r.subject)
            
        elif r.relationship == "MANAGES":
            managers.append(r.object)
        elif r.relationship == "IS_MANAGER_OF":
            managers.append(r.subject)
            
        elif r.relationship == "IS_SUB_ORGANIZATION_OF":
            orgs.append(r.object)
        elif r.relationship == "HAS_SUB_ORGANIZATION":
            orgs.append(r.subject)
            
    res = f"Who is responsible for: {term}\n"
    res += "=" * (len(term) + 25) + "\n"
    
    if experts:
        res += f"Technical Experts: {', '.join(set(experts))}\n"
    else:
        res += "Technical Experts: No specific experts identified in graph.\n"
        
    if managers:
        res += f"Managers/Owners:   {', '.join(set(managers))}\n"
    else:
        res += "Managers/Owners:   No specific managers identified in graph.\n"
        
    if orgs:
        res += f"Organization:      {', '.join(set(orgs))}\n"
        
    # Check for reports
    reports = [r.object for r in neighbors if r.relationship == "HAS_DIRECT_REPORT"]
    if reports:
        res += f"Direct Reports:    {', '.join(set(reports))}\n"
        
    return res

def main():
    parser = argparse.ArgumentParser(description="Find experts and owners for a specific term.")
    parser.add_argument("term", nargs="+", help="The term to look up.")
    parser.add_argument("--db", help="Path to the SQLite database. If not provided, uses the default from settings.")

    args = parser.parse_args()
    term = " ".join(args.term)
    
    print(get_expert_info(term, db_path=args.db))

if __name__ == "__main__":
    main()
