import re

def normalize_rtl_text(text: str, for_llm: bool = True) -> str:
    """
    Normalizes Hebrew text for LLM processing or visual display.
    
    Args:
        text: The input string (Logical Order).
        for_llm: If True (default), returns logical order (no change).
                 If False, reverses Hebrew blocks for visual display in LTR terminals.
                 
    The implementation splits words into Hebrew and non-Hebrew chunks,
    reversing only the Hebrew chunks when for_llm=False while keeping 
    English as is.
    """
    if not text:
        return text
        
    # If for_llm is True, we don't want to reverse anything. 
    # Modern LLMs expect logical order (as stored in UTF-8).
    if for_llm:
        return text

    # Visual Order Normalization (Only if not for_llm)
    # If Hebrew characters detected
    if any("\u0590" <= c <= "\u05FF" for c in text):
        # Split into words keeping whitespace
        tokens = re.split(r'(\s+)', text)
        
        result = []
        for token in tokens:
            if not token:
                continue
            if token.isspace():
                result.append(token)
                continue
                
            # Extract contiguous blocks of Hebrew and non-Hebrew
            # Using capture group () in split preserves the split parts in the resulting list
            parts = re.split(r'([\u0590-\u05FF]+)', token)
            
            normalized_token = ""
            for part in parts:
                if not part:
                    continue
                if any("\u0590" <= c <= "\u05FF" for c in part):
                    # Reverse Hebrew characters for visual display
                    normalized_token += part[::-1]
                else:
                    # Keep English/numbers as-is
                    normalized_token += part
                    
            result.append(normalized_token)
            
        return "".join(result)
        
    return text

def is_hebrew(text: str) -> bool:
    """Check if text contains Hebrew characters."""
    return any("\u0590" <= c <= "\u05FF" for c in text)
