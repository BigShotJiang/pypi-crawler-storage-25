import json
from typing import Optional, Dict, Any
from .models import LLMLogEntry
from .storage_sqlite import SQLiteStorage
from .config import settings

_storage: Optional[SQLiteStorage] = None

def get_storage():
    global _storage
    if _storage is None or _storage.db_path != settings.db_path:
        _storage = SQLiteStorage()
    return _storage

def calculate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    """
    Calculates estimated cost based on current OpenAI pricing (April 2026 estimates).
    """
    # Prices per 1M tokens
    pricing = {
        "gpt-4o-mini": {"prompt": 0.15, "completion": 0.60},
        "gpt-4o": {"prompt": 2.50, "completion": 10.0},
        "text-embedding-3-small": {"prompt": 0.02, "completion": 0.0},
    }
    
    # Fuzzy match for model names
    matched_model = None
    for k in pricing:
        if k in model:
            matched_model = k
            break
            
    if not matched_model:
        return 0.0
    
    p_price = pricing[matched_model]["prompt"] / 1_000_000
    c_price = pricing[matched_model]["completion"] / 1_000_000
    return (prompt_tokens * p_price) + (completion_tokens * c_price)

def log_interaction(
    provider: str,
    model: str,
    endpoint: str,
    prompt: Any,
    response: Optional[Any] = None,
    latency_ms: float = 0.0,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    status: str = "SUCCESS",
    error_message: Optional[str] = None
):
    """
    Captured LLM telemetry and persists it to the SQLite database.
    This function is designed to be fail-safe and won't interrupt the main pipeline.
    """
    try:
        total_tokens = prompt_tokens + completion_tokens
        cost = calculate_cost(model, prompt_tokens, completion_tokens)
        
        # Serialize complex objects to JSON strings for storage
        prompt_str = json.dumps(prompt) if not isinstance(prompt, str) else prompt
        response_str = json.dumps(response) if response is not None and not isinstance(response, str) else response
        
        entry = LLMLogEntry(
            provider=provider,
            model=model,
            endpoint=endpoint,
            prompt=prompt_str,
            response=response_str,
            latency_ms=latency_ms,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cost=cost,
            status=status,
            error_message=error_message
        )
        
        get_storage().log_llm_interaction(entry)
    except Exception as e:
        # Fallback to stderr to avoid circular logging issues
        import sys
        print(f"Telemetry Warning: Could not log LLM interaction: {e}", file=sys.stderr)
