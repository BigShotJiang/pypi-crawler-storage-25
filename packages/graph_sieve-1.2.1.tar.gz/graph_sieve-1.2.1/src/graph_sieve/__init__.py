# graph-sieve package

__version__ = "1.0.0"

# Note: Eagerly importing DictionaryAgent here causes issues with dependencies like numpy/markitdown 
# being loaded even for simple utility tests. Users should import from submodules.
