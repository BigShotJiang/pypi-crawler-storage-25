import difflib
import os
from .storage_sqlite import SQLiteStorage
from .graph_engine import GraphKnowledgeEngine

def lookup_term(term: str, db_path: str = None) -> str:
    storage = SQLiteStorage(db_path=db_path) if db_path else SQLiteStorage()
    graph_engine = GraphKnowledgeEngine(storage=storage)

    # Exact match
    entry = storage.get_entry(term)
    if entry:
        return format_entry(entry, storage, graph_engine)

    # Fuzzy match
    all_entries = storage.list_entries()
    all_terms = [e.term for e in all_entries]
    matches = difflib.get_close_matches(term, all_terms, n=1, cutoff=0.6)
    if matches:
        closest_term = matches[0]
        closest_entry = storage.get_entry(closest_term)
        return f"Exact term '{term}' not found. Closest match: '{closest_term}'\n\n{format_entry(closest_entry, storage, graph_engine)}"

    return f"Term '{term}' not found in dictionary."

def format_entry(entry, storage, graph_engine) -> str:
    term = entry.term
    res = f"Term: {entry.term}\n"
    res += f"Overview: {entry.overview}\n"
    if entry.deep_dive:
        res += f"Deep Dive: {entry.deep_dive}\n"
    res += f"Status: {entry.status}\n"
    res += f"Authority: {entry.authority_level}\n"
    res += f"Ubiquity: Found in {entry.document_count} unique documents.\n"
    
    if entry.usage_examples:
        res += "\nUsage Examples:"
        # Only show last 3 examples to keep it concise
        for ex in entry.usage_examples[-3:]:
            res += f"\n- \"{ex.context}\" (Source: {os.path.basename(ex.source)})"
            
    # Add Knowledge Graph Context
    res += f"\n\n--- Knowledge Graph Context ---"
    neighbors = graph_engine.get_neighbors(term)
    if neighbors:
        for r in neighbors:
            res += f"\n- {r.subject} --[{r.relationship}]--> {r.object}"
    else:
        res += "\nNo relationships found."
        
    # Add Community Summary if available
    reports = storage.get_all_community_reports()
    for report in reports:
        if term in report.nodes:
            res += f"\n\n--- Community Executive Summary ---\n{report.summary}"
            break
            
    return res

def main():
    import argparse
    import sys
    
    parser = argparse.ArgumentParser(description="Lookup a term in the knowledge graph dictionary.")
    parser.add_argument("term", nargs="+", help="The term to look up.")
    parser.add_argument("--db", help="Path to the SQLite database. If not provided, uses the default from settings.")

    args = parser.parse_args()
    term = " ".join(args.term)
    
    print(lookup_term(term, db_path=args.db))

if __name__ == "__main__":
    main()
