import pytest
import asyncio
from unittest.mock import MagicMock, patch, AsyncMock
from graph_sieve.llm_client import LocalLLMClient, OpenAIClientWrapper, LLMClientError

@pytest.mark.asyncio
async def test_local_llm_batch_chat_mock():
    # Use MOCK_LLM=true to trigger _mock_response
    with patch.dict("os.environ", {"MOCK_LLM": "true"}):
        client = LocalLLMClient()
        messages_list = [
            [
                {"role": "system", "content": "You are a Senior Technical Librarian."},
                {"role": "user", "content": "prism project"}
            ],
            [
                {"role": "system", "content": "You are a Senior Technical Librarian."},
                {"role": "user", "content": "sql project"}
            ]
        ]
        results = await client.batch_chat(messages_list)
        
        assert len(results) == 2
        assert results[0][0]["term"] == "Prism"
        assert results[1][0]["term"] == "SQL"

@pytest.mark.asyncio
@patch("httpx.AsyncClient.post")
async def test_local_llm_batch_chat_real_mock(mock_post):
    with patch.dict("os.environ", {"MOCK_LLM": "false"}):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": {"content": '{"term": "test"}'}}
        mock_post.return_value = mock_response

        client = LocalLLMClient(base_url="http://localhost:11434")
        messages_list = [
            [{"role": "user", "content": "hi"}],
            [{"role": "user", "content": "hello"}]
        ]
        results = await client.batch_chat(messages_list)
        
        assert len(results) == 2
        assert results[0] == {"term": "test"}
        assert mock_post.call_count == 2

@pytest.mark.asyncio
@patch("graph_sieve.llm_client.AsyncOpenAI")
async def test_openai_batch_chat(mock_async_openai):
    mock_client = AsyncMock()
    mock_async_openai.return_value = mock_client
    
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = '{"term": "openai"}'
    mock_client.chat.completions.create.return_value = mock_response

    wrapper = OpenAIClientWrapper(api_key="test-key")
    messages_list = [
        [{"role": "user", "content": "hi"}],
        [{"role": "user", "content": "hello"}]
    ]
    results = await wrapper.batch_chat(messages_list)
    
    assert len(results) == 2
    assert results[0] == {"term": "openai"}
    assert mock_client.chat.completions.create.await_count == 2
