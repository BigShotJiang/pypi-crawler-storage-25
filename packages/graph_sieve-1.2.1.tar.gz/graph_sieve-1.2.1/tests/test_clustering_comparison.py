import networkx as nx
from networkx.algorithms import community

def test_louvain_vs_cc():
    # Create two dense clusters connected by a single edge
    G = nx.Graph()
    # Cluster 1
    G.add_edge("A", "B", weight=1.0)
    G.add_edge("B", "C", weight=1.0)
    G.add_edge("C", "A", weight=1.0)
    
    # Cluster 2
    G.add_edge("X", "Y", weight=1.0)
    G.add_edge("Y", "Z", weight=1.0)
    G.add_edge("Z", "X", weight=1.0)
    
    # Weak link
    G.add_edge("C", "X", weight=0.1)
    
    # Connected components will group them all together
    cc = list(nx.connected_components(G))
    print(f"CC: {cc}")
    assert len(cc) == 1
    
    # Louvain should separate them
    louvain = community.louvain_communities(G, weight='weight', resolution=1.0)
    print(f"Louvain: {louvain}")
    # Convert to sets of frozen sets for comparison if needed, or just count
    assert len(louvain) == 2

if __name__ == "__main__":
    test_louvain_vs_cc()
