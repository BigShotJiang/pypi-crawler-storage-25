import pytest
from unittest.mock import MagicMock
from graph_sieve.resolution import SemanticResolver
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.models import DictionaryEntry
import os

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test.db"
    return SQLiteStorage(db_path=db_path)

def test_semantic_resolver_alias_linking(temp_db):
    # Setup storage with two similar terms
    entry_heb = DictionaryEntry(
        term="מערכת ניהול",
        overview="מערכת לניהול פרויקטים.",
        document_count=5
    )
    entry_eng = DictionaryEntry(
        term="Management System",
        overview="A system for managing projects.",
        document_count=10
    )
    temp_db.upsert_entry(entry_heb)
    temp_db.upsert_entry(entry_eng)
    
    # Mock LLM Client
    mock_llm = MagicMock()
    mock_llm.batch_chat_sync.return_value = [{
        "is_same": "YES",
        "reasoning": "Hebrew translation of the English term."
    }]
    
    resolver = SemanticResolver(storage=temp_db, llm_client=mock_llm)
    
    # Candidates from VectorResolver (simulated)
    candidates = [("מערכת ניהול", "Management System", 0.95)]
    
    resolver.verify_and_map(candidates)
    
    # Verify linking in storage
    updated_heb = temp_db.get_entry("מערכת ניהול")
    
    # "Management System" should be canonical because it's English and has higher document count
    assert updated_heb.canonical_id == "Management System"
    
    # Check relationships
    rels = temp_db.get_relationships(subject="מערכת ניהול", object="Management System")
    assert len(rels) == 1
    assert rels[0].relationship == "ALIAS_OF"

def test_semantic_resolver_negative(temp_db):
    # Setup storage with two different terms
    entry1 = DictionaryEntry(
        term="Python",
        overview="A programming language."
    )
    entry2 = DictionaryEntry(
        term="Java",
        overview="Another programming language."
    )
    temp_db.upsert_entry(entry1)
    temp_db.upsert_entry(entry2)
    
    # Mock LLM Client
    mock_llm = MagicMock()
    mock_llm.chat.return_value = {
        "is_same": "NO",
        "reasoning": "Different programming languages."
    }
    
    resolver = SemanticResolver(storage=temp_db, llm_client=mock_llm)
    candidates = [("Python", "Java", 0.8)]
    
    resolver.verify_and_map(candidates)
    
    # Verify NO linking
    updated1 = temp_db.get_entry("Python")
    assert updated1.canonical_id is None
    
    rels = temp_db.get_relationships(subject="Python", object="Java")
    assert len(rels) == 0

def test_decide_canonical_rules(temp_db):
    resolver = SemanticResolver(storage=temp_db)
    
    # Rule 1: Prefer English over Hebrew
    e_heb = DictionaryEntry(term="מערכת", overview="...")
    e_eng = DictionaryEntry(term="System", overview="...")
    assert resolver._decide_canonical(e_heb, e_eng) == "System"
    assert resolver._decide_canonical(e_eng, e_heb) == "System"
    
    # Rule 2: Prefer most frequent
    e1 = DictionaryEntry(term="Term1", overview="...", document_count=10)
    e2 = DictionaryEntry(term="Term2", overview="...", document_count=20)
    assert resolver._decide_canonical(e1, e2) == "Term2"
    
    # Rule 3: Alphabetical if counts are equal
    e3 = DictionaryEntry(term="A-Term", overview="...", document_count=10)
    e4 = DictionaryEntry(term="B-Term", overview="...", document_count=10)
    assert resolver._decide_canonical(e3, e4) == "A-Term"
