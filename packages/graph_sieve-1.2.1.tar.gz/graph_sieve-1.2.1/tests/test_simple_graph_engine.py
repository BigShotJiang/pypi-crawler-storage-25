import sys
import os
import pytest

# Add src to sys.path to allow importing graph_sieve
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from graph_sieve.graph_engine import GraphKnowledgeEngine
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.models import GraphTriplet

def test_louvain_communities(tmp_path):
    storage = SQLiteStorage(db_path=tmp_path / "test.db")
    engine = GraphKnowledgeEngine(storage=storage)
    # Cluster 1
    rel_id = engine.add_triplet(GraphTriplet(subject="A", relationship="ALIAS_OF", object="B"))
    storage.add_relationship_evidence(rel_id, "src1", "A is B")
    rel_id = engine.add_triplet(GraphTriplet(subject="B", relationship="ALIAS_OF", object="C"))
    storage.add_relationship_evidence(rel_id, "src1", "B is C")
    rel_id = engine.add_triplet(GraphTriplet(subject="C", relationship="ALIAS_OF", object="A"))
    storage.add_relationship_evidence(rel_id, "src1", "C is A")
    
    # Cluster 2
    rel_id = engine.add_triplet(GraphTriplet(subject="X", relationship="ALIAS_OF", object="Y"))
    storage.add_relationship_evidence(rel_id, "src2", "X is Y")
    rel_id = engine.add_triplet(GraphTriplet(subject="Y", relationship="ALIAS_OF", object="Z"))
    storage.add_relationship_evidence(rel_id, "src2", "Y is Z")
    rel_id = engine.add_triplet(GraphTriplet(subject="Z", relationship="ALIAS_OF", object="X"))
    storage.add_relationship_evidence(rel_id, "src2", "Z is X")
    
    # Weak link (weight 0.2 for REPLACES)
    rel_id = engine.add_triplet(GraphTriplet(subject="C", relationship="REPLACES", object="X"))
    storage.add_relationship_evidence(rel_id, "src3", "C replaces X")
    
    communities = engine.cluster_communities()
    assert len(communities) == 2
    
    communities_low = engine.cluster_communities(prune_threshold=0.1)
    assert len(communities_low) == 2

if __name__ == "__main__":
    test_louvain_communities(None)
    print("Test passed!")