import os
import pytest
from unittest.mock import patch, MagicMock
from graph_sieve.agent import DictionaryAgent
from graph_sieve.storage_sqlite import SQLiteStorage

def test_windowed_validation_logic(tmp_path):
    """
    Test that DictionaryAgent.process_document uses a sliding window 
    of chunks for validation instead of the full document text.
    """
    os.environ["MOCK_LLM"] = "true"
    # Mock storage and other dependencies
    storage = MagicMock(spec=SQLiteStorage)
    storage.get_chunk_cache.return_value = None # Force discovery
    # Mock existing entry to avoid issues with synthesis gate
    mock_entry = MagicMock()
    mock_entry.last_synthesized = None
    mock_entry.confidence_level = "BRONZE"
    storage.get_entry.return_value = mock_entry
    
    agent = DictionaryAgent(storage=storage)
    
    # Mock text and chunks
    chunks = ["Chunk 1 content", "Chunk 2 content", "Chunk 3 content", "Chunk 4 content"]
    
    # Create a dummy file to avoid FileNotFoundError during hashing
    dummy_file = tmp_path / "dummy_path.txt"
    dummy_file.write_text("dummy content")
    
    with patch("graph_sieve.agent.extract_all", return_value="Full text content"):
        with patch("graph_sieve.extractor.chunk_text_stream", return_value=iter(chunks)):
            with patch("graph_sieve.agent.calculate_chunk_hash", side_effect=lambda x: f"hash_{x}"):
                with patch("graph_sieve.discovery.batch_extract_with_llm", return_value=[[{"term": "test", "anchor": "test"}] for _ in chunks]):
                    with patch("graph_sieve.discovery.extract_with_llm", return_value=[{"term": "test", "anchor": "test"}]):
                        with patch("graph_sieve.agent.batch_validate_with_llm") as mock_validate:
                            mock_validate.return_value = [{"is_valid": True, "confidence_level": "GOLD"}]
                            
                            agent.process_document(str(dummy_file))
                        
                        # Verify validation context for each chunk
                        # Chunk 0: context should be [0, 1]
                        # Chunk 1: context should be [0, 1, 2]
                        # Chunk 2: context should be [1, 2, 3]
                        # Chunk 3: context should be [2, 3]
                        
                        expected_contexts = [
                            "\n\n---\n\n".join(chunks[0:2]),
                            "\n\n---\n\n".join(chunks[0:3]),
                            "\n\n---\n\n".join(chunks[1:4]),
                            "\n\n---\n\n".join(chunks[2:4])
                        ]
                        
                        assert mock_validate.call_count == 4
                        for i, call in enumerate(mock_validate.call_args_list):
                            # call[0][0] is the validation_context (first positional argument)
                            assert call[0][0] == expected_contexts[i]
