import pytest
import os
import sqlite3
from unittest.mock import MagicMock, patch
from graph_sieve.agent import DictionaryAgent
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.models import LLMLogEntry

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_graph_sieve.db"
    return str(db_path)

@pytest.fixture
def storage(temp_db):
    return SQLiteStorage(db_path=temp_db)

def test_dlq_table_exists(storage, temp_db):
    """Test that the dlq_failed_chunks table is created."""
    # This test will fail initially until we implement the table creation
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dlq_failed_chunks'")
    assert cursor.fetchone() is not None
    conn.close()

def test_chunk_failure_pushed_to_dlq(storage, tmp_path):
    """Test that a failed chunk extraction is pushed to the DLQ."""
    test_file = tmp_path / "fail_doc.txt"
    test_file.write_text("This chunk will fail.", encoding="utf-8")
    
    agent = DictionaryAgent(storage=storage)
    
    # Mock batch_extract_with_llm to fail
    with patch("graph_sieve.discovery.batch_extract_with_llm") as mock_batch:
        mock_batch.return_value = [None]
        
        agent.process_document(str(test_file))
        
    # Check DLQ table
    conn = sqlite3.connect(storage.db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM dlq_failed_chunks")
    failed_chunks = cursor.fetchall()
    
    assert len(failed_chunks) == 1
    assert failed_chunks[0]["error_reason"] == "Batch LLM Extraction Failure"
    assert failed_chunks[0]["source_file"] == "fail_doc.txt"
    conn.close()

def test_retry_failed_chunks(storage, tmp_path):
    """Test that retrying failed chunks works."""
    # 1. Add a failed chunk to DLQ manually
    chunk_content = "The project Prism is highly secure."
    conn = sqlite3.connect(storage.db_path)
    conn.execute("""
        INSERT INTO dlq_failed_chunks (chunk_hash, chunk_data, error_reason, retries, date_added, source_file)
        VALUES (?, ?, ?, ?, ?, ?)
    """, ("hash1", chunk_content, "Previous Error", 0, "2023-01-01", "retry_doc.txt"))
    conn.commit()
    conn.close()
    
    agent = DictionaryAgent(storage=storage)
    
    # 2. Mock extraction and validation to succeed this time
    with patch("graph_sieve.agent.extract_with_llm") as mock_extract, \
         patch("graph_sieve.agent.validate_with_llm") as mock_validate:
        
        mock_extract.return_value = [{
            "term": "RetriedTerm", 
            "overview": "A term from retry",
            "anchor": "The project Prism is highly secure"
        }]
        mock_validate.return_value = {"is_valid": True, "confidence_level": "GOLD"}
        
        # 3. Call retry logic
        agent.retry_failed_chunks()
        
    # 4. Verify term is now in storage
    entry = storage.get_entry("RetriedTerm")
    assert entry is not None
    assert entry.overview == "A term from retry"
    
    # 5. Verify DLQ is empty for this chunk
    conn = sqlite3.connect(storage.db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM dlq_failed_chunks")
    assert cursor.fetchone()[0] == 0
    conn.close()
