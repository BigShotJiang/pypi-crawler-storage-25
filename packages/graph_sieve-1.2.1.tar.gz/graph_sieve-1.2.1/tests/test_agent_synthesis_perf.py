import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.models import DictionaryEntry

@pytest.fixture
def agent(tmp_path):
    db_path = tmp_path / "test_perf.db"
    from src.graph_sieve.storage_sqlite import SQLiteStorage
    storage = SQLiteStorage(db_path=db_path)
    return DictionaryAgent(storage=storage)

def test_merge_conflicting_definitions_throttling(agent):
    existing = DictionaryEntry(
        term="Conflict", 
        overview="Old Overview", 
        confidence_level="GOLD"
    )
    agent.storage.upsert_entry(existing)
    agent.storage.add_usage_example("Conflict", "f1.txt", "Context")
    new_item = {
        "term": "Conflict",
        "overview": "New Overview",
        "confidence_level": "GOLD",
        "deep_dive": "New technical details"
    }
    
    mock_synthesized = {"overview": "Synthesized Overview", "deep_dive": "Synthesized Technical"}
    
    with patch("src.graph_sieve.agent.get_llm_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.chat.return_value = mock_synthesized
        
        # First call - should trigger LLM
        result1 = agent.merge_conflicting_definitions(existing, new_item)
        assert result1 is True
        assert mock_client.chat.call_count == 1
        assert existing.overview == "Synthesized Overview"
        
        # Second call - should NOT trigger LLM (within 1 hour)
        # Note: We need to make sure the overview is different again to trigger the synthesis logic
        new_item_2 = {
            "term": "Conflict",
            "overview": "Yet Another Overview",
            "confidence_level": "GOLD"
        }
        result2 = agent.merge_conflicting_definitions(existing, new_item_2)
        
        # In current implementation, this will be False if it skips, or it will call LLM again.
        # The task says "skip synthesis if it was done in the last 1 hour".
        # If it skips, it should probably return False (meaning no merge happened this time) 
        # or just return without doing anything.
        
        assert mock_client.chat.call_count == 1 # Should still be 1
        assert result2 is False # Should be false as we skipped synthesis

def test_merge_conflicting_definitions_after_one_hour(agent):
    existing = DictionaryEntry(
        term="Conflict", 
        overview="Old Overview", 
        confidence_level="GOLD"
    )
    agent.storage.upsert_entry(existing)
    agent.storage.add_usage_example("Conflict", "f1.txt", "Context")
    
    # Manually set last_synthesized to 2 hours ago
    two_hours_ago = (datetime.now() - timedelta(hours=2)).isoformat()
    # This will fail if last_synthesized is not in DictionaryEntry
    existing.last_synthesized = two_hours_ago
    
    new_item = {
        "term": "Conflict",
        "overview": "New Overview",
        "confidence_level": "GOLD"
    }
    
    mock_synthesized = {"overview": "Synthesized Overview", "deep_dive": "Synthesized Technical"}
    
    with patch("src.graph_sieve.agent.get_llm_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.chat.return_value = mock_synthesized
        
        # Should trigger LLM because it was more than 1 hour ago
        result = agent.merge_conflicting_definitions(existing, new_item)
        assert result is True
        assert mock_client.chat.call_count == 1
        assert existing.overview == "Synthesized Overview"
