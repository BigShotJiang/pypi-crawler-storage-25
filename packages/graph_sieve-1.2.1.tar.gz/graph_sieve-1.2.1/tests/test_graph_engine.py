import pytest
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_add_triplet(temp_db):
    engine = GraphKnowledgeEngine(storage=temp_db)
    triplet = GraphTriplet(
        subject="Prism",
        relationship="SUB_PROJECT_OF",
        object="Security-Suite"
    )
    engine.add_triplet(triplet)
    
    rels = temp_db.get_relationships()
    assert len(rels) == 1
    assert rels[0].subject == "Prism"

def test_duplicate_triplet(temp_db):
    engine = GraphKnowledgeEngine(storage=temp_db)
    triplet = GraphTriplet(
        subject="Prism",
        relationship="SUB_PROJECT_OF",
        object="Security-Suite"
    )
    engine.add_triplet(triplet)
    engine.add_triplet(triplet) # Exact duplicate
    
    assert len(temp_db.get_relationships()) == 1

def test_get_context_map(temp_db):
    engine = GraphKnowledgeEngine(storage=temp_db)
    triplet = GraphTriplet(
        subject="Prism",
        relationship="SUB_PROJECT_OF",
        object="Security-Suite"
    )
    engine.add_triplet(triplet)
    
    context = engine.get_context_map("Prism")
    assert "SUB_PROJECT_OF" in context
    assert "Security-Suite" in context