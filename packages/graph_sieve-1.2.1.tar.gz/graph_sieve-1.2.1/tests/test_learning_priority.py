import pytest
import os
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.storage_sqlite import SQLiteStorage
from unittest.mock import patch

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_seed_prioritization(temp_db):
    # 1. Setup seed and normal docs in a unique test folder
    test_dir = "tests/data_priority"
    os.makedirs(test_dir, exist_ok=True)
    seed_file = os.path.join(test_dir, "onboarding.txt")
    normal_file = os.path.join(test_dir, "random.txt")
    
    with open(seed_file, "w", encoding="utf-8") as f: f.write("Project Prism Onboarding")
    with open(normal_file, "w", encoding="utf-8") as f: f.write("Project Prism Random")
    
    # 2. Setup agent with seed_paths
    agent = DictionaryAgent(seed_paths=[seed_file], storage=temp_db)
    
    # 3. Mock extraction
    # Patch both batch and sync versions to be safe
    with patch("src.graph_sieve.discovery.batch_extract_with_llm") as mock_batch, \
         patch("src.graph_sieve.agent.validate_with_llm") as mock_validate:
        
        mock_batch.side_effect = [
            # Seed doc extraction
            [[{"term": "Prism", "overview": "High Quality Def", "anchor": "Project Prism", "entity_type": "PROJECT"}]],
            # Normal doc extraction
            [[{"term": "Prism", "overview": "Lower Quality Def", "anchor": "Project Prism", "entity_type": "PROJECT"}]]
        ]
        mock_validate.return_value = {"is_valid": True, "status": "PASS"}
        
        agent.process_directory(test_dir)
        
    # 4. Verify Prism has SEED authority
    entry = agent.storage.get_entry("Prism")
    assert entry.authority_level == "SEED"
    assert entry.is_golden is True

def test_pending_to_active_upgrade(temp_db):
    agent = DictionaryAgent(storage=temp_db)
    os.makedirs("tests/data", exist_ok=True)
    doc1 = "tests/data/report.txt"
    doc2 = "tests/data/onboarding.txt"
    
    with open(doc1, "w", encoding="utf-8") as f: f.write("Project Zephyr Revenue")
    with open(doc2, "w", encoding="utf-8") as f: f.write("Project Zephyr: A high-speed network.")

    with patch("src.graph_sieve.discovery.batch_extract_with_llm") as mock_batch, \
         patch("src.graph_sieve.agent.validate_with_llm") as mock_validate:
        
        mock_batch.side_effect = [
            # First doc: Pending
            [[{"term": "Zephyr", "overview": "[PENDING]", "anchor": "Zephyr Revenue", "entity_type": "PROJECT"}]],
            # Second doc: Active
            [[{"term": "Zephyr", "overview": "High-speed network", "anchor": "Project Zephyr", "entity_type": "PROJECT"}]]
        ]
        mock_validate.return_value = {"is_valid": True, "status": "PASS"}
        
        agent.process_document(doc1)
        entry = agent.storage.get_entry("Zephyr")
        assert entry is not None
        assert entry.status == "PENDING_DEFINITION"
        
        agent.process_document(doc2)
        entry = agent.storage.get_entry("Zephyr")
        assert entry.status == "ACTIVE"
        assert entry.overview == "High-speed network"
