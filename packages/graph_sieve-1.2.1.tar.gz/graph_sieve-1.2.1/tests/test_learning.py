import pytest
from src.graph_sieve.discovery import process_discovered_terms
from src.graph_sieve.storage_sqlite import SQLiteStorage

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_new_term_discovery(temp_db):
    discovered = [{"term": "New Term", "overview": "New Overview", "deep_dive": "New Deep Dive", "anchor": "Found in context"}]
    process_discovered_terms(discovered, "file.pdf", storage=temp_db)

    assert temp_db.get_term_exists("New Term")
    entry = temp_db.get_entry("New Term")
    assert entry.overview == "New Overview"
    assert entry.deep_dive == "New Deep Dive"
    assert len(temp_db.get_entry("New Term").usage_examples) == 1

def test_existing_term_enrichment(temp_db):
    # Add initial term
    initial_discovered = [{"term": "Old Term", "overview": "Old Overview", "anchor": "First found"}]
    process_discovered_terms(initial_discovered, "first.pdf", storage=temp_db)

    # Enrichment - should add second example and update deep_dive if missing
    new_discovered = [{"term": "Old Term", "overview": "Old Overview", "deep_dive": "New Deep Dive", "anchor": "Second found"}]
    process_discovered_terms(new_discovered, "second.pdf", storage=temp_db)

    examples = temp_db.get_entry("Old Term").usage_examples
    assert len(examples) == 2
    assert examples[0].source == "first.pdf"
    assert examples[1].source == "second.pdf"
    assert temp_db.get_entry("Old Term").deep_dive == "New Deep Dive"