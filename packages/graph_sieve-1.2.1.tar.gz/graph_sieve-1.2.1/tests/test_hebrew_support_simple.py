import pytest
from src.graph_sieve.hebrew_utils import normalize_rtl_text

def test_rtl_normalization_visual():
    # Test that pure Hebrew is reversed when for_llm=False
    assert normalize_rtl_text("פרויקט", for_llm=False) == "טקיורפ"
    
    # Test that pure English is NOT reversed
    assert normalize_rtl_text("Project", for_llm=False) == "Project"
    
    # Test mixed word (English then Hebrew)
    # "AIPים" -> "AIP" (English) + "ים" (Hebrew)
    # Expected: "AIPםי"
    assert normalize_rtl_text("AIPים", for_llm=False) == "AIPםי"
    
    # Test mixed word (Hebrew then English)
    assert normalize_rtl_text("שלנו-API", for_llm=False) == "ונלש-API"

    # Test full mixed sentence
    text = "היום בdaily דיברנו על AIPים"
    # "היום" -> "םויה"
    # "בdaily" -> "ב" + "daily" -> "בdaily"
    # "דיברנו" -> "ונרביד"
    # "על" -> "לע"
    # "AIPים" -> "AIPםי"
    expected = "םויה בdaily ונרביד לע AIPםי"
    assert normalize_rtl_text(text, for_llm=False) == expected

def test_rtl_normalization_llm():
    # Test that Hebrew is NOT reversed when for_llm=True (default)
    text = "פרויקט"
    assert normalize_rtl_text(text) == text
    assert normalize_rtl_text(text, for_llm=True) == text
    
    mixed_text = "היום בdaily דיברנו על AIPים"
    assert normalize_rtl_text(mixed_text) == mixed_text
