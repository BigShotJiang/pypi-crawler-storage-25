import pytest
import os
from unittest.mock import patch, MagicMock
from src.graph_sieve.discovery import extract_with_anchors, extract_with_llm

def test_anchored_extraction():
    # Sample text with a clear term and context
    text = "The project Prism uses port 8080 for secure communication."

    # Force mock LLM for local test
    os.environ["MOCK_LLM"] = "true"
    result = extract_with_anchors(text)

    assert len(result) > 0
    assert "term" in result[0]
    assert "overview" in result[0]
    assert "anchor" in result[0]
    assert "Prism" in result[0]["term"]

def test_no_extraction_on_empty_text():
    text = ""
    result = extract_with_anchors(text)
    assert len(result) == 0

def test_llm_extraction_mock_path():
    text = "Sample technical documentation."
    # Use the hardcoded mock path in extract_with_llm
    with patch.dict(os.environ, {"MOCK_LLM": "true"}):
        result = extract_with_llm(text)
        assert len(result) == 1
        assert result[0]["term"] == "Prism"
