import pytest
import os
from src.graph_sieve.extractor import extract_all
from src.graph_sieve.hebrew_utils import normalize_rtl_text

def test_extract_windows_1255_hebrew():
    # Create a temporary file with Windows-1255 encoding
    test_file = "tests/data/hebrew_1255.txt"
    os.makedirs(os.path.dirname(test_file), exist_ok=True)
    
    # "פרויקט מיקום" in windows-1255
    hebrew_text = "פרויקט מיקום"
    
    # Write as windows-1255
    with open(test_file, "wb") as f:
        f.write(hebrew_text.encode('windows-1255'))
        
    # Extract using the new logic
    # extract_all will return LOGICAL order by default now
    extracted = extract_all(test_file)
    
    # It should correctly decode the Windows-1255 text 
    # and keep it in logical order.
    assert hebrew_text in extracted

def test_rtl_normalization_visual():
    # Test that pure Hebrew is reversed when explicitly requested (for_llm=False)
    assert normalize_rtl_text("פרויקט", for_llm=False) == "טקיורפ"
    
    # Test that pure English is NOT reversed
    assert normalize_rtl_text("Project", for_llm=False) == "Project"
    
    # Test mixed word (English then Hebrew)
    assert normalize_rtl_text("AIPים", for_llm=False) == "AIPםי"
    
    # Test mixed word (Hebrew then English)
    assert normalize_rtl_text("שלנו-API", for_llm=False) == "ונלש-API"

def test_rtl_normalization_logical():
    # Test that Hebrew is NOT reversed by default (logical order)
    text = "פרויקט"
    assert normalize_rtl_text(text) == text
    
    mixed_text = "היום בdaily דיברנו על AIPים"
    assert normalize_rtl_text(mixed_text) == mixed_text
