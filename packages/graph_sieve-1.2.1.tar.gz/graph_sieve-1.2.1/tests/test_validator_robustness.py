import pytest
from graph_sieve.validator import verify_anchor_exists

def test_verify_anchor_exact_match():
    raw_text = "The quick brown fox jumps over the lazy dog."
    anchor = "quick brown fox"
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_extra_spaces():
    raw_text = "The quick brown fox jumps over the lazy dog."
    anchor = "quick  brown   fox"
    # Currently this might fail or pass depending on fuzzy threshold. 
    # But we want it to pass more robustly.
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_quotes_normalization():
    raw_text = 'He said "Hello World" today.'
    anchor = "He said 'Hello World'"
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_ocr_noise_simple_swap():
    raw_text = "Order ID: l0l-O234"
    anchor = "101-0234"
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_fuzzy_noise():
    raw_text = "The system architecture diagram shows the components."
    anchor = "systm architcture diagrm"
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_hallucination_fail():
    raw_text = "The quick brown fox jumps over the lazy dog."
    anchor = "blue elephant"
    assert verify_anchor_exists(raw_text, anchor) is False

def test_verify_anchor_ocr_noise_more_swaps():
    raw_text = "Page 92: Zone 5"
    anchor = "Page gZ: Zone S" # Wait, my anchor has 5/S and 9/g and 2/Z
    # Correcting:
    # 9 -> g
    # 2 -> z
    # S -> 5 ? wait, my ocr_map maps '5' to 's' and '9' to 'g' and '2' to 'z'
    # So if anchor is "Page gZ: Zone S"
    # norm_anchor: "page gz: zone s"
    # raw_text: "Page 92: Zone 5"
    # norm_text: "page gz: zone s"
    # They should match!
    assert verify_anchor_exists(raw_text, anchor) is True

def test_verify_anchor_multiline_robustness():
    raw_text = "Line 1\nLine 2\nLine 3"
    anchor = "Line 1 Line 2"
    assert verify_anchor_exists(raw_text, anchor) is True
