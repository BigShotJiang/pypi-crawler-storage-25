import pytest
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet, DictionaryEntry

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_metadata.db"
    return SQLiteStorage(db_path)

def test_community_report_includes_metadata(temp_db, mocker):
    # 1. Setup DB with specific metadata
    entry_a = DictionaryEntry(
        term="Project-Alpha",
        entity_type="PROJECT",
        confidence_level="GOLD",
        overview="The main initiative."
    )
    entry_b = DictionaryEntry(
        term="Component-Beta",
        entity_type="COMPONENT",
        confidence_level="SILVER",
        overview="A sub-component."
    )
    temp_db.upsert_entry(entry_a)
    temp_db.upsert_entry(entry_b)

    # Add relationship to ensure they are in the same community
    rel = GraphTriplet(
        subject="Project-Alpha",
        relationship="HAS_SUB_PROJECT",
        object="Component-Beta",
        weight=1.0
    )
    temp_db.add_relationship(rel)

    # 2. Mock LLM client
    mock_client = mocker.Mock()
    mock_client.chat.return_value = "Mocked Summary"
    mocker.patch("src.graph_sieve.graph_engine.get_llm_client", return_value=mock_client)

    # 3. Run community report generation
    engine = GraphKnowledgeEngine(storage=temp_db)
    engine.generate_community_reports()

    # 4. Verify the prompt sent to LLM
    assert mock_client.chat.called
    args, _ = mock_client.chat.call_args
    messages = args[0]
    user_message = messages[1]["content"]

    # Check if metadata is present in the prompt
    assert "Type: PROJECT" in user_message
    assert "Confidence: GOLD" in user_message
    assert "Type: COMPONENT" in user_message
    assert "Confidence: SILVER" in user_message
    assert "Overview: The main initiative." in user_message
    assert "Overview: A sub-component." in user_message
