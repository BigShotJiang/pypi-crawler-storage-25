import pytest
import os
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.storage_sqlite import SQLiteStorage
from unittest.mock import patch

def test_document_counter_increment(tmp_path):
    # 1. Setup mock data
    os.makedirs("tests/data", exist_ok=True)
    doc1_path = "tests/data/doc1.txt"
    doc2_path = "tests/data/doc2.txt"
    with open(doc1_path, "w", encoding="utf-8") as f:
        f.write("Project Prism is mentioned multiple times in Prism doc.")
    with open(doc2_path, "w", encoding="utf-8") as f:
        f.write("Another mention of Project Prism.")
        
    db_path = tmp_path / "test.db"
    temp_db = SQLiteStorage(db_path=db_path)
    agent = DictionaryAgent(storage=temp_db)
    
    # 2. Mock LLM to return Prism multiple times for doc1, and once for doc2
    with patch("src.graph_sieve.agent.extract_with_llm") as mock_extract, \
         patch("src.graph_sieve.agent.batch_validate_with_llm") as mock_validate:
        
        mock_extract.side_effect = [
            # doc1: Prism mentioned twice
            [
                {"term": "Prism", "overview": "...", "anchor": "Project Prism"},
                {"term": "Prism", "overview": "...", "anchor": "Prism doc"}
            ],
            # doc2: Prism mentioned once
            [
                {"term": "Prism", "overview": "...", "anchor": "Project Prism"}
            ]
        ]
        mock_validate.side_effect = lambda ctx, items: [{"is_valid": True, "status": "PASS"}] * len(items)
        
        agent.process_document(doc1_path)
        # After doc1, count should be 1
        assert agent.storage.get_entry("Prism").document_count == 1
        
        agent.process_document(doc2_path)
        # After doc2, count should be 2
        assert agent.storage.get_entry("Prism").document_count == 2