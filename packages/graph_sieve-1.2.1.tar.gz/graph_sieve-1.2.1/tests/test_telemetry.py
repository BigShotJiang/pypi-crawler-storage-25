import pytest
import os
import sqlite3
import json
from graph_sieve.llm_client import LocalLLMClient
from graph_sieve.config import settings
from graph_sieve.telemetry import log_interaction, get_storage

def test_telemetry_logging_direct(tmp_path):
    # Set up a temporary DB for testing
    settings.storage_dir = tmp_path
    db_path = tmp_path / "graph_sieve.db"
    
    log_interaction(
        provider="test-provider",
        model="gpt-4o-mini",
        endpoint="test-endpoint",
        prompt={"messages": [{"role": "user", "content": "hello"}]},
        response={"result": "world"},
        latency_ms=123.45,
        prompt_tokens=100,
        completion_tokens=50
    )
    
    # Verify in DB
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT * FROM llm_logs").fetchone()
    conn.close()
    
    assert row is not None
    assert row["provider"] == "test-provider"
    assert row["model"] == "gpt-4o-mini"
    assert row["endpoint"] == "test-endpoint"
    assert "hello" in row["prompt"]
    assert "world" in row["response"]
    assert row["latency_ms"] == 123.45
    assert row["prompt_tokens"] == 100
    assert row["completion_tokens"] == 50
    assert row["total_tokens"] == 150
    assert row["status"] == "SUCCESS"
    # Cost for gpt-4o-mini: (100 * 0.15 + 50 * 0.60) / 1M = (15 + 30) / 1M = 45 / 1M = 0.000045
    assert row["cost"] == pytest.approx(0.000045)

def test_chat_telemetry_integration(tmp_path, monkeypatch):
    # This test verifies that calling chat() actually triggers a log entry.
    import requests
    
    settings.storage_dir = tmp_path
    os.environ["MOCK_LLM"] = "false"
    
    class MockResponse:
        def json(self):
            return {
                "message": {"content": "{\"result\": \"ok\"}"},
                "prompt_eval_count": 50,
                "eval_count": 20
            }
        def raise_for_status(self):
            pass
            
    def mock_post(*args, **kwargs):
        return MockResponse()
        
    monkeypatch.setattr(requests, "post", mock_post)
    
    client = LocalLLMClient(base_url="http://fake", model="gpt-4o-mini")
    client.chat([{"role": "user", "content": "test"}])
    
    # Check DB
    storage = get_storage()
    with sqlite3.connect(storage.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM llm_logs ORDER BY id DESC LIMIT 1").fetchone()
        
    assert row is not None
    assert row["provider"] == "ollama"
    assert row["model"] == "gpt-4o-mini"
    assert row["prompt_tokens"] == 50
    assert row["completion_tokens"] == 20
    assert row["cost"] > 0 

def test_telemetry_error_logging(tmp_path, monkeypatch):
    import requests
    
    settings.storage_dir = tmp_path
    os.environ["MOCK_LLM"] = "false"
    
    def mock_post_fail(*args, **kwargs):
        raise requests.exceptions.ConnectionError("Connection refused")
        
    monkeypatch.setattr(requests, "post", mock_post_fail)
    
    client = LocalLLMClient(base_url="http://fake", model="test-model")
    
    with pytest.raises(Exception): # LLMClientError or ConnectionError depending on retry
        client.chat([{"role": "user", "content": "test"}])
    
    # Check DB for error log
    storage = get_storage()
    with sqlite3.connect(storage.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM llm_logs WHERE status = 'ERROR' ORDER BY id DESC").fetchone()

    assert row is not None

    assert "Connection refused" in row["error_message"]
