import pytest
import os
from unittest.mock import patch
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.storage_sqlite import SQLiteStorage

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

@pytest.fixture
def mock_llm_discovery():
    with patch("src.graph_sieve.agent.extract_with_llm") as mock_ext:
        yield mock_ext

@pytest.fixture
def mock_llm_validator():
    with patch("src.graph_sieve.agent.validate_with_llm") as mock_val:
        yield mock_val

def test_pipeline_full_run(temp_db, mock_llm_discovery, mock_llm_validator):
    # Configure mocks
    mock_llm_discovery.return_value = [
        {"term": "Prism", "overview": "Secure communication project", "anchor": "Project Prism"}
    ]
    mock_llm_validator.return_value = {"is_valid": True}

    # Create a temporary text file with a new term
    test_file = "tests/data/test_doc.txt"
    os.makedirs(os.path.dirname(test_file), exist_ok=True)
    with open(test_file, "w", encoding="utf-8") as f:
        f.write("Project Prism uses port 8080 for secure communication. It is superior to project Docker.")

    pipeline = DictionaryAgent(storage=temp_db)
    added = pipeline.process_document(test_file)

    # 'Prism' should be added
    assert "Prism" in added
    assert pipeline.storage.get_term_exists("Prism")

def test_pipeline_whitelist(temp_db, mock_llm_discovery, mock_llm_validator):
    mock_llm_discovery.return_value = [
        {"term": "SQL", "overview": "Database system", "anchor": "Project SQL"}
    ]
    mock_llm_validator.return_value = {"is_valid": True}

    test_file = "tests/data/test_whitelist.txt"
    os.makedirs(os.path.dirname(test_file), exist_ok=True)
    with open(test_file, "w", encoding="utf-8") as f:
        f.write("Project SQL is a new database system.")

    # SQL is generic, but we whitelist it
    pipeline = DictionaryAgent(whitelist=["SQL"], storage=temp_db)
    added = pipeline.process_document(test_file)
    
    assert "SQL" in added
    assert pipeline.storage.get_term_exists("SQL")