import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.storage_sqlite import SQLiteStorage

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_cache.db"
    return SQLiteStorage(db_path=db_path)

@pytest.fixture
def agent(temp_db):
    return DictionaryAgent(storage=temp_db)

def test_chunk_caching_skips_llm(agent, tmp_path):
    # Setup test file
    test_file = tmp_path / "test.txt"
    test_file.write_text("This is a test chunk content.")
    
    # Mock data to be returned by LLM
    mock_discovery = [{"term": "TestTerm", "overview": "A test term"}]
    mock_validation = {"is_valid": True, "confidence_level": "GOLD"}
    
    with patch("src.graph_sieve.agent.extract_all", return_value="This is a test chunk content."), \
         patch("src.graph_sieve.agent.extract_with_llm", return_value=mock_discovery) as mock_extract, \
         patch("src.graph_sieve.agent.batch_validate_with_llm", return_value=[mock_validation]) as mock_validate:
        
        # First scan - should call LLM
        agent.process_document(str(test_file))
        assert mock_extract.call_count == 1
        
        # Second scan of the same content - should NOT call LLM
        agent.process_document(str(test_file))
        assert mock_extract.call_count == 1 # Still 1
        
        # Verify it still processed the term (it should be in the dictionary)
        assert agent.storage.get_term_exists("TestTerm")

def test_different_chunks_call_llm_separately(agent, tmp_path):
    # Setup two different files/contents
    file1 = tmp_path / "file1.txt"
    file1.write_text("Content One")
    
    file2 = tmp_path / "file2.txt"
    file2.write_text("Content Two")
    
    mock_discovery = [{"term": "Term", "overview": "Def"}]
    mock_validation = {"is_valid": True, "confidence_level": "GOLD"}
    
    with patch("src.graph_sieve.agent.extract_all") as mock_extract_all, \
         patch("src.graph_sieve.agent.extract_with_llm", return_value=mock_discovery) as mock_extract, \
         patch("src.graph_sieve.agent.batch_validate_with_llm", return_value=[mock_validation]) as mock_validate:
        
        # Scan file 1
        mock_extract_all.return_value = "Content One"
        agent.process_document(str(file1))
        assert mock_extract.call_count == 1
        
        # Scan file 2 (different content)
        mock_extract_all.return_value = "Content Two"
        agent.process_document(str(file2))
        assert mock_extract.call_count == 2