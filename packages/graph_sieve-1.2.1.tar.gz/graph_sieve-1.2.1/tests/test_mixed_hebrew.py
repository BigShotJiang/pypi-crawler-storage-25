from src.graph_sieve.hebrew_utils import normalize_rtl_text

def test_mixed_bidi_logical():
    text = "היום בdaily דיברנו על הבעיות בAIPים, good luck with that אחים שלי"
    normalized = normalize_rtl_text(text) # default is for_llm=True (logical)
    
    # Should stay logical
    assert normalized == text

def test_mixed_bidi_visual():
    text = "היום בdaily"
    normalized = normalize_rtl_text(text, for_llm=False)
    
    # Hebrew "היום" -> "םויה"
    # English "daily" -> "daily"
    assert "םויה" in normalized
    assert "daily" in normalized
        
if __name__ == "__main__":
    test_mixed_bidi_logical()
    test_mixed_bidi_visual()
