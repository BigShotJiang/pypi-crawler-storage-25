import pytest
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import DictionaryEntry

def test_usage_example_preservation(tmp_path):
    db_path = tmp_path / "test_usage.db"
    storage = SQLiteStorage(db_path=db_path)
    
    # 1. Add an entry and its first usage example
    entry = DictionaryEntry(term="Prism", overview="Project Prism")
    storage.upsert_entry(entry)
    storage.add_usage_example("Prism", "file1.txt", "Prism is good")
    
    # Verify usage 1 exists
    retrieved = storage.get_entry("Prism")
    assert len(retrieved.usage_examples) == 1
    assert retrieved.usage_examples[0].source == "file1.txt"
    
    # 2. Upsert the SAME entry (e.g. update overview or just re-save)
    # This simulates another chunk or file discovery
    entry.overview = "Project Prism Updated"
    storage.upsert_entry(entry)
    storage.add_usage_example("Prism", "file2.txt", "Prism is still good")
    
    # 3. Check if BOTH usage examples exist
    retrieved = storage.get_entry("Prism")
    assert len(retrieved.usage_examples) == 2
    
    sources = [u.source for u in retrieved.usage_examples]
    assert "file1.txt" in sources
    assert "file2.txt" in sources
