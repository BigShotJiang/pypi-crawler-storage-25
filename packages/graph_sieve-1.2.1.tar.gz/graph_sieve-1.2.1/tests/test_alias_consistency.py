import pytest
from unittest.mock import MagicMock
from src.graph_sieve.discovery import process_discovered_terms
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import DictionaryEntry

def test_alias_auto_linking(tmp_path):
    db_path = tmp_path / "test.db"
    storage = SQLiteStorage(str(db_path))
    
    discovered = [
        {
            "term": "TermA",
            "overview": "Overview A",
            "relationships": [{"target": "TermB", "type": "ALIAS_OF"}]
        }
    ]
    
    # This should trigger storage.link_alias("TermA", "TermB")
    process_discovered_terms(discovered, "file.txt", storage=storage)
    
    aliases = storage.get_all_aliases()
    assert aliases["TermA"] == "TermB"

def test_graph_folding_with_new_alias(tmp_path):
    # This tests that the graph engine uses the aliases table
    from src.graph_sieve.graph_engine import GraphKnowledgeEngine
    
    db_path = tmp_path / "test_graph.db"
    storage = SQLiteStorage(str(db_path))
    
    # Setup: TermA is an alias of TermB
    storage.upsert_entry(DictionaryEntry(term="TermA", overview="A"))
    storage.upsert_entry(DictionaryEntry(term="TermB", overview="B"))
    storage.link_alias("TermA", "TermB")
    
    # Relationship involving TermA
    from src.graph_sieve.models import GraphTriplet
    storage.add_relationship(GraphTriplet(
        subject="TermA", 
        relationship="USES", 
        object="TermC"
    ))
    
    engine = GraphKnowledgeEngine(storage=storage)
    G = engine.build_nx_graph()
    
    # TermA should be folded into TermB
    assert "TermA" not in G.nodes
    assert "TermB" in G.nodes
    assert G.has_edge("TermB", "TermC")
