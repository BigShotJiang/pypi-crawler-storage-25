import pytest
from pathlib import Path
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet

@pytest.fixture
def storage(tmp_path):
    db_path = tmp_path / "test_opt.db"
    return SQLiteStorage(db_path=db_path)

def test_get_relationships_for_nodes(storage):
    # Setup some data
    t1 = GraphTriplet(subject="A", relationship="DEPENDS_ON", object="B")
    t2 = GraphTriplet(subject="B", relationship="DEPENDS_ON", object="C")
    t3 = GraphTriplet(subject="A", relationship="DEPENDS_ON", object="D")
    t4 = GraphTriplet(subject="X", relationship="DEPENDS_ON", object="Y")
    
    storage.add_relationship(t1)
    storage.add_relationship(t2)
    storage.add_relationship(t3)
    storage.add_relationship(t4)
    
    # We want relationships where BOTH subject and object are in the list
    nodes = ["A", "B", "C"]
    rels = storage.get_relationships_for_nodes(nodes)
    
    # Expected: A->B, B->C
    # A->D should NOT be there because D is not in nodes
    # X->Y should NOT be there
    
    assert len(rels) == 2
    subjects = {r.subject for r in rels}
    objects = {r.object for r in rels}
    assert subjects == {"A", "B"}
    assert objects == {"B", "C"}

def test_get_relationships_for_nodes_empty(storage):
    assert storage.get_relationships_for_nodes([]) == []
    assert storage.get_relationships_for_nodes(["NonExistent"]) == []
