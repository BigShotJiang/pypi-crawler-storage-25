import pytest
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet

def test_relationship_evidence_preservation(tmp_path):
    db_path = tmp_path / "test_evidence.db"
    storage = SQLiteStorage(db_path=db_path)
    
    # 1. Add a relationship and its first piece of evidence
    rel = GraphTriplet(subject="A", relationship="USES", object="B")
    rel_id = storage.add_relationship(rel)
    storage.add_relationship_evidence(rel_id, "file1.txt", "A uses B")
    
    # Verify evidence 1 exists
    triplets = storage.get_relationships(subject="A", object="B")
    assert len(triplets) == 1
    assert len(triplets[0].evidence) == 1
    assert triplets[0].evidence[0]["source_file"] == "file1.txt"
    
    # 2. Add the SAME relationship again (e.g. from another file)
    # This simulates another chunk or file discovery
    rel_id_2 = storage.add_relationship(rel)
    storage.add_relationship_evidence(rel_id_2, "file2.txt", "A also uses B")
    
    # 3. Check if BOTH pieces of evidence exist
    triplets = storage.get_relationships(subject="A", object="B")
    assert len(triplets) == 1
    
    evidence_sources = [e["source_file"] for e in triplets[0].evidence]
    print(f"Evidence sources found: {evidence_sources}")
    
    # IF THE BUG EXISTS, file1.txt will be GONE because of REPLACE + CASCADE
    assert "file1.txt" in evidence_sources
    assert "file2.txt" in evidence_sources
    assert len(triplets[0].evidence) == 2
