import pytest
import os
from src.graph_sieve.extractor import extract_text_from_txt, chunk_text_stream

def test_streaming_extraction(tmp_path):
    # Create a "large" file
    large_file = tmp_path / "large.txt"
    content = "Line 1\n" * 10000
    large_file.write_text(content, encoding="utf-8")
    
    # Test that it extracts correctly
    extracted_gen = extract_text_from_txt(str(large_file))
    extracted_full = "".join(list(extracted_gen))
    assert len(extracted_full) == len(content)
    assert extracted_full.startswith("Line 1")

def test_chunking_with_large_text():
    text = ["Word " * 1000]
    chunks = list(chunk_text_stream(text, "test.txt", chunk_size=100, overlap=20))
    assert len(chunks) > 1
    assert all(c.startswith("[Context:") for c in chunks)
