from unittest.mock import patch, MagicMock
from src.graph_sieve.validator import validate_with_llm

@patch('src.graph_sieve.validator.get_llm_client')
def test_valid_overview(mock_get_client):
    mock_client = MagicMock()
    mock_get_client.return_value = mock_client
    mock_client.chat.return_value = {
        "is_valid": True,
        "confidence_level": "GOLD",
        "status": "PASS",
        "reasoning": "Mocked: The extraction is fully supported by the context.",
        "suggested_fix": None
    }

    raw_text = "Project Prism is our new internal firewall."
    extraction = {
        "term": "Prism",
        "overview": "An internal firewall project.",
        "deep_dive": "It handles network traffic filtering.",
        "anchor": "Project Prism is our new internal firewall."
    }
    # Should pass as it's consistent AND anchor exists
    result = validate_with_llm(raw_text, extraction)
    assert result["is_valid"] is True
    assert result["status"] == "PASS"
    mock_client.chat.assert_called_once()


@patch('src.graph_sieve.validator.get_llm_client')
def test_invalid_overview(mock_get_client):
    mock_client = MagicMock()
    mock_get_client.return_value = mock_client
    mock_client.chat.return_value = {
        "is_valid": False,
        "confidence_level": "CONFLICT/HALLUCINATION",
        "status": "HALLUCINATION",
        "reasoning": "Mocked: The anchor does not exist in the raw text.",
        "suggested_fix": None
    }

    raw_text = "Project Prism is our new internal firewall."
    extraction = {
        "term": "Prism",
        "overview": "A new coffee machine in the breakroom.",
        "deep_dive": "It makes espresso.",
        "anchor": "new coffee machine" # This doesn't exist in raw_text
    }
    # result will be invalid because verify_anchor_exists fails before LLM call
    result = validate_with_llm(raw_text, extraction)
    assert result["is_valid"] is False
    assert result["status"] == "HALLUCINATION"
    mock_client.chat.assert_not_called()
