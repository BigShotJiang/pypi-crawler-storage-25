import pytest
from unittest.mock import MagicMock, patch
from graph_sieve.agent import DictionaryAgent
from graph_sieve.graph_engine import GraphKnowledgeEngine
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.models import DictionaryEntry, GraphTriplet
import os

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test.db"
    return SQLiteStorage(db_path=db_path)

def test_visualize_graph_folding(temp_db, tmp_path):
    # Setup storage with canonical term and its alias
    entry_canonical = DictionaryEntry(
        term="Management System",
        overview="A system for managing projects.",
        document_count=10,
        entity_type="COMPONENT"
    )
    entry_alias = DictionaryEntry(
        term="מערכת ניהול",
        canonical_id="Management System",
        overview="מערכת לניהול פרויקטים.",
        document_count=5,
        entity_type="COMPONENT"
    )
    # Third term not related to aliases
    entry_other = DictionaryEntry(
        term="Database",
        overview="Stores data.",
        document_count=3,
        entity_type="TECH_STACK"
    )
    
    temp_db.upsert_entry(entry_canonical)
    temp_db.upsert_entry(entry_alias)
    temp_db.upsert_entry(entry_other)
    
    # Add relationships
    # 1. Relationship involving the alias
    rel_id = temp_db.add_relationship(GraphTriplet(
        subject="מערכת ניהול",
        relationship="USES",
        object="Database"
    ))
    temp_db.add_relationship_evidence(rel_id, "test.txt", "מערכת ניהול משתמשת בבסיס נתונים")
    
    # 2. Relationship involving the canonical term
    rel_id = temp_db.add_relationship(GraphTriplet(
        subject="Management System",
        relationship="USES",
        object="Database"
    ))
    temp_db.add_relationship_evidence(rel_id, "test.txt", "The Management System uses a database")
    
    # 3. ALIAS_OF relationship
    rel_id = temp_db.add_relationship(GraphTriplet(
        subject="מערכת ניהול",
        relationship="ALIAS_OF",
        object="Management System"
    ))
    temp_db.add_relationship_evidence(rel_id, "resolver", "Alias resolution")

    engine = GraphKnowledgeEngine(storage=temp_db)
    
    # Test build_nx_graph folding
    G = engine.build_nx_graph()
    assert "Management System" in G.nodes
    assert "מערכת ניהול" not in G.nodes
    assert "Database" in G.nodes
    assert G.number_of_nodes() == 2
    assert G.has_edge("Management System", "Database")
    
    # Test visualize_graph folding (saving to a file and checking if it contains expected terms)
    output_path = tmp_path / "graph.html"
    engine.visualize_graph(output_path=str(output_path))
    
    with open(output_path, "r", encoding="utf-8") as f:
        html = f.read()
        
    # Should contain the canonical term
    assert "Management System" in html
    # Should contain the alias term in the tooltip (might be escaped)
    import json
    escaped_alias = json.dumps("מערכת ניהול").strip('"')
    assert ("מערכת ניהול" in html or escaped_alias in html)
    
    # Check if doc_count was aggregated (10 + 5 = 15)
    assert "Docs: 15" in html

def test_agent_calls_resolution(temp_db, tmp_path):
    # Mock documents dir
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "doc1.txt").write_text("Some text about Sieve System.")
    
    with patch("graph_sieve.agent.extract_all", return_value="Sieve System is a core component."), \
         patch("graph_sieve.agent.extract_with_llm", return_value=[{"term": "Sieve System", "overview": "Core component"}]), \
         patch("graph_sieve.agent.validate_with_llm", return_value={"is_valid": True, "confidence_level": "GOLD"}), \
         patch("graph_sieve.resolution.VectorResolver") as MockVector, \
         patch("graph_sieve.resolution.SemanticResolver") as MockSemantic:
        
        agent = DictionaryAgent(storage=temp_db)
        agent.process_directory(str(docs_dir))
        
        # Verify resolution was triggered
        MockVector.assert_called_once()
        MockVector.return_value.discover_candidates.assert_called_once()
        # SemanticResolver only called if candidates found
        # MockVector.return_value.discover_candidates returns MagicMock, which is truthy
        MockSemantic.assert_called_once()
        MockSemantic.return_value.verify_and_map.assert_called_once()
