import pytest
import numpy as np
from unittest.mock import MagicMock, patch
from src.graph_sieve.resolution import VectorResolver, SemanticResolver
from src.graph_sieve.models import DictionaryEntry
from src.graph_sieve.storage_sqlite import SQLiteStorage

@pytest.fixture
def mock_storage():
    storage = MagicMock(spec=SQLiteStorage)
    return storage

@pytest.fixture
def mock_llm_client():
    client = MagicMock()
    # Mock embedding to return a random vector of size 1536
    client.get_embedding.side_effect = lambda x: np.random.rand(1536).tolist()
    return client

def test_vector_resolver_vectorization(mock_storage, mock_llm_client):
    # Create 100 mock entries
    entries = [
        DictionaryEntry(term=f"term_{i}", overview=f"overview_{i}", document_count=1)
        for i in range(100)
    ]
    mock_storage.list_entries.return_value = entries
    
    resolver = VectorResolver(storage=mock_storage, llm_client=mock_llm_client)
    
    # This should now use the optimized path
    candidates = resolver.discover_candidates(threshold=0.1) # Low threshold to get many candidates
    
    assert len(candidates) > 0
    assert all(isinstance(c, tuple) and len(c) == 3 for c in candidates)
    # Check that they are sorted
    for i in range(len(candidates) - 1):
        assert candidates[i][2] >= candidates[i+1][2]

@patch("src.graph_sieve.resolution.get_llm_client")
def test_semantic_resolver_batching(mock_get_llm, mock_storage):
    mock_llm = MagicMock()
    mock_get_llm.return_value = mock_llm
    
    # Mock batch_chat_sync to return YES for all
    mock_llm.batch_chat_sync.return_value = [{"is_same": "YES", "reasoning": "matched"}] * 5

    # Mock storage.get_entry
    mock_storage.get_entry.side_effect = lambda t: DictionaryEntry(term=t, overview="desc", document_count=1)

    resolver = SemanticResolver(storage=mock_storage, llm_client=mock_llm)

    candidates = [
        ("term1", "term2", 0.9),
        ("term3", "term4", 0.85),
        ("term5", "term6", 0.8),
        ("term7", "term8", 0.75),
        ("term9", "term10", 0.7),
    ]

    resolver.verify_and_map(candidates)

    # Verify batch_chat_sync was called once with 5 pairs
    assert mock_llm.batch_chat_sync.called
    args, kwargs = mock_llm.batch_chat_sync.call_args
    assert len(args[0]) == 5
    
    # Verify link_alias was called 5 times
    assert mock_storage.link_alias.call_count == 5
