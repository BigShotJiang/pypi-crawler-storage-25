import pytest
from src.graph_sieve.validator import verify_anchor_exists
from src.graph_sieve.hebrew_utils import normalize_rtl_text

def test_hebrew_anchor_robustness_visual_raw():
    # Raw text is in visual order (common in some PDFs)
    # "היום בdaily" in visual order: "םויה בdaily"
    raw_text = "םויה בdaily דיברנו על AIPים"
    
    # LLM extracts logical anchor
    anchor = "היום בdaily"
    
    # SHOULD PASS NOW
    assert verify_anchor_exists(raw_text, anchor) == True

def test_hebrew_anchor_robustness_sofit_confusion():
    # Raw text has "שלום"
    raw_text = "שלום לכולם"
    
    # LLM returns "שלומ לכולם" (using regular 'מ' instead of 'ם')
    anchor = "שלומ לכולם"
    
    # SHOULD PASS NOW via normalization
    assert verify_anchor_exists(raw_text, anchor) == True

def test_hebrew_anchor_robustness_mixed_visual_norm():
    # Mixed visual and sofit confusion
    # "הפרויקט שלנו" -> "ונלש טקיורפה" (visual)
    # LLM returns "הפרויקט שלנו" (logical) but maybe with "שלנו" -> "שלנו"
    raw_text = "ונלש טקיורפה מוצלח מאוד"
    anchor = "הפרויקט שלנו"
    
    assert verify_anchor_exists(raw_text, anchor) == True

if __name__ == "__main__":
    pytest.main([__file__])
