import pytest
import os
import sys
import json
import sqlite3
from unittest.mock import patch, MagicMock
from src.graph_sieve.discovery import process_discovered_terms
from src.graph_sieve.extractor import extract_text_from_one, extract_all
from src.graph_sieve.filters import is_domain_specific
from src.graph_sieve.hashing import HashStore
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.hebrew_utils import normalize_rtl_text
from src.graph_sieve.models import DictionaryEntry, GraphTriplet
from src.graph_sieve.storage_sqlite import SQLiteStorage
import src.graph_sieve.tools as gs_tools
import src.graph_sieve.whois as gs_whois
import src.graph_sieve.visualize as gs_visualize
import src.graph_sieve.run_scanner as gs_run_scanner
import src.graph_sieve.mcp_server as gs_mcp

def test_extract_text_from_one(tmp_path):
    # This test previously failed because open() was called on a patched exists() but non-existent file
    one_file = tmp_path / "test.one"
    one_file.write_bytes(b"mock one content")

    with pytest.raises(FileNotFoundError):
        extract_text_from_one("completely_nonexistent.one")

    # Patch OneDocment to avoid real parsing of our junk bytes
    with patch("src.graph_sieve.extractor.OneDocment") as mock_one:
        mock_instance = MagicMock()
        mock_one.return_value = mock_instance
        # Mock the document structure pyOneNote expects
        mock_instance.get_json.return_value = {
            "properties": [
                {"val": {"RichEditTextUnicode": "OneNote content"}}
            ]
        }

        res = extract_text_from_one(str(one_file))
        assert "OneNote" in res

def test_is_domain_specific_edge_cases():
    assert is_domain_specific("") is False
    assert is_domain_specific("A") is False
    assert is_domain_specific("SQL", whitelist=["SQL"]) is True
    assert is_domain_specific("PROJECT") is False

def test_hash_store_missing_file(tmp_path):
    store = HashStore(file_path=tmp_path / "hashes.json")
    assert store.has_changed("nonexistent.txt") is False

def test_graph_engine_empty_cluster(tmp_path):
    # Pass dummy storage
    engine = GraphKnowledgeEngine(storage=SQLiteStorage(db_path=tmp_path / "test.db"))
    assert engine.cluster_communities() == []

def test_hebrew_normalization_visual():
    text = "Hello שלום World"
    # Logical to Visual (mock-ish)
    res = normalize_rtl_text(text, for_llm=False)
    assert "םולש" in res

def test_tools_lookup_not_found(tmp_path):
    db_path = tmp_path / "empty.db"
    res = gs_tools.lookup_term("NonExistent", db_path=str(db_path))
    assert "not found" in res

def test_tools_lookup_fuzzy(tmp_path):
    db_path = tmp_path / "fuzzy.db"
    storage = SQLiteStorage(str(db_path))
    entry = DictionaryEntry(term="ProjectPrism", overview="Overview")
    storage.upsert_entry(entry)

    # 'ProjectPris' should fuzzy match 'ProjectPrism'
    res = gs_tools.lookup_term("ProjectPris", db_path=str(db_path))
    assert "Closest match: 'ProjectPrism'" in res

def test_whois_lookup(tmp_path):
    db_path = tmp_path / "whois.db"
    storage = SQLiteStorage(str(db_path))
    entry = DictionaryEntry(term="Prism", overview="O")
    storage.upsert_entry(entry)
    storage.add_relationship(GraphTriplet(subject="Prism", relationship="HAS_EXPERT", object="Alice"))
    storage.add_relationship(GraphTriplet(subject="Bob", relationship="IS_EXPERT_OF", object="Prism"))
    storage.add_relationship(GraphTriplet(subject="Prism", relationship="MANAGES", object="Charlie"))
    storage.add_relationship(GraphTriplet(subject="Prism", relationship="IS_SUB_ORGANIZATION_OF", object="OrgA"))
    
    with patch("src.graph_sieve.whois.os.path.exists", return_value=True):
        res = gs_whois.get_expert_info("Prism", db_path=str(db_path))
        assert "Alice" in res
        assert "Bob" in res
        assert "Charlie" in res
        assert "OrgA" in res

def test_visualize_main_smoke(tmp_path):
    db_path = tmp_path / "viz.db"
    with patch("sys.argv", ["gs-viz", "--db", str(db_path), "--output", str(tmp_path / "out.html")]), \
         patch("src.graph_sieve.visualize.GraphKnowledgeEngine.visualize_graph"):
        gs_visualize.main()

def test_tools_main_smoke(tmp_path):
    db_path = tmp_path / "tools.db"
    with patch("sys.argv", ["gs-lookup", "term", "--db", str(db_path)]), \
         patch("src.graph_sieve.tools.lookup_term", return_value="Result"):
        gs_tools.main()

def test_whois_main_smoke():
    with patch("sys.argv", ["gs-whois", "term"]), \
         patch("src.graph_sieve.whois.get_expert_info", return_value="Result"):
        gs_whois.main()

def test_run_scanner_main_smoke(tmp_path):
    scan_dir = tmp_path / "scan"
    scan_dir.mkdir()
    db_path = tmp_path / "d.db"
    with patch("sys.argv", ["gs-scan", str(scan_dir), "--db", str(db_path)]), \
         patch("src.graph_sieve.run_scanner.run_local_agent"):
        gs_run_scanner.main()

def test_mcp_tools_smoke():
    with patch("src.graph_sieve.mcp_server.lookup_term", return_value="Lookup"), \
         patch("src.graph_sieve.mcp_server.get_expert_info", return_value="Whois"):
        assert gs_mcp.lookup("term") == "Lookup"
        assert gs_mcp.whois("term") == "Whois"

def test_sqlite_storage_chunk_cache(tmp_path):
    storage = SQLiteStorage(tmp_path / "test.db")
    data = [{"term": "T"}]
    storage.upsert_chunk_cache("hash1", data)
    assert storage.get_chunk_cache("hash1") == data
    assert storage.get_chunk_cache("hash2") is None

def test_sqlite_migration_canonical_id(tmp_path):
    db_path = tmp_path / "migrate.db"
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE entries (term TEXT PRIMARY KEY, overview TEXT)")
    conn.close()
    
    # Initializing SQLiteStorage should trigger migration
    storage = SQLiteStorage(db_path)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.execute("PRAGMA table_info(entries)")
    columns = [row['name'] for row in cursor.fetchall()]
    assert 'canonical_id' in columns
    conn.close()

def test_extract_all_unsupported(tmp_path):
    f = tmp_path / "test.exe"
    f.write_text("bin")
    assert "".join(list(extract_all(str(f)))) == ""