import asyncio
import pytest
import os
from unittest.mock import patch, MagicMock
from graph_sieve.discovery import batch_extract_with_llm
from graph_sieve.llm_client import LocalLLMClient, OpenAIClientWrapper

@pytest.mark.asyncio
async def test_batch_extract_within_existing_loop():
    """
    Test that batch_extract_with_llm works correctly when called from within an existing event loop.
    This simulates a scenario where the application is already running an async loop.
    """
    os.environ["MOCK_LLM"] = "true"
    texts = ["Project Prism description", "Database SQL info"]

    # This should not raise RuntimeError: asyncio.run() cannot be called from a running event loop
    # In the current implementation, it falls back to sequential sync calls.
    # We want to refactor it to handle the loop correctly while maintaining parallelism.
    results = batch_extract_with_llm(texts)

    assert results is not None
    assert len(results) == 2
    assert results[0][0]["term"] == "Prism"
    assert results[1][0]["term"] == "SQL"
@pytest.mark.asyncio
async def test_local_llm_client_batch_chat_within_existing_loop():
    """
    Test that LocalLLMClient.batch_chat works when called from within an existing loop.
    """
    os.environ["MOCK_LLM"] = "true"
    client = LocalLLMClient()
    messages_list = [[{"role": "user", "content": "test"}] for _ in range(2)]
    
    # batch_chat is already async, so we just await it
    results = await client.batch_chat(messages_list)
    
    assert len(results) == 2

@pytest.mark.asyncio
async def test_openai_client_batch_chat_within_existing_loop():
    """
    Test that OpenAIClientWrapper.batch_chat works when called from within an existing loop.
    """
    # Mock settings for OpenAI
    with patch("graph_sieve.llm_client.settings") as mock_settings:
        mock_settings.openai_api_key = "fake-key"
        mock_settings.llm_provider = "openai"
        mock_settings.model_name = "gpt-4o-mini"
        mock_settings.max_parallel_requests = 5
        
        client = OpenAIClientWrapper(api_key="fake-key")
        messages_list = [[{"role": "user", "content": "test"}] for _ in range(2)]
        
        # Mock the internal _async_chat to avoid actual API calls
        with patch.object(OpenAIClientWrapper, "_async_chat", return_value={"mock": "data"}):
            results = await client.batch_chat(messages_list)
            assert len(results) == 2
