import pytest
import numpy as np
from src.graph_sieve.resolution import VectorResolver
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import DictionaryEntry

class MockLLMClient:
    """Mock client returning pre-defined vectors for testing."""
    def __init__(self, embeddings_dict):
        self.embeddings_dict = embeddings_dict
        self.call_count = 0
        
    def get_embedding(self, text):
        self.call_count += 1
        # Default to a zero vector if not found
        return self.embeddings_dict.get(text, [0.0, 0.0, 0.0])

@pytest.fixture
def temp_db(tmp_path):
    """Provides a clean SQLite database for each test."""
    db_path = tmp_path / "test_resolution.db"
    return SQLiteStorage(db_path)

def test_vector_resolver_discovery(temp_db):
    # 1. Setup entries in the database
    temp_db.upsert_entry(DictionaryEntry(term="Sieve System", overview="A filtering system."))
    temp_db.upsert_entry(DictionaryEntry(term="מערכת סינון", overview="Hebrew for Sieve System."))
    temp_db.upsert_entry(DictionaryEntry(term="Coffee Machine", overview="Makes coffee."))
    
    # 2. Define mock embeddings
    # Sieve System and Hebrew counterpart are close (high cosine similarity)
    # Coffee Machine is orthogonal to both
    mock_embeddings = {
        "Sieve System": [1.0, 0.1, 0.0],
        "מערכת סינון": [0.98, 0.12, 0.01],
        "Coffee Machine": [0.0, 0.0, 1.0]
    }
    
    mock_client = MockLLMClient(mock_embeddings)
    resolver = VectorResolver(temp_db, llm_client=mock_client)
    
    # 3. Discover candidates with a high threshold
    candidates = resolver.discover_candidates(threshold=0.8)
    
    # Verify results
    assert len(candidates) == 1
    term1, term2, score = candidates[0]
    assert {term1, term2} == {"Sieve System", "מערכת סינון"}
    assert score > 0.95
    
    # Verify caching (should only call get_embedding once per term)
    assert mock_client.call_count == 3
    resolver.discover_candidates(threshold=0.8)
    assert mock_client.call_count == 3 # No new calls

def test_vector_resolver_empty_database(temp_db):
    mock_client = MockLLMClient({})
    resolver = VectorResolver(temp_db, llm_client=mock_client)
    candidates = resolver.discover_candidates()
    assert candidates == []

def test_vector_resolver_single_entry(temp_db):
    temp_db.upsert_entry(DictionaryEntry(term="Lone Term", overview="No friends."))
    mock_client = MockLLMClient({"Lone Term": [1.0, 0.0, 0.0]})
    resolver = VectorResolver(temp_db, llm_client=mock_client)
    candidates = resolver.discover_candidates()
    assert candidates == []

def test_vector_resolver_threshold_filtering(temp_db):
    temp_db.upsert_entry(DictionaryEntry(term="A", overview="."))
    temp_db.upsert_entry(DictionaryEntry(term="B", overview="."))
    
    # Similarity is 0.5 (orthogonal components)
    mock_embeddings = {
        "A": [1.0, 1.0, 0.0],
        "B": [1.0, 0.0, 0.0]
    }
    # Cosine similarity: (1*1 + 1*0) / (sqrt(2) * 1) = 1/sqrt(2) approx 0.707
    
    mock_client = MockLLMClient(mock_embeddings)
    resolver = VectorResolver(temp_db, llm_client=mock_client)
    
    # High threshold - no candidates
    assert len(resolver.discover_candidates(threshold=0.9)) == 0
    
    # Low threshold - candidate found
    assert len(resolver.discover_candidates(threshold=0.5)) == 1
