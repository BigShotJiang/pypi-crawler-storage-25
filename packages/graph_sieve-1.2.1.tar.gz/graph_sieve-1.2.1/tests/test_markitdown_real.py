
import os
import pytest
from src.graph_sieve.extractor import extract_all
from docx import Document

@pytest.fixture
def mixed_txt_file(tmp_path):
    p = tmp_path / "mixed.txt"
    text = "היום בdaily דיברנו על הבעיות בAIPים, good luck with that אחים שלי"
    p.write_text(text, encoding="utf-8")
    return str(p)

@pytest.fixture
def mixed_docx_file(tmp_path):
    p = tmp_path / "mixed.docx"
    doc = Document()
    doc.add_paragraph("This is a test of mixed language.")
    doc.add_paragraph("היום בdaily דיברנו על הבעיות בAIPים.")
    doc.save(str(p))
    return str(p)

def test_real_markitdown_txt(mixed_txt_file):
    # For .txt, we use our custom extractor first
    # extract_all returns a generator
    text = "".join(list(extract_all(mixed_txt_file)))
    print(f"\nTXT Extracted: {text}")
    # normalize_rtl_text will reverse it for display.
    # So "daily" might become "daily" (English words in middle usually stay if not spanning whole line)
    # But Hebrew words definitely reverse.
    assert "daily" in text and not "yliad" in text
    assert "AIP" in text and not "PIA" in text

def test_real_markitdown_docx(mixed_docx_file):
    # For .docx, MarkItDown is used
    text = "".join(list(extract_all(mixed_docx_file)))
    print(f"\nDOCX Extracted: {text}")
    assert "daily" in text and not "yliad" in text
    assert "AIP" in text and not "IPA" in text
