import asyncio
import pytest
import os
from unittest.mock import patch, MagicMock
from graph_sieve.llm_client import LocalLLMClient, OpenAIClientWrapper
from graph_sieve.config import settings

@pytest.mark.asyncio
async def test_local_llm_client_semaphore_usage():
    """
    Test that LocalLLMClient.batch_chat correctly uses a semaphore.
    """
    os.environ["MOCK_LLM"] = "false"
    client = LocalLLMClient()
    messages_list = [[{"role": "user", "content": "test"}] for _ in range(3)]
    
    with patch("graph_sieve.llm_client.asyncio.Semaphore", wraps=asyncio.Semaphore) as mock_semaphore:
        # Mock _async_chat to avoid actual API calls
        with patch.object(LocalLLMClient, "_async_chat", return_value={"mock": "data"}):
            await client.batch_chat(messages_list)
            
            # Check if Semaphore was initialized with max_parallel_requests
            mock_semaphore.assert_called_with(settings.max_parallel_requests)

@pytest.mark.asyncio
async def test_openai_client_semaphore_usage():
    """
    Test that OpenAIClientWrapper.batch_chat correctly uses a semaphore.
    """
    with patch("graph_sieve.llm_client.settings") as mock_settings:
        mock_settings.openai_api_key = "fake-key"
        mock_settings.llm_provider = "openai"
        mock_settings.max_parallel_requests = 2
        
        client = OpenAIClientWrapper(api_key="fake-key")
        messages_list = [[{"role": "user", "content": "test"}] for _ in range(3)]
        
        with patch("graph_sieve.llm_client.asyncio.Semaphore", wraps=asyncio.Semaphore) as mock_semaphore:
            # Mock _async_chat to avoid actual API calls
            with patch.object(OpenAIClientWrapper, "_async_chat", return_value={"mock": "data"}):
                await client.batch_chat(messages_list)
                
                # Check if Semaphore was initialized with the mocked settings value
                mock_semaphore.assert_called_with(2)
