import pytest
from pathlib import Path
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.models import GraphTriplet, DictionaryEntry

def test_global_entity_resolution_folding(tmp_path):
    db_path = tmp_path / "test_folding.db"
    storage = SQLiteStorage(db_path=db_path)
    engine = GraphKnowledgeEngine(storage=storage)

    # 1. Setup entries with aliases
    storage.upsert_entry(DictionaryEntry(
        term="Artificial Intelligence Platform",
        overview="A central AI platform.",
        confidence_level="GOLD",
        status="ACTIVE"
    ))
    storage.upsert_entry(DictionaryEntry(
        term="AIP",
        overview="An AI platform used in the project.",
        canonical_id="Artificial Intelligence Platform",
        confidence_level="SILVER",
        status="ACTIVE"
    ))

    # 2. Add relationships using both terms
    storage.add_relationship(GraphTriplet(
        subject="User Service",
        relationship="USES",
        object="AIP"
    ))
    storage.add_relationship(GraphTriplet(
        subject="Artificial Intelligence Platform",
        relationship="DEPENDS_ON",
        object="GPU Cluster"
    ))

    # 3. Build graph and check folding
    G = engine.build_nx_graph()
    
    # "AIP" should be folded into "Artificial Intelligence Platform"
    assert "Artificial Intelligence Platform" in G.nodes
    assert "AIP" not in G.nodes
    
    # Edges should be redirected
    assert G.has_edge("User Service", "Artificial Intelligence Platform")
    assert G.has_edge("Artificial Intelligence Platform", "GPU Cluster")

def test_cross_community_linking(tmp_path):
    db_path = tmp_path / "test_cross_comm.db"
    storage = SQLiteStorage(db_path=db_path)
    engine = GraphKnowledgeEngine(storage=storage)

    # Setup two communities
    # Community 1: Frontend
    storage.upsert_entry(DictionaryEntry(term="React", overview="Frontend framework.", status="ACTIVE"))
    storage.upsert_entry(DictionaryEntry(term="Tailwind", overview="CSS framework.", status="ACTIVE"))
    storage.add_relationship(GraphTriplet(subject="React", relationship="USES", object="Tailwind"))

    # Community 2: Backend
    storage.upsert_entry(DictionaryEntry(term="FastAPI", overview="Backend framework.", status="ACTIVE"))
    storage.upsert_entry(DictionaryEntry(term="PostgreSQL", overview="Database.", status="ACTIVE"))
    storage.add_relationship(GraphTriplet(subject="FastAPI", relationship="STORES_DATA_IN", object="PostgreSQL"))

    # Cross-link
    storage.add_relationship(GraphTriplet(subject="React", relationship="USES", object="FastAPI"))

    # Cluster communities
    # We expect 2 communities: {React, Tailwind} and {FastAPI, PostgreSQL} 
    # (depending on weights, but let's assume they split)
    comms = engine.cluster_communities(prune_threshold=0.1)
    
    # Verify we have communities
    assert len(comms) >= 1
