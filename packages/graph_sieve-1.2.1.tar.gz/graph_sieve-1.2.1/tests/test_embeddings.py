import pytest
from unittest.mock import MagicMock, patch
from graph_sieve.llm_client import OpenAIClientWrapper, LocalLLMClient, LLMClientError
from graph_sieve.config import Settings

def test_config_embedding_model():
    """Test that embedding_model is present in config."""
    s = Settings()
    # This should fail if embedding_model is not added yet
    assert hasattr(s, "embedding_model")
    assert s.embedding_model == "text-embedding-3-small"

@patch("graph_sieve.llm_client.OpenAI")
def test_openai_get_embedding(mock_openai):
    """Test OpenAIClientWrapper.get_embedding."""
    mock_client = MagicMock()
    mock_openai.return_value = mock_client
    
    # Mock the response from client.embeddings.create
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2, 0.3]
    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]
    mock_client.embeddings.create.return_value = mock_response

    wrapper = OpenAIClientWrapper(api_key="test-key")
    embedding = wrapper.get_embedding("hello world")
    
    assert isinstance(embedding, list)
    assert all(isinstance(x, float) for x in embedding)
    assert embedding == [0.1, 0.2, 0.3]
    mock_client.embeddings.create.assert_called_once()

@patch("requests.post")
def test_local_llm_get_embedding_ollama(mock_post):
    """Test LocalLLMClient.get_embedding with Ollama API."""
    with patch.dict("os.environ", {"MOCK_LLM": "false"}):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"embedding": [0.4, 0.5, 0.6]}
        mock_post.return_value = mock_response

        client = LocalLLMClient(base_url="http://localhost:11434")
        embedding = client.get_embedding("hello world")
        
        assert isinstance(embedding, list)
        assert embedding == [0.4, 0.5, 0.6]
        # Check that it called the correct endpoint
        args, kwargs = mock_post.call_args
        assert args[0] == "http://localhost:11434/api/embeddings"

def test_local_llm_get_embedding_mock():
    """Test LocalLLMClient.get_embedding with MOCK_LLM=true."""
    with patch.dict("os.environ", {"MOCK_LLM": "true"}):
        client = LocalLLMClient()
        embedding = client.get_embedding("hello world")
        assert len(embedding) == 1536
        assert all(x == 0.0 for x in embedding)
