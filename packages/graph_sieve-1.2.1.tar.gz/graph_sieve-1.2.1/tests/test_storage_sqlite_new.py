import pytest
import sqlite3
from pathlib import Path
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import (
    DictionaryEntry,
    GraphTriplet,
    CommunityReport,
    UsageExample
)

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_graph_sieve_new.db"
    storage = SQLiteStorage(db_path)
    return storage

def test_get_term_exists(temp_db):
    entry = DictionaryEntry(
        term="Test Term",
        overview="A test overview."
    )
    temp_db.upsert_entry(entry)
    temp_db.add_usage_example("Test Term", "test.txt", "Example context")
    
    assert temp_db.get_term_exists("Test Term") is True
    assert temp_db.get_term_exists("Non-existent Term") is False

def test_get_bounty_candidates(temp_db):
    # Bounty terms
    bounty1 = DictionaryEntry(term="Bounty 1", overview="O1", is_bounty=True)
    bounty2 = DictionaryEntry(term="Bounty 2", overview="O2", is_bounty=True)
    # Non-bounty term
    regular = DictionaryEntry(term="Regular", overview="OR", is_bounty=False)
    
    temp_db.upsert_entry(bounty1)
    temp_db.add_usage_example("Bounty 1", "S1", "Example context")
    temp_db.upsert_entry(bounty2)
    temp_db.add_usage_example("Bounty 2", "S2", "Example context")
    temp_db.upsert_entry(regular)
    temp_db.add_usage_example("Regular", "SR", "Example context")
    
    candidates = temp_db.get_bounty_candidates(limit=10)
    assert len(candidates) == 2
    terms = [e.term for e in candidates]
    assert "Bounty 1" in terms
    assert "Bounty 2" in terms
    assert "Regular" not in terms

def test_get_active_terms_count(temp_db):
    entry1 = DictionaryEntry(term="T1", overview="O1", status="ACTIVE")
    entry2 = DictionaryEntry(term="T2", overview="O2", status="LEGACY")
    entry3 = DictionaryEntry(term="T3", overview="O3", status="ACTIVE")
    
    temp_db.upsert_entry(entry1)
    temp_db.add_usage_example("T1", "S1", "Example context")
    temp_db.upsert_entry(entry2)
    temp_db.add_usage_example("T2", "S2", "Example context")
    temp_db.upsert_entry(entry3)
    temp_db.add_usage_example("T3", "S3", "Example context")
    
    assert temp_db.get_active_terms_count() == 2

def test_get_relationships_count(temp_db):
    rel1 = GraphTriplet(subject="A", relationship="USES", object="B")
    rel2 = GraphTriplet(subject="B", relationship="DEPENDS_ON", object="C")
    
    rid1 = temp_db.add_relationship(rel1)
    temp_db.add_relationship_evidence(rid1, "S1", "A uses B")
    rid2 = temp_db.add_relationship(rel2)
    temp_db.add_relationship_evidence(rid2, "S1", "B depends on C")
    
    assert temp_db.get_relationships_count() == 2

def test_get_all_community_reports(temp_db):
    report1 = CommunityReport(community_id="C1", title="Title 1", summary="S1", nodes=["N1", "N2"])
    report2 = CommunityReport(community_id="C2", title="Title 2", summary="S2", nodes=["N3", "N4"])
    
    temp_db.upsert_community_report(report1)
    temp_db.upsert_community_report(report2)
    
    reports = temp_db.get_all_community_reports()
    assert len(reports) == 2
    ids = [r.community_id for r in reports]
    assert "C1" in ids
    assert "C2" in ids
    assert reports[0].nodes == ["N1", "N2"] or reports[0].nodes == ["N3", "N4"]

def test_log_llm_interaction(temp_db):
    from src.graph_sieve.models import LLMLogEntry
    entry = LLMLogEntry(
        provider="openai",
        model="gpt-4",
        endpoint="/chat/completions",
        prompt="Hi",
        response="Hello",
        latency_ms=100.0,
        prompt_tokens=10,
        completion_tokens=5,
        total_tokens=15,
        cost=0.0001
    )
    temp_db.log_llm_interaction(entry)
    
    with temp_db._get_connection() as conn:
        row = conn.execute("SELECT * FROM llm_logs").fetchone()
        assert row is not None
        assert row['prompt'] == "Hi"

def test_link_alias(temp_db):
    # Setup entries
    canonical = DictionaryEntry(term="Canonical", overview="C")
    alias = DictionaryEntry(term="Alias", overview="A")
    temp_db.upsert_entry(canonical)
    temp_db.add_usage_example("Canonical", "S", "Context")
    temp_db.upsert_entry(alias)
    temp_db.add_usage_example("Alias", "S", "Context")
    
    temp_db.link_alias("Alias", "Canonical")
    
    retrieved_alias = temp_db.get_entry("Alias")
    assert retrieved_alias.canonical_id == "Canonical"
    
    rels = temp_db.get_relationships(subject="Alias")
    assert len(rels) == 1
    assert rels[0].relationship == "ALIAS_OF"
    assert rels[0].object == "Canonical"

def test_get_relationships_filters(temp_db):
    rel1 = GraphTriplet(subject="A", relationship="USES", object="B")
    rel2 = GraphTriplet(subject="B", relationship="USES", object="C")
    rid1 = temp_db.add_relationship(rel1)
    temp_db.add_relationship_evidence(rid1, "S", "A uses B")
    rid2 = temp_db.add_relationship(rel2)
    temp_db.add_relationship_evidence(rid2, "S", "B uses C")
    
    # Filter by subject
    assert len(temp_db.get_relationships(subject="A")) == 1
    # Filter by object
    assert len(temp_db.get_relationships(object="C")) == 1
    # Filter by both
    assert len(temp_db.get_relationships(subject="A", object="B")) == 1
    # No matches
    assert len(temp_db.get_relationships(subject="Z")) == 0

def test_upsert_and_get_chunk_cache(temp_db):
    data = [{"term": "T1", "type": "PROJECT"}]
    temp_db.upsert_chunk_cache("hash1", data)
    
    retrieved = temp_db.get_chunk_cache("hash1")
    assert retrieved == data
    assert temp_db.get_chunk_cache("non-existent") is None

def test_get_none_cases(temp_db):
    assert temp_db.get_entry("Missing") is None
    assert temp_db.get_community_report("Missing") is None
    assert temp_db.get_global_report() is None

def test_migration_canonical_id(tmp_path):
    db_path = tmp_path / "migration_test.db"
    # Create DB without canonical_id
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE entries (term TEXT PRIMARY KEY, overview TEXT)")
    conn.close()
    
    # Initialize storage, it should trigger migration
    storage = SQLiteStorage(db_path)
    
    with storage._get_connection() as conn:
        cursor = conn.execute("PRAGMA table_info(entries)")
        columns = [row['name'] for row in cursor.fetchall()]
        assert 'canonical_id' in columns
