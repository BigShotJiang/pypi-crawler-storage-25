import pytest
import os
from src.graph_sieve.extractor import chunk_text_stream, extract_text_from_txt
from src.graph_sieve.agent import DictionaryAgent
from unittest.mock import MagicMock, patch

def test_chunk_text_stream_basic(tmp_path):
    # Create a dummy file
    f = tmp_path / "test.txt"
    f.write_text("Sentence one. Sentence two. Sentence three. Sentence four.")
    
    # Use small chunk size to force multiple chunks
    text_stream = ["Sentence one. ", "Sentence two. ", "Sentence three. ", "Sentence four."]
    chunks = list(chunk_text_stream(text_stream, str(f), chunk_size=20, overlap=5))
    
    assert len(chunks) > 1
    for chunk in chunks:
        assert "[Context: Source File: test.txt]" in chunk
        assert len(chunk) > 30 # Metadata + content

def test_chunk_text_stream_overlap(tmp_path):
    f = tmp_path / "overlap.txt"
    f.write_text("A" * 50)
    
    text_stream = ["A" * 25, "A" * 25]
    # chunk_size=20, overlap=10
    chunks = list(chunk_text_stream(text_stream, str(f), chunk_size=20, overlap=10))
    
    # First chunk should be around 20 chars of 'A's (plus metadata)
    # Second chunk should start with the last 10 chars of the first chunk
    content0 = chunks[0].split("\n\n")[-1]
    content1 = chunks[1].split("\n\n")[-1]
    
    assert content0.endswith(content1[:10])

def test_chunk_text_stream_natural_boundaries(tmp_path):
    f = tmp_path / "natural.txt"
    # Create content with a paragraph break near the chunk_size (50)
    # "A" * 40 + "\n\n" + "B" * 40
    p1 = "A" * 40
    p2 = "B" * 40
    content = p1 + "\n\n" + p2
    f.write_text(content)
    
    text_stream = [p1, "\n\n", p2]
    # chunk_size=50. The paragraph break is at index 40.
    # Without natural breaks, it would take 50 chars.
    # With natural breaks, it should take 40 chars and yield the first paragraph.
    chunks = list(chunk_text_stream(text_stream, str(f), chunk_size=50, overlap=0))
    
    assert len(chunks) >= 2
    # The first chunk content (after metadata) should be exactly p1
    content0 = chunks[0].split("\n\n")[-1]
    assert content0 == p1

def test_chunk_text_stream_natural_sentence_boundaries(tmp_path):
    f = tmp_path / "sentence.txt"
    p1 = "Sentence one. "
    p2 = "Sentence two? "
    p3 = "Sentence three! "
    p4 = "This is a long sentence that should be split."
    content = p1 + p2 + p3 + p4
    f.write_text(content)
    
    text_stream = [p1, p2, p3, p4]
    # chunk_size=25. 
    # Chunk 1: "Sentence one. " (14) + "Sentence two? " (14) = 28 > 25.
    # It should break at "Sentence one. "
    chunks = list(chunk_text_stream(text_stream, str(f), chunk_size=25, overlap=0))
    
    assert len(chunks) >= 4
    content0 = chunks[0].split("\n\n")[-1]
    assert content0 == p1.strip()

@pytest.fixture
def agent(tmp_path):
    db_path = tmp_path / "test_stream.db"
    from src.graph_sieve.storage_sqlite import SQLiteStorage
    storage = SQLiteStorage(db_path=db_path)
    return DictionaryAgent(storage=storage)

def test_process_document_streaming_batches(agent, tmp_path):
    # Create a "large" file that would result in multiple batches
    f = tmp_path / "large.txt"
    
    # Mock discovery results
    mock_discovery = [{"term": "TestTerm", "overview": "Desc", "entity_type": "PROJECT"}]
    mock_validation = {"is_valid": True, "confidence_level": "GOLD"}
    
    # Patch where they are used in agent.py
    # batch_validate_with_llm is imported at top level of agent.py
    # batch_extract_with_llm is imported locally in process_batch from .discovery
    with patch("src.graph_sieve.agent.batch_validate_with_llm") as mock_val, \
         patch("src.graph_sieve.discovery.batch_extract_with_llm") as mock_batch:
        
        mock_val.side_effect = lambda ctx, items: [mock_validation] * len(items)
        mock_batch.side_effect = lambda chunks, **kwargs: [mock_discovery] * len(chunks)
        
        # Ensure the content contains the term so even if validation wasn't mocked, it might pass
        # But we definitely want to mock it.
        content_v2 = "\n\n".join([f"Sentence {i} TestTerm " * 10 for i in range(600)])
        f.write_text(content_v2)
        
        added = agent.process_document(str(f))
        
        assert "TestTerm" in added
        assert mock_batch.call_count >= 2
        
        # Verify no file_cache was created for .txt
        file_hash = agent.hash_store.get_hash(str(f))
        assert agent.storage.get_file_cache(file_hash) is None
