import pytest
from src.graph_sieve.discovery import get_extractor_system_prompt
from src.graph_sieve.validator import verify_anchor_exists
from src.graph_sieve.prompts import VALIDATOR_SYSTEM_TEMPLATE

def test_extractor_prompt_contains_contrastive_filtering():
    prompt = get_extractor_system_prompt()
    assert "REJECT generic tech terms" in prompt
    assert "DO NOT EXTRACT \"GitHub\"" in prompt

def test_validator_prompt_structure():
    assert "ZERO-TRUST PROTOCOL" in VALIDATOR_SYSTEM_TEMPLATE
    assert "OCR TOLERANCE" in VALIDATOR_SYSTEM_TEMPLATE

def test_verify_anchor_exists_with_minor_noise():
    raw_text = "The project Prism uses port 8080 for internal communication."
    # Minor OCR noise: 'Prism' -> 'Prlsm', '8080' -> '8O8O'
    noisy_anchor = "The project Prlsm uses port 8O8O"
    
    # New default threshold is 0.7. Let's see if it passes now.
    assert verify_anchor_exists(raw_text, noisy_anchor) == True
