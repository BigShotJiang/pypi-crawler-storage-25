"""第 1-2 层：Softmax 归一化与因果 EMA 置信度融合。

理论背景 — 当信号服从随机游走 + 白噪声模型时，EMA 是最优线性因果估计器
（Brown 1956；Kalman 滤波在随机游走假设下退化为 EMA）。
单参数 *alpha* 控制响应速度与平滑度之间的权衡。

作者：刘秉其
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .confidence_config import FusionConfig


def softmax(logits: np.ndarray) -> np.ndarray:
    """数值稳定的 softmax，沿最后一个轴计算。"""
    shifted = logits - np.max(logits, axis=-1, keepdims=True)
    exp = np.exp(shifted)
    return exp / np.sum(exp, axis=-1, keepdims=True)


@dataclass
class FusionResult:
    """融合预测的不可变快照。"""

    event_type: int
    confidence: float
    probabilities: np.ndarray
    frame_count: int

    @property
    def fused(self) -> bool:
        return self.frame_count > 1


class ConfidenceFusion:
    """对概率向量进行因果指数移动平均（EMA）融合。

    递推公式：p̃_t = α · p_t + (1 − α) · p̃_{t−1}

    参数来自 :class:`FusionConfig`；两级阈值实现双重门控：

    * ``base_threshold`` — 单帧预过滤（丢弃置信度过低的原始帧，
      避免其污染 EMA 状态）。
    * ``output_threshold`` — 融合后过滤（抑制融合后置信度仍不足
      以采取行动的结果）。
    """

    def __init__(self, config: FusionConfig | None = None, *, alpha: float | None = None) -> None:
        self._cfg = config or FusionConfig()
        if alpha is not None:
            self._cfg = FusionConfig(
                alpha=alpha,
                output_threshold=self._cfg.output_threshold,
                base_threshold=self._cfg.base_threshold,
            )
        if not (0.0 < self._cfg.alpha <= 1.0):
            raise ValueError(f"alpha 必须在 (0, 1] 区间内，当前值为 {self._cfg.alpha}")
        self._state: Optional[np.ndarray] = None
        self._frames: int = 0

    @property
    def alpha(self) -> float:
        return self._cfg.alpha

    @property
    def frame_count(self) -> int:
        return self._frames

    # --- 核心 API -----------------------------------------------------------

    def update(self, probabilities: np.ndarray) -> None:
        """输入一个新的概率向量并推进 EMA 状态。

        若该帧峰值概率低于 ``base_threshold``，则静默忽略（仅增加噪声）。
        """
        p = np.asarray(probabilities, dtype=np.float64)
        if np.max(p) < self._cfg.base_threshold:
            return
        if self._state is None:
            self._state = p.copy()
        else:
            self._state = self._cfg.alpha * p + (1.0 - self._cfg.alpha) * self._state
        self._frames += 1

    def update_logits(self, logits: np.ndarray) -> None:
        """便捷封装：softmax + update 一步完成。"""
        self.update(softmax(np.asarray(logits, dtype=np.float64)))

    def query(self) -> Optional[FusionResult]:
        """返回当前融合预测结果，若无有效数据则返回 *None*。"""
        if self._state is None:
            return None
        idx = int(np.argmax(self._state))
        conf = float(self._state[idx])
        if conf < self._cfg.output_threshold:
            return None
        return FusionResult(
            event_type=idx,
            confidence=conf,
            probabilities=self._state.copy(),
            frame_count=self._frames,
        )

    def reset(self) -> None:
        """清除内部状态（例如场景切换或长时间静默时使用）。"""
        self._state = None
        self._frames = 0
