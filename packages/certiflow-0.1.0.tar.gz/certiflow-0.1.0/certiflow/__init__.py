"""CertiFlow — 可复用的置信度融合与风险评分工具包。

最小依赖：仅需 numpy。

作者：刘秉其

快速开始::

    from certiflow import ConfidencePipeline, ConfidenceConfig

    config = ConfidenceConfig.from_dict({"alpha": 0.6, "output_threshold": 0.2})
    pipeline = ConfidencePipeline(config)

    # 流式处理：逐帧输入
    result = pipeline.process_logits(logits_array)

    # 批量处理：传入事件列表
    full = pipeline.process_events(events)
"""

__author__ = "刘秉其"
__version__ = "0.1.0"

from .confidence_config import (
    ConfidenceConfig,
    DriftConfig,
    FusionConfig,
    MergerConfig,
    RiskConfig,
)
from .confidence_fusion import ConfidenceFusion, FusionResult, softmax
from .drift_monitor import DriftMonitor, DriftResult
from .event_merger import merge_events
from .pipeline import ConfidencePipeline, PipelineResult
from .risk_engine import RiskEngine, RiskResult

__all__ = [
    # 配置
    "ConfidenceConfig",
    "FusionConfig",
    "MergerConfig",
    "RiskConfig",
    "DriftConfig",
    # 第 1-2 层
    "softmax",
    "ConfidenceFusion",
    "FusionResult",
    # 第 3 层
    "merge_events",
    # 第 4 层
    "RiskEngine",
    "RiskResult",
    # 第 5 层
    "DriftMonitor",
    "DriftResult",
    # 流水线
    "ConfidencePipeline",
    "PipelineResult",
]
