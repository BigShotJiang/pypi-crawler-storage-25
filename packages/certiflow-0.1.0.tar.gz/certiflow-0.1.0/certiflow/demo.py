#!/usr/bin/env python3
"""可运行演示 — 生成合成的 10 类 logits 并通过完整的五层置信度流水线处理。

    python -m certiflow.demo

作者：刘秉其
"""

from __future__ import annotations

import numpy as np

from certiflow import ConfidenceConfig, ConfidencePipeline


def _generate_logits(
    n_frames: int = 40,
    n_classes: int = 10,
    *,
    seed: int = 42,
) -> np.ndarray:
    """合成一个 (n_frames, n_classes) 的 logits 矩阵。

    模拟三个阶段：
      1. 噪声底面（帧 0–14）
      2. 事件发作，主导类为 3（帧 15–29）
      3. 事件衰减，回归噪声（帧 30–39）
    """
    rng = np.random.default_rng(seed)
    logits = rng.standard_normal((n_frames, n_classes)) * 0.3

    for i in range(15, 30):
        intensity = 2.0 + 1.5 * np.sin(np.pi * (i - 15) / 15)
        logits[i, 3] += intensity
        logits[i, 7] += intensity * 0.3

    return logits


def _separator(title: str) -> None:
    width = 60
    print(f"\n{'=' * width}")
    print(f"  {title}")
    print(f"{'=' * width}")


def main() -> None:
    config = ConfidenceConfig.from_dict({
        "alpha": 0.6,
        "output_threshold": 0.2,
        "base_threshold": 0.05,
    })
    pipeline = ConfidencePipeline(config)

    logits = _generate_logits()
    n_frames, n_classes = logits.shape
    print(f"合成数据：{n_frames} 帧 × {n_classes} 类")

    # --- 第 1–2 层：逐帧融合 ------------------------------------------------
    _separator("第 1-2 层：Softmax + EMA 融合")
    for i in range(n_frames):
        result = pipeline.process_logits(logits[i])
        if result is not None and i % 5 == 0:
            print(
                f"  帧 {i:>3d}  →  类别={result.event_type}  "
                f"置信度={result.confidence:.4f}  已融合={result.fused}"
            )

    # --- 第 3–5 层：批量处理 ------------------------------------------------
    _separator("完整流水线（端到端）")

    pipeline.reset()
    full = pipeline.process_full(logits, frame_duration_sec=0.5)

    print(f"\n  融合检测数：  {len(full.fused)}")
    print(f"  原始事件数：  {len(full.events_raw)}")
    print(f"  合并事件数：  {len(full.events_merged)}")

    _separator("第 3 层：合并后事件")
    for ev in full.events_merged:
        print(
            f"  类型={ev['event_type']}  置信度={ev['confidence']:.4f}  "
            f"[{ev['start_sec']:.2f}s – {ev['end_sec']:.2f}s]  "
            f"时长={ev['duration_sec']:.2f}s"
        )

    _separator("第 4 层：风险评估")
    if full.risk:
        print(f"  评分：       {full.risk.score}")
        print(f"  等级：       {full.risk.level}")
        print(f"  不确定性：   {full.risk.uncertainty}")
        print(f"  需复核：     {full.risk.requires_review}")
        print(f"  特征：       { {k: round(v, 3) for k, v in full.risk.features.items()} }")

    _separator("第 5 层：漂移检测")
    if full.drift:
        print(f"  检测到漂移： {full.drift.detected}")
        print(f"  置信度偏移： {full.drift.confidence_shift}")
        print(f"  类型偏移：   {full.drift.type_shift}")
        print(f"  模式：       {full.drift.mode}")
        if full.drift.reason:
            print(f"  原因：       {full.drift.reason}")

    print()


if __name__ == "__main__":
    main()
