"""第 3 层：合并同类重叠/相邻事件。

滑动窗口检测器通常会为同一个真实事件产生大量细碎的重叠检测结果。
本模块将这些结果压缩为紧凑的事件序列，每个合并组保留最高置信度和最宽时间跨度。

作者：刘秉其
"""

from __future__ import annotations

from typing import Any, Dict, List

from .confidence_config import MergerConfig


def merge_events(
    events: List[Dict[str, Any]],
    config: MergerConfig | None = None,
) -> List[Dict[str, Any]]:
    """合并时间跨度重叠或相近的同类事件。

    每个事件字典需至少包含以下字段：

    * ``event_type`` — 可哈希的标签（str 或 int）
    * ``confidence`` — 置信度浮点数，范围 [0, 1]
    * ``start_sec``  — 起始时间（秒）
    * ``end_sec``    — 结束时间（秒）

    返回新列表，不修改原始输入。
    """
    if not events:
        return []

    cfg = config or MergerConfig()
    gap = cfg.max_gap_sec

    def _start(e: Dict[str, Any]) -> float:
        return float(e.get("start_sec", 0.0) or 0.0)

    def _end(e: Dict[str, Any]) -> float:
        return float(e.get("end_sec", 0.0) or 0.0)

    ordered = sorted(events, key=lambda e: (_start(e), _end(e)))
    merged: List[Dict[str, Any]] = []

    for ev in ordered:
        etype = ev.get("event_type", "unknown")
        s, t = _start(ev), _end(ev)
        conf = float(ev.get("confidence", 0.0) or 0.0)

        if not merged:
            merged.append({"event_type": etype, "start_sec": s, "end_sec": t,
                           "confidence": conf, "fused": ev.get("fused", False)})
            continue

        last = merged[-1]
        if etype == last["event_type"] and s <= last["end_sec"] + gap:
            last["start_sec"] = min(last["start_sec"], s)
            last["end_sec"] = max(last["end_sec"], t)
            last["confidence"] = max(last["confidence"], conf)
            last["fused"] = last["fused"] or ev.get("fused", False)
        else:
            merged.append({"event_type": etype, "start_sec": s, "end_sec": t,
                           "confidence": conf, "fused": ev.get("fused", False)})

    for ev in merged:
        ev["duration_sec"] = round(ev["end_sec"] - ev["start_sec"], 6)

    return merged
