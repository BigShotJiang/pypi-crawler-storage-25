"""第 5 层：在线置信度漂移检测。

将当前批次的置信度值与滚动参考窗口进行比较，支持三种检测模式：

* **threshold** — 当均值偏移超过固定阈值时标记漂移。
* **z_test**    — 当双样本 z 检验显著且效应量足够大时标记漂移。
* **page_hinkley** — 累积和变点检测（Page 1954, Hinkley 1971）。

作者：刘秉其
"""

from __future__ import annotations

import math
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

from .confidence_config import DriftConfig


@dataclass
class DriftResult:
    """漂移评估的不可变输出。"""

    detected: bool
    confidence_shift: float
    type_shift: float
    reference_size: int
    mode: str
    p_value: Optional[float] = None
    reason: str = ""


@dataclass
class _StreamState:
    ref_conf: Deque[float] = field(default_factory=lambda: deque(maxlen=200))
    ref_types: Deque[str] = field(default_factory=lambda: deque(maxlen=200))
    ph_mean: float = 0.0
    ph_cum: float = 0.0
    ph_min: float = 0.0
    ph_n: int = 0


class DriftMonitor:
    """在线漂移检测器，将当前批次与参考窗口进行比较。"""

    def __init__(self, config: DriftConfig | None = None) -> None:
        self._cfg = config or DriftConfig()
        self._streams: Dict[str, _StreamState] = {}

    def evaluate(
        self,
        events: List[Dict[str, Any]],
        stream_key: str = "global",
    ) -> DriftResult:
        """评估当前 *events* 是否表明分布发生漂移。"""
        if not self._cfg.enabled:
            return DriftResult(detected=False, confidence_shift=0.0,
                               type_shift=0.0, reference_size=0,
                               mode=self._cfg.mode, reason="disabled")

        state = self._get_state(stream_key)

        cur_conf = [_safe_conf(e) for e in events]
        cur_types = [str(e.get("event_type", "unknown")).lower() for e in events]

        if not cur_conf:
            return DriftResult(detected=False, confidence_shift=0.0,
                               type_shift=0.0, reference_size=len(state.ref_conf),
                               mode=self._cfg.mode, reason="no_events")

        if len(state.ref_conf) < self._cfg.min_samples:
            state.ref_conf.extend(cur_conf)
            state.ref_types.extend(cur_types)
            return DriftResult(detected=False, confidence_shift=0.0,
                               type_shift=0.0, reference_size=len(state.ref_conf),
                               mode=self._cfg.mode, reason="warming_up")

        ref_mean = sum(state.ref_conf) / max(len(state.ref_conf), 1)
        cur_mean = sum(cur_conf) / max(len(cur_conf), 1)
        conf_shift = abs(cur_mean - ref_mean)
        type_shift = _tvd(_distribution(list(state.ref_types)), _distribution(cur_types))

        mode = (self._cfg.mode or "threshold").strip().lower()
        p_value: Optional[float] = None

        if mode == "z_test":
            detected, p_value = self._z_test_detect(
                list(state.ref_conf), cur_conf, type_shift,
            )
        elif mode == "page_hinkley":
            detected = self._page_hinkley_detect(state, cur_mean, type_shift)
        else:
            detected = (
                conf_shift >= self._cfg.confidence_shift_threshold
                or type_shift >= self._cfg.type_shift_threshold
            )

        state.ref_conf.extend(cur_conf)
        state.ref_types.extend(cur_types)

        return DriftResult(
            detected=detected,
            confidence_shift=round(conf_shift, 4),
            type_shift=round(type_shift, 4),
            reference_size=len(state.ref_conf),
            mode=mode,
            p_value=round(p_value, 6) if p_value is not None else None,
        )

    def reset(self, stream_key: str | None = None) -> None:
        """清除一个或所有流的参考数据。"""
        if stream_key is None:
            self._streams.clear()
        else:
            self._streams.pop(stream_key, None)

    # --- 内部辅助方法 -------------------------------------------------------

    def _get_state(self, key: str) -> _StreamState:
        if key not in self._streams:
            ws = self._cfg.window_size
            self._streams[key] = _StreamState(
                ref_conf=deque(maxlen=ws),
                ref_types=deque(maxlen=ws),
            )
        return self._streams[key]

    def _z_test_detect(
        self,
        ref: List[float],
        cur: List[float],
        type_shift: float,
    ) -> Tuple[bool, float]:
        p_value, effect = _z_test(ref, cur)
        detected = (
            (p_value < self._cfg.significance_level
             and effect >= self._cfg.min_effect_size)
            or type_shift >= self._cfg.type_shift_threshold
        )
        return detected, p_value

    def _page_hinkley_detect(
        self,
        state: _StreamState,
        signal: float,
        type_shift: float,
    ) -> bool:
        state.ph_n += 1
        alpha = min(max(self._cfg.page_hinkley_alpha, 0.0), 1.0)
        delta = max(self._cfg.page_hinkley_delta, 0.0)
        state.ph_mean = alpha * state.ph_mean + (1.0 - alpha) * signal
        state.ph_cum += signal - state.ph_mean - delta
        state.ph_min = min(state.ph_min, state.ph_cum)
        statistic = state.ph_cum - state.ph_min
        return (
            statistic > self._cfg.page_hinkley_lambda
            or type_shift >= self._cfg.type_shift_threshold
        )


# --- 纯函数辅助（无状态）---------------------------------------------------

def _safe_conf(event: Dict[str, Any]) -> float:
    try:
        return float(event.get("confidence", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _distribution(labels: List[str]) -> Dict[str, float]:
    total = max(len(labels), 1)
    counts = Counter(labels)
    return {k: v / total for k, v in counts.items()}


def _tvd(ref: Dict[str, float], cur: Dict[str, float]) -> float:
    """两个离散分布之间的总变差距离。"""
    keys = set(ref) | set(cur)
    return 0.5 * sum(abs(ref.get(k, 0.0) - cur.get(k, 0.0)) for k in keys) if keys else 0.0


def _z_test(ref: List[float], cur: List[float]) -> Tuple[float, float]:
    """双样本 z 检验（比较均值）；返回 (p_value, effect_size)。"""
    n_ref, n_cur = max(len(ref), 1), max(len(cur), 1)
    ref_mean = sum(ref) / n_ref
    cur_mean = sum(cur) / n_cur
    ref_var = _var(ref, ref_mean)
    cur_var = _var(cur, cur_mean)
    denom = math.sqrt(ref_var / n_ref + cur_var / n_cur + 1e-12)
    z = abs(cur_mean - ref_mean) / denom
    p_value = math.erfc(z / math.sqrt(2.0))
    return p_value, abs(cur_mean - ref_mean)


def _var(values: List[float], mean: float) -> float:
    if len(values) <= 1:
        return 0.0
    return sum((v - mean) ** 2 for v in values) / (len(values) - 1)
