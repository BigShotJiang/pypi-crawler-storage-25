"""统一配置模块。

为置信度融合流水线的各层提供集中化的参数管理，
支持直接构造、扁平字典与 YAML 文件三种初始化方式。

作者：刘秉其
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict


@dataclass
class FusionConfig:
    """EMA 置信度融合参数。"""

    alpha: float = 0.6
    output_threshold: float = 0.2
    base_threshold: float = 0.05


@dataclass
class MergerConfig:
    """事件合并参数。"""

    max_gap_sec: float = 0.10


@dataclass
class RiskConfig:
    """风险评分参数。"""

    medium_threshold: float = 0.40
    high_threshold: float = 0.70
    review_uncertainty_threshold: float = 0.60
    event_type_weights: Dict[str, float] = field(default_factory=dict)


@dataclass
class DriftConfig:
    """漂移检测参数。"""

    enabled: bool = True
    window_size: int = 200
    min_samples: int = 30
    confidence_shift_threshold: float = 0.20
    type_shift_threshold: float = 0.35
    mode: str = "threshold"
    significance_level: float = 0.01
    min_effect_size: float = 0.10
    page_hinkley_delta: float = 0.005
    page_hinkley_lambda: float = 0.05
    page_hinkley_alpha: float = 0.999


@dataclass
class ConfidenceConfig:
    """顶层配置，聚合所有子配置。

    支持直接构造、从扁平字典构建或从 YAML 文件加载。
    """

    fusion: FusionConfig = field(default_factory=FusionConfig)
    merger: MergerConfig = field(default_factory=MergerConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    drift: DriftConfig = field(default_factory=DriftConfig)

    @property
    def alpha(self) -> float:
        return self.fusion.alpha

    @property
    def output_threshold(self) -> float:
        return self.fusion.output_threshold

    @property
    def base_threshold(self) -> float:
        return self.fusion.base_threshold

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ConfidenceConfig:
        """从字典构建配置。

        同时支持嵌套形式 ``{"fusion": {"alpha": 0.7}}``
        和扁平形式 ``{"alpha": 0.7, "output_threshold": 0.3}``。
        """
        if "fusion" in data and isinstance(data["fusion"], dict):
            return cls(
                fusion=FusionConfig(**{k: v for k, v in data.get("fusion", {}).items() if k in FusionConfig.__dataclass_fields__}),
                merger=MergerConfig(**{k: v for k, v in data.get("merger", {}).items() if k in MergerConfig.__dataclass_fields__}),
                risk=RiskConfig(**{k: v for k, v in data.get("risk", {}).items() if k in RiskConfig.__dataclass_fields__}),
                drift=DriftConfig(**{k: v for k, v in data.get("drift", {}).items() if k in DriftConfig.__dataclass_fields__}),
            )

        fusion_fields = {k for k in FusionConfig.__dataclass_fields__}
        merger_fields = {k for k in MergerConfig.__dataclass_fields__}
        risk_fields = {k for k in RiskConfig.__dataclass_fields__}
        drift_fields = {k for k in DriftConfig.__dataclass_fields__}

        return cls(
            fusion=FusionConfig(**{k: v for k, v in data.items() if k in fusion_fields}),
            merger=MergerConfig(**{k: v for k, v in data.items() if k in merger_fields}),
            risk=RiskConfig(**{k: v for k, v in data.items() if k in risk_fields}),
            drift=DriftConfig(**{k: v for k, v in data.items() if k in drift_fields}),
        )

    @classmethod
    def from_yaml(cls, path: str) -> ConfidenceConfig:
        """从 YAML 文件加载配置（需安装 ``pyyaml``）。"""
        import yaml

        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(yaml.safe_load(fh))
