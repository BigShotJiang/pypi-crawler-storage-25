"""五层置信度融合流水线。

编排以下五个处理层：

1. Softmax 归一化
2. 因果 EMA 融合
3. 重叠事件合并
4. 风险评分
5. 漂移检测

每层可独立使用；本模块将它们串联以便一键调用。

作者：刘秉其
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from .confidence_config import ConfidenceConfig
from .confidence_fusion import ConfidenceFusion, FusionResult, softmax
from .drift_monitor import DriftMonitor, DriftResult
from .event_merger import merge_events
from .risk_engine import RiskEngine, RiskResult


@dataclass
class PipelineResult:
    """完整流水线运行的聚合输出。"""

    fused: List[FusionResult] = field(default_factory=list)
    events_raw: List[Dict[str, Any]] = field(default_factory=list)
    events_merged: List[Dict[str, Any]] = field(default_factory=list)
    risk: Optional[RiskResult] = None
    drift: Optional[DriftResult] = None


class ConfidencePipeline:
    """端到端的置信度处理流水线。

    用法::

        pipeline = ConfidencePipeline()            # 默认参数 0.6 / 0.2 / 0.05
        pipeline = ConfidencePipeline(config)       # 自定义 ConfidenceConfig

        # 逐帧流式处理
        result = pipeline.process_logits(logits)    # FusionResult | None

        # 批量事件处理
        full = pipeline.process_events(events)      # PipelineResult

        # 从 logits 序列端到端运行
        full = pipeline.process_full(logits_seq)    # PipelineResult
    """

    def __init__(self, config: ConfidenceConfig | None = None) -> None:
        self._cfg = config or ConfidenceConfig()
        self._fusion = ConfidenceFusion(self._cfg.fusion)
        self._risk = RiskEngine(self._cfg.risk)
        self._drift = DriftMonitor(self._cfg.drift)

    @property
    def config(self) -> ConfidenceConfig:
        return self._cfg

    @property
    def fusion(self) -> ConfidenceFusion:
        return self._fusion

    # --- 流式 API -----------------------------------------------------------

    def process_logits(self, logits: np.ndarray) -> Optional[FusionResult]:
        """第 1–2 层：对单帧执行 softmax → EMA 融合。"""
        self._fusion.update_logits(logits)
        return self._fusion.query()

    def process_probabilities(self, probabilities: np.ndarray) -> Optional[FusionResult]:
        """第 2 层：对已归一化的概率向量执行 EMA 融合。"""
        self._fusion.update(probabilities)
        return self._fusion.query()

    # --- 批量 API -----------------------------------------------------------

    def process_events(
        self,
        events: List[Dict[str, Any]],
        *,
        stream_key: str = "global",
    ) -> PipelineResult:
        """第 3–5 层：对事件列表执行合并 → 风险评分 → 漂移检测。"""
        merged = merge_events(events, self._cfg.merger)
        risk = self._risk.assess(merged)
        drift = self._drift.evaluate(merged, stream_key=stream_key)
        return PipelineResult(
            events_raw=events,
            events_merged=merged,
            risk=risk,
            drift=drift,
        )

    # --- 端到端 API ---------------------------------------------------------

    def process_full(
        self,
        logits_sequence: Sequence[np.ndarray],
        *,
        frame_duration_sec: float = 0.5,
        stream_key: str = "global",
    ) -> PipelineResult:
        """对原始 logits 序列运行全部五层。

        利用 *frame_duration_sec* 作为时间步长，从融合结果合成事件字典，
        再送入 合并 → 风险评分 → 漂移检测 流程。
        """
        fused_results: List[FusionResult] = []
        events: List[Dict[str, Any]] = []

        for i, logits in enumerate(logits_sequence):
            result = self.process_logits(np.asarray(logits))
            if result is not None:
                fused_results.append(result)
                events.append({
                    "event_type": result.event_type,
                    "confidence": result.confidence,
                    "start_sec": round(i * frame_duration_sec, 4),
                    "end_sec": round((i + 1) * frame_duration_sec, 4),
                    "fused": result.fused,
                })

        batch_result = self.process_events(events, stream_key=stream_key)
        batch_result.fused = fused_results
        return batch_result

    def reset(self) -> None:
        """重置所有有状态组件。"""
        self._fusion.reset()
        self._drift.reset()
