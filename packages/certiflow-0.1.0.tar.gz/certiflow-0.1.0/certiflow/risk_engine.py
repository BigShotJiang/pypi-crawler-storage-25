"""第 4 层：置信度统计量 → 风险评分。

从一组事件中提取四个统计特征（置信度的均值/最大值/P90/离散度），
经加权组合产生 [0, 1] 区间的复合风险分数与不确定性估计。

作者：刘秉其
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, List

import numpy as np

from .confidence_config import RiskConfig

RISK_LEVELS = ("low", "medium", "high")


@dataclass
class RiskResult:
    """风险评估的不可变输出。"""

    score: float
    level: str
    uncertainty: float
    requires_review: bool
    features: Dict[str, float]
    probabilities: Dict[str, float]


class RiskEngine:
    """基于置信度统计量的加权启发式风险评分器。

    评分公式（启发式模式）：

        score = 0.35 × conf_mean + 0.20 × conf_max
              + 0.20 × type_weight + 0.15 × rate + 0.07 × repeat + 0.03 × dur

    ``event_type_weights`` 字典将事件类型标签映射到 [0, 1] 的重要性权重。
    未知类型默认为 0.5。
    """

    def __init__(self, config: RiskConfig | None = None) -> None:
        self._cfg = config or RiskConfig()

    def assess(self, events: List[Dict[str, Any]]) -> RiskResult:
        """对一批事件进行评分，返回 :class:`RiskResult`。"""
        if not events:
            return RiskResult(
                score=0.0, level="low", uncertainty=0.0,
                requires_review=False, features={}, probabilities=_uniform(),
            )

        features = self._build_features(events)
        score = self._score(features)
        probabilities = self._heuristic_probabilities(score)
        uncertainty = self._estimate_uncertainty(events, features, probabilities)
        level = self._map_level(score)
        requires_review = uncertainty >= self._cfg.review_uncertainty_threshold

        return RiskResult(
            score=round(score, 4),
            level=level,
            uncertainty=round(uncertainty, 4),
            requires_review=requires_review,
            features=features,
            probabilities=probabilities,
        )

    # --- 内部方法 -----------------------------------------------------------

    def _build_features(self, events: List[Dict[str, Any]]) -> Dict[str, float]:
        confs = np.array([_safe_float(e.get("confidence")) for e in events])
        confs = np.clip(confs, 0.0, 1.0)

        type_weights = np.array([self._event_weight(e) for e in events])
        type_counter = Counter(str(e.get("event_type", "unknown")) for e in events)
        repeat_ratio = max(type_counter.values()) / max(len(events), 1)

        durations = np.array([
            max(float(e.get("end_sec", 0) or 0) - float(e.get("start_sec", 0) or 0), 0.0)
            for e in events
        ])

        starts = np.array([float(e.get("start_sec", 0) or 0) for e in events])
        window_sec = max(float(np.ptp(starts)), 1.0) if len(starts) >= 2 else 60.0
        rate_per_min = len(events) / (window_sec / 60.0)

        return {
            "event_count": float(len(events)),
            "confidence_mean": round(float(np.mean(confs)), 4),
            "confidence_max": round(float(np.max(confs)), 4),
            "confidence_p90": round(float(np.percentile(confs, 90)), 4),
            "confidence_spread": round(float(np.mean(np.abs(confs - np.mean(confs)))), 4),
            "event_rate_per_min": round(rate_per_min, 4),
            "repeat_ratio": round(repeat_ratio, 4),
            "duration_mean_sec": round(float(np.mean(durations)), 4) if len(durations) else 0.0,
            "type_weight_mean": round(float(np.mean(type_weights)), 4),
        }

    def _score(self, f: Dict[str, float]) -> float:
        rate_component = min(f["event_rate_per_min"] / 10.0, 1.0)
        repeat_component = min(f["repeat_ratio"], 1.0)
        duration_component = min(f["duration_mean_sec"] / 30.0, 1.0)

        raw = (
            0.35 * f["confidence_mean"]
            + 0.20 * f["confidence_max"]
            + 0.20 * f["type_weight_mean"]
            + 0.15 * rate_component
            + 0.07 * repeat_component
            + 0.03 * duration_component
        )
        return float(np.clip(raw, 0.0, 1.0))

    def _estimate_uncertainty(
        self,
        events: List[Dict[str, Any]],
        features: Dict[str, float],
        probabilities: Dict[str, float],
    ) -> float:
        n = len(events)
        sorted_probs = sorted(probabilities.values(), reverse=True)
        max_prob = sorted_probs[0] if sorted_probs else 0.0
        second_prob = sorted_probs[1] if len(sorted_probs) > 1 else 0.0

        small_sample_penalty = 1.0 if n <= 2 else (0.6 if n <= 4 else 0.2)
        spread_penalty = min(features.get("confidence_spread", 0.0) * 2.0, 1.0)
        probability_penalty = 1.0 - max_prob
        margin_penalty = 1.0 - max(0.0, max_prob - second_prob)

        uncertainty = (
            0.35 * small_sample_penalty
            + 0.25 * spread_penalty
            + 0.20 * probability_penalty
            + 0.20 * margin_penalty
        )
        return float(np.clip(uncertainty, 0.0, 1.0))

    def _map_level(self, score: float) -> str:
        if score >= self._cfg.high_threshold:
            return "high"
        if score >= self._cfg.medium_threshold:
            return "medium"
        return "low"

    def _event_weight(self, event: Dict[str, Any]) -> float:
        label = str(event.get("event_type", "")).lower()
        return self._cfg.event_type_weights.get(label, 0.5)

    @staticmethod
    def _heuristic_probabilities(score: float) -> Dict[str, float]:
        """将标量评分映射为风险等级上的软概率分布。"""
        raw = {
            "low": max(0.0, 1.0 - score * 2.0),
            "medium": max(0.0, 1.0 - abs(score - 0.5) * 3.0),
            "high": max(0.0, score * 2.0 - 1.0),
        }
        total = sum(raw.values()) or 1.0
        return {k: round(v / total, 4) for k, v in raw.items()}


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _uniform() -> Dict[str, float]:
    v = round(1.0 / len(RISK_LEVELS), 4)
    return {level: v for level in RISK_LEVELS}
