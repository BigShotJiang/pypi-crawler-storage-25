from setuptools import setup, find_packages

setup(
    name="MIMS_TP_Py_cli",          # 改你的包名（必须唯一）
    version="1.0.0",                 # 版本号
    author="hafoxiaowanzi",
    author_email="47597036@qq.com",
    description="带C动态库的Python框架脚手架",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/hafoxiaowanzi/my_framework_cli.git",
    packages=find_packages(),
    include_package_data=True,       # 必须开启，打包模板/C库
    install_requires=[
        "click>=8.0",
        "jinja2>=3.0"
    ],
    entry_points={
        "console_scripts": [
            "mimspytp = mycli.cli:cli",   # 全局命令
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)