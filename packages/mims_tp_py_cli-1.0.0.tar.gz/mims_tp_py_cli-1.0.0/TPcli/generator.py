import os
import shutil
from jinja2 import Environment, FileSystemLoader

BASE_PATH = os.path.dirname(__file__)
TEMPLATE_PATH = os.path.join(BASE_PATH, "templates")

def create_project(proj_name: str):
    # 生成目标文件夹
    if os.path.exists(proj_name):
        print(f"[Error] The folder {proj_name} already exists")
        return
    os.makedirs(proj_name)

    env = Environment(loader=FileSystemLoader(TEMPLATE_PATH))
    template_root = os.path.join(TEMPLATE_PATH, "project")

    # 遍历模板所有文件
    for root, dirs, files in os.walk(template_root):
        rel_path = os.path.relpath(root, template_root)
        dst_dir = os.path.join(proj_name, rel_path)
        # 替换模板变量文件夹名
        dst_dir = dst_dir.replace("{{proj_name}}", proj_name)
        os.makedirs(dst_dir, exist_ok=True)

        for filename in files:
            src_file = os.path.join(root, filename)
            dst_file = os.path.join(dst_dir, filename)
            dst_file = dst_file.replace("{{proj_name}}", proj_name)

            # 二进制动态库：直接复制，不渲染
            if filename.endswith((".dll", ".so", ".dylib")):
                shutil.copy(src_file, dst_file)
                continue

            # 文本文件：jinja渲染
            try:
                tpl = env.get_template(os.path.relpath(src_file, TEMPLATE_PATH))
                text = tpl.render(proj_name=proj_name)
                with open(dst_file, "w", encoding="utf-8") as f:
                    f.write(text)
            except Exception as e:
                shutil.copy(src_file, dst_file)

    print(f"\n✅ Project creation complete -> {os.path.abspath(proj_name)}")
    print(f"💡 Run the command：cd {proj_name} && python {proj_name}/main.py")
