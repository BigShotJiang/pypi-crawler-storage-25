import click
from mycli.generator import create_project

@click.group()
def cli():
    """Python自定义框架脚手架（内置C动态库）"""
    pass

@cli.command()
@click.argument("name")
def new(name):
    """一键创建带C动态库的工程"""
    create_project(name)

if __name__ == "__main__":
    cli()