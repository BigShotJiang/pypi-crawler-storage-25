
# -*- coding: utf-8 -*-
import time
import importlib
import sys
import os
import logging
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
parent_dir = os.path.dirname(script_dir)
sys.path.append(parent_dir)
from common.TPInfoManger import TPInfoManager
from common.TPUseXMLDataType import ALL_MSG_DATA
from common.UICommand import UICommand
from common.DataSrc import *
from task.test_osc import *

class TaskPro:

    def __init__(self,pNetCommand):
        self.m_strError=''
        self.m_strProcess=''
        self.uicmd = pNetCommand
        self.m_TaskManger = OSC_FinalTest_Process(pNetCommand)
        self.m_pstSockInfo = ALL_MSG_DATA()
        self.m_strUser = ''
      
    def CalFunctionByCfg(self,filename,funname):
        try:
            print(filename)
            # suite = unittest.TestSuite()
            members = importlib.import_module(filename)
            members = importlib.reload(members)  # 实时更新
            function = getattr(members, funname)
            res  = function()
            return res
            # list_of_functions = inspect.getmembers(members)#获取类的集合字典
            # loaders = unittest.TestLoader()
            # for name, obj in list_of_functions:
            #     suite.addTest(loaders.getTestCaseNames(testCaseClass=obj))
            # unner = unittest.TextTestRunner()
            # for test in suite:
            #     for test_case in test:
            #         if funname==test_case.id().split('.')[-1]:
            #             suite2 = unittest.TestSuite()
            #             suite2.addTest(test_case)
            #             result = runner.run(suite2)#测试运行过程
            #         if result.wasSuccessful()==True:
            #             return True
            #         else:
            #             return False 
        except Exception as e:
           _msg = str(e)
        #    logging.info(_msg)
           self.m_uicommand.XmlSendLog(_msg, len(_msg) + 1, LOGLEVEL.LOG_ERROR)
           return False 

    def RunTestTaskItem(self):
        #BOOL RunTestTaskItem();
        bRunFalg=True
        tResult=TASKRESULT.TASK_DONE
        strMsg=""
        strErrorMsg=""
        raw=self.m_pstSockInfo.unDataStruct.ComRunTaskData.szUser
        strRunTaskUser = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        strRunTaskUser= strRunTaskUser.strip()

        raw=self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex
        nRawTaskIndex = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
       
        nRawTaskIndex = int(nRawTaskIndex)
        if (nRawTaskIndex < TASKOFFSET.TASK_OFF_1000):
            if nRawTaskIndex<0:
                strTemp='Receive task error. Task Index:%s, Task Title:%s'%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                            self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
                self.uicmd.XmlSendLog(strTemp,len(strTemp)+1,LOGLEVEL.LOG_ERROR)
                bRunFalg = False
            else:
                strTemp="Handling the task. Task Index:%s, Task Title:%s"%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                            self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
                self.uicmd.XmlSendLog(strTemp, len(strTemp) + 1,LOGLEVEL.LOG_WARNING)
                strMsg='Task finished. Task Index:%s, Task Title:%s'%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                            self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
                strErrorMsg='Task failed. Task Index:%s, Task Title:%s'%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                            self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
                bRunFalg = self.m_TaskManger.RunTestTask(nRawTaskIndex,strRunTaskUser)
        else:
            raw=self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex
            iTaskIndex=raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
            iTaskIndex = int(iTaskIndex) % TASKOFFSET.TASK_OFF_1000
            strTemp = "Handling the task. Task Index:%s, Task Title:%s"%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                          self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
            self.uicmd.XmlSendLog(strTemp, len(strTemp) + 1)
            strMsg = 'Task finished. Task Index:%s, Task Title:%s'%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                       self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
            strErrorMsg = 'Task failed. Task Index:%s, Task Title:%s'%(self.m_pstSockInfo.unDataStruct.ComRunTaskData.szIndex,
                                                            self.m_pstSockInfo.unDataStruct.ComRunTaskData.szTitle)
            bRunFalg = self.m_TaskManger.RunTestTask(iTaskIndex,strRunTaskUser)
            # bRunFalg = True
        time.sleep(0.1)
        if (bRunFalg==True):
            result=self.uicmd.XmlTaskDone(nRawTaskIndex, strRunTaskUser, tResult)
            if result==False:
                strTemp = self.uicmd.GetLastError()
                self.uicmd.XmlSendLog(strTemp,  len(strErrorMsg) + 1, LOGLEVEL.LOG_ERROR)
            self.uicmd.XmlSendLog(strMsg, len(strMsg) + LOGLEVEL.LOG_NORMAL)
        else:
            self.uicmd.XmlSendLog(strErrorMsg, len(strErrorMsg)+ 1, LOGLEVEL.LOG_ERROR)
            tResult = TASKRESULT.TASK_FAIL
            self.uicmd.XmlTaskDone(nRawTaskIndex, strRunTaskUser, tResult)

    def RunTestInit(self,strUser):
        #BOOL RunTestInit();
        self.m_strUser = strUser
        script_path = os.path.abspath(__file__)
        script_dir = os.path.dirname(script_path)
        parent_dir = os.path.dirname(script_dir)
        sys.path.append(parent_dir)
        filename = os.path.join(parent_dir,'task', "test_init.py")
        funcname = "RunTestInit"
        bRunInit = False
        
        bRunInit = self.CalFunctionByCfg("task.test_init",funcname)
        # self.tpclass.InitTestUpdateDutSN()
        # bRunInit = self.m_TaskManger.RunTestInit()
        
        # strRunTaskUser=self.tpclass.GetUISendUser()
        tResult = TASKRESULT
        if (bRunInit==True):
            tResult = tResult.TASK_DONE
            strTemp = "Initial Successfully"
        else:
            tResult = tResult.TASK_FAIL
            strTemp = "Inital Failed"      
        
        res = self.uicmd.XmlTaskDone(KEY_ITEM.TEST_INIT,self.m_strUser,tResult)
        if res == False:
             strMsg = self.uicmd.GeXmlMsgError();
             self.uicmd.XmlSendLog(strMsg, len(strMsg) + 1, LOGLEVEL.LOG_ERROR)
       
        self.uicmd.XmlSendLog(strTemp, len(strTemp) + 1, LOGLEVEL.LOG_NORMAL)

        
    
        return bRunInit

    def SetTPInfoManager(self):
        #void SetTPInfoManager(CTPInfoManager* pInfoManger);
        pass

    def SetSockDataInfo(self):
        #void SetSockDataInfo(ALL_MSG_DATA * pstSockInfo);
        pass

    def SetNetCommand(self):
        # void SetNetCommand(CNetCommand * pNetCommand);
        pass

    def SetTaskMenuObj(self):
        #void SetTaskMenuObj(CTaskMenuPro * pTaskMenu);
        pass

    def QuitTestTask(self):
        #BOOL QuitTestTask();
        pass
if __name__ =="__main__":
    
    a = UICommand() 
        
    _tp = TaskPro(a)
    _tp.RunTestInit("24351")      
