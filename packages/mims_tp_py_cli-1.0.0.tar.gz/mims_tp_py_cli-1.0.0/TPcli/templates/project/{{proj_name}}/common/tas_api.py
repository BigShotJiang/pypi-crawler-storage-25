import clr,struct
class ITAS:
    def __init__(self,dll_position="C:\\Public-T\\Software\\TAS"):
        size = struct.calcsize("P") * 8
        if size == 32:
            clr.FindAssembly("{}\\USL.TAS.dll".format(dll_position))
            clr.AddReference("{}\\USL.TAS".format(dll_position))
            from USLTASLibrary import USLTASLibraryInterface
            self.tasdll = USLTASLibraryInterface()
        else:
            clr.FindAssembly("{}\\x64\\USL.TAS.dll".format(dll_position))
            clr.AddReference("{}\\x64\\USL.TAS".format(dll_position))
            from USLTASLibrary import USLTASLibraryInterface
            self.tasdll = USLTASLibraryInterface()

    def GetProdTestTemplate(self,SN, ProcessCode, User, Freecheck='', bShowData=True, strTemplateName='', strOutErrMsg=''):
        #获取产品在某工序的生产数据，返回值是xml解析的数据字符串
        #string GetProdTestTemplate(string SN, string ProcessCode, string User, string Freecheck,
        # bool bShowData, ref string strTemplateName, ref string strOutErrMsg);
        result=self.tasdll.GetProdTestTemplate(SN,ProcessCode,User,Freecheck,bShowData,
                                          strTemplateName,strOutErrMsg)
        return result

    def GetProductInfo(self,SerialNo,strOutErrMsg=''):
        #获取产品的生产信息
        #string GetProductInfo(string SerialNo, ref string strOutErrMsg);
        result= self.tasdll.GetProductInfo(SerialNo,strOutErrMsg)
        return result

    def GetProductKeyInfo(self, SerialNo,  strPN='', strSpec='', strWO='', strCurProcess='',
                          strCurStuts='', strOutErrMsg=''):
        # 获取产品的关键信息
        #bool GetProductKeyInfo(string SerialNo, ref string strPN, ref string strSpec,
        # ref string strWO, ref string strCurProcess, ref string strCurStuts, ref string strOutErrMsg)
        result= self.tasdll.GetProductKeyInfo(SerialNo, strPN,strSpec,strWO,strCurProcess,
                                                strCurStuts,strOutErrMsg)
        return result


    def GetFullProductKeyInfo(self, strContainer, SerialNo='',strMTSPN='',strMTOPN='',strOPLKPN='',
                              strCurProcess='',strSpec='',strWO='',strCurStuts=1,strOutErrMsg=''):
        # bool GetFullProductKeyInfo(string strContainer, ref string SerialNo,
        # ref string strMTSPN, ref string strMTOPN, ref string strOPLKPN,
        # ref string strCurProcess, ref string strSpec, ref string strWO,
        # ref int strCurStuts, ref string strOutErrMsg);
        result= self.tasdll.GetFullProductKeyInfo(strContainer, SerialNo,strMTSPN,strMTOPN,strOPLKPN,
                                                  strCurProcess,strSpec,strWO,strCurStuts,strOutErrMsg)
        return result


    def BindingLabelAndSerialNumber(self, strLabel, strSN,  strOutErrMsg=''):
        #bool BindingLabelAndSerialNumber(string strLabel, string strSN, ref string strOutErrMsg);
        result= self.tasdll.BindingLabelAndSerialNumber(strLabel,strSN,strOutErrMsg)
        return result

    def CreateSNDataRootDir(self, strProdFamilyDir, strSN,strSNDataRootDir='',strOutErrMsg=''):
        # bool CreateSNDataRootDir(string strProdFamilyDir, string strSN, ref string strSNDataRootDir,
        # ref string strOutErrMsg);
        result= self.tasdll.CreateSNDataRootDir(strProdFamilyDir, strSN,strSNDataRootDir,strOutErrMsg)
        return result

    def GetAutoKittingTestItem(self, strSN, strTestItem,content='',strOutErrMsg=''):
        # bool GetAutoKittingTestItem(string strSN, string strTestItem, ref string content,
        # ref string strOutErrMsg);
        result= self.tasdll.GetAutoKittingTestItem(strSN, strTestItem,content,strOutErrMsg)
        return result

    def GetAutoKittingOutsourcedTestItem(self, strSN, strTestItem,content='',strOutErrMsg=''):
        #bool GetAutoKittingOutsourcedTestItem(string strSN, string strTestItem, ref string content,
        # ref string strOutErrMsg);
        result= self.tasdll.GetAutoKittingOutsourcedTestItem(strSN, strTestItem,content,strOutErrMsg)
        return result

    def GetContainerTransferInfoList(self, strContainer, oldPN='',oldWO='',oldSpec='',oldProductFamily='',
                                     newPN='',newWO='',newSpec='',newProductFamily='',strOutErrMsg=''):
        # bool GetContainerTransferInfoList(string strContainer, ref string oldPN,ref string oldWO,
        # ref string oldSpec,ref string oldProductFamily,ref string newPN,
        # ref string newWO,ref string newSpec,ref string newProductFamily, ref string strOutErrMsg);
        result= self.tasdll.GetContainerTransferInfoList(strContainer, oldPN,oldWO,oldSpec,oldProductFamily,
                                                         newPN,newWO,newSpec,newProductFamily,strOutErrMsg)
        return result


    def GetFWConfigInfo(self, PN, strOutErrMsg=''):
        # string GetFWConfigInfo(string PN, ref string strOutErrMsg);
        result= self.tasdll.GetFWConfigInfo(PN, strOutErrMsg)
        return result

    def GetFWStandardPath(self, strPN, strFWBOMPN='',strFWStandardPath='',strOutErrMsg=''):
        #
        # bool GetFWStandardPath(string strPN, ref string strFWBOMPN, ref string strFWStandardPath,
        # ref string strOutErrMsg);
        result= self.tasdll.GetFWStandardPath(strPN, strFWBOMPN,strFWStandardPath,strOutErrMsg)
        return result

    def GetMESProcessCode(self, PN, TestProcessCode,strOutErrMsg=''):
        # string GetMESProcessCode(string PN, string TestProcessCode, ref string strOutErrMsg);
        result= self.tasdll.GetMESProcessCode(PN, TestProcessCode,strOutErrMsg)
        return result

    def GetMIMSLoginInfo(self, User, Pwd,Loginmode,strOutErrMsg=''):
        # string GetMIMSLoginInfo(string User, string Pwd, string Loginmode, ref string strOutErrMsg);
        result= self.tasdll.GetMIMSLoginInfo(User, Pwd,Loginmode,strOutErrMsg)
        return result

    def GetOMSTestTemplate(self, strSN, OMSProcess,strTemplateName='',strOutErrMsg=''):
        # string GetOMSTestTemplate(string strSN, string OMSProcess, ref string strTemplateName,
        # ref string strOutErrMsg);
        result= self.tasdll.GetOMSTestTemplate(strSN, OMSProcess,strTemplateName,strOutErrMsg)
        return result

    def GetOplinkUserInfo(self, strOplkID, strUserName='',strDptName='',strPosName='',strOPCID='',strOutErrMsg=''):
        # bool GetOplinkUserInfo(string strOplkID, ref string strUserName, ref string strDptName,
        # ref string strPosName, ref string strOPCID, ref string strOutErrMsg);
        result= self.tasdll.GetOplinkUserInfo(strOplkID, strUserName,strDptName,
                                              strPosName,strOPCID,strOutErrMsg)
        return result

    def GetProductSerialNumberAndBindRfid(self, strBatchRfid, strDeviceRfid,SN='',strOutErrMsg=''):
        # bool GetProductSerialNumberAndBindRfid(string strBatchRfid, string strDeviceRfid,
        # ref string SN, ref string strOutErrMsg);
        result= self.tasdll.GetProductSerialNumberAndBindRfid(strBatchRfid, strDeviceRfid,SN,strOutErrMsg)
        return result

    def GetProductSerialNumberByRFIDCode(self, strRFIDCode, SN='',strOutErrMsg=''):
        # bool GetProductSerialNumberByRFIDCode(string strRFIDCode, ref string SN,
        # ref string strOutErrMsg);
        result= self.tasdll.GetProductSerialNumberByRFIDCode(strRFIDCode, SN,strOutErrMsg)
        return result

    def GetProductSerialNumberByOpCenterResource(self, strOpCenterResource, SN='',strOutErrMsg=''):
        # bool GetProductSerialNumberByOpCenterResource(string strOpCenterResource, ref string SN,
        # ref string strOutErrMsg);
        result= self.tasdll.GetProductSerialNumberByOpCenterResource(strOpCenterResource, SN,strOutErrMsg)
        return result

    def GetSoftwareID(self, strPN, strMESProcess,strSpec,strWO,strOutErrMsg=''):
        # string GetSoftwareID(string strPN, string strMESProcess, string strSpec,
        # string strWO, ref string strOutErrMsg);
        result= self.tasdll.GetSoftwareID(strPN, strMESProcess,strSpec,strWO,strOutErrMsg)
        return result

    def GetStationName(self, strComputerName, strStationID='',strStationName='',strOutErrMsg=''):
        # bool GetStationName(string strComputerName, ref string strStationID,
        # ref string strStationName, ref string strOutErrMsg);
        result= self.tasdll.GetStationName(strComputerName, strStationID,strStationName,strOutErrMsg)
        return result

    def GetSystemCurrentMode(self, strOutErrMsg=''):
        # string GetSystemCurrentMode(ref string strOutErrMsg);
        result= self.tasdll.GetSystemCurrentMode(strOutErrMsg)
        return result

    def GetTestProcessCode(self, PN, MESProcessCode,strOutErrMsg=''):
        # string GetTestProcessCode(string PN, string MESProcessCode, ref string strOutErrMsg)
        result= self.tasdll.GetTestProcessCode(PN, MESProcessCode,strOutErrMsg)
        return result

    def GetTestResult(self, SerialNo, strPorcess,strPN,strSpec,strOutErrMsg=''):
        # string GetTestResult(string strSeriaNo, string strPorcess, string strPN, string strSpec,
        # ref string strError);
        result= self.tasdll.GetTestResult(SerialNo, strPorcess,strPN,strSpec,strOutErrMsg)
        return result

    def GetTPConfigInfo(self, PN, ProcessCode,LoginMode,strOutErrMsg=''):
        # string GetTPConfigInfo(string PN, string ProcessCode, string LoginMode,
        # ref string strOutErrMsg);
        result= self.tasdll.GetTPConfigInfo(PN, ProcessCode,LoginMode,strOutErrMsg)
        return result

    def GetWOHeaderList(self, strContainer, strDataCollectionDef,strPostion,strOutErrMsg=''):
        # string GetWOHeaderList(string strContainer, string strDataCollectionDef,
        # string strPostion, ref string strOutErrMsg);
        result= self.tasdll.GetWOHeaderList(strContainer,strDataCollectionDef,strPostion, strOutErrMsg)
        return result

    def GetWorkStationDeptInfo(self, strStationPCName, strStationID='',strStationName='',
                               strDepartment='',strOutErrMsg=''):
        # bool GetWorkStationDeptInfo(string strStationPCName,ref string strStationID,
        # ref string strStationName,ref string strDepartment,ref string strOutErrMsg);
        result= self.tasdll.GetWorkStationDeptInfo(strStationPCName, strStationID,strStationName,
                                                   strDepartment,strOutErrMsg)
        return result

    def LoadTestData(self, SN,MESProcess, PN,TestRecord='',MFGRecord='',strOutErrMsg=''):
        # bool LoadTestData(string SN, string MESProcess,string PN,ref string TestRecord,
        # ref string MFGRecord, ref string strOutErrMsg);
        result= self.tasdll.LoadTestData(SN, MESProcess,PN,TestRecord,MFGRecord,strOutErrMsg)
        return result

    def SetEmployeeAccount(self, strOplkID, strOutErrMsg=''):
        # bool SetEmployeeAccount(string strOplkID, ref string strOutErrMsg);
        result= self.tasdll.SetEmployeeAccount(strOplkID, strOutErrMsg)
        return result

    def SetRetestFlag(self, bReTest, strTestUser,strTestStationID,strOutErrMsg=''):
        # bool SetRetestFlag(bool bReTest, string strTestUser, string strTestStationID,
        # ref string strOutErrMsg);
        result= self.tasdll.SetRetestFlag(bReTest, strTestUser,strTestStationID,strOutErrMsg)
        return result

    def SetSystemToSpecialMode(self, strUserName, strPwd,strMode,strOutErrMsg=''):
        # bool SetSystemToSpecialMode(string strUserName, string strPwd, string strMode,
        # ref string strOutErrMsg)
        result= self.tasdll.SetSystemToSpecialMode(strUserName, strPwd,strMode,strOutErrMsg)
        return result

    def TriggerConversationPN(self, strPN,nPNType, strOutErrMsg=''):
        # string TriggerConversationPN(string strPN, int nPNType, ref string strOutErrMsg);
        result= self.tasdll.TriggerConversationPN(strPN, nPNType,strOutErrMsg)
        return result

    def TriggerMoveToCheckCenter(self, strContainerList, strResource,strEmployeeID,
                                 strComments,strOutErrMsg=''):
        # bool TriggerMoveToCheckCenter(string[] strContainerList, string strResource,
        # string strEmployeeID, string strComments, ref string strOutErrMsg);
        result= self.tasdll.TriggerMoveToCheckCenter(strContainerList, strResource,strEmployeeID,
                                                     strComments,strOutErrMsg)
        return result

    def TriggerProcessMoveIn(self, strSN, strMesProcessCode,StationID,strOutErrMsg=''):
        # bool TriggerProcessMoveIn(string strSN, string strMesProcessCode, string StationID,
        # ref string strOutErrMsg);
        result= self.tasdll.TriggerProcessMoveIn(strSN, strMesProcessCode,StationID,strOutErrMsg)
        return result

    def TriggerProcessMoveOut(self, strSN, StationID,strOutErrMsg=''):
        # bool TriggerProcessMoveOut(string strSN, string StationID, ref string strOutErrMsg);
        result= self.tasdll.TriggerProcessMoveOut(strSN, StationID,strOutErrMsg)
        return result

    def TriggerTestResultUpload(self, strSN, strOutErrMsg=''):
        # int TriggerTestResultUpload(string strSN, ref string strOutErrMsg);
        result= self.tasdll.TriggerTestResultUpload(strSN, strOutErrMsg)
        return result

    def TriggerUserSkillVerify(self, strEmployee, strSpec,strOperation,strOutErrMsg=''):
        # bool TriggerUserSkillVerify(string strEmployee, string strSpec, string strOperation,
        # ref string strOutErrMsg);
        result= self.tasdll.TriggerUserSkillVerify(strEmployee, strSpec,strOperation,strOutErrMsg)
        return result

    def TriggerWorkStationVerify(self, strWorkStation, strUserID,strType,strOutErrMsg=''):
        # bool TriggerWorkStationVerify(string strWorkStation, string strUserID, string strType,
        # ref string strOutErrMsg);
        result= self.tasdll.TriggerWorkStationVerify(strWorkStation, strUserID,strType,strOutErrMsg)
        return result

    def UploadTestData(self, strTestDataFileName):
        # string UploadTestData(string strTestDataFileName);
        result= self.tasdll.UploadTestData(strTestDataFileName)
        return result

    def VerifyOplinkIDAccount(self, strOplinkID,strPassWord, strOutErrMsg=''):
        # bool VerifyOplinkIDAccount(string strOplinkID, string strPassWord, ref string strOutErrMsg);
        result= self.tasdll.VerifyOplinkIDAccount(strOplinkID, strPassWord,strOutErrMsg)
        return result

    def CheckUserPassword(self, strUserID, strPassword,strUserName='',
                          strDeprtment='',strLevel='',strOutErrMsg=''):
        #校验CMES账户密码
        # LA：bool CheckUserPassword(string strUserID, string strPassword, out string strUserName,
        # out string strDeprtment, out string strLevel, out string strOutErrMsg);
        result= self.tasdll.CheckUserPassword(strUserID, strPassword,strUserName,strDeprtment,
                                              strLevel,strOutErrMsg)
        return result

    def GetSystemProcess(self, strProcess, bGetZHProcess,strSystemProcess='',strOutErrMsg=''):
        #获取系统工序
        # LA：bool GetSystemProcess(string strProcess, bool bGetZHProcess, ref string strSystemProcess,
        # ref string strOutErrMsg);
        result= self.tasdll.GetSystemProcess(strProcess, bGetZHProcess,strSystemProcess,strOutErrMsg)
        return result

    def GetSystemPath(self, strSN, Tag,strPath='',strOutErrMsg=''):
        #获取服务器根路径，Tag=0 返回测试软件的提示信息文件所在路径的根路径，Tag=1 返回制程/模板的根目录
        # bool GetSystemPath(string strSN, int Tag, ref string strPath, ref string strOutErrMsg);
        result= self.tasdll.GetSystemPath(strSN, Tag,strPath,strOutErrMsg)
        return result

    def JudgeTestPower(self, strUserID, strUserPwd,strOutErrMsg=''):
        #coupule冷热盘点检权限管控
        # bool JudgeTestPower(string strUserID, string strUserPwd,ref string strOutErrMsg);
        result= self.tasdll.JudgeTestPower(strUserID, strUserPwd,strOutErrMsg)
        return result

    def LoadTestDataByPN(self,SN, MESProcess,PN,TestRecord='',strOutErrMsg=''):
        #By PN获取测试数据
        # bool LoadTestDataByPN(string SN,string MESProcess, string PN, ref string TestRecord, 
        # ref string strOutErrMsg);
        result= self.tasdll.LoadTestDataByPN(SN, MESProcess,PN,TestRecord,strOutErrMsg)
        return result

    def UploadTestSystemCailbrationTime(self, strUserID, strOutErrMsg=''):
        #上传系统定标时间
        # bool UploadTestSystemCailbrationTime(string strUserID,ref string strOutErrMsg);
        result= self.tasdll.UploadTestSystemCailbrationTime(strUserID, strOutErrMsg)
        return result

    def GetSupplierSnModulePn(self, PN='', strOutErrMsg=''):
        #获取需要绕纤和打印的PN
        # bool GetSupplierSnModulePn(ref string PN,ref string strOutErrMsg);
        result= self.tasdll.GetSupplierSnModulePn(PN, strOutErrMsg)
        return result

    def GetSupplierSnErfiberPn(self, strModulePN, strErFiberLoop,strPNLoop='',strOutErrMsg=''):
        #通过产品PN和位置号获取铒纤PN和绕圈长度
        # bool GetSupplierSnErfiberPn(string strModulePN, string strErFiberLoop,ref string strPNLoop,
        # ref string strOutErrMsg);
        result= self.tasdll.GetSupplierSnErfiberPn(strModulePN, strErFiberLoop,strPNLoop,strOutErrMsg)
        return result

    def GetErfiberInfoForRD(self, strModulePN,strErFiberLoop,strLoopInfo='', strOutErrMsg=''):
        #通过产品PN和位置号获取铒纤的相关信息
        # bool GetErfiberInfoForRD(string strModulePN, string strErFiberLoop,ref string strLoopInfo,
        # ref string strOutErrMsg);
        result= self.tasdll.GetErfiberInfoForRD(strModulePN, strErFiberLoop,strLoopInfo,strOutErrMsg)
        return result

    def UpdateSupplierSn(self, strModuleSN,strSign, strOutErrMsg=''):
        #标记打印过的标签SN
        # bool UpdateSupplierSn(string strModuleSN, string strSign, ref string strOutErrMsg);
        result= self.tasdll.UpdateSupplierSn(strModuleSN,strSign, strOutErrMsg)
        return result

    def InsertOutSideKittingInfo(self, strWO, strProductSN,strDeviceSN,strDevicePN,
                                 strDeviceNO,strParamJsonList,strOutErrMsg=''):
        #上传配料系统配料信息
        # bool InsertOutSideKittingInfo(string strWO, string strProductSN, string strDeviceSN, 
        # string strDevicePN, string strDeviceNO, string strParamJsonList, ref string strOutErrMsg);
        result= self.tasdll.InsertOutSideKittingInfo(strWO, strProductSN,strDeviceSN,strDevicePN,
                                 strDeviceNO,strParamJsonList,strOutErrMsg)
        return result

    def GetOutSideDeviceValueInfo(self, strDeviceSN, strParam,strValue,strOutErrMsg=''):
        #获取上传配料系统的器件参数
        # bool GetOutSideDeviceValueInfo(string strDeviceSN,string strParam,string strValue, 
        # ref string strOutErrMsg);
        result= self.tasdll.GetOutSideDeviceValueInfo(strDeviceSN, strParam,strValue,strOutErrMsg)
        return result

    def GetAutoKittingErFiberLoopInfo(self, strEDFSN, strParam,strValue='',strOutErrMsg=''):
        #通过铒纤SN获取铒纤信息
        # bool GetAutoKittingErFiberLoopInfo(string strEDFSN, string strParam, ref string strValue, 
        # ref string strOutErrMsg);
        result= self.tasdll.GetAutoKittingErFiberLoopInfo(strEDFSN, strParam,strValue,strOutErrMsg)
        return result

    def GetWOBomInfo(self, strWO,strParam,strValue='', strOutErrMsg=''):
        #通过WO获取Bom信息
        # bool GetWOBomInfo(string strWO, string strParam, ref string strValue, ref string strOutErrMsg);
        result= self.tasdll.GetWOBomInfo(strWO, strParam,strValue,strOutErrMsg)
        return result

    def GetFiberLotInfo(self, strLot, PN='',strOutErrMsg=''):
        #通过物料Lot获取物料信息
        # bool GetFiberLotInfo(string strLot, ref string PN, ref string strOutErrMsg);
        result= self.tasdll.GetFiberLotInfo(strLot, PN,strOutErrMsg)
        return result

    def GetGlueInfo(self, strGlueLot, PN='',GlueDate='',strOutErrMsg=''):
        #通过胶批号获取胶信息
        # bool GetGlueInfo(string strGlueLot, ref string PN, ref DateTime GlueDate, 
        # ref string strOutErrMsg);
        result= self.tasdll.GetGlueInfo(strGlueLot, PN,GlueDate,strOutErrMsg)
        return result









