# -*- coding: utf-8 -*-

from ctypes import Structure, c_char, c_int, c_bool, c_double, POINTER, c_void_p, c_char_p
from ctypes import c_ulong,c_short,c_ushort,Union,c_ubyte
from enum import IntEnum
import ctypes


XSB_NONE = 0x00000000
XSB_OK	= 0x00000001
XSB_YES	= 0x00000002
XSB_NO	= 0x00000004
XSB_IGNORE	= 0x00000008
XSB_RETRY	= 0x00000010
XSB_ABORT	= 0x00000020
XSB_CANCEL	= 0x00000040

XSB_ICONERROR = 0x00020000
XSB_ICONWARNING	= 0x00040000
XSB_ICONINFORMATION = 0x00060000
XSB_ICONQUESTION   = 0x00080000

class CONNTYPE(IntEnum):
    CONN_TP = 0
    CONN_GUI = 1
    CONN_DRV = 2


class LOGLEVEL(IntEnum):
    LOG_NORMAL = 0
    LOG_WARNING = 1
    LOG_ERROR = 2


class GRAPHOPT(IntEnum):
    GRAPH_OPT_NEW = 0
    GRAPH_OPT_ADDPLOT = 1
    GRAPH_OPT_ADDDATA = 2
    GRAPH_OPT_DELPLOT = 3


class TASKRESULT(IntEnum):
    TASK_START = 0
    TASK_STOP = 1
    TASK_FAIL = 2
    TASK_DONE = 3


class TASKRANGETYPE(IntEnum):
    TASK_RG_CLASS = 0
    TASK_RG_PARENT = 1
    TASK_RG_CHILD = 2
    TASK_RG_OFFSET = 3


class TASKRANGENUM(IntEnum):
    TASK_RG_NUM1 = 10000
    TASK_RG_NUM2 = 20000
    TASK_RG_NUM3 = 30000
    TASK_RG_NUM4 = 40000
    TASK_RG_NUM5 = 50000
    TASK_RG_NUM6 = 60000
    TASK_RG_NUM7 = 70000
    TASK_RG_NUM8 = 80000
    TASK_RG_NUM9 = 90000


class TASKOFFSET(IntEnum):
    TASK_OFF_0 = 0
    TASK_OFF_1000 = 10000
    TASK_OFF_2000 = 20000
    TASK_OFF_3000 = 30000
    TASK_OFF_4000 = 40000
    TASK_OFF_5000 = 50000
    TASK_OFF_6000 = 60000
    TASK_OFF_7000 = 70000
    TASK_OFF_8000 = 80000
    TASK_OFF_9000 = 90000


class TASKINFOKEY(IntEnum):
    # // // / 线圈测试
    ROOM_25_WOI07_B_BLUE = 1
    ROOM_25_WOI03_MODULE2 = 2
    ROOM_25_WOI03_MODULE3 = 3
    ROOM_25_WOI03_MODULE4 = 4
    ROOM_25_WOI03_UPIL_MODULE1 = 5
    ROOM_25_WOI03_UPIL_MODULE2 = 6
    ROOM_25_WOI03_UPIL_MODULE3 = 7
    ROOM_25_WOI03_UPIL_MODULE4 = 8
    # // // / 干涉计组装测试
    ROOM_25_WOI06_MODULE1 = 9
    ROOM_25_WOI06_MODULE2 = 10
    ROOM_25_WOI06_MODULE3 = 11
    ROOM_25_WOI06_MODULE4 = 12
    ROOM_25_WOI06_MODULE5 = 13
    ROOM_25_WOI06_MODULE6 = 14
    ROOM_25_WOI06_MODULE7 = 15
    ROOM_25_WOI06_MODULE8 = 16
    ROOM_25_WOI06_UPIL_MODULE1 = 17
    ROOM_25_WOI06_UPIL_MODULE2 = 18
    ROOM_25_WOI06_UPIL_MODULE3 = 19
    ROOM_25_WOI06_UPIL_MODULE4 = 20
    ROOM_25_WOI06_UPIL_MODULE5 = 21
    ROOM_25_WOI06_UPIL_MODULE6 = 22
    ROOM_25_WOI06_UPIL_MODULE7 = 23
    ROOM_25_WOI06_UPIL_MODULE8 = 24

    # // // / 干涉计盘盒测试
    ROOM_25_WOI08_MODULE1 = 25
    ROOM_25_WOI08_MODULE2 = 26
    ROOM_25_WOI08_MODULE3 = 27
    ROOM_25_WOI08_MODULE4 = 28
    ROOM_25_WOI08_MODULE5 = 29
    ROOM_25_WOI08_MODULE6 = 30
    ROOM_25_WOI08_MODULE7 = 31
    ROOM_25_WOI08_MODULE8 = 32

    ROOM_25_WOI08_UPIL_MODULE1 = 33
    ROOM_25_WOI08_UPIL_MODULE2 = 34
    ROOM_25_WOI08_UPIL_MODULE3 = 35
    ROOM_25_WOI08_UPIL_MODULE4 = 36
    ROOM_25_WOI08_UPIL_MODULE5 = 37
    ROOM_25_WOI08_UPIL_MODULE6 = 38
    ROOM_25_WOI08_UPIL_MODULE7 = 39
    ROOM_25_WOI08_UPIL_MODULE8 = 40


class KEY_ITEM(IntEnum):
    TEST_INIT = 99
    DEVICE_REF = 100
    TEST_REF = 101


class CALI_POSITION(IntEnum):
    POS_NULL = -1  # //无
    POS_0 = 0  # 盘盒 VOA定标
    POS_1 = 1  # 增益预定标
    POS_2 = 2  # 增益定标及PD定标
    POS_3 = 3  # 常温验证，增益及PD
    POS_4 = 4  # 高低温验证，主要为增益验证
    POS_5 = 5  # 未启用
    POS_6 = 6  # 未启用


class SOCKACT(IntEnum):
    MIMS_NONE = 0
    # //Command
    MIMS_COM_RUNTASK = 1
    MIMS_COM_RUNDEV = 2
    MIMS_COM_STOPRUN = 3
    MIMS_COM_DEBUGMOD = 4
    # //Message
    MIMS_MSG_BASEINFO = 5
    MIMS_MSG_TASKINFO = 6
    MIMS_MSG_SHOWBOX = 7
    MIMS_MSG_FEEDBACK = 8
    MIMS_MSG_LOG = 9
    # //Data
    MIMS_DAT_PROCESS = 10
    MIMS_DAT_PROGRESS = 11
    MIMS_DAT_GRAPH = 12
    # //Setting
    MIMS_SET_SYSTEM = 13
    # //Quit TP
    MIMS_QUIT = 14
    
    

class STSOCKINITINFO(Structure):
    _fields_ = [
        ("iConnType", c_int),  # Socket client type
        ("pszSrvIP", c_char_p),  # Server IP, NULL means the IP is 127.0.0.1
    ]
stSockInfo = STSOCKINITINFO
pstSockInfo = ctypes.POINTER(STSOCKINITINFO)

class S_un_b(Structure):
    _fields_ = [
        ("s_b1", c_ubyte),
        ("s_b2", c_ubyte),
        ("s_b3", c_ubyte),
        ("s_b4", c_ubyte),
    ]

# Nested struct for words
class S_un_w(Structure):
    _fields_ = [
        ("s_w1", c_ushort),
        ("s_w2", c_ushort),
    ]

# The union containing both structs and the ULONG
class _S_un(Union):
    _fields_ = [
        ("S_un_b", S_un_b),
        ("S_un_w", S_un_w),
        ("S_addr", c_ulong),
    ]

# The top‐level in_addr struct
class in_addr(Structure):
    _anonymous_ = ("S_un",)     # allow direct access to union members
    _fields_ = [
        ("S_un", _S_un),
    ]


class sockaddr_in(Structure):
    _fields_ = [
        ("sin_family", c_short),
        ("sin_port", c_ushort),
        ("sin_addr", in_addr),
        ("sin_zero", c_char*8),
    ]

class STCOMMHEAD(Structure):
    _fields_ = [
        ("dwSequence", c_ulong),  # Sequence number
        ("addr", sockaddr_in),  # Connect client address
        ("iConnType", c_int),  # Connect client type
        ("dwMsgLens", c_ulong),  # Message length
    ]
stCommHead = STCOMMHEAD
pstCommHead = ctypes.POINTER(STCOMMHEAD)

class STCOMMMSG(Structure):
    _fields_ = [
        ("stHead", stCommHead),  # The head information of message
        ("buf", c_char*10240),  # Buffer of the message
    ]
stCommMsg = STCOMMMSG
pstCatchMsg = ctypes.POINTER(STCOMMMSG)

class STCOMMCATCH(Structure):
    _fields_ = [
        ("stHead", stCommHead),  # The head information of message
        ("cat", c_char_p),  # Pointer of the catch to receive volatile length of the message
    ]
stCommCatch = STCOMMCATCH
pstCommCatch = ctypes.POINTER(STCOMMCATCH)

class STTHREADINFO(Structure):
    _fields_ = [
        ("lpSocket", c_void_p),  # Socket handle
        ("lpSocketAddr", c_void_p),  # socket address to send to
        ("lpDlg", c_void_p),  # CWnd based pointer
    ]
stThreadInfo = STTHREADINFO
pstThreadInfo = ctypes.POINTER(STTHREADINFO)

class STTASKITEMSID(Structure):
    _fields_ = [
        ("type", c_int),  # Item type
        ("iID", c_int),  # Item ID
        ("pszProcessTypeList", c_char * 64),  # 生效的无纸化步骤列表
        ("pszPnList", c_char * 64),  # //生效的PN列表
        ("pszName", c_char * 64),  # Item Name
        ("psTaskFile", c_char * 260),  # Item Name
        ("psTaskFunc", c_char * 260),  # Item Name
        ("pszDecription", c_char * 512),  # Item description
    ]
stTaskItemsID = STTASKITEMSID
pstTaskItemsID = ctypes.POINTER(STTASKITEMSID)

class STONETASKSTATUS(Structure):
    _fields_ = [
        ("iID", c_int),
        ("iStatus", c_int)
    ]
stOneTaskStatus = STONETASKSTATUS
pstOneTaskStatus = ctypes.POINTER(STONETASKSTATUS)

class STTASKINFOPACK(Structure):
    _fields_ = [
        ("iTaskCount", c_int),
        ("pstAllTaskState", stOneTaskStatus)
    ]
stTaskInfoPack = STTASKINFOPACK
pstTaskInfoPack = ctypes.POINTER(STTASKINFOPACK)

class STSCALEINFO(Structure):
    _fields_ = [
        ("bScaleUse", c_int),
        ("pszScaleName", c_char * 64),
        ("bScaleAuto", c_int),
        ("dblScaleStart", c_double),
        ("dblScaleEnd", c_double),
    ]
stScaleInfo = STSCALEINFO
pstScaleInfo = ctypes.POINTER(STSCALEINFO)

class STGRAPHINITINFO(Structure):
    _fields_ = [
        ("iGraphIndex", c_int),
        ("pszTitle", c_char * 64),
        ("stScale", stScaleInfo * 3),
    ]
stGraphInitInfo = STGRAPHINITINFO
pstGraphInitInfo = ctypes.POINTER(STGRAPHINITINFO)

class STGRAPHDATAINFO(Structure):
    _fields_ = [
        ("opt", c_int),
        ("iGraphIndex", c_int),
        ("iPlotIndex", c_int),
        ("pszPlotTitle", c_char * 64),
        ("iColor", c_int),
        ("iYScaleIndex", c_int),
        ("iDataCount", c_int),
        ("pdblXData", POINTER(c_double)),
        ("pdblYData", POINTER(c_double)),
    ]
stGraphDataInfo = STGRAPHDATAINFO
pstGraphDataInfo = ctypes.POINTER(STGRAPHDATAINFO)

class STPROGRESSDATAINFO(Structure):
    _fields_ = [
        ("iFullStep", c_int),
        ("iStep", c_int),
    ]
stProgressDataInfo = STPROGRESSDATAINFO
pstProgressDataInfo = ctypes.POINTER(STPROGRESSDATAINFO)


class STPROCESSDATAINFO(Structure):
    _fields_ = [
        ("iDataID", c_int),
        ("pszOpLine", c_char * 256),
        ("pszDataName", c_char * 256),
        ("dbDataResult", c_double),
        ("dbDataRangeUp", c_double),
        ("dbDataRangeLow", c_double),
    ]
stProcessDataInfo = STPROCESSDATAINFO
pstProcessDataInfo = ctypes.POINTER(STPROCESSDATAINFO)