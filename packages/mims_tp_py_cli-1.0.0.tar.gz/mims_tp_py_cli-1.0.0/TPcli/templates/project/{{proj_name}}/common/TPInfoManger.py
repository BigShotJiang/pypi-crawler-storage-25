# -*- coding: utf-8 -*-
import sys
import os
import logging
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
parent_dir = os.path.dirname(script_dir)
sys.path.append(parent_dir)

from common.TPUseXMLDataType import ALL_MSG_DATA
import xml.etree.ElementTree as ET
from common.DataSrc import stTaskItemsID
from common.DataSrc import TASKRANGETYPE
from common.DataSrc import TASKOFFSET
from common.DataSrc import LOGLEVEL
import common.DataSrc 
from common.UICommand import UICommand

class TPInfoManager:

    def __init__(self,pNetCommand):
        self.m_strTestMode=''
        self.m_strWorkOlder=''
        self.m_strprdFamily=''
        self.m_strAliasName1=''
        self.m_strAliasName2=''
        self.m_strAliasName3=''
        self.m_strMTOPN=''
        self.m_strOplinkPN=''
        self.m_bInProcess=''
        self.m_bInHold=''
        self.m_bInReWork=''
        self.m_bIsTestProcess=''
        self.m_strUISendUser=""
        self.m_pstSockInfo = ALL_MSG_DATA()
        self.m_taskinfo = dict()
        self.m_strCfgSpec =""
        self.m_nCfgCount = 0
        self.m_strCfgPNArray = []
        self.m_AllTestItemArray = []
        self.m_pNetCommand = pNetCommand
        self.m_strError = ""
        self.m_strVersion =""
        self.m_strAuthor =""
        self.m_strDate =""
        self.m_strUISendPN =""
        self.m_strUISendSpec =""
        self.m_strUISendProcessType =""
        
        
    def LoadXMLTaskNode(self,node):
        for tasknode in node.findall('TaskNode'):
            if tasknode.attrib['Enable'] == '1':    
                pTaskItemID = stTaskItemsID()
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_CHILD
                pTaskItemID.iID = int(tasknode.attrib['Index'])
                pTaskItemID.pszProcessTypeList = tasknode.attrib['ProcessTypeList'].encode('utf-8')
                pTaskItemID.pszPnList = tasknode.attrib['PNList'].encode('utf-8')
                pTaskItemID.pszName = tasknode.attrib['Title'].encode('utf-8')
                pTaskItemID.psTaskFile = tasknode.attrib['TaskFile'].encode('utf-8')
                pTaskItemID.psTaskFunc = tasknode.attrib['TaskFunc'].encode('utf-8')
                pTaskItemID.pszDecription = tasknode.attrib['Name'].encode('utf-8')
                self.m_AllTestItemArray.append(pTaskItemID) 
            
    def LoadXMLLevelNode(self, node):
        for _node in node.findall('LEVEL'): 
           
            _level = _node.attrib['Attribute']
            # bytes_data = _level.encode('utf-8')
            last_byte = _level[-1]
            pTaskItemID = stTaskItemsID()
            if last_byte == '1':
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_CLASS
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_1000
            elif last_byte == '2':
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_2000
            elif last_byte == '3':  
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_3000                        
            elif last_byte == '4':  
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_4000                   
            elif last_byte == '5':  
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_5000                       
            elif last_byte == '6': 
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_6000                  
            elif last_byte == '7': 
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_7000                       
            elif last_byte == '8':  
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_8000                    
            elif last_byte == '9':  
                pTaskItemID.type = TASKRANGETYPE.TASK_RG_PARENT
                pTaskItemID.iID = TASKOFFSET.TASK_OFF_9000 
                
            pTaskItemID.pszProcessTypeList = _node.attrib['ProcessTypeList'].encode('utf-8')
            pTaskItemID.pszPnList = _node.attrib['PNList'].encode('utf-8')
            pTaskItemID.pszName = _node.attrib['Title'].encode('utf-8')
            pTaskItemID.psTaskFile = "".encode('utf-8')
            pTaskItemID.psTaskFunc = "".encode('utf-8')
            pTaskItemID.pszDecription = _node.attrib['Name'].encode('utf-8')
            self.m_AllTestItemArray.append(pTaskItemID) 
            self.LoadXMLTaskNode(_node)
            self.LoadXMLLevelNode(_node)
          
    def LoadTestItemXML(self):
        
        try:
            strItemCfgPath = '.\\TP-TASK-INFO.xml'
            # 加载XML文件
            tree = ET.parse(strItemCfgPath)
            root = tree.getroot()
            self.m_strCfgPNArray = []
            self.m_AllTestItemArray = []
            for child in root:
                if str(child.tag).upper() == 'SPEC':
                    self.m_strCfgSpec = child.text
                    self.m_nCfgCount = int(child.attrib['PNCount'])
                
            for pn in root.findall('SPEC'): 
                self.m_strCfgPNArray.append(pn.text)
            
            for pn in root.findall('PN'): 
                self.m_strCfgPNArray.append(pn.text)

            pTaskItemID = stTaskItemsID()
            pTaskItemID.type = TASKRANGETYPE.TASK_RG_OFFSET
            pTaskItemID.iID = TASKOFFSET.TASK_OFF_0
            pTaskItemID.pszProcessTypeList = "ALL".encode('utf-8')
            pTaskItemID.pszPnList = "1".encode('utf-8')
            pTaskItemID.pszName = "".encode('utf-8')
            pTaskItemID.psTaskFile = "".encode('utf-8')
            pTaskItemID.psTaskFunc = "".encode('utf-8')
            pTaskItemID.pszDecription = "".encode('utf-8')
            self.m_AllTestItemArray.append(pTaskItemID)         
            self.LoadXMLLevelNode(root)        
            # print(self.m_AllTestItemArray)   
        except Exception as e:
            self.m_strError = str(e)
            print(e)
            return False    
            
        return True
        
    def GetTPInfoFromXML(self): 
        try:
            strItemCfgPath = '.\\TP-TASK-INFO.xml'
            # 加载XML文件
            tree = ET.parse(strItemCfgPath)
            root = tree.getroot()  
            for _info in root.findall('Info'): 
                self.m_strVersion = _info.attrib['Version']
                self.m_strAuthor = _info.attrib['Author']
                self.m_strDate = _info.attrib['Date']
                
        except Exception as e:
            self.m_strError = str(e)
            print(e)
            return False
        return True
            
            
    def SendTPDllInfo(self):
        
        res= self.GetTPInfoFromXML()
        if res == False:
            strlog = self.m_strError
            self.m_pNetCommand.XmlSendLog(strlog, len(strlog) + 1, LOGLEVEL.LOG_ERROR) 
            return False
            
        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szPnNumber
        self.m_strUISendPN = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        
        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szSpec
        self.m_strUISendSpec = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        
        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szProcessType
        self.m_strUISendProcessType = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        
        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szTestMode
        self.m_strTestMode = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szMFGOrder
        self.m_strWorkOlder = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szProductFamily
        self.m_strprdFamily = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szAliasName1
        self.m_strAliasName1 = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szAliasName2
        self.m_strAliasName2 = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szAliasName3
        self.m_strAliasName3 = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szMTOPN
        self.m_strMTOPN = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szOplinkPN
        self.m_strOplinkPN = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szInProcess
        data_str = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        if data_str != '':
            iFlag =int(data_str)
            if (iFlag > 0):
                self.m_bInProcess = True
            else:
                self.m_bInProcess = False

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szInHold
        data_str = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        if data_str != '':
            iFlag = int(data_str)
            if (iFlag > 0):
                self.m_bInHold = True
            else:
                self.m_bInHold = False

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szInRework
        data_str = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        if data_str !='':
            iFlag = int(data_str)
            if (iFlag > 0):
                self.m_bInReWork = True
            else:
                self.m_bInReWork = False

        raw = self.m_pstSockInfo.unDataStruct.MsgBaseInfo.szIsTestSpec
        data_str = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')
        if data_str != '':
            iFlag = int(data_str)
            if (iFlag > 0):
                self.m_bIsTestProcess = True
            else:
                self.m_bIsTestProcess = False
        strAuthor = self.m_strAuthor
        strVersion = self.m_strVersion    
        strSpec = self.m_strUISendSpec
        strDate = self.m_strDate
        strPN = self.m_strUISendPN
        strProcessType = self.m_strUISendProcessType
        res = self.m_pNetCommand.XmlBaseInfo(strAuthor, strVersion, strSpec, strPN, strDate, strProcessType)
        if res is False:
            m_strErr = self.m_pNetCommand.GeXmlMsgError()
            self.m_pNetCommand.XmlSendLog(m_strErr, len(m_strErr) + 1, LOGLEVEL.LOG_ERROR) 
            return False		    
        return True
    
    def TaskInfoPro(self):
        res = False
        strFindPN = self.m_strUISendPN
        
        iTotalItem = len(self.m_AllTestItemArray)
        
        if iTotalItem == 0:
            self.m_strError ='The task count is 0，Please check the configuration'
            res = False
               
        strIndex =""
        strTitle =""
        iParent = 0 
        iOffset = 0
        for pTempTaskItem in self.m_AllTestItemArray:
            if pTempTaskItem.type == common.DataSrc.TASKRANGETYPE.TASK_RG_OFFSET:
                iOffset = pTempTaskItem.iID
            elif pTempTaskItem.type == common.DataSrc.TASKRANGETYPE.TASK_RG_CLASS:
                iParent = pTempTaskItem.iID
                strIndex += str(iParent)
                strIndex += ";"
                strTitle += pTempTaskItem.pszName.decode('utf-8')
                strTitle += ";"
            elif pTempTaskItem.type == common.DataSrc.TASKRANGETYPE.TASK_RG_PARENT:
                iParent = pTempTaskItem.iID
                strIndex +=  str(iParent)
                strIndex += ";"
                strTitle += pTempTaskItem.pszName.decode('utf-8');
                strTitle += ";"
            elif pTempTaskItem.type == common.DataSrc.TASKRANGETYPE.TASK_RG_CHILD:
                strTemp = pTempTaskItem.pszProcessTypeList.decode('utf-8')
                strPNList = pTempTaskItem.pszPnList.decode('utf-8')
                if self.m_strUISendProcessType in strTemp  and strFindPN in strPNList :
                    iID = pTempTaskItem.iID + iParent + iOffset;
                    strIndex += str(iID)
                    strIndex += ";"
                    strTitle += pTempTaskItem.pszName.decode('utf-8')
                    strTitle += ";"
        res = True
                    
        return res,strIndex,strTitle
        
    
    def entry_function():
        pass
        
    
        
    def SendTaskInfo(self):
        res = self.LoadTestItemXML() 
        if res == False:
            strErr = self.m_strError
            self.m_pNetCommand.XmlSendLog(strErr, len(strErr) + 1, LOGLEVEL.LOG_ERROR);
            return False
        res,strIndex,strTitle = self.TaskInfoPro()
                
        if res is False:
            m_strErr = "处理测试任务信息设置出错."
            self.m_pNetCommand.XmlSendLog(m_strErr, len(m_strErr) + 1, LOGLEVEL.LOG_ERROR);
            return False
        res =  self.m_pNetCommand.XmlTaskInfo(strIndex,strTitle)
        if res is False:
            m_strErr = self.m_pNetCommand.GeXmlMsgError()
            self.m_pNetCommand.XmlSendLog(m_strErr, m_strErr.GetLength() + 1, LOGLEVEL.LOG_ERROR);
            return False
        
        return True
    

    def GetUISendUser(self):
        raw = self.m_pstSockInfo.contents.unDataStruct.ComRunInitData.szSN
        self.m_strUISendSN = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.contents.unDataStruct.ComRunInitData.szUser
        self.m_strUISendUser=raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        raw = self.m_pstSockInfo.contents.unDataStruct.ComRunInitData.szPN
        self.m_strUISendPN = raw.split(b'\x00', 1)[0].decode('utf-8', errors='ignore')

        return self.m_strUISendUser
    
    def GetUISendMTOPN(self):
        return self.m_strMTOPN

    def GetUISendTestMode(self):
        return self.m_strTestMode

    def GetUISendWorkOder(self):
        return self.m_strWorkOlder

    def GetUISendProdFamily(self):
        return self.m_strprdFamily

    def GetUISendAliasName1(self):
        return self.m_strAliasName1

    def GetUISendAliasName2(self):
        return self.m_strAliasName2

    def GetUISendAliasName3(self):
        return self.m_strAliasName1

    def GetUISendInProcess(self):
        return self.m_bIsTestProcess

    def GetUISendIsTestProcess(self):
        return self.m_bInProcess

    def GetUISendInHold(self):
        return self.m_bInHold

    def GetUISendInReWork(self):
        return self.m_bInReWork

if __name__ =="__main__":
     n =  UICommand()
     aa = TPInfoManager(n)
     aa.LoadTestItemXML() 
     aa.SendTaskInfo()







