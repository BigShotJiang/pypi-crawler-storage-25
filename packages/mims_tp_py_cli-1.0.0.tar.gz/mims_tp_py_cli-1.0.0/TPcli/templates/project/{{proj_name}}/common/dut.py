import logging
import socket
import telnetlib
import time
from ftplib import FTP
from typing import Union
import paramiko
import serial
from scp import SCPClient

class FTP_COM:  # 使用FTP协议登录设备
    def __init__(self, hostname: str = '', port: Union[str, int] = 21, username: str = '', password: str = '',
                 timeout: int = 10):
        # FTP（文件传输）协议代理服务器常用端口号：21
        self.ftp = FTP(timeout=timeout)
        self.ftp.connect(hostname, port)
        self.ftp.login(username, password)

    def Print_Welcome_Info(self) -> None:
        # 打印出欢迎信息
        result = self.ftp.getwelcome()
        logging.info(result)

    def FTP_folder_to_remote(self, local_file_path: str, remote_file_path: str) -> None:
        # 上传文件到服务器
        with open(local_file_path, 'rb') as local_file:
            self.ftp.storbinary('STOR {}'.format(remote_file_path), local_file)

    def FTP_remote_to_folder(self, local_file_path: str, remote_file_path: str) -> None:
        # 下载文件到客户端
        with open(local_file_path, 'wb') as local_file:
            self.ftp.retrbinary('RETR {}'.format(remote_file_path), local_file.write)

    def Set_Direction(self, path: str) -> None:
        # 更改工作目录
        self.ftp.cwd(path)

    def Get_Current_Direction(self) -> str:
        # 显示当前工作目录
        return self.ftp.pwd()

    def Get_Files(self) -> list:
        # 列出当前目录下的文件和文件夹
        files_and_dirs = self.ftp.nlst()
        return files_and_dirs

    def Get_Directions(self):
        # 显示目录下文件信息
        return self.ftp.dir()

    def Delete_File(self, filename: str) -> None:
        # 删除服务器远程文件
        self.ftp.delete(filename)

    def Delete_Direction(self, dirname: str) -> None:
        # 删除远程目录
        self.ftp.rmd(dirname)

    def close(self) -> None:
        # 断开与FTP服务器的连接
        self.ftp.quit()


class SFTP_COM:  # SFTP传输文件
    def __init__(self, hostname: str = '', port: Union[str, int] = 22, username: str = '', password: str = '',
                 timeout: float = 10):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname=hostname, port=port, timeout=timeout,banner_timeout=timeout,
                         username=username, password=password)
        self.channel = self.ssh.invoke_shell()
        time.sleep(1)
        self.sftp = self.ssh.open_sftp()
        # hostname:IP
        # port:SSH（安全登录）、SCP（文件传输）、端口号重定向，默认的端口号为22/tcp
        # username:用户名
        # password:密码
        # timeout:超过此时间还没有等到会失败

    def close(self):
        self.channel.close()
        self.sftp.close()
        self.ssh.close()

    def SFTP_folder_to_remote(self, local_file_path: str, remote_file_path: str):
        # SFTP上传文件
        self.sftp.put(localpath=local_file_path, remotepath=remote_file_path)

    def SFTP_remote_to_folder(self, local_file_path: str, remote_file_path: str):
        # SFTP下载文件到客户端
        self.sftp.get(localpath=local_file_path, remotepath=remote_file_path)


class SCP_COM:  # SCP协议传输文件
    def __init__(self, hostname: str = '', port: Union[str, int] = 22, username: str = '', password: str = '',
                 timeout: float = 10):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname=hostname, port=port, timeout=timeout,banner_timeout=timeout,
                         username=username, password=password)
        self.channel = self.ssh.invoke_shell()
        time.sleep(1)
        self.scp = SCPClient(self.ssh.get_transport())
        # hostname:IP
        # port:SSH（安全登录）、SCP（文件传输）、端口号重定向，默认的端口号为22/tcp
        # username:用户名
        # password:密码
        # timeout:超过此时间还没有等到会失败

    def close(self):
        self.channel.close()
        self.scp.close()
        self.ssh.close()

    def SCP_folder_to_remote(self, local_file_path: str, remote_file_path: str):
        # SCP上传文件到服务器
        self.scp.put(files=local_file_path, recursive=True, remote_path=remote_file_path)

    def SCP_remote_to_folder(self, local_file_path: str, remote_file_path: str):
        # SCP下载文件到客户端
        self.scp.get(remote_path=remote_file_path, local_path=local_file_path, recursive=True)


class SSH_COM:  # 使用SSH协议远程登录设备
    def __init__(self, hostname: str = '', port: Union[str, int] = 22, username: str = '', password: str = '',
                 timeout: float = 10):
        self.hostname = hostname
        self.port = port
        self.timeout = timeout
        self.username = username
        self.password = password
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname=self.hostname, port=self.port, timeout=self.timeout,banner_timeout=self.timeout,
                         username=self.username, password=self.password)
        self.channel = self.ssh.invoke_shell()
        time.sleep(1)

        # hostname:IP
        # port:SSH（安全登录）、SCP（文件传输）、端口号重定向，默认的端口号为22/tcp
        # username:用户名
        # password:密码
        # timeout:超过此时间还没有等到会失败

    def open(self):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname=self.hostname, port=self.port, timeout=self.timeout,banner_timeout=self.timeout,
                         username=self.username, password=self.password)
        self.channel = self.ssh.invoke_shell()
        time.sleep(1)

    def close(self):
        self.channel.close()
        self.ssh.close()



    def send_data(self, data: str, sleep_time: float = 0.5, expect: Union[str, list] = '', fail: str = '',
                  suffix: str = '\r',
                  timeout: float = 30, coding: str = 'utf-8',
                  keep_time: float = 0.01, log_print: bool = True) -> str:
        # data:发送数据
        # sleep_time:发送数据之后睡眠时间
        # expect:期待等到的字符串，只能为字符串或者列表(列表内部是字符串,列表不能为空)
        # suffix:发送的数据带的后缀
        # fail:报错的字符串
        # timeout:超过此时间还没有等到expect会失败
        # coding:发送数据的编码格式，有utf-8与十六进制2种形式
        # keep_time:指令执行完毕，buffer读取完成之后的睡眠时间
        # log_print:是否打印buffer
        if expect == '':
            if coding == 'utf-8':
                send_data = data + suffix
                start_time = time.time()
                self.channel.send(send_data.encode("utf-8"))
                time.sleep(sleep_time)
                logging.info("send data:{}".format(data))
                while True:
                    end_time = time.time()
                    if end_time - start_time < timeout:
                        if not self.channel.recv_ready():  # 当通道数据读取完毕，返回TRUE
                            time.sleep(0.01)
                        else:
                            buffer = self.channel.recv(102400)
                            try:
                                buffer = buffer.decode('utf-8').replace('\r', '')
                            except Exception as e:
                                buffer = buffer
                            break
                    else:
                        logging.error('wait for {} timeout'.format(expect))
                        raise Exception
                logging.info(buffer)
            else:
                start_time = time.time()
                self.channel.send(bytes.fromhex(data))
                time.sleep(sleep_time)
                logging.info("send data:{}".format(data))
                while True:
                    end_time = time.time()
                    if end_time - start_time < timeout:
                        if not self.channel.recv_ready():  # 当通道数据读取完毕，返回TRUE
                            time.sleep(0.01)
                        else:
                            buffer = self.channel.recv(102400)
                            break
                    else:
                        logging.error('wait for {} timeout'.format(expect))
                        raise Exception
                logging.info(buffer)
        else:
            buffer = ''
            if coding == 'utf-8':
                send_data = data + suffix
                self.channel.send(send_data.encode("utf-8"))
                logging.info("send data:{}".format(data.replace('\r', '').replace('\n', '')))
                start_time = time.time()
                time.sleep(sleep_time)
                buffer2 = ''
                while True:
                    end_time = time.time()
                    if end_time - start_time < timeout:
                        if not self.channel.recv_ready():  # 当通道数据读取完毕，返回TRUE
                            time.sleep(0.01)
                        else:
                            new_buffer = self.channel.recv(1024000)  # 确保读取buffer的byte数量足够大
                            try:
                                new_buffer = new_buffer.decode('utf-8','ignore')
                            except Exception as e:
                                new_buffer = str(new_buffer)
                            buffer2 += new_buffer
                            if type(expect) is str:
                                if expect in buffer2:  #
                                    datatemp = data.replace('\r', '').replace('\n', '').strip()
                                    buffer2 = buffer2.replace(datatemp, "").replace('\r', '')
                                    break
                            else:
                                if any(substring in buffer2 for substring in expect):
                                    datatemp = data.replace('\r', '').replace('\n', '').strip()
                                    buffer2 = buffer2.replace(datatemp, "").replace('\r', '')
                                    break
                    else:
                        logging.error('wait for {} timeout'.format(expect))
                        raise Exception

                if buffer2.replace('\r', '').strip() != data.replace('\r', '').replace('\n', ''):
                    buffer += buffer2.replace('\r', '')
                    if log_print is True:
                        logging.warning(buffer.strip())
                if type(expect) is str:
                    if expect in buffer:
                        if fail != '' and fail in buffer:
                            logging.error('fail {} in buffer'.format(fail))
                            raise Exception
                else:
                    if any(substring in buffer for substring in expect):
                        if fail != '' and fail in buffer:
                            logging.error('fail {} in buffer'.format(fail))
                            raise Exception
        time.sleep(keep_time)
        return buffer


class SERIAL_COM:  # 串口通信
    def __init__(self, port, baud):
        self.dev = serial.Serial(port, baud, bytesize=8, parity='N',
                                 stopbits=1, xonxoff=False,
                                 rtscts=False,
                                 dsrdtr=False)

        # 初始化设备
        # port是串口号，如COM117
        # baud是波特率，如115200

    def open(self):
        if not self.dev.isOpen():
            self.dev.open()
            # 打开设备

    def close(self):
        # 关闭设备
        self.dev.close()

    def send_data(self, data: str, sleep_time: float = 0.5, expect: Union[str, list] = '', fail: str = '',
                  suffix: str = '\r',
                  timeout: float = 30, coding: str = 'utf-8',
                  keep_time: float = 0.01, log_print: bool = True) -> str:
        # data:发送数据,ctrl+C是chr(3).encode('utf-8),suffix='',ctrl+C是chr(26).encode('utf-8),suffix=''
        # sleep_time:发送数据之后睡眠时间
        # expect:期待等到的字符串，只能为字符串或者列表(列表内部是字符串,列表不能为空)
        # suffix:发送的数据带的后缀
        # fail:报错的字符串
        # timeout:超过此时间还没有等到expect会失败
        # coding:发送数据的编码格式，有utf-8与十六进制2种形式
        # keep_time:指令执行完毕，buffer读取完成之后的睡眠时间
        # log_print:是否打印buffer
        self.dev.reset_output_buffer()
        self.dev.reset_input_buffer()
        if expect == '':
            if coding == 'utf-8':
                send_data = data + suffix  # suffix是后缀，专门用于utf-8编码指令
                self.dev.write(send_data.encode("utf-8"))
                if log_print is True:
                    logging.info("send data:{}".format(data))
                time.sleep(sleep_time)
                n = self.dev.inWaiting()
                buffer = self.dev.read(n)
                try:
                    buffer = buffer.decode('utf-8').replace('\r', '')
                except Exception as e:
                    buffer = buffer
                if log_print is True:
                    logging.info(buffer)
            else:
                self.dev.write(bytes.fromhex(data))
                time.sleep(sleep_time)
                if log_print is True:
                    logging.info("send data:{}".format(data))
                n = self.dev.inWaiting()
                buffer = self.dev.read(n).hex().upper()
                if log_print is True:
                    logging.info(buffer)
        else:
            buffer = ''
            if coding == 'utf-8':
                send_data = data + suffix
                self.dev.write(send_data.encode("utf-8"))
                logging.info("send data:{}".format(data.replace('\r', '').replace('\n', '')))
                start_time = time.time()
                time.sleep(sleep_time)
                while True:
                    end_time = time.time()
                    if end_time - start_time < timeout:
                        buffer2 = ''
                        while True:
                            end_time = time.time()
                            if end_time - start_time < timeout:
                                if self.dev.inWaiting() > 0:
                                    new_buffer = self.dev.read(1)
                                    try:
                                        new_buffer = new_buffer.decode('utf-8')
                                    except Exception as e:
                                        new_buffer = str(new_buffer)
                                    buffer2 += new_buffer
                                    if type(expect) is str:
                                        if '\n' == new_buffer or expect in buffer2:  # 有\n或者expect才结束去打印
                                            break
                                    else:
                                        if '\n' == new_buffer or any(substring in buffer2 for substring in expect):
                                            break
                                else:
                                    continue
                            else:
                                logging.error('wait for {} timeout'.format(expect))
                                raise Exception
                        if buffer2.replace('\r', '').strip() != data.replace('\r', '').replace('\n', ''):
                            # 不打印write data
                            if log_print is True:
                                logging.warning(buffer2.replace('\r', '').strip())  # 去掉空行
                            buffer += buffer2.replace('\r', '')
                        if type(expect) is str:
                            if expect in buffer:
                                if fail != '' and fail in buffer:
                                    logging.error('fail {} in buffer'.format(fail))
                                    raise Exception
                                else:
                                    time.sleep(0.01)  # 保证读完全部buffer
                                    buffer_new = self.dev.read(self.dev.inWaiting())
                                    try:
                                        buffer_new = buffer_new.decode('utf-8')
                                    except Exception as e:
                                        buffer_new = str(buffer_new)
                                    if log_print is True:
                                        logging.debug(buffer_new.replace('\r', '').strip())
                                    break
                        else:
                            if any(substring in buffer for substring in expect):
                                if fail != '' and fail in buffer:
                                    logging.error('fail {} in buffer'.format(fail))
                                    raise Exception
                                else:
                                    time.sleep(0.01)  # 保证读完全部buffer
                                    buffer_new = self.dev.read(self.dev.inWaiting())
                                    try:
                                        buffer_new = buffer_new.decode('utf-8')
                                    except Exception as e:
                                        buffer_new = str(buffer_new)
                                    if log_print is True:
                                        logging.debug(buffer_new.replace('\r', '').strip())
                                break
                    else:
                        logging.error('wait for {} timeout'.format(expect))
                        raise Exception
        time.sleep(keep_time)  # 确保指令发出去后产品稳定
        return buffer


class TELNET_COM:  # telnet通信
    def __init__(self, host, port=23, user='', password='', user_expect='', word_expect='',
                 timeout=15):
        # host:IP
        # port:Telnet（远程登录）协议代理服务器常用端口号：23
        # user:用户名
        # password:密码
        # user_expect:期待等到的user字符串
        # word_expect::期待等到的password字符串
        # timeout:超过此时间还没有等到expect会失败
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.user_expect = user_expect
        self.word_expect = word_expect
        self.timeout = timeout
        self.dev = telnetlib.Telnet(self.host, self.port)
        if self.user_expect != '':  # 需要账号密码
            buffer = self.dev.read_until(self.user_expect.encode('utf-8'), timeout=self.timeout).decode('utf-8')
            logging.info(buffer)
            if self.user_expect not in buffer:
                raise Exception
            self.dev.write(self.user.encode('utf-8') + b"\n")
            buffer = self.dev.read_until(self.word_expect.encode('utf-8'), timeout=self.timeout).decode('utf-8')
            logging.info(buffer)
            if self.user_expect not in buffer:
                raise Exception
            self.dev.write(self.password.encode('utf-8') + b"\n")
        else:  # 不需要账号密码
            pass

    def open(self):
        self.dev = telnetlib.Telnet(self.host, self.port)
        if self.user_expect != '':  # 需要账号密码
            buffer = self.dev.read_until(self.user_expect.encode('utf-8'), timeout=self.timeout).decode('utf-8')
            logging.info(buffer)
            if self.user_expect not in buffer:
                raise Exception
            self.dev.write(self.user.encode('utf-8') + b"\n")
            buffer = self.dev.read_until(self.word_expect.encode('utf-8'), timeout=self.timeout).decode('utf-8')
            logging.info(buffer)
            if self.user_expect not in buffer:
                raise Exception
            self.dev.write(self.password.encode('utf-8') + b"\n")
        else:  # 不需要账号密码
            pass

    def close(self):
        self.dev.close()

    def send_data(self, data: str, sleep_time: float = 0.5, expect: Union[str, list] = '', fail: str = '',
                  suffix: str = '\r',
                  timeout: float = 30, coding: str = 'utf-8',
                  keep_time: float = 0.01, log_print: bool = True) -> str:
        # data:发送数据
        # sleep_time:发送数据之后睡眠时间
        # expect:期待等到的字符串，只能为字符串或者列表(列表内部是字符串,列表不能为空)
        # suffix:发送的数据带的后缀
        # fail:报错的字符串
        # timeout:超过此时间还没有等到expect会失败
        # coding:发送数据的编码格式，有utf-8与十六进制2种形式
        # keep_time:指令执行完毕，buffer读取完成之后的睡眠时间
        # log_print:是否打印buffer
        if expect == '':
            send_data = data + suffix  # suffix是后缀，专门用于utf-8编码指令
            self.dev.write(send_data.encode("utf-8"))
            if log_print is True:
                logging.info("send data:{}".format(data))
            time.sleep(sleep_time)
            buffer = self.dev.read_very_eager().decode('utf-8')
            if log_print is True:
                logging.info(buffer)
            if fail != '' and fail in buffer:
                logging.error('fail {} in buffer'.format(fail))
                raise Exception
        else:  # 推荐使用expect不为空
            send_data = data + suffix  # suffix是后缀，专门用于utf-8编码指令
            self.dev.write(send_data.encode("utf-8"))
            if log_print is True:
                logging.info("send data:{}".format(data))
            if type(expect) is str:
                buffer = self.dev.read_until(expect.encode('utf-8'), timeout=timeout).decode('utf-8')
            else:
                expect_list = [item.encode('utf-8') for item in expect]
                buffer = self.dev.expect(expect_list, timeout=timeout).decode('utf-8')[2]
            # timeout超时不报错
            if log_print is True:
                logging.info(buffer)
            if type(expect) is str:
                if expect not in buffer:  # 没有读取到expect
                    logging.error('no get {}'.format(expect))
                    raise Exception
            else:
                if not any(substring in buffer for substring in expect):
                    logging.error('no get {}'.format(expect))
                    raise Exception
            if fail != '' and fail in buffer:
                logging.error('fail {} in buffer'.format(fail))
                raise Exception
        time.sleep(keep_time)  # 确保指令发出去后产品稳定
        return buffer


class SOCK_COM:  # 使用socket协议交互服务器设备
    def __init__(self, hostname, port):
        self.hostname = hostname
        self.port = port
        self.dev = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.dev.connect((self.hostname, self.port))
        # hostname:IP
        # port:端口号

    def open(self):
        self.dev = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.dev.connect((self.hostname, self.port))

    def close(self):
        self.dev.close()

    def send_data(self, data: str, sleep_time: float = 0.5, expect: Union[str, list] = '', fail: str = '',
                  suffix: str = '\r', buffer_size: int = 102400,
                  timeout: float = 30, coding: str = 'utf-8',
                  keep_time: float = 0.01, log_print: bool = True) -> str:
        # data:发送数据
        # sleep_time:发送数据之后睡眠时间
        # expect:期待等到的字符串，只能为字符串或者列表(列表内部是字符串,列表不能为空)
        # suffix:发送的数据带的后缀
        # fail:报错的字符串
        # timeout:超过此时间还没有等到expect会失败
        # coding:发送数据的编码格式，有utf-8与十六进制2种形式
        # keep_time:指令执行完毕，buffer读取完成之后的睡眠时间
        # log_print:是否打印buffer
        if expect == '':
            if coding == 'utf-8':
                send_data = data + suffix
                self.dev.send(send_data.encode("utf-8"))
                time.sleep(sleep_time)
                logging.info("send data:{}".format(data))
                buffer = self.dev.recv(buffer_size)
                try:
                    buffer = buffer.decode('utf-8').replace('\r', '')
                except Exception as e:
                    buffer = buffer
                logging.info(buffer)
            else:
                self.dev.send(bytes.fromhex(data))
                time.sleep(sleep_time)
                logging.info("send data:{}".format(data))
                buffer = self.dev.recv(buffer_size)
                logging.info(buffer)
        else:
            buffer = ''
            if coding == 'utf-8':
                send_data = data + suffix
                self.dev.send(send_data.encode("utf-8"))
                logging.info("send data:{}".format(data.replace('\r', '').replace('\n', '')))
                start_time = time.time()
                time.sleep(sleep_time)
                buffer2 = ''
                while True:
                    end_time = time.time()
                    if end_time - start_time < timeout:
                        new_buffer = self.dev.recv(buffer_size)  # 确保读取buffer的byte数量足够大
                        if not new_buffer:  # 当通道数据读取完毕，返回TRUE
                            time.sleep(0.01)
                        else:
                            try:
                                new_buffer = new_buffer.decode('utf-8')
                            except Exception as e:
                                new_buffer = str(new_buffer)
                            buffer2 += new_buffer
                            if type(expect) is str:
                                if expect in buffer2:  #
                                    datatemp = data.replace('\r', '').replace('\n', '').strip()
                                    buffer2 = buffer2.replace(datatemp, "").replace('\r', '')
                                    break
                            else:
                                if any(substring in buffer2 for substring in expect):
                                    datatemp = data.replace('\r', '').replace('\n', '').strip()
                                    buffer2 = buffer2.replace(datatemp, "").replace('\r', '')
                                    break
                    else:
                        logging.error('wait for {} timeout'.format(expect))
                        raise Exception

                if buffer2.replace('\r', '').strip() != data.replace('\r', '').replace('\n', ''):
                    buffer += buffer2.replace('\r', '')
                    if log_print is True:
                        logging.warning(buffer.strip())
                if type(expect) is str:
                    if expect in buffer:
                        if fail != '' and fail in buffer:
                            logging.error('fail {} in buffer'.format(fail))
                            raise Exception
                else:
                    if any(substring in buffer for substring in expect):
                        if fail != '' and fail in buffer:
                            logging.error('fail {} in buffer'.format(fail))
                            raise Exception
        time.sleep(keep_time)
        return buffer
