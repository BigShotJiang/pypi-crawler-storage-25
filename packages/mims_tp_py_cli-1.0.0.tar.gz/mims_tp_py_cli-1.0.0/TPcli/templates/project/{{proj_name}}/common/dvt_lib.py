import binascii
import configparser
import csv
import gzip
import logging
import math
import os
import struct
import tarfile
import time
import zipfile
from typing import Union
import crcmod
import openpyxl
import serial
import xlwings
import datetime
import re
from xml.etree import ElementTree as ET
import subprocess


class Xmodem_Upgrade:
    def __init__(self, port: str, baud: Union[str, int]):
        self.dev = serial.Serial(port, baud)

    def close(self) -> None:
        self.dev.close()

    def crc_calculate(self, mode: str, data: str, width: int) -> str:
        # mode:crc-8,xmodem,modbus,crc-32
        # see https://crcmod.sourceforge.net/crcmod.predefined.html#class-predefinedcrc
        # crc32_func = crcmod.mkCrcFun(0x104c11db7, rev=True, initCrc=0, xorOut=0xFFFFFFFF)
        # result = str(hex(crc32_func(binascii.unhexlify(data))).upper())
        # crc_data = result[2:].zfill(width)
        crc = crcmod.predefined.Crc(mode)
        hexData = binascii.unhexlify(data.replace(" ", ""))
        crc.update(hexData)
        result = str(hex(crc.crcValue))
        crc_data = result[2:].zfill(width)
        return crc_data

    def start(self, start_cmd: str, start_cmd_code: str = 'utf-8', sleep_time: float = 3) -> None:
        if start_cmd_code == 'utf-8':
            self.dev.write("{}\r\n".format(start_cmd).encode('utf-8'))
            time.sleep(sleep_time)
            n = self.dev.inWaiting()
            buffer = self.dev.read(n).decode('utf-8')
            logging.info(buffer)
            if 'C' not in buffer:
                self.dev.close()
                raise Exception
        else:
            self.dev.write(bytes.fromhex(start_cmd))
            time.sleep(sleep_time)
            logging.info("send data:{}".format(start_cmd))
            n = self.dev.inWaiting()
            buffer = self.dev.read(n).hex().upper()
            logging.info(buffer)
            if '43' not in buffer:  # ‘C’对应的ASCII码的十六进制是0x43
                self.dev.close()
                raise Exception

    def end_upgrade(self, sleep_time: float = 5) -> None:
        for i in range(3):
            self.dev.write(bytes.fromhex('040404'))
            logging.info('040404')
            time.sleep(sleep_time)
            n = self.dev.inWaiting()
            buffer = self.dev.read(n).hex().upper()
            logging.info(buffer)
            if '06' in buffer:
                break
        else:
            logging.info("发送xmodem终止失败")
            self.dev.close()
            raise Exception

    def upgrade(self, filename: str, protocol: str = '1K_xmodem', sleep_time: float = 0.5) -> None:
        data = {}
        FINALSUM = {}  # 字典，以包号作为key,储存数据value
        start = 0
        with open('{}'.format(filename), "rb") as binFile:
            data_str = binFile.read().hex()  # 以十六进制打开FW bin文件
        if protocol == '1K_xmodem':
            data_length = 2048
        else:
            data_length = 256
        max_num = math.ceil(len(data_str) / data_length)
        for i in range(0, max_num - 1):
            start = i * data_length
            data[i] = data_str[start: (start + data_length)]
            FINALSUM[i] = self.crc_calculate('xmodem', '{}'.format(data[i]), 4)
        if max_num > 1:
            start += data_length
            data[max_num - 1] = data_str[(start)::]
            length = int((data_length - len(data[max_num - 1])) / 2)
            for i in range(length):
                data[max_num - 1] += '1A'  # 不足1024字节，不足的部分将以0x1A填充
        else:
            data[max_num - 1] = data_str[0: data_length]
            length = int((data_length - len(data[max_num - 1])) / 2)
            for i in range(length):
                data[max_num - 1] += '1A'  # 不足1024字节，不足的部分将以0x1A填充

        FINALSUM[max_num - 1] = self.crc_calculate('xmodem', '{}'.format(data[max_num - 1]), 4)
        for i in range(max_num):
            for j in range(3):
                if data_length == 2048:
                    send_data = '02 {} {} {} {}'.format(str(hex((1 + i) % 256))[2:].zfill(2),
                                                        str(hex(0xff - (1 + i) % 256))[2:].zfill(2),
                                                        data[i], FINALSUM[i])
                    self.dev.write(bytes.fromhex(send_data))
                    time.sleep(sleep_time)
                    n = self.dev.inWaiting()
                    buffer = self.dev.read(n).hex().upper()
                    logging.info(buffer)
                else:
                    send_data = '01 {} {} {} {}'.format(str(hex((1 + i) % 256))[2:].zfill(2),
                                                        str(hex(0xff - (1 + i) % 256))[2:].zfill(2),
                                                        data[i], FINALSUM[i])
                    self.dev.write(bytes.fromhex(send_data))
                    time.sleep(sleep_time)
                    n = self.dev.inWaiting()
                    buffer = self.dev.read(n).hex().upper()
                    logging.info(buffer)
                if '06' in buffer:
                    break
                else:
                    continue
            else:
                self.dev.write(bytes.fromhex('181818'))
                time.sleep(sleep_time)
                n = self.dev.inWaiting()
                buffer = self.dev.read(n).hex().upper()
                logging.info("取消Xmodem下载")
                self.dev.close()
                raise Exception


class ConfigParse_File:
    def __init__(self, filename: str):
        self.file = filename
        if not os.path.isfile(self.file):
            f = open(self.file, 'w')
            f.close()

    def read_config_item(self,section,option):
        #获取某section下的某个值
        self.config = configparser.RawConfigParser()
        self.config.read(self.file, encoding="gbk")
        if not self.config.has_section(section=section):
            return None
        if not self.config.has_option(section=section, option=option):
            return None
        value = self.config.get(section=section, option=option)
        return value

    def read_all_section(self):
        #获取全部section选项
        self.config = configparser.RawConfigParser()
        self.config.read(self.file, encoding="gbk")
        sections = self.config.sections()
        return sections

    def read_all_option_under_spection(self,section):
        #获取指定section下所有option
        self.config = configparser.RawConfigParser()
        self.config.read(self.file, encoding="gbk")
        if not self.config.has_section(section=section):
            return None
        else:
            options = self.config.options(section=section)
            return options

    def read_all_key_value_under_spection(self, section):
        #获取指定section下所有的键值对
        self.config = configparser.RawConfigParser()
        self.config.read(self.file, encoding="gbk")
        if not self.config.has_section(section=section):
            return None
        items = self.config.items(section=section)
        return items


    def write_config(self, section: str, option: str, value: str) -> None:
        self.config = configparser.RawConfigParser()
        self.config.optionxform = lambda option2: option2
        # 新增大小写不变
        self.config.read(self.file, encoding="gbk")
        if not self.config.has_section(section=section):
            self.config.add_section(section)
        self.config.set(section, option, value)
        self.config.write(open(self.file, "w"))


class Csv_File:
    def write_csv(self, filename: str, data: list, style: str = 'a+') -> None:
        f = open(filename, style, encoding="utf-8-sig", newline="")
        csv.writer(f).writerow(data)
        f.close()

    def read_csv(self, filename: str) -> list:  # 得到csv文件
        file = open(filename, encoding='utf-8-sig')
        reader = csv.reader(file)
        value_list = [row for row in reader]
        file.close()
        return value_list

class XML_File:
    def read(self,file):
        f = open(file, 'r')
        rawdata = f.read()
        if '\"gb2312\"' in rawdata:
            rawdata = re.sub('gb2312', 'utf-8', rawdata)
        f.close()
        root = ET.fromstring(rawdata)
        for child in root:
            logging.info(child.tag)
            logging.info(child.attrib)
            for node1 in child:
                logging.info(node1.tag)
                logging.info(node1.attrib)

class CMD_RUN():
    #python 调用cmd命令行
    def __init__(self,execmd):
        self.exe=execmd

    def run(self):
        try:
            ret = subprocess.run(self.exe, capture_output=True, shell=True, text=True)
            if ret.returncode == 0:
                output = ret.stdout.strip()
            else:
                output = ret.stderr.strip()
        except Exception as e:
            output = str(e)
        return output

    def call(self):
        try:
            ret = subprocess.call(self.exe, shell=True)
        except Exception as e:
            ret = str(e)
        return ret

    def check_output(self):
        try:
            ret = subprocess.check_output(self.exe, shell=True)
        except Exception as e:
            ret = str(e)
        return ret

    def getoutput(self):
        try:
            ret = subprocess.getoutput(self.exe)
        except Exception as e:
            ret = str(e)
        return ret

    def Popen(self,item):
        p1 = subprocess.Popen(self.exe, shell=True, stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        p1.stdin.write(item.encode('utf-8') + b'\r\n')
        p1.stdin.flush()
        output = p1.stdout.readline()
        return output.decode('gbk')


class Excel_Read_File():
    def __init__(self, filename: str, sheetname: str):
        self.file = filename
        self.wb = openpyxl.load_workbook(filename, read_only=True, data_only=True)
        self.sheet = self.wb[sheetname]
        self.value_list = []
        for row in self.sheet.iter_rows():
            row_data = []
            for cell in row:
                value = cell.value
                row_data.append(value)
            self.value_list.append(row_data)

    def close(self) -> None:
        self.wb.close()

    def read_xlsx(self, ROW: int, COLUMN: int) -> str:
        # 获取某行某列的数据,ROW, COLUMN从1开始,value_list从0开始
        return self.value_list[ROW - 1][COLUMN - 1]

    def read_xlsx_row(self, ROW: int) -> list:
        # 获取某行数据,ROW从1开始,value_list从0开始
        return self.value_list[ROW - 1]


class Excel_Write_File():
    # xlwings的使用,电脑必须安装excel软件
    def __init__(self, filename: str, type: str = 'xlwings'):
        self.file = filename
        self.type = type
        if self.type == 'xlwings':
            self.app = xlwings.App(visible=False, add_book=False)  # 界面设置
            self.app.display_alerts = False  # 关闭提示信息
            self.app.screen_updating = False  # 关闭显示更新
            self.wb = self.app.books.open(filename)
        else:
            self.wb = openpyxl.load_workbook(filename, read_only=False)

    def close(self) -> None:
        if self.type == 'xlwings':
            self.wb.save()
            self.wb.close()
            self.app.kill()
        else:
            self.wb.save(self.file)
            self.wb.close()

    def add_sheet(self, sheetname: str) -> None:
        if self.type == 'xlwings':
            sheetnames = [j.name for j in self.wb.sheets]
            if sheetname not in sheetnames:
                self.wb.sheets.add(sheetname)
        else:
            if sheetname not in self.wb.sheetnames:
                self.wb.create_sheet(sheetname)

    def read_all_sheetname(self) -> list:
        if self.type == 'xlwings':
            sheet_list = [sheet.name for sheet in self.wb.sheets]
            return sheet_list
        else:
            return self.wb.sheetnames

    def write_xlsx_row(self, sheetname: str, row_num: int, row_data: list) -> None:
        if self.type == 'xlwings':
            sheet = self.wb.sheets[sheetname]  # 打开工作表
            for col, value in enumerate(row_data, start=1):
                sheet.range(row_num, col).value = value
            # position:2表示第二行
        else:
            sheet = self.wb[sheetname]
            for col, value in enumerate(row_data, start=1):
                sheet.cell(row=row_num, column=col, value=value)

    def write_xlsx(self, sheetname: str, position: str, data: str) -> None:
        # ROW起始行从1开始，COLUMN从A开始
        if data.strip()[0] in ['-', '+', '=']:
            data_send = "'" + data
        else:
            data_send = data
        if self.type == 'xlwings':
            sheet = self.wb.sheets[sheetname]  # 打开工作表
            if ',' not in position:
                sheet.range('{}'.format(position)).value = data_send
            else:
                COLUMN = int(position.split(",")[0])
                ROW = int(position.split(",")[1])
                sheet.range(COLUMN, ROW).value = data_send
        else:
            sheet = self.wb[sheetname]
            if ',' not in position:
                sheet[position] = data_send
            else:
                COLUMN = int(position.split(",")[0])
                ROW = int(position.split(",")[1])
                sheet.cell(row=ROW, column=COLUMN, value=data_send)



class File_Extract():
    # 解压文件
    def extract_file(self, filepath: str, filename: str, extract_path: str, type: str):
        # extract_path:解压后的文件存放位置
        # filepath:目标文件路径位置
        # filename:目标文件名字
        if not os.path.exists(extract_path):
            os.makedirs(extract_path)
        if type == 'zip':
            with zipfile.ZipFile("{}\\{}".format(filepath, filename), 'r') as zip_ref:
                zip_ref.extractall(extract_path)
        elif type == 'tar':
            with tarfile.open("{}\\{}".format(filepath, filename), 'r') as tar_ref:
                tar_ref.extractall(extract_path)
        elif type == 'tar.bz2':
            with tarfile.open("{}\\{}".format(filepath, filename), 'r:bz2') as tar_ref:
                tar_ref.extractall(extract_path)
        elif type == 'tar.gz':
            with tarfile.open("{}\\{}".format(filepath, filename), 'r:gz') as tar_ref:
                tar_ref.extractall(extract_path)
        elif type == 'gz':
            with gzip.open("{}\\{}".format(filepath, filename), 'rb') as f_in:
                decompressed_data = f_in.read()
            with open("{}\\{}".format(extract_path, filename.replace('.gz', '')), 'wb') as f_out:
                f_out.write(decompressed_data)
        else:
            logging.error('File Type Wrong')
            raise Exception

class Time_Format():
    def transfer1(self,stime:float):
        #1609459224----2021-01-01 08:00:24
        dtime = time.localtime(stime)
        return time.strftime("%Y-%m-%d %H:%M:%S", dtime)

    def tranfer2(self,file_data:str):
        #2025-04-19 16:18:37-----1745050627.0
        dt = datetime.datetime.strptime(file_data, '%Y-%m-%d %H:%M:%S')
        timestamp = time.mktime(dt.timetuple())
        return timestamp



class String_Handle:
    def __init__(self):
        pass

    def hex_to_ascii(self, h: str) -> str:  # 十六进制字符串转ASCII字符串
        list_s = []
        for i in range(0, len(h), 2):
            if h[i:i + 2] != '00':
                list_s.append(chr(int(h[i:i + 2], 16)))
            else:
                list_s.append(' ')
        list_final = [i.replace('\r', '\t') for i in list_s]
        return "".join(list_final)

    def tochecksum(self, h: str) -> int:
        sum = 0
        for i in range(0, len(h), 2):
            sum += int(h[i:i + 2], 16)
        return sum

    def tohex(self, h: str) -> str:
        list_h = []
        for c in h:
            list_h.append(str(hex(ord(c))[2:]))
        return " ".join(list_h)

    def to_bytes(self, h: str) -> list:
        list_byte = []
        for i in range(0, len(h), 2):
            list_byte.append(int(h[i:i + 2], 16))
        return list_byte

    def toyoufuhao(self, dec_data: int, width: int) -> int:  # 十六进制转有符号位十进制
        if dec_data > 2 ** (width - 1) - 1:
            dec_data = 2 ** width - dec_data
            dec_data = 0 - dec_data
        return dec_data

    def toyoufuhaoHex(self, dec_data: int, width: int) -> str:  # 有符号位转十六进制
        if dec_data < 0:
            data = 2 ** width + dec_data
        else:
            data = dec_data
        hex_data = hex(data)
        return hex_data

    def tohighbyte(self, h: int) -> int:
        data = (h > 8) & 0xff
        return data

    def tolowbyte(self, h: int) -> int:
        data = h & 0xff
        return data

    def ascii_to_hex(self, h: str) -> str:
        res = ''
        for i in range(len(h)):
            res += str(hex(ord(h[i])))[2:].zfill(2)
        return res

    def to_str(self, h: str) -> str:  # ascii字符串
        res = ''  # 必须没空格
        for i in range(int(len(h) / 2)):
            res += ''.join(chr(int(h[2 * i:2 * i + 2], 16)))
        return res

    def hex_to_float(self, h: str) -> float:  # 十六进制转换为32位浮点型
        b = h.replace(" ", "")  # 去除空格，测试用方便
        x = bin(eval('0x' + b))[2:]  # 直接不能转，加0x才认
        if (len(x) < 32):  # 简单的补0操作
            x = '0' * (32 - len(x)) + x
        else:
            x = x
        if int(x[0]) == 1:  # 符号位判断
            sign = -1
        else:
            sign = 1
        mi = 2 ** (int(x[1:9], 2) - 127)  # 幂指数
        xiao = 1
        for num, i in enumerate(x[9:]):  # 小数部分，是1的位做2的-n次方全部累加
            if i == '1':
                xiao = 2 ** (-(num + 1)) + xiao
        return sign * mi * xiao  # 32bit转float函数,32-bits
        # return struct.unpack('f', struct.pack('I', h))[0]#第二种方法

    def float_to_hex(self, h: str) -> str:  # 32位浮点型转换为十六进制
        return hex(struct.unpack('<I', struct.pack('<f', h))[0])  # h是浮点数

    def double_to_hex(self, h: str) -> str:  # 64位浮点型转换为十六进制
        return hex(struct.unpack('<Q', struct.pack('<d', h))[0])  # h是浮点数

    def hex_to_double(self, h: str) -> str:  # 十六进制转换为64位浮点型
        return struct.unpack('<d', struct.pack('<Q', h))[0]  # h是整数

    def big_small_end_convert(self, h: str) -> str:  # 小端转换为大端
        result = binascii.hexlify(binascii.unhexlify(h)[::-1])
        return result.decode('utf-8')
        # big_small_end_convert("c88300")----'0083c8'


class Calculate_Handle:
    def __init__(self):
        pass

    def mW_to_Dbm(self, power):  # power必须以mW为单位
        return 10 * math.log10(float(power))

    def Dbm_to_mW(self, power):  # power必须以dBm为单位
        return math.pow(10, float(power) / 10)



