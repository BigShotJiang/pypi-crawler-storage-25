# -*- coding: utf-8 -*-
import ctypes
MIMS_DEFINES = {
    'MSG_COMMAND_RUNTASK': 1,
    'MSG_COMMAND_RUNDEVICE': 2,
    'MSG_COMMAND_STOPRUN': 3,
    'MSG_COMMAND_DEBUGMODE': 4,
    'MSG_COMMAND_RUNDONE': 5,
    'MSG_COMMAND_RUNCOMMAND': 6,
    'MSG_COMMAND_RUNINIT': 7,
    'MSG_COMMAND_QUIT': 8,
 
    'MSG_MSG_BASEINFO': 11,
    'MSG_MSG_TASKINFO': 12,
    'MSG_MSG_OLDRATE': 13,
    'MSG_MSG_TASKDESCRIPTION': 14,
    'MSG_MSG_MSGBOX': 15,
    'MSG_MSG_LOG': 16,
    'MSG_MSG_COMMANDINFO': 17,
    'MSG_MSG_CONFIGPATH': 30,
    'MSG_MSG_TEMPLATE': 31,
    'MSG_MSG_TASKLIST':32,
    'MSG_MSG_UPLOADTESTDATA': 33,
    'MSG_MSG_CONVPN': 34,
    'MSG_MSG_CONVPROCESS': 35,
    'MSG_MSG_STATIONINFO': 36,
    'MSG_MSG_TESTRESULTOPC': 37,
    'MSG_MSG_MOVEIN': 38,
    'MSG_MSG_MOVEOUT': 39,
    'MSG_MSG_USERLOGINVERIFY': 40,
    'MSG_MSG_STATIONVERIFY': 41,
    'MSG_MSG_OPLINKUSERINFO': 42,
    'MSG_MSG_USERSKILLVERIFY': 43,
    'MSG_MSG_CREATESNDIR': 44, 
    'MSG_MSG_FWSTANDARDPATH': 45,
    'MSG_MSG_LOCATIONINFO': 46,
    'MSG_MSG_GENERICFUNC': 47,
    'MSG_TESTDATA_PROCESS': 21,
    'MSG_TESTDATA_PROGRESS': 22,
    'MSG_TESTDATA_GRAPHINIT': 23,
    'MSG_TESTDATA_GRAPHDATAHEAD': 24,
    'MSG_TESTDATA_PROGRESS': 22,
    ###########command###############
    'COMMAND_RUNINIT_USER_LEN': 20*8,
    'COMMAND_RUNINIT_SN_LEN': 10*2,
    'COMMAND_RUNINIT_PN_LEN': 128*2,

    'COMMAND_RUNTASK_INDEX_LEN': 10*2,
    'COMMAND_RUNTASK_USER_LEN': 20*2,
    'COMMAND_RUNTASK_TITLE_LEN': 128*2,

    'COMMAND_RUNCOMMAND_INDEX_LEN': 10*2,
    'COMMAND_RUNCOMMAND_USER_LEN': 20*2,
    'COMMAND_RUNCOMMAND_DATA_LEN': 2048*2,

    'COMMAND_RUNDONE_INDEX_LEN': 10*2,
    'COMMAND_RUNDONE_USER_LEN': 20*2,
    'COMMAND_RUNDONE_TITLE_LEN': 10*2,
    
    'COMMAND_RUNDEVICE_INDEX_LEN': 10*2,
    'COMMAND_RUNDEVICE_USER_LEN': 20*2,
    'COMMAND_RUNDEVICE_TITLE_LEN': 128*2,

    'COMMAND_STOPRUN_USER_LEN': 20*2,

    'COMMAND_DEBUGMODE_USER_LEN': 20*2,
    'COMMAND_DEBUGMODE_PASSWORD_LEN': 20*2,
    'COMMAND_DEBUGMODE_DEBUG_LEN': 128*2,
			
    'MSG_BASEINFO_OPERATE_LEN': 10*2,
    'MSG_BASEINFO_PROCESSTYPE_LEN': 20*2,
    'MSG_BASEINFO_AUTHOR_LEN': 20*2,
    'MSG_BASEINFO_VERSION_LEN': 15*2,
    'MSG_BASEINFO_SPEC_LEN': 15*2,
    'MSG_BASEINFO_PNNUMBER_LEN': 30*2,
    'MSG_BASEINFO_DATE_LEN': 30*2,
    'MSG_CONFIGPATH_DIR_LEN': 512*2,


    'MSG_BASEINFO_TESTSPEC_LEN': 10*2,
    'MSG_BASEINFO_TESTMODE_LEN': 10*2,
    'MSG_BASEINFO_WORKORDER_LEN': 30*2,
    'MSG_BASEINFO_INPROCESS_LEN': 10*2,
    'MSG_BASEINFO_INHOLD_LEN': 10*2,
    'MSG_BASEINFO_INREWORK_LEN': 10*2,
    'MSG_BASEINFO_PRODFAMILY_LEN': 20*2,
    'MSG_BASEINFO_ALIASNAME_LEN': 512*2,
    'MSG_BASEINFO_MTOPN_LEN': 30*2,
    'MSG_BASEINFO_OPLINKPN_LEN': 30*2,

     #task info
    'MSG_TASKINFO_OPERATE_LEN': 10*2,
    'MSG_TASKINFO_INDEX_LEN': 2048*200,
    'MSG_TASKINFO_TITLE_LEN': 2048*200,
    #command info
    'MSG_COMMANDINFO_OPERATE_LEN': 10*2,
    'MSG_COMMANDINFO_INDEX_LEN': 10*2,
    'MSG_COMMANDINFO_TITLE_LEN': 256*2,
    'MSG_COMMANDINFO_EXAMPLE_LEN': 2048*2,
    
    'MSG_COMMANDINFO_OPERATE_LEN': 10*2,
    'MSG_COMMANDINFO_INDEX_LEN': 10*2,
    'MSG_COMMANDINFO_TITLE_LEN': 256*2,
    'MSG_COMMANDINFO_EXAMPLE_LEN': 2048*2,
    
    #old rate
     'MSG_OLDRATE_OPERATE_LEN': 10*2,
     'MSG_OLDRATE_INDEX_LEN': 2048*2,
     'MSG_OLDRATE_RATE_LEN': 512*2,
     
    #task description
     'MSG_TASKDESCRIPTION_OPERATE_LEN': 10*2,
     'MSG_TASKDESCRIPTION_INDEX_LEN': 10*2,
     'MSG_TASKDESCRIPTION_DESCRIPTION_LEN': 2048*2,
    				
    #msg box
    'MSG_MSGBOX_OPERATE_LEN': 10*2,
    'MSG_MSGBOX_MSGID_LEN': 10*2,
    'MSG_MSGBOX_MSGTITLE_LEN': 128*2,
    'MSG_MSGBOX_DESCRIPTION_LEN': 256*2,
    'MSG_MSGBOX_BUTTONID_LEN': 128*2,
    'MSG_MSGBOX_BUTTONTITLE_LEN': 512*2,			

    #MSG CONVPN
    'MSG_CONVPN_ORIGINPN_LEN': 30*2,
    'MSG_CONVPN_CONVTYPE_LEN': 10*2,
    'MSG_CONVPN_RESULT_LEN': 10*2,
    'MSG_CONVPN_RESULTPN_LEN': 30*2,
    'MSG_CONVPN_NOTEMSG_LEN': 2048*2,					

    #MSG CONVPROCESS
    'MSG_CONVPROCESS_PRODPN_LEN': 30*2,	
    'MSG_CONVPROCESS_ORIGINPROCESS_LEN': 30*2,	
    'MSG_CONVPROCESS_CONVTYPE_LEN': 10*2,	
    'MSG_CONVPROCESS_RESULT_LEN': 10*2,	
    'MSG_CONVPROCESS_RESULTPROCESS_LEN': 30*2,	
    'MSG_CONVPROCESS_NOTEMSG_LEN': 2048*2,	
	
    # MSG station info
    'MSG_STATIONINFO_PCNAME_LEN': 30*2,	
    'MSG_STATIONINFO_RESULT_LEN': 10*2,	
    'MSG_STATIONINFO_STATIONID_LEN': 30*2,	
    'MSG_STATIONINFO_STATIONNAME_LEN':60*2,	
    'MSG_STATIONINFO_NOTEMSG_LEN': 2048*2,	
    				

    #MSG RESULT TO OPC
    'MSG_RESULTTOOPC_SN_LEN': 30*2,	
    'MSG_RESULTTOOPC_RESULT_LEN': 10*2,	
    'MSG_RESULTTOOPC_NOTEMSG_LEN': 2048*2,	


    #msg MOVE OUT
    'MSG_MOVEOUT_SN_LEN': 30*2,	
    'MSG_MOVEOUT_RESULT_LEN': 10*2,	
    'MSG_MOVEOUT_NOTEMSG_LEN': 2048*2,	
					
    #MSG MOVE IN
    'MSG_MOVEIN_SN_LEN': 30*2,	
    'MSG_MOVEIN_RESULT_LEN': 10*2,	
    'MSG_MOVEIN_NOTEMSG_LEN': 2048*2,	

    #MSG LOGIN VERIFY
    'MSG_LOGINVERIFY_USERNAME_LEN': 30*2,	
    'MSG_LOGINVERIFY_PASSWORD_LEN': 10*2,	
    'MSG_LOGINVERIFY_LOGINMODE_LEN': 10*2,	
    'MSG_LOGINVERIFY_RESULT_LEN': 10*2,	
    'MSG_LOGINVERIFY_NOTMSG_LEN': 2048*2,	

    #MSG STATION VERIFY
    'MSG_STATIONVERIFY_STATIONID_LEN': 30*2,	
    'MSG_STATIONVERIFY_USERID_LEN': 30*2,	
    'MSG_STATIONVERIFY_TYPE_LEN': 10*2,	
    'MSG_STATIONVERIFY_RESULT_LEN': 10*2,	
    'MSG_STATIONVERIFY_NOTMSG_LEN': 2048*2,	
    
    #OplinkUserInfo
    'MSG_OPLKUSERINFO_OPERATE_LEN': 10*2,	
    'MSG_OPLKUSERINFO_OPLINKID_LEN': 10*2,	
    'MSG_OPLKUSERINFO_USERMAME_LEN': 128*2,	
    'MSG_OPLKUSERINFO_DPTNAME_LEN': 256*2,	
    'MSG_OPLKUSERINFO_POSNAME_LEN': 128*2,	
    'MSG_OPLKUSERINFO_OPCID_LEN': 10*2,	
    'MSG_OPLKUSERINFO_RESULT_LEN': 10*2,	
    'MSG_OPLKUSERINFO_NOTEMSG_LEN': 2048*2,	

    #UserSkillVerify
    'MSG_USERSKILLVERIFY_OPERATE_LEN': 10*2,	
    'MSG_USERSKILLVERIFY_OPCID_LEN': 10*2,	
    'MSG_USERSKILLVERIFY_PROCESSTYPE_LEN': 30*2,	
    'MSG_USERSKILLVERIFY_RESULT_LEN': 10*2,	
    'MSG_USERSKILLVERIFY_NOTEMSG_LEN': 2048*2,	
    

    #CreateSNDir
    'MSG_CREATEDSNDIR_OPERATE_LEN': 10*2,	
    'MSG_CREATEDSNDIR_SN_LEN': 20*2,	
    'MSG_CREATEDSNDIR_ROOTDIR_LEN': 1024*2,	
    'MSG_CREATEDSNDIR_RESULT_LEN':10*2,	
    'MSG_CREATEDSNDIR_NOTEMSG_LEN': 2048*2,	


    # fwinfo
    'MSG_FWSTANDARDPATH_OPERATE_LEN': 10*2,	
    'MSG_FWSTANDARDPATH_DUTPN_LEN': 20*2,	
    'MSG_FWSTANDARDPATH_RESULT_LEN': 10*2,	
    'MSG_FWSTANDARDPATH_FWPN_LEN': 20*2,	
    'MSG_FWSTANDARDPATH_NOTEMSG_LEN': 2048*2,	
    

    #Location info
    'MSG_LOCATION_OPERATE_LEN': 10*2,	
    'MSG_LOCATION_LANGUAGE_LEN': 10*2,	
    'MSG_LOCATION_LOCATION_LEN': 10*2,	
    'MSG_LOCATION_FACTORY_LEN': 10*2,	
    'MSG_LOCATION_RESULT_LEN': 10*2,	
    'MSG_LOCATION_NOTEMSG_LEN': 2048*2,	

    #Generasl func
    'MSG_GENERIC_PAR_MAX': 10,	
    'MSG_GENERIC_FUNCNAME_LEN': 50*2,	
    'MSG_GENERIC_OPERATE_LEN': 10*2,	
    'MSG_GENERIC_INPUTCOUNT_LEN': 10*2,	
    'MSG_GENERIC_OUTPUTCOUNT_LEN': 10*2,	
    'MSG_GENERIC_OUTPUT_LEN': 512*2,	
    'MSG_GENERIC_INPUT_LEN': 512,	
    'MSG_GENERIC_RESULT_LEN': 10*2,	
    'MSG_GENERIC_NOTEMSG_LEN': 2048*2,	
    
    # ////log
    
    'MSG_LOG_OPERATE_LEN': 10*2,
    'MSG_LOG_LEVEL_LEN': 10*2,	
    'MSG_LOG_DESCRIPTION_LEN': 512*2,
    
    'TESTDATA_PROCESS_ID_LEN': 10*2,
    'TESTDATA_PROCESS_OPLINE_LEN': 128*2,
    'TESTDATA_PROCESS_DESCRIPTION_LEN': 128*2,
    'TESTDATA_PROCESS_RESULT_LEN': 10*2,
    'TESTDATA_PROCESS_THRESHOLD_LEN':128*2,
    'TESTDATA_PROCESS_PASSFAIL_LEN':10*2,
    'TESTDATA_PROCESS_DATE_LEN': 128*2,						

    # ////// progress
    'TESTDATA_PROGRESS_FULLSTEP_LEN': 10*2,	
    'TESTDATA_PROGRESS_STEP_LEN': 10*2,	
    'TESTDATA_PROGRESS_DATE_LEN': 128*2,	

    # ///// graphinit
    'TESTDATA_GRAPHINIT_TITLE_LEN': 128*2,
    'TESTDATA_GRAPHINIT_GRAPHINDEX_LEN': 10*2,
    'TESTDATA_GRAPHINIT_X_LEN': 128*2,
    'TESTDATA_GRAPHINIT_Y1_LEN': 128*2,
    'TESTDATA_GRAPHINIT_Y2_LEN': 128*2,

    # ///// GraphDataHead 
    'TESTDATA_GRAPHDATAHEAD_OPERATE_LEN': 20*2,
    'TESTDATA_GRAPHDATAHEAD_GRAPHINDEX_LEN': 10*2,
    'TESTDATA_GRAPHDATAHEAD_PLOTINDEX_LEN': 10*2,
    'TESTDATA_GRAPHDATAHEAD_PLOTTITLE_LEN': 128*2,
    'TESTDATA_GRAPHDATAHEAD_COLOR_LEN': 20*2,
    'TESTDATA_GRAPHDATAHEAD_YINDEX_LEN': 10*2,

}

# 定义联合类型
class MSG_StructUnion(ctypes.Union):
    
    class Command_RunInit(ctypes.Structure): 
        _fields_ = [
            ("szUser", ctypes.c_char*10*2),
            ("szSN", ctypes.c_char*20*8),
            ("szPN", ctypes.c_char*128*2)
        ]
    
    class Command_RunTask(ctypes.Structure):  
        _fields_ = [
            ("szIndex", ctypes.c_char*10*2),
            ("szUser", ctypes.c_char*20*2),
            ("szTitle", ctypes.c_char*128*2),
            ("szStepType", ctypes.c_char*10*2)
        ]
        
    class Command_RunCommand(ctypes.Structure):  
        _fields_ = [
            ("szIndex", ctypes.c_char*10*2),
            ("szUser", ctypes.c_char*20*2),
            ("szData", ctypes.c_char*2048*2)
        ]
        
    class Command_RunDone(ctypes.Structure):  
        _fields_ = [
            ("szIndex", ctypes.c_char * 20),
            ("szUser", ctypes.c_double),
            ("szResult", ctypes.c_char * 20)
        ]    
        
    class Command_RunDevice(ctypes.Structure):  
        _fields_ = [
            ("szIndex", ctypes.c_char*20),
            ("szUser", ctypes.c_char*20*2)，
            ("szTitle", ctypes.c_char*128*2)
        ]    
    class Command_StopRun(ctypes.Structure):  
        _fields_ = [
            ("szUser", ctypes.c_char * 20*2)
        ]    
    class Command_DebugMode(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("szUser", ctypes.c_char*20*2),
            ("szPassword", ctypes.c_char*20*2)
            ("szDebug", ctypes.c_char*128*2)
        ]        
    class Msg_BaseInfo(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("szOperate", ctypes.c_char * 20),
            ("szProcessType", ctypes.c_char*20*2)，
            ("szAuthor", ctypes.c_char * 20*2),
            ("szVersion", ctypes.c_char*15*2)，
            ("szSpec", ctypes.c_char * 15*2),
            ("szPnNumber", ctypes.c_char*30*2)，
            ("szDate", ctypes.c_char * 30*2),
            ("szIsTestSpec", ctypes.c_char*10*2)，
            ("szTestMode", ctypes.c_char * 10*2),
            ("szMFGOrder", ctypes.c_char*30*2)，
            ("szInProcess", ctypes.c_char * 10*2),
            ("szInHold", ctypes.c_char*10*2)，
            ("szInRework", ctypes.c_char*10*2),
            ("szProductFamily", ctypes.c_char*20*2)，
            ("szAliasName1", ctypes.c_char*512*2),
            ("szAliasName2", ctypes.c_char*512*2)，
            ("szAliasName3", ctypes.c_char*512*2),
            ("szMTOPN", ctypes.c_char*30*2)，
            ("szOplinkPN", ctypes.c_char*30*2)
        ] 
    class Msg_ConfigPath(ctypes.Structure):  
        _fields_ = [
            ("szOperate", ctypes.c_char * 20),
            ("szTestDataPath", ctypes.c_char*512*2)，
            ("szConfigPath", ctypes.c_char*512*2),
            ("szFWFilePath", ctypes.c_char*512*2)
        ]  
         
    class Msg_Template(ctypes.Structure):  
        _fields_ = [
            ("szOperate", ctypes.c_char * 20),
            ("szProdSN", ctypes.c_char*512*2)，
            ("szPorcess", ctypes.c_char*512*2),
            ("szSpec", ctypes.c_char*512*2)，
            ("szWO", ctypes.c_char*512*2)，
            ("szKeyData", ctypes.c_char*512*2)，
            ("szNoteMsg", ctypes.c_char*512*2)
        ]   
               
    class Msg_TaskInfo(ctypes.Structure):  
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]                 

    class Msg_OldRate(ctypes.Structure):  
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   
        
    class Msg_TaskDescription(ctypes.Structure):  
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]             

    class Msg_MsgBox(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   

    class Msg_Log(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
        
    class Msg_CommandInfo(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   
               
    class Msg_ConfigPath(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
        
    class Msg_Template(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
        
    class Msg_TaskList(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]         
        
    class Msg_UploadData(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   
        
    class Msg_ConvPN(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
                                             
    class Msg_ConvProcess(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]                                                       
    class Msg_StationInfo(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
    class Msg_ResultToOPC(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
    class Msg_MoveOut(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
  
    class Msg_MoveIn(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
    class Msg_LoginVerify(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
              
    class Msg_StationVerify(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]            

    class Msg_OplinkUserInfo(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
          
    class Msg_UserSkillVerify(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
                
    class Msg_CreateSNDir(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ] 
        
    class Msg_FWStandardPath(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]     
        
    class Msg_LocationInfo(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   
        
        
    class Msg_GenericFunc(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]                          
 
    class Msg_GenericFunc(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
        
    class TestData_Process(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   
               
    class TestDAta_Progress(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]                                                    
    class TestData_GraphInit(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]   

    class TestData_GraphDataHead(ctypes.Structure):  # 示例子结构体2
        _fields_ = [
            ("field3", ctypes.c_char * 20),
            ("field4", ctypes.c_double)
        ]  
                                                            
    # 联合的所有成员共享同一块内存
    _fields_ = [
        ("struct1", SubStruct1),  # 第一种可能的结构
        ("struct2", SubStruct2),  # 第二种可能的结构
        # 其他可能的结构...
    ]
