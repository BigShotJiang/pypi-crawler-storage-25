# -*- coding: utf-8 -*-
import os
import logging
import datetime
import sys
from logging.handlers import RotatingFileHandler

script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
parent_dir = os.path.dirname(script_dir)
sys.path.append(parent_dir)

from common.UICommand import UICommand
import threading
import common.TPUseXMLDataType
from common.TaskPro import TaskPro
from common.TPInfoManger import TPInfoManager
import time
from common.DataSrc import LOGLEVEL
import ctypes
from ctypes import Structure, c_char, c_int, c_bool, c_double,c_char_p,POINTER


lock = threading.Lock()  # 创建线程锁
class MainTestPro:
   
   def __init__(self):
        self.m_bSockState = False
        self.m_bStartPro = False
        self.m_strErr =""
        self.m_strUser =""
        self.m_iAct = 0
        self.m_stSockInfo = common.TPUseXMLDataType.ALL_MSG_DATA()
        self.m_uicommand = UICommand()
        self.m_hMsgEvent = threading.Event()
        self.m_hMainEvent = threading.Event()
        self.m_InfoManager = TPInfoManager(self.m_uicommand)
        self.m_TestTaskRuner = TaskPro(self.m_uicommand)
          
                    
   def EventPro(self):
         
        logging.info('Event process begin.....')  
       
        if self.m_iAct == common.TPUseXMLDataType.MSG_COMMAND_RUNTASK:
            logging.info('Event type:MSG_COMMAND_RUNTASK')  
            self.m_TestTaskRuner.RunTestTaskItem()
#        elif self.m_iAct == MIMS_DEFINES['MSG_COMMAND_RUNCOMMAND']:                
        elif self.m_iAct == common.TPUseXMLDataType.MSG_COMMAND_RUNINIT:  
            logging.info('Event type:MSG_COMMAND_RUNINIT')  
            self.m_TestTaskRuner.RunTestInit(self.m_strUser)
        elif self.m_iAct == common.TPUseXMLDataType.MSG_MSG_TASKINFO: 
            logging.info('Event type:MSG_MSG_TASKINFO')  
            self.m_InfoManager.SendTaskInfo()
#        elif self.m_iAct == MIMS_DEFINES['MSG_MSG_COMMANDINFO']:   
        elif self.m_iAct == common.TPUseXMLDataType.MSG_MSG_BASEINFO: 
            logging.info('Event type:MSG_MSG_BASEINFO') 
            self.m_InfoManager.SendTPDllInfo() 
        elif self.m_iAct == common.TPUseXMLDataType.MSG_MSG_TASKDESCRIPTION: 
            logging.info('Event type:MSG_MSG_TASKDESCRIPTION')  
            self.m_InfoManager.SendTPTaskDescription() 
        else:
            print("No command") 
            logging.info('Command Type TBD')  
                      
   def EventWorkThread(self):
        logging.info('Create EventWorkThread.....') 
        while self.m_bStartPro is True:
             self.m_hMsgEvent.wait() 
             t1 = threading.Thread(target=self.EventPro)  
             t1.start()
             self.m_hMsgEvent.clear()
             time.sleep(0.16)
                                     
   def MessagePro(self):
        try:   
            logging.info('Bgein to receive XML msg....') 
            res,self.m_stSockInfo = self.m_uicommand.XmlRecv()  
            self.m_InfoManager.m_pstSockInfo = self.m_stSockInfo  
            self.m_TestTaskRuner.m_pstSockInfo = self.m_stSockInfo
            logging.info('Receive XML msg ok') 
            
            print(self.m_stSockInfo.unDataStruct) 
            
            if self.m_stSockInfo is None:
                strerror =  self.m_uicommand.GeXmlMsgError()
                _msg = 'UICommand StartSocket Error:%s'%strerror
                logging.info(_msg)
                self.m_uicommand.XmlSendLog(_msg, len(_msg) + 1, LOGLEVEL.LOG_ERROR);
                raise 'UICommand StartSocket Error:%s'%strerror
            
            iAct = self.m_stSockInfo.nDataType
                  
            if iAct == common.TPUseXMLDataType.MSG_MSG_MSGBOX:
                logging.info('XML message type:MSG_MSG_MSGBOX') 
                dwTemp = int(self.m_stSockInfo.unDataStruct.MsgBox.szButtonId)
                print(dwTemp)
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)              
            elif iAct == common.TPUseXMLDataType.MSG_MSG_CONFIGPATH:
                logging.info('XML message type:MSG_MSG_CONFIGPATH') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))
            elif iAct == common.TPUseXMLDataType.MSG_MSG_TEMPLATE:
                logging.info('XML message type:MSG_MSG_TEMPLATE') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))
            elif iAct == common.TPUseXMLDataType.MSG_MSG_TASKLIST:
                logging.info('XML message type:MSG_MSG_TASKLIST') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))               
            elif iAct == common.TPUseXMLDataType.MSG_MSG_UPLOADTESTDATA:
                logging.info('XML message type:MSG_MSG_UPLOADTESTDATA') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))  
            elif iAct == common.TPUseXMLDataType.MSG_MSG_CONVPN:
                logging.info('XML message type:MSG_MSG_CONVPN') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))                      
            elif iAct == common.TPUseXMLDataType.MSG_MSG_CONVPROCESS:
                logging.info('XML message type:MSG_MSG_CONVPROCESS') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))      
            elif iAct == common.TPUseXMLDataType.MSG_MSG_STATIONINFO:
                logging.info('XML message type:MSG_MSG_STATIONINFO') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))        
            elif iAct == common.TPUseXMLDataType.MSG_MSG_TESTRESULTOPC:
                logging.info('XML message type:MSG_MSG_TESTRESULTOPC') 
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))  
            elif iAct == common.TPUseXMLDataType.MSG_MSG_MOVEIN:
                logging.info('XML message type:MSG_MSG_MOVEIN')
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))  
            elif iAct == common.TPUseXMLDataType.MSG_MSG_MOVEOUT:
                logging.info('XML message type:MSG_MSG_MOVEOUT')
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))                           
            elif iAct == common.TPUseXMLDataType.MSG_MSG_USERLOGINVERIFY:
                logging.info('XML message type:MSG_MSG_USERLOGINVERIFY')
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))   
            elif iAct == common.TPUseXMLDataType.MSG_MSG_STATIONVERIFY:
                logging.info('XML message type:MSG_MSG_STATIONVERIFY')
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo)) 
            elif iAct == common.TPUseXMLDataType.MSG_MSG_OPLINKUSERINFO:
                logging.info('XML message type:MSG_MSG_OPLINKUSERINFO')
                self.m_uicommand.XmlFeedback(ctypes.byref(self.m_stSockInfo))  
            elif iAct == common.TPUseXMLDataType.MSG_MSG_USERSKILLVERIFY:
                logging.info('XML message type:MSG_MSG_USERSKILLVERIFY')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)                     
            elif iAct == common.TPUseXMLDataType.MSG_MSG_CREATESNDIR:
                logging.info('XML message type:MSG_MSG_CREATESNDIR')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)   
            elif iAct == common.TPUseXMLDataType.MSG_MSG_LOCATIONINFO:
                logging.info('XML message type:MSG_MSG_LOCATIONINFO')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)                     
            elif iAct == common.TPUseXMLDataType.MSG_MSG_GENERICFUNC:
                logging.info('XML message type:MSG_MSG_GENERICFUNC')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)            
            elif iAct == common.TPUseXMLDataType.MSG_MSG_FWSTANDARDPATH:
                logging.info('XML message type:MSG_MSG_FWSTANDARDPATH')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)   
            elif iAct == common.TPUseXMLDataType.MSG_MSG_FWSTANDARDPATH:
                logging.info('XML message type:MSG_MSG_FWSTANDARDPATH')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo)  
            elif iAct == common.TPUseXMLDataType.MSG_MSG_FWSTANDARDPATH:
                logging.info('XML message type:MSG_MSG_FWSTANDARDPATH')
                self.m_uicommand.XmlFeedback(self.m_stSockInfo) 
            elif iAct == common.TPUseXMLDataType.MSG_COMMAND_STOPRUN:
                logging.info('XML message type:MSG_COMMAND_STOPRUN')
                self.m_uicommand.XmlStopTask()
            elif iAct == common.TPUseXMLDataType.MSG_COMMAND_QUIT:
                logging.info('XML message type:MSG_COMMAND_QUIT')
                self.m_uicommand.XmlStopTask() 
                self.m_bStartPro = False
            else:
                logging.info('XML message type:%s'%iAct)
                self.m_iAct = iAct
                self.m_hMsgEvent.set()
        except Exception as e:
           _msg = str(e)
           logging.info(_msg)
           self.m_uicommand.XmlSendLog(_msg, len(_msg) + 1, LOGLEVEL.LOG_ERROR)

                                 
   def MsgMonitorThread(self):
        logging.info('Create MsgMonitorThread.....') 
        while self.m_bStartPro is True:
            with lock:
              iAct =  self.m_uicommand.XmlAcqMsgCount()   
              print("iAct %s"%iAct)         
              if iAct > 0:
                 logging.info('Get message %s'%iAct)
                 self.MessagePro()
            time.sleep(0.16)
                                     
   def Run(self):
       try:   
          logging.info('Beginning run...')          
          res = self.m_uicommand.Initialize()
          if res is False:
              _strerror = self.m_uicommand.GeXmlMsgError()
              raise 'UICommand StartSocket Error:%s'%_strerror
          logging.info('Beginning successfully')  
          
          logging.info('Start Socket...')   
          res = self.m_uicommand.StartSocket()   
          if res is False:
              _strerror = self.m_uicommand.GeXmlMsgError()
              raise 'UICommand StartSocket Error:%s'%_strerror
          
          logging.info('Start Socket successfully')  
          
          self.m_bStartPro = True
          
          t2 = threading.Thread(target=self.MsgMonitorThread)  
          t2.start()    
          
          t1 = threading.Thread(target=self.EventWorkThread)  
          t1.start()
       
       except Exception as e: 
          self.m_strErr = str(e)
          logging.info(self.m_strErr)  
        #   print(e) 
          return False
       return True
    
   def InitLog(self):
        full_path = os.path.abspath('Log')
        if not os.path.exists(full_path):
            os.mkdir(full_path)
        dir_name  = os.path.abspath(full_path)
        log_file  = '%s\\log_%s.txt' % (dir_name, datetime.datetime.now().strftime("%Y%m%d"))
        
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(log_file, mode='a', maxBytes=200000000, backupCount=24, encoding='utf-8', delay=0)
        handler.setLevel(logging.INFO)   
        
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        formatter = logging.Formatter('%(asctime)s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(handler)
        logger.addHandler(console_handler)       
          
if __name__ =="__main__":
        
    g_tp = MainTestPro()
    g_tp.Run()       