import ctypes
from ctypes import Union
MSG_COMMAND_RUNTASK = 1
MSG_COMMAND_RUNDEVICE = 2
MSG_COMMAND_STOPRUN = 3
MSG_COMMAND_DEBUGMODE = 4
MSG_COMMAND_RUNDONE = 5
MSG_COMMAND_RUNCOMMAND = 6
MSG_COMMAND_RUNINIT = 7
MSG_COMMAND_QUIT = 8

MSG_MSG_BASEINFO = 11
MSG_MSG_TASKINFO = 12
MSG_MSG_OLDRATE = 13
MSG_MSG_TASKDESCRIPTION = 14
MSG_MSG_MSGBOX = 15
MSG_MSG_LOG = 16
MSG_MSG_COMMANDINFO = 17
MSG_MSG_CONFIGPATH = 30
MSG_MSG_TEMPLATE = 31
MSG_MSG_TASKLIST = 32
MSG_MSG_UPLOADTESTDATA = 33

MSG_MSG_CONVPN = 34
MSG_MSG_CONVPROCESS = 35
MSG_MSG_STATIONINFO = 36
MSG_MSG_TESTRESULTOPC = 37
MSG_MSG_MOVEIN = 38
MSG_MSG_MOVEOUT = 39
MSG_MSG_USERLOGINVERIFY = 40
MSG_MSG_STATIONVERIFY = 41

MSG_MSG_OPLINKUSERINFO = 42
MSG_MSG_USERSKILLVERIFY = 43
MSG_MSG_CREATESNDIR = 44
MSG_MSG_FWSTANDARDPATH = 45

MSG_MSG_LOCATIONINFO = 46
MSG_MSG_GENERICFUNC = 47

MSG_TESTDATA_PROCESS = 21
MSG_TESTDATA_PROGRESS = 22
MSG_TESTDATA_GRAPHINIT = 23
MSG_TESTDATA_GRAPHDATAHEAD = 24

COMMAND_RUNINIT_USER_LEN = 10 * 2
COMMAND_RUNINIT_SN_LEN = 20 * 8
COMMAND_RUNINIT_PN_LEN = 128 * 2

COMMAND_RUNTASK_INDEX_LEN = 10 * 2
COMMAND_RUNTASK_USER_LEN = 20 * 2
COMMAND_RUNTASK_TITLE_LEN = 128 * 2

COMMAND_RUNCOMMAND_INDEX_LEN = 10 * 2
COMMAND_RUNCOMMAND_USER_LEN = 20 * 2
COMMAND_RUNCOMMAND_DATA_LEN = 2048 * 2

COMMAND_RUNDONE_INDEX_LEN = 10 * 2
COMMAND_RUNDONE_USER_LEN = 20 * 2
COMMAND_RUNDONE_TITLE_LEN = 10 * 2

COMMAND_RUNDEVICE_INDEX_LEN = 10 * 2
COMMAND_RUNDEVICE_USER_LEN = 20 * 2
COMMAND_RUNDEVICE_TITLE_LEN = 128 * 2

COMMAND_STOPRUN_USER_LEN = 20 * 2

COMMAND_DEBUGMODE_USER_LEN = 20 * 2
COMMAND_DEBUGMODE_PASSWORD_LEN = 20 * 2
COMMAND_DEBUGMODE_DEBUG_LEN = 128 * 2

MSG_BASEINFO_OPERATE_LEN = 10 * 2
MSG_BASEINFO_PROCESSTYPE_LEN = 100 * 2
MSG_BASEINFO_AUTHOR_LEN = 20 * 2
MSG_BASEINFO_VERSION_LEN = 15 * 2
MSG_BASEINFO_SPEC_LEN = 15 * 2
MSG_BASEINFO_PNNUMBER_LEN = 30 * 2
MSG_BASEINFO_DATE_LEN = 30 * 2
MSG_CONFIGPATH_DIR_LEN = 512 * 2

MSG_BASEINFO_TESTSPEC_LEN = 10 * 2
MSG_BASEINFO_TESTMODE_LEN = 10 * 2
MSG_BASEINFO_WORKORDER_LEN = 30 * 2
MSG_BASEINFO_INPROCESS_LEN = 10 * 2
MSG_BASEINFO_INHOLD_LEN = 10 * 2
MSG_BASEINFO_INREWORK_LEN = 10 * 2
MSG_BASEINFO_PRODFAMILY_LEN = 20 * 2
MSG_BASEINFO_ALIASNAME_LEN = 512 * 2
MSG_BASEINFO_MTOPN_LEN = 30 * 2
MSG_BASEINFO_OPLINKPN_LEN = 30 * 2

MSG_TASKINFO_OPERATE_LEN = 10 * 2
MSG_TASKINFO_INDEX_LEN = 2048 * 200
MSG_TASKINFO_TITLE_LEN = 2048 * 200

MSG_COMMANDINFO_OPERATE_LEN = 10 * 2
MSG_COMMANDINFO_INDEX_LEN = 10 * 2
MSG_COMMANDINFO_TITLE_LEN = 256 * 2
MSG_COMMANDINFO_EXAMPLE_LEN = 2048 * 2

MSG_OLDRATE_OPERATE_LEN = 10 * 2
MSG_OLDRATE_INDEX_LEN = 2048 * 2
MSG_OLDRATE_RATE_LEN = 512 * 2

MSG_TASKDESCRIPTION_OPERATE_LEN = 10 * 2
MSG_TASKDESCRIPTION_INDEX_LEN = 10 * 2
MSG_TASKDESCRIPTION_DESCRIPTION_LEN = 2048 * 2

MSG_MSGBOX_OPERATE_LEN = 10 * 2
MSG_MSGBOX_MSGID_LEN = 10 * 2
MSG_MSGBOX_MSGTITLE_LEN = 128 * 2
MSG_MSGBOX_DESCRIPTION_LEN = 256 * 2
MSG_MSGBOX_BUTTONID_LEN = 128 * 2
MSG_MSGBOX_BUTTONTITLE_LEN = 512 * 2

MSG_CONVPN_ORIGINPN_LEN = 30 * 2
MSG_CONVPN_CONVTYPE_LEN = 10 * 2
MSG_CONVPN_RESULT_LEN = 10 * 2
MSG_CONVPN_RESULTPN_LEN = 30 * 2
MSG_CONVPN_NOTEMSG_LEN = 2048 * 2

MSG_CONVPROCESS_PRODPN_LEN = 30 * 2
MSG_CONVPROCESS_ORIGINPROCESS_LEN = 30 * 2
MSG_CONVPROCESS_CONVTYPE_LEN = 10 * 2
MSG_CONVPROCESS_RESULT_LEN = 10 * 2
MSG_CONVPROCESS_RESULTPROCESS_LEN = 30 * 2
MSG_CONVPROCESS_NOTEMSG_LEN = 2048 * 2

MSG_STATIONINFO_PCNAME_LEN = 30 * 2
MSG_STATIONINFO_RESULT_LEN = 10 * 2
MSG_STATIONINFO_STATIONID_LEN = 30 * 2
MSG_STATIONINFO_STATIONNAME_LEN = 60 * 2
MSG_STATIONINFO_NOTEMSG_LEN = 2048 * 2

MSG_RESULTTOOPC_SN_LEN = 30 * 2
MSG_RESULTTOOPC_RESULT_LEN = 10 * 2
MSG_RESULTTOOPC_NOTEMSG_LEN = 2048 * 2

MSG_MOVEOUT_SN_LEN = 30 * 2
MSG_MOVEOUT_RESULT_LEN = 10 * 2
MSG_MOVEOUT_NOTEMSG_LEN = 2048 * 2

MSG_MOVEIN_SN_LEN = 30 * 2
MSG_MOVEIN_RESULT_LEN = 10 * 2
MSG_MOVEIN_NOTEMSG_LEN = 2048 * 2

MSG_LOGINVERIFY_USERNAME_LEN = 30 * 2
MSG_LOGINVERIFY_PASSWORD_LEN = 10 * 2
MSG_LOGINVERIFY_LOGINMODE_LEN = 10 * 2
MSG_LOGINVERIFY_RESULT_LEN = 10 * 2
MSG_LOGINVERIFY_NOTMSG_LEN = 2048 * 2

MSG_STATIONVERIFY_STATIONID_LEN = 30 * 2
MSG_STATIONVERIFY_USERID_LEN = 30 * 2
MSG_STATIONVERIFY_TYPE_LEN = 10 * 2
MSG_STATIONVERIFY_RESULT_LEN = 10 * 2
MSG_STATIONVERIFY_NOTMSG_LEN = 2048 * 2

MSG_OPLKUSERINFO_OPERATE_LEN = 10 * 2
MSG_OPLKUSERINFO_OPLINKID_LEN = 10 * 2
MSG_OPLKUSERINFO_USERMAME_LEN = 128 * 2
MSG_OPLKUSERINFO_DPTNAME_LEN = 256 * 2
MSG_OPLKUSERINFO_POSNAME_LEN = 128 * 2
MSG_OPLKUSERINFO_OPCID_LEN = 10 * 2
MSG_OPLKUSERINFO_RESULT_LEN = 10 * 2
MSG_OPLKUSERINFO_NOTEMSG_LEN = 2048 * 2

MSG_USERSKILLVERIFY_OPERATE_LEN = 10 * 2
MSG_USERSKILLVERIFY_OPCID_LEN = 10 * 2
MSG_USERSKILLVERIFY_PROCESSTYPE_LEN = 30 * 2
MSG_USERSKILLVERIFY_RESULT_LEN = 10 * 2
MSG_USERSKILLVERIFY_NOTEMSG_LEN = 2048 * 2

MSG_CREATEDSNDIR_OPERATE_LEN = 10 * 2
MSG_CREATEDSNDIR_SN_LEN = 20 * 2
MSG_CREATEDSNDIR_ROOTDIR_LEN = 1024 * 2
MSG_CREATEDSNDIR_RESULT_LEN = 10 * 2
MSG_CREATEDSNDIR_NOTEMSG_LEN = 2048 * 2

MSG_FWSTANDARDPATH_OPERATE_LEN = 10 * 2
MSG_FWSTANDARDPATH_DUTPN_LEN = 20 * 2
MSG_FWSTANDARDPATH_RESULT_LEN = 10 * 2
MSG_FWSTANDARDPATH_FWPN_LEN = 20 * 2
MSG_FWSTANDARDPATH_NOTEMSG_LEN = 2048 * 2

MSG_LOCATION_OPERATE_LEN = 10 * 2
MSG_LOCATION_LANGUAGE_LEN = 10 * 2
MSG_LOCATION_LOCATION_LEN = 10 * 2
MSG_LOCATION_FACTORY_LEN = 10 * 2
MSG_LOCATION_RESULT_LEN = 10 * 2
MSG_LOCATION_NOTEMSG_LEN = 2048 * 2

MSG_GENERIC_PAR_MAX = 10
MSG_GENERIC_FUNCNAME_LEN = 50 * 2
MSG_GENERIC_OPERATE_LEN = 10 * 2
MSG_GENERIC_INPUTCOUNT_LEN = 10 * 2
MSG_GENERIC_OUTPUTCOUNT_LEN = 10 * 2
MSG_GENERIC_OUTPUT_LEN = 512 * 2
MSG_GENERIC_INPUT_LEN = 512
MSG_GENERIC_RESULT_LEN = 10 * 2
MSG_GENERIC_NOTEMSG_LEN = 2048 * 2

MSG_LOG_OPERATE_LEN=10 * 2
MSG_LOG_LEVEL_LEN=10 * 2
MSG_LOG_DESCRIPTION_LEN=512 * 2

TESTDATA_PROCESS_ID_LEN=10 * 2
TESTDATA_PROCESS_OPLINE_LEN=128 * 2
TESTDATA_PROCESS_DESCRIPTION_LEN=128 * 2
TESTDATA_PROCESS_RESULT_LEN=10 * 2
TESTDATA_PROCESS_THRESHOLD_LEN=128 * 2
TESTDATA_PROCESS_PASSFAIL_LEN=10 * 2
TESTDATA_PROCESS_DATE_LEN=128 * 2

TESTDATA_PROGRESS_FULLSTEP_LEN=10 * 2
TESTDATA_PROGRESS_STEP_LEN=10 * 2
TESTDATA_PROGRESS_DATE_LEN=128 * 2

TESTDATA_GRAPHINIT_TITLE_LEN=128 * 2
TESTDATA_GRAPHINIT_GRAPHINDEX_LEN=10 * 2
TESTDATA_GRAPHINIT_X_LEN=128 * 2
TESTDATA_GRAPHINIT_Y1_LEN=128 * 2
TESTDATA_GRAPHINIT_Y2_LEN=128 * 2

TESTDATA_GRAPHDATAHEAD_OPERATE_LEN=20 * 2
TESTDATA_GRAPHDATAHEAD_GRAPHINDEX_LEN=10 * 2
TESTDATA_GRAPHDATAHEAD_PLOTINDEX_LEN=10 * 2
TESTDATA_GRAPHDATAHEAD_PLOTTITLE_LEN=128 * 2
TESTDATA_GRAPHDATAHEAD_COLOR_LEN=20 * 2
TESTDATA_GRAPHDATAHEAD_YINDEX_LEN=10 * 2


class Command_RunInit(ctypes.Structure):
    _fields_ = [
        ("szUser", ctypes.c_char*COMMAND_RUNINIT_USER_LEN),
        ("szSN", ctypes.c_char * COMMAND_RUNINIT_SN_LEN),
        ("szPN", ctypes.c_char*COMMAND_RUNINIT_PN_LEN)
    ]

class Command_RunTask(ctypes.Structure):
    _fields_ = [
        ("szIndex", ctypes.c_char*COMMAND_RUNTASK_INDEX_LEN),
        ("szUser", ctypes.c_char * COMMAND_RUNTASK_USER_LEN),
        ("szTitle", ctypes.c_char*COMMAND_RUNTASK_TITLE_LEN),
        ("szStepType", ctypes.c_char * COMMAND_RUNTASK_INDEX_LEN)
    ]

class Command_RunCommand(ctypes.Structure):
    _fields_ = [
        ("szIndex", ctypes.c_char*COMMAND_RUNCOMMAND_INDEX_LEN),
        ("szUser", ctypes.c_char * COMMAND_RUNCOMMAND_USER_LEN),
        ("szData", ctypes.c_char*COMMAND_RUNCOMMAND_DATA_LEN)
    ]
class Command_RunDone(ctypes.Structure):
    _fields_ = [
        ("szIndex", ctypes.c_char*COMMAND_RUNDONE_INDEX_LEN),
        ("szUser", ctypes.c_char * COMMAND_RUNDONE_USER_LEN),
        ("szResult", ctypes.c_char*COMMAND_RUNDONE_TITLE_LEN)
    ]
class Command_RunDevice(ctypes.Structure):
    _fields_ = [
        ("szIndex", ctypes.c_char*COMMAND_RUNDEVICE_INDEX_LEN),
        ("szUser", ctypes.c_char * COMMAND_RUNDEVICE_USER_LEN),
        ("szTitle", ctypes.c_char*COMMAND_RUNDEVICE_TITLE_LEN)
    ]

class Command_StopRun(ctypes.Structure):
    _fields_ = [
        ("szUser", ctypes.c_char * COMMAND_STOPRUN_USER_LEN),
    ]

class Command_DebugMode(ctypes.Structure):
    _fields_ = [
        ("szUser", ctypes.c_char*COMMAND_DEBUGMODE_USER_LEN),
        ("szPassword", ctypes.c_char * COMMAND_DEBUGMODE_PASSWORD_LEN),
        ("szDebug", ctypes.c_char*COMMAND_DEBUGMODE_DEBUG_LEN)
    ]


# ////基础信息
class Msg_BaseInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_BASEINFO_OPERATE_LEN),
        ("szProcessType", ctypes.c_char * MSG_BASEINFO_PROCESSTYPE_LEN),
        ("szAuthor", ctypes.c_char*MSG_BASEINFO_AUTHOR_LEN),
        ("szVersion", ctypes.c_char * MSG_BASEINFO_VERSION_LEN),
        ("szSpec", ctypes.c_char * MSG_BASEINFO_SPEC_LEN),

        ("szPnNumber", ctypes.c_char * MSG_BASEINFO_PNNUMBER_LEN),
        ("szDate", ctypes.c_char * MSG_BASEINFO_DATE_LEN),
        ("szIsTestSpec", ctypes.c_char * MSG_BASEINFO_TESTSPEC_LEN),
        ("szTestMode", ctypes.c_char * MSG_BASEINFO_TESTMODE_LEN),
        ("szMFGOrder", ctypes.c_char * MSG_BASEINFO_WORKORDER_LEN),
        ("szInProcess", ctypes.c_char * MSG_BASEINFO_INPROCESS_LEN),
        ("szInHold", ctypes.c_char * MSG_BASEINFO_INHOLD_LEN),
        ("szInRework", ctypes.c_char * MSG_BASEINFO_INREWORK_LEN),
        ("szProductFamily", ctypes.c_char * MSG_BASEINFO_PRODFAMILY_LEN),
        ("szAliasName1", ctypes.c_char * MSG_BASEINFO_ALIASNAME_LEN),
        ("szAliasName2", ctypes.c_char * MSG_BASEINFO_ALIASNAME_LEN),
        ("szAliasName3", ctypes.c_char * MSG_BASEINFO_ALIASNAME_LEN),
        ("szMTOPN", ctypes.c_char * MSG_BASEINFO_MTOPN_LEN),
        ("szOplinkPN", ctypes.c_char * MSG_BASEINFO_OPLINKPN_LEN),
    ]

class Msg_ConfigPath(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szTestDataPath", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
        ("szConfigPath", ctypes.c_char*MSG_CONFIGPATH_DIR_LEN),
        ("szFWFilePath", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
    ]

# //获取测试模板
class Msg_Template(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szProdSN", ctypes.c_char * COMMAND_RUNINIT_SN_LEN),
        ("szPorcess", ctypes.c_char*MSG_BASEINFO_PROCESSTYPE_LEN),
        ("szSpec", ctypes.c_char * MSG_BASEINFO_SPEC_LEN),
        ("szWO", ctypes.c_char * MSG_BASEINFO_SPEC_LEN),
        ("szKeyData", ctypes.c_char * MSG_MSGBOX_MSGID_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
    ]


# // 工单表头
class Msg_TaskList(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szProdSN", ctypes.c_char * COMMAND_RUNINIT_SN_LEN),
        ("szGroup", ctypes.c_char*COMMAND_RUNINIT_SN_LEN),
        ("szPosition", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
        ("szResult", ctypes.c_char * MSG_MSGBOX_MSGID_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
        ("szSubSN", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
    ]

# // 上传数据
class Msg_UploadData(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szProdSN", ctypes.c_char * COMMAND_RUNINIT_SN_LEN),
        ("szFileName", ctypes.c_char*MSG_CONFIGPATH_DIR_LEN),
        ("szResult", ctypes.c_char * MSG_MSGBOX_MSGID_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_CONFIGPATH_DIR_LEN),
    ]

class Msg_ConvPN(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szOriginPN", ctypes.c_char * MSG_CONVPN_ORIGINPN_LEN),
        ("szConvTyoe", ctypes.c_char*MSG_CONVPN_CONVTYPE_LEN),
        ("szResult", ctypes.c_char * MSG_CONVPN_RESULT_LEN),
        ("szResultPN", ctypes.c_char * MSG_CONVPN_RESULTPN_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_CONVPN_NOTEMSG_LEN),
    ]

class Msg_ConvProcess(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szOriginPN", ctypes.c_char * MSG_CONVPROCESS_PRODPN_LEN),
        ("szOriginProcess", ctypes.c_char*MSG_CONVPROCESS_ORIGINPROCESS_LEN),
        ("szConvTyoe", ctypes.c_char * MSG_CONVPROCESS_CONVTYPE_LEN),
        ("szResult", ctypes.c_char * MSG_CONVPROCESS_RESULT_LEN),
        ("szReslutProcess", ctypes.c_char * MSG_CONVPROCESS_RESULTPROCESS_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_CONVPROCESS_NOTEMSG_LEN),
    ]
class Msg_StationInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szPCName", ctypes.c_char * MSG_STATIONINFO_PCNAME_LEN),
        ("szResult", ctypes.c_char*MSG_STATIONINFO_RESULT_LEN),
        ("szStationID", ctypes.c_char *MSG_STATIONINFO_STATIONID_LEN ),
        ("szStationName", ctypes.c_char * MSG_STATIONINFO_STATIONNAME_LEN),
        ("szNoteMsg", ctypes.c_char *MSG_STATIONINFO_NOTEMSG_LEN ),
    ]

class Msg_ResultToOPC(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szSN", ctypes.c_char * MSG_RESULTTOOPC_SN_LEN),
        ("szResult", ctypes.c_char*MSG_RESULTTOOPC_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char *MSG_RESULTTOOPC_NOTEMSG_LEN ),
    ]

class Msg_MoveOut(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szSN", ctypes.c_char * MSG_MOVEOUT_SN_LEN),
        ("szResult", ctypes.c_char*MSG_MOVEOUT_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char *MSG_MOVEOUT_NOTEMSG_LEN ),
    ]
class Msg_MoveIn(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szSN", ctypes.c_char * MSG_MOVEIN_SN_LEN),
        ("szResult", ctypes.c_char*MSG_MOVEIN_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char *MSG_MOVEIN_NOTEMSG_LEN ),
    ]

class Msg_LoginVerify(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szUserName", ctypes.c_char * MSG_LOGINVERIFY_USERNAME_LEN),
        ("szPassWord", ctypes.c_char*MSG_LOGINVERIFY_PASSWORD_LEN),
        ("szLoginMode", ctypes.c_char *MSG_LOGINVERIFY_LOGINMODE_LEN ),
        ("szResult", ctypes.c_char * MSG_LOGINVERIFY_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_LOGINVERIFY_NOTMSG_LEN),
    ]

class Msg_StationVerify(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szStationID", ctypes.c_char * MSG_STATIONVERIFY_STATIONID_LEN),
        ("szUserID", ctypes.c_char*MSG_STATIONVERIFY_USERID_LEN),
        ("szType", ctypes.c_char *MSG_STATIONVERIFY_TYPE_LEN ),
        ("szResult", ctypes.c_char * MSG_STATIONVERIFY_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_STATIONVERIFY_NOTMSG_LEN),
    ]

class Msg_OplinkUserInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_OPLKUSERINFO_OPERATE_LEN),
        ("szOplinkID", ctypes.c_char * MSG_OPLKUSERINFO_OPLINKID_LEN),
        ("szUserName", ctypes.c_char*MSG_OPLKUSERINFO_USERMAME_LEN),
        ("szDptName", ctypes.c_char *MSG_OPLKUSERINFO_DPTNAME_LEN ),
        ("szPosName", ctypes.c_char * MSG_OPLKUSERINFO_POSNAME_LEN),
        ("szOPCID", ctypes.c_char * MSG_OPLKUSERINFO_OPCID_LEN),
        ("szResult", ctypes.c_char * MSG_OPLKUSERINFO_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_OPLKUSERINFO_NOTEMSG_LEN),
    ]

class Msg_UserSkillVerify(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_USERSKILLVERIFY_OPERATE_LEN),
        ("szOPCID", ctypes.c_char * MSG_USERSKILLVERIFY_OPCID_LEN),
        ("szProcessType", ctypes.c_char*MSG_USERSKILLVERIFY_PROCESSTYPE_LEN),
        ("szResult", ctypes.c_char *MSG_USERSKILLVERIFY_RESULT_LEN ),
        ("szNoteMsg", ctypes.c_char * MSG_USERSKILLVERIFY_NOTEMSG_LEN),
    ]

class Msg_CreateSNDir(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_CREATEDSNDIR_OPERATE_LEN),
        ("szSN", ctypes.c_char * MSG_CREATEDSNDIR_SN_LEN),
        ("szRootDir", ctypes.c_char*MSG_CREATEDSNDIR_ROOTDIR_LEN),
        ("szResult", ctypes.c_char *MSG_CREATEDSNDIR_RESULT_LEN ),
        ("szNoteMsg", ctypes.c_char * MSG_CREATEDSNDIR_NOTEMSG_LEN),
    ]

class Msg_FWStandardPath(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_FWSTANDARDPATH_OPERATE_LEN),
        ("szDUTMTSPN", ctypes.c_char * MSG_FWSTANDARDPATH_DUTPN_LEN),
        ("szResult", ctypes.c_char*MSG_FWSTANDARDPATH_RESULT_LEN),
        ("szFWPN", ctypes.c_char *MSG_FWSTANDARDPATH_FWPN_LEN ),
        ("szNoteMsg", ctypes.c_char * MSG_FWSTANDARDPATH_NOTEMSG_LEN),
    ]

class Msg_LocationInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_LOCATION_OPERATE_LEN),
        ("szLanguage", ctypes.c_char * MSG_LOCATION_LANGUAGE_LEN),
        ("szLocation", ctypes.c_char*MSG_LOCATION_LOCATION_LEN),
        ("szFactory", ctypes.c_char *MSG_LOCATION_FACTORY_LEN ),
        ("szResult", ctypes.c_char * MSG_LOCATION_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_LOCATION_NOTEMSG_LEN),
    ]

class Msg_GenericFunc(ctypes.Structure):
    _fields_ = [
        ("szFuncName", ctypes.c_char*MSG_GENERIC_FUNCNAME_LEN),
        ("szOperate", ctypes.c_char * MSG_GENERIC_OPERATE_LEN),
        ("szInputCount", ctypes.c_char*MSG_GENERIC_INPUTCOUNT_LEN),
        ("szOutputCount", ctypes.c_char *MSG_GENERIC_OUTPUTCOUNT_LEN ),
        ("szInput",(ctypes.c_char * MSG_GENERIC_INPUT_LEN) * MSG_GENERIC_PAR_MAX),
        ("szOutput", (ctypes.c_char * MSG_GENERIC_OUTPUT_LEN) * MSG_GENERIC_PAR_MAX),
        ("szResult", ctypes.c_char * MSG_GENERIC_RESULT_LEN),
        ("szNoteMsg", ctypes.c_char * MSG_GENERIC_NOTEMSG_LEN),
    ]
#//// 任务信息
class Msg_TaskInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKINFO_OPERATE_LEN),
        ("szIndex", ctypes.c_char * MSG_TASKINFO_INDEX_LEN),
        ("szTitle", ctypes.c_char*MSG_TASKINFO_TITLE_LEN),
        ("szStepType", ctypes.c_char *MSG_TASKINFO_OPERATE_LEN ),
    ]



#//// 命令信息
class Msg_CommandInfo(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_COMMANDINFO_OPERATE_LEN),
        ("szIndex", ctypes.c_char * MSG_COMMANDINFO_INDEX_LEN),
        ("szTitle", ctypes.c_char*MSG_COMMANDINFO_TITLE_LEN),
        ("szExample", ctypes.c_char *MSG_COMMANDINFO_EXAMPLE_LEN ),
    ]


#//// 上次测试进度
class Msg_OldRate(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_OLDRATE_OPERATE_LEN),
        ("szIndex", ctypes.c_char * MSG_OLDRATE_INDEX_LEN),
        ("szRate", ctypes.c_char*MSG_OLDRATE_RATE_LEN),
    ]


#////任务描述，用于描述显示，该结构只包含一个任务的描述信息
class Msg_TaskDescription(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_TASKDESCRIPTION_OPERATE_LEN),
        ("szIndex", ctypes.c_char * MSG_TASKDESCRIPTION_INDEX_LEN),
        ("szDescription", ctypes.c_char*MSG_TASKDESCRIPTION_DESCRIPTION_LEN),
    ]


#//// 消息提示框
class Msg_MsgBox(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_MSGBOX_OPERATE_LEN),
        ("szMsgId", ctypes.c_char * MSG_MSGBOX_MSGID_LEN),
        ("szMsgTitle", ctypes.c_char*MSG_MSGBOX_MSGTITLE_LEN),
        ("szDescription", ctypes.c_char * MSG_MSGBOX_DESCRIPTION_LEN),
        ("szButtonId", ctypes.c_char * MSG_MSGBOX_BUTTONID_LEN),
        ("szButtonTitle", ctypes.c_char * MSG_MSGBOX_BUTTONTITLE_LEN),
    ]



#//// 日志信息
class Msg_Log(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*MSG_LOG_OPERATE_LEN),
        ("szLevel", ctypes.c_char * MSG_LOG_LEVEL_LEN),
        ("szDescription", ctypes.c_char*MSG_LOG_DESCRIPTION_LEN),
    ]



#// 测试过程数据
class TestData_Process(ctypes.Structure):
    _fields_ = [
        ("szId", ctypes.c_char*TESTDATA_PROCESS_ID_LEN),
        ("szOpLine", ctypes.c_char * TESTDATA_PROCESS_OPLINE_LEN),
        ("szDescription", ctypes.c_char*TESTDATA_PROCESS_DESCRIPTION_LEN),
        ("szResult", ctypes.c_char * TESTDATA_PROCESS_RESULT_LEN),
        ("szThreshold", ctypes.c_char * TESTDATA_PROCESS_THRESHOLD_LEN),
        ("szPassFail", ctypes.c_char * TESTDATA_PROCESS_PASSFAIL_LEN),
        ("szDate", ctypes.c_char * TESTDATA_PROCESS_DATE_LEN),
    ]



class TestDAta_Progress(ctypes.Structure):
    _fields_ = [
        ("szFullStep", ctypes.c_char*TESTDATA_PROGRESS_FULLSTEP_LEN),
        ("szStep", ctypes.c_char * TESTDATA_PROGRESS_STEP_LEN),
        ("szDate", ctypes.c_char*TESTDATA_PROGRESS_DATE_LEN),
    ]

class TestData_GraphInit(ctypes.Structure):
    _fields_ = [
        ("szTitle", ctypes.c_char*TESTDATA_GRAPHINIT_TITLE_LEN),
        ("szGraphIndex", ctypes.c_char * TESTDATA_GRAPHINIT_GRAPHINDEX_LEN),
        ("szX", ctypes.c_char*TESTDATA_GRAPHINIT_X_LEN),
        ("szY1", ctypes.c_char * TESTDATA_GRAPHINIT_Y1_LEN),
        ("szY2", ctypes.c_char * TESTDATA_GRAPHINIT_Y2_LEN),
    ]

class TestData_GraphDataHead(ctypes.Structure):
    _fields_ = [
        ("szOperate", ctypes.c_char*TESTDATA_GRAPHDATAHEAD_OPERATE_LEN),
        ("szGraphIndex", ctypes.c_char * TESTDATA_GRAPHDATAHEAD_GRAPHINDEX_LEN),
        ("szPlotIndex", ctypes.c_char*TESTDATA_GRAPHDATAHEAD_PLOTINDEX_LEN),
        ("szPlotTitle", ctypes.c_char * TESTDATA_GRAPHDATAHEAD_PLOTTITLE_LEN),
        ("szColor", ctypes.c_char * TESTDATA_GRAPHDATAHEAD_COLOR_LEN),
        ("szYIndex", ctypes.c_char * TESTDATA_GRAPHDATAHEAD_YINDEX_LEN),
    ]

class MSG_StructUnion(Union):
    _fields_ = [
        ("ComRunInitData", Command_RunInit),
        ("ComRunTaskData", Command_RunTask),
        ("ComRunDone", Command_RunDone),
        ("ComRunDeviceData", Command_RunDevice),
        ("ComStopRunData", Command_StopRun),
        ("ComDebugModeData", Command_DebugMode),
        ("ComRunCommandData", Command_RunCommand),

        ("MsgBaseInfo", Msg_BaseInfo),
        ("MsgTaskInfo", Msg_TaskInfo),
        ("MsgOldRate", Msg_OldRate),
        ("MsgTaskDescription", Msg_TaskDescription),
        ("MsgBox", Msg_MsgBox),
        ("MsgLog", Msg_Log),
        ("MsgCommandInfo", Msg_CommandInfo),
        ("MsgConfigPath", Msg_ConfigPath),
        ("MsgTemplate", Msg_Template),
        ("MsgTaskList", Msg_TaskList),
        ("MsgUploadData", Msg_UploadData),
        ("MsgConvPN", Msg_ConvPN),
        ("MsgConvProcess", Msg_ConvProcess),
        ("MsgStationInfo", Msg_StationInfo),
        ("MsgResultToOPC", Msg_ResultToOPC),
        ("MsgMoveOut", Msg_MoveOut),
        ("MsgMoveIn", Msg_MoveIn),
        ("MsgLoginVerify", Msg_LoginVerify),
        ("MsgStationVerify", Msg_StationVerify),
        ("MsgOplinkUserInfo", Msg_OplinkUserInfo),
        ("MsgUserSkillVerify", Msg_UserSkillVerify),
        ("MsgCreateSNDir", Msg_CreateSNDir),
        ("MsgFWStandardPath", Msg_FWStandardPath),
        ("MsgLocationInfo", Msg_LocationInfo),
        ("MsgGenericFunc", Msg_GenericFunc),

        ("TestDataProcess", TestData_Process),
        ("TestDataProgress", TestDAta_Progress),
        ("TestDataGraphInit", TestData_GraphInit),
        ("TestDataGraphHead", TestData_GraphDataHead),
    ]

class ALL_MSG_DATA(ctypes.Structure):
    _fields_ = [
        ("nDataType",    ctypes.c_int),
        ("unDataStruct", MSG_StructUnion),
    ]





