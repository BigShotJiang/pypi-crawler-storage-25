import ctypes
import struct
from ctypes import create_string_buffer
from ctypes import Structure, c_char, c_int, c_bool, c_double,c_char_p,POINTER
from enum import IntEnum
from ctypes import cdll
import sys
import os
import logging
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
parent_dir = os.path.dirname(script_dir)
sys.path.append(parent_dir)
from common.DataSrc import LOGLEVEL,TASKRESULT,stGraphDataInfo,pstTaskInfoPack,stGraphInitInfo,stProcessDataInfo
from common.TPUseXMLDataType import ALL_MSG_DATA
from common.TPUseXMLDataType import Command_RunInit

class UICommand:
    def __init__(self):
        size = struct.calcsize("P") * 8
        if size == 32:
            self.xmlcommand = ctypes.WinDLL(".\\CLibrary\\UICommand.dll")#ctypes.WinDLL(".\\CLibrary\\UICommand.dll")
        else:
            self.xmlcommand = ctypes.WinDLL(".\\CLibrary\\x64\\UICommand.dll")

    def Initialize(self):
        logging.info("Call Initialize...")
        self.xmlcommand.Initialize.argtypes = []
        self.xmlcommand.Initialize.restype = c_bool
        _initialize = getattr(self.xmlcommand , "Initialize")  
        result = _initialize()
        logging.info("Call Initialize finished:%s"%result)
        # print(result)
        return result

    def StartSocket(self):
        logging.info("Call StartSocket...")
        self.xmlcommand.StartSocket.argtypes = []
        self.xmlcommand.StartSocket.restype = c_bool
        start_socket = getattr(self.xmlcommand , "StartSocket")
        result = start_socket()#self.xmlcommand.StartSocket()
        logging.info("Call start_socket finished:%s"%result)
        return result

    def GeXmlMsgError(self):
       
        logging.info("Call GeXmlMsgError...")
        self.xmlcommand.GeXmlMsgError.argtypes = []
        self.xmlcommand.GeXmlMsgError.restype = c_char_p
       # error_ptr = ctypes.c_char_p(None)
        error_ptr = self.xmlcommand.GeXmlMsgError()
        # error_ptr['encoding']
        # 检查是否返回NULL
        _string = error_ptr.decode('utf-8')
        logging.info("Call GeXmlMsgError finished:%s"%_string)
        return _string

    def XmlShowBox(self, lpText, lpCaption, dwTyp):
        logging.info("Call XmlShowBox...")
        #int  XmlShowBox(LPCTSTR lpText, LPCTSTR lpCaption, DWORD dwTyp);
        self.xmlcommand.XmlShowBox.argtypes = [c_char_p,c_char_p, ctypes.c_ulong]
        self.xmlcommand.XmlShowBox.restype = c_int
        lpText_N=lpText.encode('gbk')
        lpCaption_N=lpCaption.encode('gbk')
        dwTyp_N=ctypes.c_ulong(dwTyp)
        result = self.xmlcommand.XmlShowBox(lpText_N, lpCaption_N, dwTyp_N)
        logging.info("Call XmlShowBox finished:%s"%result)
        return result

    def XmlSendLog(self, lpstLog, iLength, eLevel=LOGLEVEL.LOG_NORMAL):
        logging.info("Call XmlShowBox...")
        self.xmlcommand.XmlSendLog.argtypes = [c_char_p, c_int, c_int]
        self.xmlcommand.XmlSendLog.restype = c_bool
        lpstLog_N=lpstLog.encode('gbk')
        iLength_N= len(lpstLog_N)
        if not isinstance(eLevel, LOGLEVEL):
            raise TypeError("It must be LOGLEVEL enum parameter")
        eLevel_N=eLevel.value
        result = self.xmlcommand.XmlSendLog(lpstLog_N, iLength_N, eLevel_N)
        logging.info("Call XmlSendLog finished:%s"%result)
        return result

    def XmlTaskDone(self,iTaskIndex,lpstUserID,eState=TASKRESULT.TASK_DONE):
        logging.info("Call XmlShowBox...")
        self.xmlcommand.XmlTaskDone.argtypes = [ c_int,c_char_p, c_int]
        self.xmlcommand.XmlTaskDone.restype = c_bool
        iTaskIndex_N=ctypes.c_int(iTaskIndex)
        lpstUserID_N=lpstUserID.encode('utf-8')
        if not isinstance(eState, TASKRESULT):
            raise TypeError("必须使用TASKRESULT枚举类型")
        eLevel_N = eState.value
        result=self.xmlcommand.XmlTaskDone(iTaskIndex_N,lpstUserID_N,eLevel_N)
        logging.info("Call XmlTaskDone finished:%s"%result)
        return result


    def XmlStopTask(self):
        # BOOL XmlStopTask();
        result=self.xmlcommand.XmlStopTask()
        return result

    def XmlTaskInfo(self, lpstIndex, lpstTitle):
        #BOOL XmlTaskInfo(LPCTSTR lpstIndex, LPCTSTR lpstTitle);
        self.xmlcommand.XmlTaskInfo.argtypes = [c_char_p, c_char_p]
        self.xmlcommand.XmlTaskInfo.restype = c_bool
        lpstIndex_N=lpstIndex.encode('utf-8')
        lpstTitle_N=lpstTitle.encode('utf-8')
        result = self.xmlcommand.XmlTaskInfo(lpstIndex_N, lpstTitle_N)
        return result

    def XmlBaseInfo(self, lpstAuthor, lpstVersion, lpstSpec, lpstPN, lpstDate, lpstProcessType):
        # BOOL XmlBaseInfo(LPCTSTR lpstAuthor, LPCTSTR lpstVersion, LPCTSTR lpstSpec, \
        # 	LPCTSTR lpstPN, LPCTSTR lpstDate, LPCTSTR lpstProcessType)
        self.xmlcommand.XmlBaseInfo.argtypes = [c_char_p, c_char_p,c_char_p, c_char_p,c_char_p, c_char_p]
        self.xmlcommand.XmlBaseInfo.restype = c_bool
        lpstAuthor_N = lpstAuthor.encode('utf-8')
        lpstVersion_N = lpstVersion.encode('utf-8')
        lpstSpec_N = lpstSpec.encode('utf-8')
        lpstPN_N = lpstPN.encode('utf-8')
        lpstDate_N = lpstDate.encode('utf-8')
        lpstProcessType_N = lpstProcessType.encode('utf-8')
        result = self.xmlcommand.XmlBaseInfo(lpstAuthor_N, lpstVersion_N, lpstSpec_N, lpstPN_N,
                                             lpstDate_N, lpstProcessType_N)
        return result

    def XmlTaskStatus(self, pstTaskInfo):
        # BOOL XmlTaskStatus(pstTaskInfoPack pstTaskInfo);
        self.xmlcommand.XmlTaskStatus.argtypes = [pstTaskInfoPack]
        self.xmlcommand.XmlTaskStatus.restype = c_bool
        result = self.xmlcommand.XmlTaskStatus(ctypes.byref(pstTaskInfo))
        return result


    def XmlGraphInit(self, stInfo):
       
        self.xmlcommand.XmlGraphInit.argtypes = [ctypes.POINTER(stGraphInitInfo)]
        self.xmlcommand.XmlGraphInit.restype = c_bool
        result = self.xmlcommand.XmlGraphInit(ctypes.byref(stInfo))
        return result

    def XmlGraphData(self,stInfo):
        # BOOL XmlGraphData(stGraphDataInfo& stInfo);
        self.xmlcommand.XmlGraphData.argtypes = [ctypes.POINTER(stGraphDataInfo)]
        self.xmlcommand.XmlGraphData.restype = c_bool
        result = self.xmlcommand.XmlGraphData(ctypes.byref(stInfo))
        return result

    def XmlSendProcessResult(self, stProcessResult):
        # BOOL XmlSendProcessResult(stProcessDataInfo& stProcessResult);
        self.xmlcommand.XmlSendProcessResult.argtypes = [ctypes.POINTER(stProcessDataInfo)]
        self.xmlcommand.XmlSendProcessResult.restype = c_bool
        result = self.xmlcommand.XmlSendProcessResult(ctypes.byref(stProcessResult))
        return result

    def XmlGenericFunc(self,lpstrFuncName,nInputCount,pInputParam,nOutputCount,iBufferLen):
        # BOOL XmlGenericFunc(LPCSTR lpstrFuncName, int nInputCount, TCHAR* pInputParam[10], int nOutputCount,
        # char* pOutputResult[10], int iBufferLen);

        self.xmlcommand.XmlGenericFunc.argtypes = [
            ctypes.c_char_p,  # LPCSTR lpstrFuncName
            ctypes.c_int,  # int nInputCount
            ctypes.POINTER(ctypes.c_wchar_p),  # TCHAR* pInputParam[10]
            ctypes.c_int,  # int nOutputCount
            ctypes.POINTER(ctypes.c_char_p),  # char* pOutputResult[10]
            ctypes.c_int  # int iBufferLen
        ]
        self.xmlcommand.XmlGenericFunc.restype = c_bool
        lpstrFuncName_N=lpstrFuncName.encode('utf-8')
        nInputCount_N=ctypes.c_int(nInputCount)
        nOutputCount_N = ctypes.c_int(nOutputCount)
        iBufferLen_N = ctypes.c_int(iBufferLen)

        InputArray10 = c_char_p * 10
        OutputArray10 = c_char_p * 10

        in_array = InputArray10()
        for i, s in enumerate(pInputParam[:10]):
            in_array[i] = s  # automatic conversion to wchar* if TCHAR_P==c_wchar_p
        # zero out the rest
        for i in range(len(pInputParam), 10):
            in_array[i] = None

        # 2) Prepare the output buffers and the output pointer array
        buffers = [create_string_buffer(iBufferLen) for i in range(nOutputCount)]
        # cast each buffer to c_char_p
        out_ptrs = [ctypes.cast(buf, c_char_p) for buf in buffers]
        # pad up to 10 with NULL
        out_ptrs += [None] * (10 - nOutputCount)
        out_array = OutputArray10(*out_ptrs)

        # 3) Call the C function
        result=self.xmlcommand.XmlGenericFunc(
            lpstrFuncName_N,  # LPCSTR
            nInputCount_N,
            in_array,
            nOutputCount_N,
            out_array,
            iBufferLen_N
        )
        results = [buf.value.decode('utf-8', errors='ignore') for buf in buffers]
        return result,results




    def XmlTaskDescrip(self, iTaskIndex, lpstDescrip, iLength):
        # BOOL XmlTaskDescrip(int iTaskIndex, LPCTSTR lpstDescrip, int iLength);
        self.xmlcommand.XmlTaskDescrip.argtypes = [c_int, c_char_p,  c_int]
        self.xmlcommand.XmlTaskDescrip.restype = c_bool
        iTaskIndex_N=ctypes.c_int(iTaskIndex)
        lpstDescrip_N=lpstDescrip.encode("utf-8")
        iLength_N = ctypes.c_int(iLength)
        result = self.xmlcommand.XmlTaskDescrip(iTaskIndex_N, lpstDescrip_N, iLength_N)
        return result

    def XmlSendProgressData(self, iFullStep, iCurrStep):
        # BOOL XmlSendProgressData(int iFullStep, int iCurrStep);
        iFullStep_N = ctypes.c_int(iFullStep)
        iCurrStep_N = ctypes.c_int(iCurrStep)
        result = self.xmlcommand.XmlSendProgressData(iFullStep_N, iCurrStep_N)
        return result


    def XmlGetConfigPath(self, iDataPathLen, iConfigPathLen, iFWFilePathLen):
        # BOOL XmlGetConfigPath(TCHAR* lpszTestDataPath, int iDataPathLen, TCHAR* lpszConfigPath,
        # int iConfigPathLen, TCHAR* lpszFWFilePath, int iFWFilePathLen);
        iDataPathLen_N = ctypes.c_int(iDataPathLen)
        iConfigPathLen_N = ctypes.c_int(iConfigPathLen)
        iFWFilePathLen_N = ctypes.c_int(iFWFilePathLen)
        BUFFER_SIZE = 1024
        lpszTestDataPath = create_string_buffer(BUFFER_SIZE)
        lpszConfigPath = create_string_buffer(BUFFER_SIZE)
        lpszFWFilePath = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlGetConfigPath(lpszTestDataPath, iDataPathLen_N, lpszConfigPath,
                                                  iConfigPathLen_N,lpszFWFilePath,iFWFilePathLen_N)
        return result,lpszTestDataPath.value.decode('utf-8'),\
               lpszConfigPath.value.decode('utf-8'),lpszFWFilePath.value.decode('utf-8')

    def XmlDownloadTemplate(self, lpProdSN, lpProcess, lpFileNme,iShowData):
        #BOOL XmlDownloadTemplate(LPCTSTR lpProdSN, LPCTSTR lpProcess, LPCTSTR lpFileNme, int iShowData);
        self.xmlcommand.XmlDownloadTemplate.argtypes = [c_char_p, c_char_p,c_char_p, c_int]
        self.xmlcommand.XmlDownloadTemplate.restype = c_bool
        lpProdSN_N = lpProdSN.encode("utf-8")
        lpProcess_N = lpProcess.encode("utf-8")
        lpFileNme_N=lpFileNme.encode("utf-8")
        iShowData_N = ctypes.c_int(iShowData)
        result = self.xmlcommand.XmlDownloadTemplate(lpProdSN_N, lpProcess_N, lpFileNme_N,iShowData_N)
        return result


    def XmlDownloadTaskList(self, lpProdSN, lpGroup, lpPosition, iSubSNBufLen):
        # BOOL XmlDownloadTaskList(LPCTSTR lpProdSN, LPCTSTR lpGroup, LPCTSTR lpPosition,
        # TCHAR* lpszSubSN, int iSubSNBufLen);
        self.xmlcommand.XmlDownloadTaskList.argtypes = [c_char_p, c_char_p, c_char_p,c_char_p, c_int]
        self.xmlcommand.XmlDownloadTaskList.restype = c_bool
        lpProdSN_N=lpProdSN.encode("utf-8")
        lpGroup_N=lpGroup.encode("utf-8")
        lpPosition_N=lpPosition.encode("utf-8")
        iSubSNBufLen_N=ctypes.c_int(iSubSNBufLen)
        BUFFER_SIZE = 1024
        lpszSubSN = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlDownloadTaskList(lpProdSN_N, lpGroup_N, lpPosition_N, lpszSubSN,
                                                     iSubSNBufLen_N)
        return result,lpszSubSN.value.decode('utf-8')

    def XmlUploadTestData(self, lpProdSN, lpDataFileName):
        # BOOL XmlUploadTestData(LPCTSTR lpProdSN, LPCTSTR lpDataFileName);
        self.xmlcommand.XmlUploadTestData.argtypes = [c_char_p, c_char_p]
        self.xmlcommand.XmlUploadTestData.restype = c_bool
        lpProdSN_N = lpProdSN.encode("utf-8")
        lpDataFileName_N = lpDataFileName.encode("utf-8")
        result = self.xmlcommand.XmlUploadTestData(lpProdSN_N, lpDataFileName_N)
        return result

    def XmlTriggerConverProcess(self, lpProdPN, lpOriginProcess, iBufferLen,iFindType):
        # BOOL XmlTriggerConverProcess(LPCTSTR lpProdPN, LPCTSTR lpOriginProcess, TCHAR* lpszTargetProcess,
        # int iBufferLen, int iFindType);
        self.xmlcommand.XmlTriggerConverProcess.argtypes = [c_char_p, c_char_p, c_char_p,c_int, c_int]
        self.xmlcommand.XmlTriggerConverProcess.restype = c_bool
        lpOriginPN_N = lpProdPN.encode("utf-8")
        lpOriginProcess_N = lpOriginProcess.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        iFindType_N = ctypes.c_int(iFindType)
        BUFFER_SIZE = 1024
        lpszTargetProcess = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlTriggerConverProcess(lpOriginPN_N, lpOriginProcess_N, lpszTargetProcess,
                                                         iBufferLen_N,
                                                          iFindType_N)
        return result, lpszTargetProcess.value.decode('utf-8')

    def XmlTriggerConversationPN(self, lpOriginPN, iBufferLen, iCType):
        # BOOL XmlTriggerConversationPN(LPCTSTR lpOriginPN, TCHAR* lpszTargetPN, int iBufferLen, int iCType);
        self.xmlcommand.XmlTriggerConversationPN.argtypes = [c_char_p, c_char_p, c_int, c_int]
        self.xmlcommand.XmlTriggerConversationPN.restype = c_bool
        lpOriginPN_N = lpOriginPN.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        iCType_N = ctypes.c_int(iCType)
        BUFFER_SIZE = 1024
        lpszTargetPN = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlTriggerConversationPN(lpOriginPN_N, lpszTargetPN, iBufferLen_N,
                                                   iCType_N)
        return result, lpszTargetPN.value.decode('utf-8')


    def XmlGetStationInfo(self, lpStationComputerName, iBufferLen):
        #  BOOL XmlGetStationInfo(LPCTSTR lpStationComputerName, TCHAR* lpszStationID,
        #  TCHAR* lpszStationName, int iBufferLen);
        self.xmlcommand.XmlGetStationInfo.argtypes = [c_char_p, c_char_p, c_char_p, c_int]
        self.xmlcommand.XmlGetStationInfo.restype = c_bool
        lpStationComputerName_N = lpStationComputerName.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        lpszStationID = create_string_buffer(BUFFER_SIZE)
        lpszStationName = create_string_buffer(BUFFER_SIZE)

        result = self.xmlcommand.XmlGetStationInfo(lpStationComputerName_N, lpszStationID, lpszStationName,
                                                iBufferLen_N)
        return result, lpszStationID.value.decode('utf-8'),lpszStationName.value.decode('utf-8')



    def XmlTriggerTestResultUpload2OPC(self, lpProdSN):
        # BOOL XmlTriggerTestResultUpload2OPC(LPCTSTR lpProdSN);
        self.xmlcommand.XmlTriggerTestResultUpload2OPC.argtypes = [c_char_p]
        self.xmlcommand.XmlTriggerTestResultUpload2OPC.restype = c_bool
        lpProdSN_N = lpProdSN.encode("utf-8")
        result = self.xmlcommand.XmlTriggerTestResultUpload2OPC(lpProdSN_N)
        return result



    def XmlTriggerMoveIn(self, lpProdSN):
        # BOOL XmlTriggerMoveIn(LPCTSTR lpProdSN);
        self.xmlcommand.XmlTriggerMoveIn.argtypes = [c_char_p]
        self.xmlcommand.XmlTriggerMoveIn.restype = c_bool
        lpProdSN_N = lpProdSN.encode("utf-8")
        result = self.xmlcommand.XmlTriggerMoveIn(lpProdSN_N)
        return result

    def XmlTriggerMoveOut(self, lpProdSN):
        # BOOL XmlTriggerMoveOut(LPCTSTR lpProdSN);
        self.xmlcommand.XmlTriggerMoveOut.argtypes = [c_char_p]
        self.xmlcommand.XmlTriggerMoveOut.restype = c_bool
        lpProdSN_N = lpProdSN.encode("utf-8")
        result = self.xmlcommand.XmlTriggerMoveOut(lpProdSN_N)
        return result


    def XmlTriggerMIMSIDLoginVerify(self, lpUserID, lpPassWord):
        # BOOL XmlTriggerMIMSIDLoginVerify(LPCTSTR lpUserID, LPCTSTR lpPassWord);
        self.xmlcommand.XmlTriggerMIMSIDLoginVerify.argtypes = [c_char_p,c_char_p]
        self.xmlcommand.XmlTriggerMIMSIDLoginVerify.restype = c_bool
        lpUserID_N = lpUserID.encode("utf-8")
        lpPassWord_N = lpPassWord.encode("utf-8")
        result = self.xmlcommand.XmlTriggerMIMSIDLoginVerify(lpUserID_N,lpPassWord_N)
        return result

    def XmlTriggerWorkStationVerify(self, lpWorkStationID, lpUserID, lpCheckType):
        # BOOL XmlTriggerWorkStationVerify(LPCTSTR lpWorkStationID, LPCTSTR lpUserID, LPCTSTR lpCheckType)
        self.xmlcommand.XmlTriggerWorkStationVerify.argtypes = [c_char_p, c_char_p, c_char_p]
        self.xmlcommand.XmlTriggerWorkStationVerify.restype = c_bool
        lpWorkStationID_N = lpWorkStationID.encode("utf-8")
        lpUserID_N = lpUserID.encode("utf-8")
        lpCheckType_N = lpCheckType.encode("utf-8")
        result = self.xmlcommand.XmlTriggerWorkStationVerify(lpWorkStationID_N,lpUserID_N, lpCheckType_N)
        return result

    def XmlGetOplinkUserInfo(self, lpOplinkID, iBufferLen):
        # BOOL XmlGetOplinkUserInfo(LPCTSTR lpOplinkID, TCHAR* ptchrUserName, TCHAR* ptchrDptName,
        # TCHAR* ptchrPosName, TCHAR* ptchrOPCID, int iBufferLen);
        self.xmlcommand.XmlGetOplinkUserInfo.argtypes = [c_char_p, c_char_p, c_char_p, c_char_p,
                                                         c_char_p, c_int]
        self.xmlcommand.XmlGetOplinkUserInfo.restype = c_bool
        lpOplinkID_N = lpOplinkID.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrUserName = create_string_buffer(BUFFER_SIZE)
        ptchrDptName = create_string_buffer(BUFFER_SIZE)
        ptchrPosName = create_string_buffer(BUFFER_SIZE)
        ptchrOPCID = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlGetOplinkUserInfo(lpOplinkID_N, ptchrUserName, ptchrDptName,ptchrPosName,
                                                ptchrOPCID,iBufferLen_N)
        return result, ptchrUserName.value.decode('utf-8'),ptchrDptName.value.decode('utf-8'),\
               ptchrPosName.value.decode('utf-8'),\
               ptchrOPCID.value.decode('utf-8')


    def XmlTriggerUserSkillVerify(self, lpOPCID, lpProcess):
        # BOOL XmlTriggerUserSkillVerify(LPCTSTR lpOPCID, LPCTSTR lpProcess);
        self.xmlcommand.XmlTriggerUserSkillVerify.argtypes = [c_char_p, c_char_p]
        self.xmlcommand.XmlTriggerUserSkillVerify.restype = c_bool
        lpOPCID_N = lpOPCID.encode("utf-8")
        lpProcess_N = lpProcess.encode("utf-8")
        result = self.xmlcommand.XmlTriggerUserSkillVerify(lpOPCID_N, lpProcess_N)
        return result

    def XmlCreateSNDir(self, lpDutSN, lpRootDir, iBufferLen):
        # BOOL XmlCreateSNDir(LPCTSTR lpDutSN, LPCTSTR lpRootDir, TCHAR* ptchrOutSNDir, int iBufferLen);
        self.xmlcommand.XmlCreateSNDir.argtypes = [c_char_p, c_char_p, c_char_p, c_int]
        self.xmlcommand.XmlCreateSNDir.restype = c_bool
        lpDutPN_N = lpDutSN.encode("utf-8")
        lpRootDir_N = lpRootDir.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutSNDir = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlCreateSNDir(lpDutPN_N, lpRootDir_N, ptchrOutSNDir,
                                                      iBufferLen_N)
        return result, ptchrOutSNDir.value.decode('utf-8')



    def XmlGetFWStandardPath(self,lpDutPN,iBufferLen):
        #BOOL XmlGetFWStandardPath(LPCTSTR lpDutPN, TCHAR* ptchrOutFWPN, TCHAR* ptchrOutConfigDir,
        # int iBufferLen);
        self.xmlcommand.XmlGetFWStandardPath.argtypes = [c_char_p, c_char_p, c_char_p, c_int]
        self.xmlcommand.XmlGetFWStandardPath.restype = c_bool
        lpDutPN_N=lpDutPN.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutFWPN = create_string_buffer(BUFFER_SIZE)
        ptchrOutConfigDir = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlGetFWStandardPath(lpDutPN_N, ptchrOutFWPN, ptchrOutConfigDir,
                                             iBufferLen_N)
        return result, ptchrOutFWPN.value.decode('utf-8'), \
               ptchrOutConfigDir.value.decode('utf-8')

    def XmlLocation(self,iBufferLen):
        #BOOL XmlLocation(TCHAR* ptchrLanguage, TCHAR* ptchrLocation, TCHAR* ptchrFactory, int iBufferLen);
        self.xmlcommand.XmlLocation.argtypes = [c_char_p, c_char_p, c_char_p, c_int]
        self.xmlcommand.XmlLocation.restype = c_bool
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutLanguge = create_string_buffer(BUFFER_SIZE)
        ptchrOutLocation = create_string_buffer(BUFFER_SIZE)
        ptchrOutFactory = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlLocation(ptchrOutLanguge, ptchrOutLocation, ptchrOutFactory,
                                                    iBufferLen_N)
        return result, ptchrOutLanguge.value.decode('utf-8'), \
               ptchrOutLocation.value.decode('utf-8'), ptchrOutFactory.value.decode('utf-8')



    def XmlGetPrintLabelInfo(self,lpDutSN,lpLableID,lpPosition,iBufferLen):
        #BOOL XmlGetPrintLabelInfo(LPCTSTR lpDutSN, LPCTSTR lpLableID, LPCTSTR lpPosition,
        # TCHAR* ptchrOutContent, int iBufferLen);
        #//获取标签信息
        self.xmlcommand.XmlGetPrintLabelInfo.argtypes = [c_char_p, c_char_p, c_char_p,c_char_p, c_int]
        self.xmlcommand.XmlGetPrintLabelInfo.restype = c_bool
        lpDutSN_N = lpDutSN.encode("utf-8")
        lpLableID_N = lpLableID.encode("utf-8")
        lpPosition_N = lpPosition.encode("utf-8")
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutContent = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlGetPrintLabelInfo(lpDutSN_N, lpLableID_N, lpPosition_N, ptchrOutContent,
                                                  iBufferLen_N)
        return result, ptchrOutContent.value.decode('utf-8')


    def XmlUploadTestSystemCailbrationTime(self,lpUserID):
        #BOOL XmlUploadTestSystemCailbrationTime(LPCTSTR lpUserID);
        #/上传归零时间到TMS
        self.xmlcommand.XmlUploadTestSystemCailbrationTime.argtypes = [c_char_p]
        self.xmlcommand.XmlUploadTestSystemCailbrationTime.restype = c_bool
        lpUserID_N = lpUserID.encode("utf-8")
        result = self.xmlcommand.XmlUploadTestSystemCailbrationTime(lpUserID_N)
        return result

    def XmlGetLocationInfo(self,iBufferLen):
        #BOOL XmlGetLocationInfo(TCHAR* ptchrOutLanguge, TCHAR* ptchrOutLocation, TCHAR* ptchrOutFactory,
        # int iBufferLen);
        #//获取location 信息
        self.xmlcommand.XmlGetLocationInfo.argtypes = [c_char_p, c_char_p,  c_char_p, c_int]
        self.xmlcommand.XmlGetLocationInfo.restype = c_bool
        iBufferLen_N = ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutLanguge = create_string_buffer(BUFFER_SIZE)
        ptchrOutLocation=create_string_buffer(BUFFER_SIZE)
        ptchrOutFactory=create_string_buffer(BUFFER_SIZE)
        result=self.xmlcommand.XmlGetLocationInfo(ptchrOutLanguge,ptchrOutLocation,ptchrOutFactory,
                                           iBufferLen_N)
        return result,ptchrOutLanguge.value.decode('utf-8'),\
               ptchrOutLocation.value.decode('utf-8'),ptchrOutFactory.value.decode('utf-8')


    def XmlGetMACAddress(self,lpDutSN,lpDutPN,nMACCount,iBufferLen):
        #BOOL XmlGetMACAddress(LPCTSTR lpDutSN, LPCTSTR lpDutPN, int nMACCount, TCHAR* ptchrOutContent,
        # int iBufferLen);
        #//20231024 获取MAC 地址
        self.xmlcommand.XmlGetMACAddress.argtypes = [c_char_p,c_char_p,c_int,c_char_p,c_int]
        self.xmlcommand.XmlGetMACAddress.restype = c_bool
        lpDutSN_N = lpDutSN.encode("utf-8")
        lpDutPN_N = lpDutPN.encode("utf-8")
        nMACCount_N=ctypes.c_int(nMACCount)
        iBufferLen_N=ctypes.c_int(iBufferLen)
        BUFFER_SIZE = 1024
        ptchrOutContent = create_string_buffer(BUFFER_SIZE)
        result = self.xmlcommand.XmlGetMACAddress(lpDutSN_N,lpDutPN_N,nMACCount_N,ptchrOutContent,
                                                  iBufferLen_N)
        return result,ptchrOutContent.value.decode('utf-8')


    def XmlGetRoutingTheoryIL(self,lpDutSN,lpDutPortName,lpWavelength):
        #BOOL XmlGetRoutingTheoryIL(LPCTSTR lpDutSN, LPCTSTR lpDutPortName, LPCTSTR lpWavelength,
        # double* pdbOutTheoryIL, double* pdbOutTheoryILWSplice);
        #获取 无源光路理论IL 值
        self.xmlcommand.XmlGetRoutingTheoryIL.argtypes = [c_char_p, c_char_p, c_char_p, POINTER(c_double),
                                                     POINTER(c_double)]
        self.xmlcommand.XmlGetRoutingTheoryIL.restype = c_bool
        lpDutSN_N = lpDutSN.encode("utf-8")
        lpDutPortName_N = lpDutPortName.encode("utf-8")
        lpWavelength_N = lpWavelength.encode("utf-8")
        pdbOutTheoryIL_N = (ctypes.c_double * 5001)(0)  # 最大点数不超过5001
        pdbOutTheoryILWSplice_N = (ctypes.c_double * 5001)(0)  # 最大点数不超过5001
        result=self.xmlcommand.XmlGetRoutingTheoryIL(lpDutSN_N,lpDutPortName_N,lpWavelength_N,pdbOutTheoryIL_N,
                                              pdbOutTheoryILWSplice_N)
        return result,pdbOutTheoryIL_N,pdbOutTheoryILWSplice_N
    
    def XmlAcqMsgCount(self):
        self.xmlcommand.XmlAcqMsgCount.argtypes = []
        self.xmlcommand.XmlAcqMsgCount.restype = c_int
        _acqmsgcount = getattr(self.xmlcommand , "XmlAcqMsgCount")  
        result = _acqmsgcount()        
        return result
     
    def XmlRecv(self):
        try:
            self.xmlcommand.XmlRecv.argtypes = [ctypes.POINTER(ALL_MSG_DATA)]
            # self.xmlcommand.XmlRecv.restype = c_bool
            data = ALL_MSG_DATA() 
            # print(f"nDataType: {data.nDataType}")  # 如果为None，表示NULL
            # print(f"unDataStruct: {data.unDataStruct}")
            result = self.xmlcommand.XmlRecv(ctypes.byref(data))
            # result =  self.xmlcommand.XmlRecv(ctypes.byref(data))
            # print(f"nDataType: {data.nDataType}")  # 如果为None，表示NULL
            # print(f"unDataStruct: {data.unDataStruct}")
            
            return result , data
        
        except Exception as e:
          print(e)           

    def XmlFeedback(self,pstUUISendInfo):
        self.xmlcommand.XmlFeedback.argtypes = [POINTER(ALL_MSG_DATA)]
        self.xmlcommand.XmlFeedback.restype = None
        XmlFeedback = getattr(self.xmlcommand , "XmlFeedback")  
        XmlFeedback(ctypes.byref(pstUUISendInfo))     

    
if __name__ =="__main__":
        
    g_c = UICommand()
    g_c.StartSocket()  