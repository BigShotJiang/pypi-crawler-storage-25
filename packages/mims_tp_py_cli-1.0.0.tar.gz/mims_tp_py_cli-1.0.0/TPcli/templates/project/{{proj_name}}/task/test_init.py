# -*- coding: utf-8 -*-

#You can add test initi body code
#The function name  cannot be changed.
#The file name cannot be changed.
def RunTestInit():
    a = 1 + 2
    print(a)
    return True