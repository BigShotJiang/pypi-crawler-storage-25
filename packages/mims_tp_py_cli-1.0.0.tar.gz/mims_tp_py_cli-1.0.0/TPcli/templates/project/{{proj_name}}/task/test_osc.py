# -*- coding: utf-8 -*-
import sys
import os
import time
import csv
import ctypes
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
parent_dir = os.path.dirname(script_dir)
sys.path.append(str(parent_dir))

from common import DataSrc

# from common import *


# from common import DataSrc
# from common import TPInfoManger


class OSC_FinalTest_Process():

    def __init__(self,pNetCommand):
        self.m_pNetCommand = pNetCommand
        self.m_TaskIndex = 0
        self.m_user =''
        self.m_nGraphIndex=0
    # def setUp(self):
    #     self.xmlcommand=UICommand()
    #     self.tp=TPInfoManager()
    #     self.m_strUISendSN, self.m_strUISendUser, self.m_strUISendPN=self.tp.GetUISendUser()


    def RunTestTask(self,_taksindex,_User):
       
        self.m_TaskIndex =_taksindex
        self.m_user = _User
        if _taksindex == 101:
           return self.test_ICC('cold') 
        elif _taksindex == 102:
           return self.test_Outputpower('cold')
        elif _taksindex == 103:
            return self.test_DFB_Outputpower('cold')
        elif _taksindex == 104:
            return self.test_Outpower_for_tone_mode('cold')
        elif _taksindex == 105:
            return self.test_ER('cold')            
        elif _taksindex == 106:
            return self.test_ER_for_tone_mode('cold')            
        elif _taksindex == 107:
            return self.test_Eye_Crossing('cold')            
        elif _taksindex == 108:
            return self.test_MaskMargin('cold')            
        elif _taksindex == 109:
            return self.test_LOS('cold')        
        elif _taksindex == 110:
            return self.test_WL('cold')        
        elif _taksindex == 111:
            return self.test_OSA('cold') 
        elif _taksindex == 112:
            return self.test_Sensitivity('cold')                  
        elif _taksindex == 113:
            return self.test_Saturation('cold')      
        elif _taksindex == 114:
            return self.test_SpanLoss('cold')    
        elif _taksindex == 115:
            return self.test_DDM('cold')    
            
        elif _taksindex == 201:
               return self.test_ICC('med') 
        elif _taksindex == 202:
           return self.test_Outputpower('med')
        elif _taksindex == 203:
            return self.test_DFB_Outputpower('med')
        elif _taksindex == 204:
                return self.test_Outpower_for_tone_mode('med')
        elif _taksindex == 205:
                return self.test_ER('med')            
        elif _taksindex == 206:
                return self.test_ER_for_tone_mode('med')            
        elif _taksindex == 207:
                return self.test_Eye_Crossing('med')            
        elif _taksindex == 208:
                return self.test_MaskMargin('med')            
        elif _taksindex == 209:
                return self.test_LOS('med')        
        elif _taksindex == 210:
                return self.test_WL('med')        
        elif _taksindex == 211:
                return self.test_OSA('med') 
        elif _taksindex == 212:
                return self.test_Sensitivity('med')                  
        elif _taksindex == 213:
                return self.test_Saturation('med')      
        elif _taksindex == 214:
                return self.test_SpanLoss('med')    
        elif _taksindex == 215:
                return self.test_DDM('med')      
            
        elif _taksindex == 301:
            return self.test_ICC('hot') 
        elif _taksindex == 302:
           return self.test_Outputpower('hot')
        elif _taksindex == 303:
            return self.test_DFB_Outputpower('hot')
        elif _taksindex == 304:
                return self.test_Outpower_for_tone_mode('hot')
        elif _taksindex == 305:
                return self.test_ER('hot')            
        elif _taksindex == 306:
                return self.test_ER_for_tone_mode('hot')            
        elif _taksindex == 307:
                return self.test_Eye_Crossing('hot')            
        elif _taksindex == 308:
                return self.test_MaskMargin('hot')            
        elif _taksindex == 309:
                return self.test_LOS('hot')        
        elif _taksindex == 310:
                return self.test_WL('hot')        
        elif _taksindex == 311:
                return self.test_OSA('hot') 
        elif _taksindex == 312:
                return self.test_Sensitivity('hot')                  
        elif _taksindex == 313:
                return self.test_Saturation('hot')      
        elif _taksindex == 314:
                return self.test_SpanLoss('hot')    
        elif _taksindex == 315:
                return self.test_DDM('hot')                      
    
            
    def test_ICC(self,temp):
        # index=read_xml(filename='TP-TASK-INFO.xml',temp='Cold Temperature',name='Testing ICC')
        lpstLog='test_TCC Start'
        result = self.m_pNetCommand.XmlSendLog(lpstLog, iLength=1+len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_WARNING)
        if result is False:
            return False
        time.sleep(0.1)
        self.m_pNetCommand.XmlShowBox(lpText='Please power off and then power on', lpCaption='', dwTyp = DataSrc.XSB_OK | DataSrc.XSB_ICONWARNING)
               
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = self.m_TaskIndex
        _resui.pszOpLine ='Testing ICC'.encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 1.0
        _resui.dbDataRangeLow = 0
        _resui.dbDataRangeUp = 1.1
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_TCC END'
        result=self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        if result is False:
            return False
        result=self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex,lpstUserID=self.m_user,eState=DataSrc.TASKRESULT.TASK_DONE)
        if result is False:
            return False
        
        return True

    def test_Outputpower(self,temp):
       
        lpstLog = 'test_Outputpower Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Output power:-2.5dBm, the power out of spec: [1.5,2.5] dBm'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = self.m_TaskIndex
        _resui.pszOpLine ='Testing OutputPower'.encode('gbk')
        
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = -2.5
        _resui.dbDataRangeLow = 1.5
        _resui.dbDataRangeUp = 2.5
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_Outputpower END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID='24351', eState=DataSrc.TASKRESULT.TASK_FAIL)
        return False
        
    def test_DFB_Outputpower(self,temp):
       
        lpstLog = 'test_DFB_Outputpower Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'DFB Output power:2.0dBm, the power is math the spec: [0.0,3.0] dBm'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = self.m_TaskIndex
        _resui.pszOpLine ='Testing DFB OutputPower'.encode('gbk')
        
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 2.0
        _resui.dbDataRangeLow = 0.0
        _resui.dbDataRangeUp = 3.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_DFB_Outputpower END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
    def test_Outpower_for_tone_mode(self,temp):
        
        lpstLog = 'test_Outpower_for_tone_mode Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Set tone_mode'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Output power:1.0dBm, the power is math the spec: [0.0,3.0] dBm'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = self.m_TaskIndex
        _resui.pszOpLine ='Testing OutputPower for tone mode'.encode('gbk')
        
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 1.0
        _resui.dbDataRangeLow = 0.0
        _resui.dbDataRangeUp = 23
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_Outpower_for_tone_mode END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
    def test_ER(self,temp):
        lpstLog = 'test_ER Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Get ER Value:13.97, the value is math the spec: [12.0,90.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing ER".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 13.97
        _resui.dbDataRangeUp = 90.0
        _resui.dbDataRangeLow = 12.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_ER END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
    def test_ER_for_tone_mode(self,temp):
        
        lpstLog = 'test_ER_for_tone_mode Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Set tone_mode'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Get ER Value:14.14, the value is math the spec: [12.0,90.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing ER".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 14.14
        _resui.dbDataRangeUp = 90.0
        _resui.dbDataRangeLow = 12.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)

        lpstLog = 'test_ER_for_tone_mode END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
    def test_Eye_Crossing(self,temp):
        
        lpstLog = 'test_Eye_Crossing Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'Get Crossing Value:48.3, the value is math the spec: [45.0.0,99.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing Eye Crossing".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 48.3
        _resui.dbDataRangeUp = 99.0
        _resui.dbDataRangeLow = 45.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_Eye_Crossing END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
    def test_MaskMargin(self,temp):
        
        lpstLog = 'test_MaskMargin Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'Get Tx Mask test Value:62, the value is math the spec: [60.0.0,99.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing Mask Margin".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 62
        _resui.dbDataRangeUp = 99.0
        _resui.dbDataRangeLow = 60.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_MaskMargin END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True

    def test_LOS(self,temp):
        
        lpstLog = 'test_LOS Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'Get LOS Value:-41.5, the value is math the spec: [-60.0,-40.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing LOS".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 62
        _resui.dbDataRangeUp = 99.0
        _resui.dbDataRangeLow = 60.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_LOS END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)

        return True

    def readscancsv(self):
        script_path = os.path.abspath(__file__)
        script_dir = os.path.dirname(script_path)
        parent_dir = os.path.dirname(script_dir)
        filename = os.path.join(parent_dir,'config','Wave_Scan.csv')
        wav = []
        IL = []
        with open(filename, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)  # 默认以逗号分隔
            for row in reader:
                # print(row['Wave'], row['IL'])  # 通过列名访问数据
                wav.append(row['Wave'])
                IL.append(row['IL'])
        return wav,IL  
    
    def InitGraphShow(self,title,xcapion,ycaption1,ycaption2):
        process_data = DataSrc.stGraphInitInfo()
        process_data.iGraphIndex = 0
        process_data.pszTitle = title.encode('gbk') 
        process_data.stScale[0].bScaleAuto = ctypes.c_int(1)
        process_data.stScale[0].bScaleUse =  ctypes.c_int(1)
        process_data.stScale[0].pszScaleName = xcapion.encode('gbk',errors='xmlcharrefreplace')
        process_data.stScale[1].bScaleAuto = ctypes.c_int(1)
        process_data.stScale[1].bScaleUse = ctypes.c_int(1)
        process_data.stScale[1].pszScaleName = ycaption1.encode('gbk',errors='xmlcharrefreplace')
        process_data.stScale[2].bScaleAuto = ctypes.c_int(1)
        process_data.stScale[2].bScaleUse = ctypes.c_int(1)
        process_data.stScale[2].pszScaleName = ycaption2.encode('gbk',errors='xmlcharrefreplace')
        
        res = self.m_pNetCommand.XmlGraphInit(process_data)
        if res == False:
            lpstLog = 'Inital Graph error'
            self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_ERROR) 
        return res
    
    def PlotAdd(self):
        process_data = DataSrc.stGraphDataInfo()
        
        process_data.opt = DataSrc.GRAPHOPT.GRAPH_OPT_ADDPLOT
        process_data.iGraphIndex = 0
        process_data.iPlotIndex = self.m_nGraphIndex + 1
        process_data.pszPlotTitle = 'OSA Scan'.encode('gbk')
        process_data.iColor = 2
        process_data.iYScaleIndex = 0
        process_data.iDataCount = 0
        pdblXData_N = (ctypes.c_double * 1)()
        pdblYData_N = (ctypes.c_double * 1)()
        process_data.pdblXData = pdblXData_N
        process_data.pdblYData = pdblYData_N
        res = self.m_pNetCommand.XmlGraphData(process_data)  
        if res == False:
            return False
        return True    

    def ShowScanCurve(self):
        
        res = self.InitGraphShow('OSA SCan Curve',"Wavelenth","Power","")
        if res == False:
            return False
        res = self.PlotAdd()
        if res == False:
            return False
        
        wav,il = self.readscancsv()
        xdata =wav
        length1 = len(xdata)
        pdblXData_N = (ctypes.c_double * length1)()
        for i in range(length1):
            pdblXData_N[i] = float(xdata[i])
        ydata = il
        length1 = len(ydata)
        pdblYData_N = (ctypes.c_double * length1)()
        for i in range(length1):
            pdblYData_N[i] = float(ydata[i])
            
        process_data = DataSrc.stGraphDataInfo()
        process_data.opt = DataSrc.GRAPHOPT.GRAPH_OPT_ADDDATA
        process_data.iGraphIndex = 0
        process_data.iPlotIndex = 1
        process_data.pszPlotTitle = 'OSA Scan'.encode('gbk')
        process_data.iColor = 2
        process_data.iYScaleIndex = 0
        process_data.iDataCount = length1
        process_data.pdblXData = pdblXData_N
        process_data.pdblYData = pdblYData_N

        res = self.m_pNetCommand.XmlGraphData(process_data)  
        if res == False:
            return False
        return True    

    def test_WL(self,temp):
        lpstLog = 'test_WL Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'OSA Scanning.....'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)  
        
        self.ShowScanCurve()
        
        lpstLog = 'Read Center WL Value:1518.9nm, the value is math the spec: [1518.0,1519.0] nm'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing WL".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 1518.9
        _resui.dbDataRangeUp = 1519
        _resui.dbDataRangeLow = 1518
        self.m_pNetCommand.XmlSendProcessResult(_resui)
             
        lpstLog = 'test_WL END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True

    def test_OSA(self,temp):
        lpstLog = 'test_OSA Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        
        lpstLog = 'Read LOSA Vaule:-43.37, the value is math the spec: [-70.0,-40.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing OSA".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = -43.37
        _resui.dbDataRangeUp = -40
        _resui.dbDataRangeLow = -70
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_OSA END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True

    def test_Sensitivity(self,temp):
        
        lpstLog = 'test_Sensitivity Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Read sensitivity Vaule:-37.43, the value is math the spec: [-40,-35]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing Sensitivity".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = -37.43
        _resui.dbDataRangeUp = -35.0
        _resui.dbDataRangeLow = -40.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_Sensitivity END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True

    def test_Saturation(self,temp):
        
        lpstLog = 'test_Saturation Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Test Saturation Vaule:0.0, the value is math the spec: [0.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing Saturation".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 0.0
        _resui.dbDataRangeUp = 0.1
        _resui.dbDataRangeLow = -0.1
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_Saturation END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True

    def test_SpanLoss(self,temp):
        
        lpstLog = 'test_SpanLoss Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        lpstLog = 'Test SpanLoss Vaule: 0.7, the value is math the spec: [0,1.0]'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog),eLevel=DataSrc.LOGLEVEL.LOG_NORMAL)
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing SpanLoss".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 0.7
        _resui.dbDataRangeUp = 1.0
        _resui.dbDataRangeLow = 0.0
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_SpanLoss END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True


    def test_DDM(self,temp):
       
        lpstLog = 'test_DDM Start'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'Test Tx Power error:0.01dB'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        lpstLog = 'Test Rx Power:1.367dBm'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        time.sleep(0.1)
        
        _resui = DataSrc.stProcessDataInfo()
        _resui.iDataID = 2
        _resui.pszOpLine = "Testing DDM".encode('gbk')
        if temp == 'cold':
            _resui.pszDataName ='Cold temprature test'.encode('gbk')
        elif temp =='med':
            _resui.pszDataName ='Med temprature test'.encode('gbk')
        else:
            _resui.pszDataName ='Hot temprature test'.encode('gbk')
        _resui.dbDataResult = 1
        _resui.dbDataRangeUp = 1.1
        _resui.dbDataRangeLow = 0.9
        self.m_pNetCommand.XmlSendProcessResult(_resui)
        
        lpstLog = 'test_DDM END'
        self.m_pNetCommand.XmlSendLog(lpstLog=lpstLog, iLength=1 + len(lpstLog))
        self.m_pNetCommand.XmlTaskDone(iTaskIndex=self.m_TaskIndex, lpstUserID=self.m_user, eState=DataSrc.TASKRESULT.TASK_DONE)
        return True
    
if __name__ =="__main__":
    aa = OSC_FinalTest_Process("AA")
    wav,il =  aa.readscancsv()