import re
from xml.etree import ElementTree as ET
def read_xml(filename,temp,name):
    title=''
    index=''
    f = open(filename, 'r')
    rawdata = f.read()
    if '\"gb2312\"' in rawdata:
        rawdata = re.sub('gb2312', 'utf-8', rawdata)
    f.close()
    root = ET.fromstring(rawdata)
    for child in root:
        if child.tag=='LEVEL':
            for node1 in child:
                if node1.tag == 'LEVEL' and node1.attrib['Title']==temp:
                    for node2 in node1:
                        if node2.attrib['Title']==name:
                            title=node2.attrib['Title']
                            index=int(node2.attrib['Index'])
    if title=='' or index=='':
        raise Exception
    return title,index