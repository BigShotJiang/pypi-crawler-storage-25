import time


def function1():
    pass

def function2():
    pass

def function3():
    pass

def function4():
    pass

def function5():
    pass

def function6():
    pass

def function7():
    pass

def function8():
    pass

def function9():
    pass

def function10():
    pass

def function11():
    pass

def function12():
    pass

def function13():
    pass

def function14():
    pass

def function15():
    pass

def function16():
    pass

def function17():
    pass
# import unittest
# from dut import SERIAL_COM, SCP_COM
# from .common import *
# import shutil
# logging.basicConfig(level=logging.INFO)

# #tas库获取mac地址，#tas库创建文件目录，获取FW地址配置

# #脚本如何实现Fusion模板解析信息，测试结果上传到XML

# #脚本调用MIMS界面操作的接口，比如LogInfo

# #MIMS如何运行python脚本

# #脚本如何获取MIMS内部的PN,SN

# #模板xml测试项如何与脚本测试项一一对应

# class SW1_RT_SCC_Program(unittest.TestCase):
#     #WS7-CP-T写信息
#     def setUp(self):
#         self.com = SERIAL_COM(Product_Serial, '115200')
#         buffer = self.com.send_data(data='\r', expect=['Username:', 'admin@DCI-CARMEL->', 'sh-5.2#'],
#                                     timeout=240)
#         if 'Username:' in buffer:
#             self.com.send_data(data='admin', expect='Password:')
#             self.com.send_data(data='m4X!izP#', expect='admin@DCI-CARMEL->')
#             self.com.send_data(data='shell', expect='Password:')
#             self.com.send_data(data='m4X!izP#', expect='sh-5.2#')
#         elif 'admin@DCI-CARMEL->' in buffer:
#             self.com.send_data(data='shell', expect='Password:')
#             self.com.send_data(data='m4X!izP#', expect='sh-5.2#')
#         else:
#             self.com.send_data(data='\r\n', expect='sh-5.2#')

#     def tearDown(self):
#         self.com.close()


#     def test1_Program_temple_mac(self):
#         tas = ITAS()
#         result = tas.XmlGetMACAddress( lpDutSN=SN,  lpDutPN=PN,  nMACCount=5,  ptchrOutContent="",  iBufferLen=0)
#         mac0 = result[0].replace(",","").upper()
#         mac1 = result[1].replace(",","").upper()
#         mac2 = result[2].replace(",","").upper()
#         mac3 = result[3].replace(",","").upper()
#         mac4 = result[4].replace(",","").upper()
#         self.com.send_data(data='cd /usr/local/bin',expect='sh-5.2#')
#         buffer = self.com.send_data(
#             data='./eepromaccesstool -nic=1 -f=I350_2-4port_SerdesKX_NO-MNG_1_63.hex -mac={}'.format(mac0),
#             expect='sh-5.2#', timeout=30)
#         if 'Test writing worked' not in buffer:
#             raise Exception
#         buffer = self.com.send_data(
#             data='./eepromaccesstool -nic=2 -f=I350_2-4port_SerdesKX_NO-MNG_1_63.hex -mac={}'.format(mac1),
#             expect='sh-5.2#', timeout=30)
#         if 'Test writing worked' not in buffer:
#             raise Exception
#         buffer = self.com.send_data(
#             data='./eepromaccesstool -nic=3 -f=I350_2-4port_SerdesKX_NO-MNG_1_63.hex -mac={}'.format(mac2),
#             expect='sh-5.2#', timeout=30)
#         if 'Test writing worked' not in buffer:
#             raise Exception
#         buffer = self.com.send_data(
#             data='./eepromaccesstool -nic=4 -f=I350_2-4port_SerdesKX_NO-MNG_1_63.hex -mac={}'.format(mac3),
#             expect='sh-5.2#', timeout=30)
#         if 'Test writing worked' not in buffer:
#             raise Exception
#         self.com.send_data(data='reboot\r', keep_time=160)
#         #处理保存xml结果数据



    def test2_SCC_Info_Program(self):
        tas = ITAS()
        result = tas.GetFWStandardPath(strPN=PN, strFWBOMPN='', strFWStandardPath='', strOutErrMsg='')
        fw_path = result[0]

        result = tas.XmlGetMACAddress(lpDutSN=SN, lpDutPN=PN, nMACCount=5, ptchrOutContent="", iBufferLen=0)
        mac0 = result[0].replace(",",":").upper()
        mac1 = result[1].replace(",",":").upper()
        mac2 = result[2].replace(",",":").upper()
        mac3 = result[3].replace(",",":").upper()
        mac4 = result[4].replace(",",":").upper()

        config = configparser.ConfigParser()
        config.read('{}\\FW&HW Version Config.ini'.format(fw_path), encoding="utf-8-sig")

        FPGA_File = config.get('FILE_NAME', 'SCC_FPGA_DOWNLOAD')
        CPLD_File = config.get('FILE_NAME', 'SCC_CPLD_DOWNLOAD')
        MCC_File = config.get('FILE_NAME', 'BUNDLE_MCC')
        SCC_File = config.get('FILE_NAME', 'SCC_MFG_FILE')

        shutil.copy(src='{}\\{}'.format(fw_path,SCC_File), dst='{}\\LUT\\{}'.format(SN,SCC_File))
        current_date = time.strftime('%Y-%m-%d', time.gmtime(time.time()))
        file = open("{}/LUT/{}".format(SN, SCC_File), 'r+')
        content = file.read()
        new_content = content.replace('MODULE_SN                          H9604930',
                                      'MODULE_SN                          {}'.format(SN))
        new_content = new_content.replace('MODULE_MFG_DATE                    2025-01-03',
                                          'MODULE_MFG_DATE                    {}'.format(current_date))
        new_content = new_content.replace('MODULE_CAL_DATE                    2025-01-03',
                                          'MODULE_CAL_DATE                    {}'.format(current_date))
        new_content = new_content.replace('2C:16:BD:E8:2E:6C', mac0)
        new_content = new_content.replace('2C:16:BD:E8:2E:6D', mac1)
        new_content = new_content.replace('2C:16:BD:E8:2E:6E', mac2)
        new_content = new_content.replace('2C:16:BD:E8:2E:6F', mac3)
        new_content = new_content.replace('2C:16:BD:E8:2E:70', mac4)
        file.seek(0)
        file.write(new_content)
        file.close()
        logging.info('done SCC MFG File')

        self.com.send_data(data='cd /usr/local/bin', expect='sh-5.2#')
        self.com.send_data(data=' ln -s /usr/bin/scp.openssh /usr/bin/scp', expect='sh-5.2#')
        self.com.send_data(
            data='killall -9 sshd;rm -rf /usr/local/bin/sshd; ln -s /usr/sbin/sshd  /usr/local/bin/sshd; /usr/local/bin/sshd',
            expect='sh-5.2#', keep_time=3)  # Guo guangjun指令确保scp功能启用
        self.com.send_data(data='ifconfig eth4 {}/16'.format(SCC_Config_IP), expect='sh-5.2#',keep_time=2)
        buffer = self.com.send_data(data='ping -c 5 {}'.format(PC_IP), expect='sh-5.2#')
        if '5 received, 0% packet loss' not in buffer:
            raise Exception

        self.ssh = SCP_COM(hostname=SCC_Config_IP, port=22, username='admin', password='m4X!izP#')
        self.ssh.SCP_folder_to_remote(local_file_path='{}\\LUT\\{}'.format(SN,SCC_File),
                                                 remote_file_path ='/tmp/{}'.format(SCC_File))

        self.ssh.SCP_folder_to_remote(local_file_path='{}\\{}'.format(fw_path, MCC_File),
                                      remote_file_path='/tmp/{}'.format(MCC_File))

        self.ssh.SCP_folder_to_remote(local_file_path='{}\\{}'.format(fw_path, FPGA_File),
                                      remote_file_path='/tmp/{}'.format(FPGA_File))

        self.ssh.SCP_folder_to_remote(local_file_path='{}\\{}'.format(fw_path, CPLD_File),
                                      remote_file_path='/tmp/{}'.format(CPLD_File))


        self.ssh.close()
        logging.info('SCC.conf tranfer OK')
        self.com.send_data(data='/usr/local/bin/api_main board set-scc-mfg /tmp/{}'.format(SCC_File),expect='sh-5.2#')
        logging.info('FW transfer done!')

        logging.info('SCC MCC FW transfer done!')
        self.com.send_data(data='/usr/local/bin/api_main mcc upgrade /tmp/{}'.format(MCC_File),
                           expect='sh-5.2#', timeout=600)
        self.com.send_data(data='/usr/local/bin/api_main mcc reset 1',
                           expect='sh-5.2#', timeout=600)
        logging.info('SCC MCC FW Update done!')

        logging.info('SCC FPGA FW transfer done!')
        self.com.send_data(data='/usr/local/bin/api_main  logic upgrade 0 /tmp/{}'.format(FPGA_File),
                           expect='sh-5.2#', timeout=600)
        logging.info('SCC FPGA FW Update done!')

        logging.info('SCC CPLD FW transfer done!')
        self.com.send_data(data='/usr/local/bin/api_main  logic upgrade 1 /tmp/{}'.format(CPLD_File),
                           expect='sh-5.2#', timeout=600)
        logging.info('SCC CPLD FW Update done!')

        self.com.send_data(data='reboot\r', keep_time=160)
        # 处理保存xml结果数据


    def test3_SCC_Info_Check(self):
        tas = ITAS()
        result = tas.GetFWStandardPath(strPN=PN, strFWBOMPN='', strFWStandardPath='', strOutErrMsg='')
        fw_path = result[0]
        config = configparser.ConfigParser()
        config.read('{}\\FW&HW Version Config.ini'.format(fw_path), encoding="utf-8-sig")

        FPGA_Ver = config.get('FW_Version', 'SCC_FPGA_SH52_VER')
        CPLD_Ver = config.get('FW_Version', 'SCC_CPLD_SH52_VER')
        MCC_Ver = config.get('FW_Version', 'MCC_BUNDLE_VER')

        logging.info('below is CPLD Version--------')
        buffer=self.com.send_data(data='/usr/local/bin/api_main logic read 0 1000 4', expect='sh-5.2#')
        if CPLD_Ver not in buffer:
            raise Exception

        logging.info('below is FPGA Version--------')
        buffer=self.com.send_data(data='/usr/local/bin/api_main logic read 0 0x4 4', expect='sh-5.2#')
        if FPGA_Ver not in buffer:
            raise Exception


        logging.info('below is MCC--------')
        buffer=self.com.send_data(data='/usr/local/bin/api_main mcc mfg', expect='sh-5.2#')
        if MCC_Ver not in buffer:
            raise Exception


        logging.info('below is SCC--------')
        buffer=self.com.send_data(data='/usr/local/bin/api_main board get-scc-mfg', expect='sh-5.2#')
        if 'MODULE_SN                          {}'.format(SN) not in buffer:
            raise Exception
        if 'MODULE_PART_NO                     {}'.format(PN) not in buffer:
            raise Exception

        # 处理保存xml结果数据


if __name__ =="__main__":
    test3_SCC_Info_Check()   



















