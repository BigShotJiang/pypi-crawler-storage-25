
import sys
import os

script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
sys.path.append(script_dir)

from common.MainTestPro import MainTestPro

def DemoSub(a,b):
    c =  a + b
    print(c)
    return c


def StartTP():
    g_tp = MainTestPro()
    g_tp.InitLog()
    res = g_tp.Run()
    return res
       
# def ShowDialog():
#     print('ShowDialog')

# def StopTP():
#     print('StopTP')   
 

if __name__ =="__main__":
    StartTP()   