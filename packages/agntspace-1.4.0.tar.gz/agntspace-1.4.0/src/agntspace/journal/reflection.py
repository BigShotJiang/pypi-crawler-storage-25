"""Reflection: synthesize journal entries into long-term memory.

ARCHITECTURE INVARIANT: Reflection files are ALWAYS produced when requested.
If journal data is missing, the reflection notes the gap. LLM failures are
retried indefinitely — the system never gives up. Model attribution is
included in every generated file.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

# Retry delays — exponential backoff capped at 5 minutes
_RETRY_DELAYS = [10, 30, 60, 120, 300]


def _retry_delay(attempt: int) -> int:
    idx = min(attempt - 1, len(_RETRY_DELAYS) - 1)
    return _RETRY_DELAYS[idx]


def _get_model_name(agent: object | None) -> str:
    """Extract the current model name from the agent's LLM provider."""
    try:
        if agent and hasattr(agent, "_llm") and hasattr(agent._llm, "_model"):
            return agent._llm._model
    except Exception:
        pass
    return "unknown"


class ReflectionService:
    """Runs daily and weekly reflection cycles."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        llm: object | None = None,
        memory_engine: object | None = None,
        skill_loader: object | None = None,
        model_router: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._llm = llm  # kept for backwards compat, no longer used
        self._memory_engine = memory_engine
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._agent: object | None = None  # injected post-hoc from main.py

    # ── LLM call with infinite retry ───────────────────────────────

    async def _call_agent(self, task: str, context: str, label: str) -> str:
        """Call the agent, retrying indefinitely until content is produced.

        Post-processes output to ensure clean markdown.
        """
        from agntspace.automation.daily_cycle import sanitize_llm_output

        attempt = 0
        while True:
            attempt += 1

            if not self._agent:
                delay = _retry_delay(attempt)
                log.warning("[%s] Agent not available — waiting %ds before retry (attempt %d)", label, delay, attempt)
                await asyncio.sleep(delay)
                continue

            try:
                result = await self._agent.process_task(task=task, context=context)
                if result and result.strip():
                    clean = sanitize_llm_output(result)
                    if clean and clean.strip():
                        if attempt > 1:
                            log.warning("[%s] Succeeded on attempt %d", label, attempt)
                        return clean
                log.warning("[%s] Agent returned empty response (attempt %d)", label, attempt)
            except Exception as exc:
                log.warning("[%s] LLM call failed (attempt %d): %s", label, attempt, exc)

            delay = _retry_delay(attempt)
            log.warning("[%s] Retrying in %ds...", label, delay)
            await asyncio.sleep(delay)

    # ── Frontmatter helpers ────────────────────────────────────────

    def _build_frontmatter(
        self,
        title: str,
        date: str,
        file_type: str,
        agent_name: str,
        description: str,
        extra: dict | None = None,
    ) -> str:
        """Build YAML frontmatter with model attribution and generation timestamp."""
        model = _get_model_name(self._agent)
        now = datetime.now(UTC)
        generated_at = now.strftime("%H:%M UTC")
        lines = [
            "---",
            f'title: "{title}"',
            f'date: "{date}"',
            f'generated_at: "{generated_at}"',
            f"type: {file_type}",
            "author: agent",
            f"agent: {agent_name}",
            f'model: "{model}"',
            f'description: "{description}"',
        ]
        if extra:
            for k, v in extra.items():
                if isinstance(v, bool):
                    lines.append(f"{k}: {'true' if v else 'false'}")
                elif isinstance(v, str):
                    lines.append(f"{k}: {v}")
                else:
                    lines.append(f"{k}: {v}")
        lines.append("---")
        return "\n".join(lines)

    def _is_fallback_file(self, path: str) -> bool:
        """Check if a file is a fallback placeholder (should be regenerated)."""
        try:
            if self._reader.exists(path):
                doc = self._reader.read(path)
                return doc.metadata.get("generation_failed", False) is True
        except Exception:
            pass
        return False

    # ── Daily reflection ───────────────────────────────────────────

    async def run_daily_reflection(self, date: str | None = None) -> dict:
        """Run daily reflection. Always produces a file.

        If journal is missing, notes the gap and works with whatever is available.
        Retries indefinitely until LLM content is produced.
        """
        if not date:
            date = datetime.now(UTC).strftime("%Y-%m-%d")

        reflection_path = f"journal/daily-reflection_{date}.md"
        label = f"Daily reflection ({date})"

        # Skip if already generated successfully (not a fallback)
        if self._reader.exists(reflection_path) and not self._is_fallback_file(reflection_path):
            log.warning("[%s] Already exists, skipping", label)
            doc = self._reader.read(reflection_path)
            return {
                "date": date,
                "reflection": doc.content,
                "status": doc.metadata.get("status", "pending"),
                "path": reflection_path,
            }

        # Build context — gather whatever is available
        context_parts: list[str] = []
        has_journal = False

        journal_path = f"journal/{date}.md"
        if self._reader.exists(journal_path):
            try:
                journal = self._reader.read(journal_path)
                if len(journal.content.strip()) > 10:
                    context_parts.append(f"# User Journal\n\n{journal.content}")
                    has_journal = True
                else:
                    context_parts.append("# User Journal\n\n(Journal exists but has minimal content.)")
            except Exception as exc:
                context_parts.append(f"# User Journal\n\n(Failed to read journal: {exc})")
                log.warning("[%s] Failed to read journal: %s", label, exc)
        else:
            context_parts.append("# User Journal\n\n(No journal entry for this date.)")

        # Agent observations
        agent_obs_path = f"journal/agent-observations_{date}.md"
        if self._reader.exists(agent_obs_path):
            try:
                agent_obs = self._reader.read(agent_obs_path)
                context_parts.append(f"# Agent Observations (supplementary)\n\n{agent_obs.content}")
            except Exception:
                pass

        # EOD report
        eod_path = f"journal/eod-report_{date}.md"
        if self._reader.exists(eod_path):
            try:
                eod_doc = self._reader.read(eod_path)
                if not eod_doc.metadata.get("generation_failed", False):
                    context_parts.append(f"# EOD Report\n\n{eod_doc.content}")
            except Exception:
                pass

        # Morning briefing
        briefing_path = f"journal/morning-briefing_{date}.md"
        if self._reader.exists(briefing_path):
            try:
                briefing_doc = self._reader.read(briefing_path)
                if not briefing_doc.metadata.get("generation_failed", False):
                    context_parts.append(f"# Morning Briefing\n\n{briefing_doc.content}")
            except Exception:
                pass

        context = "\n\n---\n\n".join(context_parts)

        availability_note = ""
        if not has_journal:
            availability_note = (
                "\nNOTE: No user journal entry was found for this date. "
                "Base the reflection on agent observations, EOD report, and briefing if available. "
                "If nothing is available, produce a minimal reflection noting the gap.\n"
            )

        task_instruction = (
            f"Produce a daily reflection for {date} using EXACTLY this markdown format:\n\n"
            "## Summary\n"
            "2-3 sentences on what happened today — the big picture.\n\n"
            "## Key Decisions\n"
            "- **Decision** — reasoning behind it\n"
            "- (bullet list, or *No decisions recorded.* if empty)\n\n"
            "## Learnings\n"
            "- Thing worth remembering long-term\n"
            "- (bullet list, or *No new learnings.* if empty)\n\n"
            "## Suggested Memory Updates\n"
            "- Add: specific fact to add to long-term memory\n"
            "- Update: correction to existing memory\n"
            "- (or *No memory updates.* if nothing new)\n\n"
            "---\n"
            f"{availability_note}"
            "RULES: Output ONLY valid markdown. Use ## headers exactly as shown. "
            "Use bullet lists (- item) for lists. Focus on what's worth remembering "
            "long-term, not transient details. Never output JSON."
        )

        reflection_content = await self._call_agent(task_instruction, context, label)

        fm = self._build_frontmatter(
            f"Daily Reflection — {date}", date, "daily_reflection", "philosopher",
            "Daily reflection synthesized by the philosopher agent — patterns noticed, key decisions, learnings worth remembering, and memory update suggestions.",
            extra={"status": "pending"},
        )
        self._writer.write(reflection_path, f"{fm}\n\n{reflection_content}")
        log.warning("[%s] Generated successfully", label)
        return {
            "date": date,
            "reflection": reflection_content,
            "status": "pending",
            "path": reflection_path,
        }

    # ── Weekly reflection ──────────────────────────────────────────

    async def run_weekly_reflection(self, week_end: str | None = None) -> dict:
        """Run weekly reflection. Always produces a file.

        Works with whatever data is available for the past 7 days.
        Retries indefinitely until LLM content is produced.
        """
        from datetime import timedelta

        if not week_end:
            week_end = datetime.now(UTC).strftime("%Y-%m-%d")

        end_date = datetime.strptime(week_end, "%Y-%m-%d")
        week_num = end_date.isocalendar()[1]
        week_label = f"{end_date.year}-W{week_num:02d}"
        reflection_path = f"journal/weekly-reflection_{week_label}.md"
        label = f"Weekly reflection ({week_label})"

        # Skip if already generated successfully
        if self._reader.exists(reflection_path) and not self._is_fallback_file(reflection_path):
            log.warning("[%s] Already exists, skipping", label)
            doc = self._reader.read(reflection_path)
            return {
                "week": week_label,
                "reflection": doc.content,
                "status": doc.metadata.get("status", "pending"),
                "path": reflection_path,
            }

        # Gather all available daily content for the week
        day_entries: list[str] = []
        days_with_data = 0

        for i in range(7):
            d = end_date - timedelta(days=i)
            date_str = d.strftime("%Y-%m-%d")
            day_parts: list[str] = [f"## {date_str}"]
            has_content = False

            # User journal
            journal_path = f"journal/{date_str}.md"
            if self._reader.exists(journal_path):
                try:
                    doc = self._reader.read(journal_path)
                    if doc.content.strip():
                        day_parts.append(doc.content)
                        has_content = True
                except Exception:
                    pass

            # Agent observations
            agent_path = f"journal/agent-observations_{date_str}.md"
            if self._reader.exists(agent_path):
                try:
                    agent_doc = self._reader.read(agent_path)
                    day_parts.append(f"### Agent Observations\n{agent_doc.content}")
                    has_content = True
                except Exception:
                    pass

            # EOD report
            eod_path = f"journal/eod-report_{date_str}.md"
            if self._reader.exists(eod_path):
                try:
                    eod_doc = self._reader.read(eod_path)
                    if not eod_doc.metadata.get("generation_failed", False):
                        day_parts.append(f"### EOD Report\n{eod_doc.content}")
                        has_content = True
                except Exception:
                    pass

            # Daily reflection
            refl_path = f"journal/daily-reflection_{date_str}.md"
            if self._reader.exists(refl_path):
                try:
                    refl_doc = self._reader.read(refl_path)
                    if not refl_doc.metadata.get("generation_failed", False):
                        day_parts.append(f"### Daily Reflection\n{refl_doc.content}")
                        has_content = True
                except Exception:
                    pass

            if has_content:
                days_with_data += 1
            else:
                day_parts.append("(No data available for this day.)")

            day_entries.append("\n\n".join(day_parts))

        combined = "\n\n---\n\n".join(reversed(day_entries))

        availability_note = ""
        if days_with_data == 0:
            availability_note = (
                "\nNOTE: No journal data was found for any day this week. "
                "Produce a minimal weekly reflection noting the gap and suggesting "
                "the user start journaling.\n"
            )
        elif days_with_data < 4:
            availability_note = (
                f"\nNOTE: Only {days_with_data}/7 days had data. "
                "Note the sparse coverage and work with what's available.\n"
            )

        task_instruction = (
            f"Produce a weekly reflection for the week ending {week_end} "
            "using EXACTLY this markdown format:\n\n"
            "## Week Summary\n"
            "What was the overall theme or focus this week? (2-3 sentences)\n\n"
            "## Progress\n"
            "- What moved forward\n"
            "- What stalled or got blocked\n\n"
            "## Patterns\n"
            "- Positive behavioral patterns observed\n"
            "- Concerning patterns to watch\n\n"
            "## Goal Check\n"
            "- Goal that needs attention — why\n"
            "- (or *All goals on track.* if none need attention)\n\n"
            "## Key Takeaways\n"
            "- Takeaway to carry into next week\n"
            "- (bullet list of actionable insights)\n\n"
            "---\n"
            f"{availability_note}"
            "RULES: Output ONLY valid markdown. Use ## headers exactly as shown. "
            "Use bullet lists (- item) for lists. Focus on patterns and progress, "
            "not daily details. Never output JSON."
        )

        response_content = await self._call_agent(task_instruction, combined, label)

        fm = self._build_frontmatter(
            f"Weekly Reflection — {week_label}", end_date.strftime("%Y-%m-%d"),
            "weekly_reflection", "philosopher",
            "Weekly reflection synthesized by the philosopher agent — recurring patterns, goal progress, evolution of priorities, and key takeaways from the past 7 days.",
            extra={"status": "pending"},
        )
        self._writer.write(reflection_path, f"{fm}\n\n{response_content}")
        log.warning("[%s] Generated successfully (%d days with data)", label, days_with_data)

        # Trigger layered memory compaction
        if self._memory_engine and hasattr(self._memory_engine, "compact_memory"):
            try:
                await self._memory_engine.compact_memory()
                log.warning("All memory layers compacted during weekly reflection")
            except Exception as exc:
                log.warning("Memory compaction failed during weekly reflection: %s", exc)

        return {
            "week": week_label,
            "reflection": response_content,
            "status": "pending",
            "path": reflection_path,
        }

    # ── Approve / list ─────────────────────────────────────────────

    async def approve_reflection(self, path: str) -> None:
        """Approve a reflection and apply its MEMORY.md updates."""
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Reflection not found: {path}")

        doc = self._reader.read(path)

        # Update status to approved
        content = doc.raw.replace("status: pending", "status: approved")
        self._writer.write(path, content)

        # Extract suggested MEMORY.md updates and append them
        memory_updates = self._extract_memory_updates(doc.content)
        if memory_updates and self._reader.exists("agnt-memory/MEMORY.md"):
            self._writer.append("agnt-memory/MEMORY.md", "\n" + memory_updates)
            log.warning("MEMORY.md updated from reflection: %s", path)

    def list_reflections(self, limit: int = 20) -> list[dict]:
        """List reflection files (checks journal/ and legacy agnt-reflections/)."""
        results = []
        # New location: journal/
        for f in self._reader.list_files("journal", "*reflection*.md"):
            try:
                doc = self._reader.read(f"journal/{f.name}")
                results.append({
                    "path": f"journal/{f.name}",
                    "title": doc.metadata.get("title", f.stem),
                    "status": doc.metadata.get("status", "unknown"),
                })
            except Exception:
                continue
        # Legacy location: agnt-reflections/
        try:
            for f in self._reader.list_files("agnt-reflections", "*.md"):
                try:
                    doc = self._reader.read(f"agnt-reflections/{f.name}")
                    results.append({
                        "path": f"agnt-reflections/{f.name}",
                        "title": doc.metadata.get("title", f.stem),
                        "status": doc.metadata.get("status", "unknown"),
                    })
                except Exception:
                    continue
        except Exception:
            pass  # agnt-reflections/ may not exist
        results.sort(key=lambda x: x["path"], reverse=True)
        return results[:limit]

    @staticmethod
    def _extract_memory_updates(content: str) -> str:
        """Extract suggested MEMORY.md updates from reflection content."""
        lines = []
        in_section = False
        for line in content.split("\n"):
            if "Suggested MEMORY.md" in line or "Memory Updates" in line:
                in_section = True
                continue
            if in_section:
                if line.startswith("##"):
                    break
                if line.strip().startswith("- "):
                    lines.append(line.strip())
        return "\n".join(lines)
