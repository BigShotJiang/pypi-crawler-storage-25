"""Global bibliography registry for all knowledge bases.

Stores structured bibliographic metadata (author, title, date, publisher, URL)
for every ingested source across all KBs. Supports BibTeX and RIS export.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from typing import Any

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

REGISTRY_PATH = "agnt-memory/bibliography.json"


class BibliographyService:
    """Global bibliography registry — one registry across all KBs."""

    def __init__(self, vault: VaultReader, writer: VaultWriter) -> None:
        self._vault = vault
        self._writer = writer
        self._lock = threading.Lock()

    # ── persistence ──────────────────────────────────────────────

    def _load(self) -> list[dict[str, Any]]:
        try:
            doc = self._vault.read(REGISTRY_PATH)
            return json.loads(doc.content) if doc.content.strip() else []
        except Exception:
            return []

    def _save(self, entries: list[dict[str, Any]]) -> None:
        self._writer.write(REGISTRY_PATH, json.dumps(entries, indent=2, ensure_ascii=False))

    # ── cite key generation ──────────────────────────────────────

    @staticmethod
    def _generate_cite_key(
        title: str,
        authors: list[str],
        date: str,
        existing_keys: set[str],
    ) -> str:
        # Extract year
        year_match = re.search(r"(\d{4})", date or "")
        year = year_match.group(1) if year_match else "nd"

        # First author surname or first word of title
        if authors and authors[0] and authors[0].lower() != "unknown":
            # Take last word as surname (handles "First Last" and "Last, First")
            name = authors[0].split(",")[0].strip() if "," in authors[0] else authors[0].split()[-1]
            prefix = re.sub(r"[^a-z]", "", name.lower())[:12]
        else:
            words = re.findall(r"[a-z]+", title.lower())
            # Skip common words
            stop = {"the", "a", "an", "of", "in", "on", "for", "and", "to", "from", "with"}
            sig = [w for w in words if w not in stop]
            prefix = (sig[0] if sig else (words[0] if words else "source"))[:12]

        # First significant word of title for disambiguation
        title_words = re.findall(r"[a-z]+", title.lower())
        stop = {"the", "a", "an", "of", "in", "on", "for", "and", "to", "from", "with", "is", "are"}
        sig_title = [w for w in title_words if w not in stop]
        suffix = (sig_title[0] if sig_title else "")[:10]

        base = f"{prefix}{year}{suffix}"
        key = base
        i = 1
        while key in existing_keys:
            key = f"{base}{chr(96 + i)}" if i <= 26 else f"{base}{i}"
            i += 1
        return key

    # ── CRUD ─────────────────────────────────────────────────────

    def list_entries(
        self,
        kb: str | None = None,
        source_type: str | None = None,
    ) -> list[dict[str, Any]]:
        entries = self._load()
        if kb:
            entries = [e for e in entries if e.get("kb_slug") == kb]
        if source_type:
            entries = [e for e in entries if e.get("source_type") == source_type]
        return entries

    def get_entry(self, cite_key: str) -> dict[str, Any] | None:
        for e in self._load():
            if e.get("cite_key") == cite_key:
                return e
        return None

    def add_entry(self, entry: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            entries = self._load()
            existing_keys = {e["cite_key"] for e in entries}
            if "cite_key" not in entry or not entry["cite_key"]:
                entry["cite_key"] = self._generate_cite_key(
                    entry.get("title", ""),
                    entry.get("authors", []),
                    entry.get("date", ""),
                    existing_keys,
                )
            entries.append(entry)
            self._save(entries)
        return entry

    def update_entry(self, cite_key: str, updates: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock:
            entries = self._load()
            for e in entries:
                if e.get("cite_key") == cite_key:
                    e.update(updates)
                    self._save(entries)
                    return e
        return None

    def delete_entry(self, cite_key: str) -> bool:
        with self._lock:
            entries = self._load()
            before = len(entries)
            entries = [e for e in entries if e.get("cite_key") != cite_key]
            if len(entries) < before:
                self._save(entries)
                return True
        return False

    def find_by_source(self, source_file: str, kb_slug: str) -> dict[str, Any] | None:
        for e in self._load():
            if e.get("source_file") == source_file and e.get("kb_slug") == kb_slug:
                return e
        return None

    # ── ingest integration ───────────────────────────────────────

    def register_from_ingest(self, metadata: dict[str, Any]) -> dict[str, Any]:
        """Create or update a bibliography entry from ingest metadata."""
        existing = self.find_by_source(
            metadata.get("source_file", ""),
            metadata.get("kb_slug", ""),
        )
        if existing:
            # Update with new metadata (keep cite_key stable)
            updates = {k: v for k, v in metadata.items() if v and k != "cite_key"}
            return self.update_entry(existing["cite_key"], updates) or existing
        return self.add_entry(metadata)

    # ── export formats ───────────────────────────────────────────

    @staticmethod
    def export_bibtex(entries: list[dict[str, Any]]) -> str:
        type_map = {
            "paper": "article",
            "article": "article",
            "data": "misc",
            "image": "misc",
            "code": "misc",
            "chat_history": "misc",
            "export": "misc",
            "transcript": "misc",
        }
        lines: list[str] = []
        for e in entries:
            bib_type = type_map.get(e.get("source_type", ""), "misc")
            key = e.get("cite_key", "unknown")
            lines.append(f"@{bib_type}{{{key},")

            # Authors
            authors = e.get("authors", [])
            if authors and authors != ["unknown"]:
                lines.append(f"  author = {{{' and '.join(authors)}}},")

            title = e.get("title", "")
            if title:
                lines.append(f"  title = {{{title}}},")

            date = e.get("date", "")
            year_match = re.search(r"(\d{4})", date)
            if year_match:
                lines.append(f"  year = {{{year_match.group(1)}}},")

            url = e.get("url", "")
            if url:
                lines.append(f"  url = {{{url}}},")

            publisher = e.get("publisher", "")
            if publisher and publisher != "unknown":
                lines.append(f"  publisher = {{{publisher}}},")

            doi = e.get("doi", "")
            if doi:
                lines.append(f"  doi = {{{doi}}},")

            kb = e.get("kb_slug", "")
            if kb:
                lines.append(f"  note = {{Ingested from KB: {kb}}},")

            lines.append("}")
            lines.append("")
        return "\n".join(lines)

    @staticmethod
    def export_ris(entries: list[dict[str, Any]]) -> str:
        type_map = {
            "paper": "JOUR",
            "article": "JOUR",
            "data": "DATA",
            "image": "FIGURE",
            "code": "COMP",
            "chat_history": "GEN",
            "export": "GEN",
            "transcript": "GEN",
        }
        lines: list[str] = []
        for e in entries:
            ris_type = type_map.get(e.get("source_type", ""), "GEN")
            lines.append(f"TY  - {ris_type}")

            for author in e.get("authors", []):
                if author and author != "unknown":
                    lines.append(f"AU  - {author}")

            title = e.get("title", "")
            if title:
                lines.append(f"TI  - {title}")

            date = e.get("date", "")
            year_match = re.search(r"(\d{4})", date)
            if year_match:
                lines.append(f"PY  - {year_match.group(1)}")

            url = e.get("url", "")
            if url:
                lines.append(f"UR  - {url}")

            publisher = e.get("publisher", "")
            if publisher and publisher != "unknown":
                lines.append(f"PB  - {publisher}")

            doi = e.get("doi", "")
            if doi:
                lines.append(f"DO  - {doi}")

            kb = e.get("kb_slug", "")
            if kb:
                lines.append(f"N1  - Ingested from KB: {kb}")

            lines.append("ER  - ")
            lines.append("")
        return "\n".join(lines)

    def stats(self) -> dict[str, Any]:
        entries = self._load()
        by_kb: dict[str, int] = {}
        by_type: dict[str, int] = {}
        for e in entries:
            kb = e.get("kb_slug", "unknown")
            by_kb[kb] = by_kb.get(kb, 0) + 1
            st = e.get("source_type", "unknown")
            by_type[st] = by_type.get(st, 0) + 1
        return {
            "total": len(entries),
            "by_kb": by_kb,
            "by_type": by_type,
        }
