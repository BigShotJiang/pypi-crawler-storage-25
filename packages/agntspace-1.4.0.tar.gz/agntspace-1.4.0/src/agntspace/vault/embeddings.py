"""Vector embeddings for semantic vault search.

Uses FastEmbed (all-MiniLM-L6-v2) for local embeddings — never sent to cloud.
Hybrid search: 70% vector similarity + 30% keyword (FTS5).
Stored in SQLite alongside FTS5 index.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime

import aiosqlite

from agntspace.vault.reader import VaultReader

log = logging.getLogger(__name__)

EMBEDDING_MODEL = "BAAI/bge-small-en-v1.5"
EMBEDDING_DIM = 384
CHUNK_SIZE = 500  # characters per chunk
CHUNK_OVERLAP = 50


class VaultEmbeddings:
    """Semantic search over vault using local embeddings."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        vault: VaultReader,
        exclude_dirs: list[str] | None = None,
    ) -> None:
        self._db = db
        self._vault = vault
        self._exclude_dirs = set(exclude_dirs or ["finances", "health"])
        self._model = None  # lazy load

    def _get_model(self):  # noqa: ANN202
        """Lazy-load the embedding model (downloads on first use, ~80MB)."""
        if self._model is None:
            try:
                from fastembed import TextEmbedding
            except ImportError as exc:
                raise ImportError(
                    "fastembed is required for semantic search. "
                    "Install it with: pip install agntspace[embeddings]"
                ) from exc
            self._model = TextEmbedding(model_name=EMBEDDING_MODEL)
            log.info("Embedding model loaded: %s", EMBEDDING_MODEL)
        return self._model

    async def init_schema(self) -> None:
        """Create embedding tables if they don't exist."""
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS vault_embeddings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                chunk_text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                content_hash TEXT NOT NULL,
                indexed_at TEXT NOT NULL,
                UNIQUE(path, chunk_index)
            );
            CREATE INDEX IF NOT EXISTS idx_emb_path ON vault_embeddings(path);
        """)
        await self._db.commit()

    async def index_vault(self) -> int:
        """Index all vault files with embeddings. Returns count indexed."""
        model = self._get_model()
        files = self._vault.list_files(pattern="**/*.md")
        indexed = 0

        for file_path in files:
            relative = str(file_path.relative_to(self._vault.vault_dir)).replace("\\", "/")

            if any(relative.startswith(f"{d}/") for d in self._exclude_dirs):
                continue

            try:
                doc = self._vault.read(relative)
            except Exception:
                continue

            content_hash = hashlib.md5(doc.raw.encode()).hexdigest()

            # Check if already indexed with same hash
            cursor = await self._db.execute(
                "SELECT content_hash FROM vault_embeddings WHERE path = ? LIMIT 1",
                (relative,),
            )
            row = await cursor.fetchone()
            if row and row[0] == content_hash:
                continue

            # Delete old embeddings for this file
            await self._db.execute("DELETE FROM vault_embeddings WHERE path = ?", (relative,))

            # Chunk the content
            chunks = self._chunk_text(doc.content)
            if not chunks:
                continue

            # Generate embeddings
            embeddings = list(model.embed(chunks))

            # Store
            now = datetime.now(UTC).isoformat()
            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                emb_bytes = embedding.tobytes()
                await self._db.execute(
                    "INSERT INTO vault_embeddings (path, chunk_index, chunk_text, embedding, content_hash, indexed_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (relative, i, chunk, emb_bytes, content_hash, now),
                )

            indexed += 1

        await self._db.commit()
        log.info("Vault embeddings indexed: %d files", indexed)
        return indexed

    async def search(self, query: str, limit: int = 10) -> list[dict]:
        """Semantic search using vector similarity.

        Returns results ranked by cosine similarity.
        """
        import numpy as np

        if not query.strip():
            return []

        model = self._get_model()
        query_embedding = list(model.embed([query]))[0]

        # Fetch all embeddings (for small vaults this is fine;
        # for large vaults, use sqlite-vec extension)
        cursor = await self._db.execute(
            "SELECT path, chunk_index, chunk_text, embedding FROM vault_embeddings"
        )
        rows = await cursor.fetchall()

        if not rows:
            return []

        # Compute cosine similarity
        results = []
        query_norm = np.linalg.norm(query_embedding)

        for row in rows:
            path, chunk_idx, chunk_text, emb_bytes = row
            embedding = np.frombuffer(emb_bytes, dtype=np.float32)
            emb_norm = np.linalg.norm(embedding)

            if query_norm == 0 or emb_norm == 0:
                continue

            similarity = np.dot(query_embedding, embedding) / (query_norm * emb_norm)
            results.append({
                "path": path,
                "chunk_index": chunk_idx,
                "text": chunk_text,
                "score": float(similarity),
            })

        # Sort by similarity descending
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    async def hybrid_search(
        self, query: str, limit: int = 10, vector_weight: float = 0.7
    ) -> list[dict]:
        """Hybrid search: 70% vector + 30% keyword (FTS5).

        Combines semantic understanding with exact keyword matching.
        """
        from agntspace.vault.search import VaultSearch

        # Vector results
        vector_results = await self.search(query, limit=limit * 2)

        # Keyword results (FTS5)
        fts_search = VaultSearch(self._db, self._vault)
        keyword_results = await fts_search.search(query, limit=limit * 2)

        # Normalize scores
        max_vec = max((r["score"] for r in vector_results), default=1.0)
        max_kw = max((abs(r.get("score", 0)) for r in keyword_results), default=1.0)

        # Merge by path
        merged: dict[str, dict] = {}

        for r in vector_results:
            key = f"{r['path']}:{r.get('chunk_index', 0)}"
            merged[key] = {
                "path": r["path"],
                "text": r["text"],
                "vector_score": r["score"] / max_vec if max_vec else 0,
                "keyword_score": 0,
            }

        for r in keyword_results:
            key = f"{r['path']}:0"
            if key in merged:
                merged[key]["keyword_score"] = abs(r.get("score", 0)) / max_kw if max_kw else 0
            else:
                merged[key] = {
                    "path": r["path"],
                    "text": r.get("snippet", ""),
                    "vector_score": 0,
                    "keyword_score": abs(r.get("score", 0)) / max_kw if max_kw else 0,
                }

        # Compute hybrid score
        results = []
        for item in merged.values():
            hybrid = (vector_weight * item["vector_score"]) + ((1 - vector_weight) * item["keyword_score"])
            results.append({
                "path": item["path"],
                "text": item["text"],
                "score": hybrid,
                "vector_score": item["vector_score"],
                "keyword_score": item["keyword_score"],
            })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    @staticmethod
    def _chunk_text(text: str) -> list[str]:
        """Split text into overlapping chunks."""
        if len(text) <= CHUNK_SIZE:
            return [text] if text.strip() else []

        chunks = []
        start = 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk.strip())
            start = end - CHUNK_OVERLAP

        return chunks
