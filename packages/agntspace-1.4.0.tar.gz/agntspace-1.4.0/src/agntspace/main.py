"""FastAPI application factory and lifespan management."""

from __future__ import annotations

import json
import logging
import re
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from agntspace.agent.agent import Agent
from agntspace.agent.orchestrator import Orchestrator
from agntspace.api.routes.audit import router as audit_router
from agntspace.api.routes.autopilot import router as autopilot_router
from agntspace.api.routes.bibliography import router as bibliography_router
from agntspace.api.routes.canvas import router as canvas_router
from agntspace.api.routes.channels import router as channels_router
from agntspace.api.routes.chat import router as chat_router
from agntspace.api.routes.contract import router as contract_router
from agntspace.api.routes.costs import router as costs_router
from agntspace.api.routes.cron import router as cron_router
from agntspace.api.routes.daily import router as daily_router
from agntspace.api.routes.domains import router as domains_router
from agntspace.api.routes.email import router as email_router
from agntspace.api.routes.emergency import router as emergency_router
from agntspace.api.routes.goals import router as goals_router
from agntspace.api.routes.graph import router as graph_router
from agntspace.api.routes.guardian import router as guardian_router
from agntspace.api.routes.health import router as health_router
from agntspace.api.routes.heartbeat import router as heartbeat_router
from agntspace.api.routes.integrations import router as integrations_router
from agntspace.api.routes.journal import router as journal_router
from agntspace.api.routes.kb import router as kb_router
from agntspace.api.routes.memory import router as memory_router
from agntspace.api.routes.notes import router as notes_router
from agntspace.api.routes.onboarding import router as onboarding_router
from agntspace.api.routes.orchestrator import router as orchestrator_router
from agntspace.api.routes.pairing import router as pairing_router
from agntspace.api.routes.projects import router as projects_router
from agntspace.api.routes.reflection import router as reflection_router
from agntspace.api.routes.search import router as search_router
from agntspace.api.routes.settings import router as settings_router
from agntspace.api.routes.simulate import router as simulate_router
from agntspace.api.routes.skills import router as skills_router
from agntspace.api.routes.sync import router as sync_router
from agntspace.api.routes.tasks import router as tasks_router
from agntspace.api.routes.trust import router as trust_router
from agntspace.api.routes.vault import router as vault_router
from agntspace.api.routes.wiki import router as wiki_router
from agntspace.api.routes.work_queue import router as work_queue_router
from agntspace.api.websocket.canvas import CanvasService, ws_canvas_handler
from agntspace.api.websocket.handler import ws_chat_handler
from agntspace.automation.autopilot import AutopilotService
from agntspace.automation.cron import CronScheduler
from agntspace.automation.daily_cycle import DailyCycle
from agntspace.automation.heartbeat import Heartbeat
from agntspace.automation.scheduler import TaskScheduler
from agntspace.channels.manager import ChannelManager
from agntspace.coach.service import CoachService
from agntspace.domains.base import DOMAIN_NAMES, DomainService
from agntspace.infra.config import get_settings
from agntspace.infra.credentials import CredentialStore
from agntspace.infra.database import get_db, init_schema
from agntspace.infra.logging import setup_logging
from agntspace.infra.settings_service import SettingsService
from agntspace.integrations.email_client import EmailIntegration
from agntspace.integrations.gcal import GCalIntegration
from agntspace.integrations.github import GitHubIntegration
from agntspace.integrations.gmail import GmailIntegration
from agntspace.integrations.manager import IntegrationManager
from agntspace.journal.reflection import ReflectionService
from agntspace.journal.service import JournalService
from agntspace.llm.factory import get_provider
from agntspace.mcp.client import MCPClientManager
from agntspace.memory.conversation import ConversationMemory
from agntspace.memory.engine import MemoryEngine
from agntspace.memory.graph import KnowledgeGraph
from agntspace.security.audit import AuditTrail
from agntspace.security.contract import ContractEnforcer
from agntspace.security.guardian import GuardianService
from agntspace.skills.loader import SkillLoader
from agntspace.skillschool.service import SkillSchoolService
from agntspace.tasks.service import TaskService
from agntspace.trust.service import TrustService
from agntspace.vault.reader import VaultReader
from agntspace.vault.search import VaultSearch
from agntspace.vault.sync import VaultSync
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


def _sync_contract_with_config(contract, vault, writer, settings):
    """Keep CONTRACT.md privacy mode in sync with config.toml on startup."""
    rules = contract.rules
    cfg_mode = settings.llm.mode  # "cloud" or "local"

    if rules.privacy_mode == cfg_mode:
        return  # already in sync

    contract_path = vault.resolve_identity_path("CONTRACT.md")
    try:
        doc = vault.read(contract_path)
    except Exception:
        return
    content = doc.raw

    content = re.sub(
        r"(\*\*Mode\*\*:\s*)\w+", rf"\g<1>{cfg_mode}", content, count=1,
    )
    log.info("Contract privacy mode synced: %s → %s", rules.privacy_mode, cfg_mode)

    writer.write(contract_path, content, versioned=False)
    contract.reload()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: load settings, init DB, create services. Shutdown: close DB."""
    setup_logging()
    settings = get_settings()

    # Initialize i18n with configured locale
    from agntspace.infra.i18n import init as i18n_init
    i18n_init(settings.i18n.locale)

    # app_dir = ~/agntspace/ (fixed — config, creds, db, logs)
    # vault_dir = root_dir/agntspace/ (user data — may be same as app_dir)
    vault_path = settings.vault_dir
    log.debug("App: %s", settings.app_dir)
    log.debug("Root: %s", settings.root_dir)
    log.debug("Vault: %s", vault_path)

    def _step(msg: str) -> None:
        """Print a startup progress step."""
        print(f"  \033[90m{msg}\033[0m", flush=True)

    # Ensure app_dir exists (config, db, logs)
    settings.app_dir.mkdir(parents=True, exist_ok=True)
    settings.log_dir.mkdir(parents=True, exist_ok=True)

    # Ensure vault is fully initialized (dirs, default files)
    from agntspace.setup.init import run_init

    try:
        run_init(vault_dir=settings.root_dir, minimal=True)
    except FileNotFoundError as e:
        print(f"\n  \033[31mError: {e}\033[0m", flush=True)
        print("  This usually means the package was not installed correctly.", flush=True)
        print("  Try: pip install --force-reinstall agntspace\n", flush=True)
        raise SystemExit(1) from e

    # Migrate KB data from app_dir to vault_dir when they differ
    # (happens when user switches to sync/direct mode — old data stays at ~/agntspace/)
    if settings.app_dir != vault_path:
        from agntspace.kb.migrate import migrate_kb_data

        migrate_kb_data(src=settings.app_dir, dest=vault_path)

    _step("Initializing database...")
    db = await get_db(settings.db_path)
    await init_schema(db)

    # Vault
    vault = VaultReader(vault_path)
    writer = VaultWriter(vault_path)

    # Core services
    memory = ConversationMemory(db)
    credential_store = CredentialStore(settings.credentials_path)
    llm = get_provider(settings, credential_store=credential_store)
    journal = JournalService(vault, writer)
    task_service = TaskService(vault, writer)
    trust_service = TrustService(vault, writer)
    contract = ContractEnforcer(vault_path)

    # Sync contract privacy mode + model with actual LLM config
    _sync_contract_with_config(contract, vault, writer, settings)

    # Intelligence layer
    vault_search = VaultSearch(db, vault)
    await vault_search.index_vault()

    # Semantic search (embeddings) — lazy-loaded, won't download model until first query
    from agntspace.vault.embeddings import VaultEmbeddings
    vault_embeddings = VaultEmbeddings(db, vault)
    await vault_embeddings.init_schema()

    _step("Loading skills and agents...")
    skills = SkillLoader(settings.skills_dir)
    skills.load_all()

    # Model router — resolves agent model tiers to specific models based on user's quality profile
    from agntspace.llm.model_router import ModelRouter
    active_provider = settings.llm.local_provider if settings.llm.mode == "local" else settings.llm.cloud_provider
    active_profile = "local" if settings.llm.mode == "local" else settings.llm.quality_profile
    model_router = ModelRouter(
        provider=active_provider,
        profile=active_profile,
        default_model=settings.active_model,
        skills_dir=settings.skills_dir,
    )

    orchestrator = Orchestrator(vault, llm, skill_loader=skills, contract=contract, db=db)
    orchestrator.load_agents()

    from agntspace.projects.service import ProjectService
    project_service = ProjectService(vault, writer)

    reflection_service = ReflectionService(vault, writer, llm, skill_loader=skills, model_router=model_router)  # memory_engine wired below
    coach = CoachService(vault, writer)
    skillschool = SkillSchoolService(vault, writer, task_service, llm)

    # Domains
    domains = {name: DomainService(name, vault, writer) for name in DOMAIN_NAMES}

    # Channels
    channel_manager = ChannelManager()
    # Telegram is registered if bot token is configured
    telegram_token = settings.__dict__.get("telegram_bot_token", "")
    if telegram_token:
        from agntspace.channels.telegram import TelegramChannel

        tg = TelegramChannel(telegram_token)
        channel_manager.register(tg)

    _step("Connecting channels...")
    # WhatsApp: auto-reconnect if a previous session exists
    # Bridge stores session at ~/agntspace/data/whatsapp-session/
    whatsapp_session = settings.app_dir / "data" / "whatsapp-session" / "creds.json"
    if whatsapp_session.exists():
        # Validate session file is readable JSON before attempting reconnect
        session_valid = False
        try:
            import json as _json
            _json.loads(whatsapp_session.read_text(encoding="utf-8"))
            session_valid = True
        except (ValueError, OSError):
            log.warning("WhatsApp session file corrupted — deleting for fresh QR scan")
            whatsapp_session.unlink(missing_ok=True)

        if session_valid:
            from agntspace.channels.whatsapp import WhatsAppChannel

            wa = WhatsAppChannel()
            channel_manager.register(wa)
            try:
                await wa.connect()
                log.debug("WhatsApp auto-reconnected from saved session")
            except Exception:
                log.debug("WhatsApp auto-reconnect failed (may need re-scan)", exc_info=True)

    # Settings service — always at app_dir (fixed ~/agntspace/)
    settings_service = SettingsService(settings.config_path)

    # Vault sync (Obsidian, etc.)
    sync_config = settings_service.get_section("sync")
    vault_sync = VaultSync(
        vault_dir=vault_path,
        external_dir=(
            Path(sync_config["external_path"]) if sync_config.get("external_path") else None
        ),
        sync_folders=sync_config.get("folders"),
        mode=sync_config.get("mode", "off"),
    )

    # Integrations
    integration_manager = IntegrationManager()
    email_integration = EmailIntegration()
    integration_manager.register(email_integration)
    integration_manager.register(GmailIntegration())
    integration_manager.register(GCalIntegration())
    integration_manager.register(GitHubIntegration())

    # Auto-reconnect integrations from saved credentials
    for service_name in credential_store.list_services():
        creds = credential_store.get(service_name)
        if creds:
            try:
                if service_name == "email":
                    await email_integration.connect(creds)
                    log.debug("Auto-reconnected: %s", service_name)
                else:
                    await integration_manager.connect(service_name, creds)
                    log.debug("Auto-reconnected: %s", service_name)
            except Exception:
                log.debug("Auto-reconnect failed for %s", service_name, exc_info=True)

    # Autopilot
    autopilot = AutopilotService()
    audit = AuditTrail(settings.vault_dir / "audit.log")
    contract._audit_fn = audit.log_action  # Wire contract checks to audit trail
    guardian = GuardianService(vault, writer)

    # DM pairing service
    from agntspace.security.pairing import PairingService
    pairing = PairingService(db)
    app.state.pairing = pairing

    # Canvas service (A2UI) — persistent via SQLite
    canvas = CanvasService(db)
    app.state.canvas = canvas

    # Entity registry (single source of truth for all entities)
    from agntspace.memory.entity_registry import EntityRegistry
    entity_registry = EntityRegistry(vault=vault, writer=writer)

    # Knowledge graph + memory engine (SPO triples stored in vault JSON files)
    _step("Building knowledge graph...")
    knowledge_graph = KnowledgeGraph(vault, writer=writer, llm=llm, entity_registry=entity_registry)
    knowledge_graph.build()

    # Post-wire knowledge graph into coach (created before graph existed)
    coach._graph = knowledge_graph  # noqa: SLF001

    memory_engine = MemoryEngine(
        vault_reader=vault,
        vault_writer=writer,
        llm=llm,
        conversation_memory=memory,
        journal=journal,
        task_service=task_service,
        trust_service=trust_service,
        coach=coach,
        email=email_integration,
        cost_tracker=None,  # wired below
        knowledge_graph=knowledge_graph,
        skill_loader=skills,
        model_router=model_router,
    )

    # Cost tracker
    from agntspace.infra.cost_tracker import CostTracker
    cost_settings = settings_service.get_section("costs") or {}
    cost_tracker = CostTracker(
        db,
        daily_budget=float(cost_settings.get("daily_budget", 10.0)),
        monthly_budget=float(cost_settings.get("monthly_budget", 100.0)),
    )
    await cost_tracker.init_schema()
    memory_engine._cost_tracker = cost_tracker  # noqa: SLF001

    # Wire memory_engine into reflection (created before memory_engine existed)
    reflection_service._memory_engine = memory_engine  # noqa: SLF001

    # Background tasks
    sched = settings.schedule
    heartbeat = Heartbeat(journal, task_service, db=db, interval_seconds=sched.heartbeat_seconds, llm=llm)
    await heartbeat.init_schema()
    scheduler = TaskScheduler(task_service, journal, interval_seconds=sched.scheduler_seconds)

    # Persistent cron scheduler
    cron = CronScheduler(db, journal, heartbeat=heartbeat)
    await cron.init_schema()

    # Persistent work queue — guarantees all LLM-dependent work completes
    from agntspace.automation.work_queue import WorkQueue

    work_queue = WorkQueue(db, heartbeat=heartbeat)
    await work_queue.init_schema()
    # Set initial LLM health and active model
    model_name = getattr(llm, "model_name", getattr(llm, "_model", "unknown"))
    work_queue.set_llm_health(getattr(llm, "healthy", True), model=model_name)
    app.state.work_queue = work_queue

    daily_cycle = DailyCycle(
        llm=llm,
        journal=journal,
        task_service=task_service,
        coach=coach,
        trust_service=trust_service,
        reflection_service=reflection_service,
        vault_reader=vault,
        vault_writer=writer,
        memory_engine=memory_engine,
        heartbeat=heartbeat,
        morning_hour=sched.morning_hour,
        evening_hour=sched.evening_hour,
        weekly_compaction_day=sched.weekly_compaction_day,
        skillschool=skillschool,
        vault_search=vault_search,
        orchestrator=orchestrator,
        skill_loader=skills,
        model_router=model_router,
    )

    _step("Registering tools...")
    from agntspace.agent.tools import ToolExecutor

    tool_executor = ToolExecutor(
        contract=contract,
        email=email_integration,
        vault_reader=vault,
        vault_writer=writer,
        vault_search=vault_search,
        task_service=task_service,
        journal=journal,
        coach=coach,
        memory_engine=memory_engine,
        orchestrator=orchestrator,
        project_service=project_service,
        knowledge_graph=knowledge_graph,
        vault_embeddings=vault_embeddings,
        channel_manager=channel_manager,
    )

    # Build tool registry — single source of truth for capabilities
    from agntspace.agent.registry import ToolRegistry

    registry = ToolRegistry()
    tool_executor.populate_registry(registry)

    # Wire tool access into orchestrator — subagents can now execute tools
    orchestrator._registry = registry  # noqa: SLF001
    orchestrator._tool_executor = tool_executor  # noqa: SLF001

    # Register KB research as an agent tool
    registry.register_integration(
        "kb", "Knowledge Base",
        "Research questions against personal knowledge bases (wiki articles compiled from raw sources).",
        lambda: True,
    )

    async def _kb_research_handler(inp: dict) -> dict:
        topic = inp.get("topic", "")
        query = inp.get("query", "")
        if not topic or not query:
            return {"error": "Both topic and query are required."}
        return await kb_service.research(topic, query, save_output=inp.get("save_output", False))

    # Wrap async handler for sync registry
    def _kb_research_sync(inp: dict) -> dict:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(_kb_research_handler(inp))

    registry.register_tool(
        name="research_kb",
        description="Research a question against a personal knowledge base. Use when the user asks complex questions about a topic they have a KB for.",
        input_schema={
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "KB slug (e.g., 'ai-safety', 'quantum-computing')"},
                "query": {"type": "string", "description": "The research question"},
                "save_output": {"type": "boolean", "description": "Save the research output to the KB", "default": False},
            },
            "required": ["topic", "query"],
        },
        handler=_kb_research_sync,
        integration="kb",
        contract_action="search",
    )

    # Register wiki job tool — full pipeline via chat
    async def _wiki_job_handler(inp: dict) -> dict:
        slug = inp.get("kb", "")
        skip_lint = inp.get("skip_lint", False)
        skip_reflect = inp.get("skip_reflect", False)
        if not slug:
            # Run across all KBs
            kbs = kb_service.list_kbs()
            if not kbs:
                return {"error": "No knowledge bases found. Create one first."}
            results = []
            for kb_info in kbs:
                r = await kb_service.run_wiki_job(
                    kb_info["slug"], skip_lint=skip_lint, skip_reflect=skip_reflect,
                )
                results.append(r)
            total_ingested = sum(r.get("ingested", 0) for r in results)
            total_compiled = sum(r.get("compiled", 0) for r in results)
            total_issues = sum(r.get("issues", 0) for r in results)
            total_decisions = sum(r.get("decisions_created", 0) for r in results)
            return {
                "kbs_processed": len(results),
                "total_ingested": total_ingested,
                "total_compiled": total_compiled,
                "total_decisions": total_decisions,
                "total_issues": total_issues,
                "details": results,
            }
        return await kb_service.run_wiki_job(
            slug, skip_lint=skip_lint, skip_reflect=skip_reflect,
        )

    def _wiki_job_sync(inp: dict) -> dict:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(_wiki_job_handler(inp))

    registry.register_tool(
        name="run_wiki_job",
        description=(
            "Run the full wiki processing pipeline: snapshot → ingest → compile → reflect → lint. "
            "Use when the user asks to process the wiki, run KB maintenance, or update knowledge bases. "
            "If no KB slug is provided, runs across ALL knowledge bases."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "kb": {"type": "string", "description": "KB slug to process (empty = all KBs)", "default": ""},
                "skip_lint": {"type": "boolean", "description": "Skip the lint/health-check step", "default": False},
                "skip_reflect": {"type": "boolean", "description": "Skip the structural reflection step", "default": False},
            },
        },
        handler=_wiki_job_sync,
        async_handler=_wiki_job_handler,
        integration="kb",
        contract_action="search",
    )

    # Register generic workflow execution tool (supervisor-driven)
    async def _run_workflow_handler(inp: dict) -> dict:
        wf_id = inp.get("workflow", "")
        wf_defs = app.state.workflow_defs
        if not wf_id:
            return {"available_workflows": list(wf_defs.keys())}
        wf = wf_defs.get(wf_id)
        if not wf:
            return {"error": f"Unknown workflow: {wf_id}", "available": list(wf_defs.keys())}
        execution = await supervisor.execute(wf, context=inp.get("context", ""))
        return {
            "workflow": execution.workflow_id,
            "status": execution.status,
            "iterations": execution.total_iterations,
            "steps_executed": len(execution.step_results),
            "results": [
                {"step": r.step_id, "agent": r.agent_key, "summary": r.content[:300], "attempt": r.iteration}
                for r in execution.step_results
            ],
            "supervisor_decisions": [
                {"action": d["action"], "steps": d["steps"], "reason": d["reason"]}
                for d in execution.supervisor_log
            ],
        }

    def _run_workflow_sync(inp: dict) -> dict:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(_run_workflow_handler(inp))

    registry.register_integration(
        "workflows", "Workflows",
        "Execute multi-agent workflows with adaptive supervisor coordination.",
        lambda: bool(app.state.workflow_defs),
    )

    registry.register_tool(
        name="run_workflow",
        description=(
            "Execute a multi-agent workflow through the supervisor. "
            "The supervisor adaptively decides step order, feedback loops, parallelism, and skips. "
            "Available workflows: wiki-management, email-processing, project-kickoff, daily-cycle, content-review."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "workflow": {"type": "string", "description": "Workflow ID (e.g., 'wiki-management', 'email-processing')"},
                "context": {"type": "string", "description": "Additional context for the workflow", "default": ""},
            },
            "required": ["workflow"],
        },
        handler=_run_workflow_sync,
        integration="workflows",
        contract_action="delegate_task",
    )

    agent = Agent(
        llm=llm,
        memory=memory,
        vault=vault,
        journal=journal,
        task_service=task_service,
        trust_service=trust_service,
        tool_executor=tool_executor,
        memory_engine=memory_engine,
        skill_loader=skills,
        heartbeat=heartbeat,
        registry=registry,
        project_service=project_service,
        local_mode=settings.llm.mode == "local",
        cost_tracker=cost_tracker,
    )
    await agent.initialize()

    # Wire agent into automation services (replaces direct LLM calls)
    daily_cycle._agent = agent  # noqa: SLF001
    reflection_service._agent = agent  # noqa: SLF001
    memory_engine._agent = agent  # noqa: SLF001
    knowledge_graph._agent = agent  # noqa: SLF001

    # Plugin system
    from agntspace.plugins.base import PluginContext
    from agntspace.plugins.manager import PluginManager

    plugin_manager = PluginManager(settings.app_dir, settings.vault_dir)
    plugin_ctx = PluginContext(
        registry=registry,
        vault=vault,
        vault_writer=writer,
        llm=llm,
        settings=settings,
        db=db,
        skill_loader=skills,
        plugin_data_dir=settings.app_dir / "plugins",
        log=logging.getLogger("agntspace.plugins"),
    )
    plugin_manager.load_all(plugin_ctx, app=app)
    app.state.plugin_manager = plugin_manager
    app.state.plugin_ctx = plugin_ctx

    # MCP Client — connect to external MCP servers
    mcp_config_path = settings.app_dir / "mcp-servers.json"
    mcp_client = MCPClientManager(config_path=mcp_config_path)
    mcp_client.load_config()
    app.state.mcp_client = mcp_client

    # Auto-connect to saved MCP servers
    try:
        await mcp_client.auto_connect_all()
    except Exception:
        log.warning("MCP auto-connect failed", exc_info=True)

    # Wire MCP client into registry — external tools appear in agent tool list
    registry._mcp_client = mcp_client  # noqa: SLF001

    # Set up channel message handler with Guardian scanning
    async def handle_channel_message(msg):  # noqa: ANN001
        # Guardian: scan incoming message for threats
        scan = guardian.scan_text(msg.text)
        if not scan.safe:
            threat_names = ", ".join(t["value"] for t in scan.threats)
            journal.append_observation(
                f"Guardian blocked message from {msg.sender} on {msg.channel}: "
                f"matched blacklist ({threat_names})"
            )
            return f"Message blocked by Guardian: matched blacklist entries ({threat_names})"

        # Guardian: scan sender
        sender_scan = guardian.scan_sender(msg.sender)
        if not sender_scan.safe:
            journal.append_observation(
                f"Guardian blocked sender {msg.sender} on {msg.channel}: blacklisted"
            )
            return None  # silently drop messages from blacklisted senders

        # DM pairing gate — self-chat always bypasses
        is_self = msg.metadata.get("is_self", False) or msg.metadata.get("from_me", False)
        if not is_self:
            policy = await pairing.get_dm_policy()
            if policy == "pairing":
                if not await pairing.is_allowed(msg.channel, msg.sender):
                    from agntspace.infra.i18n import t as _t
                    code = await pairing.generate_pairing_code(msg.channel, msg.sender)
                    return _t("pairing.code_msg", code=code)
            elif policy == "allowlist":
                if not await pairing.is_allowed(msg.channel, msg.sender):
                    return None  # silently drop

        conv_id = f"channel-{msg.channel}-{msg.metadata.get('chat_id', 'default')}"
        is_new_conv = not await memory.conversation_exists(conv_id)
        if is_new_conv:
            await memory.create_conversation(
                title=f"{msg.channel}: {msg.sender}",
                conversation_id=conv_id,
            )
        await heartbeat.record_pulse("channel", f"{msg.channel}: {msg.sender}")

        # Inject channel context so the agent knows where it's responding
        is_self = msg.metadata.get("is_self", False) or msg.metadata.get("from_me", False)
        context_prefix = (
            f"[Channel: {msg.channel} | Sender: {msg.sender}"
            f"{' | self-chat' if is_self else ''}"
            f"{' | first-contact' if is_new_conv else ''}]\n\n"
        )
        augmented_text = context_prefix + msg.text

        # Use streaming path (same as UI) and collect full response
        chunks = []
        async for chunk in agent.chat_stream(conv_id, augmented_text):
            if chunk.delta:
                chunks.append(chunk.delta)
        return "".join(chunks)

    channel_manager.set_message_handler(handle_channel_message)
    # Store handler for WhatsApp lazy registration
    app.state._whatsapp_handler = handle_channel_message  # noqa: SLF001

    # Store on app.state
    app.state.agent = agent
    app.state.memory = memory
    app.state.vault = vault
    app.state.vault_writer = writer
    app.state.writer = writer
    app.state.db = db
    app.state.settings = settings
    app.state.journal = journal
    app.state.task_service = task_service
    app.state.trust_service = trust_service
    app.state.contract = contract
    app.state.vault_search = vault_search
    app.state.vault_embeddings = vault_embeddings
    app.state.skills = skills
    app.state.orchestrator = orchestrator
    app.state.model_router = model_router
    app.state.project_service = project_service
    app.state.reflection_service = reflection_service
    app.state.coach = coach
    app.state.skillschool = skillschool
    app.state.heartbeat = heartbeat
    app.state.scheduler = scheduler
    app.state.cron = cron
    app.state.registry = registry
    app.state.daily_cycle = daily_cycle
    app.state.domains = domains
    app.state.channel_manager = channel_manager
    app.state.integration_manager = integration_manager
    app.state.email_integration = email_integration
    app.state.settings_service = settings_service
    app.state.credential_store = credential_store
    app.state.vault_sync = vault_sync
    app.state.knowledge_graph = knowledge_graph
    app.state.memory_engine = memory_engine
    app.state.cost_tracker = cost_tracker

    # Bibliography service (global — one registry across all KBs)
    from agntspace.kb.bibliography import BibliographyService

    bibliography_service = BibliographyService(vault, writer)
    app.state.bibliography_service = bibliography_service

    # Knowledge Base service
    from agntspace.kb.service import KnowledgeBaseService

    kb_service = KnowledgeBaseService(vault, writer, llm, skills_dir=settings.skills_dir, skill_loader=skills, model_router=model_router, bibliography=bibliography_service, work_queue=work_queue)
    app.state.kb_service = kb_service
    app.state.skills_dir = settings.skills_dir

    # Register work queue handlers — map job types to service methods
    async def _wq_call(method, *args, **kwargs):
        """Call KB service method with _called_from_queue flag set.

        When the flag is set, LLM failures raise directly instead of
        re-enqueuing — the work queue handles retry scheduling.
        """
        kb_service._called_from_queue = True
        try:
            return await method(*args, **kwargs)
        finally:
            kb_service._called_from_queue = False

    async def _wq_ingest(p: dict) -> dict:
        return await _wq_call(kb_service.ingest, p["slug"])

    async def _wq_compile(p: dict) -> dict:
        return await _wq_call(kb_service.compile_wiki, p["slug"])

    async def _wq_reflect(p: dict) -> dict:
        return await _wq_call(kb_service.reflect,
            p["slug"], p.get("articles_created", []), p.get("files_ingested", []))

    async def _wq_research(p: dict) -> dict:
        return await _wq_call(kb_service.research,
            p.get("slug", "general"), p.get("query", ""), save_output=p.get("save_output", False))

    async def _wq_lint(p: dict) -> dict:
        return await _wq_call(kb_service.lint, p["slug"])

    async def _wq_synthesize(p: dict) -> dict:
        return await _wq_call(kb_service.synthesize, p["slug"])

    work_queue.register_handler("ingest", _wq_ingest)
    work_queue.register_handler("compile", _wq_compile)
    work_queue.register_handler("reflect", _wq_reflect)
    work_queue.register_handler("research", _wq_research)
    work_queue.register_handler("lint", _wq_lint)
    work_queue.register_handler("synthesize", _wq_synthesize)
    heartbeat._work_queue = work_queue  # Wire heartbeat → work queue for LLM health updates

    # Memory ↔ Wiki bridge
    from agntspace.kb.memory_bridge import MemoryWikiBridge

    memory_bridge = MemoryWikiBridge(llm, vault, writer, kb_service)
    daily_cycle._memory_bridge = memory_bridge  # inject into already-created daily_cycle

    # System Bridge: all modules → unified graph + wiki
    from agntspace.kb.system_bridge import SystemBridge

    system_bridge = SystemBridge(
        graph=knowledge_graph,
        vault_reader=vault,
        vault_writer=writer,
        kb_service=kb_service,
        journal=journal,
        task_service=task_service,
        coach=coach,
        trust_service=trust_service,
        skill_loader=skills,
        project_service=project_service,
        heartbeat=heartbeat,
        guardian=guardian,
    )
    daily_cycle._system_bridge = system_bridge

    # Workflow Supervisor — adaptive multi-agent workflow execution
    from agntspace.agent.supervisor import WorkflowDef, WorkflowStep, WorkflowSupervisor

    supervisor = WorkflowSupervisor(orchestrator, llm)
    app.state.supervisor = supervisor

    # Register workflow definitions (match UI WORKFLOW_DEFS)
    app.state.workflow_defs = {
        "wiki-management": WorkflowDef(
            id="wiki-management",
            name="Wiki Management",
            description="Full knowledge pipeline: ingest → compile → reflect → lint. Snapshot first for safety.",
            supervisor="wiki-supervisor",
            steps=[
                WorkflowStep(id="scrape", agent_key="researcher", label="Scrape URLs (optional)",
                    description="Fetch web pages via agent-browser into KB inbox. Use scrape_url tool. Only when URLs are provided or research gaps identified.",
                    skills=["browser-automation"]),
                WorkflowStep(id="ingest", agent_key="librarian", label="Ingest & Classify",
                    description="Process inbox files. Classify by type. Extract entities, concepts, facts. Create source summaries. Cross-KB dedup.",
                    skills=["kb-ingest"]),
                WorkflowStep(id="compile", agent_key="librarian", label="Compile Articles",
                    description="Generate wiki articles from sources. Entity/concept/source pages with [[backlinks]]. Slug/title dedup.",
                    skills=["kb-compile"]),
                WorkflowStep(id="reflect", agent_key="editor", label="Reflect",
                    description="Structural analysis: what decisions were made? Ingestion bias? Blind spots? Create decision records for significant changes.",
                    skills=["kb-reflect"]),
                WorkflowStep(id="lint", agent_key="editor", label="Lint & Quality",
                    description="Two-phase health check. Structural: orphans, broken links, duplicates. Semantic: contradictions, stale claims, data gaps.",
                    skills=["kb-lint", "kb-curate"]),
                WorkflowStep(id="research", agent_key="researcher", label="Research (on demand)",
                    description="Answer questions against compiled wiki. Tiered context. Output feeds back idempotently.",
                    skills=["kb-research"]),
            ],
        ),
        "email-processing": WorkflowDef(
            id="email-processing",
            name="Email Processing",
            description="Triage inbox, draft responses, security scan, send after approval.",
            supervisor="ops-supervisor",
            steps=[
                WorkflowStep(id="triage", agent_key="assistant", label="Triage Inbox",
                    description="Read and classify emails by urgency. Flag important. Separate newsletters from actionable items."),
                WorkflowStep(id="draft", agent_key="writer", label="Draft Responses",
                    description="Compose reply drafts matching user voice. Pull context from vault. Save to Gmail Drafts."),
                WorkflowStep(id="security", agent_key="guardian", label="Security Scan",
                    description="Check outgoing content against blacklist. Scan for sensitive data leakage."),
                WorkflowStep(id="send", agent_key="assistant", label="Send & Log",
                    description="After user approval, send email. Log action to audit trail. Record as journal observation."),
            ],
        ),
        "project-kickoff": WorkflowDef(
            id="project-kickoff",
            name="Project Kickoff",
            description="Set up a new project: research context, plan structure, create brief, assign agents.",
            supervisor="project-supervisor",
            steps=[
                WorkflowStep(id="gather", agent_key="researcher", label="Gather Context",
                    description="Search vault and KBs for relevant prior work. Identify related goals. Compile background brief."),
                WorkflowStep(id="plan", agent_key="planner", label="Structure & Plan",
                    description="Break project into milestones. Define dependencies. Estimate scope. Recommend agent assignments."),
                WorkflowStep(id="brief", agent_key="writer", label="Create Brief",
                    description="Write PROJECT.md. Document objectives, constraints, success criteria."),
                WorkflowStep(id="setup", agent_key="assistant", label="Set Up & Assign",
                    description="Create project in system. Add milestones. Link goals and KBs. Assign subagents."),
            ],
        ),
        "daily-cycle": WorkflowDef(
            id="daily-cycle",
            name="Daily Cycle",
            description="Morning-to-evening: briefing, priorities, observation logging, EOD reflection.",
            supervisor="ops-supervisor",
            steps=[
                WorkflowStep(id="metrics", agent_key="analyst", label="Review Metrics",
                    description="Check email counts, task status, goal progress. Identify blockers and stalled items."),
                WorkflowStep(id="briefing", agent_key="assistant", label="Morning Briefing",
                    description="Compile overnight activity. List today's priorities. Surface deadlines."),
                WorkflowStep(id="prioritize", agent_key="planner", label="Prioritize Work",
                    description="Reorder tasks by urgency. Detect stalled goals. Generate coaching nudges."),
                WorkflowStep(id="eod", agent_key="assistant", label="EOD Report",
                    description="Summarize today. Log observations. Run memory consolidation. Prepare for tomorrow."),
            ],
        ),
        "journal-management": WorkflowDef(
            id="journal-management",
            name="Journal Management",
            description="Full daily journal lifecycle: morning briefing → observation logging → EOD report → reflection → memory extraction.",
            supervisor="ops-supervisor",
            steps=[
                WorkflowStep(id="briefing", agent_key="assistant", label="Morning Briefing",
                    description="Generate personalized morning briefing. Pull focus, tasks, goals, yesterday's journal, memory, upcoming deadlines. Warm but efficient.",
                    skills=["daily-briefing"]),
                WorkflowStep(id="observe", agent_key="analyst", label="Log Observations",
                    description="Review today's activity — emails, tasks, conversations, state changes. Append observations to agent-observations file.",
                    skills=[]),
                WorkflowStep(id="eod", agent_key="assistant", label="EOD Report",
                    description="Summarize the day: completed tasks, decisions, learnings, memory updates. Write eod-report file.",
                    skills=["eod-report"]),
                WorkflowStep(id="reflect", agent_key="memory-agent", label="Daily Reflection",
                    description="Synthesize user journal + agent observations into structured reflection. Propose MEMORY.md updates (pending user approval).",
                    skills=["daily-reflection"]),
                WorkflowStep(id="weekly", agent_key="memory-agent", label="Weekly Reflection (if due)",
                    description="On compaction day: synthesize past 7 days into weekly patterns, progress, and goal check. Trigger memory compaction.",
                    skills=["weekly-reflection"]),
            ],
        ),
        "memory-management": WorkflowDef(
            id="memory-management",
            name="Memory Management",
            description="Full memory lifecycle: consolidate daily activity → extract triples → compact layers → rebuild graph → health check.",
            supervisor="ops-supervisor",
            steps=[
                WorkflowStep(id="consolidate", agent_key="memory-agent", label="Daily Consolidation",
                    description="Gather all activity (journal, notes, conversations, tasks, goals). Synthesize into daily memory file with [[wiki-links]]. Extract permanent facts (pending approval).",
                    skills=["memory-consolidate"]),
                WorkflowStep(id="extract", agent_key="memory-agent", label="Triple Extraction",
                    description="Extract structured knowledge triples (subject-predicate-object) from daily memory. Validate against ontology. Add to knowledge graph.",
                    skills=["memory-consolidate"]),
                WorkflowStep(id="compact", agent_key="memory-agent", label="Layer Compaction",
                    description="Compact memory through temporal layers: daily → week → month → quarter → year → longterm. Preserve [user-confirmed] tags and provenance.",
                    skills=["memory-compact"]),
                WorkflowStep(id="graph", agent_key="philosopher", label="Graph Maintenance",
                    description="Evaluate decay conditions. Reweight triples by authority, confidence, temporal relevance. Detect contradictions. Resolve orphaned entities.",
                    skills=["ontology", "epistemic-audit"]),
                WorkflowStep(id="health", agent_key="analyst", label="Health Check",
                    description="Run memory health diagnostics: orphaned entities/triples, contradictions, missing daily memories, high decay ratio. Auto-repair if possible.",
                    skills=[]),
            ],
        ),
        "content-review": WorkflowDef(
            id="content-review",
            name="Content Review",
            description="Multi-stage review: draft → quality review → fact check → compliance.",
            supervisor="project-supervisor",
            steps=[
                WorkflowStep(id="draft", agent_key="writer", label="Draft Content",
                    description="Write initial document. Follow templates and brand voice. Pull supporting data."),
                WorkflowStep(id="review", agent_key="editor", label="Quality Review",
                    description="Check clarity, accuracy, completeness. Flag unsupported claims."),
                WorkflowStep(id="factcheck", agent_key="analyst", label="Fact Check",
                    description="Cross-reference claims against KB sources. Flag contradictions. Verify data."),
                WorkflowStep(id="compliance", agent_key="guardian", label="Compliance Check",
                    description="Scan for sensitive data. Check contract permissions. Ensure safe for external sharing."),
            ],
        ),
    }

    # Canvas tools — agent-driven visual interface (A2UI)
    registry.register_integration("canvas", "Canvas", "Push visual content to the operator's live canvas.", lambda: True)

    _CANVAS_TYPES = ["markdown", "html", "table", "code", "image", "json", "mermaid"]

    async def _canvas_push_handler(inp: dict) -> dict:
        content = inp.get("content", "")
        content_type = inp.get("type", "markdown")
        title = inp.get("title", "")
        if not content:
            return {"error": "Content is required"}
        item = await canvas.push(content, content_type, title)
        return {"pushed": True, "id": item["id"]}

    def _canvas_push_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_canvas_push_handler(inp))

    registry.register_tool(
        name="canvas_push",
        description="Push content to the operator's live canvas. Use for visual summaries, search results, tables, code, or task boards.",
        input_schema={
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Content to display"},
                "type": {"type": "string", "enum": _CANVAS_TYPES, "description": "Content format", "default": "markdown"},
                "title": {"type": "string", "description": "Optional title for the canvas card"},
            },
            "required": ["content"],
        },
        handler=_canvas_push_sync,
        async_handler=_canvas_push_handler,
        integration="canvas",
        contract_action="canvas_push",
    )

    async def _canvas_update_handler(inp: dict) -> dict:
        item_id = inp.get("id", "")
        if not item_id:
            return {"error": "id is required"}
        fields: dict = {}
        if "content" in inp:
            fields["content"] = inp["content"]
        if "title" in inp:
            fields["title"] = inp["title"]
        if "type" in inp:
            fields["content_type"] = inp["type"]
        item = await canvas.update(item_id, **fields)
        if not item:
            return {"error": "Item not found"}
        return {"updated": True, "id": item_id}

    def _canvas_update_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_canvas_update_handler(inp))

    registry.register_tool(
        name="canvas_update",
        description="Update an existing canvas item by ID. Can change content, title, or type.",
        input_schema={
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "ID of the canvas item to update"},
                "content": {"type": "string", "description": "New content"},
                "title": {"type": "string", "description": "New title"},
                "type": {"type": "string", "enum": _CANVAS_TYPES, "description": "New content type"},
            },
            "required": ["id"],
        },
        handler=_canvas_update_sync,
        async_handler=_canvas_update_handler,
        integration="canvas",
        contract_action="canvas_push",
    )

    async def _canvas_remove_handler(inp: dict) -> dict:
        item_id = inp.get("id", "")
        if not item_id:
            return {"error": "id is required"}
        ok = await canvas.remove(item_id)
        return {"removed": ok, "id": item_id}

    def _canvas_remove_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_canvas_remove_handler(inp))

    registry.register_tool(
        name="canvas_remove",
        description="Remove a specific item from the canvas by ID.",
        input_schema={
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "ID of the canvas item to remove"},
            },
            "required": ["id"],
        },
        handler=_canvas_remove_sync,
        async_handler=_canvas_remove_handler,
        integration="canvas",
        contract_action="canvas_push",
    )

    async def _canvas_snapshot_handler(inp: dict) -> dict:
        name = inp.get("name", "Untitled")
        snap = await canvas.snapshot_save(name)
        return {"snapshot_id": snap["id"], "name": name}

    def _canvas_snapshot_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_canvas_snapshot_handler(inp))

    registry.register_tool(
        name="canvas_snapshot",
        description="Save the current canvas state as a named snapshot that can be restored later.",
        input_schema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name for the snapshot"},
            },
            "required": ["name"],
        },
        handler=_canvas_snapshot_sync,
        async_handler=_canvas_snapshot_handler,
        integration="canvas",
        contract_action="canvas_push",
    )

    async def _canvas_reset_handler(_inp: dict) -> dict:
        await canvas.reset()
        return {"reset": True}

    def _canvas_reset_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_canvas_reset_handler(inp))

    registry.register_tool(
        name="canvas_reset",
        description="Clear all content from the operator's canvas.",
        input_schema={"type": "object", "properties": {}},
        handler=_canvas_reset_sync,
        async_handler=_canvas_reset_handler,
        integration="canvas",
        contract_action="canvas_push",
    )

    # ── Heal agents tool ──

    # Proposals file path
    _proposals_path = vault_path / "agnt-system" / "logs" / "simulation" / "heal-proposals.json"

    async def _heal_agents_handler(inp: dict) -> dict:
        """Diagnose agent health and propose fixes (user must approve)."""
        action = inp.get("action", "diagnose")

        from agntspace.api.routes.simulate import _check_single_agent

        if action == "diagnose":
            # Run agent-centric health checks and return diagnosis
            available_skills = {s.name for s in skills.skills.values() if s.status == "active"}
            diagnosis: dict = {"agents": {}, "healable": [], "needs_human": []}

            for agent_key in sorted(orchestrator.agents.keys()):
                result = _check_single_agent(orchestrator, agent_key)
                if result["status"] != "pass":
                    diagnosis["agents"][agent_key] = {
                        "status": result["status"],
                        "agent_name": result.get("agent_name", agent_key),
                        "issues": result.get("issues", []),
                    }
                for issue in result.get("issues", []):
                    if issue.startswith("Skill not loaded:"):
                        skill_name = issue.replace("Skill not loaded: ", "").strip()
                        if skill_name in available_skills:
                            diagnosis["healable"].append({
                                "agent_key": agent_key,
                                "skill": skill_name,
                                "step": f"{result.get('agent_name', agent_key)} health check",
                            })
                        else:
                            diagnosis["needs_human"].append({
                                "issue": f"Skill '{skill_name}' does not exist in registry",
                                "agent_key": agent_key,
                            })
            return diagnosis

        elif action == "propose":
            # Diagnose and save proposals for user approval — never auto-apply
            available_skills = {s.name for s in skills.skills.values() if s.status == "active"}
            proposals = []
            skill_drafts = []
            drafted_skills: set[str] = set()

            for agent_key in sorted(orchestrator.agents.keys()):
                result = _check_single_agent(orchestrator, agent_key)
                agent_def = orchestrator.agents.get(agent_key)
                if not agent_def:
                    continue
                for issue in result.get("issues", []):
                    if not issue.startswith("Skill not loaded:"):
                        continue
                    skill_name = issue.replace("Skill not loaded: ", "").strip()

                    agent_name = agent_def.name or agent_key
                    step_label = f"{agent_name} health check"

                    if skill_name in available_skills:
                        # Existing skill — propose assignment
                        if skill_name in (agent_def.skills or []):
                            continue
                        if any(p["agent_key"] == agent_key and p["skill"] == skill_name for p in proposals):
                            continue
                        proposals.append({
                            "type": "assign_skill",
                            "agent_key": agent_key,
                            "agent_name": agent_name,
                            "skill": skill_name,
                            "workflow": "agent-health",
                            "step": step_label,
                            "status": "pending",
                        })
                    else:
                        # Missing skill — draft a new one
                        if skill_name in drafted_skills:
                            continue
                        drafted_skills.add(skill_name)

                        title = skill_name.replace("-", " ").title()
                        draft_content = f"""---
name: {skill_name}
title: "{title}"
description: "Draft skill for {agent_name} — needs review"
category: custom
status: draft
triggers:
  - "{skill_name.replace('-', ' ')}"
---

## Instructions

This skill was flagged as missing from **{agent_name}** during a health check.

## Rules

- [TODO: Add specific rules and constraints]
- [TODO: Define quality criteria]
- [TODO: Specify output format if needed]
"""
                        # Save draft to pending folder
                        draft_dir = vault_path / "agnt-system" / "skills" / "pending" / skill_name
                        draft_dir.mkdir(parents=True, exist_ok=True)
                        draft_path = draft_dir / "SKILL.md"
                        draft_path.write_text(draft_content, encoding="utf-8")

                        skill_drafts.append({
                            "type": "create_skill",
                            "skill": skill_name,
                            "title": title,
                            "agent_key": agent_key,
                            "agent_name": agent_name,
                            "workflow": "agent-health",
                            "step": step_label,
                            "draft_path": f"agnt-system/skills/pending/{skill_name}/SKILL.md",
                            "status": "pending",
                        })

                        # Also propose assigning it to the agent (after approval)
                        proposals.append({
                            "type": "assign_skill",
                            "agent_key": agent_key,
                            "agent_name": agent_name,
                            "skill": skill_name,
                            "workflow": "agent-health",
                            "step": step_label,
                            "depends_on_draft": True,
                            "status": "pending",
                        })

            # Save to heal-proposals.json (for Simulate tab)
            all_proposals = skill_drafts + proposals
            _proposals_path.parent.mkdir(parents=True, exist_ok=True)
            existing = []
            if _proposals_path.exists():
                try:
                    existing = json.loads(_proposals_path.read_text(encoding="utf-8"))
                except Exception:
                    existing = []
            existing_keys = {(p.get("agent_key", ""), p.get("skill", ""), p.get("type", "")) for p in existing if p.get("status") == "pending"}
            for p in all_proposals:
                if (p.get("agent_key", ""), p.get("skill", ""), p.get("type", "")) not in existing_keys:
                    existing.append(p)
            _proposals_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")

            # Also write to skills-review/ (for Skills page proposals tab)
            for p in all_proposals:
                slug = f"heal-{p.get('agent_key', 'unknown')}-{p.get('skill', 'unknown')}"
                ptype = p.get("type", "assign_skill")
                agent_name = p.get("agent_name", p.get("agent_key", ""))
                skill_name = p.get("skill", "")
                wf_name = p.get("workflow", "")
                step_name = p.get("step", "")

                if ptype == "create_skill":
                    title = f"New Skill: {skill_name.replace('-', ' ').title()}"
                    desc = f"Draft skill for {step_name} step in {wf_name} workflow"
                else:
                    title = f"Assign {skill_name} to {agent_name}"
                    desc = f"Add skill '{skill_name}' to {agent_name} for {step_name} in {wf_name}"

                review_content = f"""---
title: "{title}"
description: "{desc}"
status: pending_review
category: healer
type: {ptype}
agent_key: {p.get('agent_key', '')}
skill: {skill_name}
workflow: {wf_name}
---

## Proposal

**Type:** {"Create new skill" if ptype == "create_skill" else "Assign existing skill"}
**Agent:** {agent_name}
**Skill:** `{skill_name}`
**Workflow:** {wf_name}
**Step:** {step_name}

{"This skill does not exist yet and needs to be created." if ptype == "create_skill" else f"The skill `{skill_name}` exists but is not assigned to {agent_name}."}
"""
                # Check if already exists
                review_path = vault_path / "skills-review" / f"{slug}.md"
                if not review_path.exists():
                    review_path.parent.mkdir(parents=True, exist_ok=True)
                    review_path.write_text(review_content, encoding="utf-8")

            return {
                "skill_drafts": skill_drafts,
                "assign_proposals": proposals,
                "total_skill_drafts": len(skill_drafts),
                "total_assign_proposals": len(proposals),
                "message": (
                    f"{len(skill_drafts)} skill draft(s) and {len(proposals)} assignment proposal(s) saved. "
                    "Review in Skills page (Proposals tab) or Simulate tab."
                ),
            }
        else:
            return {"error": f"Unknown action: {action}. Use 'diagnose' or 'propose'."}

    def _heal_agents_sync(inp: dict) -> dict:
        import asyncio as _aio
        return _aio.get_event_loop().run_until_complete(_heal_agents_handler(inp))

    registry.register_tool(
        name="heal_agents",
        description=(
            "Diagnose agent health and propose fixes for user approval. "
            "Action 'diagnose': check all agents for missing skills, tools, or configuration issues. "
            "Action 'propose': create proposals to add missing skills — saved for user to approve/reject. "
            "Never auto-modifies agents. All changes require user approval."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["diagnose", "propose"],
                    "description": "diagnose = report issues, propose = create proposals for user approval",
                },
            },
            "required": ["action"],
        },
        handler=_heal_agents_sync,
        async_handler=_heal_agents_handler,
        contract_action="delegate_task",
    )

    # Raw folder watcher — auto-ingests files dropped into raw/
    from agntspace.automation.raw_watcher import RawWatcher

    # Only scan root folder if user explicitly configured a vault location
    raw_watcher = RawWatcher(
        vault_path, kb_service,
        root_dir=settings.root_dir, scan_root=settings.root_explicit,
        heartbeat=heartbeat,
        orchestrator=orchestrator,
        work_queue=work_queue,
    )
    app.state.raw_watcher = raw_watcher

    app.state.frozen = False
    app.state.autopilot = autopilot
    app.state.audit = audit
    app.state.guardian = guardian

    # Start background tasks
    heartbeat.start()
    scheduler.start()
    daily_cycle.start()
    cron.start()
    work_queue.start()
    raw_watcher.start()

    # Pre-warm wiki article cache in background thread
    from agntspace.api.routes.wiki import warm_article_cache
    warm_article_cache(vault)

    # Auto-sync project wiki namespaces — pull real data from Projects module
    try:
        for proj in project_service.list_projects():
            for kb_slug in proj.get("linked_kbs", []):
                proj_slug = proj["slug"]
                proj_dir = vault_path / "kb" / kb_slug / "wiki" / "projects" / proj_slug
                try:
                    detail = project_service.get_project_detail(proj_slug)
                except Exception:
                    detail = proj
                if not proj_dir.is_dir():
                    kb_service.create_project_wiki(kb_slug, proj_slug, proj.get("title", proj_slug), project_data=detail)
                    log.info("Auto-created project wiki: %s in KB %s", proj_slug, kb_slug)
                else:
                    overview_path = proj_dir / f"{proj_slug}.md"
                    if overview_path.exists() and "[TODO: project description]" in overview_path.read_text(encoding="utf-8"):
                        kb_service.create_project_wiki(kb_slug, proj_slug, proj.get("title", proj_slug), project_data=detail)
                        log.info("Updated project wiki with real data: %s in KB %s", proj_slug, kb_slug)
    except Exception:
        log.debug("Project wiki auto-sync failed", exc_info=True)

    # Compact startup summary
    connected = [ch["name"] for ch in channel_manager.list_channels() if ch["connected"]]
    parts = [
        f"{len(registry._tools)} tools",
        f"{len(orchestrator._agents) if orchestrator._agents else 0} agents",
        f"{len(skills._skills)} skills",
    ]
    if connected:
        parts.append(", ".join(connected))
    summary = " | ".join(parts)
    url = f"http://{settings.host}:{settings.port}"
    print(f"\n  \033[1;32mReady\033[0m — {summary}", flush=True)
    print(f"  \033[90m{url} — Press Ctrl+C to stop\033[0m\n", flush=True)

    # Auto-open browser
    import webbrowser
    try:
        webbrowser.open(url)
    except Exception:
        pass

    yield

    plugin_manager.shutdown_all()
    await mcp_client.disconnect_all()
    heartbeat.stop()
    scheduler.stop()
    daily_cycle.stop()
    cron.stop()
    work_queue.stop()
    raw_watcher.stop()
    await channel_manager.disconnect_all()
    await db.close()
    log.debug("AgntSpace server stopped")


def _get_version() -> str:
    try:
        p = Path(__file__).resolve().parents[2] / "pyproject.toml"
        text = p.read_text(encoding="utf-8")
        m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "dev"


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="AgntSpace",
        version=_get_version(),
        description="Personal AI agent API",
        lifespan=lifespan,
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
    )

    # CORS for dev (Vite dev server on :5173)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Contract enforcement on ALL write endpoints
    from agntspace.api.contract_middleware import ContractMiddleware
    app.add_middleware(ContractMiddleware)

    # REST routes
    app.include_router(health_router, prefix="/api")
    app.include_router(chat_router, prefix="/api")
    app.include_router(vault_router, prefix="/api")
    app.include_router(onboarding_router, prefix="/api")
    app.include_router(journal_router, prefix="/api")
    app.include_router(tasks_router, prefix="/api")
    app.include_router(goals_router, prefix="/api")
    app.include_router(skills_router, prefix="/api")
    app.include_router(search_router, prefix="/api")
    app.include_router(reflection_router, prefix="/api")
    app.include_router(channels_router, prefix="/api")
    app.include_router(contract_router, prefix="/api")
    app.include_router(emergency_router, prefix="/api")
    app.include_router(daily_router, prefix="/api")
    app.include_router(email_router, prefix="/api")
    app.include_router(settings_router, prefix="/api")
    app.include_router(sync_router, prefix="/api")
    app.include_router(graph_router, prefix="/api")
    app.include_router(memory_router, prefix="/api")
    app.include_router(notes_router, prefix="/api")
    app.include_router(cron_router, prefix="/api")
    app.include_router(heartbeat_router, prefix="/api")
    app.include_router(work_queue_router, prefix="/api")
    app.include_router(kb_router, prefix="/api")
    app.include_router(wiki_router, prefix="/api")
    app.include_router(integrations_router, prefix="/api")
    app.include_router(autopilot_router, prefix="/api")
    app.include_router(audit_router, prefix="/api")
    app.include_router(bibliography_router, prefix="/api")
    app.include_router(guardian_router, prefix="/api")
    app.include_router(domains_router, prefix="/api")
    app.include_router(orchestrator_router, prefix="/api")
    app.include_router(simulate_router, prefix="/api")
    app.include_router(costs_router, prefix="/api")
    app.include_router(trust_router, prefix="/api")
    app.include_router(projects_router, prefix="/api")
    app.include_router(pairing_router, prefix="/api")
    app.include_router(canvas_router, prefix="/api")

    from agntspace.api.routes.plugins import router as plugins_router
    app.include_router(plugins_router, prefix="/api")

    from agntspace.api.routes.mcp import router as mcp_router
    app.include_router(mcp_router, prefix="/api")

    # WebSocket
    app.add_api_websocket_route("/ws/chat/{conversation_id}", ws_chat_handler)
    app.add_api_websocket_route("/ws/canvas", ws_canvas_handler)

    # Serve built UI with SPA fallback
    # Dev repo: repo_root/ui/dist — Installed package: agntspace/ui_dist
    ui_dist = Path(__file__).parent.parent.parent.parent / "ui" / "dist"
    if not ui_dist.is_dir():
        ui_dist = Path(__file__).parent / "ui_dist"
    if ui_dist.is_dir():
        from fastapi.responses import FileResponse

        # Serve static assets (JS, CSS, etc.)
        app.mount("/assets", StaticFiles(directory=str(ui_dist / "assets")), name="assets")

        # SPA fallback: all non-API routes serve index.html
        @app.get("/{path:path}")
        async def spa_fallback(path: str) -> FileResponse:
            file_path = ui_dist / path
            if file_path.is_file():
                return FileResponse(str(file_path))
            return FileResponse(str(ui_dist / "index.html"))

    return app
