#!/usr/bin/env python3
"""
ttylog — record terminal sessions as portable .cast (asciinema v2) files.
No account. No upload. No bloat.

Usage:
    python ttylog.py record session.cast         # record a new session
    python ttylog.py play   session.cast         # replay in terminal
    python ttylog.py export session.cast out.html # export standalone HTML
    python ttylog.py trim   session.cast out.cast # trim idle gaps > 2s
    python ttylog.py info   session.cast          # show metadata

The .cast format is standard asciinema v2 — compatible with asciinema.org,
agg (animated GIF), svg-term, and other tools.
"""

from __future__ import annotations

import html
import json
import os
import pty
import select
import shutil
import signal
import struct
import sys
import termios
import time
import tty
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

app = typer.Typer(help="Record, replay, and export terminal sessions.")
console = Console()

# ── asciinema v2 .cast format ────────────────────────────────────────────────
# Header: single JSON line  {"version":2, "width":N, "height":N, ...}
# Events: one JSON array per line  [time_float, "o"|"i", "data"]

def _terminal_size() -> tuple[int, int]:
    """Return (cols, rows) of the current terminal."""
    try:
        size = shutil.get_terminal_size(fallback=(80, 24))
        return size.columns, size.lines
    except Exception:
        return 80, 24


def _write_header(fp, width: int, height: int, title: str, command: str) -> None:
    header = {
        "version": 2,
        "width": width,
        "height": height,
        "timestamp": int(time.time()),
        "title": title,
        "env": {"TERM": os.environ.get("TERM", "xterm-256color")},
    }
    if command:
        header["command"] = command
    fp.write(json.dumps(header) + "\n")


def _write_event(fp, t: float, etype: str, data: str) -> None:
    fp.write(json.dumps([round(t, 6), etype, data]) + "\n")


# ── Record ────────────────────────────────────────────────────────────────────

def record(output: str, command: str, title: str, quiet: bool) -> None:
    cols, rows = _terminal_size()
    shell = os.environ.get("SHELL", "/bin/sh")
    cmd = command or shell
    cmd_list = ["/bin/sh", "-c", cmd] if command else [shell]

    if not quiet:
        console.print(
            Panel(
                f"Recording to [bold]{output}[/bold]\n"
                f"Shell: [cyan]{cmd}[/cyan]  |  {cols}×{rows}\n\n"
                "[dim]Press Ctrl-D or type 'exit' to stop.[/dim]",
                title="ttylog",
                border_style="green",
            )
        )

    out_path = Path(output)

    # Save original terminal settings
    old_tty = termios.tcgetattr(sys.stdin)
    start = time.time()

    try:
        with out_path.open("w", encoding="utf-8") as fp:
            _write_header(fp, cols, rows, title or f"ttylog — {cmd}", cmd)

            master_fd, slave_fd = pty.openpty()

            # Set slave PTY size to match current terminal
            fcntl_import = __import__("fcntl")
            TIOCSWINSZ = getattr(__import__("termios"), "TIOCSWINSZ", 0x5414)
            fcntl_import.ioctl(
                slave_fd, TIOCSWINSZ,
                struct.pack("HHHH", rows, cols, 0, 0),
            )

            pid = os.fork()
            if pid == 0:
                # Child
                os.setsid()
                fcntl_import.ioctl(slave_fd, TIOCSWINSZ,
                                   struct.pack("HHHH", rows, cols, 0, 0))
                os.dup2(slave_fd, 0)
                os.dup2(slave_fd, 1)
                os.dup2(slave_fd, 2)
                os.close(master_fd)
                os.close(slave_fd)
                os.execvp(cmd_list[0], cmd_list)
                sys.exit(1)

            os.close(slave_fd)

            # Set stdin to raw mode
            tty.setraw(sys.stdin.fileno())

            # Handle SIGWINCH (terminal resize)
            def _resize(sig, frame):
                new_cols, new_rows = _terminal_size()
                fcntl_import.ioctl(
                    master_fd, TIOCSWINSZ,
                    struct.pack("HHHH", new_rows, new_cols, 0, 0),
                )
                _write_event(fp, time.time() - start, "r", f"{new_cols}x{new_rows}")

            signal.signal(signal.SIGWINCH, _resize)

            try:
                while True:
                    r, _, _ = select.select([sys.stdin, master_fd], [], [], 0.1)

                    if sys.stdin in r:
                        data = os.read(sys.stdin.fileno(), 1024)
                        if not data:
                            break
                        _write_event(fp, time.time() - start, "i", data.decode("utf-8", errors="replace"))
                        os.write(master_fd, data)

                    if master_fd in r:
                        try:
                            data = os.read(master_fd, 4096)
                        except OSError:
                            break
                        if not data:
                            break
                        _write_event(fp, time.time() - start, "o", data.decode("utf-8", errors="replace"))
                        os.write(sys.stdout.fileno(), data)

            except (KeyboardInterrupt, OSError):
                pass

            os.waitpid(pid, 0)

    finally:
        termios.tcsetattr(sys.stdin, termios.TCSAFLUSH, old_tty)
        signal.signal(signal.SIGWINCH, signal.SIG_DFL)

    duration = time.time() - start
    if not quiet:
        console.print(
            f"\n[green]✓[/green] Saved [bold]{output}[/bold]  "
            f"({duration:.1f}s recorded)"
        )


# ── Trim ─────────────────────────────────────────────────────────────────────

def trim(source: str, output: str, max_gap: float) -> None:
    """Remove idle gaps longer than max_gap seconds."""
    p = Path(source)
    if not p.exists():
        console.print(f"[red]File not found:[/red] {source}")
        raise typer.Exit(1)

    lines = p.read_text(encoding="utf-8").splitlines()
    header = json.loads(lines[0])
    events = []
    for line in lines[1:]:
        line = line.strip()
        if line:
            events.append(json.loads(line))

    trimmed = []
    time_offset = 0.0
    prev_t = 0.0

    for i, event in enumerate(events):
        t, etype, data = event
        gap = t - prev_t
        if gap > max_gap:
            time_offset += gap - max_gap
        trimmed.append([round(t - time_offset, 6), etype, data])
        prev_t = t

    out_path = Path(output)
    with out_path.open("w", encoding="utf-8") as fp:
        fp.write(json.dumps(header) + "\n")
        for e in trimmed:
            fp.write(json.dumps(e) + "\n")

    saved = events[-1][0] - trimmed[-1][0] if events else 0
    console.print(
        f"[green]✓[/green] Trimmed [bold]{source}[/bold] → [bold]{output}[/bold]  "
        f"(saved [cyan]{saved:.1f}s[/cyan] of idle time)"
    )


# ── Info ──────────────────────────────────────────────────────────────────────

def info(source: str) -> None:
    p = Path(source)
    if not p.exists():
        console.print(f"[red]File not found:[/red] {source}")
        raise typer.Exit(1)

    lines = p.read_text(encoding="utf-8").splitlines()
    header = json.loads(lines[0])
    events = [json.loads(l) for l in lines[1:] if l.strip()]

    output_events = [e for e in events if e[1] == "o"]
    input_events  = [e for e in events if e[1] == "i"]
    duration = events[-1][0] if events else 0

    t = Table(box=box.ROUNDED, show_header=False)
    t.add_column("Key",   style="bold cyan", width=16)
    t.add_column("Value", style="white")

    t.add_row("File",       source)
    t.add_row("Title",      header.get("title", "—"))
    t.add_row("Command",    header.get("command", "—"))
    t.add_row("Terminal",   f"{header.get('width', '?')}×{header.get('height', '?')}")
    t.add_row("Duration",   f"{duration:.1f}s")
    t.add_row("Events",     str(len(events)))
    t.add_row("Output",     str(len(output_events)))
    t.add_row("Input",      str(len(input_events)))
    t.add_row("File size",  f"{p.stat().st_size / 1024:.1f} KB")

    console.print(t)


# ── Play ──────────────────────────────────────────────────────────────────────

def play(source: str, speed: float) -> None:
    """Replay a .cast file in the terminal."""
    p = Path(source)
    if not p.exists():
        console.print(f"[red]File not found:[/red] {source}")
        raise typer.Exit(1)

    lines = p.read_text(encoding="utf-8").splitlines()
    events = [json.loads(l) for l in lines[1:] if l.strip()]
    output_events = [(e[0], e[2]) for e in events if e[1] == "o"]

    console.print(f"[dim]Replaying {source} at {speed}× speed. Ctrl-C to stop.[/dim]\n")

    prev_t = 0.0
    try:
        for t, data in output_events:
            delay = (t - prev_t) / speed
            if delay > 0:
                time.sleep(min(delay, 5.0))  # cap single sleep to 5s
            sys.stdout.write(data)
            sys.stdout.flush()
            prev_t = t
    except KeyboardInterrupt:
        pass
    print()


# ── Export HTML ───────────────────────────────────────────────────────────────

# Minimal self-contained HTML player using asciinema-player CDN
_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/asciinema-player@3.7.0/dist/bundle/asciinema-player.min.css">
<style>
  body {{
    background: #1a1a1a;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    font-family: system-ui, sans-serif;
    color: #ccc;
  }}
  h1 {{ font-size: 1rem; opacity: .6; margin-bottom: 1rem; }}
  #player {{ width: min(95vw, 900px); }}
</style>
</head>
<body>
<h1>{title_escaped}</h1>
<div id="player"></div>
<script src="https://cdn.jsdelivr.net/npm/asciinema-player@3.7.0/dist/bundle/asciinema-player.min.js"></script>
<script>
const castData = {cast_json};
const blob = new Blob([castData], {{type: "text/plain"}});
const url  = URL.createObjectURL(blob);
AsciinemaPlayer.create(url, document.getElementById("player"), {{
  cols: {cols},
  rows: {rows},
  autoPlay: true,
  loop: false,
  speed: 1,
  theme: "monokai",
  fit: "width",
}});
</script>
</body>
</html>
"""

def export_html(source: str, output: str) -> None:
    p = Path(source)
    if not p.exists():
        console.print(f"[red]File not found:[/red] {source}")
        raise typer.Exit(1)

    cast_text = p.read_text(encoding="utf-8")
    header = json.loads(cast_text.splitlines()[0])
    title = header.get("title", Path(source).stem)

    html_out = _HTML_TEMPLATE.format(
        title=html.escape(title),
        title_escaped=html.escape(title),
        cast_json=json.dumps(cast_text),
        cols=header.get("width", 80),
        rows=header.get("height", 24),
    )

    Path(output).write_text(html_out, encoding="utf-8")
    console.print(
        f"[green]✓[/green] Exported to [bold]{output}[/bold]  "
        f"({Path(output).stat().st_size // 1024} KB)\n"
        f"[dim]Open in any browser — no server required.[/dim]"
    )


# ── CLI commands ─────────────────────────────────────────────────────────────

@app.command()
def record_cmd(
    output: str = typer.Argument(..., help="Output .cast file path."),
    command: str = typer.Option("", "--command", "-c", help="Command to run (default: $SHELL)."),
    title:   str = typer.Option("", "--title",   "-t", help="Session title."),
    quiet:   bool = typer.Option(False, "--quiet", "-q", help="Suppress banner."),
) -> None:
    """Record a terminal session to a .cast file."""
    if sys.platform == "win32":
        console.print("[red]Recording is not supported on Windows (requires Unix PTY).[/red]")
        raise typer.Exit(1)
    record(output, command, title, quiet)


@app.command()
def play_cmd(
    source: str = typer.Argument(..., help=".cast file to replay."),
    speed:  float = typer.Option(1.0, "--speed", "-s", help="Playback speed multiplier (default 1.0).", min=0.1, max=10.0),
) -> None:
    """Replay a recorded session in the terminal."""
    play(source, speed)


@app.command()
def export_cmd(
    source: str = typer.Argument(..., help=".cast file to export."),
    output: str = typer.Argument(..., help="Output HTML file path."),
) -> None:
    """Export a session as a self-contained HTML file (no server needed)."""
    export_html(source, output)


@app.command()
def trim_cmd(
    source:  str   = typer.Argument(..., help="Input .cast file."),
    output:  str   = typer.Argument(..., help="Output .cast file."),
    max_gap: float = typer.Option(2.0, "--max-gap", "-g", help="Max idle gap in seconds (default 2.0).", min=0.1),
) -> None:
    """Trim idle gaps from a recording."""
    trim(source, output, max_gap)


@app.command()
def info_cmd(
    source: str = typer.Argument(..., help=".cast file to inspect."),
) -> None:
    """Show metadata and statistics about a .cast file."""
    info(source)


# Alias mapping for natural CLI feel
app.command(name="record")(record_cmd)
app.command(name="play")(play_cmd)
app.command(name="export")(export_cmd)
app.command(name="trim")(trim_cmd)
app.command(name="info")(info_cmd)

if __name__ == "__main__":
    app()
