# create-star-app

Flask architecture scaffolding tool that generates core server files for the star app architecture.

## What it does

`create-star-app` is an interactive CLI that prompts for project configuration (name, port, timezone, etc.) and generates a ready-to-use Flask server directory with all the boilerplate files pre-configured.

## Installation

```bash
pip install -e .
```

## Usage

Run the CLI from the directory where you want to create your project:

```bash
create-star-app
```

You will be prompted for:

- **Project name** (required)
- **Port** (default: 5000)
- **Production server endpoint** (default: empty)
- **Client app subdirectory** (default: client/src/app)
- **Timezone offset** (default: 8)

The tool will generate the `server/`, `server/schemas/`, and `.vscode/` directories with all template files rendered using your configuration.

## Development

```bash
pip install -e .
```

Then run directly:

```bash
python -m create_star_app.cli
```
