from create_star_app.config import ProjectConfig
from create_star_app import scaffold


def _prompt(label: str, default: str = "") -> str:
    """Prompt the user for input, showing a default value if provided."""
    if default:
        raw = input(f"  {label} [{default}]: ").strip()
        return raw if raw else default
    else:
        return input(f"  {label}: ").strip()


def main() -> None:
    print()
    print("=" * 56)
    print("  create-star-app")
    print("  Flask Architecture Scaffolding Tool")
    print("=" * 56)
    print()

    # projectName is required — loop until non-empty
    project_name = ""
    while not project_name:
        project_name = _prompt("Project name (required)")
        if not project_name:
            print("  Project name cannot be empty. Please try again.")

    print()
    print("  Press Enter to use the default value shown in [brackets].")
    print()

    port_str = _prompt("Port", "5000")
    try:
        port = int(port_str)
    except ValueError:
        print(f"  Invalid port '{port_str}', using default 5000.")
        port = 5000

    client_subdir = _prompt("Client app subdirectory", "client/app")

    tz_str = _prompt("Timezone offset (hours)", "8")
    try:
        timezone = int(tz_str)
    except ValueError:
        print(f"  Invalid timezone '{tz_str}', using default 8.")
        timezone = 8

    gcp_region = _prompt("GCP region", "asia-east1")

    config = ProjectConfig(
        projectName=project_name,
        port=port,
        clientAppSubdir=client_subdir,
        timezone=timezone,
        gcpRegion=gcp_region,
    )

    print()
    scaffold.create_project(config)


if __name__ == "__main__":
    main()
