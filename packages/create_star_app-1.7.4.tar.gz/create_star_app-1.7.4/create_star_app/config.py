from dataclasses import dataclass, asdict


@dataclass
class ProjectConfig:
    projectName: str
    port: int = 5000
    clientAppSubdir: str = "client/src/app"
    timezone: int = 8
    gcpRegion: str = "asia-east1"
    ensureIndexesBody: str = "pass"

    def to_template_vars(self) -> dict:
        """Return a flat dict of all values for string.Template substitution."""
        return asdict(self)
