import os
import re
import string
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Literal

from mneia_isbn import ISBN

_SSID_PATTERN = re.compile(r"(?<![0-9a-zA-Z])\d{8}(?![0-9a-zA-Z])")
_SSID_FORBIDDEN_PREFIX_PATTERN = re.compile(r"^(1[7-9]|2\d|7\d)\d{6}$")
_ISBN_CANDIDATE_PATTERN = re.compile(r"(?<!\d)(\d{9}[0-9Xx]|\d{13})(?!\d)")
_ISBN_SEPARATOR_PATTERN = re.compile(r"[-·\s]")
_MULTI_SPACE_PATTERN = re.compile(r"\s+")
_TITLE_EXT_PATTERN = re.compile(
    r"\.(pdf|epub|mobi|txt|docx|doc|fb2|djvu|tar.gz|rar|zip|uvz|azw3|7z|pdz|caj)$",
    flags=re.IGNORECASE,
)
_YEAR_ONLY_PATTERN = re.compile(r"^\s*(\d{4})\s*(?:年)?\s*$")
_YEAR_MONTH_ONLY_PATTERN = re.compile(r"^\s*(\d{4})\s*(?:年|[\-\./])\s*(\d{1,2})\s*(?:月)?\s*$")
_DATE_PARSE_FORMATS = (
    "%Y%m%d",
    "%Y-%m-%d",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d %H:%M:%S",
    "%Y/%m/%d",
    "%Y/%m/%d %H:%M",
    "%Y/%m/%d %H:%M:%S",
    "%Y.%m.%d",
    "%Y.%m.%d %H:%M",
    "%Y.%m.%d %H:%M:%S",
)


# 默认需要替换的标点（不含 allowed_chars 中的字符）
BASE_PUNCTUATION = string.punctuation  # 包含 !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
CHINESE_PUNCTUATION = "，。！？；：“”‘’《》【】、（）……——～～▪"


def _is_token_char(ch: str) -> bool:
    if not ch:
        return False
    return unicodedata.category(ch)[0] in {"L", "N"}


def _collapse_replacement_runs(text: str, replacement_char: str) -> str:
    if not text or not replacement_char:
        return text

    pieces: list[str] = []
    index = 0
    step = len(replacement_char)

    while index < len(text):
        if text.startswith(replacement_char, index):
            run_end = index
            while text.startswith(replacement_char, run_end):
                run_end += step

            left_char = text[index - 1] if index > 0 else ""
            right_char = text[run_end] if run_end < len(text) else ""
            if _is_token_char(left_char) and _is_token_char(right_char):
                pieces.append(replacement_char)
            else:
                pieces.append(text[index:run_end])
            index = run_end
            continue

        pieces.append(text[index])
        index += 1

    return "".join(pieces)


def _truncate_text(text: str, max_length: int, truncation_suffix: str = "") -> str:
    max_length = max(0, max_length)
    if len(text) <= max_length:
        return text

    if not truncation_suffix:
        return text[:max_length]

    if len(truncation_suffix) >= max_length:
        return truncation_suffix[:max_length]

    return text[: max_length - len(truncation_suffix)] + truncation_suffix


def _truncate_preserving_extension(text: str, max_length: int, truncation_suffix: str = "") -> str:
    max_length = max(0, max_length)
    if len(text) <= max_length:
        return text

    if "." not in text or text.startswith("."):
        return _truncate_text(text, max_length, truncation_suffix)

    base, ext = text.rsplit(".", 1)
    ext_part = "." + ext
    if len(ext_part) >= max_length:
        return _truncate_text(text, max_length, truncation_suffix)

    base_limit = max_length - len(ext_part)
    truncated_base = _truncate_text(base, base_limit, truncation_suffix)
    result = truncated_base + ext_part
    if len(result) <= max_length:
        return result

    return _truncate_text(text, max_length, truncation_suffix)


def _is_cjk(ch: str) -> bool:
    if not ch:
        return False
    cp = ord(ch)
    # CJK Unified Ideographs ranges (常用)
    return (
        0x4E00 <= cp <= 0x9FFF
        or 0x3400 <= cp <= 0x4DBF
        or 0x20000 <= cp <= 0x2A6DF
        or 0x2A700 <= cp <= 0x2B73F
        or 0x2B740 <= cp <= 0x2B81F
        or 0x2B820 <= cp <= 0x2CEAF
    )


def _char_allowed_by_policy(ch: str, policy: str, allowed_chars: str, keep_spaces: bool, always_keep: str = "") -> bool:
    if not ch:
        return False
    # 始终允许在 always_keep 中声明的字符
    if always_keep and ch in always_keep:
        return True

    if ch in allowed_chars:
        return True

    if ch.isspace():
        return keep_spaces

    if policy == "default":
        return _is_token_char(ch)

    if policy == "cjk_latin":
        # 允许中文字符、ASCII 字母和数字
        return _is_cjk(ch) or ch.isascii() and (ch.isalpha() or ch.isdigit())

    if policy == "latin":
        # 仅允许 ASCII 英文字母与数字
        return ch.isascii() and (ch.isalpha() or ch.isdigit())

    if policy == "alnum_":
        return ch.isascii() and (ch.isalnum() or ch == "_")

    # fallback: default behavior
    return _is_token_char(ch)


def _try_parse_datetime(text: str) -> datetime | None:
    text = text.strip()
    if not text:
        return None

    candidates = [
        text,
        text.replace("T", " "),
        text.replace("Z", "+00:00"),
        text.replace("T", " ").replace("Z", "+00:00"),
        text.replace("年", "-").replace("月", "").replace("日", ""),
        text.replace("年", "-").replace("月", "-").replace("日", ""),
    ]

    seen: set[str] = set()
    normalized_candidates: list[str] = []
    for candidate in candidates:
        candidate = candidate.strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        normalized_candidates.append(candidate)

    for candidate in normalized_candidates:
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            continue

    for candidate in normalized_candidates:
        try:
            for fmt in _DATE_PARSE_FORMATS:
                try:
                    return datetime.strptime(candidate, fmt)
                except ValueError:
                    continue
        except ValueError:
            continue

    return None


def is_valid_date(text: str) -> bool:
    """
    判断 8 位数字是否可解释为有效日期。

    支持两种形式：
    - YYYYMMDD
    - YYYYDDMM（兼容少见写法）
    """
    if len(text) != 8:
        return False

    try:
        year = int(text[:4])
        month = int(text[4:6])
        day = int(text[6:8])
        if 1700 <= year <= 2950 and 1 <= month <= 12 and 1 <= day <= 31:
            datetime(year, month, day)
            return True
    except ValueError:
        pass

    try:
        year = int(text[:4])
        day = int(text[4:6])
        month = int(text[6:8])
        if 1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31:
            datetime(year, month, day)
            return True
    except ValueError:
        pass

    return False


def extract_year_month(text: str) -> str:
    """
    将日期相关字符串规范化为 YYYY.MM 或 YYYY。

    规则：
    - 形如 YYYY年MM月DD日 / YYYY-MM-DD / YYYY/MM/DD / YYYY.MM.DD / YYYYMMDD -> YYYY.MM
    - 支持日期后带时间，如 YYYY-MM-DD HH:MM[:SS] -> YYYY.MM
    - 形如 YYYY 或 YYYY年 -> YYYY
    - 月份不足两位时补零
    - 输入无法识别时返回空字符串
    """
    if not text or not isinstance(text, str):
        return ""

    text = text.strip()

    match = _YEAR_ONLY_PATTERN.fullmatch(text)
    if match:
        return match.group(1)

    match = _YEAR_MONTH_ONLY_PATTERN.fullmatch(text)
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        if not 1 <= month <= 12:
            return ""
        return f"{year:04d}.{month:02d}"

    parsed_dt = _try_parse_datetime(text)
    if parsed_dt is None:
        return ""

    return f"{parsed_dt.year:04d}.{parsed_dt.month:02d}"


def extract_yyyymm(text: str) -> str:
    """
    `extract_year_month` 的等价别名。

    返回值与 `extract_year_month` 完全一致。
    """
    return extract_year_month(text)


def extract_ssid(text: str | int) -> int | None:
    """
    从文本中提取第一个 SSID（8 位数字）。

    规则：
    - 必须是独立数字块（前后不能紧邻字母或数字）
    - 排除可识别为日期的 8 位数字
    - 首位不能为 0
    - 前两位不能在 17~29 之间（即排除 17/18/19 和所有 2 开头）
    - 不能以 7 开头

    返回：
    - 提取成功：SSID 整数
    - 提取失败：None
    """
    if isinstance(text, int):
        text_str = str(text)
        if 10000000 <= text <= 99999999 and not is_valid_date(text_str) and not _SSID_FORBIDDEN_PREFIX_PATTERN.fullmatch(text_str):
            return text
        return None

    if not text or not isinstance(text, str):
        return None

    for match in _SSID_PATTERN.findall(text):
        if not is_valid_date(match) and len(match) == 8 and match[0] != "0" and not _SSID_FORBIDDEN_PREFIX_PATTERN.fullmatch(match):
            return int(match)

    return None


def extract_isbn(text: str) -> str:
    """
    从文本中提取第一个有效 ISBN，并统一返回 ISBN-13。

    支持：
    - ISBN-10（末位可为 X/x）
    - ISBN-13
    - 文本中含空格、短横线、间隔符（会先清理）
    """
    if not text or not isinstance(text, str):
        return ""

    clean_text = _ISBN_SEPARATOR_PATTERN.sub("", text)

    for candidate in _ISBN_CANDIDATE_PATTERN.findall(clean_text):
        try:
            if candidate[-1] == "x":
                candidate = candidate[:-1] + "X"

            bn = ISBN(candidate)
            if bn.is_valid:
                return bn.as_isbn13

            if len(candidate) == 10:
                bn3 = ISBN("978" + candidate)
                if bn3.is_valid:
                    return bn3.as_isbn13
                continue

            if candidate.startswith("978") and len(candidate) == 13:
                bn2 = ISBN(candidate[3:])
                if bn2.is_valid:
                    return bn2.as_isbn13
                continue

            if candidate.startswith("987") and len(candidate) == 13:
                bn3 = ISBN(f"978{candidate[3:]}")
                if bn3.is_valid:
                    return bn3.as_isbn13
                continue
        except Exception:
            pass

    return ""


def extract_filetype(filename: str | Path) -> str | None:
    """
    从文件名提取合法扩展名并返回小写。

    规则：
    - 只取最后一段后缀（如 tar.gz 返回 gz）
    - 仅允许字母和数字
    - 长度需小于 5
    """
    suffix = Path(filename).suffix
    if not suffix:
        return None

    ext = suffix[1:].lower()
    if len(ext) >= 5:
        return None

    if re.fullmatch(r"[A-Za-z0-9]+", ext):
        return ext.lower()

    return None


def is_ssid_or_isbn(text: str) -> bool:
    """
    判断文本是否包含可识别的 SSID 或 ISBN。
    """
    return bool(extract_ssid(text) or extract_isbn(text))


def extract_dxid(text: str) -> str:
    """从文本中提取 dxid。
    dxid 要么
    1. 以 ZZ_ 开头，后跟 [A-Z0-9_a-z] 字符（不含小数点），直到遇到非法字符或小数点时截断；
    2. 或者以 12 位数字开头（自动忽略后续字符）。
    """
    if not text:
        return ""
    # 如果文本是一个路径, 则只取文件名部分进行匹配

    text = Path(text).stem

    # 匹配开头的 ZZ_ 标识符（字母数字下划线），遇到非允许字符或小数点时自动结束
    match_zz = re.match(r"ZZ_[A-Za-z0-9_]+", text)
    if match_zz:
        return match_zz.group(0)

    # 匹配开头的 12 位数字
    match_digits = re.match(r"\d{12}", text)
    if match_digits:
        return match_digits.group(0)

    return ""


def normalize_title(title: str) -> str:
    """
    规范化标题文本。

    处理步骤：
    - 合并多余空白
    - 去掉常见电子书扩展名
    - 移除可识别的 SSID / ISBN
    - 将下划线和竖线标准化为空格
    """
    title = title.strip()
    title = _MULTI_SPACE_PATTERN.sub(" ", title)
    title = _TITLE_EXT_PATTERN.sub("", title)

    ssid = extract_ssid(title)
    if ssid is not None:
        title = title.replace(str(ssid), "")

    isbn = extract_isbn(title)
    if isbn:
        title1 = title.replace(isbn, "")
        if title1 != title:
            title = title1
        else:
            title1 = re.sub(r"[-—一·\s]", "", title)
            title1 = title1.replace(isbn, "")
            title = title1

    title = title.replace("_", " ").replace("│", " ")
    title = _MULTI_SPACE_PATTERN.sub(" ", title).strip()

    return title


def standardize_title(
    filename: str,
    max_length: int = 200,
    replacement_char: str = "_",
    keep_spaces: bool = True,
    collapse_replacement: bool = True,
    allowed_chars: str = "._-",
    remove_control_chars: bool = True,
    strip_separators: bool = False,
    case: Literal["keep", "lower", "upper"] = "keep",
    protect_extension: bool = True,
    normalize_unicode: bool = False,
    char_policy: Literal["default", "cjk", "latin", "alnum_"] = "default",
    truncation_suffix: str = "",
    always_keep: str = "_ ",
    empty_input_return: str = "",
    empty_result_return: str = "untitled",
    extract_basename: bool = True,  # 新增参数，默认 True
) -> str:
    """
    通用文件名清洗函数：替换或删除特殊符号，支持长度限制、扩展名保护等。

    参数:
        filename: 原始文件名（如果 extract_basename=True 且包含路径，会自动提取文件名部分）
        max_length: 最大长度（包含 truncation_suffix）
        replacement_char: 用于替换不合法字符的字符（如 '_' 或 '-' 或 ''）
        keep_spaces: 是否保留空格（True保留，False则空格也被替换）
        collapse_replacement: 是否将连续多个 replacement_char 压缩为单个
        allowed_chars: 额外允许保留的字符（不含字母数字汉字及空格）
        remove_control_chars: 是否移除 ASCII 控制字符
        strip_separators: 是否去除首尾的 replacement_char 和空格
        case: 大小写转换策略
        protect_extension: 是否保护扩展名（截断时不破坏最后一个点号后的内容）
        normalize_unicode: 是否进行 Unicode 规范化（将 é 分解为 e + 组合符，然后组合符会被移除）
        char_policy: 字符保留策略，可选：
            - "default": 保持原有的基于 Unicode 类别的保留（字母/数字等）
            - "cjk": 只保留常见中文和 ASCII 拉丁字母/数字
            - "latin": 只保留 ASCII 英文字母和数字
            - "alnum_": 只保留 ASCII 字母数字和下划线（A-Za-z0-9_）
        truncation_suffix: 截断后添加的后缀（如 "..."）
        empty_input_return: 当 filename 为空时返回的值
        empty_result_return: 当清洗后结果为空时返回的值
        extract_basename: 是否提取纯文件名（去除目录路径），默认为 True，自动调用 os.path.basename

    返回:
        处理后的字符串
    """
    if not filename:
        return empty_input_return

    # 可选：提取 basename（去除路径），兼容 Unix/Windows 分隔符
    if extract_basename:
        # 统一将反斜杠转为斜杠，再取最后一段
        if isinstance(filename, str):
            filename = filename.replace("\\", "/")
        filename = os.path.basename(filename)

    result = filename

    # 1. Unicode 规范化（可选）
    if normalize_unicode:
        result = unicodedata.normalize("NFKD", result)
        result = "".join(ch for ch in result if not unicodedata.combining(ch))

    # 2. 移除控制字符
    if remove_control_chars:
        result = "".join(ch for ch in result if ord(ch) >= 32 or ch == "\t")
        result = re.sub(r"[\x00-\x1f\x7f]", "", result)

    # 2.1 按策略决定允许哪些字符（更通用，避免为特定符号硬编码）
    if char_policy != "default":
        out_chars: list[str] = []
        for ch in result:
            if _char_allowed_by_policy(ch, char_policy, allowed_chars, keep_spaces, always_keep=always_keep):
                out_chars.append(ch)
                continue

            # 若为标点或符号，视为需要替换为 replacement_char（否则丢弃）
            cat = unicodedata.category(ch)
            if cat and cat[0] in ("P", "S"):
                if replacement_char:
                    out_chars.append(replacement_char)
                continue

            # 其他字符（不可识别的控制/特殊符号）直接丢弃
            continue

        result = "".join(out_chars)

    # 3. 构建需要替换的字符集（标点符号中除去 allowed_chars）
    punctuation_to_replace = BASE_PUNCTUATION + CHINESE_PUNCTUATION
    for ch in allowed_chars:
        punctuation_to_replace = punctuation_to_replace.replace(ch, "")
    replace_chars = punctuation_to_replace
    if not keep_spaces:
        replace_chars += " \t"

    # 4. 替换为 replacement_char
    if replace_chars:
        pattern = "[" + re.escape(replace_chars) + "]"
        if replacement_char == "":
            result = re.sub(pattern, "", result)
        else:
            result = re.sub(pattern, replacement_char, result)

    # 5. 压缩连续的 replacement_char
    if collapse_replacement and replacement_char:
        result = _collapse_replacement_runs(result, replacement_char)

    # 6. 空格处理（保留空格时压缩连续空格）
    if keep_spaces:
        result = re.sub(r" +", " ", result).strip()
    # else: 空格已被替换，无需额外处理

    # 6.1 去除点号周围不必要的空格，保证扩展名紧贴点号
    result = re.sub(r"\s*\.\s*", ".", result)

    # 7. 大小写转换
    if case == "lower":
        result = result.lower()
    elif case == "upper":
        result = result.upper()

    # 8. 去除首尾的分隔符和空格
    if strip_separators and replacement_char:
        result = result.strip(" " + replacement_char)
    elif strip_separators:
        result = result.strip()

    # 9. 长度限制与扩展名保护
    if protect_extension:
        result = _truncate_preserving_extension(result, max_length, truncation_suffix)
    else:
        result = _truncate_text(result, max_length, truncation_suffix)

    # 10. 最终空结果处理
    if not result or result.strip(" " + replacement_char).strip() == "":
        return empty_result_return

    return result
