"""utils.py"""

import datetime
import re
from bisect import bisect_left
from typing import Any


def get_child_value(data: Any, key: str) -> Any:
    """
    Look up `key` in a nested dict/list. Dotted keys descend into children.

    String values that look like numbers or booleans are coerced
    (e.g. "16" -> 16, "true" -> True). Use `get_raw_value` for ID-shaped
    fields like chapter or track keys where leading-zero formatting matters.
    """
    value = get_raw_value(data, key)
    if isinstance(value, str):
        lower = value.lower()
        if lower == "true":
            return True
        if lower == "false":
            return False
        if lower.lstrip("+-").isdigit():
            return int(value)
    return value


def get_raw_value(data: Any, key: str) -> Any:
    """Like `get_child_value` but returns the raw value with no type coercion."""
    value: Any = data
    for x in key.split("."):
        try:
            value = value[x]
            continue
        except Exception:
            pass

        try:
            value = value[int(x)]
            continue
        except Exception:
            return None
    return value


def parse_datetime(value: str, timezone) -> datetime.datetime:
    if value is None:
        return datetime.datetime(2000, 1, 1, tzinfo=timezone)

    value = value.replace("-", "").replace("T", "").replace(":", "").replace("Z", "")
    m = re.match(r"(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})", value)
    return datetime.datetime(
        year=int(m.group(1)),
        month=int(m.group(2)),
        day=int(m.group(3)),
        hour=int(m.group(4)),
        minute=int(m.group(5)),
        second=int(m.group(6)),
        tzinfo=timezone,
    )


def take_closest(list: list, number: int) -> int:
    """
    Assumes list is sorted. Returns closest value to number. Used for volume mapping.

    If two numbers are equally close, return the smallest number.
    """
    pos = bisect_left(list, number)
    if pos == 0:
        return list[0]
    if pos == len(list):
        return list[-1]
    before = list[pos - 1]
    after = list[pos]
    if after - number < number - before:
        return after
    else:
        return before
