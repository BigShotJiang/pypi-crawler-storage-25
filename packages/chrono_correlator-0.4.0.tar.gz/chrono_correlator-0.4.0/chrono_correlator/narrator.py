import os
from abc import ABC, abstractmethod

from .models import AlertReport, CorrelationResult


def _build_prompt(r: CorrelationResult) -> str:
    return (
        "Datos estadísticos CALCULADOS (no los inventes ni los modifiques):\n"
        f"Variable: {r.metric_name}\n"
        f"Mediana baseline: {r.baseline_median}\n"
        f"Mediana pre-evento: {r.pre_event_median}\n"
        f"p-valor Mann-Whitney U: {r.p_value}\n"
        f"Tamaño del efecto (rank-biserial): {r.effect_size}\n"
        "Escribe UNA frase en español. Máximo 20 palabras.\n"
        "Usa: patrón detectado, asociación observada.\n"
        "Prohibido: diagnóstico, causa, predice, confirma."
    )


class BaseNarrator(ABC):
    """Abstract base for LLM narrator providers."""

    @abstractmethod
    def generate(self, prompt: str) -> str:
        """Return a single narration sentence for the given prompt."""

    def narrate(self, report: AlertReport) -> AlertReport:
        if report.level == "green":
            return report

        individual_narratives: list[str] = []
        for result in report.results:
            if result.significant:
                result.narrative = self.generate(_build_prompt(result))
                individual_narratives.append(f"[{result.metric_name}] {result.narrative}")

        report.narrative = "\n".join(individual_narratives) if individual_narratives else None
        return report


class GroqNarrator(BaseNarrator):
    def __init__(self, api_key: str | None = None, model: str = "llama3-8b-8192"):
        try:
            from groq import Groq
        except ImportError:
            raise ImportError(
                "groq is not installed. Run: pip install chrono-correlator[groq]"
            )
        self._client = Groq(api_key=api_key or os.environ["GROQ_API_KEY"])
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=80,
        )
        return response.choices[0].message.content.strip()


class AnthropicNarrator(BaseNarrator):
    def __init__(self, api_key: str | None = None, model: str = "claude-haiku-4-5-20251001"):
        try:
            import anthropic as _anthropic
        except ImportError:
            raise ImportError(
                "anthropic is not installed. Run: pip install chrono-correlator[anthropic]"
            )
        self._client = _anthropic.Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=80,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text.strip()


def narrate(report: AlertReport, provider: str = "groq") -> AlertReport:
    """Convenience wrapper — picks narrator by provider name string."""
    narrator: BaseNarrator
    if provider == "groq":
        narrator = GroqNarrator()
    elif provider == "anthropic":
        narrator = AnthropicNarrator()
    else:
        raise ValueError(
            f"Unknown provider '{provider}'. Use 'groq', 'anthropic', "
            "or instantiate a BaseNarrator subclass directly."
        )
    return narrator.narrate(report)
