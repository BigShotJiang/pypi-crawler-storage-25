from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Event:
    timestamp: datetime
    label: str
    notes: Optional[str] = None


@dataclass
class Metric:
    name: str
    timestamps: list[datetime]
    values: list[float]


@dataclass
class CorrelationResult:
    metric_name: str
    p_value: float
    significant: bool
    effect_size: float
    baseline_median: float
    pre_event_median: float
    narrative: Optional[str] = None


@dataclass
class AlertReport:
    level: str
    active_signals: int
    total_signals: int
    results: list[CorrelationResult]
    narrative: Optional[str] = None
