import pytest
from datetime import datetime, timedelta

from chrono_correlator.models import AlertReport, CorrelationResult
from chrono_correlator.narrator import BaseNarrator, GroqNarrator, AnthropicNarrator, narrate


def _make_report(level: str, significant: bool) -> AlertReport:
    result = CorrelationResult(
        metric_name="hrv",
        p_value=0.01 if significant else 0.9,
        significant=significant,
        effect_size=0.8 if significant else 0.0,
        baseline_median=55.0,
        pre_event_median=30.0 if significant else 55.0,
    )
    return AlertReport(
        level=level,
        active_signals=1 if significant else 0,
        total_signals=1,
        results=[result],
    )


class _EchoNarrator(BaseNarrator):
    """Concrete subclass for testing — returns a fixed string."""
    def generate(self, prompt: str) -> str:
        return "Patrón detectado en la variable."


def test_base_narrator_green_unchanged():
    report = _make_report("green", significant=False)
    result = _EchoNarrator().narrate(report)
    assert result.narrative is None
    assert result.results[0].narrative is None


def test_base_narrator_yellow_fills_narrative():
    report = _make_report("yellow", significant=True)
    result = _EchoNarrator().narrate(report)
    assert result.narrative is not None
    assert "hrv" in result.narrative
    assert result.results[0].narrative == "Patrón detectado en la variable."


def test_custom_narrator_via_subclass():
    class _UpperNarrator(BaseNarrator):
        def generate(self, prompt: str) -> str:
            return "ASOCIACIÓN OBSERVADA."

    report = _make_report("red", significant=True)
    result = _UpperNarrator().narrate(report)
    assert result.results[0].narrative == "ASOCIACIÓN OBSERVADA."


def test_narrate_unknown_provider_raises():
    report = _make_report("yellow", significant=True)
    with pytest.raises(ValueError, match="Unknown provider"):
        narrate(report, provider="ollama")


def test_groq_narrator_missing_package(monkeypatch):
    import sys
    monkeypatch.setitem(sys.modules, "groq", None)
    with pytest.raises(ImportError, match="pip install chrono-correlator\\[groq\\]"):
        GroqNarrator()


def test_anthropic_narrator_missing_package(monkeypatch):
    import sys
    monkeypatch.setitem(sys.modules, "anthropic", None)
    with pytest.raises(ImportError, match="pip install chrono-correlator\\[anthropic\\]"):
        AnthropicNarrator()
