import pytest
from datetime import datetime, timedelta

from chrono_correlator.models import Event, Metric
from chrono_correlator.correlator import analyze


BASE = datetime(2024, 1, 1)


def _make_flat_metric(name: str, hours: int, value: float = 55.0) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [value] * hours
    return Metric(name=name, timestamps=timestamps, values=values)


def test_detects_real_pattern():
    hours = 700
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours

    event_days = [10, 20, 30]
    for day in event_days:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = 30.0

    metric = Metric(name="hrv", timestamps=timestamps, values=values)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric)

    assert result.significant is True
    assert result.pre_event_median < result.baseline_median
    assert result.narrative is None


def test_no_false_positive():
    metric = _make_flat_metric("hrv", hours=700, value=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in [10, 20, 30]]

    result = analyze(events, metric)

    assert result.significant is False


def test_insufficient_data():
    timestamps = [BASE + timedelta(hours=h) for h in range(2)]
    metric = Metric(name="hrv", timestamps=timestamps, values=[55.0, 55.0])
    events = [Event(timestamp=BASE + timedelta(days=1), label="test")]

    with pytest.raises(ValueError, match="Datos insuficientes"):
        analyze(events, metric)
