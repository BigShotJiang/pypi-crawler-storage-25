from datetime import datetime, timedelta

from chrono_correlator.models import Event, Metric
from chrono_correlator.engine import evaluate, monitor

BASE = datetime(2024, 1, 1)
EVENT_DAYS = [10, 20, 30]
EVENTS = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in EVENT_DAYS]


def _flat_metric(name: str, hours: int = 700, value: float = 55.0) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    return Metric(name=name, timestamps=timestamps, values=[value] * hours)


def _pattern_metric(name: str, hours: int = 700) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    for day in EVENT_DAYS:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = 30.0
    return Metric(name=name, timestamps=timestamps, values=values)


def test_green_level():
    metrics = [_flat_metric(f"m{i}") for i in range(7)]
    report = evaluate(EVENTS, metrics)
    assert report.level == "green"
    assert report.narrative is None


def test_yellow_level():
    metrics = [_pattern_metric(f"m{i}") for i in range(3)] + [
        _flat_metric(f"flat{i}") for i in range(4)
    ]
    report = evaluate(EVENTS, metrics)
    assert report.level == "yellow"
    assert report.active_signals == 3


def test_red_level():
    metrics = [_pattern_metric(f"m{i}") for i in range(5)] + [
        _flat_metric(f"flat{i}") for i in range(2)
    ]
    report = evaluate(EVENTS, metrics)
    assert report.level == "red"
    assert report.active_signals >= 5


def test_skips_insufficient_metrics():
    tiny = Metric(
        name="tiny",
        timestamps=[BASE + timedelta(hours=h) for h in range(2)],
        values=[55.0, 55.0],
    )
    metrics = [tiny, _flat_metric("good")]
    report = evaluate(EVENTS, metrics)
    assert report.total_signals == 1
    assert report.level == "green"


def _now_metric(name: str, hours: int = 700, value: float = 55.0) -> Metric:
    """Metric anchored to now so monitor()'s synthetic event falls inside the data."""
    now = datetime.now()
    timestamps = [now - timedelta(hours=hours - h) for h in range(hours)]
    return Metric(name=name, timestamps=timestamps, values=[value] * hours)


def _now_pattern_metric(name: str, hours: int = 700) -> Metric:
    """Metric anchored to now with a dip in the last 48h."""
    now = datetime.now()
    timestamps = [now - timedelta(hours=hours - h) for h in range(hours)]
    values = [55.0] * hours
    for h in range(48):
        values[hours - 48 + h] = 30.0
    return Metric(name=name, timestamps=timestamps, values=values)


def test_monitor_green_returns_no_narrative():
    metrics = [_now_metric(f"m{i}") for i in range(3)]
    report = monitor(metrics, narrate=False)
    assert report.level == "green"
    assert report.narrative is None


def test_monitor_detects_pattern():
    metrics = [_now_pattern_metric(f"m{i}") for i in range(5)] + [
        _now_metric(f"flat{i}") for i in range(2)
    ]
    report = monitor(metrics, narrate=False)
    assert report.level == "red"
    assert report.active_signals >= 5


def test_monitor_no_narrate_on_green():
    """narrate=True must not call LLM when level is green."""
    metrics = [_now_metric(f"m{i}") for i in range(3)]
    # narrate=True but level will be green — no API key needed
    report = monitor(metrics, narrate=True)
    assert report.narrative is None
