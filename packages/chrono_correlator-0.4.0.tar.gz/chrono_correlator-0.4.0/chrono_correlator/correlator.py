from datetime import timedelta

import numpy as np
from scipy import stats

from .models import CorrelationResult, Event, Metric


def analyze(
    events: list[Event],
    metric: Metric,
    lookback_hours: int = 48,
    baseline_days: int = 28,
) -> CorrelationResult:
    ts = np.array([t.timestamp() for t in metric.timestamps])
    vals = np.array(metric.values)

    pre_event_values: list[float] = []
    baseline_values: list[float] = []

    for event in events:
        t_event = event.timestamp.timestamp()
        t_pre_start = t_event - lookback_hours * 3600
        t_baseline_start = t_event - baseline_days * 86400

        mask_pre = (ts >= t_pre_start) & (ts < t_event)
        mask_baseline = (ts >= t_baseline_start) & (ts < t_pre_start)

        pre_event_values.extend(vals[mask_pre].tolist())
        baseline_values.extend(vals[mask_baseline].tolist())

    n1, n2 = len(pre_event_values), len(baseline_values)

    if n1 < 3 or n2 < 3:
        raise ValueError(
            f"Datos insuficientes para '{metric.name}'. "
            f"Pre-evento: {n1}, Baseline: {n2}"
        )

    stat, p_value = stats.mannwhitneyu(
        pre_event_values, baseline_values, alternative="two-sided"
    )
    effect_size = 1 - (2 * stat) / (n1 * n2)

    return CorrelationResult(
        metric_name=metric.name,
        p_value=float(p_value),
        significant=bool(p_value < 0.05),
        effect_size=float(effect_size),
        baseline_median=float(np.median(baseline_values)),
        pre_event_median=float(np.median(pre_event_values)),
        narrative=None,
    )
