from datetime import datetime

from .correlator import analyze
from .models import AlertReport, CorrelationResult, Event, Metric

THRESHOLDS = {"green": (0, 2), "yellow": (3, 4), "red": (5, 7)}


def evaluate(
    events: list[Event],
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
) -> AlertReport:
    results: list[CorrelationResult] = []

    for metric in metrics:
        try:
            results.append(analyze(events, metric, lookback_hours, baseline_days))
        except ValueError:
            continue

    active = sum(1 for r in results if r.significant)

    if active <= 2:
        level = "green"
    elif active <= 4:
        level = "yellow"
    else:
        level = "red"

    return AlertReport(
        level=level,
        active_signals=active,
        total_signals=len(results),
        results=results,
        narrative=None,
    )


def monitor(
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    provider: str = "groq",
    narrate: bool = True,
) -> AlertReport:
    """Evaluate current state without requiring past events.

    Creates a synthetic event at now() and runs the full pipeline.
    If the level is yellow or red and narrate=True, calls the LLM narrator.
    """
    from .narrator import narrate as _narrate

    now = datetime.now()
    synthetic_event = [Event(timestamp=now, label="monitor")]

    report = evaluate(synthetic_event, metrics, lookback_hours, baseline_days)

    if narrate and report.level != "green":
        report = _narrate(report, provider=provider)

    return report
