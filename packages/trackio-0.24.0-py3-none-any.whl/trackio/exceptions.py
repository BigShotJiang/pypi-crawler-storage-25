class TrackioAPIError(Exception):
    pass
