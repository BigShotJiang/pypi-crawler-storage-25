from types import SimpleNamespace
from unittest.mock import Mock

import json

from mn_sdk import BackpressurePolicy, Client, RetryPolicy, RunnerConfig, agent, workflow
from mn_sdk.bundle import BundleCompileError
from mn_sdk.decorators import registry

TEST_DEFAULT_TOPIC = "charging"


def test_agent_decorator():
    @agent.defn(type="map")
    def my_test_agent(data):
        return data

    assert "my_test_agent" in registry.agents
    agent_def = registry.agents["my_test_agent"]
    assert agent_def.agent_type == "map"
    assert agent_def.name == "my_test_agent"


def test_agent_decorator_accepts_explicit_name():
    @agent.defn(name="custom_agent", type="reduce")
    def named_agent(data):
        return data

    assert "custom_agent" in registry.agents
    assert registry.agents["custom_agent"].func is named_agent


def test_workflow_decorator():
    @workflow.defn(name="TestFlow")
    class TestFlow:
        @workflow.run
        def run_flow(self):
            pass

    assert "TestFlow" in registry.workflows
    wf_def = registry.workflows["TestFlow"]
    assert wf_def.name == "TestFlow"
    assert wf_def.run_method.__name__ == "run_flow"


def stubbed_client(
    monkeypatch,
    job_stub=None,
    cluster_stub=None,
    observability_stub=None,
    **client_kwargs,
):
    job_stub = job_stub or SimpleNamespace()
    cluster_stub = cluster_stub or SimpleNamespace()
    observability_stub = observability_stub or SimpleNamespace()
    monkeypatch.setattr("mn_sdk.client.grpc.insecure_channel", lambda _target: object())
    monkeypatch.setattr("mn_sdk.client.job_pb2_grpc.JobServiceStub", lambda _channel: job_stub)
    monkeypatch.setattr("mn_sdk.client.cluster_pb2_grpc.ClusterServiceStub", lambda _channel: cluster_stub)
    monkeypatch.setattr(
        "mn_sdk.client.observability_pb2_grpc.ObservabilityServiceStub",
        lambda _channel: observability_stub,
    )
    return Client(**client_kwargs), job_stub, cluster_stub, observability_stub


def test_job_rpc_methods_use_default_timeout(monkeypatch):
    monkeypatch.delenv("MN_GRPC_AUTH_TOKEN", raising=False)
    job_stub = SimpleNamespace(
        SubmitJob=Mock(return_value=SimpleNamespace(job_id="job-1")),
        GetJob=Mock(return_value=SimpleNamespace(job_json='{"job_id": "job-1"}')),
        ListJobs=Mock(return_value=SimpleNamespace(jobs_json='{"data": []}')),
        CancelJob=Mock(return_value=SimpleNamespace(status="cancelled")),
        PauseJob=Mock(return_value=SimpleNamespace(status="paused")),
        ResumeJob=Mock(return_value=SimpleNamespace(status="running")),
        ClearJobs=Mock(return_value=SimpleNamespace(cleared_count=2)),
    )
    client, _, _, _ = stubbed_client(monkeypatch, job_stub=job_stub)

    assert client.submit_job("{}", {}) == "job-1"
    assert client.get_job("job-1") == '{"job_id": "job-1"}'
    assert client.list_jobs() == '{"data": []}'
    assert client.cancel_job("job-1") == "cancelled"
    assert client.pause_job("job-1") == "paused"
    assert client.resume_job("job-1") == "running"
    assert client.clear_jobs() == 2

    for call in [
        job_stub.SubmitJob,
        job_stub.GetJob,
        job_stub.ListJobs,
        job_stub.CancelJob,
        job_stub.PauseJob,
        job_stub.ResumeJob,
        job_stub.ClearJobs,
    ]:
        _, kwargs = call.call_args
        assert kwargs["timeout"] == 10.0
        assert kwargs["metadata"] is None


def test_cluster_rpc_methods_use_default_timeout(monkeypatch):
    monkeypatch.delenv("MN_GRPC_AUTH_TOKEN", raising=False)
    cluster_stub = SimpleNamespace(
        GetSystemSummary=Mock(return_value=SimpleNamespace(summary_json='{"nodes": []}')),
        RemoveNode=Mock(return_value=SimpleNamespace(status="removed")),
    )
    client, _, _, _ = stubbed_client(monkeypatch, cluster_stub=cluster_stub)

    assert client.get_system_summary() == '{"nodes": []}'
    assert client.remove_node("node@127.0.0.1") == "removed"

    for call in [cluster_stub.GetSystemSummary, cluster_stub.RemoveNode]:
        _, kwargs = call.call_args
        assert kwargs["timeout"] == 10.0
        assert kwargs["metadata"] is None


def test_timeout_can_be_disabled_by_env(monkeypatch):
    monkeypatch.setenv("MN_GRPC_TIMEOUT_SECONDS", "none")
    job_stub = SimpleNamespace(
        ListJobs=Mock(return_value=SimpleNamespace(jobs_json='{"data": []}'))
    )
    client, _, _, _ = stubbed_client(monkeypatch, job_stub=job_stub)

    client.list_jobs()

    _, kwargs = job_stub.ListJobs.call_args
    assert kwargs["timeout"] is None


def test_timeout_zero_can_be_disabled_by_env(monkeypatch):
    monkeypatch.setenv("MN_GRPC_TIMEOUT_SECONDS", "0")
    job_stub = SimpleNamespace(
        ListJobs=Mock(return_value=SimpleNamespace(jobs_json='{"data": []}'))
    )
    client, _, _, _ = stubbed_client(monkeypatch, job_stub=job_stub)

    client.list_jobs()

    _, kwargs = job_stub.ListJobs.call_args
    assert kwargs["timeout"] is None


def test_invalid_timeout_env_raises(monkeypatch):
    monkeypatch.setenv("MN_GRPC_TIMEOUT_SECONDS", "soon")
    job_stub = SimpleNamespace()
    try:
        stubbed_client(monkeypatch, job_stub=job_stub)
    except ValueError as exc:
        assert "MN_GRPC_TIMEOUT_SECONDS" in str(exc)
    else:
        raise AssertionError("expected invalid timeout env to raise ValueError")


def test_auth_metadata_from_env(monkeypatch):
    monkeypatch.setenv("MN_GRPC_AUTH_TOKEN", "secret")
    job_stub = SimpleNamespace(
        ListJobs=Mock(return_value=SimpleNamespace(jobs_json='{"data": []}'))
    )
    client, _, _, _ = stubbed_client(monkeypatch, job_stub=job_stub)

    client.list_jobs()

    _, kwargs = job_stub.ListJobs.call_args
    assert kwargs["metadata"] == (("authorization", "Bearer secret"),)


def test_explicit_empty_auth_token_disables_env_metadata(monkeypatch):
    monkeypatch.setenv("MN_GRPC_AUTH_TOKEN", "secret-from-env")
    job_stub = SimpleNamespace(
        ListJobs=Mock(return_value=SimpleNamespace(jobs_json='{"data": []}'))
    )
    client, _, _, _ = stubbed_client(
        monkeypatch,
        job_stub=job_stub,
        auth_token="",
    )

    client.list_jobs()

    _, kwargs = job_stub.ListJobs.call_args
    assert kwargs["metadata"] is None


def test_negative_timeout_env_raises(monkeypatch):
    monkeypatch.setenv("MN_GRPC_TIMEOUT_SECONDS", "-1")
    try:
        stubbed_client(monkeypatch, job_stub=SimpleNamespace())
    except ValueError as exc:
        assert "positive number" in str(exc)
    else:
        raise AssertionError("expected negative timeout env to raise ValueError")


def test_stream_events_uses_timeout_and_auth_metadata(monkeypatch):
    monkeypatch.setenv("MN_GRPC_AUTH_TOKEN", "secret")
    monkeypatch.setenv("MN_GRPC_TIMEOUT_SECONDS", "2.5")
    observability_stub = SimpleNamespace(
        StreamEvents=Mock(
            return_value=[
                SimpleNamespace(event_json='{"type": "agent_started"}'),
                SimpleNamespace(event_json='{"type": "agent_completed"}'),
            ]
        )
    )
    client, _, _, _ = stubbed_client(
        monkeypatch,
        observability_stub=observability_stub,
    )

    assert list(client.stream_events("job-1")) == [
        '{"type": "agent_started"}',
        '{"type": "agent_completed"}',
    ]
    _, kwargs = observability_stub.StreamEvents.call_args
    assert kwargs["timeout"] == 2.5
    assert kwargs["metadata"] == (("authorization", "Bearer secret"),)


def test_workflow_to_bundle_generates_manifest_and_worker(tmp_path):
    class BundleAgents:
        @agent.defn(
            name="bundle_ingress",
            type="map",
            retries=RetryPolicy(max_attempts=2, backoff_ms=100),
            backpressure=BackpressurePolicy(
                max_queue_depth=4,
                high_watermark=2,
                low_watermark=1,
                retry_after_ms=50,
            ),
            timeout_seconds=5,
        )
        def ingress(self, topic):
            return {"topic": topic}

        @agent.defn(name="bundle_worker", type="map")
        def worker(self, request):
            return {"summary": request["topic"].upper()}

        @agent.defn(name="bundle_sink", type="reduce")
        def sink(self, result):
            return {"status": "saved", "summary": result["summary"]}

    @workflow.defn(name="bundle_flow_v1", recovery_mode="cluster_recover")
    class BundleFlow:
        def __init__(self):
            self.agents = BundleAgents()

        @workflow.run
        def run(self):
            request = self.agents.ingress("charging")
            result = self.agents.worker(request)
            return self.agents.sink(result)

    bundle_dir = workflow.to_bundle(BundleFlow, tmp_path / "bundle", blueprint_id="unit")
    manifest = json.loads((bundle_dir / "manifest.json").read_text())

    assert manifest["graph_id"] == "bundle_flow_v1"
    assert manifest["entrypoints"] == ["bundle_ingress"]
    assert manifest["initial_inputs"]["bundle_ingress"] == [
        {"args": ["charging"], "kwargs": {}}
    ]
    assert [node["node_id"] for node in manifest["nodes"]] == [
        "bundle_ingress",
        "bundle_worker",
        "bundle_sink",
    ]
    assert manifest["nodes"][0]["config"]["runner_module"] == "MirrorNeuron.Runner.HostLocal"
    assert manifest["nodes"][0]["config"]["max_attempts"] == 2
    assert manifest["nodes"][0]["config"]["retry_backoff_ms"] == 100
    assert manifest["nodes"][0]["config"]["timeout_seconds"] == 5
    assert manifest["nodes"][0]["config"]["backpressure"]["max_queue_depth"] == 4
    assert (bundle_dir / "payloads" / "mn_python_workflow" / "mn_worker.py").exists()


def test_workflow_input_and_module_constant_compile(tmp_path):
    class InputAgents:
        @agent.defn(name="input_ingress", type="map")
        def ingress(self, topic):
            return {"topic": topic}

        @agent.defn(name="input_done", type="reduce")
        def done(self, request):
            return request

    @workflow.defn(name="input_flow_v1")
    class InputFlow:
        def __init__(self):
            self.agents = InputAgents()

        @workflow.run
        def run(self):
            request = self.agents.ingress(workflow.input("topic", default=TEST_DEFAULT_TOPIC))
            return self.agents.done(request)

    bundle_dir = workflow.to_bundle(InputFlow, tmp_path / "bundle")
    manifest = json.loads((bundle_dir / "manifest.json").read_text())
    assert manifest["initial_inputs"]["input_ingress"] == [
        {"args": ["charging"], "kwargs": {}}
    ]


def test_unsafe_argument_expression_is_rejected(tmp_path):
    class UnsafeAgents:
        @agent.defn(name="unsafe_ingress", type="map")
        def ingress(self, topic):
            return {"topic": topic}

    @workflow.defn(name="unsafe_flow_v1")
    class UnsafeFlow:
        def __init__(self):
            self.agents = UnsafeAgents()

        @workflow.run
        def run(self):
            return self.agents.ingress(str("not allowed"))

    try:
        workflow.to_bundle(UnsafeFlow, tmp_path / "bundle")
    except BundleCompileError as exc:
        assert "unsupported argument expression" in str(exc)
    else:
        raise AssertionError("expected unsafe expression to be rejected")


def test_openshell_runner_options_compile(tmp_path):
    class ShellAgents:
        @agent.defn(
            name="shell_ingress",
            type="map",
            runner=RunnerConfig.openshell(image="base", policy="policies/api-egress.yaml"),
        )
        def ingress(self, topic):
            return {"topic": topic}

    @workflow.defn(name="shell_flow_v1")
    class ShellFlow:
        def __init__(self):
            self.agents = ShellAgents()

        @workflow.run
        def run(self):
            return self.agents.ingress("charging")

    bundle_dir = workflow.to_bundle(ShellFlow, tmp_path / "bundle")
    manifest = json.loads((bundle_dir / "manifest.json").read_text())
    config = manifest["nodes"][0]["config"]

    assert config["runner_module"] == "MirrorNeuron.Sandbox.OpenShell"
    assert config["from"] == "base"
    assert config["policy"] == "policies/api-egress.yaml"
