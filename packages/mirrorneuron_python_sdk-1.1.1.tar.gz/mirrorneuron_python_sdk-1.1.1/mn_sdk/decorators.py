from __future__ import annotations

from typing import Any, Callable


# To collect definitions
class WorkflowRegistry:
    def __init__(self):
        self.agents = {}
        self.agents_by_qualified_name = {}
        self.workflows = {}


registry = WorkflowRegistry()


class AgentDef:
    def __init__(
        self,
        name: str,
        agent_type: str,
        func: Callable,
        options: dict[str, Any] | None = None,
    ):
        self.name = name
        self.agent_type = agent_type
        self.func = func
        self.options = options or {}


def defn(
    name: str | None = None,
    type: str = "generic",
    *,
    runner: Any = "host_local",
    retries: Any = None,
    pool: str | None = None,
    pool_slots: int | None = None,
    backpressure: Any = None,
    env: dict[str, Any] | None = None,
    pass_env: list[str] | tuple[str, ...] | None = None,
    uploads: list[dict[str, str]] | None = None,
    policy: str | None = None,
    timeout_seconds: int | float | None = None,
    role: str | None = None,
    output_message_type: str | None = None,
    raw_config: dict[str, Any] | None = None,
):
    def wrapper(func):
        agent_name = name or func.__name__
        qualified_name = f"{func.__module__}.{func.__qualname__}"
        options = {
            "runner": runner,
            "retries": retries,
            "pool": pool,
            "pool_slots": pool_slots,
            "backpressure": backpressure,
            "env": env or {},
            "pass_env": tuple(pass_env or ()),
            "uploads": uploads,
            "policy": policy,
            "timeout_seconds": timeout_seconds,
            "role": role,
            "output_message_type": output_message_type,
            "raw_config": raw_config or {},
        }
        func._mn_agent_name = agent_name
        func._mn_agent_type = type
        func._mn_agent_options = options
        registry.agents[agent_name] = AgentDef(agent_name, type, func, options)
        registry.agents_by_qualified_name[qualified_name] = AgentDef(
            agent_name, type, func, options
        )
        return func

    return wrapper


class agent:
    defn = defn


class WorkflowDef:
    def __init__(self, name: str, cls: type, options: dict[str, Any] | None = None):
        self.name = name
        self.cls = cls
        self.options = options or {}
        self.run_method = None

        for attr_name in dir(cls):
            attr = getattr(cls, attr_name)
            if hasattr(attr, "_is_workflow_run"):
                self.run_method = attr
                break


class workflow:
    @staticmethod
    def defn(
        name: str,
        *,
        daemon: bool = False,
        stream_mode: str | None = None,
        recovery_mode: str = "cluster_recover",
        backpressure: Any = None,
    ):
        def wrapper(cls):
            options = {
                "daemon": daemon,
                "stream_mode": stream_mode,
                "recovery_mode": recovery_mode,
                "backpressure": backpressure,
            }
            cls._mn_workflow_options = options
            registry.workflows[name] = WorkflowDef(name, cls, options)
            return cls

        return wrapper

    @staticmethod
    def run(func):
        func._is_workflow_run = True
        return func

    @staticmethod
    def input(name: str, default: Any = None):
        from .bundle import WorkflowInput

        return WorkflowInput(name=name, default=default)

    @staticmethod
    def to_bundle(cls, output_dir, **kwargs):
        from .bundle import build_bundle

        return build_bundle(cls, output_dir, **kwargs)
