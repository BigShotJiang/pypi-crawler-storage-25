import os
import grpc
from typing import Dict, Any, Optional

from .logging_config import configure_logging
from .proto import job_pb2, job_pb2_grpc
from .proto import cluster_pb2, cluster_pb2_grpc
from .proto import observability_pb2, observability_pb2_grpc

logger = configure_logging()


class Client:
    def __init__(self, target: Optional[str] = None, timeout: Optional[float] = None, auth_token: Optional[str] = None):
        target = target or os.environ.get("MN_GRPC_TARGET", "localhost:50051")
        logger.info("Creating gRPC client target=%s timeout=%s", target, timeout)
        self.channel = grpc.insecure_channel(target)
        self.job_stub = job_pb2_grpc.JobServiceStub(self.channel)
        self.cluster_stub = cluster_pb2_grpc.ClusterServiceStub(self.channel)
        self.observability_stub = observability_pb2_grpc.ObservabilityServiceStub(
            self.channel
        )
        self.timeout = self._resolve_timeout(timeout)
        self.metadata = self._resolve_metadata(auth_token)

    def submit_job(self, manifest_json: str, payloads: Dict[str, bytes]) -> str:
        req = job_pb2.SubmitJobRequest(manifest_json=manifest_json, payloads=payloads)
        logger.debug("Submitting job with %d payloads", len(payloads))
        resp = self.job_stub.SubmitJob(req, timeout=self.timeout, metadata=self.metadata)
        logger.info("Submitted job id=%s", resp.job_id)
        return resp.job_id

    def get_job(self, job_id: str) -> str:
        req = job_pb2.GetJobRequest(job_id=job_id)
        logger.debug("Fetching job id=%s", job_id)
        resp = self.job_stub.GetJob(req, timeout=self.timeout, metadata=self.metadata)
        return resp.job_json

    def list_jobs(self, limit: int = 0, include_terminal: bool = True) -> str:
        req = job_pb2.ListJobsRequest(limit=limit, include_terminal=include_terminal)
        resp = self.job_stub.ListJobs(req, timeout=self.timeout, metadata=self.metadata)
        return resp.jobs_json

    def cancel_job(self, job_id: str) -> str:
        req = job_pb2.CancelJobRequest(job_id=job_id)
        logger.info("Cancelling job id=%s", job_id)
        resp = self.job_stub.CancelJob(req, timeout=self.timeout, metadata=self.metadata)
        return resp.status

    def pause_job(self, job_id: str) -> str:
        req = job_pb2.PauseJobRequest(job_id=job_id)
        resp = self.job_stub.PauseJob(req, timeout=self.timeout, metadata=self.metadata)
        return resp.status

    def resume_job(self, job_id: str) -> str:
        req = job_pb2.ResumeJobRequest(job_id=job_id)
        resp = self.job_stub.ResumeJob(req, timeout=self.timeout, metadata=self.metadata)
        return resp.status

    def clear_jobs(self) -> int:
        req = job_pb2.ClearJobsRequest()
        resp = self.job_stub.ClearJobs(req, timeout=self.timeout, metadata=self.metadata)
        return resp.cleared_count

    def get_system_summary(self) -> str:
        req = cluster_pb2.GetSystemSummaryRequest()
        resp = self.cluster_stub.GetSystemSummary(req, timeout=self.timeout, metadata=self.metadata)
        return resp.summary_json
        
    def remove_node(self, node_name: str) -> str:
        req = cluster_pb2.RemoveNodeRequest(node_name=node_name)
        resp = self.cluster_stub.RemoveNode(req, timeout=self.timeout, metadata=self.metadata)
        return resp.status

    def stream_events(self, job_id: str):
        req = observability_pb2.StreamEventsRequest(job_id=job_id)
        logger.debug("Streaming events for job id=%s", job_id)
        for event in self.observability_stub.StreamEvents(
            req, timeout=self.timeout, metadata=self.metadata
        ):
            yield event.event_json

    def _resolve_timeout(self, timeout: Optional[float]) -> Optional[float]:
        if timeout is not None:
            return timeout

        value = os.environ.get("MN_GRPC_TIMEOUT_SECONDS", "10")
        if value.lower() in {"", "none", "0"}:
            return None

        try:
            resolved = float(value)
        except ValueError as exc:
            raise ValueError(
                "MN_GRPC_TIMEOUT_SECONDS must be a number, 0, or none"
            ) from exc
        if resolved < 0:
            raise ValueError(
                "MN_GRPC_TIMEOUT_SECONDS must be a positive number, 0, or none"
            )
        return resolved

    def _resolve_metadata(self, auth_token: Optional[str]):
        token = (
            auth_token
            if auth_token is not None
            else os.environ.get("MN_GRPC_AUTH_TOKEN", "")
        )
        if not token:
            return None
        return (("authorization", f"Bearer {token}"),)
