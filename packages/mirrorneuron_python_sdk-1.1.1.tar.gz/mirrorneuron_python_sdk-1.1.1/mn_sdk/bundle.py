from __future__ import annotations

import ast
import fnmatch
import hashlib
import inspect
import json
import shutil
import textwrap
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType
from typing import Any


COMPILER_VERSION = "0.2.0"
DEFAULT_EXCLUDES = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "payloads",
    "*.egg-info",
    "*.pyc",
}


class BundleCompileError(ValueError):
    """Raised when a Python workflow cannot be represented as a bundle."""


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1
    backoff_ms: int = 500


@dataclass(frozen=True)
class BackpressurePolicy:
    max_queue_depth: int
    high_watermark: int
    low_watermark: int
    retry_after_ms: int = 250


@dataclass(frozen=True)
class RunnerConfig:
    kind: str = "host_local"
    image: str | None = None
    policy: str | None = None
    providers: tuple[str, ...] = ()
    gpu: bool = False
    reuse_shared_sandbox: bool | None = None
    persistent_workspace: bool | None = None
    cleanup_remote_dir: bool | None = None
    sandbox_upload_path: str | None = None

    @staticmethod
    def host_local() -> "RunnerConfig":
        return RunnerConfig(kind="host_local")

    @staticmethod
    def openshell(**kwargs: Any) -> "RunnerConfig":
        return RunnerConfig(kind="openshell", **kwargs)


@dataclass(frozen=True)
class WorkflowInput:
    name: str
    default: Any = None


@dataclass(frozen=True)
class AgentCall:
    node_id: str
    agent_type: str
    method_name: str
    owner_class: str
    args: list[Any]
    kwargs: dict[str, Any]
    assigned_to: str | None
    options: dict[str, Any]


def build_bundle(
    workflow_cls: type,
    output_dir: str | Path,
    *,
    daemon: bool | None = None,
    blueprint_id: str | None = None,
    initial_inputs: dict[str, list[dict[str, Any]]] | None = None,
    include_source_dir: bool = True,
    includes: list[str | Path] | None = None,
    excludes: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    complete_on_final: bool | None = None,
) -> Path:
    """Compile a decorated pure-Python workflow class into a job bundle folder."""

    output_path = Path(output_dir)
    payloads_dir = output_path / "payloads"
    workflow_def = _workflow_def(workflow_cls)
    workflow_options = getattr(workflow_def.cls, "_mn_workflow_options", {})
    source_file = Path(inspect.getsourcefile(workflow_cls) or "").resolve()

    if not source_file.exists():
        raise BundleCompileError(f"could not resolve source file for {workflow_cls!r}")

    effective_daemon = bool(
        workflow_options.get("daemon", False) if daemon is None else daemon
    )
    calls = _parse_run_calls(workflow_cls, source_file)
    if not calls:
        raise BundleCompileError("workflow run method did not contain any agent calls")
    _validate_calls(calls)

    output_path.mkdir(parents=True, exist_ok=True)
    payload_root = payloads_dir / "mn_python_workflow"
    if payload_root.exists():
        shutil.rmtree(payload_root)
    source_root = payload_root / "source"
    source_root.mkdir(parents=True, exist_ok=True)

    copied_files = _copy_sources(
        source_file,
        source_root,
        include_source_dir,
        includes or [],
        set(excludes or []) | DEFAULT_EXCLUDES,
    )
    (payload_root / "mn_worker.py").write_text(_worker_source(), encoding="utf-8")

    manifest = _build_manifest(
        workflow_name=workflow_def.name,
        workflow_options=workflow_options,
        source_module=source_file.stem,
        source_hash=_source_hash(copied_files),
        calls=calls,
        daemon=effective_daemon,
        blueprint_id=blueprint_id,
        initial_inputs=initial_inputs,
        metadata=metadata,
        complete_on_final=complete_on_final
        if complete_on_final is not None
        else not effective_daemon,
    )
    (output_path / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return output_path


def _workflow_def(workflow_cls: type):
    from .decorators import registry

    for item in registry.workflows.values():
        if item.cls is workflow_cls:
            return item
    raise BundleCompileError(f"{workflow_cls.__name__} is not registered with @workflow.defn")


def _parse_run_calls(workflow_cls: type, source_file: Path) -> list[AgentCall]:
    workflow_def = _workflow_def(workflow_cls)
    run_method = workflow_def.run_method
    module = inspect.getmodule(workflow_cls)
    if module is None:
        raise BundleCompileError("could not resolve workflow module")
    agent_owner_class = _workflow_agent_owner(workflow_cls)

    run_ast = ast.parse(textwrap.dedent(inspect.getsource(run_method))).body[0]
    if not isinstance(run_ast, ast.FunctionDef):
        raise BundleCompileError("@workflow.run must decorate a normal function")

    calls: list[AgentCall] = []
    assigned: set[str] = set()

    for stmt in run_ast.body:
        if isinstance(stmt, ast.Assign):
            if len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
                raise BundleCompileError("agent call assignments must use one local variable")
            call = _parse_agent_call(stmt.value, module, assigned, agent_owner_class)
            assigned_to = stmt.targets[0].id
            calls.append(_with_assignment(call, assigned_to))
            assigned.add(assigned_to)
        elif isinstance(stmt, ast.Return):
            calls.append(_parse_agent_call(stmt.value, module, assigned, agent_owner_class))
        elif isinstance(stmt, ast.Pass):
            continue
        else:
            raise BundleCompileError(
                "only straight-line agent assignments and a final return are supported"
            )

    if not calls or calls[-1].assigned_to is not None:
        raise BundleCompileError("workflow run method must return the final agent call")

    return calls


def _workflow_agent_owner(workflow_cls: type) -> str | None:
    init_method = getattr(workflow_cls, "__init__", None)
    if init_method is None:
        return None
    try:
        init_ast = ast.parse(textwrap.dedent(inspect.getsource(init_method))).body[0]
    except (OSError, TypeError, SyntaxError):
        return None
    if not isinstance(init_ast, ast.FunctionDef):
        return None
    for stmt in init_ast.body:
        if (
            isinstance(stmt, ast.Assign)
            and len(stmt.targets) == 1
            and isinstance(stmt.targets[0], ast.Attribute)
            and isinstance(stmt.targets[0].value, ast.Name)
            and stmt.targets[0].value.id == "self"
            and stmt.targets[0].attr == "agents"
            and isinstance(stmt.value, ast.Call)
            and isinstance(stmt.value.func, ast.Name)
        ):
            return stmt.value.func.id
    return None


def _parse_agent_call(
    node: ast.AST,
    module: ModuleType,
    assigned: set[str],
    agent_owner_class: str | None,
) -> AgentCall:
    if not isinstance(node, ast.Call):
        raise BundleCompileError("workflow statements must call decorated agents")

    method_name = _method_name(node.func)
    func = _resolve_agent_method(method_name, module, agent_owner_class)
    agent_name = getattr(func, "_mn_agent_name", method_name)
    agent_type = getattr(func, "_mn_agent_type", "generic")
    owner_class = _owner_from_qualname(func.__qualname__)
    options = dict(getattr(func, "_mn_agent_options", {}))

    return AgentCall(
        node_id=agent_name,
        agent_type=agent_type,
        method_name=method_name,
        owner_class=owner_class,
        args=[_eval_arg(arg, module, assigned) for arg in node.args],
        kwargs={
            kw.arg: _eval_arg(kw.value, module, assigned)
            for kw in node.keywords
            if kw.arg is not None
        },
        assigned_to=None,
        options=options,
    )


def _with_assignment(call: AgentCall, assigned_to: str) -> AgentCall:
    return AgentCall(
        node_id=call.node_id,
        agent_type=call.agent_type,
        method_name=call.method_name,
        owner_class=call.owner_class,
        args=call.args,
        kwargs=call.kwargs,
        assigned_to=assigned_to,
        options=call.options,
    )


def _method_name(func: ast.AST) -> str:
    if isinstance(func, ast.Attribute):
        return func.attr
    raise BundleCompileError("agent calls must use attribute syntax, such as self.agents.ingress()")


def _resolve_agent_method(
    method_name: str,
    module: ModuleType,
    agent_owner_class: str | None,
):
    from .decorators import registry

    matches = []
    module_file = Path(getattr(module, "__file__", "")).resolve()
    for agent_def in registry.agents_by_qualified_name.values():
        func = agent_def.func
        if (
            getattr(func, "__name__", None) == method_name
            and Path(inspect.getsourcefile(func) or "").resolve() == module_file
            and (
                agent_owner_class is None
                or _owner_from_qualname(func.__qualname__) == agent_owner_class
            )
        ):
            matches.append(func)

    if len(matches) != 1:
        raise BundleCompileError(f"could not uniquely resolve decorated agent {method_name!r}")
    return matches[0]


def _owner_from_qualname(qualname: str) -> str:
    parts = qualname.split(".")
    if len(parts) >= 2:
        return parts[-2]
    return parts[0]


def _eval_arg(node: ast.AST, module: ModuleType, assigned: set[str]) -> Any:
    if isinstance(node, ast.Name) and node.id in assigned:
        return {"$var": node.id}

    if isinstance(node, ast.Name):
        if node.id not in module.__dict__:
            raise BundleCompileError(f"unknown workflow constant {node.id!r}")
        return _safe_constant(node.id, module.__dict__[node.id])

    if _is_workflow_input_call(node):
        return _workflow_input_from_ast(node, module, assigned)

    try:
        return ast.literal_eval(node)
    except (ValueError, SyntaxError):
        raise BundleCompileError(f"unsupported argument expression: {ast.dump(node)}")


def _is_workflow_input_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "input"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "workflow"
    )


def _workflow_input_from_ast(
    node: ast.Call, module: ModuleType, assigned: set[str]
) -> dict[str, Any]:
    if not node.args or not isinstance(node.args[0], ast.Constant) or not isinstance(node.args[0].value, str):
        raise BundleCompileError("workflow.input() requires a string name as the first argument")
    default = None
    for keyword in node.keywords:
        if keyword.arg == "default":
            default = _eval_arg(keyword.value, module, assigned)
        else:
            raise BundleCompileError(f"unsupported workflow.input() keyword {keyword.arg!r}")
    return {"$input": node.args[0].value, "default": default}


def _safe_constant(name: str, value: Any) -> Any:
    if _json_safe(value):
        return value
    raise BundleCompileError(
        f"workflow constant {name!r} must be JSON-serializable and side-effect free"
    )


def _json_safe(value: Any) -> bool:
    try:
        json.dumps(value)
        return True
    except (TypeError, ValueError):
        return False


def _validate_calls(calls: list[AgentCall]) -> None:
    seen: set[str] = set()
    for call in calls:
        if call.node_id in seen:
            raise BundleCompileError(f"duplicate node_id {call.node_id!r} in workflow")
        seen.add(call.node_id)

    for previous, current in zip(calls, calls[1:]):
        expected = {"$var": previous.assigned_to}
        if current.args != [expected] or current.kwargs:
            raise BundleCompileError(
                "v1 compiled workflows support one previous-result argument per downstream agent"
            )


def _copy_sources(
    source_file: Path,
    source_root: Path,
    include_source_dir: bool,
    includes: list[str | Path],
    excludes: set[str],
) -> list[Path]:
    copied: list[Path] = []
    base_dir = source_file.parent

    if include_source_dir:
        candidates: list[Path] = [
            item
            for item in base_dir.glob("*.py")
            if item.name != "generate_bundle.py"
        ]
    else:
        candidates = [source_file]

    candidates.extend(Path(item) for item in includes)

    for candidate in candidates:
        source = candidate if candidate.is_absolute() else base_dir / candidate
        if not source.exists():
            raise BundleCompileError(f"include path does not exist: {source}")
        target = source_root / source.name
        copied.extend(_copy_entry(source, target, source_root, excludes))
    return copied


def _copy_entry(source: Path, target: Path, root: Path, excludes: set[str]) -> list[Path]:
    if _excluded(source.name, excludes):
        return []
    if source.is_dir():
        copied: list[Path] = []
        for child in source.rglob("*"):
            rel = child.relative_to(source)
            if any(_excluded(part, excludes) for part in rel.parts):
                continue
            if child.is_file():
                destination = target / rel
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(child, destination)
                copied.append(destination)
        return copied

    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return [target]


def _excluded(name: str, excludes: set[str]) -> bool:
    return any(fnmatch.fnmatch(name, pattern) for pattern in excludes)


def _source_hash(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.as_posix()):
        digest.update(path.as_posix().encode())
        digest.update(b"\0")
        try:
            digest.update(path.read_bytes())
        except OSError:
            pass
    return digest.hexdigest()


def _build_manifest(
    *,
    workflow_name: str,
    workflow_options: dict[str, Any],
    source_module: str,
    source_hash: str,
    calls: list[AgentCall],
    daemon: bool,
    blueprint_id: str | None,
    initial_inputs: dict[str, list[dict[str, Any]]] | None,
    metadata: dict[str, Any] | None,
    complete_on_final: bool,
) -> dict[str, Any]:
    nodes = []
    edges = []

    for index, call in enumerate(calls):
        is_final = index == len(calls) - 1
        message_type = f"{call.node_id}_result"
        nodes.append(
            {
                "node_id": call.node_id,
                "agent_type": "executor",
                "type": call.agent_type,
                "role": "root_coordinator" if index == 0 else call.options.get("role"),
                "config": _node_config(call, source_module, message_type, is_final, complete_on_final),
            }
        )

        if index > 0:
            previous = calls[index - 1]
            edges.append(
                {
                    "edge_id": f"{previous.node_id}_to_{call.node_id}",
                    "from_node": previous.node_id,
                    "to_node": call.node_id,
                    "message_type": f"{previous.node_id}_result",
                }
            )

    entrypoint = calls[0].node_id
    manifest_initial_inputs = initial_inputs or {
        entrypoint: [
            {
                "args": _materialize_initial_args(calls[0].args),
                "kwargs": _materialize_inputs(calls[0].kwargs),
            }
        ]
    }
    policies = {"recovery_mode": workflow_options.get("recovery_mode", "cluster_recover")}
    stream_mode = workflow_options.get("stream_mode")
    if stream_mode:
        policies["stream_mode"] = stream_mode
    elif daemon:
        policies["stream_mode"] = "live"
    if workflow_options.get("backpressure"):
        policies["backpressure"] = _normalize_dataclass(workflow_options["backpressure"])

    manifest_metadata = {
        "compiler_version": COMPILER_VERSION,
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "generated_by": "mn-python-sdk",
        "manifest_schema": "1.0",
        "python_source_mode": True,
        "source_hash": source_hash,
    }
    if blueprint_id:
        manifest_metadata["blueprint_id"] = blueprint_id
    if metadata:
        manifest_metadata.update(metadata)

    manifest: dict[str, Any] = {
        "manifest_version": "1.0",
        "graph_id": workflow_name,
        "job_name": workflow_name.replace("_", "-"),
        "daemon": daemon,
        "entrypoints": [entrypoint],
        "initial_inputs": manifest_initial_inputs,
        "nodes": nodes,
        "edges": edges,
        "policies": policies,
        "metadata": manifest_metadata,
    }
    return _drop_none_roles(manifest)


def _node_config(
    call: AgentCall,
    source_module: str,
    message_type: str,
    is_final: bool,
    complete_on_final: bool,
) -> dict[str, Any]:
    runner = _normalize_runner(call.options.get("runner", RunnerConfig.host_local()))
    command = call.options.get("command", ["python3", "mn_worker.py"])
    config: dict[str, Any] = {
        "name_prefix": f"py-{call.node_id}",
        "upload_path": "mn_python_workflow",
        "upload_as": "mn_python_workflow",
        "workdir": "/sandbox/job/mn_python_workflow",
        "command": command,
        "output_message_type": call.options.get("output_message_type"),
        "environment": {
            **{k: str(v) for k, v in (call.options.get("env") or {}).items()},
            "MN_PY_SOURCE_MODULE": source_module,
            "MN_PY_OWNER_CLASS": call.owner_class,
            "MN_PY_METHOD": call.method_name,
            "MN_PY_OUTPUT_TYPE": message_type,
            "MN_PY_FINAL": "1" if is_final else "0",
            "MN_PY_COMPLETE_FINAL": "1" if complete_on_final else "0",
        },
    }
    if runner.kind == "host_local":
        config["runner_module"] = "MirrorNeuron.Runner.HostLocal"
    elif runner.kind == "openshell":
        config["runner_module"] = "MirrorNeuron.Sandbox.OpenShell"
        _put(config, "from", runner.image)
        _put(config, "policy", runner.policy or call.options.get("policy"))
        if runner.providers:
            config["providers"] = list(runner.providers)
        if runner.gpu:
            config["gpu"] = True
        _put(config, "reuse_shared_sandbox", runner.reuse_shared_sandbox)
        _put(config, "persistent_workspace", runner.persistent_workspace)
        _put(config, "cleanup_remote_dir", runner.cleanup_remote_dir)
        _put(config, "sandbox_upload_path", runner.sandbox_upload_path)
    else:
        raise BundleCompileError(f"unsupported runner kind {runner.kind!r}")

    retry = call.options.get("retries")
    if retry:
        retry = _normalize_dataclass(retry)
        config["max_attempts"] = retry.get("max_attempts", 1)
        config["retry_backoff_ms"] = retry.get("backoff_ms", 500)
    if call.options.get("pool"):
        config["pool"] = call.options["pool"]
    if call.options.get("pool_slots") is not None:
        config["pool_slots"] = call.options["pool_slots"]
    if call.options.get("backpressure"):
        config["backpressure"] = _normalize_dataclass(call.options["backpressure"])
    if call.options.get("pass_env"):
        config["pass_env"] = list(call.options["pass_env"])
    if call.options.get("uploads"):
        config["upload_paths"] = list(call.options["uploads"])
        config.pop("upload_path", None)
        config.pop("upload_as", None)
    if call.options.get("policy") and runner.kind != "openshell":
        config["policy"] = call.options["policy"]
    if call.options.get("timeout_seconds") is not None:
        config["timeout_seconds"] = call.options["timeout_seconds"]
    if call.options.get("raw_config"):
        config.update(call.options["raw_config"])
    return config


def _normalize_runner(value: str | RunnerConfig) -> RunnerConfig:
    if isinstance(value, RunnerConfig):
        return value
    if value in {"host_local", "host-local"}:
        return RunnerConfig.host_local()
    if value == "openshell":
        return RunnerConfig.openshell()
    raise BundleCompileError(f"unsupported runner {value!r}")


def _normalize_dataclass(value: Any) -> dict[str, Any]:
    if hasattr(value, "__dataclass_fields__"):
        return {key: item for key, item in asdict(value).items() if item is not None}
    if isinstance(value, dict):
        return dict(value)
    raise BundleCompileError(f"expected dataclass or dict config, got {type(value).__name__}")


def _put(config: dict[str, Any], key: str, value: Any) -> None:
    if value is not None:
        config[key] = value


def _materialize_initial_args(args: list[Any]) -> list[Any]:
    if any(isinstance(arg, dict) and "$var" in arg for arg in args):
        raise BundleCompileError("first agent call cannot depend on a prior workflow variable")
    return _materialize_inputs(args)


def _materialize_inputs(value: Any) -> Any:
    if isinstance(value, dict):
        if "$input" in value:
            return value.get("default")
        return {key: _materialize_inputs(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_materialize_inputs(item) for item in value]
    return value


def _drop_none_roles(manifest: dict[str, Any]) -> dict[str, Any]:
    for node in manifest["nodes"]:
        if node.get("role") is None:
            node.pop("role", None)
    return manifest


def _worker_source() -> str:
    return """#!/usr/bin/env python3
import importlib
import json
import os
import pathlib
import sys


def _load_input():
    path = pathlib.Path(os.environ["MN_INPUT_FILE"])
    payload = json.loads(path.read_text())
    return payload.get("args", []), payload.get("kwargs", {})


def main():
    source_dir = pathlib.Path(__file__).resolve().parent / "source"
    sys.path.insert(0, str(source_dir))

    module = importlib.import_module(os.environ["MN_PY_SOURCE_MODULE"])
    owner = getattr(module, os.environ["MN_PY_OWNER_CLASS"])
    method = getattr(owner(), os.environ["MN_PY_METHOD"])
    args, kwargs = _load_input()
    result = method(*args, **kwargs)

    if os.environ.get("MN_PY_FINAL") == "1" and os.environ.get("MN_PY_COMPLETE_FINAL") == "1":
        print(json.dumps({"complete_job": result}))
    elif os.environ.get("MN_PY_FINAL") == "1":
        print(json.dumps({
            "next_state": result if isinstance(result, dict) else {"result": result},
            "events": [{
                "type": "python_workflow_result",
                "payload": result if isinstance(result, dict) else {"result": result}
            }]
        }))
    else:
        print(json.dumps({
            "emit_messages": [{
                "type": os.environ["MN_PY_OUTPUT_TYPE"],
                "body": {"args": [result], "kwargs": {}}
            }]
        }))


if __name__ == "__main__":
    main()
"""
