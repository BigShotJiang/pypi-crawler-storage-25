"""WebAgent — the public API for snakeoil-web."""

import inspect
import re
import sys
import os
from typing import Optional

# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    """Search for snakeoil.web.config.py from the caller's directory upwards."""
    frame = inspect.stack()[-1]
    start = os.path.dirname(os.path.abspath(frame.filename))

    for directory in _walk_up(start):
        candidate = os.path.join(directory, "snakeoil.web.config.py")
        if os.path.exists(candidate):
            cfg = {}
            with open(candidate) as f:
                exec(f.read(), cfg)
            return cfg

    return {}


def _walk_up(path: str):
    while True:
        yield path
        parent = os.path.dirname(path)
        if parent == path:
            break
        path = parent


# ---------------------------------------------------------------------------
# Variable processor
# ---------------------------------------------------------------------------

_VAR_RE    = re.compile(r"\{\{(\w+)\}\}")
_ASSIGN_RE = re.compile(r"^\{\{(\w+)\}\}\s*=\s*(.+)$")
_DEFVAR_RE = re.compile(r"^(\w+)\s*=\s*\"(.*)\"$")


def _substitute(text: str, variables: dict) -> str:
    return _VAR_RE.sub(lambda m: str(variables.get(m.group(1), m.group(0))), text)


def _caller_locals() -> dict:
    frame = inspect.currentframe()
    try:
        caller = frame.f_back.f_back.f_back
        return dict(caller.f_locals) if caller else {}
    finally:
        del frame


# ---------------------------------------------------------------------------
# WebAgent
# ---------------------------------------------------------------------------

class WebAgent:
    """
    Selector-free, self-healing web test automation.

    Usage:
        agent = WebAgent()                          # reads snakeoil.web.config.py
        agent = WebAgent(url="https://example.com") # override config

    Pythonic:
        agent.click("Sign in")
        agent.type("email@example.com", into="Email")
        agent.verify_text("Dashboard")

    English:
        agent.run('click "Sign in"')
        agent.run('type "email@example.com" into "Email"')
        agent.run('{{balance}} = extract text next to "Balance"')
    """

    def __init__(self,
                 url: Optional[str] = None,
                 browser: Optional[str] = None,
                 headless: Optional[bool] = None,
                 maximized: Optional[bool] = None,
                 timeout: Optional[int] = None,
                 screenshots: Optional[bool] = None) -> None:

        cfg = _load_config()

        self._url         = url      or cfg.get("URL", "https://example.com")
        self._browser     = browser  or cfg.get("BROWSER", "chromium")
        self._headless    = headless if headless is not None else cfg.get("HEADLESS", False)
        self._maximized   = maximized if maximized is not None else cfg.get("MAXIMIZED", True)
        self._timeout     = timeout  or cfg.get("TIMEOUT", 30_000)
        self._screenshots = screenshots if screenshots is not None else cfg.get("SCREENSHOTS_ON_FAILURE", False)

        self._variables: dict = {}
        self._steps: list = []
        self._engine = None

        self._start()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _start(self) -> None:
        """Initialise the Playwright engine and open the browser."""
        self._engine = _Engine(
            url=self._url,
            browser=self._browser,
            headless=self._headless,
            maximized=self._maximized,
            timeout=self._timeout,
        )
        self._engine.start()

    def close(self) -> None:
        """Close the browser and end the session."""
        if self._engine:
            self._engine.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ------------------------------------------------------------------
    # Variable access
    # ------------------------------------------------------------------

    def get(self, name: str) -> Optional[str]:
        """Return a captured variable by name."""
        return self._variables.get(name)

    # ------------------------------------------------------------------
    # English mode
    # ------------------------------------------------------------------

    def run(self, instructions) -> "WebAgent":
        """Execute one or more English instructions.

        Accepts a single string or a list of strings.
        Returns the extracted value for extract instructions, otherwise returns self.

        Examples:
            agent.run('click "Sign in"')
            agent.run([
                f'type "{email}" into "Email"',
                f'type "{password}" into "Password"',
            ])
            product = agent.run('extract text from first "item name"')
            agent.run('{{balance}} = extract text next to "Balance"')
            balance = agent.get("balance")
        """
        if isinstance(instructions, str):
            instructions = [instructions]

        caller_vars = _caller_locals()
        merged = {**caller_vars, **self._variables}
        last_result = None

        for raw in instructions:
            raw = raw.strip()
            if not raw:
                continue

            # Pattern: {{var}} = instruction
            assign_match = _ASSIGN_RE.match(raw)
            if assign_match:
                var_name    = assign_match.group(1)
                instruction = _substitute(assign_match.group(2).strip(), merged)
                result      = self._execute_step(instruction)
                self._variables[var_name] = result
                merged[var_name] = result
                continue

            # Pattern: varname = "value" (inline variable definition)
            defvar_match = _DEFVAR_RE.match(raw)
            if defvar_match:
                var_name  = defvar_match.group(1)
                var_value = defvar_match.group(2)
                self._variables[var_name] = var_value
                merged[var_name] = var_value
                continue

            # Regular instruction
            instruction = _substitute(raw, merged)
            last_result = self._execute_step(instruction)

        return last_result if last_result is not None else self

    def _execute_step(self, instruction: str):
        try:
            result = self._engine.execute(instruction)
            self._steps.append({"instruction": instruction, "status": "passed", "message": "", "screenshot": None})
            return result
        except Exception as e:
            screenshot = None
            if self._screenshots:
                try:
                    import base64
                    data = self._engine._page.screenshot(type="png")
                    screenshot = base64.b64encode(data).decode("utf-8")
                except Exception:
                    pass
            self._steps.append({"instruction": instruction, "status": "failed", "message": str(e), "screenshot": screenshot})
            raise

    # ------------------------------------------------------------------
    # Pythonic mode
    # ------------------------------------------------------------------

    def navigate(self, url: str) -> "WebAgent":
        """Navigate to a URL. Relative paths are appended to the base URL."""
        if url.startswith("/"):
            url = self._url.rstrip("/") + url
        self._engine.navigate(url)
        return self

    def click(self, target: str, *,
              below: str = None,
              above: str = None,
              next_to: str = None,
              left_of: str = None,
              right_of: str = None,
              index: int = 1) -> "WebAgent":
        """Click an element by visible text or spatial position."""
        instruction = self._build_action("click", target,
                                         below=below, above=above, next_to=next_to,
                                         left_of=left_of, right_of=right_of, index=index)
        self._engine.execute(instruction)
        return self

    def type(self, text: str, *, into: str,
             below: str = None, above: str = None,
             next_to: str = None) -> "WebAgent":
        """Type text into a field identified by label or position."""
        target = self._build_target(into, below=below, above=above, next_to=next_to)
        self._engine.execute(f'type "{text}" into "{target}"')
        return self

    def select(self, value: str, *, from_: str) -> "WebAgent":
        """Select an option from a dropdown."""
        self._engine.execute(f'select "{value}" from "{from_}"')
        return self

    def hover(self, target: str) -> "WebAgent":
        """Hover over an element."""
        self._engine.execute(f'hover "{target}"')
        return self

    def press(self, key: str) -> "WebAgent":
        """Press a keyboard key (Enter, Escape, Tab, ArrowDown etc.)."""
        self._engine.execute(f'press {key}')
        return self

    def wait(self, ms: int) -> "WebAgent":
        """Wait for the given number of milliseconds."""
        self._engine.execute(f'wait "{ms}"')
        return self

    def verify_text(self, text: str, *,
                    next_to: str = None,
                    below: str = None,
                    above: str = None) -> "WebAgent":
        """Assert that text is visible on the page."""
        if next_to or below or above:
            direction = f"next to \"{next_to}\"" if next_to else \
                        f"below \"{below}\"" if below else \
                        f"above \"{above}\""
            self._engine.execute(f'verify text {direction} is "{text}"')
        else:
            self._engine.execute(f'verify text "{text}" is present')
        return self

    def verify_present(self, target: str) -> "WebAgent":
        """Assert that an element is present in the DOM."""
        self._engine.execute(f'verify "{target}" is present')
        return self

    def verify_visible(self, target: str) -> "WebAgent":
        """Assert that an element is visible on screen."""
        self._engine.execute(f'verify "{target}" is visible')
        return self

    def extract_text(self, target: str = None, *,
                     next_to: str = None,
                     below: str = None,
                     above: str = None) -> str:
        """Extract and return visible text from an element or spatial position."""
        if next_to:
            return self._engine.execute(f'extract text next to "{next_to}"')
        if below:
            return self._engine.execute(f'extract text below "{below}"')
        if above:
            return self._engine.execute(f'extract text above "{above}"')
        return self._engine.execute(f'extract text from "{target}"')

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_target(self, target: str, *,
                      below=None, above=None, next_to=None,
                      left_of=None, right_of=None) -> str:
        if next_to:  return f'{target}" next to "{next_to}'
        if below:    return f'{target}" below "{below}'
        if above:    return f'{target}" above "{above}'
        if left_of:  return f'{target}" left of "{left_of}'
        if right_of: return f'{target}" right of "{right_of}'
        return target

    def _build_action(self, action: str, target: str, *,
                      below=None, above=None, next_to=None,
                      left_of=None, right_of=None, index=1) -> str:
        ordinal = "" if index == 1 else f"{self._ordinal(index)} "
        if next_to:  return f'{action} {ordinal}"{target}" next to "{next_to}"'
        if below:    return f'{action} {ordinal}"{target}" below "{below}"'
        if above:    return f'{action} {ordinal}"{target}" above "{above}"'
        if left_of:  return f'{action} {ordinal}"{target}" left of "{left_of}"'
        if right_of: return f'{action} {ordinal}"{target}" right of "{right_of}"'
        if index > 1: return f'{action} {ordinal}"{target}"'
        return f'{action} "{target}"'

    @staticmethod
    def _ordinal(n: int) -> str:
        return {1: "first", 2: "second", 3: "third",
                4: "fourth", 5: "fifth"}.get(n, str(n))


# ---------------------------------------------------------------------------
# Engine — wraps the web-test-agent Playwright pipeline
# ---------------------------------------------------------------------------

class _Engine:
    """Internal Playwright execution engine."""

    def __init__(self, url, browser, headless, maximized, timeout):
        self.url      = url
        self.browser  = browser
        self.headless = headless
        self.maximized = maximized
        self.timeout  = timeout

        self._pw        = None
        self._browser   = None
        self._page      = None
        self._parser    = None
        self._strategy  = None
        self._actions   = None
        self._dom_parser = None
        self._matrix    = []

    def start(self) -> None:
        from playwright.sync_api import sync_playwright

        self._pw = sync_playwright().start()
        _BROWSER_MAP = {
            "chrome":   ("chromium", "chrome"),
            "edge":     ("chromium", "msedge"),
            "safari":   ("webkit",   None),
            "firefox":  ("firefox",  None),
            "chromium": ("chromium", None),
            "webkit":   ("webkit",   None),
            "msedge":   ("chromium", "msedge"),
        }
        pw_name, channel = _BROWSER_MAP.get(self.browser.lower(), ("chromium", None))
        browser_type = getattr(self._pw, pw_name, self._pw.chromium)
        args = ["--start-maximized"] if self.maximized else []
        launch_kwargs = {"headless": self.headless, "args": args}
        if channel:
            launch_kwargs["channel"] = channel
        self._browser_obj = browser_type.launch(**launch_kwargs)

        if self.maximized:
            self._page = self._browser_obj.new_page(no_viewport=True)
        else:
            self._page = self._browser_obj.new_page()

        self._page.goto(self.url, wait_until="load")
        self._init_pipeline()
        self._refresh()

    def _init_pipeline(self) -> None:
        from snakeoil_web.engine import settings as _settings
        _settings.SAVE_SNAPSHOTS = False

        from snakeoil_web.engine.agent.instruction_parser import InstructionParser
        from snakeoil_web.engine.strategies.dom_strategy import DOMStrategy
        from snakeoil_web.engine.browser.dom_parser import DOMParser
        from snakeoil_web.engine.browser.actions import Actions

        self._parser   = InstructionParser()
        self._strategy = DOMStrategy()

        class _BM:
            def __init__(self, page): self._page = page
            def get_page(self): return self._page
            def get_dialog(self): return None
            def clear_dialog(self): pass

        self._dom_parser = DOMParser(self._page)
        self._actions    = Actions(self._page, browser_manager=_BM(self._page))

    def _refresh(self) -> None:
        from snakeoil_web.engine.spatial.matrix_builder import MatrixBuilder
        dom_els, txt_els = self._dom_parser.extract_interactable_elements()
        self._dom_elements  = dom_els
        self._text_elements = txt_els
        self._matrix = MatrixBuilder(dom_els, txt_els).build()

    def navigate(self, url: str) -> None:
        self._page.goto(url, wait_until="load")
        self._refresh()

    def execute(self, instruction: str) -> Optional[str]:
        from snakeoil_web.engine.spatial.matrix_resolver import MatrixResolver

        parsed = self._parser.parse(instruction)
        action = parsed["action"]
        target = parsed.get("target", "")

        # Verification and extraction actions
        if action.startswith("verify_") or action in ("find_text", "find_exact_text"):
            result = self._strategy.resolve(parsed, self._dom_elements,
                                            text_elements=self._text_elements)
            passed = result.get("verified", result.get("resolved", False))
            if not passed:
                _action_map = {
                    "verify_text_present":  f'Text {target!r} was not found on the page.',
                    "verify_text_visible":  f'Text {target!r} is not visible on the page.',
                    "verify_present":       f'Element {target!r} was not found in the DOM.',
                    "verify_visible":       f'Element {target!r} is not visible on the page.',
                    "verify_enabled":       f'Element {target!r} is not enabled.',
                    "verify_disabled":      f'Element {target!r} is not disabled.',
                    "verify_spatial_text":  f'Expected text {parsed.get("value")!r} was not found near {target!r}.',
                    "find_text":            f'Text {target!r} was not found on the page.',
                    "find_exact_text":      f'Exact text {target!r} was not found on the page.',
                }
                msg = _action_map.get(action, f'Verification failed: {instruction!r}')
                raise AssertionError(msg)
            return None

        if action in ("extract_text", "extract_text_spatial"):
            result = self._strategy.resolve(parsed, self._dom_elements,
                                            text_elements=self._text_elements)
            return result.get("extracted") or (result.get("element") or {}).get("text", "")

        # Direct actions
        if action == "navigate":
            self._page.goto(target, wait_until="load")
            self._refresh()
            return None

        if action == "wait":
            self._page.wait_for_timeout(int(target))
            return None

        if action == "press_key":
            self._actions.press_key(target)
            self._refresh()
            return None

        if action == "sendkeys":
            self._actions.send_keys(parsed.get("value", ""))
            self._refresh()
            return None

        # Element actions — DOM → Spatial
        result = self._strategy.resolve(parsed, self._dom_elements,
                                        text_elements=self._text_elements)
        if not result["resolved"]:
            result = MatrixResolver(self._matrix).resolve(parsed)
        if not result["resolved"]:
            raise RuntimeError(
                f'Could not find element matching {target!r}. '
                f'Check the spelling or try a spatial instruction '
                f'(e.g. {action} "{target}" below "Label" / next to "Label" / near "Label").'
            )

        el = result["element"]
        url_before = self._page.url

        if action == "click":
            self._actions.click(el, anchor_text=result.get("anchor_text"),
                                ordinal=result.get("ordinal", 1))
        elif action == "type":
            self._actions.type_text(el, parsed.get("value"))
        elif action == "select":
            self._actions.select_option(el, parsed.get("value"))
        elif action == "hover":
            self._actions.hover(el)

        if self._page.url != url_before:
            self._page.wait_for_load_state("domcontentloaded")

        self._refresh()
        return None

    def close(self) -> None:
        if self._browser_obj:
            self._browser_obj.close()
        if self._pw:
            self._pw.stop()


