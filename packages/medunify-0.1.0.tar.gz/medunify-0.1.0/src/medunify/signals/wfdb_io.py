"""WFDB loading built on the wfdb adapter."""

from __future__ import annotations

from pathlib import Path

from medunify.adapters import wfdb_adapter
from medunify.signals.models import Biosignal


def load_wfdb(
    path_or_record: str | Path,
    *,
    pn_dir: str | None = None,
    channels: list[str] | None = None,
) -> Biosignal:
    """
    Load a WFDB record.

    Examples
    --------
    - PhysioNet MIT-BIH: ``path_or_record="100"``, ``pn_dir="mitdb"``.
    - Local files: pass the record path **without** extension, e.g. ``Path("data/100")``.
    """
    record_name = str(path_or_record)
    p = Path(path_or_record)
    if p.suffix.lower() in {".dat", ".hea"}:
        record_name = str(p.with_suffix(""))

    sig, meta = wfdb_adapter.read_record(record_name, pn_dir=pn_dir, channels=channels)
    ann = wfdb_adapter.read_annotations(record_name, pn_dir=pn_dir)
    return Biosignal(
        samples=sig,
        sampling_rate_hz=float(meta["fs"]),
        channel_names=list(meta.get("sig_name") or []),
        metadata=meta,
        annotations=ann,
    )


def describe_wfdb(signal: Biosignal) -> str:
    """Developer-oriented summary string."""
    return (
        f"Biosignal(channels={len(signal.channel_names)}, samples={signal.samples.shape[0]}, "
        f"fs={signal.sampling_rate_hz} Hz)"
    )
