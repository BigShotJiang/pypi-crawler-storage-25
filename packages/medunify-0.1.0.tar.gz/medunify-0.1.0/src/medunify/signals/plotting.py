"""Matplotlib plotting for biosignals."""

from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np

from medunify.signals.models import Biosignal


def plot_signal(
    signal: Biosignal,
    *,
    channel: int = 0,
    max_samples: int | None = 5000,
    title: str | None = None,
) -> None:
    """Plot a single channel over time (seconds)."""
    x = signal.samples
    if x.ndim == 1:
        y = x
    else:
        y = x[:, channel]
    n = y.shape[0]
    if max_samples is not None and n > max_samples:
        y = y[:max_samples]
        n = y.shape[0]
    t = np.arange(n, dtype=np.float32) / float(signal.sampling_rate_hz)
    plt.figure(figsize=(10, 3))
    plt.plot(t, y, lw=0.8)
    plt.xlabel("Time (s)")
    ch_name = (
        signal.channel_names[channel]
        if signal.channel_names and channel < len(signal.channel_names)
        else f"channel {channel}"
    )
    plt.ylabel(ch_name)
    plt.title(title or f"Biosignal — {ch_name}")
    plt.tight_layout()
    plt.show()
