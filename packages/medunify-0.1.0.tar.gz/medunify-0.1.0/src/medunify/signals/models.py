"""Domain models for biosignals."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class Biosignal:
    """Container for WFDB-backed (or future) biosignal arrays."""

    samples: np.ndarray
    sampling_rate_hz: float
    channel_names: list[str]
    metadata: dict[str, Any] = field(default_factory=dict)
    annotations: Any | None = None

    def to_numpy(self) -> np.ndarray:
        """Return sample matrix shaped (n_samples, n_channels)."""
        return self.samples
