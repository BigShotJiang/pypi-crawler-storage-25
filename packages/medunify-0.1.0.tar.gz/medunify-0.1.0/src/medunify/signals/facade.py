"""Public ``Signals`` facade."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from medunify.core.exceptions import UnsupportedFormatError
from medunify.signals import wfdb_io
from medunify.signals.models import Biosignal
from medunify.signals.plotting import plot_signal


class Signals:
    """
    Unified biosignal API (research tooling — not for autonomous clinical use).

    WFDB is supported first; additional sources can be added behind the same facade.
    """

    @staticmethod
    def load(
        path_or_record: str | Path,
        source: str | None = None,
        *,
        pn_dir: str | None = None,
        channels: list[str] | None = None,
    ) -> Biosignal:
        """
        Load a biosignal. Currently ``source='wfdb'`` (default) is implemented.

        For PhysioNet records, pass ``pn_dir`` (e.g. ``"mitdb"`` for MIT-BIH).
        """
        src = (source or "wfdb").lower()
        if src != "wfdb":
            raise UnsupportedFormatError(f"Unsupported biosignal source: {src!r}")
        return wfdb_io.load_wfdb(path_or_record, pn_dir=pn_dir, channels=channels)

    @staticmethod
    def metadata(signal: Biosignal) -> dict[str, Any]:
        """Return metadata gathered while loading."""
        return dict(signal.metadata)

    @staticmethod
    def to_numpy(signal: Biosignal) -> np.ndarray:
        """Return the sample array."""
        return signal.to_numpy()

    @staticmethod
    def plot(signal: Biosignal, **kwargs: Any) -> None:
        """Plot using matplotlib (see ``plotting.plot_signal``)."""
        plot_signal(signal, **kwargs)

    @staticmethod
    def describe(signal: Biosignal) -> str:
        """Short textual summary."""
        return wfdb_io.describe_wfdb(signal)
