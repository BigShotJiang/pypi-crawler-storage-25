"""
MedUnify — unified medical workflow SDK.

This package integrates imaging, biosignals, FHIR records, and optional research AI tooling.
It is **not** a medical device and must not be used for autonomous clinical diagnosis.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from medunify.core.exceptions import (
    DependencyMissingError,
    InvalidMedicalDataError,
    MedUnifyError,
    UnsupportedFormatError,
)
from medunify.imaging import Imaging
from medunify.records import Records
from medunify.signals import Signals

if TYPE_CHECKING:
    from medunify.ai.facade import AI

__all__ = [
    "AI",
    "Imaging",
    "Records",
    "Signals",
    "MedUnifyError",
    "UnsupportedFormatError",
    "DependencyMissingError",
    "InvalidMedicalDataError",
]

__version__ = "0.1.0"


def __getattr__(name: str) -> Any:
    """Lazy-load optional AI stack so core imports stay lightweight."""
    if name == "AI":
        from medunify.ai.facade import AI as _AI

        globals()["AI"] = _AI
        return _AI
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
