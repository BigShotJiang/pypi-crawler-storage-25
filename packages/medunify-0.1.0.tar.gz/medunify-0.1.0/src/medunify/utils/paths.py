"""Path helpers."""

from __future__ import annotations

from pathlib import Path


def ensure_path(path: str | Path) -> Path:
    """Return a resolved Path object."""
    return Path(path).expanduser().resolve()


def infer_suffix(path: Path) -> str:
    """Return a normalized suffix including .nii.gz style endings."""
    name = path.name.lower()
    if name.endswith(".nii.gz"):
        return ".nii.gz"
    if name.endswith(".dcm") or name.endswith(".dicom"):
        return path.suffix.lower()
    return path.suffix.lower()
