"""Validation and optional dependency checks."""

from __future__ import annotations

import importlib
from typing import Any

from medunify.core.exceptions import DependencyMissingError


def require_modules(*names: str, feature: str) -> dict[str, Any]:
    """
    Import modules by dotted name; raise DependencyMissingError if any fail.

    Returns a mapping of name -> module for successful imports.
    """
    loaded: dict[str, Any] = {}
    missing: list[str] = []
    for name in names:
        try:
            loaded[name] = importlib.import_module(name)
        except ImportError:
            missing.append(name)
    if missing:
        raise DependencyMissingError(
            f"{feature} requires optional dependencies: {', '.join(missing)}. "
            f"Install the appropriate extra (e.g. pip install 'medunify[ai]')."
        )
    return loaded


def optional_import(name: str) -> Any | None:
    """Return module or None if import fails."""
    try:
        return importlib.import_module(name)
    except ImportError:
        return None
