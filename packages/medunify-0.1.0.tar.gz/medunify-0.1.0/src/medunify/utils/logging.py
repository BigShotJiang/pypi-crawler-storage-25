"""Lightweight logging helpers."""

from __future__ import annotations

import logging
from typing import Any

from medunify.core.config import config

_LOGGER: logging.Logger | None = None


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a configured logger (module-level singleton when name is None)."""
    global _LOGGER
    if name is None and _LOGGER is not None:
        return _LOGGER
    logger = logging.getLogger(name or "medunify")
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, config.log_level.upper(), logging.INFO))
    if name is None:
        _LOGGER = logger
    return logger
