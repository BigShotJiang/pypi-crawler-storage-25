"""Optional raster image loading (PNG/JPEG) via Pillow."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image

from medunify.imaging.models import MedicalImage


def load_raster(path: str | Path) -> MedicalImage:
    """Load a standard raster image as a single-slice ``MedicalImage``."""
    p = Path(path)
    with Image.open(p) as im:
        arr = np.asarray(im.convert("L"), dtype=np.float32)
    meta = {"filepath": str(p.resolve()), "mode": "L"}
    data = arr[np.newaxis, ...] if arr.ndim == 2 else arr
    return MedicalImage(
        data=data,
        format="raster",
        metadata=meta,
        source_path=p.resolve(),
        raw=None,
    )


def save_raster(image: MedicalImage, path: str | Path) -> None:
    """Save the middle Z slice as grayscale PNG."""
    data = image.data
    if data.ndim == 3:
        slc = data[data.shape[0] // 2]
    elif data.ndim == 2:
        slc = data
    else:
        raise ValueError("Unsupported rank for raster export")
    im = Image.fromarray(np.clip(slc, 0, 255).astype(np.uint8))
    im.save(str(path))
