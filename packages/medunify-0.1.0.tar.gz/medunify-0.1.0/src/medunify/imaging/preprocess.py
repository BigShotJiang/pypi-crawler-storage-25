"""Preprocessing utilities for ``MedicalImage``."""

from __future__ import annotations

import numpy as np

from medunify.adapters import sitk_adapter
from medunify.core.exceptions import InvalidMedicalDataError
from medunify.imaging.models import MedicalImage


def normalize_image(image: MedicalImage) -> MedicalImage:
    """Min–max normalize to [0, 1] using SimpleITK when possible."""
    itk = sitk_adapter.numpy_to_sitk(image.data)
    out = sitk_adapter.normalize_intensity(itk)
    data = sitk_adapter.sitk_to_numpy(out)
    meta = dict(image.metadata)
    meta["normalized"] = True
    return MedicalImage(
        data=data,
        format=image.format,
        metadata=meta,
        source_path=image.source_path,
        raw=image.raw,
    )


def resize_image(
    image: MedicalImage,
    size: tuple[int, ...],
) -> MedicalImage:
    """
    Resize to ``size`` as (X, Y) or (X, Y, Z) matching SimpleITK indexing.

    The underlying array remains (Z, Y, X); spacing is updated in metadata when known.
    """
    if len(size) not in (2, 3):
        raise InvalidMedicalDataError("size must be length 2 or 3 (X, Y[, Z])")
    itk = sitk_adapter.numpy_to_sitk(image.data)
    if len(size) == 2:
        out = sitk_adapter.resize_to_shape(itk, (size[0], size[1]))
    else:
        out = sitk_adapter.resize_to_shape(itk, (size[0], size[1], size[2]))
    data = sitk_adapter.sitk_to_numpy(out)
    meta = dict(image.metadata)
    meta["resized_to"] = size
    return MedicalImage(
        data=data,
        format=image.format,
        metadata=meta,
        source_path=image.source_path,
        raw=image.raw,
    )


def apply_window(data: np.ndarray, center: float, width: float) -> np.ndarray:
    """Apply a linear intensity window (typical CT display)."""
    low = center - width / 2.0
    high = center + width / 2.0
    clipped = np.clip(data, low, high)
    return ((clipped - low) / max(high - low, 1e-6)).astype(np.float32)
