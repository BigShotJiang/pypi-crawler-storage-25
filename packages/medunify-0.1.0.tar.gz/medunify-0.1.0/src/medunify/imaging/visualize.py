"""Visualization helpers for imaging (matplotlib)."""

from __future__ import annotations

from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from medunify.imaging.models import MedicalImage


def show_slice(
    image: MedicalImage,
    *,
    index: int | None = None,
    axis: str = "z",
    cmap: str = "gray",
    title: str | None = None,
    **imshow_kwargs: Any,
) -> None:
    """Display a 2D slice from a ``MedicalImage`` using matplotlib."""
    data = image.data
    if data.ndim == 2:
        slc = data
    elif data.ndim == 3:
        if axis.lower() == "z":
            idx = data.shape[0] // 2 if index is None else int(index)
            slc = data[idx]
        elif axis.lower() == "y":
            idx = data.shape[1] // 2 if index is None else int(index)
            slc = data[:, idx, :]
        elif axis.lower() == "x":
            idx = data.shape[2] // 2 if index is None else int(index)
            slc = data[:, :, idx]
        else:
            raise ValueError("axis must be one of 'z', 'y', 'x'")
    else:
        raise ValueError("Unsupported array rank for slice display")
    plt.imshow(slc, cmap=cmap, **imshow_kwargs)
    plt.axis("off")
    if title:
        plt.title(title)
    plt.show()
