"""Domain models for medical imaging."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import numpy as np


@dataclass
class MedicalImage:
    """
    Unified imaging container used by the public ``Imaging`` facade.

    ``data`` uses NumPy array layout (Z, Y, X) for 3D volumes or (Y, X) for 2D.
    """

    data: np.ndarray
    format: Literal["dicom", "nifti", "raster", "array"]
    metadata: dict[str, Any] = field(default_factory=dict)
    source_path: Path | None = None
    raw: Any | None = None

    def to_numpy(self) -> np.ndarray:
        """Return the pixel/voxel array."""
        return self.data
