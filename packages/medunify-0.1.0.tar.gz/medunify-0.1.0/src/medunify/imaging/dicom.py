"""DICOM-specific helpers built on the pydicom adapter."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pydicom
from pydicom.dataset import Dataset

from medunify.adapters import pydicom_adapter
from medunify.core.exceptions import InvalidMedicalDataError
from medunify.imaging.models import MedicalImage


def load_dicom_file(path: str | Path) -> MedicalImage:
    """Load a single DICOM file into a ``MedicalImage``."""
    ds = pydicom_adapter.read_dicom(path)
    pixels = pydicom_adapter.get_pixels(ds)
    meta = pydicom_adapter.extract_metadata(ds)
    meta.setdefault("filepath", str(Path(path).resolve()))
    if pixels.ndim == 2:
        data = pixels[np.newaxis, ...]
    else:
        data = np.asarray(pixels, dtype=np.float32)
    return MedicalImage(
        data=data,
        format="dicom",
        metadata=meta,
        source_path=Path(path).resolve(),
        raw=ds,
    )


def _instance_sort_key(ds: Dataset) -> tuple[float, ...]:
    inst = getattr(ds, "InstanceNumber", None)
    if inst is not None:
        try:
            return (0.0, float(str(inst)))
        except ValueError:
            pass
    ipp = getattr(ds, "ImagePositionPatient", None)
    if ipp is not None and len(ipp) >= 3:
        try:
            z = float(ipp[2])
            return (1.0, z)
        except (TypeError, ValueError):
            pass
    return (2.0, 0.0)


def load_dicom_series(folder: str | Path) -> MedicalImage:
    """
    Load all DICOM files in a folder and stack 2D slices into a 3D volume.

    Sorting uses InstanceNumber when present, otherwise ImagePositionPatient Z.
    """
    folder_path = Path(folder).resolve()
    if not folder_path.is_dir():
        raise InvalidMedicalDataError(f"Not a directory: {folder_path}")
    files = sorted(
        [p for p in folder_path.rglob("*") if p.is_file() and p.suffix.lower() in {".dcm", ""}],
        key=lambda p: p.name,
    )
    if not files:
        files = [p for p in folder_path.iterdir() if p.is_file()]
    datasets: list[Dataset] = []
    for fp in files:
        try:
            ds = pydicom.dcmread(str(fp), stop_before_pixels=False, force=True)
            if getattr(ds, "SOPClassUID", None) is None:
                continue
            datasets.append(ds)
        except Exception:
            continue
    if not datasets:
        raise InvalidMedicalDataError(f"No readable DICOM files in {folder_path}")
    datasets.sort(key=_instance_sort_key)
    slices = [pydicom_adapter.get_pixels(ds) for ds in datasets]
    shapes = {s.shape for s in slices}
    if len(shapes) != 1:
        raise InvalidMedicalDataError(f"Inconsistent slice shapes in series: {shapes}")
    volume = np.stack(slices, axis=0).astype(np.float32)
    meta = pydicom_adapter.extract_metadata(datasets[len(datasets) // 2])
    meta["series_slice_count"] = len(datasets)
    meta["series_folder"] = str(folder_path)
    return MedicalImage(
        data=volume,
        format="dicom",
        metadata=meta,
        source_path=folder_path,
        raw=datasets,
    )


def save_dicom(ds: Dataset, path: str | Path) -> None:
    """Write a pydicom Dataset to disk."""
    pydicom_adapter.write_dicom(ds, path)
