"""Public ``Imaging`` facade — unified medical imaging entry point."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from medunify.core.exceptions import UnsupportedFormatError
from medunify.imaging import dicom as dicom_io
from medunify.imaging import nifti as nifti_io
from medunify.imaging import preprocess as pre
from medunify.imaging import raster as raster_io
from medunify.imaging.models import MedicalImage
from medunify.utils.paths import ensure_path, infer_suffix


class Imaging:
    """
    Unified medical imaging API (research tooling — not a diagnostic device).

    Wraps pydicom, nibabel, and SimpleITK via adapters; does not replace PACS or viewers.
    """

    @staticmethod
    def load(path: str | Path) -> MedicalImage:
        """Load DICOM, NIfTI, or raster (PNG/JPEG) based on file extension."""
        p = ensure_path(path)
        suf = infer_suffix(p)
        if suf in {".dcm", ".dicom"}:
            return dicom_io.load_dicom_file(p)
        if suf in {".nii", ".nii.gz"}:
            return nifti_io.load_nifti(p)
        if suf in {".png", ".jpg", ".jpeg", ".tif", ".tiff"}:
            return raster_io.load_raster(p)
        raise UnsupportedFormatError(f"Unsupported imaging format for suffix {suf!r}: {p}")

    @staticmethod
    def load_series(folder_path: str | Path) -> MedicalImage:
        """Load a DICOM series from a folder."""
        return dicom_io.load_dicom_series(folder_path)

    @staticmethod
    def save(image: MedicalImage, path: str | Path) -> None:
        """Save using NIfTI or raster rules based on extension."""
        p = ensure_path(path)
        suf = infer_suffix(p)
        if suf in {".nii", ".nii.gz"}:
            nifti_io.save_nifti(image, p)
        elif suf in {".png", ".jpg", ".jpeg"}:
            raster_io.save_raster(image, p)
        else:
            raise UnsupportedFormatError(f"Cannot save to unsupported extension: {suf!r}")

    @staticmethod
    def metadata(image: MedicalImage) -> dict[str, Any]:
        """Return imaging metadata collected at load time."""
        return dict(image.metadata)

    @staticmethod
    def to_numpy(image: MedicalImage) -> np.ndarray:
        """Return the voxel/pixel array."""
        return image.to_numpy()

    @staticmethod
    def normalize(image: MedicalImage) -> MedicalImage:
        """Intensity normalize to [0,1] (SimpleITK-backed)."""
        return pre.normalize_image(image)

    @staticmethod
    def resize(image: MedicalImage, size: tuple[int, ...]) -> MedicalImage:
        """Resize volume to ``size`` as (X,Y) or (X,Y,Z)."""
        return pre.resize_image(image, size)

    @staticmethod
    def window(image: MedicalImage, center: float, width: float) -> MedicalImage:
        """Apply display windowing and return a new ``MedicalImage``."""
        data = pre.apply_window(image.data, center, width)
        meta = dict(image.metadata)
        meta["window_center"] = center
        meta["window_width"] = width
        return MedicalImage(
            data=data,
            format=image.format,
            metadata=meta,
            source_path=image.source_path,
            raw=image.raw,
        )

    @staticmethod
    def describe(image: MedicalImage) -> str:
        """Short textual summary suitable for logging."""
        shape = tuple(int(x) for x in image.data.shape)
        src = image.source_path or Path(".")
        return (
            f"MedicalImage(format={image.format}, shape={shape}, source={src}, "
            f"keys={len(image.metadata)})"
        )
