"""NIfTI helpers built on the nibabel adapter."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from medunify.adapters import nibabel_adapter
from medunify.imaging.models import MedicalImage


def load_nifti(path: str | Path) -> MedicalImage:
    """Load a NIfTI volume into a ``MedicalImage``."""
    img, data, meta = nibabel_adapter.read_nifti(path)
    if data.ndim == 3:
        arr = np.asarray(data, dtype=np.float32)
    elif data.ndim == 4:
        arr = np.asarray(data[..., 0], dtype=np.float32)
    else:
        arr = np.asarray(data, dtype=np.float32)
    meta["filepath"] = str(Path(path).resolve())
    return MedicalImage(
        data=arr,
        format="nifti",
        metadata=meta,
        source_path=Path(path).resolve(),
        raw=img,
    )


def save_nifti(image: MedicalImage, path: str | Path) -> None:
    """Persist ``MedicalImage`` as NIfTI."""
    affine = None
    if image.raw is not None and hasattr(image.raw, "affine"):
        affine = image.raw.affine
    if affine is None:
        affine = np.eye(4)
    nibabel_adapter.write_nifti(image.data, path, affine=affine)
