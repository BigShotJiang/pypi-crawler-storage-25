"""FHIR JSON I/O using fhir.resources."""

from __future__ import annotations

from typing import Any

from medunify.adapters import fhir_adapter
from medunify.records.models import FhirResourceWrapper


def load_fhir_path(path: str) -> FhirResourceWrapper:
    """Load FHIR JSON from disk and wrap the resource."""
    data = fhir_adapter.load_json(path)
    return parse_fhir_dict(data)


def parse_fhir_dict(data: dict[str, Any]) -> FhirResourceWrapper:
    """Parse a FHIR resource dict into a typed model and wrapper."""
    obj = fhir_adapter.parse_resource(data)
    return FhirResourceWrapper(resource=obj, raw=data)
