"""Public ``Records`` facade for FHIR resources."""

from __future__ import annotations

from typing import Any

from fhir.resources.imagingstudy import ImagingStudy
from fhir.resources.observation import Observation
from fhir.resources.patient import Patient

from medunify.records.fhir_io import load_fhir_path, parse_fhir_dict
from medunify.records.models import FhirResourceWrapper


def _summarize_patient(p: Patient) -> str:
    name = ""
    if p.name:
        hn = p.name[0]
        given_list = hn.given or []
        first = given_list[0] if given_list else ""
        fam = hn.family or ""
        name = f"{first} {fam}".strip()
    return f"Patient id={p.id!r} name={name!r} gender={p.gender!r}"


def _summarize_observation(o: Observation) -> str:
    code = o.code.text or (o.code.coding[0].display if o.code.coding else "unknown")
    val = ""
    if o.valueQuantity is not None:
        vq = o.valueQuantity
        val = f"{vq.value} {vq.unit or ''}"
    return f"Observation code={code!r} value={val!r} status={o.status!r}"


def _summarize_imaging_study(s: ImagingStudy) -> str:
    return f"ImagingStudy id={s.id!r} status={s.status!r} modality count={len(s.series or [])}"


class Records:
    """
    FHIR record helpers (SDK-level — not a regulated EHR).

    Supports Patient, Observation, and ImagingStudy resources via ``fhir.resources``.
    """

    @staticmethod
    def load_fhir(path: str) -> FhirResourceWrapper:
        """Load a FHIR JSON file from ``path``."""
        return load_fhir_path(path)

    @staticmethod
    def parse_fhir_dict(data: dict[str, Any]) -> FhirResourceWrapper:
        """Parse an in-memory FHIR resource dictionary."""
        return parse_fhir_dict(data)

    @staticmethod
    def resource_type(obj: FhirResourceWrapper | Patient | Observation | ImagingStudy) -> str:
        """Return the FHIR ``resourceType`` string."""
        if isinstance(obj, FhirResourceWrapper):
            return type(obj.resource).__name__
        return type(obj).__name__

    @staticmethod
    def summarize(obj: FhirResourceWrapper | Patient | Observation | ImagingStudy) -> str:
        """Return a short human-readable summary."""
        res = obj.resource if isinstance(obj, FhirResourceWrapper) else obj
        if isinstance(res, Patient):
            return _summarize_patient(res)
        if isinstance(res, Observation):
            return _summarize_observation(res)
        if isinstance(res, ImagingStudy):
            return _summarize_imaging_study(res)
        return f"FHIR resource {type(res).__name__}"
