"""FHIR clinical records module."""

from medunify.records.facade import Records
from medunify.records.models import FhirResourceWrapper

__all__ = ["Records", "FhirResourceWrapper"]
