"""FHIR-facing domain wrappers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fhir.resources.imagingstudy import ImagingStudy
from fhir.resources.observation import Observation
from fhir.resources.patient import Patient


@dataclass
class FhirResourceWrapper:
    """
    Normalized access to a FHIR resource while preserving the typed model.

    This is interoperability glue — not a complete FHIR server or EHR replacement.
    """

    resource: Patient | Observation | ImagingStudy
    raw: dict[str, Any]
