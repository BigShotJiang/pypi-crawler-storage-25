"""Adapter for MONAI / PyTorch — tensor prep and model execution."""

from __future__ import annotations

from typing import Any

import numpy as np

from medunify.core.exceptions import DependencyMissingError
from medunify.utils.validation import require_modules


def _torch_monai():
    return require_modules("torch", "monai", feature="MONAI inference")


def prepare_tensor(
    array: np.ndarray,
    *,
    channel_first: bool = True,
    add_batch: bool = True,
    device: str | None = None,
) -> Any:
    """
    Convert a NumPy array to a Torch tensor for MONAI models.

    Shapes:
    - 2D (H, W): optional channel dim -> (C,H,W), optional batch -> (B,C,H,W)
    - 3D (Z, Y, X): optional channel -> (C,Z,Y,X), optional batch -> (B,C,Z,Y,X)

    This supports research workflows only — not clinical diagnosis.
    """
    torch, _monai = _torch_monai()
    x = torch.from_numpy(np.asarray(array, dtype=np.float32))
    if channel_first:
        x = x.unsqueeze(0)
    if add_batch:
        x = x.unsqueeze(0)
    if device:
        x = x.to(device)
    return x


def run_model(model: Any, tensor: Any) -> Any:
    """Run a forward pass under ``torch.no_grad()``."""
    torch, _m = _torch_monai()
    model.eval()
    with torch.no_grad():
        return model(tensor)


def ensure_monai_available() -> None:
    """Raise if torch/monai are not installed."""
    try:
        _torch_monai()
    except DependencyMissingError as exc:
        raise DependencyMissingError(
            "Install the AI extra: pip install 'medunify[ai]' (requires PyTorch + MONAI)."
        ) from exc
