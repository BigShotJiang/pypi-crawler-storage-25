"""Adapter for nibabel — NIfTI read/write."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np

from medunify.core.exceptions import InvalidMedicalDataError


def read_nifti(path: str | Path) -> tuple[nib.Nifti1Image, np.ndarray, dict[str, Any]]:
    """Load NIfTI and return (image, data array, header metadata dict)."""
    p = Path(path)
    if not p.is_file():
        raise InvalidMedicalDataError(f"NIfTI path is not a file: {p}")
    img = nib.load(str(p))
    data = np.asarray(img.dataobj, dtype=np.float32)
    header = img.header
    meta: dict[str, Any] = {
        "affine": img.affine.tolist(),
        "zooms": tuple(float(x) for x in img.header.get_zooms()),
        "dtype": str(data.dtype),
        "shape": tuple(int(x) for x in data.shape),
    }
    if hasattr(header, "get_xyzt_units"):
        try:
            meta["xyzt_units"] = header.get_xyzt_units()
        except Exception:
            pass
    return img, data, meta


def write_nifti(
    data: np.ndarray,
    path: str | Path,
    affine: np.ndarray | None = None,
    header: Any | None = None,
) -> None:
    """Write a NumPy volume to NIfTI."""
    if affine is None:
        affine = np.eye(4)
    img = nib.Nifti1Image(data, affine, header=header)
    nib.save(img, str(path))
