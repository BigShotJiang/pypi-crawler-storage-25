"""Adapter for WFDB — biosignal record loading."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import wfdb

from medunify.core.exceptions import InvalidMedicalDataError


def read_record(
    record_name: str,
    pn_dir: str | None = None,
    channels: list[str] | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """
    Load WFDB signals.

    Parameters
    ----------
    record_name:
        Record stem or path prefix understood by wfdb.rdrecord.
    pn_dir:
        PhysioNet database subdirectory (e.g. 'mitdb' for record '100').
    channels:
        Optional channel names to restrict loading.
    """
    try:
        rec = wfdb.rdrecord(record_name, pn_dir=pn_dir, channel_names=channels)
    except Exception as exc:  # wfdb raises various errors
        raise InvalidMedicalDataError(f"Failed to read WFDB record {record_name!r}: {exc}") from exc

    sig = np.asarray(rec.p_signal if rec.p_signal is not None else rec.d_signal, dtype=np.float32)
    meta: dict[str, Any] = {
        "fs": float(rec.fs),
        "sig_name": list(rec.sig_name),
        "units": list(rec.units),
        "n_sig": int(rec.n_sig),
        "record_name": record_name,
        "pn_dir": pn_dir,
    }
    return sig, meta


def read_annotations(record_name: str, pn_dir: str | None = None) -> Any:
    """Return WFDB annotation object if present."""
    try:
        base = Path(record_name).name
        return wfdb.rdann(base, "atr", pn_dir=pn_dir)
    except Exception:
        return None


def extract_signal_metadata(record_name: str, pn_dir: str | None) -> dict[str, Any]:
    """Lightweight metadata without loading full signal (best-effort)."""
    p = Path(record_name)
    base = p.stem if p.suffix else p.name
    return {"record": base, "pn_dir": pn_dir}
