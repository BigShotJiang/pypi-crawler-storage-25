"""
Third-party adapters — import submodules directly (e.g. ``medunify.adapters.pydicom_adapter``).

This package intentionally avoids eager re-exports so optional stacks stay isolated.
"""
