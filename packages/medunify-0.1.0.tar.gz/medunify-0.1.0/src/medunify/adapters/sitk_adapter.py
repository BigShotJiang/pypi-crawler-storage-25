"""Adapter for SimpleITK — geometric and intensity operations."""

from __future__ import annotations

import numpy as np
import SimpleITK as sitk

from medunify.core.exceptions import InvalidMedicalDataError


def numpy_to_sitk(arr: np.ndarray, spacing: tuple[float, ...] | None = None) -> sitk.Image:
    """Convert a NumPy array (Z,Y,X or Y,X) to SimpleITK Image."""
    itk = sitk.GetImageFromArray(np.asarray(arr))
    if spacing is not None and len(spacing) == itk.GetDimension():
        itk.SetSpacing(spacing[::-1] if itk.GetDimension() == 3 else spacing)
    return itk


def sitk_to_numpy(img: sitk.Image) -> np.ndarray:
    """Convert SimpleITK image to NumPy array (Z,Y,X or Y,X)."""
    return sitk.GetArrayFromImage(img).astype(np.float32)


def resize_to_shape(
    image: sitk.Image,
    size_xyz: tuple[int, int] | tuple[int, int, int],
    interpolator: int = sitk.sitkLinear,
) -> sitk.Image:
    """
    Resample so output grid has size ``size_xyz`` in (X, Y[, Z]) order.

    Physical extent is preserved by adjusting spacing.
    """
    orig_size = image.GetSize()
    orig_spacing = image.GetSpacing()
    if len(orig_size) != len(size_xyz):
        raise InvalidMedicalDataError("size_xyz dimensionality must match image dimensionality")
    new_spacing = tuple(
        float(orig_size[i] * orig_spacing[i]) / float(size_xyz[i]) for i in range(len(orig_size))
    )
    resample = sitk.ResampleImageFilter()
    resample.SetInterpolator(interpolator)
    resample.SetOutputSpacing(new_spacing)
    resample.SetSize(size_xyz)
    resample.SetOutputDirection(image.GetDirection())
    resample.SetOutputOrigin(image.GetOrigin())
    resample.SetDefaultPixelValue(0)
    return resample.Execute(image)


def normalize_intensity(
    image: sitk.Image,
    min_val: float | None = None,
    max_val: float | None = None,
) -> sitk.Image:
    """Normalize intensities roughly to [0, 1] using min/max clamp."""
    cast = sitk.Cast(image, sitk.sitkFloat32)
    stats = sitk.StatisticsImageFilter()
    stats.Execute(cast)
    mn = float(min_val if min_val is not None else stats.GetMinimum())
    mx = float(max_val if max_val is not None else stats.GetMaximum())
    if mx <= mn:
        return sitk.Image(cast)
    return (cast - mn) / (mx - mn)
