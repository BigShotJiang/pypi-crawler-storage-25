"""Adapter for fhir.resources — load and validate FHIR JSON."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fhir.resources.imagingstudy import ImagingStudy
from fhir.resources.observation import Observation
from fhir.resources.patient import Patient

from medunify.core.exceptions import InvalidMedicalDataError


def load_json(path: str | Path) -> dict[str, Any]:
    """Load JSON object from disk."""
    p = Path(path)
    if not p.is_file():
        raise InvalidMedicalDataError(f"FHIR JSON not found: {p}")
    with p.open(encoding="utf-8") as f:
        return json.load(f)


def parse_resource(data: dict[str, Any]) -> Patient | Observation | ImagingStudy:
    """Parse a FHIR resource dict into a fhir.resources model."""
    rtype = data.get("resourceType")
    if rtype == "Patient":
        return Patient.model_validate(data)
    if rtype == "Observation":
        return Observation.model_validate(data)
    if rtype == "ImagingStudy":
        return ImagingStudy.model_validate(data)
    raise InvalidMedicalDataError(f"Unsupported or missing resourceType: {rtype!r}")


def validate_resource(obj: Any) -> None:
    """Reserved hook for stricter validation pipelines."""
    if obj is None:
        raise InvalidMedicalDataError("FHIR resource is None")
