"""Adapter for pydicom — DICOM read and pixel access."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pydicom
from pydicom.dataset import Dataset

from medunify.core.exceptions import InvalidMedicalDataError


def read_dicom(path: str | Path) -> Dataset:
    """Load a DICOM file from disk."""
    p = Path(path)
    if not p.is_file():
        raise InvalidMedicalDataError(f"DICOM path is not a file: {p}")
    return pydicom.dcmread(str(p), force=True)


def extract_metadata(ds: Dataset) -> dict[str, Any]:
    """Extract a JSON-serializable subset of DICOM metadata."""
    meta: dict[str, Any] = {}
    for elem in ds.iterall():
        if elem.VR in {"SQ", "OB", "OW", "OD", "OF"} or elem.tag == (0x7FE0, 0x0010):
            continue
        key = elem.keyword or str(elem.tag)
        try:
            val = elem.value
            if hasattr(val, "original_string"):
                meta[key] = str(val)
            else:
                meta[key] = val
        except Exception:
            meta[key] = "<unavailable>"
    return meta


def get_pixels(ds: Dataset) -> np.ndarray:
    """Return pixel array with photometric interpretation applied when needed."""
    arr = ds.pixel_array
    if getattr(ds, "PhotometricInterpretation", None) == "MONOCHROME1":
        arr = np.max(arr) - arr
    return np.asarray(arr, dtype=np.float32)


def write_dicom(ds: Dataset, path: str | Path) -> None:
    """Persist a Dataset to disk."""
    ds.save_as(str(path), write_like_original=False)
