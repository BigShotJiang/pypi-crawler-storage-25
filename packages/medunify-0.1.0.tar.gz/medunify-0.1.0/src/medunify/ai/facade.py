"""Public ``AI`` facade — MONAI-oriented research inference."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from medunify.ai import monai_runner
from medunify.ai.model_registry import (
    list_models as _list_models,
    register_model as _register_model,
)
from medunify.imaging.models import MedicalImage


class AI:
    """
    Unified entry point for optional MONAI/PyTorch workflows.

    MedUnify does **not** ship clinical-grade model weights. Register your own models and
    supply weights through your loader. This is research and integration tooling only.
    """

    @staticmethod
    def run_inference(
        *,
        image: MedicalImage,
        task: str,
        model_name: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run registered inference for ``task`` and ``model_name``."""
        monai_runner.ensure_ai_dependencies()
        return monai_runner.run_inference_mvp(image, task, model_name, **kwargs)

    @staticmethod
    def list_models() -> list[dict[str, str]]:
        """List models registered via ``register_model`` (includes research stubs when enabled)."""
        monai_runner.ensure_ai_dependencies()
        monai_runner.prime_registry()
        return _list_models()

    @staticmethod
    def register_model(name: str, task: str, loader_callable: Callable[[], Any]) -> None:
        """Register a callable that returns a ``torch.nn.Module``."""
        monai_runner.ensure_ai_dependencies()
        _register_model(name, task, loader_callable)
