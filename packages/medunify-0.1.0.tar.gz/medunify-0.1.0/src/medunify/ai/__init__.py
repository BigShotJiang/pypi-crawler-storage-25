"""Optional AI / MONAI integration (requires ``medunify[ai]``)."""

from medunify.ai.facade import AI
from medunify.ai.tasks import InferenceTask

__all__ = ["AI", "InferenceTask"]
