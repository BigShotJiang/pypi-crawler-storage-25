"""AI task identifiers (research tooling — not clinical decision support)."""

from __future__ import annotations

from enum import Enum


class InferenceTask(str, Enum):
    """Supported high-level inference tasks for registry routing."""

    SEGMENTATION = "segmentation"
    CLASSIFICATION = "classification"
