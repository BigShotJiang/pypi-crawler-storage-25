"""MONAI-oriented inference runner (optional ``[ai]`` extra)."""

from __future__ import annotations

from typing import Any

import numpy as np

from medunify.adapters import monai_adapter
from medunify.ai.model_registry import RegisteredModel, get_model, register_model
from medunify.core.exceptions import DependencyMissingError, InvalidMedicalDataError
from medunify.imaging.models import MedicalImage


def prime_registry() -> None:
    """Ensure built-in research stubs are registered (development/smoke-test only)."""
    _register_built_in_research_stubs()


def _register_built_in_research_stubs() -> None:
    """
    Register a tiny, **untrained** 3D conv stub as ``basic_unet`` for smoke tests.

    This is not a clinical model and produces no meaningful segmentation.
    """
    if get_model("basic_unet", "segmentation") is not None:
        return

    def loader() -> Any:
        import torch
        import torch.nn as nn

        class _ResearchStubNet(nn.Module):
            """Untrained 3D conv stub for integration tests only."""

            def __init__(self) -> None:
                super().__init__()
                self.conv = nn.Conv3d(1, 1, kernel_size=3, padding=1)

            def forward(self, x: torch.Tensor) -> torch.Tensor:
                return torch.sigmoid(self.conv(x))

        return _ResearchStubNet()

    register_model("basic_unet", "segmentation", loader)


def run_segmentation(
    image: MedicalImage,
    entry: RegisteredModel,
    *,
    device: str | None = None,
) -> np.ndarray:
    """
    Run a segmentation model and return a NumPy map.

    **Research use only.** Requires a model appropriate for the input geometry.
    """
    monai_adapter.ensure_monai_available()
    model = entry.loader()
    tensor = monai_adapter.prepare_tensor(image.data, device=device)
    try:
        out = monai_adapter.run_model(model, tensor)
    except Exception as exc:
        raise InvalidMedicalDataError(f"Model forward pass failed: {exc}") from exc
    if hasattr(out, "detach"):
        return out.detach().cpu().numpy()
    return np.asarray(out)


def run_inference_mvp(
    image: MedicalImage,
    task: str,
    model_name: str,
    **kwargs: Any,
) -> dict[str, Any]:
    """Dispatch inference by task name using the registry."""
    _register_built_in_research_stubs()
    entry = get_model(model_name, task)
    if entry is None:
        raise InvalidMedicalDataError(
            f"No model registered for task={task!r} name={model_name!r}. "
            "Use AI.register_model(...) or rely on built-in research stubs in development only."
        )
    if task == "segmentation":
        arr = run_segmentation(image, entry, device=kwargs.get("device"))
        return {"task": task, "output": arr, "model": model_name}
    raise InvalidMedicalDataError(f"Task not implemented: {task!r}")


def ensure_ai_dependencies() -> None:
    """Raise DependencyMissingError if torch/monai are not installed."""
    try:
        monai_adapter.ensure_monai_available()
    except DependencyMissingError:
        raise DependencyMissingError(
            "AI features require: pip install 'medunify[ai]'"
        ) from None
