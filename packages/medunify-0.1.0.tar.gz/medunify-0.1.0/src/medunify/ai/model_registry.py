"""Registry for user-registered MONAI/PyTorch models."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class RegisteredModel:
    """Metadata for a callable that returns a torch.nn.Module."""

    name: str
    task: str
    loader: Callable[[], Any]


_REGISTRY: dict[tuple[str, str], RegisteredModel] = {}


def register_model(name: str, task: str, loader_callable: Callable[[], Any]) -> None:
    """Register a model factory for a given ``(name, task)`` pair."""
    key = (name, task)
    _REGISTRY[key] = RegisteredModel(name=name, task=task, loader=loader_callable)


def list_models() -> list[dict[str, str]]:
    """Return registered model descriptors."""
    return [{"name": m.name, "task": m.task} for m in _REGISTRY.values()]


def get_model(name: str, task: str) -> RegisteredModel | None:
    """Return registry entry if present."""
    return _REGISTRY.get((name, task))


def clear_registry() -> None:
    """Test helper — clear all registrations."""
    _REGISTRY.clear()
