"""Shared typing helpers and protocols used across modules."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class HasToNumpy(Protocol):
    """Objects that can export a NumPy array representation."""

    def to_numpy(self) -> Any:  # noqa: ANN401 — numpy.ndarray at runtime
        ...


@runtime_checkable
class HasMetadata(Protocol):
    """Objects that expose a metadata mapping."""

    @property
    def metadata(self) -> dict[str, Any]:
        ...
