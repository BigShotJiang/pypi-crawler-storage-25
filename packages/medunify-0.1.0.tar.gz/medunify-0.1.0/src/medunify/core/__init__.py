"""Core foundations: exceptions, types, configuration."""

from medunify.core.config import MedUnifyConfig, config
from medunify.core.exceptions import (
    DependencyMissingError,
    InvalidMedicalDataError,
    MedUnifyError,
    UnsupportedFormatError,
)

__all__ = [
    "MedUnifyConfig",
    "config",
    "DependencyMissingError",
    "InvalidMedicalDataError",
    "MedUnifyError",
    "UnsupportedFormatError",
]
