"""Shared exception hierarchy for MedUnify."""

from __future__ import annotations


class MedUnifyError(Exception):
    """Base error for all MedUnify operations."""

    pass


class UnsupportedFormatError(MedUnifyError):
    """Raised when a file format or modality is not supported."""

    pass


class DependencyMissingError(MedUnifyError):
    """Raised when an optional dependency is required but not installed."""

    pass


class InvalidMedicalDataError(MedUnifyError):
    """Raised when medical data fails validation or is inconsistent."""

    pass
