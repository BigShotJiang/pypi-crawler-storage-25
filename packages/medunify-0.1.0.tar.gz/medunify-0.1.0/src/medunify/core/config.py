"""Runtime configuration for MedUnify (unified medical workflow SDK)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class MedUnifyConfig:
    """Lightweight global defaults; extend without breaking callers."""

    log_level: str = "INFO"
    extra: dict[str, Any] = field(default_factory=dict)


config = MedUnifyConfig()
