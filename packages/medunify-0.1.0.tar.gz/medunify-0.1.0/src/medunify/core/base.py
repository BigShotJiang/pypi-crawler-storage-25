"""Base abstractions for adapters and domain objects."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class Adapter(ABC, Generic[T]):
    """Thin wrapper contract for third-party libraries."""

    name: str

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if the backing dependency imports successfully."""

    @property
    @abstractmethod
    def backend(self) -> T | None:
        """Expose the imported module or None if missing."""
