# MedUnify

**MedUnify** is a unified medical workflow SDK for Python. It wraps mature ecosystems
(**pydicom**, **nibabel**, **SimpleITK**, **WFDB**, **fhir.resources**, optional **MONAI**)
behind small adapters and a stable, developer-friendly surface API.

This project is **not** a medical device, **not** a diagnostic engine, and **not** a
replacement for PACS, EHRs, or regulated clinical software. It exists to help researchers
and engineers integrate imaging, biosignals, FHIR records, and research-grade ML tooling
with less glue code.

## Why MedUnify?

Hospital and research workflows often combine DICOM/NIfTI pipelines, waveform archives,
FHIR JSON, and PyTorch/MONAI experiments. Each ecosystem is powerful on its own, but
public codebases frequently reimplement the same adapters. MedUnify centralizes those
integrations behind explicit adapter modules and narrow facades so applications can grow
without turning into an unmaintainable monolith.

## Installation

Requires **Python 3.11+**.

```bash
pip install -e .
```

Optional AI stack (PyTorch + MONAI):

```bash
pip install -e ".[ai]"
```

Development tools:

```bash
pip install -e ".[dev]"
```

## Quickstart

```python
from medunify import Imaging, Signals, Records, AI

img = Imaging.load("scan.dcm")
series = Imaging.load_series("dicom_folder/")
meta = Imaging.metadata(img)

ecg = Signals.load("100", source="wfdb", pn_dir="mitdb")

patient = Records.parse_fhir_dict({...})

result = AI.run_inference(
    image=img,
    task="segmentation",
    model_name="basic_unet",
)
```

> **Important:** `AI` features require the `[ai]` extra. Built-in `basic_unet` is an
> **untrained research stub** for smoke tests — supply your own weights and models for
> real experiments.

## Module overview

| Module    | Purpose |
|-----------|---------|
| `Imaging` | DICOM / NIfTI / raster load, metadata, preprocess helpers |
| `Signals` | WFDB-backed biosignals (extensible to more sources) |
| `Records` | FHIR Patient / Observation / ImagingStudy via `fhir.resources` |
| `AI`      | Optional MONAI-oriented registry and inference runner |

## Architecture

- **`src/medunify/adapters/`** — thin wrappers around third-party libraries (imported as
  submodules such as `medunify.adapters.pydicom_adapter` to avoid eager loading unrelated stacks).
- **`src/medunify/*/`** — domain models and facades (`Imaging`, `Signals`, `Records`, `AI`).
- **`AI`** is lazy-imported from `medunify` so environments without PyTorch/MONAI can still use
  imaging/signals/FHIR workflows.
- **`tests/`** — pytest coverage for public APIs and adapters (with mocks where needed).

## Roadmap

- Additional biosignal sources (EDF, proprietary readers behind adapters).
- Stronger FHIR resource coverage and validation pipelines.
- Pluggable preprocessing for AI (spacing-aware resampling, clip/normalize presets).
- Optional plugins for deployment-specific configuration.

## Disclaimer

MedUnify is provided for **research, education, and integration** purposes. It must not be
used for autonomous clinical diagnosis or any regulated use without appropriate validation,
human oversight, and compliance with local laws and institutional policies.

## License

MIT — see `LICENSE`.
