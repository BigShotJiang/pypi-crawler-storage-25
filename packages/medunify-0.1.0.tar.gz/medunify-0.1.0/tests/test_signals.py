"""Tests for biosignal wrappers."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np

from medunify import Signals
from medunify.signals.models import Biosignal


def test_signals_load_wfdb_mocked() -> None:
    fake_sig = np.zeros((500, 2), dtype=np.float32)
    rec = MagicMock()
    rec.p_signal = fake_sig
    rec.d_signal = None
    rec.fs = 360.0
    rec.sig_name = ["MLII", "V5"]
    rec.units = ["mV", "mV"]
    rec.n_sig = 2
    with (
        patch("medunify.adapters.wfdb_adapter.wfdb.rdrecord", return_value=rec),
        patch("medunify.adapters.wfdb_adapter.wfdb.rdann", return_value=None),
    ):
        sig = Signals.load("100", source="wfdb", pn_dir="mitdb")
    assert isinstance(sig, Biosignal)
    assert sig.samples.shape == fake_sig.shape
    assert "MLII" in sig.channel_names
    meta = Signals.metadata(sig)
    assert meta["fs"] == 360.0
    assert Signals.to_numpy(sig).shape[0] == 500
    assert "Biosignal" in Signals.describe(sig)
