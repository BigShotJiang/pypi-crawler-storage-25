"""Smoke tests for public exports."""

from __future__ import annotations

from medunify import (
    AI,
    DependencyMissingError,
    Imaging,
    InvalidMedicalDataError,
    MedUnifyError,
    Records,
    Signals,
    UnsupportedFormatError,
)


def test_imports() -> None:
    assert Imaging is not None
    assert Signals is not None
    assert Records is not None
    assert AI is not None
    assert issubclass(MedUnifyError, Exception)
    assert issubclass(UnsupportedFormatError, MedUnifyError)
    assert issubclass(DependencyMissingError, MedUnifyError)
    assert issubclass(InvalidMedicalDataError, MedUnifyError)
