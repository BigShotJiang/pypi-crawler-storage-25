"""Tests for optional AI module (requires ``medunify[ai]``)."""

from __future__ import annotations

import numpy as np
import pytest

pytest.importorskip("torch")
pytest.importorskip("monai")

from medunify.ai.model_registry import clear_registry
from medunify.imaging.models import MedicalImage


@pytest.fixture(autouse=True)
def _clear_registry() -> None:
    clear_registry()
    yield
    clear_registry()


def test_ai_segmentation_stub() -> None:
    from medunify import AI

    vol = np.random.rand(4, 16, 16, 16).astype(np.float32)
    img = MedicalImage(data=vol, format="array")
    out = AI.run_inference(image=img, task="segmentation", model_name="basic_unet")
    assert out["task"] == "segmentation"
    assert "output" in out
    assert isinstance(out["output"], np.ndarray)


def test_list_models() -> None:
    from medunify import AI

    models = AI.list_models()
    names = {m["name"] for m in models}
    assert "basic_unet" in names
