"""Tests for FHIR record helpers."""

from __future__ import annotations

from medunify import Records
from medunify.records.models import FhirResourceWrapper


def test_parse_patient_dict() -> None:
    data = {
        "resourceType": "Patient",
        "id": "example",
        "name": [{"family": "Chalmers", "given": ["Peter", "James"]}],
        "gender": "male",
    }
    wrapped = Records.parse_fhir_dict(data)
    assert isinstance(wrapped, FhirResourceWrapper)
    assert Records.resource_type(wrapped) == "Patient"
    summary = Records.summarize(wrapped)
    assert "Patient" in summary
    assert "Chalmers" in summary


def test_parse_observation_dict() -> None:
    data = {
        "resourceType": "Observation",
        "id": "obs1",
        "status": "final",
        "code": {"text": "Heart rate"},
        "valueQuantity": {"value": 72, "unit": "beats/min"},
    }
    wrapped = Records.parse_fhir_dict(data)
    assert Records.resource_type(wrapped) == "Observation"
    assert "Heart rate" in Records.summarize(wrapped)
