"""Tests for imaging facade and adapters."""

from __future__ import annotations

from pathlib import Path

import nibabel as nib
import numpy as np
import pytest
from pydicom.data import get_testdata_file

from medunify import Imaging
from medunify.core.exceptions import UnsupportedFormatError
from medunify.imaging.models import MedicalImage


def test_load_builtin_dicom_sample() -> None:
    path = get_testdata_file("CT_small.dcm")
    img = Imaging.load(path)
    assert img.format == "dicom"
    assert img.data.ndim >= 2
    meta = Imaging.metadata(img)
    assert "Modality" in meta or "SOPClassUID" in meta


def test_nifti_roundtrip(tmp_path: Path) -> None:
    data = np.random.rand(8, 9, 10).astype(np.float32)
    affine = np.eye(4)
    p = tmp_path / "tiny.nii.gz"
    nib.save(nib.Nifti1Image(data, affine), str(p))
    img = Imaging.load(p)
    assert img.format == "nifti"
    assert img.data.shape == data.shape


def test_describe_and_numpy() -> None:
    path = get_testdata_file("CT_small.dcm")
    img = Imaging.load(path)
    assert "MedicalImage" in Imaging.describe(img)
    arr = Imaging.to_numpy(img)
    assert isinstance(arr, np.ndarray)


def test_unsupported_format(tmp_path: Path) -> None:
    p = tmp_path / "weird.xyz"
    p.write_text("nope")
    with pytest.raises(UnsupportedFormatError):
        Imaging.load(p)


def test_window() -> None:
    path = get_testdata_file("CT_small.dcm")
    img = Imaging.load(path)
    w = Imaging.window(img, center=40.0, width=400.0)
    assert w.data.shape == img.data.shape


def test_medical_image_to_numpy() -> None:
    m = MedicalImage(data=np.zeros((2, 3, 4), dtype=np.float32), format="array")
    assert m.to_numpy().shape == (2, 3, 4)
