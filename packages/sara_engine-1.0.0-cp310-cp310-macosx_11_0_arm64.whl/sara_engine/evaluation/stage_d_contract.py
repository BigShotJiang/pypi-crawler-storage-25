# Directory Path: src/sara_engine/evaluation/stage_d_contract.py
# English Title: Stage D Continual Consolidation Readiness Contract
# Purpose/Content: Shared constants for Stage D minimum checks used by phase3 suite, release gate, and soak summaries.

from typing import Dict, List


STAGE_D_MINIMUM_METRIC_NAMES: List[str] = [
    "replay_recovery_integrity",
    "long_horizon_consolidation_retention",
    "counterfactual_replay_selection_integrity",
    "replay_upgrade_reindex_integrity",
    "memory_health_index_integrity",
    "astro_modulation_stability",
]


STAGE_D_REQUIRED_MINIMUM_CHECKS: Dict[str, str] = {
    "metric.replay_recovery_integrity": "replay recovery integrity",
    "metric.long_horizon_consolidation_retention": "long-horizon consolidation retention",
    "metric.counterfactual_replay_selection_integrity": "counterfactual replay selection integrity",
    "metric.replay_upgrade_reindex_integrity": "replay upgrade reindex integrity",
    "metric.memory_health_index_integrity": "memory health index integrity",
    "metric.astro_modulation_stability": "astro modulation stability",
}


def stage_d_metric_check_name(metric_name: str) -> str:
    return f"metric.{metric_name}"
