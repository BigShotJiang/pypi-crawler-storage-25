from __future__ import annotations

import geopandas as gpd
from pyproj import CRS


def resolve_metric_crs(gdf: gpd.GeoDataFrame) -> CRS:
    """Return a local UTM CRS (meter-based) derived from the dataset's centroid."""
    if gdf.crs is None:
        raise ValueError("Input GeoDataFrame must have a defined CRS.")
    gdf_wgs = gdf.to_crs(4326)
    centroids = gdf_wgs.geometry.centroid
    lon = float(centroids.x.mean())
    lat = float(centroids.y.mean())
    zone = int((lon + 180) // 6) + 1
    epsg = 32600 + zone if lat >= 0 else 32700 + zone
    return CRS.from_epsg(epsg)
