"""Decorator-based tracing for Reflect agents."""

from __future__ import annotations

import asyncio
import functools
import inspect
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, TypeVar, overload

from reflect_sdk.client import ReflectClient
from reflect_sdk.context import TraceContext

TrajectoryInput = Sequence[dict[str, Any]] | str
F = TypeVar("F", bound=Callable[..., Any])


@dataclass(slots=True)
class TraceResult:
    """Return this from a decorated function to provide full trace data.

    When the decorated function returns a plain string, only
    ``final_response`` is captured.  Return a ``TraceResult`` instead
    to supply the full trajectory, review result, and metadata.

    Example::

        @reflect_trace(client, task=lambda q: q)
        def answer(ctx, question: str) -> TraceResult:
            messages = [{"role": "user", "content": ctx.augmented_task}]
            resp = openai.chat(messages=messages)
            messages.append({"role": "assistant", "content": resp.content})
            return TraceResult(
                output=resp.content,
                trajectory=messages,
                result="pass",
                model="gpt-5.4-mini",
            )
    """

    output: str
    """The agent's final response (returned to the caller)."""

    trajectory: TrajectoryInput
    """Conversation messages — list of dicts or a JSON string."""

    result: str | None = None
    """``"pass"`` or ``"fail"``.  ``None`` for deferred review."""

    feedback_text: str | None = None
    """Explanation of what went wrong (when ``result="fail"``)."""

    model: str | None = None
    """LLM model name (e.g. ``"gpt-5.4-mini"``)."""

    metadata: dict[str, Any] | None = None
    """Arbitrary JSON metadata for the trace."""


def reflect_trace(
    client: ReflectClient,
    *,
    task: str | Callable[..., str] | None = None,
    limit: int = 10,
    lambda_: float = 0.5,
    blocking: bool = False,
    auto_fail_on_exception: bool = True,
    inject_context: bool = True,
) -> Callable[[F], F]:
    """Decorator that wraps a function with Reflect trace tracking.

    The decorated function receives a :class:`TraceContext` as its first
    argument (when ``inject_context=True``) and should return either a
    plain ``str`` (minimal trace) or a :class:`TraceResult` (full
    control).

    Args:
        client: The :class:`ReflectClient` to use for tracing.
        task: How to derive the task string.  Can be:
            - A static ``str`` — used as-is for every call.
            - A ``callable`` — called with the same ``*args, **kwargs``
              as the decorated function (excluding the injected ``ctx``).
            - ``None`` — the first positional argument is used.
        limit: Maximum memories to retrieve.
        lambda_: Blend between similarity and Q-value.
        blocking: Wait for memory creation before returning.
        auto_fail_on_exception: Auto-submit with ``result="fail"``
            on unhandled exceptions.
        inject_context: If ``True``, prepend a :class:`TraceContext`
            as the first argument to the decorated function.

    Example — simple string return::

        @reflect_trace(client, task=lambda question: question)
        def answer(ctx, question: str) -> str:
            return my_llm(ctx.augmented_task)

    Example — full TraceResult::

        @reflect_trace(client, task=lambda question: question)
        def answer(ctx, question: str) -> TraceResult:
            msgs = [{"role": "user", "content": ctx.augmented_task}]
            resp = my_llm(msgs)
            msgs.append({"role": "assistant", "content": resp})
            return TraceResult(output=resp, trajectory=msgs, result="pass")
    """

    def _resolve_task(args: tuple, kwargs: dict) -> str:
        if isinstance(task, str):
            return task
        if callable(task):
            return task(*args, **kwargs)
        if args:
            return str(args[0])
        return "unknown"

    def decorator(fn: F) -> F:
        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                resolved_task = _resolve_task(args, kwargs)
                async with client.trace_async(
                    resolved_task,
                    limit=limit,
                    lambda_=lambda_,
                    blocking=blocking,
                    auto_fail_on_exception=auto_fail_on_exception,
                ) as ctx:
                    if inject_context:
                        result = await fn(ctx, *args, **kwargs)
                    else:
                        result = await fn(*args, **kwargs)
                    return _handle_result(ctx, result)

            return async_wrapper  # type: ignore[return-value]

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            resolved_task = _resolve_task(args, kwargs)
            with client.trace(
                resolved_task,
                limit=limit,
                lambda_=lambda_,
                blocking=blocking,
                auto_fail_on_exception=auto_fail_on_exception,
            ) as ctx:
                if inject_context:
                    result = fn(ctx, *args, **kwargs)
                else:
                    result = fn(*args, **kwargs)
                return _handle_result(ctx, result)

        return sync_wrapper  # type: ignore[return-value]

    return decorator


def _handle_result(ctx: TraceContext, result: Any) -> Any:
    """Process the return value of a decorated function."""
    if isinstance(result, TraceResult):
        ctx.set_output(
            trajectory=result.trajectory,
            final_response=None,
            result=result.result,
            feedback_text=result.feedback_text,
            model=result.model,
            metadata=result.metadata,
        )
        return result.output
    if isinstance(result, str):
        ctx.set_output(trajectory=result, final_response=result)
        return result
    # Non-string, non-TraceResult: don't submit a trace
    return result
