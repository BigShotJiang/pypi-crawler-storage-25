"""Trace context manager for single-integration-path tracing."""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from reflect_sdk.client import Memory, ReflectClient, Trace, TraceSubmission

TrajectoryInput = Sequence[dict[str, Any]] | str

logger = logging.getLogger(__name__)


@dataclass
class TraceContext:
    """Holds augmented task context and collects trace output data.

    Returned by :meth:`ReflectClient.trace` and
    :meth:`ReflectClient.trace_async`.  Use :meth:`set_output` inside the
    ``with`` block to record your agent's result; the trace is
    auto-submitted with the correct ``retrieved_memory_ids`` on exit.
    """

    task: str
    """The original task description."""

    augmented_task: str
    """Task text with retrieved memories appended — ready to use as a prompt."""

    memories: list[Memory]
    """Memories retrieved for this task."""

    _client: ReflectClient = field(repr=False)
    _blocking: bool = field(default=False, repr=False)
    _auto_fail_on_exception: bool = field(default=True, repr=False)

    # Populated by set_output()
    _trajectory: TrajectoryInput | None = field(default=None, init=False, repr=False)
    _final_response: str | None = field(default=None, init=False, repr=False)
    _result: str | None = field(default=None, init=False, repr=False)
    _feedback_text: str | None = field(default=None, init=False, repr=False)
    _model: str | None = field(default=None, init=False, repr=False)
    _metadata: dict[str, Any] | None = field(default=None, init=False, repr=False)
    _submitted: bool = field(default=False, init=False, repr=False)
    _trace_id: str | None = field(default=None, init=False, repr=False)

    @property
    def trace_id(self) -> str | None:
        """ID of the submitted trace, available after the context manager exits.

        Returns ``None`` if the trace has not been submitted yet (i.e.
        inside the ``with`` block or when ``set_output`` was never called).
        """
        return self._trace_id

    @property
    def memory_ids(self) -> list[str]:
        """IDs of retrieved memories (auto-passed to the trace on submit)."""
        return [m.id for m in self.memories]

    def set_output(
        self,
        *,
        trajectory: TrajectoryInput,
        final_response: str | None = None,
        result: str | None = None,
        feedback_text: str | None = None,
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record the agent's output before exiting the context.

        Args:
            trajectory: The conversation messages (same format as
                :meth:`ReflectClient.create_trace`).
            final_response: Agent's final answer.  Extracted from
                trajectory automatically when ``None``.
            result: ``"pass"`` or ``"fail"``.  When ``None`` the trace
                is submitted without a review (deferred review).
            feedback_text: Explanation of what went wrong (used when
                ``result`` is ``"fail"``).
            model: LLM model name for dashboard display.
            metadata: Arbitrary JSON metadata to attach.
        """
        self._trajectory = trajectory
        self._final_response = final_response
        self._result = result
        self._feedback_text = feedback_text
        self._model = model
        self._metadata = metadata

    def _submit(self) -> TraceSubmission | Trace:
        """Submit the trace synchronously.  Called by the context manager."""
        if self._submitted:
            return  # type: ignore[return-value]
        self._submitted = True

        kwargs: dict[str, Any] = dict(
            task=self.task,
            trajectory=self._trajectory,
            final_response=self._final_response,
            retrieved_memory_ids=self.memory_ids,
            model=self._model,
            metadata=self._metadata,
            review_result=self._result,
            feedback_text=self._feedback_text,
        )
        if self._blocking:
            result = self._client.create_trace_and_wait(**kwargs)
        else:
            result = self._client.create_trace(**kwargs)
        self._trace_id = result.id
        return result

    async def _submit_async(self) -> TraceSubmission | Trace:
        """Submit the trace asynchronously.  Called by the async context manager."""
        if self._submitted:
            return  # type: ignore[return-value]
        self._submitted = True

        kwargs: dict[str, Any] = dict(
            task=self.task,
            trajectory=self._trajectory,
            final_response=self._final_response,
            retrieved_memory_ids=self.memory_ids,
            model=self._model,
            metadata=self._metadata,
            review_result=self._result,
            feedback_text=self._feedback_text,
        )
        if self._blocking:
            result = await self._client.create_trace_and_wait_async(**kwargs)
        else:
            result = await self._client.create_trace_async(**kwargs)
        self._trace_id = result.id
        return result
