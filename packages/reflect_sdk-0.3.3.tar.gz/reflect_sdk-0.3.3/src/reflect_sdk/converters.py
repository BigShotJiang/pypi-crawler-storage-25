"""Trajectory converters for popular agent frameworks.

These helpers normalise framework-specific message objects into the
``list[dict[str, Any]]`` trajectory format expected by
:meth:`~reflect_sdk.client.ReflectClient.create_trace`.
"""

from __future__ import annotations

import json
from typing import Any


def _content_to_text(content: Any) -> str | None:
    """Normalise various content representations to plain text."""
    if content is None:
        return None
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                text = item.get("text")
                if text:
                    parts.append(str(text))
            elif item is not None:
                parts.append(str(item))
        return "\n".join(parts).strip() if parts else ""
    return str(content)


def from_deepagents(messages: list[Any]) -> list[dict[str, Any]]:
    """Convert Deep Agents message objects to Reflect trajectory format.

    Deep Agents (LangGraph-style) messages use ``type`` fields like
    ``"human"``, ``"ai"``, ``"tool"`` and may carry tool-call payloads
    in a non-standard shape.  This function normalises them into the
    OpenAI-compatible ``role``/``content`` dicts that Reflect expects.

    Args:
        messages: List of Deep Agents message objects (Pydantic models
            or plain dicts).

    Returns:
        A trajectory list ready for ``create_trace(trajectory=...)``.

    Example::

        from deepagents import create_deep_agent
        from reflect_sdk import ReflectClient
        from reflect_sdk.converters import from_deepagents

        agent = create_deep_agent(model="openai:gpt-5.4", ...)
        result = agent.invoke({"messages": [{"role": "user", "content": task}]})

        trajectory = from_deepagents(result["messages"])
        client.create_trace(task=task, trajectory=trajectory, ...)
    """
    role_map = {"human": "user", "ai": "assistant", "tool": "tool"}
    trajectory: list[dict[str, Any]] = []

    for message in messages:
        payload = (
            message.model_dump(mode="json")
            if hasattr(message, "model_dump")
            else {"content": str(message)}
        )
        payload = json.loads(json.dumps(payload, default=str))

        message_type = str(getattr(message, "type", ""))
        role = role_map.get(message_type, str(payload.get("role", "assistant")))
        item: dict[str, Any] = {
            "role": role,
            "content": _content_to_text(payload.get("content")),
        }

        if role == "assistant" and isinstance(payload.get("tool_calls"), list):
            normalized_tool_calls: list[dict[str, Any]] = []
            for call in payload["tool_calls"]:
                if not isinstance(call, dict):
                    continue
                function_payload = call.get("function")
                function_name = (
                    function_payload.get("name")
                    if isinstance(function_payload, dict)
                    else call.get("name")
                )
                if not function_name:
                    continue
                arguments = (
                    function_payload.get("arguments", "")
                    if isinstance(function_payload, dict)
                    else call.get("args", call.get("arguments", ""))
                )
                normalized_tool_calls.append(
                    {
                        "id": call.get("id"),
                        "type": "function",
                        "function": {
                            "name": str(function_name),
                            "arguments": arguments,
                        },
                    }
                )
            if normalized_tool_calls:
                item["tool_calls"] = normalized_tool_calls

        if role == "tool":
            if payload.get("tool_call_id"):
                item["tool_call_id"] = payload["tool_call_id"]
            if payload.get("name"):
                item["name"] = payload["name"]

        trajectory.append(item)

    return trajectory


def from_openai_agents(result: Any) -> list[dict[str, Any]]:
    """Convert an OpenAI Agents SDK ``RunResult`` to Reflect trajectory.

    The OpenAI Agents SDK ``Runner.run()`` returns a ``RunResult`` whose
    ``to_input_list()`` method produces a list of input items.  These use
    the Responses API shape (``type: "function_call"``,
    ``type: "function_call_output"``, etc.) which this function maps to
    the standard ``role``/``content`` trajectory format.

    Args:
        result: A ``RunResult`` from ``Runner.run()``.  Must expose a
            ``to_input_list()`` method and ``final_output`` attribute.

    Returns:
        A trajectory list ready for ``create_trace(trajectory=...)``.

    Example::

        from agents import Agent, Runner
        from reflect_sdk import ReflectClient
        from reflect_sdk.converters import from_openai_agents

        result = await Runner.run(agent, input=task)
        trajectory = from_openai_agents(result)
        client.create_trace(task=task, trajectory=trajectory, ...)
    """
    trajectory: list[dict[str, Any]] = []

    input_list = result.to_input_list()

    for item in input_list:
        if isinstance(item, dict):
            item_type = item.get("type", "")
            role = item.get("role")

            # Standard message with role (e.g. user, system, assistant)
            if role and role in ("user", "system", "developer"):
                trajectory.append({
                    "role": role,
                    "content": _content_to_text(item.get("content")),
                })
            elif role == "assistant" or item_type == "message":
                content = item.get("content")
                text = None
                if isinstance(content, list):
                    text_parts = []
                    for part in content:
                        if isinstance(part, dict):
                            if part.get("type") == "output_text":
                                text_parts.append(part.get("text", ""))
                            elif part.get("type") == "text":
                                text_parts.append(part.get("text", ""))
                    text = "\n".join(text_parts).strip() if text_parts else None
                elif isinstance(content, str):
                    text = content
                trajectory.append({"role": "assistant", "content": text})

            # Responses API function call → assistant with tool_calls
            elif item_type == "function_call":
                trajectory.append({
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": item.get("call_id") or item.get("id"),
                            "type": "function",
                            "function": {
                                "name": item.get("name", ""),
                                "arguments": item.get("arguments", ""),
                            },
                        }
                    ],
                })

            # Responses API function call output → tool message
            elif item_type == "function_call_output":
                trajectory.append({
                    "role": "tool",
                    "tool_call_id": item.get("call_id") or item.get("id"),
                    "content": _content_to_text(item.get("output")),
                })

            # Fallback: include as-is if it has a role
            elif role:
                trajectory.append({
                    "role": role,
                    "content": _content_to_text(item.get("content")),
                })
        else:
            # Pydantic model objects — try to extract via attributes
            item_type = getattr(item, "type", "")
            role = getattr(item, "role", None)

            if role in ("user", "system", "developer"):
                trajectory.append({
                    "role": role,
                    "content": _content_to_text(getattr(item, "content", None)),
                })
            elif item_type == "function_call":
                trajectory.append({
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": getattr(item, "call_id", None) or getattr(item, "id", None),
                            "type": "function",
                            "function": {
                                "name": getattr(item, "name", ""),
                                "arguments": getattr(item, "arguments", ""),
                            },
                        }
                    ],
                })
            elif item_type == "function_call_output":
                trajectory.append({
                    "role": "tool",
                    "tool_call_id": getattr(item, "call_id", None) or getattr(item, "id", None),
                    "content": _content_to_text(getattr(item, "output", None)),
                })
            elif role == "assistant" or item_type == "message":
                content = getattr(item, "content", None)
                text = _content_to_text(content)
                trajectory.append({"role": "assistant", "content": text})

    return trajectory
