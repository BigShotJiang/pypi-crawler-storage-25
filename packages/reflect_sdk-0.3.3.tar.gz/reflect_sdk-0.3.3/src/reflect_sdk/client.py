"""Reflect API client."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Generator, Sequence
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
import time
from typing import Any, AsyncGenerator
from urllib.parse import quote

import httpx

from reflect_sdk.context import TraceContext

logger = logging.getLogger(__name__)

TrajectoryInput = Sequence[dict[str, Any]] | str


def _api_review_result(result: str) -> str:
    """Map SDK-friendly labels to the API contract (pass | fail).

    The Reflect API accepts only ``pass`` and ``fail``; callers may also use
    ``success`` / ``failure`` for convenience.
    """
    key = result.strip().lower()
    if key in ("success", "pass"):
        return "pass"
    if key in ("failure", "fail"):
        return "fail"
    return result


@dataclass(slots=True)
class Memory:
    """Retrieved memory from the Reflect API.

    Attributes:
        id: Unique memory identifier.
        task: The past task this memory reflects on.
        reflection: The learned reflection text.
        q_value: Learned Q-value from reviews (higher = more successful).
        similarity: Embedding similarity to the query.
        score: Blended ranking score (similarity + Q-value).
        success: True/false from past reviews, or None if unreviewed.
    """

    id: str
    task: str
    reflection: str
    q_value: float
    similarity: float
    score: float
    success: bool | None = None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "Memory":
        return cls(
            id=payload["id"],
            task=payload["task"],
            reflection=payload["reflection"],
            q_value=payload.get("q_value", 0.5),
            similarity=payload.get("similarity", 0.0),
            score=payload.get("score", 0.0),
            success=payload.get("success"),
        )


@dataclass(slots=True)
class AugmentedTask:
    """Task plus the memories appended to it.

    Attributes:
        augmented_task: The original task with formatted memory blocks appended.
        memories: List of Memory objects that were used.
    """

    augmented_task: str
    memories: list[Memory]


@dataclass(slots=True)
class Review:
    """Review associated with a trace.

    Attributes:
        id: Unique review identifier.
        trace_id: ID of the traced run.
        result: "success" or "failure".
        feedback_text: Optional human feedback.
        mode: "inline" or "deferred".
    """

    id: str
    trace_id: str
    result: str
    feedback_text: str | None = None
    mode: str = "deferred"

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "Review":
        return cls(
            id=payload["id"],
            trace_id=payload["trace_id"],
            result=payload["result"],
            feedback_text=payload.get("feedback_text"),
            mode=payload.get("mode", "deferred"),
        )


@dataclass(slots=True)
class ApiKeyInfo:
    """Safe API key metadata.

    Attributes:
        id: Internal key identifier.
        public_id: Public portion of the key (safe to display).
        label: Human-readable label.
        scopes: Granted scopes (e.g. ``memory:read``, ``trace:write``).
        environment: ``"live"`` or ``"test"``.
        status: ``"active"`` or ``"revoked"``.
        is_master: Whether this is a master key with access to all projects.
        created_at: ISO 8601 creation timestamp.
        last_used_at: ISO 8601 last-use timestamp.
        revoked_at: ISO 8601 revocation timestamp.
    """

    id: str
    public_id: str
    label: str
    scopes: list[str]
    environment: str
    status: str
    is_master: bool = False
    created_at: str | None = None
    last_used_at: str | None = None
    revoked_at: str | None = None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "ApiKeyInfo":
        return cls(
            id=payload["id"],
            public_id=payload["public_id"],
            label=payload["label"],
            scopes=list(payload.get("scopes", [])),
            is_master=payload.get("is_master", False),
            environment=payload.get("environment", "live"),
            status=payload.get("status", "active"),
            created_at=payload.get("created_at"),
            last_used_at=payload.get("last_used_at"),
            revoked_at=payload.get("revoked_at"),
        )


@dataclass(slots=True)
class CreatedApiKey:
    """API key creation result.

    Attributes:
        api_key: Plaintext API key (only shown once at creation time).
        key: Key metadata.
    """

    api_key: str
    key: ApiKeyInfo

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "CreatedApiKey":
        return cls(api_key=payload["api_key"], key=ApiKeyInfo.from_api(payload["key"]))


@dataclass(slots=True)
class BootstrapInfo:
    """Bootstrap result for a new project.

    Attributes:
        user_id: Created user ID.
        project_id: Created project ID.
        api_key: Plaintext admin API key.
    """

    user_id: str
    project_id: str
    api_key: str

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "BootstrapInfo":
        return cls(
            user_id=payload["user_id"],
            project_id=payload["project_id"],
            api_key=payload["api_key"],
        )


@dataclass(slots=True)
class Trace:
    """Stored trace returned by the Reflect API.

    Attributes:
        id: Unique trace identifier.
        task: The task that was executed.
        trajectory: List of message dicts (e.g. role/content).
        final_response: The model's final response.
        retrieved_memory_ids: IDs of memories used.
        review_status: "pending" or "reviewed".
        ingest_status: "queued", "processing", "completed", or "failed".
        ingest_attempts: Number of ingestion attempts so far.
        last_ingest_error: Error message if ingestion failed.
        model: Optional model name.
        metadata: Optional key-value metadata.
        created_memory_id: ID of reflection created after review, if any.
        review: Attached Review if reviewed.
    """

    id: str
    task: str
    trajectory: list[dict[str, Any]]
    final_response: str
    retrieved_memory_ids: list[str]
    review_status: str
    ingest_status: str
    ingest_attempts: int = 0
    last_ingest_error: str | None = None
    model: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    created_memory_id: str | None = None
    review: Review | None = None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "Trace":
        review = payload.get("review")
        return cls(
            id=payload["id"],
            task=payload["task"],
            trajectory=list(payload.get("trajectory", [])),
            final_response=payload.get("final_response", ""),
            retrieved_memory_ids=list(payload.get("retrieved_memory_ids", [])),
            review_status=payload["review_status"],
            ingest_status=payload.get("ingest_status", "completed"),
            ingest_attempts=payload.get("ingest_attempts", 0),
            last_ingest_error=payload.get("last_ingest_error"),
            model=payload.get("model"),
            metadata=dict(payload.get("metadata", {})),
            created_memory_id=payload.get("created_memory_id"),
            review=Review.from_api(review) if review else None,
        )


@dataclass(slots=True)
class TraceSubmission:
    """Queued trace accepted for background ingestion.

    Attributes:
        id: Unique trace identifier.
        ingest_status: ``"queued"`` when an inline review is pending background processing, or ``"completed"`` when no review was included.
    """

    id: str
    ingest_status: str

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> "TraceSubmission":
        return cls(id=payload["trace_id"], ingest_status=payload["ingest_status"])


class ReflectClient:
    """Client for the authenticated Reflect API."""

    def __init__(
        self,
        *,
        base_url: str = "https://api.starlight-search.com",
        api_key: str,
        project_id: str | None = None,
        timeout: float | httpx.Timeout = 60.0,
    ) -> None:
        """Create a Reflect client for a project.

        Args:
            base_url: Reflect API base URL (e.g. http://localhost:8000).
            api_key: Plaintext API key (e.g. rf_live_...).
            project_id: Project identifier. If the project does not exist yet it
                will be created automatically (master keys only). Defaults to
                ``"default"`` when omitted.
            timeout: Request timeout in seconds.
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.project_id = project_id or "default"
        self.timeout = timeout

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    def _project_path(self, suffix: str) -> str:
        return f"/v1/projects/{quote(self.project_id, safe='')}{suffix}"

    @classmethod
    def bootstrap(
        cls,
        *,
        base_url: str,
        bootstrap_token: str,
        user_id: str,
        project_id: str,
        key_label: str = "Default Admin Key",
        environment: str = "live",
        timeout: float | httpx.Timeout = 60.0,
    ) -> BootstrapInfo:
        with httpx.Client(base_url=base_url.rstrip("/"), timeout=timeout) as client:
            response = client.post(
                "/v1/bootstrap",
                json={
                    "user_id": user_id,
                    "project_id": project_id,
                    "key_label": key_label,
                    "environment": environment,
                },
                headers={"X-Bootstrap-Token": bootstrap_token},
            )
            response.raise_for_status()
            return BootstrapInfo.from_api(response.json())

    def _format_memory_block(self, memory: Memory, index: int) -> str:
        outcome = "success" if memory.success is True else "failure" if memory.success is False else "unknown"
        if memory.success is True:
            context = "This approach worked. Apply this strategy."
        elif memory.success is False:
            context = "This task failed. The reflection below is a post-mortem with corrective advice — follow its recommendations."
        else:
            context = "No outcome recorded."
        return (
            f'<memory id="{memory.id}" q_value="{memory.q_value:.2f}" '
            f'similarity="{memory.similarity:.2f}" outcome="{outcome}">\n'
            f"<context>{context}</context>\n"
            f"<past_task>{memory.task}</past_task>\n"
            f"<reflection>{memory.reflection}</reflection>\n"
            f"</memory>"
        )

    def _format_memory_section(
        self, title: str, memories: Sequence[Memory], start_index: int
    ) -> str:
        if not memories:
            return ""
        memory_blocks = [
            self._format_memory_block(memory, index)
            for index, memory in enumerate(memories, start=start_index)
        ]
        return "\n\n".join(memory_blocks)

    _MEMORY_INSTRUCTIONS = (
        "Review the memories below before answering. Each memory contains a "
        "reflection — a lesson learned from a past task. Memories with higher "
        "q_value (0-1 scale) have historically led to better outcomes.\n\n"
        "- outcome=\"success\": The past task succeeded. The reflection describes "
        "the strategy that worked. FOLLOW this advice.\n"
        "- outcome=\"failure\": The past task failed. The reflection is a "
        "POST-MORTEM that diagnoses what went wrong and recommends corrective "
        "steps. FOLLOW the recommendations in the reflection — they describe "
        "what TO DO to avoid the same failure, not what to avoid doing.\n"
        "- outcome=\"unknown\": No review yet. Use your judgment.\n\n"
        "If a memory's past task differs significantly from the current task, "
        "extract only the transferable principle."
    )

    def _format_memories_xml(self, memories: Sequence[Memory]) -> str:
        """Format memories as XML with metadata and usage instructions."""
        blocks = [
            self._format_memory_block(memory, index)
            for index, memory in enumerate(memories, start=1)
        ]

        body = "\n\n".join(blocks)
        return (
            f"<relevant_memories>\n"
            f"<instructions>{self._MEMORY_INSTRUCTIONS}</instructions>\n\n"
            f"{body}\n"
            f"</relevant_memories>"
        )

    def _get(self, path: str, *, params: dict[str, Any] | None = None) -> dict | list:
        with httpx.Client(base_url=self.base_url, timeout=self.timeout) as client:
            response = client.get(path, params=params, headers=self._headers)
            response.raise_for_status()
            return response.json()

    async def _get_async(
        self, path: str, *, params: dict[str, Any] | None = None
    ) -> dict | list:
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=self.timeout
        ) as client:
            response = await client.get(path, params=params, headers=self._headers)
            response.raise_for_status()
            return response.json()

    def _post(self, path: str, payload: dict[str, Any]) -> dict | list:
        with httpx.Client(base_url=self.base_url, timeout=self.timeout) as client:
            response = client.post(path, json=payload, headers=self._headers)
            response.raise_for_status()
            return response.json()

    async def _post_async(self, path: str, payload: dict[str, Any]) -> dict | list:
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=self.timeout
        ) as client:
            response = await client.post(path, json=payload, headers=self._headers)
            response.raise_for_status()
            return response.json()

    def _is_not_found(self, exc: httpx.HTTPStatusError) -> bool:
        return exc.response is not None and exc.response.status_code == 404

    def health(self) -> dict[str, str]:
        """Return the API health status. No authentication required."""
        with httpx.Client(base_url=self.base_url, timeout=self.timeout) as client:
            response = client.get("/health")
            response.raise_for_status()
            return response.json()

    async def query_memories_async(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
    ) -> list[Memory]:
        """Async version of :meth:`query_memories`."""
        response = await self._post_async(
            self._project_path("/memory/query"),
            {"task": task, "limit": limit, "lambda": lambda_},
        )
        if not response:
            return []
        return [Memory.from_api(memory) for memory in response]

    async def augment_with_memories_async(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
    ) -> AugmentedTask:
        """Async version of :meth:`augment_with_memories`."""
        memories = await self.query_memories_async(
            task=task, limit=limit, lambda_=lambda_
        )
        if not memories:
            return AugmentedTask(augmented_task=task, memories=[])

        augmented_task = task + "\n\n" + self._format_memories_xml(memories)
        return AugmentedTask(augmented_task=augmented_task, memories=memories)

    def query_memories(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
    ) -> list[Memory]:
        """Retrieve memories by semantic similarity and Q-value ranking.

        Args:
            task: Task description to search against.
            limit: Maximum number of memories to return.
            lambda_: Blend between similarity (1.0) and Q-value (0.0). Default 0.5.

        Returns:
            List of Memory objects, ranked by blended score.
        """
        response = self._post(
            self._project_path("/memory/query"),
            {"task": task, "limit": limit, "lambda": lambda_},
        )
        if not response:
            return []
        return [Memory.from_api(memory) for memory in response]

    def get_skill(self) -> str | None:
        """Return the project skill text, or None if no skill has been created yet.

        Returns:
            The skill content string, or None if no skill exists for this project.
        """
        try:
            response = self._get(self._project_path("/skill"))
        except httpx.HTTPStatusError as exc:
            if self._is_not_found(exc):
                return None
            raise
        if isinstance(response, dict):
            return response.get("content")
        return None

    async def get_skill_async(self) -> str | None:
        """Async variant of :meth:`get_skill`."""
        try:
            response = await self._get_async(self._project_path("/skill"))
        except httpx.HTTPStatusError as exc:
            if self._is_not_found(exc):
                return None
            raise
        if isinstance(response, dict):
            return response.get("content")
        return None

    def augment_with_memories(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
    ) -> AugmentedTask:
        """Query memories and format them into the task text for prompt augmentation.

        Args:
            task: Task to augment.
            limit: Maximum memories to retrieve.
            lambda_: Blend between similarity and Q-value.

        Returns:
            AugmentedTask with augmented_task (task + memory blocks) and memories.
        """
        memories = self.query_memories(task=task, limit=limit, lambda_=lambda_)
        if not memories:
            return AugmentedTask(augmented_task=task, memories=[])

        augmented_task = task + "\n\n" + self._format_memories_xml(memories)
        return AugmentedTask(augmented_task=augmented_task, memories=memories)

    # ------------------------------------------------------------------
    # Context managers
    # ------------------------------------------------------------------

    @contextmanager
    def trace(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
        blocking: bool = False,
        auto_fail_on_exception: bool = True,
    ) -> Generator[TraceContext, None, None]:
        """Context manager that retrieves memories and auto-submits the trace.

        On entry, memories are queried and made available via
        ``ctx.augmented_task`` and ``ctx.memories``.  Call
        ``ctx.set_output(...)`` inside the block to record your agent's
        result.  On exit, the trace is submitted with the correct
        ``retrieved_memory_ids`` automatically.

        Args:
            task: Task description for memory retrieval and trace logging.
            limit: Maximum memories to retrieve.
            lambda_: Blend between similarity and Q-value.
            blocking: If ``True``, wait for memory creation before
                returning from the context (uses ``create_trace_and_wait``).
            auto_fail_on_exception: If ``True`` and an unhandled exception
                occurs after ``set_output`` was called, the trace is
                submitted with ``result="fail"`` and the exception message
                as ``feedback_text``.

        Yields:
            A :class:`TraceContext` with ``augmented_task`` ready for prompting.

        Example::

            with client.trace("Answer billing question") as ctx:
                response = my_llm(ctx.augmented_task)
                ctx.set_output(
                    trajectory=messages,
                    final_response=response,
                    result="pass",
                )
            # Trace auto-submitted with correct retrieved_memory_ids
        """
        augmented = self.augment_with_memories(task, limit=limit, lambda_=lambda_)
        ctx = TraceContext(
            task=task,
            augmented_task=augmented.augmented_task,
            memories=augmented.memories,
            _client=self,
            _blocking=blocking,
            _auto_fail_on_exception=auto_fail_on_exception,
        )
        try:
            yield ctx
        except BaseException as exc:
            if auto_fail_on_exception and ctx._trajectory is not None:
                ctx._result = "fail"
                ctx._feedback_text = ctx._feedback_text or str(exc)
                try:
                    ctx._submit()
                except Exception:
                    logger.warning("Failed to submit trace on exception", exc_info=True)
            raise
        else:
            if ctx._trajectory is not None:
                ctx._submit()

    @asynccontextmanager
    async def trace_async(
        self,
        task: str,
        *,
        limit: int = 10,
        lambda_: float = 0.5,
        blocking: bool = False,
        auto_fail_on_exception: bool = True,
    ) -> AsyncGenerator[TraceContext, None]:
        """Async version of :meth:`trace`.

        Example::

            async with client.trace_async("Debug login timeout") as ctx:
                response = await my_llm(ctx.augmented_task)
                ctx.set_output(trajectory=messages, final_response=response, result="pass")
        """
        augmented = await self.augment_with_memories_async(
            task, limit=limit, lambda_=lambda_
        )
        ctx = TraceContext(
            task=task,
            augmented_task=augmented.augmented_task,
            memories=augmented.memories,
            _client=self,
            _blocking=blocking,
            _auto_fail_on_exception=auto_fail_on_exception,
        )
        try:
            yield ctx
        except BaseException as exc:
            if auto_fail_on_exception and ctx._trajectory is not None:
                ctx._result = "fail"
                ctx._feedback_text = ctx._feedback_text or str(exc)
                try:
                    await ctx._submit_async()
                except Exception:
                    logger.warning("Failed to submit trace on exception", exc_info=True)
            raise
        else:
            if ctx._trajectory is not None:
                await ctx._submit_async()

    # ------------------------------------------------------------------
    # Trace creation
    # ------------------------------------------------------------------

    def create_trace(
        self,
        *,
        task: str,
        trajectory: TrajectoryInput,
        final_response: str | None = None,
        retrieved_memory_ids: Sequence[str] = (),
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
        review_result: str | None = None,
        feedback_text: str | None = None,
    ) -> TraceSubmission:
        """Record your agent's run without blocking your application.

        Call this after your agent finishes a task to send the full
        conversation to Reflect for storage. The call returns immediately
        with a :class:`TraceSubmission` — the trace is ingested in the
        background, so your agent can move on to the next request without
        waiting.

        If you already know whether the response was correct (e.g. you
        compared it to an expected answer), pass ``review_result`` to
        include an **inline review**. Reflect will then generate a
        reflection and store it as a new memory in the background, so
        future runs of your agent can learn from this outcome.

        If you don't know the result yet, omit ``review_result`` and
        review later via :meth:`review_trace` or the web dashboard.

        .. tip::

           If your workflow needs the memory to exist before continuing
           (e.g. a test that checks the created memory, or a pipeline
           where the next step depends on updated memories), use
           :meth:`create_trace_and_wait` instead — it blocks until
           ingestion and review processing are complete.

        Args:
            task: What your agent was asked to do — e.g. the user's
                question or the job description. Reflect uses this to
                match memories on future runs, so be descriptive.
            trajectory: The conversation between the user and your
                agent. Pass a list of ``{"role": ..., "content": ...}``
                message dicts (the same format most LLM APIs return),
                or a JSON string that deserializes to such a list.
            final_response: Your agent's final answer. When ``None``,
                Reflect extracts it from the last ``"assistant"``
                message in the trajectory automatically.
            retrieved_memory_ids: IDs of the memories your agent used
                during this run (from :meth:`query_memories` or
                :meth:`augment_with_memories`). Passing these lets
                Reflect update their Q-values when a review comes in,
                reinforcing helpful memories and down-ranking unhelpful
                ones.
            model: The model your agent used (e.g. ``"gpt-5.4-mini"``).
                Shown in the dashboard for filtering and analysis.
            metadata: Any extra context you want to attach — e.g.
                ``{"customer_id": "c42", "environment": "staging"}``.
                Visible in the dashboard and useful for filtering.
            review_result: Judge whether the response was correct:
                ``"pass"`` or ``"success"`` if it was, ``"fail"`` or
                ``"failure"`` if not. When provided, Reflect generates
                a reflection from the conversation and stores it as a
                memory so your agent improves over time.
            feedback_text: When the response failed, explain **what
                went wrong** — e.g. ``"Missed the WHERE clause"`` or
                ``"Gave an answer about the wrong product"``. This
                feedback is included in the generated reflection so
                your agent learns the specific mistake. Ignored when
                ``review_result`` is ``None``.

        Returns:
            A :class:`TraceSubmission` with the trace ``id`` and its
            ``ingest_status`` (typically ``"queued"``).

        Example — log your agent's run for later review::

            # After your agent responds to a user...
            submission = client.create_trace(
                task="Summarize this article about climate change",
                trajectory=[
                    {"role": "user", "content": "Summarize this article: ..."},
                    {"role": "assistant", "content": "Here is a summary: ..."},
                ],
                model="gpt-5.4-mini",
                metadata={"user_id": "u123"},
            )
            # Returns immediately — your app continues serving requests.
            # Review this trace later in the dashboard or via review_trace().

        Example — log and review in one call (auto-graded)::

            # Compare the agent's answer to the expected answer...
            is_correct = agent_answer.strip() == expected_answer.strip()

            submission = client.create_trace(
                task=problem_description,
                trajectory=messages,
                retrieved_memory_ids=[m.id for m in memories],
                model="gpt-5.4-mini",
                review_result="pass" if is_correct else "fail",
                feedback_text=None if is_correct else f"Expected {expected_answer}",
            )
            # Reflect generates a reflection in the background.
            # Next time your agent sees a similar task, it can retrieve
            # this memory to avoid repeating the same mistake.
        """
        payload: dict[str, Any] = {
            "task": task,
            "trajectory": (
                trajectory if isinstance(trajectory, str) else list(trajectory)
            ),
            "retrieved_memory_ids": list(retrieved_memory_ids),
            "model": model,
            "metadata": metadata or {},
        }
        if final_response is not None:
            payload["final_response"] = final_response
        if review_result is not None:
            payload["review"] = {
                "result": _api_review_result(review_result),
                "feedback_text": feedback_text,
            }
        response = self._post(self._project_path("/traces"), payload)
        return TraceSubmission.from_api(response)

    async def create_trace_async(
        self,
        *,
        task: str,
        trajectory: TrajectoryInput,
        final_response: str | None = None,
        retrieved_memory_ids: Sequence[str] = (),
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
        review_result: str | None = None,
        feedback_text: str | None = None,
    ) -> TraceSubmission:
        payload: dict[str, Any] = {
            "task": task,
            "trajectory": (
                trajectory if isinstance(trajectory, str) else list(trajectory)
            ),
            "retrieved_memory_ids": list(retrieved_memory_ids),
            "model": model,
            "metadata": metadata or {},
        }
        if final_response is not None:
            payload["final_response"] = final_response
        if review_result is not None:
            payload["review"] = {
                "result": _api_review_result(review_result),
                "feedback_text": feedback_text,
            }
        response = await self._post_async(self._project_path("/traces"), payload)
        return TraceSubmission.from_api(response)

    def wait_for_trace(
        self,
        trace_id: str,
        *,
        require_reviewed: bool = False,
        poll_interval: float = 0.25,
        wait_timeout: float = 60.0,
    ) -> Trace:
        deadline = time.monotonic() + wait_timeout
        while True:
            try:
                trace = self.get_trace(trace_id)
            except httpx.HTTPStatusError as exc:
                if not self._is_not_found(exc):
                    raise
            else:
                if trace.ingest_status == "failed":
                    raise RuntimeError(
                        trace.last_ingest_error
                        or f"Trace {trace_id} failed during ingestion"
                    )
                if not require_reviewed or trace.review_status == "reviewed":
                    return trace
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Timed out waiting for trace {trace_id} to be available"
                )
            time.sleep(poll_interval)

    async def wait_for_trace_async(
        self,
        trace_id: str,
        *,
        require_reviewed: bool = False,
        poll_interval: float = 0.25,
        wait_timeout: float = 60.0,
    ) -> Trace:
        deadline = time.monotonic() + wait_timeout
        while True:
            try:
                trace = await self.get_trace_async(trace_id)
            except httpx.HTTPStatusError as exc:
                if not self._is_not_found(exc):
                    raise
            else:
                if trace.ingest_status == "failed":
                    raise RuntimeError(
                        trace.last_ingest_error
                        or f"Trace {trace_id} failed during ingestion"
                    )
                if not require_reviewed or trace.review_status == "reviewed":
                    return trace
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Timed out waiting for trace {trace_id} to be available"
                )
            await asyncio.sleep(poll_interval)

    def create_trace_and_wait(
        self,
        *,
        task: str,
        trajectory: TrajectoryInput,
        final_response: str | None = None,
        retrieved_memory_ids: Sequence[str] = (),
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
        review_result: str | None = None,
        feedback_text: str | None = None,
        poll_interval: float = 0.25,
        wait_timeout: float = 60.0,
    ) -> Trace:
        """Record your agent's run and wait until the memory is created.

        Use this when your next step depends on the trace (and its
        memory) being fully processed — for example:

        - **Evaluation loops** where you run multiple tasks in sequence
          and need each memory to exist before the next task starts, so
          your agent can learn from earlier mistakes within the same run.
        - **Tests** where you want to assert on the created memory or
          the final review status.
        - **Scripts and pipelines** where you need confirmation that the
          reflection was stored before moving on.

        This method submits the trace, then polls until it's done:

        - **Without** ``review_result``: waits until the trace is stored.
        - **With** ``review_result``: waits until the review is processed,
          the reflection is generated, and the memory is saved. The
          returned :class:`Trace` will have ``review_status == "reviewed"``
          and a populated ``created_memory_id``.

        If your application serves real-time traffic and you don't want
        to block, use :meth:`create_trace` instead — it returns
        immediately while processing happens in the background.

        Args:
            task: What your agent was asked to do. Reflect uses this
                to match memories on future runs, so be descriptive.
            trajectory: The conversation between the user and your
                agent — a list of ``{"role": ..., "content": ...}``
                message dicts, or a JSON string.
            final_response: Your agent's final answer. When ``None``,
                Reflect extracts it from the last assistant message provided in the trajectory.
            retrieved_memory_ids: IDs of the memories your agent used
                (from :meth:`query_memories` or
                :meth:`augment_with_memories`). Passing these lets
                Reflect update their Q-values based on the review.
            model: The model your agent used (e.g. ``"gpt-5.4-mini"``).
                Shown in the dashboard for filtering.
            metadata: Extra context to attach — e.g.
                ``{"source": "eval_pipeline", "run_id": "r42"}``.
            review_result: Judge whether the response was correct:
                ``"pass"`` / ``"success"`` or ``"fail"`` / ``"failure"``.
                When provided, this method waits for the reflection to
                be generated and stored as a memory before returning.
            feedback_text: When the response failed, explain what went
                wrong so the reflection captures the specific mistake.
                Ignored when ``review_result`` is ``None``.
            poll_interval: How often (in seconds) to check whether
                processing is done. Default ``0.25``.
            wait_timeout: Maximum seconds to wait. Raise
                ``TimeoutError`` if the trace is still processing.
                Default ``60.0``. Increase this if your reflections
                use a slow model.

        Returns:
            The fully processed :class:`Trace` with the attached
            :class:`Review` and ``created_memory_id`` (when reviewed).

        Raises:
            RuntimeError: If processing fails — e.g. the LLM errored
                while generating the reflection. Check
                ``trace.last_ingest_error`` for details.
            TimeoutError: If processing doesn't finish within
                ``wait_timeout`` seconds.

        Example — evaluation loop that learns across tasks::

            for problem in problems:
                # Retrieve memories from previous tasks in this run
                augmented = client.augment_with_memories(problem.question)
                answer = my_agent.solve(augmented.augmented_task)
                is_correct = answer.strip() == problem.expected.strip()

                trace = client.create_trace_and_wait(
                    task=problem.question,
                    trajectory=augmented_messages,
                    final_response=answer,
                    retrieved_memory_ids=[m.id for m in augmented.memories],
                    model="gpt-5.4-mini",
                    review_result="pass" if is_correct else "fail",
                    feedback_text=None if is_correct else f"Expected {problem.expected}",
                )
                # Memory is now stored — the next iteration can retrieve it.

        Example — interactive CLI with human review::

            answer = my_agent.solve(task)
            result = input("Was this correct? [y/n]: ")

            trace = client.create_trace_and_wait(
                task=task,
                trajectory=messages,
                final_response=answer,
                retrieved_memory_ids=[m.id for m in memories],
                review_result="pass" if result == "y" else "fail",
                feedback_text=input("Feedback: ") if result != "y" else None,
            )
            print(f"Memory created: {trace.created_memory_id}")

        When to use which method:

        - :meth:`create_trace` — your app serves users in real time and
          you don't want to block. Memories are created in the background.
        - :meth:`create_trace_and_wait` — you're running an eval, test,
          or script and need the memory to exist before the next step.
        """
        submission = self.create_trace(
            task=task,
            trajectory=trajectory,
            final_response=final_response,
            retrieved_memory_ids=retrieved_memory_ids,
            model=model,
            metadata=metadata,
            review_result=review_result,
            feedback_text=feedback_text,
        )
        return self.wait_for_trace(
            submission.id,
            require_reviewed=review_result is not None,
            poll_interval=poll_interval,
            wait_timeout=wait_timeout,
        )

    async def create_trace_and_wait_async(
        self,
        *,
        task: str,
        trajectory: TrajectoryInput,
        final_response: str | None = None,
        retrieved_memory_ids: Sequence[str] = (),
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
        review_result: str | None = None,
        feedback_text: str | None = None,
        poll_interval: float = 0.25,
        wait_timeout: float = 60.0,
    ) -> Trace:
        submission = await self.create_trace_async(
            task=task,
            trajectory=trajectory,
            final_response=final_response,
            retrieved_memory_ids=retrieved_memory_ids,
            model=model,
            metadata=metadata,
            review_result=review_result,
            feedback_text=feedback_text,
        )
        return await self.wait_for_trace_async(
            submission.id,
            require_reviewed=review_result is not None,
            poll_interval=poll_interval,
            wait_timeout=wait_timeout,
        )

    def list_traces(self, *, review_status: str | None = None) -> list[Trace]:
        """List traces for the project.

        Args:
            review_status: Filter by "pending", "reviewed", or None for all.

        Returns:
            List of Trace objects.
        """
        params = {"review_status": review_status} if review_status is not None else None
        response = self._get(self._project_path("/traces"), params=params)
        return [Trace.from_api(trace) for trace in response]

    def get_trace(self, trace_id: str) -> Trace:
        """Fetch a single trace by ID."""
        response = self._get(self._project_path(f"/traces/{trace_id}"))
        return Trace.from_api(response)

    async def get_trace_async(self, trace_id: str) -> Trace:
        response = await self._get_async(self._project_path(f"/traces/{trace_id}"))
        return Trace.from_api(response)

    def review_trace(
        self,
        trace_id: str,
        *,
        result: str,
        feedback_text: str | None = None,
    ) -> Trace:
        """Submit a deferred review for a trace.

        Args:
            trace_id: ID of the trace to review.
            result: ``"pass"`` / ``"fail"``, or ``"success"`` / ``"failure"`` (aliases).
            feedback_text: Optional human feedback.

        Returns:
            The updated Trace with the review attached.
        """
        response = self._post(
            self._project_path(f"/traces/{trace_id}/review"),
            {"result": _api_review_result(result), "feedback_text": feedback_text},
        )
        return Trace.from_api(response)

    def list_api_keys(self) -> list[ApiKeyInfo]:
        response = self._get(self._project_path("/api-keys"))
        return [ApiKeyInfo.from_api(item) for item in response]

    def create_api_key(
        self,
        *,
        label: str,
        scopes: Sequence[str],
        environment: str = "live",
    ) -> CreatedApiKey:
        response = self._post(
            self._project_path("/api-keys"),
            {
                "label": label,
                "scopes": list(scopes),
                "environment": environment,
            },
        )
        return CreatedApiKey.from_api(response)

    def revoke_api_key(self, key_id: str) -> ApiKeyInfo:
        response = self._post(self._project_path(f"/api-keys/{key_id}/revoke"), {})
        return ApiKeyInfo.from_api(response)
