"""End-to-end example: solve math tasks with memory augmentation and inline review.

Prerequisites:
- Reflect API running locally or reachable via --base-url
- REFLECT_API_KEY set in the environment or passed by argument
- REFLECT_PROJECT_ID set in the environment or passed by argument
- For ollama: Ollama running locally with model pulled
- For openai: OPENAI_API_KEY set in the environment
"""

import argparse
import json
import os
from dataclasses import dataclass
from typing import Any

from reflect_sdk import ReflectClient


@dataclass(frozen=True, slots=True)
class MathTask:
    problem: str
    expected_answer: str


TASKS: list[MathTask] = [
    MathTask(problem="If x + 1/x = 3, find x^5 + 1/x^5.", expected_answer="123"),
    MathTask(problem="What is the remainder when 7^100 is divided by 13?", expected_answer="9"),
    MathTask(problem="A triangle has side lengths 13, 14, and 15. What is its area?", expected_answer="84"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a small memory-augmented math evaluation against the Reflect API.",
    )
    parser.add_argument("--base-url", default="http://localhost:8000", help="Reflect API base URL.")
    parser.add_argument("--project-id", default=os.getenv("REFLECT_PROJECT_ID"), help="Reflect project id.")
    parser.add_argument("--reflect-api-key", default=os.getenv("REFLECT_API_KEY"), help="Reflect API key.")
    parser.add_argument("--provider", choices=["ollama", "openai"], default="ollama", help="LLM provider.")
    parser.add_argument("--llm-base-url", default=None, help="Override LLM base URL.")
    parser.add_argument("--model", default="qwen3:1.7b", help="Model name.")
    parser.add_argument("--limit", type=int, default=3, help="Maximum number of memories to retrieve.")
    parser.add_argument("--lambda", dest="lambda_", type=float, default=0.5, help="Weight for q-value in ranking.")
    parser.add_argument("--count", type=int, default=len(TASKS), help="Number of tasks to run.")
    parser.add_argument("--api-timeout", type=float, default=180.0, help="Reflect API timeout.")
    parser.add_argument("--llm-timeout", type=float, default=120.0, help="Solver timeout.")
    args = parser.parse_args()
    if not args.project_id:
        raise RuntimeError("REFLECT_PROJECT_ID or --project-id must be provided.")
    if not args.reflect_api_key:
        raise RuntimeError("REFLECT_API_KEY or --reflect-api-key must be provided.")
    return args


def build_solver_messages(augmented_task: str, expected_answer: str) -> list[dict[str, str]]:
    answer_format = "a reduced fraction like 11/6" if "/" in expected_answer else "an integer"
    return [
        {
            "role": "system",
            "content": (
                "You are solving competition-style math problems. "
                "Use any relevant memories included in the prompt. "
                "Return valid JSON with keys reasoning and final_answer. "
                f"final_answer must contain only {answer_format}, with no extra words."
            ),
        },
        {"role": "user", "content": augmented_task},
    ]


def solve_with_ollama(
    *,
    host: str,
    model: str,
    messages: list[dict[str, str]],
    timeout: float,
) -> tuple[str, dict[str, Any]]:
    from ollama import Client

    client = Client(host=host, timeout=timeout)
    response = client.chat(model=model, messages=messages, format="json", think=False)
    content = response.message.content or ""
    parsed = json.loads(content)
    return str(parsed.get("final_answer", "")).strip(), parsed


def solve_with_openai(
    *,
    base_url: str,
    model: str,
    messages: list[dict[str, str]],
    timeout: float,
    api_key: str,
) -> tuple[str, dict[str, Any]]:
    from openai import OpenAI

    client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content or ""
    parsed = json.loads(content)
    return str(parsed.get("final_answer", "")).strip(), parsed


def normalize_answer(answer: str) -> str:
    normalized = answer.strip().replace(" ", "")
    if normalized.endswith("."):
        normalized = normalized[:-1]
    return normalized


def main() -> None:
    args = parse_args()
    client = ReflectClient(
        base_url=args.base_url,
        api_key=args.reflect_api_key,
        project_id=args.project_id,
        timeout=args.api_timeout,
    )

    openai_api_key = os.getenv("OPENAI_API_KEY")
    tasks = TASKS[: args.count]
    correct = 0

    for task in tasks:
        augmented = client.augment_with_memories(task.problem, limit=args.limit, lambda_=args.lambda_)
        messages = build_solver_messages(augmented.augmented_task, task.expected_answer)

        if args.provider == "openai":
            if not openai_api_key:
                raise RuntimeError("OPENAI_API_KEY must be set for the openai provider.")
            llm_base_url = args.llm_base_url or "https://api.openai.com/v1"
            final_answer, raw_result = solve_with_openai(
                base_url=llm_base_url,
                model=args.model,
                messages=messages,
                timeout=args.llm_timeout,
                api_key=openai_api_key,
            )
        else:
            host = args.llm_base_url or "http://localhost:11434"
            final_answer, raw_result = solve_with_ollama(
                host=host,
                model=args.model,
                messages=messages,
                timeout=args.llm_timeout,
            )

        expected = normalize_answer(task.expected_answer)
        actual = normalize_answer(final_answer)
        success = actual == expected
        if success:
            correct += 1

        feedback_text = None if success else f"Expected {task.expected_answer}, received {final_answer}."
        trace = client.create_trace_and_wait(
            task=task.problem,
            trajectory=messages,
            final_response=json.dumps(raw_result),
            retrieved_memory_ids=[memory.id for memory in augmented.memories],
            model=args.model,
            metadata={"provider": args.provider, "expected_answer": task.expected_answer},
            review_result="pass" if success else "fail",
            feedback_text=feedback_text,
        )

        print(task.problem)
        print(f"Expected: {task.expected_answer}")
        print(f"Actual:   {final_answer}")
        print(f"Success:  {success}")
        print(f"Trace:    {trace.id}")
        print()

    print(f"Completed {len(tasks)} tasks. Correct: {correct}/{len(tasks)}")


if __name__ == "__main__":
    main()
