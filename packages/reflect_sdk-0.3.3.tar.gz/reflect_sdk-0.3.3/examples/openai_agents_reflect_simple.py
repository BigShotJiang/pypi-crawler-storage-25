"""Simple OpenAI Agents SDK + Reflect SDK example (no CLI).

Prerequisites:
- Reflect API running (default: http://localhost:8000)
- REFLECT_PROJECT_ID and REFLECT_API_KEY set
- OPENAI_API_KEY set
"""

from __future__ import annotations

import asyncio
import os

from agents import Agent, Runner, WebSearchTool
from reflect_sdk import ReflectClient, TraceContext, TraceResult, reflect_trace
from reflect_sdk.converters import from_openai_agents

# Keep configuration simple and explicit.
REFLECT_API_URL = os.getenv("REFLECT_API_URL", "http://localhost:8000")
REFLECT_API_KEY = os.getenv("REFLECT_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.4-mini")

TASK = "What are the stock prices for Apple and Nvidia?"


async def main() -> None:
    if not REFLECT_API_KEY:
        raise RuntimeError("Set REFLECT_API_KEY.")
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("Set OPENAI_API_KEY.")

    reflect = ReflectClient(
        base_url=REFLECT_API_URL,
        api_key=REFLECT_API_KEY,
        project_id="example",
        timeout=120.0,
    )


    @reflect_trace(reflect, task=lambda question: question)
    async def answer(ctx: TraceContext, question: str) -> TraceResult:
        agent = Agent(
            name="Coding assistant",
            model=MODEL,
            tools = [WebSearchTool()],
            instructions=(
                "You are a concise Python assistant. Use relevant memories from the prompt if present. "
                "Return only a short explanation and the code."
            ),
        )

        result = await Runner.run(agent, input=ctx.augmented_task)
        print(ctx.memories)
        final_response = str(result.final_output).strip()
        trajectory = from_openai_agents(result)
        return TraceResult(
            output=final_response, # the answer function returns this output to the caller
            trajectory=trajectory,
            model=MODEL,
            metadata={"source": "openai_agents_reflect_simple"},
        )
 
    answer_result = await answer(question=TASK) # this returns the output from the TraceResult
    print(answer_result)


if __name__ == "__main__":
    asyncio.run(main())
