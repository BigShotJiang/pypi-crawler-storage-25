"""Using the @reflect_trace decorator to instrument agent functions.

This example shows three patterns:
1. Simple string return — minimal boilerplate, auto-submitted as trace
2. TraceResult return — full control over trajectory, review, metadata
3. Context manager — for cases where a decorator doesn't fit

Prerequisites:
- Reflect API running (default: http://localhost:8000)
- REFLECT_PROJECT_ID and REFLECT_API_KEY set
- OPENAI_API_KEY set
"""

from __future__ import annotations

import os

from openai import OpenAI

from reflect_sdk import ReflectClient, TraceContext, TraceResult, reflect_trace

REFLECT_API_URL = os.getenv("REFLECT_API_URL", "http://localhost:8000")
REFLECT_PROJECT_ID = os.getenv("REFLECT_PROJECT_ID") if os.getenv("REFLECT_PROJECT_ID") else "new"
REFLECT_API_KEY = os.getenv("REFLECT_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.4-mini")

openai = OpenAI()

reflect = ReflectClient(
    base_url=REFLECT_API_URL,
    api_key=REFLECT_API_KEY or "",
    project_id=REFLECT_PROJECT_ID,
    timeout=120.0,
)


# ---------------------------------------------------------------------------
# Pattern 1: Simple string return
#
# The decorator queries memories, injects a TraceContext as the first arg,
# and submits a minimal trace using the returned string as both the
# trajectory and final_response.  Good for quick prototyping.
# ---------------------------------------------------------------------------


@reflect_trace(reflect, task=lambda question: question)
def quick_answer(ctx: TraceContext, question: str) -> str:
    """Answer a question using memories from past runs."""
    print(f"[quick_answer] Original question: {question}")
    print(f"[quick_answer] Augmented with {len(ctx.memories)} memories")
    response = openai.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": ctx.augmented_task}],
    )
    return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# Pattern 2: TraceResult return — full control
#
# Return a TraceResult to provide the complete trajectory, review result,
# model name, and metadata.  The decorator extracts .output as the return
# value and submits a rich trace with everything else.
# ---------------------------------------------------------------------------


@reflect_trace(reflect, task=lambda question, **_: question)
def graded_answer(ctx: TraceContext, question: str, expected: str) -> TraceResult:
    """Answer a question, auto-grade against an expected answer."""
    messages = [
        {"role": "system", "content": "Answer concisely. Use memories if provided."},
        {"role": "user", "content": ctx.augmented_task},
    ]
    response = openai.chat.completions.create(model=MODEL, messages=messages)
    answer = response.choices[0].message.content or ""
    messages.append({"role": "assistant", "content": answer})

    is_correct = expected.lower() in answer.lower()

    return TraceResult(
        output=answer,
        trajectory=messages,
        result="pass" if is_correct else "fail",
        feedback_text=None if is_correct else f"Expected '{expected}' in answer",
        model=MODEL,
        metadata={"expected": expected, "source": "decorator_example"},
    )


# ---------------------------------------------------------------------------
# Pattern 3: Context manager — when a decorator doesn't fit
#
# Use client.trace() directly for multi-step workflows, streaming, or
# cases where you need to decide the review result after inspecting
# the output.
# ---------------------------------------------------------------------------


def context_manager_example(question: str) -> str:
    """Demonstrate the context manager approach."""
    with reflect.trace(question) as ctx:
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": ctx.augmented_task},
        ]
        response = openai.chat.completions.create(model=MODEL, messages=messages)
        answer = response.choices[0].message.content or ""
        messages.append({"role": "assistant", "content": answer})

        # Decide review result after seeing the output
        looks_good = len(answer) > 10
        ctx.set_output(
            trajectory=messages,
            final_response=answer,
            result="pass" if looks_good else "fail",
            model=MODEL,
        )
    return answer


# ---------------------------------------------------------------------------
# Pattern 4: Deferred review — submit trace now, review later
#
# Both the context manager and decorator expose ctx.trace_id after
# the trace is submitted.  Use client.review_trace() to review
# the trace at any point later in your application.
# ---------------------------------------------------------------------------


def deferred_review_context_manager(question: str) -> tuple[str, str]:
    """Submit a trace without a review, return the trace_id for later."""
    with reflect.trace(question) as ctx:
        messages = [
            {"role": "user", "content": ctx.augmented_task},
        ]
        response = openai.chat.completions.create(model=MODEL, messages=messages)
        answer = response.choices[0].message.content or ""
        messages.append({"role": "assistant", "content": answer})

        # No result= passed — review is deferred
        ctx.set_output(trajectory=messages, final_response=answer, model=MODEL)

    # After the with block, ctx.trace_id is available
    return answer, ctx.trace_id


# ---------------------------------------------------------------------------
# Run all patterns
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if not REFLECT_PROJECT_ID or not REFLECT_API_KEY:
        raise RuntimeError("Set REFLECT_PROJECT_ID and REFLECT_API_KEY")
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("Set OPENAI_API_KEY")

    print("--- Pattern 1: Simple string return ---")
    result1 = quick_answer("What is the capital of France?")
    print(f"Answer: {result1}\n")

    print("--- Pattern 2: TraceResult with auto-grading ---")
    result2 = graded_answer("What is 2 + 2?", expected="4")
    print(f"Answer: {result2}\n")

    print("--- Pattern 3: Context manager ---")
    result3 = context_manager_example("Explain recursion in one sentence.")
    print(f"Answer: {result3}\n")

    print("--- Pattern 4: Deferred review ---")
    answer, trace_id = deferred_review_context_manager(
        "What is the speed of light?"
    )
    print(f"Answer: {answer}")
    print(f"Trace ID: {trace_id}")
    # Review later — e.g. after human evaluation or downstream validation
    reviewed = reflect.review_trace(
        trace_id=trace_id,
        result="pass",
        feedback_text="Answer was accurate and concise",
    )
    print(f"Review submitted: {reviewed.review_status}\n")

    print("All traces submitted to Reflect.")
