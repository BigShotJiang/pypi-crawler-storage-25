"""GAIA benchmark learning loop using Deep Agents + Exa Search + Reflect memory.

Runs 10 GAIA Level-1 questions (no file attachments) through a DeepAgents agent
equipped with internet search. Every trace is stored in Reflect with an inline
review. On subsequent runs, Reflect injects memories from past mistakes so the
agent scores progressively higher.

Run twice to see the loop:

  Run 1 — no memories, agent solves from scratch, mistakes get stored.
  Run 2+ — past reflections are injected, agent avoids known pitfalls.

Prerequisites:
  pip install deepagents exa-py reflect-sdk
  export EXA_API_KEY=...
  export OPENAI_API_KEY=...          # or another provider key (agent)
  export REFLECT_API_KEY=...
  export REFLECT_PROJECT_ID=...
  AWS credentials + region for Bedrock (judge model openai.gpt-oss-120b-1:0)

Usage:
  uv run --package reflect-sdk python packages/sdk/examples/gaia_learning_loop.py
  uv run --package reflect-sdk python packages/sdk/examples/gaia_learning_loop.py
"""

from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass
from typing import Any

from deepagents import create_deep_agent
from exa_py import Exa
from langchain_aws import ChatBedrockConverse
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_exa import ExaSearchResults
from reflect_sdk import ReflectClient
from reflect_sdk.converters import from_deepagents

# Bedrock inference profile / model id for LLM-as-judge (Reflect trace feedback).
DEFAULT_JUDGE_MODEL_ID = "openai.gpt-oss-120b-1:0"


# ---------------------------------------------------------------------------
# 10 GAIA Level-1 questions (no file attachments required)
# Source: GAIA benchmark  https://huggingface.co/datasets/gaia-benchmark/GAIA
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class GAIATask:
    question: str
    expected: str   # exact expected answer (as graded by GAIA)


TASKS: list[GAIATask] = [
    GAIATask(
        question=(
            "If Eliud Kipchoge could maintain his record-making marathon pace indefinitely, "
            "how many thousand hours would it take him to run the distance between the Earth "
            "and the Moon at its closest approach? Please use the minimum perigee value on "
            "the Wikipedia page for the Moon when carrying out your calculation. Round your "
            "result to the nearest 1000 hours and do not use any comma separators if necessary."
        ),
        expected="17",
    ),
    GAIATask(
        question=(
            "How many studio albums were published by Mercedes Sosa between 2000 and 2009 "
            "(included)? You can use the latest 2022 version of English Wikipedia."
        ),
        expected="3",
    ),
    GAIATask(
        question=(
            "Here's a fun riddle that I think you'll enjoy.\n\n"
            "You have been selected to play the final round of the hit new game show "
            "'Pick That Ping-Pong'. In this round, you will be competing for a large cash "
            "prize. Your job will be to pick one of several different numbered ping-pong balls, "
            "and then the game will commence. The host describes how the game works.\n\n"
            "A device consisting of a winding clear ramp and a series of controls the outcome "
            "of the game. The ramp feeds balls onto a platform. The platform has room for three "
            "ping-pong balls at a time. The three balls on the platform are each aligned with "
            "one of three pistons. At each stage of the game, one of the three pistons will "
            "randomly fire, ejecting the ball it strikes. If the piston ejects the ball in the "
            "first position on the platform the balls in the second and third position on the "
            "platform each advance one space, and the next ball on the ramp advances to the "
            "third position. If the piston ejects the ball in the second position, the ball in "
            "the first position is released and rolls away, the ball in the third position "
            "advances two spaces to occupy the first position, and the next two balls on the "
            "ramp advance to occupy the second and third positions on the platform. If the "
            "piston ejects the ball in the third position, the ball in the first position is "
            "released and rolls away, the ball in the second position advances one space to "
            "occupy the first position, and the next two balls on the ramp advance to occupy "
            "the second and third positions on the platform.\n\n"
            "The ramp begins with 100 numbered ping-pong balls, arranged in ascending order "
            "from 1 to 100. The host activates the machine and the first three balls, numbered "
            "1, 2, and 3, advance to the platform. Before the random firing of the pistons "
            "begins, you are asked which of the 100 balls you would like to pick. If your pick "
            "is ejected by one of the pistons, you win the grand prize, $10,000.\n\n"
            "Which ball should you choose to maximize your odds of winning the big prize? "
            "Please provide your answer as the number of the ball selected."
        ),
        expected="3",
    ),
    GAIATask(
        question=(
            "What was the volume in m^3 of the fish bag that was calculated in the University "
            "of Leicester paper 'Can Hiccup Supply Enough Fish to Maintain a Dragon's Diet?'"
        ),
        expected="0.1777",
    ),
    GAIATask(
        question=(
            "In the video https://www.youtube.com/watch?v=L1vXCYZAYYM, what is the highest "
            "number of bird species to be on camera simultaneously?"
        ),
        expected="3",
    ),
    GAIATask(
        question=(
            "Of the authors (First M. Last) that worked on the paper 'Pie Menus or Linear "
            "Menus, Which Is Better?' in 2015, what was the title of the first paper authored "
            "by the one that had authored prior papers?"
        ),
        expected="Mapping Human Oriented Information to Software Agents for Online Systems Usage",
    ),
    GAIATask(
        question=(
            "In Series 9, Episode 11 of Doctor Who, the Doctor is trapped inside an "
            "ever-shifting maze. What is this location called in the official script for the "
            "episode? Give the setting exactly as it appears in the first scene heading."
        ),
        expected="THE CASTLE",
    ),
    GAIATask(
        question=(
            ".rewsna eht sa \"tfel\" drow eht fo etisoppo eht etirw ,"
            "ecnetnes siht dnatsrednu uoy fI"
        ),
        expected="Right",
    ),
    GAIATask(
        question=(
            "Which of the following is not logically equivalent to the rest? "
            "Provide the full statement that doesn't fit.\n\n"
            "¬(A ∧ B) ↔ (¬A ∨ ¬B)\n"
            "¬(A ∨ B) ↔ (¬A ∧ ¬B)\n"
            "(A → B) ↔ (¬B → ¬A)\n"
            "(A → B) ↔ (¬A ∨ B)\n"
            "(¬A → B) ↔ (A ∨ ¬B)\n"
            "¬(A → B) ↔ (A ∧ ¬B)"
        ),
        expected="(¬A → B) ↔ (A ∨ ¬B)",
    ),
    GAIATask(
        question=(
            "My family reunion is this week, and I was assigned the mashed potatoes dish. "
            "I need to bring enough for me, my twin brother and his family, my aunt and her "
            "family, my grandma and her brother, her brother's daughter, and his daughter's "
            "family. All the adults but me have been married, and no one is divorced or "
            "remarried, but my grandpa and my grandma's sister-in-law passed away last year. "
            "All living spouses are attending. My brother has two children that are still kids, "
            "my aunt has one six-year-old, and my grandma's brother's daughter has three kids "
            "under 12. I figure each adult will eat about 1.5 potatoes of mashed potatoes and "
            "each kid will eat about 1/2 a potato of mashed potatoes, except my second cousins "
            "don't eat carbs. The average potato is about half a pound, and potatoes are sold "
            "in 5-pound bags. How many whole bags of potatoes do I need? Just give the number."
        ),
        expected="2",
    ),
]


# ---------------------------------------------------------------------------
# Agent setup
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a meticulous research assistant competing on the GAIA benchmark.

You have access to an `exa_search_results_json` tool. Use it whenever the question requires
facts, numbers, or content you cannot derive by pure reasoning alone.

## Strategy
1. Read the question carefully — many GAIA questions have subtle requirements
   (exact wording, specific Wikipedia version, specific units, etc.).
2. For factual lookups, search for the primary source mentioned in the question.
3. For calculations, work step-by-step and show your arithmetic.
4. For reversed/encoded text, decode it first before answering.
5. For logic problems, evaluate each statement systematically.

## Answer format
Always end your response with your final answer wrapped in tags:

<answer>your answer here</answer>

The value inside the tags must be the bare answer only — no explanation, no units
unless the question asks for them, matching the exact format GAIA expects
(integer, decimal, short phrase, or exact quoted text).
If memories from past attempts are included in the prompt, read them carefully —
they describe mistakes made on this exact question.
"""


# def internet_search(query: str, max_results: int = 5) -> str:
#     """Search the internet using Exa and return highlighted snippets."""
#     exa = Exa(api_key=os.environ["EXA_API_KEY"])
#     results = exa.search_and_contents(
#         query,
#         num_results=max_results,
#         text={"max_characters": 3000},
#     )
#     lines: list[str] = []
#     for r in results.results:
#         lines.append(f"[{r.title}] ({r.url})")
#         if hasattr(r, "highlights") and r.highlights:
#             for h in r.highlights:
#                 lines.append(f"  {h}")
#         lines.append("")
#     return "\n".join(lines)

internet_search = ExaSearchResults(exa_api_key=os.environ["EXA_API_KEY"])


def extract_final_answer(text: str) -> str:
    """Extract the value inside <answer>...</answer> tags."""
    if not text:
        return ""
    match = re.search(r"<answer>(.*?)</answer>", text, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""


def normalize(s: str) -> str:
    return s.strip().lower().replace(",", "").replace("$", "")


def answers_match(got: str, expected: str) -> bool:
    """Pass if the normalized expected answer appears anywhere in the response."""
    return normalize(expected) == normalize(got)


JUDGE_SYSTEM_PROMPT = """You write short review feedback for a learning system that stores
reflections for future runs. You must NEVER reveal the benchmark reference answer: do not
state it, paraphrase it, hint at it, give a substring, or describe it in a way that would
let someone infer it. Comment only on process: search strategy, source use, reasoning steps,
and what to try or verify next time."""


def _langchain_message_to_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text" and block.get("text"):
                parts.append(str(block["text"]))
        return "\n".join(parts).strip()
    return str(content)


def gaia_judge_feedback(
    judge: ChatBedrockConverse,
    *,
    trajectory: list[dict[str, Any]],
    agent_final: str,
    reference_answer: str,
    matched: bool,
    trajectory_max_chars: int = 100_000,
) -> str | None:
    """Bedrock judge: trajectory + agent output + reference for internal grading only.

    Returned text is intended for Reflect ``feedback_text`` and must not echo the reference
    answer (enforced by prompt; callers may post-check).
    """
    traj_text = json.dumps(trajectory, ensure_ascii=False, default=str)
    if len(traj_text) > trajectory_max_chars:
        traj_text = traj_text[:trajectory_max_chars] + "\n... [trajectory truncated]"

    outcome = (
        "The agent's extracted answer matched the benchmark reference."
        if matched
        else "The agent's extracted answer did NOT match the benchmark reference."
    )
    human = f"""{outcome}

You may use the following reference answer ONLY to judge success internally. Your reply
must not repeat or hint at it.

--- Reference (do not output) ---
{reference_answer}
--- End reference ---

## Agent final message
{agent_final}

## Trajectory (JSON)
{traj_text}

Reply with 2–4 sentences of plain-text feedback for learning (process and strategy only).
Do not include the reference answer or any substring of it. Do not give the "correct" value."""

    try:
        msg = judge.invoke(
            [SystemMessage(content=JUDGE_SYSTEM_PROMPT), HumanMessage(content=human)]
        )
        text = _langchain_message_to_text(getattr(msg, "content", msg)).strip()
        return text or None
    except Exception as exc:
        print(f"  Judge error (no feedback_text): {exc}")
        return None


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="GAIA learning loop with DeepAgents + Reflect.")
    p.add_argument("--base-url", default=os.getenv("REFLECT_API_URL", "http://localhost:8000"))
    p.add_argument("--project-id", default=os.getenv("REFLECT_PROJECT_ID"))
    p.add_argument("--reflect-api-key", default=os.getenv("REFLECT_API_KEY"))
    p.add_argument("--model", default=os.getenv("DEEPAGENT_MODEL", "openai:gpt-5.4-mini"))
    p.add_argument("--limit", type=int, default=3, help="Max memories per task.")
    p.add_argument("--lambda", dest="lambda_", type=float, default=0.35,
                   help="Memory ranking blend (0=Q-value, 1=similarity).")
    p.add_argument("--count", type=int, default=len(TASKS), help="Number of tasks to run.")
    p.add_argument("--api-timeout", type=float, default=180.0)
    p.add_argument(
        "--judge-model",
        default=os.getenv("GAIA_JUDGE_MODEL", DEFAULT_JUDGE_MODEL_ID),
        help="Bedrock model id for Reflect feedback (LLM-as-judge).",
    )
    p.add_argument(
        "--skip-judge",
        action="store_true",
        help="Do not call Bedrock judge; trace has no feedback_text.",
    )
    p.add_argument(
        "--use-skill",
        action="store_true",
        help="Use the project skill instead of per-task memory augmentation.",
    )
    args = p.parse_args()
    if not args.project_id:
        raise RuntimeError("Set REFLECT_PROJECT_ID or pass --project-id.")
    if not args.reflect_api_key:
        raise RuntimeError("Set REFLECT_API_KEY or pass --reflect-api-key.")
    if not os.getenv("EXA_API_KEY"):
        raise RuntimeError("Set EXA_API_KEY.")
    return args


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()

    reflect = ReflectClient(
        base_url=args.base_url,
        api_key=args.reflect_api_key,
        project_id=args.project_id,
        timeout=args.api_timeout,
    )

    model = args.model if "." not in args.model else ChatBedrockConverse(model_id=args.model)
    agent = create_deep_agent(
        model=model,
        tools=[internet_search],
        system_prompt=SYSTEM_PROMPT,
    )

    judge_llm: ChatBedrockConverse | None = None
    if not args.skip_judge:
        judge_llm = ChatBedrockConverse(model_id=args.judge_model)

    tasks = TASKS[: min(args.count, len(TASKS))]
    correct = 0
    total_memories = 0
    W = 68

    # Optionally fetch the project skill once upfront
    skill_text: str | None = None
    if args.use_skill:
        skill_text = reflect.get_skill()
        if skill_text:
            print(f"  Skill loaded ({len(skill_text)} chars)")
        else:
            print("  WARNING: --use-skill set but no skill found for project. Falling back to memories.")
            args.use_skill = False

    mode = "skill" if args.use_skill else "memories"
    print("═" * W)
    judge_note = "off" if args.skip_judge else args.judge_model
    print(f"  GAIA Level-1 Learning Loop  │  agent={args.model}  │  judge={judge_note}  │  {len(tasks)} tasks  │  mode={mode}")
    print("═" * W)

    for i, task in enumerate(tasks, 1):
        print(f"\n[{i:2d}/{len(tasks)}] {task.question[:75]}{'…' if len(task.question) > 75 else ''}")

        # In skill mode: skip memory augmentation (limit=1 is the Qdrant minimum;
        # the retrieved memory is ignored and the skill is injected instead).
        with reflect.trace(
            task.question,
            limit=args.limit,
            lambda_=args.lambda_,
        ) as ctx:
            if args.use_skill:
                prompt = task.question + "\n\n<skill>\n" + skill_text + "\n</skill>"
                print("  Using project skill (no per-task memories)")
            else:
                prompt = ctx.augmented_task
                n_mem = len(ctx.memories)
                total_memories += n_mem
                if n_mem:
                    print(f"  Memories injected: {n_mem}")
                    for m in ctx.memories:
                        print(f"    [q={m.q_value:.2f}] {m.reflection[:70].splitlines()[0]}…")

            # 2. Run the agent
            result = agent.invoke({
                "messages": [{"role": "user", "content": prompt}]
            })

            # 3. Extract final answer from last assistant message
            messages = result.get("messages", [])
            last_content = ""
            for msg in reversed(messages):
                content = getattr(msg, "content", None) or (
                    msg.get("content") if isinstance(msg, dict) else ""
                )
                if not content:
                    continue
                # Handle Anthropic-style content blocks: [{'type': 'text', 'text': '...'}]
                if isinstance(content, list):
                    parts = [
                        block["text"]
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text" and block.get("text")
                    ]
                    content = "\n".join(parts)
                last_content = str(content)
                if last_content:
                    break

            got = extract_final_answer(last_content)
            success = answers_match(got, task.expected)
            if success:
                correct += 1

            icon = "✓" if success else "✗"
            print(f"  [{icon}] Expected: {task.expected!r}  │  Got: {got!r}")

            # 4. Store trace + inline review (Bedrock judge feedback — no reference answer in text)
            trajectory = from_deepagents(messages)
            feedback_text: str | None = None
            if judge_llm is not None:
                feedback_text = gaia_judge_feedback(
                    judge_llm,
                    trajectory=trajectory,
                    agent_final=last_content,
                    reference_answer=task.expected,
                    matched=success,
                )
                if feedback_text:
                    preview = feedback_text.replace("\n", " ")[:120]
                    print(f"  Judge feedback: {preview}{'…' if len(feedback_text) > 120 else ''}")

            ctx.set_output(
                trajectory=trajectory,
                final_response=last_content,
                model=args.model,
                result="pass" if success else "fail",
                feedback_text=feedback_text,
                metadata={
                    "expected": task.expected,
                    "source": "gaia_level1",
                    "judge_model": args.judge_model,
                    "matched_benchmark": success,
                },
            )

    # Summary
    pct = correct / len(tasks) * 100
    print(f"\n{'═' * W}")
    if args.use_skill:
        print(f"  Score: {correct}/{len(tasks)}  ({pct:.0f}%)   │   Mode: project skill")
        print()
        print("  ▶ Project skill was injected into every task prompt.")
        print("    Refine the skill in the dashboard to improve results.")
    elif total_memories == 0:
        print(f"  Score: {correct}/{len(tasks)}  ({pct:.0f}%)   │   Memories used: {total_memories}")
        print()
        print("  ▶ First run complete. Reflect stored reflections for every answer.")
        print("    Run again to inject those memories and improve the score.")
    else:
        print(f"  Score: {correct}/{len(tasks)}  ({pct:.0f}%)   │   Memories used: {total_memories}")
        print()
        print("  ▶ Memories were injected from prior runs.")
        print("    Remaining failures will get higher Q-value memories next time.")
    print("═" * W)


if __name__ == "__main__":
    main()
