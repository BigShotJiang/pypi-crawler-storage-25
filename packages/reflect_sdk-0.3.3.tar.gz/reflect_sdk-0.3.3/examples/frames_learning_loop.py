"""FRAMES benchmark learning loop using OpenAI Agents SDK + LiteLLM + Wikipedia + Reflect.

Runs 10 FRAMES multi-hop questions through an agent equipped with Wikipedia
search (free, no API key required). Uses LiteLLM under the hood so any provider
works -- Bedrock, OpenAI, Anthropic, etc. Every trace is stored in Reflect with
an inline review. On subsequent runs, Reflect injects memories from past mistakes
so the agent scores progressively higher.

Run twice to see the loop:

  Run 1 -- no memories, agent solves from scratch, mistakes get stored.
  Run 2+ -- past reflections are injected, agent avoids known pitfalls.

Prerequisites:
  pip install openai-agents litellm reflect-sdk wikipedia-api datasets
  export REFLECT_API_KEY=...
  export REFLECT_PROJECT_ID=...
  # Plus credentials for your chosen provider, e.g.:
  #   Bedrock: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION_NAME
  #   OpenAI:  OPENAI_API_KEY

Usage:
  # Bedrock (default)
  uv run --package reflect-sdk python packages/sdk/examples/frames_learning_loop.py

  # OpenAI
  uv run --package reflect-sdk python packages/sdk/examples/frames_learning_loop.py \
    --model openai/gpt-4.1-mini

  # Anthropic
  uv run --package reflect-sdk python packages/sdk/examples/frames_learning_loop.py \
    --model anthropic/claude-sonnet-4-5-20250514
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
from dataclasses import dataclass
from typing import Any

from agents import Agent, Runner, function_tool
from exa_py import Exa
from litellm import LiteLLM
from reflect_sdk import ReflectClient
from reflect_sdk.converters import from_openai_agents
from agents.extensions.models.litellm_model import LitellmModel

# LiteLLM model prefix docs: https://docs.litellm.ai/docs/providers
# Bedrock:   "bedrock/anthropic.claude-sonnet-4-5-20250514-v1:0"
# OpenAI:    "openai/gpt-4.1-mini"
# Anthropic: "anthropic/claude-sonnet-4-5-20250514"
DEFAULT_MODEL = "bedrock/converse/openai.gpt-oss-120b-1:0"

# ---------------------------------------------------------------------------
# Wikipedia search tool (free, no API key)
# ---------------------------------------------------------------------------

try:
    import wikipediaapi
except ImportError:
    raise ImportError(
        "Install the wikipedia-api package: pip install wikipedia-api"
    )

@function_tool
def internet_search(
    query: str,
    max_results: int = 5,
):
    """Run an internet search using Exa."""
    exa = Exa(api_key=os.environ["EXA_API_KEY"])
    return exa.search_and_contents(
        query,
        num_results=max_results,
        text={"max_characters": 2000},
    )

@function_tool
def wikipedia_search(query: str, max_sections: int = 3) -> str:
    """Search Wikipedia and return the summary plus top sections of the best matching page.

    Args:
        query: The search term or article title to look up on Wikipedia.
        max_sections: Maximum number of top-level sections to include beyond the summary.
    """
    wiki = wikipediaapi.Wikipedia(
        user_agent="ReflectFramesBenchmark/1.0 (https://github.com/starlight-search/reflect)",
        language="en",
    )
    page = wiki.page(query)
    if not page.exists():
        # Try a simpler title
        parts = query.split()
        for length in range(len(parts), 0, -1):
            candidate = " ".join(parts[:length])
            page = wiki.page(candidate)
            if page.exists():
                break
        if not page.exists():
            return f"No Wikipedia page found for: {query}"

    sections_text: list[str] = []
    sections_text.append(f"# {page.title}\n\n{page.summary}")

    count = 0
    for section in page.sections:
        if count >= max_sections:
            break
        if section.text.strip():
            sections_text.append(f"\n## {section.title}\n{section.text[:2000]}")
            count += 1

    return "\n".join(sections_text)


@function_tool
def run_python(code: str) -> str:
    """Execute Python code and return the output. Use this for calculations,
    unit conversions, date arithmetic, or any computation needed to answer
    multi-hop questions.

    Args:
        code: Python code to execute. Use print() to produce output.
    """
    import io
    import contextlib
    import math  # noqa: F401 – available inside exec

    buf = io.StringIO()
    local_ns: dict[str, Any] = {"math": math}
    try:
        with contextlib.redirect_stdout(buf):
            exec(code, {"__builtins__": __builtins__, "math": math}, local_ns)
        output = buf.getvalue()
        return output.strip() if output.strip() else "(no output — use print() to see results)"
    except Exception as exc:
        return f"Error: {type(exc).__name__}: {exc}"


@function_tool
def wikipedia_get_section(article_title: str, section_title: str) -> str:
    """Retrieve a specific section from a Wikipedia article.

    Args:
        article_title: The exact title of the Wikipedia article.
        section_title: The section heading to retrieve.
    """
    wiki = wikipediaapi.Wikipedia(
        user_agent="ReflectFramesBenchmark/1.0 (https://github.com/starlight-search/reflect)",
        language="en",
    )
    page = wiki.page(article_title)
    if not page.exists():
        return f"No Wikipedia page found for: {article_title}"

    def _find_section(sections, target: str) -> str | None:
        for s in sections:
            if s.title.lower().strip() == target.lower().strip():
                return f"## {s.title}\n{s.text[:4000]}"
            found = _find_section(s.sections, target)
            if found:
                return found
        return None

    result = _find_section(page.sections, section_title)
    if result:
        return result
    available = [s.title for s in page.sections]
    return f"Section '{section_title}' not found. Available sections: {', '.join(available)}"


# ---------------------------------------------------------------------------
# FRAMES benchmark loader
# Source: google/frames-benchmark on HuggingFace
# https://huggingface.co/datasets/google/frames-benchmark
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class FramesTask:
    question: str
    expected: str
    reasoning_type: str


def load_tasks(count: int, offset: int = 0) -> list[FramesTask]:
    """Load real FRAMES questions from the google/frames-benchmark HuggingFace dataset.

    Requires: pip install datasets
    """
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise ImportError(
            "Install the datasets library: pip install datasets"
        ) from exc

    ds = load_dataset("google/frames-benchmark", split="test")
    end = min(offset + count, len(ds))
    rows = ds.select(range(offset, end))
    return [
        FramesTask(
            question=row["Prompt"],
            expected=row["Answer"],
            reasoning_type=row["reasoning_types"],
        )
        for row in rows
    ]


# ---------------------------------------------------------------------------
# Agent setup
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a meticulous research assistant competing on the FRAMES benchmark.
FRAMES questions are multi-hop: they require fetching and combining facts from multiple
Wikipedia articles.

You have these tools:
- `internet_search` -- search the internet for information.
- `run_python` -- execute Python code for calculations, unit conversions, date math, etc.

## Strategy
1. Break the question into sub-questions. Identify which Wikipedia articles you need.
2. Look up each article and extract the specific fact needed.
3. Use `run_python` for any arithmetic, date calculations, or unit conversions.
   Do NOT do math in your head -- always use the code interpreter.
4. Double-check units, dates, and names before answering.

## Answer format
Always end your response with your final answer wrapped in tags:

<answer>your answer here</answer>

The value inside the tags must be the bare answer only -- matching the format the question
expects (a name, number, short phrase, etc.).
If memories from past attempts are included in the prompt, read them carefully --
they describe mistakes made on this exact question.
"""


def extract_final_answer(text: str) -> str:
    """Extract the value inside <answer>...</answer> tags."""
    if not text:
        return ""
    match = re.search(r"<answer>(.*?)</answer>", text, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""


def normalize(s: str) -> str:
    return s.strip().lower().replace(",", "").replace("$", "").replace(" ", "")


def answers_match(got: str, expected: str) -> bool:
    """Fuzzy match: check if the normalized expected answer appears in the response."""
    g = normalize(got)
    e = normalize(expected)
    if not g or not e:
        return False
    return e in g or g in e or g == e


# ---------------------------------------------------------------------------
# LLM-as-judge for feedback (uses the same OpenAI model, no extra deps)
# ---------------------------------------------------------------------------

JUDGE_SYSTEM_PROMPT = """You write short review feedback for a learning system that stores
reflections for future runs. You must NEVER reveal the benchmark reference answer: do not
state it, paraphrase it, hint at it, give a substring, or describe it in a way that would
let someone infer it. Comment only on process: search strategy, Wikipedia lookups,
reasoning steps, and what to try or verify next time."""


async def judge_feedback(
    *,
    model: str,
    trajectory: list[dict[str, Any]],
    agent_final: str,
    reference_answer: str,
    matched: bool,
) -> str | None:
    """Use the same LiteLLM model as a lightweight judge."""
    import litellm

    traj_text = json.dumps(trajectory, ensure_ascii=False, default=str)
    if len(traj_text) > 80_000:
        traj_text = traj_text[:80_000] + "\n... [trajectory truncated]"

    outcome = (
        "The agent's extracted answer matched the benchmark reference."
        if matched
        else "The agent's extracted answer did NOT match the benchmark reference."
    )
    human = f"""{outcome}

You may use the following reference answer ONLY to judge success internally. Your reply
must not repeat or hint at it.

--- Reference (do not output) ---
{reference_answer}
--- End reference ---

## Agent final message
{agent_final}

## Trajectory (JSON)
{traj_text}

Reply with 2-4 sentences of plain-text feedback for learning (process and strategy only).
Do not include the reference answer or any substring of it."""

    try:
        resp = await litellm.acompletion(
            model=model,
            messages=[
                {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                {"role": "user", "content": human},
            ],
        )
        text = resp.choices[0].message.content or ""
        return text.strip() or None
    except Exception as exc:
        print(f"  Judge error (no feedback_text): {exc}")
        return None


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="FRAMES learning loop with OpenAI Agents + LiteLLM + Reflect.")
    p.add_argument("--base-url", default=os.getenv("REFLECT_API_URL", "http://localhost:8000"))
    p.add_argument("--project-id", default=os.getenv("REFLECT_PROJECT_ID"))
    p.add_argument("--reflect-api-key", default=os.getenv("REFLECT_API_KEY"))
    p.add_argument("--model", default=os.getenv("LITELLM_MODEL", DEFAULT_MODEL),
                   help="LiteLLM model string, e.g. bedrock/converse/openai.gpt-oss-120b-1:0")
    p.add_argument("--judge-model", default=os.getenv("LITELLM_JUDGE_MODEL"),
                   help="LiteLLM model for judge (defaults to --model).")
    p.add_argument("--limit", type=int, default=3, help="Max memories per task.")
    p.add_argument("--lambda", dest="lambda_", type=float, default=0.35,
                   help="Memory ranking blend (0=similarity only, 1=Q-value only).")
    p.add_argument("--count", type=int, default=10, help="Number of tasks to run.")
    p.add_argument("--offset", type=int, default=0, help="Offset into the FRAMES dataset.")
    p.add_argument("--api-timeout", type=float, default=180.0)
    p.add_argument("--skip-judge", action="store_true",
                   help="Do not call judge; trace has no feedback_text.")
    args = p.parse_args()
    if not args.project_id:
        raise RuntimeError("Set REFLECT_PROJECT_ID or pass --project-id.")
    if not args.reflect_api_key:
        raise RuntimeError("Set REFLECT_API_KEY or pass --reflect-api-key.")
    if not args.judge_model:
        args.judge_model = args.model
    return args


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def run() -> None:
    args = parse_args()

    reflect = ReflectClient(
        base_url=args.base_url,
        api_key=args.reflect_api_key,
        project_id=args.project_id,
        timeout=args.api_timeout,
    )

    # LiteLLM's AsyncOpenAI proxy routes to any provider via the model string.
    litellm_model = LiteLLM(
    )

    agent = Agent(
        name="FRAMES research agent",
                    model= LitellmModel(model=args.model, api_key = "ABSKQmVkcm9ja0FQSUtleS0waWhzLWF0LTE4MjMzNTA4NDMwNzpxVmp2YlJXVnpia3Nyek9saXdrQ3hwVy8rMVhZeE9paDBXbVpETGs4eElycS9saDJ3WElheWtXZVE5MD0="),
        tools=[run_python, internet_search],
        instructions=SYSTEM_PROMPT,
        
    )

    tasks = load_tasks(args.count, offset=args.offset)
    correct = 0 
    total_memories = 0
    W = 72

    print("=" * W)
    judge_note = "off" if args.skip_judge else args.judge_model
    print(f"  FRAMES Learning Loop  |  agent={args.model}  |  judge={judge_note}  |  {len(tasks)} tasks")
    print("=" * W)

    for i, task in enumerate(tasks, 1):
        print(f"\n[{i:2d}/{len(tasks)}] ({task.reasoning_type}) {task.question[:72]}{'...' if len(task.question) > 72 else ''}")

        # 1. Augment with Reflect memories (empty on first run)
        async with reflect.trace_async(
            task.question,
            limit=args.limit,
            lambda_=args.lambda_,
        ) as ctx:
            n_mem = len(ctx.memories)
            total_memories += n_mem
            if n_mem:
                print(f"  Memories injected: {n_mem}")
                for m in ctx.memories:
                    print(f"    [q={m.q_value:.2f}] {m.reflection[:70].splitlines()[0]}...")

            # 2. Run the agent
            result = await Runner.run(agent, input=ctx.augmented_task, max_turns=20)

            # 3. Extract final answer
            last_content = str(result.final_output).strip()
            got = extract_final_answer(last_content)
            success = answers_match(got, task.expected)
            if success:
                correct += 1

            icon = "+" if success else "x"
            print(f"  [{icon}] Expected: {task.expected!r}  |  Got: {got!r}")

            # 4. Generate judge feedback
            trajectory = from_openai_agents(result)
            feedback_text: str | None = None
            if not args.skip_judge:
                feedback_text = await judge_feedback(
                    model=args.judge_model,
                    trajectory=trajectory,
                    agent_final=last_content,
                    reference_answer=task.expected,
                    matched=success,
                )
                if feedback_text:
                    preview = feedback_text.replace("\n", " ")[:120]
                    print(f"  Judge feedback: {preview}{'...' if len(feedback_text) > 120 else ''}")

            # 5. Store trace + inline review
            ctx.set_output(
                trajectory=trajectory,
                final_response=last_content,
                model=args.model,
                result="pass" if success else "fail",
                feedback_text=feedback_text,
                metadata={
                    "expected": task.expected,
                    "reasoning_type": task.reasoning_type,
                    "source": "frames_benchmark",
                    "matched_benchmark": success,
                },
            )

    # Summary
    pct = correct / len(tasks) * 100
    print(f"\n{'=' * W}")
    print(f"  Score: {correct}/{len(tasks)}  ({pct:.0f}%)   |   Memories used: {total_memories}")
    if total_memories == 0:
        print()
        print("  > First run complete. Reflect stored reflections for every answer.")
        print("    Run again to inject those memories and improve the score.")
    else:
        print()
        print("  > Memories were injected from prior runs.")
        print("    Remaining failures will get higher Q-value memories next time.")
    print("=" * W)


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
