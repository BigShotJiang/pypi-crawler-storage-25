"""Deep Agents quickstart using Exa Search + Reflect memory loop.

Prerequisites:
- pip install deepagents exa-py
- Set EXA_API_KEY
- Set one model provider API key (for example OPENAI_API_KEY)
- Set REFLECT_PROJECT_ID and REFLECT_API_KEY

Optional env vars:
- REFLECT_API_URL (default: https://api.starlight-search.com)
- DEEPAGENT_MODEL (default: openai:gpt-5.4-mini)
- RESEARCH_QUERY (default: Who is Akshay Ballal?)
"""

from __future__ import annotations

import os

from deepagents import create_deep_agent
from exa_py import Exa
from reflect_sdk import ReflectClient
from reflect_sdk.converters import from_deepagents

BASE_URL = os.getenv("REFLECT_API_URL", "http://localhost:8000")
PROJECT_ID = os.getenv("REFLECT_PROJECT_ID") if os.getenv("REFLECT_PROJECT_ID") else "example"
REFLECT_API_KEY = os.getenv("REFLECT_API_KEY")
MODEL = os.getenv("DEEPAGENT_MODEL", "openai:gpt-5.4-mini")
TASK = os.getenv("RESEARCH_QUERY", "What is the stock price of Apple and Nvidia?")
MEMORY_LIMIT = 3
MEMORY_LAMBDA = 0.5
API_TIMEOUT = 180.0

research_instructions = """You are an expert researcher. Your job is to conduct thorough research and then write a polished report.

You have access to an internet search tool as your primary means of gathering information.

## `internet_search`

Use this to run an internet search for a given query. You can specify the max number of results to return and the topic.
Prefer high-quality primary sources and cite concrete facts from search results.
"""


def internet_search(
    query: str,
    max_results: int = 5,
):
    """Run an internet search using Exa."""
    exa = Exa(api_key=os.environ["EXA_API_KEY"])
    return exa.search_and_contents(
        query,
        num_results=max_results,
        text={"max_characters": 2000},
    )

def main() -> None:
    if not os.getenv("EXA_API_KEY"):
        raise RuntimeError("Set EXA_API_KEY.")
    if not PROJECT_ID or not REFLECT_API_KEY:
        raise RuntimeError("Set REFLECT_PROJECT_ID and REFLECT_API_KEY.")

    reflect = ReflectClient(
        base_url=BASE_URL,
        api_key=REFLECT_API_KEY,
        project_id=PROJECT_ID,
        timeout=API_TIMEOUT,
    )

    with reflect.trace(TASK, limit=MEMORY_LIMIT, lambda_=MEMORY_LAMBDA) as ctx:
        agent = create_deep_agent(
            model=MODEL,
            tools=[internet_search],
            system_prompt=research_instructions,
        )
        result = agent.invoke({"messages": [{"role": "user", "content": ctx.augmented_task}]})
        print(result["messages"][-1].content)
        trajectory = from_deepagents(result["messages"])
        ctx.set_output(
            trajectory=trajectory,
            model=MODEL,
            metadata={"source": "deepagents_exa_quickstart"},
            result="pass",
        )


if __name__ == "__main__":
    main()
