"""Interactive CLI example demonstrating inline trace review.

Prerequisites:
- Reflect API running locally or reachable via --base-url
- REFLECT_API_KEY set in the environment or passed by argument
- REFLECT_PROJECT_ID set in the environment or passed by argument
- OPENAI_API_KEY set in the environment

LangSmith tracing is optional. Pass --langsmith-project <name> to send traces to LangSmith.
Install with: pip install reflect-sdk[langsmith]
"""

import argparse
import contextlib
import os

from reflect_sdk import ReflectClient

# Optional LangSmith: use no-ops when not installed or when tracing disabled
try:
    from langsmith import traceable, tracing_context
    from langsmith.wrappers import wrap_openai

    _LANGSMITH_AVAILABLE = True
except ImportError:
    traceable = lambda **kw: (lambda f: f)
    tracing_context = lambda project_name=None: contextlib.nullcontext()
    wrap_openai = lambda x: x
    _LANGSMITH_AVAILABLE = False

DEFAULT_TASK = "What is the latest news in AI?"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a single interactive trace and inline review loop against the Reflect API.",
    )
    parser.add_argument("--base-url", default="http://localhost:8000", help="Reflect API base URL.")
    parser.add_argument("--project-id", default=os.getenv("REFLECT_PROJECT_ID"), help="Reflect project id.")
    parser.add_argument("--reflect-api-key", default=os.getenv("REFLECT_API_KEY"), help="Reflect API key.")
    parser.add_argument("--llm-base-url", default="https://api.openai.com/v1", help="OpenAI-compatible base URL.")
    parser.add_argument("--model", default="gpt-5.4-mini", help="Model name for the interactive solve step.")
    parser.add_argument("--task", default=DEFAULT_TASK, help="Task to solve.")
    parser.add_argument("--limit", type=int, default=3, help="Maximum number of memories to retrieve.")
    parser.add_argument("--lambda", dest="lambda_", type=float, default=0.5, help="Weight for q-value in ranking.")
    parser.add_argument("--langsmith-project", default=None, help="Optional LangSmith project name.")
    parser.add_argument("--api-timeout", type=float, default=180.0, help="Timeout for Reflect API calls.")
    parser.add_argument("--llm-timeout", type=float, default=120.0, help="Timeout for the model call.")
    args = parser.parse_args()
    if not args.project_id:
        raise RuntimeError("REFLECT_PROJECT_ID or --project-id must be provided.")
    if not args.reflect_api_key:
        raise RuntimeError("REFLECT_API_KEY or --reflect-api-key must be provided.")
    return args


def build_solver_messages(augmented_task: str) -> list[dict[str, str]]:
    return [
        {
            "role": "system",
            "content": (
                "Solve the user's task. Use any relevant memories included in the prompt. "
                "Respond concisely with a short explanation and final answer."
            ),
        },
        {"role": "user", "content": augmented_task},
    ]


@traceable(run_type="llm", name="solve_with_openai")
def solve_with_openai(
    *,
    base_url: str,
    model: str,
    messages: list[dict[str, str]],
    timeout: float,
    api_key: str,
    use_langsmith: bool = False,
) -> str:
    from openai import OpenAI

    client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
    if use_langsmith:
        client = wrap_openai(client)
    response = client.chat.completions.create(model=model, messages=messages)
    return (response.choices[0].message.content or "").strip()


def prompt_for_review_action() -> str:
    while True:
        answer = input("Review now? [y/n/d (defer)]: ").strip().lower()
        if answer in {"y", "yes"}:
            return "pass"
        if answer in {"n", "no"}:
            return "fail"
        if answer in {"d", "defer", "deferred", "later", "skip"}:
            return "defer"
        print("Please enter 'y', 'n', or 'd'.")


def prompt_for_feedback() -> str:
    feedback = input("What feedback should be remembered for next time? ").strip()
    if feedback:
        return feedback
    return "The answer was incorrect and needs revision."


@traceable(name="interactive_feedback_cli")
def run_interactive_example(
    args: argparse.Namespace, openai_api_key: str, use_langsmith: bool = False
) -> None:
    client = ReflectClient(
        base_url=args.base_url,
        api_key=args.reflect_api_key,
        project_id=args.project_id,
        timeout=args.api_timeout,
    )

    augmented = client.augment_with_memories(
        task=args.task,
        limit=args.limit,
        lambda_=args.lambda_,
    )

    print(f"Task: {args.task}")
    print(f"Retrieved {len(augmented.memories)} memories.")
    if augmented.memories:
        for index, memory in enumerate(augmented.memories, start=1):
            print(f"{index}. {memory.task}")
        print()

    assistant_response = solve_with_openai(
        base_url=args.llm_base_url,
        model=args.model,
        messages=build_solver_messages(augmented.augmented_task),
        timeout=args.llm_timeout,
        api_key=openai_api_key,
        use_langsmith=use_langsmith,
    )

    print("Model response:")
    print(assistant_response)
    print()

    review_action = prompt_for_review_action()
    success = review_action == "pass"
    feedback = prompt_for_feedback() if review_action == "fail" else None
    trajectory = build_solver_messages(augmented.augmented_task)
    trajectory.append({"role": "assistant", "content": assistant_response})
    trace = client.create_trace_and_wait(
        task=args.task,
        trajectory=trajectory,
        final_response=assistant_response,
        retrieved_memory_ids=[memory.id for memory in augmented.memories],
        model=args.model,
        metadata={"source": "interactive_feedback_cli"},
        review_result=None if review_action == "defer" else ("pass" if success else "fail"),
        feedback_text=None if review_action == "defer" else feedback,
    )

    print()
    if review_action == "defer":
        print("Result: deferred review")
    else:
        print(f"Result: {'success' if success else 'failure'}")
    if feedback is not None:
        print(f"Captured feedback: {feedback}")
    print(f"Stored trace: {trace.id}")
    print(f"Review status: {trace.review_status}")
    print(f"Created memory id: {trace.created_memory_id}")


def main() -> None:
    args = parse_args()
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
        raise RuntimeError("OPENAI_API_KEY must be set to run this example.")

    use_langsmith = bool(args.langsmith_project)
    if use_langsmith and not _LANGSMITH_AVAILABLE:
        raise RuntimeError(
            "LangSmith tracing requested (--langsmith-project) but langsmith is not installed. "
            "Install with: pip install reflect-sdk[langsmith]"
        )
    if use_langsmith:
        os.environ["LANGCHAIN_TRACING"] = "true"
    with tracing_context(project_name=args.langsmith_project):
        run_interactive_example(args, openai_api_key, use_langsmith=use_langsmith)


if __name__ == "__main__":
    main()
