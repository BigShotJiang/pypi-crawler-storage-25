#!/usr/bin/env python3
"""Generate reflect-client.mdx from reflect_sdk.client docstrings."""

from __future__ import annotations

import inspect
import re
import sys
from pathlib import Path

# Add src to path so we can import reflect_sdk
_sdk_root = Path(__file__).resolve().parent.parent
_src = _sdk_root / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from reflect_sdk import client as client_module  # noqa: E402

# Members to exclude from the reference (undocumented in current docs)
EXCLUDED_MEMBERS = frozenset({"bootstrap", "list_api_keys", "create_api_key", "revoke_api_key"})
EXCLUDED_TYPES = frozenset({"ApiKeyInfo", "CreatedApiKey", "BootstrapInfo"})


def _get_summary(doc: str | None) -> str:
    """First paragraph of docstring, before Args/Returns/Attributes."""
    if not doc or not doc.strip():
        return ""
    # Split on common section headers
    for sep in ("\n\nArgs:", "\n\nReturns:", "\n\nAttributes:", "\n\nRaises:"):
        doc = doc.split(sep)[0]
    return doc.strip()


def _parse_args_section(doc: str | None) -> dict[str, str]:
    """Extract Args section into {param_name: description}."""
    if not doc or "Args:" not in doc:
        return {}
    match = re.search(r"\nArgs:\s*\n(.*?)(?=\n\w+:|$)", doc, re.DOTALL)
    if not match:
        return {}
    args_text = match.group(1)
    result: dict[str, str] = {}
    for line in args_text.splitlines():
        line = line.strip()
        if not line:
            continue
        # Google style: "param_name: description" or "param_name (type): description"
        m = re.match(r"(\w+)\s*(?:\([^)]*\))?:\s*(.+)", line)
        if m:
            result[m.group(1)] = m.group(2).strip()
    return result


def _format_param_default(param: inspect.Parameter) -> str:
    if param.default is inspect.Parameter.empty:
        return "required"
    if isinstance(param.default, str) and param.default:
        return f'"{param.default}"'
    return str(param.default)


def _format_signature(obj: object, *, skip_self: bool = True) -> str:
    try:
        sig = inspect.signature(obj)
        s = str(sig)
        if skip_self:
            if s.startswith("(self, "):
                s = "(" + s[7:]
            elif s.startswith("(self)"):
                s = "()" + s[6:]  # keep return annotation if present
        # Normalize forwarded annotations: ': 'str'' -> ': str', '-> 'X'' -> '-> X'
        s = re.sub(r": '([^']*)'", r": \1", s)
        s = re.sub(r"-> '([^']*)'", r"-> \1", s)
        return s
    except (ValueError, TypeError):
        return ""


def _get_dataclass_fields(cls: type) -> list[tuple[str, str]]:
    """Return [(field_name, type_str)] for a dataclass."""
    if not hasattr(cls, "__dataclass_fields__"):
        return []
    result = []
    for name, f in cls.__dataclass_fields__.items():
        anno = getattr(f, "type", None)
        type_str = (
            inspect.formatannotation(anno)
            if anno is not None and anno != inspect.Parameter.empty
            else "Any"
        )
        result.append((name, type_str))
    return result


def _get_type_description(cls: type) -> str:
    """Build description from Attributes section or field names."""
    doc = inspect.getdoc(cls) or ""
    if "Attributes:" in doc:
        match = re.search(r"Attributes:\s*\n(.*?)(?=\n\w+:|$)", doc, re.DOTALL)
        if match:
            lines = [l.strip() for l in match.group(1).splitlines() if l.strip()]
            # Format as "attr: desc" or just "attr1, attr2, ..."
            parts = []
            for line in lines:
                m = re.match(r"(\w+):\s*(.+)", line)
                if m:
                    parts.append(m.group(1))
                else:
                    m2 = re.match(r"(\w+)", line)
                    if m2:
                        parts.append(m2.group(1))
            return ", ".join(parts) if parts else ""
    fields = _get_dataclass_fields(cls)
    return ", ".join(name for name, _ in fields)


def generate_mdx() -> str:
    lines: list[str] = [
        '---',
        'title: "ReflectClient"',
        'description: "API reference for the Reflect Python client."',
        '---',
        "",
        "## Constructor",
        "",
        "```python",
        f"ReflectClient{_format_signature(ReflectClient.__init__)}",
        "```",
        "",
    ]

    # Constructor params table
    sig = inspect.signature(ReflectClient.__init__)
    args_desc = _parse_args_section(inspect.getdoc(ReflectClient.__init__))
    if any(p != "self" for p in sig.parameters):
        lines.append("| Parameter | Type | Default | Description |")
        lines.append("|-----------|------|---------|-------------|")
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            anno = param.annotation
            type_str = (
                inspect.formatannotation(anno)
                if anno != inspect.Parameter.empty
                else ""
            )
            type_str = re.sub(r"^'([^']*)'$", r"\1", type_str)
            default = _format_param_default(param)
            desc = args_desc.get(name, "")
            lines.append(f"| `{name}` | `{type_str}` | `{default}` | {desc} |")
        lines.append("")

    # Instance methods (explicit order for readable flow)
    method_order = [
        "health",
        "query_memories",
        "augment_with_memories",
        "create_trace",
        "list_traces",
        "get_trace",
        "review_trace",
    ]
    methods = {n: m for n, m in inspect.getmembers(ReflectClient, predicate=inspect.isfunction)}
    lines.append("## Instance methods")
    lines.append("")

    for name in method_order:
        method = methods.get(name)
        if not method or name.startswith("_") or name in EXCLUDED_MEMBERS:
            continue
        doc = inspect.getdoc(method) or ""
        summary = _get_summary(doc)
        sig_str = _format_signature(method)
        lines.append(f"### {name}")
        lines.append("")
        lines.append("```python")
        lines.append(f"def {name}{sig_str}")
        lines.append("```")
        lines.append("")
        if summary:
            lines.append(summary)
            lines.append("")

    # Data types
    lines.append("## Data types")
    lines.append("")
    lines.append("| Type | Description |")
    lines.append("|------|-------------|")

    for name, obj in inspect.getmembers(client_module, predicate=inspect.isclass):
        if name in EXCLUDED_TYPES or not hasattr(obj, "__dataclass_fields__"):
            continue
        # Only include types used in the public API we document
        if name in ("Memory", "AugmentedTask", "Trace", "Review"):
            desc = _get_type_description(obj)
            lines.append(f"| `{name}` | {desc} |")

    return "\n".join(lines)


if __name__ == "__main__":
    ReflectClient = client_module.ReflectClient
    output_path = _sdk_root / "docs" / "api-reference" / "reflect-client.mdx"
    output_path.write_text(generate_mdx(), encoding="utf-8")
    print(f"Generated {output_path}")
