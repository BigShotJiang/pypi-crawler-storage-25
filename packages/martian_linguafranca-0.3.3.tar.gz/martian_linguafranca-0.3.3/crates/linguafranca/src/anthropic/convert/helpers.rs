use crate::anthropic::types::*;
use crate::error::WarningAction;
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::types::*;

pub fn image_source_to_url(source: ImageSource) -> String {
    match source {
        ImageSource::Base64 { data, media_type } => format!("data:{media_type};base64,{data}"),
        ImageSource::Url { url } => url,
    }
}

/// Returns `(ImageSource, warning_message)`. The warning is `Some` when the
/// data URL is malformed (missing `;base64,` segment).
pub fn url_to_image_source(url: String) -> (ImageSource, Option<String>) {
    if url.starts_with("data:") {
        let after_data = url.strip_prefix("data:").unwrap_or("");
        if let Some((media_type, data)) = after_data.split_once(";base64,") {
            (
                ImageSource::Base64 {
                    data: data.to_string(),
                    media_type: media_type.to_string(),
                },
                None,
            )
        } else {
            (
                ImageSource::Base64 {
                    data: String::new(),
                    media_type: "application/octet-stream".into(),
                },
                Some("malformed data URL: missing ;base64, segment, using empty data".into()),
            )
        }
    } else {
        (ImageSource::Url { url }, None)
    }
}

pub fn document_source_to_open_responses_file(
    source: DocumentSource,
    title: Option<String>,
) -> InputContentPart {
    match source {
        DocumentSource::Url { url } => InputContentPart::File {
            filename: title,
            file_data: None,
            file_url: Some(url),
        },
        DocumentSource::Base64 { data, .. } | DocumentSource::PlainText { data, .. } => {
            InputContentPart::File {
                filename: title,
                file_data: Some(data),
                file_url: None,
            }
        }
        DocumentSource::Content { content } => match content {
            AnthropicDocumentContent::Text(t) => InputContentPart::Text { text: t },
            AnthropicDocumentContent::Blocks(blocks) => {
                let text = blocks
                    .into_iter()
                    .filter_map(|b| match b {
                        AnthropicInputContentBlock::Text { text, .. } => Some(text),
                        _ => None,
                    })
                    .collect::<Vec<_>>()
                    .join("\n");
                InputContentPart::Text { text }
            }
        },
    }
}

// TODO: consider using tool output blocks for richer search result representation
pub fn search_result_to_text(
    title: String,
    content: Vec<AnthropicSearchResultText>,
) -> InputContentPart {
    let text = std::iter::once(title)
        .chain(content.into_iter().map(|b| b.text))
        .collect::<Vec<_>>()
        .join("\n");
    InputContentPart::Text { text }
}

pub fn open_responses_file_to_document_source(
    file_url: Option<String>,
    file_data: Option<String>,
    filename: Option<&str>,
) -> Option<DocumentSource> {
    match (file_url, file_data) {
        (Some(url), _) => Some(DocumentSource::Url { url }),
        (None, Some(data)) => {
            let media_type = filename
                .map(guess_media_type)
                .unwrap_or_else(|| "text/plain".into());
            Some(DocumentSource::Base64 { data, media_type })
        }
        (None, None) => None,
    }
}

// TODO: rework to properly identify file type — OR doesn't carry media type info,
// so we rely on extension guessing which is fragile and defaults to text/plain.
pub fn guess_media_type(name: &str) -> String {
    let path = name.split('?').next().unwrap_or(name);
    match path.rsplit_once('.').map(|(_, ext)| ext) {
        Some("pdf") => "application/pdf",
        Some("txt" | "md" | "csv" | "json" | "xml" | "html") => "text/plain",
        _ => "text/plain",
    }
    .into()
}

// ── Response / stream shared helpers ──

pub(crate) fn convert_anthropic_messages_citation_to_open_responses(
    citation: AnthropicCitation,
) -> Option<Annotation> {
    match citation {
        AnthropicCitation::WebSearchResultLocation {
            url,
            title,
            cited_text,
            ..
        } => Some(Annotation::UrlCitation {
            url,
            title,
            start_index: 0,
            end_index: cited_text.len() as u64,
        }),
        _ => None,
    }
}

pub(crate) fn convert_open_responses_annotation_to_anthropic_messages(
    ann: Annotation,
) -> AnthropicCitation {
    match ann {
        Annotation::UrlCitation { url, title, .. } => AnthropicCitation::WebSearchResultLocation {
            cited_text: String::new(),
            encrypted_index: String::new(),
            title,
            url,
        },
    }
}

impl From<AnthropicUsage> for Usage {
    fn from(usage: AnthropicUsage) -> Self {
        // Anthropic's `input_tokens` excludes cached tokens, but the Open Responses
        // (OpenAI) convention is that `input_tokens` includes them.  Normalize here
        // so downstream consumers always see `input_tokens >= cached_tokens`.
        //
        // NOTE: `cache_creation_input_tokens` is intentionally not added here because
        // the OR `InputTokensDetails` struct has no corresponding field to carry it.
        // This means OR `input_tokens` may undercount total prompt tokens when cache
        // entries are created on a request.
        let cached = usage.cache_read_input_tokens.unwrap_or(0);
        let total_input = usage.input_tokens + cached;
        Self {
            input_tokens: total_input,
            output_tokens: usage.output_tokens,
            total_tokens: total_input + usage.output_tokens,
            input_tokens_details: usage
                .cache_read_input_tokens
                .map(|cached| InputTokensDetails {
                    cached_tokens: cached,
                }),
            output_tokens_details: None,
        }
    }
}

impl From<Usage> for AnthropicUsage {
    fn from(usage: Usage) -> Self {
        // Reverse of the normalization above: Anthropic expects `input_tokens`
        // to exclude cached tokens.
        let cached = usage
            .input_tokens_details
            .as_ref()
            .map(|d| d.cached_tokens)
            .unwrap_or(0);
        Self {
            input_tokens: usage.input_tokens.saturating_sub(cached),
            output_tokens: usage.output_tokens,
            cache_read_input_tokens: usage.input_tokens_details.map(|d| d.cached_tokens),
            ..Default::default()
        }
    }
}

pub(crate) fn convert_anthropic_messages_stop_reason_to_open_responses(
    reason: Option<AnthropicStopReason>,
) -> (ResponseStatus, Option<IncompleteDetails>) {
    match reason {
        None
        | Some(AnthropicStopReason::EndTurn)
        | Some(AnthropicStopReason::ToolUse)
        | Some(AnthropicStopReason::Refusal) => (ResponseStatus::Completed, None),
        Some(AnthropicStopReason::MaxTokens) => (
            ResponseStatus::Incomplete,
            Some(IncompleteDetails {
                reason: "max_output_tokens".into(),
            }),
        ),
        Some(AnthropicStopReason::StopSequence) => (
            ResponseStatus::Incomplete,
            Some(IncompleteDetails {
                reason: "stop_sequence".into(),
            }),
        ),
        Some(AnthropicStopReason::PauseTurn) => (
            ResponseStatus::Incomplete,
            Some(IncompleteDetails {
                reason: "pause_turn".into(),
            }),
        ),
    }
}

pub(crate) fn convert_open_responses_status_to_anthropic_messages_stop_reason(
    status: ResponseStatus,
    output: &[OutputItem],
    incomplete_details: Option<&IncompleteDetails>,
) -> Option<AnthropicStopReason> {
    match status {
        ResponseStatus::Completed => {
            let last_is_function_call = output
                .last()
                .is_some_and(|item| matches!(item, OutputItem::FunctionCall { .. }));
            if last_is_function_call {
                Some(AnthropicStopReason::ToolUse)
            } else {
                Some(AnthropicStopReason::EndTurn)
            }
        }
        ResponseStatus::Incomplete => match incomplete_details.map(|d| d.reason.as_str()) {
            Some("stop_sequence") => Some(AnthropicStopReason::StopSequence),
            Some("pause_turn") => Some(AnthropicStopReason::PauseTurn),
            _ => Some(AnthropicStopReason::MaxTokens),
        },
        ResponseStatus::Failed => Some(AnthropicStopReason::EndTurn),
        ResponseStatus::InProgress | ResponseStatus::Queued => None,
    }
}

pub(crate) fn build_open_responses_response_snapshot(
    id: String,
    model: String,
    status: ResponseStatus,
    output: Vec<OutputItem>,
    usage: Option<Usage>,
    incomplete_details: Option<IncompleteDetails>,
    service_tier: Option<ServiceTier>,
) -> OpenResponsesResponse {
    OpenResponsesResponse {
        id,
        object: "response".into(),
        // TODO: AM doesn't return a timestamp — consider using current time here
        created_at: 0,
        status,
        model,
        output,
        usage,
        incomplete_details,
        service_tier,
        ..Default::default()
    }
}

pub(crate) fn convert_web_search_results(
    content: Vec<AnthropicWebSearchToolResultItem>,
    ctx: &mut crate::anthropic::convert::ctx::ConversionCtx,
) -> (WebSearchCallStatus, Vec<WebSearchSource>) {
    let has_error = content
        .iter()
        .any(|item| matches!(item, AnthropicWebSearchToolResultItem::Error { .. }));
    if has_error {
        return (WebSearchCallStatus::Failed, vec![]);
    }
    let sources = content
        .into_iter()
        .filter_map(|item| match item {
            AnthropicWebSearchToolResultItem::WebSearchResult {
                url,
                title,
                encrypted_content,
                page_age,
            } => {
                if !title.is_empty() {
                    ctx.warn(
                        "web_search_result.title",
                        WarningAction::Dropped,
                        "not supported in Open Responses",
                    );
                }
                if !encrypted_content.is_empty() {
                    ctx.warn(
                        "web_search_result.encrypted_content",
                        WarningAction::Dropped,
                        "not supported in Open Responses",
                    );
                }
                if page_age.is_some() {
                    ctx.warn(
                        "web_search_result.page_age",
                        WarningAction::Dropped,
                        "not supported in Open Responses",
                    );
                }
                Some(WebSearchSource {
                    source_type: "url".into(),
                    url,
                })
            }
            _ => None,
        })
        .collect();
    (WebSearchCallStatus::Completed, sources)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_data_url_parses_without_warning() {
        let (source, warn) = url_to_image_source("data:image/png;base64,iVBORw0KGgo=".into());
        assert!(warn.is_none());
        match source {
            ImageSource::Base64 { data, media_type } => {
                assert_eq!(media_type, "image/png");
                assert_eq!(data, "iVBORw0KGgo=");
            }
            other => panic!("expected Base64, got {other:?}"),
        }
    }

    #[test]
    fn malformed_data_url_returns_warning() {
        let (source, warn) = url_to_image_source("data:not-valid-at-all".into());
        assert!(warn.is_some());
        assert!(warn.unwrap().contains("malformed"));
        match source {
            ImageSource::Base64 { data, media_type } => {
                assert!(data.is_empty());
                assert_eq!(media_type, "application/octet-stream");
            }
            other => panic!("expected Base64, got {other:?}"),
        }
    }

    #[test]
    fn regular_url_passes_through() {
        let (source, warn) = url_to_image_source("https://example.com/img.png".into());
        assert!(warn.is_none());
        match source {
            ImageSource::Url { url } => assert_eq!(url, "https://example.com/img.png"),
            other => panic!("expected Url, got {other:?}"),
        }
    }

    #[test]
    fn image_source_roundtrip() {
        let original = "data:image/jpeg;base64,/9j/4AAQ";
        let (source, _) = url_to_image_source(original.into());
        let url = image_source_to_url(source);
        assert_eq!(url, original);
    }
}
