use crate::anthropic::convert::config::AnthropicConvertConfig;

pub(crate) type ConversionCtx = crate::convert::ctx::ConversionCtx<AnthropicConvertConfig>;
