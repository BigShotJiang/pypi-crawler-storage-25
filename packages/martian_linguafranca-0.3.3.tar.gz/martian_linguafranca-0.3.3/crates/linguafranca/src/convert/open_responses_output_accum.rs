use crate::open_responses::types::*;

/// Accumulates Open Responses output items while buffering content parts.
///
/// Anthropic Messages responses are a flat `Vec<OutputContentBlock>`. Open Responses splits them:
/// text parts become an `OutputItem::Message`, tool calls become separate
/// `FunctionCall` items, reasoning becomes `Reasoning` items.
/// This accumulator buffers content parts and flushes them into a Message
/// whenever a non-content item appears.
pub(crate) struct OpenResponsesOutputAccum {
    items: Vec<OutputItem>,
    pending_parts: Vec<ContentPart>,
    message_index: usize,
}

impl OpenResponsesOutputAccum {
    pub(crate) fn new() -> Self {
        Self {
            items: Vec::new(),
            pending_parts: Vec::new(),
            message_index: 0,
        }
    }

    pub(crate) fn push_content_part(&mut self, part: ContentPart) {
        self.pending_parts.push(part);
    }

    /// Drain pending content parts into an `OutputItem::Message`.
    pub(crate) fn flush_message(&mut self) {
        if self.pending_parts.is_empty() {
            return;
        }
        let id = format!("msg_{}", self.message_index);
        self.message_index += 1;
        self.items.push(OutputItem::Message {
            id,
            status: ItemStatus::Completed,
            role: MessageRole::Assistant,
            content: std::mem::take(&mut self.pending_parts),
        });
    }

    /// Flush pending parts then push a standalone item.
    pub(crate) fn push_item(&mut self, item: OutputItem) {
        self.flush_message();
        self.items.push(item);
    }

    pub(crate) fn into_items(self) -> Vec<OutputItem> {
        debug_assert!(
            self.pending_parts.is_empty(),
            "OpenResponsesOutputAccum has unflushed parts - call flush_message() before into_items()"
        );
        self.items
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn single_text_flushes_as_message() {
        let mut accum = OpenResponsesOutputAccum::new();
        accum.push_content_part(ContentPart::OutputText {
            text: "hello".into(),
            annotations: vec![],
            logprobs: vec![],
        });
        accum.flush_message();

        let items = accum.into_items();
        assert_eq!(items.len(), 1);
        match &items[0] {
            OutputItem::Message { content, role, .. } => {
                assert_eq!(*role, MessageRole::Assistant);
                assert_eq!(content.len(), 1);
            }
            other => panic!("expected Message, got {other:?}"),
        }
    }

    #[test]
    fn push_item_flushes_pending() {
        let mut accum = OpenResponsesOutputAccum::new();
        accum.push_content_part(ContentPart::OutputText {
            text: "before".into(),
            annotations: vec![],
            logprobs: vec![],
        });
        accum.push_item(OutputItem::FunctionCall {
            id: "fc_0".into(),
            call_id: "call_1".into(),
            name: "func".into(),
            arguments: "{}".into(),
            status: ItemStatus::Completed,
        });

        let items = accum.into_items();
        assert_eq!(items.len(), 2);
        assert!(matches!(&items[0], OutputItem::Message { .. }));
        assert!(matches!(&items[1], OutputItem::FunctionCall { .. }));
    }

    #[test]
    fn empty_flush_is_noop() {
        let mut accum = OpenResponsesOutputAccum::new();
        accum.flush_message();
        assert!(accum.into_items().is_empty());
    }

    #[test]
    fn message_ids_increment() {
        let mut accum = OpenResponsesOutputAccum::new();
        accum.push_content_part(ContentPart::OutputText {
            text: "a".into(),
            annotations: vec![],
            logprobs: vec![],
        });
        accum.flush_message();
        accum.push_content_part(ContentPart::OutputText {
            text: "b".into(),
            annotations: vec![],
            logprobs: vec![],
        });
        accum.flush_message();

        let items = accum.into_items();
        match (&items[0], &items[1]) {
            (OutputItem::Message { id: id0, .. }, OutputItem::Message { id: id1, .. }) => {
                assert_eq!(id0, "msg_0");
                assert_eq!(id1, "msg_1");
            }
            _ => panic!("expected two Messages"),
        }
    }
}
