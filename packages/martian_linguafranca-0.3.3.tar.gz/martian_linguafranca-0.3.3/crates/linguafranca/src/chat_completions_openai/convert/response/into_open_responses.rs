use crate::chat_completions_openai::convert::mapping::{
    chat_completions_finish_reason_to_open_responses_status,
    warn_dropped_chat_completions_usage_details,
};
use crate::chat_completions_openai::convert::stream::ToolCallKind;
use crate::chat_completions_openai::response::{
    ChatCompletionsChoice, ChatCompletionsOpenAiResponse,
};
use crate::chat_completions_openai::types::*;
use crate::config::ConversionConfig;
use crate::convert::ctx::ConversionCtx;
use crate::error::{ConversionError, ConversionResult, WarningAction};
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::types::*;
use crate::traits::IntoOpenResponses;

type Ctx = ConversionCtx<()>;

impl IntoOpenResponses for ChatCompletionsOpenAiResponse {
    type Target = OpenResponsesResponse;

    fn into_open_responses(
        self,
        _config: Option<ConversionConfig>,
    ) -> Result<ConversionResult<OpenResponsesResponse>, ConversionError> {
        let mut ctx = Ctx::new();

        let mut choices = self.choices;
        if choices.is_empty() {
            return Err(ConversionError::InvalidInput(
                "chat completions response has no choices".into(),
            ));
        }
        if choices.len() > 1 {
            ctx.warn(
                "choices",
                WarningAction::Dropped,
                "multiple choices are not representable in Open Responses response; only the first choice was used",
            );
        }

        let choice = choices.swap_remove(0);
        if choice.logprobs.is_some() {
            ctx.warn(
                "choices[0].logprobs",
                WarningAction::Dropped,
                "choice-level logprobs are not supported in Open Responses response",
            );
        }

        let (status, incomplete_details) = if choice.finish_reason.is_none() {
            ctx.warn(
                "choices[0].finish_reason",
                WarningAction::Dropped,
                "missing in non-streaming Chat Completions response; emitted response as incomplete",
            );
            (
                ResponseStatus::Incomplete,
                Some(IncompleteDetails {
                    reason: "missing_finish_reason".into(),
                }),
            )
        } else {
            chat_completions_finish_reason_to_open_responses_status(choice.finish_reason.clone())
        };
        let output = convert_choice_to_open_responses_output(choice, &mut ctx);
        let usage = self.usage.map(|usage| {
            warn_dropped_chat_completions_usage_details(&usage, &mut ctx, "usage");
            usage.into()
        });

        let mut result = ConversionResult::with_warnings(
            OpenResponsesResponse {
                id: self.id,
                object: "response".into(),
                created_at: self.created,
                status,
                model: self.model,
                output,
                incomplete_details,
                usage,
                service_tier: self
                    .service_tier
                    .and_then(|tier| convert_service_tier_to_open_responses(tier, &mut ctx)),
                ..Default::default()
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Open Responses",
            &[("system_fingerprint", self.system_fingerprint.is_some())],
        );

        Ok(result)
    }
}

fn convert_choice_to_open_responses_output(
    choice: ChatCompletionsChoice,
    ctx: &mut Ctx,
) -> Vec<OutputItem> {
    let mut output = Vec::new();

    let ChatCompletionsChoice { message, .. } = choice;

    let mut message_parts = Vec::new();

    if message.role != "assistant" {
        ctx.warn(
            "choices[0].message.role",
            WarningAction::Changed,
            "non-assistant response role is not valid for Open Responses output and was coerced to assistant",
        );
    }

    if let Some(content) = message.content {
        message_parts.push(ContentPart::OutputText {
            text: content,
            annotations: message
                .annotations
                .into_iter()
                .map(convert_chat_completions_annotation_to_open_responses)
                .collect(),
            logprobs: vec![],
        });
    } else if !message.annotations.is_empty() {
        ctx.warn(
            "choices[0].message.annotations",
            WarningAction::Dropped,
            "annotations without message content are not representable in Open Responses response",
        );
    }

    if let Some(refusal) = message.refusal {
        message_parts.push(ContentPart::Refusal { refusal });
    }

    if !message_parts.is_empty() {
        output.push(OutputItem::Message {
            id: "msg_0".into(),
            status: ItemStatus::Completed,
            role: MessageRole::Assistant,
            content: message_parts,
        });
    }

    if let Some(tool_calls) = message.tool_calls {
        for (i, tool_call) in tool_calls.into_iter().enumerate() {
            ctx.push(format!("choices[0].message.tool_calls[{i}]"));
            if let Some(item) =
                convert_chat_completions_tool_call_to_open_responses(tool_call, i, ctx)
            {
                output.push(item);
            }
            ctx.pop();
        }
    }

    if let Some(reasoning_content) = message.reasoning_content
        && !reasoning_content.is_empty()
    {
        output.push(OutputItem::Reasoning {
            id: "rs_0".into(),
            summary: vec![ContentPart::SummaryText {
                text: reasoning_content,
            }],
            content: None,
            encrypted_content: None,
        });
    }

    if message.audio.is_some() {
        ctx.warn(
            "choices[0].message.audio",
            WarningAction::Dropped,
            "audio output is not supported in Open Responses response",
        );
    }

    output
}

fn convert_chat_completions_tool_call_to_open_responses(
    tool_call: ChatCompletionsToolCall,
    index: usize,
    _ctx: &mut Ctx,
) -> Option<OutputItem> {
    match tool_call {
        ChatCompletionsToolCall::Function { id, function } => Some(OutputItem::FunctionCall {
            id: format!("{}_{}", ToolCallKind::Function.item_id_prefix(), index),
            call_id: id,
            name: function.name,
            arguments: function.arguments,
            status: ItemStatus::Completed,
        }),
        ChatCompletionsToolCall::Custom { id, custom } => Some(OutputItem::CustomToolCall {
            id: format!("{}_{}", ToolCallKind::Custom.item_id_prefix(), index),
            call_id: id,
            name: custom.name,
            input: custom.input,
            status: ItemStatus::Completed,
        }),
    }
}

fn convert_chat_completions_annotation_to_open_responses(
    ann: ChatCompletionsAnnotation,
) -> Annotation {
    match ann {
        ChatCompletionsAnnotation::UrlCitation { url_citation } => Annotation::UrlCitation {
            url: url_citation.url,
            title: url_citation.title,
            start_index: url_citation.start_index,
            end_index: url_citation.end_index,
        },
    }
}

fn convert_service_tier_to_open_responses(tier: String, ctx: &mut Ctx) -> Option<ServiceTier> {
    match tier.as_str() {
        "auto" => Some(ServiceTier::Auto),
        "default" => Some(ServiceTier::Default),
        "flex" => Some(ServiceTier::Flex),
        "priority" => Some(ServiceTier::Priority),
        "scale" => {
            ctx.warn(
                "service_tier",
                WarningAction::Changed,
                "service_tier=scale is not available in Open Responses and was mapped to priority",
            );
            Some(ServiceTier::Priority)
        }
        _ => {
            ctx.warn(
                "service_tier",
                WarningAction::Dropped,
                format!("unknown service_tier '{tier}'"),
            );
            None
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn missing_finish_reason_maps_to_incomplete_with_warning() {
        let converted = ChatCompletionsOpenAiResponse {
            id: "chatcmpl_1".into(),
            object: "chat.completion".into(),
            created: 1,
            model: "gpt-4o".into(),
            choices: vec![ChatCompletionsChoice {
                index: 0,
                message:
                    crate::chat_completions_openai::response::ChatCompletionsAssistantMessage {
                        role: "assistant".into(),
                        content: Some("still generating".into()),
                        tool_calls: None,
                        refusal: None,
                        reasoning_content: None,
                        annotations: vec![],
                        audio: None,
                    },
                finish_reason: None,
                logprobs: None,
            }],
            usage: None,
            system_fingerprint: None,
            service_tier: None,
        }
        .into_open_responses(None)
        .expect("conversion should succeed");

        assert_eq!(converted.value.status, ResponseStatus::Incomplete);
        assert_eq!(
            converted
                .value
                .incomplete_details
                .as_ref()
                .map(|details| details.reason.as_str()),
            Some("missing_finish_reason")
        );
        assert_eq!(converted.warnings.len(), 1);
        assert_eq!(converted.warnings[0].field, "choices[0].finish_reason");
    }
}
