use std::path::{Path, PathBuf};

use linguafranca::anthropic::convert::stream::{
    AnthropicMessagesToOpenResponsesStream, OpenResponsesToAnthropicMessagesStream,
};
use linguafranca::anthropic::request::AnthropicRequest;
use linguafranca::anthropic::response::AnthropicResponse;
use linguafranca::open_responses::request::OpenResponsesRequest;
use linguafranca::open_responses::response::OpenResponsesResponse;
use rstest::rstest;

mod common;

fn diffs_dir() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/diffs")
}

fn case_name(path: &Path) -> &str {
    path.parent()
        .unwrap()
        .file_name()
        .unwrap()
        .to_str()
        .unwrap()
}

// ── Anthropic Messages round-trips ──

#[rstest]
fn am_request_round_trip(
    #[files("tests/fixtures/anthropic_messages/request/*/messages.json")]
    #[exclude("web_search_history")]
    // tool_search round-trip is lossy: tool_reference blocks inside tool_result
    // are split into separate ToolSearchOutput items, and server-side
    // tool_search_tool_result structure is not reconstructed identically.
    #[exclude("tool_search")]
    path: PathBuf,
) {
    let case = case_name(&path);
    let fwd = common::load_diffs(&diffs_dir().join("anthropic_messages/request_to_or.json"));
    let rev = common::load_diffs(&diffs_dir().join("anthropic_messages/request_from_or.json"));
    common::run_round_trip_case::<AnthropicRequest, OpenResponsesRequest>(
        case,
        &path,
        &fwd,
        &rev,
        &format!("{case} AM request round-trip"),
    );
}

#[rstest]
fn am_response_round_trip(
    #[files("tests/fixtures/anthropic_messages/response/*/messages.json")] path: PathBuf,
) {
    let case = case_name(&path);
    let fwd = common::load_diffs(&diffs_dir().join("anthropic_messages/response_to_or.json"));
    let rev = common::load_diffs(&diffs_dir().join("anthropic_messages/response_from_or.json"));
    common::run_round_trip_case::<AnthropicResponse, OpenResponsesResponse>(
        case,
        &path,
        &fwd,
        &rev,
        &format!("{case} AM response round-trip"),
    );
}

#[rstest]
fn am_stream_round_trip(
    #[files("tests/fixtures/anthropic_messages/stream/*/messages_events.json")]
    // tool_search round-trip is lossy: tool_search_tool_result structure is
    // not reconstructed identically from ToolSearchCall + ToolSearchOutput.
    #[exclude("tool_search")]
    path: PathBuf,
) {
    let case = case_name(&path);
    let fwd = common::load_diffs(&diffs_dir().join("anthropic_messages/stream_to_or.json"));
    let rev = common::load_diffs(&diffs_dir().join("anthropic_messages/stream_from_or.json"));
    common::run_round_trip_stream_case(
        case,
        &path,
        AnthropicMessagesToOpenResponsesStream::new(),
        OpenResponsesToAnthropicMessagesStream::new(),
        &fwd,
        &rev,
        &format!("{case} AM stream round-trip"),
    );
}
