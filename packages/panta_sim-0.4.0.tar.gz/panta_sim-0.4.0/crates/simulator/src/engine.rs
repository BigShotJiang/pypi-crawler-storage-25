use qsim_core::complex::Real;
use qsim_core::noise::apply_kraus_single_qubit;
use qsim_core::operations::{
    apply_controlled_gate, apply_controlled_swap, apply_doubly_controlled_gate,
    apply_single_qubit_gate, apply_two_qubit_gate,
};
use qsim_core::{Gate, StateVector};
use rand::rngs::StdRng;
use rand::SeedableRng;

use crate::circuit::Circuit;
use crate::instruction::Instruction;
use crate::measurement;
use crate::result::{Precision, SimulationResult};

/// 회로 실행 엔진.
pub struct ExecutionEngine {
    seed: Option<u64>,
    precision: Precision,
}

impl ExecutionEngine {
    pub fn new() -> Self {
        Self {
            seed: None,
            precision: Precision::default(),
        }
    }

    /// 재현 가능한 결과를 위한 시드 설정.
    pub fn with_seed(seed: u64) -> Self {
        Self {
            seed: Some(seed),
            precision: Precision::default(),
        }
    }

    /// 정밀도를 설정한 새 엔진 반환 (builder 패턴).
    pub fn with_precision(mut self, precision: Precision) -> Self {
        self.precision = precision;
        self
    }

    /// 회로를 실행하고 결과를 반환한다. 정밀도에 따라 f32 / f64 경로로 dispatch.
    pub fn run(&self, circuit: &Circuit, shots: usize) -> SimulationResult {
        match self.precision {
            Precision::F64 => {
                let (counts, sv) = self.run_typed::<f64>(circuit, shots);
                SimulationResult::F64 {
                    counts,
                    statevector: sv,
                }
            }
            Precision::F32 => {
                let (counts, sv) = self.run_typed::<f32>(circuit, shots);
                SimulationResult::F32 {
                    counts,
                    statevector: sv,
                }
            }
        }
    }

    /// 정밀도 `F` 로 회로 실행. f32/f64 경로 모두 동일 코드 (monomorphized).
    ///
    /// 회로에 [`Instruction::ApplyNoise`] 가 하나라도 있으면 **trajectory 모드** 로
    /// 전환된다 (각 shot 마다 회로를 처음부터 재실행, 단일 측정). noise 가 없으면
    /// 기존 fast path (1회 unitary evolution + N shot 샘플링) 를 유지한다.
    ///
    /// 반환되는 statevector 는 noise 가 있으면 *마지막 trajectory* 의 것 (디버깅 용,
    /// mixed state 를 대표하지 않음 — 사용자는 counts 를 사용).
    fn run_typed<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut rng = match self.seed {
            Some(seed) => StdRng::seed_from_u64(seed),
            None => StdRng::from_entropy(),
        };

        let has_noise = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::ApplyNoise { .. }));

        if has_noise {
            self.run_typed_trajectory::<F>(circuit, shots, &mut rng)
        } else {
            self.run_typed_unitary::<F>(circuit, shots, &mut rng)
        }
    }

    /// Noise 없는 경로 (fast): 1회 evolution → N shot 샘플링.
    fn run_typed_unitary<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
        rng: &mut StdRng,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut state: StateVector<F> = StateVector::new(circuit.num_qubits());
        let mut has_measurement = false;

        for inst in circuit.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    apply_gate_typed(&mut state, gate, targets);
                }
                Instruction::ApplyNoise { .. } => {
                    unreachable!("run_typed_unitary called with noise instruction")
                }
                Instruction::Measure { .. } | Instruction::MeasureAll => {
                    has_measurement = true;
                }
            }
        }

        apply_global_phase::<F>(&mut state, circuit.global_phase());

        let counts = if has_measurement && shots > 0 {
            measurement::sample(&state, shots, rng)
        } else {
            std::collections::HashMap::new()
        };

        (counts, state)
    }

    /// Noise 있는 경로 (trajectory): shot 마다 회로 재실행 + 단일 측정.
    ///
    /// `shots == 0` 이면 단일 trajectory 만 실행하고 counts 는 비워서 반환 (statevector
    /// 디버깅 용도). `shots > 0` 이면 각 trajectory 마다 한 번 측정해 counts 누적.
    fn run_typed_trajectory<F: Real>(
        &self,
        circuit: &Circuit,
        shots: usize,
        rng: &mut StdRng,
    ) -> (std::collections::HashMap<String, usize>, StateVector<F>) {
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut last_state: Option<StateVector<F>> = None;

        let has_measurement = circuit
            .instructions()
            .iter()
            .any(|i| matches!(i, Instruction::Measure { .. } | Instruction::MeasureAll));

        let n_trajectories = if shots == 0 { 1 } else { shots };
        let lambda = circuit.global_phase();

        for _ in 0..n_trajectories {
            let mut state: StateVector<F> = StateVector::new(circuit.num_qubits());
            for inst in circuit.instructions() {
                match inst {
                    Instruction::ApplyGate { gate, targets } => {
                        apply_gate_typed(&mut state, gate, targets);
                    }
                    Instruction::ApplyNoise { channel, target } => {
                        let kraus = channel.kraus_operators::<F>();
                        apply_kraus_single_qubit(&mut state, &kraus, *target, rng);
                    }
                    Instruction::Measure { .. } | Instruction::MeasureAll => {
                        // trajectory 끝에서 단일 측정 (mid-circuit 은 v0.4.5).
                    }
                }
            }
            apply_global_phase::<F>(&mut state, lambda);

            if has_measurement && shots > 0 {
                let outcome = measurement::sample_once(&state, rng);
                *counts.entry(outcome).or_insert(0) += 1;
            }

            last_state = Some(state);
        }

        (counts, last_state.expect("at least one trajectory"))
    }
}

fn apply_global_phase<F: Real>(state: &mut StateVector<F>, lambda: f64) {
    if lambda != 0.0 {
        let phase = qsim_core::complex::complex::<F>(lambda.cos(), lambda.sin());
        for amp in state.amplitudes_mut() {
            *amp = *amp * phase;
        }
    }
}

impl Default for ExecutionEngine {
    fn default() -> Self {
        Self::new()
    }
}

/// generic 게이트 적용. f32/f64 양쪽에 monomorphize 된다.
fn apply_gate_typed<F: Real>(state: &mut StateVector<F>, gate: &Gate, targets: &[usize]) {
    match gate {
        // 단일 큐비트 게이트
        Gate::H
        | Gate::X
        | Gate::Y
        | Gate::Z
        | Gate::S
        | Gate::Sdg
        | Gate::T
        | Gate::Tdg
        | Gate::Rx(_)
        | Gate::Ry(_)
        | Gate::Rz(_)
        | Gate::U(_, _, _)
        | Gate::Id => {
            let matrix = gate.matrix_2x2::<F>();
            apply_single_qubit_gate(state, &matrix, targets[0]);
        }
        // 2큐비트 게이트
        Gate::CNOT => {
            let x = Gate::X.matrix_2x2::<F>();
            apply_controlled_gate(state, &x, targets[0], targets[1]);
        }
        Gate::CZ => {
            let cz = Gate::cz_matrix::<F>();
            apply_two_qubit_gate(state, &cz, targets[0], targets[1]);
        }
        Gate::SWAP => {
            let swap = Gate::swap_matrix::<F>();
            apply_two_qubit_gate(state, &swap, targets[0], targets[1]);
        }
        // 3큐비트 게이트
        Gate::Toffoli => {
            let x = Gate::X.matrix_2x2::<F>();
            apply_doubly_controlled_gate(state, &x, targets[0], targets[1], targets[2]);
        }
        Gate::Fredkin => {
            apply_controlled_swap(state, targets[0], targets[1], targets[2]);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use qsim_core::complex::approx_eq;
    use qsim_core::C64;

    #[test]
    fn test_bell_circuit_execution() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 1000);

        let counts = result.counts();
        assert!(counts.contains_key("00"));
        assert!(counts.contains_key("11"));
        assert!(!counts.contains_key("01"));
        assert!(!counts.contains_key("10"));

        let expected = C64::new(std::f64::consts::FRAC_1_SQRT_2, 0.0);
        let sv = result.statevector_f64().expect("default precision is f64");
        assert!(approx_eq(sv.amplitudes()[0], expected, 1e-10));
        assert!(approx_eq(sv.amplitudes()[3], expected, 1e-10));
    }

    #[test]
    fn test_bell_circuit_execution_f32() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42).with_precision(Precision::F32);
        let result = engine.run(&circuit, 1000);

        assert_eq!(result.precision(), Precision::F32);
        let counts = result.counts();
        assert!(counts.contains_key("00"));
        assert!(counts.contains_key("11"));

        let sv = result.statevector_f32().expect("expected f32 statevector");
        let expected = num_complex::Complex::new(std::f32::consts::FRAC_1_SQRT_2, 0.0);
        assert!(approx_eq(sv.amplitudes()[0], expected, 1e-6_f32));
        assert!(approx_eq(sv.amplitudes()[3], expected, 1e-6_f32));
    }

    #[test]
    fn test_ghz_circuit_execution() {
        let mut circuit = Circuit::new(3);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.cx(0, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(123);
        let result = engine.run(&circuit, 2000);

        let counts = result.counts();
        assert!(counts.contains_key("000"));
        assert!(counts.contains_key("111"));
        let total: usize = counts.values().sum();
        assert_eq!(total, 2000);
        for key in counts.keys() {
            assert!(key == "000" || key == "111", "unexpected outcome: {key}");
        }
    }

    #[test]
    fn test_toffoli_circuit() {
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(1);
        circuit.ccx(0, 1, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        let counts = result.counts();
        assert_eq!(counts.get("111"), Some(&100));
    }

    #[test]
    fn test_swap_circuit() {
        let mut circuit = Circuit::new(2);
        circuit.x(0);
        circuit.swap(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        assert_eq!(result.counts().get("10"), Some(&100));
    }

    #[test]
    fn test_no_measurement_empty_counts() {
        let mut circuit = Circuit::new(1);
        circuit.h(0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 100);

        assert!(result.counts().is_empty());
    }

    #[test]
    fn test_statevector_without_measurement() {
        let mut circuit = Circuit::new(1);
        circuit.x(0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 0);

        let sv = result.statevector_f64().unwrap();
        assert!(approx_eq(
            sv.amplitudes()[1],
            qsim_core::complex::ONE,
            1e-10
        ));
    }

    #[test]
    fn test_rotation_gate_circuit() {
        use std::f64::consts::PI;

        let mut circuit = Circuit::new(1);
        circuit.rx(PI, 0);

        let engine = ExecutionEngine::new();
        let result = engine.run(&circuit, 0);

        let sv = result.statevector_f64().unwrap();
        assert!((sv.probability(0)).abs() < 1e-10);
        assert!((sv.probability(1) - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_fredkin_circuit() {
        let mut circuit = Circuit::new(3);
        circuit.x(0);
        circuit.x(2);
        circuit.cswap(0, 1, 2);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);

        assert_eq!(result.counts().get("011"), Some(&100));
    }

    #[test]
    fn test_bell_state_statistical_distribution() {
        let mut circuit = Circuit::new(2);
        circuit.h(0);
        circuit.cx(0, 1);
        circuit.measure_all();

        let engine = ExecutionEngine::with_seed(999);
        let result = engine.run(&circuit, 10000);

        let counts = result.counts();
        let c00 = *counts.get("00").unwrap_or(&0) as f64;
        let c11 = *counts.get("11").unwrap_or(&0) as f64;
        let ratio = c00 / (c00 + c11);
        assert!(ratio > 0.45 && ratio < 0.55, "ratio was {ratio}");
    }

    #[test]
    fn test_precision_default_is_f64() {
        let engine = ExecutionEngine::new();
        let mut circuit = Circuit::new(1);
        circuit.h(0);
        let result = engine.run(&circuit, 0);
        assert_eq!(result.precision(), Precision::F64);
    }

    // ========================================================================
    // v0.4 noise integration tests
    // ========================================================================

    #[test]
    fn test_noise_p_zero_is_identity() {
        // BitFlip(p=0) 는 항상 identity → Bell 회로 결과 변동 없음.
        let mut clean = Circuit::new(2);
        clean.h(0);
        clean.cx(0, 1);
        clean.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let baseline = engine.run(&clean, 1000);

        let mut noisy = Circuit::new(2);
        noisy.h(0);
        noisy.add_noise(qsim_core::NoiseChannel::BitFlip { p: 0.0 }, 0);
        noisy.cx(0, 1);
        noisy.add_noise(qsim_core::NoiseChannel::BitFlip { p: 0.0 }, 1);
        noisy.measure_all();
        let result = engine.run(&noisy, 1000);

        let counts = result.counts();
        // p=0 이면 baseline 과 동일 분포 (ApplyNoise 가 RNG 를 한 번 더 소비하므로
        // shot RNG sequence 가 달라질 수 있어 정확 동일 비교는 안 됨 — Bell 분포만 검증).
        assert!(counts.contains_key("00") && counts.contains_key("11"));
        assert!(!counts.contains_key("01") && !counts.contains_key("10"));
        let total: usize = counts.values().sum();
        assert_eq!(total, 1000);
        let _ = baseline; // 사용. 비교는 아니지만 회로 빌드 검증.
    }

    #[test]
    fn test_noise_bit_flip_p_one_flips_state() {
        // BitFlip(p=1) on |0⟩: 항상 X 적용 → 측정 시 항상 "1".
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::BitFlip { p: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("1"), Some(&100));
    }

    #[test]
    fn test_noise_amplitude_damping_gamma_one() {
        // |1⟩ 에 AmplitudeDamping(γ=1) → |0⟩ 강제. 측정 시 항상 "0".
        let mut circuit = Circuit::new(1);
        circuit.x(0);
        circuit.add_noise(qsim_core::NoiseChannel::AmplitudeDamping { gamma: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(42);
        let result = engine.run(&circuit, 100);
        assert_eq!(result.counts().get("0"), Some(&100));
    }

    #[test]
    fn test_noise_depolarizing_statistical() {
        // Depolarizing(p=1) on |0⟩: 4 outcome {I, X, Y, Z} 균등.
        // I: |0⟩, X: |1⟩, Y: i|1⟩, Z: |0⟩ (단 |0⟩ 이므로 Z 도 |0⟩).
        // → 측정 시 "0" 50%, "1" 50%.
        let mut circuit = Circuit::new(1);
        circuit.add_noise(qsim_core::NoiseChannel::Depolarizing { p: 1.0 }, 0);
        circuit.measure_all();
        let engine = ExecutionEngine::with_seed(2024);
        let result = engine.run(&circuit, 10_000);
        let c0 = *result.counts().get("0").unwrap_or(&0) as f64;
        let c1 = *result.counts().get("1").unwrap_or(&0) as f64;
        let ratio = c0 / (c0 + c1);
        // Each shot rebuilds state from |0⟩ then noise → I/X/Y/Z 각각 25%.
        // I, Z → "0" / X, Y → "1" → 50% 50% 기대. 3σ binomial bound ≈ 0.015.
        assert!(
            (ratio - 0.5).abs() < 0.02,
            "Depolarizing(p=1) ratio {ratio} 가 0.5 와 너무 다름"
        );
    }
}
