"""Codebase analysis utilities."""
