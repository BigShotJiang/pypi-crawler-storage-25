# Exceptions

::: cyhole.helius.exception
