"""Thin Google Drive API client for Google Workspace roundtrips.

This mirrors the stdlib-HTTP plumbing used by ``openxml-audit``: upload a
local Office/ODF package, copy it into Google's native format, then export it
back. Authentication is intentionally explicit and headless: service-account
credentials plus optional domain-wide delegation.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from typing import Any as Credentials


PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

ODP_MIME = "application/vnd.oasis.opendocument.presentation"
ODT_MIME = "application/vnd.oasis.opendocument.text"
ODS_MIME = "application/vnd.oasis.opendocument.spreadsheet"

SLIDES_MIME = "application/vnd.google-apps.presentation"
DOC_MIME = "application/vnd.google-apps.document"
SHEET_MIME = "application/vnd.google-apps.spreadsheet"

DEFAULT_CREDS_PATH = (
    Path.home() / ".config" / "tokenmoulds" / "google_service_account.json"
)
DEFAULT_SCOPES = ("https://www.googleapis.com/auth/drive",)

_DRIVE_API = "https://www.googleapis.com/drive/v3"
_UPLOAD_API = "https://www.googleapis.com/upload/drive/v3"


class GSuiteError(Exception):
    """Base class for Google Workspace roundtrip errors."""


class GSuiteAuthError(GSuiteError):
    """Authentication or authorization failure."""


class _UrllibAuthResponse:
    """Response shape expected by google-auth transports."""

    def __init__(self, status: int, headers: Any, data: bytes) -> None:
        self.status = status
        self.headers = headers
        self.data = data


class _UrllibAuthTransport:
    """Minimal urllib-backed transport for google-auth token refresh."""

    def __call__(
        self,
        url: str,
        method: str = "GET",
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = 60.0,
        **_kwargs: Any,
    ) -> _UrllibAuthResponse:
        request = urllib.request.Request(url, data=body, method=method)
        for key, value in (headers or {}).items():
            request.add_header(key, value)
        try:
            response = urllib.request.urlopen(request, timeout=timeout)
            return _UrllibAuthResponse(
                response.status, response.headers, response.read()
            )
        except urllib.error.HTTPError as exc:
            return _UrllibAuthResponse(exc.code, exc.headers, exc.read())


class GSuiteClient:
    """Small Drive API wrapper for upload/import/export/delete."""

    def __init__(
        self,
        credentials: "Credentials",
        *,
        subject: str | None = None,
    ) -> None:
        self._creds = credentials
        self._subject = subject
        self._auth_transport = _UrllibAuthTransport()

    @property
    def subject(self) -> str | None:
        """Impersonated Workspace user, if domain-wide delegation is active."""
        return self._subject

    @classmethod
    def from_service_account(
        cls,
        creds_path: Path | str | None = None,
        *,
        subject: str | None = None,
        scopes: tuple[str, ...] = DEFAULT_SCOPES,
    ) -> "GSuiteClient":
        """Build a client from a service-account JSON key.

        Environment fallbacks:
        - ``TOKENMOULDS_GSUITE_CREDS``, then ``GSUITE_ORACLE_CREDS``
        - ``TOKENMOULDS_GSUITE_SUBJECT``, then ``GSUITE_ORACLE_SUBJECT``

        The ``GSUITE_ORACLE_*`` fallbacks make the existing openxml-audit setup
        reusable during development.
        """
        try:
            from google.oauth2 import service_account  # type: ignore[reportMissingImports]
        except ImportError as exc:
            raise GSuiteAuthError(
                "google-auth is required for Google Suite roundtrips. "
                'Install with `pip install -e ".[gsuite]"`.'
            ) from exc

        path = Path(
            creds_path
            or os.environ.get("TOKENMOULDS_GSUITE_CREDS")
            or os.environ.get("GSUITE_ORACLE_CREDS")
            or DEFAULT_CREDS_PATH
        ).expanduser()
        if not path.exists():
            raise GSuiteAuthError(
                f"Service account JSON not found at {path}. Set "
                "TOKENMOULDS_GSUITE_CREDS or pass --creds."
            )

        resolved_subject = (
            subject
            or os.environ.get("TOKENMOULDS_GSUITE_SUBJECT")
            or os.environ.get("GSUITE_ORACLE_SUBJECT")
        )

        try:
            base = service_account.Credentials.from_service_account_file(
                str(path), scopes=list(scopes)
            )
            credentials = (
                base.with_subject(resolved_subject) if resolved_subject else base
            )
        except Exception as exc:
            raise GSuiteAuthError(f"Drive auth setup failed: {exc}") from exc

        return cls(credentials, subject=resolved_subject)

    def _ensure_token(self) -> str:
        if not self._creds.valid:
            try:
                self._creds.refresh(self._auth_transport)
            except Exception as exc:
                raise GSuiteAuthError(f"token refresh failed: {exc}") from exc
        return str(self._creds.token)

    def _request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        decode_json: bool = True,
        timeout: float = 60.0,
    ) -> Any:
        token = self._ensure_token()
        full_headers = {"Authorization": f"Bearer {token}"}
        if headers:
            full_headers.update(headers)
        request = urllib.request.Request(
            url, data=body, method=method, headers=full_headers
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise GSuiteError(
                f"Drive API request failed: {method} {url} -> "
                f"{exc.code} {exc.reason}: {detail}"
            ) from exc
        except urllib.error.URLError as exc:
            raise GSuiteError(
                f"Drive API request failed: {method} {url}: {exc}"
            ) from exc

        if not decode_json:
            return payload
        if not payload:
            return None
        parsed = json.loads(payload)
        if not isinstance(parsed, dict):
            raise GSuiteError(f"Unexpected Drive API response shape from {url}")
        return parsed

    def whoami(self) -> dict[str, str]:
        """Return the active Drive principal."""
        fields = urllib.parse.quote("user(emailAddress,displayName)")
        result = self._request("GET", f"{_DRIVE_API}/about?fields={fields}")
        user = (result or {}).get("user", {})
        return {
            "emailAddress": str(user.get("emailAddress", "")),
            "displayName": str(user.get("displayName", "")),
        }

    def upload(
        self,
        path: Path | str,
        *,
        parent_id: str | None = None,
        mime_type: str | None = None,
        name: str | None = None,
    ) -> str:
        """Upload a local package to Drive and return the raw file ID."""
        source = Path(path)
        if not source.exists():
            raise GSuiteError(f"upload source not found: {source}")

        resolved_mime = mime_type or source_mime_for(source.suffix.lstrip("."))
        metadata: dict[str, Any] = {"name": name or source.name}
        if parent_id:
            metadata["parents"] = [parent_id]
        body, content_type = _build_multipart(metadata, source, resolved_mime)
        result = self._request(
            "POST",
            f"{_UPLOAD_API}/files?uploadType=multipart&fields=id",
            headers={"Content-Type": content_type},
            body=body,
        )
        return str(result["id"])

    def create_folder(
        self,
        name: str,
        *,
        parent_id: str | None = None,
    ) -> str:
        """Create a Drive folder and return its file ID."""
        body: dict[str, Any] = {
            "name": name,
            "mimeType": "application/vnd.google-apps.folder",
        }
        if parent_id:
            body["parents"] = [parent_id]
        fields = urllib.parse.quote("id,name")
        result = self._request(
            "POST",
            f"{_DRIVE_API}/files?fields={fields}",
            headers={"Content-Type": "application/json; charset=UTF-8"},
            body=json.dumps(body).encode("utf-8"),
        )
        return str(result["id"])

    def convert_to_native(
        self,
        file_id: str,
        *,
        target_mime: str,
        parent_id: str | None = None,
        name: str | None = None,
    ) -> str:
        """Copy a raw Drive file into a native Google document format."""
        body: dict[str, Any] = {"mimeType": target_mime}
        if name:
            body["name"] = name
        if parent_id:
            body["parents"] = [parent_id]
        fields = urllib.parse.quote("id,mimeType")
        result = self._request(
            "POST",
            f"{_DRIVE_API}/files/{file_id}/copy?fields={fields}",
            headers={"Content-Type": "application/json; charset=UTF-8"},
            body=json.dumps(body).encode("utf-8"),
        )
        return str(result["id"])

    def export(self, file_id: str, mime_type: str) -> bytes:
        """Export a native Google file to Office or ODF bytes."""
        url = (
            f"{_DRIVE_API}/files/{file_id}/export"
            f"?mimeType={urllib.parse.quote(mime_type)}"
        )
        result = self._request("GET", url, decode_json=False)
        if not isinstance(result, bytes):
            raise GSuiteError("Drive export did not return bytes")
        return result

    def delete(self, file_id: str) -> bool:
        """Best-effort delete for raw and native Drive files."""
        try:
            self._request(
                "DELETE",
                f"{_DRIVE_API}/files/{file_id}",
                decode_json=False,
            )
            return True
        except GSuiteError:
            return False


def _build_multipart(
    metadata: dict[str, Any],
    file_path: Path,
    mime_type: str,
) -> tuple[bytes, str]:
    boundary = "==boundary==" + uuid.uuid4().hex
    metadata_json = json.dumps(metadata).encode("utf-8")
    file_bytes = file_path.read_bytes()
    parts = [
        f"--{boundary}\r\n".encode("utf-8"),
        b"Content-Type: application/json; charset=UTF-8\r\n\r\n",
        metadata_json,
        f"\r\n--{boundary}\r\n".encode("utf-8"),
        f"Content-Type: {mime_type}\r\n\r\n".encode("utf-8"),
        file_bytes,
        f"\r\n--{boundary}--\r\n".encode("utf-8"),
    ]
    return b"".join(parts), f"multipart/related; boundary={boundary}"


def source_mime_for(target_format: str) -> str:
    """Map an Office/ODF extension to its upload MIME type."""
    mapping = {
        "pptx": PPTX_MIME,
        "docx": DOCX_MIME,
        "xlsx": XLSX_MIME,
        "odp": ODP_MIME,
        "odt": ODT_MIME,
        "ods": ODS_MIME,
    }
    mime = mapping.get(target_format.lower().lstrip("."))
    if mime is None:
        raise GSuiteError(f"unsupported Google Suite source format: {target_format!r}")
    return mime


def native_mime_for(target_format: str) -> str:
    """Map an Office/ODF extension to the matching native Google MIME type."""
    mapping = {
        "pptx": SLIDES_MIME,
        "odp": SLIDES_MIME,
        "docx": DOC_MIME,
        "odt": DOC_MIME,
        "xlsx": SHEET_MIME,
        "ods": SHEET_MIME,
    }
    mime = mapping.get(target_format.lower().lstrip("."))
    if mime is None:
        raise GSuiteError(f"unsupported Google Suite native format: {target_format!r}")
    return mime


def export_mime_for(target_format: str) -> str:
    """Map a requested roundtrip extension to the Drive export MIME type."""
    return source_mime_for(target_format)
