"""Shared helpers for package-level lazy exports."""

from __future__ import annotations

import importlib
from collections.abc import Mapping
from typing import Any, NoReturn

LazyImportMap = Mapping[str, tuple[str, str]]
LazyModuleMap = Mapping[str, str]


def _raise_missing(
    name: str, module_globals: Mapping[str, Any], package: str
) -> NoReturn:
    module_name = module_globals.get("__name__", package)
    raise AttributeError(f"module {module_name!r} has no attribute {name!r}")


def resolve_lazy_attribute(
    name: str,
    *,
    module_globals: dict[str, Any],
    package: str,
    lazy_imports: LazyImportMap,
    populate_siblings: bool = False,
) -> Any:
    if name not in lazy_imports:
        _raise_missing(name, module_globals, package)
    module_path, attr_name = lazy_imports[name]
    module = importlib.import_module(module_path, package)
    if populate_siblings:
        for other_name, (other_module, other_attr) in lazy_imports.items():
            if other_module == module_path and other_name not in module_globals:
                module_globals[other_name] = getattr(module, other_attr)
        return module_globals[name]
    value = getattr(module, attr_name)
    module_globals[name] = value
    return value


def resolve_lazy_symbol_or_module(
    name: str,
    *,
    module_globals: dict[str, Any],
    package: str,
    symbol_modules: LazyModuleMap,
    module_aliases: LazyModuleMap,
) -> Any:
    if name in symbol_modules:
        module = importlib.import_module(f".{symbol_modules[name]}", package)
        value = getattr(module, name)
        module_globals[name] = value
        return value

    if name in module_aliases:
        value = importlib.import_module(f".{module_aliases[name]}", package)
        module_globals[name] = value
        return value

    _raise_missing(name, module_globals, package)


def lazy_dir(module_globals: Mapping[str, Any], public_names: list[str]) -> list[str]:
    return sorted(set(module_globals) | set(public_names))
