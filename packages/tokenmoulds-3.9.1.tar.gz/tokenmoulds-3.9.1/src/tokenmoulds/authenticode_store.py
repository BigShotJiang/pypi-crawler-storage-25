"""Certificate store helpers for Authenticode signing."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional


class CertificateStore:
    """Manages code signing certificates for Authenticode.

    Provides certificate discovery, validation, and management for
    enterprise code signing workflows.
    """

    def __init__(self):
        self.certificates: Dict[str, Dict[str, Any]] = {}
        self._windows_cert_stores = ["My", "Root", "CA", "Trust"]

    def add_certificate(
        self, name: str, cert_path: str, password: Optional[str] = None
    ):
        """Add a certificate file to the store."""
        cert_path_obj = Path(cert_path)
        self.certificates[name] = {
            "path": cert_path_obj,
            "password": password,
            "type": "file",
            "valid": cert_path_obj.exists(),
        }

    def list_certificates(self) -> List[str]:
        """List available certificates."""
        return list(self.certificates.keys())
