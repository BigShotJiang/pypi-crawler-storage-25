"""
TokenMoulds - Community-Driven Design Tokens as a Service Platform
"""

__version__ = "3.9.1"
__author__ = "TokenMoulds"
__description__ = "Formulaic design token system with OOXML template generation"

from tokenmoulds.dtcg.generator import TokenGenerator

__all__ = ["TokenGenerator"]
