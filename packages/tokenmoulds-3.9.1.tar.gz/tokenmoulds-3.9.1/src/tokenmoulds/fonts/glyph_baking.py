"""Bake OpenType feature substitutions into a font's default cmap.

This allows PowerPoint (which has no DrawingML control for figure styles,
ligatures, or other GSUB features) to render alternate glyphs by making
them the default mapping for their codepoints.

Example: bake ``onum`` into a font so digits 0-9 map to oldstyle glyph
outlines.  The result is a modified TTF where ``0123456789`` renders as
oldstyle figures without any OpenType feature activation.

Usage::

    from tokenmoulds.fonts.glyph_baking import bake_feature

    # Returns modified font bytes with oldstyle figures as default
    modified = bake_feature(font_bytes, "onum", suffix="Body")
"""

from __future__ import annotations

import io
import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    from fontTools.ttLib import TTFont

    FONTTOOLS_AVAILABLE = True
except ImportError:
    TTFont = None  # type: ignore[assignment,misc]
    FONTTOOLS_AVAILABLE = False


def _extract_feature_substitutions(
    font: Any,
    feature_tag: str,
) -> dict[str, str]:
    """Extract single-substitution mappings for a GSUB feature.

    Returns a dict mapping default glyph names to their alternates.
    Only processes SingleSubst (format 1/2) lookups, which cover
    figure alternates (onum, lnum, tnum, pnum) and small caps (smcp).
    """
    gsub = font.get("GSUB")
    if gsub is None:
        return {}

    table = getattr(gsub, "table", None)
    if table is None:
        return {}

    feature_list = getattr(table, "FeatureList", None)
    lookup_list = getattr(table, "LookupList", None)
    if feature_list is None or lookup_list is None:
        return {}

    # Collect lookup indices for the requested feature tag
    lookup_indices: list[int] = []
    for record in getattr(feature_list, "FeatureRecord", []):
        if getattr(record, "FeatureTag", "") == feature_tag:
            feature = getattr(record, "Feature", None)
            if feature is not None:
                lookup_indices.extend(getattr(feature, "LookupListIndex", []))

    if not lookup_indices:
        return {}

    # Extract substitutions from each lookup
    substitutions: dict[str, str] = {}
    lookups = getattr(lookup_list, "Lookup", [])
    for idx in lookup_indices:
        if idx >= len(lookups):
            continue
        lookup = lookups[idx]
        for subtable in getattr(lookup, "SubTable", []):
            mapping = getattr(subtable, "mapping", None)
            if mapping:
                substitutions.update(mapping)

    return substitutions


def _apply_cmap_substitutions(
    font: Any,
    substitutions: dict[str, str],
) -> int:
    """Rewrite cmap entries so codepoints map to alternate glyphs.

    Returns the number of codepoints remapped.
    """
    cmap_table = font.get("cmap")
    if cmap_table is None:
        return 0

    remapped = 0
    for table in cmap_table.tables:
        cmap = getattr(table, "cmap", None)
        if cmap is None:
            continue
        for codepoint, glyph_name in list(cmap.items()):
            if glyph_name in substitutions:
                cmap[codepoint] = substitutions[glyph_name]
                remapped += 1

    return remapped


def _rename_font_family(font: Any, suffix: str) -> None:
    """Append a suffix to the font family name to avoid conflicts.

    Modifies name table entries for Family (1), Full Name (4),
    and Preferred Family (16).
    """
    name_table = font.get("name")
    if name_table is None:
        return

    for record in getattr(name_table, "names", []):
        if record.nameID in (1, 4, 16):
            try:
                old_value = record.toUnicode()
                new_value = f"{old_value} {suffix}"
                name_table.setName(
                    new_value,
                    record.nameID,
                    record.platformID,
                    record.platEncID,
                    record.langID,
                )
            except Exception:
                continue


def bake_feature(
    font_bytes: bytes,
    feature_tag: str,
    *,
    suffix: str = "",
    strip_gsub: bool = False,
) -> bytes | None:
    """Bake a GSUB feature into the font's default cmap.

    Args:
        font_bytes: Raw TTF/OTF font data.
        feature_tag: OpenType feature tag (e.g. ``"onum"``, ``"smcp"``).
        suffix: Appended to the font family name (e.g. ``"Body"`` →
            ``"Inter Body"``).  Empty string leaves the name unchanged.
        strip_gsub: If True, remove the GSUB table after baking (smaller
            file, but no other features will work).

    Returns:
        Modified font bytes with the feature baked in, or None if the
        font lacks the requested feature or fonttools is unavailable.
    """
    if not FONTTOOLS_AVAILABLE:
        logger.warning("fonttools not available, cannot bake feature %s", feature_tag)
        return None

    try:
        assert TTFont is not None
        font = TTFont(io.BytesIO(font_bytes))
    except Exception as exc:
        logger.warning("Failed to load font for baking: %s", exc)
        return None

    try:
        substitutions = _extract_feature_substitutions(font, feature_tag)
        if not substitutions:
            logger.debug("Font has no substitutions for feature %s", feature_tag)
            return None

        remapped = _apply_cmap_substitutions(font, substitutions)
        if remapped == 0:
            logger.debug("No codepoints remapped for feature %s", feature_tag)
            return None

        if suffix:
            _rename_font_family(font, suffix)

        if strip_gsub and "GSUB" in font:
            del font["GSUB"]

        output = io.BytesIO()
        font.save(output)
        logger.info(
            "Baked feature %s: %d substitutions, %d codepoints remapped",
            feature_tag,
            len(substitutions),
            remapped,
        )
        return output.getvalue()
    except Exception as exc:
        logger.warning("Failed to bake feature %s: %s", feature_tag, exc)
        return None
    finally:
        font.close()
