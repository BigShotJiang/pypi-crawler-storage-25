"""Font metadata extraction and license warnings.

Reads SFNT name/OS/2 tables via fontTools so the embedding pipeline can
surface licensing concerns. This is a *warning* surface — extraction
failures and restrictive licenses are logged, never silently masked or
used to block embedding.
"""

from __future__ import annotations

import logging
import struct
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from fontTools.ttLib import TTFont, TTLibError

logger = logging.getLogger(__name__)


class FontFormat(Enum):
    TTF = "ttf"
    OTF = "otf"
    UNKNOWN = "unknown"


# License-description substrings (case-insensitive) that we treat as
# permissive enough for embedding without manual review. Anything else
# triggers a warning so the operator can verify rights.
PERMISSIVE_LICENSE_TOKENS: tuple[str, ...] = (
    "ofl",
    "open font license",
    "apache",
    "mit license",
    "bsd",
    "public domain",
    "cc0",
)


@dataclass(frozen=True)
class FontMetadata:
    """Metadata extracted from an SFNT font via fontTools."""

    family_name: str
    style_name: str
    weight: int
    format: FontFormat
    license_description: str | None
    license_url: str | None
    version: str | None
    vendor: str | None
    glyph_count: int
    has_kerning: bool
    has_opentype_features: bool

    @property
    def is_permissively_licensed(self) -> bool:
        if not self.license_description:
            return False
        text = self.license_description.lower()
        return any(token in text for token in PERMISSIVE_LICENSE_TOKENS)


class FontValidationError(Exception):
    """Raised when a font cannot be parsed by fontTools."""


def detect_format(font_path: Path) -> FontFormat:
    """Detect font format by reading the SFNT magic bytes."""
    if not font_path.exists():
        return FontFormat.UNKNOWN
    try:
        with font_path.open("rb") as fh:
            header = fh.read(4)
    except OSError:
        return FontFormat.UNKNOWN
    if header in (b"\x00\x01\x00\x00", b"true"):
        return FontFormat.TTF
    if header == b"OTTO":
        return FontFormat.OTF
    return FontFormat.UNKNOWN


def extract_metadata(font_path: Path) -> FontMetadata:
    """Parse font metadata via fontTools.

    Raises:
        FontValidationError: if the file is missing, has an unrecognised
            SFNT signature, or fontTools refuses to open it.
    """
    fmt = detect_format(font_path)
    if fmt is FontFormat.UNKNOWN:
        raise FontValidationError(f"Unrecognised SFNT magic in {font_path}")

    try:
        font = TTFont(str(font_path), lazy=True)
    except (TTLibError, OSError, struct.error, ValueError) as exc:
        raise FontValidationError(
            f"fontTools could not open {font_path}: {exc}"
        ) from exc

    try:
        return _extract(font, fmt)
    except (TTLibError, struct.error, ValueError) as exc:
        raise FontValidationError(
            f"fontTools failed to parse tables in {font_path}: {exc}"
        ) from exc
    finally:
        font.close()


def _extract(font: TTFont, fmt: FontFormat) -> FontMetadata:
    name_records: dict[int, str] = {}
    name_table = font.get("name")
    if name_table is not None:
        for record in name_table.names:
            try:
                text = record.toUnicode()
            except (UnicodeDecodeError, AttributeError):
                continue
            # Prefer Windows/Unicode (platformID 3) when present, but fall
            # back to whatever record we see first per nameID.
            if record.nameID not in name_records or record.platformID == 3:
                name_records[record.nameID] = text

    weight = 400
    os2 = font.get("OS/2")
    if os2 is not None:
        weight = int(getattr(os2, "usWeightClass", 400))

    glyph_count = 0
    maxp = font.get("maxp")
    if maxp is not None:
        glyph_count = int(getattr(maxp, "numGlyphs", 0))

    return FontMetadata(
        family_name=name_records.get(1, "").strip(),
        style_name=name_records.get(2, "").strip(),
        weight=weight,
        format=fmt,
        license_description=(name_records.get(13) or "").strip() or None,
        license_url=(name_records.get(14) or "").strip() or None,
        version=(name_records.get(5) or "").strip() or None,
        vendor=(name_records.get(8) or "").strip() or None,
        glyph_count=glyph_count,
        has_kerning="kern" in font or "GPOS" in font,
        has_opentype_features="GSUB" in font or "GPOS" in font,
    )


def warn_if_restrictive_license(metadata: FontMetadata, *, font_path: Path) -> None:
    """Log a warning if the font's license isn't on the permissive allowlist."""
    if metadata.is_permissively_licensed:
        return
    license_text = metadata.license_description or "(no license metadata)"
    logger.warning(
        "Font %s (%s) reports license %r — not on the permissive allowlist; "
        "verify embedding rights before shipping the template.",
        metadata.family_name or font_path.stem,
        font_path,
        license_text,
    )
