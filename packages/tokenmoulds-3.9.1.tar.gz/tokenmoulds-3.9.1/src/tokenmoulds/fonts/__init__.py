"""Font resolution and embedding services.

Borrowed from svg2ooxml's font service patterns:
- FontService: Multi-provider font resolution with fallback chain
- FontSubsetter: Permission-aware glyph subsetting with caching
"""

from tokenmoulds.fonts.service import (
    DownloadedFontProvider,
    FontMatch,
    FontProvider,
    FontQuery,
    FontService,
    SystemFontProvider,
    VendoredFontProvider,
    build_font_service,
)
from tokenmoulds.fonts.subsetter import FontSubsetter, SubsetResult
from tokenmoulds.fonts.validator import (
    FontFormat,
    FontMetadata,
    FontValidationError,
    detect_format,
    extract_metadata,
    warn_if_restrictive_license,
)

__all__ = [
    "FontMatch",
    "FontProvider",
    "FontQuery",
    "FontService",
    "FontSubsetter",
    "SubsetResult",
    "DownloadedFontProvider",
    "SystemFontProvider",
    "VendoredFontProvider",
    "build_font_service",
    "FontFormat",
    "FontMetadata",
    "FontValidationError",
    "detect_format",
    "extract_metadata",
    "warn_if_restrictive_license",
]
