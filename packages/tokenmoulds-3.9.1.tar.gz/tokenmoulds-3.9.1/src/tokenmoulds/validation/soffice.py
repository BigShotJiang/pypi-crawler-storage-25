"""Optional LibreOffice render checks for generated Office templates."""

from __future__ import annotations

import hashlib
import os
import platform
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


_SUPPORTED_RENDER_FORMATS = {
    "pptx": ".pptx",
    "potx": ".potx",
    "odp": ".odp",
    "otp": ".otp",
}


@dataclass(frozen=True)
class RenderedImage:
    """A single rendered page/slide image."""

    path: str
    size_bytes: int
    sha256: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "size_bytes": self.size_bytes,
            "sha256": self.sha256,
        }


@dataclass(frozen=True)
class SofficeRenderReport:
    """Result of attempting a LibreOffice render check."""

    fmt: str
    status: str
    renderer: str = "soffice"
    command_path: str | None = None
    engine_version: str | None = None
    images: tuple[RenderedImage, ...] = field(default_factory=tuple)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "format": self.fmt,
            "status": self.status,
            "renderer": self.renderer,
            "command_path": self.command_path,
            "engine_version": self.engine_version,
            "images": [image.to_dict() for image in self.images],
        }
        if self.error:
            payload["error"] = self.error
        return payload


def render_with_soffice(
    data: bytes,
    fmt: str,
    output_dir: Path,
    *,
    soffice_path: str | None = None,
    timeout: float | None = 90.0,
) -> SofficeRenderReport:
    """Render an Office presentation artifact to PNGs with LibreOffice."""

    suffix = _SUPPORTED_RENDER_FORMATS.get(fmt.lower())
    if suffix is None:
        return SofficeRenderReport(
            fmt=fmt,
            status="skipped",
            error=f"LibreOffice PNG render is not configured for format: {fmt}",
        )

    command_path = _resolve_soffice_path(soffice_path)
    if command_path is None:
        return SofficeRenderReport(
            fmt=fmt,
            status="skipped",
            error="LibreOffice soffice command not found",
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    input_path = output_dir / f"artifact{suffix}"
    input_path.write_bytes(data)

    user_install_dir = Path(tempfile.mkdtemp(prefix="tokenmoulds_soffice_"))
    try:
        cmd = [
            command_path,
            "--headless",
            "--nologo",
            "--nodefault",
            "--nofirststartwizard",
            "--norestore",
            "--nolockcheck",
            f"-env:UserInstallation={user_install_dir.resolve().as_uri()}",
            "--convert-to",
            "png:impress_png_Export",
            "--outdir",
            str(output_dir),
            str(input_path),
        ]
        completed = _run_soffice(cmd, timeout=timeout)
        if completed.returncode != 0 and platform.system() == "Darwin":
            open_cmd = _macos_open_command(command_path, cmd[1:])
            if open_cmd is not None:
                completed = _run_soffice(open_cmd, timeout=timeout)

        version = _soffice_version(command_path, timeout=timeout)
        if completed.returncode != 0:
            return SofficeRenderReport(
                fmt=fmt,
                status="failed",
                command_path=command_path,
                engine_version=version,
                error=_format_error(completed),
            )

        images = tuple(
            _rendered_image(path) for path in sorted(output_dir.glob("*.png"))
        )
        if not images:
            return SofficeRenderReport(
                fmt=fmt,
                status="failed",
                command_path=command_path,
                engine_version=version,
                error=f"LibreOffice produced no PNG files in {output_dir}",
            )

        return SofficeRenderReport(
            fmt=fmt,
            status="passed",
            command_path=command_path,
            engine_version=version,
            images=images,
        )
    except subprocess.TimeoutExpired:
        return SofficeRenderReport(
            fmt=fmt,
            status="failed",
            command_path=command_path,
            error=f"LibreOffice timed out after {timeout} seconds",
        )
    finally:
        shutil.rmtree(user_install_dir, ignore_errors=True)


def _resolve_soffice_path(soffice_path: str | None) -> str | None:
    candidates = [
        soffice_path,
        os.getenv("TOKENMOULDS_SOFFICE_PATH"),
        os.getenv("SVG2OOXML_SOFFICE_PATH"),
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        shutil.which("soffice"),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def _run_soffice(
    cmd: list[str],
    *,
    timeout: float | None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=True,
        check=False,
        timeout=timeout,
        text=True,
    )


def _soffice_version(command_path: str, *, timeout: float | None) -> str | None:
    try:
        completed = _run_soffice([command_path, "--version"], timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode != 0:
        return None
    return (completed.stdout or completed.stderr).strip() or None


def _macos_open_command(command_path: str, args: list[str]) -> list[str] | None:
    open_path = shutil.which("open")
    if not open_path:
        return None
    for parent in Path(command_path).parents:
        if parent.suffix == ".app":
            return [open_path, "-W", "-a", str(parent), "--args", *args]
    return None


def _rendered_image(path: Path) -> RenderedImage:
    data = path.read_bytes()
    return RenderedImage(
        path=str(path),
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
    )


def _format_error(completed: subprocess.CompletedProcess[str]) -> str:
    parts = [f"LibreOffice failed with exit code {completed.returncode}"]
    if completed.stdout:
        parts.append(f"stdout:\n{completed.stdout}")
    if completed.stderr:
        parts.append(f"stderr:\n{completed.stderr}")
    return "\n".join(parts)


__all__ = [
    "RenderedImage",
    "SofficeRenderReport",
    "render_with_soffice",
]
