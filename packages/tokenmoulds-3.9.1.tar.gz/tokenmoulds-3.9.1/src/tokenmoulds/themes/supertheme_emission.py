"""Emission and thumbnail helpers for SuperTheme packages.

Free functions taking the concrete ``SuperThemeEmitter`` as their first
argument.
"""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from string import Template
from typing import TYPE_CHECKING, Any, Dict, List

import lxml.etree as etree

from tokenmoulds.colors.parser import hex_to_rgb_tuple
from tokenmoulds.design.page_geometry import SlideGrid, create_slide_grid
from tokenmoulds.design.units import pt_to_emu
from tokenmoulds.themes.aspect_ratios import AspectRatio
from tokenmoulds.themes.supertheme_thumbnails import build_thumbnail_payloads
from tokenmoulds.themes.thumbnail_generator import generate_thumbnails_from_pptx

if TYPE_CHECKING:
    from tokenmoulds.themes.supertheme import SuperThemeEmitter, SuperThemeVariant


def create_sample_pptx_for_thumbnail(
    variant: SuperThemeVariant,
    output_path: Path,
) -> bool:
    """Create a sample PPTX with the variant's theme for thumbnail capture."""
    try:
        from pptx import Presentation  # type: ignore[import-not-found]
        from pptx.dml.color import RGBColor  # type: ignore[import-not-found]
        from pptx.enum.shapes import MSO_SHAPE  # type: ignore[import-not-found]
        from pptx.util import Emu, Inches, Pt  # type: ignore[import-not-found]

        prs = Presentation()

        prs.slide_width = Emu(variant.width_emu)
        prs.slide_height = Emu(variant.height_emu)

        slide_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(slide_layout)

        color_rgb = hex_to_rgb_tuple(variant.accent1)
        sw = int(prs.slide_width or 0)
        sh = int(prs.slide_height or 0)

        shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Emu(0), Emu(0), Emu(sw), Emu(int(sh * 0.33))
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(*color_rgb)
        shape.line.fill.background()

        lt1_rgb = hex_to_rgb_tuple(variant.lt1)
        textbox_width = Emu(sw - int(Inches(1)))

        textbox = slide.shapes.add_textbox(
            Inches(0.5), Inches(0.3), textbox_width, Inches(1.5)
        )
        tf = textbox.text_frame
        p = tf.paragraphs[0]
        p.text = variant.design_name
        p.font.size = Pt(44)
        p.font.bold = True
        p.font.color.rgb = RGBColor(*lt1_rgb)
        p.font.name = variant.major_font

        content_top = int(sh * 0.40)
        content_height = int(sh * 0.35)
        block_width = int((sw - int(Inches(2))) / 3)

        accent_colors = [
            hex_to_rgb_tuple(variant.accent1),
            hex_to_rgb_tuple(variant.accent2),
            hex_to_rgb_tuple(variant.accent3),
        ]

        for i, accent_rgb in enumerate(accent_colors):
            box_left = int(Inches(0.5)) + i * (block_width + int(Inches(0.25)))
            box = slide.shapes.add_shape(
                MSO_SHAPE.ROUNDED_RECTANGLE,
                Emu(box_left),
                Emu(content_top),
                Emu(block_width),
                Emu(content_height),
            )
            box.fill.solid()
            box.fill.fore_color.rgb = RGBColor(*accent_rgb)
            box.line.fill.background()

        prs.save(str(output_path))
        return True

    except ImportError:
        return False
    except Exception:
        return False


def generate_thumbnails(
    emitter: SuperThemeEmitter, variant: SuperThemeVariant
) -> Dict[str, bytes]:
    """Generate thumbnail images for a variant."""
    if emitter._use_soffice_thumbnails and emitter._check_soffice_available():
        try:
            import tempfile

            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                pptx_path = temp_path / "sample.pptx"

                if create_sample_pptx_for_thumbnail(variant, pptx_path):
                    thumbnails = generate_thumbnails_from_pptx(pptx_path)
                    if thumbnails:
                        return thumbnails
        except Exception:
            pass

    color = hex_to_rgb_tuple(variant.accent1)
    return build_thumbnail_payloads(color)


def build_variant_manager(
    emitter: SuperThemeEmitter, variants: List[SuperThemeVariant]
) -> str:
    """Build themeVariantManager.xml."""
    variant_template = emitter._read_template("theme_variant.xml")
    variant_entries = []

    for i, variant in enumerate(variants):
        entry = Template(variant_template).safe_substitute(
            VARIANT_NAME=variant.name,
            VARIANT_GUID=variant.guid,
            WIDTH_EMU=str(variant.width_emu),
            HEIGHT_EMU=str(variant.height_emu),
            REL_ID=f"rId{i + 1}",
        )
        variant_entries.append(entry)

    manager_template = emitter._read_template("theme_variant_manager.xml")
    return Template(manager_template).safe_substitute(
        THEME_VARIANTS="".join(variant_entries),
    )


def build_variant_manager_rels(
    emitter: SuperThemeEmitter, variants: List[SuperThemeVariant]
) -> str:
    """Build themeVariantManager.xml.rels."""
    relationships = []

    relationships.append(
        '  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="/theme/theme/themeManager.xml"/>'
    )

    for i, variant in enumerate(variants[1:], start=1):
        folder_num = i
        relationships.append(
            f'  <Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="/themeVariants/variant{folder_num}/theme/theme/themeManager.xml"/>'
        )

    rels_template = emitter._read_template("variant_manager_rels.xml")
    return Template(rels_template).safe_substitute(
        VARIANT_RELATIONSHIPS="\n".join(relationships),
    )


def get_slide_layout_xml(
    emitter: SuperThemeEmitter,
    layout_index: int,
    layout_type: str,
    layout_name: str,
    slide_grid: SlideGrid | None = None,
    slide_regions: dict[str, Any] | None = None,
) -> str:
    """Get slideLayout XML from template or build minimal fallback."""
    if layout_index <= 9:
        template_path = f"slide_layouts/slideLayout{layout_index}.xml"
        xml_str = emitter._read_template(template_path)
        if slide_grid is not None:
            xml_str = apply_layout_recipe(
                xml_str, layout_type, slide_grid, slide_regions
            )
        return xml_str

    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
             xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
             xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
             type="{layout_type}" preserve="1">
  <p:cSld name="{layout_name}">
    <p:spTree>
      <p:nvGrpSpPr>
        <p:cNvPr id="1" name=""/>
        <p:cNvGrpSpPr/>
        <p:nvPr/>
      </p:nvGrpSpPr>
      <p:grpSpPr>
        <a:xfrm>
          <a:off x="0" y="0"/>
          <a:ext cx="0" cy="0"/>
          <a:chOff x="0" y="0"/>
          <a:chExt cx="0" cy="0"/>
        </a:xfrm>
      </p:grpSpPr>
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sldLayout>"""


def apply_layout_recipe(
    xml_str: str,
    layout_type: str,
    grid: SlideGrid,
    slide_regions: dict[str, Any] | None = None,
) -> str:
    """Apply layout recipe to compute placeholder positions."""
    P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
    A_NS_STR = "http://schemas.openxmlformats.org/drawingml/2006/main"
    root = etree.fromstring(xml_str.encode("utf-8"))

    if slide_regions is not None:
        from tokenmoulds.dtcg.layout_recipe_resolver import (
            resolve_for_pptx_layout_type,
        )

        recipe = resolve_for_pptx_layout_type(layout_type, slide_regions, grid)
    else:
        recipe = {}

    for sp in root.iter(f"{{{P_NS}}}sp"):
        ph = sp.find(f".//{{{P_NS}}}ph")
        if ph is None:
            continue

        ph_type = ph.get("type")
        ph_idx = ph.get("idx")

        sp_pr = sp.find(f"{{{P_NS}}}spPr")
        if sp_pr is None:
            continue
        xfrm = sp_pr.find(f"{{{A_NS_STR}}}xfrm")

        key = (ph_type, ph_idx)
        if key in recipe:
            x, y, cx, cy = recipe[key]

            if xfrm is None:
                xfrm = etree.SubElement(sp_pr, f"{{{A_NS_STR}}}xfrm")
                etree.SubElement(xfrm, f"{{{A_NS_STR}}}off")
                etree.SubElement(xfrm, f"{{{A_NS_STR}}}ext")

            off = xfrm.find(f"{{{A_NS_STR}}}off")
            ext = xfrm.find(f"{{{A_NS_STR}}}ext")
            if off is None or ext is None:
                continue

            off.set("x", str(x))
            off.set("y", str(y))
            ext.set("cx", str(cx))
            ext.set("cy", str(cy))

        elif xfrm is not None:
            off = xfrm.find(f"{{{A_NS_STR}}}off")
            ext = xfrm.find(f"{{{A_NS_STR}}}ext")
            if off is None or ext is None:
                continue
            ox = int(off.get("x", "0"))
            oy = int(off.get("y", "0"))
            ocx = int(ext.get("cx", "0"))
            ocy = int(ext.get("cy", "0"))
            if ocx == 0 and ocy == 0:
                continue
            nx, ny, ncx, ncy = grid.snap_position(ox, oy, ocx, ocy)
            if nx + ncx > grid.slide_width_emu:
                ncx = grid.slide_width_emu - nx
            if ny + ncy > grid.slide_height_emu:
                ncy = grid.slide_height_emu - ny
            off.set("x", str(nx))
            off.set("y", str(ny))
            ext.set("cx", str(ncx))
            ext.set("cy", str(ncy))

    return etree.tostring(
        root, xml_declaration=True, encoding="UTF-8", standalone=True
    ).decode("utf-8")


def _build_base_slide_layout_content_types(emitter: SuperThemeEmitter) -> str:
    """Build content type entries for base theme slideLayouts."""
    entries = []
    for i in range(1, len(emitter.SLIDE_LAYOUT_TYPES) + 1):
        entries.append(
            f'  <Override PartName="/theme/slideLayouts/slideLayout{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
        )
    return "\n".join(entries)


def build_content_types(
    emitter: SuperThemeEmitter, variants: List[SuperThemeVariant]
) -> str:
    """Build [Content_Types].xml."""
    ct_template = emitter._read_template("variant_content_type.xml")
    variant_types = []

    for i, variant in enumerate(variants[1:], start=1):
        folder_num = i
        ct = Template(ct_template).safe_substitute(
            VARIANT_ID=str(folder_num),
        )
        variant_types.append(ct)

    types_template = emitter._read_template("content_types.xml")
    return Template(types_template).safe_substitute(
        BASE_SLIDE_LAYOUT_CONTENT_TYPES=_build_base_slide_layout_content_types(emitter),
        VARIANT_CONTENT_TYPES="".join(variant_types),
    )


def emit(emitter: SuperThemeEmitter) -> bytes:
    """Generate SuperTheme package as bytes."""
    if not emitter.design_variants:
        raise ValueError("No design variants configured")
    if not emitter.aspect_ratio_keys:
        raise ValueError("No aspect ratios configured")

    variants = emitter._build_variants()
    buffer = io.BytesIO()

    with zipfile.ZipFile(
        buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as zf:
        zf.writestr("[Content_Types].xml", build_content_types(emitter, variants))
        zf.writestr("_rels/.rels", emitter._read_template("package_rels.xml"))

        zf.writestr(
            "themeVariants/themeVariantManager.xml",
            build_variant_manager(emitter, variants),
        )
        zf.writestr(
            "themeVariants/_rels/themeVariantManager.xml.rels",
            build_variant_manager_rels(emitter, variants),
        )

        theme_manager_xml = emitter._read_template("theme_manager.xml")
        theme_manager_rels_xml = emitter._read_template("theme_manager_rels.xml")
        presentation_rels_xml = emitter._read_template("presentation_rels.xml")
        slide_master_template = emitter._read_template("slide_master.xml")
        slide_master_rels_xml = emitter._read_template("slide_master_rels.xml")
        slide_layout_rels = emitter._read_template("slide_layout_rels.xml")
        variant_rels_xml = emitter._read_template("variant_rels.xml")

        _DEFAULT_GRID_PT = 12
        _grid_emu = pt_to_emu(_DEFAULT_GRID_PT)
        _layout_cache: Dict[str, list[str]] = {}

        def _layouts_for_ar(ar: AspectRatio) -> list[str]:
            if ar.key in _layout_cache:
                return _layout_cache[ar.key]
            grid = create_slide_grid(ar.width_emu, ar.height_emu, _grid_emu)
            regions = emitter.slide_regions
            if regions is None:
                from tokenmoulds.dtcg.layout_recipe_defaults import (
                    compute_default_slide_regions,
                )

                regions = compute_default_slide_regions(grid)
            layouts = [
                get_slide_layout_xml(
                    emitter,
                    i,
                    layout_type,
                    layout_name,
                    slide_grid=grid,
                    slide_regions=regions,
                )
                for i, (layout_type, layout_name) in enumerate(
                    emitter.SLIDE_LAYOUT_TYPES, 1
                )
            ]
            _layout_cache[ar.key] = layouts
            return layouts

        default_variant = variants[0]
        zf.writestr("theme/theme/themeManager.xml", theme_manager_xml)
        zf.writestr("theme/theme/_rels/themeManager.xml.rels", theme_manager_rels_xml)
        zf.writestr("theme/theme/theme1.xml", emitter._build_theme_xml(default_variant))
        zf.writestr(
            "theme/presentation.xml", emitter._build_presentation_xml(default_variant)
        )
        zf.writestr("theme/_rels/presentation.xml.rels", presentation_rels_xml)
        zf.writestr(
            "theme/slideMasters/slideMaster1.xml",
            Template(slide_master_template).safe_substitute(
                MASTER_NAME=f"{default_variant.design_name} Master"
            ),
        )
        zf.writestr(
            "theme/slideMasters/_rels/slideMaster1.xml.rels",
            slide_master_rels_xml,
        )

        default_layouts = _layouts_for_ar(default_variant.aspect_ratio)
        for i, layout_xml in enumerate(default_layouts, 1):
            zf.writestr(f"theme/slideLayouts/slideLayout{i}.xml", layout_xml)
            zf.writestr(
                f"theme/slideLayouts/_rels/slideLayout{i}.xml.rels",
                slide_layout_rels,
            )

        default_thumbnails = generate_thumbnails(emitter, default_variant)
        zf.writestr(
            "theme/theme/themeThumbnail.jpeg",
            default_thumbnails["themeThumbnail.jpeg"],
        )
        zf.writestr(
            "theme/theme/auxiliaryThemeThumbnail.jpeg",
            default_thumbnails["auxiliaryThemeThumbnail.jpeg"],
        )
        zf.writestr(
            "theme/theme/auxiliaryThemeThumbnailMedium.jpeg",
            default_thumbnails["auxiliaryThemeThumbnailMedium.jpeg"],
        )
        zf.writestr("docProps/thumbnail.jpeg", default_thumbnails["thumbnail.jpeg"])

        for variant in variants[1:]:
            folder_num = variant.variant_id - 1
            base_dir = f"themeVariants/variant{folder_num}"

            zf.writestr(f"{base_dir}/theme/theme/themeManager.xml", theme_manager_xml)
            zf.writestr(
                f"{base_dir}/theme/theme/_rels/themeManager.xml.rels",
                theme_manager_rels_xml,
            )
            zf.writestr(
                f"{base_dir}/theme/theme/theme1.xml", emitter._build_theme_xml(variant)
            )
            zf.writestr(
                f"{base_dir}/theme/presentation.xml",
                emitter._build_presentation_xml(variant),
            )
            zf.writestr(
                f"{base_dir}/theme/_rels/presentation.xml.rels",
                presentation_rels_xml,
            )

            zf.writestr(
                f"{base_dir}/theme/slideMasters/slideMaster1.xml",
                Template(slide_master_template).safe_substitute(
                    MASTER_NAME=f"{variant.name} Master"
                ),
            )
            zf.writestr(
                f"{base_dir}/theme/slideMasters/_rels/slideMaster1.xml.rels",
                slide_master_rels_xml,
            )

            variant_layouts = _layouts_for_ar(variant.aspect_ratio)
            for i, layout_xml in enumerate(variant_layouts, 1):
                zf.writestr(
                    f"{base_dir}/theme/slideLayouts/slideLayout{i}.xml",
                    layout_xml,
                )
                zf.writestr(
                    f"{base_dir}/theme/slideLayouts/_rels/slideLayout{i}.xml.rels",
                    slide_layout_rels,
                )

            variant_thumbnails = generate_thumbnails(emitter, variant)
            zf.writestr(
                f"{base_dir}/theme/theme/themeThumbnail.jpeg",
                variant_thumbnails["themeThumbnail.jpeg"],
            )
            zf.writestr(
                f"{base_dir}/theme/theme/auxiliaryThemeThumbnail.jpeg",
                variant_thumbnails["auxiliaryThemeThumbnail.jpeg"],
            )
            zf.writestr(
                f"{base_dir}/theme/theme/auxiliaryThemeThumbnailMedium.jpeg",
                variant_thumbnails["auxiliaryThemeThumbnailMedium.jpeg"],
            )
            zf.writestr(
                f"{base_dir}/docProps/thumbnail.jpeg",
                variant_thumbnails["thumbnail.jpeg"],
            )

            zf.writestr(f"{base_dir}/_rels/.rels", variant_rels_xml)

    buffer.seek(0)
    return buffer.getvalue()


def save(emitter: SuperThemeEmitter, path: str | Path) -> None:
    """Save SuperTheme to disk."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(emit(emitter))
