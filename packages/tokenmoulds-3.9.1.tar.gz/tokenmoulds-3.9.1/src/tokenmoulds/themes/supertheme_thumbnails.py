"""Placeholder JPEG generation for SuperTheme thumbnail slots.

Provides a minimal valid JPEG constant and a factory that uses PIL when
available, falling back to the constant otherwise.
"""

from __future__ import annotations

import base64
import io
from typing import Tuple

# Minimal valid JPEG: 1x1 gray pixel (fallback when PIL is unavailable)
MINIMAL_JPEG_PLACEHOLDER = base64.b64decode(
    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRof"
    "Hh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAHwAA"
    "AQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQR"
    "BRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RF"
    "RkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ip"
    "qrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/9oACAEB"
    "AAA/AHuUEQACiigA/9k="
)


def create_placeholder_jpeg(
    width: int, height: int, color: Tuple[int, int, int]
) -> bytes:
    """Create a minimal placeholder JPEG image with a solid color.

    Uses PIL if available, otherwise returns a pre-generated 1x1 gray JPEG.
    """
    try:
        from PIL import Image

        img = Image.new("RGB", (width, height), color)
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=85)
        buffer.seek(0)
        return buffer.getvalue()
    except ImportError:
        return MINIMAL_JPEG_PLACEHOLDER


def build_thumbnail_payloads(
    color: Tuple[int, int, int],
) -> dict[str, bytes]:
    """Create the four required thumbnail sizes for a SuperTheme variant."""
    return {
        "themeThumbnail.jpeg": create_placeholder_jpeg(64, 48, color),
        "auxiliaryThemeThumbnail.jpeg": create_placeholder_jpeg(85, 48, color),
        "auxiliaryThemeThumbnailMedium.jpeg": create_placeholder_jpeg(124, 70, color),
        "thumbnail.jpeg": create_placeholder_jpeg(341, 192, color),
    }
