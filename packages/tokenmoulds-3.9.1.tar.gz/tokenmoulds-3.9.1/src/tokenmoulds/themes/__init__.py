"""Theme packaging for OOXML and SuperTheme generation.

This package provides theme building capabilities:
- Single .thmx theme packages
- SuperTheme multi-variant packages
- Aspect ratio definitions and EMU calculations
- Page geometry for layout calculations
- Design variant management
"""

from tokenmoulds.themes.aspect_ratios import (
    AspectRatio,
    AspectRatioCategory,
    ASPECT_RATIOS,
    get_aspect_ratio,
    list_aspect_ratios,
    create_custom_aspect_ratio,
)
from tokenmoulds.themes.config import (
    ThemesConfig,
    SuperThemeConfig,
    VariantPreset,
    load_themes_config,
    get_themes_config,
    reload_themes_config,
)
from tokenmoulds.themes.thmx import (
    ThmxEmitter,
    ThemeDefinition,
    ThemeMetadata,
    EmbeddedFont,
    create_thmx,
)
from tokenmoulds.themes.supertheme import (
    SuperThemeEmitter,
    SuperThemeVariant,
    DesignVariant,
    create_supertheme,
    extract_design_variants_from_supertheme,
    patch_supertheme,
    patch_supertheme_from_source,
    is_soffice_available,
)
from tokenmoulds.themes.supertheme_validator import (
    ValidationIssue,
    ValidationResult,
    Severity,
    SuperThemeValidator,
    validate_supertheme,
    validate_design_variant,
)
from tokenmoulds.themes.tables import (
    TableTextTokens,
    TableBorderTokens,
    TableCellTokens,
    TableStyleTokens,
    TableStyleGenerator,
    derive_table_style_from_brand_tone,
)

# Re-export page geometry from design module
from tokenmoulds.design.page_geometry import (
    PageGeometry,
    PageMargins,
    ContentArea,
    create_page_geometry,
    page_geometry_from_aspect_ratio,
    MARGIN_PRESETS,
)

__all__ = [
    # Aspect ratios
    "AspectRatio",
    "AspectRatioCategory",
    "ASPECT_RATIOS",
    "get_aspect_ratio",
    "list_aspect_ratios",
    "create_custom_aspect_ratio",
    # Config
    "ThemesConfig",
    "SuperThemeConfig",
    "VariantPreset",
    "load_themes_config",
    "get_themes_config",
    "reload_themes_config",
    # THMX Emitter
    "ThmxEmitter",
    "ThemeDefinition",
    "ThemeMetadata",
    "EmbeddedFont",
    "create_thmx",
    # SuperTheme Emitter
    "SuperThemeEmitter",
    "SuperThemeVariant",
    "DesignVariant",
    "create_supertheme",
    "extract_design_variants_from_supertheme",
    "patch_supertheme",
    "patch_supertheme_from_source",
    "is_soffice_available",
    # SuperTheme Validator
    "ValidationIssue",
    "ValidationResult",
    "Severity",
    "SuperThemeValidator",
    "validate_supertheme",
    "validate_design_variant",
    # Table Styles (typographically correct, brand tone derived)
    "TableTextTokens",
    "TableBorderTokens",
    "TableCellTokens",
    "TableStyleTokens",
    "TableStyleGenerator",
    "derive_table_style_from_brand_tone",
    # Page geometry
    "PageGeometry",
    "PageMargins",
    "ContentArea",
    "create_page_geometry",
    "page_geometry_from_aspect_ratio",
    "MARGIN_PRESETS",
]
