"""SuperTheme Package Emitter.

Generates Microsoft PowerPoint SuperThemes with multiple design variants across
different aspect ratios. SuperThemes allow seamless theme switching in PowerPoint
with different color schemes, fonts, and slide dimensions.

A SuperTheme is an OPC (Open Packaging Conventions) archive containing:
- [Content_Types].xml - Content type definitions
- _rels/.rels - Root relationships
- themeVariants/themeVariantManager.xml - Microsoft SuperTheme variant manager
- themeVariants/_rels/themeVariantManager.xml.rels - Variant relationships
- themeVariants/variant{n}/ - Individual variant packages
- theme/ - Default theme (first variant)

XML templates are the Single Source of Truth (SSOT) for document structure.
This emitter loads templates and modifies attribute values via template
substitution - it never constructs new XML elements programmatically.

Based on BrandWares SuperTheme research and archive-stylestack-v1 implementation.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from string import Template
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import lxml.etree as etree

from tokenmoulds.emitters import TemplateResolver
from tokenmoulds.emitters.xml_helpers import (
    A_NS,
    create_effect_style,
    find_element,
    serialize_tree,
    set_color_value,
    set_font_typeface,
    set_scheme_name,
    set_theme_name,
)
from tokenmoulds.themes.aspect_ratios import ASPECT_RATIOS, AspectRatio
from tokenmoulds.themes.supertheme_emission import (
    apply_layout_recipe,
    emit as _emit,
    save as _save,
)
from tokenmoulds.themes.supertheme_patcher import (
    extract_design_variants_from_supertheme,
    patch_supertheme,
    patch_supertheme_from_source,
)
from tokenmoulds.themes.thumbnail_generator import (
    is_soffice_available,
)

if TYPE_CHECKING:
    from tokenmoulds.ir import ColorTheme, TypographyScheme
    from tokenmoulds.ir.style_primitives import Effects


@dataclass
class SuperThemeVariant:
    """A single SuperTheme variant with aspect ratio and design settings."""

    name: str
    design_name: str
    aspect_ratio: AspectRatio
    variant_id: int
    guid: str

    # Theme colors (hex without #)
    dk1: str = "000000"
    lt1: str = "FFFFFF"
    dk2: str = "44546A"
    lt2: str = "E7E6E6"
    accent1: str = "4472C4"
    accent2: str = "ED7D31"
    accent3: str = "A5A5A5"
    accent4: str = "FFC000"
    accent5: str = "5B9BD5"
    accent6: str = "70AD47"
    hlink: str = "0563C1"
    folHlink: str = "954F72"

    # Fonts
    major_font: str = "Inter"
    minor_font: str = "Inter"

    # Effect styles (3 styles for subtle, moderate, intense)
    effect_styles: Optional[List["Effects"]] = None

    @property
    def width_emu(self) -> int:
        """Slide width in EMU."""
        return self.aspect_ratio.width_emu

    @property
    def height_emu(self) -> int:
        """Slide height in EMU."""
        return self.aspect_ratio.height_emu

    @property
    def slide_type(self) -> str:
        """PowerPoint slide type identifier."""
        # Map common aspect ratios to PowerPoint slide types
        key = self.aspect_ratio.key
        type_map = {
            "16_9": "screen16x9",
            "16_10": "screen16x10",
            "4_3": "screen4x3",
            "a4_landscape": "A4",
            "a4_portrait": "A4",
            "letter_landscape": "letter",
            "letter_portrait": "letter",
        }
        return type_map.get(key, "custom")


@dataclass
class DesignVariant:
    """A design variant with colors and fonts that can be applied to multiple aspect ratios."""

    name: str

    # Theme colors (hex without #)
    dk1: str = "000000"
    lt1: str = "FFFFFF"
    dk2: str = "44546A"
    lt2: str = "E7E6E6"
    accent1: str = "4472C4"
    accent2: str = "ED7D31"
    accent3: str = "A5A5A5"
    accent4: str = "FFC000"
    accent5: str = "5B9BD5"
    accent6: str = "70AD47"
    hlink: str = "0563C1"
    folHlink: str = "954F72"

    # Fonts
    major_font: str = "Inter"
    minor_font: str = "Inter"

    # Effect styles (3 styles for subtle, moderate, intense)
    effect_styles: Optional[List["Effects"]] = None

    @classmethod
    def from_color_theme(
        cls,
        name: str,
        color_theme: ColorTheme,
        typography: Optional[TypographyScheme] = None,
    ) -> DesignVariant:
        """Create DesignVariant from IR models."""

        def strip_hash(color: str) -> str:
            return color.lstrip("#").upper()

        return cls(
            name=name,
            dk1=strip_hash(color_theme.dk1),
            lt1=strip_hash(color_theme.lt1),
            dk2=strip_hash(color_theme.dk2),
            lt2=strip_hash(color_theme.lt2),
            accent1=strip_hash(color_theme.accent1),
            accent2=strip_hash(color_theme.accent2),
            accent3=strip_hash(color_theme.accent3),
            accent4=strip_hash(color_theme.accent4),
            accent5=strip_hash(color_theme.accent5),
            accent6=strip_hash(color_theme.accent6),
            hlink=strip_hash(color_theme.hyperlink),
            folHlink=strip_hash(color_theme.hyperlink_followed),
            major_font=typography.heading_font if typography else "Inter",
            minor_font=typography.body_font if typography else "Inter",
        )


class SuperThemeEmitter:
    """Emitter for Microsoft PowerPoint SuperTheme packages.

    Uses SSOT templates from xml-structures/ecma-376/supertheme/templates/.
    XML structure comes from templates; Python only substitutes values.

    Example:
        # Create with design variants and aspect ratios
        emitter = SuperThemeEmitter()
        emitter.add_design_variant(DesignVariant(
            name="Corporate Blue",
            accent1="0066CC",
            accent2="FF6600",
        ))
        emitter.add_aspect_ratios(["16_9", "a4_landscape", "a4_portrait"])
        data = emitter.emit()  # Returns bytes
    """

    # Standard slide layout types in PowerPoint
    SLIDE_LAYOUT_TYPES = [
        ("title", "Title Slide"),
        ("obj", "Title and Content"),
        ("secHead", "Section Header"),
        ("twoObj", "Two Content"),
        ("twoTxTwoObj", "Comparison"),
        ("titleOnly", "Title Only"),
        ("blank", "Blank"),
        ("objTx", "Content with Caption"),
        ("picTx", "Picture with Caption"),
        ("vertTx", "Vertical Text"),
        ("vertTitleAndTx", "Vertical Title and Text"),
    ]

    def __init__(
        self,
        template_root: str | Path | None = None,
        use_soffice_thumbnails: bool = False,
    ) -> None:
        """Initialize SuperTheme emitter.

        Args:
            template_root: Optional custom template root directory
            use_soffice_thumbnails: If True, use LibreOffice/soffice to generate
                real theme thumbnails by rendering a sample PPTX. Requires
                LibreOffice to be installed. Falls back to placeholder thumbnails
                if soffice is not available.
        """
        self.resolver = TemplateResolver("supertheme", template_root)
        self.thmx_resolver = TemplateResolver("thmx", template_root)
        self.pptx_resolver = TemplateResolver("presentationml", template_root)
        self.design_variants: List[DesignVariant] = []
        self.aspect_ratio_keys: List[str] = []
        self._guid_cache: Dict[str, str] = {}
        self._use_soffice_thumbnails = use_soffice_thumbnails
        self._soffice_available: Optional[bool] = None
        self.slide_regions: Optional[Dict[str, Any]] = None

    def add_design_variant(self, variant: DesignVariant) -> None:
        """Add a design variant to the SuperTheme."""
        self.design_variants.append(variant)

    def add_aspect_ratios(self, keys: List[str]) -> None:
        """Add aspect ratios by key (e.g., '16_9', 'a4_landscape').

        Args:
            keys: List of aspect ratio keys from ASPECT_RATIOS
        """
        for key in keys:
            if key not in ASPECT_RATIOS:
                raise ValueError(f"Unknown aspect ratio: {key}")
            if key not in self.aspect_ratio_keys:
                self.aspect_ratio_keys.append(key)

    def _read_template(self, template_name: str) -> str:
        """Read template content from resolver."""
        return self.resolver.read_text(template_name)

    def _read_thmx_template_tree(self, template_name: str) -> etree._Element:
        """Read and parse thmx template as lxml tree (cached)."""
        return self.thmx_resolver.read_tree(template_name)

    def _get_design_guid(self, design_name: str) -> str:
        """Get or generate consistent GUID for design variant group."""
        if design_name not in self._guid_cache:
            hash_input = f"tokenmoulds-design-{design_name}".encode("utf-8")
            hash_hex = hashlib.md5(hash_input).hexdigest()
            guid = f"{{{hash_hex[:8]}-{hash_hex[8:12]}-{hash_hex[12:16]}-{hash_hex[16:20]}-{hash_hex[20:32]}}}"
            self._guid_cache[design_name] = guid.upper()
        return self._guid_cache[design_name]

    def _build_variants(self) -> List[SuperThemeVariant]:
        """Build all SuperTheme variants (design × aspect ratio).

        Variants are ordered BY SIZE FIRST to match Microsoft's convention:
        - All designs at size 1 (e.g., 16:9)
        - All designs at size 2 (e.g., 4:3)
        - etc.

        This ordering is important for PowerPoint's Variants gallery, which
        displays color variants for the current slide size.
        """
        variants = []
        variant_id = 1

        # Microsoft orders by size first, then by design
        for ar_key in self.aspect_ratio_keys:
            aspect_ratio = ASPECT_RATIOS[ar_key]

            for design in self.design_variants:
                guid = self._get_design_guid(design.name)
                variant_name = f"{design.name} {aspect_ratio.name}"

                variant = SuperThemeVariant(
                    name=variant_name,
                    design_name=design.name,
                    aspect_ratio=aspect_ratio,
                    variant_id=variant_id,
                    guid=guid,
                    dk1=design.dk1,
                    lt1=design.lt1,
                    dk2=design.dk2,
                    lt2=design.lt2,
                    accent1=design.accent1,
                    accent2=design.accent2,
                    accent3=design.accent3,
                    accent4=design.accent4,
                    accent5=design.accent5,
                    accent6=design.accent6,
                    hlink=design.hlink,
                    folHlink=design.folHlink,
                    major_font=design.major_font,
                    minor_font=design.minor_font,
                    effect_styles=design.effect_styles,
                )
                variants.append(variant)
                variant_id += 1

        return variants

    def _build_theme_xml(self, variant: SuperThemeVariant) -> bytes:
        """Build theme XML for a variant using xml_helpers.

        Uses cached parsed tree from TemplateResolver for performance.
        """
        root = self._read_thmx_template_tree("theme.xml")

        # Set theme and scheme names
        set_theme_name(root, f"{variant.design_name} Theme")
        set_scheme_name(root, "clrScheme", f"{variant.design_name} Colors")
        set_scheme_name(root, "fontScheme", f"{variant.design_name} Fonts")
        set_scheme_name(root, "fmtScheme", f"{variant.design_name} Effects")

        # Set colors using xml_helpers (handles sysClr/srgbClr automatically)
        set_color_value(root, "dk1", variant.dk1)
        set_color_value(root, "lt1", variant.lt1)
        set_color_value(root, "dk2", variant.dk2)
        set_color_value(root, "lt2", variant.lt2)
        set_color_value(root, "accent1", variant.accent1)
        set_color_value(root, "accent2", variant.accent2)
        set_color_value(root, "accent3", variant.accent3)
        set_color_value(root, "accent4", variant.accent4)
        set_color_value(root, "accent5", variant.accent5)
        set_color_value(root, "accent6", variant.accent6)
        set_color_value(root, "hlink", variant.hlink)
        set_color_value(root, "folHlink", variant.folHlink)

        # Set font schemes
        set_font_typeface(root, "majorFont", "latin", variant.major_font)
        set_font_typeface(root, "minorFont", "latin", variant.minor_font)

        # Apply effect styles if provided
        if variant.effect_styles and len(variant.effect_styles) == 3:
            self._apply_effect_styles(root, variant.effect_styles)

        return serialize_tree(root)

    def _apply_effect_styles(
        self,
        root: etree._Element,
        effect_styles: "List[Effects]",
    ) -> None:
        """Apply effect styles to theme fmtScheme effectStyleLst.

        OOXML themes have exactly 3 effect styles: subtle, moderate, intense.
        The effect styles are defined in the effectStyleLst within fmtScheme.

        Args:
            root: Theme XML root element
            effect_styles: List of exactly 3 Effects (subtle, moderate, intense)
        """
        if len(effect_styles) != 3:
            return

        # Find effectStyleLst in fmtScheme
        ns = {"a": A_NS}
        effect_lst = find_element(root, ".//a:effectStyleLst", ns)
        if effect_lst is None:
            return

        # Remove existing effect styles
        for child in list(effect_lst):
            effect_lst.remove(child)

        # Add new effect styles
        for effects in effect_styles:
            create_effect_style(effect_lst, effects)

    def _build_presentation_xml(self, variant: SuperThemeVariant) -> str:
        """Build presentation XML for a variant."""
        template = self._read_template("presentation.xml")
        return Template(template).safe_substitute(
            WIDTH_EMU=str(variant.width_emu),
            HEIGHT_EMU=str(variant.height_emu),
            SLIDE_TYPE=variant.slide_type,
        )

    def _check_soffice_available(self) -> bool:
        """Check if soffice/LibreOffice is available (cached)."""
        if self._soffice_available is None:
            self._soffice_available = is_soffice_available()
        return self._soffice_available

    # Public emission/save delegated to free functions in
    # ``supertheme_emission``. These thin wrappers preserve the
    # public ``emitter.emit()`` / ``emitter.save()`` API.
    def emit(self) -> bytes:
        return _emit(self)

    def save(self, path: str | Path) -> None:
        _save(self, path)

    # Class-attached pointer for callers/tests that import the layout-recipe
    # helper directly (it's a pure function on its inputs).
    _apply_layout_recipe = staticmethod(apply_layout_recipe)


def create_supertheme(
    design_variants: List[DesignVariant],
    aspect_ratio_keys: List[str],
    output_path: Optional[str | Path] = None,
    use_soffice_thumbnails: bool = False,
) -> bytes:
    """Convenience function to create a SuperTheme.

    Args:
        design_variants: List of design variants
        aspect_ratio_keys: List of aspect ratio keys (e.g., ['16_9', 'a4_landscape'])
        output_path: Optional path to save the SuperTheme
        use_soffice_thumbnails: If True, use LibreOffice to generate real thumbnails

    Returns:
        Bytes content of the SuperTheme archive
    """
    emitter = SuperThemeEmitter(use_soffice_thumbnails=use_soffice_thumbnails)
    for variant in design_variants:
        emitter.add_design_variant(variant)
    emitter.add_aspect_ratios(aspect_ratio_keys)

    data = emitter.emit()

    if output_path:
        emitter.save(output_path)

    return data


__all__ = [
    "SuperThemeEmitter",
    "SuperThemeVariant",
    "DesignVariant",
    "create_supertheme",
    "extract_design_variants_from_supertheme",
    "patch_supertheme",
    "patch_supertheme_from_source",
    "is_soffice_available",
]
