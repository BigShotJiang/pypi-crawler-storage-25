"""Design system resolution - typography, color, and spacing calculations.

This package provides the core design token resolution engine and supporting
utilities for generating OOXML-compatible typography and color tokens.

Example:
    from tokenmoulds.design import DesignResolutionEngine, ScaleRatio

    engine = DesignResolutionEngine(
        fonts=font_config,
        brand=brand_config,
        locale="en-US",
        colors=color_inputs,
        scale_ratio=ScaleRatio.MAJOR_THIRD,
    )
    design = engine.resolve()
"""

from typing import TYPE_CHECKING, Any as _Any

from tokenmoulds._lazy import lazy_dir, resolve_lazy_symbol_or_module

if TYPE_CHECKING:
    from tokenmoulds.design import engine, policy, roles, services, units
    from tokenmoulds.design.engine import (
        Baseline,
        DesignResolutionEngine,
        LineHeightMode,
        ResolvedDesign,
        RoleTypography,
        ScaleRatio,
        SpacingScale,
        TypeScaleStep,
    )
    from tokenmoulds.design.policy_adapter import (
        DesignConfig,
        PolicyAwareDesignEngine,
        create_design_engine,
    )
    from tokenmoulds.design.roles import ROLE_SCALE_MAP

__all__ = [
    # Engine
    "DesignResolutionEngine",
    "ResolvedDesign",
    # Policy-aware engine
    "PolicyAwareDesignEngine",
    "DesignConfig",
    "create_design_engine",
    # Data classes
    "Baseline",
    "RoleTypography",
    "TypeScaleStep",
    "SpacingScale",
    # Enums
    "ScaleRatio",
    "LineHeightMode",
    # Roles
    "ROLE_SCALE_MAP",
    # Units
    "units",
    # Submodules
    "engine",
    "roles",
    "policy",
    "services",
]

# Symbol -> module mapping for lazy loading
_symbol_map = {
    # engine.py exports
    "DesignResolutionEngine": "engine",
    "ResolvedDesign": "engine",
    "Baseline": "engine",
    "RoleTypography": "engine",
    "TypeScaleStep": "engine",
    "SpacingScale": "engine",
    "ScaleRatio": "engine",
    "LineHeightMode": "engine",
    # roles.py exports
    "ROLE_SCALE_MAP": "roles",
    # policy_adapter.py exports
    "PolicyAwareDesignEngine": "policy_adapter",
    "DesignConfig": "policy_adapter",
    "create_design_engine": "policy_adapter",
}

# Submodule mapping
_module_map = {
    "engine": "engine",
    "roles": "roles",
    "units": "units",
    "policy": "policy",
    "services": "services",
}


def __getattr__(name: str) -> _Any:  # PEP 562
    """Lazy attribute loading for faster imports."""
    return resolve_lazy_symbol_or_module(
        name,
        module_globals=globals(),
        package=__name__,
        symbol_modules=_symbol_map,
        module_aliases=_module_map,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
