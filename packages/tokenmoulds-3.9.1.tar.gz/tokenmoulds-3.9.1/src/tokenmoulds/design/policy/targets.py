"""Policy targets for design decisions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator


@dataclass(frozen=True)
class PolicyTarget:
    """A named target for policy decisions."""

    name: str
    description: str = ""

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PolicyTarget):
            return self.name == other.name
        return False


# Pre-defined policy targets
TYPOGRAPHY_TARGET = PolicyTarget("typography", "Font selection and sizing")
COLOR_TARGET = PolicyTarget("color", "Color theme and accessibility")
SPACING_TARGET = PolicyTarget("spacing", "Spacing and vertical rhythm")
FONT_EMBEDDING_TARGET = PolicyTarget("font_embedding", "Font embedding strategy")
ACCESSIBILITY_TARGET = PolicyTarget("accessibility", "Accessibility requirements")


class TargetRegistry:
    """Registry of available policy targets."""

    def __init__(self) -> None:
        self._targets: dict[str, PolicyTarget] = {}

    def register(self, target: PolicyTarget) -> None:
        """Register a policy target."""
        self._targets[target.name] = target

    def get(self, name: str) -> PolicyTarget | None:
        """Get a target by name."""
        return self._targets.get(name)

    def iter_targets(self) -> Iterator[PolicyTarget]:
        """Iterate over all registered targets."""
        yield from self._targets.values()

    @classmethod
    def default(cls) -> TargetRegistry:
        """Create a registry with default targets."""
        registry = cls()
        registry.register(TYPOGRAPHY_TARGET)
        registry.register(COLOR_TARGET)
        registry.register(SPACING_TARGET)
        registry.register(FONT_EMBEDDING_TARGET)
        registry.register(ACCESSIBILITY_TARGET)
        return registry


__all__ = [
    "PolicyTarget",
    "TargetRegistry",
    "TYPOGRAPHY_TARGET",
    "COLOR_TARGET",
    "SPACING_TARGET",
    "FONT_EMBEDDING_TARGET",
    "ACCESSIBILITY_TARGET",
]
