"""Typography unit conversion utilities for OOXML documents.

This package provides conversion between the unit systems used in OOXML:
- EMU (English Metric Units): Base unit, 914400 EMU = 1 inch
- Points (pt): Standard typographic unit, 72 pt = 1 inch
- Twips: 1/20 of a point, used in WordprocessingML

The Measurement class provides type-safe dimensions that prevent unit mixing:

    from tokenmoulds.design.units import Measurement

    # Create from any unit - stores internally as EMU
    margin = Measurement.from_inches(1.0)
    spacing = Measurement.from_pt(12.0)

    # Convert at boundaries (when emitting to OOXML)
    emu_value = margin.emu      # For DrawingML
    twips_value = spacing.twips  # For WordprocessingML

    # Type-safe arithmetic
    total = margin + spacing
    half = margin / 2

For simple one-off conversions, use the convenience functions:

    from tokenmoulds.design.units import pt_to_emu, pt_to_twips

    emu = pt_to_emu(12.0)    # 152400
    twips = pt_to_twips(12.0) # 240
"""

from .scalars import (
    EMU_PER_CM,
    EMU_PER_INCH,
    EMU_PER_MM,
    EMU_PER_POINT,
    EMU_PER_TWIP,
    HALF_POINTS_PER_POINT,
    HUNDREDTHS_PER_POINT,
    POINTS_PER_INCH,
    TWIPS_PER_INCH,
    TWIPS_PER_POINT,
)
from .conversion import (
    TypographyContext,
    TypographyConverter,
    emu_to_inches,
    emu_to_pt,
    emu_to_twips,
    inches_to_emu,
    pt_to_emu,
    pt_to_twips,
    pt_to_hundredths,
    pt_to_half_points,
    twips_to_emu,
    twips_to_pt,
)
from .measurement import (
    Measurement,
    ZERO,
    ONE_INCH,
    ONE_PT,
    ONE_TWIP,
    MARGIN_NORMAL,
    MARGIN_NARROW,
    MARGIN_WIDE,
    A4_WIDTH,
    A4_HEIGHT,
    LETTER_WIDTH,
    LETTER_HEIGHT,
)

__all__ = [
    # Type-safe measurement
    "Measurement",
    "ZERO",
    "ONE_INCH",
    "ONE_PT",
    "ONE_TWIP",
    "MARGIN_NORMAL",
    "MARGIN_NARROW",
    "MARGIN_WIDE",
    "A4_WIDTH",
    "A4_HEIGHT",
    "LETTER_WIDTH",
    "LETTER_HEIGHT",
    # Constants
    "EMU_PER_INCH",
    "EMU_PER_POINT",
    "EMU_PER_TWIP",
    "EMU_PER_CM",
    "EMU_PER_MM",
    "POINTS_PER_INCH",
    "TWIPS_PER_POINT",
    "TWIPS_PER_INCH",
    "HALF_POINTS_PER_POINT",
    "HUNDREDTHS_PER_POINT",
    # Classes
    "TypographyContext",
    "TypographyConverter",
    # Functions (for simple one-off conversions)
    "pt_to_emu",
    "pt_to_twips",
    "pt_to_hundredths",
    "pt_to_half_points",
    "emu_to_pt",
    "emu_to_twips",
    "twips_to_pt",
    "twips_to_emu",
    "inches_to_emu",
    "emu_to_inches",
]
