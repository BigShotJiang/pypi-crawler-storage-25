"""Resolved design model types used by the design engine."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Dict, Literal, Optional, Tuple

from tokenmoulds.design.units import (
    HALF_POINTS_PER_POINT,
    pt_to_emu,
    pt_to_twips,
)

if TYPE_CHECKING:
    from tokenmoulds.design.page_geometry import PageGeometry


class ScaleRatio(Enum):
    """Classic typographic scale ratios."""

    MINOR_SECOND = 1.067  # Tight
    MAJOR_SECOND = 1.125  # Good for dense UI
    MINOR_THIRD = 1.2  # Balanced
    MAJOR_THIRD = 1.25  # Classic
    PERFECT_FOURTH = 1.333  # Strong contrast
    AUGMENTED_FOURTH = 1.414  # Geometric (sqrt 2)
    PERFECT_FIFTH = 1.5  # Dramatic
    GOLDEN_RATIO = 1.618  # Natural harmony


class LineHeightMode(Enum):
    """How line height is calculated."""

    MULTIPLIER = "multiplier"  # Relative to font size
    SNAPPED = "snapped"  # Snapped to baseline grid


@dataclass(frozen=True)
class Baseline:
    """Baseline grid for vertical rhythm."""

    grid_emu: int
    grid_pt: float

    @property
    def grid_twips(self) -> int:
        return pt_to_twips(self.grid_pt)

    def snap_pt(self, value_pt: float) -> float:
        """Snap a point value to the baseline grid."""
        if self.grid_pt <= 0:
            return value_pt
        return round(value_pt / self.grid_pt) * self.grid_pt

    def snap_up_pt(self, value_pt: float) -> float:
        """Snap a point value up to next baseline grid line."""
        if self.grid_pt <= 0:
            return value_pt
        return math.ceil(value_pt / self.grid_pt) * self.grid_pt


LigatureMode = Literal[
    "none",
    "standard",
    "contextual",
    "historical",
    "discretional",
    "standardContextual",
    "all",
]
NumberForm = Literal["default", "lining", "oldStyle"]
NumberSpacing = Literal["default", "proportional", "tabular"]


@dataclass(frozen=True)
class OpenTypeSettings:
    """Derived OpenType feature settings.

    These are derived from brand tone, content role, and typographic context.
    """

    # Ligatures: formal brands use standard, casual brands can use all
    ligatures: LigatureMode = "standard"
    # Number form: lining for headers/tables, oldstyle for body
    number_form: NumberForm = "default"
    # Number spacing: tabular for tables/data, proportional for text
    number_spacing: NumberSpacing = "default"
    # Contextual alternates: usually on
    contextual_alternates: bool = True
    # Stylistic sets (font-specific)
    stylistic_sets: Tuple[int, ...] = ()


@dataclass(frozen=True)
class TrackingSettings:
    """Derived tracking (letter-spacing) settings.

    Tracking varies by:
    - Font size: larger text needs tighter tracking
    - Role: headings tighter, body normal, captions looser
    - Caps: all-caps and small-caps need looser tracking
    """

    # Base tracking in twips (20 twips = 1pt)
    tracking_twips: int = 0
    # Tracking for all-caps text (always looser)
    caps_tracking_twips: int = 80
    # Tracking for small-caps (moderately looser)
    small_caps_tracking_twips: int = 40


@dataclass(frozen=True)
class RoleTypography:
    """Typography settings for a semantic role."""

    font_family: str
    font_size_pt: float
    line_height_pt: float
    kerning_emu: int
    space_before_pt: float
    space_after_pt: float
    # Derived OpenType and tracking settings
    opentype: OpenTypeSettings = OpenTypeSettings()
    tracking: TrackingSettings = TrackingSettings()

    @property
    def font_size_twips(self) -> int:
        return pt_to_twips(self.font_size_pt)

    @property
    def font_size_half_points(self) -> int:
        """Font size in half-points (OOXML sz attribute)."""
        return int(round(self.font_size_pt * HALF_POINTS_PER_POINT))

    @property
    def line_height_twips(self) -> int:
        return pt_to_twips(self.line_height_pt)

    @property
    def space_before_twips(self) -> int:
        return pt_to_twips(self.space_before_pt)

    @property
    def space_after_twips(self) -> int:
        return pt_to_twips(self.space_after_pt)

    @property
    def line_height_multiplier(self) -> float:
        """Effective line height as multiplier of font size."""
        if self.font_size_pt == 0:
            return 1.0
        return self.line_height_pt / self.font_size_pt


@dataclass(frozen=True)
class TypeScaleStep:
    """A single step in the type scale."""

    index: int
    name: str
    size_pt: float
    size_emu: int
    size_twips: int


@dataclass(frozen=True)
class SpacingScale:
    """Spacing scale based on baseline grid."""

    baseline_pt: float
    scale: Dict[str, float]  # name -> pt value

    def get_pt(self, name: str) -> float:
        return self.scale.get(name, self.baseline_pt)

    def get_twips(self, name: str) -> int:
        return pt_to_twips(self.get_pt(name))

    def get_emu(self, name: str) -> int:
        return pt_to_emu(self.get_pt(name))


@dataclass(frozen=True)
class ResolvedDesign:
    """Complete resolved design system."""

    baseline: Baseline
    type_scale: Tuple[TypeScaleStep, ...]
    roles: Dict[str, RoleTypography]
    spacing: SpacingScale
    colors: Dict[str, str]
    page_geometry: Optional[PageGeometry] = None

    def get_type_step(self, name: str) -> Optional[TypeScaleStep]:
        """Get type scale step by name."""
        for step in self.type_scale:
            if step.name == name:
                return step
        return None

    @property
    def has_page_geometry(self) -> bool:
        """Check if page geometry is available."""
        return self.page_geometry is not None
