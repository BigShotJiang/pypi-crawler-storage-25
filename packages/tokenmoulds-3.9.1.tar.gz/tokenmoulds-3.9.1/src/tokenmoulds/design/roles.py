# Semantic role → scale index mapping
# Single authority for typography hierarchy

ROLE_SCALE_MAP = {
    "display.primary": 8,
    "display.section": 5,
    "display.subsection": 4,
    "text.body.primary": 2,
    "text.body.secondary": 1,
    "text.meta": 1,
    "text.ui": 0,
    "text.annotation": 1,
    "text.annotation.marker": 0,
    "text.table.header": 1,
    "text.table.body": 1,
    "inline.semantic": 2,
}
