"""Bundled templates for TokenMoulds MCP server.

Provides pre-built Office templates with all 276 styles themed.
Used as fallback when no custom tokens are configured.
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

# Template directory relative to this module
TEMPLATES_DIR = Path(__file__).parent / "release"

TemplateFormat = Literal["word", "powerpoint", "excel"]

TEMPLATE_FILES: dict[TemplateFormat, str] = {
    "word": "word.dotx",
    "powerpoint": "powerpoint.potx",
    "excel": "excel.xltx",
}


def get_bundled_template(format: TemplateFormat) -> Path:
    """Get path to bundled template for the specified format.

    Args:
        format: Template format - "word", "powerpoint", or "excel"

    Returns:
        Path to the bundled template file

    Raises:
        FileNotFoundError: If bundled template is not found
        ValueError: If format is not recognized
    """
    if format not in TEMPLATE_FILES:
        raise ValueError(
            f"Unknown format: {format}. Expected one of: {list(TEMPLATE_FILES.keys())}"
        )

    template_path = TEMPLATES_DIR / TEMPLATE_FILES[format]

    if not template_path.exists():
        raise FileNotFoundError(
            f"Bundled template not found: {template_path}. "
            "This may indicate an incomplete installation."
        )

    return template_path


def get_bundled_template_bytes(format: TemplateFormat) -> bytes:
    """Get bundled template as bytes.

    Args:
        format: Template format - "word", "powerpoint", or "excel"

    Returns:
        Template file contents as bytes
    """
    return get_bundled_template(format).read_bytes()


def list_bundled_templates() -> dict[TemplateFormat, Path]:
    """List all available bundled templates.

    Returns:
        Dictionary mapping format names to template paths
    """
    return {
        format: TEMPLATES_DIR / filename
        for format, filename in TEMPLATE_FILES.items()
        if (TEMPLATES_DIR / filename).exists()
    }


__all__ = [
    "get_bundled_template",
    "get_bundled_template_bytes",
    "list_bundled_templates",
    "TemplateFormat",
    "TEMPLATES_DIR",
]
