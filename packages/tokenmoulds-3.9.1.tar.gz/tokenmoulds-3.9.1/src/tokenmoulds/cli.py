#!/usr/bin/env python3
"""
TokenMoulds CLI Entry Point
Command-line interface for the formulaic design token system
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import List

from tokenmoulds import __version__
from tokenmoulds.emitters import (
    TemplateResolver,
)

# Re-export public API so existing callers (tests, __main__) keep working.
from tokenmoulds.cli_generate import (
    create_summary_report as create_summary_report,
    generate_tokens,
)  # noqa: F401
from tokenmoulds.cli_utils import (  # noqa: F401
    _count_tokens,
    parse_font_pair,
    validate_brand_tone,
    validate_content_density,
    validate_hex_color,
)
from tokenmoulds.dtcg.generator import TokenGenerator  # noqa: F401
from tokenmoulds.font_pair_validation import (
    font_pair_validation_exit_code,
    font_pair_validation_payload,
    format_font_pair_validation_text,
    validate_font_pair_catalog,
)


def run_mcp_server(args: List[str]) -> None:
    """Run the MCP server subcommand."""
    import argparse as mcp_argparse

    parser = mcp_argparse.ArgumentParser(
        prog="tokenmoulds mcp-server",
        description="Start TokenMoulds MCP server for AI document generation",
    )
    parser.add_argument(
        "--tokens",
        type=str,
        help="Path to design tokens directory",
    )
    parser.add_argument(
        "--brands",
        type=str,
        help="Path to multi-brand directory (alternative to --tokens)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="./generated",
        help="Output directory for generated documents (default: ./generated)",
    )

    parsed = parser.parse_args(args)

    from pathlib import Path

    from tokenmoulds.mcp import run_server

    tokens_path = Path(parsed.tokens) if parsed.tokens else None
    brands_path = Path(parsed.brands) if parsed.brands else None
    output_path = Path(parsed.output)

    print("\U0001f680 Starting TokenMoulds MCP Server...", file=sys.stderr)
    if tokens_path:
        print(f"   Tokens: {tokens_path}", file=sys.stderr)
    if brands_path:
        print(f"   Brands: {brands_path}", file=sys.stderr)
    print(f"   Output: {output_path}", file=sys.stderr)
    print("   Ready for MCP connections", file=sys.stderr)

    run_server(
        tokens_path=tokens_path,
        brands_path=brands_path,
        output_path=output_path,
    )


def run_google_suite_bundle(args: List[str]) -> None:
    """Generate or deploy a Google Apps Script bundle from a stored plan."""
    parser = argparse.ArgumentParser(
        prog="tokenmoulds google-suite",
        description=(
            "Generate or deploy a Google Apps Script bundle from a stored "
            "ArtifactPlan. This is Apps Script only."
        ),
    )
    parser.add_argument(
        "--artifact-id",
        help=(
            "Artifact plan ID under generated/plans/<artifact_id>/plan.json. "
            "Optional when --plan-file is provided."
        ),
    )
    parser.add_argument(
        "--plan-file",
        type=str,
        help="Path to an ArtifactPlan JSON file to load into the bundle generator",
    )
    parser.add_argument(
        "--target-format",
        type=str,
        choices=["docx", "pptx", "xlsx"],
        help="Override the Google Workspace surface to generate",
    )
    parser.add_argument(
        "--title",
        type=str,
        help="Override the generated script title",
    )
    parser.add_argument(
        "--script-name",
        type=str,
        help="Override the generated Apps Script filename stem",
    )
    parser.add_argument(
        "--scopes",
        nargs="*",
        help=(
            "Override the Apps Script OAuth scopes. Provide one or more "
            "scope URLs after --scopes."
        ),
    )
    parser.add_argument(
        "--deploy",
        action="store_true",
        help="Deploy the generated bundle to the Apps Script API instead of only writing local files",
    )
    parser.add_argument(
        "--script-id",
        type=str,
        help="Existing Apps Script project ID to update instead of creating a new project",
    )
    parser.add_argument(
        "--parent-id",
        type=str,
        help="Optional Google Drive file ID to bind a new Apps Script project to",
    )
    parser.add_argument(
        "--access-token",
        type=str,
        help="OAuth bearer token for the Apps Script API",
    )
    parser.add_argument(
        "--access-token-env",
        type=str,
        default="TOKENMOULDS_GOOGLE_ACCESS_TOKEN",
        help="Environment variable to read the OAuth bearer token from",
    )
    parser.add_argument(
        "--api-base-url",
        type=str,
        default="https://script.googleapis.com/v1",
        help="Apps Script API base URL",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./generated",
        help="Output directory containing plans and generated bundles",
    )
    parsed = parser.parse_args(args)

    from pathlib import Path

    from tokenmoulds.mcp.artifact_plan import (
        ArtifactPlanError,
        artifact_plan_from_mapping,
    )
    from tokenmoulds.mcp.server import create_server

    server = create_server(output_path=Path(parsed.output_dir))

    artifact_id = str(parsed.artifact_id or "").strip()
    if parsed.plan_file:
        plan_path = Path(parsed.plan_file)
        try:
            plan_payload = json.loads(plan_path.read_text(encoding="utf-8"))
        except OSError as exc:
            parser.error(f"Unable to read plan file {plan_path}: {exc}")
        except json.JSONDecodeError as exc:
            parser.error(f"Plan file must be valid JSON: {plan_path}: {exc}")
        if not isinstance(plan_payload, dict):
            parser.error(f"Plan file must contain a JSON object: {plan_path}")
        try:
            plan = artifact_plan_from_mapping(plan_payload)
        except ArtifactPlanError as exc:
            parser.error(str(exc))
        if artifact_id and artifact_id != plan.artifact_id:
            parser.error(
                "artifact-id does not match plan-file artifact_id: "
                f"{artifact_id!r} != {plan.artifact_id!r}"
            )
        artifact_id = plan.artifact_id
        server.artifact_plans[artifact_id] = plan.to_dict()

    if not artifact_id:
        parser.error("--artifact-id is required unless --plan-file is provided")

    dispatch_arguments: dict[str, object] = {"artifact_id": artifact_id}
    if parsed.target_format:
        dispatch_arguments["target_format"] = parsed.target_format
    if parsed.title:
        dispatch_arguments["title"] = parsed.title
    if parsed.script_name:
        dispatch_arguments["script_name"] = parsed.script_name
    if parsed.scopes:
        dispatch_arguments["scopes"] = parsed.scopes
    if parsed.script_id:
        dispatch_arguments["script_id"] = parsed.script_id
    if parsed.parent_id:
        dispatch_arguments["parent_id"] = parsed.parent_id
    if parsed.access_token:
        dispatch_arguments["access_token"] = parsed.access_token
    if parsed.access_token_env:
        dispatch_arguments["access_token_env"] = parsed.access_token_env
    if parsed.api_base_url:
        dispatch_arguments["api_base_url"] = parsed.api_base_url

    tool_name = (
        "deploy_google_apps_script_bundle"
        if parsed.deploy
        else "generate_google_apps_script_bundle"
    )
    result = asyncio.run(server._dispatch_tool(tool_name, dispatch_arguments))
    if result.get("error"):
        raise SystemExit(str(result["error"]))

    print(json.dumps(result, indent=2, sort_keys=True))


def run_google_suite_roundtrip(args: List[str]) -> None:
    """Roundtrip a local Office/ODF file through Google Workspace."""
    parser = argparse.ArgumentParser(
        prog="tokenmoulds google-roundtrip",
        description=(
            "Upload a local Office/ODF file to Drive, convert it to native "
            "Google Workspace format, export it back, and emit a diff report."
        ),
    )
    parser.add_argument(
        "path",
        nargs="?",
        help="Local .pptx/.docx/.xlsx/.odp/.odt/.ods file to roundtrip",
    )
    parser.add_argument(
        "--artifact-id",
        type=str,
        help="Use a compiled artifact from generated/<artifact_id>/compile-result.json",
    )
    parser.add_argument(
        "--target-format",
        type=str,
        choices=["pptx", "docx", "xlsx", "odp", "odt", "ods"],
        help="Override the format inferred from the source filename",
    )
    parser.add_argument(
        "--folder-id",
        type=str,
        help="Drive folder ID for staging files; omitted means create a temporary staging folder",
    )
    parser.add_argument(
        "--no-create-staging-folder",
        action="store_true",
        help="Require --folder-id instead of creating a temporary Drive folder",
    )
    parser.add_argument(
        "--subject",
        type=str,
        help="Workspace user to impersonate via domain-wide delegation",
    )
    parser.add_argument(
        "--creds",
        type=str,
        dest="creds_path",
        help="Service-account JSON path",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./generated",
        help="Output directory for roundtrip artifacts",
    )
    parser.add_argument(
        "--keep-drive-files",
        action="store_true",
        help="Keep the raw and native staging files in Drive",
    )
    parser.add_argument(
        "--discard-artifacts",
        action="store_true",
        help="Delete local roundtrip staging artifacts after the run",
    )
    parser.add_argument(
        "--no-validate",
        action="store_true",
        help="Skip TokenMoulds/openxml-audit validation of the exported file",
    )
    parsed = parser.parse_args(args)

    from pathlib import Path

    from tokenmoulds.mcp.server import create_server

    if not parsed.path and not parsed.artifact_id:
        parser.error("path or --artifact-id is required")

    server = create_server(output_path=Path(parsed.output_dir))
    dispatch_arguments: dict[str, object] = {
        "output_dir": parsed.output_dir,
        "keep_drive_files": parsed.keep_drive_files,
        "keep_artifacts": not parsed.discard_artifacts,
        "validate_output": not parsed.no_validate,
        "create_staging_folder": not parsed.no_create_staging_folder,
    }
    if parsed.path:
        dispatch_arguments["path"] = parsed.path
    if parsed.artifact_id:
        dispatch_arguments["artifact_id"] = parsed.artifact_id
    if parsed.target_format:
        dispatch_arguments["target_format"] = parsed.target_format
    if parsed.folder_id:
        dispatch_arguments["folder_id"] = parsed.folder_id
    if parsed.subject:
        dispatch_arguments["subject"] = parsed.subject
    if parsed.creds_path:
        dispatch_arguments["creds_path"] = parsed.creds_path

    result = asyncio.run(
        server._dispatch_tool("run_google_suite_roundtrip", dispatch_arguments)
    )
    if result.get("error"):
        raise SystemExit(str(result["error"]))
    print(json.dumps(result, indent=2, sort_keys=True))


def run_validate_font_pairs(args: List[str]) -> None:
    """Validate configured font-pair catalogs against font providers."""
    parser = argparse.ArgumentParser(
        prog="tokenmoulds validate-font-pairs",
        description="Validate font-pair catalog families and embeddable faces",
    )
    parser.add_argument(
        "--catalog-dir",
        default="data/font_pairs",
        help="Directory containing font-pair YAML files or a single YAML file",
    )
    parser.add_argument(
        "--fonts-dir",
        default="data/fonts/vendored",
        help="Directory containing vendored fonts",
    )
    parser.add_argument(
        "--check-downloads",
        action="store_true",
        help="Allow approved downloadable fonts to be fetched during validation",
    )
    parser.add_argument(
        "--include-system",
        action="store_true",
        help="Include system font directories in validation",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as validation failures",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Emit machine-readable JSON",
    )
    parsed = parser.parse_args(args)

    results = validate_font_pair_catalog(
        parsed.catalog_dir,
        fonts_dir=parsed.fonts_dir,
        check_downloads=parsed.check_downloads,
        include_system=parsed.include_system,
    )

    if parsed.json_output:
        print(
            json.dumps(font_pair_validation_payload(results), indent=2, sort_keys=True)
        )
    else:
        print(format_font_pair_validation_text(results))

    if font_pair_validation_exit_code(results, strict=parsed.strict):
        raise SystemExit(1)


def main() -> None:
    """Main CLI entry point."""

    # Check for mcp-server subcommand
    if len(sys.argv) > 1 and sys.argv[1] == "mcp-server":
        run_mcp_server(sys.argv[2:])
        return
    if len(sys.argv) > 1 and sys.argv[1] == "google-suite":
        run_google_suite_bundle(sys.argv[2:])
        return
    if len(sys.argv) > 1 and sys.argv[1] == "google-roundtrip":
        run_google_suite_roundtrip(sys.argv[2:])
        return
    if len(sys.argv) > 1 and sys.argv[1] == "validate-font-pairs":
        run_validate_font_pairs(sys.argv[2:])
        return

    parser = argparse.ArgumentParser(
        prog="tokenmoulds",
        description="TokenMoulds Formulaic Design Token Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate design tokens and templates from manual inputs
  tokenmoulds --org-id="acme" --font-pair="inter-roboto" --primary-color="#2563EB" --secondary-color="#DC2626" --locale="GB" --brand-tone=0.3

  tokenmoulds --org-id="startup" --font-pair="work-sans-source" --primary-color="#6366F1" --locale="US" --brand-tone=0.8 --generate-templates

  # Generate templates from layered DTCG files (ADR 017)
  tokenmoulds --org-id="acme" --layers-dir="data/layers/" --generate-templates
  tokenmoulds --org-id="acme" --layers-manifest="data/manifest.json" --generate-templates

  # Start MCP server for AI document generation
  tokenmoulds mcp-server --tokens ./data/
  tokenmoulds mcp-server --brands ./brands/ --output ./generated/

  # Generate a Google Apps Script handoff bundle from a stored ArtifactPlan
  tokenmoulds google-suite --artifact-id="quarterly-update" --output-dir="./generated"

  # Deploy the bundle directly through the Apps Script API
  tokenmoulds google-suite --artifact-id="quarterly-update" --deploy --access-token="$TOKENMOULDS_GOOGLE_ACCESS_TOKEN"

  # Roundtrip a local artifact through Google Workspace import/export
  tokenmoulds google-roundtrip generated/acme/deck.pptx --folder-id="$TOKENMOULDS_GSUITE_FOLDER_ID"
        """,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show TokenMoulds version and exit",
    )

    # Brand source — URL, manifest, or manual
    parser.add_argument(
        "--url",
        type=str,
        default=None,
        help="Extract brand from website URL and generate templates",
    )

    parser.add_argument(
        "--manifest",
        type=str,
        default=None,
        help="Path to brand-manifest.yaml — builds templates from manifest config",
    )

    parser.add_argument(
        "--output",
        type=str,
        default=None,
        dest="output_alias",
        help="Output directory (alias for --output-dir)",
    )

    parser.add_argument(
        "--format",
        type=str,
        default=None,
        dest="format_filter",
        help="Comma-separated list of output formats (e.g., potx,dotx,xltx)",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Resolve tokens and build IR, but skip template emission",
    )

    # Organization ID (required unless --url or --manifest provides it)
    parser.add_argument(
        "--org-id",
        required=False,
        default=None,
        help='Organization identifier (e.g., "acme", "startup")',
    )

    parser.add_argument(
        "--font-pair",
        help=(
            "Font pair selection (required unless using --layers-dir/--layers-manifest). "
            "Use a preset key, 'Sans/Serif' string, or catalog alias like "
            "'scope:pair-name' when providing --font-pair-catalog-dir "
            "or TOKENMOULDS_FONT_PAIR_CATALOG_DIR."
        ),
    )

    parser.add_argument(
        "--font-pair-catalog-dir",
        default=None,
        help="Directory containing font-pair YAML files or a single YAML file",
    )

    parser.add_argument(
        "--primary-color",
        help='Primary brand color (hex, e.g., "#2563EB") (required unless using --layers-dir/--layers-manifest)',
    )

    parser.add_argument(
        "--secondary-color",
        help='Secondary brand color (hex, e.g., "#DC2626") (required unless using --layers-dir/--layers-manifest)',
    )

    parser.add_argument(
        "--locale",
        choices=["GB", "US", "DE", "FR", "JP", "HE", "NL"],
        help="Locale for formatting and punctuation (required unless using --layers-dir/--layers-manifest)",
    )

    parser.add_argument(
        "--brand-tone",
        type=float,
        help="Brand tone: 0.0 = formal, 1.0 = casual (required unless using --layers-dir/--layers-manifest)",
    )

    # Optional arguments
    parser.add_argument(
        "--content-density",
        type=float,
        default=0.4,
        help="Content density: 0.0 = sparse, 1.0 = dense (default: 0.4)",
    )

    parser.add_argument(
        "--accessibility-level",
        choices=["AA", "AAA"],
        default="AA",
        help="Accessibility compliance level (default: AA)",
    )

    parser.add_argument(
        "--license-id",
        help="License identifier to validate before generation (defaults to lic_local_dev)",
    )

    parser.add_argument(
        "--license-token",
        help="Signed license token for future remote validation (optional)",
    )

    parser.add_argument(
        "--license-repo",
        help="GitHub repository slug associated with this license (e.g., tokenmoulds/acme-suite)",
    )

    parser.add_argument(
        "--output-dir",
        default="generated",
        help="Output directory (default: generated/)",
    )

    parser.add_argument(
        "--layers-dir",
        type=str,
        default=None,
        help="Directory containing DTCG layer files (core.tokens.json, fork.tokens.json, etc.). "
        "Layers are merged in precedence order: core -> fork -> org -> group -> personal.",
    )

    parser.add_argument(
        "--layers-manifest",
        type=str,
        default=None,
        help="Path to manifest JSON file pointing to DTCG layer files. "
        "Alternative to --layers-dir for explicit layer configuration.",
    )

    parser.add_argument(
        "--template-root",
        default=None,
        help="Override directory containing format-specific template subfolders (word/excel/powerpoint)",
    )

    parser.add_argument(
        "--fonts-dir",
        default=None,
        help="Directory containing vendored font files for embedding",
    )

    parser.add_argument(
        "--disable-font-embedding",
        action="store_true",
        help="Skip font embedding during packaging",
    )

    parser.add_argument(
        "--embed-fonts",
        action="store_true",
        help="Force-enable font embedding (alias for the default behavior)",
    )

    parser.add_argument(
        "--skip-validation",
        action="store_true",
        help="Skip validate-template checks on packaged outputs",
    )

    parser.add_argument(
        "--max-quality-issues",
        type=int,
        default=None,
        help="Fail build if total quality issues exceed this threshold",
    )

    parser.add_argument(
        "--max-quality-errors",
        type=int,
        default=None,
        help="Fail build if total quality errors exceed this threshold",
    )

    parser.add_argument(
        "--max-quality-warnings",
        type=int,
        default=None,
        help="Fail build if total quality warnings exceed this threshold",
    )

    parser.add_argument(
        "--max-quality-infos",
        type=int,
        default=None,
        help="Fail build if total quality info count exceeds this threshold",
    )

    parser.add_argument(
        "--font-validation-mode",
        choices=["off", "warn", "error"],
        default="off",
        help="Include font QA evidence in template quality manifests",
    )

    parser.add_argument(
        "--check-font-downloads",
        action="store_true",
        help="Allow font QA to resolve approved downloadable fonts",
    )

    parser.add_argument(
        "--allow-font-downloads",
        action="store_true",
        help="Allow template font embedding to fetch approved downloadable fonts",
    )

    parser.add_argument(
        "--include-system-fonts-for-validation",
        action="store_true",
        help="Allow font QA to resolve system fonts",
    )

    parser.add_argument(
        "--emit-semantic-provenance",
        action="store_true",
        help="Write semantic-provenance.json for migrated semantic token families",
    )

    parser.add_argument(
        "--emit-tokenmould-ir",
        action="store_true",
        help="Write tokenmould_seed.json and tokenmould_ir.json outputs",
    )

    parser.add_argument(
        "--generate-templates",
        action="store_true",
        help="Generate OOXML templates (.potx, .dotx, .xltx)",
    )

    parser.add_argument(
        "--generate-odf",
        action="store_true",
        help="Generate ODF templates (.ott, .otp)",
    )

    parser.add_argument(
        "--compare-baselines",
        action="store_true",
        help="After generating templates, compare screenshots against stored baselines",
    )

    parser.add_argument(
        "--baselines-workspace",
        default="tests/baselines",
        help="Path to baseline workspace (default: tests/baselines)",
    )

    parser.add_argument(
        "--create-summary",
        action="store_true",
        default=True,
        help="Create generation summary report (default: True)",
    )

    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")

    parser.add_argument(
        "--preload-templates",
        action="store_true",
        help="Preload and cache all XML templates at startup for faster batch generation",
    )

    # Parse arguments
    args = parser.parse_args()

    # Validate required arguments when not using --layers-dir or --layers-manifest
    if not args.layers_dir and not args.layers_manifest:
        missing = []
        if not args.font_pair:
            missing.append("--font-pair")
        if not args.primary_color:
            missing.append("--primary-color")
        if not args.secondary_color:
            missing.append("--secondary-color")
        if not args.locale:
            missing.append("--locale")
        if args.brand_tone is None:
            missing.append("--brand-tone")
        if missing:
            parser.error(
                f"The following arguments are required when not using --layers-dir "
                f"or --layers-manifest: {', '.join(missing)}"
            )

    # Set verbose mode
    if args.verbose:
        print("\U0001f50d Verbose mode enabled")

    # Preload templates if requested
    if args.preload_templates:
        if args.verbose:
            print("\u26a1 Preloading template cache...")
        count = TemplateResolver.preload_all()
        if args.verbose:
            print(f"   Cached {count} templates")

    # Generate tokens
    generate_tokens(args)


if __name__ == "__main__":
    main()
