"""Color and font extraction helpers for URL-derived branding."""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple


def extract_all_hex_colors(css_content: str) -> List[Tuple[str, int]]:
    """Extract all hex colors from CSS with frequency counts.

    Args:
        css_content: Raw CSS content

    Returns:
        List of (color, count) tuples sorted by frequency
    """
    from collections import Counter

    # Find all 6-digit hex colors
    hex_pattern = re.compile(r"#([0-9a-fA-F]{6})(?![0-9a-fA-F])")
    colors = hex_pattern.findall(css_content)

    # Normalize to uppercase and count
    counter = Counter(f"#{c.upper()}" for c in colors)
    return counter.most_common()


def score_brand_color(color: str, frequency: int) -> float:
    """Score a color for likelihood of being a brand color.

    Higher scores = more likely brand color.
    Brand colors are typically: saturated, not too light, not too dark.

    Args:
        color: Hex color string
        frequency: How often it appears

    Returns:
        Score (higher = better candidate)
    """
    try:
        r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    except (ValueError, IndexError):
        return 0

    # Calculate saturation (0-255 range difference)
    saturation = max(r, g, b) - min(r, g, b)

    # Calculate brightness (average)
    brightness = (r + g + b) / 3

    score = 0.0

    # Saturated colors score high (brand colors are colorful)
    if saturation > 100:
        score += 50
    elif saturation > 50:
        score += 30
    elif saturation < 20:
        # Grayscale - unlikely brand color
        return 0

    # Mid-brightness scores best (not too light, not too dark)
    if 60 < brightness < 200:
        score += 30
    elif brightness >= 200:
        # Too light (near white)
        score -= 20
    elif brightness <= 60:
        # Dark colors can be secondary
        score += 10

    # Frequency bonus (common colors are likely intentional)
    score += min(frequency * 2, 20)

    # Skip common UI grays
    if saturation < 30 and 100 < brightness < 200:
        return 0

    return score


def extract_fonts_from_css(css_content: str) -> List[str]:
    """Extract font family names from CSS @font-face and font-family rules.

    Args:
        css_content: Raw CSS content

    Returns:
        List of font family names found
    """
    fonts = set()

    # Extract from @font-face declarations
    fontface_pattern = re.compile(
        r"@font-face\s*\{[^}]*font-family\s*:\s*['\"]?([^'\";}]+)['\"]?",
        re.IGNORECASE | re.DOTALL,
    )
    for match in fontface_pattern.finditer(css_content):
        font = match.group(1).strip()
        if font:
            fonts.add(font)

    # Extract from font-family declarations
    family_pattern = re.compile(
        r"font-family\s*:\s*['\"]?([^'\";}]+)['\"]?", re.IGNORECASE
    )
    for match in family_pattern.finditer(css_content):
        families = match.group(1).split(",")
        for family in families:
            family = family.strip().strip("\"'")
            # Skip generic families and CSS variables
            if family.lower() not in (
                "serif",
                "sans-serif",
                "monospace",
                "cursive",
                "fantasy",
                "system-ui",
            ) and not family.startswith("var("):
                fonts.add(family)

    return list(fonts)


def normalize_font_name(font_value: str) -> Optional[str]:
    """Normalize a font filename/variable to a standard family name.

    Maps font file patterns to their family names:
    - "InterTight-Medium" -> "Inter"
    - "Roboto-Bold" -> "Roboto"

    Args:
        font_value: Font filename or family name

    Returns:
        Normalized font family name or None
    """
    if not font_value:
        return None

    value = font_value.strip()
    value_lower = value.lower()

    # Skip CSS variables and generic families
    if value.startswith("var(") or value_lower in ("serif", "sans-serif", "monospace"):
        return None

    # Common font family mappings (file name patterns -> family)
    font_mappings = [
        # Google Fonts / Open Source
        (r"inter", "Inter"),
        (r"roboto", "Roboto"),
        (r"opensans|open.?sans", "Open Sans"),
        (r"montserrat", "Montserrat"),
        (r"lato", "Lato"),
        (r"poppins", "Poppins"),
        (r"nunito", "Nunito"),
        (r"source.?sans", "Source Sans Pro"),
        (r"source.?serif", "Source Serif Pro"),
        (r"source.?code", "Source Code Pro"),
        (r"fira.?sans", "Fira Sans"),
        (r"fira.?code", "Fira Code"),
        (r"jet.?brains", "JetBrains Mono"),
        (r"space.?mono", "Space Mono"),
        (r"merriweather", "Merriweather"),
        (r"playfair", "Playfair Display"),
        (r"eb.?garamond", "EB Garamond"),
        (r"lora", "Lora"),
        (r"raleway", "Raleway"),
        (r"oswald", "Oswald"),
        (r"work.?sans", "Work Sans"),
        (r"dm.?sans", "DM Sans"),
        (r"dm.?serif", "DM Serif Display"),
        (r"ibm.?plex.?sans", "IBM Plex Sans"),
        (r"ibm.?plex.?serif", "IBM Plex Serif"),
        (r"ibm.?plex.?mono", "IBM Plex Mono"),
        (r"barlow", "Barlow"),
        (r"manrope", "Manrope"),
        (r"mulish", "Mulish"),
        (r"jost", "Jost"),
        # System/standard fonts
        (r"georgia", "Georgia"),
        (r"arial", "Arial"),
        (r"helvetica", "Helvetica"),
        (r"times", "Times New Roman"),
        (r"verdana", "Verdana"),
    ]

    for pattern, family in font_mappings:
        if re.search(pattern, value_lower):
            return family

    # If no mapping found, try to clean up the name
    # Remove weight/style suffixes like "-Medium", "-Bold", "-Regular"
    cleaned = re.sub(
        r"[-_](thin|light|regular|medium|semi.?bold|bold|extra.?bold|black|italic).*$",
        "",
        value,
        flags=re.IGNORECASE,
    )
    cleaned = cleaned.strip()

    if cleaned and cleaned != value:
        # Add spaces before capital letters (InterTight -> Inter Tight)
        cleaned = re.sub(r"([a-z])([A-Z])", r"\1 \2", cleaned)
        return cleaned

    return value if value else None


def find_semantic_colors(css_content: str) -> Dict[str, str]:
    """Find colors defined in semantically-named CSS variables.

    Looks for patterns like:
    - --brand-primary: #407fff
    - --color-primary: #407fff
    - --dq-color-primary: #407fff
    - --color-marble-dark: #0a1f2d (for secondary)

    Args:
        css_content: Raw CSS/HTML content

    Returns:
        Dict mapping semantic role to color (e.g., {"primary": "#407FFF"})
    """
    semantic = {}

    # Pattern: --[prefix-]<semantic-name>: #hexcolor (6 or 8 digits)
    # Match variable names containing semantic keywords followed by hex color
    pattern = re.compile(
        r"--[a-z0-9-]*?(primary|secondary|accent|brand|main|highlight)[a-z0-9-]*?\s*:\s*#([0-9a-fA-F]{6})(?:[0-9a-fA-F]{2})?(?![0-9a-fA-F])",
        re.IGNORECASE,
    )

    for match in pattern.finditer(css_content):
        role = match.group(1).lower()
        color = f"#{match.group(2).upper()}"

        # Skip black, white, near-black, near-white
        try:
            r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
            brightness = (r + g + b) / 3
            if brightness < 20 or brightness > 235:
                continue
        except ValueError:
            continue

        # Map to standard roles
        if role in ("primary", "brand", "main"):
            if "primary" not in semantic:
                semantic["primary"] = color
        elif role in ("secondary", "accent", "highlight"):
            if "secondary" not in semantic:
                semantic["secondary"] = color

    # If no secondary found, look for dark/navy/marble colors
    if "secondary" not in semantic:
        dark_pattern = re.compile(
            r"--[a-z0-9-]*?(dark|navy|marble|deep)[a-z0-9-]*?\s*:\s*#([0-9a-fA-F]{6})(?![0-9a-fA-F])",
            re.IGNORECASE,
        )
        for match in dark_pattern.finditer(css_content):
            color = f"#{match.group(2).upper()}"
            try:
                r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
                brightness = (r + g + b) / 3
                # Must be actually dark
                if brightness < 80:
                    semantic["secondary"] = color
                    break
            except ValueError:
                continue

    return semantic
