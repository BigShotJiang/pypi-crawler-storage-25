"""Document IR construction for the build pipeline."""

from __future__ import annotations

import structlog

from tokenmoulds.design.engine import DesignResolutionEngine, LineHeightMode
from tokenmoulds.dtcg.font_metrics import extract_font_metrics
from tokenmoulds.ir import DocumentIR
from tokenmoulds.ir import build_document_ir as _build_document_ir_without_metrics
from tokenmoulds.ir.design_bridge import create_document_ir_from_design
from tokenmoulds.pipeline_models import BuildConfig
from tokenmoulds.semantic.build_context import font_pair_from_tokens, resolve_font_roles

logger = structlog.get_logger(__name__)


def _extract_font_pair(tokens: dict) -> dict[str, str]:
    """Extract font_pair from resolved tokens."""
    return font_pair_from_tokens(tokens)


def _extract_base_colors(tokens: dict) -> dict[str, str]:
    """Extract base colors from resolved tokens."""
    inputs = tokens.get("inputs", {})
    base_colors = inputs.get("base_colors", {})
    if base_colors:
        return dict(base_colors)
    colors = tokens.get("colors", {})
    palette = colors.get("palette", {})
    primary = palette.get("primary", {}).get("base", "#2563EB")
    secondary = palette.get("secondary", {}).get("base", "#DC2626")
    return {"primary": primary, "secondary": secondary}


def _extract_brand_tone(tokens: dict) -> float:
    """Extract brand_tone from resolved tokens."""
    inputs = tokens.get("inputs", {})
    return float(inputs.get("brand_tone", tokens.get("brand_tone", 0.5)))


def _extract_content_density(tokens: dict) -> float:
    """Extract content_density from resolved tokens."""
    inputs = tokens.get("inputs", {})
    return float(inputs.get("content_density", 0.4))


def _build_color_theme(tokens: dict):
    """Build ColorTheme from resolved token payload."""
    from tokenmoulds.design.color_defaults import (
        DEFAULT_PRIMARY,
        DEFAULT_SECONDARY,
        DEFAULT_THEME_MAPPING,
    )
    from tokenmoulds.ir import ColorTheme

    colors = tokens.get("colors", {})
    theme_map = colors.get("theme_mapping", {})
    if not theme_map:
        theme_map = dict(DEFAULT_THEME_MAPPING)
        theme_map["accent1"] = (
            colors.get("palette", {}).get("primary", {}).get("base", DEFAULT_PRIMARY)
        )
        theme_map["accent2"] = (
            colors.get("palette", {})
            .get("secondary", {})
            .get("base", DEFAULT_SECONDARY)
        )

    return ColorTheme(
        dk1=theme_map["dk1"],
        lt1=theme_map["lt1"],
        dk2=theme_map["dk2"],
        lt2=theme_map["lt2"],
        accent1=theme_map["accent1"],
        accent2=theme_map["accent2"],
        accent3=theme_map["accent3"],
        accent4=theme_map["accent4"],
        accent5=theme_map["accent5"],
        accent6=theme_map["accent6"],
        hyperlink=theme_map.get("hlink", theme_map["accent1"]),
        hyperlink_followed=theme_map.get("folHlink", theme_map["accent2"]),
    )


def _build_document_ir(
    tokens: dict,
    config: BuildConfig,
) -> DocumentIR:
    """Build DocumentIR via DesignResolutionEngine.

    Falls back to the metrics-free IR builder when font metrics are
    unavailable (e.g., PyPI install with no vendored fonts and no
    metrics cache), so the pipeline degrades gracefully instead of
    crashing.
    """
    font_pair = _extract_font_pair(tokens)
    brand_tone = _extract_brand_tone(tokens)
    content_density = _extract_content_density(tokens)
    color_theme = _build_color_theme(tokens)

    try:
        font_metrics = extract_font_metrics(
            font_pair=font_pair,
            font_metrics_cache=None,
            fonts_dir=str(config.fonts_dir) if config.fonts_dir else None,
        )
    except (ValueError, RuntimeError) as exc:
        logger.warning(
            "Font metrics unavailable, falling back to metrics-free IR builder",
            error=str(exc),
        )
        return _build_document_ir_without_metrics(tokens, config.org_id, config.locale)

    # Build DesignResolutionEngine inputs
    from tokenmoulds.dtcg.generator import (
        _BrandAdapter,
        _FontConfigAdapter,
        _FontMetricsAdapter,
        _select_scale_ratio,
    )
    from tokenmoulds.fonts.superfamilies import resolve_monospace

    heading_metrics = font_metrics["heading"]
    body_metrics = font_metrics.get("body", heading_metrics)

    roles = resolve_font_roles(font_pair)
    body_family = roles.body
    heading_family = roles.heading
    mono_family = roles.mono or "Courier New"
    try:
        mono_family = resolve_monospace(
            body_family, heading_family, font_pair.get("mono")
        )
    except Exception:
        pass

    body_adapter = _FontMetricsAdapter(
        x_height=body_metrics["x_height"],
        units_per_em=body_metrics["units_per_em"],
        cap_height=body_metrics["cap_height"],
        ascender=body_metrics["ascender"],
        descender=body_metrics["descender"],
    )
    heading_adapter = _FontMetricsAdapter(
        x_height=heading_metrics["x_height"],
        units_per_em=heading_metrics["units_per_em"],
        cap_height=heading_metrics["cap_height"],
        ascender=heading_metrics["ascender"],
        descender=heading_metrics["descender"],
    )
    font_config = _FontConfigAdapter(
        body=body_adapter,
        heading=heading_adapter,
        _body_family=body_family,
        _heading_family=heading_family,
        _mono_family=mono_family,
    )
    brand = _BrandAdapter(tone=brand_tone, density=content_density)
    scale_ratio = _select_scale_ratio(brand_tone)

    engine = DesignResolutionEngine(
        fonts=font_config,
        brand=brand,
        locale=config.locale,
        colors={},
        base_font_size_pt=config.base_font_size_pt,
        scale_ratio=scale_ratio,
        line_height_mode=LineHeightMode.SNAPPED,
    )
    design = engine.resolve()

    document_ir = create_document_ir_from_design(
        design,
        org_id=config.org_id,
        locale=config.locale,
        body_font=body_family,
        heading_font=heading_family,
        monospace_font=mono_family,
        color_theme=color_theme,
    )
    # Preserve diagnostics from the legacy IR builder until color analysis
    # moves behind the design-resolution bridge.
    try:
        diagnostics_ir = _build_document_ir_without_metrics(
            tokens, config.org_id, config.locale
        )
        document_ir.color_analysis = diagnostics_ir.color_analysis
    except Exception as exc:
        logger.warning("Color diagnostics unavailable", error=str(exc))

    if any(
        key in tokens
        for key in ("page_geometry", "margin_presets", "sections", "headers", "footers")
    ):
        from tokenmoulds.design.units.conversion import emu_to_pt
        from tokenmoulds.dtcg.long_form_resolver import resolve_long_form

        long_form_bundle = resolve_long_form(
            tokens, baseline_pt=emu_to_pt(document_ir.typography.baseline_emu)
        )
        document_ir.long_form_sections = long_form_bundle["sections"]
        document_ir.header_footer_registry = long_form_bundle["header_footer_registry"]

    return document_ir
