"""CLI utility functions for input validation and display helpers."""

from __future__ import annotations

import argparse
import os
from typing import Any, Dict, List

from tokenmoulds.font_pairs.catalog import collect_legacy_font_pairs
from tokenmoulds.licensing import resolve_license_context, validate_or_exit

FONT_PAIR_CATALOG_ENV = "TOKENMOULDS_FONT_PAIR_CATALOG_DIR"
_FONT_PAIR_DELIMITERS = ("/", "+", ",", "|")


def _parse_explicit_font_pair(value: str) -> Dict[str, str] | None:
    for separator in _FONT_PAIR_DELIMITERS:
        if separator not in value:
            continue
        left, right = (part.strip() for part in value.split(separator, 1))
        if left and right:
            return {"sans": left, "serif": right}
    return None


def _collect_catalog_font_pairs(
    catalog_dir: str | None = None,
) -> Dict[str, Dict[str, str]]:
    if catalog_dir is None:
        catalog_dir = os.getenv(FONT_PAIR_CATALOG_ENV, "").strip()
    else:
        catalog_dir = catalog_dir.strip()

    if not catalog_dir:
        return {}

    return collect_legacy_font_pairs(catalog_dir)


def collect_catalog_font_pairs(
    catalog_dir: str | None = None,
) -> Dict[str, Dict[str, str]]:
    """Collect configured font-pair catalog aliases."""
    return _collect_catalog_font_pairs(catalog_dir)


def _preview_sample(
    previews: Dict[str, List[str]], key: str, *, limit: int = 4, separator: str = ", "
) -> str:
    values = previews.get(key) or []
    if not values:
        return ""
    sample = separator.join(values[:limit])
    return sample


def _print_preview_samples(
    previews: Dict[str, List[str]],
    key: str,
    label: str,
    *,
    limit: int = 4,
    separator: str = ", ",
) -> None:
    sample = _preview_sample(previews, key, limit=limit, separator=separator)
    if sample:
        print(f"      {label}: {sample}")


def _render_preview_section(previews: Dict[str, List[str]]) -> str:
    lines: List[str] = []
    for label, key in (
        ("Lighten", "lighten"),
        ("Darken", "darken"),
        ("Saturate", "saturate"),
    ):
        sample = _preview_sample(previews, key, limit=6)
        if sample:
            lines.append(f"- **{label}:** {sample}")
    contrast_sample = _preview_sample(
        previews, "heading_contrast", limit=6, separator=" | "
    )
    if contrast_sample:
        lines.append(f"- **Heading vs Body contrast:** {contrast_sample}")
    for mode in ("protanopia", "deuteranopia", "tritanopia"):
        sample = _preview_sample(previews, f"color_blind_{mode}", limit=6)
        if sample:
            label = f"{mode.capitalize()} palette"
            lines.append(f"- **{label}:** {sample}")
    if not lines:
        return ""
    return "### Palette Previews\n" + "\n".join(lines) + "\n\n"


def _count_tokens(payload: Any) -> int:
    if isinstance(payload, dict):
        return sum(_count_tokens(value) for value in payload.values())
    if isinstance(payload, list):
        return sum(_count_tokens(value) for value in payload)
    return 1


def _resolve_license(args: argparse.Namespace) -> None:
    context = resolve_license_context(
        license_id=getattr(args, "license_id", None),
        license_repo=getattr(args, "license_repo", None),
        default_repo=f"tokenmoulds/{args.org_id}",
    )
    validate_or_exit(context)


def parse_font_pair(
    font_pair_str: str, catalog_dir: str | None = None
) -> Dict[str, str]:
    """Parse font pair string into sans/serif dictionary."""
    font_pairs: Dict[str, Dict[str, str]] = {
        "inter-roboto": {"sans": "Inter", "serif": "Roboto Slab"},
        "work-sans-source": {"sans": "Work Sans", "serif": "Source Serif Pro"},
        "public-sans-spectral": {"sans": "Public Sans", "serif": "Spectral"},
    }
    font_pairs.update(_collect_catalog_font_pairs(catalog_dir))

    value = font_pair_str.strip()
    if not value:
        available = ", ".join(sorted(font_pairs))
        raise ValueError(f"Invalid font pair '{font_pair_str}'. Available: {available}")

    if value in font_pairs:
        return dict(font_pairs[value])

    explicit = _parse_explicit_font_pair(value)
    if explicit is not None:
        return explicit

    available = ", ".join(sorted(font_pairs)[:8])
    raise ValueError(
        f"Invalid font pair '{font_pair_str}'. "
        f"Available examples: {available or 'none'}"
    )


def validate_hex_color(color: str) -> str:
    """Validate and normalize hex color."""
    if not color.startswith("#"):
        color = "#" + color

    if len(color) != 7:
        raise ValueError(f"Invalid hex color '{color}'. Must be 6 digits after #")

    try:
        int(color[1:], 16)
    except ValueError:
        raise ValueError(f"Invalid hex color '{color}'. Must contain only hex digits")

    return color.upper()


def validate_brand_tone(tone: float) -> float:
    """Validate brand tone range."""
    if not 0.0 <= tone <= 1.0:
        raise ValueError(f"Brand tone must be between 0.0 and 1.0, got {tone}")
    return tone


def validate_content_density(density: float) -> float:
    """Validate content density range."""
    if not 0.0 <= density <= 1.0:
        raise ValueError(f"Content density must be between 0.0 and 1.0, got {density}")
    return density
