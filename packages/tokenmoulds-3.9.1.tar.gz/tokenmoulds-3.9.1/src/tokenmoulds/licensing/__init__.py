"""GitHub-native licensing helpers for TokenMoulds."""

from .client import (
    LicenseContext,
    LicenseValidationError,
    LicenseValidationResult,
    LicenseValidator,
)
from .runtime import resolve_license_context, validate_or_exit

__all__ = [
    "LicenseContext",
    "LicenseValidationError",
    "LicenseValidationResult",
    "LicenseValidator",
    "resolve_license_context",
    "validate_or_exit",
]
