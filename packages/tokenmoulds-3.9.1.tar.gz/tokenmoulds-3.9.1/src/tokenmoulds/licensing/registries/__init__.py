"""Bundled license registry fixtures."""
