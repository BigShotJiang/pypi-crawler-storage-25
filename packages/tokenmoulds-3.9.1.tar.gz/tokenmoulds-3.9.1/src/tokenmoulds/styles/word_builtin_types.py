"""Word built-in style definitions.

Pure data: 98 explicit style definitions + generated table and linked
character styles. No runtime dependencies beyond dataclass/enum.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class StyleType(Enum):
    """Word style types."""

    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    TABLE = "table"
    NUMBERING = "numbering"


class StyleCategory(Enum):
    """Style categories for derivation grouping."""

    DOCUMENT = "document"  # Normal, Body Text, etc.
    HEADING = "heading"  # Heading 1-9
    LIST = "list"  # List Bullet, List Number, etc.
    TOC = "toc"  # Table of Contents
    INDEX = "index"  # Index entries
    FOOTNOTE = "footnote"  # Footnotes, endnotes
    TABLE = "table"  # Table styles
    CHARACTER = "character"  # Inline character styles
    SPECIAL = "special"  # Header, Footer, Caption, etc.


@dataclass
class BuiltinStyleDef:
    """Definition of a Word built-in style."""

    style_id: str  # e.g., "Heading1", "ListBullet"
    name: str  # e.g., "heading 1", "List Bullet"
    style_type: StyleType
    category: StyleCategory
    based_on: Optional[str] = None  # Parent style ID
    next_style: Optional[str] = None  # Style for next paragraph
    ui_priority: int = 99
    qformat: bool = False  # Show in Quick Styles gallery
    semi_hidden: bool = False
    unhide_when_used: bool = True
    # Derivation hints
    role: Optional[str] = None  # Design engine role to use
    size_scale: Optional[float] = None  # Multiplier for body size
    tracking_adjustment: int = 0  # Additional tracking twips
    space_before_scale: float = 0  # Multiplier for baseline
    space_after_scale: float = 0
    indent_scale: float = 0  # For list/quote indents
    bold: bool = False
    italic: bool = False
    all_caps: bool = False
    small_caps: bool = False
    # Special flags
    outline_level: Optional[int] = None  # For headings (0-8)
    number_format: Optional[str] = None  # For numbered styles
