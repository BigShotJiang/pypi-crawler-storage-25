"""Generated Word built-in style variants."""

from __future__ import annotations

from typing import List

from tokenmoulds.styles.word_builtin_types import (
    BuiltinStyleDef,
    StyleCategory,
    StyleType,
)

# TABLE STYLE VARIANTS (generated programmatically)
# =============================================================================

# Table style base names that have accent variants
TABLE_STYLE_BASES = [
    ("LightShading", "Light Shading"),
    ("LightList", "Light List"),
    ("LightGrid", "Light Grid"),
    ("MediumShading1", "Medium Shading 1"),
    ("MediumShading2", "Medium Shading 2"),
    ("MediumList1", "Medium List 1"),
    ("MediumList2", "Medium List 2"),
    ("MediumGrid1", "Medium Grid 1"),
    ("MediumGrid2", "Medium Grid 2"),
    ("MediumGrid3", "Medium Grid 3"),
    ("DarkList", "Dark List"),
    ("ColorfulShading", "Colorful Shading"),
    ("ColorfulList", "Colorful List"),
    ("ColorfulGrid", "Colorful Grid"),
]


# Generate table styles with accent variants
def _generate_table_styles() -> List[BuiltinStyleDef]:
    """Generate table style definitions with accent variants."""
    styles = []

    for style_id_base, name_base in TABLE_STYLE_BASES:
        # Base style (no accent)
        styles.append(
            BuiltinStyleDef(
                style_id=style_id_base,
                name=name_base,
                style_type=StyleType.TABLE,
                category=StyleCategory.TABLE,
                ui_priority=60,
                semi_hidden=False,
            )
        )

        # Accent variants 1-6
        for i in range(1, 7):
            styles.append(
                BuiltinStyleDef(
                    style_id=f"{style_id_base}Accent{i}",
                    name=f"{name_base} Accent {i}",
                    style_type=StyleType.TABLE,
                    category=StyleCategory.TABLE,
                    ui_priority=60 + i,
                    semi_hidden=False,
                )
            )

    return styles


# =============================================================================
# LINKED CHARACTER STYLES (generated programmatically)
# =============================================================================

# Paragraph styles that have linked character styles
LINKED_STYLES = [
    ("Heading1", "Heading 1 Char"),
    ("Heading2", "Heading 2 Char"),
    ("Heading3", "Heading 3 Char"),
    ("Heading4", "Heading 4 Char"),
    ("Heading5", "Heading 5 Char"),
    ("Heading6", "Heading 6 Char"),
    ("Heading7", "Heading 7 Char"),
    ("Heading8", "Heading 8 Char"),
    ("Heading9", "Heading 9 Char"),
    ("Title", "Title Char"),
    ("Subtitle", "Subtitle Char"),
    ("Quote", "Quote Char"),
    ("IntenseQuote", "Intense Quote Char"),
    ("Header", "Header Char"),
    ("Footer", "Footer Char"),
    ("HeaderMinimal", "Header Minimal Char"),
    ("HeaderRunning", "Header Running Char"),
    ("FooterCentered", "Footer Centered Char"),
    ("FooterOuter", "Footer Outer Char"),
    ("FooterFull", "Footer Full Char"),
    ("BodyText", "Body Text Char"),
    ("BodyText2", "Body Text 2 Char"),
    ("BodyText3", "Body Text 3 Char"),
    ("FootnoteText", "Footnote Text Char"),
    ("EndnoteText", "Endnote Text Char"),
    ("MacroText", "Macro Text Char"),
    ("Caption", "Caption Char"),
    ("TOCHeading", "TOC Heading Char"),
]


def _generate_linked_char_styles() -> List[BuiltinStyleDef]:
    """Generate linked character styles for paragraph styles."""
    styles = []

    for para_style_id, char_name in LINKED_STYLES:
        char_style_id = para_style_id + "Char"
        styles.append(
            BuiltinStyleDef(
                style_id=char_style_id,
                name=char_name,
                style_type=StyleType.CHARACTER,
                category=StyleCategory.CHARACTER,
                based_on="DefaultParagraphFont",
                ui_priority=99,
                semi_hidden=True,
            )
        )

    return styles
