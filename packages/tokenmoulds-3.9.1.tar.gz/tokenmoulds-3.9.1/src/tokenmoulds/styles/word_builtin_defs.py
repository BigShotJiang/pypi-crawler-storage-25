"""Word built-in style definitions."""

from __future__ import annotations

from tokenmoulds.styles.word_builtin_defs_characters import WORD_CHARACTER_STYLES
from tokenmoulds.styles.word_builtin_defs_generated import (
    _generate_linked_char_styles,
    _generate_table_styles,
)
from tokenmoulds.styles.word_builtin_defs_references import WORD_REFERENCE_STYLES
from tokenmoulds.styles.word_builtin_defs_text import WORD_TEXT_STYLES
from tokenmoulds.styles.word_builtin_types import BuiltinStyleDef

BUILTIN_STYLES: list[BuiltinStyleDef] = [
    *WORD_TEXT_STYLES,
    *WORD_REFERENCE_STYLES,
    *WORD_CHARACTER_STYLES,
    *_generate_table_styles(),
    *_generate_linked_char_styles(),
]

BUILTIN_STYLE_COUNT = len(BUILTIN_STYLES)
