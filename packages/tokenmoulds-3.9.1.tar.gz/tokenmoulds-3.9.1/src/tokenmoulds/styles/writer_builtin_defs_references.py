"""List, reference, header, footer, and caption ODF Writer styles."""

from __future__ import annotations

from tokenmoulds.styles.writer_builtin_types import (
    OdfBuiltinStyleDef,
    OdfStyleCategory,
    OdfStyleFamily,
    _generate_index_levels,
    _generate_list_sublevels,
    _generate_toc_levels,
    _LIST_HANGING_EM,
    _LIST_INDENT_BASE_EM,
)

WRITER_REFERENCE_STYLES: list[OdfBuiltinStyleDef] = [
    # =========================================================================
    # LIST STYLES (bullet, number, indent — 5 levels each)
    # =========================================================================
    # List Bullet 1-5
    # List Bullet 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Bullet",
        display_name="List Bullet",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        text_indent_em=_LIST_HANGING_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Bullet",
        "List Bullet",
        "List_20_Bullet",
        hanging=True,
    ),
    # List Number 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Number",
        display_name="List Number",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        text_indent_em=_LIST_HANGING_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Number",
        "List Number",
        "List_20_Number",
        hanging=True,
    ),
    # List Indent / Contents / Heading
    OdfBuiltinStyleDef(
        style_name="List_20_Indent",
        display_name="List Indent",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="List_20_Contents",
        display_name="List Contents",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="List_20_Heading",
        display_name="List Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        use_heading_font=True,
        bold=True,
        size_scale=1.09,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    # List Continue 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Continue",
        display_name="List Continue",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Continue",
        "List Continue",
        "List_20_Continue",
        hanging=False,
    ),
    # =========================================================================
    # TABLE OF CONTENTS
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Contents_20_Heading",
        display_name="Contents Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.TOC,
        parent_style="Standard",
        next_style="Contents_20_1",
        use_heading_font=True,
        size_scale=1.27,
        bold=True,
        space_before_scale=2.0,
        space_after_scale=1.0,
    ),
    *_generate_toc_levels(),
    # =========================================================================
    # INDEX
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Index_20_Heading",
        display_name="Index Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.INDEX,
        parent_style="Standard",
        next_style="Index_20_1",
        use_heading_font=True,
        size_scale=1.27,
        bold=True,
        space_before_scale=2.0,
        space_after_scale=1.0,
    ),
    *_generate_index_levels(),
    # =========================================================================
    # HEADER / FOOTER
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Header",
        display_name="Header",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Standard",
        size_scale=0.82,
        space_before_scale=0.0,
        space_after_scale=0.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Header_20_left",
        display_name="Header left",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        text_align="start",
    ),
    OdfBuiltinStyleDef(
        style_name="Header_20_right",
        display_name="Header right",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        text_align="end",
    ),
    OdfBuiltinStyleDef(
        style_name="Footer",
        display_name="Footer",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Standard",
        size_scale=0.82,
        space_before_scale=0.0,
        space_after_scale=0.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Footer_20_left",
        display_name="Footer left",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        text_align="start",
    ),
    OdfBuiltinStyleDef(
        style_name="Footer_20_right",
        display_name="Footer right",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        text_align="end",
    ),
    # Long-form header/footer variants (Phase 1: sections-and-page-layout).
    # Parity with word_builtin_defs.  Parent on base Header / Footer so user
    # re-theming of those cascades automatically.
    OdfBuiltinStyleDef(
        style_name="HeaderMinimal",
        display_name="Header Minimal",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        size_scale=0.82,
    ),
    OdfBuiltinStyleDef(
        style_name="HeaderRunning",
        display_name="Header Running",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        size_scale=0.82,
        small_caps=True,
    ),
    OdfBuiltinStyleDef(
        style_name="FooterCentered",
        display_name="Footer Centered",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        size_scale=0.82,
        text_align="center",
    ),
    OdfBuiltinStyleDef(
        style_name="FooterOuter",
        display_name="Footer Outer",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        size_scale=0.82,
    ),
    OdfBuiltinStyleDef(
        style_name="FooterFull",
        display_name="Footer Full",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        size_scale=0.82,
    ),
    # =========================================================================
    # FOOTNOTE / ENDNOTE
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Footnote",
        display_name="Footnote",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.FOOTNOTE,
        parent_style="Standard",
        size_scale=0.73,
        space_before_scale=0.0,
        space_after_scale=0.33,
    ),
    OdfBuiltinStyleDef(
        style_name="Endnote",
        display_name="Endnote",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.FOOTNOTE,
        parent_style="Standard",
        size_scale=0.73,
        space_before_scale=0.0,
        space_after_scale=0.33,
    ),
    # =========================================================================
    # CAPTIONS / LABELS
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Caption",
        display_name="Caption",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Standard",
        next_style="Text_20_body",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
        space_before_scale=0.5,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Illustration",
        display_name="Illustration",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Table",
        display_name="Table",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Drawing",
        display_name="Drawing",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Figure",
        display_name="Figure",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
]
