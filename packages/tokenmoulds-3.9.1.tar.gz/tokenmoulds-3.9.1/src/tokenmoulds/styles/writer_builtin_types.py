"""ODF Writer built-in style definitions.

Pure data: 90 style definitions with generators for index, TOC,
and list sub-levels.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

_INDEX_TOC_INDENT_STEP_EM = 1.25  # Per-level indent for Index/TOC
_LIST_INDENT_BASE_EM = 3.0  # Level-1 left margin for lists
_LIST_INDENT_STEP_EM = 1.5  # Per-level increment
_LIST_HANGING_EM = -1.5  # Hanging indent for bullet/number markers


class OdfStyleFamily(Enum):
    """ODF style:family values."""

    PARAGRAPH = "paragraph"
    TEXT = "text"
    TABLE_CELL = "table-cell"


class OdfStyleCategory(Enum):
    """Style categories for grouping."""

    DOCUMENT = "document"
    HEADING = "heading"
    TITLE = "title"
    LIST = "list"
    TOC = "toc"
    INDEX = "index"
    FOOTNOTE = "footnote"
    HEADER_FOOTER = "header_footer"
    CAPTION = "caption"
    SPECIAL = "special"
    CHARACTER = "character"
    TABLE = "table"


@dataclass
class OdfBuiltinStyleDef:
    """Definition of a LibreOffice Writer built-in style.

    Design fields use scales/ratios relative to the DocumentIR's body style,
    so styles adapt to any brand configuration.
    """

    style_name: str  # ODF style:name (e.g., "Heading_20_1")
    display_name: str  # ODF style:display-name (e.g., "Heading 1")
    family: OdfStyleFamily
    category: OdfStyleCategory
    parent_style: str | None = None  # ODF style:parent-style-name
    next_style: str | None = None  # ODF style:next-style-name
    # Typography decisions
    use_heading_font: bool = False  # True = heading font, False = body font
    size_scale: float = 1.0  # Multiplier on body font size
    bold: bool = False
    italic: bool = False
    small_caps: bool = False
    # Color
    use_muted_color: bool = False  # True = secondary/muted text color
    # Paragraph spacing (scales on body spacing)
    space_before_scale: float = 0.0
    space_after_scale: float = 1.0  # 1.0 = same as body
    # Indentation (em-based, resolved to pt at build time: em × body font size)
    indent_em: float = 0.0  # Left margin
    text_indent_em: float = 0.0  # First-line / hanging indent
    right_indent_em: float = 0.0  # Right margin
    # Alignment
    text_align: str | None = None  # "start", "center", "end", "justify"
    # Superscript (for anchors)
    superscript: bool = False
    # Monospace font (resolved by emitter from TypographyScheme.monospace_font)
    use_monospace: bool = False


def _depth_size_scale(level: int) -> float:
    """Size scale that diminishes with depth: 1.0 → 0.91 → 0.82."""
    if level <= 3:
        return 1.0
    if level <= 5:
        return 0.91
    return 0.82


def _generate_index_levels() -> list[OdfBuiltinStyleDef]:
    """Generate Index 1-9 with formulaic indent and size."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(1, 10):
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"Index_20_{i}",
                display_name=f"Index {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.INDEX,
                parent_style="Standard",
                indent_em=(i - 1) * _INDEX_TOC_INDENT_STEP_EM,
                size_scale=_depth_size_scale(i),
                space_before_scale=0.0,
                space_after_scale=0.33,
            )
        )
    return styles


def _generate_toc_levels() -> list[OdfBuiltinStyleDef]:
    """Generate Contents 1-10 with formulaic indent and size."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(1, 11):
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"Contents_20_{i}",
                display_name=f"Contents {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.TOC,
                parent_style="Standard",
                indent_em=(i - 1) * _INDEX_TOC_INDENT_STEP_EM,
                size_scale=_depth_size_scale(i),
                bold=(i == 1),
                space_before_scale=0.5 if i == 1 else 0.0,
                space_after_scale=0.33,
            )
        )
    return styles


def _list_indent_em(level: int) -> float:
    """Left margin for list level (1-based)."""
    return _LIST_INDENT_BASE_EM + (level - 1) * _LIST_INDENT_STEP_EM


def _generate_list_sublevels(
    base_name: str,
    display_base: str,
    parent: str,
    *,
    hanging: bool,
) -> list[OdfBuiltinStyleDef]:
    """Generate list sublevel styles 2-5."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(2, 6):
        suffix = f"_20_{i}"
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"{base_name}{suffix}",
                display_name=f"{display_base} {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.LIST,
                parent_style=parent,
                indent_em=_list_indent_em(i),
                text_indent_em=_LIST_HANGING_EM if hanging else 0.0,
                space_before_scale=0.0,
                space_after_scale=0.5,
            )
        )
    return styles
