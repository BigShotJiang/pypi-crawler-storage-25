"""ODF Writer built-in style definitions."""

from __future__ import annotations

from tokenmoulds.styles.writer_builtin_defs_characters import WRITER_CHARACTER_STYLES
from tokenmoulds.styles.writer_builtin_defs_core import WRITER_CORE_STYLES
from tokenmoulds.styles.writer_builtin_defs_references import WRITER_REFERENCE_STYLES
from tokenmoulds.styles.writer_builtin_types import OdfBuiltinStyleDef

WRITER_BUILTIN_STYLES: list[OdfBuiltinStyleDef] = [
    *WRITER_CORE_STYLES,
    *WRITER_REFERENCE_STYLES,
    *WRITER_CHARACTER_STYLES,
]

WRITER_BUILTIN_STYLE_COUNT = len(WRITER_BUILTIN_STYLES)
