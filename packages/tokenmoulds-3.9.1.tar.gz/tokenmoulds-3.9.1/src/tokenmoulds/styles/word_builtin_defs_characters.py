"""Character, table, and numbering Word built-in styles."""

from __future__ import annotations

from tokenmoulds.styles.word_builtin_types import (
    BuiltinStyleDef,
    StyleCategory,
    StyleType,
)

WORD_CHARACTER_STYLES: list[BuiltinStyleDef] = [
    # -------------------------------------------------------------------------
    # CHARACTER STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="DefaultParagraphFont",
        name="Default Paragraph Font",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=1,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="Strong",
        name="Strong",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=22,
        qformat=True,
        bold=True,
        tracking_adjustment=5,
    ),
    BuiltinStyleDef(
        style_id="Emphasis",
        name="Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=20,
        qformat=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="SubtleEmphasis",
        name="Subtle Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=19,
        qformat=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="IntenseEmphasis",
        name="Intense Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=21,
        qformat=True,
        bold=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="SubtleReference",
        name="Subtle Reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=31,
        qformat=True,
        small_caps=True,
    ),
    BuiltinStyleDef(
        style_id="IntenseReference",
        name="Intense Reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=32,
        qformat=True,
        bold=True,
        small_caps=True,
        tracking_adjustment=25,
    ),
    BuiltinStyleDef(
        style_id="BookTitle",
        name="Book Title",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=33,
        qformat=True,
        bold=True,
        small_caps=True,
        tracking_adjustment=25,
    ),
    BuiltinStyleDef(
        style_id="Hyperlink",
        name="Hyperlink",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        unhide_when_used=True,
        # Color set by hyperlink style
    ),
    BuiltinStyleDef(
        style_id="FollowedHyperlink",
        name="FollowedHyperlink",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
        # Color set by hyperlink style
    ),
    BuiltinStyleDef(
        style_id="CommentReference",
        name="annotation reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
        size_scale=0.65,
    ),
    BuiltinStyleDef(
        style_id="LineNumber",
        name="line number",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="PageNumber",
        name="page number",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
    ),
    # -------------------------------------------------------------------------
    # TABLE STYLES (defaults only, accents generated separately)
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="TableNormal",
        name="Normal Table",
        style_type=StyleType.TABLE,
        category=StyleCategory.TABLE,
        ui_priority=99,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="TableGrid",
        name="Table Grid",
        style_type=StyleType.TABLE,
        category=StyleCategory.TABLE,
        ui_priority=59,
    ),
    # -------------------------------------------------------------------------
    # NUMBERING STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="NoList",
        name="No List",
        style_type=StyleType.NUMBERING,
        category=StyleCategory.LIST,
        ui_priority=99,
        semi_hidden=True,
    ),
]
