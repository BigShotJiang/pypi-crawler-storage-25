"""Shared build pipeline for template generation.

All entrypoints (CLI, MCP, GitHub workflows) call ``build()`` instead
of implementing their own token → IR → emit → validate flow.

Routes through ``DesignResolutionEngine`` (IR Path B) for richer
typography with OpenType features, baseline-grid-snapped spacing,
and modular type scales.

See ADR 027 (F2) and the BuildPipeline spec.
"""

from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime as _datetime
from datetime import timezone
from importlib import metadata as importlib_metadata
from pathlib import Path
from typing import Any

import structlog

from tokenmoulds import __version__ as _PIPELINE_VERSION
from tokenmoulds.dtcg.converter import convert_from_dtcg
from tokenmoulds.dtcg.generator import TokenGenerator
from tokenmoulds.dtcg.layered_adapter import adapt_dtcg_layers
from tokenmoulds.dtcg.parser import parse_tokens
from tokenmoulds.dtcg.reference_resolver import resolve_references
from tokenmoulds.emitters.docprops_custom import compute_template_hash
from tokenmoulds.font_pairs.audit import audit_font_face
from tokenmoulds.font_pairs.catalog import FontPairRecord, load_font_pair_catalog
from tokenmoulds.fonts.service import build_font_service
from tokenmoulds.ir import DocumentIR
from tokenmoulds.pipeline_ir import _build_document_ir
from tokenmoulds.pipeline_models import (
    BuildBatchConfig,
    BuildConfig,
    BuildProvenance,
    BuildResult,
    QualityFormatReport,
    TemplateQualityReport,
    create_quality_timestamp,
)
from tokenmoulds.pipeline_artifact_intent import build_pipeline_artifact_intent
from tokenmoulds.semantic.build_context import font_pair_from_tokens, resolve_font_roles
from tokenmoulds.semantic.collectors import collect_header_footer_semantic_provenance
from tokenmoulds.semantic.provenance import SemanticProvenance
from tokenmoulds.validation.formats import Format
from tokenmoulds.validation.structural import validate_package_structure
from tokenmoulds.xml_structures.package_audit import audit_package_against_manifest

logger = structlog.get_logger(__name__)


# =============================================================================
# Format → Emitter Dispatch
# =============================================================================

# Maps output format extension to (module_path, class_name, supports_fonts)
_EMITTER_REGISTRY: dict[str, tuple[str, str, bool]] = {
    "potx": ("tokenmoulds.emitters.powerpoint", "PowerPointEmitter", True),
    "dotx": ("tokenmoulds.emitters.word", "WordDocumentEmitter", True),
    "xltx": ("tokenmoulds.emitters.excel", "ExcelEmitter", False),
    "otp": ("tokenmoulds.emitters.odf", "ImpressTemplateEmitter", False),
    "ott": ("tokenmoulds.emitters.odf", "WriterTemplateEmitter", False),
    "ots": ("tokenmoulds.emitters.odf", "CalcTemplateEmitter", False),
    "odg": ("tokenmoulds.emitters.odf", "DrawTemplateEmitter", False),
    "gdocs": ("tokenmoulds.emitters.google_docs", "GoogleDocsEmitter", True),
    "gdoc": ("tokenmoulds.emitters.google_docs", "GoogleDocsDocumentEmitter", False),
}

_PACKAGE_FORMAT_ALIASES = {
    "docx": Format.WORD,
    "dotx": Format.WORD_TEMPLATE,
    "pptx": Format.POWERPOINT,
    "potx": Format.POWERPOINT_TEMPLATE,
    "xlsx": Format.EXCEL,
    "xltx": Format.EXCEL_TEMPLATE,
    "odt": Format.WRITER,
    "ott": Format.WRITER,
    "odp": Format.IMPRESS,
    "otp": Format.IMPRESS,
    "ods": Format.CALC,
    "ots": Format.CALC,
    "odg": Format.DRAW,
    "otg": Format.DRAW,
}


def _get_emitter_class(fmt: str):
    """Lazy-import and return the emitter class for a format."""
    import importlib

    if fmt not in _EMITTER_REGISTRY:
        raise ValueError(
            f"Unknown output format: {fmt!r}. "
            f"Available: {sorted(_EMITTER_REGISTRY.keys())}"
        )
    module_path, class_name, _ = _EMITTER_REGISTRY[fmt]
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


# =============================================================================
# Token Resolution
# =============================================================================


def _resolve_tokens(config: BuildConfig, _depth: int = 0) -> dict:
    """Resolve tokens from whichever source is provided in config."""
    if config.repository is not None:
        if _depth > 0:
            raise ValueError("Recursive GitHub resolution not supported")

        import shutil

        from tokenmoulds.brand.github import GitHubSource, resolve_github_source
        from tokenmoulds.brand.manifest import manifest_to_build_config

        source = GitHubSource(
            repository=config.repository,
            ref=config.ref or "main",
            path=config.manifest_path or "brand-manifest.yaml",
        )
        manifest, tmp_dir = resolve_github_source(source)
        try:
            derived_config = manifest_to_build_config(manifest, tmp_dir)
            return _resolve_tokens(derived_config, _depth + 1)
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    if config.token_payload is not None:
        return config.token_payload

    if config.brand_inputs is not None:
        return TokenGenerator().generate(config.brand_inputs)

    if config.layers_dir is not None or config.layers_manifest is not None:
        result = adapt_dtcg_layers(
            layers_dir=config.layers_dir,
            manifest_path=config.layers_manifest,
        )
        return result.payload

    if config.tokens_file is not None:
        token_file = parse_tokens(config.tokens_file)
        resolved, _resolutions, _warnings = resolve_references(token_file, strict=False)
        return convert_from_dtcg(resolved)

    raise ValueError(
        "BuildConfig must provide one of: token_payload, tokens_file, "
        "layers_dir/layers_manifest, or brand_inputs"
    )


# =============================================================================
# IR Construction (Path B — DesignResolutionEngine)
# =============================================================================


# =============================================================================
# Emission
# =============================================================================


def _create_style_resolver(tokens: dict, document_ir: DocumentIR):
    """Create a StyleResolver for Word formats."""
    try:
        from tokenmoulds.styles.factory import create_style_resolver_from_tokens

        body_color = document_ir.body_style.color
        heading_color = body_color
        if document_ir.heading_styles:
            heading_color = document_ir.heading_styles[0].color

        return create_style_resolver_from_tokens(
            tokens, body_color=body_color, heading_color=heading_color
        )
    except Exception as exc:
        logger.debug("StyleResolver creation failed: %s", exc)
        return None


def _emit_format(
    fmt: str,
    document_ir: DocumentIR,
    tokens: dict,
    config: BuildConfig,
    source_report: dict[str, Any],
) -> bytes:
    """Emit a single format and return raw bytes."""
    emitter_cls = _get_emitter_class(fmt)
    _, _, supports_fonts = _EMITTER_REGISTRY[fmt]

    kwargs: dict[str, Any] = {}
    if config.template_root is not None:
        kwargs["template_root"] = str(config.template_root)

    if supports_fonts:
        kwargs["embed_fonts"] = config.embed_fonts
        if config.fonts_dir:
            kwargs["fonts_dir"] = config.fonts_dir
        kwargs["allow_font_downloads"] = config.allow_font_downloads

    # Word formats need a StyleResolver
    if fmt in ("dotx", "ott"):
        resolver = _create_style_resolver(tokens, document_ir)
        if resolver is not None:
            kwargs["style_resolver"] = resolver

    if fmt in ("potx", "pptx"):
        from tokenmoulds.archetypes.catalog import CONSULTING_FAMILY, GENERAL_FAMILY

        kwargs["layout_families"] = [CONSULTING_FAMILY, GENERAL_FAMILY]

    artifact_intent = build_pipeline_artifact_intent(
        fmt,
        document_ir,
        tokens,
        config,
        source_report,
    )
    if artifact_intent is not None:
        kwargs["artifact_intent"] = artifact_intent

    emitter = emitter_cls(document_ir, **kwargs)
    return emitter.build_package()


# =============================================================================
# Validation
# =============================================================================


def _validate_artifact(fmt: str, data: bytes) -> tuple[list[dict[str, Any]], bool]:
    """Validate a template artifact in-process.

    Returns a tuple ``(issues, skipped_validation)`` where ``issues`` are
    serialisable dictionaries and ``skipped_validation`` reflects whether
    OpenXML deep validation was intentionally skipped.
    """
    try:
        from tokenmoulds.validation import (
            supports_ooxml_deep_validation,
            validate_ooxml_bytes,
        )

        package_fmt = _PACKAGE_FORMAT_ALIASES.get(fmt, fmt)
        structural_report = validate_package_structure(data, package_fmt)
        ssot_report = audit_package_against_manifest(data, package_fmt)
        issues = [*structural_report.issues, *ssot_report.issues]

        if not supports_ooxml_deep_validation(fmt):
            logger.debug("No deep OOXML validation support configured for %s", fmt)
            return [_issue_to_dict(issue) for issue in issues], True

        if not structural_report.is_valid or not ssot_report.is_valid:
            logger.debug(
                "Deep OOXML validation skipped for %s after package audit failures",
                fmt,
            )
            return [_issue_to_dict(issue) for issue in issues], True

        outcome = validate_ooxml_bytes(data, fmt, include_binary=False)
        if not outcome.executed:
            logger.debug(
                "OOXML deep validation skipped for %s: %s", fmt, outcome.skipped_reason
            )
            return [_issue_to_dict(issue) for issue in issues], True

        issues.extend(outcome.report.issues)
        return [_issue_to_dict(issue) for issue in issues], False

    except Exception as exc:
        logger.warning("Validation failed for %s: %s", fmt, exc)
        return [
            {
                "type": "OPENXML_VALIDATION_EXCEPTION",
                "code": "OPENXML_VALIDATION_EXCEPTION",
                "description": str(exc),
                "severity": "error",
            }
        ], False


def _issue_to_dict(issue: Any) -> dict[str, Any]:
    """Convert a ValidationIssue into a serialisable structure."""
    location = getattr(issue, "location", None)
    code = getattr(issue, "code", "OPENXML_VALIDATION_ISSUE")
    severity = getattr(issue, "severity", "error")
    severity = getattr(severity, "value", severity)

    payload = {
        "code": str(code),
        "type": str(code),
        "description": getattr(issue, "message", ""),
        "severity": str(severity).lower(),
    }
    if location is not None:
        payload["location"] = str(location)
        payload["part"] = str(location).split(":", 1)[0]
        payload["path"] = str(location)
    suggestion = getattr(issue, "suggestion", None)
    if suggestion is not None:
        payload["suggestion"] = str(suggestion)
    return payload


def _issue_counts(issues: list[dict[str, Any]]) -> tuple[int, int, int]:
    """Return ``(errors, warnings, infos)`` for issue dict payloads."""
    errors = warnings = infos = 0
    for issue in issues:
        severity = str(issue.get("severity", "error")).lower()
        if severity == "warning":
            warnings += 1
        elif severity == "info":
            infos += 1
        else:
            errors += 1
    return errors, warnings, infos


def _font_pair_roles_from_tokens(tokens: dict) -> dict[str, str]:
    """Extract semantic font roles from resolved tokens."""
    return resolve_font_roles(font_pair_from_tokens(tokens)).to_dict()


def _catalog_sha256(catalog_path: Path | None) -> str | None:
    if catalog_path is None or not catalog_path.exists():
        return None
    h = hashlib.sha256()
    files = [catalog_path]
    if catalog_path.is_dir():
        files = sorted(
            list(catalog_path.glob("*.yaml")) + list(catalog_path.glob("*.yml"))
        )
    for path in files:
        if not path.is_file():
            continue
        h.update(path.name.encode("utf-8"))
        h.update(b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def _canonical_sha256(payload: Any) -> str:
    """Hash a JSON-like payload with deterministic key ordering."""
    data = json.dumps(
        _json_safe(payload),
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_safe(nested) for key, nested in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, set):
        return sorted(_json_safe(item) for item in value)
    return value


def _hash_path(path: Path | None) -> str | None:
    """Hash a file or directory tree with names and bytes included."""
    if path is None or not path.exists():
        return None

    h = hashlib.sha256()
    if path.is_file():
        h.update(path.name.encode("utf-8"))
        h.update(b"\0")
        h.update(path.read_bytes())
        return h.hexdigest()

    for child in sorted(item for item in path.rglob("*") if item.is_file()):
        rel = child.relative_to(path).as_posix()
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(child.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def _build_config_fingerprint(config: BuildConfig) -> dict[str, Any]:
    return {
        "org_id": config.org_id,
        "output_formats": list(config.output_formats),
        "token_source": config.token_source_label(),
        "tokens_file": str(config.tokens_file) if config.tokens_file else None,
        "layers_dir": str(config.layers_dir) if config.layers_dir else None,
        "layers_manifest": (
            str(config.layers_manifest) if config.layers_manifest else None
        ),
        "repository": config.repository,
        "ref": config.ref,
        "manifest_path": config.manifest_path,
        "locale": config.locale,
        "template_root": str(config.template_root) if config.template_root else None,
        "fonts_dir": str(config.fonts_dir) if config.fonts_dir else None,
        "embed_fonts": config.embed_fonts,
        "validate": config.validate,
        "emit_semantic_provenance": config.emit_semantic_provenance,
        "quality_gates": {
            "max_issue_count": config.max_issue_count,
            "max_error_count": config.max_error_count,
            "max_warning_count": config.max_warning_count,
            "max_info_count": config.max_info_count,
        },
        "font_validation": {
            "font_pair_id": config.font_pair_id,
            "font_pair_catalog_dir": (
                str(config.font_pair_catalog_dir)
                if config.font_pair_catalog_dir
                else None
            ),
            "font_validation_mode": config.font_validation_mode,
            "allow_font_downloads": config.allow_font_downloads,
            "check_font_downloads": config.check_font_downloads,
            "include_system_fonts_for_validation": (
                config.include_system_fonts_for_validation
            ),
        },
        "render_validation": {
            "enabled": config.render_validation,
            "render_output_dir": (
                str(config.render_output_dir) if config.render_output_dir else None
            ),
            "soffice_path": config.soffice_path,
            "render_timeout_s": config.render_timeout_s,
        },
        "artifact_intent": {
            "enabled": config.emit_artifact_intent,
            "artifact_id": config.artifact_id,
            "artifact_type": config.artifact_type,
            "artifact_title": config.artifact_title,
            "artifact_intent_summary": config.artifact_intent_summary,
            "artifact_status": config.artifact_status,
            "review_state": config.review_state,
        },
        "design_engine": {
            "policy": config.policy,
            "base_font_size_pt": config.base_font_size_pt,
            "base_grid_pt": config.base_grid_pt,
        },
        "license": {
            "license_id": config.license_id,
            "license_repo": config.license_repo,
        },
    }


def _token_source_sha256(config: BuildConfig) -> str | None:
    if config.token_payload is not None:
        return _canonical_sha256(config.token_payload)
    if config.brand_inputs is not None:
        return _canonical_sha256(config.brand_inputs)
    if config.tokens_file is not None:
        return _hash_path(config.tokens_file)
    if config.layers_manifest is not None:
        return _hash_path(config.layers_manifest)
    if config.layers_dir is not None:
        return _hash_path(config.layers_dir)
    if config.repository is not None:
        return _canonical_sha256(
            {
                "repository": config.repository,
                "ref": config.ref or "main",
                "manifest_path": config.manifest_path or "brand-manifest.yaml",
            }
        )
    return None


def _validation_engine_report(config: BuildConfig) -> dict[str, Any]:
    supported_formats = [
        fmt
        for fmt in config.output_formats
        if fmt in {"docx", "dotx", "pptx", "potx", "xlsx", "xltx"}
    ]
    version: str | None
    try:
        version = importlib_metadata.version("openxml-audit")
    except importlib_metadata.PackageNotFoundError:
        version = None
    return {
        "requested": config.validate,
        "engine": "openxml-audit",
        "engine_version": version,
        "supported_formats": supported_formats,
        "package_structure_audit": True,
        "ssot_manifest_audit": True,
    }


def _build_source_report(config: BuildConfig, tokens: dict) -> dict[str, Any]:
    config_fingerprint = _build_config_fingerprint(config)
    return {
        "token_source": config.token_source_label(),
        "token_source_sha256": _token_source_sha256(config),
        "resolved_tokens_sha256": _canonical_sha256(tokens),
        "build_config_sha256": _canonical_sha256(config_fingerprint),
        "build_config": config_fingerprint,
        "template_root": str(config.template_root) if config.template_root else None,
        "template_root_sha256": _hash_path(config.template_root),
        "validation": _validation_engine_report(config),
    }


def _render_artifact_report(
    fmt: str,
    data: bytes,
    config: BuildConfig,
) -> dict[str, Any]:
    from tokenmoulds.validation.soffice import render_with_soffice

    output_root = config.render_output_dir
    if output_root is None:
        output_root = Path("reports/render")
    output_dir = output_root / config.org_id / fmt
    return render_with_soffice(
        data,
        fmt,
        output_dir,
        soffice_path=config.soffice_path,
        timeout=config.render_timeout_s,
    ).to_dict()


def _select_catalog_record(
    catalog_dir: Path | None,
    font_pair_id: str | None,
) -> tuple[FontPairRecord | None, list[dict[str, Any]]]:
    if catalog_dir is None:
        return None, []
    catalog = load_font_pair_catalog(catalog_dir)
    diagnostics = [diagnostic.to_dict() for diagnostic in catalog.diagnostics]
    if font_pair_id is None:
        return None, diagnostics

    for record in catalog.records:
        if font_pair_id in (record.id, record.slug):
            diagnostics.extend(
                diagnostic.to_dict() for diagnostic in record.diagnostics
            )
            return record, diagnostics
    diagnostics.append(
        {
            "severity": "warning",
            "code": "font_pair_id_not_found",
            "message": f"Font pair id '{font_pair_id}' was not found in catalog",
            "source_path": str(catalog_dir),
        }
    )
    return None, diagnostics


def _build_font_report(tokens: dict, config: BuildConfig) -> dict[str, Any] | None:
    if config.font_validation_mode == "off":
        return None

    roles = _font_pair_roles_from_tokens(tokens)
    service = build_font_service(
        config.fonts_dir,
        enable_downloads=config.check_font_downloads,
        include_system=config.include_system_fonts_for_validation,
    )
    assets = []
    for role, family in roles.items():
        assets.append(
            audit_font_face(
                service,
                role=role,
                family=family,
                weight=400,
                required=True,
            ).to_dict()
        )
        assets.append(
            audit_font_face(
                service,
                role=role,
                family=family,
                weight=700,
                required=False,
            ).to_dict()
        )

    catalog_record, diagnostics = _select_catalog_record(
        config.font_pair_catalog_dir,
        config.font_pair_id,
    )
    catalog_families = _catalog_role_families(catalog_record)
    errors = [
        error
        for asset in assets
        for error in asset.get("errors", [])
        if isinstance(error, str)
    ]
    warnings = [
        warning
        for asset in assets
        for warning in asset.get("warnings", [])
        if isinstance(warning, str)
    ]
    errors.extend(
        str(diagnostic["message"])
        for diagnostic in diagnostics
        if diagnostic.get("severity") == "error"
    )
    warnings.extend(
        str(diagnostic["message"])
        for diagnostic in diagnostics
        if diagnostic.get("severity") == "warning"
    )
    for role, catalog_family in catalog_families.items():
        token_family = roles.get(role)
        if token_family and token_family != catalog_family:
            warnings.append(
                f"{role} family from tokens '{token_family}' does not match "
                f"catalog family '{catalog_family}'"
            )

    return {
        "mode": config.font_validation_mode,
        "font_pair_id": config.font_pair_id,
        "selected_catalog_record": catalog_record.to_dict() if catalog_record else None,
        "catalog_families": catalog_families,
        "catalog_path": (
            str(config.font_pair_catalog_dir) if config.font_pair_catalog_dir else None
        ),
        "catalog_sha256": _catalog_sha256(config.font_pair_catalog_dir),
        "families": roles,
        "assets": assets,
        "diagnostics": diagnostics,
        "errors": errors,
        "warnings": warnings,
        "summary": {
            "asset_count": len(assets),
            "error_count": len(errors),
            "warning_count": len(warnings),
        },
    }


def _font_quality_gate_failures(font_report: dict[str, Any] | None) -> list[str]:
    if not font_report:
        return []
    return [f"Font QA error: {error}" for error in font_report.get("errors", [])]


def _catalog_role_families(record: FontPairRecord | None) -> dict[str, str]:
    if record is None:
        return {}
    roles: dict[str, str] = {}
    if record.heading:
        roles["heading"] = record.heading.family
    if record.body:
        roles["body"] = record.body.family
    if record.mono:
        roles["mono"] = record.mono.family
    return roles


def _evaluate_quality_gates(
    artifact_reports: dict[str, QualityFormatReport],
    *,
    max_issue_count: int | None = None,
    max_error_count: int | None = None,
    max_warning_count: int | None = None,
    max_info_count: int | None = None,
) -> tuple[bool, list[str]]:
    """Evaluate quality thresholds against aggregate and per-format counts."""
    failures: list[str] = []

    total_issues = sum(r.issue_count for r in artifact_reports.values())
    total_errors = sum(r.error_count for r in artifact_reports.values())
    total_warnings = sum(r.warning_count for r in artifact_reports.values())
    total_infos = sum(r.info_count for r in artifact_reports.values())

    if max_issue_count is not None and total_issues > max_issue_count:
        failures.append(
            f"Total issue count {total_issues} exceeds max_issue_count {max_issue_count}"
        )
    if max_error_count is not None and total_errors > max_error_count:
        failures.append(
            f"Total error count {total_errors} exceeds max_error_count {max_error_count}"
        )
    if max_warning_count is not None and total_warnings > max_warning_count:
        failures.append(
            f"Total warning count {total_warnings} "
            f"exceeds max_warning_count {max_warning_count}"
        )
    if max_info_count is not None and total_infos > max_info_count:
        failures.append(
            f"Total info count {total_infos} exceeds max_info_count {max_info_count}"
        )

    for fmt, report in artifact_reports.items():
        if max_error_count is not None and report.error_count > max_error_count:
            failures.append(
                f"{fmt}: error count {report.error_count} "
                f"exceeds max_error_count {max_error_count}"
            )
        if max_warning_count is not None and report.warning_count > max_warning_count:
            failures.append(
                f"{fmt}: warning count {report.warning_count} "
                f"exceeds max_warning_count {max_warning_count}"
            )
        if max_info_count is not None and report.info_count > max_info_count:
            failures.append(
                f"{fmt}: info count {report.info_count} "
                f"exceeds max_info_count {max_info_count}"
            )
        if max_issue_count is not None and report.issue_count > max_issue_count:
            failures.append(
                f"{fmt}: issue count {report.issue_count} "
                f"exceeds max_issue_count {max_issue_count}"
            )

    # Remove duplicate messages for common threshold types to keep output stable.
    seen: set[str] = set()
    deduped = []
    for item in failures:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)

    return not deduped, deduped


# =============================================================================
# Main Build Function
# =============================================================================


def build(config: BuildConfig) -> BuildResult:
    """Execute the canonical build pipeline.

    Steps:
        1. Resolve tokens from whichever source is provided
        2. Build DocumentIR via DesignResolutionEngine (Path B)
        3. For each output format: emit → validate
        4. Return BuildResult with all artifacts

    All entrypoints (CLI, MCP, GitHub workflows) should call this
    function instead of implementing their own build flow.
    """
    start = time.monotonic()
    build_timestamp = _datetime.now(timezone.utc).isoformat()

    try:
        # Step 0: License check (optional — free tier works without)
        if config.license_id:
            try:
                from tokenmoulds.licensing import (
                    LicenseValidationError,
                    resolve_license_context,
                )
                from tokenmoulds.licensing.client import LicenseValidator
            except ImportError as exc:
                return BuildResult(
                    success=False,
                    error=f"Licensing module not available: {exc}",
                    timing_ms=(time.monotonic() - start) * 1000,
                )
            try:
                license_ctx = resolve_license_context(
                    license_id=config.license_id,
                    license_repo=config.license_repo,
                )
                license_result = LicenseValidator().validate(license_ctx)
                logger.info(
                    "License validated",
                    license_id=license_result.license_id,
                    plan=license_result.plan,
                )
            except LicenseValidationError as exc:
                return BuildResult(
                    success=False,
                    error=f"License validation failed: {exc}",
                    timing_ms=(time.monotonic() - start) * 1000,
                )

        # Step 1: Resolve tokens
        tokens = _resolve_tokens(config)

        # Step 2: Build IR via Path B (DesignResolutionEngine)
        document_ir = _build_document_ir(tokens, config)
        semantic_provenance: tuple[SemanticProvenance, ...] = ()
        if config.emit_semantic_provenance:
            semantic_provenance = collect_header_footer_semantic_provenance(
                tokens,
                header_footer_registry=document_ir.header_footer_registry,
                org_id=config.org_id,
            )

        # Step 3: Emit each format
        artifacts: dict[str, bytes] = {}
        validation_results: dict[str, list] = {}
        artifact_reports: dict[str, QualityFormatReport] = {}
        render_reports: dict[str, Any] = {}
        token_hash = compute_template_hash(tokens)
        source_report = _build_source_report(config, tokens)
        font_report = _build_font_report(tokens, config)
        font_gate_failures = (
            _font_quality_gate_failures(font_report)
            if config.font_validation_mode == "error"
            else []
        )

        if font_gate_failures:
            return BuildResult(
                success=False,
                artifacts=artifacts,
                validation_results=validation_results,
                document_ir=document_ir,
                token_payload=tokens,
                semantic_provenance=semantic_provenance,
                quality_report=TemplateQualityReport(
                    token_hash=token_hash,
                    generated_at=create_quality_timestamp(),
                    pipeline_version=_PIPELINE_VERSION,
                    artifact_reports=artifact_reports,
                    source_report=source_report,
                    render_report=render_reports or None,
                    font_report=font_report,
                ),
                quality_gate_failures=tuple(font_gate_failures),
                error="Quality gate failed: " + "; ".join(font_gate_failures),
                timing_ms=(time.monotonic() - start) * 1000,
            )

        for fmt in config.output_formats:
            try:
                data = _emit_format(fmt, document_ir, tokens, config, source_report)
                artifacts[fmt] = data

                # Step 4: Validate if requested
                if config.validate:
                    issues, skipped_validation = _validate_artifact(fmt, data)
                    if issues:
                        validation_results[fmt] = issues
                else:
                    issues = []
                    skipped_validation = True

                error_count, warning_count, info_count = _issue_counts(issues)
                artifact_reports[fmt] = QualityFormatReport(
                    fmt=fmt,
                    size_bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest(),
                    issue_count=len(issues),
                    error_count=error_count,
                    warning_count=warning_count,
                    info_count=info_count,
                    skipped_validation=skipped_validation,
                )
                if config.render_validation:
                    render_reports[fmt] = _render_artifact_report(fmt, data, config)
            except Exception as exc:
                logger.error("Failed to emit %s: %s", fmt, exc)
                return BuildResult(
                    success=False,
                    error=f"Emission failed for {fmt}: {exc}",
                    document_ir=document_ir,
                    token_payload=tokens,
                    semantic_provenance=semantic_provenance,
                    quality_report=TemplateQualityReport(
                        token_hash=token_hash,
                        generated_at=create_quality_timestamp(),
                        pipeline_version=_PIPELINE_VERSION,
                        artifact_reports=artifact_reports,
                        source_report=source_report,
                        render_report=render_reports or None,
                        font_report=font_report,
                    ),
                    timing_ms=(time.monotonic() - start) * 1000,
                )

        elapsed = round((time.monotonic() - start) * 1000, 1)

        provenance = BuildProvenance(
            org_id=config.org_id,
            timestamp=build_timestamp,
            token_source=config.token_source_label(),
            output_formats=list(config.output_formats),
            pipeline_version=_PIPELINE_VERSION,
            timing_ms=elapsed,
        )

        quality_report = TemplateQualityReport(
            token_hash=token_hash,
            generated_at=create_quality_timestamp(),
            pipeline_version=_PIPELINE_VERSION,
            artifact_reports=artifact_reports,
            source_report=source_report,
            render_report=render_reports or None,
            font_report=font_report,
        )

        quality_gate_passed, gate_failures = _evaluate_quality_gates(
            artifact_reports,
            max_issue_count=config.max_issue_count,
            max_error_count=config.max_error_count,
            max_warning_count=config.max_warning_count,
            max_info_count=config.max_info_count,
        )

        if not quality_gate_passed:
            return BuildResult(
                success=False,
                artifacts=artifacts,
                validation_results=validation_results,
                document_ir=document_ir,
                token_payload=tokens,
                provenance=provenance,
                semantic_provenance=semantic_provenance,
                quality_report=quality_report,
                quality_gate_failures=tuple(gate_failures),
                error="Quality gate failed: " + "; ".join(gate_failures),
                timing_ms=elapsed,
            )

        return BuildResult(
            success=True,
            artifacts=artifacts,
            validation_results=validation_results,
            document_ir=document_ir,
            token_payload=tokens,
            provenance=provenance,
            semantic_provenance=semantic_provenance,
            quality_report=quality_report,
            timing_ms=elapsed,
        )

    except Exception as exc:
        logger.error("Build pipeline failed: %s", exc, exc_info=True)
        return BuildResult(
            success=False,
            error=str(exc),
            timing_ms=(time.monotonic() - start) * 1000,
        )


# =============================================================================
# Batch Build
# =============================================================================


def build_batch(config: BuildBatchConfig) -> list[BuildResult]:
    """Build multiple brands with parallel execution.

    Args:
        config: Batch configuration with list of brand configs.

    Returns:
        List of BuildResult, one per brand, in the same order as input.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results: dict[int, BuildResult] = {}

    def _build_one(idx: int, brand_config: BuildConfig) -> tuple[int, BuildResult]:
        result = build(brand_config)
        if config.progress_callback:
            config.progress_callback(brand_config.org_id, result)
        return idx, result

    with ThreadPoolExecutor(max_workers=config.max_concurrency) as pool:
        futures = {
            pool.submit(_build_one, i, bc): i for i, bc in enumerate(config.brands)
        }
        for future in as_completed(futures):
            idx, result = future.result()
            results[idx] = result

    return [results[i] for i in range(len(config.brands))]
