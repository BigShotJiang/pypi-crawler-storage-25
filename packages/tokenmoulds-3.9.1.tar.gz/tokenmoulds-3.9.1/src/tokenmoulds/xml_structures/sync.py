"""Synchronize packaged XML structures from declared upstream artifacts."""

from __future__ import annotations

import filecmp
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, cast

Status = Literal["ok", "missing-local", "missing-upstream", "stale", "updated"]
ProvenanceKind = Literal[
    "external_byte_sync",
    "tokenmoulds_ssot",
    "generated",
    "dynamic_exception",
]

_PROVENANCE_KINDS: set[str] = {
    "external_byte_sync",
    "tokenmoulds_ssot",
    "generated",
    "dynamic_exception",
}


@dataclass(frozen=True)
class SyncIssue:
    """Single SSOT sync finding."""

    artifact_id: str
    local_template: str
    upstream_path: str
    status: Status


@dataclass(frozen=True)
class SourceRootIssue:
    """Missing declared upstream source root."""

    artifact_id: str
    source_id: str
    upstream_root: str


@dataclass(frozen=True)
class SyncReport:
    """Result of checking or updating SSOT imports."""

    issues: list[SyncIssue]
    missing_source_roots: list[SourceRootIssue]
    managed_templates: int
    unmanaged_templates: int
    byte_synced_templates: int

    @property
    def has_failures(self) -> bool:
        """Return True when check mode should fail."""
        return (
            bool(self.missing_source_roots)
            or self.unmanaged_templates > 0
            or any(
                issue.status in {"missing-local", "missing-upstream", "stale"}
                for issue in self.issues
            )
        )


def load_manifest(path: Path) -> dict[str, Any]:
    """Load an SSOT import manifest from disk."""
    return json.loads(path.read_text(encoding="utf-8"))


def check_or_update(
    *,
    manifest_path: Path,
    local_root: Path,
    upstream_root: Path,
    update: bool = False,
) -> SyncReport:
    """Check declared SSOT sync sources and optionally update local files."""
    manifest = load_manifest(manifest_path)
    issues: list[SyncIssue] = []
    missing_source_roots: list[SourceRootIssue] = []
    managed_templates = 0
    unmanaged_templates = 0
    byte_synced_templates = 0

    for artifact in manifest.get("artifact_sets", []):
        artifact_id = str(artifact["id"])
        artifact_root = local_root / str(artifact["root"])

        for source in artifact.get("upstream_sources", []):
            source_root = upstream_root / str(source["root"])
            if not source_root.exists():
                missing_source_roots.append(
                    SourceRootIssue(
                        artifact_id=artifact_id,
                        source_id=str(source["id"]),
                        upstream_root=str(source["root"]),
                    )
                )

        templates = _expand_package_templates(artifact)
        source_map = {
            str(local): str(upstream)
            for local, upstream in artifact.get("package_template_sources", {}).items()
        }
        template_names = set(templates.values())
        provenance = _declared_template_provenance(
            artifact,
            template_names=template_names,
            external_source_templates=set(source_map),
        )
        byte_synced_templates += len(source_map)
        managed_templates += len(template_names & set(provenance))
        unmanaged_templates += len(template_names - set(provenance))

        for local_template, upstream_rel in sorted(source_map.items()):
            local_path = _resolve_local_template(artifact_root, local_template)
            upstream_path = upstream_root / upstream_rel
            issues.append(
                _check_one(
                    artifact_id=artifact_id,
                    local_template=local_template,
                    upstream_rel=upstream_rel,
                    local_path=local_path,
                    upstream_path=upstream_path,
                    update=update,
                )
            )

    return SyncReport(
        issues=issues,
        missing_source_roots=missing_source_roots,
        managed_templates=managed_templates,
        unmanaged_templates=unmanaged_templates,
        byte_synced_templates=byte_synced_templates,
    )


def render_report(report: SyncReport) -> str:
    """Render a concise human-readable sync report."""
    lines: list[str] = []
    if report.missing_source_roots:
        lines.append("Missing upstream source roots:")
        for issue in report.missing_source_roots:
            lines.append(
                f"  {issue.artifact_id}:{issue.source_id} -> {issue.upstream_root}"
            )

    if report.issues:
        lines.append("Package template sync findings:")
        for issue in report.issues:
            lines.append(
                f"  {issue.status}: {issue.artifact_id}:{issue.local_template} "
                f"<- {issue.upstream_path}"
            )
    elif report.managed_templates > 0:
        lines.append("No package template sync drift.")
    else:
        lines.append("No package template provenance declared.")

    lines.append(f"Provenance-managed package templates: {report.managed_templates}")
    lines.append(f"Byte-synced package templates: {report.byte_synced_templates}")
    lines.append(f"Unmanaged package templates: {report.unmanaged_templates}")
    return "\n".join(lines)


def _expand_package_templates(artifact: dict[str, Any]) -> dict[str, str]:
    templates = {
        str(archive_path): str(template_name)
        for archive_path, template_name in artifact.get("package_templates", {}).items()
    }
    for generated_range in artifact.get("generated_template_ranges", []):
        start = int(generated_range["start"])
        end = int(generated_range["end"])
        for number in range(start, end + 1):
            templates[str(generated_range["archive_path"]).format(n=number)] = str(
                generated_range["template"]
            ).format(n=number)
    return templates


def _declared_template_provenance(
    artifact: dict[str, Any],
    *,
    template_names: set[str],
    external_source_templates: set[str],
) -> dict[str, ProvenanceKind]:
    provenance: dict[str, ProvenanceKind] = {
        template_name: "external_byte_sync"
        for template_name in external_source_templates
        if template_name in template_names
    }
    config = artifact.get("package_template_provenance", {})
    if isinstance(config, str):
        default_kind = _normalize_provenance_kind(config)
        if default_kind is not None:
            for template_name in template_names:
                provenance.setdefault(template_name, default_kind)
        return provenance
    if not isinstance(config, dict):
        return provenance

    default_kind = _normalize_provenance_kind(config.get("default"))
    if default_kind is not None:
        for template_name in template_names:
            provenance.setdefault(template_name, default_kind)

    explicit = config.get("templates", {})
    if isinstance(explicit, dict):
        for template_name, value in explicit.items():
            kind = _normalize_provenance_kind(value)
            if kind is not None:
                provenance[str(template_name)] = kind

    return provenance


def _normalize_provenance_kind(value: Any) -> ProvenanceKind | None:
    if isinstance(value, dict):
        value = value.get("kind")
    if not isinstance(value, str) or value not in _PROVENANCE_KINDS:
        return None
    return cast(ProvenanceKind, value)


def _resolve_local_template(artifact_root: Path, template_name: str) -> Path:
    templated = artifact_root / "templates" / template_name
    if templated.exists():
        return templated
    return artifact_root / template_name


def _check_one(
    *,
    artifact_id: str,
    local_template: str,
    upstream_rel: str,
    local_path: Path,
    upstream_path: Path,
    update: bool,
) -> SyncIssue:
    if not upstream_path.exists():
        return SyncIssue(artifact_id, local_template, upstream_rel, "missing-upstream")
    if not local_path.exists():
        if update:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(upstream_path, local_path)
            return SyncIssue(artifact_id, local_template, upstream_rel, "updated")
        return SyncIssue(artifact_id, local_template, upstream_rel, "missing-local")
    if filecmp.cmp(local_path, upstream_path, shallow=False):
        return SyncIssue(artifact_id, local_template, upstream_rel, "ok")
    if update:
        shutil.copy2(upstream_path, local_path)
        return SyncIssue(artifact_id, local_template, upstream_rel, "updated")
    return SyncIssue(artifact_id, local_template, upstream_rel, "stale")
