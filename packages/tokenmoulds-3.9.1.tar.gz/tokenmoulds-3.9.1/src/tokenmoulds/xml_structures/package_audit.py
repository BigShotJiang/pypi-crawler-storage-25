"""Audit generated packages against the packaged SSOT manifest."""

from __future__ import annotations

import json
import re
import zipfile
from importlib import resources
from io import BytesIO
from typing import Any

from tokenmoulds.validation.formats import Format
from tokenmoulds.validation.model import ValidationReport

_PACKAGE_PART_EXTENSIONS = (".xml", ".rels")


def audit_package_against_manifest(
    package: bytes,
    validation_format: str,
    *,
    manifest: dict[str, Any] | None = None,
) -> ValidationReport:
    """Validate package members against the SSOT import manifest."""
    report = ValidationReport()
    format_key = _format_key(validation_format)
    if format_key is None:
        return report

    manifest_data = manifest or _load_packaged_manifest()
    artifact = _artifact_for_format(manifest_data, format_key)
    if artifact is None:
        report.add_warning(
            "SSOT_MANIFEST_MISSING_FORMAT",
            f"No SSOT import manifest artifact for format {format_key!r}",
        )
        return report

    try:
        with zipfile.ZipFile(BytesIO(package), "r") as zf:
            names = set(zf.namelist())
    except zipfile.BadZipFile:
        report.add_error("SSOT_BAD_ZIP", "Cannot audit SSOT manifest for bad ZIP")
        return report

    expected = set(_expand_package_templates(artifact))
    missing = sorted(expected - names)
    for archive_path in missing:
        report.add_error(
            "SSOT_MISSING_PART",
            f"Package missing SSOT manifest part {archive_path}",
            location=archive_path,
            suggestion="Keep emitter package structure aligned with import_manifest.json.",
        )

    allowed_dynamic = _allowed_dynamic_patterns(format_key)
    for name in sorted(names):
        if not _is_package_xml_part(name) or name in expected:
            continue
        if any(pattern.match(name) for pattern in allowed_dynamic):
            continue
        report.add_warning(
            "SSOT_UNDECLARED_XML_PART",
            f"XML package part is not declared in SSOT manifest: {name}",
            location=name,
            suggestion="Declare static roots in import_manifest.json or classify them as dynamic.",
        )

    return report


def _load_packaged_manifest() -> dict[str, Any]:
    manifest = resources.files("tokenmoulds.xml_structures").joinpath(
        "import_manifest.json"
    )
    return json.loads(manifest.read_text(encoding="utf-8"))


def _format_key(validation_format: str) -> str | None:
    return {
        "docx": "word",
        "dotx": "word",
        Format.WORD: "word",
        Format.WORD_TEMPLATE: "word",
        "pptx": "powerpoint",
        "potx": "powerpoint",
        Format.POWERPOINT: "powerpoint",
        Format.POWERPOINT_TEMPLATE: "powerpoint",
        "xlsx": "excel",
        "xltx": "excel",
        Format.EXCEL: "excel",
        Format.EXCEL_TEMPLATE: "excel",
        "odt": "writer",
        "ott": "writer",
        Format.WRITER: "writer",
        "odp": "impress",
        "otp": "impress",
        Format.IMPRESS: "impress",
        "ods": "calc",
        "ots": "calc",
        Format.CALC: "calc",
        "odg": "draw",
        "otg": "draw",
        Format.DRAW: "draw",
    }.get(validation_format)


def _artifact_for_format(
    manifest: dict[str, Any], format_key: str
) -> dict[str, Any] | None:
    for artifact in manifest.get("artifact_sets", []):
        if artifact.get("format_key") == format_key:
            return artifact
    return None


def _expand_package_templates(artifact: dict[str, Any]) -> set[str]:
    templates = {
        str(archive_path) for archive_path in artifact.get("package_templates", {})
    }
    for generated_range in artifact.get("generated_template_ranges", []):
        start = int(generated_range["start"])
        end = int(generated_range["end"])
        pattern = str(generated_range["archive_path"])
        for number in range(start, end + 1):
            templates.add(pattern.format(n=number))
    return templates


def _is_package_xml_part(name: str) -> bool:
    return name.endswith(_PACKAGE_PART_EXTENSIONS)


def _allowed_dynamic_patterns(format_key: str) -> tuple[re.Pattern[str], ...]:
    common = (
        re.compile(r"^docProps/custom\.xml$"),
        re.compile(r"^customXml/"),
    )
    if format_key == "word":
        return common + (
            re.compile(r"^word/header\d+\.xml$"),
            re.compile(r"^word/footer\d+\.xml$"),
            re.compile(r"^word/_rels/fontTable\.xml\.rels$"),
        )
    if format_key == "powerpoint":
        return common + (
            re.compile(r"^ppt/media/"),
            re.compile(r"^ppt/fonts/"),
            re.compile(r"^ppt/slideLayouts/slideLayout\d+\.xml$"),
            re.compile(r"^ppt/slideLayouts/_rels/slideLayout\d+\.xml\.rels$"),
        )
    if format_key == "excel":
        return common + (re.compile(r"^xl/worksheets/sheet\d+\.xml$"),)
    if format_key in {"writer", "impress", "calc", "draw"}:
        return common
    return common
