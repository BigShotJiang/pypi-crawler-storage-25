"""Packaged SSOT XML template resources for TokenMoulds emitters."""

from tokenmoulds.xml_structures.manifest import load_import_manifest

__all__ = ["load_import_manifest"]
