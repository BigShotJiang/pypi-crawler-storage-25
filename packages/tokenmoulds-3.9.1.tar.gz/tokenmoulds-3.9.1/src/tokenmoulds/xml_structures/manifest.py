"""Access to the packaged XML structures import contract."""

from __future__ import annotations

import json
from importlib import resources
from typing import Any


def load_import_manifest() -> dict[str, Any]:
    """Return the packaged SSOT import manifest."""
    manifest = resources.files(__package__).joinpath("import_manifest.json")
    return json.loads(manifest.read_text(encoding="utf-8"))
