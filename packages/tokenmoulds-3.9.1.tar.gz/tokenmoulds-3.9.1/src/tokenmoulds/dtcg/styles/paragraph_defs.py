"""Paragraph style definitions."""

from __future__ import annotations

from tokenmoulds.dtcg.styles.paragraph_heading_defs import HEADING_STYLES
from tokenmoulds.dtcg.styles.paragraph_reference_defs import INDEX_STYLES, TOC_STYLES
from tokenmoulds.dtcg.styles.paragraph_special_defs import SPECIAL_STYLES
from tokenmoulds.dtcg.styles.paragraph_text_defs import (
    BODY_STYLES,
    CAPTION_STYLES,
    HEADER_FOOTER_STYLES,
    LIST_STYLES,
    NOTE_STYLES,
    QUOTE_STYLES,
)

ALL_PARAGRAPH_STYLES = (
    BODY_STYLES
    + QUOTE_STYLES
    + CAPTION_STYLES
    + HEADER_FOOTER_STYLES
    + NOTE_STYLES
    + LIST_STYLES
    + HEADING_STYLES
    + TOC_STYLES
    + INDEX_STYLES
    + SPECIAL_STYLES
)
