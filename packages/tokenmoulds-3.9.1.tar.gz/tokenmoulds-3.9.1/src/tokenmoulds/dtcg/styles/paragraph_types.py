"""Paragraph style definitions.

Pure data: 86 style definitions across 10 categories.
No runtime dependencies beyond the dataclass.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ParagraphStyleDef:
    """Definition of a paragraph style."""

    name: str  # Canonical name
    description: str
    ooxml_id: str  # Word styleId
    odf_name: str  # ODF style:name

    # Typography
    font_family: str = "{typography.font.body}"  # Reference or value
    font_size_formula: str = "{typography.scale.base}"
    font_weight: int = 400
    font_style: str = "normal"  # normal, italic

    # Spacing
    line_height_formula: str = "{typography.lineHeight.relaxed}"
    space_before_formula: str = "0"
    space_after_formula: str = "{spacing.md}"

    # Indentation
    indent_left_formula: str = "0"
    indent_right_formula: str = "0"
    indent_first_formula: str = "0"  # First line indent

    # Alignment
    alignment: str = "left"  # left, center, right, justify

    # Paragraph control
    keep_with_next: bool = False
    keep_together: bool = False
    widow_control: bool = True
    orphan_control: bool = True

    # Color
    color_formula: str = "{color.text.primary}"

    # Kerning
    kerning_threshold_formula: str = "{inputs.dimension.kerningThreshold}"

    # Parent style
    based_on: Optional[str] = None  # Parent style name
    next_style: Optional[str] = None  # Style for next paragraph
