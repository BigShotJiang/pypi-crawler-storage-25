"""Body, quote, caption, header, footer, note, and list paragraph styles."""

from __future__ import annotations

from tokenmoulds.dtcg.styles.paragraph_types import ParagraphStyleDef

# =============================================================================
# BODY TEXT STYLES
# =============================================================================

BODY_STYLES = [
    ParagraphStyleDef(
        name="Normal",
        description="Default paragraph style - base for all text",
        ooxml_id="Normal",
        odf_name="Standard",
        font_family="{typography.font.body}",
        font_size_formula="{typography.scale.base}",
        line_height_formula="{typography.lineHeight.relaxed}",
        space_after_formula="{spacing.md}",
    ),
    ParagraphStyleDef(
        name="BodyText",
        description="Body text - main content paragraphs",
        ooxml_id="BodyText",
        odf_name="Text body",
        based_on="Normal",
        font_family="{typography.font.body}",
        font_size_formula="{typography.scale.base}",
        line_height_formula="{typography.lineHeight.relaxed}",
        space_after_formula="{spacing.md}",
    ),
    ParagraphStyleDef(
        name="BodyTextIndent",
        description="Body text with first line indent",
        ooxml_id="BodyTextIndent",
        odf_name="Text body first line indent",
        based_on="BodyText",
        indent_first_formula="{spacing.lg}",
        space_after_formula="0",  # No space between indented paragraphs
    ),
    ParagraphStyleDef(
        name="BodyTextHanging",
        description="Body text with hanging indent",
        ooxml_id="BodyTextIndent2",
        odf_name="Text body hanging indent",
        based_on="BodyText",
        indent_left_formula="{spacing.lg}",
        indent_first_formula="-{spacing.lg}",  # Negative = hanging
    ),
    ParagraphStyleDef(
        name="BodyTextBlockIndent",
        description="Body text indented from left margin",
        ooxml_id="BodyTextIndent3",
        odf_name="Text body indent",
        based_on="BodyText",
        indent_left_formula="{spacing.xl}",
    ),
]


# =============================================================================
# QUOTE STYLES
# =============================================================================

QUOTE_STYLES = [
    ParagraphStyleDef(
        name="Quote",
        description="Block quotation",
        ooxml_id="Quote",
        odf_name="Quotations",
        based_on="BodyText",
        font_style="italic",
        indent_left_formula="{spacing.xl}",
        indent_right_formula="{spacing.xl}",
        space_before_formula="{spacing.lg}",
        space_after_formula="{spacing.lg}",
        color_formula="{color.text.muted}",
    ),
    ParagraphStyleDef(
        name="IntenseQuote",
        description="Emphasized block quotation",
        ooxml_id="IntenseQuote",
        odf_name="Quotations Intense",
        based_on="Quote",
        font_weight=600,
        color_formula="{color.brand.primary}",
    ),
    ParagraphStyleDef(
        name="BlockQuote",
        description="HTML-style blockquote",
        ooxml_id="HTMLBlockquote",
        odf_name="HTML Blockquote",
        based_on="Quote",
    ),
]


# =============================================================================
# CAPTION AND LABEL STYLES
# =============================================================================

CAPTION_STYLES = [
    ParagraphStyleDef(
        name="Caption",
        description="Figure/table captions",
        ooxml_id="Caption",
        odf_name="Caption",
        font_size_formula="{typography.scale.sm}",
        font_style="italic",
        space_before_formula="{spacing.sm}",
        space_after_formula="{spacing.md}",
        color_formula="{color.text.muted}",
    ),
    ParagraphStyleDef(
        name="CaptionFigure",
        description="Caption for figures/illustrations",
        ooxml_id="CaptionFigure",
        odf_name="Caption figure",
        based_on="Caption",
    ),
    ParagraphStyleDef(
        name="CaptionTable",
        description="Caption for tables",
        ooxml_id="CaptionTable",
        odf_name="Caption table",
        based_on="Caption",
    ),
    ParagraphStyleDef(
        name="CaptionDrawing",
        description="Caption for drawings",
        ooxml_id="CaptionDrawing",
        odf_name="Caption drawing objects",
        based_on="Caption",
    ),
]


# =============================================================================
# HEADER AND FOOTER STYLES
# =============================================================================

HEADER_FOOTER_STYLES = [
    ParagraphStyleDef(
        name="Header",
        description="Page header content",
        ooxml_id="Header",
        odf_name="Header",
        font_size_formula="{typography.scale.sm}",
        line_height_formula="{typography.lineHeight.normal}",
        space_after_formula="0",
        color_formula="{color.text.muted}",
    ),
    ParagraphStyleDef(
        name="HeaderLeft",
        description="Left page header",
        ooxml_id="HeaderLeft",
        odf_name="Header Left",
        based_on="Header",
        alignment="left",
    ),
    ParagraphStyleDef(
        name="HeaderRight",
        description="Right page header",
        ooxml_id="HeaderRight",
        odf_name="Header Right",
        based_on="Header",
        alignment="right",
    ),
    ParagraphStyleDef(
        name="Footer",
        description="Page footer content",
        ooxml_id="Footer",
        odf_name="Footer",
        font_size_formula="{typography.scale.sm}",
        line_height_formula="{typography.lineHeight.normal}",
        space_before_formula="0",
        color_formula="{color.text.muted}",
    ),
    ParagraphStyleDef(
        name="FooterLeft",
        description="Left page footer",
        ooxml_id="FooterLeft",
        odf_name="Footer Left",
        based_on="Footer",
        alignment="left",
    ),
    ParagraphStyleDef(
        name="FooterRight",
        description="Right page footer",
        ooxml_id="FooterRight",
        odf_name="Footer Right",
        based_on="Footer",
        alignment="right",
    ),
]


# =============================================================================
# FOOTNOTE AND ENDNOTE STYLES
# =============================================================================

NOTE_STYLES = [
    ParagraphStyleDef(
        name="FootnoteText",
        description="Footnote content",
        ooxml_id="FootnoteText",
        odf_name="Footnote",
        font_size_formula="{typography.scale.xs}",
        line_height_formula="{typography.lineHeight.snug}",
        space_after_formula="{spacing.xs}",
        indent_left_formula="{spacing.sm}",
        indent_first_formula="-{spacing.sm}",  # Hanging indent
    ),
    ParagraphStyleDef(
        name="EndnoteText",
        description="Endnote content",
        ooxml_id="EndnoteText",
        odf_name="Endnote",
        based_on="FootnoteText",
    ),
    ParagraphStyleDef(
        name="CommentText",
        description="Comment/annotation text",
        ooxml_id="CommentText",
        odf_name="Comment",
        font_size_formula="{typography.scale.xs}",
        color_formula="{color.text.muted}",
    ),
]


# =============================================================================
# LIST CONTINUATION STYLES
# =============================================================================

LIST_STYLES = [
    ParagraphStyleDef(
        name="ListParagraph",
        description="Paragraph within a list",
        ooxml_id="ListParagraph",
        odf_name="List Contents",
        based_on="BodyText",
        indent_left_formula="{spacing.xl}",
        space_after_formula="{spacing.sm}",
    ),
    ParagraphStyleDef(
        name="ListBullet",
        description="Bulleted list item",
        ooxml_id="ListBullet",
        odf_name="List 1",
        based_on="ListParagraph",
    ),
    ParagraphStyleDef(
        name="ListBullet2",
        description="Bulleted list item level 2",
        ooxml_id="ListBullet2",
        odf_name="List 2",
        based_on="ListBullet",
        indent_left_formula="{spacing.xl} * 2",
    ),
    ParagraphStyleDef(
        name="ListBullet3",
        description="Bulleted list item level 3",
        ooxml_id="ListBullet3",
        odf_name="List 3",
        based_on="ListBullet",
        indent_left_formula="{spacing.xl} * 3",
    ),
    ParagraphStyleDef(
        name="ListNumber",
        description="Numbered list item",
        ooxml_id="ListNumber",
        odf_name="Numbering 1",
        based_on="ListParagraph",
    ),
    ParagraphStyleDef(
        name="ListNumber2",
        description="Numbered list item level 2",
        ooxml_id="ListNumber2",
        odf_name="Numbering 2",
        based_on="ListNumber",
        indent_left_formula="{spacing.xl} * 2",
    ),
    ParagraphStyleDef(
        name="ListNumber3",
        description="Numbered list item level 3",
        ooxml_id="ListNumber3",
        odf_name="Numbering 3",
        based_on="ListNumber",
        indent_left_formula="{spacing.xl} * 3",
    ),
    ParagraphStyleDef(
        name="ListNumber4",
        description="Numbered list item level 4",
        ooxml_id="ListNumber4",
        odf_name="Numbering 4",
        based_on="ListNumber",
        indent_left_formula="{spacing.xl} * 4",
    ),
    ParagraphStyleDef(
        name="ListNumber5",
        description="Numbered list item level 5",
        ooxml_id="ListNumber5",
        odf_name="Numbering 5",
        based_on="ListNumber",
        indent_left_formula="{spacing.xl} * 5",
    ),
    ParagraphStyleDef(
        name="ListBullet4",
        description="Bulleted list item level 4",
        ooxml_id="ListBullet4",
        odf_name="List 4",
        based_on="ListBullet",
        indent_left_formula="{spacing.xl} * 4",
    ),
    ParagraphStyleDef(
        name="ListBullet5",
        description="Bulleted list item level 5",
        ooxml_id="ListBullet5",
        odf_name="List 5",
        based_on="ListBullet",
        indent_left_formula="{spacing.xl} * 5",
    ),
    # List continuation styles (no bullet/number)
    ParagraphStyleDef(
        name="ListContinue",
        description="Continuation paragraph in list (no bullet)",
        ooxml_id="ListContinue",
        odf_name="List Contents",
        based_on="ListParagraph",
    ),
    ParagraphStyleDef(
        name="ListContinue2",
        description="Continuation paragraph level 2",
        ooxml_id="ListContinue2",
        odf_name="List Contents 2",
        based_on="ListContinue",
        indent_left_formula="{spacing.xl} * 2",
    ),
    ParagraphStyleDef(
        name="ListContinue3",
        description="Continuation paragraph level 3",
        ooxml_id="ListContinue3",
        odf_name="List Contents 3",
        based_on="ListContinue",
        indent_left_formula="{spacing.xl} * 3",
    ),
    ParagraphStyleDef(
        name="ListContinue4",
        description="Continuation paragraph level 4",
        ooxml_id="ListContinue4",
        odf_name="List Contents 4",
        based_on="ListContinue",
        indent_left_formula="{spacing.xl} * 4",
    ),
    ParagraphStyleDef(
        name="ListContinue5",
        description="Continuation paragraph level 5",
        ooxml_id="ListContinue5",
        odf_name="List Contents 5",
        based_on="ListContinue",
        indent_left_formula="{spacing.xl} * 5",
    ),
]
