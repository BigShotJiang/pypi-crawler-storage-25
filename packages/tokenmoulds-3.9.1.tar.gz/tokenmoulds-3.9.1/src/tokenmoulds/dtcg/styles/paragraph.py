"""Paragraph style definitions with derivation formulas.

Defines all paragraph styles from the ODF/OOXML canonical set.
Each style includes properties derived from RecipeInputs.
"""

from __future__ import annotations

import ast
from typing import TYPE_CHECKING

from tokenmoulds.dtcg.types import (
    DimensionValue,
    Token,
    TokenExtensions,
    TokenGroup,
    TokenType,
)

if TYPE_CHECKING:
    from tokenmoulds.dtcg.recipe import RecipeInputs
from tokenmoulds.dtcg.styles.paragraph_defs import (  # noqa: F401
    ALL_PARAGRAPH_STYLES,
    HEADING_STYLES,
)
from tokenmoulds.dtcg.styles.paragraph_types import ParagraphStyleDef  # noqa: F401


def build_paragraph_styles(inputs: RecipeInputs) -> TokenGroup:
    """Build paragraph style tokens from inputs.

    Args:
        inputs: Recipe inputs for derivation

    Returns:
        TokenGroup containing all paragraph styles
    """
    group = TokenGroup(
        name="paragraph",
        description="Paragraph styles - body text, quotes, captions, etc.",
    )

    for style_def in ALL_PARAGRAPH_STYLES:
        style_group = _build_style_token(style_def, inputs)
        group.groups[style_def.name] = style_group

    return group


def _build_style_token(
    style_def: ParagraphStyleDef, inputs: RecipeInputs
) -> TokenGroup:
    """Build a single style as a TokenGroup."""
    spacing_map = {
        "spacing.xs": inputs.baseline_pt * 0.25,
        "spacing.sm": inputs.baseline_pt * 0.5,
        "spacing.md": inputs.baseline_pt * 1.0,
        "spacing.lg": inputs.baseline_pt * 1.5,
        "spacing.xl": inputs.baseline_pt * 2.0,
        "spacing.2xl": inputs.baseline_pt * 3.0,
        "spacing.3xl": inputs.baseline_pt * 4.0,
        "spacing.4xl": inputs.baseline_pt * 6.0,
    }
    ratio = inputs.type_scale_ratio
    scale_map = {
        "typography.scale.xs": inputs.baseline_pt * (ratio**-2),
        "typography.scale.sm": inputs.baseline_pt * (ratio**-1),
        "typography.scale.base": inputs.baseline_pt,
        "typography.scale.md": inputs.baseline_pt * (ratio**1),
        "typography.scale.lg": inputs.baseline_pt * (ratio**2),
        "typography.scale.xl": inputs.baseline_pt * (ratio**3),
        "typography.scale.2xl": inputs.baseline_pt * (ratio**4),
        "typography.scale.3xl": inputs.baseline_pt * (ratio**5),
        "typography.scale.4xl": inputs.baseline_pt * (ratio**6),
    }
    dimension_lookup = {**spacing_map, **scale_map}
    dimension_lookup["inputs.dimension.kerningThreshold"] = inputs.kerning_threshold_pt

    def _eval_expression(expr: str) -> float:
        parsed = ast.parse(expr, mode="eval")

        def _eval(node: ast.AST) -> float:
            if isinstance(node, ast.Expression):
                return _eval(node.body)
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
                return float(node.value)
            if isinstance(node, ast.UnaryOp) and isinstance(
                node.op, (ast.UAdd, ast.USub)
            ):
                value = _eval(node.operand)
                return value if isinstance(node.op, ast.UAdd) else -value
            if isinstance(node, ast.BinOp) and isinstance(
                node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)
            ):
                left = _eval(node.left)
                right = _eval(node.right)
                if isinstance(node.op, ast.Add):
                    return left + right
                if isinstance(node.op, ast.Sub):
                    return left - right
                if isinstance(node.op, ast.Mult):
                    return left * right
                return left / right
            raise ValueError(f"Unsupported formula expression: {expr}")

        return _eval(parsed)

    def _dimension_from_formula(formula: str) -> DimensionValue:
        value = formula.strip()
        try:
            return DimensionValue(value=float(value), unit="pt")
        except ValueError:
            pass
        for key, replacement in dimension_lookup.items():
            value = value.replace(f"{{{key}}}", str(replacement))
        resolved = _eval_expression(value)
        return DimensionValue(value=round(resolved, 2), unit="pt")

    style = TokenGroup(
        name=style_def.name,
        description=style_def.description,
    )

    # OOXML/ODF mapping
    style.tokens["ooxmlId"] = Token(
        name="ooxmlId",
        value=style_def.ooxml_id,
        description="Word styleId",
    )
    style.tokens["odfName"] = Token(
        name="odfName",
        value=style_def.odf_name,
        description="ODF style:name",
    )

    # Font family (reference)
    style.tokens["fontFamily"] = Token(
        name="fontFamily",
        value=style_def.font_family,
        type=TokenType.FONT_FAMILY,
    )

    # Font size (with formula)
    style.tokens["fontSize"] = Token(
        name="fontSize",
        value=style_def.font_size_formula,
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.font_size_formula,
            derivation_source="formula",
        ),
    )

    # Font weight
    style.tokens["fontWeight"] = Token(
        name="fontWeight",
        value=style_def.font_weight,
        type=TokenType.FONT_WEIGHT,
    )

    # Line height
    style.tokens["lineHeight"] = Token(
        name="lineHeight",
        value=style_def.line_height_formula,
        type=TokenType.NUMBER,
        extensions=TokenExtensions(
            derivation_formula=style_def.line_height_formula,
            derivation_source="formula",
        ),
    )

    # Spacing
    style.tokens["spaceBefore"] = Token(
        name="spaceBefore",
        value=_dimension_from_formula(style_def.space_before_formula),
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.space_before_formula,
            derivation_source="formula",
        ),
    )
    style.tokens["spaceAfter"] = Token(
        name="spaceAfter",
        value=_dimension_from_formula(style_def.space_after_formula),
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.space_after_formula,
            derivation_source="formula",
        ),
    )

    # Indentation
    style.tokens["indentLeft"] = Token(
        name="indentLeft",
        value=_dimension_from_formula(style_def.indent_left_formula),
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.indent_left_formula,
            derivation_source="formula",
        ),
    )
    style.tokens["indentFirst"] = Token(
        name="indentFirst",
        value=_dimension_from_formula(style_def.indent_first_formula),
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.indent_first_formula,
            derivation_source="formula",
        ),
    )

    # Kerning threshold
    style.tokens["kerningThreshold"] = Token(
        name="kerningThreshold",
        value=_dimension_from_formula(style_def.kerning_threshold_formula),
        type=TokenType.DIMENSION,
        extensions=TokenExtensions(
            derivation_formula=style_def.kerning_threshold_formula,
            derivation_source="formula",
        ),
    )

    # Alignment
    style.tokens["alignment"] = Token(
        name="alignment",
        value=style_def.alignment,
    )

    # Color
    style.tokens["color"] = Token(
        name="color",
        value=style_def.color_formula,
        type=TokenType.COLOR,
        extensions=TokenExtensions(
            derivation_formula=style_def.color_formula,
            derivation_source="formula",
        ),
    )

    # Paragraph control
    style.tokens["keepWithNext"] = Token(
        name="keepWithNext",
        value=1 if style_def.keep_with_next else 0,
        type=TokenType.NUMBER,
    )
    style.tokens["keepTogether"] = Token(
        name="keepTogether",
        value=1 if style_def.keep_together else 0,
        type=TokenType.NUMBER,
    )

    # Inheritance
    if style_def.based_on:
        style.tokens["basedOn"] = Token(
            name="basedOn",
            value=f"{{styles.paragraph.{style_def.based_on}.ooxmlId}}",
            description="Parent style",
        )

    if style_def.next_style:
        style.tokens["nextStyle"] = Token(
            name="nextStyle",
            value=f"{{styles.paragraph.{style_def.next_style}}}",
            description="Style for following paragraph",
        )

    return style
