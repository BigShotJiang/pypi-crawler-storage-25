"""Special paragraph styles."""

from __future__ import annotations

from tokenmoulds.dtcg.styles.paragraph_types import ParagraphStyleDef

# =============================================================================
# SPECIAL STYLES
# =============================================================================

SPECIAL_STYLES = [
    ParagraphStyleDef(
        name="Title",
        description="Document title",
        ooxml_id="Title",
        odf_name="Title",
        font_family="{typography.font.heading}",
        font_size_formula="{typography.scale.3xl}",
        font_weight=700,
        line_height_formula="{typography.lineHeight.tight}",
        space_after_formula="{spacing.xl}",
        alignment="center",
        color_formula="{color.brand.primary}",
    ),
    ParagraphStyleDef(
        name="Subtitle",
        description="Document subtitle",
        ooxml_id="Subtitle",
        odf_name="Subtitle",
        font_family="{typography.font.heading}",
        font_size_formula="{typography.scale.xl}",
        font_weight=400,
        line_height_formula="{typography.lineHeight.snug}",
        space_after_formula="{spacing.2xl}",
        alignment="center",
        color_formula="{color.text.muted}",
    ),
    ParagraphStyleDef(
        name="Signature",
        description="Signature line",
        ooxml_id="Signature",
        odf_name="Signature",
        space_before_formula="{spacing.2xl}",
        alignment="left",
    ),
    ParagraphStyleDef(
        name="Salutation",
        description="Letter salutation (Dear...)",
        ooxml_id="Salutation",
        odf_name="Salutation",
        space_before_formula="{spacing.lg}",
        space_after_formula="{spacing.md}",
    ),
    ParagraphStyleDef(
        name="Closing",
        description="Letter closing (Sincerely...)",
        ooxml_id="Closing",
        odf_name="Complimentary close",
        space_before_formula="{spacing.lg}",
    ),
    ParagraphStyleDef(
        name="Date",
        description="Date line",
        ooxml_id="Date",
        odf_name="Date",
        space_after_formula="{spacing.md}",
    ),
    ParagraphStyleDef(
        name="Preformatted",
        description="Preformatted/code block",
        ooxml_id="HTMLPreformatted",
        odf_name="Preformatted Text",
        font_family="monospace",
        font_size_formula="{typography.scale.sm}",
        line_height_formula="{typography.lineHeight.normal}",
        space_before_formula="{spacing.md}",
        space_after_formula="{spacing.md}",
    ),
]
