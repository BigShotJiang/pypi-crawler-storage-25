"""Model and merge helpers for token resolution."""

from __future__ import annotations

import copy
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from tokenmoulds.dtcg.formula_evaluator import is_formula


@dataclass(frozen=True)
class TokenLayer:
    """A named token layer with its payload."""

    name: str
    payload: Mapping[str, Any]
    source_path: Optional[str] = None


@dataclass
class Override:
    """Records a single value override during layer merging."""

    path: str
    from_layer: str
    to_layer: str
    old_value: Any
    new_value: Any


@dataclass
class FormulaEvaluation:
    """Records a formula evaluation."""

    path: str
    expression: str
    result: Any
    source_layer: Optional[str] = None


@dataclass
class LayerConflict:
    """Records when multiple layers define the same key."""

    path: str
    layers: List[str]
    final_layer: str
    final_value: Any


@dataclass
class ResolutionAudit:
    """Complete audit trail for a token resolution operation."""

    timestamp: datetime
    layers_used: List[str]
    layer_sources: Dict[str, Optional[str]]
    overrides: List[Override]
    formulas_evaluated: List[FormulaEvaluation]
    conflicts: List[LayerConflict]
    license_id: Optional[str] = None
    license_valid: Optional[bool] = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert audit to dictionary for serialization."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "layers_used": self.layers_used,
            "layer_sources": self.layer_sources,
            "overrides": [
                {
                    "path": o.path,
                    "from_layer": o.from_layer,
                    "to_layer": o.to_layer,
                    "old_value": _safe_serialize(o.old_value),
                    "new_value": _safe_serialize(o.new_value),
                }
                for o in self.overrides
            ],
            "formulas_evaluated": [
                {
                    "path": f.path,
                    "expression": f.expression,
                    "result": _safe_serialize(f.result),
                    "source_layer": f.source_layer,
                }
                for f in self.formulas_evaluated
            ],
            "conflicts": [
                {
                    "path": c.path,
                    "layers": c.layers,
                    "final_layer": c.final_layer,
                    "final_value": _safe_serialize(c.final_value),
                }
                for c in self.conflicts
            ],
            "license_id": self.license_id,
            "license_valid": self.license_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "summary": {
                "total_overrides": len(self.overrides),
                "total_formulas": len(self.formulas_evaluated),
                "total_conflicts": len(self.conflicts),
                "total_errors": len(self.errors),
                "total_warnings": len(self.warnings),
            },
        }


@dataclass
class Provenance:
    """Tracks the source layer for each token value."""

    layer: str
    source_path: Optional[str] = None
    overridden_by: Optional[List[str]] = None


@dataclass
class ResolutionResult:
    """Result of token resolution including tokens, provenance, and audit."""

    tokens: Dict[str, Any]
    provenance: Dict[str, Provenance]
    audit: ResolutionAudit

    def to_dict(
        self, include_provenance: bool = True, include_audit: bool = True
    ) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        result: Dict[str, Any] = {"tokens": self.tokens}
        if include_provenance:
            result["_provenance"] = {
                path: {
                    "layer": prov.layer,
                    "source_path": prov.source_path,
                    "overridden_by": prov.overridden_by,
                }
                for path, prov in self.provenance.items()
            }
        if include_audit:
            result["_audit"] = self.audit.to_dict()
        return result


def _safe_serialize(value: Any) -> Any:
    """Safely serialize a value for JSON output."""
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, (list, tuple)):
        return [_safe_serialize(v) for v in value]
    if isinstance(value, Mapping):
        return {k: _safe_serialize(v) for k, v in value.items()}
    return str(value)


def _deep_merge_with_tracking(
    base: Dict[str, Any],
    override: Mapping[str, Any],
    base_layer: str,
    override_layer: str,
    path_prefix: str = "",
    overrides: Optional[List[Override]] = None,
    provenance: Optional[Dict[str, Provenance]] = None,
    source_path: Optional[str] = None,
    preserve_provenance: bool = False,
) -> Dict[str, Any]:
    """Deep merge with override tracking and provenance.

    Args:
        base: Base dictionary to merge into
        override: Override dictionary to merge from
        base_layer: Name of the base layer
        override_layer: Name of the override layer
        path_prefix: Current path prefix for nested tracking
        overrides: List to append override records to
        provenance: Dict to update with provenance info
        source_path: Source file path for the override layer
        preserve_provenance: If True, don't overwrite existing provenance entries
    """
    if overrides is None:
        overrides = []
    if provenance is None:
        provenance = {}

    merged = copy.deepcopy(base)

    for key, value in override.items():
        current_path = f"{path_prefix}.{key}" if path_prefix else key

        if key in merged:
            old_value = merged[key]
            if isinstance(merged[key], dict) and isinstance(value, Mapping):
                # Recursive merge for nested dicts
                merged[key] = _deep_merge_with_tracking(
                    merged[key],
                    value,
                    base_layer,
                    override_layer,
                    current_path,
                    overrides,
                    provenance,
                    source_path,
                    preserve_provenance,
                )
            else:
                # Value override
                merged[key] = copy.deepcopy(value)

                # Skip override tracking if preserving provenance and not a real override
                if preserve_provenance and current_path in provenance:
                    continue

                overrides.append(
                    Override(
                        path=current_path,
                        from_layer=base_layer,
                        to_layer=override_layer,
                        old_value=old_value,
                        new_value=value,
                    )
                )
                # Update provenance
                existing_prov = provenance.get(current_path)
                if existing_prov:
                    if existing_prov.overridden_by is None:
                        existing_prov = Provenance(
                            layer=override_layer,
                            source_path=source_path,
                            overridden_by=[existing_prov.layer],
                        )
                    else:
                        existing_prov = Provenance(
                            layer=override_layer,
                            source_path=source_path,
                            overridden_by=existing_prov.overridden_by
                            + [existing_prov.layer],
                        )
                    provenance[current_path] = existing_prov
                else:
                    provenance[current_path] = Provenance(
                        layer=override_layer,
                        source_path=source_path,
                        overridden_by=[base_layer],
                    )
        else:
            # New key
            merged[key] = copy.deepcopy(value)

            # Skip provenance tracking if preserving and already tracked
            if preserve_provenance and current_path in provenance:
                continue

            if isinstance(value, Mapping):
                # Track provenance for nested values
                _track_nested_provenance(
                    value,
                    current_path,
                    override_layer,
                    source_path,
                    provenance,
                    preserve_existing=preserve_provenance,
                )
            else:
                if current_path not in provenance:
                    provenance[current_path] = Provenance(
                        layer=override_layer, source_path=source_path
                    )

    return merged


def _track_nested_provenance(
    data: Mapping[str, Any],
    path_prefix: str,
    layer: str,
    source_path: Optional[str],
    provenance: Dict[str, Provenance],
    preserve_existing: bool = False,
) -> None:
    """Recursively track provenance for nested structures."""
    for key, value in data.items():
        current_path = f"{path_prefix}.{key}"
        if isinstance(value, Mapping):
            _track_nested_provenance(
                value, current_path, layer, source_path, provenance, preserve_existing
            )
        else:
            # Don't overwrite existing provenance if preserving
            if not preserve_existing or current_path not in provenance:
                provenance[current_path] = Provenance(
                    layer=layer, source_path=source_path
                )


def _deep_merge(base: Dict[str, Any], override: Mapping[str, Any]) -> Dict[str, Any]:
    """Simple deep merge without tracking (for backward compatibility)."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, Mapping)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _iter_formula_paths(
    node: Any, path: Tuple[Any, ...] = ()
) -> Iterable[Tuple[Any, ...]]:
    if is_formula(node):
        yield path
        return
    if isinstance(node, Mapping):
        for key, value in node.items():
            yield from _iter_formula_paths(value, path + (key,))
    elif isinstance(node, list):
        for idx, value in enumerate(node):
            yield from _iter_formula_paths(value, path + (idx,))


def _get_path(data: Any, path: Tuple[Any, ...]) -> Any:
    value = data
    for key in path:
        value = value[key]
    return value


def _set_path(data: Any, path: Tuple[Any, ...], value: Any) -> None:
    current = data
    for key in path[:-1]:
        current = current[key]
    current[path[-1]] = value


def _path_to_str(path: Tuple[Any, ...]) -> str:
    return ".".join(str(p) for p in path)


def _detect_conflicts(layers: Sequence[TokenLayer]) -> List[LayerConflict]:
    """Detect keys that are defined in multiple layers."""
    key_layers: Dict[str, List[Tuple[str, Any]]] = {}

    def collect_keys(
        data: Mapping[str, Any], layer_name: str, path_prefix: str = ""
    ) -> None:
        for key, value in data.items():
            current_path = f"{path_prefix}.{key}" if path_prefix else key
            if isinstance(value, Mapping):
                collect_keys(value, layer_name, current_path)
            else:
                if current_path not in key_layers:
                    key_layers[current_path] = []
                key_layers[current_path].append((layer_name, value))

    for layer in layers:
        collect_keys(layer.payload, layer.name)

    conflicts = []
    for path, layer_values in key_layers.items():
        if len(layer_values) > 1:
            layers_list = [lv[0] for lv in layer_values]
            final_layer, final_value = layer_values[-1]
            conflicts.append(
                LayerConflict(
                    path=path,
                    layers=layers_list,
                    final_layer=final_layer,
                    final_value=final_value,
                )
            )

    return conflicts
