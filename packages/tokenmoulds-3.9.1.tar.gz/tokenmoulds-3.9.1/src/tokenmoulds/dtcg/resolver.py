"""Hierarchical token resolver with formula evaluation, audit trail, and provenance tracking."""

from __future__ import annotations

import copy
import json
import logging
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple, Union

from tokenmoulds.dtcg.generator import TokenGenerator
from tokenmoulds.dtcg.resolver_models import (
    FormulaEvaluation,
    Provenance,
    ResolutionAudit,
    ResolutionResult,
    TokenLayer,
    _deep_merge,
    _deep_merge_with_tracking,
    _detect_conflicts,
    _get_path,
    _iter_formula_paths,
    _path_to_str,
    _set_path,
    _track_nested_provenance,
)
from tokenmoulds.dtcg.errors import (
    FormulaError,
    FormulaReferenceError,
    FormulaResolutionError,
)
from tokenmoulds.dtcg.formula_evaluator import (
    FormulaEvaluator,
    is_formula,
    strip_formula,
)
from tokenmoulds.dtcg.loader import load_token_file

logger = logging.getLogger(__name__)

# Layer precedence order (lowest to highest)
LAYER_ORDER = ("core", "fork", "org", "group", "personal")


class TokenResolver:
    """Resolve layered token sets with formula evaluation, audit trail, and provenance tracking."""

    def __init__(
        self,
        evaluator: FormulaEvaluator | None = None,
        generator: TokenGenerator | None = None,
        *,
        use_engine: bool = True,
        license_validator: Any = None,
        layer_validator: Any = None,
    ) -> None:
        self._evaluator = evaluator or FormulaEvaluator()
        self._generator = generator or TokenGenerator()
        self._use_engine = use_engine
        self._license_validator = license_validator
        self._layer_validator = layer_validator

    def resolve_layers(
        self,
        layers: Sequence[TokenLayer],
        *,
        track_provenance: bool = True,
        track_audit: bool = True,
        license_context: Any = None,
        validate_layers: bool = False,
        strict_validation: bool = False,
    ) -> Union[Dict[str, Any], ResolutionResult]:
        """Resolve layered tokens with optional provenance and audit tracking.

        Args:
            layers: Sequence of TokenLayer objects in precedence order (lowest first)
            track_provenance: If True, return ResolutionResult with provenance
            track_audit: If True, include audit trail in result
            license_context: Optional LicenseContext for validation
            validate_layers: If True, validate each layer against schema before merging
            strict_validation: If True, treat validation warnings as errors

        Returns:
            If track_provenance is False: Dict of resolved tokens (backward compatible)
            If track_provenance is True: ResolutionResult with tokens, provenance, and audit
        """
        audit = ResolutionAudit(
            timestamp=datetime.now(timezone.utc),
            layers_used=[layer.name for layer in layers],
            layer_sources={layer.name: layer.source_path for layer in layers},
            overrides=[],
            formulas_evaluated=[],
            conflicts=[],
        )

        # Layer validation
        if validate_layers:
            self._validate_layers(layers, strict_validation, audit)

        # License validation
        if license_context and self._license_validator:
            try:
                result = self._license_validator.validate(license_context)
                audit.license_id = result.license_id
                audit.license_valid = result.allowed

                # Filter layers based on license permissions
                if result.layers:
                    allowed_layers = []
                    for layer in layers:
                        if result.layers.get(layer.name, False):
                            allowed_layers.append(layer)
                        else:
                            audit.warnings.append(
                                f"Layer '{layer.name}' not permitted by license '{result.license_id}'"
                            )
                    layers = allowed_layers

                if not result.allowed:
                    audit.errors.append(
                        f"License validation failed: {result.license_id}"
                    )
            except Exception as e:
                audit.errors.append(f"License validation error: {e}")
                logger.warning(f"License validation failed: {e}")

        # Detect conflicts before merging
        if track_audit:
            audit.conflicts = _detect_conflicts(layers)
            for conflict in audit.conflicts:
                audit.warnings.append(
                    f"Key '{conflict.path}' defined in multiple layers: {conflict.layers} "
                    f"(using '{conflict.final_layer}')"
                )

        # Merge layers with tracking
        provenance: Dict[str, Provenance] = {}
        merged: Dict[str, Any] = {}
        prev_layer = "base"

        for layer in layers:
            if track_provenance:
                merged = _deep_merge_with_tracking(
                    merged,
                    layer.payload,
                    prev_layer,
                    layer.name,
                    overrides=audit.overrides,
                    provenance=provenance,
                    source_path=layer.source_path,
                )
            else:
                merged = _deep_merge(merged, layer.payload)
            prev_layer = layer.name

        # Resolve inputs formulas
        inputs = merged.get("inputs", {})
        if isinstance(inputs, Mapping) and inputs:
            resolved_inputs, input_formulas = self._resolve_formulas_with_tracking(
                {"inputs": inputs}, "inputs"
            )
            resolved_inputs = resolved_inputs.get("inputs", {})
            audit.formulas_evaluated.extend(input_formulas)
        else:
            resolved_inputs = {}

        # Generate derived tokens
        generated: Dict[str, Any] = {}
        if (
            self._use_engine
            and isinstance(resolved_inputs, Mapping)
            and resolved_inputs
        ):
            generated = self._generator.generate(resolved_inputs)
            # Track generated tokens provenance
            if track_provenance:
                _track_nested_provenance(generated, "", "generated", None, provenance)

        # Merge generated with overrides
        overrides = dict(merged)
        if resolved_inputs:
            overrides["inputs"] = resolved_inputs

        if track_provenance:
            # When merging overrides, preserve existing provenance from layers
            # Only update provenance for values that come from generated tokens
            resolved = _deep_merge_with_tracking(
                generated,
                overrides,
                "generated",
                "overrides",
                overrides=audit.overrides,
                provenance=provenance,
                preserve_provenance=True,  # Don't overwrite layer provenance with "overrides"
            )
        else:
            resolved = _deep_merge(generated, overrides)

        # Resolve remaining formulas
        resolved, final_formulas = self._resolve_formulas_with_tracking(
            resolved, "final"
        )
        audit.formulas_evaluated.extend(final_formulas)

        # Log audit
        self._log_audit(audit)

        if track_provenance:
            return ResolutionResult(
                tokens=resolved,
                provenance=provenance,
                audit=audit,
            )
        return resolved

    def resolve_files(
        self,
        files: Sequence[Tuple[str, Path]],
        *,
        track_provenance: bool = False,
        track_audit: bool = True,
        license_context: Any = None,
    ) -> Union[Dict[str, Any], ResolutionResult]:
        """Resolve tokens from file paths."""
        layers: List[TokenLayer] = []
        for name, path in files:
            payload = load_token_file(path)
            layers.append(TokenLayer(name=name, payload=payload, source_path=str(path)))
        return self.resolve_layers(
            layers,
            track_provenance=track_provenance,
            track_audit=track_audit,
            license_context=license_context,
        )

    def _resolve_formulas_with_tracking(
        self,
        data: Mapping[str, Any],
        phase: str = "",
    ) -> Tuple[Dict[str, Any], List[FormulaEvaluation]]:
        """Resolve formulas and track evaluations."""
        resolved = copy.deepcopy(data)
        formula_evals: List[FormulaEvaluation] = []
        pending = list(_iter_formula_paths(resolved))

        if not pending:
            return dict(resolved), formula_evals

        context = self._build_context(resolved)
        max_passes = max(5, len(pending) * 2)

        for _ in range(max_passes):
            progress = False
            next_pending: List[Tuple[Any, ...]] = []

            for path in pending:
                value = _get_path(resolved, path)
                if not is_formula(value):
                    progress = True
                    continue

                expression = strip_formula(value)
                try:
                    evaluated = self._evaluator.evaluate(expression, context)
                except FormulaReferenceError:
                    next_pending.append(path)
                    continue
                except FormulaError as exc:
                    raise FormulaResolutionError(
                        f"Failed to evaluate formula at {_path_to_str(path)}: {exc}"
                    ) from exc

                _set_path(resolved, path, evaluated)
                context = self._build_context(resolved)
                progress = True

                formula_evals.append(
                    FormulaEvaluation(
                        path=_path_to_str(path),
                        expression=expression,
                        result=evaluated,
                        source_layer=phase,
                    )
                )

            pending = next_pending
            if not pending:
                return dict(resolved), formula_evals
            if not progress:
                break

        if pending:
            unresolved = ", ".join(_path_to_str(path) for path in pending)
            raise FormulaResolutionError(
                f"Unresolved formulas after evaluation: {unresolved}"
            )

        return dict(resolved), formula_evals

    def _resolve_formulas(self, data: Mapping[str, Any]) -> Dict[str, Any]:
        """Resolve formulas without tracking (backward compatibility)."""
        resolved, _ = self._resolve_formulas_with_tracking(data)
        return resolved

    @staticmethod
    def _build_context(data: Mapping[str, Any]) -> Dict[str, Any]:
        context = dict(data)
        inputs = data.get("inputs")
        if isinstance(inputs, Mapping):
            for key, value in inputs.items():
                context.setdefault(key, value)
        return context

    def _validate_layers(
        self,
        layers: Sequence[TokenLayer],
        strict: bool,
        audit: ResolutionAudit,
    ) -> Dict[str, Any]:
        """Validate layers against schema before merging."""
        results = {}

        # Use provided validator or create one
        if self._layer_validator:
            validator = self._layer_validator
        else:
            try:
                from tokenmoulds.dtcg.layer_validator import LayerValidator

                validator = LayerValidator(strict=strict)
            except ImportError:
                audit.warnings.append(
                    "Layer validation skipped: layer_validator not available"
                )
                return results

        for layer in layers:
            result = validator.validate(layer.payload, layer_name=layer.name)
            results[layer.name] = result

            # Add validation issues to audit
            for issue in result.issues:
                if issue.severity == "error":
                    audit.errors.append(f"[{layer.name}] {issue.path}: {issue.message}")
                elif issue.severity == "warning":
                    audit.warnings.append(
                        f"[{layer.name}] {issue.path}: {issue.message}"
                    )

            if not result.is_valid:
                logger.warning(
                    f"Layer '{layer.name}' validation failed with {len(result.errors)} errors"
                )

        return results

    def _log_audit(self, audit: ResolutionAudit) -> None:
        """Log audit trail for compliance."""
        log_entry = {
            "event": "token.resolution",
            "timestamp": audit.timestamp.isoformat(),
            "layers": audit.layers_used,
            "license_id": audit.license_id,
            "overrides_count": len(audit.overrides),
            "formulas_count": len(audit.formulas_evaluated),
            "conflicts_count": len(audit.conflicts),
            "warnings_count": len(audit.warnings),
            "errors_count": len(audit.errors),
        }
        logger.info(json.dumps(log_entry, sort_keys=True))

        if audit.warnings:
            for warning in audit.warnings:
                logger.warning(f"Token resolution warning: {warning}")

        if audit.errors:
            for error in audit.errors:
                logger.error(f"Token resolution error: {error}")
