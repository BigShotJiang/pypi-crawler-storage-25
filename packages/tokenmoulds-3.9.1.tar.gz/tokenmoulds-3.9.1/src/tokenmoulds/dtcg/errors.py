"""Token resolution errors for TokenMoulds."""


class TokenError(Exception):
    """Base error for token processing failures."""


class TokenLoadError(TokenError):
    """Raised when token files cannot be loaded."""


class FormulaError(TokenError):
    """Raised when a formula expression fails to evaluate."""


class FormulaResolutionError(FormulaError):
    """Raised when formulas cannot be resolved after evaluation passes."""


class FormulaReferenceError(FormulaError):
    """Raised when a formula references an unresolved token."""


class MappingError(TokenError):
    """Raised when mapping resolution fails."""


class LayerValidationError(TokenError):
    """Raised when a token layer fails schema validation."""

    def __init__(self, layer_name: str, errors: list, message: str | None = None):
        self.layer_name = layer_name
        self.errors = errors
        super().__init__(message or f"Layer '{layer_name}' validation failed: {errors}")
