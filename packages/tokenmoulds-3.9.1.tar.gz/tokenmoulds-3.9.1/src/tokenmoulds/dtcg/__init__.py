"""W3C Design Tokens Community Group (DTCG) format support.

This module provides parsing, validation, and emission of design tokens
in the DTCG format (https://tr.designtokens.org/format/).

Example:
    from tokenmoulds.dtcg import parse_tokens, emit_tokens, TokenFile

    # Parse a .tokens.json file
    token_file = parse_tokens(Path("design.tokens.json"))

    # Access tokens
    primary_color = token_file.get_token("color.primary")
    print(primary_color.value)  # "#2563EB"

    # Emit to file
    emit_tokens(token_file, Path("output.tokens.json"))
"""

from tokenmoulds.dtcg.types import (
    Token,
    TokenFile,
    TokenGroup,
    TokenType,
    TokenValue,
    # Value types
    ColorValue,
    DimensionValue,
    TypographyValue,
    ShadowValue,
    BorderValue,
    GradientValue,
    GradientStop,
    StrokeStyleValue,
    TransitionValue,
    CubicBezierValue,
)
from tokenmoulds.dtcg.parser import parse_tokens, parse_tokens_from_string
from tokenmoulds.dtcg.emitter import (
    emit_tokens,
    emit_tokens_to_dict,
    emit_tokens_to_string,
)
from tokenmoulds.dtcg.converter import convert_to_dtcg, convert_from_dtcg
from tokenmoulds.dtcg.layered_adapter import adapt_dtcg_layers
from tokenmoulds.dtcg.generator import AdvancedTokenEngine, TokenGenerator
from tokenmoulds.dtcg.recipe import build_recipe, RecipeInputs

__all__ = [
    # Core types
    "Token",
    "TokenFile",
    "TokenGroup",
    "TokenType",
    "TokenValue",
    # Value types
    "ColorValue",
    "DimensionValue",
    "TypographyValue",
    "ShadowValue",
    "BorderValue",
    "GradientValue",
    "GradientStop",
    "StrokeStyleValue",
    "TransitionValue",
    "CubicBezierValue",
    # Functions
    "parse_tokens",
    "parse_tokens_from_string",
    "emit_tokens",
    "emit_tokens_to_dict",
    "emit_tokens_to_string",
    "convert_to_dtcg",
    "convert_from_dtcg",
    "adapt_dtcg_layers",
    # Generator
    "AdvancedTokenEngine",
    "TokenGenerator",
    "build_recipe",
    "RecipeInputs",
]
