"""Catalog data for slide layout recipe resolution."""

from __future__ import annotations

from dataclasses import dataclass, field

# Placeholder name → PPTX (ph_type, ph_idx) mapping
# ---------------------------------------------------------------------------

#: Maps token region names to PPTX ``<p:ph type="..." idx="..."/>`` values.
#: ph_type or ph_idx is None when the PPTX attribute is absent.
_INCIDENTAL_PH: dict[str, tuple[str | None, str | None]] = {
    "date": ("dt", "10"),
    "footer": ("ftr", "11"),
    "slide_num": ("sldNum", "12"),
}

PPTX_PLACEHOLDER_MAP: dict[str, dict[str, tuple[str | None, str | None]]] = {
    "title_slide": {
        "title": ("ctrTitle", None),
        "subtitle": ("subTitle", "1"),
        **_INCIDENTAL_PH,
    },
    "title_content": {
        "title": ("title", None),
        "body": (None, "1"),
        **_INCIDENTAL_PH,
    },
    "section_header": {
        "title": ("title", None),
        "body": ("body", "1"),
        **_INCIDENTAL_PH,
    },
    "two_content": {
        "title": ("title", None),
        "body_left": (None, "1"),
        "body_right": (None, "2"),
        **_INCIDENTAL_PH,
    },
    "comparison": {
        "title": ("title", None),
        "label_left": ("body", "1"),
        "content_left": (None, "2"),
        "label_right": ("body", "3"),
        "content_right": (None, "4"),
        **_INCIDENTAL_PH,
    },
    "title_only": {
        "title": ("title", None),
        **_INCIDENTAL_PH,
    },
    "blank": {
        **_INCIDENTAL_PH,
    },
    "content_caption": {
        "title": ("title", None),
        "content": (None, "1"),
        "caption": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "picture_caption": {
        "title": ("title", None),
        "picture": ("pic", "1"),
        "caption": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "vertical_text": {
        "title": ("title", None),
        "body": (None, "1"),
        **_INCIDENTAL_PH,
    },
    "vertical_title": {
        "title": ("title", None),
        "body": (None, "1"),
        **_INCIDENTAL_PH,
    },
    # --- Extended standard layouts (12-37) ---
    "title_alt": {
        "title": ("ctrTitle", None),
        "subtitle": ("subTitle", "1"),
        **_INCIDENTAL_PH,
    },
    "text": {
        "title": ("title", None),
        "body": ("body", "1"),
        **_INCIDENTAL_PH,
    },
    "two_column_text": {
        "title": ("title", None),
        "body_left": ("body", "1"),
        "body_right": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "table": {
        "title": ("title", None),
        "table": ("tbl", "1"),
        **_INCIDENTAL_PH,
    },
    "text_and_chart": {
        "title": ("title", None),
        "text": ("body", "1"),
        "chart": ("chart", "2"),
        **_INCIDENTAL_PH,
    },
    "chart_and_text": {
        "title": ("title", None),
        "chart": ("chart", "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "diagram": {
        "title": ("title", None),
        "diagram": ("dgm", "1"),
        **_INCIDENTAL_PH,
    },
    "chart": {
        "title": ("title", None),
        "chart": ("chart", "1"),
        **_INCIDENTAL_PH,
    },
    "text_and_clipart": {
        "title": ("title", None),
        "text": ("body", "1"),
        "clipart": ("clipArt", "2"),
        **_INCIDENTAL_PH,
    },
    "clipart_and_text": {
        "title": ("title", None),
        "clipart": ("clipArt", "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "text_and_media": {
        "title": ("title", None),
        "text": ("body", "1"),
        "media": ("media", "2"),
        **_INCIDENTAL_PH,
    },
    "media_and_text": {
        "title": ("title", None),
        "media": ("media", "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "text_and_object": {
        "title": ("title", None),
        "text": ("body", "1"),
        "object": (None, "2"),
        **_INCIDENTAL_PH,
    },
    "object_and_text": {
        "title": ("title", None),
        "object": (None, "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "object_only": {
        "title": ("title", None),
        "object": (None, "1"),
        **_INCIDENTAL_PH,
    },
    "object_over_text": {
        "title": ("title", None),
        "object": (None, "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "text_over_object": {
        "title": ("title", None),
        "text": ("body", "1"),
        "object": (None, "2"),
        **_INCIDENTAL_PH,
    },
    "text_and_two_objects": {
        "title": ("title", None),
        "text": ("body", "1"),
        "object_top": (None, "2"),
        "object_bottom": (None, "3"),
        **_INCIDENTAL_PH,
    },
    "two_objects_and_text": {
        "title": ("title", None),
        "object_top": (None, "1"),
        "object_bottom": (None, "2"),
        "text": ("body", "3"),
        **_INCIDENTAL_PH,
    },
    "two_objects_over_text": {
        "title": ("title", None),
        "object_left": (None, "1"),
        "object_right": (None, "2"),
        "text": ("body", "3"),
        **_INCIDENTAL_PH,
    },
    "four_objects": {
        "title": ("title", None),
        "object_tl": (None, "1"),
        "object_tr": (None, "2"),
        "object_bl": (None, "3"),
        "object_br": (None, "4"),
        **_INCIDENTAL_PH,
    },
    "object_and_two_objects": {
        "title": ("title", None),
        "object_large": (None, "1"),
        "object_top": (None, "2"),
        "object_bottom": (None, "3"),
        **_INCIDENTAL_PH,
    },
    "two_objects_and_object": {
        "title": ("title", None),
        "object_top": (None, "1"),
        "object_bottom": (None, "2"),
        "object_large": (None, "3"),
        **_INCIDENTAL_PH,
    },
    "large_object": {
        "title": ("title", None),
        "content": (None, "1"),
        **_INCIDENTAL_PH,
    },
    "clipart_and_vertical_text": {
        "title": ("title", None),
        "clipart": ("clipArt", "1"),
        "text": ("body", "2"),
        **_INCIDENTAL_PH,
    },
    "vertical_title_text_chart": {
        "title": ("title", None),
        "content": (None, "1"),
        **_INCIDENTAL_PH,
    },
}

#: Maps token layout type names to PPTX layout type attribute values.
LAYOUT_TYPE_TO_PPTX: dict[str, str] = {
    "title_slide": "title",
    "title_content": "obj",
    "section_header": "secHead",
    "two_content": "twoObj",
    "comparison": "twoTxTwoObj",
    "title_only": "titleOnly",
    "blank": "blank",
    "content_caption": "objTx",
    "picture_caption": "picTx",
    "vertical_text": "vertTx",
    "vertical_title": "vertTitleAndTx",
    # Extended standard layouts
    "title_alt": "title",
    "text": "tx",
    "two_column_text": "twoColTx",
    "table": "tbl",
    "text_and_chart": "txAndChart",
    "chart_and_text": "chartAndTx",
    "diagram": "dgm",
    "chart": "chart",
    "text_and_clipart": "txAndClipArt",
    "clipart_and_text": "clipArtAndTx",
    "text_and_media": "txAndMedia",
    "media_and_text": "mediaAndTx",
    "text_and_object": "txAndObj",
    "object_and_text": "objAndTx",
    "object_only": "objOnly",
    "object_over_text": "objOverTx",
    "text_over_object": "txOverObj",
    "text_and_two_objects": "txAndTwoObj",
    "two_objects_and_text": "twoObjAndTx",
    "two_objects_over_text": "twoObjOverTx",
    "four_objects": "fourObj",
    "object_and_two_objects": "objAndTwoObj",
    "two_objects_and_object": "twoObjAndObj",
    "large_object": "obj",
    "clipart_and_vertical_text": "clipArtAndVertTx",
    "vertical_title_text_chart": "vertTitleAndTxOverChart",
}

#: Reverse mapping: PPTX type → token layout type.
#: Extended entries are inserted first so the core 11 layouts win on
#: duplicate PPTX type keys (e.g. "title" → "title_slide" not "title_alt").
PPTX_TO_LAYOUT_TYPE: dict[str, str] = {
    v: k for k, v in reversed(list(LAYOUT_TYPE_TO_PPTX.items()))
}

#: Maps token region names to ODF ``presentation:object`` values.
#: Used by the Impress emitter to resolve placeholder classes.
ODF_PLACEHOLDER_MAP: dict[str, str] = {
    "title": "title",
    "subtitle": "subtitle",
    "body": "outline",
    "body_left": "outline",
    "body_right": "outline",
    "content": "object",
    "caption": "notes",
    "picture": "object",
    "label_left": "text",
    "label_right": "text",
    "content_left": "object",
    "content_right": "object",
    # Extended layout regions
    "table": "object",
    "chart": "chart",
    "diagram": "object",
    "media": "object",
    "clipart": "graphic",
    "text": "text",
    "object": "object",
    "object_large": "object",
    "object_top": "object",
    "object_bottom": "object",
    "object_left": "object",
    "object_right": "object",
    "object_tl": "object",
    "object_tr": "object",
    "object_bl": "object",
    "object_br": "object",
}

#: Maps token layout type names to ODF presentation-page-layout names.
LAYOUT_TYPE_TO_ODF: dict[str, tuple[str, str]] = {
    "title_slide": ("AL1T", "Title Slide"),
    "title_content": ("AL2T", "Title, Content"),
    "section_header": ("AL3T", "Section Header"),
    "two_content": ("AL4T", "Two Content"),
    "comparison": ("AL5T", "Comparison"),
    "title_only": ("AL6T", "Title Only"),
    "blank": ("AL0T", "Blank"),
    "content_caption": ("AL7T", "Content with Caption"),
    "picture_caption": ("AL8T", "Picture with Caption"),
    "vertical_text": ("AL9T", "Vertical Text"),
    "vertical_title": ("AL10T", "Vertical Title and Text"),
    # Extended standard layouts
    "title_alt": ("AL11T", "Title (Alt)"),
    "text": ("AL12T", "Text"),
    "two_column_text": ("AL13T", "Two Column Text"),
    "table": ("AL14T", "Table"),
    "text_and_chart": ("AL15T", "Text and Chart"),
    "chart_and_text": ("AL16T", "Chart and Text"),
    "diagram": ("AL17T", "Diagram"),
    "chart": ("AL18T", "Chart"),
    "text_and_clipart": ("AL19T", "Text and ClipArt"),
    "clipart_and_text": ("AL20T", "ClipArt and Text"),
    "text_and_media": ("AL21T", "Text and MediaClip"),
    "media_and_text": ("AL22T", "MediaClip and Text"),
    "text_and_object": ("AL23T", "Text and Object"),
    "object_and_text": ("AL24T", "Object and Text"),
    "object_only": ("AL25T", "Object"),
    "object_over_text": ("AL26T", "Object over Text"),
    "text_over_object": ("AL27T", "Text over Object"),
    "text_and_two_objects": ("AL28T", "Text and Two Objects"),
    "two_objects_and_text": ("AL29T", "Two Objects and Text"),
    "two_objects_over_text": ("AL30T", "Two Objects over Text"),
    "four_objects": ("AL31T", "Four Objects"),
    "object_and_two_objects": ("AL32T", "Object and Two Objects"),
    "two_objects_and_object": ("AL33T", "Two Objects and Object"),
    "large_object": ("AL34T", "Large Object"),
    "clipart_and_vertical_text": ("AL35T", "ClipArt and Vertical Text"),
    "vertical_title_text_chart": ("AL36T", "Vertical Title and Text over Chart"),
}


@dataclass(frozen=True)
class SemanticLayoutSpec:
    """Semantic slide archetype metadata used outside the standard 11 layouts."""

    name: str
    display_name: str
    fallback_standard_layout: str
    placeholder_map: dict[str, tuple[str | None, str | None]] = field(
        default_factory=dict
    )
    decorative_regions: frozenset[str] = frozenset()
    pptx_layout_number: int | None = None
    pptx_base_type: str | None = None
    seed_template_name: str | None = None


SEMANTIC_LAYOUT_SPECS: dict[str, SemanticLayoutSpec] = {
    "hero_cover": SemanticLayoutSpec(
        name="hero_cover",
        display_name="Hero Cover",
        fallback_standard_layout="title_slide",
        placeholder_map={
            "title": ("title", None),
            "subtitle": (None, "1"),
            **_INCIDENTAL_PH,
        },
        decorative_regions=frozenset(
            {"background", "overlay", "kicker", "footer_band"}
        ),
        pptx_layout_number=39,
        pptx_base_type="cust",
        seed_template_name="ssot/slide_hero.xml",
    ),
    "section_statement": SemanticLayoutSpec(
        name="section_statement",
        display_name="Section Statement",
        fallback_standard_layout="section_header",
        placeholder_map={
            "title": ("title", None),
            "body": ("body", "1"),
            **_INCIDENTAL_PH,
        },
        decorative_regions=frozenset({"background", "band"}),
        pptx_layout_number=38,
        pptx_base_type="cust",
        seed_template_name="ssot/slide_section_statement.xml",
    ),
    "card_matrix": SemanticLayoutSpec(
        name="card_matrix",
        display_name="Card Matrix",
        fallback_standard_layout="two_content",
        placeholder_map={
            "title": ("title", None),
            "body": ("body", "1"),
            **_INCIDENTAL_PH,
        },
        decorative_regions=frozenset({"card_1", "card_2", "card_3", "card_4"}),
        pptx_layout_number=40,
        pptx_base_type="cust",
        seed_template_name="ssot/slide_card_matrix.xml",
    ),
}
