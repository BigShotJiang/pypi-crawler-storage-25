"""Resolver for long-form document token groups.

Translates the ``page_geometry``, ``margin_presets``, ``headers``,
``footers``, and ``sections`` token groups into the IR dataclasses
used by Word/Writer section emission.

Unit convention — **pt throughout**.  Tokens are pt, IR is pt, and
conversion to twips/cm/EMU happens only at the emitter serialization
boundary.  The resolver never touches format-specific units.

The resolver is deliberately decoupled from the main DTCG resolver:
these groups use a tiny formula dialect like ``"{typography.baseline} * 10"``
rather than the full ``${...}`` formula system.  Keeps the section-layer
logic independent of typography resolution order.
"""

from __future__ import annotations

from typing import Any

from tokenmoulds.dtcg.formula_evaluator import FormulaEvaluator
from tokenmoulds.ir.long_form import (
    HeaderFooterConfig,
    LongFormSection,
    NamedMargins,
    NamedPageGeometry,
    PageNumberConfig,
)
from tokenmoulds.semantic.content import (
    SemanticContent,
    parse_authored_semantic_content,
)

_FORMULA_EVALUATOR = FormulaEvaluator()
_HEADER_FOOTER_SLOTS = ("left", "center", "right", "outer", "inner")
_HEADER_FOOTER_VARIANTS = {
    "headers": {
        "minimal": "HeaderMinimal",
        "running": "HeaderRunning",
        "appendix": "HeaderAppendix",
    },
    "footers": {
        "centered": "FooterCentered",
        "outer": "FooterOuter",
        "full": "FooterFull",
    },
}


def _unwrap(value: Any) -> Any:
    """Unwrap a DTCG ``{"$value": X}`` envelope (noop for raw values)."""
    if isinstance(value, dict) and "$value" in value:
        return value["$value"]
    return value


def _iter_entries(group: dict) -> list[tuple[str, dict]]:
    """Yield ``(name, entry)`` pairs, skipping DTCG ``$``-prefixed meta keys."""
    return [
        (name, entry)
        for name, entry in group.items()
        if not name.startswith("$") and isinstance(entry, dict)
    ]


def _resolve_pt(value: Any, baseline_pt: float) -> float:
    """Resolve a margin/spacing token to a point value.

    Supports plain ints/floats (already pt) and formula strings like
    ``"{typography.baseline} * 10"`` delegated to the shared
    :class:`FormulaEvaluator` with ``typography.baseline`` bound in pt.
    """
    raw = _unwrap(value)
    if isinstance(raw, (int, float)):
        return float(raw)
    if isinstance(raw, str):
        # Strip the DTCG-style {braces} so FormulaEvaluator sees bare refs.
        stripped = raw.replace("{", "").replace("}", "")
        context = {"typography": {"baseline": baseline_pt}}
        try:
            return float(_FORMULA_EVALUATOR.evaluate(stripped, context))
        except Exception as exc:  # pragma: no cover - defensive
            raise ValueError(
                f"Could not evaluate margin formula {raw!r}: {exc}"
            ) from exc
    raise ValueError(f"Unsupported margin value: {raw!r}")


def resolve_page_geometries(tokens: dict) -> dict[str, NamedPageGeometry]:
    """Resolve the ``page_geometry`` group to a name→geometry map.

    Token fields are in pt (``width_pt`` / ``height_pt``) and flow
    straight through to the IR unchanged.
    """
    group = tokens.get("page_geometry", {})
    result: dict[str, NamedPageGeometry] = {}
    for name, entry in _iter_entries(group):
        width_pt = _unwrap(entry.get("width_pt"))
        height_pt = _unwrap(entry.get("height_pt"))
        if width_pt is None or height_pt is None:
            raise ValueError(f"page_geometry {name!r} missing width_pt or height_pt")
        orientation = _unwrap(entry.get("orientation", "portrait"))
        result[name] = NamedPageGeometry(
            name=name,
            width_pt=float(width_pt),
            height_pt=float(height_pt),
            orientation=orientation,
        )
    return result


def resolve_margin_presets(tokens: dict, baseline_pt: float) -> dict[str, NamedMargins]:
    """Resolve the ``margin_presets`` group to a name→margins map.

    Token field values are pt (plain numbers or formulas referencing
    ``{typography.baseline}`` in pt).  Results flow straight to the IR.
    """
    group = tokens.get("margin_presets", {})
    result: dict[str, NamedMargins] = {}
    for name, entry in _iter_entries(group):
        mirror = bool(_unwrap(entry.get("mirror", False)))

        def _opt(key: str) -> float | None:
            if key not in entry:
                return None
            return _resolve_pt(entry[key], baseline_pt)

        if "top" not in entry or "bottom" not in entry:
            raise ValueError(f"margin_preset {name!r} must have top and bottom")

        result[name] = NamedMargins(
            name=name,
            top_pt=_resolve_pt(entry["top"], baseline_pt),
            bottom_pt=_resolve_pt(entry["bottom"], baseline_pt),
            left_pt=_opt("left"),
            right_pt=_opt("right"),
            outer_pt=_opt("outer"),
            inner_pt=_opt("inner"),
            gutter_pt=_resolve_pt(entry.get("gutter", 0), baseline_pt),
            mirror=mirror,
        )
    return result


def _resolve_header_footer_style(group_name: str, name: str, entry: dict) -> str:
    style = _unwrap(entry.get("style", "")) or ""
    variant = _unwrap(entry.get("variant"))
    if style:
        if variant is not None:
            mapped = _HEADER_FOOTER_VARIANTS[group_name].get(variant)
            if mapped is None:
                raise ValueError(
                    f"{group_name[:-1]} {name!r} has unknown variant {variant!r}"
                )
            if mapped != style:
                raise ValueError(
                    f"{group_name[:-1]} {name!r} style {style!r} conflicts with "
                    f"variant {variant!r}"
                )
        return style

    if variant is None:
        return ""

    if not isinstance(variant, str):
        raise ValueError(f"{group_name[:-1]} {name!r} variant must be a string")

    mapped = _HEADER_FOOTER_VARIANTS[group_name].get(variant)
    if mapped is None:
        raise ValueError(f"{group_name[:-1]} {name!r} has unknown variant {variant!r}")
    return mapped


def _resolve_header_footer_slot(
    group_name: str,
    name: str,
    slot: str,
    value: Any,
) -> SemanticContent | None:
    path = f"{group_name}.{name}.content.{slot}"
    try:
        content = parse_authored_semantic_content(_unwrap(value))
        return content if content.items else None
    except ValueError as exc:
        raise ValueError(f"{path}: {exc}") from exc


def _resolve_header_footer_entry(
    group_name: str, name: str, entry: dict
) -> HeaderFooterConfig:
    def _opt(key: str, default: Any = None) -> Any:
        if key not in entry:
            return default
        return _unwrap(entry[key])

    content_entry = _unwrap(entry.get("content", {})) or {}
    if not isinstance(content_entry, dict):
        raise ValueError(
            f"{group_name[:-1]} {name!r} content must be an object, got "
            f"{type(content_entry).__name__}"
        )

    unknown_slots = [
        slot
        for slot in content_entry
        if slot not in _HEADER_FOOTER_SLOTS and not str(slot).startswith("$")
    ]
    if unknown_slots:
        raise ValueError(
            f"{group_name[:-1]} {name!r} content has unknown slots: {unknown_slots}"
        )

    slot_values: dict[str, SemanticContent | None] = {}
    for slot in _HEADER_FOOTER_SLOTS:
        top_level_key = f"content_{slot}"
        has_top_level = top_level_key in entry
        has_nested = slot in content_entry
        if has_top_level and has_nested:
            raise ValueError(
                f"{group_name[:-1]} {name!r} defines both {top_level_key!r} and "
                f"content.{slot!r}"
            )
        if has_top_level:
            slot_values[slot] = _resolve_header_footer_slot(
                group_name, name, slot, entry[top_level_key]
            )
        elif has_nested:
            slot_values[slot] = _resolve_header_footer_slot(
                group_name, name, slot, content_entry[slot]
            )
        else:
            slot_values[slot] = None

    return HeaderFooterConfig(
        name=name,
        style=_resolve_header_footer_style(group_name, name, entry),
        left=slot_values["left"],
        center=slot_values["center"],
        right=slot_values["right"],
        outer=slot_values["outer"],
        inner=slot_values["inner"],
        rule_top=_opt("rule_top", False) or False,
        rule_bottom=_opt("rule_bottom", False) or False,
        align=_opt("align"),
    )


def resolve_headers_and_footers(tokens: dict) -> dict[str, HeaderFooterConfig]:
    """Build a flat registry of header/footer configs.

    The ``headers`` and ``footers`` groups share a single namespace so
    sections can reference either by name.
    """
    registry: dict[str, HeaderFooterConfig] = {}
    for group_name in ("headers", "footers"):
        for name, entry in _iter_entries(tokens.get(group_name, {})):
            registry[name] = _resolve_header_footer_entry(group_name, name, entry)
    return registry


def _resolve_page_number(entry: dict) -> PageNumberConfig:
    pn = entry.get("page_number")
    if not pn:
        return PageNumberConfig()
    fmt = _unwrap(pn.get("format", "decimal")) or "decimal"
    restart = _unwrap(pn.get("restart_at", "continue"))
    visible = bool(_unwrap(pn.get("visible", True)))
    position = _unwrap(pn.get("position", "center_footer")) or "center_footer"
    return PageNumberConfig(
        format=fmt,
        restart_at=restart,
        visible=visible,
        position=position,
    )


def _lookup(
    entry: dict,
    key: str,
    registry: dict,
    section_name: str,
    kind: str,
) -> Any:
    if key not in entry:
        return None
    ref = _unwrap(entry[key])
    if ref is None:
        return None
    if ref not in registry:
        raise ValueError(f"Section {section_name!r} references unknown {kind}: {ref!r}")
    return registry[ref]


def resolve_sections(
    tokens: dict,
    geometries: dict[str, NamedPageGeometry],
    margins: dict[str, NamedMargins],
    header_footer_registry: dict[str, HeaderFooterConfig],
    baseline_pt: float,
) -> list[LongFormSection]:
    """Resolve the ``sections`` group into ordered LongFormSection objects."""
    group = tokens.get("sections", {})
    sections: list[LongFormSection] = []
    for name, entry in _iter_entries(group):
        geom = _lookup(entry, "page_geometry", geometries, name, "page geometry")
        mgn = _lookup(entry, "margins", margins, name, "margins preset")
        if geom is None:
            raise ValueError(f"Section {name!r} missing page_geometry")
        if mgn is None:
            raise ValueError(f"Section {name!r} missing margins")

        columns = int(_unwrap(entry.get("columns", 1)) or 1)
        column_gap_pt = _resolve_pt(entry.get("column_gap", 36), baseline_pt)

        sections.append(
            LongFormSection(
                name=name,
                page_geometry=geom,
                margins=mgn,
                columns=columns,
                column_gap_pt=column_gap_pt,
                page_number=_resolve_page_number(entry),
                header_ref=_lookup(
                    entry, "header_ref", header_footer_registry, name, "header"
                ),
                header_ref_odd=_lookup(
                    entry, "header_ref_odd", header_footer_registry, name, "header"
                ),
                header_ref_even=_lookup(
                    entry, "header_ref_even", header_footer_registry, name, "header"
                ),
                header_ref_first=_lookup(
                    entry, "header_ref_first", header_footer_registry, name, "header"
                ),
                footer_ref=_lookup(
                    entry, "footer_ref", header_footer_registry, name, "footer"
                ),
                footer_ref_odd=_lookup(
                    entry, "footer_ref_odd", header_footer_registry, name, "footer"
                ),
                footer_ref_even=_lookup(
                    entry, "footer_ref_even", header_footer_registry, name, "footer"
                ),
                footer_ref_first=_lookup(
                    entry, "footer_ref_first", header_footer_registry, name, "footer"
                ),
                first_page_different=bool(
                    _unwrap(entry.get("first_page_different", False))
                ),
                odd_even_different=bool(
                    _unwrap(entry.get("odd_even_different", False))
                ),
            )
        )
    return sections


def resolve_long_form(tokens: dict, baseline_pt: float) -> dict[str, Any]:
    """Top-level resolver — runs all four stages and returns a bundle dict.

    ``baseline_pt`` is the baseline grid in pt (typically 12).  Feed it
    from the typography scheme's baseline, converted from whatever unit
    the caller happens to have it in.
    """
    geometries = resolve_page_geometries(tokens)
    margins = resolve_margin_presets(tokens, baseline_pt)
    registry = resolve_headers_and_footers(tokens)
    sections = resolve_sections(tokens, geometries, margins, registry, baseline_pt)
    return {
        "page_geometries": geometries,
        "margin_presets": margins,
        "header_footer_registry": registry,
        "sections": sections,
    }
