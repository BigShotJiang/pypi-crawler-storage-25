"""Formula evaluation for token resolution."""

from __future__ import annotations

import ast
import re
from collections.abc import Mapping
from typing import Any, Callable, Dict

from tokenmoulds.design.units import (
    inches_to_emu,
    pt_to_emu,
    pt_to_hundredths,
    pt_to_twips,
    twips_to_emu,
)
from tokenmoulds.dtcg.errors import FormulaError, FormulaReferenceError
from tokenmoulds.colors.transforms import (
    contrast_color,
    darken,
    desaturate,
    hex_to_hsl,
    hsl_rotate,
    hsl_to_hex,
    lighten,
)
from tokenmoulds.dtcg.formula_functions import (
    alpha_mod,
    bevel,
    complement,
    dash_pattern,
    document_preset,
    font_preset,
    gradient_linear,
    gradient_radial,
    grayscale,
    hue_rotate,
    icon_font_family,
    lum_mod,
    mod_stack,
    reflection,
    sat_mod,
    scene_3d,
    shade,
    shadow,
    soft_edge,
    tint,
)

FormulaFunction = Callable[..., Any]

_NUMERIC_ATTR_RE = re.compile(r"(\]|\b[A-Za-z_][A-Za-z0-9_]*)\.(\d+)")


def _normalize_numeric_attrs(expression: str) -> str:
    """Allow dotted numeric keys by translating to bracket syntax."""
    return _NUMERIC_ATTR_RE.sub(r'\1["\2"]', expression)


def is_formula(value: object) -> bool:
    if not isinstance(value, str):
        return False
    stripped = value.strip()
    return (stripped.startswith("${") and stripped.endswith("}")) or (
        stripped.startswith("{{") and stripped.endswith("}}")
    )


def strip_formula(value: str) -> str:
    stripped = value.strip()
    if stripped.startswith("${") and stripped.endswith("}"):
        return stripped[2:-1].strip()
    if stripped.startswith("{{") and stripped.endswith("}}"):
        return stripped[2:-2].strip()
    return stripped


def scale_by_ratio(base: float, ratio: float, step: int) -> float:
    """Calculate modular scale value: base * (ratio ^ step)."""
    return base * (ratio**step)


class FormulaEvaluator:
    """Safe mathematical expression evaluator for token formulas."""

    def __init__(
        self, extra_functions: Mapping[str, FormulaFunction] | None = None
    ) -> None:
        self.functions: Dict[str, FormulaFunction] = {
            # Math functions
            "round": round,
            "abs": abs,
            "min": min,
            "max": max,
            "sqrt": lambda value: value**0.5,
            "floor": lambda value: int(value // 1),
            "ceil": lambda value: int(-(-value // 1)),
            "int": int,
            # Color functions
            "lighten": lighten,
            "darken": darken,
            "hex_to_hsl": hex_to_hsl,
            "hsl_to_hex": hsl_to_hex,
            "hsl_rotate": hsl_rotate,
            "desaturate": desaturate,
            "contrast_color": contrast_color,
            # Unit conversion functions
            "pt_to_twips": pt_to_twips,
            "twips_to_emu": twips_to_emu,
            "pt_to_emu": pt_to_emu,
            "pt_to_hundredths": pt_to_hundredths,
            "inches_to_emu": inches_to_emu,
            # Typography scale functions
            "scale_by_ratio": scale_by_ratio,
            # Style primitive constructors
            "mod_stack": mod_stack,
            "gradient_linear": gradient_linear,
            "gradient_radial": gradient_radial,
            "dash_pattern": dash_pattern,
            "scene_3d": scene_3d,
            "shadow": shadow,
            "reflection": reflection,
            "soft_edge": soft_edge,
            "bevel": bevel,
            # Modifier step helpers
            "tint": tint,
            "shade": shade,
            "sat_mod": sat_mod,
            "lum_mod": lum_mod,
            "alpha_mod": alpha_mod,
            "complement": complement,
            "grayscale": grayscale,
            # AI-editable design token functions
            "hue_rotate": hue_rotate,
            "document_preset": document_preset,
            "font_preset": font_preset,
            "icon_font_family": icon_font_family,
        }
        if extra_functions:
            self.functions.update(extra_functions)

    def evaluate(self, expression: str, context: Mapping[str, Any]) -> Any:
        expression = _normalize_numeric_attrs(expression)
        try:
            tree = ast.parse(expression, mode="eval")
        except SyntaxError as exc:
            raise FormulaError(f"Invalid formula syntax: {expression}") from exc
        return self._eval_node(tree.body, context)

    def _eval_node(self, node: ast.AST, context: Mapping[str, Any]) -> Any:
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return self._resolve_name(node.id, context)
        if isinstance(node, ast.Attribute):
            base = self._eval_node(node.value, context)
            return self._resolve_attr(base, node.attr)
        if isinstance(node, ast.Subscript):
            base = self._eval_node(node.value, context)
            key = (
                self._eval_node(node.slice, context)
                if not isinstance(node.slice, ast.Slice)
                else None
            )
            if key is None:
                raise FormulaError("Slices are not supported in formulas")
            return self._resolve_subscript(base, key)
        if isinstance(node, ast.BinOp):
            left = self._eval_node(node.left, context)
            right = self._eval_node(node.right, context)
            return self._apply_operator(node.op, left, right)
        if isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand, context)
            return self._apply_unary(node.op, operand)
        if isinstance(node, ast.BoolOp):
            values = [self._eval_node(val, context) for val in node.values]
            if isinstance(node.op, ast.And):
                return all(values)
            if isinstance(node.op, ast.Or):
                return any(values)
            raise FormulaError("Unsupported boolean operator")
        if isinstance(node, ast.Compare):
            left = self._eval_node(node.left, context)
            for op, comparator in zip(node.ops, node.comparators):
                right = self._eval_node(comparator, context)
                if not self._apply_compare(op, left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            test = self._eval_node(node.test, context)
            return (
                self._eval_node(node.body, context)
                if test
                else self._eval_node(node.orelse, context)
            )
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id in self.functions:
                args = [self._eval_node(arg, context) for arg in node.args]
                return self.functions[func.id](*args)
            raise FormulaError("Unsupported function call in formula")
        if isinstance(node, ast.List):
            return [self._eval_node(elt, context) for elt in node.elts]
        if isinstance(node, ast.Tuple):
            return tuple(self._eval_node(elt, context) for elt in node.elts)
        if isinstance(node, ast.Dict):
            return {
                self._eval_node(key, context): self._eval_node(value, context)
                for key, value in zip(node.keys, node.values)
                if key is not None
            }
        raise FormulaError(f"Unsupported formula expression: {ast.dump(node)}")

    def _resolve_name(self, name: str, context: Mapping[str, Any]) -> Any:
        if name in {"True", "False", "None"}:
            return {"True": True, "False": False, "None": None}[name]
        if name not in context:
            raise FormulaReferenceError(f"Unknown token reference: {name}")
        value = context[name]
        if is_formula(value):
            raise FormulaReferenceError(f"Unresolved token reference: {name}")
        return value

    def _resolve_attr(self, base: Any, attr: str) -> Any:
        if isinstance(base, Mapping):
            if attr not in base:
                raise FormulaReferenceError(f"Unknown token reference: {attr}")
            value = base[attr]
            if is_formula(value):
                raise FormulaReferenceError(f"Unresolved token reference: {attr}")
            return value
        if hasattr(base, attr):
            value = getattr(base, attr)
            if is_formula(value):
                raise FormulaReferenceError(f"Unresolved token reference: {attr}")
            return value
        raise FormulaReferenceError(f"Attribute {attr} not found in formula context")

    def _resolve_subscript(self, base: Any, key: Any) -> Any:
        try:
            value = base[key]
        except Exception as exc:
            raise FormulaError(f"Invalid subscript access in formula: {key}") from exc
        if is_formula(value):
            raise FormulaReferenceError(f"Unresolved token reference: {key}")
        return value

    @staticmethod
    def _apply_operator(op: ast.operator, left: Any, right: Any) -> Any:
        if isinstance(op, ast.Add):
            return left + right
        if isinstance(op, ast.Sub):
            return left - right
        if isinstance(op, ast.Mult):
            return left * right
        if isinstance(op, ast.Div):
            return left / right
        if isinstance(op, ast.Mod):
            return left % right
        if isinstance(op, ast.Pow):
            if isinstance(right, (int, float)) and abs(right) > 1000:
                raise FormulaError(
                    f"Exponent too large ({right}); maximum allowed is 1000"
                )
            return left**right
        raise FormulaError("Unsupported operator in formula")

    @staticmethod
    def _apply_unary(op: ast.unaryop, value: Any) -> Any:
        if isinstance(op, ast.UAdd):
            return +value
        if isinstance(op, ast.USub):
            return -value
        raise FormulaError("Unsupported unary operator in formula")

    @staticmethod
    def _apply_compare(op: ast.cmpop, left: Any, right: Any) -> bool:
        if isinstance(op, ast.Eq):
            return left == right
        if isinstance(op, ast.NotEq):
            return left != right
        if isinstance(op, ast.Lt):
            return left < right
        if isinstance(op, ast.LtE):
            return left <= right
        if isinstance(op, ast.Gt):
            return left > right
        if isinstance(op, ast.GtE):
            return left >= right
        raise FormulaError("Unsupported comparison in formula")
