"""Shared color utilities for TokenMoulds.

Lightweight imports (models, parser) are loaded eagerly so that
``from tokenmoulds.colors import parse_color`` always works.

Heavy imports that pull in numpy / Pillow / etc. are loaded lazily on
first attribute access so that the package remains importable even when
optional dependencies are not installed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from tokenmoulds._lazy import lazy_dir, resolve_lazy_attribute

# Lightweight – always available
from .models import Color
from .parser import hex_to_ooxml_argb, hex_to_ooxml_rgb, hex_to_rgb_tuple, parse_color

if TYPE_CHECKING:
    # Let type-checkers see everything without lazy-loading
    from .accessibility import contrast_ratio as contrast_ratio
    from .accessibility import ensure_contrast as ensure_contrast
    from .accessibility import generate_shades as generate_shades
    from .accessibility import generate_tints as generate_tints
    from .analysis import summarize_palette as summarize_palette
    from .colorblind import simulate_palette as simulate_colorblind_palette
    from .palette import ColorVariant as ColorVariant
    from .palette import ThemePalette as ThemePalette
    from .palette import ThemeSlot as ThemeSlot
    from .palette import TransformType as TransformType
    from .palette import generate_palette as generate_palette
    from .service import ColorEngine as ColorEngine
    from .service import ColorNormalization as ColorNormalization
    from .service import ColorNormalizer as ColorNormalizer
    from .service import NormalizedImage as NormalizedImage
    from .spaces import ColorSpaceConverter as ColorSpaceConverter
    from .spaces import ColorSpaceResult as ColorSpaceResult

__all__ = [
    "Color",
    "parse_color",
    "hex_to_ooxml_rgb",
    "hex_to_ooxml_argb",
    "hex_to_rgb_tuple",
    "summarize_palette",
    "ColorNormalizer",
    "ColorNormalization",
    "ColorEngine",
    "NormalizedImage",
    "ColorSpaceConverter",
    "ColorSpaceResult",
    "contrast_ratio",
    "ensure_contrast",
    "generate_tints",
    "generate_shades",
    "simulate_colorblind_palette",
    # Palette generation
    "ThemeSlot",
    "TransformType",
    "ColorVariant",
    "ThemePalette",
    "generate_palette",
]

# Mapping from public name -> (submodule, real attribute name)
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "summarize_palette": (".analysis", "summarize_palette"),
    "ColorNormalizer": (".service", "ColorNormalizer"),
    "ColorNormalization": (".service", "ColorNormalization"),
    "ColorEngine": (".service", "ColorEngine"),
    "NormalizedImage": (".service", "NormalizedImage"),
    "ColorSpaceConverter": (".spaces", "ColorSpaceConverter"),
    "ColorSpaceResult": (".spaces", "ColorSpaceResult"),
    "contrast_ratio": (".accessibility", "contrast_ratio"),
    "ensure_contrast": (".accessibility", "ensure_contrast"),
    "generate_tints": (".accessibility", "generate_tints"),
    "generate_shades": (".accessibility", "generate_shades"),
    "simulate_colorblind_palette": (".colorblind", "simulate_palette"),
    "ThemeSlot": (".palette", "ThemeSlot"),
    "TransformType": (".palette", "TransformType"),
    "ColorVariant": (".palette", "ColorVariant"),
    "ThemePalette": (".palette", "ThemePalette"),
    "generate_palette": (".palette", "generate_palette"),
}


def __getattr__(name: str) -> object:
    return resolve_lazy_attribute(
        name,
        module_globals=globals(),
        package=__package__ or __name__,
        lazy_imports=_LAZY_IMPORTS,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
