"""OKLab/OKLCH conversion helpers (ported from svg2ooxml)."""

from __future__ import annotations

import math
from typing import Tuple

_M1 = (
    (0.4122214708, 0.5363325363, 0.0514459929),
    (0.2119034982, 0.6806995451, 0.1073969566),
    (0.0883024619, 0.2817188376, 0.6299787005),
)
_M2 = (
    (0.2104542553, 0.7936177850, -0.0040720468),
    (1.9779984951, -2.4285922050, 0.4505937099),
    (0.0259040371, 0.7827717662, -0.8086757660),
)
_M1_INV = (
    (4.0767416621, -3.3077115913, 0.2309699292),
    (-1.2684380046, 2.6097574011, -0.3413193965),
    (-0.0041960863, -0.7034186147, 1.7076147010),
)
_M2_INV = (
    (1.0000000000, 0.3963377774, 0.2158037573),
    (1.0000000000, -0.1055613458, -0.0638541728),
    (1.0000000000, -0.0894841775, -1.2914855480),
)


def rgb_to_oklab(r: float, g: float, b: float) -> Tuple[float, float, float]:
    rl = _srgb_to_linear(r)
    gl = _srgb_to_linear(g)
    bl = _srgb_to_linear(b)

    l = _M1[0][0] * rl + _M1[0][1] * gl + _M1[0][2] * bl
    m = _M1[1][0] * rl + _M1[1][1] * gl + _M1[1][2] * bl
    s = _M1[2][0] * rl + _M1[2][1] * gl + _M1[2][2] * bl

    l_, m_, s_ = l ** (1 / 3), m ** (1 / 3), s ** (1 / 3)
    return (
        _M2[0][0] * l_ + _M2[0][1] * m_ + _M2[0][2] * s_,
        _M2[1][0] * l_ + _M2[1][1] * m_ + _M2[1][2] * s_,
        _M2[2][0] * l_ + _M2[2][1] * m_ + _M2[2][2] * s_,
    )


def oklab_to_rgb(l: float, a: float, b: float) -> Tuple[float, float, float]:
    l_ = l + 0.3963377774 * a + 0.2158037573 * b
    m_ = l - 0.1055613458 * a - 0.0638541728 * b
    s_ = l - 0.0894841775 * a - 1.2914855480 * b

    l3 = l_**3
    m3 = m_**3
    s3 = s_**3

    rl = _M1_INV[0][0] * l3 + _M1_INV[0][1] * m3 + _M1_INV[0][2] * s3
    gl = _M1_INV[1][0] * l3 + _M1_INV[1][1] * m3 + _M1_INV[1][2] * s3
    bl = _M1_INV[2][0] * l3 + _M1_INV[2][1] * m3 + _M1_INV[2][2] * s3

    r = _linear_to_srgb(rl)
    g = _linear_to_srgb(gl)
    b = _linear_to_srgb(bl)
    return (r, g, b)


def rgb_to_oklch(r: float, g: float, b: float) -> Tuple[float, float, float]:
    l, a, b_val = rgb_to_oklab(r, g, b)
    c = math.sqrt(a * a + b_val * b_val)
    h = math.degrees(math.atan2(b_val, a)) % 360.0
    return (l, c, h)


def oklch_to_rgb(l: float, c: float, h: float) -> Tuple[float, float, float]:
    rad = math.radians(h)
    a = c * math.cos(rad)
    b = c * math.sin(rad)
    return oklab_to_rgb(l, a, b)


def _linear_to_srgb(value: float) -> float:
    if value <= 0.0031308:
        return max(0.0, min(1.0, 12.92 * value))
    return max(0.0, min(1.0, 1.055 * value ** (1 / 2.4) - 0.055))


def _srgb_to_linear(value: float) -> float:
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


__all__ = [
    "rgb_to_oklab",
    "oklab_to_rgb",
    "rgb_to_oklch",
    "oklch_to_rgb",
]
