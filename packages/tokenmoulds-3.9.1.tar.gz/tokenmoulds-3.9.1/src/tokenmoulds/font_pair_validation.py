"""Validation helpers for font-pair catalogs."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tokenmoulds.font_pairs.catalog import FontPairDiagnostic, load_font_pair_catalog
from tokenmoulds.font_pairs.audit import FontAssetAudit, audit_font_face
from tokenmoulds.fonts.service import build_font_service


@dataclass(frozen=True, slots=True)
class FontFamilyValidation:
    """Validation state for one font family role."""

    role: str
    family: str
    regular: str | None
    bold: str | None
    assets: tuple[FontAssetAudit, ...] = ()

    @property
    def errors(self) -> tuple[str, ...]:
        return tuple(error for asset in self.assets for error in asset.errors)

    @property
    def warnings(self) -> tuple[str, ...]:
        return tuple(warning for asset in self.assets for warning in asset.warnings)

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "family": self.family,
            "regular": self.regular,
            "bold": self.bold,
            "assets": [asset.to_dict() for asset in self.assets],
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True, slots=True)
class FontPairValidation:
    """Validation state for one font-pair alias."""

    alias: str
    families: tuple[FontFamilyValidation, ...]
    diagnostics: tuple[FontPairDiagnostic, ...] = ()

    @property
    def errors(self) -> tuple[str, ...]:
        diagnostic_errors = tuple(
            diagnostic.message
            for diagnostic in self.diagnostics
            if diagnostic.severity == "error"
        )
        family_errors = tuple(
            error for family in self.families for error in family.errors
        )
        return diagnostic_errors + family_errors

    @property
    def warnings(self) -> tuple[str, ...]:
        diagnostic_warnings = tuple(
            diagnostic.message
            for diagnostic in self.diagnostics
            if diagnostic.severity == "warning"
        )
        family_warnings = tuple(
            warning for family in self.families for warning in family.warnings
        )
        return diagnostic_warnings + family_warnings

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "alias": self.alias,
            "ok": self.ok,
            "families": [family.to_dict() for family in self.families],
            "diagnostics": [diagnostic.to_dict() for diagnostic in self.diagnostics],
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


def validate_font_pair_catalog(
    catalog_dir: str | Path,
    *,
    fonts_dir: str | Path | None = "data/fonts/vendored",
    check_downloads: bool = False,
    include_system: bool = False,
) -> list[FontPairValidation]:
    """Validate catalog font families against configured font providers."""
    catalog = load_font_pair_catalog(catalog_dir)
    if catalog.diagnostics and not catalog.records:
        return [
            FontPairValidation(
                alias=str(catalog_dir),
                families=(),
                diagnostics=catalog.diagnostics,
            )
        ]

    service = build_font_service(
        Path(fonts_dir) if fonts_dir else None,
        enable_downloads=check_downloads,
        include_system=include_system,
    )

    results: list[FontPairValidation] = []
    for record in sorted(catalog.records, key=lambda item: item.id):
        families: list[FontFamilyValidation] = []
        for role, role_record in (
            ("heading", record.heading),
            ("body", record.body),
            ("mono", record.mono),
        ):
            family = role_record.family.strip() if role_record else ""
            if not family:
                continue
            regular_asset = audit_font_face(
                service,
                role=role,
                family=family,
                weight=400,
                required=True,
            )
            bold_asset = audit_font_face(
                service,
                role=role,
                family=family,
                weight=700,
                required=False,
            )
            families.append(
                FontFamilyValidation(
                    role=role,
                    family=family,
                    regular=regular_asset.path,
                    bold=bold_asset.path,
                    assets=(regular_asset, bold_asset),
                )
            )
        results.append(
            FontPairValidation(
                alias=record.id,
                families=tuple(families),
                diagnostics=record.diagnostics,
            )
        )

    if catalog.diagnostics:
        results.append(
            FontPairValidation(
                alias=str(catalog_dir),
                families=(),
                diagnostics=catalog.diagnostics,
            )
        )

    return results


def font_pair_validation_summary(
    results: list[FontPairValidation],
) -> dict[str, int]:
    """Summarize font-pair validation results for CLI/CI output."""
    return {
        "pairs": len(results),
        "ok": sum(1 for result in results if result.ok),
        "errors": sum(len(result.errors) for result in results),
        "warnings": sum(len(result.warnings) for result in results),
    }


def font_pair_validation_payload(
    results: list[FontPairValidation],
) -> dict[str, Any]:
    """Return machine-readable validation payload."""
    return {
        "summary": font_pair_validation_summary(results),
        "results": [result.to_dict() for result in results],
    }


def font_pair_validation_exit_code(
    results: list[FontPairValidation],
    *,
    strict: bool = False,
) -> int:
    """Return process exit code for validation results."""
    summary = font_pair_validation_summary(results)
    if summary["errors"]:
        return 1
    if strict and summary["warnings"]:
        return 1
    return 0


def format_font_pair_validation_text(
    results: list[FontPairValidation],
) -> str:
    """Format human-readable validation output."""
    summary = font_pair_validation_summary(results)
    lines = [
        (
            "Font-pair validation: "
            f"{summary['pairs']} checked, "
            f"{summary['errors']} errors, "
            f"{summary['warnings']} warnings"
        )
    ]
    if not results:
        lines.append("No font pairs found")

    for result in results:
        status = "ok" if result.ok else "error"
        lines.append(f"{status}: {result.alias}")
        for family in result.families:
            lines.append(f"  {family.role}: {family.family}")
            for asset in family.assets:
                provider = asset.provider or "missing"
                face = "bold" if asset.requested_weight >= 700 else "regular"
                path = asset.path or "unresolved"
                lines.append(f"    {face}: {provider} {path}")
        for warning in result.warnings:
            lines.append(f"  warning: {warning}")
        for error in result.errors:
            lines.append(f"  error: {error}")

    return "\n".join(lines)
