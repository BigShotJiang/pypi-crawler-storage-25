"""Asset accumulation and snapshot for package building.

Borrowed from svg2ooxml's AssetRegistry pattern:
- Mutable accumulator during rendering (list-based)
- Frozen snapshot for downstream packaging (tuple-based)
- Typed per-asset-kind methods
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class FontAsset:
    """A font to be embedded in a document package."""

    family_name: str
    font_path: Path
    relationship_id: str
    is_bold: bool = False
    is_italic: bool = False

    # Word-specific (ODTTF)
    font_key: str = ""
    odttf_filename: str = ""

    # PowerPoint-specific (EOT/fntdata)
    fntdata_filename: str = ""


@dataclass(frozen=True, slots=True)
class MediaAsset:
    """A media resource (image, icon, etc.) to embed in a package."""

    archive_path: str
    data: bytes
    content_type: str
    source: str = ""


@dataclass(frozen=True, slots=True)
class AssetSnapshot:
    """Immutable view of all collected assets.

    Consumed by PackageWriter and emitter _build_font_entries().
    """

    fonts: tuple[FontAsset, ...] = ()
    media: tuple[MediaAsset, ...] = ()


class AssetRegistry:
    """Mutable accumulator for assets collected during rendering.

    Usage:
        registry = AssetRegistry()
        registry.add_font(FontAsset(...))
        registry.add_media(MediaAsset(...))
        snapshot = registry.snapshot()
    """

    def __init__(self) -> None:
        self._fonts: list[FontAsset] = []
        self._media: list[MediaAsset] = []

    def add_font(self, font: FontAsset) -> None:
        """Register a font asset for embedding."""
        self._fonts.append(font)

    def add_media(self, media: MediaAsset) -> None:
        """Register a media asset for embedding."""
        self._media.append(media)

    @property
    def fonts(self) -> tuple[FontAsset, ...]:
        """Current fonts (read-only view)."""
        return tuple(self._fonts)

    @property
    def media(self) -> tuple[MediaAsset, ...]:
        """Current media (read-only view)."""
        return tuple(self._media)

    def snapshot(self) -> AssetSnapshot:
        """Return a frozen view of all collected assets."""
        return AssetSnapshot(
            fonts=tuple(self._fonts),
            media=tuple(self._media),
        )

    def clear(self) -> None:
        """Remove all collected assets."""
        self._fonts.clear()
        self._media.clear()
