"""Shared dataclasses for document packaging.

These types describe package parts declaratively. They carry no I/O logic
and can be used across OOXML, ODF, and future formats.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class CompressionMode(Enum):
    """ZIP compression mode for a package entry."""

    DEFLATED = "deflated"
    STORED = "stored"


@dataclass(frozen=True, slots=True)
class PackagedEntry:
    """A single entry to be written into a ZIP package.

    Lowest-level unit: an archive path and its byte content,
    plus compression preference.
    """

    archive_path: str
    data: bytes
    compression: CompressionMode = CompressionMode.DEFLATED
