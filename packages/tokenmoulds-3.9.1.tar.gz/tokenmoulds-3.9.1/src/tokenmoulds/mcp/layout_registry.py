"""Unified layout registry for MCP tool discovery.

Merges three layout sources into one lookup:
- Standard PPTX layouts from ``layout_recipe_resolver.PPTX_PLACEHOLDER_MAP``
- Semantic layouts from ``layout_recipe_resolver.SEMANTIC_LAYOUT_SPECS``
- DSL archetypes from ``archetypes.catalog.ARCHETYPE_REGISTRY``

The curated set (~35 layouts) is what AI agents see via ``list_layouts``.
Extended standard duplicates (12-37) are excluded from the curated set
since they're for manual gallery browsing, not AI selection.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class LayoutInfo:
    """Metadata about a slide layout for AI agent discovery."""

    name: str
    display_name: str
    family: str
    slots: tuple[str, ...]
    description: str


# Incidental slots present on every layout (AI doesn't fill these)
_INCIDENTAL_SLOTS = frozenset({"date", "footer", "slide_num"})

# Display names for standard layouts
_STANDARD_DISPLAY_NAMES: dict[str, str] = {
    "title_slide": "Title Slide",
    "title_content": "Title and Content",
    "section_header": "Section Header",
    "two_content": "Two Content",
    "comparison": "Comparison",
    "title_only": "Title Only",
    "blank": "Blank",
    "content_caption": "Content with Caption",
    "picture_caption": "Picture with Caption",
    "vertical_text": "Vertical Text",
    "vertical_title": "Vertical Title and Text",
}

# Descriptions for standard layouts
_STANDARD_DESCRIPTIONS: dict[str, str] = {
    "title_slide": "Centered title and subtitle for opening slides",
    "title_content": "Title with a single content area below",
    "section_header": "Section divider with title and body text",
    "two_content": "Title with two side-by-side content areas",
    "comparison": "Title with two labeled content columns for comparison",
    "title_only": "Title placeholder only, rest is open canvas",
    "blank": "Empty slide with only incidental placeholders",
    "content_caption": "Title with content area and caption sidebar",
    "picture_caption": "Title with picture area and caption sidebar",
    "vertical_text": "Title with vertical text content area",
    "vertical_title": "Vertical title with horizontal body text",
}


def _build_registry() -> dict[str, LayoutInfo]:
    """Build the unified layout registry from all sources."""
    from tokenmoulds.dtcg.layout_recipe_catalog import (
        PPTX_PLACEHOLDER_MAP,
        SEMANTIC_LAYOUT_SPECS,
    )

    registry: dict[str, LayoutInfo] = {}

    # 1. Standard PPTX layouts (core 11 only)
    for layout_name, ph_map in PPTX_PLACEHOLDER_MAP.items():
        if layout_name not in _STANDARD_DISPLAY_NAMES:
            continue
        slots = tuple(name for name in ph_map if name not in _INCIDENTAL_SLOTS)
        registry[layout_name] = LayoutInfo(
            name=layout_name,
            display_name=_STANDARD_DISPLAY_NAMES[layout_name],
            family="core",
            slots=slots,
            description=_STANDARD_DESCRIPTIONS.get(layout_name, ""),
        )

    # 2. Semantic layouts
    for spec in SEMANTIC_LAYOUT_SPECS.values():
        slots = tuple(
            name for name in spec.placeholder_map if name not in _INCIDENTAL_SLOTS
        )
        registry[spec.name] = LayoutInfo(
            name=spec.name,
            display_name=spec.display_name,
            family="semantic",
            slots=slots,
            description=f"Semantic {spec.display_name.lower()} with decorative regions",
        )

    # 3. DSL archetypes (consulting + general families)
    # Only expose slots that are real placeholders (ph_type or ph_idx set).
    # Named decorative shapes are part of the layout, not fillable from slides.
    try:
        from tokenmoulds.archetypes.catalog import LAYOUT_FAMILIES

        for family in LAYOUT_FAMILIES.values():
            for archetype in family.archetypes:
                if archetype.name in registry:
                    continue
                fillable_slots: list[str] = []
                for shape in archetype.shapes:
                    region = getattr(shape, "region", None)
                    if region is None or region in _INCIDENTAL_SLOTS:
                        continue
                    ph_type = getattr(shape, "ph_type", None)
                    ph_idx = getattr(shape, "ph_idx", None)
                    if ph_type is not None or ph_idx is not None:
                        fillable_slots.append(region)
                registry[archetype.name] = LayoutInfo(
                    name=archetype.name,
                    display_name=archetype.display_name,
                    family=family.name,
                    slots=tuple(fillable_slots),
                    description=archetype.extra_context.get(
                        "SLIDE_TITLE", archetype.display_name
                    ),
                )
    except ImportError:
        pass

    # Clear module-level cache so tests get the updated version
    return registry


# Module-level singleton
_REGISTRY: dict[str, LayoutInfo] | None = None


def get_layout_registry() -> dict[str, LayoutInfo]:
    """Return the unified layout registry (cached)."""
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _build_registry()
    return _REGISTRY


def get_layout_info(layout_name: str) -> LayoutInfo | None:
    """Look up a single layout by name."""
    return get_layout_registry().get(layout_name)


def list_layouts(
    family: str | None = None,
) -> Sequence[LayoutInfo]:
    """Return curated layouts, optionally filtered by family."""
    registry = get_layout_registry()
    layouts = list(registry.values())
    if family:
        layouts = [l for l in layouts if l.family == family]
    return sorted(layouts, key=lambda l: (l.family, l.name))


def get_layout_names() -> tuple[str, ...]:
    """Return all curated layout names for schema enums."""
    return tuple(sorted(get_layout_registry().keys()))
