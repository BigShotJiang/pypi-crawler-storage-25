"""TokenMoulds MCP Server.

Model Context Protocol server for AI-powered document generation.
Enables AI agents to generate professionally styled Office documents
using TokenMoulds' design token system.

Import of the actual server module is deferred so
``tokenmoulds.mcp.tools.*`` can be used without the optional ``mcp``
runtime dependency installed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from tokenmoulds._lazy import resolve_lazy_attribute

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import create_server, run_server

__all__ = ["create_server", "run_server"]

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "create_server": (".server", "create_server"),
    "run_server": (".server", "run_server"),
}


def __getattr__(name: str) -> Any:
    return resolve_lazy_attribute(
        name,
        module_globals=globals(),
        package=__package__ or __name__,
        lazy_imports=_LAZY_IMPORTS,
    )
