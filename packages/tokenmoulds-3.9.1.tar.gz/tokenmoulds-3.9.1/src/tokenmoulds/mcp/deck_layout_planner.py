"""Layout decision path for deck generation.

This module keeps slide planning away from blank-canvas drawing.  A content
adapter asks for slots; the planner either selects an existing layout whose
placeholders cover those slots, or records that a new cloned layout is needed.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Sequence

from tokenmoulds.mcp.layout_registry import LayoutInfo, get_layout_info, list_layouts


@dataclass(frozen=True)
class LayoutDecision:
    """Auditable layout-planning result for a slide."""

    layout_name: str
    strategy: str
    reason: str
    required_slots: tuple[str, ...]
    matched_slots: tuple[str, ...]
    missing_slots: tuple[str, ...]
    extra_layout_slots: tuple[str, ...]
    clone_source: str | None = None
    clone_name: str | None = None

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-serializable representation."""
        return asdict(self)


def decide_layout(
    required_slots: Sequence[str],
    *,
    preferred_layouts: Sequence[str] = (),
    fallback_layout: str = "title_content",
    clone_source: str | None = None,
    clone_name: str | None = None,
) -> LayoutDecision:
    """Choose a layout or record that a clone is required.

    The decision path is:

    1. Try preferred layouts in order.
    2. Try any curated layout that covers all required slots.
    3. Fail closed with a clone-required decision, using ``fallback_layout``
       only as an emission-safe placeholder until the cloned layout exists.
    """
    required = tuple(dict.fromkeys(slot for slot in required_slots if slot))

    for layout_name in preferred_layouts:
        info = get_layout_info(layout_name)
        if info is not None and _covers(info, required):
            return _decision(
                info,
                required,
                strategy="reuse_existing",
                reason="preferred layout covers all required slots",
            )

    candidates = [info for info in list_layouts() if _covers(info, required)]
    if candidates:
        info = min(
            candidates,
            key=lambda candidate: (
                _family_rank(candidate.family),
                len(candidate.slots),
                candidate.name,
            ),
        )
        return _decision(
            info,
            required,
            strategy="inherit_existing",
            reason="selected closest curated layout that covers required slots",
        )

    fallback = get_layout_info(fallback_layout)
    if fallback is None:
        raise ValueError(f"Unknown fallback layout: {fallback_layout!r}")

    source = clone_source or _best_clone_source(required) or fallback.name
    missing = tuple(slot for slot in required if slot not in fallback.slots)
    return LayoutDecision(
        layout_name=fallback.name,
        strategy="clone_required",
        reason="no curated layout covers all required slots",
        required_slots=required,
        matched_slots=tuple(slot for slot in required if slot in fallback.slots),
        missing_slots=missing,
        extra_layout_slots=tuple(
            slot for slot in fallback.slots if slot not in required
        ),
        clone_source=source,
        clone_name=clone_name or _clone_name(source, required),
    )


def _decision(
    info: LayoutInfo,
    required: tuple[str, ...],
    *,
    strategy: str,
    reason: str,
) -> LayoutDecision:
    return LayoutDecision(
        layout_name=info.name,
        strategy=strategy,
        reason=reason,
        required_slots=required,
        matched_slots=tuple(slot for slot in required if slot in info.slots),
        missing_slots=tuple(slot for slot in required if slot not in info.slots),
        extra_layout_slots=tuple(slot for slot in info.slots if slot not in required),
    )


def _covers(info: LayoutInfo, required: tuple[str, ...]) -> bool:
    return set(required).issubset(set(info.slots))


def _family_rank(family: str) -> int:
    return {"semantic": 0, "consulting": 1, "general": 2, "core": 3}.get(family, 9)


def _best_clone_source(required: tuple[str, ...]) -> str | None:
    best: tuple[int, int, str] | None = None
    for info in list_layouts():
        overlap = len(set(required).intersection(info.slots))
        if overlap == 0:
            continue
        score = (overlap, -len(info.slots), info.name)
        if best is None or score > best:
            best = score
    return best[2] if best is not None else None


def _clone_name(source: str, required: tuple[str, ...]) -> str:
    signature = "_".join(slot for slot in required if slot != "title") or "content"
    return f"{source}_clone_for_{signature}"
