"""Validation, cache, and discovery helpers for the TokenMoulds MCP server.

Free functions taking the concrete ``TokenMouldsServer`` as their first
argument.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict

from tokenmoulds.mcp.validation import validate_template as do_validate_template

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


async def validate_template(
    server: TokenMouldsServer, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """Validate a template file."""
    del server  # validation is a pure function on the file path
    file_path = arguments.get("file_path")
    if not file_path:
        return {"error": "Missing required 'file_path' parameter"}

    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    try:
        template_data = path.read_bytes()
        strict = arguments.get("strict_mode", True)
        extract = arguments.get("extract_structure", False)

        result = do_validate_template(
            template_data,
            strict_mode=strict,
            extract_structure=extract,
        )

        return {
            "success": True,
            "action": "validate_template",
            "file_path": file_path,
            "valid": result.valid,
            "format": result.format,
            "iso_compliant": result.iso_compliant,
            "errors": result.errors if result.errors else None,
            "warnings": result.warnings if result.warnings else None,
            "info": result.info if result.info else None,
            "structure": result.structure if extract else None,
        }

    except Exception as e:
        return {"error": f"Validation failed: {str(e)}"}


async def clear_cache(
    server: TokenMouldsServer, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """Clear template cache."""
    brand = arguments.get("brand")

    if brand:
        cleared = server.cache_manager.invalidate(brand)
        return {
            "success": True,
            "action": "clear_template_cache",
            "brand": brand,
            "cleared": cleared,
            "message": (
                f"Cache cleared for brand '{brand}'"
                if cleared
                else f"No cache found for brand '{brand}'"
            ),
        }
    else:
        count = server.cache_manager.clear()
        return {
            "success": True,
            "action": "clear_template_cache",
            "brands_cleared": count,
            "message": f"Cleared cache for {count} brands",
        }


async def list_cache(
    server: TokenMouldsServer, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """List cached templates."""
    brand = arguments.get("brand")

    if brand:
        info = server.cache_manager.get_brand_info(brand)
        if info:
            return {
                "success": True,
                "action": "list_cached_templates",
                "brand": brand,
                "cache_info": info,
            }
        else:
            return {
                "success": True,
                "action": "list_cached_templates",
                "brand": brand,
                "message": f"No cache found for brand '{brand}'",
            }
    else:
        cache_info = server.cache_manager.get_cache_info()
        brands = server.cache_manager.list_brands()

        brands_detail = {}
        for b in brands:
            brands_detail[b] = server.cache_manager.get_brand_info(b)

        return {
            "success": True,
            "action": "list_cached_templates",
            "cache_summary": cache_info,
            "brands": brands_detail,
        }


async def list_layouts(
    server: TokenMouldsServer, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """List available slide layouts."""
    del server
    from tokenmoulds.mcp.layout_registry import list_layouts as registry_list_layouts

    family = arguments.get("family")
    layouts = registry_list_layouts(family=family)
    return {
        "success": True,
        "action": "list_layouts",
        "count": len(layouts),
        "layouts": [
            {
                "name": l.name,
                "display_name": l.display_name,
                "family": l.family,
                "slots": list(l.slots),
                "description": l.description,
            }
            for l in layouts
        ],
    }


async def list_styles(
    server: TokenMouldsServer, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """List available document styles."""
    del server
    type_filter = arguments.get("type_filter")
    styles = [
        {
            "style_id": "Title",
            "name": "Document Title",
            "type": "heading",
            "description": "Main document title",
        },
        {
            "style_id": "Subtitle",
            "name": "Document Subtitle",
            "type": "heading",
            "description": "Document subtitle or tagline",
        },
        {
            "style_id": "Heading1",
            "name": "Heading 1",
            "type": "heading",
            "description": "Top-level section heading",
        },
        {
            "style_id": "Heading2",
            "name": "Heading 2",
            "type": "heading",
            "description": "Subsection heading",
        },
        {
            "style_id": "Heading3",
            "name": "Heading 3",
            "type": "heading",
            "description": "Sub-subsection heading",
        },
        {
            "style_id": "Heading4",
            "name": "Heading 4",
            "type": "heading",
            "description": "Fourth-level heading",
        },
        {
            "style_id": "BodyText",
            "name": "Body Text",
            "type": "paragraph",
            "description": "Standard running prose",
        },
        {
            "style_id": "NoSpacing",
            "name": "No Spacing",
            "type": "paragraph",
            "description": "Compact paragraph with no extra spacing",
        },
        {
            "style_id": "ListBullet",
            "name": "Bullet List",
            "type": "list",
            "description": "Unordered bullet list item",
        },
        {
            "style_id": "ListNumber",
            "name": "Numbered List",
            "type": "list",
            "description": "Ordered numbered list item",
        },
        {
            "style_id": "Quote",
            "name": "Block Quote",
            "type": "paragraph",
            "description": "Indented block quotation",
        },
        {
            "style_id": "IntenseQuote",
            "name": "Pull Quote",
            "type": "paragraph",
            "description": "Prominent pull quote with accent styling",
        },
        {
            "style_id": "Caption",
            "name": "Caption",
            "type": "paragraph",
            "description": "Figure or table caption",
        },
        {
            "style_id": "SourceCode",
            "name": "Source Code",
            "type": "code",
            "description": "Monospaced code snippet",
        },
        {
            "style_id": "TableGrid",
            "name": "Table",
            "type": "table",
            "description": "Themed data table with grid lines",
        },
        {
            "style_id": "SubtleReference",
            "name": "Citation",
            "type": "inline",
            "description": "Subtle inline reference or citation",
        },
    ]
    if type_filter:
        styles = [s for s in styles if s["type"] == type_filter]
    return {
        "success": True,
        "action": "list_styles",
        "count": len(styles),
        "styles": styles,
    }
