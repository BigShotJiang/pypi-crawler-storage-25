"""ArtifactPlan model for MCP document compiler workflows."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, cast

from tokenmoulds.artifact_intent import (
    ARTIFACT_STATUSES,
    ARTIFACT_TYPES,
    REVIEW_STATES,
    ArtifactStatus,
    ArtifactType,
    ReviewState,
    canonical_json,
)

ARTIFACT_KINDS: tuple[str, ...] = (
    "auto",
    "deck",
    "document",
    "workbook",
    "template_bundle",
)
SECTION_PRIORITIES: tuple[str, ...] = ("required", "recommended", "optional")
SUPPORTED_OUTPUT_FORMATS: tuple[str, ...] = (
    "docx",
    "dotx",
    "pptx",
    "potx",
    "xlsx",
    "xltx",
    "odt",
    "ott",
    "odp",
    "otp",
    "ods",
    "ots",
    "odg",
    "otg",
    "thmx",
)
DEFAULT_REQUIRED_CHECKS: tuple[str, ...] = (
    "schema_validation",
    "package_validation",
    "artifact_intent",
    "render_validation",
    "office_oracle_review",
)

_MAX_TEXT_LENGTH = 512
_MAX_SHORT_TEXT_LENGTH = 256
_MAX_SECTIONS = 64
_UNSAFE_KEY_RE = re.compile(
    r"(raw_?prompt|chat_?history|conversation|password|secret|api_?key|credential)",
    re.IGNORECASE,
)
_SECRET_VALUE_RE = re.compile(
    r"(sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9_]{16,}|"
    r"xox[baprs]-[A-Za-z0-9-]{16,})"
)


class ArtifactPlanError(ValueError):
    """Raised when an artifact plan is unsafe or malformed."""


@dataclass(frozen=True)
class ArtifactPlanSection:
    """Semantic section requested by an LLM plan."""

    title: str
    purpose: str | None = None
    evidence: str | None = None
    priority: str = "recommended"

    def to_dict(self) -> dict[str, str]:
        payload = {"title": self.title, "priority": self.priority}
        if self.purpose:
            payload["purpose"] = self.purpose
        if self.evidence:
            payload["evidence"] = self.evidence
        return payload


@dataclass(frozen=True)
class ArtifactPlan:
    """Typed pre-compilation planning object produced through MCP."""

    artifact_id: str
    title: str
    intent_summary: str
    artifact_type: ArtifactType = "report"
    artifact_kind: str = "document"
    audience: str | None = None
    source_summary: str | None = None
    brand_name: str | None = None
    repository: str | None = None
    ref: str | None = None
    output_formats: tuple[str, ...] = ("docx",)
    sections: tuple[ArtifactPlanSection, ...] = ()
    required_checks: tuple[str, ...] = DEFAULT_REQUIRED_CHECKS
    status: ArtifactStatus = "draft"
    review_state: ReviewState = "draft"
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        _validate_plan(self)

    def to_dict(self, *, include_hash: bool = True) -> dict[str, Any]:
        """Return a normalized JSON-compatible representation."""
        payload: dict[str, Any] = {
            "artifact_id": self.artifact_id,
            "title": self.title,
            "intent_summary": self.intent_summary,
            "artifact_type": self.artifact_type,
            "artifact_kind": self.artifact_kind,
            "audience": self.audience,
            "source_summary": self.source_summary,
            "brand_name": self.brand_name,
            "repository": self.repository,
            "ref": self.ref,
            "output_formats": list(self.output_formats),
            "sections": [section.to_dict() for section in self.sections],
            "required_checks": list(self.required_checks),
            "status": self.status,
            "review_state": self.review_state,
            "warnings": list(self.warnings),
            "next_tools": next_tools_for_formats(self.output_formats),
        }
        if include_hash:
            payload["plan_sha256"] = self.sha256()
            payload["source_sha256"] = self.source_sha256()
        return payload

    def canonical_json(self) -> str:
        """Serialize without the self-referential hash field."""
        return canonical_json(self.to_dict(include_hash=False))

    def sha256(self) -> str:
        """Return the SHA-256 hash of the canonical plan payload."""
        return hashlib.sha256(self.canonical_json().encode("utf-8")).hexdigest()

    def source_sha256(self) -> str:
        """Return a hash of source descriptors referenced by the plan."""
        payload = {
            "source_summary": self.source_summary,
            "repository": self.repository,
            "ref": self.ref,
            "sections": [
                {
                    "title": section.title,
                    "evidence": section.evidence,
                }
                for section in self.sections
            ],
        }
        return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def artifact_plan_from_mapping(payload: Mapping[str, Any]) -> ArtifactPlan:
    """Build an :class:`ArtifactPlan` from a JSON-like mapping."""
    _validate_safe_mapping(payload, path="plan")
    sections = tuple(_section_from_mapping(item) for item in _list(payload, "sections"))
    output_formats = tuple(_normalize_formats(payload.get("output_formats")))
    required_checks = tuple(_normalize_string_list(payload.get("required_checks")))
    warnings = tuple(_normalize_string_list(payload.get("warnings"), lower=False))
    return ArtifactPlan(
        artifact_id=_required_text(payload, "artifact_id"),
        title=_required_text(payload, "title"),
        intent_summary=_required_text(payload, "intent_summary"),
        artifact_type=_artifact_type(payload.get("artifact_type", "report")),
        artifact_kind=str(payload.get("artifact_kind") or "document"),
        audience=_optional_text(payload.get("audience")),
        source_summary=_optional_text(payload.get("source_summary"), long=True),
        brand_name=_optional_text(payload.get("brand_name")),
        repository=_optional_text(payload.get("repository")),
        ref=_optional_text(payload.get("ref")),
        output_formats=output_formats or ("docx",),
        sections=sections,
        required_checks=required_checks or DEFAULT_REQUIRED_CHECKS,
        status=_artifact_status(payload.get("status", "draft")),
        review_state=_review_state(payload.get("review_state", "draft")),
        warnings=warnings,
    )


def persist_artifact_plan(plan: ArtifactPlan, output_root: Path) -> Path:
    """Persist a plan below ``generated/plans/<artifact_id>/plan.json``."""
    plan_path = artifact_plan_path(output_root, plan.artifact_id)
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(json.dumps(plan.to_dict(), indent=2), encoding="utf-8")
    return plan_path


def load_artifact_plan(output_root: Path, artifact_id: str) -> ArtifactPlan:
    """Load a persisted artifact plan by artifact ID."""
    path = artifact_plan_path(output_root, artifact_id)
    if not path.exists():
        raise ArtifactPlanError(f"Artifact plan not found: {path}")
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, Mapping):
        raise ArtifactPlanError(f"Artifact plan must be a JSON object: {path}")
    return artifact_plan_from_mapping(payload)


def artifact_plan_path(output_root: Path, artifact_id: str) -> Path:
    """Return the canonical persisted plan path."""
    safe_id = safe_artifact_id(artifact_id)
    return Path(output_root) / "plans" / safe_id / "plan.json"


def safe_artifact_id(value: str) -> str:
    """Normalize an artifact identifier for files and MCP state keys."""
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug[:80] or "artifact"


def warnings_for_plan(plan: ArtifactPlan) -> tuple[str, ...]:
    """Return non-fatal planning diagnostics."""
    warnings = list(plan.warnings)
    if not plan.audience:
        warnings.append("audience is missing")
    for section in plan.sections:
        if section.priority == "required" and not section.evidence:
            warnings.append(f"required section lacks evidence: {section.title}")
    return tuple(dict.fromkeys(warnings))


def next_tools_for_formats(formats: tuple[str, ...]) -> list[str]:
    """Return recommended MCP tools for compiling the requested formats."""
    tools: list[str] = []
    if any(fmt in formats for fmt in ("pptx", "odp")):
        tools.append("create_powerpoint_document")
    if any(fmt in formats for fmt in ("docx", "odt")):
        tools.append("create_word_document")
    if any(fmt in formats for fmt in ("xlsx", "ods")):
        tools.append("create_excel_document")
    if any(fmt in formats for fmt in _TEMPLATE_FORMATS):
        tools.append("generate_all_templates")
    tools.extend(["validate_artifact_plan", "validate_template"])
    return list(dict.fromkeys(tools))


def _validate_plan(plan: ArtifactPlan) -> None:
    _check_text(plan.artifact_id, "artifact_id")
    _check_text(plan.title, "title")
    _check_text(plan.intent_summary, "intent_summary", long=True)
    for field_name, value in (
        ("audience", plan.audience),
        ("source_summary", plan.source_summary),
        ("brand_name", plan.brand_name),
        ("repository", plan.repository),
        ("ref", plan.ref),
    ):
        if value is not None:
            _check_text(value, field_name, long=field_name == "source_summary")
    if plan.artifact_type not in ARTIFACT_TYPES:
        raise ArtifactPlanError(f"unsupported artifact_type: {plan.artifact_type!r}")
    if plan.artifact_kind not in ARTIFACT_KINDS:
        raise ArtifactPlanError(f"unsupported artifact_kind: {plan.artifact_kind!r}")
    if plan.status not in ARTIFACT_STATUSES:
        raise ArtifactPlanError(f"unsupported status: {plan.status!r}")
    if plan.review_state not in REVIEW_STATES:
        raise ArtifactPlanError(f"unsupported review_state: {plan.review_state!r}")
    if not plan.output_formats:
        raise ArtifactPlanError("output_formats must not be empty")
    for fmt in plan.output_formats:
        if fmt not in SUPPORTED_OUTPUT_FORMATS:
            raise ArtifactPlanError(f"unsupported output format: {fmt!r}")
    if len(plan.sections) > _MAX_SECTIONS:
        raise ArtifactPlanError(f"sections exceeds {_MAX_SECTIONS} items")
    for section in plan.sections:
        _check_text(section.title, "sections[].title")
        if section.purpose:
            _check_text(section.purpose, "sections[].purpose")
        if section.evidence:
            _check_text(section.evidence, "sections[].evidence")
        if section.priority not in SECTION_PRIORITIES:
            raise ArtifactPlanError(
                f"unsupported section priority: {section.priority!r}"
            )
    for check in plan.required_checks:
        _check_text(check, "required_checks[]")
    for warning in plan.warnings:
        _check_text(warning, "warnings[]", long=True)


def _section_from_mapping(value: Any) -> ArtifactPlanSection:
    if not isinstance(value, Mapping):
        raise ArtifactPlanError("sections[] must be an object")
    _validate_safe_mapping(value, path="sections[]")
    return ArtifactPlanSection(
        title=_required_text(value, "title"),
        purpose=_optional_text(value.get("purpose")),
        evidence=_optional_text(value.get("evidence")),
        priority=str(value.get("priority") or "recommended"),
    )


def _validate_safe_mapping(value: Mapping[str, Any], *, path: str) -> None:
    for raw_key, raw_value in value.items():
        key = str(raw_key)
        child_path = f"{path}.{key}"
        if _UNSAFE_KEY_RE.search(key):
            raise ArtifactPlanError(f"{child_path} is not allowed in artifact plans")
        if isinstance(raw_value, Mapping):
            _validate_safe_mapping(raw_value, path=child_path)
        elif isinstance(raw_value, list):
            for index, item in enumerate(raw_value):
                if isinstance(item, Mapping):
                    _validate_safe_mapping(item, path=f"{child_path}[{index}]")
                elif isinstance(item, str):
                    _check_text(item, f"{child_path}[{index}]", long=True)
        elif isinstance(raw_value, str):
            _check_text(raw_value, child_path, long=True)


def _required_text(payload: Mapping[str, Any], key: str) -> str:
    value = _optional_text(payload.get(key), long=key.endswith("summary"))
    if not value:
        raise ArtifactPlanError(f"{key} is required")
    return value


def _optional_text(value: Any, *, long: bool = False) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    _check_text(text, "value", long=long)
    return text


def _check_text(value: str, path: str, *, long: bool = False) -> None:
    if _SECRET_VALUE_RE.search(value):
        raise ArtifactPlanError(f"{path} appears to contain a secret")
    limit = _MAX_TEXT_LENGTH if long else _MAX_SHORT_TEXT_LENGTH
    if len(value) > limit:
        raise ArtifactPlanError(f"{path} exceeds {limit} characters")


def _normalize_formats(value: Any) -> list[str]:
    return _normalize_string_list(value)


def _normalize_string_list(value: Any, *, lower: bool = True) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value[:64]:
        text = str(item).strip().lstrip(".")
        if lower:
            text = text.lower()
        if text and text not in result:
            result.append(text)
    return result


def _list(payload: Mapping[str, Any], key: str) -> list[Any]:
    value = payload.get(key, [])
    if value is None:
        return []
    if not isinstance(value, list):
        raise ArtifactPlanError(f"{key} must be an array")
    return value


def _artifact_type(value: Any) -> ArtifactType:
    text = str(value)
    if text not in ARTIFACT_TYPES:
        raise ArtifactPlanError(f"unsupported artifact_type: {text!r}")
    return cast(ArtifactType, text)


def _artifact_status(value: Any) -> ArtifactStatus:
    text = str(value)
    if text not in ARTIFACT_STATUSES:
        raise ArtifactPlanError(f"unsupported status: {text!r}")
    return cast(ArtifactStatus, text)


def _review_state(value: Any) -> ReviewState:
    text = str(value)
    if text not in REVIEW_STATES:
        raise ArtifactPlanError(f"unsupported review_state: {text!r}")
    return cast(ReviewState, text)


_TEMPLATE_FORMATS = {"dotx", "potx", "xltx", "ott", "otp", "ots", "otg", "thmx"}
