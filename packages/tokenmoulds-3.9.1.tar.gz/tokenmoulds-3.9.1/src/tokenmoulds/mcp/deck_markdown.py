"""Markdown-to-slide adapter for MCP PowerPoint generation.

The adapter deliberately returns ``slides[{layout, placeholders}]`` rather than
absolute shape geometry.  ``slide_builder.build_slide_xml`` can then bind that
content to existing layout placeholders so the slide master and layout grid own
positioning.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from tokenmoulds.mcp.deck_layout_planner import LayoutDecision, decide_layout


@dataclass
class _DraftSlide:
    title: str
    blocks: list[dict[str, Any]] = field(default_factory=list)
    section: bool = False


@dataclass
class _Group:
    label: str
    blocks: list[dict[str, Any]] = field(default_factory=list)


def markdown_to_powerpoint_slides(
    markdown: str,
    *,
    title: str | None = None,
) -> list[dict[str, Any]]:
    """Convert Markdown into layout-backed PowerPoint slide specs.

    Mapping is intentionally conservative:

    - first ``#`` becomes a ``title_slide`` cover;
    - ``##`` starts a content slide;
    - ``###`` creates grouped content inside the current slide;
    - exactly two ``###`` groups become a ``comparison`` layout;
    - all other content uses standard placeholder layouts.

    The returned slide specs are suitable for ``_inject_powerpoint_content`` and
    contain no shape coordinates.
    """
    blocks = _markdown_to_blocks(markdown)
    slides: list[dict[str, Any]] = []
    drafts: list[_DraftSlide] = []
    current: _DraftSlide | None = None
    cover_title = title
    cover_subtitle: str | None = None
    saw_content_heading = False

    def flush_current() -> None:
        nonlocal current
        if current is not None:
            drafts.append(current)
            current = None

    for block in blocks:
        block_type = block.get("type", "")
        text = _block_text(block)
        if not text and block_type not in {"table", "horizontal_rule"}:
            continue

        if block_type == "heading1":
            if not saw_content_heading and current is None and not drafts:
                if cover_title is None:
                    cover_title = text
                continue
            flush_current()
            current = _DraftSlide(title=text, section=True)
            saw_content_heading = True
            continue

        if block_type == "heading2":
            flush_current()
            current = _DraftSlide(title=text)
            saw_content_heading = True
            continue

        if current is None and cover_title and cover_subtitle is None:
            cover_subtitle = text
            continue

        if current is None:
            current = _DraftSlide(title=cover_title or title or "Overview")

        current.blocks.append(block)

    flush_current()

    if cover_title:
        placeholders = {"title": cover_title}
        if cover_subtitle:
            placeholders["subtitle"] = cover_subtitle
        slides.append(
            _slide_spec(
                placeholders,
                decide_layout(placeholders, preferred_layouts=("title_slide",)),
            )
        )

    slides.extend(_draft_to_slide(draft) for draft in drafts)

    if not slides:
        slides.append(
            {
                "layout": "title_slide",
                "placeholders": {"title": title or "Untitled Presentation"},
            }
        )

    return slides


def _draft_to_slide(draft: _DraftSlide) -> dict[str, Any]:
    body_blocks, groups = _split_groups(draft.blocks)

    if draft.section and not groups:
        body = _blocks_text(body_blocks)
        placeholders = {"title": draft.title}
        if body:
            placeholders["body"] = body
        return _slide_spec(
            placeholders,
            decide_layout(
                placeholders,
                preferred_layouts=("section_header",),
            ),
        )

    if len(groups) == 2 and not body_blocks:
        placeholders = {
            "title": draft.title,
            "label_left": groups[0].label,
            "content_left": _blocks_text(groups[0].blocks),
            "label_right": groups[1].label,
            "content_right": _blocks_text(groups[1].blocks),
        }
        return _slide_spec(
            placeholders,
            decide_layout(placeholders, preferred_layouts=("comparison",)),
        )

    if len(groups) == 3 and not body_blocks:
        placeholders = {"title": draft.title}
        for idx, group in enumerate(groups, start=1):
            placeholders[f"step_{idx}"] = _group_text(group)
        return _slide_spec(
            placeholders,
            decide_layout(placeholders, preferred_layouts=("process_3step",)),
        )

    if len(groups) == 4 and not body_blocks:
        swot_slots = _swot_slot_map(groups)
        if swot_slots is not None:
            placeholders = {"title": draft.title, **swot_slots}
            return _slide_spec(
                placeholders,
                decide_layout(placeholders, preferred_layouts=("swot_2x2",)),
            )

        placeholders = {"title": draft.title}
        for idx, group in enumerate(groups, start=1):
            placeholders[f"step_{idx}"] = _group_text(group)
        return _slide_spec(
            placeholders,
            decide_layout(placeholders, preferred_layouts=("process_4step",)),
        )

    if len(groups) > 4 and not body_blocks:
        intended_slots = ("title",) + tuple(
            f"group_{idx}" for idx in range(1, len(groups) + 1)
        )
        placeholders = {"title": draft.title}
        for idx, group in enumerate(groups, start=1):
            placeholders[f"group_{idx}"] = _group_text(group)
        return _slide_spec(
            placeholders,
            decide_layout(
                intended_slots,
                preferred_layouts=("process_4step", "kpi_4card"),
                fallback_layout="title_content",
                clone_source="process_4step",
                clone_name=f"process_{len(groups)}group",
            ),
        )

    placeholders = {
        "title": draft.title,
        "body": _blocks_text(draft.blocks),
    }
    return _slide_spec(
        placeholders,
        decide_layout(placeholders, preferred_layouts=("title_content",)),
    )


def _slide_spec(
    placeholders: dict[str, str],
    decision: LayoutDecision,
) -> dict[str, Any]:
    return {
        "layout": decision.layout_name,
        "placeholders": placeholders,
        "layout_decision": decision.to_dict(),
    }


def _group_text(group: _Group) -> str:
    body = _blocks_text(group.blocks)
    return f"{group.label}\n{body}".strip()


def _swot_slot_map(groups: list[_Group]) -> dict[str, str] | None:
    slots = {
        "strength": "strengths",
        "strengths": "strengths",
        "weakness": "weaknesses",
        "weaknesses": "weaknesses",
        "opportunity": "opportunities",
        "opportunities": "opportunities",
        "threat": "threats",
        "threats": "threats",
    }
    mapped: dict[str, str] = {}
    for group in groups:
        key = group.label.strip().lower()
        slot = slots.get(key)
        if slot is None:
            return None
        mapped[slot] = _group_text(group)
    return mapped if len(mapped) == 4 else None


def _split_groups(
    blocks: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[_Group]]:
    body_blocks: list[dict[str, Any]] = []
    groups: list[_Group] = []
    current_group: _Group | None = None

    for block in blocks:
        block_type = block.get("type", "")
        if block_type in {"heading3", "heading4"}:
            current_group = _Group(_block_text(block))
            groups.append(current_group)
            continue
        if current_group is None:
            body_blocks.append(block)
        else:
            current_group.blocks.append(block)

    return body_blocks, groups


def _blocks_text(blocks: list[dict[str, Any]]) -> str:
    return "\n".join(text for block in blocks if (text := _block_text(block))).strip()


def _block_text(block: dict[str, Any]) -> str:
    block_type = block.get("type", "")

    if block_type in {"bullet_list", "numbered_list"}:
        text = _runs_text(block.get("runs", [])) or block.get("text", "")
        prefix = "1. " if block_type == "numbered_list" else "- "
        return f"{prefix}{text}".strip()

    if block_type == "table":
        rows = []
        for row in block.get("rows", []):
            cells = [_runs_text(cell.get("runs", [])) for cell in row]
            rows.append(" | ".join(cells))
        return "\n".join(rows)

    if block_type == "code_block":
        language = block.get("language")
        code = str(block.get("text", "")).strip()
        return f"{language}\n{code}".strip() if language else code

    if block_type in {"block_quote", "quote"}:
        text = _runs_text(block.get("runs", [])) or block.get("text", "")
        return f"> {text}".strip()

    if "runs" in block:
        return _runs_text(block.get("runs", []))

    return str(block.get("text", "")).strip()


def _runs_text(runs: list[dict[str, Any]]) -> str:
    return "".join(str(run.get("text", "")) for run in runs).strip()


def _markdown_to_blocks(markdown: str) -> list[dict[str, Any]]:
    try:
        from tokenmoulds.mcp.markdown import markdown_to_blocks

        return markdown_to_blocks(markdown)
    except ModuleNotFoundError:
        return _basic_markdown_to_blocks(markdown)


def _basic_markdown_to_blocks(markdown: str) -> list[dict[str, Any]]:
    """Small fallback parser for environments without mistune installed."""
    blocks: list[dict[str, Any]] = []
    paragraph: list[str] = []
    in_code = False
    code_language = ""
    code_lines: list[str] = []

    def flush_paragraph() -> None:
        if paragraph:
            blocks.append(
                {
                    "type": "paragraph",
                    "runs": [{"text": " ".join(paragraph).strip()}],
                }
            )
            paragraph.clear()

    for raw_line in markdown.splitlines():
        line = raw_line.rstrip()

        if line.startswith("```"):
            if in_code:
                blocks.append(
                    {
                        "type": "code_block",
                        "text": "\n".join(code_lines),
                        "language": code_language,
                    }
                )
                in_code = False
                code_language = ""
                code_lines = []
            else:
                flush_paragraph()
                in_code = True
                code_language = line[3:].strip()
            continue

        if in_code:
            code_lines.append(line)
            continue

        if not line.strip():
            flush_paragraph()
            continue

        heading = re.match(r"^(#{1,4})\s+(.+)$", line)
        if heading:
            flush_paragraph()
            blocks.append(
                {
                    "type": f"heading{len(heading.group(1))}",
                    "runs": [{"text": heading.group(2).strip()}],
                }
            )
            continue

        unordered = re.match(r"^\s*[-*+]\s+(.+)$", line)
        if unordered:
            flush_paragraph()
            blocks.append(
                {
                    "type": "bullet_list",
                    "runs": [{"text": unordered.group(1).strip()}],
                }
            )
            continue

        ordered = re.match(r"^\s*\d+[.)]\s+(.+)$", line)
        if ordered:
            flush_paragraph()
            blocks.append(
                {
                    "type": "numbered_list",
                    "runs": [{"text": ordered.group(1).strip()}],
                }
            )
            continue

        if line.startswith(">"):
            flush_paragraph()
            blocks.append(
                {
                    "type": "block_quote",
                    "runs": [{"text": line.lstrip("> ").strip()}],
                }
            )
            continue

        paragraph.append(line.strip())

    flush_paragraph()
    return blocks
