"""Apps Script bundle generation and deploy helpers for Google Workspace."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping
from urllib import error as urllib_error
from urllib import request as urllib_request

from tokenmoulds.mcp.artifact_plan import (
    ArtifactPlan,
    ArtifactPlanError,
    artifact_plan_from_mapping,
    load_artifact_plan,
    safe_artifact_id,
)
from tokenmoulds.artifact_intent import canonical_json

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


GOOGLE_APPS_SCRIPT_API_BASE = "https://script.googleapis.com/v1"
GOOGLE_APPS_SCRIPT_REQUIRED_SCOPE = "https://www.googleapis.com/auth/script.projects"
GOOGLE_APPS_SCRIPT_DRIVE_SCOPE = "https://www.googleapis.com/auth/drive"
GOOGLE_APPS_SCRIPT_DEFAULT_SCOPES = (
    "https://www.googleapis.com/auth/documents",
    "https://www.googleapis.com/auth/presentations",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive.file",
    GOOGLE_APPS_SCRIPT_REQUIRED_SCOPE,
)

GENERATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact plan ID under generated/plans/<artifact_id>/plan.json",
        },
        "plan": {
            "type": "object",
            "description": "Inline ArtifactPlan payload to render into Apps Script instead of loading by ID",
        },
        "title": {
            "type": "string",
            "description": "Override the generated script title",
        },
        "target_format": {
            "type": "string",
            "enum": ["docx", "pptx", "xlsx"],
            "description": (
                "Which Google Workspace surface the Apps Script should create "
                "under the user's identity"
            ),
        },
        "script_id": {
            "type": "string",
            "description": "Existing Apps Script project ID to update instead of creating a new project",
        },
        "parent_id": {
            "type": "string",
            "description": "Optional Google Drive file ID to bind a new Apps Script project to",
        },
        "access_token": {
            "type": "string",
            "description": "OAuth bearer token for the Apps Script API. If omitted, TokenMoulds looks for TOKENMOULDS_GOOGLE_ACCESS_TOKEN, GOOGLE_OAUTH_ACCESS_TOKEN, or gcloud ADC.",
        },
        "access_token_env": {
            "type": "string",
            "description": "Environment variable to read the OAuth bearer token from before falling back to other token sources",
        },
        "api_base_url": {
            "type": "string",
            "description": "Override the Apps Script API base URL for testing or alternate endpoints",
        },
        "content": {
            "type": "object",
            "description": (
                "Document payload keyed by format or kind. Supports the same "
                "by_format shape used by compile_artifact."
            ),
        },
        "script_name": {
            "type": "string",
            "description": "Optional Apps Script file stem, defaults to the artifact ID",
        },
        "scopes": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional explicit Apps Script OAuth scopes for the generated manifest. Overrides the default scope set.",
        },
    },
    "required": ["artifact_id"],
}

DEPLOY_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact plan ID under generated/plans/<artifact_id>/plan.json",
        },
        "plan": {
            "type": "object",
            "description": "Inline ArtifactPlan payload to render into Apps Script instead of loading by ID",
        },
        "title": {
            "type": "string",
            "description": "Override the generated project title",
        },
        "target_format": {
            "type": "string",
            "enum": ["docx", "pptx", "xlsx"],
            "description": (
                "Which Google Workspace surface the Apps Script should create "
                "under the user's identity"
            ),
        },
        "script_id": {
            "type": "string",
            "description": "Existing Apps Script project ID to update instead of creating a new project",
        },
        "parent_id": {
            "type": "string",
            "description": "Optional Google Drive file ID to bind a new Apps Script project to",
        },
        "access_token": {
            "type": "string",
            "description": "OAuth bearer token for the Apps Script API. If omitted, TokenMoulds looks for TOKENMOULDS_GOOGLE_ACCESS_TOKEN, GOOGLE_OAUTH_ACCESS_TOKEN, or gcloud ADC.",
        },
        "access_token_env": {
            "type": "string",
            "description": "Environment variable to read the OAuth bearer token from before falling back to other token sources",
        },
        "api_base_url": {
            "type": "string",
            "description": "Override the Apps Script API base URL for testing or alternate endpoints",
        },
        "content": {
            "type": "object",
            "description": (
                "Document payload keyed by format or kind. Supports the same "
                "by_format shape used by compile_artifact."
            ),
        },
        "script_name": {
            "type": "string",
            "description": "Optional Apps Script file stem, defaults to the artifact ID",
        },
        "scopes": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional explicit Apps Script OAuth scopes for the generated manifest. Overrides the default scope set.",
        },
    },
    "required": ["artifact_id"],
}

VALIDATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact plan ID under generated/plans/<artifact_id>/plan.json",
        },
        "output_dir": {
            "type": "string",
            "description": "Output directory containing generated/apps-script/<artifact_id>/",
        },
        "script_name": {
            "type": "string",
            "description": "Optional Apps Script file stem, defaults to the artifact ID",
        },
        "scopes": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional explicit Apps Script OAuth scopes that must be present in the generated manifest.",
        },
    },
    "required": ["artifact_id"],
}


async def generate_google_apps_script_bundle(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Generate an Apps Script bundle for Google Workspace."""
    try:
        bundle = _prepare_bundle(arguments, server)
    except ArtifactPlanError as exc:
        return {
            "error": str(exc),
            "action": "generate_google_apps_script_bundle",
        }

    plan = bundle["plan"]
    code_path = bundle["code_path"]
    manifest_path = bundle["manifest_path"]
    readme_path = bundle["readme_path"]

    payload = {
        "success": True,
        "action": "generate_google_apps_script_bundle",
        "artifact_id": plan.artifact_id,
        "artifact_plan_sha256": plan.sha256(),
        "target_format": bundle["target_format"],
        "script_title": bundle["script_title"],
        "script_name": bundle["script_name"],
        "scopes": bundle["scopes"],
        "bundle_path": str(bundle["bundle_root"]),
        "code_path": str(code_path),
        "manifest_path": str(manifest_path),
        "readme_path": str(readme_path),
        "job_path": str(bundle["job_path"]),
        "files": [str(code_path), str(manifest_path), str(readme_path)],
        "google_apps_script_api": {
            "project_create_url": f"{GOOGLE_APPS_SCRIPT_API_BASE}/projects",
            "project_update_url": (
                f"{GOOGLE_APPS_SCRIPT_API_BASE}/projects/{{scriptId}}/content"
            ),
            "required_scope": GOOGLE_APPS_SCRIPT_REQUIRED_SCOPE,
        },
        "message": (f"Generated an Apps Script bundle for {bundle['target_format']}."),
    }
    return payload


async def deploy_google_apps_script_bundle(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Deploy an Apps Script bundle through the Apps Script API."""
    try:
        bundle = _prepare_bundle(arguments, server)
        access_token = _resolve_access_token(arguments)
        deployment = _deploy_bundle(
            bundle, access_token=access_token, arguments=arguments
        )
    except ArtifactPlanError as exc:
        return {
            "error": str(exc),
            "action": "deploy_google_apps_script_bundle",
        }

    payload = {
        "success": True,
        "action": "deploy_google_apps_script_bundle",
        "artifact_id": bundle["plan"].artifact_id,
        "artifact_plan_sha256": bundle["plan"].sha256(),
        "target_format": bundle["target_format"],
        "script_title": bundle["script_title"],
        "script_name": bundle["script_name"],
        "scopes": bundle["scopes"],
        "bundle_path": str(bundle["bundle_root"]),
        "code_path": str(bundle["code_path"]),
        "manifest_path": str(bundle["manifest_path"]),
        "readme_path": str(bundle["readme_path"]),
        "job_path": str(bundle["job_path"]),
        "files": [
            str(bundle["code_path"]),
            str(bundle["manifest_path"]),
            str(bundle["readme_path"]),
        ],
        "google_apps_script_api": {
            "project_create_url": f"{GOOGLE_APPS_SCRIPT_API_BASE}/projects",
            "project_update_url": (
                f"{GOOGLE_APPS_SCRIPT_API_BASE}/projects/{{scriptId}}/content"
            ),
            "required_scope": GOOGLE_APPS_SCRIPT_REQUIRED_SCOPE,
        },
        "deployment": deployment,
        "message": (f"Deployed an Apps Script project for {bundle['target_format']}."),
    }
    return payload


async def validate_google_apps_script_bundle(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Validate a generated Apps Script bundle without contacting Google."""
    try:
        plan = _load_plan(arguments, server)
        artifact_id = plan.artifact_id
        script_title = str(arguments.get("title") or plan.title).strip() or plan.title
        script_name = _script_name(
            arguments.get("script_name"),
            artifact_id,
            script_title,
        )
        output_root = Path(str(arguments.get("output_dir") or server.output_path))
        bundle_root = output_root / "apps-script" / safe_artifact_id(artifact_id)
        bundle = {
            "plan": plan,
            "target_format": _requested_target_format(arguments, plan),
            "script_title": script_title,
            "script_name": script_name,
            "scopes": _requested_scopes(arguments),
            "bundle_root": bundle_root,
            "code_path": bundle_root / f"{script_name}.gs",
            "manifest_path": bundle_root / "appsscript.json",
            "readme_path": bundle_root / "README.md",
            "job_path": bundle_root / "tokenmoulds-job.json",
        }
        validation = _validate_bundle(bundle)
    except ArtifactPlanError as exc:
        return {
            "error": str(exc),
            "action": "validate_google_apps_script_bundle",
        }

    return {
        "success": True,
        "action": "validate_google_apps_script_bundle",
        "artifact_id": plan.artifact_id,
        "artifact_plan_sha256": plan.sha256(),
        "target_format": bundle["target_format"],
        "script_title": bundle["script_title"],
        "script_name": bundle["script_name"],
        "scopes": bundle["scopes"],
        "bundle_path": str(bundle["bundle_root"]),
        "code_path": str(bundle["code_path"]),
        "manifest_path": str(bundle["manifest_path"]),
        "readme_path": str(bundle["readme_path"]),
        "job_path": str(bundle["job_path"]),
        "validation": validation,
        "message": "Validated the generated Apps Script bundle and confirmed the embedded job matches the sidecar.",
    }


def _load_plan(
    arguments: Mapping[str, Any], server: "TokenMouldsServer"
) -> ArtifactPlan:
    inline_plan = arguments.get("plan")
    if isinstance(inline_plan, Mapping):
        return artifact_plan_from_mapping(inline_plan)

    artifact_id = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id:
        raise ArtifactPlanError("artifact_id is required")

    memory_plan = getattr(server, "artifact_plans", {}).get(artifact_id)
    if isinstance(memory_plan, Mapping):
        return artifact_plan_from_mapping(memory_plan)
    return load_artifact_plan(server.output_path, artifact_id)


def _requested_target_format(arguments: Mapping[str, Any], plan: ArtifactPlan) -> str:
    raw = str(arguments.get("target_format") or "").strip().lower()
    if raw:
        if raw not in {"docx", "pptx", "xlsx"}:
            raise ArtifactPlanError(f"unsupported target_format: {raw!r}")
        return raw

    for fmt in plan.output_formats:
        if fmt in {"docx", "pptx", "xlsx"}:
            return fmt
    raise ArtifactPlanError(
        "target_format is required when the plan does not include docx, pptx, or xlsx"
    )


def _script_name(explicit: Any, artifact_id: str, title: str) -> str:
    candidate = str(explicit or "").strip()
    if candidate:
        return _safe_js_name(candidate)
    if artifact_id:
        return _safe_js_name(artifact_id)
    return _safe_js_name(title)


def _safe_js_name(value: str) -> str:
    candidate = value.strip()
    if not candidate:
        return "TokenMouldsBundle"
    candidate = candidate.replace(" ", "_")
    return "".join(ch for ch in candidate if ch.isalnum() or ch in "-_")


def _prepare_bundle(
    arguments: Mapping[str, Any], server: "TokenMouldsServer"
) -> dict[str, Any]:
    plan = _load_plan(arguments, server)
    target_format = _requested_target_format(arguments, plan)
    artifact_id = plan.artifact_id
    script_title = str(arguments.get("title") or plan.title).strip() or plan.title
    script_name = _script_name(
        arguments.get("script_name"),
        artifact_id,
        script_title,
    )
    output_root = Path(str(arguments.get("output_dir") or server.output_path))
    bundle_root = output_root / "apps-script" / safe_artifact_id(artifact_id)
    bundle_root.mkdir(parents=True, exist_ok=True)

    content = arguments.get("content", {})
    job = _build_job_payload(
        plan=plan,
        target_format=target_format,
        content=content if isinstance(content, Mapping) else {},
        script_title=script_title,
    )

    code_text = _render_code(job, script_title=script_title)
    manifest_text = _render_manifest(arguments)
    readme_text = _render_readme(bundle_root, script_title, target_format)

    code_path = bundle_root / f"{script_name}.gs"
    manifest_path = bundle_root / "appsscript.json"
    readme_path = bundle_root / "README.md"
    job_path = bundle_root / "tokenmoulds-job.json"

    code_path.write_text(code_text, encoding="utf-8")
    manifest_path.write_text(manifest_text, encoding="utf-8")
    readme_path.write_text(readme_text, encoding="utf-8")
    job_path.write_text(
        json.dumps(job, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    return {
        "plan": plan,
        "target_format": target_format,
        "script_title": script_title,
        "script_name": script_name,
        "scopes": _requested_scopes(arguments),
        "bundle_root": bundle_root,
        "code_path": code_path,
        "manifest_path": manifest_path,
        "readme_path": readme_path,
        "job_path": job_path,
        "code_text": code_text,
        "manifest_text": manifest_text,
        "job": job,
    }


def _validate_bundle(bundle: Mapping[str, Any]) -> dict[str, Any]:
    code_path = Path(str(bundle["code_path"]))
    manifest_path = Path(str(bundle["manifest_path"]))
    readme_path = Path(str(bundle["readme_path"]))
    job_path = Path(str(bundle["job_path"]))

    missing = [
        str(path)
        for path in (code_path, manifest_path, readme_path, job_path)
        if not path.exists()
    ]
    if missing:
        raise ArtifactPlanError(
            "Generated Apps Script bundle is incomplete: " + ", ".join(missing)
        )

    code_text = code_path.read_text(encoding="utf-8")
    job_sidecar = json.loads(job_path.read_text(encoding="utf-8"))
    if not isinstance(job_sidecar, dict):
        raise ArtifactPlanError("tokenmoulds-job.json must contain a JSON object")

    embedded_job = _embedded_job_from_code(code_text)
    if embedded_job != job_sidecar:
        raise ArtifactPlanError(
            "Embedded Apps Script job does not match tokenmoulds-job.json"
        )

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ArtifactPlanError("appsscript.json must contain a JSON object")

    required_scopes = set(
        _requested_scopes(
            {"scopes": bundle.get("scopes")} if bundle.get("scopes") is not None else {}
        )
    )
    scopes = set(str(scope) for scope in manifest.get("oauthScopes", []))
    missing_scopes = sorted(required_scopes - scopes)
    if missing_scopes:
        raise ArtifactPlanError(
            "appsscript.json is missing required scopes: " + ", ".join(missing_scopes)
        )

    code_has_runner = "function runTokenMouldsJob()" in code_text
    if not code_has_runner:
        raise ArtifactPlanError("Apps Script bundle must define runTokenMouldsJob()")

    return {
        "bundle_complete": True,
        "job_matches_sidecar": True,
        "code_path": str(code_path),
        "manifest_path": str(manifest_path),
        "readme_path": str(readme_path),
        "job_path": str(job_path),
        "manifest_scope_count": len(scopes),
        "embedded_job_sha256": hashlib.sha256(
            canonical_json(embedded_job).encode("utf-8")
        ).hexdigest(),
    }


def _embedded_job_from_code(code_text: str) -> dict[str, Any]:
    marker = "const TOKENMOULDS_JOB = "
    start = code_text.find(marker)
    if start < 0:
        raise ArtifactPlanError("Apps Script bundle is missing TOKENMOULDS_JOB")
    start += len(marker)
    end_marker = ";\n\nfunction runTokenMouldsJob()"
    end = code_text.find(end_marker, start)
    if end < 0:
        raise ArtifactPlanError("Apps Script bundle is missing runTokenMouldsJob()")
    payload = code_text[start:end].strip()
    parsed = json.loads(payload)
    if not isinstance(parsed, dict):
        raise ArtifactPlanError("Embedded TOKENMOULDS_JOB must be a JSON object")
    return parsed


def _build_job_payload(
    *,
    plan: ArtifactPlan,
    target_format: str,
    content: Mapping[str, Any],
    script_title: str,
) -> dict[str, Any]:
    default_content = _default_content(plan, target_format)
    resolved_content = _content_for_target(target_format, content, default_content)
    return {
        "artifactId": plan.artifact_id,
        "title": script_title,
        "targetFormat": target_format,
        "brandName": plan.brand_name,
        "repository": plan.repository,
        "ref": plan.ref,
        "sections": [section.to_dict() for section in plan.sections],
        "content": resolved_content,
    }


def _default_content(plan: ArtifactPlan, target_format: str) -> Any:
    if target_format == "docx":
        blocks: list[dict[str, Any]] = [
            {"type": "title", "text": plan.title},
            {"type": "paragraph", "text": plan.intent_summary},
        ]
        for section in plan.sections:
            blocks.append({"type": "heading1", "text": section.title})
            if section.purpose:
                blocks.append({"type": "paragraph", "text": section.purpose})
            if section.evidence:
                blocks.append({"type": "quote", "text": section.evidence})
        return {"blocks": blocks}

    if target_format == "pptx":
        slides: list[dict[str, Any]] = [
            {
                "title": plan.title,
                "body": plan.intent_summary,
            }
        ]
        for section in plan.sections:
            slides.append(
                {
                    "title": section.title,
                    "body": section.purpose or section.evidence or "",
                }
            )
        return {"slides": slides}

    rows = [["Section", "Priority", "Purpose", "Evidence"]]
    rows.extend(
        [
            section.title,
            section.priority,
            section.purpose or "",
            section.evidence or "",
        ]
        for section in plan.sections
    )
    return {
        "sheets": [
            {
                "name": "Plan",
                "data": rows,
                "headers": True,
            }
        ]
    }


def _content_for_target(
    target_format: str, content: Mapping[str, Any], default_content: Any
) -> Any:
    by_format = content.get("by_format")
    if isinstance(by_format, Mapping) and target_format in by_format:
        return by_format[target_format]
    if target_format in content:
        return content[target_format]
    if target_format == "docx":
        return content.get("document") or content.get("content") or default_content
    if target_format == "pptx":
        return content.get("slides") or content.get("markdown") or default_content
    if target_format == "xlsx":
        return content.get("sheets") or default_content
    return default_content


def _render_code(job: Mapping[str, Any], *, script_title: str) -> str:
    payload = json.dumps(job, indent=2, ensure_ascii=False)
    return (
        "/**\n"
        f" * TokenMoulds Apps Script bundle: {script_title}\n"
        " * Generated by TokenMoulds as a user-run Apps Script artifact.\n"
        " */\n\n"
        f"const TOKENMOULDS_JOB = {payload};\n\n"
        "function runTokenMouldsJob() {\n"
        "  var job = TOKENMOULDS_JOB;\n"
        "  switch (job.targetFormat) {\n"
        "    case 'docx':\n"
        "      return buildDocument_(job);\n"
        "    case 'pptx':\n"
        "      return buildPresentation_(job);\n"
        "    case 'xlsx':\n"
        "      return buildSpreadsheet_(job);\n"
        "    default:\n"
        "      throw new Error('Unsupported targetFormat: ' + job.targetFormat);\n"
        "  }\n"
        "}\n\n"
        "function buildDocument_(job) {\n"
        "  var doc = DocumentApp.create(job.title || 'TokenMoulds Document');\n"
        "  var body = doc.getBody();\n"
        "  renderDocumentBlocks_(body, (job.content && job.content.blocks) || []);\n"
        "  doc.saveAndClose();\n"
        "  return {id: doc.getId(), url: doc.getUrl(), title: doc.getName()};\n"
        "}\n\n"
        "function renderDocumentBlocks_(body, blocks) {\n"
        "  blocks.forEach(function(block) {\n"
        "    if (!block || !block.type) return;\n"
        "    if (block.type === 'title') {\n"
        "      body.appendParagraph(block.text || '').setHeading(DocumentApp.ParagraphHeading.HEADING1);\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'heading1' || block.type === 'heading2' || block.type === 'heading3') {\n"
        "      var heading = DocumentApp.ParagraphHeading.HEADING1;\n"
        "      if (block.type === 'heading2') heading = DocumentApp.ParagraphHeading.HEADING2;\n"
        "      if (block.type === 'heading3') heading = DocumentApp.ParagraphHeading.HEADING3;\n"
        "      body.appendParagraph(block.text || '').setHeading(heading);\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'paragraph' || block.type === 'quote' || block.type === 'code_block') {\n"
        "      body.appendParagraph(block.text || '');\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'bullet_list' && Array.isArray(block.items)) {\n"
        "      block.items.forEach(function(item) { body.appendListItem(String(item)).setGlyphType(DocumentApp.GlyphType.BULLET); });\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'numbered_list' && Array.isArray(block.items)) {\n"
        "      block.items.forEach(function(item) { body.appendListItem(String(item)).setGlyphType(DocumentApp.GlyphType.NUMBER); });\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'table' && Array.isArray(block.rows)) {\n"
        "      body.appendTable(block.rows.map(function(row) { return row.map(String); }));\n"
        "      return;\n"
        "    }\n"
        "    if (block.type === 'page_break') {\n"
        "      body.appendPageBreak();\n"
        "    }\n"
        "  });\n"
        "}\n\n"
        "function buildPresentation_(job) {\n"
        "  var pres = SlidesApp.create(job.title || 'TokenMoulds Presentation');\n"
        "  var slides = (job.content && job.content.slides) || [];\n"
        "  if (!slides.length) {\n"
        "    return {id: pres.getId(), url: pres.getUrl(), title: pres.getName(), slides: 0};\n"
        "  }\n"
        "  var first = pres.getSlides()[0];\n"
        "  renderSlide_(first, slides[0], job);\n"
        "  for (var i = 1; i < slides.length; i++) {\n"
        "    var slide = pres.appendSlide(SlidesApp.PredefinedLayout.BLANK);\n"
        "    renderSlide_(slide, slides[i], job);\n"
        "  }\n"
        "  return {id: pres.getId(), url: pres.getUrl(), title: pres.getName(), slides: slides.length};\n"
        "}\n\n"
        "function renderSlide_(slide, spec, job) {\n"
        "  var title = (spec && spec.title) || job.title || '';\n"
        "  var body = (spec && (spec.body || spec.text)) || '';\n"
        "  slide.clear();\n"
        "  slide.insertTextBox(String(title), 40, 30, 640, 70)\n"
        "    .getText().getTextStyle().setFontSize(24).setBold(true);\n"
        "  if (body) {\n"
        "    slide.insertTextBox(String(body), 40, 110, 640, 300)\n"
        "      .getText().getTextStyle().setFontSize(14);\n"
        "  }\n"
        "}\n\n"
        "function buildSpreadsheet_(job) {\n"
        "  var ss = SpreadsheetApp.create(job.title || 'TokenMoulds Workbook');\n"
        "  var sheets = (job.content && job.content.sheets) || [];\n"
        "  if (!sheets.length) {\n"
        "    return {id: ss.getId(), url: ss.getUrl(), title: ss.getName(), sheets: 0};\n"
        "  }\n"
        "  var primary = ss.getSheets()[0];\n"
        "  configureSheet_(primary, sheets[0]);\n"
        "  for (var i = 1; i < sheets.length; i++) {\n"
        "    var sheet = ss.insertSheet(String(sheets[i].name || 'Sheet ' + (i + 1)));\n"
        "    configureSheet_(sheet, sheets[i]);\n"
        "  }\n"
        "  return {id: ss.getId(), url: ss.getUrl(), title: ss.getName(), sheets: sheets.length};\n"
        "}\n\n"
        "function configureSheet_(sheet, spec) {\n"
        "  var name = String((spec && spec.name) || 'Sheet1');\n"
        "  sheet.setName(name);\n"
        "  var rows = (spec && spec.data) || [];\n"
        "  if (!rows.length) return;\n"
        "  var range = sheet.getRange(1, 1, rows.length, rows[0].length);\n"
        "  range.setValues(rows.map(function(row) { return row.map(function(cell) { return cell === null || cell === undefined ? '' : cell; }); }));\n"
        "  if (spec && spec.headers) {\n"
        "    sheet.getRange(1, 1, 1, rows[0].length).setFontWeight('bold');\n"
        "  }\n"
        "  sheet.autoResizeColumns(1, rows[0].length);\n"
        "}\n"
    )


def _render_manifest(arguments: Mapping[str, Any]) -> str:
    scopes = _requested_scopes(arguments)
    manifest = {
        "timeZone": "Europe/Amsterdam",
        "exceptionLogging": "STACKDRIVER",
        "runtimeVersion": "V8",
        "oauthScopes": scopes,
        "addOns": {},
    }
    return json.dumps(manifest, indent=2) + "\n"


def _render_readme(bundle_root: Path, script_title: str, target_format: str) -> str:
    return (
        f"# {script_title}\n\n"
        "This folder is a Google Apps Script project generated by TokenMoulds.\n\n"
        f"- Target format: `{target_format}`\n"
        f"- Project root: `{bundle_root}`\n\n"
        "The bundle includes a `tokenmoulds-job.json` sidecar with the same\n"
        "plan payload embedded into `Code.gs`.\n\n"
        "Workflow:\n\n"
        "1. Deploy the files with `tokenmoulds google-suite --deploy`.\n"
        "2. Open the generated script in `script.google.com` and run "
        "`runTokenMouldsJob()` under your own identity.\n"
    )


def _requested_scopes(arguments: Mapping[str, Any]) -> list[str]:
    raw_scopes = arguments.get("scopes")
    if raw_scopes is not None:
        if not isinstance(raw_scopes, list):
            raise ArtifactPlanError("scopes must be an array of strings")
        scopes = [str(scope).strip() for scope in raw_scopes if str(scope).strip()]
    else:
        scopes = list(GOOGLE_APPS_SCRIPT_DEFAULT_SCOPES)

    unique_scopes: list[str] = []
    for scope in scopes:
        if scope not in unique_scopes:
            unique_scopes.append(scope)
    return unique_scopes


def _resolve_access_token(arguments: Mapping[str, Any]) -> str:
    explicit = str(arguments.get("access_token") or "").strip()
    if explicit:
        return explicit

    env_name = str(arguments.get("access_token_env") or "").strip()
    env_candidates = [env_name] if env_name else []
    env_candidates.extend(
        ["TOKENMOULDS_GOOGLE_ACCESS_TOKEN", "GOOGLE_OAUTH_ACCESS_TOKEN"]
    )
    for candidate in env_candidates:
        token = os.environ.get(candidate)
        if token and token.strip():
            return token.strip()

    gcloud = shutil.which("gcloud")
    if gcloud:
        try:
            result = subprocess.run(
                [gcloud, "auth", "application-default", "print-access-token"],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ArtifactPlanError(
                "Unable to obtain a Google access token from gcloud application-default"
            ) from exc
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()

    raise ArtifactPlanError(
        "Google access token required for Apps Script API deploy. Provide --access-token, set TOKENMOULDS_GOOGLE_ACCESS_TOKEN or GOOGLE_OAUTH_ACCESS_TOKEN, or ensure gcloud application-default auth is available."
    )


def _deploy_bundle(
    bundle: dict[str, Any],
    *,
    access_token: str,
    arguments: Mapping[str, Any],
) -> dict[str, Any]:
    script_id = str(arguments.get("script_id") or "").strip()
    parent_id = str(arguments.get("parent_id") or "").strip()
    base_url = str(arguments.get("api_base_url") or GOOGLE_APPS_SCRIPT_API_BASE).strip()
    if not base_url:
        base_url = GOOGLE_APPS_SCRIPT_API_BASE

    project = None
    if not script_id:
        create_payload = {"title": bundle["script_title"]}
        if parent_id:
            create_payload["parentId"] = parent_id
        project = _google_apps_script_request(
            "POST",
            f"{base_url}/projects",
            access_token=access_token,
            payload=create_payload,
        )
        script_id = str(
            project.get("scriptId")
            or project.get("projectId")
            or project.get("id")
            or ""
        ).strip()
        if not script_id:
            raise ArtifactPlanError(
                "Apps Script API did not return a scriptId when creating the project"
            )
    else:
        _google_apps_script_request(
            "GET",
            f"{base_url}/projects/{script_id}",
            access_token=access_token,
        )

    files = [
        {
            "name": "appsscript",
            "type": "JSON",
            "source": bundle["manifest_text"],
        },
        {
            "name": bundle["script_name"],
            "type": "SERVER_JS",
            "source": bundle["code_text"],
        },
    ]
    content = _google_apps_script_request(
        "PUT",
        f"{base_url}/projects/{script_id}/content",
        access_token=access_token,
        payload={"files": files},
    )

    return {
        "script_id": script_id,
        "project_title": bundle["script_title"],
        "project_url": f"https://script.google.com/d/{script_id}/edit",
        "created": project is not None,
        "project": project,
        "content": content,
        "files": files,
        "api_base_url": base_url,
    }


def _google_apps_script_request(
    method: str,
    url: str,
    *,
    access_token: str,
    payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib_request.Request(url, data=data, method=method)
    request.add_header("Authorization", f"Bearer {access_token}")
    request.add_header("Accept", "application/json")
    if data is not None:
        request.add_header("Content-Type", "application/json; charset=utf-8")

    try:
        with urllib_request.urlopen(request, timeout=30) as response:
            body = response.read().decode("utf-8").strip()
            if not body:
                return {}
            parsed = json.loads(body)
            if not isinstance(parsed, dict):
                raise ArtifactPlanError(
                    f"Unexpected Apps Script API response shape from {url}"
                )
            return parsed
    except urllib_error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace").strip()
        if detail:
            raise ArtifactPlanError(
                f"Apps Script API request failed: {method} {url} -> {exc.code}: {detail}"
            ) from exc
        raise ArtifactPlanError(
            f"Apps Script API request failed: {method} {url} -> {exc.code}"
        ) from exc
    except urllib_error.URLError as exc:
        raise ArtifactPlanError(
            f"Apps Script API request failed: {method} {url} -> {exc.reason}"
        ) from exc


__all__ = [
    "GENERATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA",
    "VALIDATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA",
    "generate_google_apps_script_bundle",
    "validate_google_apps_script_bundle",
]
