"""PowerPoint content injection for MCP document tools."""

from __future__ import annotations

import zipfile
from io import BytesIO
from typing import Any, Dict, List

import lxml.etree as etree


def _inject_powerpoint_content(
    template_bytes: bytes,
    slides: List[Dict[str, Any]],
) -> bytes:
    """Inject slide content into PowerPoint template.

    Each slide in the ``slides`` list specifies a ``layout`` name and a
    ``placeholders`` dict.  The slide builder produces a ``p:sld`` XML
    element with shapes referencing the layout's placeholders by type/idx,
    inheriting geometry from the layout and master.

    The content type is swapped from template to presentation so the
    output file is a valid .pptx.

    Each emitted slide points at an existing slide layout relationship.
    Content shapes reference placeholders only; they do not carry explicit
    positions, so layout/master grid geometry remains authoritative.
    """
    import lxml.etree as ET

    from tokenmoulds.mcp.deck_layout_clone import build_dynamic_layouts
    from tokenmoulds.mcp.tools.slide_builder import build_slide_xml

    input_zip = BytesIO(template_bytes)
    output_zip = BytesIO()
    slide_width, slide_height = _read_powerpoint_slide_size(template_bytes)
    dynamic_layouts = build_dynamic_layouts(
        slides,
        slide_width=slide_width,
        slide_height=slide_height,
    )

    slide_parts: dict[str, bytes] = {}
    slide_rel_parts: dict[str, bytes] = {}
    slide_rel_ids = [f"rId{1000 + idx}" for idx in range(1, len(slides) + 1)]

    for idx, slide in enumerate(slides, start=1):
        layout_name = slide.get("layout") or "title_content"
        placeholders = slide.get("placeholders", {})
        dynamic_layout = _dynamic_layout_for_slide(slide, dynamic_layouts)
        if dynamic_layout is not None:
            layout_name = dynamic_layout.name
            root = build_slide_xml(
                layout_name,
                placeholders,
                layout_info=dynamic_layout.layout_info,
                placeholder_map=dynamic_layout.placeholder_map,
            )
            layout_number = dynamic_layout.layout_number
        else:
            root = build_slide_xml(layout_name, placeholders)
            layout_number = _layout_number_for_slide(layout_name)
        slide_parts[f"ppt/slides/slide{idx}.xml"] = ET.tostring(
            root, encoding="UTF-8", xml_declaration=True, standalone=True
        )
        slide_rel_parts[f"ppt/slides/_rels/slide{idx}.xml.rels"] = (
            _build_powerpoint_slide_rels_xml(layout_number)
        )

    with zipfile.ZipFile(input_zip, "r") as zin:
        with zipfile.ZipFile(
            output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zout:
            for item in zin.namelist():
                if slides and _is_powerpoint_slide_part(item):
                    continue

                data = zin.read(item)
                if item == "[Content_Types].xml":
                    data = _update_powerpoint_content_types(
                        data,
                        slide_count=len(slides),
                        dynamic_layout_numbers=[
                            layout.layout_number for layout in dynamic_layouts.values()
                        ],
                    )
                elif item == "ppt/presentation.xml" and slides:
                    data = _update_powerpoint_presentation_xml(data, slide_rel_ids)
                elif item == "ppt/_rels/presentation.xml.rels" and slides:
                    data = _update_powerpoint_presentation_rels_xml(
                        data,
                        slide_rel_ids,
                    )
                elif item == "ppt/slideMasters/slideMaster1.xml" and dynamic_layouts:
                    data = _update_powerpoint_slide_master_xml(
                        data,
                        [layout.layout_number for layout in dynamic_layouts.values()],
                    )
                elif (
                    item == "ppt/slideMasters/_rels/slideMaster1.xml.rels"
                    and dynamic_layouts
                ):
                    data = _update_powerpoint_slide_master_rels_xml(
                        data,
                        [layout.layout_number for layout in dynamic_layouts.values()],
                    )
                zout.writestr(item, data)

            for item, data in slide_parts.items():
                zout.writestr(item, data)
            for item, data in slide_rel_parts.items():
                zout.writestr(item, data)
            for layout in dynamic_layouts.values():
                zout.writestr(
                    f"ppt/slideLayouts/slideLayout{layout.layout_number}.xml",
                    layout.layout_xml,
                )
                zout.writestr(
                    f"ppt/slideLayouts/_rels/slideLayout{layout.layout_number}.xml.rels",
                    _build_powerpoint_slide_layout_rels_xml(),
                )

    return output_zip.getvalue()


def _dynamic_layout_for_slide(slide: dict[str, Any], dynamic_layouts: dict):
    decision = slide.get("layout_decision")
    if not isinstance(decision, dict):
        return None
    if decision.get("strategy") != "clone_required":
        return None
    clone_name = decision.get("clone_name")
    if not isinstance(clone_name, str):
        return None
    return dynamic_layouts.get(clone_name)


def _read_powerpoint_slide_size(template_bytes: bytes) -> tuple[int, int]:
    p_ns = "http://schemas.openxmlformats.org/presentationml/2006/main"
    with zipfile.ZipFile(BytesIO(template_bytes), "r") as zin:
        root = etree.fromstring(zin.read("ppt/presentation.xml"))
    sld_sz = root.find(f"{{{p_ns}}}sldSz")
    if sld_sz is None:
        return 9144000, 5143500
    return int(sld_sz.get("cx", "9144000")), int(sld_sz.get("cy", "5143500"))


def _is_powerpoint_slide_part(item: str) -> bool:
    return (
        item.startswith("ppt/slides/slide")
        and item.endswith(".xml")
        or item.startswith("ppt/slides/_rels/slide")
        and item.endswith(".xml.rels")
    )


def _layout_number_for_slide(layout_name: str) -> int:
    """Resolve a registry layout name to its slideLayoutN.xml part number."""
    standard = {
        "title_slide": 1,
        "title_content": 2,
        "section_header": 3,
        "two_content": 4,
        "comparison": 5,
        "title_only": 6,
        "blank": 7,
        "content_caption": 8,
        "picture_caption": 9,
        "vertical_text": 10,
        "vertical_title": 11,
    }
    if layout_name in standard:
        return standard[layout_name]

    from tokenmoulds.dtcg.layout_recipe_catalog import SEMANTIC_LAYOUT_SPECS

    spec = SEMANTIC_LAYOUT_SPECS.get(layout_name)
    if spec is not None:
        if spec.pptx_layout_number is not None:
            return spec.pptx_layout_number
        return standard.get(spec.fallback_standard_layout, 2)

    try:
        from tokenmoulds.archetypes.catalog import LAYOUT_FAMILIES

        for family in LAYOUT_FAMILIES.values():
            for offset, archetype in enumerate(family.archetypes):
                if archetype.name == layout_name:
                    return family.layout_number_start + offset
    except ImportError:
        pass

    return 2


def _build_powerpoint_slide_rels_xml(layout_number: int) -> bytes:
    rels_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    root = etree.Element(f"{{{rels_ns}}}Relationships", nsmap={None: rels_ns})
    rel = etree.SubElement(root, f"{{{rels_ns}}}Relationship")
    rel.set("Id", "rId1")
    rel.set(
        "Type",
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout",
    )
    rel.set("Target", f"../slideLayouts/slideLayout{layout_number}.xml")
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _build_powerpoint_slide_layout_rels_xml() -> bytes:
    rels_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    root = etree.Element(f"{{{rels_ns}}}Relationships", nsmap={None: rels_ns})
    rel = etree.SubElement(root, f"{{{rels_ns}}}Relationship")
    rel.set("Id", "rId1")
    rel.set(
        "Type",
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster",
    )
    rel.set("Target", "../slideMasters/slideMaster1.xml")
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _update_powerpoint_content_types(
    data: bytes,
    *,
    slide_count: int,
    dynamic_layout_numbers: list[int] | None = None,
) -> bytes:
    ct_ns = "http://schemas.openxmlformats.org/package/2006/content-types"
    root = etree.fromstring(data)

    for override in root.findall(f"{{{ct_ns}}}Override"):
        content_type = override.get("ContentType", "")
        if "presentationml.template.main+xml" in content_type:
            override.set(
                "ContentType",
                content_type.replace(
                    "presentationml.template.main+xml",
                    "presentationml.presentation.main+xml",
                ),
            )

    if slide_count:
        for override in list(root.findall(f"{{{ct_ns}}}Override")):
            part_name = override.get("PartName", "")
            if part_name.startswith("/ppt/slides/slide") and part_name.endswith(".xml"):
                root.remove(override)

        for idx in range(1, slide_count + 1):
            override = etree.SubElement(root, f"{{{ct_ns}}}Override")
            override.set("PartName", f"/ppt/slides/slide{idx}.xml")
            override.set(
                "ContentType",
                "application/vnd.openxmlformats-officedocument.presentationml.slide+xml",
            )

    existing_layout_parts = {
        override.get("PartName")
        for override in root.findall(f"{{{ct_ns}}}Override")
        if override.get("PartName", "").startswith("/ppt/slideLayouts/slideLayout")
    }
    for layout_number in dynamic_layout_numbers or []:
        part_name = f"/ppt/slideLayouts/slideLayout{layout_number}.xml"
        if part_name in existing_layout_parts:
            continue
        override = etree.SubElement(root, f"{{{ct_ns}}}Override")
        override.set("PartName", part_name)
        override.set(
            "ContentType",
            "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml",
        )
        existing_layout_parts.add(part_name)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_powerpoint_presentation_xml(data: bytes, slide_rel_ids: list[str]) -> bytes:
    p_ns = "http://schemas.openxmlformats.org/presentationml/2006/main"
    r_ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    root = etree.fromstring(data)

    sld_id_lst = root.find(f"{{{p_ns}}}sldIdLst")
    if sld_id_lst is None:
        sld_master_lst = root.find(f"{{{p_ns}}}sldMasterIdLst")
        sld_id_lst = etree.Element(f"{{{p_ns}}}sldIdLst")
        insert_at = (
            list(root).index(sld_master_lst) + 1 if sld_master_lst is not None else 0
        )
        root.insert(insert_at, sld_id_lst)

    for child in list(sld_id_lst):
        if child.tag == f"{{{p_ns}}}sldId":
            sld_id_lst.remove(child)

    for idx, rel_id in enumerate(slide_rel_ids, start=1):
        sld_id = etree.SubElement(sld_id_lst, f"{{{p_ns}}}sldId")
        sld_id.set("id", str(255 + idx))
        sld_id.set(f"{{{r_ns}}}id", rel_id)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_powerpoint_presentation_rels_xml(
    data: bytes,
    slide_rel_ids: list[str],
) -> bytes:
    rels_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    slide_rel_type = (
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"
    )
    root = etree.fromstring(data)

    for rel in list(root.findall(f"{{{rels_ns}}}Relationship")):
        if rel.get("Type") == slide_rel_type:
            root.remove(rel)

    for idx, rel_id in enumerate(slide_rel_ids, start=1):
        rel = etree.SubElement(root, f"{{{rels_ns}}}Relationship")
        rel.set("Id", rel_id)
        rel.set("Type", slide_rel_type)
        rel.set("Target", f"slides/slide{idx}.xml")

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_powerpoint_slide_master_xml(
    data: bytes,
    dynamic_layout_numbers: list[int],
) -> bytes:
    p_ns = "http://schemas.openxmlformats.org/presentationml/2006/main"
    r_ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    root = etree.fromstring(data)
    layout_id_lst = root.find(f"{{{p_ns}}}sldLayoutIdLst")
    if layout_id_lst is None:
        return data

    existing_rel_ids = {
        child.get(f"{{{r_ns}}}id")
        for child in layout_id_lst.findall(f"{{{p_ns}}}sldLayoutId")
    }
    existing_ids = [
        int(child.get("id", "0"))
        for child in layout_id_lst.findall(f"{{{p_ns}}}sldLayoutId")
        if child.get("id", "0").isdigit()
    ]
    next_id = max(existing_ids or [2147483648]) + 1

    for layout_number in dynamic_layout_numbers:
        rel_id = f"rId{layout_number}"
        if rel_id in existing_rel_ids:
            continue
        layout_id = etree.SubElement(layout_id_lst, f"{{{p_ns}}}sldLayoutId")
        layout_id.set("id", str(next_id))
        layout_id.set(f"{{{r_ns}}}id", rel_id)
        next_id += 1

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_powerpoint_slide_master_rels_xml(
    data: bytes,
    dynamic_layout_numbers: list[int],
) -> bytes:
    rels_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    layout_rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
    root = etree.fromstring(data)
    existing_ids = {rel.get("Id") for rel in root.findall(f"{{{rels_ns}}}Relationship")}

    for layout_number in dynamic_layout_numbers:
        rel_id = f"rId{layout_number}"
        if rel_id in existing_ids:
            continue
        rel = etree.SubElement(root, f"{{{rels_ns}}}Relationship")
        rel.set("Id", rel_id)
        rel.set("Type", layout_rel_type)
        rel.set("Target", f"../slideLayouts/slideLayout{layout_number}.xml")
        existing_ids.add(rel_id)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")
