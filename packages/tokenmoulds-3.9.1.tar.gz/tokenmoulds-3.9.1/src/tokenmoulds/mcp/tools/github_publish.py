"""GitHub PR publishing for compiled MCP artifacts."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping, Protocol

from tokenmoulds.mcp.artifact_plan import (
    ArtifactPlanError,
    artifact_plan_path,
    load_artifact_plan,
    safe_artifact_id,
)
from tokenmoulds.mcp.tools.artifact_review import (
    build_artifact_review_bundle,
)
from tokenmoulds.mcp.tools.review_bundle import persist_review_bundle

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


OPEN_GITHUB_PR_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact ID whose compiled outputs should be published",
        },
        "base": {
            "type": "string",
            "default": "main",
            "description": "Base branch to open the PR against",
        },
        "branch": {
            "type": "string",
            "description": "Optional explicit branch to create or update",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional explicit list of paths to stage in the PR branch",
        },
        "title": {
            "type": "string",
            "description": "Optional PR title. Defaults to the plan title.",
        },
        "reviewers": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional reviewers to request on the PR",
        },
    },
    "required": ["artifact_id"],
}

_COMPILATION_RESULT_NAME = "compile-result.json"
_QUALITY_RESULT_NAME = "quality-gate-result.json"
_REVIEW_BUNDLE_NAME = "review-bundle.json"
_BRANCH_RE = re.compile(r"^(?!-)(?!.*//)(?!.*\.\.)[A-Za-z0-9._/-]+(?<!/)$")


@dataclass(frozen=True)
class GitHubPullRequestRequest:
    """Structured request passed to a GitHub PR adapter."""

    artifact_id: str
    base: str
    branch: str
    title: str
    body: str
    paths: tuple[str, ...]
    reviewers: tuple[str, ...]
    repo_root: Path
    repository: str | None = None
    plan_path: str | None = None
    compile_result_path: str | None = None
    quality_gate_path: str | None = None
    review_bundle_path: str | None = None


class GitHubPullRequestAdapter(Protocol):
    """Publish a prepared artifact review bundle to GitHub."""

    def publish(self, request: GitHubPullRequestRequest) -> dict[str, Any]: ...


async def open_github_pr(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Open or update a GitHub pull request for a compiled artifact."""
    artifact_id_raw = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id_raw:
        return {"error": "artifact_id is required", "action": "open_github_pr"}

    try:
        artifact_id = safe_artifact_id(artifact_id_raw)
        plan = load_artifact_plan(server.output_path, artifact_id)
        compile_result = _load_json(
            _compile_result_path(server.output_path, artifact_id)
        )
        quality_result = _load_json(_quality_gate_path(server.output_path, artifact_id))
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "open_github_pr"}

    review_bundle = _load_or_build_review_bundle(
        artifact_id=artifact_id,
        plan=plan,
        compile_result=compile_result,
        quality_result=quality_result,
        output_root=server.output_path,
    )

    repo_root = _repository_root(server)
    base = str(arguments.get("base") or "main").strip() or "main"
    branch = _branch_name(
        artifact_id=artifact_id,
        explicit_branch=arguments.get("branch"),
    )
    title = _title_for_pr(arguments.get("title"), plan, review_bundle)
    reviewers = _normalize_string_list(arguments.get("reviewers"))
    explicit_paths = _normalize_paths(arguments.get("paths"), repo_root=repo_root)
    paths = _merge_unique_paths(
        [
            *explicit_paths,
            *(_artifact_paths_from_compile(compile_result)),
            *(
                Path(str(path))
                for path in compile_result.get("evidence_paths", [])
                if path
            ),
            _compile_result_path(server.output_path, artifact_id),
            _quality_gate_path(server.output_path, artifact_id),
            artifact_plan_path(server.output_path, artifact_id),
            _review_bundle_path(server.output_path, artifact_id),
            *(
                Path(str(path))
                for path in quality_result.get("evidence_paths", [])
                if path
            ),
            *(
                Path(str(path))
                for path in review_bundle.get("evidence_paths", [])
                if path
            ),
        ],
        repo_root=repo_root,
    )

    body = _build_pr_body(
        artifact_id=artifact_id,
        plan=plan.to_dict(),
        compile_result=compile_result,
        quality_result=quality_result,
        review_bundle=review_bundle,
        base=base,
        branch=branch,
        reviewers=reviewers,
        paths=paths,
    )

    request = GitHubPullRequestRequest(
        artifact_id=artifact_id,
        base=base,
        branch=branch,
        title=title,
        body=body,
        paths=paths,
        reviewers=reviewers,
        repo_root=repo_root,
        repository=_repository_for_plan(plan.to_dict()),
        plan_path=str(artifact_plan_path(server.output_path, artifact_id)),
        compile_result_path=str(_compile_result_path(server.output_path, artifact_id)),
        quality_gate_path=str(_quality_gate_path(server.output_path, artifact_id)),
        review_bundle_path=str(_review_bundle_path(server.output_path, artifact_id)),
    )

    adapter = getattr(server, "github_pr_adapter", None) or GhCliGitHubPrAdapter()
    try:
        result = adapter.publish(request)
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "open_github_pr"}

    if isinstance(result, dict):
        result.setdefault("action", "open_github_pr")
        result.setdefault("artifact_id", artifact_id)
        result.setdefault("branch", branch)
        result.setdefault("base", base)
        result.setdefault("title", title)
        result.setdefault("paths", [str(path) for path in paths])
        result.setdefault("review_bundle_path", request.review_bundle_path)
        result.setdefault("reviewers", list(reviewers))
        result.setdefault("pr_body", body)
        result.setdefault(
            "message", "Opened a GitHub pull request for the artifact review."
        )
        return result

    return {
        "success": True,
        "action": "open_github_pr",
        "artifact_id": artifact_id,
        "branch": branch,
        "base": base,
        "title": title,
        "paths": [str(path) for path in paths],
        "review_bundle_path": request.review_bundle_path,
        "reviewers": list(reviewers),
        "pr_body": body,
        "message": "Opened a GitHub pull request for the artifact review.",
    }


class GhCliGitHubPrAdapter:
    """Publish artifact review bundles using git and the GitHub CLI."""

    def publish(self, request: GitHubPullRequestRequest) -> dict[str, Any]:
        self._ensure_authenticated(request.repo_root)
        repo_info = self._repo_info(request.repo_root)
        with tempfile.TemporaryDirectory(
            prefix=f"tokenmoulds-{request.artifact_id}-"
        ) as tmp:
            worktree = Path(tmp)
            self._create_worktree(request.repo_root, worktree, request.branch)
            commit_sha = ""
            try:
                self._copy_paths(request.repo_root, worktree, request.paths)
                self._stage_paths(worktree, request.paths)
                commit_sha = self._commit(worktree, request.artifact_id, request.title)
                self._push(worktree, request.branch)
                pr = self._open_or_update_pr(
                    worktree=worktree,
                    repo_name=repo_info["nameWithOwner"],
                    request=request,
                )
            finally:
                self._remove_worktree(request.repo_root, worktree)
        return {
            "success": True,
            "repository": repo_info["nameWithOwner"],
            "repository_url": repo_info.get("url"),
            "branch": request.branch,
            "base": request.base,
            "title": request.title,
            "paths": [str(path) for path in request.paths],
            "reviewers": list(request.reviewers),
            "commit_sha": commit_sha,
            **pr,
        }

    def _ensure_authenticated(self, repo_root: Path) -> None:
        self._run(["gh", "auth", "status", "-h", "github.com"], cwd=repo_root)

    def _repo_info(self, repo_root: Path) -> dict[str, Any]:
        payload = self._run_json(
            [
                "gh",
                "repo",
                "view",
                "--json",
                "nameWithOwner,url,defaultBranchRef",
            ],
            cwd=repo_root,
        )
        name = payload.get("nameWithOwner")
        if not name:
            raise ArtifactPlanError(
                "Could not determine GitHub repository for PR publishing"
            )
        return payload

    def _create_worktree(self, repo_root: Path, worktree: Path, branch: str) -> None:
        self._run(
            ["git", "worktree", "add", "-B", branch, str(worktree), "HEAD"],
            cwd=repo_root,
        )

    def _copy_paths(
        self, repo_root: Path, worktree: Path, paths: tuple[str, ...]
    ) -> None:
        for path_str in paths:
            source = repo_root / path_str
            if not source.exists():
                continue
            destination = worktree / path_str
            destination.parent.mkdir(parents=True, exist_ok=True)
            if source.is_dir():
                shutil.copytree(source, destination, dirs_exist_ok=True)
            else:
                shutil.copy2(source, destination)

    def _stage_paths(self, worktree: Path, paths: tuple[str, ...]) -> None:
        if not paths:
            self._run(["git", "add", "-A"], cwd=worktree)
            return
        self._run(["git", "add", "-f", "--", *paths], cwd=worktree)

    def _commit(self, worktree: Path, artifact_id: str, title: str) -> str:
        self._run(
            [
                "git",
                "commit",
                "--allow-empty",
                "-m",
                f"artifact: {artifact_id}",
                "-m",
                title,
            ],
            cwd=worktree,
        )
        commit_sha = self._run_text(["git", "rev-parse", "HEAD"], cwd=worktree)
        return commit_sha.strip()

    def _push(self, worktree: Path, branch: str) -> None:
        self._run(["git", "push", "-u", "origin", branch], cwd=worktree)

    def _open_or_update_pr(
        self,
        *,
        worktree: Path,
        repo_name: str,
        request: GitHubPullRequestRequest,
    ) -> dict[str, Any]:
        existing = self._run_json_list(
            [
                "gh",
                "pr",
                "list",
                "--head",
                request.branch,
                "--state",
                "open",
                "--json",
                "number,url",
                "--repo",
                repo_name,
            ],
            cwd=worktree,
        )
        if existing:
            pr_number = existing[0].get("number")
            self._run(
                [
                    "gh",
                    "pr",
                    "edit",
                    str(pr_number),
                    "--title",
                    request.title,
                    "--body",
                    request.body,
                    "--repo",
                    repo_name,
                ],
                cwd=worktree,
            )
            return {
                "pr_number": pr_number,
                "pr_url": existing[0].get("url"),
                "message": "Updated the existing GitHub pull request.",
            }

        reviewers = [reviewer for reviewer in request.reviewers if reviewer]
        cmd = [
            "gh",
            "pr",
            "create",
            "--base",
            request.base,
            "--head",
            request.branch,
            "--title",
            request.title,
            "--body",
            request.body,
            "--repo",
            repo_name,
        ]
        if reviewers:
            for reviewer in reviewers:
                cmd.extend(["--reviewer", reviewer])
        created_url = self._run_text(cmd, cwd=worktree).strip()
        return {
            "pr_url": created_url or None,
            "message": "Created a new GitHub pull request.",
        }

    def _remove_worktree(self, repo_root: Path, worktree: Path) -> None:
        if not worktree.exists():
            return
        self._run(
            ["git", "worktree", "remove", "--force", str(worktree)], cwd=repo_root
        )

    def _run(self, cmd: list[str], *, cwd: Path) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
        if result.returncode != 0:
            raise ArtifactPlanError(
                f"Command failed: {' '.join(cmd)}\n{result.stderr.strip() or result.stdout.strip()}"
            )
        return result

    def _run_text(self, cmd: list[str], *, cwd: Path) -> str:
        return self._run(cmd, cwd=cwd).stdout

    def _run_json(self, cmd: list[str], *, cwd: Path) -> dict[str, Any]:
        result = self._run(cmd, cwd=cwd)
        payload = json.loads(result.stdout or "{}")
        if not isinstance(payload, dict):
            raise ArtifactPlanError(f"Expected JSON object from: {' '.join(cmd)}")
        return payload

    def _run_json_list(self, cmd: list[str], *, cwd: Path) -> list[dict[str, Any]]:
        result = self._run(cmd, cwd=cwd)
        payload = json.loads(result.stdout or "[]")
        if not isinstance(payload, list):
            raise ArtifactPlanError(f"Expected JSON array from: {' '.join(cmd)}")
        items: list[dict[str, Any]] = []
        for item in payload:
            if isinstance(item, dict):
                items.append(item)
        return items


def build_github_pr_request(
    *,
    artifact_id: str,
    base: str,
    branch: str,
    title: str,
    body: str,
    paths: tuple[str, ...],
    reviewers: tuple[str, ...],
    repo_root: Path,
    repository: str | None = None,
    plan_path: str | None = None,
    compile_result_path: str | None = None,
    quality_gate_path: str | None = None,
    review_bundle_path: str | None = None,
) -> GitHubPullRequestRequest:
    """Build a PR request object with normalized values."""
    return GitHubPullRequestRequest(
        artifact_id=safe_artifact_id(artifact_id),
        base=base.strip() or "main",
        branch=_validate_branch_name(branch),
        title=title.strip(),
        body=body,
        paths=paths,
        reviewers=reviewers,
        repo_root=repo_root,
        repository=repository,
        plan_path=plan_path,
        compile_result_path=compile_result_path,
        quality_gate_path=quality_gate_path,
        review_bundle_path=review_bundle_path,
    )


def _build_pr_body(
    *,
    artifact_id: str,
    plan: Mapping[str, Any],
    compile_result: Mapping[str, Any],
    quality_result: Mapping[str, Any],
    review_bundle: Mapping[str, Any],
    base: str,
    branch: str,
    reviewers: tuple[str, ...],
    paths: tuple[str, ...],
) -> str:
    status = str(quality_result.get("status") or "unknown")
    plan_summary = plan.get("intent_summary") or plan.get("summary") or ""
    output_formats = ", ".join(str(fmt) for fmt in plan.get("output_formats", []))
    lines = [
        f"Artifact: `{artifact_id}`",
        f"Base: `{base}`",
        f"Branch: `{branch}`",
        f"Quality: `{status}`",
    ]
    if plan.get("title"):
        lines.append(f"Plan: {plan['title']}")
    if plan_summary:
        lines.append("")
        lines.append(plan_summary)
    if output_formats:
        lines.append("")
        lines.append(f"Formats: {output_formats}")
    if reviewers:
        lines.append("")
        lines.append(f"Requested reviewers: {', '.join(reviewers)}")

    lines.extend(
        [
            "",
            "## Generated Paths",
            *[f"- `{path}`" for path in paths],
            "",
            "## Review Summary",
            f"- Review bundle: `{review_bundle.get('review_id', '')}`",
            f"- Review state: `{review_bundle.get('review_state') or review_bundle.get('proposal_state') or 'unknown'}`",
            f"- Evidence paths: {len(review_bundle.get('evidence_paths', []))}",
            f"- Compile warnings: {len(compile_result.get('warnings', []))}",
            f"- Quality warnings: {len(quality_result.get('warnings', []))}",
            "",
            "## Checklist",
            "- [ ] Review generated artifacts",
            "- [ ] Verify quality gate evidence",
            "- [ ] Approve or request changes",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def _branch_name(
    *,
    artifact_id: str,
    explicit_branch: Any,
    now: datetime | None = None,
) -> str:
    if explicit_branch:
        return _validate_branch_name(str(explicit_branch))
    timestamp = (now or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%SZ")
    return f"artifact/{safe_artifact_id(artifact_id)}-{timestamp}"


def _validate_branch_name(branch: str) -> str:
    candidate = branch.strip()
    if not candidate or not _BRANCH_RE.match(candidate):
        raise ArtifactPlanError(
            "branch must use only letters, numbers, dots, underscores, slashes, and hyphens"
        )
    return candidate


def _title_for_pr(
    explicit_title: Any,
    plan: Any,
    review_bundle: Mapping[str, Any],
) -> str:
    title = str(explicit_title or "").strip()
    if title:
        return title
    if isinstance(plan, Mapping):
        plan_title = str(plan.get("title") or "").strip()
        if plan_title:
            return plan_title
    summary = str(review_bundle.get("summary") or "").strip()
    if summary:
        return summary
    return "TokenMoulds artifact review"


def _repository_for_plan(plan: Mapping[str, Any]) -> str | None:
    repository = str(plan.get("repository") or "").strip()
    return repository or None


def _repository_root(server: "TokenMouldsServer") -> Path:
    root = getattr(server, "repository_root", None)
    if root:
        return Path(root)
    resolved = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        cwd=Path.cwd(),
    )
    if resolved.returncode != 0:
        raise ArtifactPlanError(
            "Could not determine repository root for GitHub publishing"
        )
    return Path(resolved.stdout.strip())


def _compile_result_path(output_root: Path, artifact_id: str) -> Path:
    return output_root / artifact_id / _COMPILATION_RESULT_NAME


def _quality_gate_path(output_root: Path, artifact_id: str) -> Path:
    return output_root / artifact_id / "quality" / _QUALITY_RESULT_NAME


def _review_bundle_path(output_root: Path, artifact_id: str) -> Path:
    return output_root / "review" / f"artifact-{artifact_id}" / _REVIEW_BUNDLE_NAME


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ArtifactPlanError(f"Artifact review input not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ArtifactPlanError(f"Artifact review input must be a JSON object: {path}")
    return payload


def _load_or_build_review_bundle(
    *,
    artifact_id: str,
    plan: Any,
    compile_result: Mapping[str, Any],
    quality_result: Mapping[str, Any],
    output_root: Path,
) -> dict[str, Any]:
    review_path = _review_bundle_path(output_root, artifact_id)
    if review_path.exists():
        return _load_json(review_path)
    bundle = build_artifact_review_bundle(
        artifact_id=artifact_id,
        review_state=str(plan.review_state),
        output_root=output_root,
        plan=plan.to_dict(),
        compile_result=compile_result,
        quality_result=quality_result,
    )
    persist_review_bundle(bundle, output_root=output_root)
    return bundle


def _artifact_paths_from_compile(compile_result: Mapping[str, Any]) -> tuple[Path, ...]:
    paths: list[Path] = []
    for artifact in compile_result.get("artifacts", []):
        if isinstance(artifact, Mapping) and artifact.get("path"):
            paths.append(Path(str(artifact["path"])))
    return tuple(paths)


def _normalize_paths(raw_paths: Any, *, repo_root: Path) -> tuple[str, ...]:
    if raw_paths is None:
        return ()
    if not isinstance(raw_paths, list):
        raise ArtifactPlanError("paths must be an array")
    normalized: list[str] = []
    for raw_path in raw_paths:
        path = Path(str(raw_path)).expanduser()
        if not path.is_absolute():
            path = repo_root / path
        try:
            relative = path.resolve().relative_to(repo_root.resolve())
        except ValueError as exc:
            raise ArtifactPlanError(
                f"paths must stay within the repository root: {raw_path!r}"
            ) from exc
        normalized.append(str(relative))
    return tuple(normalized)


def _merge_unique_paths(paths: list[Any], *, repo_root: Path) -> tuple[str, ...]:
    resolved: list[str] = []
    seen: set[str] = set()
    root = repo_root.resolve()
    for path in paths:
        if not path:
            continue
        if isinstance(path, str):
            path = Path(path)
        if not path.is_absolute():
            candidate = (repo_root / path).resolve()
        else:
            candidate = path.resolve()
        try:
            rel = candidate.relative_to(root)
        except ValueError:
            continue
        key = str(rel)
        if key in seen:
            continue
        seen.add(key)
        resolved.append(key)
    return tuple(resolved)


def _normalize_string_list(raw_values: Any) -> tuple[str, ...]:
    if raw_values is None:
        return ()
    if not isinstance(raw_values, list):
        raise ArtifactPlanError("reviewers must be an array")
    values: list[str] = []
    for raw in raw_values:
        value = str(raw).strip()
        if value and value not in values:
            values.append(value)
    return tuple(values)


def _branch_name_for_artifact(artifact_id: str) -> str:
    return _branch_name(artifact_id=artifact_id, explicit_branch=None)


__all__ = [
    "GitHubPullRequestAdapter",
    "GitHubPullRequestRequest",
    "GhCliGitHubPrAdapter",
    "OPEN_GITHUB_PR_SCHEMA",
    "_branch_name_for_artifact",
    "build_github_pr_request",
    "open_github_pr",
]
