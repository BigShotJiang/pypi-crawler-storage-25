"""JSON schemas for template generation MCP tools."""

from __future__ import annotations

from typing import Any, Dict

# ============================================================================
# JSON Schemas for MCP Tools
# ============================================================================

GENERATE_WORD_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in template (always enabled for production)",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate for ISO 29500 compliance",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_POWERPOINT_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in template",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate for ISO 29500 compliance",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_EXCEL_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in template",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate for ISO 29500 compliance",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_WRITER_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in template",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate for ODF compliance",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_IMPRESS_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in template",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate for ODF compliance",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_GOOGLE_DOCS_TEMPLATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached template if available",
        },
    },
}

GENERATE_THEME_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in theme",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached theme if available",
        },
    },
}

GENERATE_ALL_TEMPLATES_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand": {
            "type": "string",
            "description": "Brand identifier (optional, uses active brand)",
        },
        "formats": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": [
                    "word",
                    "powerpoint",
                    "excel",
                    "writer",
                    "impress",
                    "google_docs",
                    "theme",
                ],
            },
            "description": "Formats to generate (default: all)",
        },
        "embed_fonts": {
            "type": "boolean",
            "default": True,
            "description": "Embed fonts in templates",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate all templates",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached templates if available",
        },
    },
}


# ============================================================================
# Helper Functions
