"""Certificate management tools for add-in signing."""

from __future__ import annotations

import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, TYPE_CHECKING

from tokenmoulds.authenticode_signer import AuthenticodeSigner, get_signer_status
from tokenmoulds.mcp.tools.addin_common import (
    _escape_openssl_subject_value,
    _get_certificates_dir,
    _sanitize_filename,
)

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer

GENERATE_CERTIFICATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "common_name": {
            "type": "string",
            "description": "Certificate CN (e.g., 'My Organization Code Signing')",
        },
        "organization": {
            "type": "string",
            "description": "Organization name",
        },
        "validity_days": {
            "type": "integer",
            "default": 365,
            "description": "Certificate validity in days",
        },
        "key_size": {
            "type": "integer",
            "enum": [2048, 4096],
            "default": 2048,
            "description": "RSA key size",
        },
        "password": {
            "type": "string",
            "description": "Password to protect the .pfx file",
        },
        "output_path": {
            "type": "string",
            "description": "Where to save the certificate",
        },
    },
    "required": ["common_name", "password"],
}

LIST_CERTIFICATES_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "include_expired": {
            "type": "boolean",
            "default": False,
            "description": "Include expired certificates",
        },
    },
}


async def generate_self_signed_certificate(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Generate a self-signed code signing certificate.

    Uses OpenSSL to create a certificate suitable for signing
    Office VBA projects.

    Args:
        arguments: Tool arguments
        server: TokenMouldsServer instance

    Returns:
        Result with certificate info
    """
    import subprocess
    from datetime import timedelta

    common_name = arguments.get("common_name")
    if not common_name:
        return {"error": "Missing required 'common_name' parameter"}

    password = arguments.get("password")
    if not password:
        return {"error": "Missing required 'password' parameter"}

    organization = arguments.get("organization", "")
    validity_days = arguments.get("validity_days", 365)
    key_size = arguments.get("key_size", 2048)

    # Determine output path
    output_path = arguments.get("output_path")
    if output_path:
        cert_path = Path(output_path)
    else:
        certs_dir = _get_certificates_dir(server)
        safe_name = _sanitize_filename(common_name)
        cert_path = certs_dir / f"{safe_name}.pfx"

    try:
        # Check if OpenSSL is available
        result = subprocess.run(
            ["openssl", "version"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return {
                "error": "OpenSSL not found. Install OpenSSL to generate certificates.",
                "suggestion": "On macOS: brew install openssl",
            }

        # Generate certificate using OpenSSL
        with tempfile.TemporaryDirectory() as tmpdir:
            key_path = Path(tmpdir) / "private.key"
            crt_path = Path(tmpdir) / "certificate.crt"

            # Build subject string (escape values for slash-delimited format)
            cn_escaped = _escape_openssl_subject_value(common_name)
            subject_parts = [f"/CN={cn_escaped}"]
            if organization:
                org_escaped = _escape_openssl_subject_value(organization)
                subject_parts.append(f"/O={org_escaped}")
            subject = "".join(subject_parts)

            # Generate private key
            subprocess.run(
                [
                    "openssl",
                    "genrsa",
                    "-out",
                    str(key_path),
                    str(key_size),
                ],
                check=True,
                capture_output=True,
            )

            # Generate self-signed certificate
            subprocess.run(
                [
                    "openssl",
                    "req",
                    "-new",
                    "-x509",
                    "-key",
                    str(key_path),
                    "-out",
                    str(crt_path),
                    "-days",
                    str(validity_days),
                    "-subj",
                    subject,
                    "-addext",
                    "keyUsage=digitalSignature",
                    "-addext",
                    "extendedKeyUsage=codeSigning",
                ],
                check=True,
                capture_output=True,
            )

            # Create PFX
            cert_path.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                [
                    "openssl",
                    "pkcs12",
                    "-export",
                    "-out",
                    str(cert_path),
                    "-inkey",
                    str(key_path),
                    "-in",
                    str(crt_path),
                    "-password",
                    f"pass:{password}",
                ],
                check=True,
                capture_output=True,
            )

        # Calculate thumbprint (SHA-1 of DER-encoded certificate).
        # Extract the certificate from the PFX via openssl, then pipe
        # through ``openssl x509 -fingerprint`` to get the true thumbprint.
        extract_cert = subprocess.run(
            [
                "openssl",
                "pkcs12",
                "-in",
                str(cert_path),
                "-password",
                f"pass:{password}",
                "-clcerts",
                "-nokeys",
            ],
            capture_output=True,
        )
        fingerprint_result = subprocess.run(
            ["openssl", "x509", "-fingerprint", "-sha1", "-noout"],
            input=extract_cert.stdout,
            capture_output=True,
            text=True,
        )
        # Output looks like "sha1 Fingerprint=AA:BB:CC:..."
        fp_line = fingerprint_result.stdout.strip()
        thumbprint = fp_line.partition("=")[2].replace(":", "").upper()

        # Calculate validity dates
        valid_from = datetime.now(timezone.utc)
        valid_until = valid_from + timedelta(days=validity_days)

        # Add certificate to signer's store for easy access
        signer = AuthenticodeSigner()
        signer.cert_store.add_certificate(common_name, str(cert_path), password)

        return {
            "success": True,
            "action": "generate_self_signed_certificate",
            "certificate": {
                "path": str(cert_path),
                "common_name": common_name,
                "organization": organization,
                "valid_from": valid_from.isoformat(),
                "valid_until": valid_until.isoformat(),
                "thumbprint": thumbprint,
                "key_size": key_size,
            },
            "signer_backend": signer.backend_name,
            "message": f"Generated self-signed certificate '{common_name}' valid for {validity_days} days.",
            "warning": "Self-signed certificates are for development only. Use organizational certificates for production.",
        }

    except subprocess.CalledProcessError as e:
        return {
            "error": f"OpenSSL command failed: {e.stderr.decode() if e.stderr else str(e)}",
        }
    except Exception as e:
        return {
            "error": f"Failed to generate certificate: {str(e)}",
        }


async def list_certificates(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """List available code signing certificates.

    Args:
        arguments: Tool arguments
        server: TokenMouldsServer instance

    Returns:
        List of certificate info and signer status
    """
    certs_dir = _get_certificates_dir(server)

    certificates = []

    for cert_file in certs_dir.glob("*.pfx"):
        try:
            info = {
                "path": str(cert_file),
                "name": cert_file.stem,
                "size_bytes": cert_file.stat().st_size,
                "created": datetime.fromtimestamp(
                    cert_file.stat().st_ctime
                ).isoformat(),
            }
            certificates.append(info)
        except Exception:
            continue

    # Get signer status and recommendations
    signer_status = get_signer_status()

    return {
        "success": True,
        "action": "list_certificates",
        "certificates_dir": str(certs_dir),
        "count": len(certificates),
        "certificates": certificates,
        "signer": {
            "available": signer_status.get("available"),
            "backend": signer_status.get("backend"),
            "platform": signer_status.get("platform"),
        },
        "recommendations": signer_status.get("recommendations", {}).get(
            "installation", []
        )[:3],
    }
