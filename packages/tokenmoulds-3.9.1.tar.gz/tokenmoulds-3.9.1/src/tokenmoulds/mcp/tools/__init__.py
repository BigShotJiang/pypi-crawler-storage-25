"""Public API for MCP tool callables and schemas."""

from __future__ import annotations

from typing import Any

from tokenmoulds._lazy import lazy_dir, resolve_lazy_attribute

__all__ = [
    "create_document",
    "configure_brand",
    "list_styles",
    "DOCUMENT_TOOL_SCHEMA",
    "BRAND_TOOL_SCHEMA",
    "STYLES_TOOL_SCHEMA",
]


_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "create_document": (".document", "create_document"),
    "DOCUMENT_TOOL_SCHEMA": (".document", "DOCUMENT_TOOL_SCHEMA"),
    "configure_brand": (".brand", "configure_brand"),
    "list_styles": (".brand", "list_styles"),
    "BRAND_TOOL_SCHEMA": (".brand", "BRAND_TOOL_SCHEMA"),
    "STYLES_TOOL_SCHEMA": (".brand", "STYLES_TOOL_SCHEMA"),
}


def __getattr__(name: str) -> Any:
    return resolve_lazy_attribute(
        name,
        module_globals=globals(),
        package=__package__ or __name__,
        lazy_imports=_LAZY_IMPORTS,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
