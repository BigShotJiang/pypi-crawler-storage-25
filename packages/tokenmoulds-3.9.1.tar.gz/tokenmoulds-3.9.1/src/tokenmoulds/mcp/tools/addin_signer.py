"""Signed add-in and macro generation for TokenMoulds MCP."""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, TYPE_CHECKING

from tokenmoulds.authenticode_signer import AuthenticodeSigner, get_signer_status
from tokenmoulds.macros import compile_and_inject_vba
from tokenmoulds.mcp.cache import TemplateFormat
from tokenmoulds.mcp.tools.addin_common import _sanitize_filename

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


@dataclass(frozen=True)
class _AddinFormatInfo:
    macro_ext: str
    content_type_old: bytes
    content_type_new: bytes
    host_name: str


_ADDIN_FORMATS: Dict[TemplateFormat, _AddinFormatInfo] = {
    TemplateFormat.WORD: _AddinFormatInfo(
        macro_ext=".docm",
        content_type_old=b"wordprocessingml.template.main+xml",
        content_type_new=b"wordprocessingml.document.macroEnabled.main+xml",
        host_name="Document",
    ),
    TemplateFormat.EXCEL: _AddinFormatInfo(
        macro_ext=".xlam",
        content_type_old=b"spreadsheetml.template.main+xml",
        content_type_new=b"spreadsheetml.addin.macroEnabled.main+xml",
        host_name="Workbook",
    ),
    TemplateFormat.POWERPOINT: _AddinFormatInfo(
        macro_ext=".ppam",
        content_type_old=b"presentationml.template.main+xml",
        content_type_new=b"presentationml.addin.macroEnabled.main+xml",
        host_name="Presentation",
    ),
}

_DEFAULT_FORMAT_INFO = _AddinFormatInfo(
    macro_ext=".docm",
    content_type_old=b"",
    content_type_new=b"",
    host_name="Document",
)


# ============================================================================
# JSON Schemas for MCP Tools
# ============================================================================

CREATE_VBA_ADDIN_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "description": "Add-in name (used for filename and internal references)",
        },
        "description": {
            "type": "string",
            "description": "Add-in description",
        },
        "target": {
            "type": "string",
            "enum": ["word", "excel", "powerpoint"],
            "description": "Target Office application",
        },
        "vba_code": {
            "type": "string",
            "description": "VBA source code for the add-in",
        },
        "modules": {
            "type": "array",
            "description": "VBA modules (alternative to single vba_code)",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Module name"},
                    "type": {
                        "type": "string",
                        "enum": ["standard", "class", "form"],
                        "description": "Module type",
                    },
                    "code": {"type": "string", "description": "Module source code"},
                },
                "required": ["name", "code"],
            },
        },
        "sign": {
            "type": "boolean",
            "default": True,
            "description": "Sign the add-in (requires certificate)",
        },
        "certificate_path": {
            "type": "string",
            "description": "Path to .pfx certificate (uses self-signed if not provided)",
        },
        "certificate_password": {
            "type": "string",
            "description": "Certificate password",
        },
        "brand_name": {
            "type": "string",
            "description": "Brand for theming the add-in UI",
        },
    },
    "required": ["name", "target"],
}


async def create_vba_addin(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a VBA add-in for Office applications.

    Uses TokenMoulds VBA compilation and signing infrastructure:
    - vba_compiler.py: Compiles source to vbaProject.bin
    - authenticode_signer.py: Signs with certificate
    - macros.py: Injects into template

    Args:
        arguments: Tool arguments
        server: TokenMouldsServer instance

    Returns:
        Result with add-in path and info
    """
    name = arguments.get("name")
    if not name:
        return {"error": "Missing required 'name' parameter"}

    target = arguments.get("target")
    if not target:
        return {"error": "Missing required 'target' parameter"}

    description = arguments.get("description", f"{name} Add-in")
    vba_code = arguments.get("vba_code", "")
    modules = arguments.get("modules", [])
    should_sign = arguments.get("sign", True)
    brand_name = arguments.get("brand_name") or server.active_brand

    # Resolve format
    try:
        template_format = TemplateFormat(target)
    except ValueError:
        template_format = TemplateFormat.WORD
    fmt_info = _ADDIN_FORMATS.get(template_format, _DEFAULT_FORMAT_INFO)

    # Create output path
    safe_name = _sanitize_filename(name)
    output_file = server.output_path / f"{safe_name}{fmt_info.macro_ext}"

    try:
        # Check for cached template
        template_bytes = None
        if brand_name and brand_name in server.loaded_tokens:
            tokens = server.loaded_tokens[brand_name]
            token_hash = server.cache_manager.compute_token_hash(tokens)
            template_bytes = server.cache_manager.get_template(
                brand_name, template_format, token_hash
            )

        if template_bytes is None:
            return {
                "error": f"No {target} template available.",
                "suggestion": f"Generate a template first with generate_{target}_template.",
            }

        # Write template to temp file for processing
        with tempfile.NamedTemporaryFile(suffix=".dotx", delete=False) as tmp:
            tmp.write(template_bytes)
            template_path = Path(tmp.name)

        signed = False
        modules_compiled = 0

        # If we have VBA code/modules, compile and inject
        if vba_code or modules:
            # Create temp directory for VBA source files
            with tempfile.TemporaryDirectory() as vba_dir:
                vba_source_dir = Path(vba_dir)

                # Write VBA code to .bas file
                if vba_code:
                    main_module = vba_source_dir / "Main.bas"
                    main_module.write_text(vba_code, encoding="utf-8")
                    modules_compiled += 1

                # Write additional modules
                for mod in modules:
                    mod_name = mod.get("name", "Module1")
                    mod_type = mod.get("type", "standard")
                    mod_code = mod.get("code", "")

                    ext_map = {"standard": ".bas", "class": ".cls", "form": ".frm"}
                    mod_ext = ext_map.get(mod_type, ".bas")

                    mod_file = vba_source_dir / f"{mod_name}{mod_ext}"
                    mod_file.write_text(mod_code, encoding="utf-8")
                    modules_compiled += 1

                # Get signing certificate if provided
                cert_path = arguments.get("certificate_path")
                cert_password = arguments.get("certificate_password")

                # Use TokenMoulds compile_and_inject_vba pipeline
                success = compile_and_inject_vba(
                    template=template_path,
                    vba_source_dir=vba_source_dir,
                    output=output_file,
                    project_config={"name": name},
                    certificate_path=Path(cert_path) if cert_path else None,
                    certificate_password=cert_password,
                )

                if not success:
                    return {
                        "error": "VBA compilation failed",
                        "suggestion": "Check VBA source code syntax and ensure vbaProject-Compiler is installed",
                    }

                # Check if signing was successful
                if should_sign and cert_path:
                    signer = AuthenticodeSigner()
                    signed = signer.is_available
        else:
            # No VBA code - just convert template to macro-enabled format
            _convert_template_to_macro_enabled(template_path, output_file, fmt_info)

        # Clean up temp template
        template_path.unlink(missing_ok=True)

        # Get signer status for info
        signer_status = get_signer_status()

        return {
            "success": True,
            "action": "create_vba_addin",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "name": name,
            "description": description,
            "target": target,
            "modules_compiled": modules_compiled,
            "signed": signed,
            "brand_used": brand_name,
            "file_size_kb": round(output_file.stat().st_size / 1024, 1),
            "signer_backend": signer_status.get("backend"),
            "message": f"Created {target.title()} add-in '{name}' with {modules_compiled} VBA modules.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create add-in: {str(e)}",
            "name": name,
        }


def _convert_template_to_macro_enabled(
    template_path: Path,
    output_path: Path,
    fmt_info: _AddinFormatInfo,
) -> None:
    """Convert template to macro-enabled format (without VBA code)."""
    import zipfile
    from io import BytesIO

    template_bytes = template_path.read_bytes()
    input_zip = BytesIO(template_bytes)
    output_zip = BytesIO()

    old_ct = fmt_info.content_type_old
    new_ct = fmt_info.content_type_new

    with zipfile.ZipFile(input_zip, "r") as zin:
        with zipfile.ZipFile(
            output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9
        ) as zout:
            for item in zin.namelist():
                data = zin.read(item)

                if item == "[Content_Types].xml" and old_ct and new_ct:
                    data = data.replace(old_ct, new_ct)

                zout.writestr(item, data)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(output_zip.getvalue())
