"""Quality gate orchestration for compiled MCP artifacts."""

from __future__ import annotations

import json
import hashlib
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Mapping

from tokenmoulds.artifact_intent import artifact_intent_from_mapping
from tokenmoulds.mcp.artifact_plan import (
    ArtifactPlanError,
    artifact_plan_path,
    artifact_plan_from_mapping,
    load_artifact_plan,
    safe_artifact_id,
)
from tokenmoulds.mcp.validation import validate_template
from tokenmoulds.validation.soffice import render_with_soffice

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


QUALITY_GATE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact ID whose compiled outputs should be validated",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional explicit list of artifact paths to validate",
        },
        "checks": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": [
                    "package_validation",
                    "artifact_intent",
                    "render_validation",
                    "plan_validation",
                ],
            },
            "description": "Optional subset of checks to run; defaults to all",
        },
        "strict_mode": {
            "type": "boolean",
            "default": True,
            "description": "Run strict package validation and deep OOXML checks when available",
        },
        "extract_structure": {
            "type": "boolean",
            "default": False,
            "description": "Return package structure from the underlying template validator",
        },
        "render_validation": {
            "type": "boolean",
            "default": True,
            "description": "Attempt LibreOffice render validation for supported presentation formats",
        },
        "soffice_path": {
            "type": "string",
            "description": "Optional explicit soffice path for render validation",
        },
        "render_timeout_s": {
            "type": "number",
            "default": 90.0,
            "description": "LibreOffice render timeout in seconds",
        },
    },
    "required": ["artifact_id"],
}

_COMPILATION_RESULT_NAME = "compile-result.json"
_QUALITY_RESULT_NAME = "quality-gate-result.json"
_OOXML_INTENT_PART = "customXml/tokenmoulds-intent.json"
_ODF_INTENT_PART = "tokenmoulds/intent.json"
_RENDER_SUPPORTED = {"pptx", "potx", "odp", "otp"}
_DEFAULT_CHECKS = (
    "plan_validation",
    "package_validation",
    "artifact_intent",
    "render_validation",
)


async def run_document_quality_gate(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Validate compiled artifacts and persist a quality-gate report."""
    artifact_id_raw = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id_raw:
        return {
            "error": "artifact_id is required",
            "action": "run_document_quality_gate",
        }

    try:
        artifact_id = safe_artifact_id(artifact_id_raw)
        compiled = _load_compilation_result(server.output_path, artifact_id)
        artifact_entries = _resolve_artifacts(arguments, compiled, server.output_path)
        checks = _requested_checks(arguments)
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "run_document_quality_gate"}

    strict_mode = bool(arguments.get("strict_mode", True))
    extract_structure = bool(arguments.get("extract_structure", False))
    render_enabled = bool(arguments.get("render_validation", True))
    soffice_path = arguments.get("soffice_path")
    render_timeout_s = arguments.get("render_timeout_s", 90.0)
    plan = _load_plan_if_available(server.output_path, artifact_id)

    report_artifacts: list[dict[str, Any]] = []
    evidence_paths: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []
    check_summaries: dict[str, dict[str, Any]] = {
        "plan_validation": {"status": "skipped"},
        "package_validation": {"status": "skipped"},
        "artifact_intent": {"status": "skipped"},
        "render_validation": {"status": "skipped"},
    }

    if plan is not None:
        plan_check = _plan_validation_summary(plan, compiled, server.output_path)
        check_summaries["plan_validation"] = plan_check
        evidence_paths.extend(plan_check.get("evidence_paths", []))
        if plan_check["status"] == "failed":
            errors.extend(plan_check.get("errors", []))
        elif plan_check["status"] == "warning":
            warnings.extend(plan_check.get("warnings", []))

    for artifact in artifact_entries:
        path = artifact["path"]
        fmt = artifact["format"]
        artifact_result: dict[str, Any] = {
            "format": fmt,
            "path": str(path),
            "package_validation": {"status": "skipped"},
            "artifact_intent": {"status": "skipped"},
            "render_validation": {"status": "skipped"},
        }
        artifact_status = "passed"

        if "package_validation" in checks:
            package_result = _package_validation_summary(
                path,
                fmt,
                strict_mode=strict_mode,
                extract_structure=extract_structure,
            )
            artifact_result["package_validation"] = package_result
            evidence_paths.append(package_result["report_path"])
            evidence_paths.append(str(path))
            if package_result["status"] == "failed":
                artifact_status = "failed"
                errors.extend(package_result.get("errors", []))
            elif package_result["status"] == "warning" and artifact_status != "failed":
                artifact_status = "warning"
                warnings.extend(package_result.get("warnings", []))

        if "artifact_intent" in checks:
            intent_result = _artifact_intent_summary(path, fmt, compiled)
            artifact_result["artifact_intent"] = intent_result
            if intent_result.get("report_path"):
                evidence_paths.append(intent_result["report_path"])
            if intent_result["status"] == "failed":
                artifact_status = "failed"
                errors.extend(intent_result.get("errors", []))
            elif intent_result["status"] == "warning" and artifact_status != "failed":
                artifact_status = "warning"
                warnings.extend(intent_result.get("warnings", []))

        if render_enabled and "render_validation" in checks:
            render_result = _render_summary(path, fmt, soffice_path, render_timeout_s)
            artifact_result["render_validation"] = render_result
            evidence_paths.extend(render_result.get("evidence_paths", []))
            if render_result["status"] == "failed":
                artifact_status = "failed"
                errors.extend(render_result.get("errors", []))
            elif render_result["status"] == "warning" and artifact_status != "failed":
                artifact_status = "warning"
                warnings.extend(render_result.get("warnings", []))
        elif "render_validation" in checks:
            artifact_result["render_validation"] = {
                "status": "skipped",
                "reason": "render_validation disabled",
            }

        artifact_result["status"] = artifact_status
        report_artifacts.append(artifact_result)

    final_status = _aggregate_status(report_artifacts, check_summaries)
    success = final_status != "failed"
    quality_root = server.output_path / artifact_id / "quality"
    quality_root.mkdir(parents=True, exist_ok=True)
    report_path = quality_root / _QUALITY_RESULT_NAME

    payload: dict[str, Any] = {
        "success": success,
        "action": "run_document_quality_gate",
        "artifact_id": artifact_id,
        "status": final_status,
        "compile_result_path": str(
            _compile_result_path(server.output_path, artifact_id)
        ),
        "plan_path": str(artifact_plan_path(server.output_path, artifact_id)),
        "artifacts": report_artifacts,
        "checks": _checks_payload(check_summaries, checks),
        "warnings": list(dict.fromkeys(warnings)),
        "errors": list(dict.fromkeys(errors)) or None,
        "evidence_paths": list(dict.fromkeys(evidence_paths)),
    }
    payload["quality_gate_result_path"] = str(report_path)
    payload["artifact_id_hash"] = hashlib.sha256(
        artifact_id.encode("utf-8")
    ).hexdigest()
    report_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    payload["message"] = (
        f"Quality gate {final_status} for {len(report_artifacts)} artifact(s)."
    )
    payload["next_tools"] = (
        ["create_artifact_review_bundle"]
        if success
        else ["validate_artifact_plan", "compile_artifact"]
    )
    return payload


def _requested_checks(arguments: Mapping[str, Any]) -> tuple[str, ...]:
    raw_checks = arguments.get("checks")
    if raw_checks is None:
        return _DEFAULT_CHECKS
    if not isinstance(raw_checks, list):
        raise ArtifactPlanError("checks must be an array")

    checks: list[str] = []
    for item in raw_checks:
        check = str(item).strip().lower()
        if check and check not in checks:
            if check not in _DEFAULT_CHECKS:
                raise ArtifactPlanError(f"unsupported check: {check!r}")
            checks.append(check)
    if not checks:
        raise ArtifactPlanError("checks must not be empty")
    return tuple(checks)


def _load_compilation_result(output_root: Path, artifact_id: str) -> dict[str, Any]:
    path = _compile_result_path(output_root, artifact_id)
    if not path.exists():
        raise ArtifactPlanError(f"compile result not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ArtifactPlanError(f"compile result must be a JSON object: {path}")
    return payload


def _resolve_artifacts(
    arguments: Mapping[str, Any],
    compiled: Mapping[str, Any],
    output_root: Path,
) -> list[dict[str, Any]]:
    raw_paths = arguments.get("paths")
    paths: list[Path]
    if raw_paths is None:
        artifacts = compiled.get("artifacts", [])
        if not isinstance(artifacts, list) or not artifacts:
            raise ArtifactPlanError("compile result does not list any artifacts")
        resolved: list[dict[str, Any]] = []
        for item in artifacts:
            if not isinstance(item, Mapping):
                continue
            path = Path(str(item.get("path") or ""))
            if not path.is_absolute():
                path = output_root / path
            fmt = str(item.get("format") or path.suffix.lstrip(".")).lower()
            resolved.append({"path": path, "format": fmt})
        return resolved

    if not isinstance(raw_paths, list):
        raise ArtifactPlanError("paths must be an array")

    paths = []
    for item in raw_paths:
        raw = Path(str(item))
        if not raw.is_absolute():
            raw = output_root / raw
        paths.append(raw)
    if not paths:
        raise ArtifactPlanError("paths must not be empty")
    return [{"path": path, "format": path.suffix.lstrip(".").lower()} for path in paths]


def _load_plan_if_available(
    output_root: Path, artifact_id: str
) -> dict[str, Any] | None:
    path = artifact_plan_path(output_root, artifact_id)
    if not path.exists():
        return None
    try:
        plan = load_artifact_plan(output_root, artifact_id)
    except ArtifactPlanError:
        return None
    return plan.to_dict()


def _plan_validation_summary(
    plan: Mapping[str, Any],
    compiled: Mapping[str, Any],
    output_root: Path,
) -> dict[str, Any]:
    plan_sha = str(compiled.get("artifact_plan_sha256") or "")
    current_sha = artifact_plan_from_mapping(plan).sha256()
    status = "passed" if not plan_sha or plan_sha == current_sha else "failed"
    evidence_paths: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []
    summary: dict[str, Any] = {
        "status": status,
        "plan_sha256": current_sha,
        "expected_sha256": plan_sha or None,
        "warnings": warnings,
        "errors": errors,
        "evidence_paths": evidence_paths,
    }
    if status == "failed":
        errors.append("Persisted ArtifactPlan hash does not match compiled output")
    else:
        evidence_paths.append(
            str(artifact_plan_path(output_root, str(plan.get("artifact_id") or "")))
        )
    return summary


def _package_validation_summary(
    path: Path,
    fmt: str,
    *,
    strict_mode: bool,
    extract_structure: bool,
) -> dict[str, Any]:
    data = path.read_bytes()
    validation_format = _validation_format_for_extension(fmt)
    result = validate_template(
        data,
        format_hint=validation_format,
        strict_mode=strict_mode,
        extract_structure=extract_structure,
    )
    report_path = path.parent.parent / "quality" / f"{path.stem}.validation.json"
    payload = result.to_dict()
    payload["report_path"] = str(report_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    status = "passed" if result.valid else "failed"
    if result.warnings and status == "passed":
        status = "warning"
    return {
        "status": status,
        "format": result.format,
        "valid": result.valid,
        "iso_compliant": result.iso_compliant,
        "errors": list(result.errors),
        "warnings": list(result.warnings),
        "info": list(result.info),
        "structure": result.structure,
        "report_path": str(report_path),
        "evidence_paths": [str(report_path)],
    }


def _artifact_intent_summary(
    path: Path,
    fmt: str,
    compiled: Mapping[str, Any],
) -> dict[str, Any]:
    if not zipfile.is_zipfile(path):
        return {
            "status": "failed",
            "errors": ["Artifact is not a ZIP package"],
            "warnings": [],
            "report_path": None,
        }

    part = (
        _OOXML_INTENT_PART
        if fmt
        in {
            "docx",
            "dotx",
            "pptx",
            "potx",
            "xlsx",
            "xltx",
            "word",
            "word_template",
            "powerpoint",
            "powerpoint_template",
            "excel",
            "excel_template",
        }
        else _ODF_INTENT_PART
    )
    with zipfile.ZipFile(path, "r") as zf:
        if part not in zf.namelist():
            return {
                "status": "warning",
                "errors": [],
                "warnings": [f"Missing embedded artifact intent: {part}"],
                "report_path": None,
            }
        payload = json.loads(zf.read(part))

    intent = artifact_intent_from_mapping(payload)
    current_sha = intent.sha256()
    expected_sha = str(compiled.get("artifact_intent_sha256") or "")
    status = "passed" if not expected_sha or current_sha == expected_sha else "failed"
    errors: list[str] = []
    warnings: list[str] = []
    result: dict[str, Any] = {
        "status": status,
        "artifact_intent_sha256": current_sha,
        "expected_sha256": expected_sha or None,
        "warnings": warnings,
        "errors": errors,
        "report_path": None,
    }
    if status == "failed":
        errors.append("Embedded artifact intent hash does not match compile output")
    return result


def _render_summary(
    path: Path,
    fmt: str,
    soffice_path: str | None,
    render_timeout_s: float | int | None,
) -> dict[str, Any]:
    render_format = _render_format_for_extension(fmt)
    if render_format is None:
        return {
            "format": fmt,
            "status": "skipped",
            "renderer": "soffice",
            "command_path": None,
            "engine_version": None,
            "images": [],
            "error": f"LibreOffice PNG render is not configured for format: {fmt}",
            "warnings": [f"LibreOffice PNG render is not configured for format: {fmt}"],
            "evidence_paths": [],
        }
    report = render_with_soffice(
        path.read_bytes(),
        render_format,
        path.parent.parent / "quality" / "render",
        soffice_path=soffice_path,
        timeout=float(render_timeout_s) if render_timeout_s is not None else None,
    )
    payload = report.to_dict()
    status = report.status
    if status == "skipped":
        payload["warnings"] = [report.error] if report.error else []
    elif status == "failed":
        payload["errors"] = (
            [report.error] if report.error else ["Render validation failed"]
        )
    evidence_paths = [image.path for image in report.images]
    payload["evidence_paths"] = evidence_paths
    payload["status"] = status if status in {"passed", "failed"} else "warning"
    return payload


def _validation_format_for_extension(fmt: str) -> str:
    fmt = fmt.lower()
    if fmt in {"docx", "dotx"}:
        return "word"
    if fmt in {"pptx", "potx"}:
        return "powerpoint"
    if fmt in {"xlsx", "xltx"}:
        return "excel"
    if fmt == "odt":
        return "writer"
    if fmt == "odp":
        return "impress"
    return fmt


def _render_format_for_extension(fmt: str) -> str | None:
    fmt = fmt.lower()
    if fmt in _RENDER_SUPPORTED:
        return fmt
    if fmt in {"pptx", "potx"}:
        return "pptx"
    if fmt in {"odp", "otp"}:
        return "odp"
    return None


def _compile_result_path(output_root: Path, artifact_id: str) -> Path:
    return output_root / artifact_id / _COMPILATION_RESULT_NAME


def _checks_payload(
    summaries: Mapping[str, Mapping[str, Any]],
    checks: tuple[str, ...],
) -> list[dict[str, Any]]:
    return [
        {"name": name, **dict(summaries.get(name, {"status": "skipped"}))}
        for name in checks
    ]


def _aggregate_status(
    artifacts: list[dict[str, Any]],
    checks: Mapping[str, Mapping[str, Any]],
) -> str:
    statuses = [artifact.get("status", "passed") for artifact in artifacts]
    statuses.extend(summary.get("status", "skipped") for summary in checks.values())
    if any(status == "failed" for status in statuses):
        return "failed"
    if any(status == "warning" for status in statuses):
        return "warning"
    if artifacts:
        return "passed"
    return "skipped"
