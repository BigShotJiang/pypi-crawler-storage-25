"""Translate python-pptx-shaped intent into TokenMoulds MCP arguments."""

from __future__ import annotations

import ast
from typing import TYPE_CHECKING, Any, Dict

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


TRANSLATE_PYTHON_PPTX_INTENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "code": {
            "type": "string",
            "description": (
                "Small python-pptx-style snippet to translate. The code is "
                "parsed but never executed."
            ),
        },
        "operations": {
            "type": "array",
            "description": (
                "Structured python-pptx-style slide operations when code is "
                "not available."
            ),
            "items": {
                "type": "object",
                "properties": {
                    "layout_index": {"type": "integer"},
                    "layout": {"type": "string"},
                    "title": {"type": "string"},
                    "body": {"type": "string"},
                    "subtitle": {"type": "string"},
                    "placeholders": {
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
            },
        },
        "title": {
            "type": "string",
            "description": "Presentation title override",
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier to pass to create_powerpoint_document",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
        "layout_map": {
            "type": "object",
            "description": (
                "Optional mapping from python-pptx slide_layouts indices to "
                "TokenMoulds layout names"
            ),
            "additionalProperties": {"type": "string"},
        },
    },
}

_DEFAULT_LAYOUT_MAP: dict[int, str] = {
    0: "title_slide",
    1: "title_content",
    2: "section_header",
    3: "two_content",
    4: "comparison",
    5: "title_only",
    6: "blank",
    7: "content_caption",
    8: "picture_caption",
}
_DEFAULT_PLACEHOLDER_MAP: dict[int, str] = {
    0: "title",
    1: "body",
    2: "subtitle",
}
_MAX_CODE_CHARS = 20_000


async def translate_python_pptx_intent(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Translate familiar python-pptx operations to TokenMoulds MCP args."""
    del server
    layout_map = _layout_map(arguments.get("layout_map"))
    warnings: list[str] = []

    code = arguments.get("code")
    if isinstance(code, str) and code.strip():
        if len(code) > _MAX_CODE_CHARS:
            return {"error": f"code exceeds {_MAX_CODE_CHARS} characters"}
        try:
            slides, inferred_filename, parse_warnings = _translate_code(
                code, layout_map
            )
        except SyntaxError as exc:
            return {
                "error": f"Could not parse python-pptx snippet: {exc.msg}",
                "line": exc.lineno,
            }
        warnings.extend(parse_warnings)
    else:
        slides = _translate_operations(arguments.get("operations"), layout_map)
        inferred_filename = None

    if not slides:
        return {
            "error": "No translatable slides found",
            "suggestion": (
                "Provide a small python-pptx snippet with add_slide() and "
                ".text assignments, or pass structured operations."
            ),
        }

    title = str(arguments.get("title") or _infer_title(slides)).strip()
    filename = arguments.get("filename") or inferred_filename
    create_args: Dict[str, Any] = {
        "title": title,
        "slides": slides,
    }
    brand_name = arguments.get("brand_name")
    if brand_name:
        create_args["brand_name"] = str(brand_name)
    if filename:
        create_args["filename"] = _strip_pptx_suffix(str(filename))

    return {
        "success": True,
        "action": "translate_python_pptx_intent",
        "target_tool": "create_powerpoint_document",
        "create_powerpoint_document_args": create_args,
        "translated_slides": slides,
        "warnings": warnings,
        "guidance_for_llm": (
            "Call create_powerpoint_document with create_powerpoint_document_args. "
            "Do not execute the original python-pptx code; TokenMoulds owns "
            "layouts, geometry, brand rules, and package validation."
        ),
    }


def _translate_code(
    code: str, layout_map: dict[int, str]
) -> tuple[list[dict[str, Any]], str | None, list[str]]:
    tree = ast.parse(code)
    slides: list[dict[str, Any]] = []
    slide_vars: dict[str, dict[str, Any]] = {}
    layout_vars: dict[str, str] = {}
    shape_vars: dict[str, tuple[str, str]] = {}
    warnings: list[str] = []
    filename: str | None = None

    for statement in tree.body:
        if isinstance(statement, ast.Assign):
            _handle_assign(
                statement,
                slides=slides,
                slide_vars=slide_vars,
                layout_vars=layout_vars,
                shape_vars=shape_vars,
                layout_map=layout_map,
                warnings=warnings,
            )
        elif isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call):
            saved = _extract_save_filename(statement.value)
            if saved is not None:
                filename = saved

    return slides, filename, warnings


def _handle_assign(
    statement: ast.Assign,
    *,
    slides: list[dict[str, Any]],
    slide_vars: dict[str, dict[str, Any]],
    layout_vars: dict[str, str],
    shape_vars: dict[str, tuple[str, str]],
    layout_map: dict[int, str],
    warnings: list[str],
) -> None:
    value = statement.value
    for target in statement.targets:
        if isinstance(target, ast.Name):
            slide = _slide_from_add_slide(value, layout_vars, layout_map)
            if slide is not None:
                slides.append(slide)
                slide_vars[target.id] = slide
                continue

            layout_name = _layout_from_node(value, layout_vars, layout_map)
            if layout_name is not None:
                layout_vars[target.id] = layout_name
                continue

            shape_ref = _shape_ref_from_node(value)
            if shape_ref is not None:
                shape_vars[target.id] = shape_ref
                continue

        if isinstance(target, ast.Attribute) and target.attr == "text":
            text = _literal_text(value)
            if text is None:
                warnings.append("Skipped non-literal text assignment")
                continue
            slot_ref = _slot_ref_from_text_target(target.value, shape_vars)
            if slot_ref is None:
                warnings.append("Skipped text assignment with unsupported target")
                continue
            slide_var, slot = slot_ref
            slide = slide_vars.get(slide_var)
            if slide is None:
                warnings.append(
                    f"Skipped text assignment for unknown slide {slide_var}"
                )
                continue
            placeholders = slide.setdefault("placeholders", {})
            if isinstance(placeholders, dict):
                placeholders[slot] = text


def _translate_operations(
    value: Any, layout_map: dict[int, str]
) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    slides: list[dict[str, Any]] = []
    for item in value[:64]:
        if not isinstance(item, dict):
            continue
        layout = item.get("layout")
        if not layout and isinstance(item.get("layout_index"), int):
            layout = layout_map.get(item["layout_index"], "title_content")
        slide: dict[str, Any] = {"layout": str(layout or "title_content")}
        placeholders: dict[str, str] = {}
        for key in ("title", "body", "subtitle"):
            if item.get(key):
                placeholders[key] = str(item[key])
        raw_placeholders = item.get("placeholders")
        if isinstance(raw_placeholders, dict):
            for key, raw_value in raw_placeholders.items():
                placeholders[str(key)] = str(raw_value)
        if placeholders:
            slide["placeholders"] = placeholders
        slides.append(slide)
    return slides


def _slide_from_add_slide(
    value: ast.AST, layout_vars: dict[str, str], layout_map: dict[int, str]
) -> dict[str, Any] | None:
    if not isinstance(value, ast.Call):
        return None
    func = value.func
    if not isinstance(func, ast.Attribute) or func.attr != "add_slide":
        return None
    if not value.args:
        return {"layout": "title_content", "placeholders": {}}
    layout = _layout_from_node(value.args[0], layout_vars, layout_map)
    return {"layout": layout or "title_content", "placeholders": {}}


def _layout_from_node(
    node: ast.AST, layout_vars: dict[str, str], layout_map: dict[int, str]
) -> str | None:
    if isinstance(node, ast.Name):
        return layout_vars.get(node.id)
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    index = _slide_layout_index(node)
    if index is not None:
        return layout_map.get(index, "title_content")
    return None


def _slide_layout_index(node: ast.AST) -> int | None:
    if not isinstance(node, ast.Subscript):
        return None
    value = node.value
    if not isinstance(value, ast.Attribute) or value.attr != "slide_layouts":
        return None
    subscript = node.slice
    if isinstance(subscript, ast.Constant) and isinstance(subscript.value, int):
        return subscript.value
    return None


def _shape_ref_from_node(node: ast.AST) -> tuple[str, str] | None:
    if isinstance(node, ast.Attribute) and node.attr == "title":
        value = node.value
        if (
            isinstance(value, ast.Attribute)
            and value.attr == "shapes"
            and isinstance(value.value, ast.Name)
        ):
            return value.value.id, "title"
    if isinstance(node, ast.Subscript):
        return _placeholder_ref(node)
    return None


def _slot_ref_from_text_target(
    node: ast.AST, shape_vars: dict[str, tuple[str, str]]
) -> tuple[str, str] | None:
    if isinstance(node, ast.Name):
        return shape_vars.get(node.id)
    if isinstance(node, ast.Attribute) and node.attr == "title":
        return _shape_ref_from_node(node)
    if isinstance(node, ast.Subscript):
        return _placeholder_ref(node)
    return None


def _placeholder_ref(node: ast.Subscript) -> tuple[str, str] | None:
    value = node.value
    if not (
        isinstance(value, ast.Attribute)
        and value.attr == "placeholders"
        and isinstance(value.value, ast.Name)
    ):
        return None
    index = node.slice
    if not (isinstance(index, ast.Constant) and isinstance(index.value, int)):
        return None
    return value.value.id, _DEFAULT_PLACEHOLDER_MAP.get(
        index.value, f"placeholder_{index.value}"
    )


def _literal_text(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _extract_save_filename(call: ast.Call) -> str | None:
    func = call.func
    if not isinstance(func, ast.Attribute) or func.attr != "save" or not call.args:
        return None
    first = call.args[0]
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        return first.value
    return None


def _layout_map(value: Any) -> dict[int, str]:
    result = dict(_DEFAULT_LAYOUT_MAP)
    if not isinstance(value, dict):
        return result
    for raw_key, raw_value in value.items():
        try:
            key = int(raw_key)
        except (TypeError, ValueError):
            continue
        result[key] = str(raw_value)
    return result


def _infer_title(slides: list[dict[str, Any]]) -> str:
    for slide in slides:
        placeholders = slide.get("placeholders")
        if isinstance(placeholders, dict) and placeholders.get("title"):
            return str(placeholders["title"])
    return "Untitled Presentation"


def _strip_pptx_suffix(filename: str) -> str:
    return filename.removesuffix(".pptx").removesuffix(".potx")
