"""JSON schemas for document creation MCP tools."""

from __future__ import annotations

from typing import Any, Dict

# ============================================================================
# JSON Schemas for MCP Tools
# ============================================================================

# Content block schema (shared across document types)
CONTENT_BLOCK_SCHEMA = {
    "type": "object",
    "properties": {
        "type": {
            "type": "string",
            "enum": [
                "title",
                "heading1",
                "heading2",
                "heading3",
                "heading4",
                "paragraph",
                "bullet_list",
                "numbered_list",
                "table",
                "quote",
                "code_block",
                "image",
                "page_break",
            ],
            "description": "Content block type",
        },
        "text": {
            "type": "string",
            "description": "Text content (for headings, paragraphs, quotes, code)",
        },
        "items": {
            "type": "array",
            "items": {"type": "string"},
            "description": "List items (for bullet_list, numbered_list)",
        },
        "rows": {
            "type": "array",
            "items": {
                "type": "array",
                "items": {"type": "string"},
            },
            "description": "Table rows including header row (for table)",
        },
        "level": {
            "type": "integer",
            "minimum": 0,
            "maximum": 8,
            "description": "Nesting level for lists (default 0)",
        },
        "language": {
            "type": "string",
            "description": "Programming language for code blocks",
        },
        "src": {
            "type": "string",
            "description": "Image source path or URL",
        },
        "alt": {
            "type": "string",
            "description": "Image alt text for accessibility",
        },
    },
    "required": ["type"],
}

CREATE_WORD_DOCUMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Document title (used in metadata and optionally as first heading)",
        },
        "content": {
            "oneOf": [
                {
                    "type": "string",
                    "description": "Markdown content (# headings, - bullets, 1. numbered, ``` code, > quotes)",
                },
                {
                    "type": "array",
                    "description": "Structured content blocks",
                    "items": CONTENT_BLOCK_SCHEMA,
                },
            ],
            "description": "Document content as markdown string or structured blocks",
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier (uses generic TokenMoulds template if not specified)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension (auto-generated if not specified)",
        },
        "add_title_page": {
            "type": "boolean",
            "default": False,
            "description": "Add a title page before content",
        },
        "include_toc": {
            "type": "boolean",
            "default": False,
            "description": "Include table of contents",
        },
        "metadata": {
            "type": "object",
            "properties": {
                "author": {"type": "string"},
                "subject": {"type": "string"},
                "keywords": {"type": "array", "items": {"type": "string"}},
                "category": {"type": "string"},
            },
            "description": "Document metadata",
        },
    },
    "required": ["title", "content"],
}


def _build_layout_enum() -> list[str]:
    """Build the layout enum from the curated registry."""
    try:
        from tokenmoulds.mcp.layout_registry import get_layout_names

        return list(get_layout_names())
    except Exception:
        # Fall back to minimal set if registry unavailable
        return ["title_slide", "title_content", "section_header", "blank"]


CREATE_POWERPOINT_DOCUMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Presentation title",
        },
        "slides": {
            "type": "array",
            "description": "Structured slides to create when the layout and placeholder content are already known. For ordinary 'make slides' requests, prefer markdown/content and let TokenMoulds plan layouts.",
            "items": {
                "type": "object",
                "properties": {
                    "layout": {
                        "type": "string",
                        "enum": _build_layout_enum(),
                        "description": "Layout name from the curated vocabulary. Use list_layouts only when you need explicit structured slide construction.",
                    },
                    "placeholders": {
                        "type": "object",
                        "description": "Content for each named slot in the chosen layout. Keys are slot names (e.g. 'title', 'body', 'source', 'strengths'). Values are plain text (newlines create paragraphs).",
                        "additionalProperties": {"type": "string"},
                    },
                    "notes": {"type": "string", "description": "Speaker notes"},
                },
                "required": ["layout"],
            },
        },
        "markdown": {
            "type": "string",
            "description": "Preferred input for ordinary deck creation. Markdown deck content: # creates the cover, ## starts slides, and ### creates grouped slide sections that map to layout placeholders.",
        },
        "content": {
            "type": "string",
            "description": "Alias for markdown deck content.",
        },
        "audience": {
            "type": "string",
            "description": "Audience for the deck. If missing from a vague request, ask the user instead of guessing.",
        },
        "slide_count": {
            "type": "integer",
            "minimum": 1,
            "description": "Approximate desired slide count. If missing from a vague request, ask only when useful.",
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier (uses active brand if omitted)",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
    },
    "required": ["title"],
}

CREATE_EXCEL_DOCUMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Workbook title",
        },
        "sheets": {
            "type": "array",
            "description": "Worksheet definitions",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Sheet name"},
                    "data": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {"type": ["string", "number", "boolean", "null"]},
                        },
                        "description": "2D array of cell values",
                    },
                    "headers": {
                        "type": "boolean",
                        "default": True,
                        "description": "First row is header row",
                    },
                    "freeze_panes": {
                        "type": "string",
                        "description": "Cell reference for freeze panes (e.g., 'A2' for frozen header)",
                    },
                },
                "required": ["name", "data"],
            },
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
    },
    "required": ["title", "sheets"],
}

CREATE_WRITER_DOCUMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Document title",
        },
        "content": {
            "type": "array",
            "description": "Document content blocks",
            "items": CONTENT_BLOCK_SCHEMA,
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
    },
    "required": ["title", "content"],
}

CREATE_IMPRESS_DOCUMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Presentation title",
        },
        "slides": {
            "type": "array",
            "description": "Slide content (same format as PowerPoint)",
            "items": {
                "type": "object",
                "properties": {
                    "layout": {"type": "string"},
                    "title": {"type": "string"},
                    "content": {"type": "array"},
                },
            },
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier",
        },
        "filename": {
            "type": "string",
            "description": "Output filename without extension",
        },
    },
    "required": ["title", "slides"],
}

# ============================================================================
# Tool Implementations
# ============================================================================
