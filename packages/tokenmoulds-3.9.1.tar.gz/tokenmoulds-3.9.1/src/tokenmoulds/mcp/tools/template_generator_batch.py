"""Batch template generation helper."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, TYPE_CHECKING

from tokenmoulds.mcp.tools.template_generator import (
    _get_brand_tokens,
    generate_excel_template,
    generate_google_docs_template,
    generate_impress_template,
    generate_powerpoint_template,
    generate_theme,
    generate_word_template,
    generate_writer_template,
)

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


async def generate_all_templates(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Generate all template formats for a brand.

    Args:
        arguments: Tool arguments
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with all template paths
    """
    try:
        brand_name, tokens = _get_brand_tokens(server, arguments.get("brand"))
    except ValueError as e:
        return {"error": str(e)}

    formats = arguments.get(
        "formats",
        ["word", "powerpoint", "excel", "writer", "impress", "google_docs", "theme"],
    )
    embed_fonts = arguments.get("embed_fonts", True)
    do_validate = arguments.get("validate", True)
    use_cache = arguments.get("use_cache", True)

    results = {}
    errors = []
    start_time = datetime.now(timezone.utc)

    # Generate each format
    format_handlers = {
        "word": generate_word_template,
        "powerpoint": generate_powerpoint_template,
        "excel": generate_excel_template,
        "writer": generate_writer_template,
        "impress": generate_impress_template,
        "google_docs": generate_google_docs_template,
        "theme": generate_theme,
    }

    for fmt in formats:
        if fmt not in format_handlers:
            errors.append(f"Unknown format: {fmt}")
            continue

        handler = format_handlers[fmt]
        fmt_args = {
            "brand": brand_name,
            "embed_fonts": embed_fonts,
            "validate": do_validate,
            "use_cache": use_cache,
        }

        result = await handler(fmt_args, server)

        if result.get("success"):
            results[fmt] = {
                "file_path": result.get("file_path"),
                "cached": result.get("cached", False),
                "size_bytes": result.get("size_bytes"),
            }
        else:
            errors.append(f"{fmt}: {result.get('error', 'Unknown error')}")

    end_time = datetime.now(timezone.utc)
    duration = (end_time - start_time).total_seconds()

    return {
        "success": len(results) > 0,
        "action": "generate_all_templates",
        "brand": brand_name,
        "formats_requested": formats,
        "formats_generated": list(results.keys()),
        "templates": results,
        "errors": errors if errors else None,
        "duration_seconds": round(duration, 2),
        "message": f"Generated {len(results)}/{len(formats)} templates in {duration:.1f}s",
    }
