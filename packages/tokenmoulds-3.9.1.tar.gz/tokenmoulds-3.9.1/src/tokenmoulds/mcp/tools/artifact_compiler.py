"""Artifact compilation orchestration for MCP workflows."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Dict, Mapping

from tokenmoulds.artifact_intent import (
    DEFAULT_PAYLOAD_PART,
    artifact_intent_from_mapping,
    canonical_json,
)
from tokenmoulds.emitters.docprops_custom import build_custom_properties_xml
from tokenmoulds.emitters.ooxml_base import (
    _append_artifact_content_types,
    _append_artifact_root_relationships,
)
from tokenmoulds.mcp.artifact_plan import (
    SUPPORTED_OUTPUT_FORMATS,
    ArtifactPlan,
    ArtifactPlanError,
    artifact_plan_from_mapping,
    load_artifact_plan,
)
from tokenmoulds.mcp.tools.artifact_planner import artifact_intent_from_plan
from tokenmoulds.mcp.tools.document_creator import (
    create_excel_document,
    create_impress_document,
    create_powerpoint_document,
    create_word_document,
    create_writer_document,
)
from tokenmoulds.mcp.tools.template_generator import (
    generate_excel_template,
    generate_impress_template,
    generate_powerpoint_template,
    generate_theme,
    generate_word_template,
    generate_writer_template,
)

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


COMPILE_ARTIFACT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact plan ID under generated/plans/<artifact_id>/plan.json",
        },
        "plan": {
            "type": "object",
            "description": "Inline ArtifactPlan payload to compile instead of loading by ID",
        },
        "formats": {
            "type": "array",
            "items": {"type": "string", "enum": list(SUPPORTED_OUTPUT_FORMATS)},
            "description": "Optional subset of plan output_formats to compile",
        },
        "content": {
            "type": "object",
            "description": (
                "Content payload keyed by format or kind. Supports markdown, "
                "deck_markdown, slides, document, content, sheets, and "
                "by_format.{pptx|docx|xlsx|odt|odp}."
            ),
        },
        "brand_name": {
            "type": "string",
            "description": "Brand override; defaults to plan brand_name or active brand",
        },
        "use_cache": {
            "type": "boolean",
            "default": True,
            "description": "Use cached templates for template outputs",
        },
        "validate": {
            "type": "boolean",
            "default": True,
            "description": "Validate generated template outputs where supported",
        },
    },
    "required": ["artifact_id"],
}

_DOCUMENT_FORMATS = {"docx", "pptx", "xlsx", "odt", "odp"}
_TEMPLATE_HANDLERS: dict[
    str, Callable[[Dict[str, Any], "TokenMouldsServer"], Awaitable[Dict[str, Any]]]
] = {
    "dotx": generate_word_template,
    "potx": generate_powerpoint_template,
    "xltx": generate_excel_template,
    "ott": generate_writer_template,
    "otp": generate_impress_template,
    "thmx": generate_theme,
}
_COMPILE_FORMATS = _DOCUMENT_FORMATS | set(_TEMPLATE_HANDLERS)


async def compile_artifact(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Compile a stored or inline artifact plan into concrete artifacts."""
    try:
        plan = _load_plan(arguments, server)
        formats = _requested_formats(arguments, plan)
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "compile_artifact"}

    unsupported = [fmt for fmt in formats if fmt not in _COMPILE_FORMATS]
    if unsupported:
        return {
            "error": f"compile_artifact does not yet support: {', '.join(unsupported)}",
            "action": "compile_artifact",
            "unsupported_formats": unsupported,
        }

    raw_content = arguments.get("content", {})
    content = (
        raw_content if isinstance(raw_content, Mapping) else {"content": raw_content}
    )
    brand_name = (
        arguments.get("brand_name") or plan.brand_name or server.active_brand or None
    )
    artifact_intent = artifact_intent_from_plan(plan).to_dict()
    artifact_intent_sha256 = hashlib.sha256(
        canonical_json(artifact_intent).encode("utf-8")
    ).hexdigest()

    artifacts: list[dict[str, Any]] = []
    format_reports: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []

    for fmt in formats:
        result = await _compile_format(
            fmt,
            plan=plan,
            content=content,
            brand_name=brand_name,
            artifact_intent=artifact_intent,
            arguments=arguments,
            server=server,
        )
        report = {
            "format": fmt,
            "tool": result.get("action"),
            "success": result.get("success") is True,
        }
        if result.get("success") and result.get("file_path"):
            output_path = Path(str(result["file_path"]))
            embedding = _embed_artifact_intent_if_supported(
                output_path, artifact_intent
            )
            artifact = _artifact_record(fmt, output_path, result)
            artifact["artifact_intent_embedding"] = embedding
            artifacts.append(artifact)
            report["path"] = artifact["path"]
            report["artifact_intent_embedding"] = embedding
        else:
            errors.append(
                {
                    "format": fmt,
                    "error": str(result.get("error") or "compilation failed"),
                }
            )
            report["error"] = str(result.get("error") or "compilation failed")
        format_reports.append(report)

    success = len(errors) == 0
    payload: dict[str, Any] = {
        "success": success,
        "action": "compile_artifact",
        "artifact_id": plan.artifact_id,
        "artifact_plan_sha256": plan.sha256(),
        "artifact_intent_sha256": artifact_intent_sha256,
        "artifact_intent": artifact_intent,
        "artifacts": artifacts,
        "format_reports": format_reports,
        "errors": errors or None,
        "quality_gate_recommended": bool(artifacts),
        "next_tools": ["run_document_quality_gate"] if artifacts else [],
    }
    result_path = _persist_compilation_result(
        payload, server.output_path, plan.artifact_id
    )
    payload["compilation_result_path"] = str(result_path)
    payload["message"] = (
        f"Compiled {len(artifacts)}/{len(formats)} requested artifact formats."
    )
    return payload


def _load_plan(
    arguments: Mapping[str, Any], server: "TokenMouldsServer"
) -> ArtifactPlan:
    inline_plan = arguments.get("plan")
    if isinstance(inline_plan, Mapping):
        return artifact_plan_from_mapping(inline_plan)

    artifact_id = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id:
        raise ArtifactPlanError("artifact_id is required")

    memory_plan = getattr(server, "artifact_plans", {}).get(artifact_id)
    if isinstance(memory_plan, Mapping):
        return artifact_plan_from_mapping(memory_plan)
    return load_artifact_plan(server.output_path, artifact_id)


def _requested_formats(arguments: Mapping[str, Any], plan: ArtifactPlan) -> list[str]:
    raw_formats = arguments.get("formats")
    if raw_formats is None:
        return list(plan.output_formats)
    if not isinstance(raw_formats, list):
        raise ArtifactPlanError("formats must be an array")

    requested: list[str] = []
    for item in raw_formats:
        fmt = str(item).strip().lstrip(".").lower()
        if not fmt:
            continue
        if fmt not in SUPPORTED_OUTPUT_FORMATS:
            raise ArtifactPlanError(f"unsupported output format: {fmt!r}")
        if fmt not in plan.output_formats:
            raise ArtifactPlanError(
                f"requested format {fmt!r} is not in artifact plan output_formats"
            )
        if fmt not in requested:
            requested.append(fmt)
    if not requested:
        raise ArtifactPlanError("formats must not be empty")
    return requested


async def _compile_format(
    fmt: str,
    *,
    plan: ArtifactPlan,
    content: Mapping[str, Any],
    brand_name: str | None,
    artifact_intent: dict[str, Any],
    arguments: Mapping[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    stem = f"{plan.artifact_id}/artifacts/{plan.artifact_id}"
    if fmt == "pptx":
        return await create_powerpoint_document(
            {
                "title": plan.title,
                "markdown": _content_value(content, fmt, "deck_markdown", "markdown"),
                "slides": _content_value(content, fmt, "slides", default=[]),
                "audience": plan.audience,
                "brand_name": brand_name,
                "filename": stem,
            },
            server,
        )
    if fmt == "docx":
        return await create_word_document(
            {
                "title": plan.title,
                "content": _content_value(
                    content,
                    fmt,
                    "document",
                    "content",
                    "markdown",
                    default=_document_blocks_from_plan(plan),
                ),
                "brand_name": brand_name,
                "filename": stem,
                "metadata": _document_metadata(plan, artifact_intent),
            },
            server,
        )
    if fmt == "xlsx":
        return await create_excel_document(
            {
                "title": plan.title,
                "sheets": _content_value(
                    content, fmt, "sheets", default=_workbook_sheets_from_plan(plan)
                ),
                "brand_name": brand_name,
                "filename": stem,
            },
            server,
        )
    if fmt == "odt":
        return await create_writer_document(
            {
                "title": plan.title,
                "content": _writer_content(content, fmt, plan),
                "brand_name": brand_name,
                "filename": stem,
            },
            server,
        )
    if fmt == "odp":
        return await create_impress_document(
            {
                "title": plan.title,
                "slides": _content_value(
                    content, fmt, "slides", default=_slides_from_plan(plan)
                ),
                "brand_name": brand_name,
                "filename": stem,
            },
            server,
        )

    handler = _TEMPLATE_HANDLERS[fmt]
    return await handler(
        {
            "brand": brand_name,
            "filename": stem,
            "use_cache": arguments.get("use_cache", True),
            "validate": arguments.get("validate", True),
        },
        server,
    )


def _content_value(
    content: Mapping[str, Any],
    fmt: str,
    *keys: str,
    default: Any = None,
) -> Any:
    by_format = content.get("by_format")
    if isinstance(by_format, Mapping) and fmt in by_format:
        return by_format[fmt]
    for key in keys:
        if key in content:
            return content[key]
    return default


def _document_blocks_from_plan(plan: ArtifactPlan) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = [{"type": "title", "text": plan.title}]
    blocks.append({"type": "paragraph", "text": plan.intent_summary})
    for section in plan.sections:
        blocks.append({"type": "heading1", "text": section.title})
        if section.purpose:
            blocks.append({"type": "paragraph", "text": section.purpose})
    return blocks


def _workbook_sheets_from_plan(plan: ArtifactPlan) -> list[dict[str, Any]]:
    rows = [["Section", "Priority", "Evidence"]]
    rows.extend(
        [
            section.title,
            section.priority,
            section.evidence or "",
        ]
        for section in plan.sections
    )
    return [{"name": "Plan", "data": rows, "headers": True}]


def _slides_from_plan(plan: ArtifactPlan) -> list[dict[str, Any]]:
    slides = [
        {
            "layout": "title_slide",
            "placeholders": {
                "title": plan.title,
                "subtitle": plan.intent_summary,
            },
        }
    ]
    for section in plan.sections:
        slides.append(
            {
                "layout": "title_content",
                "placeholders": {
                    "title": section.title,
                    "body": section.purpose or section.evidence or "",
                },
            }
        )
    return slides


def _writer_content(
    content: Mapping[str, Any], fmt: str, plan: ArtifactPlan
) -> list[dict[str, Any]]:
    value = _content_value(content, fmt, "document", "content")
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return [{"type": "paragraph", "text": value}]
    return _document_blocks_from_plan(plan)


def _document_metadata(
    plan: ArtifactPlan, artifact_intent: dict[str, Any]
) -> dict[str, Any]:
    return {
        "subject": plan.intent_summary,
        "category": plan.artifact_type,
        "keywords": [
            "tokenmoulds",
            plan.artifact_id,
            f"plan:{plan.sha256()}",
        ],
        "artifact_intent": artifact_intent,
    }


def _artifact_record(fmt: str, path: Path, result: Mapping[str, Any]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "format": fmt,
        "path": str(path),
        "tool": result.get("action"),
    }
    if path.exists():
        data = path.read_bytes()
        payload["sha256"] = hashlib.sha256(data).hexdigest()
        payload["size_bytes"] = len(data)
    if "validation" in result:
        payload["validation"] = result["validation"]
    return payload


def _embed_artifact_intent_if_supported(
    path: Path, artifact_intent: Mapping[str, Any]
) -> dict[str, Any]:
    if path.suffix.lower() not in {
        ".docx",
        ".dotx",
        ".pptx",
        ".potx",
        ".xlsx",
        ".xltx",
    }:
        return {"embedded": False, "reason": "format_not_supported"}
    if not path.exists():
        return {"embedded": False, "reason": "missing_file"}

    intent = artifact_intent_from_mapping(artifact_intent)
    try:
        with zipfile.ZipFile(path, "r") as zin:
            entries = {name: zin.read(name) for name in zin.namelist()}
            compression = zin.compression
    except zipfile.BadZipFile:
        return {"embedded": False, "reason": "not_zip_package"}

    required = {"[Content_Types].xml", "_rels/.rels"}
    if not required.issubset(entries):
        return {"embedded": False, "reason": "missing_ooxml_package_parts"}

    entries["[Content_Types].xml"] = _append_artifact_content_types(
        entries["[Content_Types].xml"]
    )
    entries["_rels/.rels"] = _append_artifact_root_relationships(entries["_rels/.rels"])
    entries["docProps/custom.xml"] = build_custom_properties_xml(artifact_intent=intent)
    entries[DEFAULT_PAYLOAD_PART.removeprefix("/")] = intent.canonical_json().encode(
        "utf-8"
    )

    tmp_path = path.with_suffix(f"{path.suffix}.tmp")
    with zipfile.ZipFile(tmp_path, "w", compression=compression) as zout:
        for name, data in entries.items():
            zout.writestr(name, data)
    tmp_path.replace(path)
    return {
        "embedded": True,
        "payload_part": DEFAULT_PAYLOAD_PART,
        "sha256": intent.sha256(),
    }


def _persist_compilation_result(
    payload: Mapping[str, Any], output_root: Path, artifact_id: str
) -> Path:
    path = Path(output_root) / artifact_id / "compile-result.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path
