"""Corporate GitHub source tools for the MCP server."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict

from tokenmoulds.brand.github import GitHubSource, resolve_github_source

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


LINK_CORPORATE_GITHUB_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "repository": {
            "type": "string",
            "description": "Corporate brand repository as owner/repo or a GitHub URL",
        },
        "ref": {
            "type": "string",
            "default": "main",
            "description": "Branch, tag, or commit SHA to read",
        },
        "manifest_path": {
            "type": "string",
            "default": "brand-manifest.yaml",
            "description": "Path to brand-manifest.yaml inside the repository",
        },
        "brand_name": {
            "type": "string",
            "description": "Override brand identifier; defaults to manifest brand_id",
        },
        "set_active": {
            "type": "boolean",
            "default": True,
            "description": "Set the loaded corporate brand as active",
        },
        "load_tokens": {
            "type": "boolean",
            "default": True,
            "description": "Fetch the manifest token source and load it into the MCP brand cache",
        },
    },
    "required": ["repository"],
}


async def link_corporate_github(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Link the MCP session to a GitHub-hosted corporate brand repo."""
    raw_repository = arguments.get("repository")
    if not raw_repository:
        return {"error": "Missing required 'repository' parameter"}

    try:
        repository = _normalize_github_repository(str(raw_repository))
    except ValueError as exc:
        return {"error": str(exc), "repository": raw_repository}

    ref = str(arguments.get("ref") or "main")
    manifest_path = str(arguments.get("manifest_path") or "brand-manifest.yaml")
    set_active = bool(arguments.get("set_active", True))
    load_tokens = bool(arguments.get("load_tokens", True))

    corporate_source: Dict[str, Any] = {
        "repository": repository,
        "ref": ref,
        "manifest_path": manifest_path,
        "provider": "github",
    }

    if not load_tokens:
        _store_corporate_source(server, None, corporate_source)
        return {
            "success": True,
            "action": "link_corporate_github",
            "linked_only": True,
            "corporate_source": corporate_source,
            "message": (
                f"Linked corporate GitHub source {repository}@{ref} without "
                "loading tokens."
            ),
        }

    try:
        manifest, source_dir = resolve_github_source(
            GitHubSource(
                repository=repository,
                ref=ref,
                path=manifest_path,
            )
        )
        token_file = source_dir / manifest.token_source
        tokens = _load_token_file(token_file)
    except Exception as exc:
        return {
            "error": f"Failed to load corporate GitHub brand: {exc}",
            "corporate_source": corporate_source,
            "suggestion": (
                "Check repository/ref/manifest_path and GitHub authentication. "
                "Private repositories require an authenticated gh CLI session."
            ),
        }

    brand_name = str(arguments.get("brand_name") or manifest.brand_id)
    tokens_path = server.cache_manager.save_tokens(brand_name, tokens)
    server.loaded_tokens[brand_name] = tokens
    if hasattr(server, "brand_token_files"):
        server.brand_token_files[brand_name] = Path(tokens_path)
    if set_active:
        server.active_brand = brand_name

    manifest_payload = {
        "brand_id": manifest.brand_id,
        "display_name": manifest.display_name,
        "default_locale": manifest.default_locale,
        "artifact_prefix": manifest.artifact_prefix,
        "token_source": manifest.token_source,
        "formats": manifest.formats,
        "policy_profile": manifest.policy_profile,
        "release_strategy": manifest.release_strategy,
        "preview_on_pr": manifest.preview_on_pr,
    }
    corporate_source["manifest"] = manifest_payload
    corporate_source["brand_name"] = brand_name
    corporate_source["tokens_path"] = str(tokens_path)
    _store_corporate_source(server, brand_name, corporate_source)

    return {
        "success": True,
        "action": "link_corporate_github",
        "brand_name": brand_name,
        "active_brand": server.active_brand,
        "corporate_source": corporate_source,
        "loaded_brands": list(server.loaded_tokens.keys()),
        "message": (
            f"Linked {repository}@{ref} and loaded corporate brand '{brand_name}'."
        ),
    }


def _store_corporate_source(
    server: "TokenMouldsServer",
    brand_name: str | None,
    source: Dict[str, Any],
) -> None:
    if not hasattr(server, "corporate_sources"):
        server.corporate_sources = {}
    key = brand_name or source["repository"]
    server.corporate_sources[key] = source
    server.corporate_github = source


def _load_token_file(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Token source not found: {path}")
    if path.suffix.lower() != ".json":
        raise ValueError(f"Unsupported token source format: {path.name}")
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError(f"Token source must be a JSON object: {path}")
    return payload


def _normalize_github_repository(value: str) -> str:
    candidate = value.strip()
    if not candidate:
        raise ValueError("repository must not be empty")

    candidate = re.sub(r"^git@github\.com:", "", candidate)
    candidate = re.sub(r"^https?://github\.com/", "", candidate)
    candidate = candidate.removesuffix(".git").strip("/")

    parts = candidate.split("/")
    if len(parts) != 2 or not all(parts):
        raise ValueError(
            "repository must be a GitHub owner/repo slug or github.com URL"
        )
    owner, repo = parts
    allowed = re.compile(r"^[A-Za-z0-9_.-]+$")
    if not allowed.match(owner) or not allowed.match(repo):
        raise ValueError(
            "repository owner and name may contain only letters, numbers, ., _, and -"
        )
    return f"{owner}/{repo}"
