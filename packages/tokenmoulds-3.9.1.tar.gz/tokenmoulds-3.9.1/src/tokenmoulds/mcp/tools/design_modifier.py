"""MCP tool: modify_design — adjust typographic formulas via presets.

Gives AI agents level 3 control: change the typographic algebra without
knowing the underlying math. The AI picks from curated named adjustments
(tight tracking, dramatic heading spacing, perfect-fourth type scale) and
the tool translates them to concrete token values.

Design overlays are stored on the server alongside brand tokens and
re-applied after any modify_brand call, so brand + design modifications
compose cleanly.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


#: Modular scale ratios mapped to their numeric multipliers.
SCALE_RATIOS: Dict[str, float] = {
    "minor_second": 1.067,
    "major_second": 1.125,
    "minor_third": 1.2,
    "major_third": 1.25,
    "perfect_fourth": 1.333,
    "golden_ratio": 1.618,
}


#: Tracking curves: list of (font_size_pt, tracking_units) breakpoints.
TRACKING_CURVES: Dict[str, List[Dict[str, float]]] = {
    "tight": [
        {"size_pt": 8, "tracking": 10},
        {"size_pt": 14, "tracking": -5},
        {"size_pt": 36, "tracking": -30},
    ],
    "neutral": [
        {"size_pt": 8, "tracking": 15},
        {"size_pt": 14, "tracking": 0},
        {"size_pt": 36, "tracking": -20},
    ],
    "loose": [
        {"size_pt": 8, "tracking": 25},
        {"size_pt": 14, "tracking": 5},
        {"size_pt": 36, "tracking": -10},
    ],
}


#: Heading spacing: grid-line multiples for space-before and space-after.
HEADING_SPACING: Dict[str, Dict[str, float]] = {
    "compact": {"before_grid_lines": 1, "after_grid_lines": 0.5},
    "standard": {"before_grid_lines": 2, "after_grid_lines": 1},
    "dramatic": {"before_grid_lines": 3, "after_grid_lines": 1},
}


#: Figure style strategies.
FIGURE_STYLES: Dict[str, Dict[str, str]] = {
    "default": {
        "body": "default",
        "heading": "default",
        "tabular": "default",
    },
    "oldstyle_body": {
        "body": "oldstyle",
        "heading": "lining",
        "tabular": "lining-tabular",
    },
    "lining_everywhere": {
        "body": "lining",
        "heading": "lining",
        "tabular": "lining-tabular",
    },
    "tabular_everywhere": {
        "body": "lining-tabular",
        "heading": "lining-tabular",
        "tabular": "lining-tabular",
    },
}


MODIFY_DESIGN_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "scale_ratio": {
            "type": "string",
            "enum": list(SCALE_RATIOS.keys()),
            "description": "Modular type scale ratio. Tighter ratios (minor_second) keep headings close to body size. Wider ratios (perfect_fourth, golden_ratio) create dramatic headline/body contrast.",
        },
        "tracking_curve": {
            "type": "string",
            "enum": list(TRACKING_CURVES.keys()),
            "description": "Letter-spacing curve. 'tight' is for headline-focused decks, 'loose' is for body-text-heavy documents.",
        },
        "heading_spacing": {
            "type": "string",
            "enum": list(HEADING_SPACING.keys()),
            "description": "Space around headings. 'compact' for dense layouts, 'dramatic' for editorial.",
        },
        "figure_style": {
            "type": "string",
            "enum": list(FIGURE_STYLES.keys()),
            "description": "Number figure strategy. 'oldstyle_body' puts oldstyle in body text (elegant), 'lining_everywhere' keeps all numbers uniform.",
        },
        "optical_margin": {
            "type": "boolean",
            "description": "Enable hanging punctuation and bullet outdent for clean text edges.",
        },
        "small_caps": {
            "type": "string",
            "enum": ["opentype", "synthesized", "none"],
            "description": "Small caps rendering. 'opentype' uses font smcp feature (requires capable font), 'synthesized' scales+tracks, 'none' disables.",
        },
        "brand_name": {
            "type": "string",
            "description": "Target brand (defaults to active brand)",
        },
    },
}


def _apply_design_overlay(
    tokens: Dict[str, Any],
    overlay: Dict[str, Any],
) -> Dict[str, Any]:
    """Apply a design overlay to generated tokens.

    Modifies typography tokens in-place to reflect scale ratio,
    tracking curve, heading spacing, figure styles, etc.
    """
    if not overlay:
        return tokens

    typo = tokens.setdefault("typography", {})

    # Scale ratio: store as typography.scale_ratio for emitters to consult
    if "scale_ratio" in overlay:
        ratio_name = overlay["scale_ratio"]
        if ratio_name in SCALE_RATIOS:
            typo["scale_ratio"] = {
                "$value": SCALE_RATIOS[ratio_name],
                "$type": "number",
                "$description": f"Modular scale ratio: {ratio_name}",
            }

    # Tracking curve: breakpoint list for size-dependent tracking
    if "tracking_curve" in overlay:
        curve_name = overlay["tracking_curve"]
        if curve_name in TRACKING_CURVES:
            typo.setdefault("tracking", {})
            typo["tracking"]["curve"] = {
                "$value": TRACKING_CURVES[curve_name],
                "$type": "array",
                "$description": f"Tracking curve: {curve_name}",
            }

    # Heading spacing: grid-line multiples
    if "heading_spacing" in overlay:
        spacing_name = overlay["heading_spacing"]
        if spacing_name in HEADING_SPACING:
            hs = HEADING_SPACING[spacing_name]
            typo["heading_spacing"] = {
                "before_grid_lines": {
                    "$value": hs["before_grid_lines"],
                    "$type": "number",
                },
                "after_grid_lines": {
                    "$value": hs["after_grid_lines"],
                    "$type": "number",
                },
            }

    # Figure style strategy
    if "figure_style" in overlay:
        fs_name = overlay["figure_style"]
        if fs_name in FIGURE_STYLES:
            fs = FIGURE_STYLES[fs_name]
            typo["figures"] = {
                "body": {"$value": fs["body"], "$type": "string"},
                "heading": {"$value": fs["heading"], "$type": "string"},
                "tabular": {"$value": fs["tabular"], "$type": "string"},
            }

    # Optical margin
    if "optical_margin" in overlay:
        typo["optical_margin"] = {
            "$value": bool(overlay["optical_margin"]),
            "$type": "boolean",
        }

    # Small caps mode
    if "small_caps" in overlay:
        typo["small_caps"] = {
            "$value": overlay["small_caps"],
            "$type": "string",
        }

    return tokens


async def modify_design(
    arguments: Dict[str, Any],
    server: Any,
) -> Dict[str, Any]:
    """Apply design formula adjustments to the active brand.

    Stores the design overlay on the server so subsequent modify_brand
    calls preserve it. Applies the overlay to the current tokens
    immediately and invalidates the template cache.
    """
    from pathlib import Path

    from tokenmoulds.mcp.tools.review_bundle import (
        build_curated_review_bundle,
        persist_review_bundle,
    )

    brand_name = arguments.get("brand_name") or server.active_brand
    if not brand_name:
        return {
            "error": "No active brand. Load or set a brand first.",
        }

    # Collect the design overlay from arguments
    overlay: Dict[str, Any] = {}
    for key in (
        "scale_ratio",
        "tracking_curve",
        "heading_spacing",
        "figure_style",
        "optical_margin",
        "small_caps",
    ):
        if key in arguments:
            overlay[key] = arguments[key]

    if not overlay:
        return {
            "error": "No design adjustments specified.",
            "suggestion": "Provide at least one preset (scale_ratio, tracking_curve, etc.)",
        }

    # Merge with any existing overlay on the server
    if not hasattr(server, "design_overlays"):
        server.design_overlays = {}
    existing = server.design_overlays.get(brand_name, {})
    merged_overlay = {**existing, **overlay}
    server.design_overlays[brand_name] = merged_overlay

    # Apply the overlay to the current brand tokens
    current_tokens = server.loaded_tokens.get(brand_name)
    if current_tokens is None:
        return {
            "error": f"Brand '{brand_name}' not loaded.",
            "suggestion": "Load the brand with load_brand before modify_design.",
        }

    try:
        _apply_design_overlay(current_tokens, merged_overlay)
    except Exception as exc:
        return {
            "error": f"Failed to apply design overlay: {exc}",
        }

    # Invalidate template cache
    cache_cleared = False
    try:
        if hasattr(server, "cache_manager") and server.cache_manager is not None:
            server.cache_manager.invalidate(brand_name)
            cache_cleared = True
    except Exception as exc:
        logger.warning("Failed to invalidate template cache: %s", exc)

    review_bundle = build_curated_review_bundle(
        action="modify_design",
        brand_name=brand_name,
        authored_before=existing,
        authored_after=merged_overlay,
        token_payload=current_tokens,
    )
    review_bundle_path: str | None = None
    output_root = getattr(server, "output_path", None)
    if output_root is not None:
        artifact_path = persist_review_bundle(
            review_bundle,
            output_root=Path(output_root),
        )
        review_bundle["artifact_path"] = str(artifact_path)
        review_bundle_path = str(artifact_path)

    return {
        "success": True,
        "action": "modify_design",
        "brand": brand_name,
        "changes": overlay,
        "overlay": merged_overlay,
        "cache_cleared": cache_cleared,
        "review_bundle": review_bundle,
        "review_bundle_path": review_bundle_path,
        "message": (
            f"Applied design overlay to brand '{brand_name}'. "
            f"Next create_document/create_presentation will use the updated design."
        ),
    }
