"""Artifact review bundle orchestration for compiled MCP outputs."""

from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

from tokenmoulds.artifact_intent import canonical_json
from tokenmoulds.mcp.artifact_plan import (
    ArtifactPlanError,
    artifact_plan_path,
    load_artifact_plan,
    safe_artifact_id,
)
from tokenmoulds.mcp.tools.review_bundle import persist_review_bundle

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


ARTIFACT_REVIEW_BUNDLE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Compiled artifact identifier under generated/<artifact_id>/",
        },
        "review_state": {
            "type": "string",
            "enum": ["draft", "reviewed", "approved", "rejected"],
            "description": "Optional review state to store in the bundle.",
        },
        "quality_gate_path": {
            "type": "string",
            "description": "Optional explicit quality-gate-result.json path.",
        },
    },
    "required": ["artifact_id"],
}

_COMPILATION_RESULT_NAME = "compile-result.json"
_QUALITY_RESULT_NAME = "quality-gate-result.json"


async def create_artifact_review_bundle(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Create a deterministic artifact review bundle from compiled outputs."""
    artifact_id_raw = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id_raw:
        return {
            "error": "artifact_id is required",
            "action": "create_artifact_review_bundle",
        }

    try:
        artifact_id = safe_artifact_id(artifact_id_raw)
        plan = load_artifact_plan(server.output_path, artifact_id)
        compile_result = _load_json(
            _compile_result_path(server.output_path, artifact_id)
        )
        quality_result = _load_json(
            _quality_gate_path(
                server.output_path, artifact_id, arguments.get("quality_gate_path")
            )
        )
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "create_artifact_review_bundle"}

    raw_review_state = arguments.get("review_state")
    review_state = (
        str(raw_review_state).strip() if raw_review_state else plan.review_state
    )
    bundle = build_artifact_review_bundle(
        artifact_id=artifact_id,
        review_state=review_state,
        output_root=server.output_path,
        plan=plan.to_dict(),
        compile_result=compile_result,
        quality_result=quality_result,
    )
    bundle_path = persist_review_bundle(bundle, output_root=server.output_path)
    bundle["artifact_path"] = str(bundle_path)

    return {
        "success": True,
        "action": "create_artifact_review_bundle",
        "artifact_id": artifact_id,
        "review_id": bundle["review_id"],
        "review_state": bundle["proposal_state"],
        "review_bundle_path": str(bundle_path),
        "review_bundle": bundle,
        "message": "Created a review bundle for the compiled artifact and quality gate.",
    }


def build_artifact_review_bundle(
    *,
    artifact_id: str,
    review_state: str,
    output_root: Path,
    plan: Mapping[str, Any],
    compile_result: Mapping[str, Any],
    quality_result: Mapping[str, Any],
) -> dict[str, Any]:
    """Build a review bundle with paths, hashes, validation results, and evidence."""
    plan_summary = _plan_summary(plan)
    compile_summary = _compile_summary(compile_result)
    quality_summary = _quality_summary(quality_result)
    evidence_paths = _merge_unique(
        [
            *compile_summary.pop("evidence_paths", []),
            *quality_summary.pop("evidence_paths", []),
            str(_compile_result_path_from_summary(compile_result, artifact_id)),
            str(_quality_gate_path_from_summary(quality_result, artifact_id)),
            str(artifact_plan_path(output_root, artifact_id)),
        ]
    )
    warnings = _merge_unique(
        [
            *plan_summary.get("warnings", []),
            *compile_summary.get("warnings", []),
            *quality_summary.get("warnings", []),
        ]
    )
    errors = _merge_unique(
        [
            *compile_summary.get("errors", []),
            *quality_summary.get("errors", []),
        ]
    )

    review_id = f"artifact-{safe_artifact_id(artifact_id)}"
    bundle: dict[str, Any] = {
        "review_id": review_id,
        "proposal_id": review_id,
        "created_at": quality_summary.get("created_at")
        or compile_summary.get("created_at")
        or None,
        "action": "create_artifact_review_bundle",
        "proposal_state": review_state,
        "review_state": review_state,
        "artifact_id": artifact_id,
        "brand_name": plan_summary.get("brand_name"),
        "summary": plan_summary.get("summary"),
        "artifact_plan": plan_summary,
        "compile_result": compile_summary,
        "quality_gate_result": quality_summary,
        "artifact_paths": compile_summary.get("artifacts", []),
        "hashes": {
            "artifact_plan_sha256": compile_summary.get("artifact_plan_sha256"),
            "artifact_intent_sha256": compile_summary.get("artifact_intent_sha256"),
            "quality_gate_sha256": quality_summary.get("quality_gate_sha256"),
        },
        "validation_results": quality_summary.get("validation_results", {}),
        "render_evidence": quality_summary.get("render_evidence", {}),
        "warnings": warnings,
        "errors": errors,
        "evidence_paths": evidence_paths,
        "preview_artifacts": [],
        "apply_options": ["open_github_pr"],
        "semantic_provenance": [],
    }
    return bundle


def _plan_summary(plan: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "artifact_id": plan.get("artifact_id"),
        "title": plan.get("title"),
        "artifact_type": plan.get("artifact_type"),
        "artifact_kind": plan.get("artifact_kind"),
        "audience": plan.get("audience"),
        "source_summary": plan.get("source_summary"),
        "brand_name": plan.get("brand_name"),
        "repository": plan.get("repository"),
        "ref": plan.get("ref"),
        "output_formats": list(plan.get("output_formats", [])),
        "sections": list(plan.get("sections", [])),
        "required_checks": list(plan.get("required_checks", [])),
        "status": plan.get("status"),
        "review_state": plan.get("review_state"),
        "warnings": list(plan.get("warnings", [])),
        "plan_sha256": plan.get("plan_sha256"),
        "source_sha256": plan.get("source_sha256"),
        "summary": plan.get("intent_summary"),
    }


def _compile_summary(compile_result: Mapping[str, Any]) -> dict[str, Any]:
    artifact_paths: list[dict[str, Any]] = []
    for artifact in compile_result.get("artifacts", []):
        if not isinstance(artifact, Mapping):
            continue
        artifact_paths.append(
            {
                "format": artifact.get("format"),
                "path": artifact.get("path"),
                "sha256": artifact.get("sha256"),
                "size_bytes": artifact.get("size_bytes"),
                "artifact_intent_embedding": artifact.get("artifact_intent_embedding"),
            }
        )
    return {
        "artifact_id": compile_result.get("artifact_id"),
        "artifact_plan_sha256": compile_result.get("artifact_plan_sha256"),
        "artifact_intent_sha256": compile_result.get("artifact_intent_sha256"),
        "artifact_intent": compile_result.get("artifact_intent"),
        "artifacts": artifact_paths,
        "artifact_paths": [
            artifact["path"] for artifact in artifact_paths if artifact.get("path")
        ],
        "format_reports": list(compile_result.get("format_reports", [])),
        "warnings": list(compile_result.get("warnings", [])),
        "errors": list(compile_result.get("errors", []) or []),
        "quality_gate_recommended": compile_result.get("quality_gate_recommended"),
        "next_tools": list(compile_result.get("next_tools", [])),
        "compiled_at": compile_result.get("compiled_at"),
        "evidence_paths": [str(compile_result.get("compilation_result_path"))]
        if compile_result.get("compilation_result_path")
        else [],
    }


def _quality_summary(quality_result: Mapping[str, Any]) -> dict[str, Any]:
    quality_sha = quality_result.get("quality_gate_sha256")
    if not quality_sha:
        quality_sha = hashlib.sha256(
            canonical_json(quality_result).encode("utf-8")
        ).hexdigest()
    return {
        "artifact_id": quality_result.get("artifact_id"),
        "status": quality_result.get("status"),
        "success": quality_result.get("success"),
        "checks": list(quality_result.get("checks", [])),
        "artifacts": list(quality_result.get("artifacts", [])),
        "warnings": list(quality_result.get("warnings", [])),
        "errors": list(quality_result.get("errors", []) or []),
        "evidence_paths": list(quality_result.get("evidence_paths", [])),
        "render_evidence": list(quality_result.get("render_evidence", [])),
        "quality_gate_sha256": quality_sha,
        "created_at": quality_result.get("created_at"),
        "validation_results": {
            entry.get("format"): entry
            for entry in quality_result.get("artifacts", [])
            if isinstance(entry, Mapping) and entry.get("format")
        },
    }


def _compile_result_path(output_root: Path, artifact_id: str) -> Path:
    return output_root / artifact_id / _COMPILATION_RESULT_NAME


def _quality_gate_path(
    output_root: Path,
    artifact_id: str,
    explicit_path: Any,
) -> Path:
    if explicit_path:
        return Path(str(explicit_path))
    return output_root / artifact_id / "quality" / _QUALITY_RESULT_NAME


def _compile_result_path_from_summary(
    compile_result: Mapping[str, Any], artifact_id: str
) -> Path:
    path = compile_result.get("compilation_result_path")
    if path:
        return Path(str(path))
    return Path("./generated") / artifact_id / _COMPILATION_RESULT_NAME


def _quality_gate_path_from_summary(
    quality_result: Mapping[str, Any], artifact_id: str
) -> Path:
    path = quality_result.get("quality_gate_result_path")
    if path:
        return Path(str(path))
    return Path("./generated") / artifact_id / "quality" / _QUALITY_RESULT_NAME


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ArtifactPlanError(f"Artifact review input not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ArtifactPlanError(f"Artifact review input must be a JSON object: {path}")
    return payload


def _merge_unique(values: list[Any]) -> list[Any]:
    seen: set[str] = set()
    result: list[Any] = []
    for value in values:
        if value is None:
            continue
        if isinstance(value, str):
            key = value
        else:
            key = json.dumps(value, sort_keys=True, default=str)
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


__all__ = [
    "ARTIFACT_REVIEW_BUNDLE_SCHEMA",
    "build_artifact_review_bundle",
    "create_artifact_review_bundle",
]
