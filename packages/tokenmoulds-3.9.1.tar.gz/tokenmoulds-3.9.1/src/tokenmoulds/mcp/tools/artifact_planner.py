"""Artifact planning tools for LLM-driven MCP workflows."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, cast

from tokenmoulds import __version__
from tokenmoulds.artifact_intent import (
    ARTIFACT_TYPES,
    ArtifactIntentMetadata,
)
from tokenmoulds.mcp.artifact_plan import (
    ArtifactPlan,
    ArtifactPlanError,
    artifact_plan_from_mapping,
    artifact_plan_path,
    load_artifact_plan,
    persist_artifact_plan,
    safe_artifact_id,
    warnings_for_plan,
)

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


CREATE_ARTIFACT_PLAN_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "Business-facing artifact title",
        },
        "intent_summary": {
            "type": "string",
            "description": "Compact summary of purpose, audience, and expected outcome. Do not include raw prompt text.",
        },
        "artifact_type": {
            "type": "string",
            "enum": list(ARTIFACT_TYPES),
            "description": "Optional explicit TokenMoulds artifact type",
        },
        "artifact_kind": {
            "type": "string",
            "enum": ["auto", "deck", "document", "workbook", "template_bundle"],
            "default": "auto",
            "description": "Coarse artifact kind used to choose default output formats",
        },
        "audience": {
            "type": "string",
            "description": "Primary audience, such as board, client, internal leadership, or regulators",
        },
        "source_summary": {
            "type": "string",
            "description": "Short summary of source material. Do not pass raw notes, chat history, secrets, or credentials.",
        },
        "sections": {
            "type": "array",
            "description": "Semantic section or slide groups the artifact should contain",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "purpose": {"type": "string"},
                    "evidence": {"type": "string"},
                    "priority": {
                        "type": "string",
                        "enum": ["required", "recommended", "optional"],
                    },
                },
                "required": ["title"],
            },
        },
        "output_formats": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Explicit output extensions, such as pptx, docx, xlsx, odt, or odp",
        },
        "brand_name": {
            "type": "string",
            "description": "Brand identifier; defaults to the active brand",
        },
        "repository": {
            "type": "string",
            "description": "Optional corporate GitHub owner/repo associated with the plan",
        },
        "ref": {
            "type": "string",
            "description": "Optional Git ref associated with the plan",
        },
        "status": {
            "type": "string",
            "enum": ["draft", "review", "approved", "released", "unknown"],
            "default": "draft",
            "description": "Artifact lifecycle status",
        },
        "review_state": {
            "type": "string",
            "enum": [
                "unreviewed",
                "draft",
                "reviewed",
                "approved",
                "rejected",
                "unknown",
            ],
            "default": "draft",
            "description": "Review state for the plan",
        },
    },
    "required": ["title", "intent_summary"],
}

VALIDATE_ARTIFACT_PLAN_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "artifact_id": {
            "type": "string",
            "description": "Artifact plan ID under generated/plans/<artifact_id>/plan.json",
        },
        "plan": {
            "type": "object",
            "description": "Inline artifact plan payload to validate",
        },
        "file_path": {
            "type": "string",
            "description": "Direct path to a persisted plan JSON file",
        },
    },
}


async def create_artifact_plan(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a typed artifact plan that later MCP calls can compile."""
    title = str(arguments.get("title") or "").strip()
    intent_summary = str(arguments.get("intent_summary") or "").strip()
    if not title:
        return {"error": "Missing required 'title' parameter"}
    if not intent_summary:
        return {"error": "Missing required 'intent_summary' parameter"}

    artifact_kind = str(arguments.get("artifact_kind") or "auto")
    explicit_type = arguments.get("artifact_type")
    output_formats = _normalize_formats(arguments.get("output_formats"))
    artifact_type = (
        str(explicit_type)
        if explicit_type
        else _infer_artifact_type(title, intent_summary, artifact_kind, output_formats)
    )
    if artifact_type not in ARTIFACT_TYPES:
        return {"error": f"Unsupported artifact_type: {artifact_type}"}

    if not output_formats:
        output_formats = _default_formats(artifact_type, artifact_kind)

    brand_name = str(arguments.get("brand_name") or server.active_brand or "").strip()
    corporate_source = _corporate_source_for(server, brand_name)
    repository = (
        arguments.get("repository") or corporate_source.get("repository")
        if corporate_source
        else arguments.get("repository")
    )
    ref = (
        arguments.get("ref") or corporate_source.get("ref")
        if corporate_source
        else arguments.get("ref")
    )

    artifact_id = safe_artifact_id(str(arguments.get("artifact_id") or title))
    plan_payload = {
        "artifact_id": artifact_id,
        "title": title,
        "intent_summary": intent_summary,
        "artifact_type": artifact_type,
        "artifact_kind": artifact_kind,
        "audience": arguments.get("audience"),
        "source_summary": arguments.get("source_summary"),
        "brand_name": brand_name or None,
        "repository": repository,
        "ref": ref,
        "output_formats": output_formats,
        "sections": _normalize_sections(arguments.get("sections")),
        "required_checks": [
            "schema_validation",
            "package_validation",
            "artifact_intent",
            "render_validation",
            "office_oracle_review",
        ],
        "status": arguments.get("status", "draft"),
        "review_state": arguments.get("review_state", "draft"),
    }
    try:
        artifact_plan = artifact_plan_from_mapping(plan_payload)
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "create_artifact_plan"}

    warnings = warnings_for_plan(artifact_plan)
    if warnings:
        artifact_plan = artifact_plan_from_mapping(
            {**artifact_plan.to_dict(include_hash=False), "warnings": list(warnings)}
        )
    plan_path = persist_artifact_plan(artifact_plan, server.output_path)
    artifact_intent = artifact_intent_from_plan(artifact_plan).to_dict()

    if not hasattr(server, "artifact_plans"):
        server.artifact_plans = {}
    server.artifact_plans[artifact_plan.artifact_id] = artifact_plan.to_dict()

    return {
        "success": True,
        "action": "create_artifact_plan",
        "artifact_id": artifact_plan.artifact_id,
        "artifact_plan_sha256": artifact_plan.sha256(),
        "source_sha256": artifact_plan.source_sha256(),
        "artifact_plan_path": str(plan_path),
        "artifact_plan": artifact_plan.to_dict(),
        "artifact_intent": artifact_intent,
        "warnings": list(warnings),
        "recommended_next_tools": artifact_plan.to_dict()["next_tools"],
        "message": (
            "Created and persisted a typed artifact plan. Use "
            "validate_artifact_plan before compilation."
        ),
    }


async def validate_artifact_plan(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Validate a persisted or inline artifact plan."""
    try:
        plan = _load_plan_from_arguments(arguments, server)
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "validate_artifact_plan"}

    warnings = warnings_for_plan(plan)
    plan_dict = plan.to_dict()
    if warnings and tuple(plan.warnings) != warnings:
        plan = artifact_plan_from_mapping(
            {**plan.to_dict(include_hash=False), "warnings": list(warnings)}
        )
        plan_dict = plan.to_dict()

    return {
        "success": True,
        "action": "validate_artifact_plan",
        "artifact_id": plan.artifact_id,
        "artifact_plan_sha256": plan.sha256(),
        "source_sha256": plan.source_sha256(),
        "artifact_plan_path": str(
            artifact_plan_path(server.output_path, plan.artifact_id)
        ),
        "artifact_plan": plan_dict,
        "warnings": list(warnings),
        "recommended_next_tools": plan_dict["next_tools"],
        "message": "Artifact plan is valid.",
    }


def artifact_intent_from_plan(plan: ArtifactPlan) -> ArtifactIntentMetadata:
    """Build embedded artifact intent metadata from a pre-compilation plan."""
    plan_dict = plan.to_dict()
    return ArtifactIntentMetadata(
        artifact={
            "id": plan.artifact_id,
            "type": plan.artifact_type,
            "title": plan.title,
            "intent_summary": plan.intent_summary,
            "audience": plan.audience,
            "status": plan.status,
            "tags": _artifact_tags(plan.artifact_type, list(plan.output_formats)),
        },
        source={
            "summary": plan.source_summary or "",
            "repository": plan.repository,
            "ref": plan.ref,
        },
        generation={
            "compiler": "tokenmoulds",
            "compiler_version": __version__,
            "brand_id": plan.brand_name,
            "artifact_plan_sha256": plan.sha256(),
        },
        plan={
            "artifact_kind": plan.artifact_kind,
            "output_formats": list(plan.output_formats),
            "sections": [section.to_dict() for section in plan.sections],
            "required_checks": list(plan.required_checks),
            "next_tools": plan_dict["next_tools"],
            "github_native_review": True,
        },
        quality={
            "required_checks": list(plan.required_checks),
            "validation_requested": True,
        },
        review={"state": plan.review_state},
    )


def _load_plan_from_arguments(
    arguments: Dict[str, Any], server: "TokenMouldsServer"
) -> ArtifactPlan:
    inline_plan = arguments.get("plan")
    if isinstance(inline_plan, dict):
        return artifact_plan_from_mapping(inline_plan)

    file_path = arguments.get("file_path")
    if file_path:
        path = Path(str(file_path))
        if not path.is_absolute() and not path.exists():
            path = server.output_path / path
        if not path.exists():
            raise ArtifactPlanError(f"Artifact plan not found: {path}")
        with open(path, encoding="utf-8") as fh:
            payload = json.load(fh)
        if not isinstance(payload, dict):
            raise ArtifactPlanError(f"Artifact plan must be a JSON object: {path}")
        return artifact_plan_from_mapping(payload)

    artifact_id = str(arguments.get("artifact_id") or "").strip()
    if not artifact_id:
        raise ArtifactPlanError("Provide artifact_id, plan, or file_path")

    memory_plan = getattr(server, "artifact_plans", {}).get(artifact_id)
    if isinstance(memory_plan, dict):
        return artifact_plan_from_mapping(memory_plan)
    return load_artifact_plan(server.output_path, artifact_id)


def _corporate_source_for(
    server: "TokenMouldsServer", brand_name: str
) -> Dict[str, Any]:
    sources = getattr(server, "corporate_sources", {}) or {}
    if brand_name and brand_name in sources:
        return cast(Dict[str, Any], sources[brand_name])
    return cast(Dict[str, Any], getattr(server, "corporate_github", {}) or {})


def _infer_artifact_type(
    title: str,
    intent_summary: str,
    artifact_kind: str,
    output_formats: list[str],
) -> str:
    text = f"{title} {intent_summary}".lower()
    formats = set(output_formats)
    if artifact_kind == "template_bundle" or any(
        fmt in formats for fmt in _TEMPLATE_FORMATS
    ):
        return "template_bundle"
    if artifact_kind == "workbook" or {"xlsx", "xlsm", "ods"} & formats:
        return "workbook"
    if "board" in text or artifact_kind == "deck" or {"pptx", "odp"} & formats:
        return "board_deck"
    if "proposal" in text:
        return "proposal"
    if "policy" in text:
        return "policy_memo"
    if "memo" in text:
        return "memo"
    if "manual" in text or "playbook" in text:
        return "manual"
    if "whitepaper" in text or "white paper" in text:
        return "whitepaper"
    if "annual report" in text:
        return "annual_report"
    return "report"


def _default_formats(artifact_type: str, artifact_kind: str) -> list[str]:
    if artifact_type == "template_bundle" or artifact_kind == "template_bundle":
        return ["dotx", "potx", "xltx", "ott", "otp"]
    if artifact_type == "workbook" or artifact_kind == "workbook":
        return ["xlsx"]
    if artifact_type == "board_deck" or artifact_kind == "deck":
        return ["pptx"]
    return ["docx"]


def _normalize_formats(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    formats: list[str] = []
    for item in value:
        fmt = str(item).strip().lower().lstrip(".")
        if fmt and fmt not in formats:
            formats.append(fmt)
    return formats[:12]


def _normalize_sections(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    sections: list[dict[str, str]] = []
    for item in value[:24]:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        section = {"title": title}
        for key in ("purpose", "evidence", "priority"):
            raw = item.get(key)
            if raw:
                section[key] = str(raw).strip()
        sections.append(section)
    return sections


def _artifact_tags(artifact_type: str, output_formats: list[str]) -> list[str]:
    return [artifact_type, *output_formats, "mcp-plan"][:16]


_TEMPLATE_FORMATS = {"dotx", "potx", "xltx", "ott", "otp", "ots", "otg", "thmx"}
