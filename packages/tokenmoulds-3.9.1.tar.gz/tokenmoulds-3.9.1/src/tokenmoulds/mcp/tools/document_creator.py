"""Document creation MCP tools for TokenMoulds.

Provides tools for creating styled documents in all supported formats.
All documents are based on TokenMoulds-generated templates - either brand-specific
or the generic TokenMoulds default template (full quality, non-branded).

Supported formats:
- Word (.docx) from .dotx template
- PowerPoint (.pptx) from .potx template
- Excel (.xlsx) from .xltx template
- Writer (.odt) from .ott template
- Impress (.odp) from .otp template
- Google Docs (.docx) optimized for Google Drive

NO minimal Office defaults - every document has full TokenMoulds quality.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer

from tokenmoulds.mcp.deck_intake import deck_clarification_if_needed
from tokenmoulds.mcp.deck_markdown import markdown_to_powerpoint_slides
from tokenmoulds.mcp.tools.document_pipeline.content_injection import (
    _inject_excel_content,
    _inject_impress_content,
    _inject_powerpoint_content,
    _inject_word_content,
    _inject_writer_content,
    _parse_markdown_to_blocks,
)
from tokenmoulds.mcp.tools.document_pipeline.template_acquisition import (
    GENERIC_BRAND_NAME,
    _get_excel_template,
    _get_impress_template,
    _get_powerpoint_template,
    _get_style_context,
    _get_word_template,
    _get_writer_template,
)
from tokenmoulds.mcp.validation import validate_template


async def create_word_document(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a styled Word document (.docx).

    Uses TokenMoulds-generated template (brand-specific or generic).
    Full 276+ styles, proper typography, ISO 29500 compliant.

    Args:
        arguments: Tool arguments from MCP call
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with file path and metadata
    """
    title = arguments.get("title", "Untitled Document")
    raw_content = arguments.get("content", [])
    brand_name = arguments.get("brand_name") or server.active_brand
    filename = arguments.get("filename")
    metadata = arguments.get("metadata", {})

    # Support both markdown string and structured content blocks
    if isinstance(raw_content, str):
        content_blocks = _parse_markdown_to_blocks(raw_content)
    else:
        content_blocks = raw_content

    # Generate filename if not provided
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join(c if c.isalnum() or c in " -_" else "" for c in title)
        safe_title = safe_title.replace(" ", "_")[:30]
        filename = f"{safe_title}_{timestamp}"

    # Ensure .docx extension (avoid double extension)
    if not filename.lower().endswith(".docx"):
        filename = f"{filename}.docx"
    output_file = server.output_path / filename

    try:
        # Step 1: Acquire template
        template_bytes, template_source = await _get_word_template(server, brand_name)

        if template_bytes is None:
            return {
                "error": "No template available. Load a brand or ensure generic template can be generated.",
                "suggestion": "Use extract_brand_from_url or build_recipe_from_inputs first.",
            }

        # Step 2: Inject content
        style_context = _get_style_context(server, brand_name)
        document_bytes = _inject_word_content(
            template_bytes,
            content_blocks,
            style_context,
            title=title,
            metadata=metadata,
        )

        # Step 3: Validate output
        validation = validate_template(document_bytes, format_hint="word")

        # Step 4: Write to file
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_bytes(document_bytes)

        return {
            "success": True,
            "action": "create_word_document",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "title": title,
            "content_blocks": len(content_blocks),
            "template_source": template_source,
            "brand_used": brand_name or GENERIC_BRAND_NAME,
            "validation": {
                "valid": validation.valid,
                "iso_compliant": validation.iso_compliant,
                "warnings": validation.warnings[:3] if validation.warnings else [],
            },
            "file_size_kb": round(len(document_bytes) / 1024, 1),
            "message": f"Created '{title}' with full TokenMoulds styling. {template_source} template.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create document: {str(e)}",
            "title": title,
            "attempted_output": str(output_file),
        }


async def create_powerpoint_document(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a styled PowerPoint presentation (.pptx).

    Args:
        arguments: Tool arguments from MCP call
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with file path and metadata
    """
    title = arguments.get("title", "Untitled Presentation")
    slides = arguments.get("slides", [])
    markdown = arguments.get("markdown") or arguments.get("content")
    clarification = deck_clarification_if_needed(arguments)
    if clarification is not None:
        return clarification

    if markdown and not slides:
        slides = markdown_to_powerpoint_slides(str(markdown), title=title)
    brand_name = arguments.get("brand_name") or server.active_brand
    filename = arguments.get("filename")

    if not slides:
        return deck_clarification_if_needed(arguments) or {
            "error": "No usable slides or markdown content provided.",
            "suggestion": "Pass markdown content or slides with layout and placeholders.",
        }

    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join(c if c.isalnum() or c in " -_" else "" for c in title)
        safe_title = safe_title.replace(" ", "_")[:30]
        filename = f"{safe_title}_{timestamp}"

    output_file = server.output_path / f"{filename}.pptx"

    try:
        # Get template
        template_bytes, template_source = await _get_powerpoint_template(
            server, brand_name
        )

        if template_bytes is None:
            return {
                "error": "No PowerPoint template available.",
                "suggestion": "Generate template first with generate_powerpoint_template.",
            }

        # Inject slides content
        document_bytes = _inject_powerpoint_content(template_bytes, slides)

        # Write file
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_bytes(document_bytes)

        return {
            "success": True,
            "action": "create_powerpoint_document",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "title": title,
            "slides_count": len(slides),
            "layout_decisions": [
                slide["layout_decision"]
                for slide in slides
                if isinstance(slide, dict) and "layout_decision" in slide
            ],
            "template_source": template_source,
            "brand_used": brand_name or GENERIC_BRAND_NAME,
            "file_size_kb": round(len(document_bytes) / 1024, 1),
            "message": f"Created presentation with {len(slides)} slides.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create presentation: {str(e)}",
            "title": title,
        }


async def create_excel_document(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a styled Excel workbook (.xlsx).

    Args:
        arguments: Tool arguments from MCP call
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with file path and metadata
    """
    title = arguments.get("title", "Untitled Workbook")
    sheets = arguments.get("sheets", [])
    brand_name = arguments.get("brand_name") or server.active_brand
    filename = arguments.get("filename")

    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join(c if c.isalnum() or c in " -_" else "" for c in title)
        safe_title = safe_title.replace(" ", "_")[:30]
        filename = f"{safe_title}_{timestamp}"

    output_file = server.output_path / f"{filename}.xlsx"

    try:
        # Get template
        template_bytes, template_source = await _get_excel_template(server, brand_name)

        if template_bytes is None:
            return {
                "error": "No Excel template available.",
                "suggestion": "Generate template first with generate_excel_template.",
            }

        # Inject sheet data
        document_bytes = _inject_excel_content(template_bytes, sheets)

        # Write file
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_bytes(document_bytes)

        return {
            "success": True,
            "action": "create_excel_document",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "title": title,
            "sheets_count": len(sheets),
            "template_source": template_source,
            "brand_used": brand_name or GENERIC_BRAND_NAME,
            "file_size_kb": round(len(document_bytes) / 1024, 1),
            "message": f"Created workbook with {len(sheets)} sheets.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create workbook: {str(e)}",
            "title": title,
        }


async def create_writer_document(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a styled LibreOffice Writer document (.odt).

    Args:
        arguments: Tool arguments from MCP call
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with file path and metadata
    """
    title = arguments.get("title", "Untitled Document")
    content_blocks = arguments.get("content", [])
    brand_name = arguments.get("brand_name") or server.active_brand
    filename = arguments.get("filename")

    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join(c if c.isalnum() or c in " -_" else "" for c in title)
        safe_title = safe_title.replace(" ", "_")[:30]
        filename = f"{safe_title}_{timestamp}"

    output_file = server.output_path / f"{filename}.odt"

    try:
        # Get template
        template_bytes, template_source = await _get_writer_template(server, brand_name)

        if template_bytes is None:
            return {
                "error": "No Writer template available.",
                "suggestion": "Generate template first with generate_writer_template.",
            }

        # Inject content (ODF format)
        document_bytes = _inject_writer_content(template_bytes, content_blocks)

        # Write file
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_bytes(document_bytes)

        return {
            "success": True,
            "action": "create_writer_document",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "title": title,
            "content_blocks": len(content_blocks),
            "template_source": template_source,
            "brand_used": brand_name or GENERIC_BRAND_NAME,
            "file_size_kb": round(len(document_bytes) / 1024, 1),
            "message": f"Created ODF document with {len(content_blocks)} content blocks.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create document: {str(e)}",
            "title": title,
        }


async def create_impress_document(
    arguments: Dict[str, Any],
    server: "TokenMouldsServer",
) -> Dict[str, Any]:
    """Create a styled LibreOffice Impress presentation (.odp).

    Args:
        arguments: Tool arguments from MCP call
        server: TokenMouldsServer instance

    Returns:
        Result dictionary with file path and metadata
    """
    title = arguments.get("title", "Untitled Presentation")
    slides = arguments.get("slides", [])
    brand_name = arguments.get("brand_name") or server.active_brand
    filename = arguments.get("filename")

    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join(c if c.isalnum() or c in " -_" else "" for c in title)
        safe_title = safe_title.replace(" ", "_")[:30]
        filename = f"{safe_title}_{timestamp}"

    output_file = server.output_path / f"{filename}.odp"

    try:
        # Get template
        template_bytes, template_source = await _get_impress_template(
            server, brand_name
        )

        if template_bytes is None:
            return {
                "error": "No Impress template available.",
                "suggestion": "Generate template first with generate_impress_template.",
            }

        # Inject slides (ODF format)
        document_bytes = _inject_impress_content(template_bytes, slides)

        # Write file
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_bytes(document_bytes)

        return {
            "success": True,
            "action": "create_impress_document",
            "file_path": str(output_file.absolute()),
            "filename": output_file.name,
            "title": title,
            "slides_count": len(slides),
            "template_source": template_source,
            "brand_used": brand_name or GENERIC_BRAND_NAME,
            "file_size_kb": round(len(document_bytes) / 1024, 1),
            "message": f"Created ODP presentation with {len(slides)} slides.",
        }

    except Exception as e:
        return {
            "error": f"Failed to create presentation: {str(e)}",
            "title": title,
        }
