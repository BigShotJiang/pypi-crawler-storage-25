"""MCP review surfaces for stored token review artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REVIEW_TOKEN_PROPOSAL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "review_id": {
            "type": "string",
            "description": "Review artifact identifier under generated/review/<review_id>/",
        },
        "file_path": {
            "type": "string",
            "description": "Direct path to review-bundle.json",
        },
    },
}

LIST_TOKEN_PROPOSALS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "brand_name": {
            "type": "string",
            "description": "Optional brand filter.",
        },
        "action": {
            "type": "string",
            "description": "Optional action filter (modify_brand, modify_design, propose_token_changes).",
        },
        "proposal_state": {
            "type": "string",
            "enum": ["validated", "applied", "rejected", "unknown"],
            "description": "Optional proposal lifecycle state filter.",
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 200,
            "description": "Maximum review artifacts to return (default 20).",
        },
    },
}


def _review_root(server: Any) -> Path:
    """Return the server review artifact root."""
    return Path(getattr(server, "output_path", Path("./generated"))) / "review"


def _bundle_path_from_review_id(server: Any, review_id: str) -> Path:
    """Resolve the on-disk bundle path for a review identifier."""
    return _review_root(server) / review_id / "review-bundle.json"


def _load_bundle(path: Path) -> dict[str, Any]:
    """Load one review bundle JSON file."""
    return json.loads(path.read_text(encoding="utf-8"))


def _bundle_response(path: Path, bundle: dict[str, Any]) -> dict[str, Any]:
    """Attach computed artifact metadata to a loaded bundle."""
    result = dict(bundle)
    result["artifact_path"] = str(path)
    return result


def _maybe_load_proposal(path: Path) -> dict[str, Any] | None:
    proposal_path = path.parent / "proposal.json"
    if not proposal_path.exists():
        return None
    return json.loads(proposal_path.read_text(encoding="utf-8"))


def _source_artifact_fields(
    proposal: dict[str, Any] | None,
    bundle: dict[str, Any] | None,
) -> dict[str, Any]:
    proposal = proposal or {}
    bundle = bundle or {}
    return {
        "source_token_path": proposal.get(
            "source_token_path", bundle.get("source_token_path")
        ),
        "source_audit_path": proposal.get(
            "source_audit_path", bundle.get("source_audit_path")
        ),
        "source_persisted_at": proposal.get(
            "source_persisted_at", bundle.get("source_persisted_at")
        ),
    }


def _effective_proposal_state(
    proposal: dict[str, Any] | None,
    bundle: dict[str, Any] | None,
) -> str:
    proposal = proposal or {}
    bundle = bundle or {}
    return str(proposal.get("state", bundle.get("proposal_state", "unknown")))


async def review_token_proposal(
    arguments: dict[str, Any], server: Any
) -> dict[str, Any]:
    """Read one persisted review bundle by review id or file path."""
    review_id = arguments.get("review_id")
    file_path = arguments.get("file_path")

    if bool(review_id) == bool(file_path):
        return {
            "error": "Provide exactly one of 'review_id' or 'file_path'.",
        }

    path = (
        _bundle_path_from_review_id(server, str(review_id))
        if review_id is not None
        else Path(str(file_path))
    )
    if not path.exists():
        return {
            "error": f"Review bundle not found: {path}",
        }

    bundle = _bundle_response(path, _load_bundle(path))
    result = {
        "success": True,
        "review_id": bundle["review_id"],
        "review_bundle": bundle,
    }
    proposal = _maybe_load_proposal(path)
    if proposal is not None:
        result["proposal"] = proposal
        result["proposal_id"] = proposal.get("proposal_id", bundle["review_id"])
        result["proposal_state"] = _effective_proposal_state(proposal, bundle)
    result.update(_source_artifact_fields(proposal, bundle))
    return result


async def list_token_proposals(
    arguments: dict[str, Any], server: Any
) -> dict[str, Any]:
    """List persisted review bundle artifacts."""
    review_root = _review_root(server)
    if not review_root.exists():
        return {"success": True, "reviews": []}

    brand_name = arguments.get("brand_name")
    action = arguments.get("action")
    proposal_state = arguments.get("proposal_state")
    limit = int(arguments.get("limit", 20))

    reviews: list[dict[str, Any]] = []
    for path in sorted(
        review_root.glob("*/review-bundle.json"),
        key=lambda candidate: candidate.stat().st_mtime,
        reverse=True,
    ):
        bundle = _bundle_response(path, _load_bundle(path))
        proposal = _maybe_load_proposal(path)
        if brand_name is not None and bundle.get("brand_name") != brand_name:
            continue
        if action is not None and bundle.get("action") != action:
            continue
        effective_state = _effective_proposal_state(proposal, bundle)
        if proposal_state is not None and effective_state != proposal_state:
            continue
        reviews.append(
            {
                "review_id": bundle.get("review_id"),
                "proposal_id": (proposal or {}).get(
                    "proposal_id", bundle.get("proposal_id", bundle.get("review_id"))
                ),
                "proposal_state": effective_state,
                "created_at": bundle.get("created_at"),
                "action": bundle.get("action"),
                "brand_name": bundle.get("brand_name"),
                "summary": bundle.get("summary"),
                "artifact_path": bundle.get("artifact_path"),
                "warning_count": len(bundle.get("warnings", [])),
                "semantic_diff_count": len(bundle.get("semantic_diff", [])),
                **_source_artifact_fields(proposal, bundle),
            }
        )
        if len(reviews) >= limit:
            break

    return {"success": True, "reviews": reviews}
