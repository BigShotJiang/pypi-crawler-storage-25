"""Build p:sld XML from a layout name + placeholder content dict.

Given a layout like "single_exhibit" and a placeholders dict like
``{"title": "Revenue grew", "source": "Q3 2026"}``, produce a complete
``p:sld`` XML element that references the layout's placeholders and
injects the content text.

The slide inherits geometry from the layout, which inherits from the
slide master. We only emit shape references with text bodies, no
explicit positioning.
"""

from __future__ import annotations

import lxml.etree as etree

from tokenmoulds.mcp.layout_registry import LayoutInfo, get_layout_info

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _slot_to_placeholder(
    layout_name: str,
    slot: str,
    placeholder_map: dict[str, tuple[str | None, str | None]] | None = None,
) -> tuple[str | None, str | None]:
    """Map a slot name to its PPTX placeholder (ph_type, ph_idx).

    Looks up the layout's original placeholder map from the source
    (PPTX_PLACEHOLDER_MAP, SEMANTIC_LAYOUT_SPECS, or ARCHETYPE_REGISTRY).
    """
    if placeholder_map is not None and slot in placeholder_map:
        return placeholder_map[slot]

    from tokenmoulds.dtcg.layout_recipe_catalog import (
        PPTX_PLACEHOLDER_MAP,
        SEMANTIC_LAYOUT_SPECS,
    )

    # 1. Standard layouts
    if layout_name in PPTX_PLACEHOLDER_MAP:
        return PPTX_PLACEHOLDER_MAP[layout_name].get(slot, (None, None))

    # 2. Semantic layouts
    if layout_name in SEMANTIC_LAYOUT_SPECS:
        spec = SEMANTIC_LAYOUT_SPECS[layout_name]
        return spec.placeholder_map.get(slot, (None, None))

    # 3. Archetypes: only slots that are real placeholders (have ph_type
    # or ph_idx) can be filled by slides. Named decorative shapes are
    # part of the layout and cannot be overridden per-slide.
    try:
        from tokenmoulds.archetypes.catalog import ARCHETYPE_REGISTRY

        if layout_name in ARCHETYPE_REGISTRY:
            arch = ARCHETYPE_REGISTRY[layout_name]
            for shape in arch.shapes:
                if getattr(shape, "region", None) == slot:
                    ph_type = getattr(shape, "ph_type", None)
                    ph_idx = getattr(shape, "ph_idx", None)
                    if ph_type or ph_idx:
                        return (ph_type, ph_idx)
                    break
    except ImportError:
        pass

    return (None, None)


def build_slide_xml(
    layout_name: str,
    placeholders: dict[str, str],
    *,
    shape_id_start: int = 2,
    layout_info: LayoutInfo | None = None,
    placeholder_map: dict[str, tuple[str | None, str | None]] | None = None,
) -> etree._Element:
    """Build a ``p:sld`` element from a layout name and content dict.

    Args:
        layout_name: Name of the layout (must exist in the layout registry).
        placeholders: Dict mapping slot names to text content.
        shape_id_start: Starting ID for non-group shapes (default 2,
            since group shape uses id=1).

    Returns:
        A ``p:sld`` lxml element ready to serialize.

    Raises:
        ValueError: If the layout is unknown.
    """
    info = layout_info or get_layout_info(layout_name)
    if info is None:
        raise ValueError(
            f"Unknown layout: {layout_name!r}. "
            f"Use list_layouts to see available layouts."
        )

    nsmap = {"p": P_NS, "a": A_NS, "r": R_NS}
    root = etree.Element(f"{{{P_NS}}}sld", nsmap=nsmap)
    c_sld = etree.SubElement(root, f"{{{P_NS}}}cSld")
    sp_tree = etree.SubElement(c_sld, f"{{{P_NS}}}spTree")

    # Required group shape properties (id=1)
    nv_grp = etree.SubElement(sp_tree, f"{{{P_NS}}}nvGrpSpPr")
    etree.SubElement(nv_grp, f"{{{P_NS}}}cNvPr", id="1", name="")
    etree.SubElement(nv_grp, f"{{{P_NS}}}cNvGrpSpPr")
    etree.SubElement(nv_grp, f"{{{P_NS}}}nvPr")
    grp_sp_pr = etree.SubElement(sp_tree, f"{{{P_NS}}}grpSpPr")
    xfrm = etree.SubElement(grp_sp_pr, f"{{{A_NS}}}xfrm")
    etree.SubElement(xfrm, f"{{{A_NS}}}off", x="0", y="0")
    etree.SubElement(xfrm, f"{{{A_NS}}}ext", cx="0", cy="0")
    etree.SubElement(xfrm, f"{{{A_NS}}}chOff", x="0", y="0")
    etree.SubElement(xfrm, f"{{{A_NS}}}chExt", cx="0", cy="0")

    # Emit one shape per fillable placeholder slot
    shape_id = shape_id_start
    for slot in info.slots:
        if slot not in placeholders:
            continue
        ph_type, ph_idx = _slot_to_placeholder(layout_name, slot, placeholder_map)
        # Skip slots that aren't real placeholders (named decorative shapes)
        if ph_type is None and ph_idx is None:
            continue
        text = placeholders[slot]
        _emit_placeholder_shape(
            sp_tree,
            shape_id=shape_id,
            name=f"{slot.title()} {shape_id - 1}",
            ph_type=ph_type,
            ph_idx=ph_idx,
            text=str(text),
        )
        shape_id += 1

    # Color map override (required)
    clr_map = etree.SubElement(root, f"{{{P_NS}}}clrMapOvr")
    etree.SubElement(clr_map, f"{{{A_NS}}}masterClrMapping")

    return root


def _emit_placeholder_shape(
    parent: etree._Element,
    *,
    shape_id: int,
    name: str,
    ph_type: str | None,
    ph_idx: str | None,
    text: str,
) -> etree._Element:
    """Append a ``p:sp`` element referencing a layout placeholder."""
    sp = etree.SubElement(parent, f"{{{P_NS}}}sp")

    nv = etree.SubElement(sp, f"{{{P_NS}}}nvSpPr")
    etree.SubElement(nv, f"{{{P_NS}}}cNvPr", id=str(shape_id), name=name)
    c_nv_sp_pr = etree.SubElement(nv, f"{{{P_NS}}}cNvSpPr")
    etree.SubElement(c_nv_sp_pr, f"{{{A_NS}}}spLocks", noGrp="1")
    nv_pr = etree.SubElement(nv, f"{{{P_NS}}}nvPr")
    ph = etree.SubElement(nv_pr, f"{{{P_NS}}}ph")
    if ph_type:
        ph.set("type", ph_type)
    if ph_idx:
        ph.set("idx", ph_idx)

    # Empty spPr — inherits geometry from layout/master
    etree.SubElement(sp, f"{{{P_NS}}}spPr")

    # Text body with the content
    tx_body = etree.SubElement(sp, f"{{{P_NS}}}txBody")
    etree.SubElement(tx_body, f"{{{A_NS}}}bodyPr")
    etree.SubElement(tx_body, f"{{{A_NS}}}lstStyle")

    # Split text on newlines, one paragraph per line
    for line in text.split("\n"):
        p = etree.SubElement(tx_body, f"{{{A_NS}}}p")
        if line:
            r = etree.SubElement(p, f"{{{A_NS}}}r")
            r_pr = etree.SubElement(r, f"{{{A_NS}}}rPr")
            r_pr.set("lang", "en-US")
            r_pr.set("dirty", "0")
            t = etree.SubElement(r, f"{{{A_NS}}}t")
            t.text = line
        etree.SubElement(p, f"{{{A_NS}}}endParaRPr", lang="en-US")

    return sp
