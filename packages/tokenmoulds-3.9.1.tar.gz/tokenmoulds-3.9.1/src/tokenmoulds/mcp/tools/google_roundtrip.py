"""Google Workspace import/export roundtrip tool."""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import shutil
import time
import uuid
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

from tokenmoulds.gsuite import (
    GSuiteAuthError,
    GSuiteClient,
    export_mime_for,
    native_mime_for,
    source_mime_for,
)
from tokenmoulds.mcp.artifact_plan import ArtifactPlanError, safe_artifact_id
from tokenmoulds.mcp.validation import validate_template

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


GOOGLE_SUITE_ROUNDTRIP_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": (
                "Local Office/ODF file to upload, convert to native Google "
                "Workspace format, and export back"
            ),
        },
        "artifact_id": {
            "type": "string",
            "description": (
                "Optional compiled artifact ID. When path is omitted, "
                "TokenMoulds uses generated/<artifact_id>/compile-result.json."
            ),
        },
        "target_format": {
            "type": "string",
            "enum": ["pptx", "docx", "xlsx", "odp", "odt", "ods"],
            "description": "Override the source/export format inferred from path",
        },
        "folder_id": {
            "type": "string",
            "description": (
                "Drive folder ID for staging. Falls back to "
                "TOKENMOULDS_GSUITE_FOLDER_ID or GSUITE_ORACLE_FOLDER_ID. "
                "When omitted, TokenMoulds creates and deletes a temporary "
                "staging folder."
            ),
        },
        "create_staging_folder": {
            "type": "boolean",
            "default": True,
            "description": (
                "Create a temporary Drive staging folder when folder_id is not provided"
            ),
        },
        "subject": {
            "type": "string",
            "description": (
                "Workspace user to impersonate with domain-wide delegation. "
                "Falls back to TOKENMOULDS_GSUITE_SUBJECT."
            ),
        },
        "creds_path": {
            "type": "string",
            "description": (
                "Service-account JSON path. Falls back to "
                "TOKENMOULDS_GSUITE_CREDS or GSUITE_ORACLE_CREDS."
            ),
        },
        "output_dir": {
            "type": "string",
            "description": (
                "Output directory for roundtrip artifacts. Defaults to the MCP "
                "server output path."
            ),
        },
        "keep_drive_files": {
            "type": "boolean",
            "default": False,
            "description": "Keep raw and native staging files in Drive",
        },
        "keep_artifacts": {
            "type": "boolean",
            "default": True,
            "description": "Keep local original/exported artifacts and diff report",
        },
        "validate_output": {
            "type": "boolean",
            "default": True,
            "description": "Run TokenMoulds/openxml-audit package validation on export",
        },
    },
}

_SUPPORTED_FORMATS = {"pptx", "docx", "xlsx", "odp", "odt", "ods"}


async def run_google_suite_roundtrip(
    arguments: dict[str, Any],
    server: "TokenMouldsServer",
) -> dict[str, Any]:
    """Roundtrip a local Office/ODF artifact through Google Workspace."""
    try:
        source_path = _resolve_source_path(arguments, server.output_path)
        result = roundtrip_google_suite_file(
            source_path,
            output_root=_output_root(arguments, server.output_path),
            target_format=_requested_format(arguments, source_path),
            folder_id=_folder_id(arguments),
            create_staging_folder=bool(arguments.get("create_staging_folder", True)),
            subject=_optional_string(arguments.get("subject")),
            creds_path=_optional_path(arguments.get("creds_path")),
            keep_drive_files=bool(arguments.get("keep_drive_files", False)),
            keep_artifacts=bool(arguments.get("keep_artifacts", True)),
            validate_output=bool(arguments.get("validate_output", True)),
        )
    except ArtifactPlanError as exc:
        return {"error": str(exc), "action": "run_google_suite_roundtrip"}

    return result


def roundtrip_google_suite_file(
    source_path: Path,
    *,
    output_root: Path,
    target_format: str,
    folder_id: str | None,
    create_staging_folder: bool = True,
    subject: str | None = None,
    creds_path: Path | None = None,
    keep_drive_files: bool = False,
    keep_artifacts: bool = True,
    validate_output: bool = True,
    client: Any | None = None,
) -> dict[str, Any]:
    """Upload/import/export a file through Google Workspace."""
    started = time.monotonic()
    source_path = source_path.expanduser().resolve()
    if not source_path.exists():
        raise ArtifactPlanError(f"roundtrip source does not exist: {source_path}")
    if target_format not in _SUPPORTED_FORMATS:
        raise ArtifactPlanError(f"unsupported Google Suite format: {target_format!r}")
    if not folder_id and not create_staging_folder:
        raise ArtifactPlanError(
            "Google Suite roundtrip requires a Drive folder ID when "
            "create_staging_folder is false."
        )

    run_id = uuid.uuid4().hex[:8]
    work_dir = (
        output_root
        / "google-suite-roundtrip"
        / safe_artifact_id(source_path.stem)
        / run_id
    )
    work_dir.mkdir(parents=True, exist_ok=True)
    original_path = work_dir / f"original{source_path.suffix}"
    exported_path = work_dir / f"google-roundtripped{source_path.suffix}"
    shutil.copy2(source_path, original_path)

    source_mime = source_mime_for(target_format)
    native_mime = native_mime_for(target_format)
    export_mime = export_mime_for(target_format)

    uploaded_id: str | None = None
    native_id: str | None = None
    created_folder_id: str | None = None
    notes: list[str] = []

    try:
        if client is None:
            try:
                client = GSuiteClient.from_service_account(
                    creds_path=creds_path,
                    subject=subject,
                )
            except GSuiteAuthError as exc:
                return _failed_result(
                    source_path=source_path,
                    target_format=target_format,
                    outcome="auth_failed",
                    started=started,
                    work_dir=work_dir,
                    notes=[str(exc)],
                    keep_artifacts=keep_artifacts,
                )

        active_subject = str(getattr(client, "subject", subject) or "")
        active_folder_id = folder_id
        if not active_folder_id:
            try:
                created_folder_id = client.create_folder(
                    f"TokenMoulds roundtrip {source_path.stem} {run_id}"
                )
                active_folder_id = created_folder_id
            except Exception as exc:
                return _failed_result(
                    source_path=source_path,
                    target_format=target_format,
                    outcome="folder_create_failed",
                    started=started,
                    work_dir=work_dir,
                    subject=active_subject,
                    notes=[f"folder create failed: {exc}"],
                    keep_artifacts=keep_artifacts,
                )

        try:
            uploaded_id = client.upload(
                original_path,
                parent_id=active_folder_id,
                mime_type=source_mime,
                name=f"{source_path.stem}-tokenmoulds-source{source_path.suffix}",
            )
        except Exception as exc:
            return _failed_result(
                source_path=source_path,
                target_format=target_format,
                outcome="upload_failed",
                started=started,
                work_dir=work_dir,
                subject=active_subject,
                notes=[f"upload failed: {exc}"],
                keep_artifacts=keep_artifacts,
            )

        try:
            native_id = client.convert_to_native(
                uploaded_id,
                target_mime=native_mime,
                parent_id=active_folder_id,
                name=f"{source_path.stem}-tokenmoulds-native",
            )
        except Exception as exc:
            return _failed_result(
                source_path=source_path,
                target_format=target_format,
                outcome="convert_failed",
                started=started,
                work_dir=work_dir,
                subject=active_subject,
                uploaded_id=uploaded_id,
                notes=[f"convert failed: {exc}"],
                keep_artifacts=keep_artifacts,
            )

        try:
            exported_path.write_bytes(client.export(native_id, export_mime))
        except Exception as exc:
            return _failed_result(
                source_path=source_path,
                target_format=target_format,
                outcome="export_failed",
                started=started,
                work_dir=work_dir,
                subject=active_subject,
                uploaded_id=uploaded_id,
                native_id=native_id,
                notes=[f"export failed: {exc}"],
                keep_artifacts=keep_artifacts,
            )

        diff = _compare_zip_packages(original_path, exported_path)
        validation = (
            _validate_export(exported_path, target_format) if validate_output else None
        )
        if validation and not validation.get("valid", False):
            notes.append("exported package failed TokenMoulds validation")

        has_package_diff = bool(diff["changed"] or diff["added"] or diff["removed"])
        report = {
            "success": True,
            "action": "run_google_suite_roundtrip",
            "outcome": "lossy_conversion" if has_package_diff else "preserved",
            "source_path": str(source_path),
            "target_format": target_format,
            "source_mime": source_mime,
            "native_mime": native_mime,
            "export_mime": export_mime,
            "subject": active_subject or None,
            "folder_id": active_folder_id,
            "created_staging_folder_id": created_folder_id,
            "duration_seconds": round(time.monotonic() - started, 3),
            "work_dir": str(work_dir),
            "original_path": str(original_path),
            "exported_path": str(exported_path),
            "uploaded_file_id": uploaded_id if keep_drive_files else None,
            "native_file_id": native_id if keep_drive_files else None,
            "staging_folder_kept": bool(keep_drive_files and created_folder_id),
            "size_in": source_path.stat().st_size,
            "size_out": exported_path.stat().st_size,
            "sha256_in": _sha256(source_path),
            "sha256_out": _sha256(exported_path),
            "diff": diff,
            "validation": validation,
            "notes": notes,
        }
        report_path = work_dir / "google-suite-roundtrip-result.json"
        report["report_path"] = str(report_path)
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        return report
    finally:
        if not keep_drive_files and client is not None:
            for file_id in (uploaded_id, native_id):
                if file_id:
                    with contextlib.suppress(Exception):
                        client.delete(file_id)
            if created_folder_id:
                with contextlib.suppress(Exception):
                    client.delete(created_folder_id)
        if not keep_artifacts:
            shutil.rmtree(work_dir, ignore_errors=True)


def _resolve_source_path(arguments: Mapping[str, Any], output_root: Path) -> Path:
    raw_path = _optional_string(arguments.get("path"))
    if raw_path:
        return Path(raw_path)

    artifact_id = _optional_string(arguments.get("artifact_id"))
    if not artifact_id:
        raise ArtifactPlanError("path or artifact_id is required")

    compile_result_path = (
        output_root / safe_artifact_id(artifact_id) / "compile-result.json"
    )
    if not compile_result_path.exists():
        raise ArtifactPlanError(f"compile result not found: {compile_result_path}")
    payload = json.loads(compile_result_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ArtifactPlanError("compile result must be a JSON object")

    requested_format = _optional_string(arguments.get("target_format"))
    artifacts = payload.get("artifacts")
    if not isinstance(artifacts, list):
        raise ArtifactPlanError("compile result does not contain artifacts")
    for artifact in artifacts:
        if not isinstance(artifact, Mapping):
            continue
        fmt = str(artifact.get("format") or "").lower()
        path_value = artifact.get("path")
        if requested_format and fmt != requested_format:
            continue
        if path_value:
            path = Path(str(path_value))
            return path if path.is_absolute() else output_root / path
    raise ArtifactPlanError(
        f"compile result does not contain a roundtrippable artifact: {artifact_id}"
    )


def _requested_format(arguments: Mapping[str, Any], source_path: Path) -> str:
    raw = _optional_string(arguments.get("target_format"))
    fmt = (raw or source_path.suffix.lstrip(".")).lower()
    if fmt not in _SUPPORTED_FORMATS:
        raise ArtifactPlanError(f"unsupported Google Suite format: {fmt!r}")
    return fmt


def _folder_id(arguments: Mapping[str, Any]) -> str | None:
    return (
        _optional_string(arguments.get("folder_id"))
        or os.environ.get("TOKENMOULDS_GSUITE_FOLDER_ID")
        or os.environ.get("GSUITE_ORACLE_FOLDER_ID")
    )


def _output_root(arguments: Mapping[str, Any], default: Path) -> Path:
    raw = _optional_string(arguments.get("output_dir"))
    return Path(raw) if raw else default


def _optional_path(value: Any) -> Path | None:
    raw = _optional_string(value)
    return Path(raw).expanduser() if raw else None


def _optional_string(value: Any) -> str | None:
    raw = str(value or "").strip()
    return raw or None


def _failed_result(
    *,
    source_path: Path,
    target_format: str,
    outcome: str,
    started: float,
    work_dir: Path,
    subject: str | None = None,
    uploaded_id: str | None = None,
    native_id: str | None = None,
    notes: list[str] | None = None,
    keep_artifacts: bool,
) -> dict[str, Any]:
    report = {
        "success": False,
        "action": "run_google_suite_roundtrip",
        "outcome": outcome,
        "source_path": str(source_path),
        "target_format": target_format,
        "subject": subject,
        "duration_seconds": round(time.monotonic() - started, 3),
        "work_dir": str(work_dir),
        "uploaded_file_id": uploaded_id,
        "native_file_id": native_id,
        "notes": notes or [],
    }
    if keep_artifacts:
        report_path = work_dir / "google-suite-roundtrip-result.json"
        report["report_path"] = str(report_path)
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def _compare_zip_packages(base_path: Path, head_path: Path) -> dict[str, Any]:
    if not zipfile.is_zipfile(base_path) or not zipfile.is_zipfile(head_path):
        return {
            "status": "skipped",
            "reason": "source or exported file is not a ZIP package",
            "changed": [],
            "added": [],
            "removed": [],
        }

    base_hashes = _zip_hashes(base_path)
    head_hashes = _zip_hashes(head_path)
    base_names = set(base_hashes)
    head_names = set(head_hashes)
    added = sorted(head_names - base_names)
    removed = sorted(base_names - head_names)
    changed = sorted(
        name
        for name in base_names & head_names
        if base_hashes[name] != head_hashes[name]
    )
    return {
        "status": "compared",
        "changed": changed,
        "added": added,
        "removed": removed,
        "changed_count": len(changed),
        "added_count": len(added),
        "removed_count": len(removed),
    }


def _zip_hashes(path: Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    with zipfile.ZipFile(path, "r") as zf:
        for name in sorted(zf.namelist()):
            if name.endswith("/"):
                continue
            hashes[name] = hashlib.sha256(zf.read(name)).hexdigest()
    return hashes


def _validate_export(path: Path, target_format: str) -> dict[str, Any]:
    result = validate_template(
        path.read_bytes(),
        format_hint=_validation_format_for(target_format),
        strict_mode=True,
        extract_structure=False,
    )
    return result.to_dict()


def _validation_format_for(target_format: str) -> str:
    mapping = {
        "pptx": "powerpoint",
        "docx": "word",
        "xlsx": "excel",
        "odp": "impress",
        "odt": "writer",
        "ods": "calc",
    }
    return mapping.get(target_format, target_format)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


__all__ = [
    "GOOGLE_SUITE_ROUNDTRIP_SCHEMA",
    "roundtrip_google_suite_file",
    "run_google_suite_roundtrip",
]
