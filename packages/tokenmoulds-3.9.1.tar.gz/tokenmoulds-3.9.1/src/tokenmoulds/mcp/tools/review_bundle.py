"""Review bundle helpers for curated MCP token controls."""

from __future__ import annotations

from dataclasses import asdict
import json
from datetime import datetime, timezone
from pathlib import Path
import re
from typing import Any, Mapping

from tokenmoulds.dtcg.long_form_resolver import resolve_headers_and_footers
from tokenmoulds.semantic.collectors import collect_header_footer_semantic_provenance
from tokenmoulds.semantic.provenance import SemanticProvenance


def _flatten_authored_values(
    value: Mapping[str, Any],
    *,
    prefix: str = "",
) -> dict[str, Any]:
    """Flatten a nested authored-value mapping into dotted leaf paths."""
    result: dict[str, Any] = {}
    for key, nested in value.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(nested, Mapping):
            result.update(_flatten_authored_values(nested, prefix=path))
        else:
            result[path] = nested
    return result


def _authored_diff(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Return a compact authored diff for review bundles."""
    before_flat = _flatten_authored_values(before)
    after_flat = _flatten_authored_values(after)
    paths = sorted(set(before_flat) | set(after_flat))
    return [
        {
            "path": path,
            "before": before_flat.get(path),
            "after": after_flat.get(path),
        }
        for path in paths
        if before_flat.get(path) != after_flat.get(path)
    ]


def _semantic_entries_for_tokens(
    brand_name: str,
    tokens: Mapping[str, Any],
) -> tuple[SemanticProvenance, ...]:
    """Collect semantic provenance entries for the current token payload."""
    if not any(key in tokens for key in ("headers", "footers")):
        return ()

    registry = resolve_headers_and_footers(dict(tokens))
    return collect_header_footer_semantic_provenance(
        tokens,
        header_footer_registry=registry,
        org_id=brand_name,
    )


def _format_impact_summary(
    semantic_entries: tuple[SemanticProvenance, ...],
) -> dict[str, list[str]]:
    """Summarize per-format semantic lowering impact."""
    summary: dict[str, list[str]] = {}
    for format_name in ("word", "writer", "excel"):
        format_decisions = [
            decision
            for entry in semantic_entries
            for decision in entry.per_format.get(format_name, ())
        ]
        if not format_decisions:
            continue

        native = sum(1 for decision in format_decisions if decision.mode == "native")
        fallback = sum(
            1 for decision in format_decisions if decision.mode == "fallback"
        )
        literal = sum(1 for decision in format_decisions if decision.mode == "literal")
        unsupported = sum(
            1 for decision in format_decisions if decision.mode == "unsupported"
        )

        messages: list[str] = []
        if native:
            messages.append(f"{native} semantic item(s) remain native")
        if fallback:
            messages.append(f"{fallback} semantic item(s) lower via fallback")
        if literal:
            messages.append(f"{literal} semantic item(s) lower as literal text")
        if unsupported:
            messages.append(f"{unsupported} semantic item(s) are unsupported")
        summary[format_name] = messages
    return summary


def _semantic_warnings(
    semantic_entries: tuple[SemanticProvenance, ...],
) -> list[str]:
    """Extract warning lines from semantic provenance decisions."""
    warnings: list[str] = []
    for entry in semantic_entries:
        if entry.diagnostics:
            diagnostics = ", ".join(entry.diagnostics)
            warnings.append(f"{entry.source_path}: diagnostics={diagnostics}")
        for format_name, decisions in entry.per_format.items():
            for decision in decisions:
                if decision.mode in {"fallback", "unsupported"} and decision.reason:
                    warnings.append(
                        f"{entry.source_path} [{format_name} {decision.mode}]: "
                        f"{decision.reason}"
                    )
    return warnings


def _slug(value: str) -> str:
    """Return a filesystem-friendly lowercase slug."""
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "item"


def make_review_id(
    action: str,
    brand_name: str,
    *,
    now: datetime | None = None,
) -> str:
    """Create a review artifact identifier."""
    timestamp = (now or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{_slug(action)}-{_slug(brand_name)}-{timestamp}"


def build_curated_review_bundle(
    *,
    action: str,
    brand_name: str,
    authored_before: Mapping[str, Any],
    authored_after: Mapping[str, Any],
    token_payload: Mapping[str, Any],
) -> dict[str, Any]:
    """Build a lightweight review bundle for fast-path curated controls."""
    now = datetime.now(timezone.utc)
    semantic_entries = _semantic_entries_for_tokens(brand_name, token_payload)
    review_id = make_review_id(action, brand_name, now=now)
    return {
        "review_id": review_id,
        "created_at": now.isoformat(),
        "action": action,
        "brand_name": brand_name,
        "summary": f"{action} updated brand '{brand_name}'",
        "token_diff": _authored_diff(authored_before, authored_after),
        "semantic_diff": [
            {
                "source_path": entry.source_path,
                "authored_value": entry.authored_value,
                "normalized_value": entry.normalized_value,
                "diagnostics": list(entry.diagnostics),
            }
            for entry in semantic_entries
        ],
        "resolved_metric_diff": [],
        "format_impact": _format_impact_summary(semantic_entries),
        "warnings": _semantic_warnings(semantic_entries),
        "preview_artifacts": [],
        "apply_options": ["already_applied_in_memory"],
        "semantic_provenance": [asdict(entry) for entry in semantic_entries],
    }


def build_proposal_review_bundle(
    *,
    proposal_id: str,
    brand_name: str,
    summary: str,
    token_diff: list[dict[str, Any]],
    token_payload: Mapping[str, Any],
    extra_warnings: list[str] | None = None,
) -> dict[str, Any]:
    """Build a review bundle for a persisted token proposal."""
    semantic_entries = _semantic_entries_for_tokens(brand_name, token_payload)
    warnings = _semantic_warnings(semantic_entries)
    if extra_warnings:
        warnings.extend(extra_warnings)
    return {
        "review_id": proposal_id,
        "proposal_id": proposal_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "action": "propose_token_changes",
        "proposal_state": "validated",
        "brand_name": brand_name,
        "summary": summary,
        "token_diff": token_diff,
        "semantic_diff": [
            {
                "source_path": entry.source_path,
                "authored_value": entry.authored_value,
                "normalized_value": entry.normalized_value,
                "diagnostics": list(entry.diagnostics),
            }
            for entry in semantic_entries
        ],
        "resolved_metric_diff": [],
        "format_impact": _format_impact_summary(semantic_entries),
        "warnings": warnings,
        "preview_artifacts": [],
        "apply_options": [
            "review_token_proposal",
            "apply_token_proposal",
            "reject_token_proposal",
        ],
        "semantic_provenance": [asdict(entry) for entry in semantic_entries],
    }


def persist_review_bundle(
    review_bundle: Mapping[str, Any],
    *,
    output_root: Path,
) -> Path:
    """Persist a review bundle under ``<output_root>/review/<review_id>/``."""
    review_id = review_bundle.get("review_id")
    if not isinstance(review_id, str) or not review_id:
        raise ValueError("review_bundle missing string review_id")

    artifact_dir = output_root / "review" / review_id
    artifact_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = artifact_dir / "review-bundle.json"
    artifact_path.write_text(
        json.dumps(dict(review_bundle), indent=2), encoding="utf-8"
    )
    return artifact_path
