"""MCP tool: modify_brand — change design tokens or apply a preset.

Gives AI agents level 2 control over document generation: change the
brand without regenerating tokens from scratch. Merges individual
overrides or a preset into the active brand's input values and
re-derives the complete token system.

Preset + override combination:
  preset_values ← BRAND_PRESETS[preset]  (if preset specified)
  final_values  ← preset_values | individual_overrides
  tokens        ← TokenGenerator().generate(final_values)
"""

from __future__ import annotations

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


#: Curated brand presets. Each preset is a partial generator input dict
#: that gets merged with the user's individual overrides.
BRAND_PRESETS: Dict[str, Dict[str, Any]] = {
    "corporate": {
        "brand_tone": 0.15,
        "content_density": 0.7,
        "font_pair": {"sans": "Inter", "serif": "Merriweather"},
    },
    "startup": {
        "brand_tone": 0.7,
        "content_density": 0.4,
        "font_pair": {"sans": "Inter", "serif": "Roboto Slab"},
    },
    "editorial": {
        "brand_tone": 0.3,
        "content_density": 0.5,
        "font_pair": {"sans": "Source Sans 3", "serif": "Source Serif 4"},
    },
    "academic": {
        "brand_tone": 0.1,
        "content_density": 0.8,
        "font_pair": {"sans": "Noto Sans", "serif": "Noto Serif"},
    },
    "creative": {
        "brand_tone": 0.9,
        "content_density": 0.3,
        "font_pair": {"sans": "Space Grotesk", "serif": "Fraunces"},
    },
}


MODIFY_BRAND_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "preset": {
            "type": "string",
            "enum": list(BRAND_PRESETS.keys()),
            "description": "Apply a curated brand preset. Individual overrides below cherry-pick from the preset base.",
        },
        "brand_tone": {
            "type": "number",
            "minimum": 0,
            "maximum": 1,
            "description": "Formal (0) to casual (1). Affects ligatures, figure styles, type scale.",
        },
        "primary_color": {
            "type": "string",
            "description": "Hex color for the primary brand color (e.g. #2563EB)",
        },
        "secondary_color": {
            "type": "string",
            "description": "Hex color for the secondary/accent color",
        },
        "font_sans": {
            "type": "string",
            "description": "Sans-serif font family name (body/UI text)",
        },
        "font_serif": {
            "type": "string",
            "description": "Serif font family name (headings)",
        },
        "content_density": {
            "type": "number",
            "minimum": 0,
            "maximum": 1,
            "description": "Sparse (0) to dense (1). Affects spacing, margins, line heights.",
        },
        "locale": {
            "type": "string",
            "description": "Locale code (US, GB, DE, FR, JP, etc.)",
        },
        "baseline_pt": {
            "type": "number",
            "minimum": 6,
            "maximum": 18,
            "description": "Baseline grid in points (default 11)",
        },
        "brand_name": {
            "type": "string",
            "description": "Target brand to modify (defaults to active brand)",
        },
    },
}


def _merge_inputs(
    base: Dict[str, Any],
    overrides: Dict[str, Any],
) -> Dict[str, Any]:
    """Deep-merge override dict into base dict.

    Dicts are merged recursively; other values replace.
    """
    result = {k: v for k, v in base.items()}
    for key, value in overrides.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge_inputs(result[key], value)
        else:
            result[key] = value
    return result


def _build_generator_inputs(
    current_inputs: Dict[str, Any],
    arguments: Dict[str, Any],
) -> Dict[str, Any]:
    """Merge preset + overrides into existing generator inputs.

    Precedence (low to high):
      1. current_inputs (from active brand)
      2. preset (if specified)
      3. individual overrides (brand_tone, primary_color, etc.)
    """
    merged = {k: v for k, v in current_inputs.items()}

    # Layer 1: apply preset
    preset_name = arguments.get("preset")
    if preset_name and preset_name in BRAND_PRESETS:
        merged = _merge_inputs(merged, BRAND_PRESETS[preset_name])

    # Layer 2: individual overrides
    if "brand_tone" in arguments:
        merged["brand_tone"] = float(arguments["brand_tone"])
    if "content_density" in arguments:
        merged["content_density"] = float(arguments["content_density"])
    if "locale" in arguments:
        merged["locale"] = str(arguments["locale"])
    if "baseline_pt" in arguments:
        merged["base_grid_pt"] = float(arguments["baseline_pt"])

    # Color overrides
    base_colors = dict(merged.get("base_colors") or {})
    if "primary_color" in arguments:
        base_colors["primary"] = str(arguments["primary_color"])
    if "secondary_color" in arguments:
        base_colors["secondary"] = str(arguments["secondary_color"])
    if base_colors:
        merged["base_colors"] = base_colors

    # Font pair overrides
    font_pair = dict(merged.get("font_pair") or {})
    if "font_sans" in arguments:
        font_pair["sans"] = str(arguments["font_sans"])
    if "font_serif" in arguments:
        font_pair["serif"] = str(arguments["font_serif"])
    if font_pair:
        merged["font_pair"] = font_pair

    return merged


def _extract_current_inputs(loaded_tokens: Dict[str, Any]) -> Dict[str, Any]:
    """Extract generator inputs from already-derived tokens.

    The loaded token set has an "inputs" field containing the
    normalized inputs that produced the tokens. Round-trip those
    through the modify operation.
    """
    inputs = loaded_tokens.get("inputs") or {}
    if not isinstance(inputs, dict):
        return {}

    def _normalize(value: Any) -> Any:
        if isinstance(value, dict):
            if "$value" in value:
                return _normalize(value["$value"])
            return {key: _normalize(nested) for key, nested in value.items()}
        if isinstance(value, list):
            return [_normalize(item) for item in value]
        return value

    # The inputs section has nested structure; flatten to generator format
    result: Dict[str, Any] = {}

    # Newer generator/CLI outputs already store flat generator inputs.
    for key, value in inputs.items():
        if key in {"color", "font", "number"}:
            continue
        result[key] = _normalize(value)

    color = inputs.get("color", {})
    if isinstance(color, dict):
        primary = color.get("primary")
        secondary = color.get("secondary")
        if isinstance(primary, dict):
            primary = primary.get("$value")
        if isinstance(secondary, dict):
            secondary = secondary.get("$value")
        if primary or secondary:
            result.setdefault("base_colors", {})
            if primary:
                result["base_colors"].setdefault("primary", primary)
            if secondary:
                result["base_colors"].setdefault("secondary", secondary)

    font = inputs.get("font", {})
    if isinstance(font, dict):
        sans = font.get("sans")
        serif = font.get("serif")
        if isinstance(sans, dict):
            sans = sans.get("$value")
        if isinstance(serif, dict):
            serif = serif.get("$value")
        if sans or serif:
            result.setdefault("font_pair", {})
            if sans:
                result["font_pair"].setdefault("sans", sans)
            if serif:
                result["font_pair"].setdefault("serif", serif)

    number = inputs.get("number", {})
    if isinstance(number, dict):
        tone = number.get("brandTone")
        density = number.get("contentDensity")
        if isinstance(tone, dict):
            tone = tone.get("$value")
        if isinstance(density, dict):
            density = density.get("$value")
        if tone is not None:
            result.setdefault("brand_tone", float(tone))
        if density is not None:
            result.setdefault("content_density", float(density))

    return result


async def modify_brand(
    arguments: Dict[str, Any],
    server: Any,
) -> Dict[str, Any]:
    """Modify brand tokens by applying overrides and/or a preset.

    Re-derives all tokens through TokenGenerator and updates the
    server's active brand. Subsequent create_document / create_presentation
    calls use the modified brand.
    """
    from tokenmoulds.dtcg.generator import TokenGenerator
    from pathlib import Path

    from tokenmoulds.mcp.tools.review_bundle import (
        build_curated_review_bundle,
        persist_review_bundle,
    )

    brand_name = arguments.get("brand_name") or server.active_brand
    if not brand_name:
        return {
            "error": "No active brand. Load or set a brand first.",
            "suggestion": "Use load_brand or set_active_brand before modify_brand.",
        }

    # Extract current inputs (if a brand is loaded) or start empty
    current_tokens = server.loaded_tokens.get(brand_name, {})
    current_inputs = _extract_current_inputs(current_tokens)

    # Merge preset + overrides
    merged_inputs = _build_generator_inputs(current_inputs, arguments)

    if not merged_inputs:
        return {
            "error": "No changes specified.",
            "suggestion": "Provide a preset or at least one token override.",
        }

    # Re-derive all tokens
    try:
        generator = TokenGenerator()
        new_tokens = generator.generate(merged_inputs)
    except Exception as exc:
        return {
            "error": f"Token generation failed: {exc}",
            "inputs": merged_inputs,
        }

    # Re-apply any persistent design overlay (from modify_design calls)
    try:
        from tokenmoulds.mcp.tools.design_modifier import _apply_design_overlay

        design_overlays = getattr(server, "design_overlays", {}) or {}
        overlay = design_overlays.get(brand_name)
        if overlay:
            _apply_design_overlay(new_tokens, overlay)
    except Exception as exc:
        logger.warning("Failed to re-apply design overlay: %s", exc)

    # Update server state
    server.loaded_tokens[brand_name] = new_tokens
    if server.active_brand is None:
        server.active_brand = brand_name

    # Invalidate template cache so subsequent creates rebuild with new tokens
    cache_cleared = False
    try:
        if hasattr(server, "cache_manager") and server.cache_manager is not None:
            server.cache_manager.invalidate(brand_name)
            cache_cleared = True
    except Exception as exc:
        logger.warning("Failed to invalidate template cache: %s", exc)

    # Summarize what changed
    changes: Dict[str, Any] = {}
    if arguments.get("preset"):
        changes["preset"] = arguments["preset"]
    for key in (
        "brand_tone",
        "content_density",
        "primary_color",
        "secondary_color",
        "font_sans",
        "font_serif",
        "locale",
        "baseline_pt",
    ):
        if key in arguments:
            changes[key] = arguments[key]

    review_bundle = build_curated_review_bundle(
        action="modify_brand",
        brand_name=brand_name,
        authored_before=current_inputs,
        authored_after=merged_inputs,
        token_payload=new_tokens,
    )
    review_bundle_path: str | None = None
    output_root = getattr(server, "output_path", None)
    if output_root is not None:
        artifact_path = persist_review_bundle(
            review_bundle,
            output_root=Path(output_root),
        )
        review_bundle["artifact_path"] = str(artifact_path)
        review_bundle_path = str(artifact_path)

    return {
        "success": True,
        "action": "modify_brand",
        "brand": brand_name,
        "changes": changes,
        "cache_cleared": cache_cleared,
        "inputs_applied": merged_inputs,
        "review_bundle": review_bundle,
        "review_bundle_path": review_bundle_path,
        "message": (
            f"Modified brand '{brand_name}'. "
            f"Next create_document/create_presentation will rebuild the template."
        ),
    }
