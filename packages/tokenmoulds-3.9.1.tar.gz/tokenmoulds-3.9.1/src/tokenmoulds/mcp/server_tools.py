"""Tool registration and dispatch helpers for the TokenMoulds MCP server.

Free functions taking the concrete ``TokenMouldsServer`` as their first
argument.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List

from mcp.types import Tool

from tokenmoulds.mcp.server_support import (
    clear_cache,
    list_cache,
    list_layouts,
    list_styles,
    validate_template,
)

# Add-in and macro tools
from tokenmoulds.mcp.tools.addin_certificates import (
    GENERATE_CERTIFICATE_SCHEMA,
    LIST_CERTIFICATES_SCHEMA,
    generate_self_signed_certificate,
    list_certificates,
)
from tokenmoulds.mcp.tools.addin_signer import (
    CREATE_VBA_ADDIN_SCHEMA,
    create_vba_addin,
)
from tokenmoulds.mcp.tools.addin_web import (
    CREATE_WEB_ADDIN_SCHEMA,
    create_web_addin,
)
from tokenmoulds.mcp.tools.artifact_compiler import (
    COMPILE_ARTIFACT_SCHEMA,
    compile_artifact,
)
from tokenmoulds.mcp.tools.artifact_review import (
    ARTIFACT_REVIEW_BUNDLE_SCHEMA,
    create_artifact_review_bundle,
)
from tokenmoulds.mcp.tools.artifact_planner import (
    CREATE_ARTIFACT_PLAN_SCHEMA,
    VALIDATE_ARTIFACT_PLAN_SCHEMA,
    create_artifact_plan,
    validate_artifact_plan,
)
from tokenmoulds.mcp.tools.github_publish import (
    OPEN_GITHUB_PR_SCHEMA,
    open_github_pr,
)
from tokenmoulds.mcp.tools.google_apps_script import (
    DEPLOY_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
    GENERATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
    deploy_google_apps_script_bundle,
    generate_google_apps_script_bundle,
    VALIDATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
    validate_google_apps_script_bundle,
)
from tokenmoulds.mcp.tools.google_roundtrip import (
    GOOGLE_SUITE_ROUNDTRIP_SCHEMA,
    run_google_suite_roundtrip,
)
from tokenmoulds.mcp.tools.quality_gate import (
    QUALITY_GATE_SCHEMA,
    run_document_quality_gate,
)

# Brand management tools
from tokenmoulds.mcp.tools.brand_manager import (
    BUILD_RECIPE_SCHEMA,
    EXTRACT_BRAND_SCHEMA,
    LIST_BRANDS_SCHEMA,
    LOAD_BRAND_SCHEMA,
    SET_ACTIVE_BRAND_SCHEMA,
    build_recipe_from_inputs,
    extract_brand_from_url,
    list_brands,
    load_brand,
    set_active_brand,
)

# Brand modification (level 2 AI control)
from tokenmoulds.mcp.tools.brand_modifier import (
    MODIFY_BRAND_SCHEMA,
    modify_brand,
)
from tokenmoulds.mcp.tools.corporate_github import (
    LINK_CORPORATE_GITHUB_SCHEMA,
    link_corporate_github,
)

# Design modification (level 3 AI control)
from tokenmoulds.mcp.tools.design_modifier import (
    MODIFY_DESIGN_SCHEMA,
    modify_design,
)

# Document creation tools (full pipeline - no bundled fallbacks)
from tokenmoulds.mcp.tools.document_creator import (
    create_excel_document,
    create_impress_document,
    create_powerpoint_document,
    create_word_document,
    create_writer_document,
)
from tokenmoulds.mcp.tools.document_creator_schemas import (
    CREATE_EXCEL_DOCUMENT_SCHEMA,
    CREATE_IMPRESS_DOCUMENT_SCHEMA,
    CREATE_POWERPOINT_DOCUMENT_SCHEMA,
    CREATE_WORD_DOCUMENT_SCHEMA,
    CREATE_WRITER_DOCUMENT_SCHEMA,
)
from tokenmoulds.mcp.tools.python_pptx_bridge import (
    TRANSLATE_PYTHON_PPTX_INTENT_SCHEMA,
    translate_python_pptx_intent,
)
from tokenmoulds.mcp.tools.review_proposal import (
    LIST_TOKEN_PROPOSALS_SCHEMA,
    REVIEW_TOKEN_PROPOSAL_SCHEMA,
    list_token_proposals,
    review_token_proposal,
)

# Template generation tools
from tokenmoulds.mcp.tools.template_generator import (
    generate_excel_template,
    generate_google_docs_template,
    generate_impress_template,
    generate_powerpoint_template,
    generate_theme,
    generate_word_template,
    generate_writer_template,
)
from tokenmoulds.mcp.tools.template_generator_batch import generate_all_templates
from tokenmoulds.mcp.tools.template_generator_schemas import (
    GENERATE_ALL_TEMPLATES_SCHEMA,
    GENERATE_EXCEL_TEMPLATE_SCHEMA,
    GENERATE_GOOGLE_DOCS_TEMPLATE_SCHEMA,
    GENERATE_IMPRESS_TEMPLATE_SCHEMA,
    GENERATE_POWERPOINT_TEMPLATE_SCHEMA,
    GENERATE_THEME_SCHEMA,
    GENERATE_WORD_TEMPLATE_SCHEMA,
    GENERATE_WRITER_TEMPLATE_SCHEMA,
)
from tokenmoulds.mcp.tools.token_proposal import (
    APPLY_TOKEN_PROPOSAL_SCHEMA,
    PROPOSE_TOKEN_CHANGES_SCHEMA,
    REJECT_TOKEN_PROPOSAL_SCHEMA,
    apply_token_proposal,
    propose_token_changes,
    reject_token_proposal,
)
from tokenmoulds.mcp.tools.user_context import (
    GET_USER_CONTEXT_SCHEMA,
    INFER_BRAND_SCHEMA,
    SET_USER_CONTEXT_SCHEMA,
    get_user_context,
    infer_brand_from_email,
    set_user_context,
)

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import TokenMouldsServer


def register_tools(server: TokenMouldsServer) -> None:
    """Register all MCP tools on the underlying ``server.server`` instance."""

    @server.server.list_tools()  # type: ignore[untyped-decorator]
    async def list_tools() -> List[Tool]:
        """List all available tools."""
        return [
            # ============================================================
            # USER CONTEXT TOOLS
            # ============================================================
            Tool(
                name="set_user_context",
                description="Set user context from email. Automatically extracts domain, infers brand name, and fetches brand from organization's website CSS.",
                inputSchema=SET_USER_CONTEXT_SCHEMA,
            ),
            Tool(
                name="infer_brand_from_email",
                description="Infer brand by fetching website CSS from email domain. user@democorp.com → https://democorp.com → extract colors/fonts → brand tokens ready.",
                inputSchema=INFER_BRAND_SCHEMA,
            ),
            Tool(
                name="get_user_context",
                description="Get current user context including email, domain, and active brand.",
                inputSchema=GET_USER_CONTEXT_SCHEMA,
            ),
            # ============================================================
            # BRAND MANAGEMENT TOOLS
            # ============================================================
            Tool(
                name="extract_brand_from_url",
                description="Extract brand colors, fonts, and styling from a website URL. Generates complete DTCG design tokens with derivation formulas. Full pipeline: URL → CSS → Brand → Recipe → Tokens.",
                inputSchema=EXTRACT_BRAND_SCHEMA,
            ),
            Tool(
                name="build_recipe_from_inputs",
                description="Build DTCG design tokens from minimal inputs (colors, fonts, parameters). Creates a complete token system with formulas, page layouts, and 100+ paragraph/character styles.",
                inputSchema=BUILD_RECIPE_SCHEMA,
            ),
            Tool(
                name="load_brand",
                description="Load existing design tokens from a directory. Supports DTCG (*.tokens.json) and legacy (*-design-tokens.json) formats.",
                inputSchema=LOAD_BRAND_SCHEMA,
            ),
            Tool(
                name="list_brands",
                description="List all loaded and cached brands with their status and available templates.",
                inputSchema=LIST_BRANDS_SCHEMA,
            ),
            Tool(
                name="set_active_brand",
                description="Set the active brand for template and document generation.",
                inputSchema=SET_ACTIVE_BRAND_SCHEMA,
            ),
            Tool(
                name="link_corporate_github",
                description="Link a corporate GitHub brand repository to the MCP session. Fetches brand-manifest.yaml and its token source, loads the brand into cache, and records repository/ref provenance for follow-on artifact plans.",
                inputSchema=LINK_CORPORATE_GITHUB_SCHEMA,
            ),
            Tool(
                name="modify_brand",
                description="Modify the active brand's design tokens. Apply a curated preset (corporate, startup, editorial, academic, creative) and/or override individual values (brand_tone, primary_color, font_sans, etc.). Re-derives the complete token system and invalidates the template cache so the next create_document/create_presentation uses the updated brand. This is level 2 AI control — change the design system, not just content.",
                inputSchema=MODIFY_BRAND_SCHEMA,
            ),
            Tool(
                name="modify_design",
                description="Adjust typographic formulas via curated presets. Scale ratio (minor_second to golden_ratio), tracking curve (tight/neutral/loose), heading spacing (compact/standard/dramatic), figure style, optical margin, small caps mode. This is level 3 AI control — change the typographic algebra without touching individual values. Design overlays persist through modify_brand calls.",
                inputSchema=MODIFY_DESIGN_SCHEMA,
            ),
            Tool(
                name="review_token_proposal",
                description="Read a stored token review bundle by review_id or file_path. This is the first review surface over persisted curated-control artifacts and aligns with the future proposal workflow.",
                inputSchema=REVIEW_TOKEN_PROPOSAL_SCHEMA,
            ),
            Tool(
                name="propose_token_changes",
                description="Validate and persist a token proposal without mutating the active brand. Produces proposal.json plus review-bundle.json under generated/review/<proposal_id>/.",
                inputSchema=PROPOSE_TOKEN_CHANGES_SCHEMA,
            ),
            Tool(
                name="apply_token_proposal",
                description="Apply a persisted token proposal to the in-memory brand state and mark the proposal artifact as applied.",
                inputSchema=APPLY_TOKEN_PROPOSAL_SCHEMA,
            ),
            Tool(
                name="reject_token_proposal",
                description="Reject a persisted token proposal without mutating live tokens, and mark the stored proposal artifact as rejected.",
                inputSchema=REJECT_TOKEN_PROPOSAL_SCHEMA,
            ),
            Tool(
                name="list_token_proposals",
                description="List stored token review bundles under generated/review/, optionally filtered by brand or action.",
                inputSchema=LIST_TOKEN_PROPOSALS_SCHEMA,
            ),
            Tool(
                name="create_artifact_plan",
                description="Create a typed, reviewable artifact plan from business intent before compiling documents. This is the LLM-safe handoff object: purpose, audience, semantic sections, output formats, corporate GitHub provenance, required checks, and embedded artifact-intent metadata.",
                inputSchema=CREATE_ARTIFACT_PLAN_SCHEMA,
            ),
            Tool(
                name="validate_artifact_plan",
                description="Validate a persisted or inline ArtifactPlan before compilation. Returns normalized plan data, plan hash, warnings, and recommended next tools.",
                inputSchema=VALIDATE_ARTIFACT_PLAN_SCHEMA,
            ),
            Tool(
                name="compile_artifact",
                description="Compile a stored or inline ArtifactPlan into deterministic Office/ODF artifacts. Loads the plan, constrains formats to approved outputs, dispatches to existing document/template tools, hashes artifacts, and returns quality-gate guidance.",
                inputSchema=COMPILE_ARTIFACT_SCHEMA,
            ),
            Tool(
                name="run_document_quality_gate",
                description="Validate compiled artifact paths with package checks, artifact-intent inspection, openxml-audit-backed OOXML validation, and optional LibreOffice render checks. Persists a quality gate report alongside the artifact outputs.",
                inputSchema=QUALITY_GATE_SCHEMA,
            ),
            Tool(
                name="create_artifact_review_bundle",
                description="Create a deterministic review bundle from a compiled artifact, its plan, and the quality-gate result. Persists a review artifact under generated/review/ with paths, hashes, validation results, warnings, and evidence.",
                inputSchema=ARTIFACT_REVIEW_BUNDLE_SCHEMA,
            ),
            Tool(
                name="open_github_pr",
                description="Create or update a GitHub pull request for a compiled artifact review. Uses a GitHub adapter to create a branch, stage generated outputs and evidence, and publish the review bundle through a scoped PR workflow.",
                inputSchema=OPEN_GITHUB_PR_SCHEMA,
            ),
            Tool(
                name="generate_google_apps_script_bundle",
                description="Generate a Google Apps Script project bundle that the user can deploy or paste into script.google.com. This is the repo's Google route; the script runs under the user's own Google identity and creates Docs, Slides, or Sheets from the embedded TokenMoulds job payload.",
                inputSchema=GENERATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
            ),
            Tool(
                name="validate_google_apps_script_bundle",
                description="Validate a generated TokenMoulds Apps Script bundle locally. Confirms the generated Code.gs embeds the same job as tokenmoulds-job.json, checks manifest scopes, and ensures the bundle is ready for Apps Script deployment or user-run execution.",
                inputSchema=VALIDATE_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
            ),
            Tool(
                name="deploy_google_apps_script_bundle",
                description="Deploy a TokenMoulds Apps Script bundle directly through the Google Apps Script API. This creates or updates a user-owned Apps Script project from the stored ArtifactPlan and returns the script ID and edit URL.",
                inputSchema=DEPLOY_GOOGLE_APPS_SCRIPT_BUNDLE_SCHEMA,
            ),
            Tool(
                name="run_google_suite_roundtrip",
                description="Upload a local Office/ODF artifact to Drive, import it into native Google Workspace format, export it back, and report package diff plus validation evidence. This uses the openxml-audit style Drive roundtrip plumbing.",
                inputSchema=GOOGLE_SUITE_ROUNDTRIP_SCHEMA,
            ),
            # ============================================================
            # TEMPLATE GENERATION TOOLS
            # ============================================================
            Tool(
                name="generate_word_template",
                description="Generate Word template (.dotx) with 276 themed styles. Full TokenMoulds pipeline with font embedding, ISO 29500 compliance, zero Office defaults.",
                inputSchema=GENERATE_WORD_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_powerpoint_template",
                description="Generate PowerPoint template (.potx) with professional table styles, theme colors, and font embedding. ISO 29500 compliant.",
                inputSchema=GENERATE_POWERPOINT_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_excel_template",
                description="Generate Excel template (.xltx) with themed cell styles and colors.",
                inputSchema=GENERATE_EXCEL_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_writer_template",
                description="Generate LibreOffice Writer template (.ott) with ODF-compliant styles.",
                inputSchema=GENERATE_WRITER_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_impress_template",
                description="Generate LibreOffice Impress template (.otp) with ODF-compliant slides.",
                inputSchema=GENERATE_IMPRESS_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_google_docs_template",
                description="Generate Google Docs-compatible template (.dotx optimized for Google Workspace import).",
                inputSchema=GENERATE_GOOGLE_DOCS_TEMPLATE_SCHEMA,
            ),
            Tool(
                name="generate_theme",
                description="Generate standalone Office theme (.thmx) that can be applied to any Office document.",
                inputSchema=GENERATE_THEME_SCHEMA,
            ),
            Tool(
                name="generate_all_templates",
                description="Generate all template formats for a brand in one call (Word, PowerPoint, Excel, Writer, Impress, Google Docs, Theme).",
                inputSchema=GENERATE_ALL_TEMPLATES_SCHEMA,
            ),
            # ============================================================
            # DOCUMENT CREATION TOOLS
            # All documents from TokenMoulds templates (with generic fallback)
            # ============================================================
            Tool(
                name="create_word_document",
                description="Create a professionally styled Word document (.docx) with content. Full TokenMoulds pipeline with 276 themed styles. Uses brand template or generic TokenMoulds template.",
                inputSchema=CREATE_WORD_DOCUMENT_SCHEMA,
            ),
            Tool(
                name="create_powerpoint_document",
                description=(
                    "Create a styled PowerPoint presentation (.pptx). "
                    "For ordinary 'make slides' requests, pass markdown/content "
                    "and let TokenMoulds plan layouts. If source content is "
                    "missing, the tool returns a polite clarification prompt; "
                    "ask about brief, audience, and slide count, not grids or placeholders."
                ),
                inputSchema=CREATE_POWERPOINT_DOCUMENT_SCHEMA,
            ),
            Tool(
                name="translate_python_pptx_intent",
                description="Translate a python-pptx-style snippet or operations list into TokenMoulds create_powerpoint_document arguments. The snippet is parsed but never executed; use this when an LLM naturally reaches for python-pptx concepts.",
                inputSchema=TRANSLATE_PYTHON_PPTX_INTENT_SCHEMA,
            ),
            Tool(
                name="create_excel_document",
                description="Create a styled Excel workbook (.xlsx) with sheets. Uses TokenMoulds template for themed cell styles.",
                inputSchema=CREATE_EXCEL_DOCUMENT_SCHEMA,
            ),
            Tool(
                name="create_writer_document",
                description="Create a LibreOffice Writer document (.odt) with ODF-compliant styling.",
                inputSchema=CREATE_WRITER_DOCUMENT_SCHEMA,
            ),
            Tool(
                name="create_impress_document",
                description="Create a LibreOffice Impress presentation (.odp) with ODF-compliant styling.",
                inputSchema=CREATE_IMPRESS_DOCUMENT_SCHEMA,
            ),
            # ============================================================
            # ADD-IN AND MACRO TOOLS
            # Macros are codebases - they deserve the same rigor
            # ============================================================
            Tool(
                name="create_vba_addin",
                description="Create a VBA add-in (.docm/.xlam/.ppam) with optional code signing. Macros are codebases - treated with same rigor.",
                inputSchema=CREATE_VBA_ADDIN_SCHEMA,
            ),
            Tool(
                name="create_web_addin",
                description="Create an Office Web Add-in manifest and project structure. For modern Office.js add-ins.",
                inputSchema=CREATE_WEB_ADDIN_SCHEMA,
            ),
            Tool(
                name="generate_certificate",
                description="Generate a self-signed code signing certificate for development. Use organizational certificates for production.",
                inputSchema=GENERATE_CERTIFICATE_SCHEMA,
            ),
            Tool(
                name="list_certificates",
                description="List available code signing certificates.",
                inputSchema=LIST_CERTIFICATES_SCHEMA,
            ),
            # ============================================================
            # DISCOVERY TOOLS
            # ============================================================
            Tool(
                name="list_layouts",
                description="List available slide layouts for presentations. Returns layout names, display names, placeholder slot names, and descriptions. Use this to discover which layouts exist and what content slots each one accepts.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "family": {
                            "type": "string",
                            "enum": ["core", "semantic", "consulting", "general"],
                            "description": "Filter by layout family (optional, returns all if omitted)",
                        },
                    },
                },
            ),
            Tool(
                name="list_styles",
                description="List available document styles for Word/Writer documents. Returns style names, types (heading/paragraph/list/table/code), and descriptions. Use this to discover which styles to use when creating documents.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "type_filter": {
                            "type": "string",
                            "enum": [
                                "heading",
                                "paragraph",
                                "list",
                                "table",
                                "code",
                                "inline",
                            ],
                            "description": "Filter by style type (optional, returns all if omitted)",
                        },
                    },
                },
            ),
            # ============================================================
            # CACHE & VALIDATION TOOLS
            # ============================================================
            Tool(
                name="validate_template",
                description="Validate a template for ISO 29500 (OOXML) or ODF compliance. Checks structure, content types, relationships.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to template file to validate",
                        },
                        "strict_mode": {
                            "type": "boolean",
                            "default": True,
                            "description": "Use strict ISO 29500 validation",
                        },
                        "extract_structure": {
                            "type": "boolean",
                            "default": False,
                            "description": "Return template structure details",
                        },
                    },
                    "required": ["file_path"],
                },
            ),
            Tool(
                name="clear_template_cache",
                description="Clear cached templates for a brand or all brands.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "brand": {
                            "type": "string",
                            "description": "Brand to clear (optional, clears all if not specified)",
                        },
                    },
                },
            ),
            Tool(
                name="list_cached_templates",
                description="List all cached templates with metadata (size, fonts, validation status).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "brand": {
                            "type": "string",
                            "description": "Filter by brand (optional)",
                        },
                    },
                },
            ),
        ]


async def dispatch_tool(
    server: TokenMouldsServer, name: str, arguments: Dict[str, Any]
) -> Dict[str, Any]:
    """Dispatch tool call to appropriate handler."""

    # User context
    if name == "set_user_context":
        return await set_user_context(arguments, server)
    elif name == "infer_brand_from_email":
        return await infer_brand_from_email(arguments, server)
    elif name == "get_user_context":
        return await get_user_context(arguments, server)

    # Brand management
    elif name == "extract_brand_from_url":
        return await extract_brand_from_url(arguments, server)
    elif name == "build_recipe_from_inputs":
        return await build_recipe_from_inputs(arguments, server)
    elif name == "load_brand":
        return await load_brand(arguments, server)
    elif name == "list_brands":
        return await list_brands(arguments, server)
    elif name == "set_active_brand":
        return await set_active_brand(arguments, server)
    elif name == "link_corporate_github":
        return await link_corporate_github(arguments, server)
    elif name == "modify_brand":
        return await modify_brand(arguments, server)
    elif name == "modify_design":
        return await modify_design(arguments, server)
    elif name == "review_token_proposal":
        return await review_token_proposal(arguments, server)
    elif name == "propose_token_changes":
        return await propose_token_changes(arguments, server)
    elif name == "apply_token_proposal":
        return await apply_token_proposal(arguments, server)
    elif name == "reject_token_proposal":
        return await reject_token_proposal(arguments, server)
    elif name == "list_token_proposals":
        return await list_token_proposals(arguments, server)
    elif name == "create_artifact_plan":
        return await create_artifact_plan(arguments, server)
    elif name == "validate_artifact_plan":
        return await validate_artifact_plan(arguments, server)
    elif name == "compile_artifact":
        return await compile_artifact(arguments, server)
    elif name == "run_document_quality_gate":
        return await run_document_quality_gate(arguments, server)
    elif name == "create_artifact_review_bundle":
        return await create_artifact_review_bundle(arguments, server)
    elif name == "open_github_pr":
        return await open_github_pr(arguments, server)
    elif name == "generate_google_apps_script_bundle":
        return await generate_google_apps_script_bundle(arguments, server)
    elif name == "validate_google_apps_script_bundle":
        return await validate_google_apps_script_bundle(arguments, server)
    elif name == "deploy_google_apps_script_bundle":
        return await deploy_google_apps_script_bundle(arguments, server)
    elif name == "run_google_suite_roundtrip":
        return await run_google_suite_roundtrip(arguments, server)

    # Template generation
    elif name == "generate_word_template":
        return await generate_word_template(arguments, server)
    elif name == "generate_powerpoint_template":
        return await generate_powerpoint_template(arguments, server)
    elif name == "generate_excel_template":
        return await generate_excel_template(arguments, server)
    elif name == "generate_writer_template":
        return await generate_writer_template(arguments, server)
    elif name == "generate_impress_template":
        return await generate_impress_template(arguments, server)
    elif name == "generate_google_docs_template":
        return await generate_google_docs_template(arguments, server)
    elif name == "generate_theme":
        return await generate_theme(arguments, server)
    elif name == "generate_all_templates":
        return await generate_all_templates(arguments, server)

    # Document creation (full pipeline - no bundled fallbacks)
    elif name == "create_word_document":
        return await create_word_document(arguments, server)
    elif name == "create_powerpoint_document":
        return await create_powerpoint_document(arguments, server)
    elif name == "translate_python_pptx_intent":
        return await translate_python_pptx_intent(arguments, server)
    elif name == "create_excel_document":
        return await create_excel_document(arguments, server)
    elif name == "create_writer_document":
        return await create_writer_document(arguments, server)
    elif name == "create_impress_document":
        return await create_impress_document(arguments, server)

    # Add-in and macro tools
    elif name == "create_vba_addin":
        return await create_vba_addin(arguments, server)
    elif name == "create_web_addin":
        return await create_web_addin(arguments, server)
    elif name == "generate_certificate":
        return await generate_self_signed_certificate(arguments, server)
    elif name == "list_certificates":
        return await list_certificates(arguments, server)

    # Discovery
    elif name == "list_layouts":
        return await list_layouts(server, arguments)
    elif name == "list_styles":
        return await list_styles(server, arguments)

    # Cache & Validation
    elif name == "validate_template":
        return await validate_template(server, arguments)
    elif name == "clear_template_cache":
        return await clear_cache(server, arguments)
    elif name == "list_cached_templates":
        return await list_cache(server, arguments)

    else:
        return {"error": f"Unknown tool: {name}"}
