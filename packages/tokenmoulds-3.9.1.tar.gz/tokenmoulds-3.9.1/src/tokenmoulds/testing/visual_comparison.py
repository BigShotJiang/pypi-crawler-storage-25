"""Visual comparison public API."""

from __future__ import annotations

from tokenmoulds.testing.visual_comparison_core import (
    ComparisonConfig,
    ComparisonResult,
    calculate_perceptual_hash_distance,
    calculate_pixel_difference_count,
    calculate_structural_similarity,
    load_image_safely,
    normalize_images,
    validate_imagehash_available,
)
from tokenmoulds.testing.visual_comparison_reports import (
    compare_images,
    comprehensive_comparison,
    generate_diff_image,
    validate_comparison_environment,
)

__all__ = [
    "ComparisonConfig",
    "ComparisonResult",
    "calculate_perceptual_hash_distance",
    "calculate_pixel_difference_count",
    "calculate_structural_similarity",
    "compare_images",
    "comprehensive_comparison",
    "generate_diff_image",
    "load_image_safely",
    "normalize_images",
    "validate_comparison_environment",
    "validate_imagehash_available",
]
