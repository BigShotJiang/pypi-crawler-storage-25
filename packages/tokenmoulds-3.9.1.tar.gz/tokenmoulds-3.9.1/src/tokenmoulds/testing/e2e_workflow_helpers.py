"""Private helpers for E2E workflow execution."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from .before_after import BeforeAfterComparator
from .screenshot_capture import (
    capture_template_screenshot,
    convert_template_to_pdf as capture_convert_template_to_pdf,
    convert_pdf_to_png as capture_convert_pdf_to_png,
    validate_libreoffice_availability,
)

try:
    from PIL import Image
except ImportError:
    Image = None

logger = structlog.get_logger(__name__)


def _reports_root(workspace: Path) -> Path:
    return workspace / "reports" / "e2e"


def _reports_dirs(workspace: Path) -> Dict[str, Path]:
    root = _reports_root(workspace)
    screenshots_dir = root / "screenshots"
    diffs_dir = root / "diffs"
    reports_dir = root / "reports"
    for directory in (screenshots_dir, diffs_dir, reports_dir):
        directory.mkdir(parents=True, exist_ok=True)
    return {
        "root": root,
        "screenshots": screenshots_dir,
        "diffs": diffs_dir,
        "reports": reports_dir,
    }


def _manifest_path(workspace: Path) -> Path:
    return _reports_dirs(workspace)["reports"] / "screenshot_manifest.json"


def _comparison_report_path(workspace: Path) -> Path:
    return _reports_dirs(workspace)["reports"] / "comparison_report.json"


def _summary_report_path(workspace: Path) -> Path:
    return _reports_dirs(workspace)["reports"] / "e2e_summary.json"


def _discover_templates(workspace: Path) -> List[Path]:
    search_roots = [
        workspace / "generated" / "templates",
        workspace / "generated",
    ]
    extensions = (".potx", ".dotx", ".xltx")
    templates: List[Path] = []
    seen: set[Path] = set()

    for root in search_roots:
        if not root.exists():
            continue
        for ext in extensions:
            for template_path in root.rglob(f"*{ext}"):
                if not template_path.is_file():
                    continue
                resolved = template_path.resolve()
                if resolved in seen:
                    continue
                seen.add(resolved)
                templates.append(template_path)

    templates.sort(key=lambda path: str(path))
    return templates


def _template_output_name(template_path: Path, workspace: Path) -> str:
    try:
        relative = template_path.relative_to(workspace)
        token = str(relative)
    except ValueError:
        token = str(template_path)
    digest = hashlib.sha1(token.encode("utf-8")).hexdigest()[:8]
    return f"{template_path.stem}-{digest}"


def _write_json_file(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _load_json_file(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        logger.error("Failed to parse JSON report", path=str(path))
        return None


def _validate_template_structure(template_path: Path, workspace: Path) -> bool:
    validator_path = workspace / "bin" / "validate-template"
    if not validator_path.exists():
        logger.error("Template validator script not found", path=str(validator_path))
        return False

    cmd = [
        sys.executable,
        str(validator_path),
        "--template",
        str(template_path),
        "--format",
        "ooxml",
        "--extract",
    ]
    result = subprocess.run(
        cmd,
        cwd=str(workspace),
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        logger.error(
            "Template validation failed",
            template=str(template_path),
            returncode=result.returncode,
            stderr=result.stderr.strip(),
        )
        return False

    return True


def _find_baseline_image(baselines_root: Path, template_stem: str) -> Optional[Path]:
    matches = list(baselines_root.rglob(f"{template_stem}.png"))
    if not matches:
        logger.error("Baseline image missing", template=template_stem)
        return None
    if len(matches) > 1:
        logger.error(
            "Multiple baseline images found",
            template=template_stem,
            matches=[str(path) for path in matches],
        )
        return None
    return matches[0]


def _validate_workspace(workspace_path: str) -> bool:
    """Validate workspace directory structure."""
    try:
        workspace = Path(workspace_path)
        return workspace.exists() and workspace.is_dir()
    except Exception:
        return False


def _setup_test_directories(workspace_path: str) -> bool:
    """Set up test directories."""
    try:
        workspace = Path(workspace_path)
        _reports_dirs(workspace)
        (workspace / "tests" / "baselines").mkdir(parents=True, exist_ok=True)
        return True
    except Exception as e:
        logger.error("Failed to set up test directories", error=str(e))
        return False


def _process_all_templates(workspace_path: str) -> bool:
    """Process all templates in workspace."""
    try:
        workspace = Path(workspace_path)
        templates = _discover_templates(workspace)
        if not templates:
            logger.error("No templates found for processing", workspace=workspace_path)
            return False

        logger.debug("Processing templates", count=len(templates))

        all_successful = True
        for template_path in templates:
            if not _validate_template_structure(template_path, workspace):
                all_successful = False

        return all_successful
    except Exception as e:
        logger.error("Error processing templates", error=str(e))
        return False


def _capture_template_screenshots(workspace_path: str) -> bool:
    """Capture screenshots of processed templates."""
    try:
        if not validate_libreoffice_availability():
            logger.error("LibreOffice not available for screenshot capture")
            return False

        workspace = Path(workspace_path)
        templates = _discover_templates(workspace)
        if not templates:
            logger.error(
                "No templates found for screenshot capture", workspace=workspace_path
            )
            return False

        directories = _reports_dirs(workspace)
        manifest_entries: List[Dict[str, Any]] = []

        all_successful = True
        for template_path in templates:
            output_name = _template_output_name(template_path, workspace)
            screenshot_path = directories["screenshots"] / f"{output_name}.png"

            success = capture_template_screenshot(
                str(template_path),
                str(screenshot_path),
            )

            if not success or not _validate_screenshot(str(screenshot_path)):
                logger.error("Screenshot capture failed", template=str(template_path))
                all_successful = False

            manifest_entries.append(
                {
                    "template": str(template_path),
                    "template_stem": template_path.stem,
                    "screenshot": str(screenshot_path),
                }
            )

        manifest = {
            "workspace": workspace_path,
            "generated_at": time.time(),
            "templates": manifest_entries,
        }
        _write_json_file(_manifest_path(workspace), manifest)

        return all_successful
    except Exception as e:
        logger.error("Error capturing screenshots", error=str(e))
        return False


def _run_baseline_comparisons(workspace_path: str) -> bool:
    """Run baseline comparisons."""
    try:
        workspace = Path(workspace_path)
        manifest = _load_json_file(_manifest_path(workspace))
        if not manifest:
            logger.error("Screenshot manifest missing for baseline comparison")
            return False

        baselines_root = workspace / "tests" / "baselines"
        if not baselines_root.exists():
            logger.error("Baselines directory not found", path=str(baselines_root))
            return False

        directories = _reports_dirs(workspace)
        comparator = BeforeAfterComparator(artifacts_dir=directories["diffs"])

        results: List[Dict[str, Any]] = []
        all_passed = True

        for entry in manifest.get("templates", []):
            template_stem = entry.get("template_stem")
            screenshot_path = entry.get("screenshot")
            if not template_stem or not screenshot_path:
                all_passed = False
                results.append(
                    {
                        "template": entry.get("template"),
                        "status": "error",
                        "error": "Manifest entry missing template stem or screenshot",
                    }
                )
                continue

            baseline_path = _find_baseline_image(baselines_root, template_stem)
            if baseline_path is None:
                all_passed = False
                results.append(
                    {
                        "template": entry.get("template"),
                        "status": "error",
                        "error": "Baseline image not found",
                    }
                )
                continue

            try:
                report = comparator.compare_paths(baseline_path, screenshot_path)
                passed = report.result.passed
                if not passed:
                    all_passed = False
                results.append(
                    {
                        "template": entry.get("template"),
                        "baseline": str(baseline_path),
                        "screenshot": screenshot_path,
                        "status": "passed" if passed else "failed",
                        "similarity": report.result.similarity,
                        "pixel_diff_percentage": report.result.pixel_diff_percentage,
                        "diff_path": str(report.diff_path)
                        if report.diff_path
                        else None,
                    }
                )
            except Exception as e:
                logger.error(
                    "Baseline comparison error",
                    template=entry.get("template"),
                    error=str(e),
                )
                all_passed = False
                results.append(
                    {
                        "template": entry.get("template"),
                        "status": "error",
                        "error": str(e),
                    }
                )

        report_payload = {
            "workspace": workspace_path,
            "generated_at": time.time(),
            "results": results,
        }
        _write_json_file(_comparison_report_path(workspace), report_payload)

        return all_passed
    except Exception as e:
        logger.error("Error running baseline comparisons", error=str(e))
        return False


def _generate_test_reports(workspace_path: str) -> bool:
    """Generate test reports."""
    try:
        workspace = Path(workspace_path)
        manifest = _load_json_file(_manifest_path(workspace)) or {}
        comparison_report = _load_json_file(_comparison_report_path(workspace)) or {}

        results = comparison_report.get("results", [])
        failed = sum(1 for result in results if result.get("status") != "passed")
        total = len(results) if results else len(manifest.get("templates", []))

        status = "passed" if total > 0 and failed == 0 else "failed"

        summary = {
            "workspace": workspace_path,
            "generated_at": time.time(),
            "templates_processed": len(manifest.get("templates", [])),
            "comparisons_run": total,
            "comparisons_failed": failed,
            "status": status,
        }
        _write_json_file(_summary_report_path(workspace), summary)

        return True
    except Exception as e:
        logger.error("Error generating test reports", error=str(e))
        return False


def _convert_template_to_pdf(template_path: str, output_dir: str) -> str:
    """Convert template to PDF using LibreOffice."""
    try:
        logger.debug(
            "Converting template to PDF", template=template_path, output=output_dir
        )
        if not capture_convert_template_to_pdf(template_path, output_dir):
            return ""

        pdf_path = Path(output_dir) / f"{Path(template_path).stem}.pdf"
        if not pdf_path.exists():
            logger.error("Expected PDF not found after conversion", path=str(pdf_path))
            return ""

        return str(pdf_path)
    except Exception as e:
        logger.error("Template to PDF conversion error", error=str(e))
        return ""


def _convert_pdf_to_png(pdf_path: str, output_dir: str) -> str:
    """Convert PDF to PNG screenshot."""
    try:
        logger.debug("Converting PDF to PNG", pdf=pdf_path, output=output_dir)
        output_path = Path(output_dir) / f"{Path(pdf_path).stem}.png"
        if not capture_convert_pdf_to_png(pdf_path, str(output_path)):
            return ""
        if not output_path.exists():
            logger.error(
                "Expected PNG not found after conversion", path=str(output_path)
            )
            return ""
        return str(output_path)
    except Exception as e:
        logger.error("PDF to PNG conversion error", error=str(e))
        return ""


def _validate_screenshot(screenshot_path: str) -> bool:
    """Validate screenshot file."""
    try:
        screenshot = Path(screenshot_path)
        if not screenshot.exists():
            logger.error("Screenshot file missing", screenshot=screenshot_path)
            return False
        if screenshot.stat().st_size == 0:
            logger.error("Screenshot file is empty", screenshot=screenshot_path)
            return False

        if Image is not None:
            with Image.open(screenshot) as image:
                if image.size[0] == 0 or image.size[1] == 0:
                    logger.error(
                        "Screenshot has invalid dimensions", screenshot=screenshot_path
                    )
                    return False
        else:
            logger.warning("Pillow not available; skipping image content validation")

        return True
    except Exception as e:
        logger.error("Error validating screenshot", error=str(e))
        return False
