"""Core image loading and metric helpers for visual comparison."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

import structlog

from PIL import Image, ImageChops

if TYPE_CHECKING:
    import imagehash  # type: ignore[import-not-found]
    import numpy as np
else:
    try:
        import imagehash  # type: ignore[import-not-found]
    except ImportError:  # pragma: no cover
        imagehash = None

    try:
        import numpy as np  # type: ignore[import-not-found]
    except ImportError:  # pragma: no cover
        np = None

logger = structlog.get_logger(__name__)


@dataclass
class ComparisonResult:
    """Result of visual comparison between two images."""

    similarity_score: float
    are_similar: bool
    difference_percentage: float
    hash_distance: Optional[int]
    structural_similarity: Optional[float]
    pixel_differences: Optional[int]
    diff_image_path: Optional[str]
    metadata: Dict[str, Any]


@dataclass
class ComparisonConfig:
    """Configuration for visual comparison algorithms."""

    similarity_threshold: float = 0.95
    hash_threshold: int = 5
    pixel_tolerance: int = 10
    structural_threshold: float = 0.85
    generate_diff_image: bool = True
    diff_enhancement: bool = True
    ignore_transparency: bool = True


def validate_imagehash_available() -> bool:
    """
    Validate that imagehash is available for perceptual hashing.

    Returns:
        bool: True if imagehash is available, False otherwise.
    """
    try:
        if imagehash is None:
            logger.error(
                "imagehash is not available - install with: pip install imagehash>=4.3.0"
            )
            return False
        return True
    except Exception as e:
        logger.error("Error validating imagehash availability", error=str(e))
        return False


def load_image_safely(image_path: str) -> Optional[Image.Image]:
    """
    Load image file safely with error handling.

    Args:
        image_path: Path to image file.

    Returns:
        PIL Image object if successful, None otherwise.
    """
    try:
        image_file = Path(image_path)
        if not image_file.exists():
            logger.warning("Image file does not exist", path=image_path)
            return None

        image = Image.open(image_path)
        logger.debug(
            "Image loaded successfully",
            path=image_path,
            size=image.size,
            mode=image.mode,
        )
        return image

    except Exception as e:
        logger.error("Error loading image", path=image_path, error=str(e))
        return None


def normalize_images(
    image1: Image.Image, image2: Image.Image
) -> Tuple[Image.Image, Image.Image]:
    """
    Normalize two images to same size and mode for comparison.

    Args:
        image1: First image.
        image2: Second image.

    Returns:
        Tuple of normalized images.
    """
    try:
        # Convert to same mode
        if image1.mode != image2.mode:
            if image1.mode == "RGBA" or image2.mode == "RGBA":
                image1 = image1.convert("RGBA")
                image2 = image2.convert("RGBA")
            else:
                image1 = image1.convert("RGB")
                image2 = image2.convert("RGB")

        # Resize to same dimensions (use larger size)
        size1 = image1.size
        size2 = image2.size

        if size1 != size2:
            target_size = (max(size1[0], size2[0]), max(size1[1], size2[1]))

            if size1 != target_size:
                image1 = image1.resize(target_size, Image.Resampling.LANCZOS)
            if size2 != target_size:
                image2 = image2.resize(target_size, Image.Resampling.LANCZOS)

            logger.debug(
                "Images resized for comparison",
                original_sizes=[size1, size2],
                target_size=target_size,
            )

        return image1, image2

    except Exception as e:
        logger.error("Error normalizing images", error=str(e))
        return image1, image2


def calculate_perceptual_hash_distance(
    image1: Image.Image, image2: Image.Image
) -> Optional[int]:
    """
    Calculate perceptual hash distance between two images.

    Args:
        image1: First image.
        image2: Second image.

    Returns:
        Hash distance (lower is more similar), None if error.
    """
    try:
        if not validate_imagehash_available():
            return None

        hash1 = imagehash.average_hash(image1)
        hash2 = imagehash.average_hash(image2)

        distance = abs(hash1 - hash2)
        logger.debug(
            "Perceptual hash calculated",
            hash1=str(hash1),
            hash2=str(hash2),
            distance=distance,
        )

        return distance

    except Exception as e:
        logger.error("Error calculating perceptual hash", error=str(e))
        return None


def calculate_pixel_difference_count(
    image1: Image.Image, image2: Image.Image, tolerance: int = 0
) -> Optional[int]:
    """
    Calculate number of different pixels between two images.

    Args:
        image1: First image.
        image2: Second image.
        tolerance: Pixel value tolerance (0-255).

    Returns:
        Number of different pixels, None if error.
    """
    try:
        # Calculate absolute difference
        diff_image = ImageChops.difference(image1, image2)

        # Convert to numpy for efficient processing
        diff_array = np.array(diff_image)

        # Count pixels that exceed tolerance (sum along channel axis first)
        if diff_array.ndim == 3:
            channel_max = diff_array.max(axis=2)
        else:
            channel_max = diff_array

        if tolerance == 0:
            different_pixels = np.count_nonzero(channel_max)
        else:
            different_pixels = np.count_nonzero(channel_max > tolerance)

        total_pixels = channel_max.size
        logger.debug(
            "Pixel difference calculated",
            different=different_pixels,
            total=total_pixels,
            tolerance=tolerance,
        )

        return int(different_pixels)

    except Exception as e:
        logger.error("Error calculating pixel differences", error=str(e))
        return None


def calculate_structural_similarity(
    image1: Image.Image, image2: Image.Image
) -> Optional[float]:
    """
    Calculate structural similarity between two images.

    Args:
        image1: First image.
        image2: Second image.

    Returns:
        Structural similarity score (0.0-1.0), None if error.
    """
    try:
        # Convert to grayscale for structural analysis
        gray1 = image1.convert("L")
        gray2 = image2.convert("L")

        # Convert to numpy arrays
        array1 = np.array(gray1, dtype=np.float64)
        array2 = np.array(gray2, dtype=np.float64)

        # Calculate means
        mu1 = np.mean(array1)
        mu2 = np.mean(array2)

        # Calculate variances and covariance
        var1 = np.var(array1)
        var2 = np.var(array2)
        cov12 = np.mean((array1 - mu1) * (array2 - mu2))

        # SSIM constants
        c1 = (0.01 * 255) ** 2
        c2 = (0.03 * 255) ** 2

        # Calculate SSIM
        numerator = (2 * mu1 * mu2 + c1) * (2 * cov12 + c2)
        denominator = (mu1**2 + mu2**2 + c1) * (var1 + var2 + c2)

        ssim = numerator / denominator
        logger.debug("Structural similarity calculated", ssim=ssim)

        return float(ssim)

    except Exception as e:
        logger.error("Error calculating structural similarity", error=str(e))
        return None
