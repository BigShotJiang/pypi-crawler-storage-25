"""Diff image generation and aggregate visual comparisons."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional

import structlog

from PIL import Image, ImageChops

if TYPE_CHECKING:
    import numpy as np
else:
    try:
        import numpy as np  # type: ignore[import-not-found]
    except ImportError:  # pragma: no cover
        np = None

from tokenmoulds.testing.visual_comparison_core import (
    ComparisonConfig,
    ComparisonResult,
    calculate_perceptual_hash_distance,
    calculate_pixel_difference_count,
    calculate_structural_similarity,
    load_image_safely,
    normalize_images,
    validate_imagehash_available,
)

logger = structlog.get_logger(__name__)


def generate_diff_image(
    image1: Image.Image, image2: Image.Image, output_path: str, enhance: bool = True
) -> bool:
    """
    Generate visual diff image highlighting differences.

    Args:
        image1: First image.
        image2: Second image.
        output_path: Path to save diff image.
        enhance: Whether to enhance differences for visibility.

    Returns:
        bool: True if diff image generated successfully.
    """
    try:
        logger.info("Generating diff image", output=output_path, enhance=enhance)

        # Calculate difference
        diff_image = ImageChops.difference(image1, image2)

        if enhance:
            # Enhance differences for better visibility
            # Convert to grayscale and apply contrast enhancement
            diff_gray = diff_image.convert("L")

            # Apply threshold to highlight significant differences
            diff_array = np.array(diff_gray)
            threshold = 30  # Minimum difference to highlight
            diff_array[diff_array < threshold] = 0
            diff_array[diff_array >= threshold] = 255

            # Convert back to image
            enhanced_diff = Image.fromarray(diff_array, mode="L")

            # Convert to RGB and colorize differences
            diff_rgb = enhanced_diff.convert("RGB")
            diff_array_rgb = np.array(diff_rgb)

            # Make differences red
            red_mask = diff_array_rgb[:, :, 0] > 0
            diff_array_rgb[red_mask] = [255, 0, 0]  # Red for differences

            final_diff = Image.fromarray(diff_array_rgb)
        else:
            final_diff = diff_image

        # Save diff image
        output_dir = Path(output_path).parent
        output_dir.mkdir(parents=True, exist_ok=True)

        final_diff.save(output_path)
        logger.info("Diff image generated successfully", path=output_path)

        return True

    except Exception as e:
        logger.error("Error generating diff image", error=str(e))
        return False


def compare_images(
    image1_path: str, image2_path: str, config: Optional[ComparisonConfig] = None
) -> ComparisonResult:
    """
    Compare two images using multiple algorithms.

    Args:
        image1_path: Path to first image.
        image2_path: Path to second image.
        config: Comparison configuration.

    Returns:
        ComparisonResult with detailed analysis.
    """
    try:
        logger.info("Starting image comparison", image1=image1_path, image2=image2_path)

        if config is None:
            config = ComparisonConfig()

        # Load images
        image1 = load_image_safely(image1_path)
        image2 = load_image_safely(image2_path)

        if image1 is None or image2 is None:
            return ComparisonResult(
                similarity_score=0.0,
                are_similar=False,
                difference_percentage=100.0,
                hash_distance=None,
                structural_similarity=None,
                pixel_differences=None,
                diff_image_path=None,
                metadata={"error": "Failed to load images"},
            )

        # Normalize images
        image1, image2 = normalize_images(image1, image2)

        # Calculate various similarity metrics
        hash_distance = calculate_perceptual_hash_distance(image1, image2)
        pixel_differences = calculate_pixel_difference_count(
            image1, image2, tolerance=config.pixel_tolerance
        )
        structural_similarity = calculate_structural_similarity(image1, image2)

        # Calculate overall similarity score
        similarity_scores = []

        if hash_distance is not None:
            # Convert hash distance to similarity (0-1)
            hash_similarity = max(
                0, 1 - (hash_distance / 64)
            )  # 64 is max hash distance
            similarity_scores.append(hash_similarity)

        if pixel_differences is not None:
            total_pixels = image1.size[0] * image1.size[1] * len(image1.getbands())
            pixel_similarity = 1 - (pixel_differences / total_pixels)
            similarity_scores.append(pixel_similarity)

        if structural_similarity is not None:
            similarity_scores.append(structural_similarity)

        # Overall similarity is average of available metrics
        overall_similarity = np.mean(similarity_scores) if similarity_scores else 0.0

        # Determine if images are similar
        are_similar = overall_similarity >= config.similarity_threshold

        if hash_distance is not None:
            are_similar = are_similar and hash_distance <= config.hash_threshold

        if structural_similarity is not None:
            are_similar = (
                are_similar and structural_similarity >= config.structural_threshold
            )

        # Calculate difference percentage
        difference_percentage = (1 - overall_similarity) * 100

        # Generate diff image if requested
        diff_image_path = None
        if config.generate_diff_image:
            diff_dir = Path(image1_path).parent / "diffs"
            diff_filename = (
                f"diff_{Path(image1_path).stem}_{Path(image2_path).stem}.png"
            )
            diff_image_path = str(diff_dir / diff_filename)

            if not generate_diff_image(
                image1, image2, diff_image_path, config.diff_enhancement
            ):
                diff_image_path = None

        result = ComparisonResult(
            similarity_score=float(overall_similarity),
            are_similar=bool(are_similar),
            difference_percentage=float(difference_percentage),
            hash_distance=hash_distance,
            structural_similarity=structural_similarity,
            pixel_differences=pixel_differences,
            diff_image_path=diff_image_path,
            metadata={
                "image1_size": image1.size,
                "image2_size": image2.size,
                "image1_mode": image1.mode,
                "image2_mode": image2.mode,
                "config": {
                    "similarity_threshold": config.similarity_threshold,
                    "hash_threshold": config.hash_threshold,
                    "pixel_tolerance": config.pixel_tolerance,
                    "structural_threshold": config.structural_threshold,
                },
            },
        )

        logger.info(
            "Image comparison completed",
            similarity=overall_similarity,
            similar=are_similar,
            difference_pct=difference_percentage,
        )

        return result

    except Exception as e:
        logger.error("Error during image comparison", error=str(e))
        return ComparisonResult(
            similarity_score=0.0,
            are_similar=False,
            difference_percentage=100.0,
            hash_distance=None,
            structural_similarity=None,
            pixel_differences=None,
            diff_image_path=None,
            metadata={"error": str(e)},
        )


def comprehensive_comparison(
    baseline_path: str, current_path: str, output_dir: str
) -> Dict[str, Any]:
    """
    Perform comprehensive comparison with detailed analysis.

    Args:
        baseline_path: Path to baseline image.
        current_path: Path to current image.
        output_dir: Directory for output files.

    Returns:
        Dictionary with comprehensive comparison results.
    """
    try:
        logger.info(
            "Starting comprehensive comparison",
            baseline=baseline_path,
            current=current_path,
        )

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Multiple comparison configurations
        configs = {
            "strict": ComparisonConfig(
                similarity_threshold=0.98, hash_threshold=2, pixel_tolerance=5
            ),
            "normal": ComparisonConfig(
                similarity_threshold=0.95, hash_threshold=5, pixel_tolerance=10
            ),
            "relaxed": ComparisonConfig(
                similarity_threshold=0.90, hash_threshold=10, pixel_tolerance=20
            ),
        }

        results = {}

        for config_name, config in configs.items():
            logger.debug("Running comparison with config", config=config_name)

            # Set unique diff image path for each config
            diff_filename = f"diff_{config_name}_{Path(baseline_path).stem}.png"
            config.generate_diff_image = True

            # Temporarily modify comparison to save diff in correct location
            result = compare_images(baseline_path, current_path, config)

            # Move diff image to output directory if generated
            if result.diff_image_path and Path(result.diff_image_path).exists():
                new_diff_path = output_path / diff_filename
                Path(result.diff_image_path).rename(new_diff_path)
                result.diff_image_path = str(new_diff_path)

            results[config_name] = {
                "similarity_score": result.similarity_score,
                "are_similar": result.are_similar,
                "difference_percentage": result.difference_percentage,
                "hash_distance": result.hash_distance,
                "structural_similarity": result.structural_similarity,
                "pixel_differences": result.pixel_differences,
                "diff_image_path": result.diff_image_path,
                "metadata": result.metadata,
            }

        # Generate summary report
        summary = {
            "baseline_image": baseline_path,
            "current_image": current_path,
            "output_directory": str(output_path),
            "comparison_results": results,
            "overall_assessment": {
                "passed_strict": results["strict"]["are_similar"],
                "passed_normal": results["normal"]["are_similar"],
                "passed_relaxed": results["relaxed"]["are_similar"],
                "recommended_action": "approve"
                if results["normal"]["are_similar"]
                else "review",
            },
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

        # Save comprehensive report
        report_path = output_path / "comparison_report.json"
        with open(report_path, "w") as f:
            json.dump(summary, f, indent=2)

        logger.info(
            "Comprehensive comparison completed",
            report=str(report_path),
            passed_normal=results["normal"]["are_similar"],
        )

        return summary

    except Exception as e:
        logger.error("Error in comprehensive comparison", error=str(e))
        return {
            "error": str(e),
            "baseline_image": baseline_path,
            "current_image": current_path,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }


def validate_comparison_environment() -> bool:
    """
    Validate that all required dependencies are available.

    Returns:
        bool: True if environment is ready for comparison.
    """
    try:
        logger.info("Validating visual comparison environment")

        checks = {
            "pillow": True,  # hard dependency
            "imagehash": validate_imagehash_available(),
            "numpy": np is not None,
        }

        all_available = all(checks.values())

        logger.info(
            "Environment validation completed",
            pillow=checks["pillow"],
            imagehash=checks["imagehash"],
            numpy=checks["numpy"],
            ready=all_available,
        )

        return all_available

    except Exception as e:
        logger.error("Error validating comparison environment", error=str(e))
        return False
