"""Workflow-level screenshot capture helpers."""

from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import structlog

from tokenmoulds.testing.screenshot_capture import (
    capture_template_screenshot,
    process_all_template_tiers,
    validate_github_actions_environment,
    validate_libreoffice_availability,
)

logger = structlog.get_logger(__name__)


def capture_template_with_error_reporting(
    template_path: str, output_path: str
) -> Tuple[bool, Optional[str]]:
    """
    Capture template screenshot with detailed error reporting.

    Args:
        template_path: Path to the template file.
        output_path: Path for the output PNG file.

    Returns:
        Tuple of (success boolean, error details if failed).
    """
    try:
        logger.info(
            "Starting template capture with error reporting", template=template_path
        )

        result = capture_template_screenshot(template_path, output_path)

        if result:
            return True, None
        else:
            return False, "Screenshot capture failed - check logs for details"

    except subprocess.CalledProcessError as e:
        error_details = f"LibreOffice execution failed: {e}"
        logger.error("LibreOffice execution failed", error=error_details)
        return False, error_details
    except Exception as e:
        error_details = f"Unexpected error during screenshot capture: {e}"
        logger.error("Unexpected error during screenshot capture", error=error_details)
        return False, error_details


def process_all_template_tiers_with_retry(
    templates_base_dir: str, output_base_dir: str, max_retries: int = 2
) -> bool:
    """
    Process all template tiers with retry logic.

    Args:
        templates_base_dir: Base directory containing tier subdirectories.
        output_base_dir: Base directory for screenshot outputs.
        max_retries: Maximum number of retry attempts.

    Returns:
        bool: True if processing successful (possibly after retries), False otherwise.
    """
    try:
        logger.info(
            "Processing all template tiers with retry",
            base=templates_base_dir,
            retries=max_retries,
        )

        for attempt in range(max_retries + 1):
            logger.debug(
                "Processing attempt", attempt=attempt + 1, max_retries=max_retries + 1
            )

            result = process_all_template_tiers(templates_base_dir, output_base_dir)

            if result:
                logger.info("Template processing successful", attempt=attempt + 1)
                return True
            elif attempt < max_retries:
                logger.warning(
                    "Template processing failed, retrying", attempt=attempt + 1
                )
                time.sleep(5)  # Brief delay before retry
            else:
                logger.error("Template processing failed after all retries")

        return False

    except Exception as e:
        logger.error("Error during template processing with retry", error=str(e))
        return False


def run_github_actions_workflow() -> bool:
    """
    Run screenshot capture workflow in GitHub Actions context.

    Returns:
        bool: True if workflow completed successfully, False otherwise.
    """
    try:
        logger.info("Running GitHub Actions screenshot capture workflow")

        # Validate GitHub Actions environment
        if not validate_github_actions_environment():
            logger.error("GitHub Actions environment validation failed")
            return False

        # Get workspace paths from environment
        workspace = os.environ.get("GITHUB_WORKSPACE", "/github/workspace")
        templates_dir = f"{workspace}/templates"
        screenshots_dir = f"{workspace}/screenshots"

        # Process all templates
        return process_all_template_tiers(templates_dir, screenshots_dir)

    except Exception as e:
        logger.error("Error running GitHub Actions workflow", error=str(e))
        return False


def execute_matrix_strategy(
    matrix_config: Dict[str, List[str]], workspace_dir: str, output_dir: str
) -> List[Dict[str, Any]]:
    """
    Execute matrix strategy for template processing.

    Args:
        matrix_config: Matrix configuration with template types and tiers.
        workspace_dir: Base workspace directory.
        output_dir: Base output directory.

    Returns:
        List of execution results for each matrix combination.
    """
    try:
        logger.info("Executing matrix strategy", config=matrix_config)

        results: List[Dict[str, Any]] = []

        if not validate_libreoffice_availability():
            logger.error("LibreOffice not available for matrix execution")
            return results

        template_types = matrix_config.get("template-type", [])
        tiers = matrix_config.get("tier", [])

        workspace = Path(workspace_dir)
        output_root = Path(output_dir)
        output_root.mkdir(parents=True, exist_ok=True)

        templates_root = workspace / "templates"
        if not templates_root.exists():
            alt_root = workspace / "generated" / "templates"
            templates_root = alt_root if alt_root.exists() else templates_root

        if not templates_root.exists():
            logger.error("Templates root directory not found", path=str(templates_root))
            return results

        for template_type in template_types:
            extension = f".{template_type.lstrip('.')}"
            for tier in tiers:
                tier_dir = templates_root / tier
                if not tier_dir.exists():
                    logger.error(
                        "Tier directory missing", tier=tier, path=str(tier_dir)
                    )
                    results.append(
                        {
                            "template-type": template_type,
                            "tier": tier,
                            "status": "missing_tier",
                            "processed": 0,
                            "failed": 0,
                            "duration": 0,
                        }
                    )
                    continue

                template_files = list(tier_dir.rglob(f"*{extension}"))
                if not template_files:
                    results.append(
                        {
                            "template-type": template_type,
                            "tier": tier,
                            "status": "missing_templates",
                            "processed": 0,
                            "failed": 0,
                            "duration": 0,
                        }
                    )
                    continue

                start_time = time.time()
                failed = 0
                for template_path in template_files:
                    output_path = (
                        output_root / tier / template_type / f"{template_path.stem}.png"
                    )
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    if not capture_template_screenshot(
                        str(template_path), str(output_path)
                    ):
                        failed += 1
                duration = int(time.time() - start_time)

                status = "success" if failed == 0 else "failed"
                results.append(
                    {
                        "template-type": template_type,
                        "tier": tier,
                        "status": status,
                        "processed": len(template_files),
                        "failed": failed,
                        "duration": duration,
                    }
                )

        logger.info(
            "Matrix strategy execution completed", total_combinations=len(results)
        )

        return results

    except Exception as e:
        logger.error("Error executing matrix strategy", error=str(e))
        return []


def run_workflow_with_monitoring(templates_dir: str, output_dir: str) -> bool:
    """
    Run screenshot capture workflow with comprehensive monitoring.

    Args:
        templates_dir: Directory containing templates.
        output_dir: Directory for screenshot outputs.

    Returns:
        bool: True if workflow completed successfully, False otherwise.
    """
    try:
        start_time = time.time()

        logger.info(
            "Starting workflow with monitoring",
            templates=templates_dir,
            output=output_dir,
        )

        # Process templates with monitoring
        result = process_all_template_tiers(templates_dir, output_dir)

        end_time = time.time()
        duration = end_time - start_time

        logger.info(
            "Workflow with monitoring completed", success=result, duration=duration
        )

        return result

    except Exception as e:
        logger.error("Error during workflow with monitoring", error=str(e))
        return False
