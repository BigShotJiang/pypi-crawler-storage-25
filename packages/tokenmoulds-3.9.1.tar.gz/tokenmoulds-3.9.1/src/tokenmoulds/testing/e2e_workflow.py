"""
End-to-end workflow execution for OOXML template testing.

Handles complete E2E workflow execution including template processing,
screenshot capture, and result validation.
"""

import tempfile
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

import structlog

from .e2e_workflow_helpers import (
    _capture_template_screenshots,
    _comparison_report_path,
    _generate_test_reports,
    _manifest_path,
    _process_all_templates,
    _reports_dirs,
    _run_baseline_comparisons,
    _setup_test_directories,
    _summary_report_path,
    _validate_workspace,
)
from .screenshot_capture import (
    validate_libreoffice_availability,
)

try:
    from PIL import Image
except ImportError:
    Image = None

logger = structlog.get_logger(__name__)


def execute_complete_workflow(workspace_path: str) -> bool:
    """
    Execute complete E2E workflow from start to finish.

    Args:
        workspace_path: Path to workspace directory.

    Returns:
        bool: True if workflow successful, False otherwise.
    """
    try:
        logger.info(
            "Starting complete E2E workflow execution", workspace=workspace_path
        )

        workflow_steps = [
            ("validate_workspace", _validate_workspace),
            ("setup_directories", _setup_test_directories),
            ("process_templates", _process_all_templates),
            ("capture_screenshots", _capture_template_screenshots),
            ("run_comparisons", _run_baseline_comparisons),
            ("generate_reports", _generate_test_reports),
        ]

        overall_success = True

        for step_name, step_func in workflow_steps:
            logger.debug("Executing workflow step", step=step_name)

            try:
                success = step_func(workspace_path)
            except Exception as e:
                logger.error("Error in workflow step", step=step_name, error=str(e))
                success = False

            if not success:
                logger.error("Workflow step failed", step=step_name)
                overall_success = False

        if overall_success:
            logger.info("Complete E2E workflow execution successful")
        else:
            logger.error("Complete E2E workflow execution failed")

        return overall_success

    except Exception as e:
        logger.error("Error during complete workflow execution", error=str(e))
        return False


def test_libreoffice_e2e_setup() -> bool:
    """
    Test LibreOffice E2E setup and functionality.

    Returns:
        bool: True if setup test successful, False otherwise.
    """
    try:
        logger.info("Testing LibreOffice E2E setup")

        from .libreoffice_setup import (
            validate_headless_mode,
            test_libreoffice_conversion,
        )

        if not validate_libreoffice_availability():
            logger.error("LibreOffice not available for E2E setup test")
            return False

        if not validate_headless_mode():
            logger.error("LibreOffice headless validation failed")
            return False

        if not test_libreoffice_conversion():
            logger.error("LibreOffice conversion test failed")
            return False

        logger.info("LibreOffice E2E setup test completed successfully")
        return True

    except Exception as e:
        logger.error("Error in LibreOffice E2E setup test", error=str(e))
        return False


def generate_workflow_artifacts(artifacts_dir: str) -> bool:
    """
    Generate workflow artifacts for testing.

    Args:
        artifacts_dir: Directory to store artifacts.

    Returns:
        bool: True if artifact generation successful, False otherwise.
    """
    try:
        logger.info("Generating workflow artifacts", artifacts_dir=artifacts_dir)

        workspace = Path(artifacts_dir)
        if not workspace.exists():
            logger.error("Workspace directory does not exist", path=artifacts_dir)
            return False

        if not execute_complete_workflow(str(workspace)):
            logger.error("E2E workflow failed during artifact generation")
            return False

        expected_files = [
            _manifest_path(workspace),
            _comparison_report_path(workspace),
            _summary_report_path(workspace),
        ]
        missing = [path for path in expected_files if not path.exists()]
        if missing:
            logger.error(
                "Expected reports missing", missing=[str(path) for path in missing]
            )
            return False

        screenshots_dir = _reports_dirs(workspace)["screenshots"]
        screenshots = list(screenshots_dir.glob("*.png"))
        if not screenshots:
            logger.error("No screenshots produced during artifact generation")
            return False

        logger.info(
            "Workflow artifacts generated successfully", screenshots=len(screenshots)
        )
        return True

    except Exception as e:
        logger.error("Error generating workflow artifacts", error=str(e))
        return False


def test_failure_recovery() -> bool:
    """
    Test workflow failure recovery mechanisms.

    Returns:
        bool: True if recovery test successful, False otherwise.
    """
    try:
        logger.info("Testing failure recovery mechanisms")

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_workspace = Path(temp_dir)
            temp_workspace.mkdir(parents=True, exist_ok=True)

            # Expect failure when no templates are available.
            failure_detected = not execute_complete_workflow(str(temp_workspace))
            if not failure_detected:
                logger.error("Expected workflow failure was not detected")
                return False

        logger.info("Failure detection test completed successfully")
        return True

    except Exception as e:
        logger.error("Error in failure recovery test", error=str(e))
        return False


def measure_workflow_performance(workspace_path: str) -> Dict[str, int]:
    """
    Measure workflow performance metrics.

    Returns:
        Dictionary with performance metrics.
    """
    try:
        logger.info("Measuring workflow performance")

        workspace = Path(workspace_path)
        if not workspace.exists():
            logger.error("Workspace does not exist", workspace=workspace_path)
            return {}

        setup_start = time.time()
        setup_ok = _setup_test_directories(workspace_path)
        setup_time = int(time.time() - setup_start)

        exec_start = time.time()
        execution_ok = (
            _process_all_templates(workspace_path)
            and _capture_template_screenshots(workspace_path)
            and _run_baseline_comparisons(workspace_path)
        )
        execution_time = int(time.time() - exec_start)

        cleanup_start = time.time()
        report_ok = _generate_test_reports(workspace_path)
        cleanup_time = int(time.time() - cleanup_start)

        total_time = setup_time + execution_time + cleanup_time
        metrics = {
            "setup_time": setup_time,
            "execution_time": execution_time,
            "cleanup_time": cleanup_time,
            "total_time": total_time,
            "setup_ok": setup_ok,
            "execution_ok": execution_ok,
            "report_ok": report_ok,
        }

        logger.info("Performance measurement completed", metrics=metrics)
        return metrics

    except Exception as e:
        logger.error("Error measuring workflow performance", error=str(e))
        return {}


def execute_matrix_strategy(
    matrix_config: Dict[str, List[str]],
    workspace_path: Optional[str] = None,
    output_dir: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Execute matrix strategy testing.

    Args:
        matrix_config: Matrix configuration.

    Returns:
        List of matrix execution results.
    """
    try:
        workspace = Path(workspace_path) if workspace_path else Path.cwd()
        output_root = (
            Path(output_dir) if output_dir else _reports_dirs(workspace)["screenshots"]
        )

        logger.info(
            "Executing matrix strategy", config=matrix_config, workspace=str(workspace)
        )

        from .screenshot_workflow import (
            execute_matrix_strategy as capture_matrix_strategy,
        )

        return capture_matrix_strategy(matrix_config, str(workspace), str(output_root))

    except Exception as e:
        logger.error("Error executing matrix strategy", error=str(e))
        return []


def test_notification_system(scenario: Dict[str, str]) -> bool:
    """
    Test notification system with different scenarios.

    Args:
        scenario: Notification scenario to test.

    Returns:
        bool: True if notification test successful, False otherwise.
    """
    try:
        logger.info("Testing notification system", scenario=scenario)

        notification_type = scenario.get("type")
        message = scenario.get("message")

        if notification_type and message:
            logger.info(
                "Notification processed", type=notification_type, message=message
            )
            return True
        else:
            logger.error("Invalid notification scenario")
            return False

    except Exception as e:
        logger.error("Error testing notification system", error=str(e))
        return False


def test_resource_cleanup(workspace_path: str) -> bool:
    """
    Test resource cleanup functionality.

    Args:
        workspace_path: Path to workspace for cleanup testing.

    Returns:
        bool: True if cleanup test successful, False otherwise.
    """
    try:
        logger.info("Testing resource cleanup", workspace=workspace_path)

        workspace = Path(workspace_path)
        if not workspace.exists():
            logger.error("Workspace does not exist for cleanup test")
            return False

        # Check for and clean up temporary resources
        temp_dirs = ["temp_screenshots", "temp_pdfs", "temp_logs"]
        for temp_dir in temp_dirs:
            temp_path = workspace / temp_dir
            if temp_path.exists():
                logger.debug("Removing temporary directory", path=temp_dir)
                import shutil

                shutil.rmtree(temp_path)

        logger.info("Resource cleanup test completed successfully")
        return True

    except Exception as e:
        logger.error("Error testing resource cleanup", error=str(e))
        return False


def simulate_user_workflow() -> Dict[str, Dict[str, Any]]:
    """
    Simulate complete user workflow from template change to result.

    Returns:
        Dictionary with workflow step results.
    """
    try:
        logger.info("Executing complete user workflow")

        workflow_steps = [
            "template_change",
            "workflow_trigger",
            "environment_setup",
            "libreoffice_install",
            "template_processing",
            "screenshot_capture",
            "baseline_comparison",
            "result_reporting",
        ]

        start_time = time.time()
        success = execute_complete_workflow(str(Path.cwd()))
        duration = int(time.time() - start_time)
        status = "completed" if success else "failed"

        results = {
            step: {
                "status": status,
                "duration": duration,
                "timestamp": time.time(),
            }
            for step in workflow_steps
        }

        logger.info(
            "User workflow execution completed", steps=len(results), status=status
        )
        return results

    except Exception as e:
        logger.error("Error simulating user workflow", error=str(e))
        return {}


# Helper functions
