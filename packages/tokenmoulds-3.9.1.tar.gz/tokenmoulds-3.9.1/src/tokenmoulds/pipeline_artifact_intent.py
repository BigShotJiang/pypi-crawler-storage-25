"""Build artifact intent metadata for pipeline-emitted documents."""

from __future__ import annotations

from typing import Any

from tokenmoulds import __version__ as _PIPELINE_VERSION
from tokenmoulds.artifact_intent import ArtifactIntentMetadata, ArtifactType
from tokenmoulds.emitters.docprops_custom import compute_template_hash
from tokenmoulds.ir import DocumentIR
from tokenmoulds.pipeline_models import BuildConfig

ARTIFACT_INTENT_FORMATS = {
    "docx",
    "dotx",
    "pptx",
    "potx",
    "xlsx",
    "xltx",
    "odt",
    "ott",
    "odp",
    "otp",
    "ods",
    "ots",
    "odg",
    "otg",
}
DEFAULT_ARTIFACT_TYPE_BY_FORMAT: dict[str, ArtifactType] = {
    "docx": "report",
    "dotx": "report",
    "pptx": "board_deck",
    "potx": "board_deck",
    "xlsx": "workbook",
    "xltx": "workbook",
    "odt": "report",
    "ott": "report",
    "odp": "board_deck",
    "otp": "board_deck",
    "ods": "workbook",
    "ots": "workbook",
    "odg": "unknown",
    "otg": "unknown",
}
ARTIFACT_LABEL_BY_FORMAT = {
    "docx": "Word document",
    "dotx": "Word template",
    "pptx": "PowerPoint deck",
    "potx": "PowerPoint template",
    "xlsx": "Excel workbook",
    "xltx": "Excel template",
    "odt": "Writer document",
    "ott": "Writer template",
    "odp": "Impress deck",
    "otp": "Impress template",
    "ods": "Calc spreadsheet",
    "ots": "Calc template",
    "odg": "Draw graphic",
    "otg": "Draw template",
}


def build_pipeline_artifact_intent(
    fmt: str,
    document_ir: DocumentIR,
    tokens: dict[str, Any],
    config: BuildConfig,
    source_report: dict[str, Any],
) -> ArtifactIntentMetadata | None:
    """Build per-format artifact intent metadata for supported outputs."""
    if not config.emit_artifact_intent or fmt not in ARTIFACT_INTENT_FORMATS:
        return None

    label = ARTIFACT_LABEL_BY_FORMAT.get(fmt, f"{fmt} artifact")
    artifact_id = config.artifact_id or f"{config.org_id}-{fmt}"
    artifact_title = config.artifact_title or f"{config.org_id} {label}"
    intent_summary = (
        config.artifact_intent_summary
        or f"Generate a branded {label} for {config.org_id} from resolved design "
        "tokens."
    )

    return ArtifactIntentMetadata(
        artifact={
            "id": artifact_id,
            "type": config.artifact_type
            or DEFAULT_ARTIFACT_TYPE_BY_FORMAT.get(fmt, "unknown"),
            "title": artifact_title,
            "intent_summary": intent_summary,
            "locale": config.locale,
            "status": config.artifact_status,
            "tags": ["template", fmt, config.token_source_label()],
        },
        source={
            "token_source": source_report["token_source"],
            "token_source_sha256": source_report["token_source_sha256"],
            "resolved_tokens_sha256": source_report["resolved_tokens_sha256"],
            "build_config_sha256": source_report["build_config_sha256"],
            "repository": config.repository,
            "ref": config.ref,
            "manifest_path": config.manifest_path,
            "template_root": source_report["template_root"],
            "template_root_sha256": source_report["template_root_sha256"],
        },
        generation={
            "compiler": "tokenmoulds",
            "compiler_version": _PIPELINE_VERSION,
            "org_id": config.org_id,
            "brand_id": document_ir.org_id,
            "locale": config.locale,
            "output_format": fmt,
            "tokens_sha256": compute_template_hash(tokens),
            "artifact_plan_sha256": source_report["build_config_sha256"],
            "font_pair_id": config.font_pair_id,
        },
        plan={
            "output_formats": list(config.output_formats),
            "design_policy": config.policy,
            "base_font_size_pt": config.base_font_size_pt,
            "base_grid_pt": config.base_grid_pt,
            "embed_fonts": config.embed_fonts,
            "validate": config.validate,
            "render_validation": config.render_validation,
        },
        quality={
            "validation_requested": config.validate,
            "validation_engine": source_report["validation"]["engine"],
            "validation_engine_version": source_report["validation"]["engine_version"],
            "max_issue_count": config.max_issue_count,
            "max_error_count": config.max_error_count,
            "max_warning_count": config.max_warning_count,
            "max_info_count": config.max_info_count,
        },
        review={"state": config.review_state},
    )
