"""Collectors for semantic provenance artifacts."""

from __future__ import annotations

from typing import Any, Mapping

from tokenmoulds.semantic.lowerers.excel import lower_excel_content_with_trace
from tokenmoulds.semantic.lowerers.word import lower_word_content
from tokenmoulds.semantic.lowerers.writer import lower_writer_content
from tokenmoulds.semantic.provenance import (
    SemanticProvenance,
    semantic_content_to_payload,
)

_HEADER_FOOTER_GROUPS = ("headers", "footers")
_HEADER_FOOTER_SLOTS = ("left", "center", "right", "outer", "inner")


def _unwrap(value: object) -> object:
    """Unwrap a DTCG ``{\"$value\": X}`` envelope when present."""
    if isinstance(value, dict) and "$value" in value:
        return value["$value"]
    return value


def collect_header_footer_semantic_provenance(
    tokens: Mapping[str, Any],
    *,
    header_footer_registry: Mapping[str, Any],
    org_id: str,
) -> tuple[SemanticProvenance, ...]:
    """Collect semantic provenance entries for long-form header/footer slots."""
    entries: list[SemanticProvenance] = []

    for group_name in _HEADER_FOOTER_GROUPS:
        group = tokens.get(group_name)
        if not isinstance(group, Mapping):
            continue

        for name, entry in group.items():
            if name.startswith("$") or not isinstance(entry, Mapping):
                continue

            cfg = header_footer_registry.get(name)
            if cfg is None:
                continue

            content_entry = _unwrap(entry.get("content", {})) or {}
            if not isinstance(content_entry, Mapping):
                content_entry = {}

            for slot in _HEADER_FOOTER_SLOTS:
                top_level_key = f"content_{slot}"
                if top_level_key in entry:
                    authored_value = _unwrap(entry[top_level_key])
                    source_path = f"{group_name}.{name}.{top_level_key}"
                elif slot in content_entry:
                    authored_value = _unwrap(content_entry[slot])
                    source_path = f"{group_name}.{name}.content.{slot}"
                else:
                    continue

                normalized_value = cfg.slot_content(slot)
                if normalized_value is None or not normalized_value.items:
                    continue

                diagnostics = ()
                if isinstance(authored_value, str):
                    diagnostics = ("deprecated_syntax",)

                entries.append(
                    SemanticProvenance(
                        source_path=source_path,
                        authored_value=authored_value,
                        normalized_value=semantic_content_to_payload(normalized_value),
                        per_format={
                            "word": lower_word_content(normalized_value).decisions,
                            "writer": lower_writer_content(
                                normalized_value,
                                document_title=f"{org_id} Document",
                            ).decisions,
                            "excel": lower_excel_content_with_trace(
                                normalized_value
                            ).decisions,
                        },
                        diagnostics=diagnostics,
                    )
                )

    return tuple(entries)
