"""Shared semantic build context helpers.

This module centralizes interpretation of user-facing token inputs so CLI,
pipeline, MCP, and emitters do not each invent their own precedence rules.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class FontRoles:
    """Canonical semantic font roles for a build."""

    heading: str
    body: str
    mono: str | None = None

    def to_token_font_pair(self) -> dict[str, str]:
        """Return token input keys with canonical and legacy aliases."""
        result = {
            "heading": self.heading,
            "body": self.body,
            "major": self.heading,
            "minor": self.body,
            "sans": self.body,
            "serif": self.heading,
        }
        if self.mono:
            result["mono"] = self.mono
        return result

    def to_dict(self) -> dict[str, str]:
        result = {"heading": self.heading, "body": self.body}
        if self.mono:
            result["mono"] = self.mono
        return result


def resolve_font_roles(font_pair: Mapping[str, Any] | None) -> FontRoles:
    """Resolve mixed legacy/canonical font keys into semantic roles."""
    source = font_pair or {}
    body = _first_string(
        source,
        ("body", "minor", "sans"),
        default="Inter",
    )
    heading = _first_string(
        source,
        ("heading", "major", "serif"),
        default=body,
    )
    mono = _first_string(source, ("mono", "monospace"), default="")
    return FontRoles(heading=heading, body=body, mono=mono or None)


def font_pair_from_tokens(tokens: Mapping[str, Any]) -> dict[str, str]:
    """Extract canonical token font-pair aliases from resolved tokens."""
    typography_fonts = tokens.get("typography", {})
    if isinstance(typography_fonts, Mapping):
        fonts = typography_fonts.get("fonts", {})
        if isinstance(fonts, Mapping) and fonts:
            return resolve_font_roles(fonts).to_token_font_pair()

    inputs = tokens.get("inputs", {})
    if isinstance(inputs, Mapping):
        font_pair = inputs.get("font_pair", {})
        if isinstance(font_pair, Mapping):
            return resolve_font_roles(font_pair).to_token_font_pair()

    return resolve_font_roles({}).to_token_font_pair()


def _first_string(
    source: Mapping[str, Any], keys: tuple[str, ...], *, default: str
) -> str:
    for key in keys:
        value = source.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return default
