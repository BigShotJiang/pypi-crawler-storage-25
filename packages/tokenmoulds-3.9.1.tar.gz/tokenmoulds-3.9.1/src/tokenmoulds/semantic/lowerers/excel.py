"""Excel lowering for semantic header/footer content."""

from __future__ import annotations

from tokenmoulds.semantic.content import (
    CurrentDate,
    CurrentTime,
    DocumentTitle,
    FileName,
    LiteralText,
    PageCount,
    PageNumber,
    RunningHeading,
    SemanticContentInput,
    SheetName,
    ensure_semantic_content,
)
from tokenmoulds.semantic.capabilities import capability_for
from tokenmoulds.semantic.provenance import LoweringDecision, LoweringResult

_EXCEL_FIELD_TOKENS: dict[str, str] = {
    "PAGE": "&P",
    "NUMPAGES": "&N",
    "DATE": "&D",
    "TIME": "&T",
    "FILENAME": "&F",
    "SHEETNAME": "&A",
}


def _legacy_split_excel_content(content: str) -> str:
    parts: list[str] = []
    for token in content.split(" "):
        if token.startswith("STYLEREF:"):
            parts.append("&A")
            continue
        parts.append(_EXCEL_FIELD_TOKENS.get(token, token))
    return " ".join(parts)


def lower_excel_content_with_trace(
    content: SemanticContentInput,
) -> LoweringResult[str]:
    """Lower semantic content to Excel escapes with provenance."""
    semantic = ensure_semantic_content(content)
    if not semantic.items:
        return LoweringResult(rendered="", decisions=())

    if (
        isinstance(content, str)
        and len(semantic.items) == 1
        and isinstance(semantic.items[0], LiteralText)
    ):
        rendered = _legacy_split_excel_content(semantic.items[0].text)
        mode = "fallback" if rendered != semantic.items[0].text else "literal"
        reason = None
        if mode == "fallback":
            reason = "Legacy string compatibility token split for Excel field codes."
        return LoweringResult(
            rendered=rendered,
            decisions=(
                LoweringDecision(
                    kind="literal_text",
                    mode=mode,
                    rendered=rendered,
                    reason=reason,
                ),
            ),
        )

    rendered_parts: list[str] = []
    decisions: list[LoweringDecision] = []
    for item in semantic:
        capability = capability_for("excel", item)
        if isinstance(item, PageNumber):
            rendered = "&P"
        elif isinstance(item, PageCount):
            rendered = "&N"
        elif isinstance(item, CurrentDate):
            rendered = "&D"
        elif isinstance(item, CurrentTime):
            rendered = "&T"
        elif isinstance(item, FileName):
            rendered = "&F"
        elif isinstance(item, (SheetName, RunningHeading)):
            rendered = "&A"
        elif isinstance(item, DocumentTitle):
            rendered = "{document.title}"
        elif isinstance(item, LiteralText):
            rendered = item.text
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unsupported semantic item {item!r}")
        rendered_parts.append(rendered)
        decisions.append(
            LoweringDecision(
                kind=capability.kind,
                mode=capability.mode,
                rendered=rendered,
                reason=capability.reason,
            )
        )

    return LoweringResult(rendered="".join(rendered_parts), decisions=tuple(decisions))


def lower_excel_content(content: SemanticContentInput) -> str:
    """Lower semantic content to Excel header/footer escapes."""
    return lower_excel_content_with_trace(content).rendered
