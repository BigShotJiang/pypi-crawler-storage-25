"""Writer lowering for semantic header/footer content."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import lxml.etree as etree

from tokenmoulds.emitters.odf_helpers import q
from tokenmoulds.semantic.content import (
    CurrentDate,
    CurrentTime,
    DocumentTitle,
    FileName,
    LiteralText,
    PageCount,
    PageNumber,
    RunningHeading,
    SemanticContentInput,
    SheetName,
    ensure_semantic_content,
    to_legacy_content_spec,
)
from tokenmoulds.semantic.capabilities import capability_for
from tokenmoulds.semantic.provenance import LoweringDecision, LoweringResult

WriterOpKind = Literal["text", "page-number", "page-count", "chapter", "title"]


@dataclass(frozen=True)
class WriterContentOp:
    """One Writer content operation."""

    op: WriterOpKind
    text: str | None = None
    attrs: tuple[tuple[str, str], ...] = ()


def _append_text(paragraph: etree._Element, text: str) -> None:
    if len(paragraph):
        last = paragraph[-1]
        existing = last.tail or ""
        last.tail = existing + text
    else:
        existing = paragraph.text or ""
        paragraph.text = existing + text


def _rendered_dict(op: WriterContentOp) -> dict[str, object]:
    return {
        "op": op.op,
        "text": op.text,
        "attrs": dict(op.attrs),
    }


def lower_writer_content(
    content: SemanticContentInput,
    *,
    document_title: str,
) -> LoweringResult[tuple[WriterContentOp, ...]]:
    """Lower semantic content into Writer operations with provenance."""
    semantic = ensure_semantic_content(content)
    ops: list[WriterContentOp] = []
    decisions: list[LoweringDecision] = []
    for item in semantic:
        capability = capability_for("writer", item)
        if isinstance(item, PageNumber):
            op = WriterContentOp(
                op="page-number",
                text="1",
                attrs=((q("text", "select-page"), "current"),),
            )
        elif isinstance(item, PageCount):
            op = WriterContentOp(op="page-count", text="1")
        elif isinstance(item, RunningHeading):
            op = WriterContentOp(
                op="chapter",
                attrs=(
                    (q("text", "display"), "name"),
                    (q("text", "outline-level"), str(item.level)),
                ),
            )
        elif isinstance(item, DocumentTitle):
            op = WriterContentOp(op="title", text=document_title or "Document Title")
        elif isinstance(
            item, (LiteralText, SheetName, CurrentDate, CurrentTime, FileName)
        ):
            op = WriterContentOp(
                op="text",
                text=to_legacy_content_spec(type(semantic)(items=(item,))) or "",
            )
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unsupported semantic item {item!r}")
        ops.append(op)
        decisions.append(
            LoweringDecision(
                kind=capability.kind,
                mode=capability.mode,
                rendered=_rendered_dict(op),
                reason=capability.reason,
            )
        )
    return LoweringResult(rendered=tuple(ops), decisions=tuple(decisions))


def append_writer_content(
    paragraph: etree._Element,
    content: SemanticContentInput,
    *,
    document_title: str,
) -> None:
    """Lower semantic content into ODF Writer field/text nodes."""
    for op in lower_writer_content(content, document_title=document_title).rendered:
        if op.op == "page-number":
            element = etree.SubElement(paragraph, q("text", "page-number"))
            for key, value in op.attrs:
                element.set(key, value)
            element.text = op.text
        elif op.op == "page-count":
            element = etree.SubElement(paragraph, q("text", "page-count"))
            element.text = op.text
        elif op.op == "chapter":
            element = etree.SubElement(paragraph, q("text", "chapter"))
            for key, value in op.attrs:
                element.set(key, value)
        elif op.op == "title":
            element = etree.SubElement(paragraph, q("text", "title"))
            element.text = op.text
        elif op.op == "text":
            _append_text(paragraph, op.text or "")
