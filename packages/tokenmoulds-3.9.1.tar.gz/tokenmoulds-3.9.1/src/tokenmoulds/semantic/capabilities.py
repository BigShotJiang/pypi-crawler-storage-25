"""Capability declarations for semantic content lowerers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypeAlias

from tokenmoulds.semantic.content import (
    CurrentDate,
    CurrentTime,
    DocumentTitle,
    FileName,
    LiteralText,
    PageCount,
    PageNumber,
    RunningHeading,
    SemanticContentItem,
    SheetName,
)

LoweringMode: TypeAlias = Literal["native", "fallback", "literal", "unsupported"]
FormatName: TypeAlias = Literal["word", "writer", "excel"]
SemanticKind: TypeAlias = Literal[
    "literal_text",
    "page_number",
    "page_count",
    "running_heading",
    "document_title",
    "sheet_name",
    "current_date",
    "current_time",
    "file_name",
]


@dataclass(frozen=True)
class LoweringCapability:
    """Declared handling mode for one semantic kind in one format."""

    format_name: FormatName
    kind: SemanticKind
    mode: LoweringMode
    reason: str | None = None


_CAPABILITY_MATRIX: dict[
    FormatName, dict[SemanticKind, tuple[LoweringMode, str | None]]
] = {
    "word": {
        "literal_text": ("literal", None),
        "page_number": ("native", None),
        "page_count": ("native", None),
        "running_heading": ("native", None),
        "document_title": ("native", None),
        "sheet_name": ("literal", "Word lowerer currently emits the placeholder text."),
        "current_date": (
            "literal",
            "Word lowerer currently emits the placeholder text.",
        ),
        "current_time": (
            "literal",
            "Word lowerer currently emits the placeholder text.",
        ),
        "file_name": ("literal", "Word lowerer currently emits the placeholder text."),
    },
    "writer": {
        "literal_text": ("literal", None),
        "page_number": ("native", None),
        "page_count": ("native", None),
        "running_heading": ("native", None),
        "document_title": ("native", None),
        "sheet_name": (
            "literal",
            "Writer lowerer currently emits literal placeholder text.",
        ),
        "current_date": (
            "literal",
            "Writer lowerer currently emits literal placeholder text.",
        ),
        "current_time": (
            "literal",
            "Writer lowerer currently emits literal placeholder text.",
        ),
        "file_name": (
            "literal",
            "Writer lowerer currently emits literal placeholder text.",
        ),
    },
    "excel": {
        "literal_text": ("literal", None),
        "page_number": ("native", None),
        "page_count": ("native", None),
        "running_heading": ("fallback", "Excel falls back to the sheet name field."),
        "document_title": (
            "literal",
            "Excel currently emits the document title placeholder literally.",
        ),
        "sheet_name": ("native", None),
        "current_date": ("native", None),
        "current_time": ("native", None),
        "file_name": ("native", None),
    },
}


def semantic_kind_name(item: SemanticContentItem) -> SemanticKind:
    """Return the canonical semantic kind string for a content item."""
    if isinstance(item, LiteralText):
        return "literal_text"
    if isinstance(item, PageNumber):
        return "page_number"
    if isinstance(item, PageCount):
        return "page_count"
    if isinstance(item, RunningHeading):
        return "running_heading"
    if isinstance(item, DocumentTitle):
        return "document_title"
    if isinstance(item, SheetName):
        return "sheet_name"
    if isinstance(item, CurrentDate):
        return "current_date"
    if isinstance(item, CurrentTime):
        return "current_time"
    if isinstance(item, FileName):
        return "file_name"
    raise TypeError(f"Unsupported semantic item {item!r}")


def capability_for(
    format_name: FormatName,
    kind_or_item: SemanticKind | SemanticContentItem,
) -> LoweringCapability:
    """Return the declared handling mode for a semantic item in one format."""
    kind = (
        kind_or_item
        if isinstance(kind_or_item, str)
        else semantic_kind_name(kind_or_item)
    )
    mode, reason = _CAPABILITY_MATRIX[format_name][kind]
    return LoweringCapability(
        format_name=format_name,
        kind=kind,
        mode=mode,
        reason=reason,
    )
