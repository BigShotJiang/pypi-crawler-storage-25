"""Provenance structures for semantic lowering."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Literal, TypeAlias, TypeVar

from tokenmoulds.semantic.content import (
    CurrentDate,
    CurrentTime,
    DocumentTitle,
    FileName,
    LiteralText,
    PageCount,
    PageNumber,
    RunningHeading,
    SemanticContent,
    SemanticContentItem,
    SheetName,
)

from tokenmoulds.semantic.capabilities import LoweringMode, SemanticKind

RenderedValue = str | dict[str, object] | None
RenderedT = TypeVar("RenderedT")
SemanticDiagnostic: TypeAlias = Literal["deprecated_syntax"]


@dataclass(frozen=True)
class LoweringDecision:
    """One semantic item's handling outcome in one format."""

    kind: SemanticKind
    mode: LoweringMode
    rendered: RenderedValue
    reason: str | None = None


@dataclass(frozen=True)
class LoweringResult(Generic[RenderedT]):
    """Rendered lowering output plus per-item provenance decisions."""

    rendered: RenderedT
    decisions: tuple[LoweringDecision, ...] = ()


@dataclass(frozen=True)
class SemanticProvenance:
    """Optional provenance bundle for a normalized semantic value."""

    source_path: str
    authored_value: object
    normalized_value: object
    per_format: dict[str, tuple[LoweringDecision, ...]]
    diagnostics: tuple[SemanticDiagnostic, ...] = ()


def semantic_item_to_payload(item: SemanticContentItem) -> dict[str, object]:
    """Serialize one semantic content item to a JSON-like payload."""
    if isinstance(item, LiteralText):
        return {"kind": "literal_text", "text": item.text}
    if isinstance(item, PageNumber):
        return {"kind": "page_number"}
    if isinstance(item, PageCount):
        return {"kind": "page_count"}
    if isinstance(item, RunningHeading):
        return {
            "kind": "running_heading",
            "source": "heading",
            "reference": item.reference,
            "level": item.level,
        }
    if isinstance(item, DocumentTitle):
        return {"kind": "document_title"}
    if isinstance(item, SheetName):
        return {"kind": "sheet_name"}
    if isinstance(item, CurrentDate):
        return {"kind": "current_date"}
    if isinstance(item, CurrentTime):
        return {"kind": "current_time"}
    if isinstance(item, FileName):
        return {"kind": "file_name"}
    raise TypeError(f"Unsupported semantic item {item!r}")


def semantic_content_to_payload(
    content: SemanticContent,
) -> tuple[dict[str, object], ...]:
    """Serialize semantic content to a JSON-like payload."""
    return tuple(semantic_item_to_payload(item) for item in content)
