"""Shared Word emitter constants."""

from __future__ import annotations

# Word + DrawingML namespaces used across Word emitter modules.
NSMAP = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "w14": "http://schemas.microsoft.com/office/word/2010/wordml",
    "w15": "http://schemas.microsoft.com/office/word/2012/wordml",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
}

W = f"{{{NSMAP['w']}}}"
W14 = f"{{{NSMAP['w14']}}}"
A = f"{{{NSMAP['a']}}}"
R = f"{{{NSMAP['r']}}}"
