"""Semantic slide rendering helpers for the PowerPoint emitter.

Provides data-driven rendering of semantic slide archetypes (hero cover,
section statement, card matrix) using :class:`SemanticSlideDescriptor`
constants. Free functions taking the concrete ``PowerPointEmitter`` as
their first argument.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import lxml.etree as etree

from tokenmoulds.dtcg.layout_recipe_resolver import get_semantic_layout_spec
from tokenmoulds.emitters.pptx_layout import (
    get_slide_dimensions_emu,
    resolved_regions_for_layout,
)
from tokenmoulds.emitters.pptx_master import _seed_layout_name
from tokenmoulds.emitters.pptx_shape_helpers import (
    PRESENTATIONML_NS,
    append_no_outline,
    assign_group_shape_ids,
    read_shape_rect,
    set_group_rect,
    shape_bounds_in_group,
)
from tokenmoulds.emitters.xml_helpers import replace_placeholders
from tokenmoulds.emitters.xml_helpers_fills import emit_fill, emit_illustration_group

if TYPE_CHECKING:
    from tokenmoulds.emitters.powerpoint import PowerPointEmitter


# ---------------------------------------------------------------------------
# Semantic slide descriptors
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SemanticSlideDescriptor:
    """Everything needed to render a semantic slide from its SSOT template."""

    template_name: str
    regions: tuple[str, ...]
    placeholder_context_map: dict[str, str]
    named_shapes: dict[str, str]
    extra_context: dict[str, str]


_HERO_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_hero.xml",
    # Order matters: title before kicker (kicker fallback depends on title rect)
    regions=("background", "overlay", "title", "kicker", "subtitle"),
    placeholder_context_map={
        "background": "BACKGROUND",
        "overlay": "OVERLAY",
        "kicker": "KICKER",
        "title": "TITLE",
        "subtitle": "SUBTITLE",
    },
    named_shapes={"background": "Hero Background 1", "overlay": "Hero Overlay 2"},
    extra_context={
        "SLIDE_KICKER": "{org_id_upper}",
        "SLIDE_SUBTITLE": "Token-driven hero cover layout",
    },
)

_SECTION_STATEMENT_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_section_statement.xml",
    regions=("background", "band", "title", "body"),
    placeholder_context_map={
        "background": "BACKGROUND",
        "band": "BAND",
        "title": "TITLE",
        "body": "BODY",
    },
    named_shapes={"background": "Section Background 1", "band": "Section Band 2"},
    extra_context={
        "SLIDE_BODY": "A token-driven section divider for semantic slide galleries",
    },
)

_CARD_MATRIX_DESCRIPTOR = SemanticSlideDescriptor(
    template_name="ssot/slide_card_matrix.xml",
    regions=("title", "body", "card_1", "card_2", "card_3", "card_4"),
    placeholder_context_map={
        "title": "TITLE",
        "body": "BODY",
        "card_1": "CARD1",
        "card_2": "CARD2",
        "card_3": "CARD3",
        "card_4": "CARD4",
    },
    named_shapes={
        "card_1": "Card Surface 1",
        "card_2": "Card Surface 2",
        "card_3": "Card Surface 3",
        "card_4": "Card Surface 4",
    },
    extra_context={
        "SLIDE_TITLE": "{org_id} Capabilities",
        "SLIDE_BODY": "Four reusable card surfaces driven by semantic regions",
    },
)

_SEMANTIC_SLIDE_DESCRIPTORS: dict[str, SemanticSlideDescriptor] = {
    "ssot/slide_hero.xml": _HERO_DESCRIPTOR,
    "ssot/slide_section_statement.xml": _SECTION_STATEMENT_DESCRIPTOR,
    "ssot/slide_card_matrix.xml": _CARD_MATRIX_DESCRIPTOR,
}


# ---------------------------------------------------------------------------
# Free functions
# ---------------------------------------------------------------------------


def baseline_emu(emitter: PowerPointEmitter) -> int:
    """Resolved baseline grid (EMU) for the document."""
    return int(emitter.document.typography.baseline_emu or 152400)


def _region_fallback(
    emitter: PowerPointEmitter,
    region_name: str,
    base_emu: int,
    slide_width: int,
    slide_height: int,
    resolved: dict[str, tuple[int, int, int, int]],
) -> tuple[int, int, int, int]:
    """Compute a sensible fallback rect for a region."""
    if region_name == "background":
        return (0, 0, slide_width, slide_height)
    if region_name == "overlay":
        return (0, 0, slide_width * 2 // 3, slide_height)
    if region_name == "band":
        return (0, 0, max(slide_width // 3, base_emu * 8), slide_height)
    if region_name == "kicker" and "title" in resolved:
        t = resolved["title"]
        return (
            t[0],
            max(base_emu * 2, t[1] - base_emu * 2),
            min(t[2], slide_width // 3),
            base_emu * 2,
        )
    kind = {"title": "title", "subtitle": "body", "body": "body"}.get(region_name)
    if kind:
        for ph in emitter.document.presentation_layout.placeholders:
            if ph.kind == kind:
                return (ph.x, ph.y, ph.cx, ph.cy)
    return (base_emu * 2, base_emu * 6, slide_width // 3, slide_height // 4)


def _customize_semantic_slide_ssot(
    emitter: PowerPointEmitter, descriptor: SemanticSlideDescriptor
) -> bytes:
    """Render any semantic slide archetype from its descriptor."""
    root = emitter.templates.read_tree(descriptor.template_name)
    slide_width, slide_height = get_slide_dimensions_emu(emitter)
    base_emu = baseline_emu(emitter)

    resolved: dict[str, tuple[int, int, int, int]] = {}
    for region_name in descriptor.regions:
        fallback = _region_fallback(
            emitter, region_name, base_emu, slide_width, slide_height, resolved
        )
        resolved[region_name] = _seed_layout_region_rect(emitter, region_name, fallback)

    context: dict[str, str] = {}
    for region_name, rect in resolved.items():
        prefix = descriptor.placeholder_context_map.get(region_name)
        if prefix:
            x, y, cx, cy = rect
            context[f"{prefix}_X"] = str(x)
            context[f"{prefix}_Y"] = str(y)
            context[f"{prefix}_CX"] = str(cx)
            context[f"{prefix}_CY"] = str(cy)

    org_id = emitter.document.org_id
    for key, value in descriptor.extra_context.items():
        context[key] = value.format(
            org_id=org_id,
            org_id_upper=org_id.replace("-", " ").upper(),
        )
    context.setdefault("SLIDE_TITLE", f"{org_id} Template")
    context.setdefault("SLIDE_BODY", "")

    replace_placeholders(root, context)

    for region_name, shape_name in descriptor.named_shapes.items():
        _apply_fill_to_named_shape(
            root,
            shape_name=shape_name,
            fill_tokens=_selected_decorative_fill(emitter, region_name),
        )

    return emitter._serialize_tree(root)


def customize_slide_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize slide via DOM-based placeholder replacement."""
    semantic_spec = get_semantic_layout_spec(_seed_layout_name(emitter))
    if semantic_spec is not None and semantic_spec.seed_template_name:
        descriptor = _SEMANTIC_SLIDE_DESCRIPTORS.get(semantic_spec.seed_template_name)
        if descriptor is not None:
            return _customize_semantic_slide_ssot(emitter, descriptor)
    context = {
        "SLIDE_TITLE": f"{emitter.document.org_id} Template",
        "SLIDE_CONTENT": "Sample slide content",
    }
    return emitter._render_tree("ssot/slide.xml", context)


# ------------------------------------------------------------------
# Fill application helpers
# ------------------------------------------------------------------


def _seed_layout_region_rect(
    emitter: PowerPointEmitter,
    name: str,
    fallback: tuple[int, int, int, int],
) -> tuple[int, int, int, int]:
    """Return the selected layout region rectangle or a fallback."""
    resolved = resolved_regions_for_layout(emitter, _seed_layout_name(emitter)).get(
        name
    )
    if resolved is None:
        return fallback
    return resolved


def _selected_decorative_fill(
    emitter: PowerPointEmitter, region_name: str
) -> dict[str, object] | None:
    """Return decorative fill tokens for the selected semantic slide."""
    decoration = emitter.document.presentation_layout.decoration
    if region_name in decoration.decorative_fills:
        return decoration.decorative_fills[region_name]
    if region_name == "background":
        return decoration.background_fill
    if region_name == "overlay":
        return decoration.overlay_fill
    return None


def _apply_fill_to_named_shape(
    root: etree._Element,
    *,
    shape_name: str,
    fill_tokens: dict[str, object] | None,
) -> None:
    """Apply fill tokens to a named slide shape."""
    if fill_tokens is None:
        return
    shapes = root.xpath(
        f".//p:sp[p:nvSpPr/p:cNvPr[@name='{shape_name}']]",
        namespaces={"p": PRESENTATIONML_NS},
    )
    if not shapes:
        return
    shape: etree._Element = shapes[0]  # type: ignore[assignment]
    if fill_tokens.get("type") == "illustration":
        _replace_shape_with_illustration(
            root,
            shape=shape,
            shape_name=shape_name,
            fill_tokens=fill_tokens,
        )
        return
    sp_pr: etree._Element | None = shape.find(f"{{{PRESENTATIONML_NS}}}spPr")  # type: ignore[assignment]
    if sp_pr is None:
        return
    emit_fill(sp_pr, fill_tokens)
    append_no_outline(sp_pr)


def _replace_shape_with_illustration(
    root: etree._Element,
    *,
    shape: etree._Element,
    shape_name: str,
    fill_tokens: dict[str, object],
) -> None:
    """Replace a decorative placeholder shape with an illustration group."""
    shape_xml = fill_tokens.get("shape_xml")
    if not shape_xml:
        sp_pr = shape.find(f"{{{PRESENTATIONML_NS}}}spPr")
        if sp_pr is None:
            return
        emit_fill(sp_pr, fill_tokens)
        append_no_outline(sp_pr)
        return

    parent = shape.getparent()
    if parent is None:
        return
    target_rect = read_shape_rect(shape)
    if target_rect is None:
        return
    insertion_index = parent.index(shape)
    parent.remove(shape)
    group_shape = emit_illustration_group(parent, str(shape_xml))
    parent.remove(group_shape)
    parent.insert(insertion_index, group_shape)

    assign_group_shape_ids(root, group_shape, base_name=f"{shape_name} Illustration")
    source_bounds = shape_bounds_in_group(group_shape)
    set_group_rect(
        group_shape,
        target_rect=target_rect,
        source_bounds=source_bounds,
    )
