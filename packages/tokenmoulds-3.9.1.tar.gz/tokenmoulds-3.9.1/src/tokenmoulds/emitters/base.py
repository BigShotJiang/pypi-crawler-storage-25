"""Base class for all document emitters.

Defines the stable constructor contract and package contract shared by all
document emitters.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

    from tokenmoulds.artifact_intent import ArtifactIntentMetadata
    from tokenmoulds.ir import DocumentIR


class BaseEmitter(ABC):
    """Abstract base class for all document emitters.

    All emitters consume a DocumentIR and produce bytes representing
    a document package (OOXML, ODF, etc.).
    """

    def __init__(
        self,
        document: "DocumentIR",
        template_root: Path | str | None = None,
        *,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: object | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
        layout_families: Sequence[object] | None = None,
        output_format: str | None = None,
        allow_font_downloads: bool = False,
        artifact_intent: "ArtifactIntentMetadata | Mapping[str, Any] | None" = None,
    ) -> None:
        """Initialize the emitter.

        Args:
            document: The Document IR containing all style/typography information
            template_root: Optional override path for XML templates
            embed_fonts: Whether to embed fonts into the package (if supported)
            fonts_dir: Optional fonts directory used by font embedders
            style_resolver: Optional cached style resolver for compatibility
            use_pure_text_colors: If True, force strict black/white text defaults
            enable_opentype_features: If True, keep OpenType rendering features
            layout_families: Optional layout families requested by the emitter
            output_format: Optional output format hint (for format-specific emitters)
            allow_font_downloads: Whether font embedding may fetch approved fonts
            artifact_intent: Optional side-channel metadata for generated artifacts
        """
        self.document = document
        self.template_root = template_root
        self.embed_fonts = embed_fonts
        self.fonts_dir = Path(fonts_dir) if fonts_dir else None
        self.style_resolver = style_resolver
        self.use_pure_text_colors = use_pure_text_colors
        self.enable_opentype_features = enable_opentype_features
        self.layout_families = list(layout_families or [])
        self.output_format = output_format
        self.allow_font_downloads = allow_font_downloads
        self.artifact_intent = artifact_intent

    @abstractmethod
    def build_package(self) -> bytes:
        """Build the output package.

        Returns:
            bytes: The complete document package
        """
        pass
