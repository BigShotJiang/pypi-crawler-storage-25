"""Settings, document layout, and numbering customization for the Word emitter.

Free functions taking the concrete ``WordDocumentEmitter`` as their first
argument.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

import lxml.etree as etree

from tokenmoulds.emitters.word_sect_pr import build_sect_pr
from tokenmoulds.emitters.word_sections_layout import (
    apply_section_settings_to_sect_pr,
    attach_section_pr,
    build_section_paragraphs,
    find_template_paragraph,
    insert_section_break,
)
from tokenmoulds.emitters.word_shared import NSMAP, W
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)
from tokenmoulds.ir import DocumentSettings

if TYPE_CHECKING:
    from tokenmoulds.emitters.word import WordDocumentEmitter


def customize_settings(emitter: WordDocumentEmitter, data: bytes) -> bytes:
    """Customize settings.xml with document-wide typography settings."""
    root = etree.fromstring(data)
    settings = emitter.document.document_settings

    _apply_hyphenation_settings_ssot(root, settings)
    _apply_tab_settings_ssot(root, settings)
    _apply_compatibility_settings_ssot(emitter, root, settings)
    _apply_even_odd_headers_ssot(emitter, root)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _apply_even_odd_headers_ssot(
    emitter: WordDocumentEmitter, root: etree._Element
) -> None:
    """Emit ``<w:evenAndOddHeaders/>`` when any long-form section uses it."""
    if not any(s.odd_even_different for s in emitter.document.long_form_sections):
        return
    if root.find("w:evenAndOddHeaders", NSMAP) is not None:
        return
    element = etree.Element(f"{W}evenAndOddHeaders")
    for successor_name in (
        "w:characterSpacingControl",
        "w:compat",
        "w:themeFontLang",
        "w:clrSchemeMapping",
    ):
        successor = root.find(successor_name, NSMAP)
        if successor is not None:
            successor.addprevious(element)
            return
    root.append(element)


def _apply_hyphenation_settings_ssot(
    root: etree._Element, settings: DocumentSettings
) -> None:
    """Apply hyphenation settings to settings.xml."""
    auto_hyph = root.find("w:autoHyphenation", NSMAP)
    if auto_hyph is not None:
        auto_hyph.set(f"{W}val", "1" if settings.auto_hyphenation else "0")

    hyph_zone = root.find("w:hyphenationZone", NSMAP)
    if hyph_zone is not None:
        hyph_zone.set(f"{W}val", str(settings.hyphenation_zone_twips))

    consec = root.find("w:consecutiveHyphenLimit", NSMAP)
    if consec is not None:
        consec.set(f"{W}val", str(settings.consecutive_hyphen_limit))

    no_caps = root.find("w:doNotHyphenateCaps", NSMAP)
    if no_caps is not None:
        no_caps.set(f"{W}val", "1" if not settings.hyphenate_caps else "0")


def _apply_tab_settings_ssot(root: etree._Element, settings: DocumentSettings) -> None:
    """Apply default tab stop setting."""
    tab_stop = root.find("w:defaultTabStop", NSMAP)
    if tab_stop is not None:
        tab_stop.set(f"{W}val", str(settings.default_tab_stop_twips))


def _apply_compatibility_settings_ssot(
    emitter: WordDocumentEmitter,
    root: etree._Element,
    settings: DocumentSettings,
) -> None:
    """Apply compatibility settings."""
    compat = root.find("w:compat", NSMAP)
    if compat is None:
        return

    for cs in compat.findall("w:compatSetting", NSMAP):
        if cs.get(f"{W}name") == "enableOpenTypeFeatures":
            if emitter.allow_opentype_features and settings.enable_opentype_features:
                cs.set(f"{W}val", "1")
            else:
                cs.set(f"{W}val", "0")
            break


def customize_document(emitter: WordDocumentEmitter, data: bytes) -> bytes:
    """Customize document.xml with sample content and layout."""
    root = etree.fromstring(data)

    _add_sample_content(emitter, root)

    _apply_section_properties(emitter, root)

    _PLACEHOLDER_RE = re.compile(r"\$\{[^}]+\}")
    for el in list(root.iter()):
        if "data-template" in el.attrib:
            parent = el.getparent()
            if parent is not None:
                parent.remove(el)
                continue
        for attr_val in el.attrib.values():
            if isinstance(attr_val, bytes):
                attr_val = attr_val.decode("utf-8", errors="ignore")
            if _PLACEHOLDER_RE.search(attr_val):
                parent = el.getparent()
                if parent is not None:
                    parent.remove(el)
                break

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _add_sample_content(emitter: WordDocumentEmitter, root: etree._Element) -> None:
    """Add sample content to document body for template preview."""
    body = root.find(".//w:body", NSMAP)
    if body is None:
        return

    sect_pr = body.find("w:sectPr", NSMAP)
    for p in body.findall("w:p", NSMAP):
        body.remove(p)

    if emitter.document.long_form_sections:
        if sect_pr is not None:
            body.remove(sect_pr)
            body.append(sect_pr)
        return

    ssot_template = emitter.templates.read_tree("document.xml")

    heading_el = clone_template_element(ssot_template, "paragraph_heading")
    replace_placeholders(
        heading_el,
        {
            "STYLE_ID": "Heading1",
            "TEXT": f"{emitter.document.org_id} Template",
            "OUTLINE_LEVEL": "0",
            "BOOKMARK_ID": "1",
        },
    )
    remove_template_elements(heading_el)
    body.insert(0, heading_el)

    body_el = clone_template_element(ssot_template, "paragraph_body")
    replace_placeholders(
        body_el,
        {
            "STYLE_ID": "BodyText",
            "TEXT": "TokenMoulds Document IR powers this body copy.",
        },
    )
    remove_template_elements(body_el)
    body.insert(1, body_el)

    if sect_pr is not None:
        body.remove(sect_pr)
        body.append(sect_pr)


def _apply_section_properties(
    emitter: WordDocumentEmitter, root: etree._Element
) -> None:
    """Apply section properties (page size, margins, columns, grid)."""
    body = root.find(".//w:body", NSMAP)
    if body is None:
        return
    final_sect_pr = body.find("w:sectPr", NSMAP)
    if final_sect_pr is None:
        return

    if emitter.document.long_form_sections:
        _apply_long_form_sections(emitter, body, final_sect_pr)
        return

    sections = emitter.document.sections

    if sections:
        ssot_template = emitter.templates.read_tree("document.xml")

        for section in sections[:-1]:
            insert_section_break(emitter, body, final_sect_pr, ssot_template, section)

        last = sections[-1]
        apply_section_settings_to_sect_pr(
            final_sect_pr,
            page_geometry=last.page_geometry or emitter.document.page_geometry,
            columns=last.columns or emitter.document.section_columns,
            grid=last.grid or emitter.document.document_grid,
        )
    else:
        apply_section_settings_to_sect_pr(
            final_sect_pr,
            page_geometry=emitter.document.page_geometry,
            columns=emitter.document.section_columns,
            grid=emitter.document.document_grid,
        )


def _apply_long_form_sections(
    emitter: WordDocumentEmitter,
    body: etree._Element,
    final_sect_pr: etree._Element,
) -> None:
    """Wire long-form sections into the body with per-section content."""
    bundle = emitter._get_long_form_bundle()
    if bundle is None:
        return

    sections = emitter.document.long_form_sections
    document_has_odd_even = any(s.odd_even_different for s in sections)

    ssot_template = emitter.templates.read_tree("document.xml")
    heading_tmpl = find_template_paragraph(ssot_template, "paragraph_heading")
    body_tmpl = find_template_paragraph(ssot_template, "paragraph_body")

    insert_index = list(body).index(final_sect_pr)
    for index, section in enumerate(sections):
        heading_el, body_el = build_section_paragraphs(
            section,
            index,
            heading_tmpl=heading_tmpl,
            body_tmpl=body_tmpl,
        )
        is_final = index == len(sections) - 1
        if not is_final:
            attach_section_pr(
                body_el,
                section,
                bundle=bundle,
                document_has_odd_even=document_has_odd_even,
            )
        body.insert(insert_index, heading_el)
        insert_index += 1
        body.insert(insert_index, body_el)
        insert_index += 1

    new_final = build_sect_pr(
        sections[-1],
        header_rid_map=bundle.header_rid_map,
        footer_rid_map=bundle.footer_rid_map,
        document_has_odd_even=document_has_odd_even,
    )
    parent = final_sect_pr.getparent()
    if parent is not None:
        parent.replace(final_sect_pr, new_final)
