"""Calc ODF emitter."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

from tokenmoulds.artifact_intent import ArtifactIntentMetadata
from tokenmoulds.design.units import emu_to_pt
from tokenmoulds.emitters.odf_base import OdfBaseEmitter, _LOCALE_CURRENCY

if TYPE_CHECKING:
    from tokenmoulds.ir import DocumentIR


class CalcTemplateEmitter(OdfBaseEmitter):
    """LibreOffice Calc template emitter (.ots).

    Generates ODF spreadsheet templates with:
    - 27 named cell styles (Default, Heading, Good, Bad, Neutral, Note,
      Result, Accent1-6, Accent1Light-Accent6Light)
    - Number/date/currency/percentage formats
    - Locale-aware page setup with baseline-grid row heights
    - OpenType features (ligatures, stylistic sets, etc.)

    Inherits from OdfBaseEmitter (-> BaseEmitter).
    """

    MIMETYPE = "application/vnd.oasis.opendocument.spreadsheet-template"

    # Semantic background tint factor (80% toward white for pastels)
    _SEMANTIC_TINT_FACTOR = 0.8

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: object | None = None,
        layout_families: list[object] | None = None,
        output_format: str | None = None,
        artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None = None,
    ) -> None:
        """Initialize Calc template emitter.

        Args:
            document: Document IR with style information
            template_root: Optional override for template resolution
            use_pure_text_colors: If True, use pure black/white for text
            enable_opentype_features: If True, enable OpenType features
        """
        super().__init__(
            document,
            template_root,
            format_key="calc",
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            style_resolver=style_resolver,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
            layout_families=layout_families,
            output_format=output_format,
            artifact_intent=artifact_intent,
        )

    # ------------------------------------------------------------------
    # Light-tint computation
    # ------------------------------------------------------------------

    @staticmethod
    def _tint_toward_white(hex_color: str, factor: float = 0.8) -> str:
        """Compute a light tint of *hex_color* toward white.

        ``factor`` of 0.8 means 80 % of the way to white, producing a
        pastel variant suitable for AccentNLight cell backgrounds.
        """
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        r2 = int(r + (255 - r) * factor)
        g2 = int(g + (255 - g) * factor)
        b2 = int(b + (255 - b) * factor)
        return f"#{r2:02X}{g2:02X}{b2:02X}"

    # ------------------------------------------------------------------
    # Page geometry helpers
    # ------------------------------------------------------------------

    def _page_dimensions_pt(self) -> dict[str, str]:
        """Return page size, margins and orientation from the IR (in pt)."""
        geom = self.document.page_geometry
        if geom is not None:
            width_pt = emu_to_pt(geom.width_emu)
            height_pt = emu_to_pt(geom.height_emu)
            margin_top = emu_to_pt(geom.margins.top)
            margin_bottom = emu_to_pt(geom.margins.bottom)
            margin_left = emu_to_pt(geom.margins.left)
            margin_right = emu_to_pt(geom.margins.right)
            orientation = "landscape" if geom.is_landscape else "portrait"
        else:
            # A4 defaults in pt (210mm × 297mm)
            width_pt = 210.0 * 72.0 / 25.4
            height_pt = 297.0 * 72.0 / 25.4
            margin_top = margin_bottom = margin_left = margin_right = 2.0 * 72.0 / 2.54
            orientation = "portrait"
        return {
            "PAGE_WIDTH": f"{width_pt:.2f}",
            "PAGE_HEIGHT": f"{height_pt:.2f}",
            "MARGIN_TOP": f"{margin_top:.2f}",
            "MARGIN_BOTTOM": f"{margin_bottom:.2f}",
            "MARGIN_LEFT": f"{margin_left:.2f}",
            "MARGIN_RIGHT": f"{margin_right:.2f}",
            "ORIENTATION": orientation,
        }

    # ------------------------------------------------------------------
    # Styles context
    # ------------------------------------------------------------------

    def _styles_context(self) -> dict[str, str]:
        """Build the full substitution context for styles.xml."""
        body = self.document.body_style
        typo = self.document.typography
        ct = self.document.color_theme

        heading_style = (
            self.document.heading_styles[0] if self.document.heading_styles else body
        )
        heading1_size = heading_style.font_size_pt

        # Row height: from baseline grid or 1.4x body size
        row_height_pt = round(body.font_size_pt * 1.4, 1)
        if (
            self.document.page_geometry is not None
            and self.document.page_geometry.baseline_grid_emu > 0
        ):
            row_height_pt = round(
                emu_to_pt(self.document.page_geometry.baseline_grid_emu), 1
            )
        # Default column width: 5× body font size
        col_width_pt = round(body.font_size_pt * 5, 1)

        # Currency symbol based on locale
        locale_upper = self.document.locale.upper()
        currency_symbol = _LOCALE_CURRENCY.get(locale_upper, "$")

        # Light accent tints (80 % toward white)
        accents = [
            ct.accent1,
            ct.accent2,
            ct.accent3,
            ct.accent4,
            ct.accent5,
            ct.accent6,
        ]
        light_accents = {
            f"ACCENT{i}_LIGHT": self._tint_toward_white(c)
            for i, c in enumerate(accents, 1)
        }

        ctx: dict[str, str] = {
            "BODY_FONT": body.font_family,
            "HEADING_FONT": typo.heading_font,
            "MONO_FONT": typo.monospace_font,
            "BODY_SIZE": f"{body.font_size_pt:.1f}",
            "HEADING_SIZE": f"{heading_style.font_size_pt:.1f}",
            "HEADING1_SIZE": f"{heading1_size:.1f}",
            "BODY_COLOR": body.color,
            "HEADING_COLOR": heading_style.color,
            "ACCENT1": ct.accent1,
            "ACCENT2": ct.accent2,
            "ACCENT3": ct.accent3,
            "ACCENT4": ct.accent4,
            "ACCENT5": ct.accent5,
            "ACCENT6": ct.accent6,
            "DK1": ct.dk1,
            "DK2": ct.dk2,
            "LT1": ct.lt1,
            "LT2": ct.lt2,
            "LINK_COLOR": self.document.hyperlink_style.link_color,
            # Semantic backgrounds: tint accent3 (green-ish), accent2 (red), accent4 (warm)
            "GOOD_BG": self._tint_toward_white(ct.accent3, self._SEMANTIC_TINT_FACTOR),
            "BAD_BG": self._tint_toward_white(ct.accent2, self._SEMANTIC_TINT_FACTOR),
            "NEUTRAL_BG": self._tint_toward_white(
                ct.accent4, self._SEMANTIC_TINT_FACTOR
            ),
            "ROW_HEIGHT": f"{row_height_pt:.2f}",
            "COL_WIDTH": f"{col_width_pt:.2f}",
            "CURRENCY_SYMBOL": currency_symbol,
            **light_accents,
        }
        ctx.update(self._page_dimensions_pt())
        return ctx

    # ------------------------------------------------------------------
    # Package builder
    # ------------------------------------------------------------------

    def build_package(self) -> bytes:
        """Build the Calc template package."""
        buffer = io.BytesIO()
        title_text = f"{self.document.org_id} Spreadsheet Template"
        body_text = (
            f"Body font: {self.document.body_style.font_family} "
            f"{self.document.body_style.font_size_pt:.1f}pt"
        )

        styles_context = self._styles_context()

        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            archive.writestr(
                "mimetype", self.MIMETYPE, compress_type=zipfile.ZIP_STORED
            )
            archive.writestr(
                "content.xml",
                self._render(
                    "content.xml", context={"TITLE": title_text, "BODY": body_text}
                ),
            )
            archive.writestr(
                "styles.xml",
                self._render("styles.xml", context=styles_context),
            )
            # settings.xml (static, no substitutions needed)
            archive.writestr(
                "settings.xml",
                self._render("settings.xml"),
                compress_type=zipfile.ZIP_DEFLATED,
            )
            self._write_common_entries(archive, title=title_text)
        return buffer.getvalue()
