"""Base and Writer ODF emitters."""

from __future__ import annotations

import datetime
import io
import zipfile
from pathlib import Path
from string import Template
from typing import Any, Mapping

import lxml.etree as etree

from tokenmoulds.artifact_intent import (
    ArtifactIntentMetadata,
    artifact_intent_from_mapping,
)
from tokenmoulds.emitters import TemplateResolver
from tokenmoulds.emitters.base import BaseEmitter
from tokenmoulds.emitters.writer import WriterStylesEmitter
from tokenmoulds.ir import DocumentIR

# BCP-47 language tag lookup from 2-letter locale code
_LOCALE_TO_BCP47: dict[str, str] = {
    "US": "en-US",
    "GB": "en-GB",
    "UK": "en-GB",
    "AU": "en-AU",
    "NZ": "en-NZ",
    "IE": "en-IE",
    "ZA": "en-ZA",
    "IN": "en-IN",
    "SG": "en-SG",
    "HK": "en-HK",
    "CA": "en-CA",
    "DE": "de-DE",
    "AT": "de-AT",
    "FR": "fr-FR",
    "BE": "fr-BE",
    "ES": "es-ES",
    "IT": "it-IT",
    "PT": "pt-PT",
    "NL": "nl-NL",
    "JP": "ja-JP",
    "CN": "zh-CN",
    "BR": "pt-BR",
    "MX": "es-MX",
}

# Currency symbol lookup from 2-letter locale code
_LOCALE_CURRENCY: dict[str, str] = {
    "US": "$",
    "GB": "\u00a3",
    "UK": "\u00a3",
    "AU": "$",
    "NZ": "$",
    "CA": "$",
    "SG": "$",
    "HK": "$",
    "EU": "\u20ac",
    "DE": "\u20ac",
    "AT": "\u20ac",
    "FR": "\u20ac",
    "ES": "\u20ac",
    "IT": "\u20ac",
    "PT": "\u20ac",
    "NL": "\u20ac",
    "BE": "\u20ac",
    "IE": "\u20ac",
    "JP": "\u00a5",
    "CN": "\u00a5",
    "IN": "\u20b9",
    "ZA": "R",
    "BR": "R$",
}
_MANIFEST_NS = "urn:oasis:names:tc:opendocument:xmlns:manifest:1.0"
_OFFICE_NS = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
_META_NS = "urn:oasis:names:tc:opendocument:xmlns:meta:1.0"
_ODF_ARTIFACT_INTENT_PART = "tokenmoulds/intent.json"
_ARTIFACT_INTENT_MEDIA_TYPE = "application/vnd.tokenmoulds.artifact-intent+json"


def _normalize_artifact_intent(
    artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None,
) -> ArtifactIntentMetadata | None:
    if artifact_intent is None:
        return None
    if isinstance(artifact_intent, ArtifactIntentMetadata):
        return artifact_intent
    return artifact_intent_from_mapping(artifact_intent)


def _with_artifact_manifest_entry(data: str) -> str:
    root = etree.fromstring(data.encode("utf-8"))
    for entry in root.findall(f"{{{_MANIFEST_NS}}}file-entry"):
        if entry.get(f"{{{_MANIFEST_NS}}}full-path") == _ODF_ARTIFACT_INTENT_PART:
            entry.set(f"{{{_MANIFEST_NS}}}media-type", _ARTIFACT_INTENT_MEDIA_TYPE)
            return _serialize_xml(root).decode("utf-8")
    entry = etree.SubElement(root, f"{{{_MANIFEST_NS}}}file-entry")
    entry.set(f"{{{_MANIFEST_NS}}}full-path", _ODF_ARTIFACT_INTENT_PART)
    entry.set(f"{{{_MANIFEST_NS}}}media-type", _ARTIFACT_INTENT_MEDIA_TYPE)
    return _serialize_xml(root).decode("utf-8")


def _with_artifact_meta_index(data: str, intent: ArtifactIntentMetadata) -> str:
    root = etree.fromstring(data.encode("utf-8"))
    meta = root.find(f"{{{_OFFICE_NS}}}meta")
    if meta is None:
        meta = etree.SubElement(root, f"{{{_OFFICE_NS}}}meta")
    existing = {
        item.get(f"{{{_META_NS}}}name"): item
        for item in meta.findall(f"{{{_META_NS}}}user-defined")
    }
    for name, value in intent.flat_properties(
        payload_part=_ODF_ARTIFACT_INTENT_PART
    ).items():
        item = existing.get(name)
        if item is None:
            item = etree.SubElement(meta, f"{{{_META_NS}}}user-defined")
            item.set(f"{{{_META_NS}}}name", name)
        item.set(f"{{{_META_NS}}}value-type", "string")
        item.text = value
    return _serialize_xml(root).decode("utf-8")


def _serialize_xml(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


class OdfBaseEmitter(BaseEmitter):
    """Base class for ODF (LibreOffice) document emitters.

    Inherits from BaseEmitter and provides ODF-specific functionality:
    - ZIP package building with ODF structure
    - Template rendering with variable substitution
    - OpenType feature support
    - Direct font embedding (OTF/TTF)

    Unlike OOXML emitters, ODF doesn't have native theme colors,
    so use_pure_text_colors has less impact (colors are always literal).
    """

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
        format_key: str = "writer",
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: object | None = None,
        layout_families: list[object] | None = None,
        output_format: str | None = None,
        artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None = None,
    ) -> None:
        """Initialize ODF emitter.

        Args:
            format_key: Format identifier for template resolution ('writer', 'impress')
            document: Document IR with style information
            template_root: Optional override for template resolution
            use_pure_text_colors: If True, use pure black/white for text colors
                (less relevant for ODF since colors are always literal)
            enable_opentype_features: If True, enable OpenType features like
                ligatures, stylistic sets, etc. (LibreOffice 7.0+)
        """
        super().__init__(
            document=document,
            template_root=template_root,
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            style_resolver=style_resolver,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
            layout_families=layout_families,
            output_format=output_format,
            artifact_intent=artifact_intent,
        )
        self.templates = TemplateResolver(format_key, template_root)
        self.format_key = format_key
        self.artifact_intent = _normalize_artifact_intent(artifact_intent)

    def _render(self, name: str, *, context: dict[str, str] | None = None) -> str:
        """Render an XML template with optional variable substitution."""
        template = self.templates.read_text(name, spec_rel_path=f"templates/{name}")
        if context:
            return Template(template).safe_substitute(context)
        return template

    def _write_common_entries(self, archive: zipfile.ZipFile, *, title: str) -> None:
        """Write common ODF package entries (manifest, metadata, settings)."""
        if "META-INF/manifest.xml" not in archive.NameToInfo:
            manifest_xml = self._render("META-INF/manifest.xml")
            if self.artifact_intent is not None:
                manifest_xml = _with_artifact_manifest_entry(manifest_xml)
            archive.writestr(
                "META-INF/manifest.xml",
                manifest_xml,
                compress_type=zipfile.ZIP_DEFLATED,
            )
        locale_upper = (self.document.locale or "US").upper()
        language = _LOCALE_TO_BCP47.get(locale_upper, f"en-{locale_upper}")
        if "meta.xml" not in archive.NameToInfo:
            meta_context = {
                "TITLE": title,
                "DATE": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "LANGUAGE": language,
            }
            meta_xml = self._render("meta.xml", context=meta_context)
            if self.artifact_intent is not None:
                meta_xml = _with_artifact_meta_index(meta_xml, self.artifact_intent)
            archive.writestr(
                "meta.xml",
                meta_xml,
                compress_type=zipfile.ZIP_DEFLATED,
            )
        if (
            self.artifact_intent is not None
            and _ODF_ARTIFACT_INTENT_PART not in archive.NameToInfo
        ):
            archive.writestr(
                _ODF_ARTIFACT_INTENT_PART,
                self.artifact_intent.canonical_json(),
                compress_type=zipfile.ZIP_DEFLATED,
            )
        # Write settings.xml if not already written by a subclass
        if "settings.xml" not in archive.NameToInfo:
            try:
                settings_xml = self._render("settings.xml")
            except FileNotFoundError:
                pass
            else:
                archive.writestr(
                    "settings.xml",
                    settings_xml,
                    compress_type=zipfile.ZIP_DEFLATED,
                )


class WriterTemplateEmitter(OdfBaseEmitter):
    """LibreOffice Writer template emitter (.ott).

    Generates ODF text document templates with:
    - Paragraph styles (Normal, Heading1-6, Quote)
    - Character styles (Hyperlinks)
    - Table styles with banding and accent variants
    - OpenType features (ligatures, stylistic sets, etc.)

    Inherits from OdfBaseEmitter (→ BaseEmitter).
    """

    MIMETYPE = "application/vnd.oasis.opendocument.text-template"

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: object | None = None,
        layout_families: list[object] | None = None,
        output_format: str | None = None,
        artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None = None,
    ) -> None:
        """Initialize Writer template emitter.

        Args:
            document: Document IR with style information
            template_root: Optional override for template resolution
            use_pure_text_colors: If True, use pure black/white for text
            enable_opentype_features: If True, enable OpenType features
        """
        super().__init__(
            document,
            template_root,
            format_key="writer",
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            style_resolver=style_resolver,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
            layout_families=layout_families,
            output_format=output_format,
            artifact_intent=artifact_intent,
        )

    def build_package(self) -> bytes:
        """Build the Writer template package."""
        buffer = io.BytesIO()
        title_text = f"{self.document.org_id} Narrative Template"
        body_style = self.document.body_style
        color_theme = self.document.color_theme
        body_text = (
            f"Our body copy uses {body_style.font_family} {body_style.font_size_pt:.1f}pt "
            f"in {body_style.color}, paired with accent {color_theme.accent1}."
        )
        # Prepare settings.xml context from document_settings
        ds = self.document.document_settings
        auto_hyph = "true" if ds.auto_hyphenation else "false"
        # Convert hyphenation zone from twips to hundredths of mm
        hyph_zone_hmm = int(ds.hyphenation_zone_twips * 25.4 / 1440 * 100)
        settings_context = {
            "AUTO_HYPHENATION": auto_hyph,
            "HYPHENATION_ZONE": str(hyph_zone_hmm),
        }

        with zipfile.ZipFile(
            buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            archive.writestr(
                "mimetype", self.MIMETYPE, compress_type=zipfile.ZIP_STORED
            )
            archive.writestr(
                "content.xml",
                self._render(
                    "content.xml",
                    context={
                        "TITLE": title_text,
                        "BODY": body_text,
                    },
                ),
            )
            styles_xml = WriterStylesEmitter(
                self.document,
                enable_opentype_features=self.enable_opentype_features,
            ).build_xml()
            archive.writestr(
                "styles.xml", styles_xml, compress_type=zipfile.ZIP_DEFLATED
            )
            # Write settings.xml with hyphenation context
            archive.writestr(
                "settings.xml",
                self._render("settings.xml", context=settings_context),
                compress_type=zipfile.ZIP_DEFLATED,
            )
            self._write_common_entries(archive, title=title_text)
        return buffer.getvalue()
