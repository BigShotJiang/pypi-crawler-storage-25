"""Layout, table, and extended typography helpers for Writer styles.

Free functions taking the concrete ``WriterStylesEmitter`` as their first
argument.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import lxml.etree as etree

from tokenmoulds.colors.parser import parse_color
from tokenmoulds.design.color_defaults import PURE_WHITE
from tokenmoulds.design.layout_defaults import (
    A4_HEIGHT_EMU,
    A4_WIDTH_EMU,
    DEFAULT_BASELINE_PT,
    table_cell_padding_pt,
    word_fallback_header_footer_twips,
)
from tokenmoulds.design.page_geometry import PageGeometry
from tokenmoulds.design.units import EMU_PER_POINT, twips_to_pt
from tokenmoulds.emitters.odf_helpers import (
    DEFAULT_TABLE_BORDER_COLOR,
    DEFAULT_TABLE_BORDER_WIDTH_PT,
    ODF_NSMAP,
    q,
)

if TYPE_CHECKING:
    from tokenmoulds.emitters.writer import WriterStylesEmitter

_LOEXT_NS = "urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0"
_DEFAULT_MARGIN_PT: float = 2.0 * 72.0 / 2.54
_FRAME_STROKE_WIDTH_PT: float = 0.57


def apply_table_styles(
    emitter: WriterStylesEmitter,
    style_index: dict[str, etree._Element],
) -> None:
    """Update table styles with IR-derived values."""
    font_family = emitter.document.body_style.font_family
    font_size_pt = emitter.document.body_style.font_size_pt
    text_color = emitter.document.body_style.color

    border_spec = (
        f"{DEFAULT_TABLE_BORDER_WIDTH_PT:.2f}pt solid {DEFAULT_TABLE_BORDER_COLOR}"
    )

    padding = table_cell_padding_pt()
    padding_left = f"{padding['left']:.2f}pt"
    padding_right = f"{padding['right']:.2f}pt"
    padding_top = f"{padding['top']:.2f}pt"
    padding_bottom = f"{padding['bottom']:.2f}pt"

    header_fill = emitter.document.color_theme.lt2
    body_fill = emitter.document.color_theme.lt1

    header_style = style_index.get("TableHeader")
    if header_style is not None:
        _apply_table_cell_props(
            header_style,
            font_family,
            font_size_pt,
            header_fill,
            text_color,
            border_spec,
            padding_left,
            padding_right,
            padding_top,
            padding_bottom,
            bold=True,
        )

    table_body_style = style_index.get("TableBody")
    if table_body_style is not None:
        _apply_table_cell_props(
            table_body_style,
            font_family,
            font_size_pt,
            body_fill,
            text_color,
            border_spec,
            padding_left,
            padding_right,
            padding_top,
            padding_bottom,
        )

    if emitter.document.color_palette:
        band1_variant = emitter.document.color_palette.get("Accent1.Tint60")
        band1_color = (
            band1_variant.hex
            if band1_variant
            else _apply_tint(emitter.document.color_theme.accent1, 60)
        )
    else:
        band1_color = _apply_tint(emitter.document.color_theme.accent1, 60)
    band1_style = style_index.get("TableBand1")
    if band1_style is not None:
        _apply_table_cell_props(
            band1_style,
            font_family,
            font_size_pt,
            band1_color,
            text_color,
            border_spec,
            padding_left,
            padding_right,
            padding_top,
            padding_bottom,
        )

    band2_style = style_index.get("TableBand2")
    if band2_style is not None:
        _apply_table_cell_props(
            band2_style,
            font_family,
            font_size_pt,
            body_fill,
            text_color,
            border_spec,
            padding_left,
            padding_right,
            padding_top,
            padding_bottom,
        )

    accent_colors = [
        emitter.document.color_theme.accent1,
        emitter.document.color_theme.accent2,
        emitter.document.color_theme.accent3,
        emitter.document.color_theme.accent4,
        emitter.document.color_theme.accent5,
        emitter.document.color_theme.accent6,
    ]

    for i, accent in enumerate(accent_colors, 1):
        accent_style = style_index.get(f"TableAccent{i}Header")
        if accent_style is not None:
            _apply_table_cell_props(
                accent_style,
                font_family,
                font_size_pt,
                accent,
                PURE_WHITE,
                border_spec,
                padding_left,
                padding_right,
                padding_top,
                padding_bottom,
                bold=True,
            )


def _apply_table_cell_props(
    style: etree._Element,
    font_family: str,
    font_size_pt: float,
    bg_color: str,
    text_color: str,
    border_spec: str,
    padding_left: str,
    padding_right: str,
    padding_top: str,
    padding_bottom: str,
    bold: bool = False,
) -> None:
    """Apply table cell properties to a style element."""
    cell_props = style.find(q("style", "table-cell-properties"))
    if cell_props is not None:
        if bg_color.startswith("#"):
            cell_props.set(q("fo", "background-color"), bg_color)
        cell_props.set(q("fo", "border"), border_spec)
        cell_props.set(q("fo", "padding-left"), padding_left)
        cell_props.set(q("fo", "padding-right"), padding_right)
        cell_props.set(q("fo", "padding-top"), padding_top)
        cell_props.set(q("fo", "padding-bottom"), padding_bottom)

    text_props = style.find(q("style", "text-properties"))
    if text_props is not None:
        text_props.set(q("fo", "font-family"), font_family)
        text_props.set(q("fo", "font-size"), f"{font_size_pt:.1f}pt")
        if text_color.startswith("#"):
            text_props.set(q("fo", "color"), text_color)
        if bold:
            text_props.set(q("fo", "font-weight"), "bold")


def _apply_tint(hex_color: str, tint_percent: int) -> str:
    """Apply a tint (lighten) to a hex color using OKLab perceptual color space."""
    color = parse_color(hex_color)
    if color is None:
        return hex_color

    lightness_delta = (tint_percent / 100.0) * 0.5
    tinted = color.lighten(lightness_delta)
    return tinted.to_hex()


def apply_page_geometry(emitter: WriterStylesEmitter, root: etree._Element) -> None:
    """Apply page size, margins, orientation, and header/footer from IR."""
    page_layout = root.find(".//style:page-layout[@style:name='pm1']", ODF_NSMAP)
    if page_layout is None:
        return

    props = page_layout.find("style:page-layout-properties", ODF_NSMAP)
    if props is None:
        return

    sections = emitter.document.sections

    if sections:
        first_geom = sections[0].page_geometry or emitter.document.page_geometry
        _set_page_layout_props(props, first_geom)

        auto_styles = root.find("office:automatic-styles", ODF_NSMAP)
        master_styles = root.find("office:master-styles", ODF_NSMAP)
        if auto_styles is not None and master_styles is not None:
            for i, section in enumerate(sections[1:], 2):
                sec_geom = section.page_geometry or emitter.document.page_geometry
                layout_name = f"pm{i}"
                master_name = f"Section{i}"

                new_layout = etree.SubElement(auto_styles, q("style", "page-layout"))
                new_layout.set(q("style", "name"), layout_name)
                new_props = etree.SubElement(
                    new_layout, q("style", "page-layout-properties")
                )
                _set_page_layout_props(new_props, sec_geom)

                new_master = etree.SubElement(master_styles, q("style", "master-page"))
                new_master.set(q("style", "name"), master_name)
                new_master.set(q("style", "page-layout-name"), layout_name)
    else:
        _set_page_layout_props(props, emitter.document.page_geometry)

    master_page = root.find(".//style:master-page[@style:name='Standard']", ODF_NSMAP)
    if master_page is not None:
        header = master_page.find(q("style", "header"))
        if header is None:
            header = etree.SubElement(master_page, q("style", "header"))
            header_p = etree.SubElement(header, q("text", "p"))
            header_p.text = emitter.document.org_id

        footer = master_page.find(q("style", "footer"))
        if footer is None:
            footer = etree.SubElement(master_page, q("style", "footer"))
            footer_p = etree.SubElement(footer, q("text", "p"))
            page_num = etree.SubElement(footer_p, q("text", "page-number"))
            page_num.text = "1"


def _set_page_layout_props(
    props: etree._Element,
    geom: object | None,
) -> None:
    """Set page-layout-properties attributes from a PageGeometry."""
    if isinstance(geom, PageGeometry):
        w_pt = geom.width_emu / EMU_PER_POINT
        h_pt = geom.height_emu / EMU_PER_POINT
        mt_pt = geom.margins.top / EMU_PER_POINT
        mb_pt = geom.margins.bottom / EMU_PER_POINT
        ml_pt = geom.margins.left / EMU_PER_POINT
        mr_pt = geom.margins.right / EMU_PER_POINT
        orient = "landscape" if geom.is_landscape else "portrait"
    else:
        w_pt = A4_WIDTH_EMU / EMU_PER_POINT
        h_pt = A4_HEIGHT_EMU / EMU_PER_POINT
        mt_pt = mb_pt = ml_pt = mr_pt = _DEFAULT_MARGIN_PT
        orient = "portrait"

    hf_pt = twips_to_pt(word_fallback_header_footer_twips(DEFAULT_BASELINE_PT))

    props.set(q("fo", "page-width"), f"{w_pt:.2f}pt")
    props.set(q("fo", "page-height"), f"{h_pt:.2f}pt")
    props.set(q("style", "print-orientation"), orient)
    props.set(q("fo", "margin-top"), f"{mt_pt:.2f}pt")
    props.set(q("fo", "margin-bottom"), f"{mb_pt:.2f}pt")
    props.set(q("fo", "margin-left"), f"{ml_pt:.2f}pt")
    props.set(q("fo", "margin-right"), f"{mr_pt:.2f}pt")
    props.set(q("style", "header-height"), f"{hf_pt:.2f}pt")
    props.set(q("style", "footer-height"), f"{hf_pt:.2f}pt")


def remove_opentype_features(root: etree._Element) -> None:
    """Remove style:font-feature-settings attributes for older LibreOffice."""
    font_feature_attr = q("style", "font-feature-settings")
    for text_props in root.iter(q("style", "text-properties")):
        if font_feature_attr in text_props.attrib:
            del text_props.attrib[font_feature_attr]


def apply_text_direction(
    emitter: WriterStylesEmitter,
    style_index: dict[str, etree._Element],
) -> None:
    """Apply RTL/LTR writing mode based on locale settings."""
    if not emitter.document.locale_settings.rtl:
        return

    writing_mode = "rl-tb"

    style_names = ["Standard", "Text_20_body"] + [
        f"Heading_20_{h.level}" for h in emitter.document.heading_styles
    ]

    for style_name in style_names:
        style = style_index.get(style_name)
        if style is None:
            continue

        para_props = style.find(q("style", "paragraph-properties"))
        if para_props is not None:
            para_props.set(q("style", "writing-mode"), writing_mode)


def apply_text_alignment(
    emitter: WriterStylesEmitter,
    style_index: dict[str, etree._Element],
) -> None:
    """Apply text alignment from Document IR (l/r/ctr/just → ODF)."""
    alignment_map = {
        "l": "start",
        "r": "end",
        "ctr": "center",
        "just": "justify",
    }

    text_align = emitter.document.text_alignment
    body_align = alignment_map.get(text_align.body_horizontal, "start")

    for style_name in ("Standard", "Text_20_body"):
        style = style_index.get(style_name)
        if style is None:
            continue

        para_props = style.find(q("style", "paragraph-properties"))
        if para_props is not None:
            para_props.set(q("fo", "text-align"), body_align)


def apply_letter_spacing(
    emitter: WriterStylesEmitter,
    style_index: dict[str, etree._Element],
) -> None:
    """Apply letter spacing (tracking) from Document IR."""
    tracking = emitter.document.tracking
    body_font_size = emitter.document.body_style.font_size_pt

    body_spacing_pt = (tracking.body / 100.0) * body_font_size
    heading_spacing_pt = (tracking.heading / 100.0) * body_font_size

    if abs(body_spacing_pt) > 0.01:
        for style_name in ("Standard", "Text_20_body"):
            style = style_index.get(style_name)
            if style is None:
                continue

            text_props = style.find(q("style", "text-properties"))
            if text_props is not None:
                text_props.set(q("fo", "letter-spacing"), f"{body_spacing_pt:.2f}pt")

    if abs(heading_spacing_pt) > 0.01:
        for heading in emitter.document.heading_styles:
            style_name = f"Heading_20_{heading.level}"
            style = style_index.get(style_name)
            if style is None:
                continue

            text_props = style.find(q("style", "text-properties"))
            if text_props is not None:
                text_props.set(q("fo", "letter-spacing"), f"{heading_spacing_pt:.2f}pt")
