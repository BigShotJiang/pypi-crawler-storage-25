"""ODF template emitter public API."""

from __future__ import annotations

from tokenmoulds.emitters.odf_base import OdfBaseEmitter, WriterTemplateEmitter
from tokenmoulds.emitters.odf_draw import DrawTemplateEmitter
from tokenmoulds.emitters.odf_presentation import ImpressTemplateEmitter
from tokenmoulds.emitters.odf_spreadsheet import CalcTemplateEmitter

__all__ = [
    "CalcTemplateEmitter",
    "DrawTemplateEmitter",
    "ImpressTemplateEmitter",
    "OdfBaseEmitter",
    "WriterTemplateEmitter",
]
