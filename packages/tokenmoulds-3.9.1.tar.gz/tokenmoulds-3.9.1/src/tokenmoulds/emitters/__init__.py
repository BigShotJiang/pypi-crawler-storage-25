"""Public API for document emitters.

This package-level module exposes stable emitter entry points while keeping
implementation modules lazily imported to avoid unnecessary import-time
side effects across layers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from tokenmoulds._lazy import lazy_dir, resolve_lazy_attribute

if TYPE_CHECKING:
    from tokenmoulds.emitters.excel import ExcelEmitter
    from tokenmoulds.emitters.google_docs import (
        GoogleDocsDocumentEmitter,
        GoogleDocsEmitter,
    )
    from tokenmoulds.emitters.odf import (
        CalcTemplateEmitter,
        DrawTemplateEmitter,
        ImpressTemplateEmitter,
        WriterTemplateEmitter,
    )
    from tokenmoulds.emitters.powerpoint import PowerPointEmitter
    from tokenmoulds.emitters.template_loader import TemplateResolver
    from tokenmoulds.emitters.word import WordDocumentEmitter
    from tokenmoulds.emitters.writer import WriterStylesEmitter


__all__ = [
    "TemplateResolver",
    "WordDocumentEmitter",
    "PowerPointEmitter",
    "ExcelEmitter",
    "WriterStylesEmitter",
    "WriterTemplateEmitter",
    "ImpressTemplateEmitter",
    "CalcTemplateEmitter",
    "DrawTemplateEmitter",
    "GoogleDocsEmitter",
    "GoogleDocsDocumentEmitter",
]


_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "TemplateResolver": (".template_loader", "TemplateResolver"),
    "WordDocumentEmitter": (".word", "WordDocumentEmitter"),
    "PowerPointEmitter": (".powerpoint", "PowerPointEmitter"),
    "ExcelEmitter": (".excel", "ExcelEmitter"),
    "WriterStylesEmitter": (".writer", "WriterStylesEmitter"),
    "WriterTemplateEmitter": (".odf", "WriterTemplateEmitter"),
    "ImpressTemplateEmitter": (".odf", "ImpressTemplateEmitter"),
    "CalcTemplateEmitter": (".odf", "CalcTemplateEmitter"),
    "DrawTemplateEmitter": (".odf", "DrawTemplateEmitter"),
    "GoogleDocsEmitter": (".google_docs", "GoogleDocsEmitter"),
    "GoogleDocsDocumentEmitter": (".google_docs", "GoogleDocsDocumentEmitter"),
}


def __getattr__(name: str) -> Any:
    return resolve_lazy_attribute(
        name,
        module_globals=globals(),
        package=__package__ or __name__,
        lazy_imports=_LAZY_IMPORTS,
    )


def __dir__() -> list[str]:
    return lazy_dir(globals(), __all__)
