"""Stateless shape DOM helpers for PresentationML emitters.

Pure XML transforms with zero IR dependency.  All functions operate on
``lxml.etree`` elements using the DrawingML (``a:``) and PresentationML
(``p:``) namespaces.
"""

from __future__ import annotations

import lxml.etree as etree

from tokenmoulds.emitters.ooxml_base import A_NS

PRESENTATIONML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"


# ---------------------------------------------------------------------------
# Single-shape helpers
# ---------------------------------------------------------------------------


def append_no_outline(sp_pr: etree._Element) -> None:
    """Append an explicit no-outline line definition to a shape."""
    line = sp_pr.find(f"{{{A_NS}}}ln")
    if line is None:
        line = etree.SubElement(sp_pr, f"{{{A_NS}}}ln")
    for child in list(line):
        line.remove(child)
    etree.SubElement(line, f"{{{A_NS}}}noFill")


def read_shape_rect(shape: etree._Element) -> tuple[int, int, int, int] | None:
    """Return the shape transform rectangle from ``a:xfrm`` if present."""
    xfrm = shape.find(f".//{{{A_NS}}}xfrm")
    if xfrm is None:
        return None
    off = xfrm.find(f"{{{A_NS}}}off")
    ext = xfrm.find(f"{{{A_NS}}}ext")
    if off is None or ext is None:
        return None
    return (
        int(off.get("x", "0")),
        int(off.get("y", "0")),
        int(ext.get("cx", "0")),
        int(ext.get("cy", "0")),
    )


def set_shape_rect(
    shape: etree._Element,
    rect: tuple[int, int, int, int],
) -> None:
    """Overwrite a shape transform with the supplied rectangle."""
    x, y, cx, cy = rect
    sp_pr = shape.find(f"{{{PRESENTATIONML_NS}}}spPr")
    if sp_pr is None:
        sp_pr = etree.SubElement(shape, f"{{{PRESENTATIONML_NS}}}spPr")
    xfrm = sp_pr.find(f"{{{A_NS}}}xfrm")
    if xfrm is None:
        xfrm = etree.SubElement(sp_pr, f"{{{A_NS}}}xfrm")
    off = xfrm.find(f"{{{A_NS}}}off")
    if off is None:
        off = etree.SubElement(xfrm, f"{{{A_NS}}}off")
    ext = xfrm.find(f"{{{A_NS}}}ext")
    if ext is None:
        ext = etree.SubElement(xfrm, f"{{{A_NS}}}ext")
    off.set("x", str(x))
    off.set("y", str(y))
    ext.set("cx", str(cx))
    ext.set("cy", str(cy))


def find_shape_by_placeholder(
    root: etree._Element,
    *,
    ph_type: str | None,
    ph_idx: str | None,
) -> etree._Element | None:
    """Find a shape by its placeholder type/index binding."""
    conditions = []
    if ph_type is None:
        conditions.append("not(@type)")
    else:
        conditions.append(f"@type='{ph_type}'")
    if ph_idx is None:
        conditions.append("not(@idx)")
    else:
        conditions.append(f"@idx='{ph_idx}'")
    matches = root.xpath(
        f".//p:sp[p:nvSpPr/p:nvPr/p:ph[{' and '.join(conditions)}]]",
        namespaces={"p": PRESENTATIONML_NS},
    )
    return matches[0] if matches else None  # type: ignore[return-value]


def next_nonvisual_id(root: etree._Element) -> int:
    """Return the next available non-visual drawing id in the slide tree."""
    max_id = 1
    for c_nv_pr in root.findall(f".//{{{PRESENTATIONML_NS}}}cNvPr"):
        try:
            max_id = max(max_id, int(c_nv_pr.get("id", "1")))
        except ValueError:
            continue
    return max_id + 1


# ---------------------------------------------------------------------------
# Group-shape helpers
# ---------------------------------------------------------------------------


def shape_bounds_in_group(
    group_shape: etree._Element,
) -> tuple[int, int, int, int] | None:
    """Compute illustration bounds from embedded child shape transforms."""
    bounds: tuple[int, int, int, int] | None = None
    for xfrm in group_shape.findall(
        f"./{{{PRESENTATIONML_NS}}}sp/{{{PRESENTATIONML_NS}}}spPr/{{{A_NS}}}xfrm"
    ):
        off = xfrm.find(f"{{{A_NS}}}off")
        ext = xfrm.find(f"{{{A_NS}}}ext")
        if off is None or ext is None:
            continue
        left = int(off.get("x", "0"))
        top = int(off.get("y", "0"))
        right = left + int(ext.get("cx", "0"))
        bottom = top + int(ext.get("cy", "0"))
        if bounds is None:
            bounds = (left, top, right, bottom)
        else:
            bounds = (
                min(bounds[0], left),
                min(bounds[1], top),
                max(bounds[2], right),
                max(bounds[3], bottom),
            )
    return bounds


def set_group_rect(
    group_shape: etree._Element,
    *,
    target_rect: tuple[int, int, int, int],
    source_bounds: tuple[int, int, int, int] | None,
) -> None:
    """Set the group transform so embedded illustration shapes scale to the target."""
    grp_sp_pr = group_shape.find(f"{{{PRESENTATIONML_NS}}}grpSpPr")
    if grp_sp_pr is None:
        grp_sp_pr = etree.SubElement(group_shape, f"{{{PRESENTATIONML_NS}}}grpSpPr")
    xfrm = grp_sp_pr.find(f"{{{A_NS}}}xfrm")
    if xfrm is None:
        xfrm = etree.SubElement(grp_sp_pr, f"{{{A_NS}}}xfrm")
    children = {child.tag.rsplit("}", 1)[-1]: child for child in xfrm}
    off = children.get("off")
    if off is None:
        off = etree.SubElement(xfrm, f"{{{A_NS}}}off")
    ext = children.get("ext")
    if ext is None:
        ext = etree.SubElement(xfrm, f"{{{A_NS}}}ext")
    ch_off = children.get("chOff")
    if ch_off is None:
        ch_off = etree.SubElement(xfrm, f"{{{A_NS}}}chOff")
    ch_ext = children.get("chExt")
    if ch_ext is None:
        ch_ext = etree.SubElement(xfrm, f"{{{A_NS}}}chExt")

    x, y, cx, cy = target_rect
    off.set("x", str(x))
    off.set("y", str(y))
    ext.set("cx", str(cx))
    ext.set("cy", str(cy))

    if source_bounds is None:
        src_x = src_y = 0
        src_cx, src_cy = cx, cy
    else:
        src_x, src_y, src_right, src_bottom = source_bounds
        src_cx = max(1, src_right - src_x)
        src_cy = max(1, src_bottom - src_y)
    ch_off.set("x", str(src_x))
    ch_off.set("y", str(src_y))
    ch_ext.set("cx", str(src_cx))
    ch_ext.set("cy", str(src_cy))


def assign_group_shape_ids(
    root: etree._Element, group_shape: etree._Element, *, base_name: str
) -> None:
    """Assign unique ``p:cNvPr`` ids to an inserted illustration group."""
    nid = next_nonvisual_id(root)
    for index, c_nv_pr in enumerate(
        group_shape.findall(f".//{{{PRESENTATIONML_NS}}}cNvPr")
    ):
        c_nv_pr.set("id", str(nid + index))
        if index == 0:
            c_nv_pr.set("name", base_name)
        elif not c_nv_pr.get("name"):
            c_nv_pr.set("name", f"{base_name} {index}")
