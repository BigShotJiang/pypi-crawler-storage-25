"""Media asset resolution helpers for the PowerPoint emitter.

Free functions taking the concrete ``PowerPointEmitter`` as their first
argument. State (``_base_decoration``, ``_slide_media_assets``,
``_slide_media_relationships``) lives on the emitter; ``init_media`` is
called from ``PowerPointEmitter.__init__``.
"""

from __future__ import annotations

import logging
from copy import deepcopy
from typing import TYPE_CHECKING

from tokenmoulds.emitters.pptx_master import _seed_layout_name
from tokenmoulds.packaging import MediaAsset

if TYPE_CHECKING:
    from tokenmoulds.emitters.powerpoint import PowerPointEmitter
    from tokenmoulds.ir import SemanticSlideDecoration

logger = logging.getLogger(__name__)


def init_media(emitter: PowerPointEmitter, decoration: SemanticSlideDecoration) -> None:
    """Initialise media state — call from ``PowerPointEmitter.__init__``."""
    emitter._base_decoration = deepcopy(decoration)
    emitter._slide_media_assets = []
    emitter._slide_media_relationships = []


def prepare_semantic_media_assets(emitter: PowerPointEmitter) -> None:
    """Resolve photo and illustration assets for the selected semantic slide."""
    layout = emitter.document.presentation_layout
    layout.decoration = deepcopy(emitter._base_decoration)
    emitter._slide_media_assets = []
    emitter._slide_media_relationships = []

    prepared: dict[str, dict[str, object]] = {}
    for region_name, fill_tokens in layout.decoration.decorative_fills.items():
        prepared[region_name] = _prepare_fill_asset(emitter, region_name, fill_tokens)

    layout.decoration.decorative_fills = prepared
    layout.decoration.background_fill = prepared.get("background")
    layout.decoration.overlay_fill = prepared.get("overlay")


def _prepare_fill_asset(
    emitter: PowerPointEmitter,
    region_name: str,
    fill_tokens: dict[str, object],
) -> dict[str, object]:
    """Resolve emitter-side assets required by a semantic decorative fill."""
    prepared = deepcopy(fill_tokens)
    fill_type = str(prepared.get("type", ""))

    if fill_type == "photo" and not prepared.get("relationship_id"):
        from tokenmoulds.media.pexels import (
            PexelsUnavailableError,
            download_photo,
            search_photos,
        )

        try:
            image_url = prepared.get("url")
            if not image_url:
                query = str(prepared.get("query", "")).strip()
                if not query:
                    raise PexelsUnavailableError("photo fill is missing a query")
                color = prepared.get("color")
                results = search_photos(
                    query,
                    color=str(color) if isinstance(color, str) else None,
                    orientation=str(prepared.get("orientation", "landscape")),
                    per_page=1,
                )
                if not results:
                    raise PexelsUnavailableError(
                        f"no photo results for query {query!r}"
                    )
                image_url = results[0].url
            image_bytes = download_photo(
                str(image_url),
                preset=str(prepared.get("preset", "presentation_bg")),
            )
            prepared["relationship_id"] = _register_slide_media_asset(
                emitter,
                region_name=region_name,
                data=image_bytes,
                extension="jpg",
                content_type="image/jpeg",
            )
        except Exception as exc:
            logger.warning(
                "Failed to resolve photo fill for %s on %s: %s",
                region_name,
                _seed_layout_name(emitter),
                exc,
            )

    if fill_type == "illustration" and not prepared.get("shape_xml"):
        from tokenmoulds.media.undraw import (
            IllustrationUnavailableError,
            fetch_illustration,
        )

        try:
            name = str(prepared.get("name", "")).strip()
            if not name:
                raise IllustrationUnavailableError(
                    "illustration fill is missing a name"
                )
            color_map = prepared.get("color_map")
            theme_color = prepared.get("color")
            prepared["shape_xml"] = fetch_illustration(
                name,
                theme_color=(
                    str(theme_color)
                    if isinstance(theme_color, str)
                    and not str(theme_color).startswith("#")
                    else "accent1"
                ),
                color_map=color_map if isinstance(color_map, dict) else None,
            )
        except Exception as exc:
            logger.warning(
                "Failed to resolve illustration fill for %s on %s: %s",
                region_name,
                _seed_layout_name(emitter),
                exc,
            )

    return prepared


def _register_slide_media_asset(
    emitter: PowerPointEmitter,
    *,
    region_name: str,
    data: bytes,
    extension: str,
    content_type: str,
) -> str:
    """Register a media asset and return the slide relationship id."""
    asset_index = len(emitter._slide_media_assets) + 1
    archive_path = f"ppt/media/{region_name}_{asset_index}.{extension}"
    relationship_id = f"rId{len(emitter._slide_media_relationships) + 2}"
    emitter._slide_media_assets.append(
        MediaAsset(
            archive_path=archive_path,
            data=data,
            content_type=content_type,
            source=region_name,
        )
    )
    emitter._slide_media_relationships.append((relationship_id, archive_path))
    return relationship_id
