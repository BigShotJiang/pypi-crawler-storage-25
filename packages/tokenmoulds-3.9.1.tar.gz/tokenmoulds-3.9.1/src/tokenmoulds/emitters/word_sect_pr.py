"""Pure builder for WordprocessingML ``w:sectPr`` from LongFormSection.

This is a standalone helper so that the logic is unit-testable without
instantiating the full Word emitter.  The free functions in
``tokenmoulds.emitters.word_sections`` delegate here.

ECMA-376 Part 1, Section 17.6.17 defines the ``CT_SectPr`` sequence.  The
children used by long-form sections, in the required order:

1. ``w:headerReference``  (any, type default/even/first)
2. ``w:footerReference``  (any, type default/even/first)
3. ``w:pgSz``
4. ``w:pgMar``
5. ``w:pgNumType``         (omitted when restart_at == "continue")
6. ``w:cols``              (omitted for single-column layouts)
7. ``w:titlePg``           (emitted when first_page_different)
8. ``w:docGrid``           (optional; not yet emitted here)
"""

from __future__ import annotations

from typing import Literal, Mapping

import lxml.etree as etree

from tokenmoulds.design.units.conversion import pt_to_twips
from tokenmoulds.emitters.word_shared import NSMAP, R, W
from tokenmoulds.ir.long_form import HeaderFooterConfig, LongFormSection

_REF_TYPE = Literal["default", "even", "first"]


def _refs_for(
    section: LongFormSection,
    *,
    base: HeaderFooterConfig | None,
    odd: HeaderFooterConfig | None,
    even: HeaderFooterConfig | None,
    first: HeaderFooterConfig | None,
) -> list[tuple[_REF_TYPE, HeaderFooterConfig]]:
    """Return (type, config) pairs in ECMA order.

    ``default`` is used both for single-ref sections and as the odd-page
    ref when ``odd_even_different`` is True.
    """
    refs: list[tuple[_REF_TYPE, HeaderFooterConfig]] = []
    default_cfg = base or odd
    if default_cfg is not None:
        refs.append(("default", default_cfg))
    if section.odd_even_different and even is not None:
        refs.append(("even", even))
    if section.first_page_different and first is not None:
        refs.append(("first", first))
    return refs


def _append_reference(
    parent: etree._Element,
    kind: Literal["header", "footer"],
    ref_type: _REF_TYPE,
    rid: str,
) -> None:
    el = etree.SubElement(parent, f"{W}{kind}Reference")
    el.set(f"{W}type", ref_type)
    el.set(f"{R}id", rid)


def _ensure_even_fallback(
    refs: list[tuple[_REF_TYPE, HeaderFooterConfig]],
    *,
    active: bool,
) -> list[tuple[_REF_TYPE, HeaderFooterConfig]]:
    """Auto-emit an ``even`` ref mirroring ``default`` when needed.

    Without this, a section that only declares a ``default`` ref inside
    a document that has ``<w:evenAndOddHeaders/>`` enabled silently
    loses its header/footer on every even page — Word and Writer look
    for ``type="even"`` first and do NOT fall back to default when the
    document is in odd/even mode.  Every section must supply both
    variants.
    """
    if not active:
        return refs
    default_cfg: HeaderFooterConfig | None = None
    has_even = False
    for ref_type, cfg in refs:
        if ref_type == "default" and default_cfg is None:
            default_cfg = cfg
        elif ref_type == "even":
            has_even = True
    if default_cfg is not None and not has_even:
        return [*refs, ("even", default_cfg)]
    return refs


def build_sect_pr(
    section: LongFormSection,
    *,
    header_rid_map: Mapping[str, str],
    footer_rid_map: Mapping[str, str],
    document_has_odd_even: bool = False,
) -> etree._Element:
    """Build a ``w:sectPr`` element for a resolved :class:`LongFormSection`.

    The rId maps translate header/footer config names to the relationship
    ids assigned by the caller (the Word emitter tracks rId allocation
    across the document).

    ``document_has_odd_even`` signals that ``<w:evenAndOddHeaders/>`` is
    set in settings.xml — Word and Writer then both require every
    section that has a ``default`` header/footer reference to also
    supply an ``even`` variant, otherwise the footer silently fails to
    render on even pages.  When the flag is True and this section has
    a default ref but no explicit even ref, we auto-emit an even ref
    pointing at the same rId as the default.
    """
    sect_pr = etree.Element(f"{W}sectPr", nsmap=NSMAP)

    header_refs = _refs_for(
        section,
        base=section.header_ref,
        odd=section.header_ref_odd,
        even=section.header_ref_even,
        first=section.header_ref_first,
    )
    header_refs = _ensure_even_fallback(header_refs, active=document_has_odd_even)
    for ref_type, cfg in header_refs:
        _append_reference(sect_pr, "header", ref_type, header_rid_map[cfg.name])

    footer_refs = _refs_for(
        section,
        base=section.footer_ref,
        odd=section.footer_ref_odd,
        even=section.footer_ref_even,
        first=section.footer_ref_first,
    )
    footer_refs = _ensure_even_fallback(footer_refs, active=document_has_odd_even)
    for ref_type, cfg in footer_refs:
        _append_reference(sect_pr, "footer", ref_type, footer_rid_map[cfg.name])

    geom = section.page_geometry
    pg_sz = etree.SubElement(sect_pr, f"{W}pgSz")
    pg_sz.set(f"{W}w", str(pt_to_twips(geom.width_pt)))
    pg_sz.set(f"{W}h", str(pt_to_twips(geom.height_pt)))
    pg_sz.set(f"{W}orient", geom.orientation)

    margins = section.margins
    pg_mar = etree.SubElement(sect_pr, f"{W}pgMar")
    pg_mar.set(f"{W}top", str(pt_to_twips(margins.top_pt)))
    pg_mar.set(f"{W}bottom", str(pt_to_twips(margins.bottom_pt)))
    pg_mar.set(f"{W}left", str(pt_to_twips(margins.resolve_left())))
    pg_mar.set(f"{W}right", str(pt_to_twips(margins.resolve_right())))
    # header/footer distance: half the top margin or a 360-twip floor,
    # whichever is larger — gives tight margins enough breathing room.
    hf = max(pt_to_twips(margins.top_pt) // 2, 360)
    pg_mar.set(f"{W}header", str(hf))
    pg_mar.set(f"{W}footer", str(hf))
    pg_mar.set(f"{W}gutter", str(pt_to_twips(margins.gutter_pt)))

    pn = section.page_number
    if pn.restart_at != "continue":
        assert isinstance(pn.restart_at, int)
        pg_num = etree.SubElement(sect_pr, f"{W}pgNumType")
        pg_num.set(f"{W}fmt", pn.format)
        pg_num.set(f"{W}start", str(pn.restart_at))

    if section.columns > 1:
        cols = etree.SubElement(sect_pr, f"{W}cols")
        cols.set(f"{W}num", str(section.columns))
        cols.set(f"{W}space", str(pt_to_twips(section.column_gap_pt)))
        cols.set(f"{W}equalWidth", "1")

    if section.first_page_different:
        etree.SubElement(sect_pr, f"{W}titlePg")

    # docGrid intentionally omitted — not yet wired to LongFormSection.

    return sect_pr
