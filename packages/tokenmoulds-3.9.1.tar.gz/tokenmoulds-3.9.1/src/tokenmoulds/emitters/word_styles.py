"""Style customization helpers for the Word document emitter.

Free functions taking the concrete ``WordDocumentEmitter`` as their first
argument.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import lxml.etree as etree

from tokenmoulds.design.style_recipes import TableStyleRecipe
from tokenmoulds.emitters.word_shared import NSMAP, W
from tokenmoulds.emitters.word_style_typography import (
    apply_opentype_features,
    apply_paragraph_properties,
    apply_run_properties,
)
from tokenmoulds.emitters.word_tables import generate_table_style
from tokenmoulds.styles.resolver import ResolvedStyle
from tokenmoulds.styles.word_builtin import BUILTIN_STYLES, StyleCategory, StyleType

if TYPE_CHECKING:
    from tokenmoulds.emitters.word import WordDocumentEmitter


def customize_styles(emitter: WordDocumentEmitter, data: bytes) -> bytes:
    """Customize styles.xml with Document IR values."""
    root = etree.fromstring(data)

    _update_doc_defaults_ssot(emitter, root)

    _update_style_ssot(root, "Normal", emitter.document.body_style)
    _update_style_ssot(root, "BodyText", emitter.document.body_style)

    for heading in emitter.document.heading_styles:
        style_id = f"Heading{heading.level}"
        _update_style_ssot(root, style_id, heading)
        _update_style_ssot(root, f"{style_id}Char", heading)

    _update_style_ssot(root, "Quote", emitter.document.quote_style)

    _update_hyperlink_style_ssot(emitter, root)

    _update_base_styles_ssot(emitter, root)

    _add_table_styles_ssot(emitter, root)

    _add_missing_builtin_styles(root)

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def _update_doc_defaults_ssot(
    emitter: WordDocumentEmitter, root: etree._Element
) -> None:
    """Update docDefaults with body font settings."""
    doc_defaults = root.find(".//w:docDefaults", NSMAP)
    if doc_defaults is None:
        return

    rpr = doc_defaults.find(".//w:rPrDefault/w:rPr", NSMAP)
    if rpr is not None:
        rfonts = rpr.find("w:rFonts", NSMAP)
        if rfonts is not None:
            font = emitter.document.body_style.font_family
            rfonts.set(f"{W}ascii", font)
            rfonts.set(f"{W}hAnsi", font)
            rfonts.set(f"{W}eastAsia", font)
            rfonts.set(f"{W}cs", font)

        sz = rpr.find("w:sz", NSMAP)
        if sz is not None:
            sz.set(f"{W}val", str(int(emitter.document.body_style.font_size_pt * 2)))
        szCs = rpr.find("w:szCs", NSMAP)
        if szCs is not None:
            szCs.set(f"{W}val", str(int(emitter.document.body_style.font_size_pt * 2)))


def _update_style_ssot(root: etree._Element, style_id: str, style_data) -> None:
    """Update a style with Document IR values."""
    style_el = root.find(f'.//w:style[@w:styleId="{style_id}"]', NSMAP)
    if style_el is None:
        return

    rpr = style_el.find("w:rPr", NSMAP)
    if rpr is not None:
        _update_rpr_ssot(rpr, style_data)

    ppr = style_el.find("w:pPr", NSMAP)
    if ppr is not None:
        _update_ppr_ssot(ppr, style_data)


def _update_rpr_ssot(rpr: etree._Element, style_data) -> None:
    """Update run properties with style data."""
    rfonts = rpr.find("w:rFonts", NSMAP)
    if rfonts is not None:
        font = style_data.font_family
        rfonts.set(f"{W}ascii", font)
        rfonts.set(f"{W}hAnsi", font)
        if rfonts.get(f"{W}eastAsia") is not None:
            rfonts.set(f"{W}eastAsia", font)
        if rfonts.get(f"{W}cs") is not None:
            rfonts.set(f"{W}cs", font)

    sz = rpr.find("w:sz", NSMAP)
    if sz is not None:
        sz.set(f"{W}val", str(int(style_data.font_size_pt * 2)))
    szCs = rpr.find("w:szCs", NSMAP)
    if szCs is not None:
        szCs.set(f"{W}val", str(int(style_data.font_size_pt * 2)))

    color = rpr.find("w:color", NSMAP)
    if color is not None:
        color.set(f"{W}val", style_data.color.lstrip("#").upper())


def _update_ppr_ssot(ppr: etree._Element, style_data) -> None:
    """Update paragraph properties with style data."""
    spacing = ppr.find("w:spacing", NSMAP)
    if spacing is not None and hasattr(style_data, "spacing"):
        spacing.set(f"{W}before", str(style_data.spacing.before_twips))
        spacing.set(f"{W}after", str(style_data.spacing.after_twips))


def _update_hyperlink_style_ssot(
    emitter: WordDocumentEmitter, root: etree._Element
) -> None:
    """Update Hyperlink styles with Document IR colors."""
    hyperlink = root.find('.//w:style[@w:styleId="Hyperlink"]', NSMAP)
    if hyperlink is not None:
        rpr = hyperlink.find("w:rPr", NSMAP)
        if rpr is not None:
            color = rpr.find("w:color", NSMAP)
            if color is not None:
                color.set(
                    f"{W}val",
                    emitter.document.hyperlink_style.link_color.lstrip("#").upper(),
                )

    followed = root.find('.//w:style[@w:styleId="FollowedHyperlink"]', NSMAP)
    if followed is not None:
        rpr = followed.find("w:rPr", NSMAP)
        if rpr is not None:
            color = rpr.find("w:color", NSMAP)
            if color is not None:
                color.set(
                    f"{W}val",
                    emitter.document.hyperlink_style.visited_color.lstrip("#").upper(),
                )


def _update_base_styles_ssot(
    emitter: WordDocumentEmitter, root: etree._Element
) -> None:
    """Update TokenMoulds base styles with Document IR values."""
    body_base = root.find('.//w:style[@w:styleId="TMBodyBase"]', NSMAP)
    if body_base is not None:
        rpr = body_base.find("w:rPr", NSMAP)
        if rpr is not None:
            _update_rpr_ssot(rpr, emitter.document.body_style)
        ppr = body_base.find("w:pPr", NSMAP)
        if ppr is not None:
            _update_ppr_ssot(ppr, emitter.document.body_style)

    heading_base = root.find('.//w:style[@w:styleId="TMHeadingBase"]', NSMAP)
    if heading_base is not None:
        rpr = heading_base.find("w:rPr", NSMAP)
        if rpr is not None:
            rfonts = rpr.find("w:rFonts", NSMAP)
            if rfonts is not None:
                font = emitter.document.typography.heading_font
                rfonts.set(f"{W}ascii", font)
                rfonts.set(f"{W}hAnsi", font)
                if rfonts.get(f"{W}eastAsia") is not None:
                    rfonts.set(f"{W}eastAsia", font)
                if rfonts.get(f"{W}cs") is not None:
                    rfonts.set(f"{W}cs", font)
            color = rpr.find("w:color", NSMAP)
            if color is not None and emitter.document.heading_styles:
                color.set(
                    f"{W}val",
                    emitter.document.heading_styles[0].color.lstrip("#").upper(),
                )


def _add_table_styles_ssot(emitter: WordDocumentEmitter, root: etree._Element) -> None:
    """Add table styles with theme-aware colors."""
    recipe = TableStyleRecipe.from_brand_tone(
        emitter.document.brand_tone,
        name="Brand Table",
    )

    table_style = generate_table_style(
        recipe,
        style_id="BrandTable",
        palette=emitter.document.color_palette,
    )

    latent = root.find("w:latentStyles", NSMAP)
    if latent is not None:
        latent.addprevious(table_style)
    else:
        root.append(table_style)


def _add_missing_builtin_styles(root: etree._Element) -> None:
    """Add stub definitions for built-in styles not already in the template."""
    existing = {style.get(f"{W}styleId") for style in root.findall(".//w:style", NSMAP)}

    for defn in BUILTIN_STYLES:
        if defn.style_id in existing:
            continue
        if defn.category == StyleCategory.TABLE:
            continue

        style_el = etree.SubElement(root, f"{W}style")
        style_el.set(f"{W}type", defn.style_type.value)
        style_el.set(f"{W}styleId", defn.style_id)

        name_el = etree.SubElement(style_el, f"{W}name")
        name_el.set(f"{W}val", defn.name)

        if defn.based_on:
            based = etree.SubElement(style_el, f"{W}basedOn")
            based.set(f"{W}val", defn.based_on)

        if defn.next_style:
            next_el = etree.SubElement(style_el, f"{W}next")
            next_el.set(f"{W}val", defn.next_style)

        ui = etree.SubElement(style_el, f"{W}uiPriority")
        ui.set(f"{W}val", str(defn.ui_priority))

        if defn.semi_hidden:
            etree.SubElement(style_el, f"{W}semiHidden")
        if defn.unhide_when_used:
            etree.SubElement(style_el, f"{W}unhideWhenUsed")
        if defn.qformat:
            etree.SubElement(style_el, f"{W}qFormat")

        if defn.style_type == StyleType.PARAGRAPH:
            has_ppr = (
                defn.outline_level is not None
                or defn.indent_scale > 0
                or defn.space_before_scale > 0
                or defn.space_after_scale > 0
            )
            if has_ppr:
                ppr = etree.SubElement(style_el, f"{W}pPr")
                if defn.space_before_scale > 0 or defn.space_after_scale > 0:
                    spacing = etree.SubElement(ppr, f"{W}spacing")
                    if defn.space_before_scale > 0:
                        twips = int(defn.space_before_scale * 240)
                        spacing.set(f"{W}before", str(twips))
                    if defn.space_after_scale > 0:
                        twips = int(defn.space_after_scale * 240)
                        spacing.set(f"{W}after", str(twips))
                if defn.indent_scale > 0:
                    ind = etree.SubElement(ppr, f"{W}ind")
                    twips = int(defn.indent_scale * 360)
                    ind.set(f"{W}left", str(twips))
                if defn.outline_level is not None:
                    ol = etree.SubElement(ppr, f"{W}outlineLvl")
                    ol.set(f"{W}val", str(defn.outline_level))

        has_rpr = defn.bold or defn.italic or defn.small_caps or defn.all_caps
        if has_rpr:
            rpr = etree.SubElement(style_el, f"{W}rPr")
            if defn.bold:
                etree.SubElement(rpr, f"{W}b")
                etree.SubElement(rpr, f"{W}bCs")
            if defn.italic:
                etree.SubElement(rpr, f"{W}i")
                etree.SubElement(rpr, f"{W}iCs")
            if defn.small_caps:
                etree.SubElement(rpr, f"{W}smallCaps")
            if defn.all_caps:
                etree.SubElement(rpr, f"{W}caps")


def create_style_element(
    emitter: WordDocumentEmitter, resolved: ResolvedStyle
) -> etree._Element:
    """Create a new style element from a ResolvedStyle."""
    style_el = etree.Element(f"{W}style")
    style_el.set(f"{W}type", resolved.style_type)
    style_el.set(f"{W}styleId", resolved.style_id)

    name_el = etree.SubElement(style_el, f"{W}name")
    name_el.set(f"{W}val", resolved.name)

    if resolved.based_on:
        based_on = etree.SubElement(style_el, f"{W}basedOn")
        based_on.set(f"{W}val", resolved.based_on)

    if resolved.next_style:
        next_el = etree.SubElement(style_el, f"{W}next")
        next_el.set(f"{W}val", resolved.next_style)

    if resolved.linked_style_id:
        link = etree.SubElement(style_el, f"{W}link")
        link.set(f"{W}val", resolved.linked_style_id)

    ui_priority = etree.SubElement(style_el, f"{W}uiPriority")
    ui_priority.set(f"{W}val", str(resolved.ui_priority))

    if resolved.qformat:
        etree.SubElement(style_el, f"{W}qFormat")

    if resolved.semi_hidden:
        etree.SubElement(style_el, f"{W}semiHidden")

    if resolved.unhide_when_used:
        etree.SubElement(style_el, f"{W}unhideWhenUsed")

    if resolved.style_type == "paragraph":
        _apply_resolved_paragraph_style(emitter, style_el, resolved)
    elif resolved.style_type == "character":
        _apply_resolved_character_style(emitter, style_el, resolved)

    return style_el


def update_style_from_resolved(
    emitter: WordDocumentEmitter,
    style_el: etree._Element,
    resolved: ResolvedStyle,
) -> None:
    """Update an existing style element with resolved values."""
    ui_priority = style_el.find("w:uiPriority", NSMAP)
    if ui_priority is not None:
        ui_priority.set(f"{W}val", str(resolved.ui_priority))

    if resolved.style_type == "paragraph":
        _apply_resolved_paragraph_style(emitter, style_el, resolved)
    elif resolved.style_type == "character":
        _apply_resolved_character_style(emitter, style_el, resolved)


def _apply_resolved_paragraph_style(
    emitter: WordDocumentEmitter,
    style_el: etree._Element,
    resolved: ResolvedStyle,
) -> None:
    """Apply paragraph style properties from a ResolvedStyle."""
    rpr = style_el.find("w:rPr", NSMAP)
    if rpr is None:
        rpr = etree.SubElement(style_el, f"{W}rPr")

    _apply_resolved_run_properties(emitter, rpr, resolved)

    ppr = style_el.find("w:pPr", NSMAP)
    if ppr is None:
        ppr = etree.SubElement(style_el, f"{W}pPr")

    _apply_resolved_paragraph_properties(ppr, resolved)


def _apply_resolved_character_style(
    emitter: WordDocumentEmitter,
    style_el: etree._Element,
    resolved: ResolvedStyle,
) -> None:
    """Apply character style properties from a ResolvedStyle."""
    rpr = style_el.find("w:rPr", NSMAP)
    if rpr is None:
        rpr = etree.SubElement(style_el, f"{W}rPr")

    _apply_resolved_run_properties(emitter, rpr, resolved)


def _apply_resolved_run_properties(
    emitter: WordDocumentEmitter,
    rpr: etree._Element,
    resolved: ResolvedStyle,
) -> None:
    """Apply run (character-level) properties from a ResolvedStyle."""
    if resolved.font_family:
        rfonts = rpr.find("w:rFonts", NSMAP)
        if rfonts is None:
            rfonts = etree.SubElement(rpr, f"{W}rFonts")
        rfonts.set(f"{W}ascii", resolved.font_family)
        rfonts.set(f"{W}hAnsi", resolved.font_family)

    if resolved.font_size_pt is not None:
        sz = rpr.find("w:sz", NSMAP)
        if sz is None:
            sz = etree.SubElement(rpr, f"{W}sz")
        sz.set(f"{W}val", str(int(resolved.font_size_pt * 2)))

        szCs = rpr.find("w:szCs", NSMAP)
        if szCs is None:
            szCs = etree.SubElement(rpr, f"{W}szCs")
        szCs.set(f"{W}val", str(int(resolved.font_size_pt * 2)))

    if resolved.color:
        color = rpr.find("w:color", NSMAP)
        if color is None:
            color = etree.SubElement(rpr, f"{W}color")
        color.set(f"{W}val", resolved.color.lstrip("#").upper())

    if resolved.bold:
        if rpr.find("w:b", NSMAP) is None:
            etree.SubElement(rpr, f"{W}b")

    if resolved.italic:
        if rpr.find("w:i", NSMAP) is None:
            etree.SubElement(rpr, f"{W}i")

    if resolved.small_caps:
        if rpr.find("w:smallCaps", NSMAP) is None:
            etree.SubElement(rpr, f"{W}smallCaps")

    if resolved.all_caps:
        if rpr.find("w:caps", NSMAP) is None:
            etree.SubElement(rpr, f"{W}caps")

    if resolved.tracking_twips != 0:
        spacing = rpr.find("w:spacing", NSMAP)
        if spacing is None:
            spacing = etree.SubElement(rpr, f"{W}spacing")
        spacing.set(f"{W}val", str(resolved.tracking_twips))

    if resolved.opentype:
        apply_opentype_features(emitter, rpr, resolved.opentype)


def _apply_resolved_paragraph_properties(
    ppr: etree._Element, resolved: ResolvedStyle
) -> None:
    """Apply paragraph properties from a ResolvedStyle."""
    if (
        resolved.space_before_twips is not None
        or resolved.space_after_twips is not None
    ):
        spacing = ppr.find("w:spacing", NSMAP)
        if spacing is None:
            spacing = etree.SubElement(ppr, f"{W}spacing")
        if resolved.space_before_twips is not None:
            spacing.set(f"{W}before", str(resolved.space_before_twips))
        if resolved.space_after_twips is not None:
            spacing.set(f"{W}after", str(resolved.space_after_twips))

    if resolved.left_indent_twips > 0 or resolved.first_line_indent_twips > 0:
        ind = ppr.find("w:ind", NSMAP)
        if ind is None:
            ind = etree.SubElement(ppr, f"{W}ind")
        if resolved.left_indent_twips > 0:
            ind.set(f"{W}left", str(resolved.left_indent_twips))
        if resolved.first_line_indent_twips > 0:
            ind.set(f"{W}firstLine", str(resolved.first_line_indent_twips))

    if resolved.outline_level is not None:
        outline = ppr.find("w:outlineLvl", NSMAP)
        if outline is None:
            outline = etree.SubElement(ppr, f"{W}outlineLvl")
        outline.set(f"{W}val", str(resolved.outline_level))

    if resolved.keep_with_next:
        if ppr.find("w:keepNext", NSMAP) is None:
            etree.SubElement(ppr, f"{W}keepNext")

    if resolved.keep_lines_together:
        if ppr.find("w:keepLines", NSMAP) is None:
            etree.SubElement(ppr, f"{W}keepLines")


# Re-export the typography helpers used internally so callers can keep a
# single import point.
__all__ = [
    "create_style_element",
    "customize_styles",
    "update_style_from_resolved",
    "apply_opentype_features",
    "apply_paragraph_properties",
    "apply_run_properties",
]
