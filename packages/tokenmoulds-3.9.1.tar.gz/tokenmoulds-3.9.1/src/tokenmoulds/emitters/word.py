"""Word document emitter that renders the Document IR into a DOTX template.

SSOT Architecture:
==================
All XML structure comes from xml-structures/ecma-376/wordprocessingml/ as the
Single Source of Truth. The emitter loads templates and modifies attribute
values - it never constructs new XML elements programmatically.

For dynamic content (e.g., paragraphs, font entries), template fragments are
loaded, values substituted, parsed, and inserted into the document.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Literal, Mapping


from tokenmoulds.artifact_intent import ArtifactIntentMetadata
from tokenmoulds.emitters.ooxml_base import OOXMLBaseEmitter
from tokenmoulds.emitters.word_headers import HeaderFooterBundle, HeaderFooterEmitter
from tokenmoulds.emitters.word_sections import (
    customize_document,
    customize_settings,
)
from tokenmoulds.emitters.word_sections_packaging import (
    build_font_relationships,
    customize_content_types,
    customize_document_rels,
    customize_font_table,
    customize_numbering,
)
from tokenmoulds.emitters.word_styles import customize_styles
from tokenmoulds.ir import (
    DocumentIR,
)

logger = logging.getLogger(__name__)


class WordDocumentEmitter(OOXMLBaseEmitter):
    """Build Word templates from the canonical Document IR.

    Uses a known-good base template and modifies specific style values
    based on the Document IR, preserving Word-required internal structures.

    Inherits from OOXMLBaseEmitter which provides:
    - ZIP package building pattern
    - Font embedding infrastructure (ODTTF format)
    - Theme customization (color scheme, font scheme)
    - Core properties metadata
    """

    _long_form_bundle_cache: HeaderFooterBundle | None

    def __init__(
        self,
        document: DocumentIR,
        template_root: Path | str | None = None,
        embed_fonts: bool = False,
        fonts_dir: Path | str | None = None,
        style_resolver: object | None = None,
        use_pure_text_colors: bool = True,
        enable_opentype_features: bool = True,
        layout_families: list[object] | None = None,
        output_format: str | None = None,
        allow_font_downloads: bool = False,
        artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(
            document=document,
            template_root=template_root,
            embed_fonts=embed_fonts,
            fonts_dir=fonts_dir,
            style_resolver=style_resolver,
            use_pure_text_colors=use_pure_text_colors,
            enable_opentype_features=enable_opentype_features,
            layout_families=layout_families,
            output_format=output_format,
            allow_font_downloads=allow_font_downloads,
            artifact_intent=artifact_intent,
        )
        self.allow_opentype_features = enable_opentype_features
        self._long_form_bundle_cache = None

    PACKAGE_STRUCTURE = {
        "[Content_Types].xml": "content_types.xml",
        "_rels/.rels": "package_rels.xml",
        "word/document.xml": "document.xml",
        "word/styles.xml": "styles.xml",
        "word/stylesWithEffects.xml": "styles.xml",
        "word/settings.xml": "settings.xml",
        "word/numbering.xml": "numbering.xml",
        "word/fontTable.xml": "fontTable.xml",
        "word/webSettings.xml": "webSettings.xml",
        "word/theme/theme1.xml": "theme.xml",
        "word/_rels/document.xml.rels": "document_rels.xml",
        "docProps/core.xml": "docprops_core.xml",
        "docProps/app.xml": "docprops_app.xml",
    }

    def _get_format_key(self) -> str:
        return "word"

    def _get_package_structure(self) -> Dict[str, str]:
        return self.PACKAGE_STRUCTURE

    def _get_document_title(self) -> str:
        return f"{self.document.org_id} Template"

    def _get_font_embedding_format(self) -> Literal["odttf", "eot", "none"]:
        return "odttf"

    def _get_font_entries_path(self) -> str:
        return "word/fonts/"

    def _should_customize_entry(self, entry_path: str) -> bool:
        customizable = {
            "[Content_Types].xml",
            "word/styles.xml",
            "word/stylesWithEffects.xml",
            "word/settings.xml",
            "word/theme/theme1.xml",
            "word/document.xml",
            "word/numbering.xml",
            "word/fontTable.xml",
            "word/_rels/document.xml.rels",
            "docProps/core.xml",
            "docProps/app.xml",
        }
        return entry_path in customizable

    def _customize_entry(self, entry_path: str, data: bytes) -> bytes | None:
        """Customize specific ZIP entry with Document IR values."""
        if entry_path == "[Content_Types].xml":
            return customize_content_types(self, data)
        elif entry_path in ("word/styles.xml", "word/stylesWithEffects.xml"):
            return customize_styles(self, data)
        elif entry_path == "word/settings.xml":
            return customize_settings(self, data)
        elif entry_path == "word/theme/theme1.xml":
            return self._customize_theme(data)
        elif entry_path == "word/document.xml":
            return customize_document(self, data)
        elif entry_path == "word/numbering.xml":
            return customize_numbering(self, data)
        elif entry_path == "word/fontTable.xml":
            return customize_font_table(self, data)
        elif entry_path == "word/_rels/document.xml.rels":
            return customize_document_rels(self, data)
        elif entry_path == "docProps/core.xml":
            return self._customize_core_props_ssot(data)
        elif entry_path == "docProps/app.xml":
            return self._customize_app_props_ssot(data)
        return data

    def _customize_core_props_ssot(self, data: bytes) -> bytes:
        """Customize core properties using SSOT template substitution."""
        timestamp = self._utc_timestamp()
        content = data.decode("utf-8")
        content = content.replace("${TITLE}", self._get_document_title())
        content = content.replace("${CREATOR}", "TokenMoulds")
        content = content.replace("${MODIFIER}", "TokenMoulds")
        content = content.replace("${TIMESTAMP}", timestamp)
        return content.encode("utf-8")

    def _customize_app_props_ssot(self, data: bytes) -> bytes:
        """Customize app properties using SSOT template substitution."""
        content = data.decode("utf-8")
        content = content.replace("${APPLICATION}", "TokenMoulds")
        content = content.replace("${COMPANY}", self.document.org_id)
        return content.encode("utf-8")

    def _get_font_metadata_entries(self) -> list:
        """Return Word font relationships as PackagedEntry list."""
        from tokenmoulds.packaging.types import PackagedEntry

        if self.embedded_fonts:
            rels_data = build_font_relationships(self)
            return [
                PackagedEntry(
                    archive_path="word/_rels/fontTable.xml.rels",
                    data=rels_data,
                )
            ]
        return []

    def _get_additional_packaged_entries(self):
        """Emit long-form header/footer PackagedEntries."""
        bundle = self._get_long_form_bundle()
        if bundle is None:
            return []
        return list(bundle.entries)

    def _get_long_form_bundle(self) -> HeaderFooterBundle | None:
        """Lazily build the long-form header/footer bundle, cached per emit."""
        if self._long_form_bundle_cache is not None:
            return self._long_form_bundle_cache
        if not self.document.long_form_sections:
            return None
        emitter = HeaderFooterEmitter(document_title=self._get_document_title())
        self._long_form_bundle_cache = emitter.build_packaged_entries(
            self.document.long_form_sections
        )
        return self._long_form_bundle_cache
