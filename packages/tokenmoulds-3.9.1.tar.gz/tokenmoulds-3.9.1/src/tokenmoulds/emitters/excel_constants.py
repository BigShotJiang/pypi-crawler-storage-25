"""Constants for the Excel emitter.

Paper sizes, locale mappings, theme color indices, tint values,
number format IDs, built-in cell style IDs, and shared helpers.
"""

from __future__ import annotations

from typing import Dict, Tuple

SSML_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"

# Paper sizes (ECMA-376 §18.18.52)
_PAPER_LETTER = "1"  # US Letter 8.5×11"
_PAPER_A4 = "9"  # ISO A4 210×297mm

# Locales that use US Letter paper
_LETTER_LOCALES = frozenset(
    {
        "US",
        "CA",
        "MX",
        "CO",
        "VE",
        "CL",
        "PH",
        "DO",
        "GT",
        "CR",
        "PA",
        "SV",
        "HN",
        "NI",
        "BO",
        "PY",
        "EC",
        "PE",
    }
)

# Custom number format IDs start at 164 (ECMA-376 §18.8.31)
_CUSTOM_NUMFMT_BASE = 164

# Locale → (currency format, date format) for non-US locales
_LOCALE_NUMFMTS: Dict[str, Tuple[str, str]] = {
    "GB": ("£#,##0.00", "dd/mm/yyyy"),
    "AU": ("$#,##0.00", "dd/mm/yyyy"),
    "NZ": ("$#,##0.00", "dd/mm/yyyy"),
    "IE": ("#,##0.00 €", "dd/mm/yyyy"),
    "ZA": ("R #,##0.00", "dd/mm/yyyy"),
    "IN": ("₹#,##0.00", "dd/mm/yyyy"),
    "SG": ("$#,##0.00", "dd/mm/yyyy"),
    "HK": ("$#,##0.00", "dd/mm/yyyy"),
    "DE": ("#.##0,00 €", "dd.mm.yyyy"),
    "AT": ("#.##0,00 €", "dd.mm.yyyy"),
    "FR": ("#.##0,00 €", "dd.mm.yyyy"),
    "ES": ("#.##0,00 €", "dd.mm.yyyy"),
    "IT": ("#.##0,00 €", "dd.mm.yyyy"),
    "PT": ("#.##0,00 €", "dd.mm.yyyy"),
    "NL": ("#.##0,00 €", "dd.mm.yyyy"),
    "BE": ("#.##0,00 €", "dd.mm.yyyy"),
    "JP": ("¥#,##0", "yyyy/mm/dd"),
    "BR": ("R$ #.##0,00", "dd/mm/yyyy"),
}

# OOXML theme color indices for <color theme="N"/>
# These match the order in theme1.xml: dk1=0, lt1=1, dk2=2, lt2=3, accent1-6=4-9, hlink=10, folHlink=11
_THEME_DK1 = "0"
_THEME_LT1 = "1"
_THEME_DK2 = "2"
_THEME_LT2 = "3"
_THEME_ACCENT1 = "4"
_THEME_ACCENT2 = "5"
_THEME_ACCENT3 = "6"
_THEME_ACCENT4 = "7"
_THEME_ACCENT5 = "8"
_THEME_ACCENT6 = "9"
_THEME_HLINK = "10"
_THEME_FOLHLINK = "11"

# OOXML tint values (fraction of the way toward white)
_TINT_20 = "0.7999"  # 80% tint → 20% of original color remains
_TINT_40 = "0.5999"  # 60% tint → 40% of original color remains
_TINT_60 = "0.3999"  # 40% tint → 60% of original color remains

# Excel built-in number format IDs (ECMA-376 §18.8.30)
_NUMFMT_GENERAL = "0"
_NUMFMT_COMMA = "3"  # #,##0
_NUMFMT_COMMA_DEC = "4"  # #,##0.00
_NUMFMT_CURRENCY = "44"  # _("$"* #,##0.00_)
_NUMFMT_PERCENT = "10"  # 0.00%
_NUMFMT_PERCENT_INT = "9"  # 0%
_NUMFMT_DATE = "14"  # m/d/yyyy
_NUMFMT_TIME = "20"  # h:mm
_NUMFMT_DATETIME = "22"  # m/d/yyyy h:mm

# Excel built-in cell style IDs (builtinId)
_BUILTIN_NORMAL = "0"
_BUILTIN_COMMA = "3"
_BUILTIN_CURRENCY = "4"
_BUILTIN_PERCENT = "5"
_BUILTIN_COMMA_0 = "6"
_BUILTIN_CURRENCY_0 = "7"
_BUILTIN_HYPERLINK = "8"
_BUILTIN_FOLLOWED_HYPERLINK = "9"
_BUILTIN_NOTE = "10"
_BUILTIN_WARNING = "11"
_BUILTIN_TITLE = "15"
_BUILTIN_HEADING1 = "16"
_BUILTIN_HEADING2 = "17"
_BUILTIN_HEADING3 = "18"
_BUILTIN_HEADING4 = "19"
_BUILTIN_INPUT = "20"
_BUILTIN_OUTPUT = "21"
_BUILTIN_CALCULATION = "22"
_BUILTIN_CHECK_CELL = "23"
_BUILTIN_GOOD = "26"
_BUILTIN_BAD = "27"
_BUILTIN_NEUTRAL = "28"
_BUILTIN_ACCENT1 = "29"
_BUILTIN_ACCENT1_20 = "30"
_BUILTIN_ACCENT1_40 = "31"
_BUILTIN_ACCENT1_60 = "32"
_BUILTIN_ACCENT2 = "33"
_BUILTIN_ACCENT2_20 = "34"
_BUILTIN_ACCENT2_40 = "35"
_BUILTIN_ACCENT2_60 = "36"
_BUILTIN_ACCENT3 = "37"
_BUILTIN_ACCENT3_20 = "38"
_BUILTIN_ACCENT3_40 = "39"
_BUILTIN_ACCENT3_60 = "40"
_BUILTIN_ACCENT4 = "41"
_BUILTIN_ACCENT4_20 = "42"
_BUILTIN_ACCENT4_40 = "43"
_BUILTIN_ACCENT4_60 = "44"
_BUILTIN_ACCENT5 = "45"
_BUILTIN_ACCENT5_20 = "46"
_BUILTIN_ACCENT5_40 = "47"
_BUILTIN_ACCENT5_60 = "48"
_BUILTIN_ACCENT6 = "49"
_BUILTIN_ACCENT6_20 = "50"
_BUILTIN_ACCENT6_40 = "51"
_BUILTIN_ACCENT6_60 = "52"
_BUILTIN_EXPLANATORY = "53"
_BUILTIN_TOTAL = "25"


def _fmt_size(pt: float) -> str:
    """Format font size, stripping trailing zeros."""
    return f"{pt:.1f}".rstrip("0").rstrip(".")
