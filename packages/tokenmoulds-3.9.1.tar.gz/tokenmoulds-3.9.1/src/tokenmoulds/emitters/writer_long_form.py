"""Writer long-form section wiring — ties the resolver builders into styles.xml.

The :class:`WriterStylesEmitter` delegates here when the document has
long-form sections.  The function replaces the template's default
``pm1``/``Standard`` pair with per-section page layouts and master pages,
and appends section-first transition paragraph styles to the automatic
styles set.

Kept in its own module so ``writer.py`` stays under the 1000-line
maintainability guardrail.
"""

from __future__ import annotations

import lxml.etree as etree

from tokenmoulds.emitters.odf_helpers import ODF_NSMAP, q
from tokenmoulds.emitters.odf_master_pages import (
    build_master_page,
    build_page_layout,
    build_section_transition_styles,
    odf_name,
)
from tokenmoulds.ir import DocumentIR


def apply_long_form_sections(root: etree._Element, document: DocumentIR) -> None:
    """Replace the template's default page-layout/master-page with long-form.

    No-op when the document has no long-form sections.  When present:

    1. Remove the template's default ``pm1`` page-layout and ``Standard``
       master-page from ``office:automatic-styles``/``office:master-styles``.
    2. For each section, append a ``<style:page-layout>`` named
       ``pm_{section}`` via :func:`build_page_layout`.
    3. For each section, append a ``<style:master-page>`` named
       ``Section_{section}`` via :func:`build_master_page`, with headers
       and footers resolved from the section's config.
    4. Additionally append a ``Standard`` alias master-page pointing at
       the first section's layout — Writer expects ``Standard`` to exist
       so fallback paragraphs without an explicit section-first style
       still render with the front-matter geometry.
    5. Append one section-first transition paragraph style per section
       (``P_{section}_First``) so content.xml can apply them to the
       first paragraph of each section and trigger the master-page switch.
    """
    sections = document.long_form_sections
    if not sections:
        return

    auto_styles = root.find("office:automatic-styles", ODF_NSMAP)
    master_styles = root.find("office:master-styles", ODF_NSMAP)
    if auto_styles is None or master_styles is None:
        return

    document_title = f"{document.org_id} Document"
    transition_bundle = build_section_transition_styles(sections)

    for el in list(auto_styles.findall(q("style", "page-layout"))):
        if el.get(q("style", "name")) == "pm1":
            auto_styles.remove(el)
    for el in list(master_styles.findall(q("style", "master-page"))):
        if el.get(q("style", "name")) == "Standard":
            master_styles.remove(el)

    for index, section in enumerate(sections):
        layout_name = f"pm_{odf_name(section.name)}"
        master_name = transition_bundle.master_page_for_section[section.name]

        layout_el = build_page_layout(
            layout_name,
            section.page_geometry,
            section.margins,
            page_number=section.page_number,
            columns=section.columns,
            column_gap_pt=section.column_gap_pt,
        )
        auto_styles.append(layout_el)

        master_el = build_master_page(
            master_name,
            layout_name,
            section,
            document_title=document_title,
        )
        master_styles.append(master_el)

        if index == 0:
            alias = build_master_page(
                "Standard",
                layout_name,
                section,
                document_title=document_title,
            )
            master_styles.append(alias)

    for transition_style in transition_bundle.styles:
        auto_styles.append(transition_style)
