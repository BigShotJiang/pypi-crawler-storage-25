"""Generate ``docProps/custom.xml`` for OOXML templates.

Custom properties embed compliance metadata (classification, watermark),
a SHA-256 hash of the resolved token inputs (for change detection), and
the template version — all as standard OOXML custom document properties.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

import lxml.etree as etree

from tokenmoulds.artifact_intent import (
    ArtifactIntentMetadata,
    artifact_intent_from_mapping,
)

_CUSTOM_NS = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties"
_VT_NS = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
_FMTID = "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}"

_NSMAP = {
    None: _CUSTOM_NS,
    "vt": _VT_NS,
}


def build_custom_properties_xml(
    *,
    classification: str | None = None,
    template_hash: str | None = None,
    template_version: str | None = None,
    company: str | None = None,
    custom_properties: Mapping[str, object] | None = None,
    artifact_intent: ArtifactIntentMetadata | Mapping[str, Any] | None = None,
) -> bytes:
    """Build ``docProps/custom.xml`` content.

    Args:
        classification: Document classification (e.g. "Confidential", "Internal").
        template_hash: SHA-256 hex digest of resolved token inputs.
        template_version: Semantic version of the template.
        company: Company name for metadata.
        custom_properties: Additional custom properties to append.
        artifact_intent: Artifact intent metadata to expose as TokenMoulds index
            properties.

    Returns:
        UTF-8 encoded XML bytes.
    """
    root = etree.Element(f"{{{_CUSTOM_NS}}}Properties", nsmap=_NSMAP)

    pid = 2  # OOXML custom property IDs start at 2
    props: list[tuple[str, str]] = []
    _append_property(props, "Classification", classification)
    _append_property(props, "TemplateHash", template_hash)
    _append_property(props, "TemplateVersion", template_version)
    _append_property(props, "Company", company)

    if artifact_intent is not None:
        intent = (
            artifact_intent
            if isinstance(artifact_intent, ArtifactIntentMetadata)
            else artifact_intent_from_mapping(artifact_intent)
        )
        for name, value in intent.flat_properties().items():
            _append_property(props, name, value)

    if custom_properties is not None:
        for name in sorted(custom_properties):
            _append_property(props, name, custom_properties[name])

    for name, value in props:
        prop = etree.SubElement(root, f"{{{_CUSTOM_NS}}}property")
        prop.set("fmtid", _FMTID)
        prop.set("pid", str(pid))
        prop.set("name", name)
        vt = etree.SubElement(prop, f"{{{_VT_NS}}}lpwstr")
        vt.text = value
        pid += 1

    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _append_property(
    props: list[tuple[str, str]],
    name: str,
    value: object | None,
) -> None:
    """Append one string custom property if present and not already defined."""
    if value is None:
        return
    if any(existing_name == name for existing_name, _ in props):
        return
    props.append((name, str(value)))


def compute_template_hash(inputs: dict[str, Any]) -> str:
    """Compute SHA-256 hash of resolved token inputs.

    Keys are sorted recursively for deterministic output regardless of
    dict insertion order.

    Args:
        inputs: Resolved input token values.

    Returns:
        Lowercase hex digest (64 characters).
    """
    canonical = json.dumps(inputs, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
