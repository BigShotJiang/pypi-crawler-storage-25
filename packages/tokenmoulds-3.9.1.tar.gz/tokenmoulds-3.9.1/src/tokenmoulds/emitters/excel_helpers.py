"""Shared Excel emitter helper functions."""

from __future__ import annotations

import math
import re
from typing import Dict

from tokenmoulds.design.units import emu_to_inches, emu_to_pt
from tokenmoulds.emitters.excel_constants import _LETTER_LOCALES
from tokenmoulds.ir import DocumentIR
from tokenmoulds.ir.long_form import HeaderFooterConfig
from tokenmoulds.semantic.content import SemanticContentInput
from tokenmoulds.semantic.lowerers.excel import lower_excel_content


def _hf_content_to_excel(content: SemanticContentInput) -> str:
    """Compatibility wrapper for the semantic Excel lowerer."""
    return lower_excel_content(content)


def _absolutize_range(ref: str) -> str:
    """Convert an A1-style range to the absolute form ``$A$1:$Z$100``.

    Accepts an already-absolute range unchanged. Used for defined names
    like ``_xlnm.Print_Area`` where Excel requires absolute references.
    """

    def _abs_one(cell: str) -> str:
        m = re.match(r"^\$?([A-Za-z]+)\$?(\d+)$", cell)
        if not m:
            return cell
        col, row = m.group(1), m.group(2)
        return f"${col}${row}"

    if ":" in ref:
        a, b = ref.split(":", 1)
        return f"{_abs_one(a)}:{_abs_one(b)}"
    return _abs_one(ref)


def _quote_sheet_name_for_formula(name: str) -> str:
    """Quote a sheet name for use in an Excel formula reference.

    Per ECMA-376 / Excel grammar, plain ASCII-letter/digit/underscore names
    that don't start with a digit can appear unquoted (``Sheet1!$A$1``).
    Anything else must be wrapped in single quotes, with embedded single
    quotes doubled (``'O''Brien Q1'!$A$1``).
    """
    if name and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        return name
    return "'" + name.replace("'", "''") + "'"


def _hf_config_to_excel_format(cfg: HeaderFooterConfig | None) -> str | None:
    """Render a HeaderFooterConfig as an Excel header/footer format string.

    Outer/inner slots collapse to left/right since Excel has no mirror-page
    concept at the worksheet level. Returns None when the config is None or
    yields an empty string (nothing to set).
    """
    if cfg is None:
        return None
    parts: list[str] = []
    left = cfg.left if cfg.left is not None else cfg.inner
    center = cfg.center
    right = cfg.right if cfg.right is not None else cfg.outer
    if left is not None:
        parts.append(f"&L{_hf_content_to_excel(left)}")
    if center is not None:
        parts.append(f"&C{_hf_content_to_excel(center)}")
    if right is not None:
        parts.append(f"&R{_hf_content_to_excel(right)}")
    return "".join(parts) if parts else None


def _default_row_height_pt(doc: DocumentIR) -> float:
    """Derive default row height from baseline grid or body font size.

    Excel row height = enough to fit body text + padding, snapped to the
    baseline grid when available.  Falls back to 1.4× body size.
    """
    body_size = doc.body_style.font_size_pt
    if doc.page_geometry and doc.page_geometry.baseline_grid_emu > 0:
        grid_pt = emu_to_pt(doc.page_geometry.baseline_grid_emu)
        lines = math.ceil(body_size * 1.2 / grid_pt)
        return lines * grid_pt
    # No grid — use 1.4× line height (Excel default ratio)
    return round(body_size * 1.4, 1)


def _page_margins_inches(doc: DocumentIR, locale: str) -> Dict[str, str]:
    """Get page margins in inches from IR or locale defaults."""
    if doc.page_geometry:
        m = doc.page_geometry.margins
        return {
            "left": f"{emu_to_inches(m.left):.2f}",
            "right": f"{emu_to_inches(m.right):.2f}",
            "top": f"{emu_to_inches(m.top):.2f}",
            "bottom": f"{emu_to_inches(m.bottom):.2f}",
        }
    # Locale defaults
    if locale in _LETTER_LOCALES:
        return {"left": "0.70", "right": "0.70", "top": "0.75", "bottom": "0.75"}
    # A4 metric defaults (narrower margins)
    return {"left": "0.79", "right": "0.79", "top": "0.79", "bottom": "0.79"}
