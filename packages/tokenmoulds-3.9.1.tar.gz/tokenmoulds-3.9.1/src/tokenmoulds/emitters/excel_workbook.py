"""Workbook and worksheet customization helpers for the Excel emitter.

Free functions taking the concrete ``ExcelEmitter`` as their first argument.
"""

from __future__ import annotations

import html
from typing import TYPE_CHECKING

import lxml.etree as etree

if TYPE_CHECKING:
    from tokenmoulds.emitters.excel import ExcelEmitter
    from tokenmoulds.ir.excel_layout import ExcelSheet
    from tokenmoulds.ir.long_form import HeaderFooterConfig

from tokenmoulds.emitters.excel_constants import (
    _LETTER_LOCALES,
    _PAPER_A4,
    _PAPER_LETTER,
    _THEME_ACCENT1,
    SSML_NS,
    _fmt_size,
)
from tokenmoulds.emitters.excel_helpers import (
    _absolutize_range,
    _default_row_height_pt,
    _hf_config_to_excel_format,
    _page_margins_inches,
)
from tokenmoulds.emitters.excel_stylesheet import _col_index_to_letters
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
    serialize_tree,
)
from tokenmoulds.packaging import PackagedEntry


def customize_workbook_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    sheets = emitter._resolved_sheets()
    root = emitter.templates.read_tree("templates/workbook.xml")
    replace_placeholders(root, {"SHEET_NAME": sheets[0].name})
    sheets_el = root.find(f"{{{SSML_NS}}}sheets")
    if sheets_el is not None and len(sheets) > 1:
        for child in list(sheets_el):
            sheets_el.remove(child)
        rns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        for idx, sheet in enumerate(sheets, start=1):
            sheet_el = etree.SubElement(sheets_el, f"{{{SSML_NS}}}sheet")
            sheet_el.set("name", sheet.name)
            sheet_el.set("sheetId", str(idx))
            sheet_el.set(f"{{{rns}}}id", f"rId{idx}")

    # Promote per-sheet print area / print titles into <definedNames>.
    # These names use the reserved ``_xlnm.Print_Area`` / ``_xlnm.Print_Titles``
    # prefix and must be scoped to the sheet via ``localSheetId`` (zero-based).
    defined_names_entries: list[tuple[int, str, str]] = []
    for sheet_idx, sheet in enumerate(sheets):
        if sheet.print_area:
            ref = f"'{sheet.name}'!{_absolutize_range(sheet.print_area)}"
            defined_names_entries.append((sheet_idx, "_xlnm.Print_Area", ref))
        title_parts: list[str] = []
        if sheet.print_titles_rows:
            title_parts.append(f"'{sheet.name}'!{sheet.print_titles_rows}")
        if sheet.print_titles_cols:
            title_parts.append(f"'{sheet.name}'!{sheet.print_titles_cols}")
        if title_parts:
            defined_names_entries.append(
                (sheet_idx, "_xlnm.Print_Titles", ",".join(title_parts))
            )

    if defined_names_entries:
        # <definedNames> belongs between <sheets> and <calcPr> in ECMA-376.
        dn_el = etree.Element(f"{{{SSML_NS}}}definedNames")
        for local_id, name, value in defined_names_entries:
            n = etree.SubElement(dn_el, f"{{{SSML_NS}}}definedName")
            n.set("name", name)
            n.set("localSheetId", str(local_id))
            n.text = value
        if sheets_el is not None:
            sheets_el.addnext(dn_el)
        else:
            root.append(dn_el)

    return serialize_tree(root, xml_declaration=False)


def customize_workbook_rels_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    """Emit sheet1..N, then styles, theme relationship ids."""
    sheets = emitter._resolved_sheets()
    rns = "http://schemas.openxmlformats.org/package/2006/relationships"
    root = etree.Element(
        f"{{{rns}}}Relationships",
        nsmap={None: rns},  # type: ignore[dict-item]
    )
    next_rid = 1
    for i, _ in enumerate(sheets, start=1):
        rel = etree.SubElement(root, f"{{{rns}}}Relationship")
        rel.set("Id", f"rId{next_rid}")
        rel.set(
            "Type",
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
        )
        rel.set("Target", f"worksheets/sheet{i}.xml")
        next_rid += 1
    for rel_type, target in (
        (
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
            "styles.xml",
        ),
        (
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
            "theme/theme1.xml",
        ),
    ):
        rel = etree.SubElement(root, f"{{{rns}}}Relationship")
        rel.set("Id", f"rId{next_rid}")
        rel.set("Type", rel_type)
        rel.set("Target", target)
        next_rid += 1
    return serialize_tree(root, xml_declaration=True)


def customize_content_types_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    """Add per-sheet Override entries for sheet2..N."""
    sheets = emitter._resolved_sheets()
    root = emitter.templates.read_tree("templates/content_types.xml")
    ctns = "http://schemas.openxmlformats.org/package/2006/content-types"
    worksheet_ct = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
    )
    for i in range(2, len(sheets) + 1):
        override = etree.SubElement(root, f"{{{ctns}}}Override")
        override.set("PartName", f"/xl/worksheets/sheet{i}.xml")
        override.set("ContentType", worksheet_ct)
    return serialize_tree(root, xml_declaration=True)


def get_additional_packaged_entries(emitter: ExcelEmitter) -> list[PackagedEntry]:
    """Emit sheet2..N worksheet XML parts for multi-sheet workbooks."""
    sheets = emitter._resolved_sheets()
    if len(sheets) <= 1:
        return []
    entries: list[PackagedEntry] = []
    for i, sheet in enumerate(sheets[1:], start=2):
        entries.append(
            PackagedEntry(
                archive_path=f"xl/worksheets/sheet{i}.xml",
                data=_build_secondary_worksheet(emitter, sheet),
            )
        )
    return entries


def customize_worksheet_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    """Customize the primary worksheet (sheet1.xml) with table + chart."""
    sheets = emitter._resolved_sheets()
    primary = sheets[0]
    body = emitter.document.body_style
    root = emitter.templates.read_tree("templates/worksheet.xml")
    _apply_common_sheet_mutations(emitter, root, primary)
    _apply_default_columns(root)
    _populate_primary_sheet_data(emitter, root, body)
    _wire_primary_drawing_and_table(root)
    _strip_sample_sheet_decorations(root)
    remove_template_elements(root)
    from tokenmoulds.emitters.xml_helpers_template import remove_empty_containers

    remove_empty_containers(root)
    return serialize_tree(root, xml_declaration=False)


def _build_secondary_worksheet(emitter: ExcelEmitter, sheet: ExcelSheet) -> bytes:
    """Render a simple secondary worksheet: sample heading + body."""
    root = emitter.templates.read_tree("templates/worksheet.xml")
    _apply_common_sheet_mutations(emitter, root, sheet)
    _apply_default_columns(root)

    heading = sheet.sample_heading or sheet.name
    body_text = sheet.sample_body or f"{sheet.name} — placeholder content."
    sheet_data = root.find(f"{{{SSML_NS}}}sheetData")
    if sheet_data is not None:
        for row_idx, value in enumerate((heading, body_text), start=1):
            row_clone = clone_template_element(root, "row")
            replace_placeholders(row_clone, {"ROW_NUM": str(row_idx)})
            for child in list(row_clone):
                if child.get("data-template"):
                    row_clone.remove(child)
            cell_clone = clone_template_element(root, "cell")
            replace_placeholders(
                cell_clone,
                {"CELL_REF": f"A{row_idx}", "VALUE": html.escape(value)},
            )
            row_clone.append(cell_clone)
            sheet_data.append(row_clone)

    for tag in (
        "drawing",
        "tableParts",
        "autoFilter",
        "sortState",
        "conditionalFormatting",
        "dataValidations",
        "hyperlinks",
        "mergeCells",
    ):
        for el in root.findall(f"{{{SSML_NS}}}{tag}"):
            el.getparent().remove(el)  # type: ignore[union-attr]

    remove_template_elements(root)
    from tokenmoulds.emitters.xml_helpers_template import remove_empty_containers

    remove_empty_containers(root)
    return serialize_tree(root, xml_declaration=False)


def _apply_common_sheet_mutations(
    emitter: ExcelEmitter,
    root: etree._Element,
    sheet: ExcelSheet,
) -> None:
    """Shared mutations: tab color, row height, page setup, margins, header."""
    body = emitter.document.body_style
    locale = (emitter.document.locale or "US").upper()

    tab_color = root.find(f".//{{{SSML_NS}}}tabColor")
    if tab_color is not None:
        theme_slot = (
            str(sheet.tab_color_theme)
            if sheet.tab_color_theme is not None
            else _THEME_ACCENT1
        )
        tab_color.set("theme", theme_slot)
        tab_color.set("tint", "0")
        if "rgb" in tab_color.attrib:
            del tab_color.attrib["rgb"]

    fmt_pr = root.find(f"{{{SSML_NS}}}sheetFormatPr")
    if fmt_pr is not None:
        row_height = _default_row_height_pt(emitter.document)
        fmt_pr.set("defaultRowHeight", _fmt_size(row_height))
        fmt_pr.set("customHeight", "1")

    page_setup = root.find(f"{{{SSML_NS}}}pageSetup")
    if page_setup is not None:
        if sheet.page_geometry is not None:
            page_setup.set("orientation", sheet.page_geometry.orientation)
            short_edge = min(
                sheet.page_geometry.width_pt,
                sheet.page_geometry.height_pt,
            )
            if abs(short_edge - 595.0) < 1.0:
                page_setup.set("paperSize", _PAPER_A4)
            elif abs(short_edge - 612.0) < 1.0:
                page_setup.set("paperSize", _PAPER_LETTER)
            else:
                page_setup.set(
                    "paperSize",
                    _PAPER_LETTER if locale in _LETTER_LOCALES else _PAPER_A4,
                )
        else:
            page_setup.set(
                "paperSize",
                _PAPER_LETTER if locale in _LETTER_LOCALES else _PAPER_A4,
            )
        page_setup.set("scale", str(sheet.scale))
        page_setup.set("fitToWidth", str(sheet.fit_to_width))
        page_setup.set("fitToHeight", str(sheet.fit_to_height))

    fit_to_page = sheet.fit_to_width != 1 or sheet.fit_to_height != 1
    page_setup_pr = root.find(f".//{{{SSML_NS}}}pageSetUpPr")
    if page_setup_pr is not None:
        page_setup_pr.set("fitToPage", "1" if fit_to_page else "0")

    page_margins = root.find(f"{{{SSML_NS}}}pageMargins")
    if page_margins is not None:
        if sheet.margins is not None:
            m = sheet.margins
            pt_in = 72.0
            page_margins.set("left", f"{m.resolve_left() / pt_in:.2f}")
            page_margins.set("right", f"{m.resolve_right() / pt_in:.2f}")
            page_margins.set("top", f"{m.top_pt / pt_in:.2f}")
            page_margins.set("bottom", f"{m.bottom_pt / pt_in:.2f}")
        else:
            margins = _page_margins_inches(emitter.document, locale)
            page_margins.set("left", margins["left"])
            page_margins.set("right", margins["right"])
            page_margins.set("top", margins["top"])
            page_margins.set("bottom", margins["bottom"])

    _apply_header_footer(root, sheet, body_font_family=body.font_family)


def _apply_header_footer(
    root: etree._Element,
    sheet: ExcelSheet,
    *,
    body_font_family: str,
) -> None:
    """Populate <headerFooter> from sheet config or fall back to defaults."""
    hf_el = root.find(f"{{{SSML_NS}}}headerFooter")
    if hf_el is None:
        return
    hf_el.set("differentOddEven", "1" if sheet.odd_even_different else "0")
    hf_el.set("differentFirst", "1" if sheet.first_page_different else "0")

    font_prefix = f'&"{body_font_family},Regular"&K000000'

    def _fill(tag: str, cfg: HeaderFooterConfig | None, default: str | None) -> None:
        el = hf_el.find(f"{{{SSML_NS}}}{tag}")
        if el is None:
            return
        format_str = _hf_config_to_excel_format(cfg)
        if format_str is None:
            if default is None:
                el.text = None
                return
            format_str = default
        el.text = f"{font_prefix}{format_str}"

    default_header = "&L&A&R"
    default_footer = "&L&C&P of &N&R&D"

    _fill("oddHeader", sheet.header, default_header)
    _fill("oddFooter", sheet.footer, default_footer)
    _fill(
        "evenHeader",
        sheet.even_header if sheet.odd_even_different else None,
        None,
    )
    _fill(
        "evenFooter",
        sheet.even_footer if sheet.odd_even_different else None,
        None,
    )
    _fill(
        "firstHeader",
        sheet.first_header if sheet.first_page_different else None,
        None,
    )
    _fill(
        "firstFooter",
        sheet.first_footer if sheet.first_page_different else None,
        None,
    )


def _apply_default_columns(root: etree._Element) -> None:
    """Populate <cols> with three reasonable default widths."""
    cols_el = root.find(f"{{{SSML_NS}}}cols")
    if cols_el is None:
        return
    col_widths = [(1, 1, 15), (2, 2, 25), (3, 3, 30)]
    for min_col, max_col, width in col_widths:
        col_clone = clone_template_element(root, "col")
        replace_placeholders(
            col_clone,
            {"MIN": str(min_col), "MAX": str(max_col), "WIDTH": str(width)},
        )
        cols_el.append(col_clone)


def _populate_primary_sheet_data(
    emitter: ExcelEmitter,
    root: etree._Element,
    body: object,
) -> None:
    """Populate the primary sheet with the SummaryTable sample rows."""
    del body  # reserved for future typography-driven sample content
    _STYLE_INPUT = 38
    _STYLE_CALC = 40
    sheet_data = root.find(f"{{{SSML_NS}}}sheetData")
    if sheet_data is None:
        return
    rows: list[tuple[tuple[str, str, int | None], ...]] = []
    rows.append(tuple((c, "s", None) for c in emitter._TABLE_COLUMNS))
    for i, (cat, val, note) in enumerate(
        zip(emitter._SAMPLE_CATEGORIES, emitter._SAMPLE_VALUES, emitter._SAMPLE_NOTES)
    ):
        is_summary_row = i == len(emitter._SAMPLE_CATEGORIES) - 1
        style: int | None = _STYLE_CALC if is_summary_row else _STYLE_INPUT
        rows.append(
            (
                (cat, "s", None),
                (f"{val:g}", "n", style),
                (note, "s", None),
            )
        )

    for row_idx, row_cells in enumerate(rows, start=1):
        row_clone = clone_template_element(root, "row")
        replace_placeholders(row_clone, {"ROW_NUM": str(row_idx)})
        for child in list(row_clone):
            if child.get("data-template"):
                row_clone.remove(child)

        for col_idx, (value, cell_type, style_xf) in enumerate(row_cells):
            column = _col_index_to_letters(col_idx)
            cell_ref = f"{column}{row_idx}"
            cell_clone = clone_template_element(root, "cell")
            if cell_type == "n":
                is_el = cell_clone.find(f"{{{SSML_NS}}}is")
                if is_el is not None:
                    cell_clone.remove(is_el)
                cell_clone.set("r", cell_ref)
                if "t" in cell_clone.attrib:
                    del cell_clone.attrib["t"]
                v_el = etree.SubElement(cell_clone, f"{{{SSML_NS}}}v")
                v_el.text = value
            else:
                replace_placeholders(
                    cell_clone,
                    {"CELL_REF": cell_ref, "VALUE": html.escape(str(value))},
                )
            if style_xf is not None:
                cell_clone.set("s", str(style_xf))
            row_clone.append(cell_clone)

        sheet_data.append(row_clone)


def _wire_primary_drawing_and_table(root: etree._Element) -> None:
    """Bind the chart drawing (rId2) and SummaryTable (rId1)."""
    drawing_el = root.find(f"{{{SSML_NS}}}drawing")
    if drawing_el is not None:
        rns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        drawing_el.set(f"{{{rns}}}id", "rId2")

    table_parts = root.find(f"{{{SSML_NS}}}tableParts")
    if table_parts is not None:
        table_parts.set("count", "1")
        part_clone = clone_template_element(root, "table_part")
        replace_placeholders(part_clone, {"TABLE_RID": "rId1"})
        table_parts.append(part_clone)


def _strip_sample_sheet_decorations(root: etree._Element) -> None:
    """Remove SSOT sample autoFilter/sortState/etc. that overlap the table."""
    for tag in (
        "autoFilter",
        "sortState",
        "conditionalFormatting",
        "dataValidations",
    ):
        for el in root.findall(f"{{{SSML_NS}}}{tag}"):
            el.getparent().remove(el)  # type: ignore[union-attr]


def customize_theme_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    root = emitter.templates.read_tree("templates/theme.xml")
    theme = emitter.document.color_theme
    typo = emitter.document.typography

    emitter._set_color_value(root, "dk1", theme.dk1)
    emitter._set_color_value(root, "lt1", theme.lt1)
    emitter._set_color_value(root, "dk2", theme.dk2)
    emitter._set_color_value(root, "lt2", theme.lt2)
    emitter._set_color_value(root, "accent1", theme.accent1)
    emitter._set_color_value(root, "accent2", theme.accent2)
    emitter._set_color_value(root, "accent3", theme.accent3)
    emitter._set_color_value(root, "accent4", theme.accent4)
    emitter._set_color_value(root, "accent5", theme.accent5)
    emitter._set_color_value(root, "accent6", theme.accent6)
    emitter._set_color_value(root, "hlink", theme.hyperlink)
    emitter._set_color_value(root, "folHlink", theme.hyperlink_followed)

    emitter._set_font_typeface(root, "majorFont", "latin", typo.heading_font)
    emitter._set_font_typeface(root, "minorFont", "latin", typo.body_font)

    return emitter._serialize_tree(root)


def customize_core_props_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    timestamp = emitter._utc_timestamp()
    context = {
        "TITLE": emitter._get_document_title(),
        "CREATOR": "TokenMoulds",
        "MODIFIER": "TokenMoulds",
        "TIMESTAMP": timestamp,
    }
    return emitter._render_tree("templates/docprops_core.xml", context)


def customize_app_props_ssot(emitter: ExcelEmitter, data: bytes) -> bytes:
    context = {
        "APPLICATION": "TokenMoulds",
        "COMPANY": emitter.document.org_id,
    }
    return emitter._render_tree("templates/docprops_app.xml", context)
