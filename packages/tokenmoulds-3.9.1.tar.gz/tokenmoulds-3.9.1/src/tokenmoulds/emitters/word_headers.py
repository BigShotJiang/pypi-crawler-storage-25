"""Word HeaderFooterEmitter — produces header/footer parts for long-form sections.

Given :class:`LongFormSection` objects, this emitter loads the SSOT
header/footer XML templates, substitutes content slot values, allocates
relationship IDs, and returns a :class:`HeaderFooterBundle` containing
packaged entries and rId maps ready to drop into a ``.docx`` / ``.dotx``
archive.

Dedup: two sections sharing the same config name produce a single part
and a single rId — the Word emitter doesn't need to care.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from tokenmoulds.emitters.template_loader import TemplateResolver
from tokenmoulds.ir.long_form import HeaderFooterConfig, LongFormSection
from tokenmoulds.packaging.types import PackagedEntry
from tokenmoulds.semantic.content import SemanticContentInput
from tokenmoulds.semantic.lowerers.word import (
    ContentToken,
    lower_word_content_tokens,
)

# Style name → SSOT template filename.  Kept here rather than referencing
# BuiltinStyleDef.style_id to avoid an import cycle between emitters and
# the styles layer.
_STYLE_TO_TEMPLATE: dict[str, str] = {
    "HeaderMinimal": "header_minimal.xml",
    "HeaderRunning": "header_running.xml",
    "HeaderAppendix": "header_appendix.xml",
    "FooterCentered": "footer_centered.xml",
    "FooterOuter": "footer_outer.xml",
    "FooterFull": "footer_full.xml",
}

_TEMPLATE_RESOLVER = TemplateResolver("word")


def _load_all_templates() -> dict[str, bytes]:
    """Load every SSOT template once at module import.

    The files are small (< 1 KB) and never change at runtime, so caching
    their bytes avoids redundant disk reads per emit.
    """
    cache: dict[str, bytes] = {}
    for style_name, filename in _STYLE_TO_TEMPLATE.items():
        cache[style_name] = _TEMPLATE_RESOLVER.read_text(filename).encode("utf-8")
    cache["__header_fallback__"] = cache["HeaderMinimal"]
    cache["__footer_fallback__"] = cache["FooterCentered"]
    return cache


_TEMPLATE_CACHE = _load_all_templates()


def parse_content_spec(spec: SemanticContentInput) -> list[ContentToken]:
    """Compatibility wrapper for callers expecting Word/ODF content tokens."""
    return lower_word_content_tokens(spec)


@dataclass
class HeaderFooterBundle:
    """Result of building headers/footers for a long-form document.

    Carries everything the Word emitter needs to wire the new parts into
    the package: the archive entries themselves, and the rId maps the
    sectPr builder looks up by config name.
    """

    entries: list[PackagedEntry] = field(default_factory=list)
    header_part_for: dict[str, str] = field(default_factory=dict)
    footer_part_for: dict[str, str] = field(default_factory=dict)
    header_rid_map: dict[str, str] = field(default_factory=dict)
    footer_rid_map: dict[str, str] = field(default_factory=dict)


class HeaderFooterEmitter:
    """Builds Word header/footer parts from long-form section configs."""

    def __init__(self, document_title: str = "", *, rid_start: int = 100) -> None:
        self.document_title = document_title
        self.rid_start = rid_start

    def _load_template(self, style: str) -> bytes:
        if style in _TEMPLATE_CACHE:
            return _TEMPLATE_CACHE[style]
        fallback = (
            "__header_fallback__"
            if style.startswith("Header")
            else "__footer_fallback__"
        )
        return _TEMPLATE_CACHE[fallback]

    def _substitute(self, xml_bytes: bytes) -> bytes:
        """Replace ``${DOCUMENT_TITLE}`` with the real title (or empty)."""
        return xml_bytes.replace(
            b"${DOCUMENT_TITLE}", self.document_title.encode("utf-8")
        )

    def build_header_xml(self, config: HeaderFooterConfig) -> bytes:
        return self._substitute(self._load_template(config.style))

    def build_footer_xml(self, config: HeaderFooterConfig) -> bytes:
        return self._substitute(self._load_template(config.style))

    def build_packaged_entries(
        self, sections: list[LongFormSection]
    ) -> HeaderFooterBundle:
        """Build header/footer parts with dedup and rId allocation.

        Configs sharing a name across sections produce a single part and
        a single rId.  rIds start at ``rid_start`` (default 100) to stay
        clear of the base template's reserved rId1..rId7 range.
        """
        bundle = HeaderFooterBundle()
        if not sections:
            return bundle

        unique_headers: dict[str, HeaderFooterConfig] = {}
        unique_footers: dict[str, HeaderFooterConfig] = {}
        for section in sections:
            for cfg in section.all_header_configs:
                unique_headers.setdefault(cfg.name, cfg)
            for cfg in section.all_footer_configs:
                unique_footers.setdefault(cfg.name, cfg)

        rid_counter = self.rid_start
        for index, (name, cfg) in enumerate(unique_headers.items(), start=1):
            archive_path = f"word/header{index}.xml"
            bundle.entries.append(
                PackagedEntry(
                    archive_path=archive_path, data=self.build_header_xml(cfg)
                )
            )
            bundle.header_part_for[name] = archive_path
            bundle.header_rid_map[name] = f"rId{rid_counter}"
            rid_counter += 1

        for index, (name, cfg) in enumerate(unique_footers.items(), start=1):
            archive_path = f"word/footer{index}.xml"
            bundle.entries.append(
                PackagedEntry(
                    archive_path=archive_path, data=self.build_footer_xml(cfg)
                )
            )
            bundle.footer_part_for[name] = archive_path
            bundle.footer_rid_map[name] = f"rId{rid_counter}"
            rid_counter += 1

        return bundle
