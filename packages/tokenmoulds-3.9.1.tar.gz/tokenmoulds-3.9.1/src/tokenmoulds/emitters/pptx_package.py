"""Package-level PowerPoint emitter customizations.

Free functions taking the concrete ``PowerPointEmitter`` as their first
argument.
"""

from __future__ import annotations

import logging
from copy import deepcopy
from typing import TYPE_CHECKING, Dict, List

import lxml.etree as etree

from tokenmoulds.emitters.ooxml_base import EmbeddedFont
from tokenmoulds.emitters.pptx_layout import get_slide_dimensions_emu
from tokenmoulds.emitters.pptx_master import add_extra_color_schemes
from tokenmoulds.design.page_geometry import (
    create_slide_grid,
    page_geometry_from_locale,
)
from tokenmoulds.emitters.xml_helpers import (
    clone_template_element,
    remove_template_elements,
    replace_placeholders,
)

if TYPE_CHECKING:
    from tokenmoulds.emitters.powerpoint import PowerPointEmitter

logger = logging.getLogger(__name__)

PRESENTATIONML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
SLIDE_LAYOUT_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
)
THEME_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
)
STANDARD_LAYOUT_NUMBER_BY_NAME = {
    "title_slide": 1,
    "title_content": 2,
    "section_header": 3,
    "two_content": 4,
    "comparison": 5,
    "title_only": 6,
    "blank": 7,
    "content_caption": 8,
    "picture_caption": 9,
    "vertical_text": 10,
    "vertical_title": 11,
}
IMAGE_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
)
HANDOUT_MASTER_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/handoutMaster"
)


def customize_content_types_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize [Content_Types].xml by appending proper XML elements."""
    import lxml.etree as ET

    CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
    root = emitter.templates.read_tree("ssot/content_types.xml")

    # Swap content type for .pptx output
    if emitter._output_format == "pptx":
        for override in root.findall(f"{{{CT_NS}}}Override"):
            ct = override.get("ContentType", "")
            if "template.main+xml" in ct:
                override.set(
                    "ContentType",
                    ct.replace("template.main+xml", "presentation.main+xml"),
                )

    # Remove placeholder text if present (may be in text or tail)
    for elem in root.iter():
        if elem.text and "${EXTRA_CONTENT_TYPES}" in elem.text:
            elem.text = elem.text.replace("${EXTRA_CONTENT_TYPES}", "").strip() or None
        if elem.tail and "${EXTRA_CONTENT_TYPES}" in elem.tail:
            elem.tail = elem.tail.replace("${EXTRA_CONTENT_TYPES}", "").strip() or None

    # Append slide layout content types as proper elements
    for layout_number in emitter.DEFAULT_SLIDE_LAYOUT_NUMBERS[1:]:
        override = ET.SubElement(root, f"{{{CT_NS}}}Override")
        override.set(
            "PartName",
            f"/ppt/slideLayouts/slideLayout{layout_number}.xml",
        )
        override.set(
            "ContentType",
            "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml",
        )

    handout_master_override = ET.SubElement(root, f"{{{CT_NS}}}Override")
    handout_master_override.set(
        "PartName",
        "/ppt/handoutMasters/handoutMaster1.xml",
    )
    handout_master_override.set(
        "ContentType",
        "application/vnd.openxmlformats-officedocument.presentationml.handoutMaster+xml",
    )

    # Append media content types
    existing_defaults = {
        default.get("Extension")
        for default in root.findall(f"{{{CT_NS}}}Default")
        if default.get("Extension")
    }
    for asset in emitter._slide_media_assets:
        extension = asset.archive_path.rsplit(".", 1)[-1].lower()
        if extension in existing_defaults:
            continue
        default = ET.SubElement(root, f"{{{CT_NS}}}Default")
        default.set("Extension", extension)
        default.set("ContentType", asset.content_type)
        existing_defaults.add(extension)

    # Append font content type if embedding
    if emitter.embed_fonts and emitter.embedded_fonts:
        default = ET.SubElement(root, f"{{{CT_NS}}}Default")
        default.set("Extension", "fntdata")
        default.set("ContentType", "application/x-fontdata")

    from tokenmoulds.emitters.xml_helpers_template import serialize_tree

    return serialize_tree(root)


def customize_presentation_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize ppt/presentation.xml via SSOT clone pattern."""
    P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
    R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    P15_NS = "http://schemas.microsoft.com/office/powerpoint/2012/main"

    root = emitter.templates.read_tree("ssot/presentation.xml")
    ext_lst_template = clone_template_element(root, "ext_lst")
    slide_width, slide_height = get_slide_dimensions_emu(emitter)
    baseline_grid_emu = int(emitter.document.typography.baseline_emu or 152400)
    notes_geometry = page_geometry_from_locale(
        emitter.document.locale,
        baseline_grid_emu=baseline_grid_emu,
    )
    notes_grid = create_slide_grid(
        slide_width_emu=notes_geometry.width_emu,
        slide_height_emu=notes_geometry.height_emu,
        baseline_grid_emu=baseline_grid_emu,
    )
    replace_placeholders(
        root,
        {
            "SLIDE_WIDTH": str(slide_width),
            "SLIDE_HEIGHT": str(slide_height),
            "HANDOUT_MASTER_RID": "rId7",
        },
    )

    sld_master_lst = root.find(f"{{{P_NS}}}sldMasterIdLst")
    if sld_master_lst is not None:
        master_clone = clone_template_element(root, "sld_master_id")
        if master_clone is not None:
            master_clone.set("id", "2147483648")
            master_clone.set(f"{{{R_NS}}}id", "rId1")
            sld_master_lst.append(master_clone)

    sld_id_lst = root.find(f"{{{P_NS}}}sldIdLst")
    if sld_id_lst is not None:
        slide_clone = clone_template_element(root, "sld_id")
        if slide_clone is not None:
            slide_clone.set("id", "256")
            slide_clone.set(f"{{{R_NS}}}id", "rId2")
            sld_id_lst.append(slide_clone)

    handout_master_lst = root.find(f"{{{P_NS}}}handoutMasterIdLst")
    if handout_master_lst is not None:
        handout_clone = clone_template_element(root, "handout_master_id")
        if handout_clone is not None:
            handout_clone.set(f"{{{R_NS}}}id", "rId7")
            handout_master_lst.append(handout_clone)

    notes_sz = root.find(f"{{{P_NS}}}notesSz")
    if notes_sz is not None and notes_geometry is not None:
        notes_sz.set("cx", str(notes_geometry.width_emu))
        notes_sz.set("cy", str(notes_geometry.height_emu))

    notes_guide_lst = ext_lst_template.find(f".//{{{P15_NS}}}notesGuideLst")
    if notes_guide_lst is not None:
        notes_guide_template = clone_template_element(root, "notes_guide")
        slide_guide_lst = ext_lst_template.find(f".//{{{P15_NS}}}sldGuideLst")
        if slide_guide_lst is not None:
            slide_guide_parent = slide_guide_lst.getparent()
            if slide_guide_parent is not None:
                ext_lst_template.remove(slide_guide_parent)
        for child in list(notes_guide_lst):
            notes_guide_lst.remove(child)

        guide_id = 1
        for column_index in range(notes_grid.columns + 1):
            guide = deepcopy(notes_guide_template)
            guide.set("id", str(guide_id))
            guide.set("orient", "vert")
            guide.set(
                "pos",
                str(
                    notes_grid.margin_left_emu
                    + column_index * notes_grid.column_module_emu
                ),
            )
            guide.set("userDrawn", "1")
            notes_guide_lst.append(guide)
            guide_id += 1

        for row_index in range(notes_grid.rows + 1):
            guide = deepcopy(notes_guide_template)
            guide.set("id", str(guide_id))
            guide.set("orient", "horz")
            guide.set(
                "pos",
                str(notes_grid.margin_top_emu + row_index * notes_grid.row_module_emu),
            )
            guide.set("userDrawn", "1")
            notes_guide_lst.append(guide)
            guide_id += 1

    for list_name in ["notesMasterIdLst", "custShowLst"]:
        lst_el = root.find(f"{{{P_NS}}}{list_name}")
        if lst_el is not None:
            has_non_template_children = any(
                "data-template" not in child.attrib for child in lst_el
            )
            if not has_non_template_children:
                root.remove(lst_el)

    for el_name in ["smartTags", "photoAlbum", "kinsoku", "custDataLst"]:
        el = root.find(f"{{{P_NS}}}{el_name}")
        if el is not None:
            root.remove(el)

    if emitter.embed_fonts and emitter.embedded_fonts:
        _build_embedded_fonts_from_template(emitter, root)
    else:
        font_lst = root.find(f"{{{P_NS}}}embeddedFontLst")
        if font_lst is not None:
            root.remove(font_lst)

    remove_template_elements(root)
    if notes_guide_lst is not None:
        root.append(ext_lst_template)

    return emitter._serialize_tree(root)


def _build_embedded_fonts_from_template(
    emitter: PowerPointEmitter, root: etree._Element
) -> None:
    """Build embeddedFontLst using SSOT clone pattern."""
    P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"

    font_lst = root.find(f"{{{P_NS}}}embeddedFontLst")
    if font_lst is None:
        return

    if "data-template" in font_lst.attrib:
        del font_lst.attrib["data-template"]

    fonts_by_family: Dict[str, List[EmbeddedFont]] = {}
    for font in emitter.embedded_fonts:
        if font.family_name not in fonts_by_family:
            fonts_by_family[font.family_name] = []
        fonts_by_family[font.family_name].append(font)

    for family_name, fonts in fonts_by_family.items():
        embed_clone = clone_template_element(root, "embedded_font")

        font_el = embed_clone.find(f"{{{P_NS}}}font")
        if font_el is not None:
            font_el.set("typeface", family_name)
            font_el.set("panose", "020B0604020202020204")
            font_el.set("pitchFamily", "34")
            font_el.set("charset", "0")

        for child in list(embed_clone):
            if child.get("data-template") in (
                "regular",
                "bold",
                "italic",
                "bold_italic",
            ):
                embed_clone.remove(child)

        for font in fonts:
            if font.is_bold and font.is_italic:
                ref_clone = clone_template_element(root, "bold_italic")
            elif font.is_bold:
                ref_clone = clone_template_element(root, "bold")
            elif font.is_italic:
                ref_clone = clone_template_element(root, "italic")
            else:
                ref_clone = clone_template_element(root, "regular")

            replace_placeholders(ref_clone, {"REL_ID": font.relationship_id})
            embed_clone.append(ref_clone)

        font_lst.append(embed_clone)


def customize_presentation_rels_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize ppt/_rels/presentation.xml.rels via SSOT clone pattern."""
    root = emitter.templates.read_tree("ssot/presentation_rels.xml")

    handout_master_rel = clone_template_element(root, "handout_master_relationship")
    replace_placeholders(handout_master_rel, {"REL_ID": "rId7"})
    root.append(handout_master_rel)

    if emitter.embed_fonts and emitter.embedded_fonts:
        for font in emitter.embedded_fonts:
            rel_clone = clone_template_element(root, "font_relationship")
            replace_placeholders(
                rel_clone,
                {
                    "REL_ID": font.relationship_id,
                    "FILENAME": font.fntdata_filename,
                },
            )
            root.append(rel_clone)

    remove_template_elements(root)

    return emitter._serialize_tree(root)


def customize_slide_master_rels_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize the slide master relationships for the full layout set."""
    root = emitter.templates.read_tree("ssot/slide_master_rels.xml")
    template_relationships = root.findall(f"{{{PACKAGE_REL_NS}}}Relationship")
    layout_template = next(
        rel
        for rel in template_relationships
        if rel.get("Type") == SLIDE_LAYOUT_REL_TYPE
    )
    theme_relationship = next(
        rel for rel in template_relationships if rel.get("Type") == THEME_REL_TYPE
    )

    for rel in template_relationships:
        root.remove(rel)

    for rel_index, layout_number in enumerate(
        emitter.DEFAULT_SLIDE_LAYOUT_NUMBERS, start=1
    ):
        layout_relationship = deepcopy(layout_template)
        layout_relationship.set("Id", f"rId{rel_index}")
        layout_relationship.set(
            "Target", f"../slideLayouts/slideLayout{layout_number}.xml"
        )
        root.append(layout_relationship)

    theme_rel_id = len(emitter.DEFAULT_SLIDE_LAYOUT_NUMBERS) + 1
    theme_relationship = deepcopy(theme_relationship)
    theme_relationship.set("Id", f"rId{theme_rel_id}")
    root.append(theme_relationship)

    return emitter._serialize_tree(root)


def customize_theme_ssot(emitter: PowerPointEmitter, data: bytes) -> bytes:
    """Customize theme via lxml DOM manipulation with cached template."""
    root = emitter.templates.read_tree("ssot/theme.xml")
    theme = emitter.document.color_theme
    typo = emitter.document.typography

    if emitter.use_pure_text_colors:
        emitter._set_color_value(root, "dk1", "000000")
        emitter._set_color_value(root, "lt1", "FFFFFF")
    else:
        emitter._set_color_value(root, "dk1", theme.dk1)
        emitter._set_color_value(root, "lt1", theme.lt1)

    emitter._set_color_value(root, "dk2", theme.dk2)
    emitter._set_color_value(root, "lt2", theme.lt2)
    emitter._set_color_value(root, "accent1", theme.accent1)
    emitter._set_color_value(root, "accent2", theme.accent2)
    emitter._set_color_value(root, "accent3", theme.accent3)
    emitter._set_color_value(root, "accent4", theme.accent4)
    emitter._set_color_value(root, "accent5", theme.accent5)
    emitter._set_color_value(root, "accent6", theme.accent6)
    emitter._set_color_value(root, "hlink", theme.hyperlink)
    emitter._set_color_value(root, "folHlink", theme.hyperlink_followed)

    emitter._set_font_typeface(root, "majorFont", "latin", typo.heading_font)
    emitter._set_font_typeface(root, "minorFont", "latin", typo.body_font)

    if emitter.extra_color_themes:
        add_extra_color_schemes(emitter, root)
        logger.info(f"Added {len(emitter.extra_color_themes)} extra color themes")

    remove_template_elements(root)

    return emitter._serialize_tree(root)
