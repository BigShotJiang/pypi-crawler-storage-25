"""Presentation layout construction for DocumentIR builder."""

from __future__ import annotations

from typing import Any, Dict, List

from tokenmoulds.design.units import pt_to_emu as _pt_to_emu
from tokenmoulds.ir.model import (
    PresentationLayout,
    SemanticSlideDecoration,
    SlidePlaceholder,
)

try:
    from tokenmoulds.design.layout_defaults import (
        DEFAULT_BASELINE_EMU as _DEFAULT_BASELINE_EMU,
    )
except Exception:  # pragma: no cover
    _DEFAULT_BASELINE_EMU = 152400


def _build_presentation_layout(tokens: Dict[str, Dict]) -> PresentationLayout:
    from tokenmoulds.design.layout_defaults import (
        SLIDE_4_3_HEIGHT_EMU,
        SLIDE_4_3_WIDTH_EMU,
    )
    from tokenmoulds.design.page_geometry import create_slide_grid
    from tokenmoulds.dtcg.layout_recipe_defaults import compute_default_slide_regions
    from tokenmoulds.dtcg.layout_recipe_resolver import resolve_layout_by_name

    def _unwrap(value: Any) -> Any:
        if isinstance(value, dict):
            if "$value" in value:
                return _unwrap(value["$value"])
            return {
                key: _unwrap(item)
                for key, item in value.items()
                if not key.startswith("$")
            }
        return value

    def _normalize_fill(fill_tokens: Any) -> Dict[str, object] | None:
        if not isinstance(fill_tokens, dict):
            return None
        normalized = {
            key: _unwrap(value)
            for key, value in fill_tokens.items()
            if not key.startswith("$")
        }
        if not normalized.get("type"):
            return None
        return normalized

    def _merge_layout_region_map(
        defaults: Dict[str, Dict[str, Any]],
        overrides: Any,
    ) -> Dict[str, Dict[str, Any]]:
        merged = {
            layout_name: {
                region_name: (
                    dict(region_value)
                    if isinstance(region_value, dict)
                    else region_value
                )
                for region_name, region_value in layout_regions.items()
            }
            for layout_name, layout_regions in defaults.items()
        }
        if not isinstance(overrides, dict):
            return merged

        for layout_name, layout_regions in overrides.items():
            if not isinstance(layout_regions, dict):
                continue
            merged_layout = merged.setdefault(layout_name, {})
            for region_name, region_value in layout_regions.items():
                if isinstance(region_value, dict) and isinstance(
                    merged_layout.get(region_name), dict
                ):
                    updated = dict(merged_layout[region_name])
                    updated.update(region_value)
                    merged_layout[region_name] = updated
                else:
                    merged_layout[region_name] = region_value

        return merged

    def _build_decorative_fills(
        layout_name: str,
        fills: Dict[str, Any],
    ) -> Dict[str, Dict[str, object]]:
        decorative: Dict[str, Dict[str, object]] = {}

        if layout_name == "hero_cover":
            background_fill = _normalize_fill(
                fills.get("hero_background") or fills.get("hero")
            )
            if background_fill is None:
                background_fill = {
                    "type": "gradient",
                    "from": "dk1",
                    "to": "accent1",
                    "angle": 315,
                    "opacity": 1.0,
                }
            overlay_fill = _normalize_fill(fills.get("hero_overlay"))
            if overlay_fill is None:
                overlay_fill = {
                    "type": "solid",
                    "color": "dk1",
                    "opacity": 0.42,
                }
            decorative["background"] = background_fill
            decorative["overlay"] = overlay_fill
            return decorative

        if layout_name == "section_statement":
            background_fill = _normalize_fill(fills.get("section_background"))
            if background_fill is None:
                background_fill = {
                    "type": "solid",
                    "color": "lt1",
                    "opacity": 1.0,
                }
            band_fill = _normalize_fill(
                fills.get("section_band") or fills.get("accent")
            )
            if band_fill is None:
                band_fill = {
                    "type": "solid",
                    "color": "accent1",
                    "opacity": 0.18,
                }
            decorative["background"] = background_fill
            decorative["band"] = band_fill
            return decorative

        if layout_name == "card_matrix":
            card_fill = _normalize_fill(fills.get("card_surface"))
            if card_fill is None:
                card_fill = {
                    "type": "solid",
                    "color": "lt1",
                    "opacity": 1.0,
                }
            for region_name in ("card_1", "card_2", "card_3", "card_4"):
                decorative[region_name] = dict(card_fill)

        return decorative

    def _seed_layout_name() -> str:
        presentation = tokens.get("presentation", {})
        layout_slide = tokens.get("layout", {}).get("slide", {})
        candidate = _unwrap(
            presentation.get("seed_layout") or layout_slide.get("seed_layout")
        )
        if isinstance(candidate, str) and candidate:
            return candidate
        return "title_content"

    def _brand_tone() -> float:
        raw = _unwrap(
            tokens.get("brand_tone")
            or tokens.get("inputs", {}).get("brand_tone")
            or tokens.get("inputs", {}).get("number", {}).get("brandTone")
        )
        try:
            return float(raw)
        except (TypeError, ValueError):
            return 0.5

    grid = tokens.get("grid", {})
    spacing_tokens = tokens.get("spacing", {})
    spacing_scale = spacing_tokens.get("scale_pt", {})

    slide_width = SLIDE_4_3_WIDTH_EMU  # 10in slide width (4:3)
    slide_height = SLIDE_4_3_HEIGHT_EMU  # 7.5in slide height

    margins = grid.get("margins", {})
    margin_x = int(margins.get("left_emu", slide_width * 0.08))
    margin_y = int(margins.get("top_emu", slide_height * 0.08))

    margin_x = min(max(margin_x, int(slide_width * 0.04)), int(slide_width * 0.3))
    margin_y = min(max(margin_y, int(slide_height * 0.04)), int(slide_height * 0.3))

    usable_width = max(slide_width - (2 * margin_x), slide_width // 2)
    usable_height = max(slide_height - (2 * margin_y), slide_height // 2)

    gap = _pt_to_emu(float(spacing_scale.get("space_2", 8.0)))

    title_height = int(usable_height * 0.25)
    body_height = int(usable_height * 0.45)
    remaining = usable_height - title_height - body_height - (2 * gap)
    min_table_height = _pt_to_emu(72)
    table_height = max(remaining, min_table_height)

    total_needed = title_height + body_height + table_height + (2 * gap)
    if total_needed > usable_height:
        overflow = total_needed - usable_height
        table_height = max(min_table_height, table_height - overflow)

    placeholders: List[SlidePlaceholder] = []
    current_y = margin_y
    placeholders.append(
        SlidePlaceholder(
            kind="title",
            x=margin_x,
            y=current_y,
            cx=usable_width,
            cy=title_height,
            text_style="heading",
            level=0,
        )
    )
    current_y += title_height + gap
    placeholders.append(
        SlidePlaceholder(
            kind="body",
            x=margin_x,
            y=current_y,
            cx=usable_width,
            cy=body_height,
            text_style="body",
            level=1,
        )
    )
    current_y += body_height + gap
    placeholders.append(
        SlidePlaceholder(
            kind="table",
            x=margin_x,
            y=current_y,
            cx=usable_width,
            cy=table_height,
            text_style="table",
            level=0,
        )
    )

    colors = tokens.get("colors", {})
    palette = colors.get("palette", {})
    neutral = palette.get("neutral", {})
    from tokenmoulds.design.color_defaults import SURFACE_WHITE

    background = neutral.get("white", SURFACE_WHITE)

    layout_slide = tokens.get("layout", {}).get("slide", {})
    baseline_emu = int(
        tokens.get("typography", {}).get("baseline_emu", _DEFAULT_BASELINE_EMU)
    )
    slide_grid = create_slide_grid(
        slide_width_emu=slide_width,
        slide_height_emu=slide_height,
        baseline_grid_emu=baseline_emu,
    )
    default_regions = compute_default_slide_regions(
        slide_grid, brand_tone=_brand_tone()
    )
    token_regions = layout_slide.get("regions")
    generated_token_defaults = compute_default_slide_regions(
        baseline_emu, brand_tone=_brand_tone()
    )
    if token_regions == generated_token_defaults:
        slide_regions = default_regions
    else:
        slide_regions = _merge_layout_region_map(default_regions, token_regions)
    layout_name = _seed_layout_name()
    selected_regions = (
        slide_regions.get(layout_name)
        if isinstance(slide_regions, dict)
        else default_regions.get(layout_name)
    )
    if not isinstance(selected_regions, dict):
        layout_name = "title_content"
        selected_regions = default_regions["title_content"]
    resolved_regions = resolve_layout_by_name(layout_name, selected_regions, slide_grid)
    layout_regions = {
        name: resolve_layout_by_name(name, regions, slide_grid)
        for name, regions in slide_regions.items()
        if isinstance(regions, dict)
    }

    fills = tokens.get("fills", {})
    decorative_fills = _build_decorative_fills(layout_name, fills)
    decoration = SemanticSlideDecoration(
        decorative_fills=decorative_fills,
        background_fill=decorative_fills.get("background"),
        overlay_fill=decorative_fills.get("overlay"),
    )

    return PresentationLayout(
        slide_width=slide_width,
        slide_height=slide_height,
        background_color=background,
        placeholders=placeholders,
        layout_name=layout_name,
        regions=resolved_regions,
        layout_regions=layout_regions,
        decoration=decoration,
    )
