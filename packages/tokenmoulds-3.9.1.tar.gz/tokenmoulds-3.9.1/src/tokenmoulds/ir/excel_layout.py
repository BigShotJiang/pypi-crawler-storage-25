"""Excel-specific IR dataclasses (multi-sheet workbook layout).

Mirrors the long_form module for Word/Writer: fully resolved
per-sheet configuration consumed by the Excel emitter.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from tokenmoulds.ir.long_form import (
    HeaderFooterConfig,
    NamedMargins,
    NamedPageGeometry,
)

# Role tags drive which sample content template a sheet receives.
# "primary" gets the table + themed chart; "content" gets simple
# headings and body paragraphs without decorative parts.
SheetRole = Literal["primary", "content"]


@dataclass(frozen=True)
class ExcelSheet:
    """Per-sheet configuration for a multi-sheet Excel workbook.

    Reuses the long-form ``HeaderFooterConfig`` vocabulary so a brand's
    header/footer library stays format-agnostic — the Excel emitter
    translates its content slots to ``&L``/``&C``/``&R`` field codes.

    Print area and print titles use the Excel A1 / `$1:$1` notation and
    are promoted into ``xl/workbook.xml`` as ``_xlnm.Print_Area`` and
    ``_xlnm.Print_Titles`` defined names scoped to the sheet.
    """

    name: str
    role: SheetRole = "content"
    tab_color_theme: int | None = None
    sample_heading: str | None = None
    sample_body: str | None = None

    # Print fidelity (phase 2c)
    page_geometry: NamedPageGeometry | None = None
    margins: NamedMargins | None = None
    fit_to_width: int = 1
    fit_to_height: int = 1
    scale: int = 100  # percent; ignored when fit_to_* are set

    header: HeaderFooterConfig | None = None
    footer: HeaderFooterConfig | None = None
    odd_even_different: bool = False
    first_page_different: bool = False
    even_header: HeaderFooterConfig | None = None
    even_footer: HeaderFooterConfig | None = None
    first_header: HeaderFooterConfig | None = None
    first_footer: HeaderFooterConfig | None = None

    # Print area and print titles use Excel A1 notation. Examples:
    #   print_area = "A1:Z100"
    #   print_titles_rows = "$1:$1"    -> repeat row 1
    #   print_titles_cols = "$A:$A"    -> repeat column A
    print_area: str | None = None
    print_titles_rows: str | None = None
    print_titles_cols: str | None = None
