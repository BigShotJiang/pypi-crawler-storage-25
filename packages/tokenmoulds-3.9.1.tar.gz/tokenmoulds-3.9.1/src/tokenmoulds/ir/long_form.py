"""IR dataclasses for long-form documents (sections, headers, footers).

Phase 1 of the long-form document layer.  These types hold the resolved
output of the long_form_resolver, ready for Word and Writer emission.

Unit convention — **pt throughout**.  Tokens are pt, IR is pt, and
emitters convert to their format's serialization unit at the write
boundary: twips for OOXML, cm for ODF, EMU for DrawingML.  No EMU or
twips leak into this layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from tokenmoulds.semantic.content import (
    SemanticContent,
    SemanticContentInput,
    ensure_semantic_content,
    to_legacy_content_spec,
)

PageOrientation = Literal["portrait", "landscape"]

PageNumberFormat = Literal[
    "decimal",
    "lowerRoman",
    "upperRoman",
    "lowerLetter",
    "upperLetter",
    "none",
]

HeaderFooterPosition = Literal[
    "center_footer",
    "outer_footer",
    "inner_footer",
    "center_header",
    "outer_header",
    "inner_header",
]
HeaderFooterSlot = Literal["left", "center", "right", "outer", "inner"]


def _normalize_header_footer_slot(
    value: SemanticContentInput,
) -> SemanticContent | None:
    content = ensure_semantic_content(value)
    return content if content.items else None


@dataclass(frozen=True)
class NamedPageGeometry:
    """Token-level primitive for a named page size and orientation.

    Dimensions in pt (the PostScript convention — A4 is 595 × 842 pt).
    Not to be confused with ``design.page_geometry.PageGeometry`` which
    is the legacy short-form section type holding EMU.
    """

    name: str
    width_pt: float
    height_pt: float
    orientation: PageOrientation


@dataclass(frozen=True)
class NamedMargins:
    """Token-level primitive for a named margin preset, in pt.

    Mirror margins use ``outer_pt`` / ``inner_pt`` (for book layouts).
    Non-mirror layouts use ``left_pt`` / ``right_pt``.
    """

    name: str
    top_pt: float
    bottom_pt: float
    left_pt: float | None = None
    right_pt: float | None = None
    outer_pt: float | None = None
    inner_pt: float | None = None
    gutter_pt: float = 0.0
    mirror: bool = False

    def resolve_left(self) -> float:
        """Return the effective left margin in pt (left_pt or inner_pt)."""
        if self.left_pt is not None:
            return self.left_pt
        if self.inner_pt is not None:
            return self.inner_pt
        return 0.0

    def resolve_right(self) -> float:
        """Return the effective right margin in pt (right_pt or outer_pt)."""
        if self.right_pt is not None:
            return self.right_pt
        if self.outer_pt is not None:
            return self.outer_pt
        return 0.0


@dataclass(frozen=True)
class PageNumberConfig:
    """Per-section page numbering configuration."""

    format: PageNumberFormat = "decimal"
    restart_at: int | Literal["continue"] = "continue"
    visible: bool = True
    position: HeaderFooterPosition = "center_footer"


@dataclass(frozen=True, init=False)
class HeaderFooterConfig:
    """A named header or footer composition.

    Content slots hold strings that the emitters parse as field
    instructions or literal text:

    - ``"PAGE"`` → current page number field
    - ``"NUMPAGES"`` → total pages field
    - ``"PAGE of NUMPAGES"`` → compound
    - ``"STYLEREF:Heading1"`` → running chapter title field
    - ``"{document.title}"`` → static document title
    - ``"DATE"`` / ``"TIME"`` / ``"FILENAME"`` / ``"SHEETNAME"`` →
      format-specific fields where supported
    - any other string → literal text
    """

    name: str
    style: str
    left: SemanticContent | None
    center: SemanticContent | None
    right: SemanticContent | None
    outer: SemanticContent | None
    inner: SemanticContent | None
    rule_top: str | bool
    rule_bottom: str | bool
    align: str | None

    def __init__(
        self,
        name: str,
        style: str,
        content_left: SemanticContentInput = None,
        content_center: SemanticContentInput = None,
        content_right: SemanticContentInput = None,
        content_outer: SemanticContentInput = None,
        content_inner: SemanticContentInput = None,
        rule_top: str | bool = False,
        rule_bottom: str | bool = False,
        align: str | None = None,
        *,
        left: SemanticContentInput = None,
        center: SemanticContentInput = None,
        right: SemanticContentInput = None,
        outer: SemanticContentInput = None,
        inner: SemanticContentInput = None,
    ) -> None:
        def _coalesce(
            canonical: SemanticContentInput,
            legacy: SemanticContentInput,
            slot: HeaderFooterSlot,
        ) -> SemanticContent | None:
            if canonical is not None and legacy is not None:
                raise ValueError(
                    f"HeaderFooterConfig slot {slot!r} cannot be set through both "
                    f"canonical and legacy arguments"
                )
            return _normalize_header_footer_slot(
                canonical if canonical is not None else legacy
            )

        object.__setattr__(self, "name", name)
        object.__setattr__(self, "style", style)
        object.__setattr__(self, "left", _coalesce(left, content_left, "left"))
        object.__setattr__(self, "center", _coalesce(center, content_center, "center"))
        object.__setattr__(self, "right", _coalesce(right, content_right, "right"))
        object.__setattr__(self, "outer", _coalesce(outer, content_outer, "outer"))
        object.__setattr__(self, "inner", _coalesce(inner, content_inner, "inner"))
        object.__setattr__(self, "rule_top", rule_top)
        object.__setattr__(self, "rule_bottom", rule_bottom)
        object.__setattr__(self, "align", align)

    @property
    def content_left(self) -> str | None:
        return self.slot_spec("left")

    @property
    def content_center(self) -> str | None:
        return self.slot_spec("center")

    @property
    def content_right(self) -> str | None:
        return self.slot_spec("right")

    @property
    def content_outer(self) -> str | None:
        return self.slot_spec("outer")

    @property
    def content_inner(self) -> str | None:
        return self.slot_spec("inner")

    def slot_spec(self, slot: HeaderFooterSlot) -> str | None:
        """Return the raw content string for a logical slot."""
        content = self.slot_content(slot)
        if content is None:
            return None
        return to_legacy_content_spec(content)

    def slot_content(self, slot: HeaderFooterSlot) -> SemanticContent | None:
        """Return semantic content for a logical slot or None when unset."""
        return getattr(self, slot)

    def semantic_content(self, slot: HeaderFooterSlot) -> SemanticContent:
        """Return semantic content for a logical slot."""
        return self.slot_content(slot) or SemanticContent()

    @property
    def semantic_left(self) -> SemanticContent:
        return self.semantic_content("left")

    @property
    def semantic_center(self) -> SemanticContent:
        return self.semantic_content("center")

    @property
    def semantic_right(self) -> SemanticContent:
        return self.semantic_content("right")

    @property
    def semantic_outer(self) -> SemanticContent:
        return self.semantic_content("outer")

    @property
    def semantic_inner(self) -> SemanticContent:
        return self.semantic_content("inner")


@dataclass(frozen=True)
class LongFormSection:
    """Fully-resolved per-section configuration for a long-form document.

    This is what the Word and Writer emitters read to produce
    ``w:sectPr`` / ``style:master-page`` output.
    """

    name: str
    page_geometry: NamedPageGeometry
    margins: NamedMargins
    columns: int = 1
    column_gap_pt: float = 36.0  # 0.5 inch default
    page_number: PageNumberConfig = field(default_factory=PageNumberConfig)

    header_ref: HeaderFooterConfig | None = None
    header_ref_odd: HeaderFooterConfig | None = None
    header_ref_even: HeaderFooterConfig | None = None
    header_ref_first: HeaderFooterConfig | None = None

    footer_ref: HeaderFooterConfig | None = None
    footer_ref_odd: HeaderFooterConfig | None = None
    footer_ref_even: HeaderFooterConfig | None = None
    footer_ref_first: HeaderFooterConfig | None = None

    first_page_different: bool = False
    odd_even_different: bool = False

    # Optional sample content for emitter-generated preview paragraphs.
    # Fills the Heading 1 and BodyText paragraphs that the Word/Writer
    # emitters inject when rendering a long-form template so the
    # preview document has meaningful per-section copy (e.g. "Table of
    # Contents" on front matter, "Executive Summary" on body).  When
    # None, the emitter uses a generic fallback.
    sample_heading: str | None = None
    sample_body: str | None = None

    @property
    def all_header_configs(self) -> tuple[HeaderFooterConfig, ...]:
        """All unique header configs on this section (non-None, deduped)."""
        seen: dict[str, HeaderFooterConfig] = {}
        for cfg in (
            self.header_ref,
            self.header_ref_odd,
            self.header_ref_even,
            self.header_ref_first,
        ):
            if cfg is not None and cfg.name not in seen:
                seen[cfg.name] = cfg
        return tuple(seen.values())

    @property
    def all_footer_configs(self) -> tuple[HeaderFooterConfig, ...]:
        """All unique footer configs on this section (non-None, deduped)."""
        seen: dict[str, HeaderFooterConfig] = {}
        for cfg in (
            self.footer_ref,
            self.footer_ref_odd,
            self.footer_ref_even,
            self.footer_ref_first,
        ):
            if cfg is not None and cfg.name not in seen:
                seen[cfg.name] = cfg
        return tuple(seen.values())
