"""Font-pair catalog domain model and parser."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True, slots=True)
class FontPairDiagnostic:
    """Parser diagnostic for a font-pair catalog."""

    severity: str
    code: str
    message: str
    source_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "source_path": self.source_path,
        }


@dataclass(frozen=True, slots=True)
class FontPairRole:
    """A semantic role within a font-pair record."""

    family: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"family": self.family, "metadata": self.metadata}


@dataclass(frozen=True, slots=True)
class FontPairRecord:
    """Canonical font-pair catalog entry."""

    id: str
    scope: str
    slug: str
    name: str
    heading: FontPairRole | None
    body: FontPairRole | None
    mono: FontPairRole | None = None
    source_path: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    diagnostics: tuple[FontPairDiagnostic, ...] = ()

    @property
    def errors(self) -> tuple[FontPairDiagnostic, ...]:
        return tuple(d for d in self.diagnostics if d.severity == "error")

    @property
    def warnings(self) -> tuple[FontPairDiagnostic, ...]:
        return tuple(d for d in self.diagnostics if d.severity == "warning")

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_legacy_pair(self) -> dict[str, str]:
        pair: dict[str, str] = {}
        if self.heading is not None:
            pair["serif"] = self.heading.family
        if self.body is not None:
            pair["sans"] = self.body.family
        if self.mono is not None:
            pair["mono"] = self.mono.family
        return pair

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "scope": self.scope,
            "slug": self.slug,
            "name": self.name,
            "heading": self.heading.to_dict() if self.heading else None,
            "body": self.body.to_dict() if self.body else None,
            "mono": self.mono.to_dict() if self.mono else None,
            "source_path": self.source_path,
            "metadata": self.metadata,
            "diagnostics": [d.to_dict() for d in self.diagnostics],
        }


@dataclass(frozen=True, slots=True)
class FontPairCatalog:
    """Parsed font-pair catalog with diagnostics."""

    records: tuple[FontPairRecord, ...] = ()
    diagnostics: tuple[FontPairDiagnostic, ...] = ()

    @property
    def errors(self) -> tuple[FontPairDiagnostic, ...]:
        record_errors = tuple(
            error for record in self.records for error in record.errors
        )
        catalog_errors = tuple(d for d in self.diagnostics if d.severity == "error")
        return catalog_errors + record_errors

    @property
    def warnings(self) -> tuple[FontPairDiagnostic, ...]:
        record_warnings = tuple(
            warning for record in self.records for warning in record.warnings
        )
        catalog_warnings = tuple(d for d in self.diagnostics if d.severity == "warning")
        return catalog_warnings + record_warnings

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_legacy_pairs(self) -> dict[str, dict[str, str]]:
        duplicate_counts: dict[str, int] = {}
        for record in self.records:
            duplicate_counts[record.slug] = duplicate_counts.get(record.slug, 0) + 1

        pairs: dict[str, dict[str, str]] = {}
        for record in self.records:
            pair = record.to_legacy_pair()
            if "sans" not in pair or "serif" not in pair:
                continue
            pairs[record.id] = pair
            if duplicate_counts.get(record.slug, 0) == 1:
                pairs[record.slug] = dict(pair)
        return pairs

    def to_dict(self) -> dict[str, Any]:
        return {
            "records": [record.to_dict() for record in self.records],
            "diagnostics": [diagnostic.to_dict() for diagnostic in self.diagnostics],
        }


def load_font_pair_catalog(catalog_path: str | Path) -> FontPairCatalog:
    """Load a font-pair catalog from a YAML file or directory."""
    base_path = Path(catalog_path).expanduser()
    diagnostics: list[FontPairDiagnostic] = []
    records: list[FontPairRecord] = []

    if not base_path.exists():
        return FontPairCatalog(
            diagnostics=(
                _diagnostic(
                    "error",
                    "missing_catalog_path",
                    f"Font-pair catalog path does not exist: {base_path}",
                    base_path,
                ),
            )
        )

    files = _catalog_files(base_path)
    if not files:
        return FontPairCatalog(
            diagnostics=(
                _diagnostic(
                    "error",
                    "empty_catalog",
                    f"No font-pair YAML files found in {base_path}",
                    base_path,
                ),
            )
        )

    for path in files:
        parsed_records, parsed_diagnostics = _load_catalog_file(path)
        records.extend(parsed_records)
        diagnostics.extend(parsed_diagnostics)

    if not records and not any(d.severity == "error" for d in diagnostics):
        diagnostics.append(
            _diagnostic(
                "error",
                "empty_catalog",
                f"No font-pair records found in {base_path}",
                base_path,
            )
        )

    diagnostics.extend(_duplicate_id_diagnostics(records))
    return FontPairCatalog(records=tuple(records), diagnostics=tuple(diagnostics))


def collect_legacy_font_pairs(catalog_path: str | Path) -> dict[str, dict[str, str]]:
    """Load catalog records as legacy `parse_font_pair()` mappings."""
    return load_font_pair_catalog(catalog_path).to_legacy_pairs()


def _catalog_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix.lower() in (".yaml", ".yml") else []
    return sorted(list(path.glob("*.yaml")) + list(path.glob("*.yml")))


def _load_catalog_file(
    path: Path,
) -> tuple[list[FontPairRecord], list[FontPairDiagnostic]]:
    diagnostics: list[FontPairDiagnostic] = []
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [], [
            _diagnostic(
                "error",
                "malformed_yaml",
                f"Could not parse YAML: {exc}",
                path,
            )
        ]

    if raw is None:
        return [], [
            _diagnostic("error", "empty_file", "Catalog YAML file is empty", path)
        ]

    entries = _catalog_entries(raw, path)
    records: list[FontPairRecord] = []
    for slug_hint, entry, entry_diagnostics in entries:
        diagnostics.extend(entry_diagnostics)
        if not isinstance(entry, dict):
            continue
        records.append(_record_from_entry(path, slug_hint, entry))
    return records, diagnostics


def _catalog_entries(
    raw: Any, path: Path
) -> list[tuple[str, dict[str, Any] | None, tuple[FontPairDiagnostic, ...]]]:
    entries: list[
        tuple[str, dict[str, Any] | None, tuple[FontPairDiagnostic, ...]]
    ] = []

    if isinstance(raw, list):
        for index, entry in enumerate(raw):
            if isinstance(entry, dict):
                entries.append(("", dict(entry), ()))
            else:
                entries.append(
                    (
                        "",
                        None,
                        (
                            _diagnostic(
                                "error",
                                "unsupported_entry",
                                f"List entry {index} is not a mapping",
                                path,
                            ),
                        ),
                    )
                )
        return entries

    if not isinstance(raw, dict):
        return [
            (
                "",
                None,
                (
                    _diagnostic(
                        "error",
                        "unsupported_catalog",
                        "Catalog root must be a list or mapping",
                        path,
                    ),
                ),
            )
        ]

    if "font_pairs" in raw:
        pairs = raw["font_pairs"]
        if not isinstance(pairs, dict):
            return [
                (
                    "",
                    None,
                    (
                        _diagnostic(
                            "error",
                            "unsupported_font_pairs",
                            "`font_pairs` must be a mapping",
                            path,
                        ),
                    ),
                )
            ]
        for pair_slug, pair in pairs.items():
            entries.append(_mapping_entry(pair_slug, pair, path))
        return entries

    for pair_slug, pair in raw.items():
        entries.append(_mapping_entry(pair_slug, pair, path))
    return entries


def _mapping_entry(
    pair_slug: Any, pair: Any, path: Path
) -> tuple[str, dict[str, Any] | None, tuple[FontPairDiagnostic, ...]]:
    slug = str(pair_slug)
    if not isinstance(pair, dict):
        return (
            slug,
            None,
            (
                _diagnostic(
                    "error",
                    "unsupported_entry",
                    f"Entry '{slug}' is not a mapping",
                    path,
                ),
            ),
        )
    entry = dict(pair)
    entry.setdefault("name", slug)
    return slug, entry, ()


def _record_from_entry(
    path: Path, slug_hint: str, entry: dict[str, Any]
) -> FontPairRecord:
    scope = path.stem
    name = str(entry.get("name") or slug_hint or "font-pair").strip()
    slug = _slugify(slug_hint or name or "font-pair")
    source_path = str(path)
    heading = _role_from_entry(
        entry,
        (
            "heading",
            "major",
            "display",
            "header",
            "sans",
            "heading_font",
            "display_font",
            "heading_family",
            "header_family",
        ),
    )
    body = _role_from_entry(
        entry,
        (
            "body",
            "minor",
            "text",
            "copy",
            "serif",
            "body_font",
            "paragraph_font",
            "copy_font",
            "body_family",
            "copy_family",
        ),
    )
    mono = _role_from_entry(entry, ("mono", "monospace", "mono_font", "mono_family"))
    diagnostics: list[FontPairDiagnostic] = []

    if heading is None:
        diagnostics.append(
            _diagnostic(
                "error",
                "missing_heading_family",
                f"Font pair '{scope}:{slug}' is missing a heading family",
                path,
            )
        )
    if body is None:
        diagnostics.append(
            _diagnostic(
                "error",
                "missing_body_family",
                f"Font pair '{scope}:{slug}' is missing a body family",
                path,
            )
        )

    return FontPairRecord(
        id=f"{scope}:{slug}",
        scope=scope,
        slug=slug,
        name=name,
        heading=heading,
        body=body,
        mono=mono,
        source_path=source_path,
        metadata=_record_metadata(entry),
        diagnostics=tuple(diagnostics),
    )


def _role_from_entry(
    entry: dict[str, Any], keys: tuple[str, ...]
) -> FontPairRole | None:
    fonts_node = entry.get("fonts")
    for key in keys:
        if key in entry:
            role = _role_from_node(entry[key])
            if role is not None:
                return role
        if isinstance(fonts_node, dict) and key in fonts_node:
            role = _role_from_node(fonts_node[key])
            if role is not None:
                return role
    return None


def _role_from_node(node: Any) -> FontPairRole | None:
    family = _normalize_font_family(node)
    if family:
        return FontPairRole(family=family)

    if not isinstance(node, dict):
        return None

    for key in ("family", "name", "font", "font_name", "fontFamily", "familyName"):
        family = _normalize_font_family(node.get(key))
        if family:
            return FontPairRole(
                family=family,
                metadata={k: v for k, v in node.items() if k != key},
            )

    if len(node) == 1:
        value = _normalize_font_family(next(iter(node.values())))
        if value:
            return FontPairRole(family=value)
    return None


def _record_metadata(entry: dict[str, Any]) -> dict[str, Any]:
    role_keys = {
        "name",
        "heading",
        "body",
        "major",
        "minor",
        "display",
        "header",
        "sans",
        "serif",
        "text",
        "copy",
        "mono",
        "monospace",
        "heading_font",
        "display_font",
        "heading_family",
        "header_family",
        "body_font",
        "paragraph_font",
        "copy_font",
        "body_family",
        "copy_family",
        "mono_font",
        "mono_family",
        "fonts",
    }
    return {key: value for key, value in entry.items() if key not in role_keys}


def _duplicate_id_diagnostics(
    records: list[FontPairRecord],
) -> list[FontPairDiagnostic]:
    counts: dict[str, int] = {}
    for record in records:
        counts[record.id] = counts.get(record.id, 0) + 1
    return [
        _diagnostic(
            "error",
            "duplicate_font_pair_id",
            f"Duplicate font-pair id '{record_id}'",
        )
        for record_id, count in sorted(counts.items())
        if count > 1
    ]


def _normalize_font_family(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip()


def _slugify(value: str) -> str:
    return re.sub(r"[^0-9a-z]+", "-", value.strip().lower()).strip("-")


def _diagnostic(
    severity: str, code: str, message: str, source_path: Path | None = None
) -> FontPairDiagnostic:
    return FontPairDiagnostic(
        severity=severity,
        code=code,
        message=message,
        source_path=str(source_path) if source_path else None,
    )
