"""Font asset audit records for font-pair validation."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tokenmoulds.fonts.service import FontMatch, FontQuery, FontService


@dataclass(frozen=True, slots=True)
class FontAssetAudit:
    """Evidence for one requested font face."""

    role: str
    requested_family: str
    requested_weight: int
    requested_style: str
    resolved_family: str | None
    resolved_weight: int | None
    resolved_style: str | None
    provider: str | None
    path: str | None
    source_url: str | None
    expected_sha256: str | None
    hash_verified: bool | None
    sha256: str | None
    size_bytes: int | None
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "requested_family": self.requested_family,
            "requested_weight": self.requested_weight,
            "requested_style": self.requested_style,
            "resolved_family": self.resolved_family,
            "resolved_weight": self.resolved_weight,
            "resolved_style": self.resolved_style,
            "provider": self.provider,
            "path": self.path,
            "source_url": self.source_url,
            "expected_sha256": self.expected_sha256,
            "hash_verified": self.hash_verified,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


def audit_font_face(
    service: FontService,
    *,
    role: str,
    family: str,
    weight: int,
    style: str = "normal",
    required: bool = True,
) -> FontAssetAudit:
    """Resolve and hash one requested font face."""
    match = service.find_font(FontQuery(family, weight=weight, style=style))
    if match is None:
        message = _missing_message(role, family, weight, style)
        return FontAssetAudit(
            role=role,
            requested_family=family,
            requested_weight=weight,
            requested_style=style,
            resolved_family=None,
            resolved_weight=None,
            resolved_style=None,
            provider=None,
            path=None,
            source_url=None,
            expected_sha256=None,
            hash_verified=None,
            sha256=None,
            size_bytes=None,
            errors=(message,) if required else (),
            warnings=() if required else (message,),
        )

    return _audit_match(role, family, weight, style, match, required=required)


def _audit_match(
    role: str,
    family: str,
    weight: int,
    style: str,
    match: FontMatch,
    *,
    required: bool,
) -> FontAssetAudit:
    warnings: list[str] = []
    errors: list[str] = []
    path = Path(match.path)
    sha256: str | None = None
    size_bytes: int | None = None
    hash_verified: bool | None = None

    try:
        data = path.read_bytes()
        sha256 = hashlib.sha256(data).hexdigest()
        size_bytes = len(data)
    except Exception as exc:
        errors.append(f"{role} family '{family}' could not be hashed: {exc}")

    if match.expected_sha256 and sha256:
        hash_verified = sha256.lower() == match.expected_sha256.lower()
        if not hash_verified:
            errors.append(
                f"{role} family '{family}' downloaded hash does not match expected SHA256"
            )

    if match.found_via == "downloaded" and not match.source_url:
        warnings.append(f"{role} family '{family}' downloaded without source URL")
    if match.found_via == "downloaded" and not match.expected_sha256:
        warnings.append(f"{role} family '{family}' is an unverified download")
    if match.found_via == "system":
        warnings.append(f"{role} family '{family}' resolved from system fonts")
    if not _satisfies_request(weight, style, match):
        message = _missing_message(role, family, weight, style)
        if required:
            errors.append(message)
        else:
            warnings.append(message)

    return FontAssetAudit(
        role=role,
        requested_family=family,
        requested_weight=weight,
        requested_style=style,
        resolved_family=match.family,
        resolved_weight=match.weight,
        resolved_style=match.style,
        provider=match.found_via,
        path=str(path),
        source_url=match.source_url,
        expected_sha256=match.expected_sha256,
        hash_verified=hash_verified,
        sha256=sha256,
        size_bytes=size_bytes,
        errors=tuple(errors),
        warnings=tuple(warnings),
    )


def _missing_message(role: str, family: str, weight: int, style: str) -> str:
    face = "bold" if weight >= 700 else "regular"
    if style == "italic":
        face += " italic"
    return f"{role} family '{family}' has no {face} face"


def _satisfies_request(weight: int, style: str, match: FontMatch) -> bool:
    if style != match.style:
        return False
    if weight >= 700:
        return match.weight >= 700
    return match.weight < 700
