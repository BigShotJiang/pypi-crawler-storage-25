"""Bridge between SlideArchetype definitions and the existing emitter pipeline.

Converts archetype data into :class:`SemanticSlideDescriptor` and
:class:`SemanticLayoutSpec` objects so the existing mixin machinery
renders them without modification.
"""

from __future__ import annotations

from tokenmoulds.archetypes.shape_dsl import ShapeDef, SlideArchetype
from tokenmoulds.dtcg.layout_recipe_catalog import SemanticLayoutSpec
from tokenmoulds.emitters.pptx_semantic import SemanticSlideDescriptor

ARCHETYPE_PREFIX = "archetype:"


def archetype_to_descriptor(arch: SlideArchetype) -> SemanticSlideDescriptor:
    """Convert a SlideArchetype to a SemanticSlideDescriptor."""
    return SemanticSlideDescriptor(
        template_name=f"{ARCHETYPE_PREFIX}{arch.name}",
        regions=tuple(arch.regions.keys()),
        placeholder_context_map={region: region.upper() for region in arch.regions},
        named_shapes={
            shape.region: shape.name
            for shape in arch.shapes
            if isinstance(shape, ShapeDef) and shape.fill_region
        },
        extra_context=dict(arch.extra_context),
    )


def archetype_to_layout_spec(
    arch: SlideArchetype,
    layout_number: int,
) -> SemanticLayoutSpec:
    """Convert a SlideArchetype to a SemanticLayoutSpec."""
    ph_map: dict[str, tuple[str | None, str | None]] = {}
    for shape in arch.shapes:
        if isinstance(shape, ShapeDef) and shape.ph_type is not None:
            ph_map[shape.region] = (shape.ph_type, shape.ph_idx)
    return SemanticLayoutSpec(
        name=arch.name,
        display_name=arch.display_name,
        fallback_standard_layout=arch.fallback_standard_layout,
        placeholder_map=ph_map,
        decorative_regions=arch.decorative_regions,
        pptx_layout_number=layout_number,
        pptx_base_type="cust",
        seed_template_name=f"{ARCHETYPE_PREFIX}{arch.name}",
    )


def regions_to_grid_recipe(
    arch: SlideArchetype,
) -> dict[str, dict[str, int]]:
    """Convert archetype regions to the grid-coordinate format."""
    return {
        name: {
            "col": pos.col,
            "row": pos.row,
            "col_span": pos.col_span,
            "row_span": pos.row_span,
        }
        for name, pos in arch.regions.items()
    }
