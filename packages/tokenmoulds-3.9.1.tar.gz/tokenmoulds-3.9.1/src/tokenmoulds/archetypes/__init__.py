"""Slide archetype DSL for data-driven layout generation."""

from __future__ import annotations
