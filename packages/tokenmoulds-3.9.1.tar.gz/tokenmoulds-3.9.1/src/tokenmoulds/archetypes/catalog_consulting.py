"""Consulting-oriented slide archetypes."""

from __future__ import annotations

from tokenmoulds.archetypes.catalog_helpers import _card, _title
from tokenmoulds.archetypes.shape_dsl import (
    GridPos,
    ShapeDef,
    SlideArchetype,
    TextBody,
    TextParagraph,
    TextRun,
)


def _source(region: str = "source", ph_idx: str = "30") -> ShapeDef:
    """Convenience: source/footnote line at the bottom of an exhibit slide."""
    return ShapeDef(
        name="Source",
        region=region,
        ph_idx=ph_idx,
        no_fill=True,
        text=TextBody(
            paragraphs=(
                TextParagraph(
                    runs=(TextRun("${SLIDE_SOURCE}", "dk2", 8),),
                    align="l",
                ),
            ),
            anchor="t",
        ),
    )


def _consulting_body_slide(
    name: str,
    display_name: str,
    body_shape_name: str,
    default_title: str,
) -> SlideArchetype:
    """Factory for title + body placeholder consulting slides."""
    return SlideArchetype(
        name=name,
        display_name=display_name,
        fallback_standard_layout="blank",
        regions={
            "title": GridPos(0, 0, 12, 6),
            "body": GridPos(1, 7, 10, 22),
        },
        shapes=(
            _title(size_pt=28),
            ShapeDef(
                name=body_shape_name,
                region="body",
                ph_type="body",
                ph_idx="1",
                no_fill=True,
                no_group=True,
            ),
        ),
        extra_context={"SLIDE_TITLE": default_title},
    )


SINGLE_EXHIBIT = SlideArchetype(
    name="single_exhibit",
    display_name="Single Exhibit",
    fallback_standard_layout="title_only",
    regions={
        "title": GridPos(0, 0, 12, 8),
        "exhibit": GridPos(0, 9, 12, 19),
        "source": GridPos(0, 29, 12, 2),
    },
    shapes=(
        _title(size_pt=22),
        ShapeDef(
            name="Exhibit",
            region="exhibit",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
        _source(),
    ),
    extra_context={
        "SLIDE_TITLE": "Action title stating the conclusion of this exhibit",
        "SLIDE_SOURCE": "Source: ",
    },
)

EXHIBIT_WITH_CALLOUT = SlideArchetype(
    name="exhibit_with_callout",
    display_name="Exhibit with Callout",
    fallback_standard_layout="title_only",
    regions={
        "title": GridPos(0, 0, 12, 8),
        "exhibit": GridPos(0, 9, 8, 19),
        "callout": GridPos(9, 9, 3, 19),
        "source": GridPos(0, 29, 12, 2),
    },
    decorative_regions=frozenset({"callout"}),
    shapes=(
        _title(size_pt=22),
        ShapeDef(
            name="Exhibit",
            region="exhibit",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
        _card("Callout", "callout", ph_idx="20"),
        _source(),
    ),
    extra_context={
        "SLIDE_TITLE": "Action title with supporting callout for key insight",
        "SLIDE_SOURCE": "Source: ",
    },
)

BOLD_STATEMENT = SlideArchetype(
    name="bold_statement",
    display_name="Bold Statement",
    fallback_standard_layout="blank",
    regions={
        "statement": GridPos(1, 8, 10, 14),
    },
    shapes=(
        ShapeDef(
            name="Statement",
            region="statement",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_STATEMENT}", "dk1", 36, bold=True),),
                        align="ctr",
                    ),
                ),
                anchor="ctr",
            ),
        ),
    ),
    extra_context={"SLIDE_STATEMENT": "One sentence that changes everything."},
)

FULL_BLEED_PHOTO = SlideArchetype(
    name="full_bleed_photo",
    display_name="Full-Bleed Photo",
    fallback_standard_layout="blank",
    regions={
        "photo": GridPos(0, 0, 12, 30),
        "caption": GridPos(1, 24, 10, 4),
    },
    decorative_regions=frozenset({"photo"}),
    shapes=(
        _card("Photo", "photo"),
        ShapeDef(
            name="Caption",
            region="caption",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_CAPTION}", "lt1", 20, bold=True),),
                        align="ctr",
                    ),
                ),
                anchor="b",
            ),
        ),
    ),
    extra_context={"SLIDE_CAPTION": ""},
)

SCR_STRUCTURE = SlideArchetype(
    name="scr_structure",
    display_name="Situation / Complication / Resolution",
    fallback_standard_layout="blank",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "situation": GridPos(0, 5, 12, 4),
        "complication": GridPos(0, 10, 12, 6),
        "resolution": GridPos(0, 17, 12, 13),
    },
    decorative_regions=frozenset({"situation", "complication", "resolution"}),
    shapes=(
        _title(size_pt=20),
        _card("Situation", "situation", ph_idx="20"),
        _card("Complication", "complication", ph_idx="21"),
        _card("Resolution", "resolution", ph_idx="22"),
    ),
    extra_context={"SLIDE_TITLE": "Executive Summary"},
)

AGENDA_CONSULTING = _consulting_body_slide(
    "agenda_consulting", "Agenda (Consulting)", "Agenda Body", "Today's Discussion"
)

NEXT_STEPS = _consulting_body_slide(
    "next_steps", "Next Steps", "Action Items", "Next Steps"
)


# =========================================================================
# LAYOUT FAMILIES
# =========================================================================
