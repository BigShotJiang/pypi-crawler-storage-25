"""Slide archetype catalog public API."""

from __future__ import annotations

from tokenmoulds.archetypes.catalog_consulting import *  # noqa: F403
from tokenmoulds.archetypes.catalog_general import *  # noqa: F403
from tokenmoulds.archetypes.shape_dsl import LayoutFamily, SlideArchetype

CONSULTING_FAMILY = LayoutFamily(
    name="consulting",
    display_name="Consulting",
    layout_number_start=60,
    archetypes=(
        SINGLE_EXHIBIT,
        EXHIBIT_WITH_CALLOUT,
        BOLD_STATEMENT,
        FULL_BLEED_PHOTO,
        SCR_STRUCTURE,
        AGENDA_CONSULTING,
        NEXT_STEPS,
    ),
)

GENERAL_FAMILY = LayoutFamily(
    name="general",
    display_name="General Business",
    layout_number_start=80,
    archetypes=(
        SWOT_2X2,
        COMPARISON_2COL,
        MATRIX_2X2,
        PROCESS_3STEP,
        PROCESS_4STEP,
        FUNNEL_4STAGE,
        PYRAMID_3TIER,
        KPI_3CARD,
        KPI_4CARD,
        BIG_NUMBER,
        PRICING_3COL,
        QUOTE,
        PHOTO_TEXT_SPLIT,
        TEAM_4MEMBER,
        AGENDA,
        THANK_YOU,
        TIMELINE_4POINT,
    ),
)

LAYOUT_FAMILIES: dict[str, LayoutFamily] = {
    GENERAL_FAMILY.name: GENERAL_FAMILY,
    CONSULTING_FAMILY.name: CONSULTING_FAMILY,
}
ARCHETYPE_REGISTRY: dict[str, SlideArchetype] = {
    arch.name: arch for family in LAYOUT_FAMILIES.values() for arch in family.archetypes
}
