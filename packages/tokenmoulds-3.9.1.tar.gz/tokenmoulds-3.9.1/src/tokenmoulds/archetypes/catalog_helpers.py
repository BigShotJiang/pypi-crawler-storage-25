"""Slide archetype catalog — first batch.

Each archetype is a pure-data :class:`SlideArchetype` definition.
The registry maps archetype names to their definitions for lookup
by the rendering pipeline.
"""

from __future__ import annotations

from tokenmoulds.archetypes.shape_dsl import (
    ShapeDef,
    TextBody,
    TextParagraph,
    TextRun,
)


def _title(
    region: str = "title",
    text: str = "${SLIDE_TITLE}",
    size_pt: float = 26,
) -> ShapeDef:
    """Convenience: standard title placeholder shape."""
    return ShapeDef(
        name="Title",
        region=region,
        ph_type="title",
        no_fill=True,
        no_group=True,
        text=TextBody(
            paragraphs=(
                TextParagraph(
                    runs=(TextRun(text, "dk1", size_pt, bold=True),),
                    align="l",
                ),
            ),
            anchor="b",
        ),
    )


def _card(
    name: str,
    region: str,
    kind: str = "roundRect",
    ph_idx: str | None = None,
) -> ShapeDef:
    """Convenience: card shape with fill from region.

    If ``ph_idx`` is provided, the card becomes a fillable placeholder
    that slides can inject text into. Otherwise it's a pure decorative
    shape.
    """
    return ShapeDef(
        name=name,
        region=region,
        kind=kind,
        fill_region=region,
        ph_idx=ph_idx,
    )
