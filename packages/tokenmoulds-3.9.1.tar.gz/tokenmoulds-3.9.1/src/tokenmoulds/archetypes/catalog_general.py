"""General-purpose slide archetypes."""

from __future__ import annotations

from tokenmoulds.archetypes.catalog_helpers import _card, _title
from tokenmoulds.archetypes.shape_dsl import (
    ConnectorDef,
    GridPos,
    ShapeDef,
    SlideArchetype,
    TextBody,
    TextParagraph,
    TextRun,
)

# =========================================================================
# STRATEGY & ANALYSIS
# =========================================================================

SWOT_2X2 = SlideArchetype(
    name="swot_2x2",
    display_name="SWOT Analysis",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "strengths": GridPos(0, 5, 5, 12),
        "weaknesses": GridPos(7, 5, 5, 12),
        "opportunities": GridPos(0, 18, 5, 12),
        "threats": GridPos(7, 18, 5, 12),
    },
    decorative_regions=frozenset(
        {"strengths", "weaknesses", "opportunities", "threats"}
    ),
    shapes=(
        _title(),
        _card("Strengths", "strengths", ph_idx="20"),
        _card("Weaknesses", "weaknesses", ph_idx="21"),
        _card("Opportunities", "opportunities", ph_idx="22"),
        _card("Threats", "threats", ph_idx="23"),
    ),
    extra_context={"SLIDE_TITLE": "SWOT Analysis"},
)

COMPARISON_2COL = SlideArchetype(
    name="comparison_2col",
    display_name="Two-Column Comparison",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "col_left": GridPos(0, 5, 5, 25),
        "col_right": GridPos(7, 5, 5, 25),
    },
    decorative_regions=frozenset({"col_left", "col_right"}),
    shapes=(
        _title(),
        _card("Column Left", "col_left", ph_idx="20"),
        _card("Column Right", "col_right", ph_idx="21"),
    ),
    extra_context={"SLIDE_TITLE": "Comparison"},
)

MATRIX_2X2 = SlideArchetype(
    name="matrix_2x2",
    display_name="2x2 Matrix",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "q1": GridPos(0, 5, 5, 12),
        "q2": GridPos(7, 5, 5, 12),
        "q3": GridPos(0, 18, 5, 12),
        "q4": GridPos(7, 18, 5, 12),
    },
    decorative_regions=frozenset({"q1", "q2", "q3", "q4"}),
    shapes=(
        _title(),
        _card("Quadrant 1", "q1", ph_idx="20"),
        _card("Quadrant 2", "q2", ph_idx="21"),
        _card("Quadrant 3", "q3", ph_idx="22"),
        _card("Quadrant 4", "q4", ph_idx="23"),
    ),
    extra_context={"SLIDE_TITLE": "Matrix"},
)

# =========================================================================
# PROCESS & FLOW
# =========================================================================

PROCESS_3STEP = SlideArchetype(
    name="process_3step",
    display_name="3-Step Process",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "step_1": GridPos(0, 6, 3, 22),
        "arrow_1": GridPos(3, 14, 1, 6),
        "step_2": GridPos(4, 6, 3, 22),
        "arrow_2": GridPos(7, 14, 1, 6),
        "step_3": GridPos(8, 6, 3, 22),
    },
    decorative_regions=frozenset({"step_1", "step_2", "step_3"}),
    shapes=(
        _title(),
        _card("Step 1", "step_1", ph_idx="20"),
        ConnectorDef(name="Arrow 1-2", region="arrow_1", color="accent1"),
        _card("Step 2", "step_2", ph_idx="21"),
        ConnectorDef(name="Arrow 2-3", region="arrow_2", color="accent1"),
        _card("Step 3", "step_3", ph_idx="22"),
    ),
    extra_context={"SLIDE_TITLE": "Process"},
)

PROCESS_4STEP = SlideArchetype(
    name="process_4step",
    display_name="4-Step Process",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "step_1": GridPos(0, 6, 2, 22),
        "arrow_1": GridPos(2, 14, 1, 6),
        "step_2": GridPos(3, 6, 2, 22),
        "arrow_2": GridPos(5, 14, 1, 6),
        "step_3": GridPos(6, 6, 2, 22),
        "arrow_3": GridPos(8, 14, 1, 6),
        "step_4": GridPos(9, 6, 2, 22),
    },
    decorative_regions=frozenset({"step_1", "step_2", "step_3", "step_4"}),
    shapes=(
        _title(),
        _card("Step 1", "step_1", ph_idx="20"),
        ConnectorDef(name="Arrow 1-2", region="arrow_1", color="accent1"),
        _card("Step 2", "step_2", ph_idx="21"),
        ConnectorDef(name="Arrow 2-3", region="arrow_2", color="accent1"),
        _card("Step 3", "step_3", ph_idx="22"),
        ConnectorDef(name="Arrow 3-4", region="arrow_3", color="accent1"),
        _card("Step 4", "step_4", ph_idx="23"),
    ),
    extra_context={"SLIDE_TITLE": "Process"},
)

FUNNEL_4STAGE = SlideArchetype(
    name="funnel_4stage",
    display_name="Funnel",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "stage_1": GridPos(0, 5, 12, 6),
        "stage_2": GridPos(1, 11, 10, 5),
        "stage_3": GridPos(2, 16, 8, 5),
        "stage_4": GridPos(3, 21, 6, 5),
    },
    decorative_regions=frozenset({"stage_1", "stage_2", "stage_3", "stage_4"}),
    shapes=(
        _title(),
        _card("Stage 1", "stage_1", kind="trapezoid", ph_idx="20"),
        _card("Stage 2", "stage_2", kind="trapezoid", ph_idx="21"),
        _card("Stage 3", "stage_3", kind="trapezoid", ph_idx="22"),
        _card("Stage 4", "stage_4", ph_idx="23"),
    ),
    extra_context={"SLIDE_TITLE": "Funnel"},
)

PYRAMID_3TIER = SlideArchetype(
    name="pyramid_3tier",
    display_name="Pyramid",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "tier_1": GridPos(4, 5, 4, 8),
        "tier_2": GridPos(2, 13, 8, 8),
        "tier_3": GridPos(0, 21, 12, 8),
    },
    decorative_regions=frozenset({"tier_1", "tier_2", "tier_3"}),
    shapes=(
        _title(),
        _card("Top", "tier_1", kind="triangle", ph_idx="20"),
        _card("Middle", "tier_2", kind="trapezoid", ph_idx="21"),
        _card("Base", "tier_3", ph_idx="22"),
    ),
    extra_context={"SLIDE_TITLE": "Pyramid"},
)

# =========================================================================
# DATA & METRICS
# =========================================================================

KPI_3CARD = SlideArchetype(
    name="kpi_3card",
    display_name="3 KPI Cards",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "kpi_1": GridPos(0, 5, 3, 10),
        "kpi_2": GridPos(4, 5, 3, 10),
        "kpi_3": GridPos(8, 5, 3, 10),
        "body": GridPos(0, 16, 12, 14),
    },
    decorative_regions=frozenset({"kpi_1", "kpi_2", "kpi_3"}),
    shapes=(
        _title(),
        _card("KPI 1", "kpi_1", ph_idx="20"),
        _card("KPI 2", "kpi_2", ph_idx="21"),
        _card("KPI 3", "kpi_3", ph_idx="22"),
        ShapeDef(
            name="Body",
            region="body",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
    ),
    extra_context={"SLIDE_TITLE": "Key Metrics"},
)

KPI_4CARD = SlideArchetype(
    name="kpi_4card",
    display_name="4 KPI Cards",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "kpi_1": GridPos(0, 5, 2, 10),
        "kpi_2": GridPos(3, 5, 2, 10),
        "kpi_3": GridPos(6, 5, 2, 10),
        "kpi_4": GridPos(9, 5, 2, 10),
        "body": GridPos(0, 16, 12, 14),
    },
    decorative_regions=frozenset({"kpi_1", "kpi_2", "kpi_3", "kpi_4"}),
    shapes=(
        _title(),
        _card("KPI 1", "kpi_1", ph_idx="20"),
        _card("KPI 2", "kpi_2", ph_idx="21"),
        _card("KPI 3", "kpi_3", ph_idx="22"),
        _card("KPI 4", "kpi_4", ph_idx="23"),
        ShapeDef(
            name="Body",
            region="body",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
    ),
    extra_context={"SLIDE_TITLE": "Key Metrics"},
)

BIG_NUMBER = SlideArchetype(
    name="big_number",
    display_name="Big Number",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "number": GridPos(1, 6, 10, 12),
        "label": GridPos(2, 19, 8, 6),
    },
    shapes=(
        _title(),
        ShapeDef(
            name="Big Number",
            region="number",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_NUMBER}", "accent1", 72, bold=True),),
                        align="ctr",
                    ),
                ),
                anchor="b",
            ),
        ),
        ShapeDef(
            name="Label",
            region="label",
            ph_idx="21",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_LABEL}", "dk1", 18),),
                        align="ctr",
                    ),
                ),
                anchor="t",
            ),
        ),
    ),
    extra_context={
        "SLIDE_TITLE": "Statistic",
        "SLIDE_NUMBER": "42%",
        "SLIDE_LABEL": "Conversion Rate",
    },
)

# =========================================================================
# PRICING & COMPARISON
# =========================================================================

PRICING_3COL = SlideArchetype(
    name="pricing_3col",
    display_name="Pricing Table",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "col_1": GridPos(0, 5, 3, 25),
        "col_2": GridPos(4, 5, 3, 25),
        "col_3": GridPos(8, 5, 3, 25),
    },
    decorative_regions=frozenset({"col_1", "col_2", "col_3"}),
    shapes=(
        _title(),
        _card("Plan 1", "col_1", ph_idx="20"),
        _card("Plan 2", "col_2", ph_idx="21"),
        _card("Plan 3", "col_3", ph_idx="22"),
    ),
    extra_context={"SLIDE_TITLE": "Choose Your Plan"},
)

# =========================================================================
# CONTENT & STORYTELLING
# =========================================================================

QUOTE = SlideArchetype(
    name="quote",
    display_name="Quote",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "quote_area": GridPos(1, 6, 10, 16),
        "attribution": GridPos(2, 23, 8, 4),
    },
    shapes=(
        _title(text="${SLIDE_TITLE}", size_pt=20),
        ShapeDef(
            name="Quote",
            region="quote_area",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_QUOTE}", "dk1", 24, italic=True),),
                        align="ctr",
                    ),
                ),
                anchor="ctr",
            ),
        ),
        ShapeDef(
            name="Attribution",
            region="attribution",
            ph_idx="21",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_ATTRIBUTION}", "dk2", 14),),
                        align="ctr",
                    ),
                ),
                anchor="t",
            ),
        ),
    ),
    extra_context={
        "SLIDE_TITLE": "",
        "SLIDE_QUOTE": '"Design is not just what it looks like. Design is how it works."',
        "SLIDE_ATTRIBUTION": "— Steve Jobs",
    },
)

PHOTO_TEXT_SPLIT = SlideArchetype(
    name="photo_text_split",
    display_name="Photo + Text Split",
    regions={
        "photo": GridPos(0, 0, 6, 30),
        "title": GridPos(7, 4, 5, 6),
        "body": GridPos(7, 11, 5, 16),
    },
    decorative_regions=frozenset({"photo"}),
    shapes=(
        _card("Photo", "photo"),
        _title(region="title"),
        ShapeDef(
            name="Body",
            region="body",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
    ),
    extra_context={"SLIDE_TITLE": "Title"},
)

# =========================================================================
# TEAM & ABOUT
# =========================================================================

TEAM_4MEMBER = SlideArchetype(
    name="team_4member",
    display_name="Team (4 Members)",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "member_1": GridPos(0, 5, 2, 24),
        "member_2": GridPos(3, 5, 2, 24),
        "member_3": GridPos(6, 5, 2, 24),
        "member_4": GridPos(9, 5, 2, 24),
    },
    decorative_regions=frozenset({"member_1", "member_2", "member_3", "member_4"}),
    shapes=(
        _title(),
        _card("Member 1", "member_1", ph_idx="20"),
        _card("Member 2", "member_2", ph_idx="21"),
        _card("Member 3", "member_3", ph_idx="22"),
        _card("Member 4", "member_4", ph_idx="23"),
    ),
    extra_context={"SLIDE_TITLE": "Our Team"},
)

# =========================================================================
# OPENING & CLOSING
# =========================================================================

AGENDA = SlideArchetype(
    name="agenda",
    display_name="Agenda",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "body": GridPos(1, 5, 10, 24),
    },
    shapes=(
        _title(),
        ShapeDef(
            name="Agenda Body",
            region="body",
            ph_type="body",
            ph_idx="1",
            no_fill=True,
            no_group=True,
        ),
    ),
    extra_context={"SLIDE_TITLE": "Agenda"},
)

THANK_YOU = SlideArchetype(
    name="thank_you",
    display_name="Thank You",
    regions={
        "message": GridPos(1, 6, 10, 12),
        "contact": GridPos(2, 20, 8, 6),
    },
    shapes=(
        ShapeDef(
            name="Thank You",
            region="message",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_MESSAGE}", "dk1", 44, bold=True),),
                        align="ctr",
                    ),
                ),
                anchor="b",
            ),
        ),
        ShapeDef(
            name="Contact",
            region="contact",
            ph_idx="21",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${SLIDE_CONTACT}", "dk2", 16),),
                        align="ctr",
                    ),
                ),
                anchor="t",
            ),
        ),
    ),
    extra_context={
        "SLIDE_MESSAGE": "Thank You",
        "SLIDE_CONTACT": "questions@example.com",
    },
)

# =========================================================================
# TIMELINE
# =========================================================================

TIMELINE_4POINT = SlideArchetype(
    name="timeline_4point",
    display_name="Timeline (4 Points)",
    regions={
        "title": GridPos(0, 0, 12, 4),
        "line": GridPos(0, 14, 12, 1),
        "point_1": GridPos(0, 6, 2, 8),
        "point_2": GridPos(3, 6, 2, 8),
        "point_3": GridPos(6, 6, 2, 8),
        "point_4": GridPos(9, 6, 2, 8),
        "label_1": GridPos(0, 16, 2, 8),
        "label_2": GridPos(3, 16, 2, 8),
        "label_3": GridPos(6, 16, 2, 8),
        "label_4": GridPos(9, 16, 2, 8),
    },
    decorative_regions=frozenset({"point_1", "point_2", "point_3", "point_4"}),
    shapes=(
        _title(),
        ConnectorDef(name="Timeline", region="line", color="dk2", width_pt=2.0),
        _card("Point 1", "point_1", kind="ellipse"),
        _card("Point 2", "point_2", kind="ellipse"),
        _card("Point 3", "point_3", kind="ellipse"),
        _card("Point 4", "point_4", kind="ellipse"),
        ShapeDef(
            name="Label 1",
            region="label_1",
            ph_idx="20",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${LABEL_1}", "dk1", 12),), align="ctr"
                    ),
                ),
                anchor="t",
            ),
        ),
        ShapeDef(
            name="Label 2",
            region="label_2",
            ph_idx="21",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${LABEL_2}", "dk1", 12),), align="ctr"
                    ),
                ),
                anchor="t",
            ),
        ),
        ShapeDef(
            name="Label 3",
            region="label_3",
            ph_idx="22",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${LABEL_3}", "dk1", 12),), align="ctr"
                    ),
                ),
                anchor="t",
            ),
        ),
        ShapeDef(
            name="Label 4",
            region="label_4",
            ph_idx="23",
            no_fill=True,
            text=TextBody(
                paragraphs=(
                    TextParagraph(
                        runs=(TextRun("${LABEL_4}", "dk1", 12),), align="ctr"
                    ),
                ),
                anchor="t",
            ),
        ),
    ),
    extra_context={
        "SLIDE_TITLE": "Timeline",
        "LABEL_1": "Q1",
        "LABEL_2": "Q2",
        "LABEL_3": "Q3",
        "LABEL_4": "Q4",
    },
)
