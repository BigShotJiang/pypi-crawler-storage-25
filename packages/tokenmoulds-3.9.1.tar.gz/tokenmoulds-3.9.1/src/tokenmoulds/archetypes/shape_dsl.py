"""Shape Builder DSL data model.

Frozen dataclasses that define slide archetypes as pure data.  No lxml,
no XML, no runtime dependencies.  The renderer consumes these to produce
PresentationML element trees.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class GridPos:
    """Grid-relative position. Converted to EMU by ``SlideGrid.cell_rect``."""

    col: int
    row: int
    col_span: int = 1
    row_span: int = 1


@dataclass(frozen=True, slots=True)
class TextRun:
    """A single styled text run within a paragraph."""

    text: str
    color: str = "dk1"
    size_pt: float = 14
    bold: bool = False
    italic: bool = False


@dataclass(frozen=True, slots=True)
class TextParagraph:
    """A paragraph containing one or more text runs."""

    runs: tuple[TextRun, ...]
    align: str = "l"  # "l", "ctr", "r"


@dataclass(frozen=True, slots=True)
class TextBody:
    """Text body for a shape (maps to ``p:txBody``)."""

    paragraphs: tuple[TextParagraph, ...]
    anchor: str = "ctr"  # "t", "ctr", "b"
    word_wrap: bool = True


@dataclass(frozen=True, slots=True)
class ShapeDef:
    """A single shape on a slide."""

    name: str
    region: str
    kind: str = "rect"
    ph_type: str | None = None
    ph_idx: str | None = None
    fill_region: str | None = None
    no_fill: bool = False
    no_outline: bool = True
    text: TextBody | None = None
    no_group: bool = False


@dataclass(frozen=True, slots=True)
class ConnectorDef:
    """A connector line occupying a grid region."""

    name: str
    region: str
    kind: str = "straightConnector1"
    color: str = "dk1"
    width_pt: float = 1.0
    flip_h: bool = False
    flip_v: bool = False


@dataclass(frozen=True)
class SlideArchetype:
    """Complete slide archetype definition — pure data.

    Each archetype specifies the shapes, their grid positions, and how
    they connect to the brand's decorative fill system.  The renderer
    converts this into valid PresentationML at build time.
    """

    name: str
    display_name: str
    shapes: tuple[ShapeDef | ConnectorDef, ...]
    regions: dict[str, GridPos]
    decorative_regions: frozenset[str] = frozenset()
    fallback_standard_layout: str = "blank"
    extra_context: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LayoutFamily:
    """A named collection of slide archetypes sharing a design philosophy.

    Three canonical families:

    * **microsoft** — the 36 ECMA-376 standard layout types.  Conventional,
      expected, what users see when they click "New Slide."
    * **consulting** — sparse, argument-driven.  Action titles, single
      exhibits, big numbers, full-bleed photos.  Every slide makes one point.
    * **general** — the volume play.  SWOT, funnel, timeline, pricing, team
      grid, KPI dashboard, and dozens more market archetypes.

    Templates can include one family, two, or all three.
    """

    name: str
    display_name: str
    archetypes: tuple[SlideArchetype, ...]
    layout_number_start: int = 1
