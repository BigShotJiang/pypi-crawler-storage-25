"""Artifact intent side-channel model.

The payload is the machine-readable handoff contract embedded in generated
documents. It is deliberately compact: future agents should learn the artifact's
purpose and constraints without receiving raw prompts or chat transcripts.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

SCHEMA_ID = "tokenmoulds.artifact_intent"
SCHEMA_VERSION = "0.1"
DEFAULT_PAYLOAD_PART = "/customXml/tokenmoulds-intent.json"

ArtifactType = Literal[
    "annual_report",
    "board_deck",
    "manual",
    "memo",
    "policy_memo",
    "proposal",
    "report",
    "template_bundle",
    "whitepaper",
    "workbook",
    "unknown",
]
ReviewState = Literal[
    "unreviewed",
    "draft",
    "reviewed",
    "approved",
    "rejected",
    "unknown",
]
ArtifactStatus = Literal["draft", "review", "approved", "released", "unknown"]

ARTIFACT_TYPES: tuple[str, ...] = (
    "annual_report",
    "board_deck",
    "manual",
    "memo",
    "policy_memo",
    "proposal",
    "report",
    "template_bundle",
    "whitepaper",
    "workbook",
    "unknown",
)
REVIEW_STATES: tuple[str, ...] = (
    "unreviewed",
    "draft",
    "reviewed",
    "approved",
    "rejected",
    "unknown",
)
ARTIFACT_STATUSES: tuple[str, ...] = (
    "draft",
    "review",
    "approved",
    "released",
    "unknown",
)

_MAX_TEXT_LENGTH = 512
_MAX_SHORT_TEXT_LENGTH = 256
_MAX_LIST_ITEMS = 64
_UNSAFE_KEY_RE = re.compile(
    r"(raw_?prompt|chat_?history|conversation|password|secret|api_?key|credential)",
    re.IGNORECASE,
)
_SECRET_VALUE_RE = re.compile(
    r"(sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9_]{16,}|"
    r"xox[baprs]-[A-Za-z0-9-]{16,})"
)


class ArtifactIntentError(ValueError):
    """Raised when artifact intent metadata is unsafe or malformed."""


@dataclass(frozen=True)
class ArtifactIntentMetadata:
    """Versioned artifact intent side-channel payload."""

    artifact: Mapping[str, Any]
    source: Mapping[str, Any] = field(default_factory=dict)
    generation: Mapping[str, Any] = field(default_factory=dict)
    plan: Mapping[str, Any] = field(default_factory=dict)
    quality: Mapping[str, Any] = field(default_factory=dict)
    review: Mapping[str, Any] = field(default_factory=dict)
    schema: str = SCHEMA_ID
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        payload = self.to_dict(validate_schema=False)
        _validate_payload(payload)

    def to_dict(self, *, validate_schema: bool = True) -> dict[str, Any]:
        """Return the normalized JSON-compatible payload."""
        payload = {
            "schema": self.schema,
            "schema_version": self.schema_version,
            "artifact": _normalize_mapping(self.artifact, path="artifact"),
            "source": _normalize_mapping(self.source, path="source"),
            "generation": _normalize_mapping(self.generation, path="generation"),
            "plan": _normalize_mapping(self.plan, path="plan"),
            "quality": _normalize_mapping(self.quality, path="quality"),
            "review": _normalize_mapping(self.review, path="review"),
        }
        if validate_schema:
            _validate_payload(payload)
        return payload

    def canonical_json(self) -> str:
        """Serialize with deterministic key ordering for hashes and diffs."""
        return canonical_json(self.to_dict())

    def sha256(self) -> str:
        """Return the SHA-256 hash of the canonical payload."""
        return hashlib.sha256(self.canonical_json().encode("utf-8")).hexdigest()

    def flat_properties(
        self,
        *,
        payload_part: str = DEFAULT_PAYLOAD_PART,
    ) -> dict[str, str]:
        """Return the short OOXML custom-property index."""
        payload = self.to_dict()
        artifact = payload["artifact"]
        generation = payload["generation"]
        review = payload["review"]
        props = {
            "TokenMouldsSchema": payload["schema"],
            "TokenMouldsSchemaVersion": payload["schema_version"],
            "TokenMouldsArtifactType": str(artifact.get("type", "unknown")),
            "TokenMouldsIntentSummary": str(artifact.get("intent_summary", "")),
            "TokenMouldsPayloadPart": payload_part,
        }
        optional = {
            "TokenMouldsBrandId": generation.get("brand_id")
            or generation.get("org_id"),
            "TokenMouldsCompilerVersion": generation.get("compiler_version"),
            "TokenMouldsTokensHash": generation.get("tokens_sha256"),
            "TokenMouldsPlanHash": generation.get("artifact_plan_sha256"),
            "TokenMouldsReviewState": review.get("state"),
        }
        props.update(
            {key: str(value) for key, value in optional.items() if value is not None}
        )
        return props


def canonical_json(payload: Mapping[str, Any]) -> str:
    """Return deterministic compact JSON for a metadata payload."""
    return json.dumps(
        _normalize_mapping(payload, path="payload"),
        sort_keys=True,
        separators=(",", ":"),
    )


def artifact_intent_from_mapping(
    payload: Mapping[str, Any],
) -> ArtifactIntentMetadata:
    """Build metadata from a JSON-like payload mapping."""
    return ArtifactIntentMetadata(
        schema=str(payload.get("schema", SCHEMA_ID)),
        schema_version=str(payload.get("schema_version", SCHEMA_VERSION)),
        artifact=_mapping(payload.get("artifact"), "artifact"),
        source=_mapping(payload.get("source", {}), "source"),
        generation=_mapping(payload.get("generation", {}), "generation"),
        plan=_mapping(payload.get("plan", {}), "plan"),
        quality=_mapping(payload.get("quality", {}), "quality"),
        review=_mapping(payload.get("review", {}), "review"),
    )


def _mapping(value: Any, path: str) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    raise ArtifactIntentError(f"{path} must be an object")


def _validate_payload(payload: Mapping[str, Any]) -> None:
    if payload.get("schema") != SCHEMA_ID:
        raise ArtifactIntentError(f"schema must be {SCHEMA_ID!r}")
    if payload.get("schema_version") != SCHEMA_VERSION:
        raise ArtifactIntentError(f"schema_version must be {SCHEMA_VERSION!r}")

    artifact = _mapping(payload.get("artifact"), "artifact")
    for key in ("id", "type", "title", "intent_summary"):
        if not str(artifact.get(key, "")).strip():
            raise ArtifactIntentError(f"artifact.{key} is required")
    if artifact["type"] not in ARTIFACT_TYPES:
        raise ArtifactIntentError(f"unsupported artifact.type: {artifact['type']!r}")
    status = artifact.get("status")
    if status is not None and status not in ARTIFACT_STATUSES:
        raise ArtifactIntentError(f"unsupported artifact.status: {status!r}")

    review = _mapping(payload.get("review"), "review")
    state = review.get("state")
    if state is not None and state not in REVIEW_STATES:
        raise ArtifactIntentError(f"unsupported review.state: {state!r}")


def _normalize_mapping(value: Mapping[str, Any], *, path: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for raw_key, raw_value in value.items():
        key = str(raw_key)
        child_path = f"{path}.{key}"
        _check_safe_key(key, child_path)
        result[key] = _normalize_value(raw_value, path=child_path)
    return result


def _normalize_value(value: Any, *, path: str) -> Any:
    if isinstance(value, Mapping):
        return _normalize_mapping(value, path=path)
    if isinstance(value, list):
        if len(value) > _MAX_LIST_ITEMS:
            raise ArtifactIntentError(f"{path} has too many items")
        return [_normalize_value(item, path=f"{path}[]") for item in value]
    if isinstance(value, tuple):
        if len(value) > _MAX_LIST_ITEMS:
            raise ArtifactIntentError(f"{path} has too many items")
        return [_normalize_value(item, path=f"{path}[]") for item in value]
    if isinstance(value, str):
        _check_safe_value(value, path)
        limit = _MAX_TEXT_LENGTH if path.endswith("summary") else _MAX_SHORT_TEXT_LENGTH
        if len(value) > limit:
            raise ArtifactIntentError(f"{path} exceeds {limit} characters")
        return value
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    raise ArtifactIntentError(f"{path} has unsupported value type")


def _check_safe_key(key: str, path: str) -> None:
    if _UNSAFE_KEY_RE.search(key):
        raise ArtifactIntentError(f"{path} is not allowed in artifact intent metadata")


def _check_safe_value(value: str, path: str) -> None:
    if _SECRET_VALUE_RE.search(value):
        raise ArtifactIntentError(f"{path} appears to contain a secret")
