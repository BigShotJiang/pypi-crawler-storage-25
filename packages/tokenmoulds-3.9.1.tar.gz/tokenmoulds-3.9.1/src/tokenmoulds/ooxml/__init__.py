"""OOXML structural utilities.

Namespace registry, relationship model, and package abstractions for
reading and validating Open Packaging Convention archives.
"""
