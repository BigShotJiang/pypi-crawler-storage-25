"""Centralised OOXML and ODF namespace registry.

All namespace URIs, prefix mappings, and utility functions in one place.
Constant names match ``openxml_audit.namespaces`` for interoperability.

See ADR 020, item 4.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# ECMA-376 / ISO 29500 — OOXML namespaces
# ---------------------------------------------------------------------------

DRAWINGML = "http://schemas.openxmlformats.org/drawingml/2006/main"
PRESENTATIONML = "http://schemas.openxmlformats.org/presentationml/2006/main"
WORDPROCESSINGML = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
SPREADSHEETML = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"

CONTENT_TYPES = "http://schemas.openxmlformats.org/package/2006/content-types"
RELATIONSHIPS = "http://schemas.openxmlformats.org/package/2006/relationships"
RELATIONSHIPS_DOC = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
)

# Dublin Core
DC = "http://purl.org/dc/elements/1.1/"
DCTERMS = "http://purl.org/dc/terms/"

# Microsoft extensions
THEMEML = "http://schemas.microsoft.com/office/thememl/2012/main"
P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
P15 = "http://schemas.microsoft.com/office/powerpoint/2012/main"

# ---------------------------------------------------------------------------
# OASIS ODF namespaces
# ---------------------------------------------------------------------------

ODF_DRAW = "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0"
ODF_STYLE = "urn:oasis:names:tc:opendocument:xmlns:style:1.0"
ODF_FO = "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
ODF_SVG = "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0"
ODF_OFFICE = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
ODF_TEXT = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
ODF_TABLE = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"

# ---------------------------------------------------------------------------
# Prefix ↔ URI mappings
# ---------------------------------------------------------------------------

NSMAP: dict[str, str] = {
    "a": DRAWINGML,
    "p": PRESENTATIONML,
    "w": WORDPROCESSINGML,
    "x": SPREADSHEETML,
    "ct": CONTENT_TYPES,
    "rel": RELATIONSHIPS,
    "r": RELATIONSHIPS_DOC,
    "dc": DC,
    "dcterms": DCTERMS,
    "thm15": THEMEML,
    "p14": P14,
    "p15": P15,
    # ODF
    "draw": ODF_DRAW,
    "style": ODF_STYLE,
    "fo": ODF_FO,
    "svg": ODF_SVG,
    "office": ODF_OFFICE,
    "text": ODF_TEXT,
    "table": ODF_TABLE,
}

PREFIX_MAP: dict[str, str] = {uri: prefix for prefix, uri in NSMAP.items()}


def qualify(prefix: str, local: str) -> str:
    """Create a Clark notation qualified name.

    >>> qualify("a", "theme")
    '{http://schemas.openxmlformats.org/drawingml/2006/main}theme'
    """
    uri = NSMAP.get(prefix)
    if uri is None:
        raise KeyError(f"Unknown namespace prefix: {prefix!r}")
    return f"{{{uri}}}{local}"


def split_qname(qname: str) -> tuple[str | None, str]:
    """Split a Clark notation name into ``(namespace, local_name)``.

    Returns ``(None, qname)`` when the name has no namespace.

    >>> split_qname('{http://schemas.openxmlformats.org/drawingml/2006/main}theme')
    ('http://schemas.openxmlformats.org/drawingml/2006/main', 'theme')
    >>> split_qname('theme')
    (None, 'theme')
    """
    if qname.startswith("{"):
        ns, local = qname[1:].split("}", 1)
        return ns, local
    return None, qname
