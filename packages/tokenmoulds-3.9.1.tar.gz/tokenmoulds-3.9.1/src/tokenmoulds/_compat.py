"""Shared utilities and optional-dependency flags.

``httpx`` is a hard dependency, so callers should ``import httpx`` directly.
``svg2ooxml`` is optional and gated through ``HAS_SVG2OOXML``.
"""

from __future__ import annotations


def strip_hex(color: str) -> str:
    """Strip ``#`` prefix and uppercase a hex color string."""
    return color.lstrip("#").upper()


try:
    from svg2ooxml.public import SVGParser  # noqa: F401

    HAS_SVG2OOXML = True
except ImportError:
    HAS_SVG2OOXML = False
