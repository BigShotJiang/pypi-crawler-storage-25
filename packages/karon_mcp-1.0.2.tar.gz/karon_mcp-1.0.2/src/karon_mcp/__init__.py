"""Karon Web Unblocker — MCP Server for Claude, Cursor, and other MCP clients."""

__version__ = "1.0.0"
