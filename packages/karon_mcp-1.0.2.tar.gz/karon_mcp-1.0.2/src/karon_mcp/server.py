#!/usr/bin/env python3
"""Karon Web Unblocker — MCP Server"""
from mcp.server.fastmcp import FastMCP
import httpx
import os
import json
import asyncio
import logging
import ipaddress
import socket
from urllib.parse import urlparse

logger = logging.getLogger("karon-unblocker")

mcp = FastMCP("karon-unblocker")

_API_BASE = "https://api.karonlabs.net"
_ALLOWED_EXTRACTS = {"markdown", "text", "html"}
_MAX_URL_LEN = 8192
_MAX_CONTENT_LEN = 200_000
_MAX_CONCURRENCY = 5
_MAX_URLS = 20
_TIMEOUT_LOCAL = 70.0
_MAX_RESPONSE_BYTES = 10 * 1024 * 1024

_global_sem = asyncio.Semaphore(_MAX_CONCURRENCY)
_client: httpx.AsyncClient | None = None


def _get_api_key() -> str:
    return os.environ.get("KARON_API_KEY", "")


async def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            timeout=_TIMEOUT_LOCAL,
            follow_redirects=True,
            limits=httpx.Limits(max_connections=_MAX_CONCURRENCY),
        )
    return _client


_BLOCKED_NETS = [
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("100.64.0.0/10"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.0.0.0/24"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("::/128"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


def _is_blocked_ip(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    check_addrs = [addr]
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        check_addrs.append(addr.ipv4_mapped)
    for a in check_addrs:
        for net in _BLOCKED_NETS:
            if a in net:
                return True
    return False


def _validate_url(url: str) -> str | None:
    """Returns error message if invalid, None if OK."""
    if not isinstance(url, str) or not url.strip():
        return "url must be a non-empty string"
    if len(url) > _MAX_URL_LEN:
        return f"url exceeds {_MAX_URL_LEN} chars"
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return "url must use http or https scheme"
    hostname = parsed.hostname
    if not hostname:
        return "url has no hostname"
    hostname_lower = hostname.lower()
    if hostname_lower in ("localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback"):
        return "url targets a blocked loopback hostname"
    try:
        addr = ipaddress.ip_address(hostname_lower)
        if _is_blocked_ip(addr):
            return "url targets a blocked internal network"
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(hostname, None, proto=socket.IPPROTO_TCP)
        for info in infos:
            resolved_ip = info[4][0]
            try:
                addr = ipaddress.ip_address(resolved_ip)
                if _is_blocked_ip(addr):
                    return "url resolves to a blocked internal network"
            except ValueError:
                continue
    except socket.gaierror:
        pass
    return None


def _safe_str(val: object) -> str:
    if isinstance(val, str):
        return val.translate({i: f"\\x{i:02x}" for i in range(32) if i not in (10, 13)})
    return str(val)


def _parse_response(data: object) -> dict | None:
    """Validate upstream response is a dict. Returns None if not."""
    if not isinstance(data, dict):
        return None
    return data


def _build_error(msg: str, status_code: int | None = None, cost: object = None) -> str:
    parts = [f"Error: {msg}"]
    if status_code is not None:
        parts.append(f"(HTTP {status_code})")
    if cost is not None:
        parts.append(f"[credits_used: {cost}]")
    return " ".join(parts)


@mcp.tool()
async def browse(
    url: str,
    extract: str = "markdown",
    readability: bool = True,
) -> str:
    """
    Fetch any URL bypassing WAF protections.
    Returns clean text or markdown. Costs 1 credit (cache hit) or 10 credits (cache miss).

    Args:
        url: Target URL (must start with http/https)
        extract: Output format — "markdown" | "text" | "html"
        readability: True = main content only (default). False = full page.
    """
    api_key = _get_api_key()
    if not api_key:
        return _build_error("KARON_API_KEY environment variable not set")

    url_err = _validate_url(url)
    if url_err:
        return _build_error(url_err)

    if extract not in _ALLOWED_EXTRACTS:
        return _build_error(f"extract must be one of {_ALLOWED_EXTRACTS}")

    if not isinstance(readability, bool):
        return _build_error("readability must be a boolean")

    async with _global_sem:
        try:
            client = await _get_client()
            r = await client.post(
                f"{_API_BASE}/v1/agent/browse",
                headers={"Authorization": f"Bearer {api_key}"},
                json={"url": url, "extract": extract, "readability": readability},
            )
        except Exception as e:
            logger.error("browse request failed", exc_info=True)
            return _build_error(str(e))

    status_code = r.status_code
    try:
        raw = r.content
        if len(raw) > _MAX_RESPONSE_BYTES:
            return _build_error("response too large", status_code=status_code)
        data = json.loads(raw)
    except Exception as e:
        logger.error("browse JSON parse failed (HTTP %d)", status_code, exc_info=True)
        return _build_error(f"JSON parse failed: {e}", status_code=status_code)

    data = _parse_response(data)
    if data is None:
        return _build_error("unexpected response format", status_code=status_code)

    success = data.get("success")
    cost = data.get("cost_credits")

    if success is not True:
        return _build_error(
            data.get("error", "unknown"),
            status_code=status_code,
            cost=cost,
        )

    if status_code >= 400:
        return _build_error("HTTP error with success flag", status_code=status_code, cost=cost)

    content = _safe_str(data.get("content", ""))
    if len(content) > _MAX_CONTENT_LEN:
        content = content[:_MAX_CONTENT_LEN] + "\n[truncated]"

    resolved_url = _safe_str(data.get("url", url))
    timing = data.get("timing")
    cache_hit = timing.get("cache_hit", "?") if isinstance(timing, dict) else "?"

    if extract == "html":
        return json.dumps({
            "source": resolved_url,
            "credits_used": cost,
            "cache_hit": cache_hit,
            "content": content,
        }, ensure_ascii=False)

    lines = [
        f"[source]: {resolved_url}",
        f"[credits_used]: {cost if cost is not None else '?'}",
        f"[cache_hit]: {cache_hit}",
        "---",
        content,
    ]
    return "\n".join(lines)


@mcp.tool()
async def crawl(
    urls: list[str],
    extract: str = "markdown",
    readability: bool = True,
    concurrency: int = 3,
) -> str:
    """
    Fetch multiple URLs concurrently bypassing WAFs. Returns JSON array of results.

    Args:
        urls: List of URLs (max 20)
        extract: Output format — "markdown" | "text"
        readability: True = main content only (default). False = full page.
        concurrency: Parallel requests (1-5, default 3)
    """
    api_key = _get_api_key()
    if not api_key:
        return json.dumps([{"url": "N/A", "success": False, "error": "KARON_API_KEY environment variable not set"}])

    if not isinstance(urls, list):
        return json.dumps([{"url": "N/A", "success": False, "error": "urls must be a list of strings"}])

    if not isinstance(concurrency, int):
        return json.dumps([{"url": "N/A", "success": False, "error": "concurrency must be an integer"}])

    if extract not in _ALLOWED_EXTRACTS:
        return json.dumps([{"url": "N/A", "success": False, "error": f"extract must be one of {sorted(_ALLOWED_EXTRACTS)}"}])

    if not isinstance(readability, bool):
        return json.dumps([{"url": "N/A", "success": False, "error": "readability must be a boolean"}])

    concurrency = max(1, min(_MAX_CONCURRENCY, concurrency))

    validated: list[str] = []
    rejected: list[dict] = []
    seen: set[str] = set()
    for u in urls:
        if not isinstance(u, str) or not u.strip():
            rejected.append({"url": str(u), "error": "invalid url type or empty"})
            continue
        url_err = _validate_url(u)
        if url_err:
            rejected.append({"url": u, "error": url_err})
            continue
        if u in seen:
            continue
        seen.add(u)
        validated.append(u)

    if len(validated) > _MAX_URLS:
        return json.dumps([{
            "url": "N/A", "success": False,
            "error": f"too many URLs: {len(validated)} (max {_MAX_URLS})",
        }])

    local_sem = asyncio.Semaphore(concurrency)

    async def fetch_one(target_url: str) -> dict:
        async with _global_sem:
            async with local_sem:
                try:
                    client = await _get_client()
                    r = await client.post(
                        f"{_API_BASE}/v1/agent/browse",
                        headers={"Authorization": f"Bearer {api_key}"},
                        json={"url": target_url, "extract": extract, "readability": readability},
                    )
                except Exception as e:
                    logger.error("crawl fetch failed for %s", target_url, exc_info=True)
                    return {"url": target_url, "success": False, "content": "", "error": str(e)}

                status_code = r.status_code
                try:
                    raw = r.content
                    if len(raw) > _MAX_RESPONSE_BYTES:
                        return {"url": target_url, "success": False, "content": "", "error": "response too large", "status_code": status_code}
                    data = json.loads(raw)
                except Exception as e:
                    logger.error("crawl JSON parse failed for %s (HTTP %d)", target_url, status_code, exc_info=True)
                    return {"url": target_url, "success": False, "content": "", "error": f"JSON parse: {e}", "status_code": status_code}

                if not isinstance(data, dict):
                    return {"url": target_url, "success": False, "content": "", "error": "unexpected response format", "status_code": status_code}

                success = data.get("success") is True
                content = _safe_str(data.get("content", ""))
                if len(content) > _MAX_CONTENT_LEN:
                    content = content[:_MAX_CONTENT_LEN] + "\n[truncated]"

                return {
                    "url": target_url,
                    "resolved_url": data.get("url", target_url),
                    "success": success,
                    "content": content,
                    "error": data.get("error"),
                    "cost_credits": data.get("cost_credits"),
                    "status_code": status_code,
                }

    tasks = [fetch_one(u) for u in validated]
    try:
        results = await asyncio.wait_for(
            asyncio.gather(*tasks, return_exceptions=True),
            timeout=_TIMEOUT_LOCAL * len(validated) / max(concurrency, 1) + 30,
        )
    except asyncio.TimeoutError:
        results = [{"url": "batch", "success": False, "error": "batch timeout exceeded"}]

    final: list[dict] = []
    for r in results:
        if isinstance(r, BaseException):
            final.append({"url": "?", "success": False, "error": str(r)})
        else:
            final.append(r)

    if rejected:
        for rej in rejected:
            final.append({"url": rej["url"], "success": False, "content": "", "error": rej["error"]})

    return json.dumps(final, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    from karon_mcp.__main__ import main
    main()
