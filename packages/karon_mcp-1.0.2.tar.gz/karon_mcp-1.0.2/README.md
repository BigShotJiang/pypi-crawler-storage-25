# karon-mcp

MCP server for the [Karon Web Unblocker API](https://karonlabs.net/api/). Fetch any URL bypassing Cloudflare, Akamai, DataDome, hCaptcha, PerimeterX, Kasada, and AWS WAF — directly from Claude, Cursor, or any MCP-compatible client.

## Quick Start

### 1. Get your API key

Sign up at [karonlabs.net/api/signup.html](https://karonlabs.net/api/signup.html) (Google login, free tier: 1,000 credits).

### 2. Install

**Claude Desktop / Claude Code** — add to your MCP config (`claude_desktop_config.json` or `.mcp.json`):

```json
{
  "mcpServers": {
    "karon": {
      "command": "uvx",
      "args": ["karon-mcp"],
      "env": {
        "KARON_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

> `uvx` auto-fetches the latest version from PyPI on every run. No manual updates needed.

**Cursor** — go to Settings > MCP Servers > Add, then use the same config above.

**Manual install** (if you prefer pip):

```bash
pip install karon-mcp
```

### 3. Use

Once installed, two tools become available in your MCP client:

#### `browse` — Fetch a single URL

```
browse(url="https://example.com", extract="markdown", readability=True)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `url` | string | required | Target URL (http/https) |
| `extract` | string | `"markdown"` | Output format: `"markdown"`, `"text"`, or `"html"` |
| `readability` | bool | `True` | `True` = main content only, `False` = full page |

#### `crawl` — Fetch multiple URLs concurrently

```
crawl(urls=["https://a.com", "https://b.com"], extract="markdown", concurrency=3)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `urls` | list[string] | required | Up to 20 URLs |
| `extract` | string | `"markdown"` | Output format: `"markdown"` or `"text"` |
| `readability` | bool | `True` | Main content only |
| `concurrency` | int | `3` | Parallel requests (1-5) |

### Credits

| Method | Cost |
|--------|------|
| Cache hit | 1 credit |
| Cache miss | 10 credits |

Free tier includes 1,000 credits. See [pricing](https://karonlabs.net/api/pricing.html) for paid plans.

## Configuration

The only required configuration is the `KARON_API_KEY` environment variable. Get yours at [karonlabs.net/api/signup.html](https://karonlabs.net/api/signup.html).

## Updating

If you're using `uvx` (recommended), updates are automatic — every run fetches the latest version.

If you installed with pip:

```bash
pip install --upgrade karon-mcp
```

## Links

- [API Documentation](https://karonlabs.net/api/docs.html)
- [Pricing](https://karonlabs.net/api/pricing.html)
- [WAF Compatibility](https://karonlabs.net/api/waf.html)
- [Changelog](CHANGELOG.md)

## License

MIT
