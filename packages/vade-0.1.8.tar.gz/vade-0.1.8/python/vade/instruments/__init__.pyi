"""Type stubs for vade.instruments module."""

import datetime
from typing import Any, Optional, Union

import polars as pl
import numpy as np

from vade.context import MarketContext
from vade.curves import DiscountCurve, LineCurve
from vade.solver import Solver

Curve = Union[DiscountCurve, LineCurve]
CurveInput = Union[Curve, list, dict, None]


class InterestRateSwap:
    """Interest Rate Swap: fixed vs floating leg."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "a",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        amortization: Optional[Any] = None,
        fixed_amortization: Optional[Any] = None,
        float_amortization: Optional[Any] = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


IRS = InterestRateSwap


class ForwardRateAgreement:
    """Forward Rate Agreement: single-period forward rate instrument."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        notional: float = 1_000_000.0,
        fixed_rate: float = 0.0,
        convention: str = "act360",
        fixing_method: str = "rfr_payment_delay",
        calendar: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


FRA = ForwardRateAgreement


class ZeroCouponSwap:
    """Zero Coupon Swap: zero-coupon fixed vs floating leg."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


ZCS = ZeroCouponSwap


class SingleBasisSwap:
    """Single Basis Swap: two floating legs."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "q",
        leg2_frequency: str = "s",
        notional: float = 1_000_000.0,
        spread: float = 0.0,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        leg2_fixing_method: Optional[str] = None,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


SBS = SingleBasisSwap


class OvernightIndexedSwap:
    """Overnight Indexed Swap: fixed vs RFR floating leg."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "a",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: str = "USD",
        amortization: Optional[Any] = None,
        fixed_amortization: Optional[Any] = None,
        float_amortization: Optional[Any] = None,
        compounding_method: Optional[str] = None,
        lockout: Optional[int] = None,
        lookback: Optional[int] = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


OIS = OvernightIndexedSwap


class Deposit:
    """Deposit instrument for short-end calibration."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


class IRFuture:
    """STIR Futures instrument with convexity adjustment."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        price: float = 100.0,
        notional: float = 1_000_000.0,
        convexity_adjustment: float = 0.0,
        convention: str = "act360",
        quote_convention: str = "price",
        sigma: Optional[float] = None,
        tick_size: Optional[float] = None,
        notional_multiplier: Optional[float] = None,
        contract_size: Optional[float] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


class CapFloor:
    """Cap/Floor instrument with Black-76 or Bachelier pricing."""

    def __init__(
        self,
        *,
        effective: datetime.date | None = None,
        termination: datetime.date | str | None = None,
        strike: float = 0.0,
        vol: float = 0.0,
        notional: float = 1_000_000.0,
        frequency: str = "q",
        cap_floor_type: str = "cap",
        model: str = "black76",
        convention: str = "act360",
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def npv(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, *, ctx: Optional[MarketContext] = None) -> Any: ...


class FixedRateBond:
    """Fixed Rate Bond with full analytics suite."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        coupon: float = 0.0,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cs01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def price_yield_sensitivity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


class Bill:
    """Zero-coupon bill (Treasury bill)."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        settlement_days: int = 1,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        face_value: float = 100.0,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...


class CreditDefaultSwap:
    """Credit Default Swap with hazard rate curve pricing."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "q",
        notional: float = 10_000_000.0,
        recovery_rate: float = 0.4,
        fixed_rate: float = 100.0,
        convention: str = "act360",
        currency: str = "USD",
        premium_accrued: bool = True,
        modifier: str = "mf",
        stub: str = "shortfront",
    ) -> None: ...
    def rate(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...
    def npv(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...
    def spread(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...
    def cashflows(self, disc_curve: CurveInput, credit_curve: CurveInput) -> pl.DataFrame: ...
    def accrued(self, today: Optional[datetime.date] = None) -> float: ...
    def analytic_rec_risk(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...
    def jtd(self, today: Optional[datetime.date] = None) -> float: ...
    def ead(self) -> float: ...
    def upfront(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...
    def to_upfront_spread(self, disc_curve: CurveInput, credit_curve: CurveInput) -> float: ...


CDS = CreditDefaultSwap


class CrossCurrencySwap:
    """Cross Currency Swap with 4-curve pricing model."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "q",
        leg1_currency: str = "EUR",
        leg2_currency: str = "USD",
        leg1_notional: float = 1_000_000.0,
        leg2_notional: float = 1_100_000.0,
        initial_fx_rate: float = 1.1,
        fixed_rate: Optional[float] = None,
        notional_exchange: bool = True,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        modifier: str = "mf",
        stub: str = "shortfront",
        mtm_leg: Optional[int] = None,
        leg1_disc_curve_id: Optional[str] = None,
        leg1_forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        leg2_forecast_curve_id: Optional[str] = None,
    ) -> None: ...
    def rate(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, metric: str = "leg2", *, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, *, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...


XCS = CrossCurrencySwap


class FXForward:
    """FX Forward instrument."""

    def __init__(
        self,
        *,
        pair: str = "eurusd",
        notional: float = 1_000_000.0,
        delivery: Optional[datetime.date] = None,
        currency: str = "USD",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
    ) -> None: ...
    def rate(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...


class NDF(FXForward):
    """Non-Deliverable FX Forward: single-currency net settlement."""

    def __init__(
        self,
        *,
        pair: str = "usdbrl",
        notional: float = 1_000_000.0,
        delivery: Optional[datetime.date] = None,
        settlement_currency: str = "usd",
        contracted_rate: Optional[float] = None,
        fx_fixing: Optional[float] = None,
        leg2_fx_fixing: Optional[float] = None,
        currency: Optional[str] = None,
        spec: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def spread(self, disc_curve: CurveInput = None, forecast_curve: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def pillar_date(self) -> datetime.date: ...
    def to_json(self) -> str: ...
    @classmethod
    def from_json(cls, json_str: str) -> "NDF": ...


class FloatRateNote:
    """Floating Rate Note (FRN)."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        spread: float = 0.0,
        frequency: str = "q",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


class ZeroCouponBond:
    """Zero Coupon Bond."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        settlement_days: int = 1,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        face_value: float = 100.0,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...


class StepUpBond:
    """Bond with coupon step-up schedule."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        coupon_schedule: Optional[list[tuple[datetime.date, float]]] = None,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...


class AmortizingBond:
    """Bond with declining notional and periodic principal repayments."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        coupon: float = 0.0,
        amortization_schedule: Optional[list[tuple[datetime.date, float]]] = None,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def i_spread(self, settlement: datetime.date, swap_curve: CurveInput = None) -> float: ...


class PIKBond:
    """Payment-in-kind bond where accrued interest compounds into notional."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        coupon: float = 0.0,
        pik_fraction: float = 1.0,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def i_spread(self, settlement: datetime.date, swap_curve: CurveInput = None) -> float: ...
    def notional_schedule(self) -> list[tuple[datetime.date, float]]: ...


class SubPeriodFRN:
    """Sub-Period Floating Rate Note with compounded fixings."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        spread: float = 0.0,
        frequency: str = "q",
        fixing_frequency: str = "m",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def i_spread(self, settlement: datetime.date, swap_curve: CurveInput = None) -> float: ...
    def sub_period_schedule(self) -> Optional[list[tuple[datetime.date, datetime.date, datetime.date, list[tuple[datetime.date, datetime.date, float, Optional[float]]]]]]: ...


class CappedFloatRateNote:
    """Capped and/or Floored Floating Rate Note."""

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        spread: float = 0.0,
        frequency: str = "q",
        fixing_frequency: Optional[str] = None,
        cap_rate: Optional[float] = None,
        floor_rate: Optional[float] = None,
        vol: Optional[float] = None,
        vol_model: str = "black76",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def dirty_price(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def accrued_interest(self, settlement: datetime.date) -> float: ...
    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def duration(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, metric: str = "modified", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def convexity(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def duration_from_ytm(self, ytm: float, settlement: datetime.date, metric: str = "modified", convention: str = "periodic") -> float: ...
    def convexity_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float: ...
    def dv01(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def z_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, settlement: Optional[datetime.date] = None, compounding: str = "annual", ctx: Optional[MarketContext] = None) -> float: ...
    def asw_spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, price: Optional[float] = None, method: str = "par_par", settlement: Optional[datetime.date] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None, future_only: bool = True, eval_date: Optional[datetime.date] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def analytic_delta(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def i_spread(self, settlement: datetime.date, swap_curve: CurveInput = None) -> float: ...
    def sub_period_schedule(self) -> Optional[list[tuple[datetime.date, datetime.date, datetime.date, list[tuple[datetime.date, datetime.date, float, Optional[float]]]]]]: ...


class NDIRS(InterestRateSwap):
    """Non-Deliverable Interest Rate Swap."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "s",
        fixed_rate: float = 0.0,
        notional: float = 1_000_000.0,
        convention: str = "act360",
        float_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        calendar: Optional[str] = None,
        payment_lag: Optional[int] = None,
        currency: Optional[str] = None,
        settlement_currency: str = "usd",
        pair: str = "usdbrl",
        fx_fixings: Optional[dict] = None,
        modifier: str = "mf",
        stub: str = "shortfront",
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, fx_rates: Any = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, fx_rates: Any = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, fx_rates: Any = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, fx_rates: Any = None, ctx: Optional[MarketContext] = None) -> float: ...
    def pillar_date(self) -> datetime.date: ...
    def to_json(self) -> str: ...
    @classmethod
    def from_json(cls, json_str: str) -> "NDIRS": ...


class NDXCS(CrossCurrencySwap):
    """Non-Deliverable Cross-Currency Swap."""

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Union[datetime.date, str, None] = None,
        frequency: str = "q",
        leg1_currency: str = "USD",
        leg2_currency: str = "BRL",
        leg1_notional: float = 1_000_000.0,
        leg2_notional: float = 5_000_000.0,
        initial_fx_rate: float = 5.0,
        fixed_rate: Optional[float] = None,
        notional_exchange: bool = True,
        convention: str = "act360",
        leg2_convention: Optional[str] = None,
        fixing_method: str = "rfr_payment_delay",
        spread: float = 0.0,
        modifier: str = "mf",
        stub: str = "shortfront",
        mtm_leg: Optional[int] = None,
        settlement_currency: str = "usd",
        nd_leg: int = 2,
        pair: Optional[str] = None,
        fx_fixings: Optional[dict] = None,
        calendar: Optional[str] = None,
        disc_curve_id: Optional[str] = None,
        forecast_curve_id: Optional[str] = None,
        leg2_disc_curve_id: Optional[str] = None,
        leg2_forecast_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
    def spread(self, leg1_disc: CurveInput = None, leg1_forecast: CurveInput = None, leg2_disc: CurveInput = None, leg2_forecast: CurveInput = None, fx_rates: Any = None, *, ctx: Optional[MarketContext] = None) -> float: ...
    def pillar_date(self) -> datetime.date: ...
    def to_json(self) -> dict: ...
    @classmethod
    def from_json(cls, data: dict) -> "NDXCS": ...


class AssetSwap:
    """Asset swap instrument for computing par and non-par spreads."""

    def __init__(
        self,
        bond: Any,
        *,
        asw_type: str = "par",
        dirty_price: Optional[float] = None,
        spread: Optional[float] = None,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ) -> None: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...


class CallableBond:
    """Callable/puttable bond priced via Hull-White trinomial tree."""

    def __init__(
        self,
        bond: Any,
        *,
        call_schedule: list[tuple],
        put_schedule: list[tuple] | None = None,
        disc_curve_id: str | None = None,
        index: str | None = None,
    ) -> None: ...
    def tree_price(self, curves: CurveInput = None, *, a: float, sigma: float, spread: float = 0.0, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def oas(self, curves: CurveInput = None, *, market_price: float, a: float, sigma: float, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def effective_duration(self, curves: CurveInput = None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def effective_convexity(self, curves: CurveInput = None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def vega(self, curves: CurveInput = None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def rate(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def npv(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> float: ...
    def cashflows(self, curves: CurveInput = None, *, solver: Optional[Solver] = None, ctx: Optional[MarketContext] = None) -> pl.DataFrame: ...
