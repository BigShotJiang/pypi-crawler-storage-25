class TextStudio:
    def __init__(self, text):
        self.text = text
    def to_morse(self):
        morse_code = {
            'A': '.-',
            'B': '-...',
            'C': '-.-.',
            'D': '-..',
            'E': '.',
            'F': '..-.',
            'G': '--.',
            'H': '....',
            'I': '..',
            'J': '.---',
            'K': '-.-',
            'L': '.-..',
            'M': '--',
            'N': '-.',
            'O': '---',
            'P': '.--.',
            'Q': '--.-',
            'R': '.-.',
            'S': '...',
            'T': '-',
            'U': '..-',
            'V': '...-',
            'W': '.--',
            'X': '-..-',
            'Y': '-.--',
            'Z': '--..',

            '0': '-----',
            '1': '.----',
            '2': '..---',
            '3': '...--',
            '4': '....-',
            '5': '.....',
            '6': '-....',
            '7': '--...',
            '8': '---..',
            '9': '----.',

            '.': '.-.-.-',
            ',': '--..--',
            '?': '..--..',
            '!': '-.-.--',
            '/': '-..-.',
            '(': '-.--.',
            ')': '-.--.-',
            ':': '---...',
            "'": '.----.',
            '=': '-...-',
            '+': '.-.-.',
            '-': '-....-',
            ' ': '/'
        }
        result = ''

        for letter in self.text.upper():
            result += f"{morse_code.get(letter, '?')} "

        return result.strip()

    def to_upper(self):
        return self.text.upper()

    def to_title(self):
        return self.text.title()

    def to_lower(self):
        return self.text.lower()

    def replace_with_spaces(self, replacement):
        return self.text.replace(replacement, ' ')

    def space_out_letters(self):
        result = ''
        for char in self.text:
            char = f' {char}'
            result += char
        return result

