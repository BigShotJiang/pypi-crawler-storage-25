import time


class Timer:
    def countdown(self, count, time_type, show):
        if time_type == 'min':
            count *= 60

        elif time_type == 'hour':
            count *= 3600

        for i in range(count, 0, -1):
            mins, secs = divmod(i, 60)

            show(f"{mins:02}:{secs:02}")

            time.sleep(1)

        show("⏰ Time's up!")

    def pomodoro(self, work_time, break_time, long_break_time, show):
        """ Enter work, break, and long break as mins.
            and show is how you're gonna show it.
            Example:
                speak
                print
                label.config"""
        reps = 0
        work_time *= 60
        break_time *= 60
        long_break_time *= 60
        running = True
        while running:
            reps += 1
            if reps % 8 == 0:
                show("⏰ Long Break Time")
                for i in range(long_break_time, 0, -1):
                    mins, secs = divmod(i, 60)

                    show(f"{mins:02}:{secs:02}")

                    time.sleep(1)
            elif reps % 2 == 0:
                show("☕ Short Break Time")
                for i in range(break_time, 0, -1):
                    mins, secs = divmod(i, 60)

                    show(f"{mins:02}:{secs:02}")

                    time.sleep(1)
            else:
                show("💻 Work Time")
                for i in range(work_time, 0, -1):
                    mins, secs = divmod(i, 60)

                    show(f"{mins:02}:{secs:02}")

                    time.sleep(1)
