# yoyo-bgw

## A cozy Python package with greetings, bedtime stories, quotes, and friendly messages.

#### Created by Youssef.

---

# Requirements
- #### + Python 3.11

---

# Installation

#### Install the package:

```bash
pip install yoyo-bgw
```
---
#### Update the package:
```bash
pip install --upgrade yoyo-bgw
```
---

## What is this package?

### yoyo-bgw is a friendly Python package that provides:

#### Welcome messages
#### Goodbye messages
#### Morning greetings
#### Bedtime stories
#### Motivational quotes
#### JSON-powered random content...

#### The package is designed to be simple, cozy, and beginner-friendly. 

# Using the package and its classes

---
## How to use this package:
### Import it:
```python
from yoyo import Yoyo
```
---
### Then create the object:
```python
from yoyo import Yoyo

example_name = Yoyo(
                name='Example',
                age=12,
                height=12,
                weight=13,
                eye_color='blue',
                hair_color='black',
                gender='male',
                nickname='Example'
)
```
---

### Functions

- `welcome()` welcomes you
- `good_morning()` gives you a morning quote
- `good_afternoon()` gives you an afternoon quote
- `good_evening()` gives you an evening quote
- `good_night()` tells you a bedtime story
- `auto_greet()` calls the specific function depending on the time and season
- `bye()` tells you goodbye
---

## Example Usage:
```python
from yoyo import Yoyo

person = Yoyo(
    name="Youssef",
    nickname="Yoyo"
)

print(person.welcome())
```
---

## Example Output:
```
Welcome Youssef!
Or welcome Yoyo!
```
---

## How to use the Timer class
### Import it:
```python
from yoyo import Timer
```
---

### Then create the object:
```python
from yoyo import Timer

timer = Timer() # No parameters required currently
```
---

### Functions:

- `countdown(count, time_type, show)` 
#### Enter the count amount,
#### then if it is min/hour/sec.
#### The `show` parameter allows custom output systems such as:
- print
- pyttsx3 speech
- Tkinter labels
- custom logging functions

---

## Example Usage:
```python
from yoyo import Timer

timer = Timer()
timer.countdown(10, 'sec', print)
timer.pomodoro(work_time=25, break_time=5, long_break_time=25, show=print)
```
---

## Example Output:
```
00:10
00:09
00:08
...
Time's Up!

💻 Work Time
25:00
...
00:01

☕ Short Break Time
05:00
...
00:01

⏰ Long Break Time
25:00
```
---

# How to use the TextStudio class
## Import it:
```python
from yoyo import TextStudio
```
---

## Then create the object:
```python
from yoyo import TextStudio

text_editor = TextStudio(
    text='Blah-blAh-TExt'
)
```
---
## Functions:

- `to_morse()`
- `to_upper()`
- `to_title()`
- `to_lower()`
- `space_out_letters()`
- `replace_with_spaces()`
---
## Example Usage:
```python
from yoyo import TextStudio

text_editor = TextStudio(
    text="Blah-blAh-TExt"
)
text_editor.to_lower()
text_editor.to_upper()
text_editor.to_title()
text_editor.replace_with_spaces(replacement='-') # Replacement is the letter you're gonna replace with spaces.
text_editor.space_out_letters()
```
---

## Example Output:
```text
blah-blah-text
BLAH-BLAH-TEXT
Blah-Blah-Text
Blah blAh TExt
B l a h  b l A h  T E x t
```