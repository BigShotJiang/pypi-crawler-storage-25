#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

from .buffer_utils import HexShmRingBuffer
from .file_utils import hex_rmtree
from .time_utils import hex_ts_to_ns, ns_to_hex_ts, ns_now, hex_ts_now, hex_ts_delta_ms, HexRate

__all__ = [
    # buffer_utils
    "HexShmRingBuffer",

    # file_utils
    "hex_rmtree",

    # time_utils
    "hex_ts_to_ns",
    "ns_to_hex_ts",
    "ns_now",
    "hex_ts_now",
    "hex_ts_delta_ms",
    "HexRate",

    # dora_utils
    "get_dora_node_name",
    "get_dora_bool",
]

HAS_DORA = False
try:
    import dora
    HAS_DORA = True
except ImportError:
    pass

if HAS_DORA:
    from .dora_utils import get_dora_node_name, get_dora_bool
    from .dora_utils import color_encode, depth_encode, color_decode, depth_decode
    __all__.extend([
        "get_dora_node_name",
        "get_dora_bool",
        "color_encode",
        "depth_encode",
        "color_decode",
        "depth_decode",
    ])
