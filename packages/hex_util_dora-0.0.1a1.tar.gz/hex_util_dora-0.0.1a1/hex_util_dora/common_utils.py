#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-13
################################################################

from __future__ import annotations

from typing import Any

import cv2
import numpy as np
import pyarrow as pa

_COLOR_ENCODERS: dict[str, Any] = {
    "bgr8":
    lambda img: pa.array(img.ravel()),
    "mjpg":
    lambda img: pa.array(
        cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, 75])[1].tobytes()
    ),
}

_DEPTH_ENCODERS: dict[str, Any] = {
    "uint16":
    lambda img: pa.array(img.ravel()),
    "png":
    lambda img: pa.array(
        cv2.imencode('.png', img, [cv2.IMWRITE_PNG_COMPRESSION, 1])[1].tobytes(
        )),
}

_COLOR_DECODERS: dict[str, Any] = {
    "bgr8": lambda data, meta: data.reshape(meta["height"], meta["width"], 3),
    "mjpg":
    lambda data, _: cv2.imdecode(data.astype(np.uint8), cv2.IMREAD_COLOR),
}

_DEPTH_DECODERS: dict[str, Any] = {
    "uint16":
    lambda data, meta: data.reshape(meta["height"], meta["width"]),
    "png":
    lambda data, _: cv2.imdecode(data.astype(np.uint8), cv2.IMREAD_UNCHANGED),
}


def get_dora_node_name(env_name: str = "") -> str:
    return env_name if env_name else "NODE_NAME"


def get_dora_bool(env_bool: str = "False") -> bool:
    return env_bool.lower() in ('true', '1', 'yes')


# ── image encode / decode ────────────────────────────────────


def _image_encode(
    image: np.ndarray,
    encoding: str,
    metadata: dict[str, str],
    encoders: dict[str, Any],
) -> tuple[pa.Array, dict[str, str]]:
    metadata.pop("timestamp", None)
    metadata.update(
        encoding=encoding,
        width=str(image.shape[1]),
        height=str(image.shape[0]),
        primitive="image",
    )

    encoder = encoders.get(encoding)
    if encoder is None:
        raise ValueError(f"Unsupported encoding: {encoding}")
    return encoder(image), metadata


def _image_decode(
    storage: pa.Array,
    metadata: dict[str, str],
    decoders: dict[str, Any],
) -> np.ndarray:
    data = storage.to_numpy()
    encoding = metadata["encoding"]

    decoder = decoders.get(encoding)
    if decoder is None:
        raise ValueError(f"Unsupported encoding: {encoding}")

    meta = {
        "width": int(metadata["width"]),
        "height": int(metadata["height"]),
    }
    return decoder(data, meta)


def color_encode(
    color: np.ndarray,
    encoding: str,
    metadata: dict[str, str],
) -> tuple[pa.Array, dict[str, str]]:
    return _image_encode(color, encoding, metadata, _COLOR_ENCODERS)


def depth_encode(
    depth: np.ndarray,
    encoding: str,
    metadata: dict[str, str],
) -> tuple[pa.Array, dict[str, str]]:
    return _image_encode(depth, encoding, metadata, _DEPTH_ENCODERS)


def color_decode(
    storage: pa.Array,
    metadata: dict[str, str],
) -> np.ndarray:
    return _image_decode(storage, metadata, _COLOR_DECODERS)


def depth_decode(
    storage: pa.Array,
    metadata: dict[str, str],
) -> np.ndarray:
    return _image_decode(storage, metadata, _DEPTH_DECODERS)
