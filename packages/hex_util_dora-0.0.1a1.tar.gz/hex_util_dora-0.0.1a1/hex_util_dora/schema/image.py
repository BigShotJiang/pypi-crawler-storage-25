#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-16
################################################################

import pyarrow as pa

IMAGE_COLOR_SCHEMA = pa.schema([
    pa.field("width", pa.int32()),
    pa.field("height", pa.int32()),
    pa.field("encoding", pa.string()),
    pa.field("data", pa.binary()),
])

IMAGE_DEPTH_SCHEMA = pa.schema([
    pa.field("width", pa.int32()),
    pa.field("height", pa.int32()),
    pa.field("encoding", pa.string()),
    pa.field("data", pa.binary()),
])
