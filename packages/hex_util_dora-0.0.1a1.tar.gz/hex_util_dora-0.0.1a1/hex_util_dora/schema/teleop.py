#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-16
################################################################

import pyarrow as pa

TELEOP_KEYBOARD_SCHEMA = pa.schema([
    # keys
    pa.field("a", pa.bool_()),
    pa.field("b", pa.bool_()),
    pa.field("c", pa.bool_()),
    pa.field("d", pa.bool_()),
    pa.field("e", pa.bool_()),
    pa.field("f", pa.bool_()),
    pa.field("g", pa.bool_()),
    pa.field("h", pa.bool_()),
    pa.field("i", pa.bool_()),
    pa.field("j", pa.bool_()),
    pa.field("k", pa.bool_()),
    pa.field("l", pa.bool_()),
    pa.field("m", pa.bool_()),
    pa.field("n", pa.bool_()),
    pa.field("o", pa.bool_()),
    pa.field("p", pa.bool_()),
    pa.field("q", pa.bool_()),
    pa.field("r", pa.bool_()),
    pa.field("s", pa.bool_()),
    pa.field("t", pa.bool_()),
    pa.field("u", pa.bool_()),
    pa.field("v", pa.bool_()),
    pa.field("w", pa.bool_()),
    pa.field("x", pa.bool_()),
    pa.field("y", pa.bool_()),
    pa.field("z", pa.bool_()),
])

TELEOP_JOYSTICK_SCHEMA = pa.schema([
    # buttons
    pa.field("btn_a", pa.bool_()),
    pa.field("btn_b", pa.bool_()),
    pa.field("btn_x", pa.bool_()),
    pa.field("btn_y", pa.bool_()),
    pa.field("btn_lb", pa.bool_()),
    pa.field("btn_rb", pa.bool_()),
    pa.field("btn_lt", pa.bool_()),
    pa.field("btn_rt", pa.bool_()),
    pa.field("btn_lthumb", pa.bool_()),
    pa.field("btn_rthumb", pa.bool_()),
    # axes
    pa.field("axis_lx", pa.float32()),
    pa.field("axis_ly", pa.float32()),
    pa.field("axis_rx", pa.float32()),
    pa.field("axis_ry", pa.float32()),
    pa.field("axis_lt", pa.float32()),
    pa.field("axis_rt", pa.float32()),
    # hats
    pa.field("hat_x", pa.float32()),
    pa.field("hat_y", pa.float32()),
])
