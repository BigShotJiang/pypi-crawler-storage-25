#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-17
################################################################

import pyarrow as pa

GRIP_STATE_MOTOR_SCHEMA = pa.schema([
    pa.field("pos", pa.list_(pa.float32())),
    pa.field("vel", pa.list_(pa.float32())),
    pa.field("eff", pa.list_(pa.float32())),
])

GRIP_STATE_HELLO_SCHEMA = pa.schema([
    pa.field("trigger", pa.float32()),
    pa.field("axis_x", pa.float32()),
    pa.field("axis_y", pa.float32()),
    pa.field("btn_x", pa.bool_()),
    pa.field("btn_y", pa.bool_()),
    pa.field("btn_z", pa.bool_()),
    pa.field("btn_w", pa.bool_()),
])

GRIP_CTRL_MIT_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("vel_tar", pa.list_(pa.float32())),
    pa.field("eff_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])

GRIP_CTRL_COMP_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("vel_tar", pa.list_(pa.float32())),
    pa.field("eff_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])

GRIP_CTRL_POS_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])
