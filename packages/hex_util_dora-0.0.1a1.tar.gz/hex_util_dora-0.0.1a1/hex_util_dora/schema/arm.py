#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-17
################################################################

import pyarrow as pa

ARM_STATE_MOTOR_SCHEMA = pa.schema([
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("vel_tar", pa.list_(pa.float32())),
    pa.field("eff_tar", pa.list_(pa.float32())),
])

ARM_STATE_GRIP_SCHEMA = pa.schema([
    pa.field("pos", pa.list_(pa.float32())),
    pa.field("quat", pa.list_(pa.float32())),
])

ARM_CTRL_MIT_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("vel_tar", pa.list_(pa.float32())),
    pa.field("eff_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])

ARM_CTRL_COMP_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("vel_tar", pa.list_(pa.float32())),
    pa.field("eff_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])

ARM_CTRL_POS_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])

ARM_CTRL_POSE_SCHEMA = pa.schema([
    pa.field("type", pa.string()),
    pa.field("pos_tar", pa.list_(pa.float32())),
    pa.field("quat_tar", pa.list_(pa.float32())),
    pa.field("kp", pa.list_(pa.float32())),
    pa.field("kd", pa.list_(pa.float32())),
])
