#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-16
################################################################

import pyarrow as pa

BOOL_SCHEMA = pa.schema([
    pa.field("value", pa.bool_()),
])