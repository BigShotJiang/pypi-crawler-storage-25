from .chunker import ChunkResult, split_csv

__all__ = ["ChunkResult", "split_csv"]
__version__ = "0.2.5"
