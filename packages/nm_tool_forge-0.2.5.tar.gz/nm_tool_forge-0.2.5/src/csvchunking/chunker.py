import csv
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ChunkResult:
    input_file: Path
    output_dir: Path
    chunk_size: int
    data_rows_processed: int
    files_created: int
    output_files: tuple[Path, ...]


def cleanup_existing_chunks(output_dir: Path, input_file: Path) -> None:
    output_dir = Path(output_dir)
    if not output_dir.exists():
        return

    input_file = Path(input_file)
    pattern = re.compile(
        rf"^{re.escape(input_file.stem)}_\d{{2,}}{re.escape(input_file.suffix)}$"
    )

    for existing_file in output_dir.iterdir():
        if existing_file.is_file() and pattern.fullmatch(existing_file.name):
            existing_file.unlink()


def split_csv(
    input_file: Path,
    chunk_size: int,
    encoding: str = "utf-8-sig",
) -> ChunkResult:
    if not Path(input_file).is_file():
        raise FileNotFoundError(f"Input file not found: {input_file}")
    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than 0")

    input_file = Path(input_file)
    output_dir = input_file.parent / input_file.stem
    output_dir.mkdir(exist_ok=True)
    cleanup_existing_chunks(output_dir, input_file)

    # Detect the delimiter automatically.
    with open(input_file, encoding=encoding, newline="") as f:
        sample = f.read(4096)
        f.seek(0)
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except Exception:
            dialect = csv.excel
            dialect.delimiter = ";"
        reader = csv.reader(f, dialect)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise ValueError("Input file is empty.") from exc
        chunk = []
        file_count = 0
        data_rows = 0
        output_files = []
        for row in reader:
            chunk.append(row)
            data_rows += 1
            if len(chunk) == chunk_size:
                file_count += 1
                out_path = output_dir / f"{input_file.stem}_{file_count:02d}{input_file.suffix}"
                with open(out_path, "w", encoding=encoding, newline="") as out:
                    writer = csv.writer(out, dialect)
                    writer.writerow(header)
                    writer.writerows(chunk)
                output_files.append(out_path)
                chunk = []
        if chunk:
            file_count += 1
            out_path = output_dir / f"{input_file.stem}_{file_count:02d}{input_file.suffix}"
            with open(out_path, "w", encoding=encoding, newline="") as out:
                writer = csv.writer(out, dialect)
                writer.writerow(header)
                writer.writerows(chunk)
            output_files.append(out_path)
    return ChunkResult(
        input_file=input_file,
        output_dir=output_dir,
        chunk_size=chunk_size,
        data_rows_processed=data_rows,
        files_created=file_count,
        output_files=tuple(output_files),
    )
