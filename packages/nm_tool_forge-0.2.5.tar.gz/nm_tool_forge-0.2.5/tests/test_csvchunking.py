import pytest

from csvchunking.chunker import split_csv


def make_csv(tmp_path, name, header, rows, encoding="utf-8-sig", delimiter=";"):
    file = tmp_path / name
    with open(file, "w", encoding=encoding, newline="") as f:
        f.write(delimiter.join(header) + "\n")
        for row in rows:
            f.write(delimiter.join(row) + "\n")
    return file


def test_regular_split(tmp_path):
    header = ["col1", "col2"]
    rows = [["A", "1"], ["B", "2"], ["C", "3"], ["D", "4"], ["E", "5"]]
    file = make_csv(tmp_path, "sample.csv", header, rows)
    result = split_csv(file, chunk_size=2)
    assert result.files_created == 3
    for out in result.output_files:
        with open(out, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
            assert lines[0] == "col1;col2"
    assert (result.output_dir / "sample_01.csv").exists()
    assert (result.output_dir / "sample_02.csv").exists()
    assert (result.output_dir / "sample_03.csv").exists()


def test_header_in_each_file(tmp_path):
    header = ["foo", "bar"]
    rows = [["x", "1"], ["y", "2"], ["z", "3"]]
    file = make_csv(tmp_path, "test.csv", header, rows)
    result = split_csv(file, chunk_size=1)
    for out in result.output_files:
        with open(out, encoding="utf-8-sig") as f:
            assert f.readline().strip() == "foo;bar"


def test_filename_with_spaces(tmp_path):
    header = ["a", "b"]
    rows = [["1", "2"]]
    file = make_csv(tmp_path, "Part-Storage Areas Relationships.csv", header, rows)
    result = split_csv(file, chunk_size=1)
    assert result.output_dir.name == "Part-Storage Areas Relationships"
    assert (result.output_dir / "Part-Storage Areas Relationships_01.csv").exists()


def test_cleanup_removes_stale_matching_chunk_files(tmp_path):
    header = ["col1", "col2"]
    rows = [["A", "1"], ["B", "2"], ["C", "3"], ["D", "4"]]
    file = make_csv(tmp_path, "sample.csv", header, rows)
    output_dir = tmp_path / "sample"
    output_dir.mkdir()
    for name in ("sample_01.csv", "sample_02.csv", "sample_03.csv"):
        (output_dir / name).write_text("old chunk\n", encoding="utf-8-sig")

    result = split_csv(file, chunk_size=2)

    assert result.files_created == 2
    assert (result.output_dir / "sample_01.csv").exists()
    assert (result.output_dir / "sample_02.csv").exists()
    assert not (result.output_dir / "sample_03.csv").exists()


def test_cleanup_keeps_non_matching_csv_files_and_subdirectories(tmp_path):
    header = ["col1", "col2"]
    rows = [["A", "1"], ["B", "2"]]
    file = make_csv(tmp_path, "sample.csv", header, rows)
    output_dir = tmp_path / "sample"
    output_dir.mkdir()
    preserved_files = [
        "notes.csv",
        "sample_backup.csv",
        "sample_old.csv",
        "other_01.csv",
        "sample_1.csv",
    ]
    for name in preserved_files:
        (output_dir / name).write_text("keep\n", encoding="utf-8-sig")
    matching_subdir = output_dir / "sample_99.csv"
    matching_subdir.mkdir()
    (matching_subdir / "nested.txt").write_text("keep nested\n", encoding="utf-8-sig")

    result = split_csv(file, chunk_size=1)

    for name in preserved_files:
        assert (result.output_dir / name).exists()
    assert matching_subdir.is_dir()
    assert (matching_subdir / "nested.txt").exists()


def test_cleanup_filename_with_spaces_uses_exact_chunk_pattern(tmp_path):
    header = ["a", "b"]
    rows = [["1", "2"], ["3", "4"], ["5", "6"], ["7", "8"]]
    filename = "Part-Storage Areas Relationships.csv"
    file = make_csv(tmp_path, filename, header, rows)
    output_dir = tmp_path / "Part-Storage Areas Relationships"
    output_dir.mkdir()
    for name in (
        "Part-Storage Areas Relationships_01.csv",
        "Part-Storage Areas Relationships_02.csv",
        "Part-Storage Areas Relationships_99.csv",
    ):
        (output_dir / name).write_text("old chunk\n", encoding="utf-8-sig")
    backup_file = output_dir / "Part-Storage Areas Relationships_backup.csv"
    backup_file.write_text("keep\n", encoding="utf-8-sig")

    result = split_csv(file, chunk_size=2)

    assert result.output_dir == output_dir
    assert (result.output_dir / "Part-Storage Areas Relationships_01.csv").exists()
    assert (result.output_dir / "Part-Storage Areas Relationships_02.csv").exists()
    assert not (result.output_dir / "Part-Storage Areas Relationships_99.csv").exists()
    assert backup_file.exists()
    assert "old chunk" not in (
        result.output_dir / "Part-Storage Areas Relationships_01.csv"
    ).read_text(encoding="utf-8-sig")


def test_cleanup_repeated_run_removes_extra_chunks(tmp_path):
    header = ["col1", "col2"]
    first_rows = [["A", "1"], ["B", "2"], ["C", "3"], ["D", "4"], ["E", "5"]]
    file = make_csv(tmp_path, "sample.csv", header, first_rows)
    first_result = split_csv(file, chunk_size=2)
    assert first_result.files_created == 3
    assert (first_result.output_dir / "sample_03.csv").exists()

    second_rows = [["A", "1"], ["B", "2"]]
    make_csv(tmp_path, "sample.csv", header, second_rows)
    second_result = split_csv(file, chunk_size=2)

    assert second_result.files_created == 1
    assert (second_result.output_dir / "sample_01.csv").exists()
    assert not (second_result.output_dir / "sample_02.csv").exists()
    assert not (second_result.output_dir / "sample_03.csv").exists()


def test_invalid_chunk_size(tmp_path):
    header = ["a", "b"]
    rows = [["1", "2"]]
    file = make_csv(tmp_path, "fail.csv", header, rows)
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=0)
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=-1)


def test_empty_file(tmp_path):
    file = tmp_path / "empty.csv"
    file.write_text("")
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=1)
