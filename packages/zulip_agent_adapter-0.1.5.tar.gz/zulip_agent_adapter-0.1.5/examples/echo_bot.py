#!/usr/bin/env python3
"""
Simple echo bot example for Zulip Agent Adapter.

Echoes back any message it receives when @mentioned.

Setup:
    1. Create a bot in your Zulip organization settings
    2. Set environment variables (see below) or edit the config inline
    3. Run: python echo_bot.py

Environment variables:
    ZULIP_URL         https://your-org.zulipchat.com
    ZULIP_BOT_EMAIL   bot@your-org.zulipchat.com
    ZULIP_API_KEY     (from Zulip bot settings)
"""

import asyncio
import os
from zulip_agent_adapter import ZulipAdapter, ZulipConfig


async def main():
    # Option A: load from environment
    # config = ZulipConfig.from_env()

    # Option B: configure inline
    config = ZulipConfig(
        base_url=os.getenv("ZULIP_URL", "https://your-org.zulipchat.com"),
        bot_email=os.getenv("ZULIP_BOT_EMAIL", "bot@your-org.zulipchat.com"),
        api_key=os.getenv("ZULIP_API_KEY", "your-api-key-here"),
        chatmode="oncall",
        default_topic="bot-testing",
    )

    adapter = ZulipAdapter(config)

    async def on_message(event):
        """Handle incoming messages by echoing them back."""
        print(f"\n[{event.source.chat_name}]")
        print(f"  From: {event.source.user_name}")
        print(f"  Text: {event.text[:80]}{'...' if len(event.text) > 80 else ''}")

        if event.message_type.value == "command":
            return

        result = await adapter.send(
            event.source.chat_id,
            f"Echo: {event.text}",
            topic=event.source.chat_topic,
        )

        if result.success:
            print(f"  Replied (msg_id: {result.message_id})")
        else:
            print(f"  Error: {result.error}")

    adapter.on_message = on_message

    print("Connecting to Zulip...")
    connected = await adapter.connect()

    if not connected:
        print("Failed to connect. Check your credentials.")
        return

    print(f"Connected as {adapter._bot_full_name}!")
    print("Mention the bot in Zulip to see it echo back.")
    print("Press Ctrl+C to disconnect.\n")

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("\nDisconnecting...")
        await adapter.disconnect()
        print("Done.")


if __name__ == "__main__":
    asyncio.run(main())
