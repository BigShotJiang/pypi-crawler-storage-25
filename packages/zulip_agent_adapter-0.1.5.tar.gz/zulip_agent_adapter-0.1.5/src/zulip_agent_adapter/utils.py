"""
Utility functions for Zulip Agent Adapter.
"""

import json
import re
from typing import Any, Optional


def normalize_zulip_topic(topic: str) -> str:
    """Normalize topic string for sticky map keys.

    Args:
        topic: Raw topic string

    Returns:
        Lowercase, whitespace-normalized topic
    """
    return " ".join((topic or "").strip().split()).lower()


def build_sticky_key(stream_id: int, topic: str) -> str:
    """Build a unique key for channel+topic combination.

    Args:
        stream_id: Zulip stream/channel ID
        topic: Topic name

    Returns:
        Unique key string
    """
    return f"{stream_id}\x1f{normalize_zulip_topic(topic)}"


def parse_zulip_retry_after(resp: Any, body: str) -> Optional[float]:
    """Parse retry-after from a Zulip 429 response.

    Zulip includes a ``retry-after`` field in the JSON body of 429 responses.
    Some deployments may also set a ``Retry-After`` HTTP header; we check
    the header first, then fall back to the JSON body.

    See https://zulip.com/api/rest-error-handling for rate-limit details.

    Args:
        resp: Response object with a ``headers`` attribute
        body: Response body string

    Returns:
        Seconds to wait before retrying, or None if not parseable
    """
    ra = resp.headers.get("Retry-After") if resp is not None else None
    if ra:
        try:
            return float(str(ra).strip())
        except ValueError:
            pass

    try:
        data = json.loads(body) if body else {}
    except json.JSONDecodeError:
        return None

    val = data.get("retry-after")
    if val is None:
        val = data.get("retry_after")
    if val is None:
        return None

    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def resolve_sticky_feature_enabled(
    chatmode: str,
    require_mention: bool,
    explicit: Optional[bool],
) -> bool:
    """Determine if sticky topic feature should be enabled.

    Defaults to on for oncall mode with mention gating, unless overridden.

    Args:
        chatmode: Chat mode (oncall, onmessage, onchar)
        require_mention: Whether mention is required
        explicit: Explicit override setting

    Returns:
        True if sticky feature should be enabled
    """
    if explicit is not None:
        return explicit
    if chatmode == "oncall" and require_mention:
        return True
    return False


def is_unfocus_message(text: str, bot_full_name: str) -> bool:
    """Check if message is an explicit unfocus command.

    Matches:
    - /unfocus (at start of message)
    - @**Bot Name** unfocus

    Args:
        text: Message text
        bot_full_name: Bot's full name for mention matching

    Returns:
        True if this is an unfocus command
    """
    t = (text or "").strip()
    if not t:
        return False

    first = t.split()[0]
    if first.rstrip(".,!?;:") == "/unfocus":
        return True

    safe = re.escape(bot_full_name.strip())
    pat = re.compile(
        rf"^@\*\*{safe}\*\*\s+unfocus\b",
        re.IGNORECASE | re.DOTALL,
    )
    return bool(pat.match(t))


def format_zulip_message(content: str) -> str:
    """Format message content for Zulip.

    Zulip uses its own markdown variant. This converts standard markdown
    image syntax to plain URLs (Zulip renders URL previews natively).

    Args:
        content: Raw message content

    Returns:
        Formatted content for Zulip
    """
    content = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r"\2", content)
    return content
