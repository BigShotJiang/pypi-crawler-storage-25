"""
Main Zulip adapter implementation.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import re
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .models import MessageEvent, MessageSource, MessageType, SendResult, ZulipConfig
from .utils import (
    build_sticky_key,
    format_zulip_message,
    is_unfocus_message,
    parse_zulip_retry_after,
    resolve_sticky_feature_enabled,
)

logger = logging.getLogger(__name__)

# Reconnection settings
_RECONNECT_BASE_DELAY = 2.0
_RECONNECT_MAX_DELAY = 60.0
_RECONNECT_JITTER = 0.2

# Rate limit logging throttle
_ZULIP_429_LOG_THROTTLE_SEC = 45.0

# Message deduplication
_SEEN_MAX = 2000
_SEEN_TTL = 300


class ZulipAdapter:
    """Async adapter for Zulip integration.

    Connects via the Zulip REST API: registers an event queue, long-polls
    ``/api/v1/events``, and sends messages via ``POST /api/v1/messages``.
    Uses HTTP Basic auth (bot email + API key).

    Features:
    - Automatic reconnection with exponential backoff
    - Rate limit handling with retry-after support
    - Message deduplication
    - Sticky topic focus (stay engaged after mention)
    - Channel filtering
    """

    # Zulip's hard limit is 10,000 characters; we leave a small margin.
    MAX_MESSAGE_LENGTH = 9900

    def __init__(self, config: ZulipConfig):
        """Initialize the adapter.

        Args:
            config: Zulip configuration
        """
        self.config = config

        self._session: Any = None
        self._poll_task: Optional[asyncio.Task] = None
        self._closing = False

        self._bot_user_id: int = -1
        self._bot_full_name: str = ""

        self._queue_id: Optional[str] = None
        self._last_event_id: int = -1

        self._last_events_429_log_ts: float = 0.0

        # Message deduplication
        self._seen_messages: Dict[str, float] = {}

        # Sticky topic focus
        self._sticky_topic_expiry: Dict[str, float] = {}

        # Channel filtering
        self._streams_allow = self._parse_streams_allow()
        self._free_streams: Set[str] = {
            x.strip()
            for x in self.config.free_response_streams.split(",")
            if x.strip()
        }

        # Determine if mention is required
        self._require_mention = self._resolve_require_mention()

        # Callback for message handling
        self.on_message: Optional[Callable[[MessageEvent], asyncio.Future]] = None

    def _parse_streams_allow(self) -> Set[str]:
        """Parse allowed channels from config."""
        raw = self.config.streams
        if raw.strip() == "*":
            return {"*"}
        parts = [p.strip() for p in raw.replace(",", " ").split() if p.strip()]
        return set(parts) if parts else {"*"}

    def _resolve_require_mention(self) -> bool:
        """Determine if mention is required based on config."""
        if self.config.require_mention is not None:
            return self.config.require_mention
        if self.config.chatmode == "oncall":
            return True
        if self.config.chatmode in ("onmessage", "onchar"):
            return False
        return True

    def _sticky_enabled(self) -> bool:
        """Check if sticky topic feature is enabled."""
        return resolve_sticky_feature_enabled(
            self.config.chatmode,
            self._require_mention,
            self.config.sticky_topic_after_mention,
        )

    def _auth(self) -> Any:
        """Create authentication object for aiohttp."""
        import aiohttp
        return aiohttp.BasicAuth(self.config.bot_email, self.config.api_key)

    async def _api_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make GET request to Zulip API."""
        import aiohttp

        url = f"{self.config.base_url}/api/v1/{path.lstrip('/')}"
        try:
            async with self._session.get(
                url,
                auth=self._auth(),
                params=params,
                timeout=aiohttp.ClientTimeout(total=120),
            ) as resp:
                body = await resp.text()
                if resp.status >= 400:
                    logger.error("Zulip GET %s → %s: %s", path, resp.status, body[:300])
                    return {}
                return json.loads(body) if body else {}
        except Exception as exc:
            logger.error("Zulip GET %s error: %s", path, exc)
            return {}

    async def _api_post(
        self, path: str, payload: Dict[str, Any], use_json: bool = False
    ) -> Tuple[Dict[str, Any], int]:
        """Make POST request to Zulip API."""
        import aiohttp

        url = f"{self.config.base_url}/api/v1/{path.lstrip('/')}"
        try:
            post_kwargs = {"auth": self._auth(), "timeout": aiohttp.ClientTimeout(total=60)}
            if use_json:
                post_kwargs["json"] = payload
            else:
                post_kwargs["data"] = payload

            async with self._session.post(url, **post_kwargs) as resp:
                body = await resp.text()
                data = json.loads(body) if body else {}
                return data, resp.status
        except Exception as exc:
            logger.error("Zulip POST %s error: %s", path, exc)
            return {}, 0

    async def _api_patch(
        self, path: str, payload: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], int]:
        """Make PATCH request to Zulip API."""
        import aiohttp

        url = f"{self.config.base_url}/api/v1/{path.lstrip('/')}"
        try:
            async with self._session.patch(
                url,
                auth=self._auth(),
                json=payload,
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                body = await resp.text()
                data = json.loads(body) if body else {}
                return data, resp.status
        except Exception as exc:
            logger.error("Zulip PATCH %s error: %s", path, exc)
            return {}, 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> bool:
        """Connect to Zulip and start event polling.

        Returns:
            True if connection successful, False otherwise
        """
        import aiohttp

        if not self.config.base_url or not self.config.bot_email or not self.config.api_key:
            logger.error("Zulip: base_url, bot_email, and api_key are required")
            return False

        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=120)
        )
        self._closing = False

        me = await self._api_get("users/me")
        if not me or me.get("result") == "error" or me.get("user_id") is None:
            logger.error("Zulip: failed to authenticate — check credentials")
            await self._session.close()
            return False

        self._bot_user_id = int(me.get("user_id", -1))
        self._bot_full_name = (me.get("full_name") or me.get("email") or "bot").strip()
        logger.info(
            "Zulip: authenticated as %s (%s) on %s",
            self._bot_full_name,
            self._bot_user_id,
            self.config.base_url,
        )

        if not await self._register_queue():
            await self._session.close()
            return False

        self._poll_task = asyncio.create_task(self._poll_loop())
        return True

    async def _register_queue(self) -> bool:
        """Register event queue with Zulip."""
        data, status = await self._api_post(
            "register",
            {"event_types": json.dumps(["message"]), "all_public_streams": "false"},
        )
        if status >= 400 or data.get("result") == "error":
            logger.error("Zulip: register failed: %s", data)
            return False
        self._queue_id = data.get("queue_id")
        self._last_event_id = int(data.get("last_event_id", -1))
        if not self._queue_id:
            logger.error("Zulip: register returned no queue_id")
            return False
        logger.info("Zulip: event queue registered (last_event_id=%s)", self._last_event_id)
        return True

    async def disconnect(self) -> None:
        """Disconnect from Zulip and cleanup."""
        self._closing = True
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        if self._session and not self._session.closed:
            await self._session.close()
        logger.info("Zulip: disconnected")

    # ------------------------------------------------------------------
    # Send / edit
    # ------------------------------------------------------------------

    def _resolve_topic(self, topic: Optional[str] = None) -> str:
        """Resolve topic for outgoing message."""
        if topic and topic.strip():
            return topic.strip()
        return self.config.default_topic

    async def send(
        self,
        chat_id: str,
        content: str,
        reply_to: Optional[str] = None,
        topic: Optional[str] = None,
    ) -> SendResult:
        """Send a message to Zulip.

        Args:
            chat_id: Target chat ID (``"stream:ID"`` or ``"private:ID1,ID2"``)
            content: Message content (Zulip markdown)
            reply_to: Reserved for future use; not currently sent to Zulip.
            topic: Topic name for channel messages (uses default_topic if omitted)

        Returns:
            SendResult with success status and message ID
        """
        if not content:
            return SendResult(success=True)

        formatted = format_zulip_message(content)
        chunks = self._chunk_message(formatted, self.MAX_MESSAGE_LENGTH)
        last_id = None

        for chunk in chunks:
            payload, err = self._build_send_payload(chat_id, chunk, topic)
            if err:
                return SendResult(success=False, error=err)

            data, status = await self._api_post("messages", payload)
            if status >= 400 or data.get("result") == "error":
                msg = data.get("msg", data)
                return SendResult(success=False, error=str(msg))

            last_id = str(data.get("id", "")) if data.get("id") is not None else None

        return SendResult(success=True, message_id=last_id)

    def _build_send_payload(
        self,
        chat_id: str,
        content: str,
        topic: Optional[str],
    ) -> Tuple[Dict[str, Any], Optional[str]]:
        """Build payload for send request."""
        resolved_topic = self._resolve_topic(topic)

        if chat_id.startswith("stream:"):
            sid = chat_id.split(":", 1)[1].strip()
            if not sid.isdigit():
                return {}, f"Invalid stream chat_id: {chat_id}"
            payload: Dict[str, Any] = {
                "type": "stream",
                "to": sid,
                "topic": resolved_topic,
                "content": content,
            }
            return payload, None

        if chat_id.startswith("private:"):
            rest = chat_id.split(":", 1)[1].strip()
            ids: List[int] = []
            for part in rest.replace(",", " ").split():
                if part.isdigit():
                    ids.append(int(part))
            if not ids:
                return {}, f"Invalid private chat_id: {chat_id}"
            return {
                "type": "direct",
                "to": json.dumps(ids),
                "content": content,
            }, None

        return {}, f"Unrecognized Zulip chat_id format: {chat_id}"

    def _chunk_message(self, content: str, max_length: int) -> List[str]:
        """Split message into chunks if needed."""
        if len(content) <= max_length:
            return [content]

        chunks = []
        while content:
            if len(content) <= max_length:
                chunks.append(content)
                break
            split_at = content.rfind("\n", 0, max_length)
            if split_at <= 0:
                split_at = max_length
            chunks.append(content[:split_at])
            content = content[split_at:].lstrip()
        return chunks

    async def edit_message(
        self,
        message_id: str,
        content: str,
    ) -> SendResult:
        """Edit an existing message.

        Args:
            message_id: ID of message to edit
            content: New content

        Returns:
            SendResult with success status
        """
        formatted = format_zulip_message(content)
        data, status = await self._api_patch(
            f"messages/{message_id}",
            {"content": formatted},
        )
        if status >= 400 or data.get("result") == "error":
            return SendResult(success=False, error=data.get("msg", "edit failed"))
        return SendResult(success=True, message_id=message_id)

    async def get_chat_info(self, chat_id: str) -> Dict[str, Any]:
        """Get info about a chat.

        Args:
            chat_id: Chat ID (``"stream:ID"`` or ``"private:..."``)

        Returns:
            Dict with ``name`` (str) and ``type`` (``"channel"`` or ``"dm"``).
        """
        if chat_id.startswith("stream:"):
            sid = chat_id.split(":", 1)[1].strip()
            if sid.isdigit():
                data = await self._api_get(f"streams/{sid}")
                stream = data.get("stream", {})
                if data.get("result") != "error" and stream:
                    return {
                        "name": stream.get("name", chat_id),
                        "type": "channel",
                    }
        if chat_id.startswith("private:"):
            return {"name": "direct message", "type": "dm"}
        return {"name": chat_id, "type": "channel"}

    # ------------------------------------------------------------------
    # Event polling
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        """Main event polling loop with reconnection logic."""
        import aiohttp

        delay = _RECONNECT_BASE_DELAY
        while not self._closing:
            try:
                if not self._queue_id:
                    if not await self._register_queue():
                        await asyncio.sleep(delay + random.random() * delay * _RECONNECT_JITTER)
                        delay = min(delay * 2, _RECONNECT_MAX_DELAY)
                        continue
                    delay = _RECONNECT_BASE_DELAY

                params = {
                    "queue_id": self._queue_id,
                    "last_event_id": self._last_event_id,
                }
                url = f"{self.config.base_url}/api/v1/events"
                async with self._session.get(
                    url,
                    auth=self._auth(),
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=90),
                ) as resp:
                    body = await resp.text()
                    if resp.status == 400:
                        data = json.loads(body) if body else {}
                        if data.get("code") == "BAD_EVENT_QUEUE_ID":
                            logger.warning("Zulip: bad event queue — re-registering")
                            self._queue_id = None
                            continue

                    if resp.status >= 400:
                        retry_after = (
                            parse_zulip_retry_after(resp, body)
                            if resp.status == 429
                            else None
                        )
                        if resp.status == 429:
                            now = time.time()
                            if now - self._last_events_429_log_ts >= _ZULIP_429_LOG_THROTTLE_SEC:
                                self._last_events_429_log_ts = now
                                logger.warning(
                                    "Zulip: events HTTP 429 (rate limit) — "
                                    "retry-after=%ss; applying backoff (see DEBUG for repeats)",
                                    retry_after if retry_after is not None else "?",
                                )
                            else:
                                logger.debug(
                                    "Zulip: events HTTP 429 (throttled log); retry-after=%s",
                                    retry_after,
                                )
                        else:
                            logger.warning(
                                "Zulip: events HTTP %s: %s",
                                resp.status,
                                body[:200],
                            )
                        jitter = random.random() * max(delay, 1.0) * _RECONNECT_JITTER
                        wait_s = max(delay, float(retry_after or 0.0)) + jitter
                        await asyncio.sleep(wait_s)
                        delay = min(delay * 2, _RECONNECT_MAX_DELAY)
                        continue

                    data = json.loads(body) if body else {}
                    if data.get("result") == "error":
                        logger.warning("Zulip: events error: %s", data)
                        await asyncio.sleep(2)
                        continue

                    self._queue_id = data.get("queue_id", self._queue_id)
                    for ev in data.get("events") or []:
                        et = ev.get("type")
                        if et == "heartbeat":
                            continue
                        if et == "message":
                            await self._on_message_event(ev.get("message") or {})

                    self._last_event_id = int(data.get("last_event_id", self._last_event_id))

                delay = _RECONNECT_BASE_DELAY

            except asyncio.CancelledError:
                return
            except Exception as exc:
                if self._closing:
                    return
                logger.warning("Zulip poll error: %s — retrying", exc)
                await asyncio.sleep(delay + random.random() * delay * _RECONNECT_JITTER)
                delay = min(delay * 2, _RECONNECT_MAX_DELAY)

    def _prune_seen(self) -> None:
        """Prune old message IDs from dedup cache."""
        if len(self._seen_messages) < _SEEN_MAX:
            return
        now = time.time()
        self._seen_messages = {
            k: t for k, t in self._seen_messages.items() if now - t < _SEEN_TTL
        }

    def _prune_sticky(self) -> None:
        """Prune expired sticky topic entries."""
        now = time.time()
        dead = [k for k, exp in self._sticky_topic_expiry.items() if exp <= now]
        for k in dead:
            del self._sticky_topic_expiry[k]

    async def _on_message_event(self, msg: Dict[str, Any]) -> None:
        """Handle incoming message event."""
        mid = str(msg.get("id", ""))
        if not mid:
            return

        sender_id = msg.get("sender_id")
        if sender_id == self._bot_user_id:
            return

        # Deduplication
        self._prune_seen()
        if mid in self._seen_messages:
            return
        self._seen_messages[mid] = time.time()

        msg_type = msg.get("type")
        content = msg.get("content") or ""

        # Channel filter
        if msg_type == "stream":
            stream_name = msg.get("display_recipient") or ""
            if (
                self._streams_allow != {"*"}
                and stream_name
                and stream_name not in self._streams_allow
            ):
                logger.debug("Zulip: skipping channel %r (not in allowlist)", stream_name)
                return

        # Build routing / gating
        stream_id: Optional[int] = None
        topic_str = ""
        chat_id: str
        chat_type: str
        thread_id: Optional[str] = None
        chat_name: Optional[str] = None

        if msg_type == "stream":
            stream_id = int(msg.get("stream_id", 0))
            topic_str = (msg.get("subject") or "(no topic)").strip() or "(no topic)"
            chat_id = f"stream:{stream_id}"
            thread_id = topic_str
            chat_type = "channel"
            chat_name = str(msg.get("display_recipient") or f"stream {stream_id}")

            self._prune_sticky()
            sk = build_sticky_key(stream_id, topic_str)
            now = time.time()
            sticky_active = self._sticky_enabled() and (
                self._sticky_topic_expiry.get(sk, 0) > now
            )

            # Handle unfocus command
            if self._sticky_enabled() and is_unfocus_message(content, self._bot_full_name):
                if sk in self._sticky_topic_expiry:
                    del self._sticky_topic_expiry[sk]
                    logger.debug("Zulip: sticky focus cleared for %s", sk)
                return

            # Check mention requirements
            require = self._require_mention
            has_mention = False
            if require:
                flags = set(msg.get("flags") or [])
                has_mention = (
                    "mentioned" in flags
                    or "wildcard_mentioned" in flags
                    or self._content_mentions_bot(content)
                )
                free_ok = (
                    str(stream_id) in self._free_streams
                    or (msg.get("display_recipient") or "") in self._free_streams
                )
                if not sticky_active and not free_ok and not has_mention:
                    logger.debug(
                        "Zulip: skipping channel message without mention (stream=%s topic=%s)",
                        stream_id,
                        topic_str,
                    )
                    return

                # Refresh sticky focus on mention
                if has_mention and self._sticky_enabled():
                    idle_sec = max(60.0, self.config.sticky_topic_idle_minutes * 60.0)
                    self._sticky_topic_expiry[sk] = now + idle_sec

            if has_mention:
                content = self._strip_bot_mentions(content)

        elif msg_type == "private":
            chat_type = "dm"
            recipients = msg.get("display_recipient") or []
            peer_ids: List[int] = []
            if isinstance(recipients, list):
                for u in recipients:
                    if isinstance(u, dict):
                        uid = u.get("id")
                        if uid and int(uid) != self._bot_user_id:
                            peer_ids.append(int(uid))
            if not peer_ids and sender_id:
                peer_ids = [int(sender_id)]
            peer_ids.sort()
            chat_id = "private:" + ",".join(str(p) for p in peer_ids)
            thread_id = None
            chat_name = "direct message"
        else:
            return

        sender_name = (msg.get("sender_full_name") or str(sender_id) or "user").strip()

        source = MessageSource(
            chat_id=chat_id,
            chat_name=chat_name,
            chat_type=chat_type,
            user_id=str(sender_id) if sender_id is not None else None,
            user_name=sender_name,
            thread_id=thread_id,
            chat_topic=topic_str if msg_type == "stream" else None,
        )

        msg_type_enum = MessageType.COMMAND if content.strip().startswith("/") else MessageType.TEXT

        event = MessageEvent(
            text=content.strip(),
            message_type=msg_type_enum,
            source=source,
            raw_message=msg,
            message_id=mid,
            reply_to_message_id=str(msg.get("id")) if msg.get("id") else None,
        )

        if self.on_message:
            try:
                await self.on_message(event)
            except Exception as exc:
                logger.error("Error in on_message handler: %s", exc)

    def _content_mentions_bot(self, content: str) -> bool:
        """Check if content mentions the bot."""
        if not content or not self._bot_full_name:
            return False
        safe = re.escape(self._bot_full_name)
        if re.search(rf"@\*\*{safe}\*\*", content):
            return True
        if self.config.bot_email:
            local = self.config.bot_email.split("@")[0].lower()
            if local in content.lower():
                return True
        return False

    def _strip_bot_mentions(self, content: str) -> str:
        """Strip the bot's own @-mentions from content.

        Only removes mentions of this bot; other users' mentions are preserved.
        """
        text = content
        if self._bot_full_name:
            text = re.sub(
                rf"@\*\*{re.escape(self._bot_full_name)}\*\*",
                "",
                text,
                flags=re.IGNORECASE,
            )
        return text.strip()
