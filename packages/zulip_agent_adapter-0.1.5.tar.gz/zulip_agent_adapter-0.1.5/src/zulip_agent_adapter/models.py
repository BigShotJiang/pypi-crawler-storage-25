"""
Data models for Zulip Agent Adapter.
"""

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class MessageType(Enum):
    """Message type classification."""
    TEXT = "text"
    COMMAND = "command"
    IMAGE = "image"
    AUDIO = "audio"
    DOCUMENT = "document"


@dataclass
class MessageSource:
    """Source context for a message event."""
    chat_id: str
    chat_name: str
    chat_type: str  # "channel" or "dm"
    user_id: Optional[str] = None
    user_name: str = "user"
    thread_id: Optional[str] = None
    chat_topic: Optional[str] = None


@dataclass
class MessageEvent:
    """Event representing a received message."""
    text: str
    message_type: MessageType
    source: MessageSource
    raw_message: Dict[str, Any] = field(default_factory=dict)
    message_id: Optional[str] = None
    media_urls: List[str] = field(default_factory=list)
    media_types: List[str] = field(default_factory=list)
    reply_to_message_id: Optional[str] = None


@dataclass
class SendResult:
    """Result of a send operation."""
    success: bool
    message_id: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ZulipConfig:
    """Configuration for the Zulip adapter.

    Required fields (base_url, bot_email, api_key) can be passed directly
    or loaded from environment variables via ``ZulipConfig.from_env()``.
    """
    # Required
    base_url: str  # e.g., https://your-org.zulipchat.com
    bot_email: str
    api_key: str

    # Behavior
    chatmode: str = "oncall"  # "oncall", "onmessage", or "onchar"
    require_mention: Optional[bool] = None  # None = follow chatmode default
    default_topic: str = "general"

    # Sticky topic
    sticky_topic_after_mention: Optional[bool] = None  # None = auto (on for oncall)
    sticky_topic_idle_minutes: float = 45.0

    # Channel filtering
    streams: str = "*"  # Comma-separated channel names, or "*" for all
    free_response_streams: str = ""  # Comma-separated channel IDs that skip mention gate

    def __post_init__(self):
        self.base_url = self.base_url.rstrip("/")
        if self.chatmode not in ("oncall", "onmessage", "onchar"):
            self.chatmode = "oncall"

    @classmethod
    def from_env(cls) -> "ZulipConfig":
        """Create a config from environment variables.

        Reads:
            ZULIP_URL        -> base_url
            ZULIP_BOT_EMAIL  -> bot_email
            ZULIP_API_KEY    -> api_key
            ZULIP_CHATMODE   -> chatmode  (default: "oncall")
            ZULIP_STREAMS    -> streams   (default: "*")

        Returns:
            A new ZulipConfig instance.

        Raises:
            KeyError: If a required variable (ZULIP_URL, ZULIP_BOT_EMAIL,
                or ZULIP_API_KEY) is not set.
        """
        return cls(
            base_url=os.environ["ZULIP_URL"],
            bot_email=os.environ["ZULIP_BOT_EMAIL"],
            api_key=os.environ["ZULIP_API_KEY"],
            chatmode=os.environ.get("ZULIP_CHATMODE", "oncall"),
            streams=os.environ.get("ZULIP_STREAMS", "*"),
        )
