"""
Zulip Agent Adapter

An async Python adapter for connecting AI agents and bots to Zulip chat.

Example::

    import asyncio
    from zulip_agent_adapter import ZulipAdapter, ZulipConfig

    config = ZulipConfig(
        base_url="https://your-org.zulipchat.com",
        bot_email="bot@your-org.zulipchat.com",
        api_key="your-api-key",
    )
    adapter = ZulipAdapter(config)

    async def on_message(event):
        print(f"Received: {event.text}")
        await adapter.send(event.source.chat_id, "Hello!")

    adapter.on_message = on_message
    asyncio.run(adapter.connect())
"""

from .adapter import ZulipAdapter, ZulipConfig, MessageEvent, SendResult
from .utils import (
    normalize_zulip_topic,
    build_sticky_key,
    parse_zulip_retry_after,
    is_unfocus_message,
    resolve_sticky_feature_enabled,
)

__version__ = "0.1.5"
__all__ = [
    "ZulipAdapter",
    "ZulipConfig",
    "MessageEvent",
    "SendResult",
    "normalize_zulip_topic",
    "build_sticky_key",
    "parse_zulip_retry_after",
    "is_unfocus_message",
    "resolve_sticky_feature_enabled",
]
