"""Tests for utility functions."""

import pytest

from zulip_agent_adapter.utils import (
    build_sticky_key,
    format_zulip_message,
    is_unfocus_message,
    normalize_zulip_topic,
    parse_zulip_retry_after,
    resolve_sticky_feature_enabled,
)


def test_normalize_zulip_topic():
    """Test topic normalization."""
    assert normalize_zulip_topic("  Foo   Bar ") == "foo bar"
    assert normalize_zulip_topic("Test Topic") == "test topic"
    assert normalize_zulip_topic("") == ""
    assert normalize_zulip_topic("UPPER") == "upper"


def test_build_sticky_key():
    """Test sticky key generation."""
    k = build_sticky_key(42, "My Topic")
    assert "42" in k
    assert "my topic" in k

    # Same channel, different case -> same key
    k1 = build_sticky_key(1, "General")
    k2 = build_sticky_key(1, "general")
    assert k1 == k2


def test_parse_zulip_retry_after_json():
    """Test parsing retry-after from JSON body."""
    class MockResp:
        headers = {}

    body = (
        '{"result":"error","code":"RATE_LIMIT_HIT",'
        '"retry-after":0.23484563827514648}'
    )
    result = parse_zulip_retry_after(MockResp(), body)
    assert abs(result - 0.23484563827514648) < 1e-9


def test_parse_zulip_retry_after_header_prefers_header():
    """Test that header value takes precedence over body."""
    class MockResp:
        headers = {"Retry-After": "3"}

    assert parse_zulip_retry_after(MockResp(), "{}") == 3.0


def test_parse_zulip_retry_after_invalid_returns_none():
    """Test handling of invalid responses."""
    class MockResp:
        headers = {}

    assert parse_zulip_retry_after(MockResp(), "not json") is None
    assert parse_zulip_retry_after(MockResp(), "{}") is None


def test_resolve_sticky_feature_enabled():
    """Test sticky feature resolution."""
    assert resolve_sticky_feature_enabled("oncall", True, None) is True
    assert resolve_sticky_feature_enabled("onmessage", False, None) is False
    assert resolve_sticky_feature_enabled("oncall", True, False) is False
    assert resolve_sticky_feature_enabled("onmessage", False, True) is True


def test_is_unfocus_message():
    """Test unfocus command detection."""
    bot_name = "Hermes Bot"

    assert is_unfocus_message("/unfocus", bot_name)
    assert is_unfocus_message("/unfocus.", bot_name)
    assert is_unfocus_message("@**Hermes Bot** unfocus", bot_name)
    assert is_unfocus_message("@**Hermes Bot** unfocus now", bot_name)

    assert not is_unfocus_message('Please run "/unfocus" to clear', bot_name)
    assert not is_unfocus_message("Just a regular message", bot_name)
    assert not is_unfocus_message("", bot_name)


def test_format_zulip_message():
    """Test message formatting."""
    content = "Check this out: ![alt](https://example.com/img.png)"
    result = format_zulip_message(content)
    assert "![alt]" not in result
    assert "https://example.com/img.png" in result

    assert format_zulip_message("Hello world") == "Hello world"
