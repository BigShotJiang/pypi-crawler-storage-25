"""Tests for ZulipAdapter."""

import asyncio

import pytest
from unittest.mock import AsyncMock, MagicMock

from zulip_agent_adapter.adapter import ZulipAdapter
from zulip_agent_adapter.models import ZulipConfig


@pytest.fixture
def config():
    """Create a test config."""
    return ZulipConfig(
        base_url="https://test.zulipchat.com",
        bot_email="bot@test.zulipchat.com",
        api_key="test-key",
    )


@pytest.fixture
def adapter(config):
    """Create a test adapter."""
    return ZulipAdapter(config)


def test_adapter_init(adapter, config):
    """Test adapter initialization."""
    assert adapter.config == config
    assert adapter._bot_user_id == -1
    assert adapter._closing is False
    assert adapter.on_message is None


def test_parse_streams_allow_all(adapter):
    """Test parsing '*' streams setting."""
    assert adapter._parse_streams_allow() == {"*"}


def test_parse_streams_allow_specific():
    """Test parsing specific channel names."""
    config = ZulipConfig(
        base_url="https://test.zulipchat.com",
        bot_email="bot@test.zulipchat.com",
        api_key="test-key",
        streams="general, random, dev",
    )
    adapter = ZulipAdapter(config)
    assert adapter._parse_streams_allow() == {"general", "random", "dev"}


def test_resolve_require_mention_default(adapter):
    """Test default mention requirement (oncall mode)."""
    assert adapter._resolve_require_mention() is True


def test_resolve_require_mention_onmessage():
    """Test onmessage mode doesn't require mention."""
    config = ZulipConfig(
        base_url="https://test.zulipchat.com",
        bot_email="bot@test.zulipchat.com",
        api_key="test-key",
        chatmode="onmessage",
    )
    adapter = ZulipAdapter(config)
    assert adapter._resolve_require_mention() is False


def test_resolve_require_mention_explicit():
    """Test explicit mention override."""
    config = ZulipConfig(
        base_url="https://test.zulipchat.com",
        bot_email="bot@test.zulipchat.com",
        api_key="test-key",
        chatmode="oncall",
        require_mention=False,
    )
    adapter = ZulipAdapter(config)
    assert adapter._resolve_require_mention() is False


def test_sticky_enabled_default(adapter):
    """Test sticky feature defaults to on for oncall mode."""
    assert adapter._sticky_enabled() is True


def test_build_send_payload_stream(adapter):
    """Test building payload for channel message."""
    payload, err = adapter._build_send_payload("stream:123", "Hello", None)
    assert err is None
    assert payload["type"] == "stream"
    assert payload["to"] == "123"
    assert payload["content"] == "Hello"


def test_build_send_payload_stream_invalid(adapter):
    """Test building payload with invalid stream ID."""
    payload, err = adapter._build_send_payload("stream:abc", "Hello", None)
    assert err is not None
    assert "Invalid stream chat_id" in err


def test_build_send_payload_private(adapter):
    """Test building payload for direct message uses 'direct' type."""
    payload, err = adapter._build_send_payload("private:123,456", "Hello", None)
    assert err is None
    assert payload["type"] == "direct"
    assert "123" in payload["to"]
    assert "456" in payload["to"]


def test_build_send_payload_unknown_format(adapter):
    """Test building payload with unknown format."""
    payload, err = adapter._build_send_payload("unknown:123", "Hello", None)
    assert err is not None
    assert "Unrecognized" in err


def test_chunk_message_small(adapter):
    """Test chunking small message."""
    chunks = adapter._chunk_message("Hello", 1000)
    assert len(chunks) == 1
    assert chunks[0] == "Hello"


def test_chunk_message_large(adapter):
    """Test chunking large message."""
    big_text = "A" * 2000
    chunks = adapter._chunk_message(big_text, 1000)
    assert len(chunks) == 2
    assert len(chunks[0]) == 1000


def test_content_mentions_bot(adapter):
    """Test bot mention detection in content."""
    adapter._bot_full_name = "Test Bot"

    assert adapter._content_mentions_bot("Hello @**Test Bot**") is True
    assert adapter._content_mentions_bot("No mention here") is False


def test_content_mentions_bot_email_fallback(adapter):
    """Test email-based mention detection."""
    adapter._bot_full_name = ""
    adapter.config.bot_email = "bot@test.com"

    assert adapter._content_mentions_bot("Hello bot") is True
    assert adapter._content_mentions_bot("Hello other") is False


def test_strip_bot_mentions_only_strips_bot(adapter):
    """Test that only the bot's own mentions are stripped, not other users'."""
    adapter._bot_full_name = "Test Bot"

    result = adapter._strip_bot_mentions("Hello @**Test Bot** and @**Alice**")
    assert "@**Test Bot**" not in result
    assert "@**Alice**" in result
    assert "Hello" in result


@pytest.mark.asyncio
async def test_connect_missing_credentials():
    """Test connect fails with missing credentials."""
    config = ZulipConfig(
        base_url="",
        bot_email="",
        api_key="",
    )
    adapter = ZulipAdapter(config)

    result = await adapter.connect()
    assert result is False


@pytest.mark.asyncio
async def test_send_empty_content(adapter):
    """Test sending empty content returns success."""
    result = await adapter.send("stream:123", "")
    assert result.success is True


@pytest.mark.asyncio
async def test_disconnect():
    """Test disconnect cancels poll task and closes session."""
    config = ZulipConfig(
        base_url="https://test.zulipchat.com",
        bot_email="bot@test.zulipchat.com",
        api_key="test-key",
    )
    adapter = ZulipAdapter(config)

    async def hang_forever():
        await asyncio.sleep(3600)

    adapter._poll_task = asyncio.create_task(hang_forever())

    mock_session = MagicMock()
    mock_session.closed = False
    mock_session.close = AsyncMock()
    adapter._session = mock_session

    await adapter.disconnect()

    assert adapter._closing is True
    assert adapter._poll_task.cancelled()
    mock_session.close.assert_awaited_once()
