"""Tests for zulip-agent-adapter."""
