# Code Audit Notes

**Package:** zulip-agent-adapter  
**Version:** v0.1.5  
**Origin:** Extracted from Hermes Agent (`gateway/platforms/zulip.py`)

---

## Overview

This document records the extraction of the Zulip adapter from the Hermes Agent codebase and its evolution into a standalone package.

### Version History

- **v0.1.0** — Initial extraction from Hermes Agent (27 pre-publish issues identified)
- **v0.1.1** — Advisor review; attempted fixes (auth syntax errors persisted in display)
- **v0.1.3** — Verified working code; version bumped to reflect completion

---

## v0.1.3 — Verified Working Release

### Critical Fixes Verified

| Issue | Status | Notes |
|-------|--------|-------|
| HTTP auth syntax | ✅ Fixed | All three occurrences use `auth=self._auth()` correctly |
| Import test | ✅ Passes | `from zulip_agent_adapter import ZulipAdapter` succeeds |

### Previously Implemented (from v0.1.1)

| Rec # | Issue | Status |
|-------|-------|--------|
| #2 | `reply_to_message_id` removed | ✅ Fixed — documented as "reserved for future use" |
| #3 | `"private"` → `"direct"` | ✅ Fixed — uses modern Zulip API |
| #5 | Attachment claims removed | ✅ Fixed — README no longer claims unsupported features |
| #6 | `reactions_enabled` removed | ✅ Fixed — field removed from config |
| #7 | Environment variable support | ✅ Fixed — added `ZulipConfig.from_env()` |
| #8 | `__init__.py` example | ✅ Fixed — uses `event.source.chat_id` |
| #11 | Trailing comma | ✅ Fixed — README code example corrected |
| #12 | `get_chat_info` documented | ✅ Fixed — return shape documented |
| #16 | `_strip_bot_mentions` | ✅ Fixed — only strips bot's mentions |
| #17 | Dead code removed | ✅ Fixed — redundant elif branch removed |
| #18 | Unused `Path` import | ✅ Fixed — import removed |

### Code Quality

- **Type hints:** Full typing throughout
- **Docstrings:** Google-style for public APIs
- **Tests:** Unit tests for utilities and adapter internals
- **Dependencies:** Only `aiohttp` required
- **Async:** Proper async/await patterns with cancellation handling

---

## Architecture (Standalone vs Hermes)

| Aspect | Hermes (Original) | Standalone (v0.1.3) |
|--------|-------------------|---------------------|
| **Config** | `PlatformConfig` with `.extra` dict | `ZulipConfig` dataclass |
| **Base class** | `BasePlatformAdapter` | Self-contained `ZulipAdapter` |
| **Events** | From gateway base | Local `models.py` |
| **Media handling** | Auto-cached to Hermes dir | Removed (not reimplemented) |
| **Session** | Via base class | Direct aiohttp |
| **Callback** | `handle_message()` | `on_message` attribute |

---

## Sensitive Data Check

- [x] No API keys or tokens in code
- [x] No hardcoded URLs (only example placeholders)
- [x] No internal hostnames or paths
- [x] No personal information
- [x] No private prompts or system messages

---

## Attribution

- Code originated from Hermes Agent internal integration
- Initial extraction assisted by AI tooling
- Reviewed and refined for standalone publication
- MIT license (compatible with aiohttp's Apache 2.0)

---

## Notes

- The adapter intentionally keeps `aiohttp` as the only runtime dependency
- Chat modes (`oncall`/`onmessage`/`onchar`) preserved; `onchar` accepted but behaves like `onmessage`
- Message length limit set to 9900 (Zulip's hard limit is 10000; 100-char safety margin)
- Sticky topic focus enabled by default in `oncall` mode
