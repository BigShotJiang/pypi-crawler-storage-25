import matplotlib
matplotlib.use("Agg")

import numpy as np
import pandas as pd
import xarray as xr

from simianpy.analysis.gaze import GazeData, TrialGazeData


def make_session_gaze():
    time = np.arange(0.0, 5.0, 0.1)
    position = np.column_stack([time, time * 2.0])
    blink_mask = np.ones(time.size, dtype=bool)
    blink_mask[np.where(np.isclose(time, 3.0))[0][0]] = False
    return GazeData.from_arrays(time, position, ["eyeh", "eyev"], blink_mask=blink_mask)


def make_trial_gaze():
    time = np.array([-0.2, -0.1, 0.0, 0.1, 0.2])
    trialids = np.array([101, 102])
    data = xr.DataArray(
        np.array(
            [
                [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [4.0, 4.0], [4.0, 4.0]],
                [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [8.0, 8.0], [8.0, 8.0]],
            ]
        ),
        dims=("trialid", "time", "dimension"),
        coords={"trialid": trialids, "time": time, "dimension": ["eyeh", "eyev"]},
    )
    trial_metadata = pd.DataFrame(
        {"condition": ["near", "far"]},
        index=pd.Index(trialids, name="trialid"),
    )
    blink_mask = np.ones((2, 5), dtype=bool)
    blink_mask[0, 4] = False
    return TrialGazeData(data, blink_mask=blink_mask, window=(-0.2, 0.2), trial_metadata=trial_metadata)


def test_gazedata_to_trials_aligns_data_and_metadata():
    gaze = make_session_gaze()
    event_timestamps = pd.Series([1.0, 3.0], index=pd.Index([11, 12], name="trialid"))
    trial_metadata = pd.DataFrame(
        {"condition": ["A", "B"]},
        index=pd.Index([11, 12], name="trialid"),
    )

    trial_gaze = gaze.to_trials(
        event_timestamps=event_timestamps,
        window=(-0.2, 0.2),
        trial_metadata=trial_metadata,
        time_step=0.1,
    )

    assert trial_gaze.data.dims == ("trialid", "time", "dimension")
    assert trial_gaze.data.trialid.values.tolist() == [11, 12]
    assert np.allclose(trial_gaze.data.time.values, [-0.2, -0.1, 0.0, 0.1, 0.2])
    assert trial_gaze.data.sel(trialid=11, time=0.0, dimension="eyeh").item() == 1.0
    assert trial_gaze.data.sel(trialid=11, time=0.0, dimension="eyev").item() == 2.0
    assert trial_gaze.data.coords["condition"].values.tolist() == ["A", "B"]
    assert not trial_gaze.blink_mask.sel(trialid=12, time=0.0).item()


def test_trialgazedata_saccades_selectors_and_metadata_join():
    trial_gaze = make_trial_gaze()

    saccades = trial_gaze.get_saccades(
        velocity_query={"min": 20},
        amplitude_query={"min": 5},
    )
    selected = trial_gaze.select_saccades(
        center=[4.0, 4.0],
        distance=1.0,
        include_trial_metadata=True,
    )

    assert set(saccades["trialid"]) == {101, 102}
    assert np.allclose(saccades.loc[saccades["trialid"] == 101, ["landing_eyeh", "landing_eyev"]].iloc[0], [4.0, 4.0])
    assert selected["trialid"].tolist() == [101]
    assert selected["condition"].tolist() == ["near"]


def test_trialgazedata_fixations_and_plotting_smoke():
    trial_gaze = make_trial_gaze()

    fixations = trial_gaze.get_fixations(
        velocity_query={"max": 1},
        duration_query={"min": 0.05},
    )
    selected_saccades = trial_gaze.get_saccades(
        velocity_query={"min": 20},
    )

    assert not fixations.empty
    assert "trialid" in fixations.columns

    ax_time = trial_gaze.plot_time(overlay_events=selected_saccades, mask_blinks=True)
    ax_xy = trial_gaze.plot_xy(overlay_events=selected_saccades, mask_blinks=True)

    assert ax_time is not None
    assert ax_xy is not None
    assert np.isnan(ax_time.lines[0].get_ydata()).any()
    assert np.isnan(ax_xy.lines[0].get_xdata()).any()
