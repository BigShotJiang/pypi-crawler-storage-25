from pathlib import Path
from uuid import uuid4

import numpy as np
import pandas as pd

from simianpy.analysis.spiketrain import SpikeTrainSet


def make_spiketrainset(with_metadata: bool = True) -> SpikeTrainSet:
    trialids = np.array([1, 1, 2, 2], dtype=np.int32)
    unitids = np.array([10, 11, 10, 11], dtype=np.int32)
    spike_times = np.array([0.05, 0.15, 0.10, 0.20], dtype=np.float32)
    kwargs = {}
    if with_metadata:
        kwargs["trial_metadata"] = pd.DataFrame(
            {"condition": ["A", "B"], "shared": ["trial-a", "trial-b"]},
            index=pd.Index([1, 2], name="trialid"),
        )
        kwargs["unit_metadata"] = pd.DataFrame(
            {"area": ["V1", "MT"], "shared": ["unit-10", "unit-11"]},
            index=pd.Index([10, 11], name="unitid"),
        )
    return SpikeTrainSet(
        trialids=trialids,
        unitids=unitids,
        spike_times=spike_times,
        window=(0.0, 0.3),
        **kwargs,
    )


def test_unit_metadata_exports_with_xarray_outputs_and_dataframe():
    sts = make_spiketrainset()

    psth = sts.to_psth(time_step=0.1)
    firing_rates = sts.get_firing_rates((0.0, 0.3))
    spikes = sts.to_dataframe()

    assert "condition" in psth.coords
    assert "area" in psth.coords
    assert "trial_shared" in psth.coords
    assert "unit_shared" in psth.coords
    assert list(psth.coords["area"].values) == ["V1", "MT"]
    assert list(firing_rates.coords["area"].values) == ["V1", "MT"]

    assert "condition" in spikes.columns
    assert "area" in spikes.columns
    assert "trial_shared" in spikes.columns
    assert "unit_shared" in spikes.columns


def test_metadata_roundtrip_in_save_load_preserves_unit_metadata():
    sts = make_spiketrainset()

    path = Path("tests") / f"tmp_spiketrainset_{uuid4().hex}.zip"
    try:
        sts.save(path)
        loaded = SpikeTrainSet.load(path)
    finally:
        path.unlink(missing_ok=True)

    pd.testing.assert_frame_equal(loaded.trial_metadata, sts.trial_metadata)
    pd.testing.assert_frame_equal(loaded.unit_metadata, sts.unit_metadata)
    assert list(loaded.to_psth(time_step=0.1).coords["area"].values) == ["V1", "MT"]


def test_metadata_can_be_added_retroactively_and_aligns_by_ids():
    sts = make_spiketrainset(with_metadata=False)

    trial_metadata = sts.add_trial_metadata(
        pd.DataFrame(
            {"condition": ["A"]},
            index=pd.Index([1], name="trialid"),
        )
    )
    unit_metadata = sts.add_unit_metadata(
        pd.DataFrame(
            {"area": ["V1", "MT"]},
            index=pd.Index([10, 11], name="unitid"),
        )
    )

    assert list(unit_metadata["area"].values) == ["V1", "MT"]
    assert trial_metadata.index.tolist() == [1, 2]
    assert trial_metadata.loc[1, "condition"] == "A"
    assert pd.isna(trial_metadata.loc[2, "condition"])

    psth = sts.to_psth(time_step=0.1)
    assert list(psth.coords["area"].values) == ["V1", "MT"]
    assert pd.isna(psth.coords["condition"].sel(trialid=2).item())
