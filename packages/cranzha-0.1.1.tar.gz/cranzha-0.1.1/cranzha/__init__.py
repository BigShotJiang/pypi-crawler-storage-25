from .crall import ml_1, ml_2, ml_3, ml_4, ml_5, ml_6, ml_7, ml_8
from .cralld import f1, f2, f3, f4, f5, f6, f7, f8