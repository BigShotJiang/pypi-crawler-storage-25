from setuptools import setup, find_packages

setup(
    name='cranzha',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        'colorama>=0.4.6',
    ],
    entry_points={
        'console_scripts': [
            'ml_1 = cranzha.crall:ml_1',
            'ml_2 = cranzha.crall:ml_2',
            'ml_3 = cranzha.crall:ml_3',
            'ml_4 = cranzha.crall:ml_4',
            'ml_5 = cranzha.crall:ml_5',
            'ml_6 = cranzha.crall:ml_6',
            'ml_7 = cranzha.crall:ml_7',
            'ml_8 = cranzha.crall:ml_8',
        ],
    }
)
