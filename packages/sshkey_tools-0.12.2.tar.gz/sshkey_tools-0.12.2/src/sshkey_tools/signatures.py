"""SSH Data signature implementation

Raises:
    _EX.InvalidDataException: Data is invalid
    _EX.InvalidHashAlgorithmException: The hash algorithm is invalid
    _EX.InvalidCertificateFieldException: The certificate field contains invalid data
"""

# Format:
# byte[6]   MAGIC_PREAMBLE (SSHSIG)
# uint32    SIG_VERSION (0x01)
# string    publickey
# string    namespace
# string    reserved
# string    hash_algorithm
# string    signature
from base64 import b64decode, b64encode
from prettytable import PrettyTable
from .cert import Fieldset, dataclass, Union
from .utils import concat_to_bytestring, ensure_bytestring
from . import fields as _FIELD, keys as _KEY, exceptions as _EX, utils as _U


@dataclass
class SignatureFieldset(Fieldset):
    """Fields for SSH Signature"""

    DECODE_ORDER = [
        "magic_preamble",
        "sig_version",
        "public_key",
        "namespace",
        "reserved",
        "hash_algorithm",
        "signature",
    ]

    magic_preamble: _FIELD.SshsigField = _FIELD.SshsigField.factory
    sig_version: _FIELD.SignatureVersionField = _FIELD.SignatureVersionField.factory
    public_key: _FIELD.PublicKeyField = _FIELD.PublicKeyField.factory

    namespace: _FIELD.SignatureNamespaceField = _FIELD.SignatureNamespaceField.factory
    reserved: _FIELD.ReservedField = _FIELD.ReservedField.factory
    hash_algorithm: _FIELD.SignatureHashAlgorithmField = (
        _FIELD.SignatureHashAlgorithmField.factory
    )
    signature: _FIELD.SignatureField = _FIELD.SignatureField.factory

    def __bytes__(self):
        """Returns the data as a bytestring for encoding

        Returns:
            data: Data bytes
        """
        return concat_to_bytestring(
            bytes(self.magic_preamble),
            bytes(self.namespace),
            bytes(self.reserved),
            bytes(self.hash_algorithm),
        )

    def format_pubkey(self):
        """Format the public key and strip and extra data

        Returns:
            key: The formatted public key
        """
        pubkey = self.public_key.value.to_string().split(" ")

        return _FIELD.StringField.encode(
            concat_to_bytestring(pubkey[0], " ", b64decode(pubkey[1]))
        )

        # return _FIELD.BytestringField.encode(concat_to_bytestring(
        #     _FIELD.StringField.encode(pubkey[0]),
        #     _FIELD.StringField.encode(b64decode(pubkey[1]))
        # ))

    def bytes_out(self):
        """Generates the output bytes for the finished signature

        Returns:
            output: The complete signature
        """
        return concat_to_bytestring(
            bytes(self.magic_preamble),
            bytes(self.sig_version),
            _FIELD.StringField.encode(self.public_key.value.raw_bytes()),
            bytes(self.namespace),
            bytes(self.reserved),
            bytes(self.hash_algorithm),
            bytes(self.signature),
        )

    @classmethod
    def decode(cls, data: bytes):
        """
        Decode a SignatureFieldset from SSHSIG binary format.
        Overrides Fieldset.decode to handle the public key field
        which is encoded as a length-prefixed SSH wire-format key.
        """
        cl_instance = cls()

        decoded, data = cl_instance.magic_preamble.from_decode(data)
        cl_instance.magic_preamble = decoded

        decoded, data = cl_instance.sig_version.from_decode(data)
        cl_instance.sig_version = decoded

        # public_key is stored as string(ssh-wire-key) in SSHSIG format
        pubkey_bytes, data = _FIELD.BytestringField.decode(data)
        key_type, key_data = _FIELD.StringField.decode(pubkey_bytes)

        sshsig_key_map = {
            "ssh-rsa": "RsaPubkeyField",
            "ecdsa-sha2-nistp256": "EcdsaPubkeyField",
            "ecdsa-sha2-nistp384": "EcdsaPubkeyField",
            "ecdsa-sha2-nistp521": "EcdsaPubkeyField",
            "ssh-ed25519": "Ed25519PubkeyField",
        }

        field_cls_name = sshsig_key_map.get(key_type)
        if field_cls_name is None:
            raise _EX.InvalidDataException(
                f"Unknown public key type in signature: {key_type}"
            )

        field_cls = getattr(_FIELD, field_cls_name)
        key_value, _ = field_cls.decode(key_data)
        cl_instance.public_key = field_cls(value=key_value)

        decoded, data = cl_instance.namespace.from_decode(data)
        cl_instance.namespace = decoded

        decoded, data = cl_instance.reserved.from_decode(data)
        cl_instance.reserved = decoded

        decoded, data = cl_instance.hash_algorithm.from_decode(data)
        cl_instance.hash_algorithm = decoded

        decoded, data = cl_instance.signature.from_decode(data)
        cl_instance.signature = decoded

        return cl_instance, data


class SSHSignature:
    """
    General class for SSH Signatures, used for loading and parsing.
    """

    data: bytes = None

    def __init__(
        self,
        signer_privkey: _KEY.PrivateKey = None,
        fields: SignatureFieldset = SignatureFieldset,
    ):
        self.fields = fields() if isinstance(fields, type) else fields

        if signer_privkey is not None:
            self.fields.replace_field(
                "signature", _FIELD.SignatureField.from_object(signer_privkey)
            )
            self.fields.replace_field(
                "public_key",
                _FIELD.PublicKeyField.from_object(signer_privkey.public_key),
            )

        if issubclass(type(self.fields.public_key.value), type(self.fields.public_key)):
            self.fields.public_key = self.fields.public_key.value

    @classmethod
    def from_file(cls, path: str, encoding: str = "none") -> "SSHSignature":
        """
        Loads an existing SSH Signature from a file

        Args:
            path (str): The path to the file
            encoding (str, optional): The encoding of the file. None will load the byte
                content directly. Defaults to 'utf-8'.

        Returns:
            SSHSignature: SSH Signature Object
        """
        with open(path, "rb" if encoding == "none" else "r") as f:
            data = f.read()

        return cls.from_string(data, encoding if encoding != "none" else None)

    @classmethod
    def from_string(
        cls, data: Union[str, bytes], encoding: str = "utf-8"
    ) -> "SSHSignature":
        """
        Loads an existing SSH Signature from file contents/string

        Args:
            data (str): The normalized string data from the .sig-file

        Returns:
            SSHSignature: The parsed SSH Signature
        """
        if isinstance(data, str):
            data = data.encode(encoding)

        if b"BEGIN SSH SIGNATURE" in data:
            data = data.replace(b"-----BEGIN SSH SIGNATURE-----\n", b"")

        if b"END SSH SIGNATURE" in data:
            data = data.replace(b"-----END SSH SIGNATURE-----", b"")

        data = data.strip(b"\n \t")

        return cls.decode(b64decode(data))

    @classmethod
    def decode(cls, data: bytes) -> "SSHSignature":
        """
        Loads an existing SSH Signature from byte contents

        Args:
            data (bytes): The normalized byte data from the .sig-file

        Returns:
            SSHSignature: The parsed SSH Signature
        """
        sig_fields, data = SignatureFieldset.decode(data)
        return cls(fields=sig_fields)

    def get_signable(self, data: Union[str, bytes]) -> bytes:
        """
        Returns the signable data for the signature or verification

        Returns:
            bytes: The signable data
        """
        hash_kind = b""
        if self.fields.hash_algorithm.value == "sha256":
            hash_kind = _U.sha256_hash(ensure_bytestring(data))
        elif self.fields.hash_algorithm.value == "sha512":
            hash_kind = _U.sha512_hash(ensure_bytestring(data))
        else:
            raise _EX.InvalidHashAlgorithmException(
                f"Unknown hash algorithm {self.fields.hash_algorithm}"
            )

        return bytes(self.fields) + _FIELD.StringField.encode(hash_kind)

    def get_signable_file(self, path: str) -> bytes:
        """
        Loads the signable content from a file.
        Will be loaded as bytes without encoding.

        Args:
            path (str): Path to the file

        Returns:
            bytes: The signable data from the file
        """
        with open(path, "rb") as f:
            data = f.read()

        return self.get_signable(data)

    def __str__(self) -> str:
        table = PrettyTable(["Field", "Value"])

        for row in self.fields.__table__():
            table.add_row(row)

        return str(table)

    def get(self, field: str):
        """Get the contents of a field

        Args:
            field (str): Field name

        Raises:
            _EX.InvalidCertificateFieldException: Invalid field name

        Returns:
            data: The field data
        """
        if field in self.fields.getattrs():
            return self.fields.get(field, None)

        raise _EX.InvalidCertificateFieldException(f"Unknown field {field}")

    def set(self, field: str, data):
        """Sets the contents of a field

        Args:
            field (str): Field name
            data (any): Data for the field

        Raises:
            _EX.InvalidCertificateFieldException: Invalid field name
        """
        if field in self.fields.getattrs():
            self.fields.set(field, data)
            return

        raise _EX.InvalidCertificateFieldException(f"Unknown field {field}")

    def verify(
        self, data, public_key: _KEY.PublicKey = None, raise_on_error: bool = False
    ) -> bool:
        """Verify a SSH Signature

        Args:
            data (bytes): The signed data
            public_key (_KEY.PublicKey, optional): The public key to use to verify
                the signature. If none are specified, the public key from the
                signature will be used. Defaults to None.
            raise_on_error (bool, optional): Whether to raise an exception on
                verification failure. Defaults to False.

        Returns:
            bool: True if the signature is valid, False otherwise.
        """
        if not public_key:
            public_key = self.fields.get("public_key", None)

        if raise_on_error and not public_key.verify(
            self.get_signable(data), self.fields.signature.value
        ):
            raise _EX.InvalidSignatureException("Signature verification failed")

        public_key.verify(self.get_signable(data), self.fields.signature.value)

    def sign(self, data: Union[str, bytes]):
        """Signs the data

        Args:
            data (Union[str, bytes]): The data to sign
        """
        signable = self.get_signable(data)
        self.fields.signature.sign(signable)

    def sign_file(self, path: str):
        """Signs a file at a given path

        Args:
            path (str): The path to the file to sign
        """
        signable = self.get_signable_file(path)
        self.fields.signature.sign(signable)

    def to_string(self):
        """Converts the signature data to the text-based signature format

        Returns:
            string: The encoded signature data
        """
        content = self.fields.bytes_out()
        content = b64encode(content)
        file_content = b"-----BEGIN SSH SIGNATURE-----\n"
        file_content += b"".join(
            [content[i : i + 70] + b"\n" for i in range(0, len(content), 70)]
        )
        file_content += b"-----END SSH SIGNATURE-----"

        return file_content

    def to_file(self, path: str):
        """Save the content of the signature to a file

        Args:
            path (str): The path to the file
        """
        with open(path, "wb") as f:
            f.write(self.to_string())
