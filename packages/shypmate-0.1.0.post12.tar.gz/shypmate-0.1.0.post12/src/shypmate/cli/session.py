"""Session commands: up, down, status."""

import time
from datetime import datetime, timezone

import click
from rich.console import Console

from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.config import (
    get_api_key,
    get_api_url,
    get_project_config,
    get_user_config,
    is_authenticated,
    is_initialized,
    save_project_config,
    write_curl_auth_config,
)
from shypmate.session import (
    clear_session_status,
    get_last_sync,
    get_machine_id,
    get_session_status,
    is_running,
    spawn_daemon,
    stop_daemon,
    touch_last_sync,
)
from shypmate.skills import list_installed_skills, sync_all_mates, write_session_instructions

console = Console()


@click.command()
@click.option("--no-poll", is_flag=True, hidden=True, help="Sync once and exit without starting background poller")
def up(no_poll: bool):
    """Start a shypmate session — sync mates and poll for updates."""
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()

    if not is_initialized():
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    if is_running():
        console.print("[yellow]Session already active.[/yellow] Run [bold]shypmate down[/bold] first.")
        raise click.Abort()

    config = get_project_config()
    project_id = config.get("project_id", "")
    client = ShypmateClient()

    # Ensure curl-auth file is current (may be missing on first run after upgrade)
    if client.api_key:
        write_curl_auth_config(client.api_key)

    console.print()

    # Sync mates and playbook
    with console.status("Syncing mates and playbook..."):
        try:
            all_mates = client.list_mates()
            installed = sync_all_mates(client)
            touch_last_sync()
            clear_session_status()
        except ShypmateAPIError as e:
            console.print(f"[red]Sync failed:[/red] {e.message}")
            raise click.Abort()

    mate_list = ", ".join(installed) if installed else "none"
    console.print(f"  [green]✓[/green] Synced {len(installed)} mates ({mate_list})")

    # Save all mates (not just installed) so teammates can see the full roster
    config["mates"] = [m["name"] for m in all_mates]
    save_project_config(config)

    write_session_instructions(project_id, client.base_url, config["mates"], machine_id=get_machine_id())

    if no_poll:
        console.print(f"\n[green]✓[/green] Synced. No background poller started (--no-poll).\n")
        return

    # Register session (best-effort — don't block on failure)
    machine_id = get_machine_id()
    poll_available = True
    try:
        client.register_session(machine_id=machine_id, project_id=project_id, mate_names=config["mates"])
    except ShypmateAPIError as e:
        if e.status_code == 403:
            poll_available = False

    if not poll_available:
        console.print(f"\n[green]✓[/green] Synced.")
        console.print(f"  [dim]Background polling requires Pro — upgrade at shypmate.dev[/dim]")
        _print_ready(installed, config.get("project_name", ""), polling=False)
        return

    spawn_daemon(project_id)
    time.sleep(0.3)  # Let daemon write its PID file
    console.print(f"  [green]✓[/green] Polling for updates every 30s in background")
    _print_ready(installed, config.get("project_name", ""), polling=True)


def _print_ready(mates: list, project_name: str, polling: bool) -> None:
    console.print()
    console.print(f"  [bold]Session active[/bold] for {project_name or 'this project'}.")
    if polling:
        console.print(f"  You'll be notified here if anything changes on shypmate.dev.")
    if mates:
        console.print(f"\n  Start working:")
        console.print(f'    claude [bold]/{mates[0]}[/bold] "your task here"')
    console.print(f"\n  Stop with: [bold]shypmate down[/bold]\n")


@click.command()
def down():
    """Stop the active shypmate session."""
    machine_id = get_machine_id()
    stopped = stop_daemon()
    clear_session_status()

    if is_authenticated():
        try:
            ShypmateClient().deregister_session(machine_id=machine_id)
        except Exception:
            pass  # Best-effort

    if stopped:
        console.print("[green]✓[/green] Session stopped.")
    else:
        console.print("[dim]No active session.[/dim]")


@click.command()
def status():
    """Show session, auth, and project status."""
    console.print()

    user_config = get_user_config()
    project_config = get_project_config()
    running = is_running()
    session_status = get_session_status()
    last_sync = get_last_sync()

    # Session
    if running:
        console.print(f"  [green]●[/green] Session:   active")
    else:
        console.print(f"  [dim]○[/dim] Session:   inactive  (run [bold]shypmate up[/bold] to start)")

    # Project
    if project_config.get("project_name"):
        pid = project_config.get("project_id", "")
        console.print(f"  Project:   {project_config['project_name']}  [dim](id: {pid[:8]}...  join: shypmate init --project {project_config['project_name']})[/dim]")
    elif is_initialized():
        console.print(f"  Project:   {project_config.get('project_id', 'unknown')}")
    else:
        console.print(f"  Project:   [dim]not initialized[/dim]  (run [bold]shypmate init[/bold])")

    # Auth
    if is_authenticated():
        email = user_config.get("user_email", "authenticated")
        plan = user_config.get("plan", "unknown")
        console.print(f"  Auth:      [green]{email}[/green]  ({plan})")
    else:
        console.print(f"  Auth:      [red]not authenticated[/red]  (run [bold]shypmate auth login[/bold])")

    # Mates
    installed = set(list_installed_skills())
    stale = set(session_status.get("stale_mates", [])) if session_status else set()
    server_mates = []
    if is_authenticated():
        try:
            server_mates = ShypmateClient().list_mates()
        except Exception:
            pass

    if server_mates:
        mate_parts = []
        for m in server_mates:
            name = m["name"]
            if name in stale:
                mate_parts.append(f"[yellow]{name} ⟳[/yellow]")
            elif name not in installed:
                mate_parts.append(f"[dim]{name}[/dim]")
            else:
                mate_parts.append(name)
        console.print(f"  Mates:     {', '.join(mate_parts)}")
        if stale:
            console.print(f"             [yellow]⟳ updated on shypmate.dev — run shypmate sync[/yellow]")
        if any(m["name"] not in installed for m in server_mates):
            console.print(f"             [dim]dimmed = no skill installed, run shypmate mate generate <name>[/dim]")
    else:
        console.print(f"  Mates:     [dim]none[/dim]  (run [bold]shypmate hire[/bold])")

    # Last sync
    if last_sync:
        secs = (datetime.now(timezone.utc) - last_sync).total_seconds()
        if secs < 60:
            ago = "just now"
        elif secs < 3600:
            ago = f"{int(secs // 60)}m ago"
        else:
            ago = f"{int(secs // 3600)}h {int((secs % 3600) // 60)}m ago"
        console.print(f"  Last sync: {ago}")

    # Server
    console.print(f"  Server:    {get_api_url()}")

    # Team — show other active sessions (best-effort, Team plan only)
    if is_authenticated() and project_config.get("project_id"):
        try:
            sessions = ShypmateClient().list_sessions(project_id=project_config["project_id"])
            machine_id = get_machine_id()
            others = [s for s in sessions if s.get("machine_id") != machine_id]
            if others:
                names = ", ".join(s.get("user_email", "unknown") for s in others)
                console.print(f"  Team:      {names} also active")
        except Exception:
            pass

    console.print()
