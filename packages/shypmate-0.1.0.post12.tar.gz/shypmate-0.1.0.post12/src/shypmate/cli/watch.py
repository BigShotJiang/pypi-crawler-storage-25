"""Watch command — autonomous handoff processing."""

import time
from pathlib import Path

import click
from rich.console import Console

from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.config import get_project_config, is_authenticated, is_initialized
from shypmate.providers import get_provider

console = Console()


def _process_handoff(
    client: ShypmateClient,
    handoff: dict,
    project_id: str,
    mate_name: str,
    skill_content: str,
    llm: str,
) -> None:
    """Invoke the mate's LLM on a handoff, send result back, mark original as read."""
    handoff_id = handoff["id"]
    from_mate = handoff["from_mate"]
    message = handoff["message"]
    preview = message[:80] + ("..." if len(message) > 80 else "")

    console.print(f"\n  [bold]Handoff from /{from_mate}:[/bold] {preview}")

    provider = get_provider(llm)
    with console.status(f"  /{mate_name} working ({llm})..."):
        result = provider.run_once(mate_name, skill_content, message)

    console.print(f"  [dim]Response: {len(result)} chars[/dim]")

    try:
        client.create_handoff(
            project_id=project_id,
            from_mate=mate_name,
            to_mate=from_mate,
            message=result,
            reply_to_id=handoff_id,
            parent_id=handoff.get("parent_id"),
        )
        console.print(f"  [green]✓[/green] Result sent to /{from_mate}")
    except ShypmateAPIError as e:
        console.print(f"  [red]Failed to send result:[/red] {e.message}")

    try:
        client.mark_handoff_read(handoff_id)
    except Exception:
        pass


@click.command()
@click.option("--mate", required=True, help="Mate name to watch for incoming handoffs")
@click.option("--interval", default=30, show_default=True, help="Poll interval in seconds")
@click.option("--once", is_flag=True, help="Process the first pending handoff then exit")
def watch(mate: str, interval: int, once: bool):
    """Watch for handoffs and process them autonomously.

    Uses the LLM assigned to the mate on shypmate.dev.

    Example:

        shypmate watch --mate terry
    """
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()

    if not is_initialized():
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    config = get_project_config()
    project_id = config.get("project_id", "")
    mate_name = mate.lower().strip()

    api_client = ShypmateClient()

    # Fetch mate to get LLM assignment and skill content
    try:
        mate_obj = api_client.get_mate(mate_name)
    except ShypmateAPIError as e:
        console.print(f"[red]Error loading mate:[/red] {e.message}")
        raise click.Abort()

    llm = mate_obj.get("llm", "claude")
    skill_content = mate_obj.get("skill_md", "")

    # Fall back to local skill file
    if not skill_content:
        skill_file = Path.home() / ".claude" / "skills" / mate_name / "SKILL.md"
        if skill_file.exists():
            skill_content = skill_file.read_text().strip()

    console.print()
    console.print(f"  [bold]/{mate_name}[/bold] watching for handoffs  [dim]({llm})[/dim]")
    console.print(f"  Polling every {interval}s")
    if once:
        console.print("  [dim]--once: will exit after first handoff[/dim]")
    console.print("  Ctrl+C to stop\n")

    try:
        while True:
            try:
                handoffs = api_client.get_handoffs(project_id=project_id, to_mate=mate_name)
            except ShypmateAPIError as e:
                console.print(f"  [red]Poll error:[/red] {e.message}")
                time.sleep(interval)
                continue

            for handoff in handoffs:
                _process_handoff(api_client, handoff, project_id, mate_name, skill_content, llm)
                if once:
                    console.print("\n  [dim]Done.[/dim]")
                    return

            time.sleep(interval)

    except KeyboardInterrupt:
        console.print("\n  [dim]Stopped.[/dim]")
