"""Authentication commands."""

import click
from rich.console import Console

from shypmate.config import save_user_config, get_user_config, is_authenticated, DEFAULT_API_URL
from shypmate.api import ShypmateClient, ShypmateAPIError

console = Console()


@click.group()
def auth():
    """Manage authentication with shypmate.dev."""
    pass


@auth.command()
@click.option("--api-key", prompt=False, default=None, help="API key (or login via browser)")
@click.option("--api-url", default=None, help="Custom API URL (default: api.shypmate.dev)")
def login(api_key: str | None, api_url: str | None):
    """Authenticate with shypmate.dev."""
    if api_key is None:
        # If only updating the URL, reuse the saved key
        saved_key = get_user_config().get("api_key")
        if api_url and saved_key:
            api_key = saved_key
        else:
            console.print("\nCreate or copy your API key at [bold][link=https://shypmate.dev/settings/api-keys]shypmate.dev/settings/api-keys[/link][/bold]\n")
            api_key = click.prompt("Paste your API key here", hide_input=True)

    # Verify the key works
    config = get_user_config()
    config["api_key"] = api_key
    if api_url:
        config["api_url"] = api_url

    try:
        client = ShypmateClient(api_key=api_key, base_url=api_url)
        user_info = client.verify_token()

        config["user_email"] = user_info.get("email", "")
        config["user_name"] = user_info.get("name", "")
        config["plan"] = user_info.get("plan", "free")

        save_user_config(config)

        console.print(f"\n[green]✓[/green] Authenticated as [bold]{config['user_email']}[/bold]")
        console.print(f"  Plan: {config['plan']}")

        mates = client.list_mates()
        if mates:
            names = ", ".join(a["name"] for a in mates)
            console.print(f"  Your team: {len(mates)} mates ({names})")
        else:
            console.print("  No mates yet. Run [bold]shypmate hire[/bold] to create one.")

    except ShypmateAPIError as e:
        console.print(f"\n[red]✗[/red] Authentication failed: {e.message}")
        raise click.Abort()


@auth.command()
def logout():
    """Remove saved credentials."""
    config = get_user_config()
    config.pop("api_key", None)
    save_user_config(config)
    console.print("[green]✓[/green] Logged out. API key removed.")


@auth.command()
def status():
    """Show current auth status."""
    if is_authenticated():
        config = get_user_config()
        console.print(f"[green]✓[/green] Authenticated as [bold]{config.get('user_email', 'unknown')}[/bold]")
        console.print(f"  Plan: {config.get('plan', 'unknown')}")
    else:
        console.print("[yellow]Not authenticated.[/yellow] Run [bold]shypmate auth login[/bold]")
