"""Project commands — init, sync."""

import json
import subprocess
import click
from pathlib import Path
from rich.console import Console

from shypmate.config import (
    is_authenticated,
    save_project_config,
    get_project_config,
    write_curl_auth_config,
    PROJECT_CONFIG_DIR,
)
from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.skills import sync_all_mates, install_base_skill, write_session_instructions

console = Console()


GITIGNORE_ENTRIES = [
    (".shypmate/mates/", "generated skill files (safe to regenerate)"),
    (".shypmate/session-instructions.md", "generated at runtime by shypmate up/sync"),
    (".shypmate/active-mate", "runtime: currently active mate name"),
    (".shypmate/.compacting", "runtime: compact-in-progress flag"),
    (".shypmate/pending-handoffs.json", "runtime: unread handoffs written on mate activation"),
]


def _ensure_gitignore() -> None:
    """Add shypmate-generated files to .gitignore if not already present."""
    gitignore = Path(".gitignore")
    existing = gitignore.read_text() if gitignore.exists() else ""

    additions = []
    for entry, reason in GITIGNORE_ENTRIES:
        if entry not in existing:
            additions.append(f"{entry}  # {reason}")

    if not additions:
        return

    block = "\n\n# shypmate — do not commit\n" + "\n".join(additions) + "\n"
    gitignore.write_text(existing.rstrip() + block)

    for entry, _ in GITIGNORE_ENTRIES:
        if entry not in existing:
            console.print(f"  [dim]Added {entry} to .gitignore[/dim]")


def _ensure_claude_hooks() -> None:
    """Install shypmate Stop and PreCompact hooks into .claude/settings.json."""
    import json as _json

    claude_dir = Path(".claude")
    claude_dir.mkdir(exist_ok=True)
    settings_file = claude_dir / "settings.json"

    settings = {}
    if settings_file.exists():
        try:
            settings = _json.loads(settings_file.read_text())
        except Exception:
            settings = {}

    # Allow all shypmate CLI calls without prompting
    permissions = settings.setdefault("permissions", {})
    allow = permissions.setdefault("allow", [])
    if "Bash(shypmate:*)" not in allow:
        allow.append("Bash(shypmate:*)")

    hooks = settings.setdefault("hooks", {})

    # Stop hook — deactivates the active mate on session end
    stop_hooks = hooks.setdefault("Stop", [])
    stop_cmd = "shypmate mate deactivate --quiet 2>/dev/null || true"
    if not any(
        any(h.get("command") == stop_cmd for h in entry.get("hooks", []))
        for entry in stop_hooks
    ):
        stop_hooks.append({"hooks": [{"type": "command", "command": stop_cmd}]})
        console.print("  [green]✓[/green] Installed Stop hook (.claude/settings.json)")

    # PreCompact hook — sets a flag so Stop hook knows not to deactivate
    precompact_hooks = hooks.setdefault("PreCompact", [])
    precompact_cmd = "touch .shypmate/.compacting 2>/dev/null || true"
    if not any(
        any(h.get("command") == precompact_cmd for h in entry.get("hooks", []))
        for entry in precompact_hooks
    ):
        precompact_hooks.append({"hooks": [{"type": "command", "command": precompact_cmd}]})
        console.print("  [green]✓[/green] Installed PreCompact hook (.claude/settings.json)")

    settings_file.write_text(_json.dumps(settings, indent=2))


def _require_auth():
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()


def _detect_stack() -> dict:
    """Detect the project stack from manifest files."""
    stack = {"languages": [], "frameworks": [], "databases": [], "tools": []}
    cwd = Path.cwd()

    # Node/JS
    pkg = cwd / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text())
            deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
            stack["languages"].append("TypeScript" if "typescript" in deps else "JavaScript")

            framework_map = {
                "vue": "Vue", "react": "React", "next": "Next.js", "nuxt": "Nuxt",
                "svelte": "Svelte", "angular": "Angular", "fastify": "Fastify",
                "express": "Express", "hono": "Hono", "nestjs": "NestJS",
            }
            for key, name in framework_map.items():
                if any(key in d.lower() for d in deps):
                    stack["frameworks"].append(name)

            db_map = {
                "drizzle": "Drizzle ORM", "prisma": "Prisma", "postgres": "PostgreSQL",
                "pg": "PostgreSQL", "mysql": "MySQL", "mongodb": "MongoDB",
                "supabase": "Supabase", "sqlite": "SQLite",
            }
            for key, name in db_map.items():
                if any(key in d.lower() for d in deps):
                    if name not in stack["databases"]:
                        stack["databases"].append(name)

            tool_map = {
                "vite": "Vite", "vitest": "Vitest", "jest": "Jest",
                "docker": "Docker", "expo": "Expo",
            }
            for key, name in tool_map.items():
                if any(key in d.lower() for d in deps):
                    stack["tools"].append(name)
        except (json.JSONDecodeError, KeyError):
            pass

    # Python
    pyproject = cwd / "pyproject.toml"
    if pyproject.exists():
        stack["languages"].append("Python")

    # Docker
    if (cwd / "docker-compose.yml").exists() or (cwd / "Dockerfile").exists():
        if "Docker" not in stack["tools"]:
            stack["tools"].append("Docker")

    return stack


@click.command()
@click.option("--name", default=None, help="Project name (default: directory name)")
@click.option("--project", "join_project", default=None, metavar="NAME_OR_ID",
              help="Join an existing project by name or ID instead of creating a new one.")
def init(name: str | None, join_project: str | None):
    """Initialize shypmate in the current project directory.

    To join an existing project on another machine:

        shypmate init --project shypmate
    """
    _require_auth()
    client = ShypmateClient()

    # Check if already initialized
    existing = get_project_config()
    if existing.get("project_id"):
        console.print(f"[yellow]Already initialized[/yellow] (project: {existing['project_name']})")
        console.print("  Run [bold]shypmate sync[/bold] to refresh mates.")
        _ensure_claude_hooks()
        return

    if join_project:
        _init_join(client, join_project)
    else:
        _init_create(client, name)


def _init_join(client, name_or_id: str) -> None:
    """Join an existing shypmate project by name or UUID."""
    console.print(f"[bold]Joining project:[/bold] {name_or_id}\n")

    with console.status("Looking up project on shypmate.dev..."):
        try:
            project = client.find_project(name_or_id)
        except ShypmateAPIError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise click.Abort()

    if not project:
        console.print(f"[red]Project not found:[/red] {name_or_id}")
        console.print("  Check the name with [bold]shypmate status[/bold] on the original machine.")
        raise click.Abort()

    project_id = project["id"]
    project_name = project.get("name", name_or_id)
    console.print(f"  [green]✓[/green] Found: {project_name} ({project_id[:8]}...)")

    save_project_config({
        "project_id": project_id,
        "project_name": project_name,
        "mates": [],
    })

    _sync_and_finish(client, project_id, project_name, is_join=True)


def _init_create(client, name: str | None) -> None:
    """Create and register a new shypmate project."""
    project_name = name or Path.cwd().name
    console.print(f"[bold]Initializing shypmate for:[/bold] {project_name}\n")

    with console.status("Analyzing project..."):
        stack = _detect_stack()

    stack_parts = stack["frameworks"] + stack["databases"] + stack["tools"]
    if stack_parts:
        console.print(f"  Stack detected: {' + '.join(stack_parts)}")
    if stack["languages"]:
        console.print(f"  Languages: {', '.join(stack['languages'])}")
    console.print()

    try:
        with console.status("Registering project on shypmate.dev..."):
            stack_list = stack["languages"] + stack["frameworks"] + stack["databases"] + stack["tools"]
            project = client.create_project({"name": project_name, "stack": stack_list})
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()

    project_id = project["id"]
    save_project_config({"project_id": project_id, "project_name": project_name, "mates": []})

    # Create project context stub and push to server
    context_file = PROJECT_CONFIG_DIR / "project-context.md"
    if not context_file.exists():
        stack_str = " + ".join(stack_parts) if stack_parts else "Unknown"
        initial_context = (
            f"# {project_name}\n\n"
            f"Stack: {stack_str}\n"
            f"Languages: {', '.join(stack['languages']) if stack['languages'] else 'Unknown'}\n"
        )
        context_file.write_text(initial_context)
        console.print(f"  [green]✓[/green] .shypmate/project-context.md")

        try:
            with console.status("Pushing initial project context..."):
                client.update_project_context(project_id, initial_context)
            console.print("  [green]✓[/green] Project context synced to shypmate.dev")
        except ShypmateAPIError as e:
            console.print(f"  [yellow]Warning:[/yellow] Could not push context: {e.message}")

    _sync_and_finish(client, project_id, project_name, is_join=False)


def _sync_and_finish(client, project_id: str, project_name: str, is_join: bool) -> None:
    """Shared tail of init: sync mates, write files, install hooks, print ready."""
    from shypmate.session import get_machine_id

    console.print("Syncing mates from shypmate.dev...")
    installed = []
    try:
        all_mates = client.list_mates()
        installed = sync_all_mates(client)
        for m in installed:
            console.print(f"  [green]✓[/green] {m}")

        config = get_project_config()
        config["mates"] = [m["name"] for m in all_mates]
        save_project_config(config)
        write_session_instructions(project_id, client.base_url, config["mates"], machine_id=get_machine_id())
    except ShypmateAPIError as e:
        console.print(f"  [yellow]Warning:[/yellow] Could not sync mates: {e.message}")

    _ensure_gitignore()
    _ensure_claude_hooks()

    console.print(f"\n[green]✓ Ready![/green] Your mates are connected to this project.\n")

    if installed:
        console.print(f"  Start working:")
        console.print(f'    claude [bold]/{installed[0]}[/bold] "your task here"')
    else:
        console.print("  No mates yet. Run [bold]shypmate hire[/bold] to create one.")


@click.command()
@click.option("--quiet", is_flag=True, hidden=True, help="Suppress output (for hooks)")
@click.option("--if-stale", "if_stale", default=0, hidden=True, type=int,
              help="Skip if last sync was within N seconds (for hooks)")
def sync(quiet: bool, if_stale: int):
    """Sync mates and playbook from shypmate.dev."""
    from shypmate.session import (
        clear_session_status, seconds_since_last_sync, touch_last_sync
    )

    _require_auth()

    if if_stale > 0:
        secs = seconds_since_last_sync()
        if secs is not None and secs < if_stale:
            return  # Fresh enough — skip

    client = ShypmateClient()
    if client.api_key:
        write_curl_auth_config(client.api_key)

    config = get_project_config()
    if not config.get("project_id"):
        if not quiet:
            console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        return

    project_id = config["project_id"]

    with console.status("Syncing from shypmate.dev...") if not quiet else _null_context():
        try:
            all_mates = client.list_mates()
            installed = sync_all_mates(client)
        except ShypmateAPIError as e:
            if not quiet:
                console.print(f"[red]Error:[/red] {e.message}")
            return

        # Pull latest project context
        try:
            context = client.get_project_context(project_id)
            if context:
                context_file = PROJECT_CONFIG_DIR / "project-context.md"
                context_file.write_text(context)
        except ShypmateAPIError:
            pass  # Non-fatal — local file stays as fallback

    config["mates"] = [m["name"] for m in all_mates]
    save_project_config(config)
    from shypmate.session import get_machine_id
    write_session_instructions(project_id, client.base_url, config["mates"], machine_id=get_machine_id())
    _ensure_claude_hooks()
    touch_last_sync()
    clear_session_status()

    if not quiet:
        console.print(f"[green]✓[/green] Synced {len(installed)} mates, context and playbook updated")
        for name in installed:
            console.print(f"  /{name}")


@click.command("push-context")
@click.option("--append", "append_text", default=None, metavar="TEXT",
              help="Append a note instead of replacing the full context.")
def push_context(append_text: str | None):
    """Push .shypmate/project-context.md to shypmate.dev.

    Use --append to add a timestamped note without replacing the full context.
    """
    _require_auth()

    config = get_project_config()
    if not config.get("project_id"):
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    client = ShypmateClient()
    project_id = config["project_id"]

    if append_text:
        try:
            with console.status("Appending to project context..."):
                client.append_project_context(project_id, append_text.strip())
            console.print("[green]✓[/green] Context updated on shypmate.dev")
        except ShypmateAPIError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise click.Abort()
        return

    context_file = PROJECT_CONFIG_DIR / "project-context.md"
    if not context_file.exists():
        console.print(f"[red]Not found:[/red] {context_file}")
        console.print("  Create it with a description of your project stack and technologies.")
        raise click.Abort()

    content = context_file.read_text().strip()
    if not content:
        console.print("[yellow]project-context.md is empty — nothing to push.[/yellow]")
        raise click.Abort()

    try:
        with console.status("Pushing project context..."):
            client.update_project_context(project_id, content)
        console.print("[green]✓[/green] Project context updated on shypmate.dev")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


@click.command("stack-add")
@click.argument("technologies", nargs=-1, required=True)
def stack_add(technologies: tuple[str, ...]):
    """Add technologies to the project stack on shypmate.dev.

    Example: shypmate stack-add Redis BullMQ
    """
    _require_auth()

    config = get_project_config()
    if not config.get("project_id"):
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    client = ShypmateClient()
    try:
        with console.status("Updating stack..."):
            result = client.update_project_stack(config["project_id"], list(technologies))
        added = result.get("added", [])
        if added:
            console.print(f"[green]✓[/green] Added: {', '.join(added)}")
        else:
            console.print("[dim]No new technologies — already in stack.[/dim]")
        console.print(f"  Stack: {', '.join(result.get('stack', []))}")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


@click.command("stack-remove")
@click.argument("technology")
def stack_remove(technology: str):
    """Remove a technology from the project stack on shypmate.dev.

    Example: shypmate stack-remove Redis
    """
    _require_auth()

    config = get_project_config()
    if not config.get("project_id"):
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    client = ShypmateClient()
    try:
        with console.status(f"Removing {technology} from stack..."):
            result = client.remove_project_stack_tech(config["project_id"], technology)
        console.print(f"[green]✓[/green] Removed: {technology}")
        stack = result.get("stack", [])
        if stack:
            console.print(f"  Stack: {', '.join(stack)}")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


@click.command()
def playbook():
    """Print the shared team playbook from shypmate.dev."""
    _require_auth()
    client = ShypmateClient()
    try:
        content = client.get_playbook()
        console.print(content)
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


from contextlib import contextmanager

@contextmanager
def _null_context():
    yield
