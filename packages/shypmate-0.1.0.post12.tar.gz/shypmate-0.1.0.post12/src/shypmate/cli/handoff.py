"""Handoff commands — send, list, and mark read."""

import click
from pathlib import Path
from rich.console import Console

from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.config import is_authenticated, get_project_id, is_initialized

console = Console()


def _require_auth():
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()


def _require_project():
    if not is_initialized():
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()


@click.group()
def handoff():
    """Send and receive handoff messages between mates."""
    pass


@handoff.command("send")
@click.option("--from", "from_mate", required=True, help="Sending mate name")
@click.option("--to", "to_mate", required=True, help="Receiving mate name")
@click.option("--message", "-m", required=True, help="Handoff message body")
@click.option("--reply-to", "reply_to_id", default=None, help="UUID of the handoff this replies to")
@click.option("--parent", "parent_id", default=None, help="UUID of the originating handoff in a cascade")
def handoff_send(from_mate: str, to_mate: str, message: str, reply_to_id: str | None, parent_id: str | None):
    """Send a handoff message to a teammate.

    Examples:

        shypmate handoff send --from marco --to terry --message "PR is ready for review"

        shypmate handoff send --from marco --to terry -m "Done" --reply-to <uuid>
    """
    _require_auth()
    _require_project()

    project_id = get_project_id()
    client = ShypmateClient()

    try:
        result = client.create_handoff(
            project_id=project_id,
            from_mate=from_mate.lower().strip(),
            to_mate=to_mate.lower().strip(),
            message=message,
            reply_to_id=reply_to_id,
            parent_id=parent_id,
        )
        console.print(f"[green]✓[/green] Handoff sent to [bold]/{to_mate}[/bold] (id: {result['id']})")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


@handoff.command("list")
@click.option("--mate", required=True, help="Mate name to fetch handoffs for")
@click.option("--all", "show_all", is_flag=True, help="Include already-read handoffs")
def handoff_list(mate: str, show_all: bool):
    """List pending handoffs for a mate.

    Exits with output suitable for a mate to read and act on.

    Example:

        shypmate handoff list --mate marco
    """
    _require_auth()
    _require_project()

    project_id = get_project_id()
    client = ShypmateClient()

    try:
        handoffs = client.get_handoffs(project_id=project_id, to_mate=mate.lower().strip(), unread_only=not show_all)
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()

    if not handoffs:
        console.print("No pending handoffs.")
        return

    for h in handoffs:
        reply_info = f"  [dim]reply-to: {h['reply_to_id']}[/dim]" if h.get("reply_to_id") else ""
        parent_info = f"  [dim]parent: {h['parent_id']}[/dim]" if h.get("parent_id") else ""
        console.print(
            f"[bold]{h['id']}[/bold]  from /{h['from_mate']}{reply_info}{parent_info}\n"
            f"  {h['message']}\n"
        )


@handoff.command("pending")
@click.option("--mate", default=None, help="Mate name (informational only)")
def handoff_pending(mate: str | None):
    """Print and clear pending handoffs written at session activation.

    Called automatically at session start. Outputs JSON to stdout and
    removes the file so handoffs are only surfaced once.
    """
    import json as _json

    pending_file = Path(".shypmate") / "pending-handoffs.json"
    if not pending_file.exists():
        return

    try:
        data = pending_file.read_text()
        print(data)
    finally:
        pending_file.unlink(missing_ok=True)


@handoff.command("read")
@click.argument("handoff_id")
def handoff_read(handoff_id: str):
    """Mark a handoff as read.

    Example:

        shypmate handoff read <uuid>
    """
    _require_auth()

    client = ShypmateClient()
    try:
        client.mark_handoff_read(handoff_id)
        console.print(f"[green]✓[/green] Marked read: {handoff_id}")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()
