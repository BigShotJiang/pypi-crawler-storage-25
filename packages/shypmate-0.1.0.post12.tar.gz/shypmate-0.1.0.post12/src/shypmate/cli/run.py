"""Run command — start an interactive mate session on the appropriate LLM."""

from pathlib import Path

import click
from rich.console import Console

from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.config import is_authenticated
from shypmate.providers import get_provider

console = Console()


@click.command(
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
@click.option("--mate", required=True, help="Mate name to run")
@click.argument("extra_args", nargs=-1, type=click.UNPROCESSED)
def run(mate: str, extra_args: tuple):
    """Start an interactive session with a mate using their assigned LLM.

    Any arguments after -- are passed directly to the underlying CLI or API:

        shypmate run --mate terry -- --dangerously-skip-permissions

        shypmate run --mate marco -- --model gpt-4o-mini --temperature 0.5
    """
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()

    mate_name = mate.lower().strip()
    client = ShypmateClient()

    try:
        with console.status(f"Loading /{mate_name}..."):
            mate_obj = client.get_mate(mate_name)
    except ShypmateAPIError as e:
        if e.status_code == 404:
            console.print(f"[red]Mate not found:[/red] {mate_name}")
        else:
            console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()

    llm = mate_obj.get("llm", "claude")
    skill_content = mate_obj.get("skill_md", "")

    # Fall back to local skill file if server didn't return skill_md
    if not skill_content:
        skill_file = Path.home() / ".claude" / "skills" / mate_name / "SKILL.md"
        if skill_file.exists():
            skill_content = skill_file.read_text().strip()

    provider = get_provider(llm)

    console.print(f"\n  Starting [bold]/{mate_name}[/bold] on [bold]{llm}[/bold]")
    if extra_args:
        console.print(f"  Passing: {' '.join(extra_args)}")
    console.print()

    try:
        provider.run_interactive(mate_name, skill_content, list(extra_args))
    except RuntimeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.Abort()
