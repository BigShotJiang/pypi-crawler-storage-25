"""Memory browsing commands."""

import click
from rich.console import Console

from shypmate.config import is_authenticated, get_project_id
from shypmate.api import ShypmateClient, ShypmateAPIError

console = Console()


def _require_auth():
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()


@click.group()
def memory():
    """Browse and manage mate memory."""
    pass


@memory.command("list")
@click.option("--project", default=None, help="Filter by project ID")
def memory_list(project: str | None):
    """List all memory entries."""
    _require_auth()
    client = ShypmateClient()
    project_id = project or get_project_id()

    try:
        entries = client.list_memory(project_id=project_id)
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        return

    if not entries:
        console.print("No memory entries yet. Mates save learnings at session end.")
        return

    by_mate: dict[str, list] = {}
    for entry in entries:
        mate = entry.get("mate_name", "unknown")
        by_mate.setdefault(mate, []).append(entry)

    for mate, mate_entries in sorted(by_mate.items()):
        global_count = sum(1 for e in mate_entries if e.get("scope") == "global")
        project_count = sum(1 for e in mate_entries if e.get("scope") == "project")
        console.print(
            f"  [bold]{mate}[/bold] — {len(mate_entries)} entries "
            f"({project_count} project, {global_count} global)"
        )


@memory.command("show")
@click.argument("mate_name")
@click.option("--scope", type=click.Choice(["global", "project", "all"]), default="all")
@click.option("--project", default=None, help="Project ID for project-scoped memory")
@click.option("--last", "limit", default=10, help="Number of entries to show")
def memory_show(mate_name: str, scope: str, project: str | None, limit: int):
    """Show memory entries for a mate."""
    _require_auth()
    client = ShypmateClient()
    project_id = project or get_project_id()
    name = mate_name.lower().strip()

    try:
        if scope in ("global", "all"):
            global_mem = client.get_memory(name, scope="global")
            if global_mem.strip():
                console.print(f"\n[bold]{name} — global memory[/bold]")
                lines = global_mem.strip().split("\n")[-limit:]
                for line in lines:
                    console.print(f"  {line}")

        if scope in ("project", "all") and project_id:
            project_mem = client.get_memory(name, scope="project", project_id=project_id)
            if project_mem.strip():
                console.print(f"\n[bold]{name} — project memory[/bold]")
                lines = project_mem.strip().split("\n")[-limit:]
                for line in lines:
                    console.print(f"  {line}")

    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")


@memory.command("save")
@click.argument("mate_name")
@click.argument("content")
@click.option("--scope", type=click.Choice(["global", "project"]), default="project", show_default=True)
@click.option("--project", default=None, help="Project ID (default: current project)")
def memory_save(mate_name: str, content: str, scope: str, project: str | None):
    """Save a memory entry for a mate.

    Example:

        shypmate memory save terry "prefer short PR descriptions" --scope global

        shypmate memory save terry "postgres is on port 5433 in dev" --scope project
    """
    _require_auth()
    client = ShypmateClient()
    name = mate_name.lower().strip()
    project_id = project or get_project_id()

    payload: dict = {"content": content, "scope": scope}
    if scope == "project" and project_id:
        payload["project_id"] = project_id

    try:
        client.append_memory(name, content, scope=scope, project_id=project_id if scope == "project" else None)
        console.print(f"[green]✓[/green] Memory saved for [bold]{name}[/bold] ({scope})")
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        raise click.Abort()


@memory.command("search")
@click.argument("query")
@click.option("--mate", default=None, help="Filter by mate name")
def memory_search(query: str, mate: str | None):
    """Search across all mate memory."""
    _require_auth()
    client = ShypmateClient()

    try:
        entries = client.list_memory()
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        return

    query_lower = query.lower()
    matches = [
        e for e in entries
        if query_lower in e.get("content", "").lower()
        and (mate is None or e.get("mate_name") == mate.lower())
    ]

    if not matches:
        console.print(f"No memory entries matching '{query}'.")
        return

    console.print(f"\n[bold]{len(matches)} matches for '{query}'[/bold]\n")
    for entry in matches[:20]:
        mate_name = entry.get("mate_name", "?")
        scope = entry.get("scope", "?")
        content = entry.get("content", "")
        ts = entry.get("created_at", "")[:16]
        console.print(f"  [{ts}] [bold]{mate_name}[/bold] ({scope}) — {content}")
