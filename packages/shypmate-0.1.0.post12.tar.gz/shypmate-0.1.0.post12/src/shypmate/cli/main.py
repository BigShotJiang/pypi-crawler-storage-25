"""shypmate CLI entry point (registered in pyproject.toml)."""

from shypmate.cli import cli

if __name__ == "__main__":
    cli()
