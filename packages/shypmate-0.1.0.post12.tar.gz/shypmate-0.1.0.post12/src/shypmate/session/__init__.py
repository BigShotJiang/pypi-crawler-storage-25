"""Session management: daemon lifecycle, machine ID, status file."""

import json
import os
import signal
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from shypmate.config import USER_CONFIG_DIR


MACHINE_ID_FILE = USER_CONFIG_DIR / "machine-id"
PID_FILE = USER_CONFIG_DIR / "session.pid"
SESSION_STATUS_FILE = USER_CONFIG_DIR / "session-status.json"
LAST_SYNC_FILE = USER_CONFIG_DIR / "last-sync"


def get_machine_id() -> str:
    """Get or create a stable machine ID."""
    if MACHINE_ID_FILE.exists():
        return MACHINE_ID_FILE.read_text().strip()
    machine_id = str(uuid.uuid4())
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    MACHINE_ID_FILE.write_text(machine_id)
    return machine_id


def write_pid(pid: int) -> None:
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(pid))


def read_pid() -> Optional[int]:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def clear_pid() -> None:
    PID_FILE.unlink(missing_ok=True)


def is_running() -> bool:
    """Check if the daemon process is alive."""
    pid = read_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        clear_pid()
        return False


def stop_daemon() -> bool:
    """Send SIGTERM to the daemon. Returns True if a process was stopped."""
    pid = read_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, signal.SIGTERM)
        clear_pid()
        return True
    except ProcessLookupError:
        clear_pid()
        return False


def write_session_status(data: dict) -> None:
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_STATUS_FILE.write_text(json.dumps(data, indent=2))


def clear_session_status() -> None:
    SESSION_STATUS_FILE.unlink(missing_ok=True)


def get_session_status() -> Optional[dict]:
    if not SESSION_STATUS_FILE.exists():
        return None
    try:
        return json.loads(SESSION_STATUS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def touch_last_sync() -> None:
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    LAST_SYNC_FILE.write_text(datetime.now(timezone.utc).isoformat())


def get_last_sync() -> Optional[datetime]:
    if not LAST_SYNC_FILE.exists():
        return None
    try:
        return datetime.fromisoformat(LAST_SYNC_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def seconds_since_last_sync() -> Optional[float]:
    last = get_last_sync()
    if last is None:
        return None
    return (datetime.now(timezone.utc) - last).total_seconds()


def spawn_daemon(project_id: str) -> int:
    """Spawn the SSE listener as a detached background process. Returns PID."""
    cmd = [sys.executable, "-m", "shypmate._daemon", project_id]
    kwargs: dict = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        kwargs["creationflags"] = (
            subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        kwargs["start_new_session"] = True

    proc = subprocess.Popen(cmd, **kwargs)
    return proc.pid
