"""
shypmate — Build, manage, and deploy AI mates across your projects.

Usage:
    pip install shypmate
    shypmate auth login
    shypmate init
    claude /terry "your task here"
"""

__app_name__ = "shypmate"
