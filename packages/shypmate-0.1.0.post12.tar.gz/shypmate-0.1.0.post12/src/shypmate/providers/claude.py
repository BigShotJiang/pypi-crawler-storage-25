"""Claude Code CLI provider."""

import os
import shutil
import subprocess
from pathlib import Path

from shypmate.providers.base import BaseProvider

CLAUDE_TIMEOUT = 300


class ClaudeProvider(BaseProvider):
    def _find_binary(self) -> str | None:
        return shutil.which("claude")

    def run_interactive(self, mate_name: str, skill_content: str, extra_args: list[str]) -> None:
        """Hand off to the Claude Code CLI, auto-loading the mate's skill."""
        claude = self._find_binary()
        if not claude:
            raise RuntimeError(
                "Claude CLI not found. Install Claude Code: https://claude.ai/code"
            )
        # Pass /mate_name as the initial message — Claude Code loads the skill automatically
        os.execvp(claude, [claude, f"/{mate_name}", *extra_args])

    def run_once(self, mate_name: str, skill_content: str, message: str) -> str:
        """Invoke claude non-interactively with the skill as context."""
        claude = self._find_binary()
        if not claude:
            return "Error: Claude CLI not found. Install Claude Code to process handoffs."

        prompt = f"{skill_content}\n\n---\n\n{message}" if skill_content else message

        try:
            result = subprocess.run(
                [claude, "-p", prompt],
                capture_output=True,
                text=True,
                timeout=CLAUDE_TIMEOUT,
            )
            return result.stdout.strip() or result.stderr.strip() or "No response."
        except subprocess.TimeoutExpired:
            return f"Task timed out after {CLAUDE_TIMEOUT // 60} minutes."
        except Exception as e:
            return f"Error invoking Claude: {e}"
