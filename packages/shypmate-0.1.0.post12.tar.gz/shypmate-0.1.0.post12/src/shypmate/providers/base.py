"""Base class for LLM providers."""


class BaseProvider:
    def run_interactive(self, mate_name: str, skill_content: str, extra_args: list[str]) -> None:
        """Start an interactive session as this mate. Does not return (takes over the process)."""
        raise NotImplementedError

    def run_once(self, mate_name: str, skill_content: str, message: str) -> str:
        """Invoke the mate once with a message and return the text response."""
        raise NotImplementedError
