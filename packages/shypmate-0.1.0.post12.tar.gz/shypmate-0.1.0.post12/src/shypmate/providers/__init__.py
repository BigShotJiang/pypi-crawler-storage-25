"""LLM provider abstraction for running and invoking mates.

Each provider implements two modes:
- run_interactive: start a full interactive session (used by `shypmate run`)
- run_once: invoke once and return text output (used by `shypmate watch`)
"""

from shypmate.providers.base import BaseProvider


def get_provider(llm: str) -> BaseProvider:
    """Return the provider for the given LLM name."""
    llm = (llm or "claude").lower().strip()
    if llm == "openai":
        from shypmate.providers.openai_llm import OpenAIProvider
        return OpenAIProvider()
    else:  # "claude", "anthropic", or anything unrecognised defaults to Claude
        from shypmate.providers.claude import ClaudeProvider
        return ClaudeProvider()
