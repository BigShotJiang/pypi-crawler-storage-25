"""OpenAI provider — interactive REPL and single-shot invocation."""

from shypmate.providers.base import BaseProvider

DEFAULT_MODEL = "gpt-4o"


def _get_client():
    try:
        from openai import OpenAI
        return OpenAI()  # reads OPENAI_API_KEY from environment
    except ImportError:
        raise RuntimeError(
            "openai package not installed. Run: pip install openai"
        )


def _parse_extra_args(extra_args: list[str]) -> dict:
    """Extract known OpenAI API params from passthrough args. Unknown args are ignored."""
    params = {}
    i = 0
    while i < len(extra_args):
        arg = extra_args[i]
        if arg == "--model" and i + 1 < len(extra_args):
            params["model"] = extra_args[i + 1]
            i += 2
        elif arg == "--temperature" and i + 1 < len(extra_args):
            params["temperature"] = float(extra_args[i + 1])
            i += 2
        elif arg == "--max-tokens" and i + 1 < len(extra_args):
            params["max_tokens"] = int(extra_args[i + 1])
            i += 2
        else:
            i += 1
    return params


class OpenAIProvider(BaseProvider):
    def run_interactive(self, mate_name: str, skill_content: str, extra_args: list[str]) -> None:
        """Run an interactive chat REPL with the mate's persona as the system prompt."""
        client = _get_client()
        api_params = _parse_extra_args(extra_args)
        model = api_params.pop("model", DEFAULT_MODEL)

        messages = []
        if skill_content:
            messages.append({"role": "system", "content": skill_content})

        print(f"\n  /{mate_name} ({model}) — type /exit to end session\n")

        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print(f"\n  /{mate_name} session ended.")
                break

            if user_input.lower() in ("/exit", "/quit", "exit", "quit"):
                print(f"  /{mate_name} session ended.")
                break

            if not user_input:
                continue

            messages.append({"role": "user", "content": user_input})

            try:
                stream = client.chat.completions.create(
                    model=model,
                    messages=messages,
                    stream=True,
                    **api_params,
                )
                print(f"\n/{mate_name}: ", end="", flush=True)
                response = ""
                for chunk in stream:
                    content = chunk.choices[0].delta.content or ""
                    print(content, end="", flush=True)
                    response += content
                print("\n")
                messages.append({"role": "assistant", "content": response})

            except Exception as e:
                print(f"\n  [error] {e}\n")

    def run_once(self, mate_name: str, skill_content: str, message: str) -> str:
        """Single invocation — returns the response text."""
        client = _get_client()

        messages = []
        if skill_content:
            messages.append({"role": "system", "content": skill_content})
        messages.append({"role": "user", "content": message})

        try:
            response = client.chat.completions.create(
                model=DEFAULT_MODEL,
                messages=messages,
            )
            return response.choices[0].message.content or "No response."
        except Exception as e:
            return f"Error invoking OpenAI: {e}"
