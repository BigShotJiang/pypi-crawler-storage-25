"""Security checks for outbound content."""

import re

# Patterns that indicate secrets or credentials
_SECRET_PATTERNS = [
    # shypmate API keys
    (r"shyp_sk_[A-Za-z0-9_\-]{10,}", "shypmate API key"),
    # OpenAI / Anthropic style keys
    (r"sk-[A-Za-z0-9]{20,}", "API key"),
    # AWS access keys
    (r"AKIA[0-9A-Z]{16}", "AWS access key"),
    # GitHub tokens
    (r"gh[pors]_[A-Za-z0-9]{36,}", "GitHub token"),
    # Generic key/secret/password/token assignments
    (r"(?i)(api[_\-]?key|secret[_\-]?key|access[_\-]?token|auth[_\-]?token|password|passwd)\s*[:=]\s*[\"']?\S{6,}", "credential"),
    # PEM private keys
    (r"-----BEGIN [A-Z ]+PRIVATE KEY-----", "private key"),
    # JWT tokens
    (r"eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}", "JWT token"),
    # Bearer tokens in text
    (r"(?i)bearer\s+[A-Za-z0-9_\-\.]{20,}", "bearer token"),
    # Long hex strings (32+ chars) typical of keys/tokens
    (r"\b[0-9a-f]{32,}\b", "token or hash"),
]


def find_secrets(text: str) -> list[str]:
    """Return a list of human-readable descriptions of secrets found in text."""
    found = []
    for pattern, label in _SECRET_PATTERNS:
        if re.search(pattern, text):
            if label not in found:
                found.append(label)
    return found


def contains_secrets(text: str) -> bool:
    return bool(find_secrets(text))
