"""HTTP client for the shypmate.dev API.

All communication with the server goes through this module.
Mates use this to read/write memory, fetch playbooks and personas.
The CLI uses this for auth, team management, and project operations.
"""

from typing import Optional

import httpx

from shypmate.config import get_api_key, get_api_url, get_project_id
from shypmate.security import find_secrets


class ShypmateAPIError(Exception):
    """Raised when the API returns an error."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API error {status_code}: {message}")


class ShypmateClient:
    """Client for the shypmate.dev API."""

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        self.api_key = api_key or get_api_key()
        self.base_url = (base_url or get_api_url()).rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._headers(),
            timeout=30.0,
        )

    def _headers(self) -> dict:
        from shypmate.session import get_machine_id
        from shypmate.config import get_project_config
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        h["X-Machine-Id"] = get_machine_id()
        project_id = get_project_id()
        if project_id:
            h["X-Project-Id"] = project_id
        project_name = get_project_config().get("project_name", "")
        if project_name:
            h["X-Project-Name"] = project_name
        return h

    def _request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise ShypmateAPIError(resp.status_code, detail)
        return resp.json() if resp.content else {}

    # ── Auth ────────────────────────────────────────────────────

    def verify_token(self) -> dict:
        """Verify the current API key is valid."""
        return self._request("GET", "/auth/verify")

    # ── Mates ────────────────────────────────────────────────────

    def list_mates(self) -> list[dict]:
        """List all mates for the authenticated user."""
        return self._request("GET", "/mates/")

    def get_mate(self, name: str) -> dict:
        """Get a single mate by name."""
        return self._request("GET", f"/mates/{name}")

    def create_mate(self, data: dict) -> dict:
        """Create a new mate."""
        return self._request("POST", "/mates/", json=data)

    def update_mate(self, name: str, data: dict) -> dict:
        """Update a mate's persona."""
        return self._request("PATCH", f"/mates/{name}", json=data)

    def delete_mate(self, name: str, archive: bool = True) -> dict:
        """Delete or archive a mate."""
        return self._request("DELETE", f"/mates/{name}", params={"archive": archive})

    def get_mate_skill(self, name: str) -> str:
        """Get the SKILL.md content for a mate (field on the mate object)."""
        mate = self.get_mate(name)
        return mate.get("skill_md", "")

    # ── Memory ──────────────────────────────────────────────────

    def get_memory(
        self, mate_name: str, scope: str = "global", project_id: Optional[str] = None
    ) -> str:
        """Read a mate's memory. scope = 'global' or 'project'."""
        params = {"scope": scope}
        if project_id:
            params["project_id"] = project_id
        resp = self._client.get(f"/mates/{mate_name}/memory", params=params)
        if resp.status_code >= 400:
            raise ShypmateAPIError(resp.status_code, resp.text)
        return resp.text

    def append_memory(
        self,
        mate_name: str,
        content: str,
        scope: str = "global",
        project_id: Optional[str] = None,
    ) -> dict:
        """Append to a mate's memory. Requires X-Mate-Name to match."""
        data = {"content": content, "scope": scope}
        if project_id:
            data["project_id"] = project_id
        return self._request(
            "POST",
            f"/mates/{mate_name}/memory",
            json=data,
            headers={"X-Mate-Name": mate_name},
        )

    def list_memory(self, project_id: Optional[str] = None) -> list[dict]:
        """List all memory entries, optionally filtered by project."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        return self._request("GET", "/memory/", params=params)

    # ── Projects ────────────────────────────────────────────────

    def list_projects(self) -> list[dict]:
        """List all projects for the authenticated user."""
        return self._request("GET", "/projects/")

    def find_project(self, name_or_id: str) -> dict | None:
        """Find a project by name (case-insensitive) or UUID. Returns None if not found."""
        # Try UUID lookup first
        import re
        if re.match(r"^[0-9a-f-]{36}$", name_or_id.lower()):
            try:
                return self.get_project(name_or_id)
            except ShypmateAPIError as e:
                if e.status_code != 404:
                    raise
        # Fall back to name search
        projects = self.list_projects()
        needle = name_or_id.lower()
        for p in projects:
            if p.get("name", "").lower() == needle:
                return p
        return None

    def create_project(self, data: dict) -> dict:
        """Register a new project."""
        return self._request("POST", "/projects/", json=data)

    def get_project(self, project_id: str) -> dict:
        """Get project details."""
        return self._request("GET", f"/projects/{project_id}/")

    def get_project_context(self, project_id: str) -> str:
        """Fetch the project context document as plain text."""
        resp = self._client.get(f"/projects/{project_id}/context")
        if resp.status_code >= 400:
            raise ShypmateAPIError(resp.status_code, resp.text)
        return resp.text

    def update_project_context(self, project_id: str, context: str) -> dict:
        """Replace the project context document (full rewrite)."""
        return self._request(
            "PATCH", f"/projects/{project_id}/context", json={"context": context}
        )

    def append_project_context(self, project_id: str, content: str) -> str:
        """Append a timestamped section to the project context. Returns full updated context."""
        resp = self._client.post(
            f"/projects/{project_id}/context",
            json={"content": content},
        )
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise ShypmateAPIError(resp.status_code, detail)
        return resp.text

    def update_project_stack(self, project_id: str, technologies: list[str]) -> dict:
        """Merge technologies into the project stack. Returns {stack, added}."""
        return self._request(
            "POST", f"/projects/{project_id}/stack", json={"technologies": technologies}
        )

    def remove_project_stack_tech(self, project_id: str, tech: str) -> dict:
        """Remove a technology from the project stack. Returns {stack}."""
        from urllib.parse import quote
        return self._request("DELETE", f"/projects/{project_id}/stack/{quote(tech)}")

    # ── Playbook ────────────────────────────────────────────────

    def get_playbook(self) -> str:
        """Fetch the shared playbook."""
        resp = self._client.get("/playbook/")
        if resp.status_code >= 400:
            raise ShypmateAPIError(resp.status_code, resp.text)
        return resp.text

    def update_playbook(self, content: str) -> dict:
        """Update the shared playbook."""
        return self._request("PUT", "/playbook/", json={"content": content})

    # ── Team Generation ─────────────────────────────────────────

    def generate_mate_persona(self, name: str, role: str | None = None) -> dict:
        """Generate or regenerate an LLM persona for an existing mate."""
        data = {}
        if role:
            data["role"] = role
        return self._request("POST", f"/mates/{name}/generate", json=data)

    def copy_mate(self, source: str, new_name: str) -> dict:
        """Copy a mate's role and skill to a new name."""
        return self._request("POST", f"/mates/{source}/copy", json={"name": new_name})

    def generate_mate(self, role_description: str, project_id: Optional[str] = None) -> dict:
        """Ask the server to generate a mate persona for a given role."""
        data = {"role": role_description}
        if project_id:
            data["project_id"] = project_id
        return self._request("POST", "/mates/generate", json=data)

    # ── Sessions ────────────────────────────────────────────────

    def register_session(self, machine_id: str, project_id: str, mate_names: list[str] | None = None) -> dict:
        """Register an active session (called on shypmate up)."""
        payload = {"machine_id": machine_id, "project_id": project_id}
        if mate_names:
            payload["mate_names"] = mate_names
        return self._request("POST", "/sessions/", json=payload)

    def deregister_session(self, machine_id: str) -> None:
        """Deregister a session (called on shypmate down). Idempotent."""
        try:
            self._request("DELETE", f"/sessions/{machine_id}/")
        except ShypmateAPIError as e:
            if e.status_code != 404:
                raise

    def connect_mate(self, machine_id: str, mate_name: str) -> dict:
        """Mark a mate as active within a session."""
        return self._request("POST", f"/sessions/{machine_id}/mates/{mate_name}")

    def disconnect_mate(self, machine_id: str, mate_name: str) -> None:
        """Mark a mate as inactive within a session. Idempotent."""
        try:
            self._request("DELETE", f"/sessions/{machine_id}/mates/{mate_name}")
        except ShypmateAPIError as e:
            if e.status_code != 404:
                raise

    def list_sessions(self, project_id: str) -> list[dict]:
        """List active sessions for a project (Team tier)."""
        return self._request("GET", "/sessions/", params={"project_id": project_id})

    def check_for_updates(self, since: Optional[str] = None) -> dict:
        """Poll for changes since a given ISO timestamp.

        Returns: { "has_updates": bool, "stale_mates": [...], "playbook_updated": bool }
        """
        params = {}
        if since:
            params["since"] = since
        return self._request("GET", "/sync/status", params=params)

    # ── Handoffs ────────────────────────────────────────────────

    def create_handoff(
        self,
        project_id: str,
        from_mate: str,
        to_mate: str,
        message: str,
        reply_to_id: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> dict:
        """Create a handoff message from one mate to another.

        reply_to_id: UUID of the handoff this is a direct reply/ack to.
        parent_id: UUID of the originating handoff in a cascade chain.
        """
        secrets = find_secrets(message)
        if secrets:
            kinds = ", ".join(secrets)
            raise ShypmateAPIError(400, f"Handoff blocked — possible {kinds} detected. Remove any credentials before sending.")
        body: dict = {
            "project_id": project_id,
            "from_mate": from_mate,
            "to_mate": to_mate,
            "message": message,
        }
        if reply_to_id:
            body["reply_to_id"] = reply_to_id
        if parent_id:
            body["parent_id"] = parent_id
        return self._request("POST", "/handoffs/", json=body)

    def get_handoffs(self, project_id: str, to_mate: str, unread_only: bool = True) -> list[dict]:
        """List handoffs for a mate in a project. Defaults to unread only."""
        params: dict = {"project_id": project_id, "to_mate": to_mate}
        if unread_only:
            params["unread"] = "1"
        return self._request("GET", "/handoffs/", params=params)

    def mark_handoff_read(self, handoff_id: str) -> None:
        """Mark a handoff as read."""
        try:
            self._request("PATCH", f"/handoffs/{handoff_id}/read")
        except ShypmateAPIError as e:
            if e.status_code != 404:
                raise
