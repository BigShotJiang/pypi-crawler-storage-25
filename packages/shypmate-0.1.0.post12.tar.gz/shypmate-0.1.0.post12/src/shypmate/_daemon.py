"""Background poll daemon.

Spawned as a detached subprocess by `shypmate up`. Polls the server every
30 seconds and writes ~/.shypmate/session-status.json when updates are found.

Not intended to be invoked directly — use `shypmate up`.
"""

import os
import signal
import sys
import time
from datetime import datetime, timezone


POLL_INTERVAL = 30  # seconds


def run(project_id: str) -> None:
    from shypmate.api import ShypmateClient, ShypmateAPIError
    from shypmate.session import (
        clear_pid, get_last_sync, get_session_status,
        write_pid, write_session_status,
    )

    write_pid(os.getpid())

    def _shutdown(signum, frame):
        clear_pid()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)

    client = ShypmateClient()

    while True:
        try:
            last_sync = get_last_sync()
            since = last_sync.isoformat() if last_sync else None
            updates = client.check_for_updates(since=since)

            if updates.get("has_updates"):
                status = get_session_status() or {}
                stale_mates = list(status.get("stale_mates", []))

                for mate in updates.get("stale_mates", []):
                    if mate not in stale_mates:
                        stale_mates.append(mate)

                write_session_status({
                    "stale_mates": stale_mates,
                    "playbook_updated": updates.get("playbook_updated", False),
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                })

        except ShypmateAPIError as e:
            if e.status_code in (401, 403):
                clear_pid()
                sys.exit(0)
        except Exception:
            pass  # Network blip — try again next interval

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    project_id = sys.argv[1] if len(sys.argv) > 1 else ""
    run(project_id)
