"""Claude Code skill installation and management.

Handles syncing mate personas from shypmate.dev to:
- ~/.claude/skills/<name>/SKILL.md  — global, enables Claude Code slash commands
- .shypmate/mates/<name>/SKILL.md   — project record, safe to commit
"""

import shutil
from pathlib import Path
from typing import Optional

from shypmate.api import ShypmateClient
from shypmate.config import get_api_url


CLAUDE_SKILLS_DIR = Path.home() / ".claude" / "skills"
PROJECT_MATES_DIR = Path(".shypmate") / "mates"
SESSION_INSTRUCTIONS_FILE = Path(".shypmate") / "session-instructions.md"


# Minimal footer — all live instructions are in session-instructions.md
_REFRESH_FOOTER = """
## Refresh / Sync

When the user says anything like "refresh", "reload", "sync up", "synchronize",
"who's on the team", or "update your context" — read `.shypmate/session-instructions.md`
and confirm the current state to the user.
"""


def write_session_instructions(project_id: str, api_url: str, mates: list[str], machine_id: str = "") -> Path:
    """Write .shypmate/session-instructions.md with live values filled in.

    Called on `shypmate up` and `shypmate sync`. Mates read this file at runtime
    so instructions stay current without needing to regenerate skill files.
    """
    if not Path(".shypmate").exists():
        return SESSION_INSTRUCTIONS_FILE

    team = ", ".join(f"/{m}" for m in mates) if mates else "none yet"
    machine_id_section = """
## Connect / Disconnect

At session start, register yourself as active (do this silently):
```bash
shypmate mate activate YOUR_MATE_NAME --quiet
```

If this command exits with an error (any line beginning with `SHYPMATE ERROR:`), stop
immediately. Do not proceed with any work. Tell the user exactly what the error says,
and that this session must be started via `shypmate` commands rather than opening the
slash command directly. Then stop responding.

The Stop hook handles disconnect automatically via `shypmate mate deactivate`.
""" if machine_id else ""

    content = f"""# shypmate Session Instructions

_Updated by `shypmate up` / `shypmate sync`. Read this file when asked to refresh or sync._

## Your Team

{team}

Full roster and project details: `.shypmate/config.json`
{machine_id_section}
## Handoffs

Use handoffs to leave messages for teammates. They will read them on their next session.

**At session start**, check for pending handoffs delivered during activation:

```bash
shypmate handoff pending
```

This prints any unread handoffs and clears the file in one step. If there are none, it
outputs nothing.

**During the session** (on refresh, or when asked about pending tasks, messages, or
work from a teammate — e.g. "any tasks from Terry?", "anything waiting?"), always
re-fetch from the server. Never answer from context that may be stale:

```bash
shypmate handoff list --mate YOUR_MATE_NAME
```

Do all of this silently with no announcement. Only mention it if there are unread
messages. If there are, say something natural like "Got a handoff from Terry: ..." —
do not narrate the command or say "checking handoffs" or "no handoffs waiting".

**When writing a handoff that needs a response**, make it explicit — end with
"Please reply when done." or "Send the result back to me." or ask a direct question.
Do not leave it ambiguous. If the receiver can't tell whether a reply is expected,
they may not send one.

**When a handoff asks you to do something and reply back — just do it.** A reply is
expected if the message contains a direct question, asks you to send/return a result,
or explicitly says to reply. Complete the task, send the reply with `--reply-to`,
mark it read. Do not ask the user for permission or confirmation — the instruction
came from a teammate. The user is not the audience for teammate handoffs.

**Send a handoff** (when asked to message a teammate):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to TARGET_MATE --message "your message here"
```

**Reply to a handoff** (acknowledge completion back to the sender):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to ORIGINAL_SENDER --message "done — here is what I did..." --reply-to ORIGINAL_HANDOFF_ID
```

**Cascade a handoff** (delegate downstream as part of a chain):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to DOWNSTREAM_MATE --message "your task here" --parent ORIGINATING_HANDOFF_ID
```

Use `--reply-to` when sending a reply/ack back to whoever sent you a handoff. Use `--parent` when forwarding work downstream so the full chain stays linked. You can include both when replying to a cascade.

**Mark a handoff as read** (after reading):
```bash
shypmate handoff read HANDOFF_ID
```

> Never include API keys, passwords, tokens, or any credentials in a handoff message.
> The server will reject it, and so will the CLI.

## Project Context

When you notice new technologies, dependencies, or architectural changes, record them.

**Append a note** (server timestamps and concatenates — safe to call anytime):
```bash
shypmate push-context --append "describe what changed here"
```

**Add technologies to the stack**:
```bash
shypmate stack-add Redis BullMQ
```

**Remove a technology from the stack**:
```bash
shypmate stack-remove TechName
```
"""

    SESSION_INSTRUCTIONS_FILE.write_text(content)
    return SESSION_INSTRUCTIONS_FILE


def install_mate_skill(mate_name: str, skill_content: str) -> Path:
    """Install a SKILL.md for a mate — globally and project-locally if initialized."""
    content = skill_content.rstrip() + "\n" + _REFRESH_FOOTER

    # Global: enables /name slash commands in Claude Code
    global_dir = CLAUDE_SKILLS_DIR / mate_name
    global_dir.mkdir(parents=True, exist_ok=True)
    global_file = global_dir / "SKILL.md"
    global_file.write_text(content)

    # Project-local: project record, written only if .shypmate/ exists
    if Path(".shypmate").exists():
        local_dir = PROJECT_MATES_DIR / mate_name
        local_dir.mkdir(parents=True, exist_ok=True)
        (local_dir / "SKILL.md").write_text(content)

    return global_file


def install_base_skill(api_url: Optional[str] = None) -> Path:
    """Install the _base skill that loads the shared playbook."""
    base_dir = CLAUDE_SKILLS_DIR / "_base"
    base_dir.mkdir(parents=True, exist_ok=True)

    url = api_url or get_api_url()

    content = f"""---
name: _base
description: >
  Shared team playbook loader for shypmate. Auto-applied to all sessions where
  a mate skill is active. Fetches the team playbook from shypmate.dev on session start.
autoApply: true
---

# Shared Team Playbook

You are a shypmate mate. Before starting any work:

1. Fetch and follow the shared playbook:
```bash
shypmate playbook
```

2. The playbook defines how ALL mates work: communication standards,
   code quality rules, memory protocol, handoff format, and error handling.

3. Your persona SKILL.md defines WHO you are. The playbook defines HOW you work.

## Session Instructions

Read `.shypmate/session-instructions.md` for your current team roster, handoff
commands, and any other live context. Re-read it whenever asked to refresh or sync.

## Memory Protocol

To save a learning at session end:

**Global** (applies everywhere):
```bash
shypmate memory save YOURMATENAME "your learning here" --scope global
```

**Project-specific**:
```bash
shypmate memory save YOURMATENAME "your learning here" --scope project
```

Replace YOURMATENAME with your mate name.

## Project Context — Keep It Current

You are responsible for keeping the project's context and stack accurate over time.

**At session start**, glance at `.shypmate/project-context.md` and the project's
manifest files (package.json, pyproject.toml, Dockerfile, etc.). If you notice
anything significant that's missing or has changed — a new library, a new service,
a removed dependency — update the server silently as part of your startup routine.

**During work**, if you add, remove, or discover a technology, update it immediately
— don't wait until session end. Use the commands in `.shypmate/session-instructions.md`.

What counts as worth recording:
- New frameworks, databases, queues, caches, or infrastructure
- Removed or replaced dependencies
- New services (APIs, third-party integrations)
- Significant architectural decisions

What to skip: minor version bumps, dev tooling changes, test libraries.
"""

    skill_file = base_dir / "SKILL.md"
    skill_file.write_text(content)

    return skill_file


def remove_mate_skill(mate_name: str) -> bool:
    """Remove a mate's skill from both global and project-local locations."""
    removed = False
    global_dir = CLAUDE_SKILLS_DIR / mate_name
    if global_dir.exists():
        shutil.rmtree(global_dir)
        removed = True
    local_dir = PROJECT_MATES_DIR / mate_name
    if local_dir.exists():
        shutil.rmtree(local_dir)
        removed = True
    return removed


def list_installed_skills() -> list[str]:
    """List all installed mate skill names."""
    if not CLAUDE_SKILLS_DIR.exists():
        return []
    return [
        d.name
        for d in sorted(CLAUDE_SKILLS_DIR.iterdir())
        if d.is_dir()
        and d.name not in ("_base", "_archived", "team-generator")
        and (d / "SKILL.md").exists()
    ]


def sync_all_mates(client: ShypmateClient) -> list[str]:
    """Sync all mates from shypmate.dev to local skills."""
    mates = client.list_mates()
    installed = []

    for mate in mates:
        name = mate["name"]
        skill_content = mate.get("skill_md") or client.get_mate_skill(name)
        if skill_content:
            install_mate_skill(name, skill_content)
            installed.append(name)

    install_base_skill(client.base_url)

    return installed
