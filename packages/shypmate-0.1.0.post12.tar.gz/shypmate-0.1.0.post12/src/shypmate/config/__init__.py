"""Configuration management for shypmate.

Two config scopes:
- User config: ~/.shypmate/config.json (API key, auth — never committed)
- Project config: .shypmate/config.json (project link — safe to commit)
"""

import json
import os
from pathlib import Path
from typing import Optional


USER_CONFIG_DIR = Path.home() / ".shypmate"
USER_CONFIG_FILE = USER_CONFIG_DIR / "config.json"
CURL_AUTH_FILE = USER_CONFIG_DIR / "curl-auth"

PROJECT_CONFIG_DIR = Path(".shypmate")
PROJECT_CONFIG_FILE = PROJECT_CONFIG_DIR / "config.json"

DEFAULT_API_URL = "https://api.shypmate.dev/v1"


def get_user_config() -> dict:
    """Load user-level config (~/.shypmate/config.json)."""
    if USER_CONFIG_FILE.exists():
        return json.loads(USER_CONFIG_FILE.read_text())
    return {}


def save_user_config(config: dict) -> None:
    """Save user-level config."""
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    USER_CONFIG_FILE.write_text(json.dumps(config, indent=2))
    # Restrict permissions — contains API key
    USER_CONFIG_FILE.chmod(0o600)
    if config.get("api_key"):
        write_curl_auth_config(config["api_key"])


def write_curl_auth_config(api_key: str) -> None:
    """Write ~/.shypmate/curl-auth for use with curl -K.

    Lets mates call curl without $() command substitution, avoiding
    Claude Code's command substitution safety prompt.
    """
    USER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [f'header = "Authorization: Bearer {api_key}"']
    machine_id_file = USER_CONFIG_DIR / "machine-id"
    if machine_id_file.exists():
        machine_id = machine_id_file.read_text().strip()
        if machine_id:
            lines.append(f'header = "X-Machine-Id: {machine_id}"')
    CURL_AUTH_FILE.write_text("\n".join(lines) + "\n")
    CURL_AUTH_FILE.chmod(0o600)


def get_api_key() -> Optional[str]:
    """Get the API key — env var takes precedence over user config."""
    return os.environ.get("SHYPMATE_API_KEY") or get_user_config().get("api_key")


def get_api_url() -> str:
    """Get the API endpoint URL — env var takes precedence over user config."""
    return (
        os.environ.get("SHYPMATE_API_URL")
        or get_user_config().get("api_url")
        or DEFAULT_API_URL
    )


def get_project_config() -> dict:
    """Load project-level config (.shypmate/config.json)."""
    if PROJECT_CONFIG_FILE.exists():
        return json.loads(PROJECT_CONFIG_FILE.read_text())
    return {}


def save_project_config(config: dict) -> None:
    """Save project-level config."""
    PROJECT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PROJECT_CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_project_id() -> Optional[str]:
    """Get the project ID from project config."""
    return get_project_config().get("project_id")


def is_authenticated() -> bool:
    """Check if the user has a valid API key."""
    return get_api_key() is not None


def is_initialized() -> bool:
    """Check if the current directory has a shypmate project."""
    return PROJECT_CONFIG_FILE.exists()
