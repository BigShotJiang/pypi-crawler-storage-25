# shypmate Session Instructions

_Updated by `shypmate up` / `shypmate sync`. Read this file when asked to refresh or sync._

## Your Team

/terry, /nina

Full roster and project details: `.shypmate/config.json`

## Connect / Disconnect

At session start, register yourself as active (do this silently):
```bash
shypmate mate activate YOUR_MATE_NAME --quiet
```

The Stop hook handles disconnect automatically via `shypmate mate deactivate`.

## Handoffs

Use handoffs to leave messages for teammates. They will read them on their next session.

**At session start**, check for pending handoffs delivered during activation:

```bash
shypmate handoff pending
```

This prints any unread handoffs and clears the file in one step. If there are none, it
outputs nothing.

**During the session** (on refresh, or when asked about pending tasks, messages, or
work from a teammate — e.g. "any tasks from Terry?", "anything waiting?"), always
re-fetch from the server. Never answer from context that may be stale:

```bash
shypmate handoff list --mate YOUR_MATE_NAME
```

Do all of this silently with no announcement. Only mention it if there are unread
messages. If there are, say something natural like "Got a handoff from Terry: ..." —
do not narrate the command or say "checking handoffs" or "no handoffs waiting".

**When writing a handoff that needs a response**, make it explicit — end with
"Please reply when done." or "Send the result back to me." or ask a direct question.
Do not leave it ambiguous. If the receiver can't tell whether a reply is expected,
they may not send one.

**When a handoff asks you to do something and reply back — just do it.** A reply is
expected if the message contains a direct question, asks you to send/return a result,
or explicitly says to reply. Complete the task, send the reply with `--reply-to`,
mark it read. Do not ask the user for permission or confirmation — the instruction
came from a teammate. The user is not the audience for teammate handoffs.

**Send a handoff** (when asked to message a teammate):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to TARGET_MATE --message "your message here"
```

**Reply to a handoff** (acknowledge completion back to the sender):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to ORIGINAL_SENDER --message "done — here is what I did..." --reply-to ORIGINAL_HANDOFF_ID
```

**Cascade a handoff** (delegate downstream as part of a chain):
```bash
shypmate handoff send --from YOUR_MATE_NAME --to DOWNSTREAM_MATE --message "your task here" --parent ORIGINATING_HANDOFF_ID
```

Use `--reply-to` when sending a reply/ack back to whoever sent you a handoff. Use `--parent` when forwarding work downstream so the full chain stays linked. You can include both when replying to a cascade.

**Mark a handoff as read** (after reading):
```bash
shypmate handoff read HANDOFF_ID
```

> Never include API keys, passwords, tokens, or any credentials in a handoff message.
> The server will reject it, and so will the CLI.

## Project Context

When you notice new technologies, dependencies, or architectural changes, record them.

**Append a note** (server timestamps and concatenates — safe to call anytime):
```bash
shypmate push-context --append "describe what changed here"
```

**Add technologies to the stack**:
```bash
shypmate stack-add Redis BullMQ
```

**Remove a technology from the stack**:
```bash
shypmate stack-remove TechName
```
