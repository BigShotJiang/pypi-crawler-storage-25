# shypmate

Build, manage, and deploy AI agent teams across your projects.

Create named AI personas with distinct skills and personalities, deploy them as Claude Code slash commands, and let them accumulate memory across sessions. Manage everything through a CLI or the [shypmate.dev](https://shypmate.dev) dashboard.

## Quick start

```bash
pip install shypmate
shypmate auth login
cd ~/projects/my-app
shypmate init
claude /terry "Implement the login screen"
```

## Commands

```bash
# Auth
shypmate auth login              # Authenticate with shypmate.dev
shypmate auth status             # Check auth status
shypmate auth logout             # Remove credentials

# Project setup
shypmate init                    # Initialize shypmate in current project
shypmate sync                    # Sync agents and playbook from shypmate.dev

# Team management
shypmate hire "qa"               # Hire by role shortcut
shypmate hire "senior backend engineer with postgres expertise"
shypmate fire terry --archive    # Archive an agent (reversible)
shypmate rehire terry            # Reinstate an archived agent
shypmate roster                  # Detailed team roster
shypmate team list               # Quick agent list

# Memory
shypmate memory list             # List all memory entries
shypmate memory show terry       # Show an agent's memory
shypmate memory search "drizzle" # Search across all memory
```

## Role shortcuts

| Shortcut | Role |
|----------|------|
| `qa` | Senior QA Engineer |
| `frontend` | Senior Frontend Engineer |
| `backend` | Senior Backend Engineer |
| `devops` | Senior DevOps Engineer |
| `security` | Security Engineer |
| `mobile` | Senior Mobile Engineer |
| `data` | Data Engineer |
| `writer` | Technical Writer |
| `architect` | Solutions Architect |
| `designer` | UI/UX Designer |
| `fullstack` | Senior Full-Stack Engineer |
| `lead` | Technical Lead |

## How it works

1. **shypmate.dev** stores your agent personas, shared playbook, and memory centrally
2. **`shypmate init`** syncs agents to your local `~/.claude/skills/` as Claude Code slash commands
3. **Agents read/write memory** via the shypmate API on session start/end
4. **The playbook** defines shared behavior for all agents — update it once, all agents get the update

## What goes where

| Location | Contains | Committed? |
|----------|----------|-----------|
| `~/.shypmate/config.json` | API key | Never |
| `~/.claude/skills/{name}/` | Agent SKILL.md files | No (auto-synced) |
| `.shypmate/config.json` | Project ID, agent list | Yes |
| `.shypmate/project-context.md` | Stack and architecture notes | Yes |
| shypmate.dev | Personas, playbook, memory | Cloud |

## Links

- Dashboard: [shypmate.dev](https://shypmate.dev)
- Docs: [docs.shypmate.dev](https://docs.shypmate.dev)
- GitHub: [github.com/paulr978/shypmate](https://github.com/paulr978/shypmate)
