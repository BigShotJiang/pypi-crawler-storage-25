# common-fractals

This package includes classes for drawing common fractals in pgzero and pygame.

---

## Usage

This package has 5 fractals implemented:

- Koch Snowflake (KochSnowflake)
- Koch Anti-Snowflake (KochAntiSnowflake)
- Mandelbrot Set (MandelbrotSet)
- Newton Fractal (NewtonFractal)
- Sierpinski Triangle (SierpinskiTriangle)
- Julia Sets (JuliaSet)

This package also includes a base Fractal class which is the super class for all of the fractals mentioned above. The Fractal class does not change the effects or add methods to the sub classes.

### Koch Snowflake

An example of drawing the Koch Snowflake in a pgzero and pygame game is shown below (this example includes all of the parameters available in the KochSnowflake class):

```python
from common_fractals import KochSnowflake # Imports KochSnowflake necessary for creating the Snowflake

koch_snowflake = KochSnowflake(iterations = 20, side_length = 200, topleft = (100, 100)) # Creates the Snowflake. You should not call this in your draw function because that would decrease speed significantly

... # Your code here

    koch_snowflake.draw_pgzero(screen, color = "green") # Draws the Snowflake. The screen parameter should be the screen you use to draw on the window

```

All of them have the same parameters. For pygame, the screen parameter is the surface of which you want to draw the Snowflake onto.

### Koch Anti-Snowflake

An example of drawing the Koch Anti-Snowflake in a pgzero and pygame game is shown below (this example includes all of the parameters available in the KochAntiSnowflake class):

```python
from common_fractals import KochAntiSnowflake # Imports KochAntiSnowflake necessary for creating the Anti-Snowflake

koch_anti_snowflake = KochAntiSnowflake(iterations = 20, side_length = 200, topleft = (100, 100)) # Creates the Anti-Snowflake. You should not call this in your while loop because that would decrease speed significantly

... # Your code here

    koch_anti_snowflake.draw_pygame(display_screen, color = "green") # Draws the Snowflake. For pygame, the surface parameter should be the display_screen or a different Surface. For pgzero, the screen parameter should be the screen you use to draw on the window
```

koch_anti_snowflake has the same methods as the KochSnowflake.

### Mandelbrot Set

An example of drawing the Mandelbrot Set in a pgzero and pygame game is shown in the two examples below (this example includes all of the parameters available in the MandelbrotSet class):

```python
from common_fractals import MandelbrotSet # Imports MandelbrotSet necessary for creating the Mandelbrot Set

mandelbrot_set = MandelbrotSet(iterations = 1000, scale = 50, width = 600, height = 600, topleft = (100, 100)) # Creates the Mandelbrot Set. You should not call this in your while loop because that would decrease speed significantly

... # Your code here

    mandelbrot_set.draw_pgzero(screen, color = "green") # Draws the Mandelbrot Set. For pygame, the surface parameter should be the display_screen or a different Surface. For pgzero, the screen parameter should be the screen you use to draw on the window
```

mandelbrot_set has the same methods as the KochSnowflake and KochAntiSnowflake.

### Newton Fractal

An example of drawing the Newton Fractal in a pgzero and pygame game is shown in the two examples below (this example includes all of the parameters available in the NewtonFractal class):

```python
from common_fractals import NewtonFractal # Imports NewtonFractal necessary for creating the Newton Fractal

newton_fractal = NewtonFractal(iterations = 50, width = 600, height = 600, scale = 75, animate = True, show_roots = True, point_scale = 1 / 2,
                 root_scale: float = 1, func = lambda x: x ** 3 + 2 * (x ** 2) + 10, colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255)], print_current_iter = True) # Creates the Newton Fractal. You should not call this in your draw function because that would decrease speed significantly. The length of the colors must be equal to or greater than the degree measure (the highest power in func. In this case, it is 3)

... # Your code here

    newton_fractal.draw_pygame(display_screen, color = "green") # Draws the Newton Fractal. For pygame, the surface parameter should be the display_screen or a different Surface. For pgzero, the screen parameter should be the screen you use to draw on the window
```

newton_fractal has the same methods as the KochSnowflake, KochAntiSnowflake, and MandelbrotSet.

---

## Versions

Version 0.0.1: Base Code added.
**(Latest) Version 0.0.2:** Julia Sets added

### Coming Soon

Version 0.0.3: C Code for the Julia Sets added.
Version 0.0.4: C code for Koch Snowflake (KochSnowflake) added.
