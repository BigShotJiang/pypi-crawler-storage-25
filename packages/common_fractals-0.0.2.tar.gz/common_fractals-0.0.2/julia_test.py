from src.common_fractals.julia_sets import JuliaSet
import pgzrun
import numpy
import time

WIDTH = 800
HEIGHT = 800

jsets = [JuliaSet(c=complex(0, c)) for c in numpy.arange(0, 10, 0.1)]

index = 0

def draw():
    global index
    screen.fill("white")
    jsets[index].draw_pgzero(screen)

def update():
    global index
    index += 1
    if index == len(jsets):
        index = 0

    time.sleep(0.5)

pgzrun.go()