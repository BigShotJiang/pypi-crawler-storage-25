from .utilities import *

def _koch_subdivide(p1: tuple[int, int], p2: tuple[int, int]) -> list[tuple[int, int]]:
    x1, y1 = p1
    x2, y2 = p2

    dx = (x2 - x1) / 3
    dy = (y2 - y1) / 3

    pA = (x1 + dx, y1 + dy)
    pB = (x1 + 2*dx, y1 + 2*dy)

    angle = math.radians(60)
    px = pA[0] + (dx * math.cos(angle) - dy * math.sin(angle))
    py = pA[1] + (dx * math.sin(angle) + dy * math.cos(angle))
    pC = (px, py)

    return [p1, pA, pC, pB, p2]

def _koch_iterate(points: list[tuple[int, int]]) -> list[tuple[int, int]]:
    new_points = []
    for i in range(len(points) - 1):
        seg = _koch_subdivide(points[i], points[i+1])
        new_points.extend(seg[:-1])
    new_points.append(points[-1])
    return new_points

def _generate_koch_flake(iterations: int, start_pos: tuple[int, int] = (0, 0), side_length: int = 300, anti: bool = False) -> list[tuple[int, int]]:
    if not anti:
        start_pos = (start_pos[0], start_pos[1] + 300 * math.sqrt(3) / 2)
    x, y = start_pos
    pos1 = (x, y)
    pos2 = (x + side_length, y)
    h = (math.sqrt(3) / 2) * side_length
    if anti:
        pos3 = (x + side_length / 2, y + h)
    else:
        pos3 = (x + side_length / 2, y - h)
    triangle_points = [pos1, pos2, pos3]

    points = triangle_points + [pos1]

    for i in range(iterations):
        points = _koch_iterate(points)

    return points

class KochSnowflake(Fractal):
    def __init__(self, iterations: int, side_length: int = 300, topleft: tuple[int, int] = (0, 0)) -> None:
        self.points = _generate_koch_flake(iterations, topleft, side_length, False)
        self._side_length = side_length
        self._iterations = iterations
        self._topleft = topleft

    def _update_points(self) -> None:
        self.points = _generate_koch_flake(self._iterations, self._topleft, self._side_length, False)

    def draw_pgzero(self, screen: PgzeroScreen, color: Union[str, tuple[int, int, int]] = "black", thickness: int = 1) -> None:
        """This method is incorrect and will be removed in future versions."""
        warnings.warn("This method is incorrect and will be removed in future versions.", DeprecationWarning)
        pygame.draw.polygon(screen.surface, color, self.points, thickness)

    def draw_pgzero_filled(self, screen: PgzeroScreen, color: Union[str, tuple[int, int, int]] = "black") -> None:
        """This method will be renamed to draw_pgzero in future versions."""
        print("This method will be renamed to draw_pgzero in future versions.")
        pygame.draw.polygon(screen.surface, color, self.points)

    def draw_pygame(self, surface: PygameSurface, color: Union[str, tuple[int, int, int]] = "black", thickness = 1) -> None:
        """This method is incorrect and will be removed in future versions."""
        warnings.warn("This method is incorrect and will be removed in future versions.", DeprecationWarning)
        pygame.draw.polygon(surface, color, self.points, thickness)

    def draw_pygame_filled(self, surface: PygameSurface, color: Union[str, tuple[int, int, int]] = "black") -> None:
        """This method will be renamed to draw_pygame in future versions."""
        print("This method will be renamed to draw_pygame in future versions.")
        pygame.draw.polygon(surface, color, self.points)

    @property
    def side_length(self) -> int:
        return self._side_length

    @property
    def iterations(self) -> int:
        return self._iterations

    @property
    def topleft(self) -> tuple[int, int]:
        return self._topleft

    @side_length.setter
    def side_length(self, value: int) -> None:
        self._side_length = value
        self._update_points()

    @iterations.setter
    def iterations(self, value: int) -> None:
        self._iterations = value
        self._update_points()

    @topleft.setter
    def topleft(self, value: tuple[int, int]) -> None:
        self._topleft = value
        self._update_points()

    @property
    def perimeter(self) -> float:
        return 3 * self.side_length * ((4 / 3) ** self.iterations)

    @property
    def area(self) -> float:
        a = (math.sqrt(3) / 4) * (self.side_length ** 2)
        return a * (1 + (3 / 5) * (1 - (4 / 9) ** self.iterations))

class KochAntiSnowflake(Fractal):
    def __init__(self, iterations: int, side_length: int = 300, topleft: tuple[int, int] = (0, 0)) -> None:
        self.points = _generate_koch_flake(iterations, topleft, side_length, True)
        self._side_length = side_length
        self._iterations = iterations
        self._topleft = topleft

    def _update_points(self) -> None:
        self.points = _generate_koch_flake(self._iterations, self._topleft, self._side_length, True)

    def draw_pgzero(self, screen: PgzeroScreen, color = "black", thickness = 1) -> None:
        pygame.draw.polygon(screen.surface, color, self.points, thickness)

    def draw_pgzero_filled(self, screen: PgzeroScreen, color = "black") -> None:
        pygame.draw.polygon(screen.surface, color, self.points)

    def draw_pygame(self, surface: PygameSurface, color = "black", thickness = 1) -> None:
        pygame.draw.polygon(surface, color, self.points, thickness)

    def draw_pygame_filled(self, surface: PygameSurface, color = "black") -> None:
        pygame.draw.polygon(surface, color, self.points)

    @property
    def side_length(self) -> int:
        return self._side_length

    @property
    def iterations(self) -> int:
        return self._iterations

    @property
    def topleft(self) -> tuple[int, int]:
        return self._topleft

    @side_length.setter
    def side_length(self, value: int) -> None:
        self._side_length = value
        self._update_points()

    @iterations.setter
    def iterations(self, value: int) -> None:
        self._iterations = value
        self._update_points()

    @topleft.setter
    def topleft(self, value: tuple[int, int]) -> None:
        self._topleft = value
        self._update_points()

    @property
    def perimeter(self) -> float:
        return 3 * self.side_length * ((4 / 3) ** self.iterations)

    @property
    def area(self) -> float:
        a = (math.sqrt(3) / 4) * (self.side_length ** 2)
        return a * (1 + (3 / 5) * (1 - (4 / 9) ** self.iterations))

