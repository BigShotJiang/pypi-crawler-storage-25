from .utilities import *

class JuliaSet(Fractal):
    def __init__(self, max_iter = 50, width = 800, height = 800, r = 2, c = 0):
        self._surf = pygame.Surface((width, height))
        pixels = pygame.PixelArray(self._surf)

        for x in range(width):
            for y in range(height):
                zx = 1.5 * (x - width / 2) / (0.5 * width)
                zy = 1.0 * (y - height / 2) / (0.5 * height)
                z = complex(zx, zy)

                iteration = 0
                while abs(z) < r and iteration < max_iter:
                    z = z**2 + c
                    iteration += 1

                if iteration == max_iter:
                    pixels[x][y] = (0, 0, 0)
                else:
                    color = int(iteration / max_iter * 255)
                    pixels[x][y] = (color, color, 255)

        pixels.close()

    def draw_pgzero(self, screen, pos = (0, 0)):
        screen.blit(self._surf, pos)

    def draw_pygame(self, surface: PygameSurface, pos = (0, 0)):
        surface.blit(self._surf, pos)
