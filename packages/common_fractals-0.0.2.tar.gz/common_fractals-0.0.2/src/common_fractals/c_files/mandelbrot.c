#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double x;
    double y;
} Tuple;

double* linspace(double start, double stop, int num) {
    double* arr = malloc(num * sizeof(double));
    if (!arr) exit(1);

    double step = (num > 1) ? (stop - start) / (num - 1) : 0.0;

    for (int i = 0; i < num; i++)
        arr[i] = start + step * i;

    return arr;
}

Tuple create_tuple(double x, double y) {
    Tuple t;
    t.x = x;
    t.y = y;
    return t;
}

Tuple* get_mandelbrot_points(int iterations, int width, int height, double zoom, double center_x, double center_y, int* out_count) {
    double half_width = 2.0 / zoom;
    double half_height = 1.5 / zoom;

    double* real_vals = linspace(center_x - half_width, center_x + half_width, width);
    double* imag_vals = linspace(center_y - half_height, center_y + half_height, height);

    int capacity = 16;
    Tuple* points = malloc(capacity * sizeof(Tuple));
    int count = 0;

    for (int r = 0; r < width; r++) {
        double a = real_vals[r];

        for (int im = 0; im < height; im++) {
            double b = imag_vals[im];

            double zr = 0;
            double zi = 0;
            bool inside = true;

            for (int i = 0; i < iterations; i++) {
                double zr2 = zr * zr;
                double zi2 = zi * zi;

                double new_zr = zr2 - zi2 + a;
                double new_zi = 2 * zr * zi + b;

                if (new_zr * new_zr + new_zi * new_zi > 4.0) {
                    inside = false;
                    break;
                }

                zr = new_zr;
                zi = new_zi;
            }

            if (inside) {
                if (count >= capacity) {
                    capacity *= 2;
                    points = realloc(points, capacity * sizeof(Tuple));
                }
                points[count] = create_tuple(a, b);
                count++;
            }
        }
    }

    free(real_vals);
    free(imag_vals);

    *out_count = count;
    return points;
}

void free_points(Tuple* p) {
    free(p);
}

#ifdef __cplusplus
}
#endif
