from ctypes import *
import os

class Tuple(Structure):
    _fields_ = [("x", c_double), ("y", c_double)]

_file = 'mandelbrot_lib.so'
_path = os.path.join(*(os.path.split(__file__)[:-1] + (_file,)))
_mod = cdll.LoadLibrary(_path)

_mod.get_mandelbrot_points.restype = POINTER(Tuple)
_mod.get_mandelbrot_points.argtypes = [c_int, c_int, c_int, c_double, c_double, c_double, POINTER(c_int)]

_mod.free_points.argtypes = [POINTER(Tuple)]
_mod.free_points.restype = None

def get_mandelbrot_points(iterations, width, height, zoom, cx, cy):
    count = c_int()
    ptr = _mod.get_mandelbrot_points(iterations, width, height, zoom, cx, cy, byref(count))
    n = count.value

    if not ptr or n <= 0:
        return []

    result = []
    for i in range(n):
        x = ptr[i].x
        y = ptr[i].y
        result.append(complex(x, y))

    _mod.free_points(ptr)
    return result
