from .utilities import *

def _sierpinski_subdivide(p1: tuple[int, int], p2: tuple[int, int], p3: tuple[int, int]):
    m12 = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
    m23 = ((p2[0] + p3[0]) / 2, (p2[1] + p3[1]) / 2)
    m31 = ((p3[0] + p1[0]) / 2, (p3[1] + p1[1]) / 2)
    return [
        (p1, m12, m31),
        (m12, p2, m23),
        (m31, m23, p3)
    ]

def _generate_sierpinski(iterations: int, topleft: tuple[int, int] = (0, 0), side: int = 300):
    x, y = topleft
    h = side * math.sqrt(3) / 2
    p1 = (x, y)
    p2 = (x + side, y)
    p3 = (x + side/2, y - h)

    triangles = [(p1, p2, p3)]

    for i in range(iterations):
        new = []
        for t in triangles:
            new.extend(_sierpinski_subdivide(*t))
        triangles = new

    return triangles

class SierpinskiTriangle(Fractal):
    def __init__(self, iterations: int = 4, side: int = 300, topleft: tuple[int, int] = (0, 0)):
        self._iterations = iterations
        self._side = side
        self._topleft = topleft
        self.triangles = _generate_sierpinski(iterations, topleft, side)

    def draw_pgzero(self, screen: PgzeroScreen, color: Union[str, tuple[int, int, int]] = "black"):
        for t in self.triangles:
            pygame.draw.polygon(screen.surface, color, t)

    def draw_pygame(self, surface, color = "white"):
        for t in self.triangles:
            pygame.draw.polygon(surface, color, t)