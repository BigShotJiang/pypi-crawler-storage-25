from .utilities import *

class MandelbrotSet(Fractal):
    def __init__(self, iterations=100, zoom=1.0,
                 zoom_center=(0.0, 0.0),
                 width=400, height=400,
                 topleft=(0, 0)):

        self._iterations = iterations
        self._zoom = zoom
        self.zoom_center = zoom_center
        self.width = width
        self.height = height
        self.topleft = topleft

        self.points = get_mandelbrot_points(
            iterations, width, height, zoom,
            zoom_center[0], zoom_center[1]
        )

    @property
    def zoom(self):
        return self._zoom

    @zoom.setter
    def zoom(self, value):
        self._zoom = value
        self._update_points()

    @property
    def iterations(self):
        return self._iterations

    @iterations.setter
    def iterations(self, value):
        self._iterations = max(1, int(value))
        self._update_points()

    def _update_points(self):
        self.points = get_mandelbrot_points(
            self._iterations,
            self.width,
            self.height,
            self._zoom,
            self.zoom_center[0],
            self.zoom_center[1]
        )

    def _draw(self, surface, color, thickness):
        half_width = 2.0 / self._zoom
        half_height = 1.5 / self._zoom

        min_real = self.zoom_center[0] - half_width
        max_real = self.zoom_center[0] + half_width
        min_imag = self.zoom_center[1] - half_height
        max_imag = self.zoom_center[1] + half_height

        scale_x = self.width / (max_real - min_real)
        scale_y = self.height / (max_imag - min_imag)

        for c in self.points:
            px = (c.real - min_real) * scale_x
            py = (c.imag - min_imag) * scale_y
            sx = int(px) + self.topleft[0]
            sy = int(py) + self.topleft[1]

            pygame.draw.rect(surface, color, Rect(sx, sy, 1, 1), thickness)

    def draw_pgzero(self, screen, color="black", thickness=1):
        """This method is incorrect and will be removed in future versions."""
        warnings.warn("This method is incorrect and will be removed in future versions.", DeprecationWarning)
        self._draw(screen.surface, color, thickness)

    def draw_pgzero_filed(self, screen, color="black"):
        """This method will be renamed to draw_pgzero in future versions."""
        print("This method will be renamed to draw_pgzero in future versions.")
        self._draw(screen.surface, color, 0)

    def draw_pygame(self, surface, color = "black"):
        self._draw(surface, color, 0)
