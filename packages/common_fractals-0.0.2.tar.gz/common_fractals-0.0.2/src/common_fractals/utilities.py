import warnings
import sympy as sp
import inspect
import pygame
import math
import numpy as np
from pygame.rect import Rect
import random
from pgzero.screen import Screen as PgzeroScreen
from pygame.surface import Surface as PygameSurface
from typing import Union, Callable, Optional
from .c_files.mandelbrot_loader import get_mandelbrot_points

def _get_expr(func):
    sig = inspect.signature(func)
    params = list(sig.parameters.keys())
    var_name = params[0]

    x = sp.symbols(var_name)
    return x, func(x)

def derivative(func):
    x, expr = _get_expr(func)

    if not isinstance(expr, sp.Expr):
        expr = sp.sympify(expr)

    derivative_expr = sp.diff(expr, x)

    return sp.lambdify(x, derivative_expr, 'math')

def find_roots(func):
    x, expr = _get_expr(func)

    roots_sym = sp.solve(sp.Eq(expr, 0), x)
    roots_complex = [complex(sp.N(r)) for r in roots_sym]

    return roots_complex

class Fractal:
    pass

