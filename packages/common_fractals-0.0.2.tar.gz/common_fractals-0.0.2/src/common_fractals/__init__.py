"""
# common-fractals

This package includes common fractals and methods to draw it on pgzero and pygame.
"""

from .koch_flake import *
from .sierpinski_tri import *
from .mandelbrot_set import *
from .newton_fractal import *