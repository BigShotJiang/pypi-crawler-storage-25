from .utilities import *

class NewtonFractal(Fractal):
    def __init__(self, iterations: int = 20, width: int = 400, height: int = 400, scale: int = 50, animate: bool = False, show_roots: bool = False, point_scale: float = 1/3,
                 root_scale: float = 1, func: Callable = lambda x: x ** 2 + x + 1, colors: Optional[list[Union[str, tuple[int, int, int]]]] = None, print_current_iter: bool = False) -> None:

        self.scale = scale
        self.animate = animate
        self._func = func
        self._deriv_func = derivative(func)
        self._roots = find_roots(func)
        if colors == None:
            colors = [(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for i in range(len(self._roots))]

        self._colors = colors
        self.print_current_iter = print_current_iter
        self._iter_passed = 0
        self.iterations = iterations

        points = []
        for x in range(-(width // 2 // scale), (width // 2 // scale) + 1):
            for y in range(-(height // 2 // scale), (height // 2 // scale + 1)):
                points.append([complex(x, y), 0, complex(x, y)])

        self._points = points
        self.width = width
        self.height = height
        self.show_roots = show_roots
        self.point_scale = point_scale
        self.root_scale = root_scale

    @property
    def func(self) -> Callable:
        return self._func

    @func.setter
    def func(self, value: Callable) -> None:
        self._func = value
        self._deriv_func = derivative(value)
        self._roots = find_roots(value)

    @property
    def colors(self) -> list[Union[str, tuple[int, int, int]]]:
        return self._colors

    @colors.setter
    def colors(self, value: Optional[list[Union[str, tuple[int, int, int]]]]) -> None:
        if value == None:
            value = [(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for i in range(len(self._roots))]

        self._colors = value

    @property
    def deriv_func(self) -> Callable:
        return self._deriv_func

    @property
    def roots(self) -> list[complex]:
        return self._roots

    @property
    def iter_passed(self) -> int:
        return self._iter_passed

    @property
    def points(self) -> list[complex, int, complex]:
        return self._points

    def _get_next_point(self, prev_z: complex) -> complex:
        denom = self._deriv_func(prev_z)
        if denom == 0:
            return prev_z

        return prev_z - self._func(prev_z) / self._deriv_func(prev_z)

    def _plot(self, z: complex, color: Union[str, tuple[int, int, int]], scale: float, screen: PygameSurface, thickness) -> None:
        pygame.draw.rect(screen, color, Rect(z.real * self.scale + self.width / 2 - self.scale * scale / 2, z.imag * self.scale + self.height / 2 - self.scale * scale / 2, self.scale, self.scale), thickness)

    def _get_closest_root(self, z: complex) -> float:
        distances = []
        for root in self.roots:
            re_diff = root.real - z.real
            imag_diff = root.imag - z.imag
            distances.append(math.sqrt(re_diff ** 2 + imag_diff ** 2))

        return distances.index(min(distances))

    def _draw(self, surface, thickness):
        if self.iter_passed <= self.iterations:
            if self.show_roots:
                for root in self.roots:
                    self._plot(root, "red", self.root_scale, surface, thickness)

            for point in self.points:
                if self.animate:
                    self._plot(point[0], "yellow", self.point_scale, surface, thickness)
                point[0] = self._get_next_point(point[0])

            if self.print_current_iter:
                print(self.iter_passed)

            self._iter_passed += 1
        else:
            for point in self.points:
                point[1] = self._get_closest_root(point[0])

            for point in self.points:
                self._plot(point[2], self.colors[point[1]], self.point_scale, surface, thickness)

    def draw_pgzero(self, screen: PgzeroScreen, thickness: int = 1) -> None:
        """This method is incorrect and will be removed in future versions."""
        warnings.warn("This method is incorrect and will be removed in future versions.", DeprecationWarning)
        self._draw(screen.surface, thickness)

    def draw_pgzero_filled(self, screen):
        """This method will be renamed to draw_pgzero in future versions."""
        print("This method will be renamed to draw_pgzero in future versions.")
        self.draw_pgzero(self, screen, 0)

    def draw_pygame(self, surface):
        self._draw(surface, 0)