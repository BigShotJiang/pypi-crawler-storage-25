from src.common_fractals import MandelbrotSet
import pgzrun

WIDTH = 800
HEIGHT = 800

SPEED = 1.05
center = (-0.743643887037151, 0.131825904205330)

mandelbrot = MandelbrotSet(zoom=1, width=WIDTH, height=HEIGHT, zoom_center=center)

def draw():
    screen.fill("white")
    mandelbrot.draw_pgzero_filed(screen)

def update():
    mandelbrot._zoom *= SPEED
    mandelbrot.iterations = int(50 + 10 * mandelbrot.zoom)

def on_mouse_down(pos, button):
    global SPEED
    if button == 1:
        SPEED += 0.01
    elif button == 3:
        SPEED -= 0.01

pgzrun.go()
