"""RangerClient — the protocol oak_config uses to talk to Ranger.

Three implementations:

  RangerClient (ABC)        — the contract.
  LocalRangerClient         — in-process: wraps ranger.SecretsStore +
                              ranger.ConfigStore directly. Used for
                              tests AND for Ranger's own startup (when
                              Ranger is the consumer of its own data).
  HttpRangerClient (stub)   — production: talks to Ranger's HTTP API.
                              Phase 3.1 fills in the actual calls; the
                              wire-format contract (request shape, auth
                              header) is documented here for reference.

Services configure ONE of these at bootstrap. The rest of oak_config
treats them uniformly via the ABC.
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Any, Optional


class RangerClient(ABC):
    """Read-only client interface for Ranger from a service consumer.

    Why no write methods: services are CONSUMERS of config; mutation
    is admin-only via the Ranger UI / API. The client lib never writes.
    """

    @abstractmethod
    def fetch_secret(
        self,
        *,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> bytes:
        """Return the decrypted value for a secret, or raise."""

    @abstractmethod
    def fetch_config(
        self,
        *,
        service: str,
        environment: str,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> Any:
        """Return the value of a config row, or raise."""


class LocalRangerClient(RangerClient):
    """In-process client — calls into Ranger's stores directly.

    Used for:
      * tests (no HTTP server needed);
      * Ranger's own startup, where Ranger is the consumer of its own
        config + secrets and the stores live in the same process.

    Construction takes the two stores; the client does not own their
    lifecycles (the caller manages sessions and transactions).
    """

    def __init__(self, secrets_store: Any, config_store: Any) -> None:
        self._secrets = secrets_store
        self._config = config_store

    def fetch_secret(
        self,
        *,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> bytes:
        return self._secrets.get(
            tenant_id=tenant_id,
            namespace=namespace,
            name=key,
            actor=actor,
        )

    def fetch_config(
        self,
        *,
        service: str,
        environment: str,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> Any:
        return self._config.get(
            tenant_id=tenant_id,
            service=service,
            environment=environment,
            namespace=namespace,
            key=key,
            actor=actor,
        )


class HttpRangerClient(RangerClient):
    """Production client — talks to Ranger via HTTP.

    Phase 3.1 implements this. The wire-format contract (documented for
    reference and for the Phase 3.1 server-side implementation):

      GET  {base_url}/api/v1/secrets/{namespace}/{key}?tenant_id=<uuid>
           Authorization: Bearer <bootstrap-or-service-token>
           → 200 {"value": "<utf-8-string>"} OR 200 {"value_b64": "..."} for binary
           → 404 if missing
           → 403 if actor lacks access

      GET  {base_url}/api/v1/config/{service}/{environment}/{namespace}/{key}?tenant_id=<uuid>
           Authorization: Bearer <bootstrap-or-service-token>
           → 200 {"value": <any JSON-encodable>}
           → 404 if missing
           → 403 if actor lacks access

    Bootstrap flow: service starts → reads ``OAK_RANGER_URL`` and
    ``OAK_BOOTSTRAP_TOKEN_FILE`` (the only two env vars the service
    needs to know) → constructs HttpRangerClient → calls bootstrap().
    """

    def __init__(
        self,
        base_url: str,
        token_provider: Any,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token_provider = token_provider

    def fetch_secret(
        self,
        *,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> bytes:
        raise NotImplementedError(
            "HttpRangerClient.fetch_secret ships in Phase 3.1 alongside the "
            "Ranger HTTP API server. See client.py docstring for the wire "
            "format that's already specified."
        )

    def fetch_config(
        self,
        *,
        service: str,
        environment: str,
        namespace: str,
        key: str,
        tenant_id: Optional[uuid.UUID],
        actor: Any,
    ) -> Any:
        raise NotImplementedError(
            "HttpRangerClient.fetch_config ships in Phase 3.1."
        )
