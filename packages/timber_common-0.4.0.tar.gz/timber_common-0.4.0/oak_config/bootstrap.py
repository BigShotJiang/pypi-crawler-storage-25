"""bootstrap() — fetch declared specs and populate the cache + env.

Called once at service startup. The service declares what it needs as
:class:`SecretSpec` + :class:`ConfigSpec` lists and gets back a
:class:`Cache` populated with the fetched values. Env vars listed in
the specs are written to ``os.environ`` so existing code paths that
read ``os.environ[X]`` continue to work unchanged.

This function does not start the live-reload subscriber; that's a
separate explicit call (:func:`oak_config.subscriber.build_change_handler`)
because it has lifecycle concerns (background thread, broker
connection) the service should manage on purpose.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Iterable, Optional

from oak_config.cache import Cache
from oak_config.client import RangerClient
from oak_config.env import populate_environ
from oak_config.specs import ConfigSpec, SecretSpec

logger = logging.getLogger(__name__)


class BootstrapError(Exception):
    """Raised when one or more required specs failed to fetch."""

    def __init__(self, errors: list[str]) -> None:
        super().__init__(
            f"bootstrap failed for {len(errors)} required spec(s): "
            f"{'; '.join(errors)}"
        )
        self.errors = errors


def bootstrap(
    *,
    client: RangerClient,
    actor: Any,
    tenant_id: Optional[uuid.UUID] = None,
    secrets: Iterable[SecretSpec] = (),
    configs: Iterable[ConfigSpec] = (),
    overwrite_env: bool = True,
) -> Cache:
    """Fetch every spec and populate the cache + env.

    Args:
        client: a :class:`RangerClient` (Local for tests, Http for prod).
        actor: the caller's identity (typically
            ``ranger.identity.Actor.system("bootstrap")`` for service startup).
        tenant_id: tenant context for tenant-scoped specs. ``None``
            fetches global rows; for B2B services this is set per-call
            from the JWT.
        secrets: declarative list of :class:`SecretSpec`.
        configs: declarative list of :class:`ConfigSpec`.
        overwrite_env: if False, existing env vars take precedence over
            fetched values (enables local dev overrides via shell export).

    Returns:
        A populated :class:`Cache`.

    Raises:
        BootstrapError: if any ``required=True`` spec failed.
    """
    cache = Cache()
    fetched_secrets: dict[str, bytes] = {}
    fetched_configs: dict[str, Any] = {}
    secret_encodings: dict[str, Optional[str]] = {}
    errors: list[str] = []

    secrets_list = list(secrets)
    configs_list = list(configs)

    logger.info(
        "oak_config bootstrap: fetching %d secret(s) and %d config(s)",
        len(secrets_list),
        len(configs_list),
    )

    for spec in secrets_list:
        try:
            value = client.fetch_secret(
                namespace=spec.namespace,
                key=spec.key,
                tenant_id=tenant_id,
                actor=actor,
            )
        except Exception as exc:
            msg = f"secret {spec.namespace}/{spec.key}: {type(exc).__name__}: {exc}"
            if spec.required:
                errors.append(msg)
            else:
                logger.warning("oak_config bootstrap (optional): %s", msg)
            continue
        cache.set_secret(spec.namespace, spec.key, value)
        if spec.env_var is not None:
            fetched_secrets[spec.env_var] = value
            secret_encodings[spec.env_var] = spec.encoding

    for spec in configs_list:
        try:
            value = client.fetch_config(
                service=spec.service,
                environment=spec.environment,
                namespace=spec.namespace,
                key=spec.key,
                tenant_id=tenant_id,
                actor=actor,
            )
        except Exception as exc:
            msg = (
                f"config {spec.service}/{spec.environment}/{spec.namespace}/"
                f"{spec.key}: {type(exc).__name__}: {exc}"
            )
            if spec.required:
                errors.append(msg)
            else:
                logger.warning("oak_config bootstrap (optional): %s", msg)
            continue
        cache.set_config(
            spec.service, spec.environment, spec.namespace, spec.key, value
        )
        if spec.env_var is not None:
            fetched_configs[spec.env_var] = value

    if errors:
        # Fail-closed: a required spec missing means the service should
        # not start in degraded mode silently.
        raise BootstrapError(errors)

    populate_environ(
        secrets=fetched_secrets,
        configs=fetched_configs,
        secret_encodings=secret_encodings,
        overwrite=overwrite_env,
    )
    logger.info(
        "oak_config bootstrap: complete — populated %d env var(s)",
        len(fetched_secrets) + len(fetched_configs),
    )
    return cache
