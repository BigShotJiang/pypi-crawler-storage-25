"""In-process cache for fetched secrets + config values.

Not a security-sensitive cache — secret PLAINTEXT lives here while the
service runs. That's the intended shape of envelope encryption: the
encrypted value is in Ranger; the decrypted value lives only in the
consuming service's memory for the duration of its lifetime.

Thread-safe via a single RLock — write contention is low (bootstrap
populates once, live-reload writes occasionally) and read contention
is bounded by hot keys, so a single lock is plenty for current scale.
Could split per-key locks later if profiling motivates it.
"""

from __future__ import annotations

import threading
from typing import Any, Optional


class Cache:
    """Mapping of fetched values, populated by bootstrap and updated by live reload."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        # (namespace, key) → bytes
        self._secrets: dict[tuple[str, str], bytes] = {}
        # (service, environment, namespace, key) → Any
        self._config: dict[tuple[str, str, str, str], Any] = {}

    # ------------------------------------------------------------------
    # Secrets
    # ------------------------------------------------------------------

    def get_secret(self, namespace: str, key: str) -> Optional[bytes]:
        with self._lock:
            return self._secrets.get((namespace, key))

    def set_secret(self, namespace: str, key: str, value: bytes) -> None:
        if not isinstance(value, (bytes, bytearray)):
            raise TypeError(
                f"secret values must be bytes (got {type(value).__name__}). "
                f"If you have a string, encode it explicitly."
            )
        with self._lock:
            self._secrets[(namespace, key)] = bytes(value)

    def remove_secret(self, namespace: str, key: str) -> None:
        with self._lock:
            self._secrets.pop((namespace, key), None)

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------

    def get_config(
        self, service: str, environment: str, namespace: str, key: str
    ) -> Any:
        with self._lock:
            return self._config.get((service, environment, namespace, key))

    def set_config(
        self,
        service: str,
        environment: str,
        namespace: str,
        key: str,
        value: Any,
    ) -> None:
        with self._lock:
            self._config[(service, environment, namespace, key)] = value

    def remove_config(
        self, service: str, environment: str, namespace: str, key: str
    ) -> None:
        with self._lock:
            self._config.pop((service, environment, namespace, key), None)

    # ------------------------------------------------------------------
    # Inspection (test/debug)
    # ------------------------------------------------------------------

    def secret_keys(self) -> list[tuple[str, str]]:
        with self._lock:
            return list(self._secrets.keys())

    def config_keys(self) -> list[tuple[str, str, str, str]]:
        with self._lock:
            return list(self._config.keys())
