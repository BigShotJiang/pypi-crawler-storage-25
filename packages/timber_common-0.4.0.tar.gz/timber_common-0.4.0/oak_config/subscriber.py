"""Subscriber abstraction + change-event handler builder.

Phase 2.2's config store publishes events on
``oak.config.changed.<service>`` whenever a config row mutates. This
module gives consumers the bricks to react:

  Subscriber               — abstract base. Concrete impls connect to a
                             broker, listen, and dispatch JSON events
                             to handlers.
  build_change_handler()   — returns a closure suitable for use as a
                             Subscriber handler. The closure refetches
                             the affected key from Ranger, updates the
                             cache, and re-populates the env var if the
                             matching spec declared one.

The actual Redis-backed Subscriber implementation ships in Phase 2.4
when oak_config is wired to a real broker. Phase 2.3 ships the ABC
and the handler so the live-reload SHAPE is testable now.
"""

from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from typing import Any, Callable, Iterable, Optional

from oak_config.cache import Cache
from oak_config.client import RangerClient
from oak_config.env import populate_environ
from oak_config.specs import ConfigSpec, SecretSpec

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# Subscriber interface
# ----------------------------------------------------------------------


class Subscriber(ABC):
    """Listen to a broker channel; dispatch parsed events to a handler."""

    @abstractmethod
    def subscribe(
        self,
        channel: str,
        handler: Callable[[dict[str, Any]], None],
    ) -> None:
        """Register ``handler`` for ``channel``. Multiple subscribes to
        the same channel append handlers (all fire on each event).
        """

    @abstractmethod
    def start(self) -> None:
        """Begin listening. Blocking subscribers run a thread; non-
        blocking ones do nothing here.
        """

    @abstractmethod
    def stop(self) -> None:
        """Stop listening and release any background resources."""


# ----------------------------------------------------------------------
# Change-event handler
# ----------------------------------------------------------------------


def build_change_handler(
    *,
    client: RangerClient,
    cache: Cache,
    actor: Any,
    tenant_id: Optional[uuid.UUID] = None,
    secret_specs: Iterable[SecretSpec] = (),
    config_specs: Iterable[ConfigSpec] = (),
) -> Callable[[dict[str, Any]], None]:
    """Build a handler that updates the cache + env when a change event arrives.

    The handler matches the event's ``(service, environment, namespace,
    key)`` against the registered specs. On a match, it:

      * if action == DELETE: removes from cache; clears env var if present.
      * else: refetches via ``client``, updates cache + env var.

    Events for keys NOT in the specs are ignored — the service only
    cares about the things it declared.

    The handler is exception-safe: an error during refetch is logged
    and the cache is left in its previous state. Live reload is
    best-effort; the next bootstrap or scheduled refresh will recover.
    """
    secret_specs = list(secret_specs)
    config_specs = list(config_specs)

    # Index by identity for O(1) lookup.
    secret_by_id = {(s.namespace, s.key): s for s in secret_specs}
    config_by_id = {
        (s.service, s.environment, s.namespace, s.key): s for s in config_specs
    }

    def handler(event: dict[str, Any]) -> None:
        try:
            namespace = event.get("namespace")
            key = event.get("key")
            service = event.get("service")
            environment = event.get("environment")
            action = event.get("action")
            if not all([namespace, key, service, environment, action]):
                logger.debug("oak_config: ignoring malformed event: %s", event)
                return

            # Look up the matching spec(s). A change event might match a
            # secret spec, a config spec, or neither (we ignore the latter).
            secret_spec = secret_by_id.get((namespace, key))
            config_spec = config_by_id.get((service, environment, namespace, key))

            if secret_spec is not None:
                _apply_secret_change(
                    secret_spec, action, cache, client, actor, tenant_id
                )
            if config_spec is not None:
                _apply_config_change(
                    config_spec, action, cache, client, actor, tenant_id
                )
        except Exception:
            # Never let a handler exception crash the subscriber thread.
            # Log and move on; bootstrap will recover the bad state on
            # next service restart.
            logger.exception("oak_config: change handler raised on event %s", event)

    return handler


def _apply_secret_change(
    spec: SecretSpec,
    action: str,
    cache: Cache,
    client: RangerClient,
    actor: Any,
    tenant_id: Optional[uuid.UUID],
) -> None:
    if action == "DELETE":
        cache.remove_secret(spec.namespace, spec.key)
        return
    value = client.fetch_secret(
        namespace=spec.namespace,
        key=spec.key,
        tenant_id=tenant_id,
        actor=actor,
    )
    cache.set_secret(spec.namespace, spec.key, value)
    if spec.env_var is not None:
        populate_environ(
            secrets={spec.env_var: value},
            configs={},
            secret_encodings={spec.env_var: spec.encoding},
        )


def _apply_config_change(
    spec: ConfigSpec,
    action: str,
    cache: Cache,
    client: RangerClient,
    actor: Any,
    tenant_id: Optional[uuid.UUID],
) -> None:
    if action == "DELETE":
        cache.remove_config(
            spec.service, spec.environment, spec.namespace, spec.key
        )
        return
    value = client.fetch_config(
        service=spec.service,
        environment=spec.environment,
        namespace=spec.namespace,
        key=spec.key,
        tenant_id=tenant_id,
        actor=actor,
    )
    cache.set_config(
        spec.service, spec.environment, spec.namespace, spec.key, value
    )
    if spec.env_var is not None:
        populate_environ(secrets={}, configs={spec.env_var: value})
