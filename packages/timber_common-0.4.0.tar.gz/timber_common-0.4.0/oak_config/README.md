# `oak_config` — service-side bootstrap for Oak's centralized config + secrets

Phase 2.3 deliverable. The client-side library that services import at
startup. Lives at the top level of `timber/` (not under `common/`)
specifically so that `import oak_config` does not trigger any database
connection — services bootstrap config BEFORE talking to the database,
so the import path must be DB-free.

## Layout

```
oak_config/
├── __init__.py    # public API
├── specs.py       # SecretSpec, ConfigSpec — declarative "what to fetch"
├── client.py      # RangerClient ABC + LocalRangerClient + HttpRangerClient (stub)
├── cache.py       # Thread-safe in-process cache
├── env.py         # populate_environ() helper
├── bootstrap.py   # bootstrap() — orchestrates fetch + populate
├── subscriber.py  # Subscriber ABC + build_change_handler()
└── README.md
```

## End-to-end usage

A service's startup looks like this:

```python
import os
from ranger.identity import Actor

from oak_config import (
    Cache,
    ConfigSpec,
    HttpRangerClient,   # or LocalRangerClient for tests
    SecretSpec,
    bootstrap,
    build_change_handler,
)

# Step 1: bootstrap — only TWO env vars need to exist before this runs:
#   OAK_RANGER_URL          — where Ranger lives
#   OAK_BOOTSTRAP_TOKEN     — short-lived token that authenticates this service
client = HttpRangerClient(
    base_url=os.environ["OAK_RANGER_URL"],
    token_provider=lambda: os.environ["OAK_BOOTSTRAP_TOKEN"],
)

# Step 2: declare what we need
SECRETS = [
    SecretSpec(namespace="grove", key="OPENAI_API_KEY", env_var="OPENAI_API_KEY"),
    SecretSpec(namespace="grove", key="DATABASE_URL", env_var="DATABASE_URL"),
]

CONFIGS = [
    ConfigSpec(
        service="grove", environment=os.environ.get("OAK_ENV", "dev"),
        namespace="ports", key="grove-api/http", env_var="GROVE_API_PORT",
    ),
    ConfigSpec(
        service="grove", environment=os.environ.get("OAK_ENV", "dev"),
        namespace="feature_flags", key="enable_ai_analysis",
        env_var="ENABLE_AI_ANALYSIS",
    ),
]

# Step 3: fetch everything. Populates os.environ for legacy code.
cache = bootstrap(
    client=client,
    actor=Actor.system("grove-bootstrap"),
    secrets=SECRETS,
    configs=CONFIGS,
)

# Step 4 (Phase 2.4): subscribe to live-reload events
# subscriber = RedisSubscriber(redis_client)
# handler = build_change_handler(
#     client=client, cache=cache, actor=Actor.system("grove-reloader"),
#     secret_specs=SECRETS, config_specs=CONFIGS,
# )
# subscriber.subscribe(channel_for("grove"), handler)
# subscriber.start()

# Step 5: run the rest of the application — existing code paths that
# read os.environ[X] keep working unchanged.
```

## What's in vs out (Phase 2.3)

| Capability | Status |
|---|---|
| `RangerClient` protocol | ✅ ABC defined |
| `LocalRangerClient` (in-process, for tests) | ✅ |
| `HttpRangerClient` (production) | 🟡 stub — implementation in Phase 3.1 with the Ranger HTTP server |
| Declarative specs (`SecretSpec`, `ConfigSpec`) | ✅ |
| `bootstrap()` orchestration | ✅ |
| `populate_environ()` helper | ✅ |
| Thread-safe `Cache` | ✅ |
| `Subscriber` ABC + change handler builder | ✅ |
| Concrete `RedisSubscriber` | 🟡 Phase 2.4 |
| Lazy DB init in `common/__init__.py` | 🟡 deferred — see follow-ups |

## Why this is a top-level package, not under `common/`

Importing `common` triggers timber's eager DB connect. Services
bootstrap config BEFORE they have a database, so the bootstrap library
cannot live under `common/`. The lazy-init refactor is tracked as a
deferred capability and will land when Phase 2.4 needs it.

## Wire-format contract for `HttpRangerClient`

Phase 3.1 implements these on the server side. The client side
implementation is stubbed today but the URL shape is locked:

```
GET  {base_url}/api/v1/secrets/{namespace}/{key}?tenant_id=<uuid>
     Authorization: Bearer <token>
     → 200 {"value": "<utf-8-string>"} | {"value_b64": "..."}
     → 404 if missing | 403 if no access

GET  {base_url}/api/v1/config/{service}/{environment}/{namespace}/{key}?tenant_id=<uuid>
     Authorization: Bearer <token>
     → 200 {"value": <any JSON-encodable>}
     → 404 if missing | 403 if no access
```

## Best-effort live reload

Pubsub is the fast path. The DB is the source of truth. If the
subscriber misses an event for any reason (broker outage, partition,
service restart timing), the worst case is that the consuming service
continues running with stale config until the next bootstrap or a
scheduled refresh. Subscribers should NEVER raise — handler errors
are logged and swallowed.

## Adding a new spec to a service

1. Add a `SecretSpec` or `ConfigSpec` to the service's bootstrap module.
2. Add the actual secret/config to Ranger via the admin UI (Phase 3.2)
   or via direct DB seed during local dev.
3. Restart the service (Phase 2.3) or wait for live reload (Phase 2.4).

The declarative spec list is the audit log of what a service consumes.
Reviewers can read one block to know everything a service touches.
