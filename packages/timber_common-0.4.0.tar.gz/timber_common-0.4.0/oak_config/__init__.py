"""oak_config — service-side bootstrap for Oak's centralized config + secrets.

This is the client-side library that services import at startup. It calls
into Ranger (the control plane), fetches the service's secrets and
config, populates ``os.environ`` so existing code paths don't change,
and (Phase 2.4 onward) subscribes to live-reload notifications so
non-secret config changes take effect without a restart.

Top-level package on purpose — does NOT live under ``common/`` so that
``import oak_config`` does not trigger the eager DB connect in
``common/__init__.py``. Services bootstrap config BEFORE talking to the
database, so the import path must be DB-free.

Public API:
    RangerClient, LocalRangerClient, HttpRangerClient
        — protocol for talking to Ranger. LocalRangerClient is the
          in-process implementation (tests + Ranger's own startup).
          HttpRangerClient is the production implementation (Phase 3.1
          fills in the actual HTTP calls).

    SecretSpec, ConfigSpec
        — declarative shape for "what to fetch on bootstrap." Services
          declare the secrets/config they need + which env vars to
          populate.

    Cache
        — thread-safe in-process cache of fetched values. Survives the
          bootstrap call so live-reload can update it later.

    bootstrap()
        — orchestration. Given a client + actor + specs, fetches
          everything and populates env vars.

    populate_environ()
        — exposed separately for callers who want to populate env
          themselves from a Cache (e.g. after a live reload).

    Subscriber, build_change_handler()
        — subscriber abstraction + handler builder for the live-reload
          loop. The actual Redis subscriber is a Phase 2.4 deliverable.

See README.md for end-to-end usage.
"""

from oak_config.bootstrap import bootstrap
from oak_config.cache import Cache
from oak_config.client import HttpRangerClient, LocalRangerClient, RangerClient
from oak_config.env import populate_environ
from oak_config.specs import ConfigSpec, SecretSpec
from oak_config.subscriber import Subscriber, build_change_handler

__all__ = [
    "Cache",
    "ConfigSpec",
    "HttpRangerClient",
    "LocalRangerClient",
    "RangerClient",
    "SecretSpec",
    "Subscriber",
    "bootstrap",
    "build_change_handler",
    "populate_environ",
]
