"""Declarative specs for what to fetch on bootstrap.

A service declares a list of :class:`SecretSpec` and :class:`ConfigSpec`
describing what it needs and (optionally) which environment variable to
populate with each. The :func:`oak_config.bootstrap` function consumes
the list and orchestrates the fetch.

Why declarative: keeping the "what to fetch" data separate from the
"how to fetch" code means a service's bootstrap surface is auditable.
You can list every secret a service touches by reading a single
configuration block.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class SecretSpec:
    """Specification for a single secret to fetch at bootstrap.

    Attributes:
        namespace: which secret namespace (e.g. ``"grove"``,
            ``"acorn"``, ``"global"``).
        key: the secret name within the namespace.
        env_var: optional ``os.environ`` key to populate with the
            decoded value. If omitted, the value is held in the cache
            only (use ``Cache.get_secret(...)`` to retrieve it).
        encoding: how to decode bytes for env-var population (default
            UTF-8). Set to ``None`` if the secret is binary and you
            won't populate env.
        required: if True, bootstrap raises on miss. If False, miss is
            logged and execution continues.
    """

    namespace: str
    key: str
    env_var: Optional[str] = None
    encoding: Optional[str] = "utf-8"
    required: bool = True


@dataclass(frozen=True)
class ConfigSpec:
    """Specification for a single config row to fetch at bootstrap.

    Attributes:
        service: which service the config belongs to (e.g. ``"grove"``).
            Usually the same as the consuming service, but a service
            can read another's config when there's a dependency.
        environment: ``"dev"`` / ``"staging"`` / ``"prod"``. Resolved
            once at bootstrap from a single source of truth (one of the
            three things that legitimately stays in a small bootstrap
            ``.env``).
        namespace: ``"feature_flags"`` / ``"models"`` / ``"ports"`` /
            etc.
        key: the config key within the namespace.
        env_var: optional ``os.environ`` key to populate. The value
            renders as JSON if it's a dict/list, str() otherwise.
        required: same semantics as :class:`SecretSpec`.
    """

    service: str
    environment: str
    namespace: str
    key: str
    env_var: Optional[str] = None
    required: bool = True
