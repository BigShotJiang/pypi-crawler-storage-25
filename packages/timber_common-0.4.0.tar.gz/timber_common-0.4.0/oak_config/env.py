"""``os.environ`` population helpers.

Most existing service code reads config via ``os.environ[...]``. The
oak_config bootstrap populates env vars from fetched secrets / config
so that those code paths don't change. Live reload re-runs the
populate function for the affected entries.

Kept in its own module because the rules — "encode bytes how?", "render
dicts as JSON?" — are fiddly enough that they deserve isolated tests.
"""

from __future__ import annotations

import json
import os
from typing import Any, Optional


def render_secret_for_env(value: bytes, encoding: Optional[str] = "utf-8") -> str:
    """Decode a secret value to a string suitable for ``os.environ``.

    Raises ValueError if ``encoding`` is None — caller has explicitly
    declared the secret is binary, so it shouldn't be populated to env.
    """
    if encoding is None:
        raise ValueError(
            "secret has encoding=None — cannot populate as env var. "
            "Use Cache.get_secret() in the service code instead."
        )
    return value.decode(encoding)


def render_config_for_env(value: Any) -> str:
    """Render a config value to a string for ``os.environ``.

    Rules:
      * str → as-is
      * bool / int / float → str()
      * dict / list → json.dumps()
      * None → empty string
      * everything else → json.dumps() (best-effort)
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (bool, int, float)):
        return str(value)
    return json.dumps(value, default=str, sort_keys=True)


def populate_environ(
    *,
    secrets: dict[str, bytes],
    configs: dict[str, Any],
    secret_encodings: Optional[dict[str, Optional[str]]] = None,
    overwrite: bool = True,
) -> dict[str, str]:
    """Set ``os.environ`` for every (env_var → value) mapping passed in.

    Args:
        secrets: env_var name → secret bytes.
        configs: env_var name → config value (any JSON-serializable).
        secret_encodings: optional env_var → encoding override for binary
            handling. Defaults to UTF-8 for any secret not in the dict.
        overwrite: if False, env vars already set in the environment are
            preserved (lets a developer locally override a single value
            via shell export without editing config). Defaults True.

    Returns:
        A dict of every env_var that was actually set (after the
        overwrite check), so the caller can audit-log it.
    """
    written: dict[str, str] = {}
    encodings = secret_encodings or {}

    for env_var, secret_value in secrets.items():
        if not overwrite and env_var in os.environ:
            continue
        encoding = encodings.get(env_var, "utf-8")
        rendered = render_secret_for_env(secret_value, encoding)
        os.environ[env_var] = rendered
        written[env_var] = rendered

    for env_var, config_value in configs.items():
        if not overwrite and env_var in os.environ:
            continue
        rendered = render_config_for_env(config_value)
        os.environ[env_var] = rendered
        written[env_var] = rendered

    return written
