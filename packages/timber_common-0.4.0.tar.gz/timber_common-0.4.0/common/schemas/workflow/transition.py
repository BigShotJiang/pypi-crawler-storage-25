"""Transition — a single state-to-state edge in a workflow."""

from __future__ import annotations

import ast
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from common.schemas.workflow.enums import TransitionType
from common.schemas.workflow.patterns import is_identifier


class Transition(BaseModel):
    """A state-to-state transition.

    Validators enforce:
      * `to` is a valid identifier (state name shape).
      * `condition`, when present, parses as a Python expression and does
        not contain dunder access (defense-in-depth — the runtime
        evaluator is also locked down in grove).
      * when=CONDITIONAL requires `condition`.
      * when=ON_EVENT requires `event`.
    """

    model_config = ConfigDict(extra="forbid")

    to: str = Field(description="Target state name.")
    when: TransitionType = Field(default=TransitionType.ALWAYS)
    condition: str | None = None
    priority: int = Field(default=0, description="Lower = higher priority.")
    event: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("to")
    @classmethod
    def _validate_to(cls, value: str) -> str:
        if not is_identifier(value):
            raise ValueError(
                f"transition target '{value}' is not a valid state name "
                f"(must match [a-zA-Z_][\\w]*)"
            )
        return value

    @field_validator("condition")
    @classmethod
    def _validate_condition(cls, value: str | None) -> str | None:
        if value is None:
            return value
        try:
            ast.parse(value, mode="eval")
        except SyntaxError as exc:
            raise ValueError(
                f"condition is not a valid Python expression: {exc.msg}"
            ) from exc
        if "__" in value:
            raise ValueError(
                "condition contains '__' — dunder access is forbidden "
                "(prevents sandbox escape in the runtime evaluator)"
            )
        return value

    @model_validator(mode="after")
    def _validate_when_requirements(self) -> "Transition":
        if self.when == TransitionType.CONDITIONAL and not self.condition:
            raise ValueError(
                "when='conditional' requires a 'condition' expression"
            )
        if self.when == TransitionType.ON_EVENT and not self.event:
            raise ValueError("when='on_event' requires an 'event' name")
        return self
