"""WorkflowDefinition — the top-level schema for grove_workflow_configs.config_content.

This is the universal Tier 2 shape; per-tenant extensions live in the
inherited `extensions` field and (Phase 4) are validated against a
per-tenant JSON Schema overlay.
"""

from __future__ import annotations

from typing import Any

from pydantic import Field, field_validator, model_validator

from common.schemas.base import ConfigContent
from common.schemas.workflow.enums import WorkflowType, is_absorbing
from common.schemas.workflow.patterns import (
    STANDARD_TEMPLATE_SCOPES,
    TEMPLATE_VAR_RE,
    is_identifier,
)
from common.schemas.workflow.state import StateDefinition


class WorkflowDefinition(ConfigContent):
    """Validation invariants enforced at upsert time.

    See ``ranger/docs/security/`` and ``naming-standards.md`` for the
    architectural context. Each invariant below corresponds to a real
    bug class that has bitten Grove in production.
    """

    name: str = Field(min_length=1, max_length=200)
    workflow_type: WorkflowType = WorkflowType.STANDARD
    initial_state: str
    states: dict[str, StateDefinition] = Field(min_length=1)

    display_name: str | None = None
    description: str | None = None
    version: str | None = None
    session_model: str | None = None
    inputs: dict[str, Any] = Field(default_factory=dict)
    config: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Workflow-level config block (timeout_hours, allow_resume, "
            "track_time_spent, image_service settings, etc.). Free-form for "
            "now; tightened to a typed schema in a later phase."
        ),
    )
    timeout_hours: int | None = Field(default=None, gt=0)
    on_complete: dict[str, Any] | None = None
    on_error: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    validation: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Optional `validation:` block defining pre-execution input checks. "
            "Free-form for now."
        ),
    )

    # `extensions: dict[str, Any] | None` is inherited from ConfigContent.

    # ------------------------------------------------------------------
    # Pre-validation: unwrap legacy `workflow:` wrapper
    # ------------------------------------------------------------------

    @model_validator(mode="before")
    @classmethod
    def _unwrap_workflow_wrapper(cls, data: Any) -> Any:
        """Some Grove workflows put metadata under a `workflow:` key while
        keeping `states:`, `inputs:`, `config:`, `initial_state:` at the root.
        Merge the wrapped fields into the root so the rest of the model sees
        a flat shape. Top-level keys take precedence over wrapped keys (so
        an explicit root `name` overrides `workflow.name` if both exist).
        """
        if not isinstance(data, dict):
            return data
        wrapper = data.get("workflow")
        if not isinstance(wrapper, dict):
            return data
        merged = dict(wrapper)
        for key, value in data.items():
            if key == "workflow":
                continue
            merged[key] = value
        return merged

    # ------------------------------------------------------------------
    # Field-level validators
    # ------------------------------------------------------------------

    @field_validator("name")
    @classmethod
    def _validate_name(cls, value: str) -> str:
        if not is_identifier(value):
            raise ValueError(
                f"workflow name '{value}' must match [a-zA-Z_][\\w]*"
            )
        return value

    @field_validator("states")
    @classmethod
    def _validate_state_keys(
        cls, value: dict[str, StateDefinition]
    ) -> dict[str, StateDefinition]:
        for state_name in value:
            if not is_identifier(state_name):
                raise ValueError(
                    f"state name '{state_name}' must match [a-zA-Z_][\\w]*"
                )
        return value

    # ------------------------------------------------------------------
    # Cross-field invariants
    # ------------------------------------------------------------------

    @model_validator(mode="after")
    def _validate_initial_state_exists(self) -> "WorkflowDefinition":
        if self.initial_state not in self.states:
            known = sorted(self.states.keys())
            raise ValueError(
                f"initial_state '{self.initial_state}' is not defined in "
                f"states (known: {known})"
            )
        return self

    @model_validator(mode="after")
    def _validate_transition_targets(self) -> "WorkflowDefinition":
        known = set(self.states.keys())
        errors: list[str] = []
        for state_name, state in self.states.items():
            for index, transition in enumerate(state.transitions):
                if transition.to not in known:
                    errors.append(
                        f"states.{state_name}.transitions[{index}].to "
                        f"references unknown state '{transition.to}'"
                    )
        if errors:
            raise ValueError("; ".join(errors))
        return self

    @model_validator(mode="after")
    def _validate_terminal_states_exist(self) -> "WorkflowDefinition":
        terminal = [name for name, s in self.states.items() if is_absorbing(s.type)]
        if not terminal:
            raise ValueError(
                "workflow has no absorbing states — execution would never "
                "end. Add at least one state with type='terminal', 'final', "
                "or 'error'."
            )
        return self

    @model_validator(mode="after")
    def _validate_template_scopes(self) -> "WorkflowDefinition":
        """Walk every task's parameters; reject ${scope.path} where `scope`
        is neither a STANDARD_TEMPLATE_SCOPE nor a defined state name.

        State names ARE valid scopes — `${plaid_auth.outputs.token}` is the
        standard way to reference a previous state's outputs. This check
        only runs at the workflow level because per-task validators don't
        have access to the full set of state names.
        """
        valid_scopes = STANDARD_TEMPLATE_SCOPES | set(self.states.keys())
        # Step IDs (StateTaskRef.name) are also valid scope names — downstream
        # states reference them as ${<task_name>.outputs.X}.
        for state in self.states.values():
            for task in state.tasks:
                if task.name:
                    valid_scopes = valid_scopes | {task.name}

        errors: list[str] = []
        for state_name, state in self.states.items():
            for task_index, task in enumerate(state.tasks):
                _check_templates(
                    task.parameters,
                    f"states.{state_name}.tasks[{task_index}].parameters",
                    valid_scopes,
                    errors,
                )
        if errors:
            raise ValueError("; ".join(errors))
        return self

    @model_validator(mode="after")
    def _validate_reachability(self) -> "WorkflowDefinition":
        reachable = self._reachable_from(self.initial_state)
        unreachable = sorted(set(self.states.keys()) - reachable)
        if unreachable:
            raise ValueError(
                f"states unreachable from initial_state="
                f"'{self.initial_state}': {unreachable}"
            )
        return self

    # ------------------------------------------------------------------
    # Helpers (kept compatible with the dataclass API where reasonable)
    # ------------------------------------------------------------------

    def _reachable_from(self, start: str) -> set[str]:
        reachable: set[str] = set()
        stack: list[str] = [start]
        while stack:
            current = stack.pop()
            if current in reachable:
                continue
            reachable.add(current)
            state = self.states.get(current)
            if state is None:
                continue
            for transition in state.transitions:
                if transition.to not in reachable:
                    stack.append(transition.to)
        return reachable

    def get_terminal_states(self) -> list[str]:
        return [name for name, s in self.states.items() if is_absorbing(s.type)]

    def list_states(self) -> list[str]:
        return list(self.states.keys())

    def get_all_task_names(self) -> list[str]:
        names: set[str] = set()
        for state in self.states.values():
            for task in state.tasks:
                names.add(task.task_name)
        return sorted(names)


def _check_templates(
    node: Any,
    path: str,
    valid_scopes: set[str],
    errors: list[str],
) -> None:
    """Walk `node` collecting any ${scope.path} whose `scope` isn't valid.

    Errors append to `errors` rather than raise, so the caller can report
    every offending parameter at once instead of stopping at the first.
    """
    if isinstance(node, str):
        for match in TEMPLATE_VAR_RE.finditer(node):
            full_ref = match.group(1)
            scope = full_ref.split(".", 1)[0]
            if scope not in valid_scopes:
                errors.append(
                    f"{path}: template '${{{full_ref}}}' uses unknown scope "
                    f"'{scope}' (not a standard scope and not a defined state "
                    f"name or step id)"
                )
    elif isinstance(node, dict):
        for k, v in node.items():
            _check_templates(v, f"{path}.{k}", valid_scopes, errors)
    elif isinstance(node, list):
        for i, item in enumerate(node):
            _check_templates(item, f"{path}[{i}]", valid_scopes, errors)
