"""Enumerations used across the workflow schema package."""

from __future__ import annotations

from enum import Enum


class StateType(str, Enum):
    """Semantic category of a workflow state.

    Active categories (run tasks, then evaluate transitions):
      NORMAL          : the canonical "do work" state.
      PROCESSING      : synonym used in older workflows for backend processing.
      TASK_EXECUTION  : legacy synonym for PROCESSING.
      TASK            : alternative naming used in some workflows.
      INITIAL         : the explicit starting state (when the YAML chooses to
                        annotate the initial state with this rather than
                        relying solely on the top-level `initial_state` field).
      NOTIFICATION    : sends a user-facing notification, then transitions.

    Waiting categories (pause for human or external event):
      WAITING         : pause for any external event.
      USER_INPUT      : pause for user input specifically.
      HUMAN_TASK      : pause for human-in-the-loop work.

    Absorbing categories (must NOT declare outgoing transitions):
      TERMINAL        : end of a successful workflow run.
      FINAL           : synonym for TERMINAL used in some legacy workflows.
      ERROR           : end of a failed workflow run.

    Use `is_absorbing()` rather than comparing against TERMINAL/ERROR/FINAL
    individually so synonyms stay consistent.
    """

    NORMAL = "normal"
    PROCESSING = "processing"
    TASK_EXECUTION = "task_execution"
    TASK = "task"
    INITIAL = "initial"
    NOTIFICATION = "notification"
    WAITING = "waiting"
    USER_INPUT = "user_input"
    HUMAN_TASK = "human_task"
    TERMINAL = "terminal"
    FINAL = "final"
    ERROR = "error"


_ABSORBING_STATE_TYPES: frozenset[StateType] = frozenset(
    {StateType.TERMINAL, StateType.FINAL, StateType.ERROR}
)


def is_absorbing(state_type: StateType) -> bool:
    """True if a state of this type cannot declare outgoing transitions."""
    return state_type in _ABSORBING_STATE_TYPES


class TransitionType(str, Enum):
    """Trigger semantics for a state-to-state transition."""

    ALWAYS = "always"
    CONDITIONAL = "conditional"
    ON_SUCCESS = "on_success"
    ON_ERROR = "on_error"
    ON_EVENT = "on_event"


class TaskOnError(str, Enum):
    """How a state should react when a task fails."""

    FAIL = "fail"
    CONTINUE = "continue"
    SKIP = "skip"


class WorkflowType(str, Enum):
    """Workflow execution category — affects scheduling and runtime."""

    STANDARD = "standard"
    HITL = "hitl"
    SCHEDULED = "scheduled"
    PARALLEL = "parallel"
