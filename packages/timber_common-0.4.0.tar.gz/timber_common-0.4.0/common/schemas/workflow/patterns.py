"""Regex patterns and identifier helpers for workflow schemas.

These are the syntactic rules that workflow names, state names, task names,
output keys, and template variables must follow. Keeping them isolated
makes it easy to evolve the rules in one place.
"""

from __future__ import annotations

import re

#: Single Python identifier: letter/underscore start, then alphanumerics/underscore.
NAME_RE: re.Pattern[str] = re.compile(r"^[a-zA-Z_][\w]*$")

#: Dotted identifier: e.g. "plaid.create_link_token" — each segment is a NAME_RE.
DOTTED_NAME_RE: re.Pattern[str] = re.compile(r"^[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)*$")

#: Template variable inside a parameter value: ${scope.path.parts}
TEMPLATE_VAR_RE: re.Pattern[str] = re.compile(
    r"\$\{([a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)*)\}"
)

#: Standard scopes a template variable is universally allowed to reference.
#: State names are ALSO allowed as scopes (verified against the workflow's
#: actual states by ``WorkflowDefinition._validate_template_scopes``), so
#: ``${plaid_auth.outputs.public_token}`` resolves if ``plaid_auth`` is a
#: defined state.
STANDARD_TEMPLATE_SCOPES: frozenset[str] = frozenset(
    {
        "context",   # workflow run context (user_id, etc.)
        "inputs",    # workflow- or task-level inputs
        "input",     # singular legacy form of `inputs`
        "session",   # session-persisted state
        "steps",     # explicit step-prefixed reference
        "state",     # current state metadata
        "config",    # workflow `config:` block
        "outputs",   # outputs of the current step
        "env",       # environment variables
        "now",       # current time
    }
)


# Backwards-compat alias kept for any external imports.
VALID_TEMPLATE_SCOPES = STANDARD_TEMPLATE_SCOPES


def is_identifier(value: str) -> bool:
    """Return True if `value` is a single valid identifier."""
    return bool(NAME_RE.match(value))


def is_dotted_identifier(value: str) -> bool:
    """Return True if `value` is one or more dot-joined identifiers."""
    return bool(DOTTED_NAME_RE.match(value))
