"""State-level schema types: StateTaskRef and StateDefinition."""

from __future__ import annotations

import ast
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from common.schemas.workflow.enums import StateType, TaskOnError, is_absorbing
from common.schemas.workflow.patterns import (
    is_dotted_identifier,
    is_identifier,
)
from common.schemas.workflow.transition import Transition


class StateTaskRef(BaseModel):
    """A task to execute within a state.

    `task_name` is a reference into the task registry (rows in
    `grove_task_configs`). The dotted form (e.g. "plaid.create_link_token")
    is supported: each dot-segment must itself be a valid identifier.

    `parameters` may contain template variables of the form ${scope.path}.
    The validator only checks scope validity; whether the path resolves at
    runtime depends on workflow inputs / prior step outputs.
    """

    model_config = ConfigDict(extra="forbid")

    task_name: str
    name: str | None = Field(
        default=None,
        description=(
            "Optional human-readable label / step ID. When set, downstream "
            "states can reference this step's outputs via ${<name>.outputs.X}."
        ),
    )
    parameters: dict[str, Any] = Field(default_factory=dict)
    timeout: int = Field(default=120, gt=0, description="Task timeout in seconds.")
    retry_count: int = Field(default=3, ge=0)
    retry_delay: int = Field(default=60, ge=0, description="Seconds between retries.")
    on_error: TaskOnError = TaskOnError.FAIL
    condition: str | None = None
    output_key: str | None = Field(
        default=None,
        description=(
            "If set, task result is stored at session.<output_key> instead of "
            "flat-merging into research_data."
        ),
    )

    @field_validator("task_name")
    @classmethod
    def _validate_task_name(cls, value: str) -> str:
        if not is_dotted_identifier(value):
            raise ValueError(
                f"task_name '{value}' is invalid — each dot-segment must "
                f"match [a-zA-Z_][\\w]*"
            )
        return value

    @field_validator("name")
    @classmethod
    def _validate_name(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if not is_identifier(value):
            raise ValueError(
                f"task name '{value}' must be a valid identifier "
                f"(used as a step ID for ${{<name>.outputs.X}} references)"
            )
        return value

    @field_validator("output_key")
    @classmethod
    def _validate_output_key(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if not is_identifier(value):
            raise ValueError(
                f"output_key '{value}' must be a valid Python identifier"
            )
        return value

    @field_validator("condition")
    @classmethod
    def _validate_condition(cls, value: str | None) -> str | None:
        if value is None:
            return value
        try:
            ast.parse(value, mode="eval")
        except SyntaxError as exc:
            raise ValueError(
                f"task condition is not a valid Python expression: {exc.msg}"
            ) from exc
        if "__" in value:
            raise ValueError("task condition must not contain '__'")
        return value

    # Note: template-variable scope validation is enforced by
    # WorkflowDefinition._validate_template_scopes (which has access to the
    # full set of state names). Scopes that aren't in STANDARD_TEMPLATE_SCOPES
    # and aren't a defined state name are rejected at the workflow level.


class StateDefinition(BaseModel):
    """A single state in a workflow state machine.

    A NORMAL state runs its tasks then evaluates transitions.
    A WAITING state pauses for human input or external events, then evaluates
    transitions. TERMINAL and ERROR states are absorbing and must not declare
    outgoing transitions.
    """

    model_config = ConfigDict(extra="forbid")

    type: StateType = StateType.NORMAL
    display_name: str | None = None
    description: str | None = None
    tasks: list[StateTaskRef] = Field(default_factory=list)
    transitions: list[Transition] = Field(default_factory=list)
    on_enter: dict[str, Any] | None = None
    on_exit: dict[str, Any] | None = None
    on_complete: dict[str, Any] | None = None
    timeout: int | None = Field(default=None, gt=0)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_terminal_no_transitions(self) -> "StateDefinition":
        if is_absorbing(self.type) and self.transitions:
            raise ValueError(
                f"state.type={self.type.value} is absorbing and cannot "
                f"declare outgoing transitions (got {len(self.transitions)})"
            )
        return self
