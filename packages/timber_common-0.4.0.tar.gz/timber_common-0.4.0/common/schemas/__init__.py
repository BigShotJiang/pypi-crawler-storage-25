"""Tier 2 Pydantic schemas for config-content validation.

These schemas validate the JSON content stored in Tier 1 universal tables
(e.g. the `config_content` column of `grove_workflow_configs`). They are the
canonical contract for what a workflow / model / agent definition LOOKS LIKE,
and are used by:

  * the validate-on-upsert API endpoint in Grove/Ranger
  * the Ranger UI (form generation)
  * Claude skills (authoring assistance)
  * the `timber validate` CLI

See ranger/docs/architecture/yaml-vs-pydantic-strategy.md for the three-tier
model that motivates this directory.

To add a new schema:
  1. Create `common/schemas/<capability>.py` with a Pydantic model that
     subclasses `ConfigContent`.
  2. Re-export from this module.
  3. Add tests under `tests/schemas/`.
  4. Wire into the upsert API and (later) into a Claude skill.
"""

from common.schemas.base import ConfigContent
from common.schemas.workflow import (
    StateDefinition,
    StateTaskRef,
    StateType,
    TaskOnError,
    Transition,
    TransitionType,
    WorkflowDefinition,
    WorkflowType,
)

__all__ = [
    "ConfigContent",
    "StateDefinition",
    "StateTaskRef",
    "StateType",
    "TaskOnError",
    "Transition",
    "TransitionType",
    "WorkflowDefinition",
    "WorkflowType",
]
