"""Base classes for Tier 2 config-content schemas."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ConfigContent(BaseModel):
    """Base class for the JSON content of a config row.

    Subclasses define the universal shape of a capability (Workflow, Model,
    Agent, etc.). The `extensions` field is reserved for Tier 3: per-tenant
    schema overlays that add tenant-specific fields without changing the
    universal model. Until the overlay validator ships, `extensions` accepts
    any JSON-compatible dict; from Phase 4 forward, it is validated against
    a per-tenant JSON Schema stored in `tenant_schema_overlays`.

    Strictness: `extra='forbid'` rejects unknown top-level fields. Tenant-
    specific data goes in `extensions`, never as a top-level addition. This
    is what makes "wrong format" bugs surface at the API boundary instead of
    halfway through Celery task execution.
    """

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
    )

    extensions: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Tenant-specific overlay fields. Validated against a per-tenant "
            "JSON Schema in Phase 4. Until then, accepts any dict."
        ),
    )
