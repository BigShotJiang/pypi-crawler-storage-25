# `common/schemas/` — Tier 2 Pydantic schemas

This directory holds the canonical content schemas for what goes IN the
universal config tables (Tier 1, defined as schema YAML and loaded by
`common/models/factory.py`). Each schema is a Pydantic v2 model that is the
single source of truth, used by:

- the validate-on-upsert API endpoint
- the Ranger UI (form generation)
- Claude skills (authoring assistance and validation steps)
- the `timber validate` CLI

## The three-tier model (one paragraph recap)

Tier 1 = table definitions (YAML, slow-changing, defined once). Tier 2 = the
content of those tables (THIS DIRECTORY) — Pydantic-validated, DB-stored, the
universal shape of every workflow / model / agent / etc. Tier 3 = per-tenant
overlay schemas that extend Tier 2 via the `extensions` field, for tenant-
specific custom fields. Tier 3 ships in Phase 4.

See `ranger/docs/architecture/yaml-vs-pydantic-strategy.md` for the full
rationale.

## What's here today

| Schema                | File           | Status |
|-----------------------|----------------|--------|
| `WorkflowDefinition`  | `workflow.py`  | Phase 1.2 — current |
| `ModelDefinition`     | (planned)      | Phase 4.2 |
| `StateMachineDefinition` | (planned)   | Phase 4.3 |
| `AgentDefinition`     | (planned)      | Phase 4.4 |
| `IntegrationDefinition` | (existing in `common/services/integrations/models.py`) | needs migration to this dir |

## Adding a new schema

1. Create `common/schemas/<capability>.py`.
2. Subclass `ConfigContent` from `base.py`. This gives you `extra='forbid'`
   strictness and the `extensions: dict[str, Any] | None` field for free.
3. Use `field_validator` for single-field rules and `model_validator(mode='after')`
   for cross-field invariants. Be specific in error messages — name the field,
   show the bad value, suggest the fix.
4. Re-export from `__init__.py`.
5. Add tests under `tests/schemas/test_<capability>.py`. Cover at least:
   - the minimal valid case
   - one rejection per validator
   - extensions field round-trip
   - unknown top-level field is rejected
6. Add to the migration table above.
7. (Phase 1.4 onwards) Author a Claude skill in `timber/.claude/skills/` that
   references the model.

## Why every schema gets `extra='forbid'`

The bug class we're closing — "workflow YAML in wrong format" — is almost
always a typo or a renamed field that the runtime silently ignored. Strict
mode raises at the API boundary with the exact unknown field name. Tenant
extensibility is preserved through the `extensions` field, which IS lax by
design.
