"""Pydantic models for A2UI directives.

See ``architecture/ARCHITECTURE_A2UI.md`` for the protocol design.

An A2UI directive is a structured payload the agent attaches to its
text response to instruct the chat client to render a piece of UI
inline. The client matches on ``kind`` and falls back gracefully on
unknown kinds.

All v1 kinds:

  - ``render_workflow_screen``  — a screen from a Grove workflow session

Adding a kind: define a new ``Spec*`` model + a new ``Submit*``
model + a new entry in :class:`A2UIDirective.kind` enum. Keep
shapes flat and human-readable — the LLM may need to inspect them
during multi-turn reasoning.
"""

from __future__ import annotations

import uuid
from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


# ----------------------------------------------------------------------
# Form-field primitives (shared across directive kinds)
# ----------------------------------------------------------------------


class FormFieldOption(BaseModel):
    """One option in a select/radio/checkbox group."""

    model_config = ConfigDict(extra="forbid")

    value: str
    label: str
    description: Optional[str] = None


class FormField(BaseModel):
    """One input field in a rendered form."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Submit-payload key for this field's value.")
    type: Literal[
        "text",
        "textarea",
        "number",
        "email",
        "radio",
        "select",
        "checkbox",
        "date",
        "hidden",
    ]
    label: str
    placeholder: Optional[str] = None
    required: bool = False
    default: Any = None
    options: Optional[list[FormFieldOption]] = None
    help_text: Optional[str] = None


# ----------------------------------------------------------------------
# Spec — what to render
# ----------------------------------------------------------------------


class WorkflowScreenSpec(BaseModel):
    """Render-payload for a single Grove workflow waiting-state screen."""

    model_config = ConfigDict(extra="forbid")

    title: str
    subtitle: Optional[str] = None
    description: Optional[str] = None
    form_id: str = Field(
        description=(
            "Identifier of the underlying form (matches ui_form on the "
            "Grove state's on_enter). Lets the client cache renders + "
            "report telemetry per form."
        )
    )
    fields: list[FormField]
    submit_label: str = "Continue"
    cancel_label: Optional[str] = None  # null = no cancel button


# ----------------------------------------------------------------------
# Submit — where the response goes
# ----------------------------------------------------------------------


class AdvanceGroveSessionSubmit(BaseModel):
    """Submit the form's payload to advance a Grove workflow session.

    The client POSTs to its acorn-facing endpoint with the form
    values + this submit block; acorn (or sky's BFF) translates that
    into a Grove ``advance_session`` call.
    """

    model_config = ConfigDict(extra="forbid")

    kind: Literal["advance_grove_session"] = "advance_grove_session"
    session_id: str
    state: str = Field(
        description="The Grove state this submission satisfies (for safety: "
                    "rejects if the session has moved past this state)."
    )


# Future submit kinds get added here as a discriminated union.
Submit = AdvanceGroveSessionSubmit


# ----------------------------------------------------------------------
# Directive — the top-level wrapper
# ----------------------------------------------------------------------


class A2UIDirective(BaseModel):
    """Top-level A2UI directive attached to an agent chat turn."""

    model_config = ConfigDict(extra="forbid")

    directive_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique id for telemetry + idempotency of submit.",
    )
    version: str = "1"
    kind: Literal["render_workflow_screen"]
    spec: WorkflowScreenSpec
    on_submit: Submit

    # ------------------------------------------------------------------
    # Convenience constructors
    # ------------------------------------------------------------------

    @classmethod
    def workflow_screen(
        cls,
        *,
        title: str,
        fields: list[FormField],
        session_id: str,
        state: str,
        form_id: str,
        subtitle: Optional[str] = None,
        description: Optional[str] = None,
        submit_label: str = "Continue",
    ) -> "A2UIDirective":
        return cls(
            kind="render_workflow_screen",
            spec=WorkflowScreenSpec(
                title=title,
                subtitle=subtitle,
                description=description,
                form_id=form_id,
                fields=fields,
                submit_label=submit_label,
            ),
            on_submit=AdvanceGroveSessionSubmit(
                session_id=session_id,
                state=state,
            ),
        )
