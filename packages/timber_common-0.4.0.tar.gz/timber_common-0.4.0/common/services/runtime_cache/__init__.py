"""Runtime (Redis / Valkey) cache for per-user + per-tenant context.

This is the shared cache layer that agent services use to memoize
frequently-needed lookups (profile, goals, holdings) and to render
compact context blocks into LLM system prompts. Distinct from
``common.services.persistence.cache`` (DB-backed result cache for
market data, etc.) — these are complementary, not overlapping.

Lift history: originally landed in acorn/services/cache/ as a
vertical slice; moved here in timber-common 0.4.0 so canopy and any
future agent service can share the same plumbing + invalidation
channel naming.

Public API:

    valkey_client                    — singleton connection, fail-soft
    UserContextCache                 — read-through cache for the
                                        per-user entity bundle
    UserContextSummary               — compact prompt-block dataclass
    user_context_cache               — module-level singleton
    WorkflowCatalogCache             — caches a remote workflow catalog
    WorkflowSummary                  — descriptor for one workflow
    workflow_catalog_cache           — module-level singleton
    start_invalidator() / stop_     — pubsub subscriber lifecycle
    publish_invalidate(entity, uid) — writer helper for invalidation
"""

from common.services.runtime_cache.invalidator import (
    publish_invalidate,
    start_invalidator,
    stop_invalidator,
)
from common.services.runtime_cache.user_context_cache import (
    UserContextCache,
    UserContextSummary,
    user_context_cache,
)
from common.services.runtime_cache.valkey_client import valkey_client
from common.services.runtime_cache.workflow_catalog_cache import (
    WorkflowCatalogCache,
    WorkflowSummary,
    workflow_catalog_cache,
)

__all__ = [
    "UserContextCache",
    "UserContextSummary",
    "WorkflowCatalogCache",
    "WorkflowSummary",
    "publish_invalidate",
    "start_invalidator",
    "stop_invalidator",
    "user_context_cache",
    "valkey_client",
    "workflow_catalog_cache",
]
