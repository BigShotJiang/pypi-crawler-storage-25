"""Acorn-side cache of grove's workflow catalog.

Wraps ``GET http://grove-api:8000/api/workflow_sessions/available``
behind a Valkey-backed read-through cache + a compact prompt-block
renderer, mirroring the UserContextCache pattern.

Why a cache here:

  - Grove's catalog scan is fast but the trip-through-the-network is
    still 10+ms. Agents check available workflows on every turn (via
    the pre-loaded summary in the system prompt) — caching cuts the
    cost to a single Valkey GET.
  - Invalidation arrives via the same pubsub channel pattern as
    UserContextCache: writers publish ``oak.workflow.changed`` when
    they add/remove/update a workflow, the existing cache invalidator
    subscriber drops the catalog key, the next fetch repopulates.

Why pre-load into the prompt (vs. expose as a tool):

  Same calculus as user-context: the catalog is small (10s of
  workflows, each ~3 lines of summary), but the LLM-decision cost
  of asking "should I call list_available_workflows?" + the
  tool-call round trip dwarfs the token savings of not embedding it.
  Pre-loading lets the model just NAME the workflow when launching:

    "I've started the account_linking_workflow workflow for you..."

  …with no tool call required to pick the name. The tool surface
  STILL exists (launch_grove_workflow) so external MCP clients work,
  and so the model can pass the name through.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import httpx

from common.services.runtime_cache.valkey_client import valkey_client

logger = logging.getLogger(__name__)


_GROVE_API_BASE_URL = os.environ.get("GROVE_API_BASE_URL", "http://grove-api:8000")
_GROVE_API_TIMEOUT_S = float(os.environ.get("GROVE_API_TIMEOUT_S", "5.0"))

_CACHE_KEY = "oak:catalog:workflows"
_CACHE_TTL_S = 300  # 5 min — bounded by pubsub invalidation


@dataclass
class WorkflowSummary:
    """Compact workflow descriptor for the agent prompt + launch flow."""

    name: str
    display_name: str
    description: Optional[str] = None
    workflow_type: str = "standard"
    tags: list[str] = field(default_factory=list)
    required_inputs: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "workflow_type": self.workflow_type,
            "tags": self.tags,
            "required_inputs": self.required_inputs,
        }


class WorkflowCatalogCache:
    """Read-through cache for the workflow catalog."""

    def fetch_all(self) -> list[WorkflowSummary]:
        """Return every workflow currently launchable.

        Order of operations: Valkey → grove HTTP. Fail-soft: on any
        error returns an empty list (agent prompt simply omits the
        workflows block; the tool surface still works since the model
        can pass a name through to grove's POST endpoint, which will
        validate against the live catalog).
        """
        cached = self._read_cache()
        if cached is not None:
            return cached

        try:
            data = self._fetch_from_grove()
        except Exception:
            logger.exception(
                "workflow catalog fetch failed (non-fatal — falling back to empty)"
            )
            return []

        summaries = [
            WorkflowSummary(
                name=w["name"],
                display_name=w.get("display_name") or w["name"],
                description=w.get("description"),
                workflow_type=w.get("workflow_type") or "standard",
                tags=list(w.get("tags") or []),
                required_inputs=list(w.get("required_inputs") or []),
            )
            for w in data.get("workflows", [])
        ]
        self._write_cache(summaries)
        return summaries

    def to_prompt_block(self) -> str:
        """Render the catalog as a compact system-prompt section.

        Designed to fit comfortably into a system prompt — typical
        budget is ~300 tokens for 10 workflows. Includes a hint to
        the model about HOW to launch (so it knows to call
        ``launch_grove_workflow`` rather than free-text answer).
        """
        summaries = self.fetch_all()
        if not summaries:
            return ""

        lines: list[str] = []
        lines.append("AVAILABLE WORKFLOWS")
        lines.append(
            "(You can launch any of these for the user with the "
            "`launch_grove_workflow` tool, passing the `name` exactly.)"
        )
        lines.append("")
        for s in summaries:
            req = (
                f"  inputs: {', '.join(s.required_inputs)}"
                if s.required_inputs
                else ""
            )
            tags = f"  tags: {', '.join(s.tags)}" if s.tags else ""
            desc = f"  — {s.description}" if s.description else ""
            lines.append(f"- {s.name}: {s.display_name}{desc}")
            if req:
                lines.append(req)
            if tags:
                lines.append(tags)
        lines.append("")
        return "\n".join(lines)

    def invalidate(self) -> None:
        """Drop the cached catalog. Called by the pubsub invalidator
        when writers publish ``oak.workflow.changed``."""
        conn = valkey_client.connection()
        if conn is None:
            return
        try:
            conn.delete(_CACHE_KEY)
            logger.info("workflow catalog cache invalidated")
        except Exception:
            logger.exception("workflow catalog cache invalidate failed (non-fatal)")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _read_cache(self) -> Optional[list[WorkflowSummary]]:
        conn = valkey_client.connection()
        if conn is None:
            return None
        try:
            raw = conn.get(_CACHE_KEY)
        except Exception:
            logger.exception("workflow catalog cache read failed (non-fatal)")
            return None
        if raw is None:
            return None
        try:
            data = json.loads(raw)
        except (ValueError, TypeError):
            try:
                conn.delete(_CACHE_KEY)
            except Exception:
                pass
            return None
        return [WorkflowSummary(**item) for item in data]

    def _write_cache(self, summaries: list[WorkflowSummary]) -> None:
        conn = valkey_client.connection()
        if conn is None:
            return
        try:
            conn.setex(
                _CACHE_KEY,
                _CACHE_TTL_S,
                json.dumps([s.to_dict() for s in summaries]),
            )
        except Exception:
            logger.exception("workflow catalog cache write failed (non-fatal)")

    def _fetch_from_grove(self) -> dict:
        url = f"{_GROVE_API_BASE_URL.rstrip('/')}/api/workflow_sessions/available"
        with httpx.Client(timeout=_GROVE_API_TIMEOUT_S) as client:
            resp = client.get(url)
        resp.raise_for_status()
        return resp.json()


# Module-level singleton.
workflow_catalog_cache = WorkflowCatalogCache()
