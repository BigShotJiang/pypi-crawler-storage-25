"""Cache invalidation subscriber.

Background thread that listens on Valkey pubsub channels and drops
the matching cache keys when writers publish "I just changed X".

Channel naming convention:

    oak.cache.invalidate.<entity>.<user_id>     specific user + entity
    oak.cache.invalidate.<entity>.*             all users for an entity (less safe; use sparingly)
    oak.cache.invalidate.*                      everything (admin-only)
    oak.workflow.changed                        global workflow catalog drift

``<entity>`` is one of ``profile`` / ``goals`` / ``holdings`` /
``all``. ``all`` drops the four user keys + the composed summary.

Writers (TODO):
    - canopy on user-profile UPDATE → publish
      ``oak.cache.invalidate.profile.<user_id>``
    - grove on goal CRUD → publish
      ``oak.cache.invalidate.goals.<user_id>``
    - grove on portfolio holding CRUD → publish
      ``oak.cache.invalidate.holdings.<user_id>``
    - grove on workflow add/update/delete → publish
      ``oak.workflow.changed`` (acorn drops its catalog cache so the
      next agent turn sees the new workflow)

Until those hooks land, this subscriber sits idle but consumes the
channel namespace, so adding them later doesn't require any acorn-
side change.

Lifecycle: started by ``start_invalidator()`` once per process,
typically during app startup. Uses a daemon thread so it doesn't
block shutdown.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from common.services.runtime_cache.user_context_cache import user_context_cache
from common.services.runtime_cache.valkey_client import valkey_client

logger = logging.getLogger(__name__)

CHANNEL_PATTERN = "oak.cache.invalidate.*"
WORKFLOW_CHANNEL = "oak.workflow.changed"

_VALID_ENTITIES = {"profile", "goals", "holdings", "all"}


class CacheInvalidator:
    """Subscribes to invalidation events and drops cache keys.

    Thread-safe singleton (one subscriber per process). Idempotent
    start — calling ``start()`` twice is a no-op.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._started = False

    def start(self) -> None:
        with self._lock:
            if self._started:
                return
            self._started = True
            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._run,
                name="cache-invalidator",
                daemon=True,
            )
            self._thread.start()
            logger.info(
                "Cache invalidator started — listening on %s", CHANNEL_PATTERN
            )

    def stop(self, timeout: float = 5.0) -> None:
        with self._lock:
            self._stop_event.set()
            t = self._thread
        if t is not None:
            t.join(timeout=timeout)

    # ------------------------------------------------------------------
    # Background loop
    # ------------------------------------------------------------------

    def _run(self) -> None:
        """Subscribe + dispatch loop. Reconnects with backoff on errors.

        Cache invalidation is best-effort: a dropped message is fine
        because TTLs are the consistency floor. We log noisily on
        failures but never raise out of the thread.
        """
        backoff_s = 1.0
        while not self._stop_event.is_set():
            conn = valkey_client.connection()
            if conn is None:
                logger.warning(
                    "Cache invalidator: Valkey unavailable, retrying in %.0fs",
                    backoff_s,
                )
                if self._stop_event.wait(backoff_s):
                    return
                backoff_s = min(backoff_s * 2, 30.0)
                # Force re-connect attempt on next iteration.
                valkey_client.reset()
                continue

            try:
                pubsub = conn.pubsub(ignore_subscribe_messages=True)
                pubsub.psubscribe(CHANNEL_PATTERN)
                # Also subscribe to the workflow catalog drift channel.
                # ``subscribe`` (not psubscribe) — this is an exact-name match.
                pubsub.subscribe(WORKFLOW_CHANNEL)
                backoff_s = 1.0
                while not self._stop_event.is_set():
                    # 1-second timeout so stop_event is responsive.
                    msg = pubsub.get_message(timeout=1.0)
                    if msg is not None:
                        self._dispatch(msg)
            except Exception:
                logger.exception(
                    "Cache invalidator: pubsub loop crashed, reconnecting in %.0fs",
                    backoff_s,
                )
                if self._stop_event.wait(backoff_s):
                    return
                backoff_s = min(backoff_s * 2, 30.0)
                valkey_client.reset()

    def _dispatch(self, msg: dict) -> None:
        """Handle one pubsub message.

        Dispatches by channel:
          - ``oak.workflow.changed``                → workflow catalog cache invalidate
          - ``oak.cache.invalidate.<entity>.<uid>`` → user context cache invalidate

        Malformed channels are logged at WARNING and dropped.
        """
        channel = msg.get("channel")
        if channel is None:
            return
        if isinstance(channel, bytes):
            channel = channel.decode("utf-8", errors="replace")

        if channel == WORKFLOW_CHANNEL:
            self._invalidate_workflow_catalog()
            return

        parts = channel.split(".")
        # Expect: ["oak", "cache", "invalidate", "<entity>", "<user_id>"]
        if len(parts) < 5 or parts[0] != "oak" or parts[2] != "invalidate":
            logger.warning("invalidator: ignoring malformed channel %r", channel)
            return

        entity = parts[3]
        user_id = ".".join(parts[4:])  # tolerant of user_ids containing dots

        if entity not in _VALID_ENTITIES:
            logger.warning(
                "invalidator: unknown entity %r on channel %r", entity, channel
            )
            return

        target_entity = None if entity == "all" else entity
        try:
            user_context_cache.invalidate(user_id, target_entity)
        except Exception:
            logger.exception(
                "invalidator: dropping keys failed for user=%s entity=%s",
                user_id,
                entity,
            )

    def _invalidate_workflow_catalog(self) -> None:
        # Imported lazily to avoid an import cycle with the cache pkg
        # init. The catalog cache lives in the same package but is
        # initialized after the invalidator module is imported.
        try:
            from common.services.runtime_cache.workflow_catalog_cache import workflow_catalog_cache

            workflow_catalog_cache.invalidate()
        except Exception:
            logger.exception(
                "invalidator: workflow catalog invalidation failed (non-fatal)"
            )


# Module-level singleton.
_invalidator = CacheInvalidator()


def start_invalidator() -> None:
    """Start the background invalidator. Idempotent."""
    _invalidator.start()


def stop_invalidator(timeout: float = 5.0) -> None:
    """Stop the background invalidator (for graceful shutdown / tests)."""
    _invalidator.stop(timeout=timeout)


def publish_invalidate(entity: str, user_id: str) -> bool:
    """Helper for writers: publish an invalidation event.

    Returns True if published (or best-effort sent), False if Valkey
    was unavailable. Writers should NOT block on this — invalidation
    is opportunistic.
    """
    if entity not in _VALID_ENTITIES:
        raise ValueError(
            f"entity must be one of {sorted(_VALID_ENTITIES)}, got {entity!r}"
        )
    conn = valkey_client.connection()
    if conn is None:
        return False
    channel = f"oak.cache.invalidate.{entity}.{user_id}"
    try:
        conn.publish(channel, "1")
        return True
    except Exception:
        logger.exception("invalidator publish failed (non-fatal)")
        return False
