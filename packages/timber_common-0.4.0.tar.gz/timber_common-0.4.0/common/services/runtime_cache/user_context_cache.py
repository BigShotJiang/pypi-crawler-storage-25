"""Per-user context cache (profile + goals + portfolio holdings).

Architecture:

  - Cache keys are namespaced ``oak:user:<user_id>:<entity>`` so
    invalidation can target one entity without dropping the whole
    user's cache.
  - Values are JSON-encoded bytes.
  - Each entity has its own TTL — profile changes rarely (1 hour),
    goals occasionally (5 minutes), holdings frequently (1 minute,
    since prices in display calculations move).
  - Cache-miss callbacks load from Timber (Postgres) and write-through.
  - Invalidation is **pubsub-driven**: writers (canopy on profile
    update, grove on goal change, etc.) publish to the channel
    ``oak.cache.invalidate.<entity>.<user_id>``. A background
    subscriber (started by the orchestrator) drops the affected key.

Token efficiency:

  The orchestrator typically wants a COMPACT SUMMARY of user
  context to embed in the system prompt (saves a tool-call round
  trip every conversation). For that, callers use
  :meth:`UserContextCache.get_summary(user_id)` which returns a
  :class:`UserContextSummary` — pre-trimmed fields, no DB columns
  like timestamps, no nested structures the model doesn't care
  about. Detailed lookups still go through the per-entity getters.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from common.services.runtime_cache.valkey_client import valkey_client

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# Cache key conventions + TTLs
# ----------------------------------------------------------------------

_KEY_PREFIX = "oak:user"
_TTL_PROFILE = 3600          # 1 hour
_TTL_GOALS = 300             # 5 minutes
_TTL_HOLDINGS = 60           # 1 minute
_TTL_SUMMARY = 60            # 1 minute (rebuilt from underlying entities)


def _key(user_id: str, entity: str) -> str:
    return f"{_KEY_PREFIX}:{user_id}:{entity}"


# ----------------------------------------------------------------------
# Summary dataclass — the compact payload pre-loaded into agent context
# ----------------------------------------------------------------------


@dataclass
class UserContextSummary:
    """Pre-trimmed user context for embedding in the agent system prompt.

    Designed to be **token-efficient**: no IDs the model doesn't need,
    no timestamps, no nested DB-row noise. Roughly 200-500 tokens for
    a typical user with a few goals + ~10 holdings.
    """

    user_id: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    roles: list[str] = field(default_factory=list)
    goals: list[dict] = field(default_factory=list)
    holdings: list[dict] = field(default_factory=list)
    portfolio_value_estimate: Optional[float] = None
    generated_at: float = 0.0  # epoch seconds

    def to_prompt_block(self) -> str:
        """Render as a human-readable block for the system prompt.

        This is what gets injected into the orchestrator's Jinja
        template. Designed to be self-explanatory to the model with
        no extra instructions.
        """
        lines: list[str] = []
        lines.append("USER CONTEXT")
        name = self.display_name or self.user_id
        lines.append(f"Name: {name}")
        if self.email:
            lines.append(f"Email: {self.email}")
        if self.roles:
            lines.append(f"Roles: {', '.join(self.roles)}")

        if self.goals:
            lines.append("")
            lines.append(f"Active goals ({len(self.goals)}):")
            for g in self.goals:
                tgt = g.get("target_amount")
                cur = g.get("current_amount") or 0
                name = g.get("name") or g.get("description") or f"goal #{g.get('id')}"
                pct = f"{(cur / tgt * 100):.0f}%" if tgt else "?"
                lines.append(f"  - {name}: ${cur:,.0f} / ${tgt:,.0f} ({pct})")

        if self.holdings:
            lines.append("")
            lines.append(f"Holdings ({len(self.holdings)} positions):")
            # Top 5 by total cost basis * shares (proxy for size).
            top = sorted(
                self.holdings,
                key=lambda h: (h.get("total_shares", 0) or 0)
                * (h.get("average_cost_basis", 0) or 0),
                reverse=True,
            )[:5]
            for h in top:
                sym = h.get("stock_symbol", "?")
                shares = h.get("total_shares", 0) or 0
                cost = h.get("average_cost_basis", 0) or 0
                lines.append(f"  - {sym}: {shares:g} sh @ ${cost:,.2f} avg cost")
            if len(self.holdings) > 5:
                lines.append(f"  ... and {len(self.holdings) - 5} more")

        if self.portfolio_value_estimate is not None:
            lines.append("")
            lines.append(
                f"Approx portfolio value: ${self.portfolio_value_estimate:,.0f}"
            )

        lines.append("")
        lines.append(
            "(This context is auto-loaded — you can answer questions about "
            "the user's goals, holdings, and profile WITHOUT calling tools. "
            "Call tools only when you need detail beyond what's shown here.)"
        )
        return "\n".join(lines)


# ----------------------------------------------------------------------
# Cache class
# ----------------------------------------------------------------------


class UserContextCache:
    """Read-through cache for user profile/goals/holdings.

    Loaders are injected so this class doesn't need to know about
    Timber internals. Each ``get_*`` method takes an optional
    ``loader`` callable used on cache-miss. The default loaders
    (assigned in ``__init__``) wrap the existing tool functions.
    """

    def __init__(
        self,
        *,
        profile_loader: Optional[Callable[[str], Optional[dict]]] = None,
        goals_loader: Optional[Callable[[str], list[dict]]] = None,
        holdings_loader: Optional[Callable[[str], list[dict]]] = None,
    ) -> None:
        # Loaders default to None; resolved lazily on first use to
        # avoid an import-cycle with the tool modules.
        self._profile_loader = profile_loader
        self._goals_loader = goals_loader
        self._holdings_loader = holdings_loader

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_profile(self, user_id: str) -> Optional[dict]:
        return self._read_through(
            key=_key(user_id, "profile"),
            ttl=_TTL_PROFILE,
            load=lambda: self._resolve_profile_loader()(user_id),
        )

    def get_goals(self, user_id: str) -> list[dict]:
        result = self._read_through(
            key=_key(user_id, "goals"),
            ttl=_TTL_GOALS,
            load=lambda: self._resolve_goals_loader()(user_id),
        )
        return result or []

    def get_holdings(self, user_id: str) -> list[dict]:
        result = self._read_through(
            key=_key(user_id, "holdings"),
            ttl=_TTL_HOLDINGS,
            load=lambda: self._resolve_holdings_loader()(user_id),
        )
        return result or []

    def get_summary(self, user_id: str) -> UserContextSummary:
        """Compose a :class:`UserContextSummary` from cached entities.

        Memoizes the composed summary under its own short TTL so
        repeat calls during a conversation don't re-render. Per-
        entity caches still get their own (longer) TTL so the
        summary's freshness is bounded by the freshest entity.
        """
        summary_key = _key(user_id, "summary")
        cached = self._cache_read_json(summary_key)
        if cached is not None:
            return _summary_from_dict(cached)

        profile = self.get_profile(user_id) or {}
        goals = self.get_goals(user_id)
        holdings = self.get_holdings(user_id)

        summary = UserContextSummary(
            user_id=user_id,
            display_name=profile.get("name") or profile.get("display_name"),
            email=profile.get("email"),
            roles=list(profile.get("roles") or []),
            goals=goals,
            holdings=holdings,
            portfolio_value_estimate=_estimate_portfolio_value(holdings),
            generated_at=time.time(),
        )
        self._cache_write_json(summary_key, _summary_to_dict(summary), _TTL_SUMMARY)
        return summary

    # ------------------------------------------------------------------
    # Invalidation
    # ------------------------------------------------------------------

    def invalidate(self, user_id: str, entity: Optional[str] = None) -> None:
        """Drop the cached value(s) for a user.

        ``entity`` is one of ``profile`` / ``goals`` / ``holdings`` /
        ``summary``, or ``None`` to drop all four (a "burn the user's
        cache" call). The summary key is always dropped when any
        underlying entity is invalidated.
        """
        conn = valkey_client.connection()
        if conn is None:
            return
        if entity is None:
            entities = ("profile", "goals", "holdings", "summary")
        else:
            entities = (entity, "summary")
        try:
            conn.delete(*[_key(user_id, e) for e in entities])
            logger.info("cache invalidated: user=%s entities=%s", user_id, entities)
        except Exception:
            logger.exception("cache invalidate failed (non-fatal)")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _read_through(
        self,
        *,
        key: str,
        ttl: int,
        load: Callable[[], Any],
    ) -> Any:
        cached = self._cache_read_json(key)
        if cached is not None:
            return cached
        # Cache miss: load from DB, write-through.
        try:
            value = load()
        except Exception:
            logger.exception("cache loader failed for key=%s", key)
            return None
        if value is not None:
            self._cache_write_json(key, value, ttl)
        return value

    def _cache_read_json(self, key: str) -> Any:
        conn = valkey_client.connection()
        if conn is None:
            return None
        try:
            raw = conn.get(key)
        except Exception:
            logger.exception("cache read failed for key=%s (non-fatal)", key)
            return None
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            logger.warning("cache value at %s was not valid JSON; dropping", key)
            try:
                conn.delete(key)
            except Exception:
                pass
            return None

    def _cache_write_json(self, key: str, value: Any, ttl: int) -> None:
        conn = valkey_client.connection()
        if conn is None:
            return
        try:
            conn.setex(key, ttl, json.dumps(value, default=str))
        except Exception:
            logger.exception("cache write failed for key=%s (non-fatal)", key)

    # ----- lazy loader resolution (avoids import cycles) -----

    def _resolve_profile_loader(self) -> Callable[[str], Optional[dict]]:
        if self._profile_loader is None:
            self._profile_loader = _default_profile_loader
        return self._profile_loader

    def _resolve_goals_loader(self) -> Callable[[str], list[dict]]:
        # On the timber-common side we don't ship a default loader —
        # each consumer (acorn, future canopy, etc.) injects its own
        # via the constructor since the goal-storage schema is
        # consumer-specific. Raise a clear error if a loader is
        # needed and none was provided.
        if self._goals_loader is None:
            self._goals_loader = lambda uid: _raise_no_loader("goals_loader")
        return self._goals_loader

    def _resolve_holdings_loader(self) -> Callable[[str], list[dict]]:
        if self._holdings_loader is None:
            self._holdings_loader = lambda uid: _raise_no_loader("holdings_loader")
        return self._holdings_loader


# ----------------------------------------------------------------------
# Default loaders
# ----------------------------------------------------------------------


def _raise_no_loader(name: str):
    raise RuntimeError(
        f"UserContextCache.{name} was not injected. timber-common ships "
        "no default for consumer-specific schemas (goals, holdings) — "
        "pass goals_loader= / holdings_loader= to the constructor."
    )


def _default_profile_loader(user_id: str) -> Optional[dict]:
    """Load a user row from Timber's users table.

    Returns a small dict (no password hash, no JSON columns the model
    won't use). Falls back to None on missing user / DB failure.
    """
    from common.services.db_service import db_service
    from sqlalchemy import text

    session = db_service.get_session()
    try:
        row = session.execute(
            text(
                """
                SELECT id, email, name, roles, subscription_tier,
                       is_active, is_verified
                FROM users
                WHERE id = :uid
                """
            ),
            {"uid": user_id},
        ).mappings().first()
        if not row:
            return None
        return {
            "id": row["id"],
            "email": row["email"],
            "name": row["name"],
            "roles": row["roles"] or [],
            "subscription_tier": row["subscription_tier"],
            "is_active": row["is_active"],
            "is_verified": row["is_verified"],
        }
    except Exception:
        logger.exception("profile loader failed for user_id=%s", user_id)
        return None
    finally:
        try:
            session.close()
        except Exception:
            pass


# ----------------------------------------------------------------------
# Summary (de)serialization
# ----------------------------------------------------------------------


def _summary_to_dict(s: UserContextSummary) -> dict:
    return {
        "user_id": s.user_id,
        "display_name": s.display_name,
        "email": s.email,
        "roles": s.roles,
        "goals": s.goals,
        "holdings": s.holdings,
        "portfolio_value_estimate": s.portfolio_value_estimate,
        "generated_at": s.generated_at,
    }


def _summary_from_dict(d: dict) -> UserContextSummary:
    return UserContextSummary(
        user_id=d["user_id"],
        display_name=d.get("display_name"),
        email=d.get("email"),
        roles=list(d.get("roles") or []),
        goals=list(d.get("goals") or []),
        holdings=list(d.get("holdings") or []),
        portfolio_value_estimate=d.get("portfolio_value_estimate"),
        generated_at=d.get("generated_at") or 0.0,
    )


def _estimate_portfolio_value(holdings: list[dict]) -> Optional[float]:
    """Cost-basis estimate (sum of shares * avg_cost). Not market price.

    The model knows this is "approx" from the prompt block wording.
    Computing a real value would need current quotes which we don't
    cache here (prices change too fast and have their own pipeline).
    """
    if not holdings:
        return None
    total = 0.0
    for h in holdings:
        shares = h.get("total_shares") or 0
        cost = h.get("average_cost_basis") or 0
        try:
            total += float(shares) * float(cost)
        except (ValueError, TypeError):
            continue
    return round(total, 2) if total > 0 else None


# Module-level singleton.
user_context_cache = UserContextCache()
