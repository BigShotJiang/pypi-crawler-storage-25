"""Valkey/Redis client singleton for the cache layer.

Acorn's stack uses Valkey 7.2 in local + DigitalOcean Managed Cache in
prod. Wire-compatible with Redis client libraries, so we use the
`redis-py` package the rest of the stack already depends on.

Connection lifecycle:
  - Lazy: first call to ``valkey_client.connection()`` initializes.
  - Singleton: one connection pool per process.
  - Fail-soft: if Valkey is unreachable, the cache layer returns
    ``None`` to indicate cache-miss; callers fall through to DB.
    A connection error is NOT fatal to the agent — caching is an
    optimization, not a correctness requirement.

Env vars (resolution order):
  ``CACHE_REDIS_URL`` (preferred, full DSN) ->
  ``REDIS_URL`` ->
  ``redis://valkey:6379/0`` (default — matches the local compose)
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Optional

import redis

logger = logging.getLogger(__name__)


class _ValkeyClient:
    """Thread-safe Valkey/Redis connection singleton."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._client: Optional[redis.Redis] = None
        self._connection_ok: Optional[bool] = None

    def _resolve_url(self) -> str:
        return (
            os.environ.get("CACHE_REDIS_URL")
            or os.environ.get("REDIS_URL")
            or "redis://valkey:6379/0"
        )

    def connection(self) -> Optional[redis.Redis]:
        """Return a connected Redis client, or None if unavailable.

        Caches the unavailability result for the lifetime of the
        process so we don't spam connect attempts in a hot loop. To
        retry connectivity after a known-down period, call
        :meth:`reset()`.
        """
        if self._connection_ok is False:
            return None
        if self._client is not None:
            return self._client

        with self._lock:
            if self._client is not None:
                return self._client
            if self._connection_ok is False:
                return None
            url = self._resolve_url()
            try:
                client = redis.Redis.from_url(
                    url,
                    socket_timeout=2,
                    socket_connect_timeout=2,
                    health_check_interval=30,
                    decode_responses=False,  # we encode JSON ourselves
                )
                client.ping()
                self._client = client
                self._connection_ok = True
                logger.info("Valkey cache connected at %s", _redact(url))
                return self._client
            except Exception as exc:
                self._connection_ok = False
                logger.warning(
                    "Valkey cache unavailable (%s); falling back to "
                    "uncached DB reads",
                    exc,
                )
                return None

    def reset(self) -> None:
        """Drop the cached connection state and retry on next access."""
        with self._lock:
            try:
                if self._client is not None:
                    self._client.close()
            except Exception:
                pass
            self._client = None
            self._connection_ok = None


def _redact(url: str) -> str:
    """Strip credentials from a Redis URL for logging."""
    try:
        from urllib.parse import urlparse, urlunparse

        u = urlparse(url)
        if u.password:
            netloc = f"{u.username}:***@{u.hostname}"
            if u.port:
                netloc += f":{u.port}"
            return urlunparse((u.scheme, netloc, u.path, u.params, u.query, u.fragment))
    except Exception:
        pass
    return url


valkey_client = _ValkeyClient()
