"""A2A client — call other A2A-compliant agents over HTTP.

Complements ``services/agent_card_service.py`` (which exposes acorn's
OWN agents as A2A cards). This is the caller side: when one of
acorn's agents wants to delegate to another A2A agent (could be a
remote service, another acorn instance, a third-party agent), it
calls through here.

Wire format (per Google A2A v0.1):

  GET  /.well-known/agent-card.json
       Discovery — returns the agent's capability card.

  POST /tasks/send
       Body: { "task": { "id": "...", "messages": [...] }, ... }
       Response: stream of events terminated by a final task object.

For the vertical slice we implement the unary (non-streaming) ``send``
path. Streaming arrives with the A2UI work — see ARCHITECTURE_A2UI.md.

Architectural intent: as oracle / catalyst / future agents are
extracted from acorn's in-process orchestrator into their own
deployable services, the orchestrator's ``_run_oracle_agent`` /
``_run_catalyst_agent`` switch from direct Python calls to
``a2a_client.send_task(...)``. Today both paths coexist:

  - In-process (fast, current behavior) for tightly-coupled agents
  - A2A HTTP (slower per-call, independently deployable) for
    agents that are operationally separate

Choose in-process when latency + co-location matter; choose A2A
when independent scaling, language polyglot, or cross-org delegation
matter.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# Result + exception types
# ----------------------------------------------------------------------


class A2AError(Exception):
    """Raised when an A2A call fails in a way the caller should handle."""


class A2ADiscoveryError(A2AError):
    """Couldn't fetch / parse the remote agent's card."""


class A2ATaskError(A2AError):
    """The remote agent rejected or failed the task."""


@dataclass
class A2AAgentCard:
    """Subset of the A2A agent card that acorn cares about.

    Kept narrow on purpose — we only consume the fields needed to
    dispatch a task. The full A2A card spec carries auth metadata,
    rate limits, etc. that we'll add as we need them.
    """

    agent_id: str
    name: str
    description: str
    base_url: str
    capabilities: list[str] = field(default_factory=list)
    raw: dict = field(default_factory=dict)


@dataclass
class A2ATaskResult:
    """What an A2A ``send_task`` returns."""

    task_id: str
    status: str  # "completed" / "failed" / "in_progress"
    output_text: Optional[str] = None
    artifacts: list[dict] = field(default_factory=list)
    raw: dict = field(default_factory=dict)


# ----------------------------------------------------------------------
# Client
# ----------------------------------------------------------------------


class A2AClient:
    """Thin HTTP client for A2A agent calls.

    Stateless — one shared instance per process via the module-level
    ``a2a_client`` singleton at the bottom. Tests instantiate their
    own with a mock ``httpx.Client``.
    """

    DEFAULT_TIMEOUT_S = 30.0

    def __init__(
        self,
        *,
        http_client: Optional[httpx.Client] = None,
        timeout_s: float = DEFAULT_TIMEOUT_S,
    ) -> None:
        self._http = http_client or httpx.Client(timeout=timeout_s)
        self._timeout_s = timeout_s

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def discover(self, base_url: str) -> A2AAgentCard:
        """Fetch ``<base_url>/.well-known/agent-card.json`` and parse."""
        base_url = base_url.rstrip("/")
        url = f"{base_url}/.well-known/agent-card.json"
        try:
            resp = self._http.get(url)
            resp.raise_for_status()
            raw = resp.json()
        except Exception as exc:
            raise A2ADiscoveryError(
                f"failed to discover agent at {url}: {exc}"
            ) from exc

        try:
            return A2AAgentCard(
                agent_id=raw.get("id") or raw.get("agent_id") or "?",
                name=raw.get("name", "unknown"),
                description=raw.get("description", ""),
                base_url=base_url,
                capabilities=list(raw.get("capabilities") or []),
                raw=raw,
            )
        except Exception as exc:
            raise A2ADiscoveryError(
                f"agent card at {url} missing required fields: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Send (unary)
    # ------------------------------------------------------------------

    def send_task(
        self,
        *,
        base_url: str,
        user_message: str,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        context: Optional[dict] = None,
        task_id: Optional[str] = None,
        extra_headers: Optional[dict[str, str]] = None,
    ) -> A2ATaskResult:
        """Send a task to a remote A2A agent and return the result.

        Args:
            base_url:      Agent root (without /tasks/send).
            user_message:  The user-facing prompt or instruction.
            user_id:       Optional caller identity (propagated in metadata).
            tenant_id:     Optional tenant scope (propagated).
            context:       Free-form context dict the remote agent may use.
            task_id:       Override the random task id (idempotency).
            extra_headers: Auth tokens etc. (e.g. Bearer JWT).
        """
        base_url = base_url.rstrip("/")
        url = f"{base_url}/tasks/send"
        tid = task_id or str(uuid.uuid4())

        payload = {
            "task": {
                "id": tid,
                "messages": [
                    {"role": "user", "content": user_message},
                ],
                "metadata": {
                    "user_id": user_id,
                    "tenant_id": tenant_id,
                    "context": context or {},
                    "sent_at": int(time.time()),
                },
            }
        }

        try:
            resp = self._http.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json", **(extra_headers or {})},
            )
            resp.raise_for_status()
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            raise A2ATaskError(
                f"A2A task {tid} HTTP {exc.response.status_code} at {url}: "
                f"{exc.response.text[:200]}"
            ) from exc
        except Exception as exc:
            raise A2ATaskError(f"A2A task {tid} failed at {url}: {exc}") from exc

        return _parse_task_response(raw, tid)


def _parse_task_response(raw: dict, fallback_task_id: str) -> A2ATaskResult:
    """Best-effort parse of a Google-A2A task response.

    The spec leaves some shape flexibility (final message can be at
    ``task.messages[-1]`` or ``result.output_text`` depending on the
    server). We try the common shapes and degrade gracefully.
    """
    task = raw.get("task") or raw.get("result") or raw
    output_text: Optional[str] = task.get("output_text")
    if not output_text:
        msgs = task.get("messages") or []
        if msgs:
            last = msgs[-1]
            output_text = last.get("content") if isinstance(last, dict) else None
    return A2ATaskResult(
        task_id=task.get("id", fallback_task_id),
        status=task.get("status", "completed"),
        output_text=output_text,
        artifacts=list(task.get("artifacts") or []),
        raw=raw,
    )


# Module-level singleton.
a2a_client = A2AClient()
