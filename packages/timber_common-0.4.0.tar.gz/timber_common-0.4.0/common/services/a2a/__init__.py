"""Google A2A protocol client.

Caller-side HTTP client for delegating tasks to A2A-compliant agents.
Acorn already exposes its OWN agents as A2A cards via
``services.agent_card_service`` — this module is the complement:
when one service wants to delegate a task to a remote agent, it uses
:class:`A2AClient`.

See ``acorn/agents/vanguard_orchestrator.py`` for the in-process
fallback pattern: choose in-process for latency + co-location, choose
A2A HTTP for independent scaling / cross-org / polyglot.
"""

from common.services.a2a.client import (
    A2AAgentCard,
    A2AClient,
    A2ADiscoveryError,
    A2AError,
    A2ATaskError,
    A2ATaskResult,
    a2a_client,
)

__all__ = [
    "A2AAgentCard",
    "A2AClient",
    "A2ADiscoveryError",
    "A2AError",
    "A2ATaskError",
    "A2ATaskResult",
    "a2a_client",
]
