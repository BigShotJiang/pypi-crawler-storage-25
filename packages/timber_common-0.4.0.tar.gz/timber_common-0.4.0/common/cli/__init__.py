"""Timber command-line interface.

Entry point: ``timber <command> ...``

Defined as a console script in ``pyproject.toml`` (``[tool.poetry.scripts]``).
The dispatcher lives in :mod:`common.cli.main`; individual commands live
under :mod:`common.cli.commands`.
"""
