"""Top-level dispatcher for the ``timber`` CLI.

Subcommands live in :mod:`common.cli.commands`. Each command module exposes
a ``register(subparsers)`` function that adds its parser, and a ``run(args)``
function that executes given parsed args.

Usage:
    timber validate workflow path/to/workflow.yaml
    timber validate <type> <file>
"""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from common.cli.commands import validate as validate_cmd


def build_parser() -> argparse.ArgumentParser:
    """Return the top-level argument parser with all subcommands wired in."""
    parser = argparse.ArgumentParser(
        prog="timber",
        description=(
            "Timber CLI — schema validation, config tooling, and "
            "developer-facing helpers for the Oak monorepo."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    validate_cmd.register(subparsers)
    return parser


def cli(argv: Sequence[str] | None = None) -> int:
    """Console-script entry point. Returns process exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(cli())
