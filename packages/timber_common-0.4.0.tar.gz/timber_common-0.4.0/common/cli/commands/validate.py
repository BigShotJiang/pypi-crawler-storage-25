"""``timber validate <type> <file>`` — validate config content against its Tier 2 Pydantic schema.

The same validator that runs at the API upsert boundary runs here. A clean
exit (code 0) means the file would be accepted by the upsert endpoint.
A non-zero exit means it would be rejected and prints precise field-path
errors.

Used by:
  * Developers, locally, to check workflow files before committing.
  * The ``grove-workflow`` Claude skill, which instructs Claude to invoke
    this before declaring workflow edits done.
  * CI (Phase 5.3) on every PR that touches workflow files.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# Mapping of "type name" → Pydantic content schema. New schemas register
# themselves here when they ship.
_TYPE_REGISTRY: dict[str, type] = {}


def _register_default_types() -> None:
    """Lazily register schemas the first time the command runs.

    Imported lazily so `timber --help` doesn't pay the import cost of every
    schema, and so a broken schema in one module doesn't prevent unrelated
    commands from working.
    """
    if _TYPE_REGISTRY:
        return
    from common.schemas.workflow import WorkflowDefinition

    _TYPE_REGISTRY["workflow"] = WorkflowDefinition


def register(subparsers: argparse._SubParsersAction) -> None:
    """Wire the validate command into the top-level parser."""
    parser = subparsers.add_parser(
        "validate",
        help="Validate a config file against its Tier 2 Pydantic schema.",
        description=(
            "Validate a YAML or JSON file against the canonical Tier 2 "
            "Pydantic schema for the given type. Exits 0 on success, 1 on "
            "validation errors, 2 on file/parse errors."
        ),
    )
    parser.add_argument(
        "type",
        help="Schema type to validate against (e.g. 'workflow').",
    )
    parser.add_argument(
        "file",
        type=Path,
        help="Path to the YAML/JSON file to validate.",
    )
    parser.add_argument(
        "--list-types",
        action="store_true",
        help="List the registered schema types and exit.",
    )
    parser.set_defaults(func=run)


def run(args: argparse.Namespace) -> int:
    """Execute the validate command. Returns process exit code."""
    _register_default_types()

    if args.list_types:
        for name in sorted(_TYPE_REGISTRY):
            print(name)
        return 0

    schema_type = args.type
    if schema_type not in _TYPE_REGISTRY:
        known = ", ".join(sorted(_TYPE_REGISTRY)) or "(none registered)"
        print(
            f"error: unknown type {schema_type!r}. Known types: {known}",
            file=sys.stderr,
        )
        return 2

    try:
        content = _load_file(args.file)
    except FileNotFoundError:
        print(f"error: file not found: {args.file}", file=sys.stderr)
        return 2
    except ValueError as exc:
        print(f"error: could not parse {args.file}: {exc}", file=sys.stderr)
        return 2

    schema_cls = _TYPE_REGISTRY[schema_type]
    try:
        schema_cls.model_validate(content)
    except Exception as exc:  # ValidationError or anything Pydantic-side
        print(f"INVALID {args.file} ({schema_type}):", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 1

    print(f"OK   {args.file} ({schema_type})")
    return 0


def _load_file(path: Path) -> Any:
    """Load YAML or JSON based on file extension. Raises ValueError on parse errors."""
    if not path.exists():
        raise FileNotFoundError(str(path))

    text = path.read_text(encoding="utf-8")
    suffix = path.suffix.lower()

    if suffix in {".yaml", ".yml"}:
        try:
            import yaml  # PyYAML — already a timber dep
        except ImportError as exc:  # pragma: no cover
            raise ValueError("PyYAML not installed") from exc
        try:
            return yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ValueError(str(exc)) from exc

    if suffix == ".json":
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(str(exc)) from exc

    raise ValueError(f"unsupported file extension {suffix!r} (expected .yaml/.yml/.json)")
