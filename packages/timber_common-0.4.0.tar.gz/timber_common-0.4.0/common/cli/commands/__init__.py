"""Subcommand modules for the timber CLI.

Each module exposes:
  * ``register(subparsers)`` — adds its parser to the top-level dispatcher.
  * ``run(args)`` — implements the command and returns an int exit code.

Modules are wired into the dispatcher in :mod:`common.cli.main`.
"""
