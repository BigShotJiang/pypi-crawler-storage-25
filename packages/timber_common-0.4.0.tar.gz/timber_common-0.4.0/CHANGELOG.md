# Changelog

All notable changes to Timber will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.0] - 2026-05-12

### Added — Shared agent-runtime modules (lifted from acorn)

These modules originally landed in acorn as a vertical slice. Now they
live here so canopy and any future agent-facing service can share the
same plumbing + invalidation channel naming.

#### `common.services.runtime_cache`

- **Valkey/Redis-backed read-through cache** for per-user context
  (profile / goals / portfolio holdings) keyed under `oak:user:<id>:*`,
  with tiered TTLs (1h profile, 5m goals, 1m holdings, 1m composed
  summary).
- **`UserContextCache.get_summary()`** returns a compact
  `UserContextSummary` whose `to_prompt_block()` renders a token-
  efficient block for embedding in an LLM system prompt. Live-measured
  on the development stack: cold 1295ms → warm 0.1ms (12000× speedup).
- **`WorkflowCatalogCache`** fronts grove's
  `GET /api/workflow_sessions/available` endpoint with a Valkey read-
  through + a `to_prompt_block()` renderer so agents can launch any
  workflow by name without per-workflow code changes.
- **`CacheInvalidator`** background subscriber:
  - `oak.cache.invalidate.<entity>.<user_id>` drops per-user keys
  - `oak.workflow.changed` drops the workflow catalog key
- **`publish_invalidate(entity, user_id)`** helper for writers
  (canopy on profile update, grove on goal/holding mutation, etc.).

Consumer-specific entity loaders (goals, holdings) are NOT shipped
with a default — pass `goals_loader=` / `holdings_loader=` to the
constructor. Profile loader has a default using `db_service`.

#### `common.services.a2a`

- **`A2AClient`** for Google A2A v0.1 caller-side delegation:
  - `discover(base_url)` → fetch `/.well-known/agent-card.json`
  - `send_task(base_url, user_message, ...)` → POST `/tasks/send`
- Unary (non-streaming) only in 0.4.0; streaming arrives with the
  A2UI work.
- Complements `services.agent_card_service` on the producer side.

#### `common.models.a2ui`

- Pydantic v2 models for the A2UI directive protocol:
  - `FormField` / `FormFieldOption` — field-level primitives
  - `WorkflowScreenSpec` — render-payload for one Grove workflow
    waiting-state screen
  - `AdvanceGroveSessionSubmit` — where the form payload goes back
  - `A2UIDirective` — top-level wrapper (version + kind discriminator)
- See `acorn/architecture/ARCHITECTURE_A2UI.md` for protocol design.

### Dependencies

- Added `httpx ^0.28.0` (used by `A2AClient` and `WorkflowCatalogCache`
  for outbound HTTP).

### Migration

Consumers pin `timber-common = "^0.4.0"` and replace local imports:

```
# before (in acorn)
from services.cache import user_context_cache, workflow_catalog_cache
from models.a2ui import A2UIDirective, FormField
from clients.a2a_client import a2a_client

# after
from common.services.runtime_cache import user_context_cache, workflow_catalog_cache
from common.models.a2ui import A2UIDirective, FormField
from common.services.a2a import a2a_client
```

## [0.1.0] - 2025-10-19

### Added - Initial Release

#### Core Features
- **Config-Driven Models**: Define SQLAlchemy models using YAML configuration files
- **Dynamic Model Factory**: Automatically generate model classes from YAML at runtime
- **Model Registry**: Global model registry with `get_model()` accessor
- **Relationship Resolution**: Automatic relationship building with dependency management

#### Database Management
- **Connection Pooling**: Optimized PostgreSQL connection pooling with QueuePool
- **Session Management**: Context manager for automatic transaction handling
- **Transaction Support**: Automatic commit/rollback with `session_scope()`
- **Health Checks**: Database connectivity monitoring
- **Migration Support**: Schema evolution with Alembic integration

#### Service Layer
- **Session Service**: Manage user sessions across applications
- **Research Service**: Store and query research data and analysis
- **Notification Service**: User notification system with read tracking
- **Tracker Service**: Event tracking and user activity analytics
- **Stock Data Service**: Financial data fetching from multiple sources

#### Feature Services
- **Encryption Service**: Field-level encryption with Fernet
- **Cache Service**: Multi-level caching (Redis + local)
- **Vector Search Service**: Semantic search with embeddings
- **GDPR Service**: Data export and deletion for compliance

#### Vector Search Integration
- **Automatic Embedding Generation**: Using sentence-transformers
- **Vector Database Support**: Qdrant, Weaviate, Pinecone integration
- **Semantic Search**: Find similar documents by meaning
- **Hybrid Search**: Combine vector and keyword search
- **Batch Processing**: Efficient batch embedding generation

#### Data Sources
- **Yahoo Finance**: Historical and real-time stock data
- **Alpha Vantage**: Company fundamentals and financials
- **Polygon.io**: Market data and news
- **SEC Edgar**: Company filings and documents

#### Security & Compliance
- **Field-Level Encryption**: Automatic encryption of sensitive fields
- **GDPR Compliance**: Data export, deletion, and audit trails
- **Secure Configuration**: Environment variable management
- **Connection Security**: SSL/TLS support for database connections

#### Multi-Application Support
- **Application Context**: Separate contexts for different apps
- **Session Type Filtering**: Isolate data by application
- **Shared Infrastructure**: Common database, cache, and vector store
- **Independent Deployment**: Apps deploy separately

#### Documentation
- **How-To Guides**: Step-by-step instructions for common tasks
  - Getting Started
  - Creating Models
  - Using Services
- **Design Guides**: Architecture and design documentation
  - System Architecture
  - Config-Driven Models
  - Persistence Layer
  - Vector Integration
  - Multi-App Support
- **API Documentation**: Comprehensive API reference
- **Code Examples**: Working examples for all features

#### Developer Tools
- **Type Hints**: Full type annotation support
- **Testing Framework**: pytest integration with fixtures
- **Code Quality**: Black, isort, mypy configuration
- **Error Handling**: Consistent error types and handling patterns

### Technical Details

#### Supported Python Versions
- Python 3.13+

#### Supported Databases
- PostgreSQL 12+
- pgvector extension for vector support

#### Supported Vector Stores
- Qdrant (recommended)
- Weaviate
- Pinecone

#### Embedding Models
- BAAI/bge-small-en-v1.5 (default)
- sentence-transformers/all-MiniLM-L6-v2
- Custom models supported

### Dependencies
- SQLAlchemy 2.0.36+
- PostgreSQL driver (psycopg2-binary)
- Redis 6.4.0+
- Pydantic 2.11.9+
- FastEmbed 0.7.3+
- Cryptography 46.0.2+
- See pyproject.toml for complete dependency list

### Known Limitations
- Requires PostgreSQL (other databases not yet supported)
- Python 3.13+ only
- Vector search requires external vector database

### Breaking Changes
- None (initial release)

### Migration Guide
- None (initial release)

---

## [Unreleased]

### Planned Features
- MySQL and SQLite support
- Built-in vector store option (no external database required)
- GraphQL API generation
- Real-time data streaming
- Advanced analytics dashboard
- CLI tools for model management
- Docker deployment templates
- Kubernetes manifests

---

## Version History

- **0.1.0** (2025-10-19) - Initial public release

---

## Copyright

Copyright (c) 2025 Pumulo Sikaneta. All rights reserved.

This software is released under the MIT License.
See LICENSE file for details.

## Author

**Pumulo Sikaneta**
- Email: pumulo@gmail.com
- GitHub: [@pumulo](https://github.com/pumulo)

## Contributing

Contributions are welcome! Please read CONTRIBUTING.md for guidelines.

## Support

For bugs, feature requests, or questions:
- GitHub Issues: https://github.com/pumulo/timber-common/issues
- Email: pumulo@gmail.com