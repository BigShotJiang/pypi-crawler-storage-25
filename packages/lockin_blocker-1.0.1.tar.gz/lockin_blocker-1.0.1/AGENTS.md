# AGENTS.md — lockin

> For AI coding agents working on this project.

## Setup

```bash
uv sync --extra dev
uv run lockin --help
```

## Rules

1. **TDD always.** Write the test first, watch it fail, then implement.
2. **Conventional commits:** `feat(scope):`, `fix(scope):`, `test(scope):`, `refactor(scope):`, `chore:`.
3. **Don't break the host.** Never run `nft delete table` or `sudo tee /etc/hosts` without explicit approval.
4. **Verify before claiming done.** Run `uv run ruff check . && uv run pytest` after every task.

## Commands

```bash
uv run ruff check .          # lint
uv run ruff check --fix .    # auto-fix
uv run pytest                # all tests
uv run pytest -v -k "name"   # specific test
uv run lockin --help         # CLI help
```

## Architecture

lockin uses `/etc/hosts` + nftables for system-level domain blocking. No proxy, no certs, no browser extensions.

| Module | Responsibility |
|--------|---------------|
| `lockin/cli.py` | Click commands, arg parsing, output formatting |
| `lockin/block.py` | Orchestration: start/stop/status via /etc/hosts + nftables |
| `lockin/hosts.py` | /etc/hosts manager — adds/removes blocked domain entries |
| `lockin/nat.py` | nftables/iptables QUIC sinkhole (UDP 443 drop) |
| `lockin/scheduler.py` | systemd/at/cron/thread unblock scheduling |

## Dependencies

- `click` — CLI framework
- `pyyaml` — rules file parsing
- `ruff`, `pytest` — dev only
