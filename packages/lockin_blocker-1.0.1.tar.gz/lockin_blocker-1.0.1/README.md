# lockin

[![CI](https://github.com/madhusudan-kulkarni/lockin/actions/workflows/ci.yml/badge.svg)](https://github.com/madhusudan-kulkarni/lockin/actions)

Block distracting websites at the system level. No proxy, no certs, no extensions.

lockin writes blocked domains to `/etc/hosts` and blocks QUIC/HTTP3 via nftables. Every app on your system is affected — browsers, terminals, email clients — until the timer expires.

## Install

```bash
pip install lockin-blocker
```

Or with uv:

```bash
uv tool install lockin-blocker
```

Or from source:

```bash
uv tool install git+https://github.com/madhusudan-kulkarni/lockin.git
```

Requires Python ≥3.11, uv, and nftables (or iptables). lockin uses `sudo` for firewall rules and `/etc/hosts` writes.

## Usage

```bash
# Block social media for 2 hours
lockin start --rule social --for 2h

# Only allow coding sites
lockin start --rule coding --for 1h30m

# Block until 5 PM
lockin start --rule social --until 17:00

# Check remaining time
lockin status

# End early
lockin stop
```

| Command | Purpose |
|---------|---------|
| `lockin start --rule <name> --for 30m` | Start a block |
| `lockin start --rule <name> --until 17:00` | Block until a specific time |
| `lockin stop` | End the current block |
| `lockin status` | Show active block and time remaining |
| `lockin list` | List all rules |
| `lockin doctor` | Check installation health |
| `lockin cleanup` | Remove leftover entries from crashes |
| `lockin update` | Upgrade to the latest version |
| `lockin uninstall` | Clean up and print removal instructions |

Durations: `30m`, `2h`, `1h30m`. Times: `17:00`, `9:30pm`.

## How it works

`lockin start --rule social --for 2h` does three things:

1. **Adds domains to `/etc/hosts`** — blocked domains resolve to `127.0.0.2` and `::1`. All apps see the block.
2. **Blocks QUIC/HTTP3** via nftables — rejects UDP 443 so browsers fall back to TCP, where the hosts file takes effect.
3. **Schedules cleanup** via systemd timer (falls back to at → cron → in-process). When time's up, hosts entries are removed and nftables rules are flushed.

Blocked sites show **connection refused**. This is intentional — no cert warnings, no browser errors, nothing to maintain.

## Rules

Rules live in `~/.config/lockin/rules.yaml`. A default file is copied there on first run.

```bash
$EDITOR ~/.config/lockin/rules.yaml
```

```yaml
whitelists:
  coding:
    - github.com
    - stackoverflow.com
    - docs.python.org

blacklists:
  social:
    - twitter.com
    - facebook.com
    - reddit.com
    - youtube.com
```

Whitelist mode blocks everything except the listed domains. Blacklist mode allows everything except the listed domains.

## Troubleshooting

**Sites still load in Firefox** — Firefox uses DNS-over-HTTPS by default, which bypasses `/etc/hosts`. Disable it:

```
Firefox → Settings → Privacy & Security → DNS over HTTPS → Off
```

**Sites still blocked after `lockin stop`** — run `lockin cleanup`.

## Uninstall

```bash
lockin uninstall
```

## License

MIT
