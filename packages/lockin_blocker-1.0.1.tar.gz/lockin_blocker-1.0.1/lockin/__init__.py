"""lockin — Block distracting websites so you can focus."""

__version__ = "1.0.1"
