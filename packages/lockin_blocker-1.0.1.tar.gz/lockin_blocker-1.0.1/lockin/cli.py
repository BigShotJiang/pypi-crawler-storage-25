"""CLI for lockin — block distracting websites so you can focus.

lockin v2 uses /etc/hosts for domain blocking. No proxy, no certs,
no extension. Blocked sites show "connection refused" — honest and zero-maintenance.
"""

import sys

import click

from lockin import __version__
from lockin.block import (
    _cleanup_stale,
    clear_state,
    ensure_user_rules,
    get_rules_path,
    get_state,
    get_status,
    list_rules,
    parse_duration,
    start_block,
    stop_block,
)


@click.group()
@click.version_option(version=__version__, prog_name="lockin")
def main():
    """lockin — block distracting websites so you can focus."""


@main.command()
@click.option(
    "--rule", "-r", required=True, help="Rule name from rules.yaml"
)
@click.option("--for", "-f", "duration", help="Duration: 30m, 2h, 1h30m")
@click.option("--until", "-u", help="End time: 17:00")
def start(rule: str, duration: str, until: str):
    """Start a blocking session."""
    if not duration and not until:
        raise click.UsageError("Must specify --for or --until.")

    try:
        duration_mins = parse_duration(duration) if duration else None
        state = start_block(
            rule_name=rule,
            duration_minutes=duration_mins,
            until_time=until,
        )
        click.echo(
            f"Block '{state['rule_name']}' ({state['block_type']}) "
            f"active until {state['end']}."
        )
        click.echo(
            f"  {len(state['domains'])} domains added to /etc/hosts"
        )
        click.echo("  QUIC/HTTP3 blocked via nftables")
    except FileNotFoundError as e:
        click.echo(str(e), err=True)
        sys.exit(1)
    except (ValueError, RuntimeError) as e:
        msg = str(e)
        if "already active" in msg:
            click.echo(msg, err=True)
            sys.exit(2)
        elif "not found" in msg:
            click.echo(msg, err=True)
            sys.exit(4)
        elif "duration" in msg.lower():
            click.echo(msg, err=True)
            sys.exit(1)
        else:
            click.echo(msg, err=True)
            sys.exit(1)


@main.command()
def stop():
    """Stop the active block and clean up."""
    state = stop_block()
    if state is None:
        click.echo("No active block.", err=True)
        sys.exit(3)
    click.echo(f"Block '{state['rule_name']}' ended. Cleaned up.")


@main.command()
def status():
    """Show status of the active block."""
    output = get_status()
    click.echo(output)


@main.command("list")
def list_rules_cmd():
    """List all available rules."""
    ensure_user_rules()
    rules_path = get_rules_path()
    rules = list_rules(rules_path)
    if not rules:
        click.echo("No rules defined. Edit ~/.config/lockin/rules.yaml")
        return
    click.echo(f"{'RULE':<20} {'TYPE':<12} ADDRESSES")
    click.echo("-" * 50)
    for name, block_type, count in rules:
        click.echo(f"{name:<20} {block_type:<12} {count}")


@main.command(hidden=True)
def reset():
    """Internal: cleanup command called by the scheduler."""
    state = get_state()
    if state:
        _cleanup_stale(state)
        clear_state()


@main.command()
def cleanup():
    """Remove stale /etc/hosts entries, firewall rules, and timers."""
    state = get_state()
    if state:
        click.echo(
            f"Cleaning up stale"
            f" '{state.get('rule_name', 'unknown')}' session..."
        )
        _cleanup_stale(state)
        clear_state()
        click.echo("Done.")
    else:
        click.echo("Nothing to clean up.")


@main.command()
def doctor():
    """Run diagnostic checks on your lockin installation."""
    from lockin.doctor import format_results, run_checks
    click.echo(format_results(run_checks()))


@main.command()
def update():
    """Upgrade lockin to the latest version."""
    import shutil
    import subprocess

    current = __version__
    if shutil.which("uv"):
        cmd = ["uv", "tool", "upgrade", "lockin-blocker"]
    elif shutil.which("pip"):
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "lockin-blocker"]
    else:
        click.echo("Neither uv nor pip found.", err=True)
        sys.exit(1)

    click.echo(f"Upgrading lockin (current: {current})...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        click.echo("Done. Run 'lockin --version' to verify.")
    else:
        click.echo(result.stderr or "Upgrade failed.", err=True)
        sys.exit(1)


@main.command()
def uninstall():
    """Remove lockin and clean up all traces."""
    import shutil

    # First, clean up any active blocks
    state = get_state()
    if state:
        _cleanup_stale(state)
        clear_state()
        click.echo("Cleaned up active block.")

    click.echo()
    click.echo("To complete uninstall, run one of:")

    if shutil.which("uv"):
        click.echo("  uv tool uninstall lockin-blocker")
    if shutil.which("pip") or shutil.which("pip3"):
        click.echo("  pip uninstall lockin-blocker")


if __name__ == "__main__":
    main()
