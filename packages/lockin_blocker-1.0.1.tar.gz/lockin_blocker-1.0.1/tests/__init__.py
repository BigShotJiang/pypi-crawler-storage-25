# Tests for lockin
