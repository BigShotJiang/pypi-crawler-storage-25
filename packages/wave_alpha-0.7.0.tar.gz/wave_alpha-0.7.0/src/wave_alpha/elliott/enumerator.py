from __future__ import annotations

from itertools import pairwise

from wave_alpha.elliott.fib import fib_confluence_score
from wave_alpha.elliott.fib_features import confluence_score, fib_features
from wave_alpha.elliott.models import WaveCount
from wave_alpha.elliott.templates import PatternTemplate, load_bundled_templates
from wave_alpha.elliott.validator import validate
from wave_alpha.pivots.models import PivotEvent

# Score weights — must sum to 1.0
_WEIGHT_BASE = 0.50  # template fit (1 - 0.10 * soft violations)
_WEIGHT_CONFLUENCE = 0.20  # W2-vs-W1 fib confluence
_WEIGHT_RECENCY = 0.30  # how close the candidate's last pivot is to "now"


def enumerate_counts(
    pivots: list[PivotEvent],
    *,
    degree: int,
    top_k: int = 5,
    templates: list[PatternTemplate] | None = None,
) -> list[WaveCount]:
    """Try each template against pivot windows; return top_k by score.

    A swing-trader-friendly ranker: each candidate's score blends template fit,
    fib confluence at W2's retrace, and recency (how close the candidate's last
    pivot is to the latest input pivot). Multiple windows of the same template
    are deduplicated to the highest-scoring one before the global top_k cut, so
    one template family cannot crowd out alternates.
    """
    if not pivots:
        return []
    templates = templates or load_bundled_templates()
    latest_idx = len(pivots) - 1

    best_per_template: dict[str, WaveCount] = {}
    for tpl in templates:
        n_required = len(tpl.waves) + 1  # waves -> n segments need n+1 pivots
        if len(pivots) < n_required:
            continue
        for end_idx in range(len(pivots), n_required - 1, -1):
            window = pivots[end_idx - n_required : end_idx]
            if not _alternates_ok(window):
                continue
            count = WaveCount(pattern=tpl.name, degree=degree, pivots=window)
            count = validate(count, tpl)
            if count.hard_violations:
                continue
            score = _score(count, tpl, last_window_idx=end_idx - 1, latest_idx=latest_idx)
            count = count.model_copy(update={"score": score})

            current = best_per_template.get(tpl.name)
            if current is None or score > current.score:
                best_per_template[tpl.name] = count

    candidates = sorted(best_per_template.values(), key=lambda c: c.score, reverse=True)
    return candidates[:top_k]


def _alternates_ok(window: list[PivotEvent]) -> bool:
    types = [p.type for p in window]
    return all(a != b for a, b in pairwise(types))


def _score(
    count: WaveCount, tpl: PatternTemplate, *, last_window_idx: int, latest_idx: int
) -> float:
    base = 1.0 - 0.10 * len(count.soft_violations)
    confluence = _confluence_bonus(count, tpl)
    recency = _recency_factor(last_window_idx=last_window_idx, latest_idx=latest_idx)
    raw = _WEIGHT_BASE * base + _WEIGHT_CONFLUENCE * confluence + _WEIGHT_RECENCY * recency
    return max(0.0, raw)


def _confluence_bonus(count: WaveCount, tpl: PatternTemplate) -> float:
    """Pattern-aware Fib confluence with generic fallback.

    Curated patterns (impulse, zigzag) use the multi-ratio
    ``fib_features.confluence_score``. Other patterns fall back to the
    legacy single-ratio ``fib_confluence_score(W2, reference=W1)`` so their
    scores stay stable until they're promoted to curated.
    """
    feats = fib_features(count)
    if feats.is_curated_pattern:
        return confluence_score(feats)
    segs = count.segments()
    if len(segs) < 2:
        return 0.0
    return fib_confluence_score(target_price=segs[1].end.price, reference=segs[0])


def _recency_factor(*, last_window_idx: int, latest_idx: int) -> float:
    """1.0 when the window ends at the most recent pivot; decays linearly to 0.2
    over a 16-pivot gap. Old patterns aren't useless, but a swing trader needs
    actionable now-counts ranked above twenty-year-old setups."""
    if latest_idx <= 0:
        return 1.0
    gap = max(0, latest_idx - last_window_idx)
    return max(0.2, 1.0 - 0.05 * gap)
