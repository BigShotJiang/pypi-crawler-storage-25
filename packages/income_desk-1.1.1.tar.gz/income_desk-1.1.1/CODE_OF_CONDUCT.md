# Code of Conduct

## Our Pledge

We are committed to making participation in this project a harassment-free experience for everyone.

## Our Standards

Examples of behavior that contributes to a positive environment:
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

Examples of unacceptable behavior:
- Trolling, insulting, or derogatory comments
- Publishing others' private information (especially trading credentials)
- Other conduct which could reasonably be considered inappropriate

## Enforcement

Project maintainers are responsible for clarifying standards and taking appropriate corrective action.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
