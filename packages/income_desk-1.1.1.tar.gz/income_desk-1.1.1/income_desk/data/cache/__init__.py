"""Parquet-based data cache."""
