from mcp_pymetasploit3 import mcp


def main() -> int:
    """Main entry point for the MCP server."""
    mcp.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
