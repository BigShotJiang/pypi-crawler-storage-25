"""MCP server for Metasploit Framework via pymetasploit3."""

__version__ = "0.1.0"

__all__ = ["mcp", "MsfRpcClient"]

from pymetasploit3.msfrpc import MsfRpcClient

from mcp_pymetasploit3.mcp import msf_mcp as mcp
