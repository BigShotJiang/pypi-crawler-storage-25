# mcp-pymetasploit3

MCP server for Metasploit Framework via pymetasploit3. This server exposes all pymetasploit3 functionality as MCP tools, allowing LLMs to interact with Metasploit Framework through the msfrpc protocol.

[![PyPI](https://img.shields.io/pypi/v/mcp-pymetasploit3.svg)](https://pypi.org/project/mcp-pymetasploit3/)
[![Python](https://img.shields.io/pypi/pyversions/mcp-pymetasploit3.svg)](https://pypi.org/project/mcp-pymetasploit3/)

## Install

```bash
pip install mcp-pymetasploit3
```

## MCP Server Configuration

```json
{
  "mcpServers": {
    "mcp-pymetasploit3": {
      "command": "mcp-pymetasploit3",
      "env": {}
    }
  }
}
```

## Usage

### Starting Metasploit RPC Server

Before using the MCP server, you need to start the Metasploit RPC server:

**Using msfrpcd:**
```bash
msfrpcd -P yourpassword -p 55553 -n
```

**Using msfconsole:**
```bash
msfconsole -q
msf6 > load msgrpc Pass=yourpassword
```

### MCP Tools

Once connected, the following tools are available:

#### Connection Management
- `connect` - Connect to Metasploit RPC server
- `disconnect` - Disconnect from RPC server
- `get_client_info` - Get current connection status

#### Module Management
- `list_modules` - List available modules by type
- `use_module` - Load a specific module
- `get_module_info` - Get module description and info
- `get_module_options` - Get all module options
- `set_module_option` - Set a module option
- `get_missing_required` - Get required options not set
- `execute_module` - Execute a module
- `get_module_targets` - Get available targets
- `set_module_target` - Set the target
- `get_target_payloads` - Get compatible payloads

#### Payload Generation
- `generate_payload` - Generate a payload

#### Session Management
- `list_sessions` - List all active sessions
- `get_session_info` - Get session information
- `interact_session` - Write/read from session
- `session_run_command` - Run command with output
- `stop_session` - Stop a session

#### Console Management
- `create_console` - Create a new console
- `destroy_console` - Destroy a console
- `write_console` - Write to console
- `read_console` - Read console output
- `console_is_busy` - Check if console is busy
- `run_module_output` - Execute module and get output

#### Core/Framework
- `get_framework_version` - Get framework version
- `core_save` - Save core state
- `core_reload_modules` - Reload modules
- `core_set_global` - Set global variable
- `core_unset_global` - Unset global variable

#### Database
- `get_db_status` - Get database status
- `db_list_workspaces` - List workspaces
- `db_set_workspace` - Set current workspace
- `db_list_hosts` - List hosts
- `db_list_services` - List services
- `db_list_notes` - List notes
- `db_list_creds` - List credentials
- `db_list_vulns` - List vulnerabilities

#### Jobs
- `list_jobs` - List running jobs
- `stop_job` - Stop a job
- `get_job_info` - Get job information

#### Plugins
- `list_plugins` - List loaded plugins
- `load_plugin` - Load a plugin
- `unload_plugin` - Unload a plugin

#### Search
- `search_modules` - Search for modules
- `get_module_references` - Get module references

## Example

```python
# Connect to Metasploit
connect(password="yourpassword", host="127.0.0.1", port=55553, ssl=False)

# List exploits
exploits = list_modules("exploit")

# Use an exploit
use_module("exploit", "unix/ftp/vsftpd_234_backdoor")

# Set options
set_module_option("exploit", "unix/ftp/vsftpd_234_backdoor", "RHOSTS", "192.168.1.100")

# Execute
result = execute_module("exploit", "unix/ftp/vsftpd_234_backdoor", payload="cmd/unix/interact")

# List sessions
sessions = list_sessions()

# Interact with session
output = interact_session("1", "whoami")

# Disconnect
disconnect()
```

## Development

```bash
git clone https://github.com/daedalus/mcp-pymetasploit3.git
cd mcp-pymetasploit3
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mypy src/
```

## mcp-name

io.github.daedalus/mcp-pymetasploit3