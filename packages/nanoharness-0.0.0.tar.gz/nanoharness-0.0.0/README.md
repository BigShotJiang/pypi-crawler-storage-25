# nanoharness

A minimal, didactic agent harness in pure Python.

**Status: placeholder release.** The real implementation is in progress. This v0.0.0 exists to reserve the package name on PyPI.

## What is this

`nanoharness` will be a tiny, readable agent harness that fits in a few thousand lines of pure standard-library Python. It is designed to be read end-to-end in an afternoon, modified without fighting a framework, and used as a starting point for anyone building their own agent infrastructure.

Planned scope for v0.1:

- A simple agent loop with tool use.
- A small toolkit (bash, file read/write/edit, search, web fetch).
- Memory system (AGENTS.md discovery, persistent MEMORY.md, session resume).
- Subagent delegation.
- Observability (git diffs, error logs, file state).
- MCP client for external tool integration.
- CLI and Python SDK.

Follow along at https://www.dailydoseofds.com.

## License

MIT.
