"""nanoharness: a minimal, didactic agent harness in pure Python.

Placeholder release. Real implementation coming soon.
"""

__version__ = "0.0.0"
