"""
setup.py  —  standalone build & publish script for omga-cli
────────────────────────────────────────────────────────────
The actual package metadata lives in pyproject.toml.
This script is for humans only:

  python setup.py              # check deps → build sdist+wheel → verify
  python setup.py --check      # dependency check only, no build
  python setup.py --clean      # wipe dist/ build/ *.egg-info and exit
  python setup.py --upload     # build + upload to PyPI
  python setup.py --upload-test# build + upload to TestPyPI
  python setup.py --skip-sanity# skip import check (CI use)

IMPORTANT: never run via "pip install ." or "python -m build" directly
(those tools use pyproject.toml and ignore this script completely).
"""

import argparse
import importlib.metadata
import importlib.util
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import NamedTuple

# ── Guard: setuptools may call us with legacy sub-commands ────────────────────
# When pip or python -m build invokes setup.py egg_info (or any other
# setuptools command), we must NOT run our custom logic.  Detect that case
# and hand control back to setuptools immediately.
_SETUPTOOLS_CMDS = {
    "egg_info", "install", "develop", "bdist_egg", "bdist_wheel",
    "sdist", "build_ext", "build", "clean", "dist_info", "upload",
    "register", "check",
}

if len(sys.argv) > 1 and sys.argv[1] in _SETUPTOOLS_CMDS:
    try:
        from setuptools import setup  # type: ignore
        setup()
    except SystemExit:
        pass
    sys.exit(0)

# ── Metadata ───────────────────────────────────────────────────────────────────
NAME    = "omga-cli"
VERSION = "1.0.0"
AUTHOR  = "Pouria Hosseini"
EMAIL   = "PouriaHosseini@outlook.com"

MIN_PYTHON = (3, 10)

# (import_name, pip_install_spec, minimum_version)
RUNTIME_DEPS: list[tuple[str, str, str]] = [
    ("click",          "click>=8.1.0",         "8.1.0"),
    ("prompt_toolkit", "prompt_toolkit>=3.0.0", "3.0.0"),
    ("requests",       "requests>=2.31.0",      "2.31.0"),
    ("rich",           "rich>=13.7.0",          "13.7.0"),
    ("dotenv",         "python-dotenv>=1.0.0",  "1.0.0"),
]

BUILD_TOOLS: list[tuple[str, str, str]] = [
    ("pip",        "pip>=23.0",        "23.0"),
    ("setuptools", "setuptools>=68.0", "68.0"),
    ("wheel",      "wheel>=0.41.0",    "0.41.0"),
    ("build",      "build>=1.0.0",     "1.0.0"),
    ("twine",      "twine>=4.0.0",     "4.0.0"),
]

# ── Terminal colour helpers (zero external deps) ───────────────────────────────
_USE_COLOR: bool = sys.stdout.isatty() and not bool(os.getenv("NO_COLOR"))

def _c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text

def green(t: str)  -> str: return _c(t, "32")
def red(t: str)    -> str: return _c(t, "31")
def yellow(t: str) -> str: return _c(t, "33")
def cyan(t: str)   -> str: return _c(t, "36")
def bold(t: str)   -> str: return _c(t, "1")
def dim(t: str)    -> str: return _c(t, "2")

def banner(msg: str) -> None:
    line = "─" * 62
    print(f"\n{cyan(line)}\n  {bold(msg)}\n{cyan(line)}\n")

def ok(msg: str)   -> None: print(f"  {green('✔')}  {msg}")
def fail(msg: str) -> None: print(f"  {red('✘')}  {msg}", file=sys.stderr)
def warn(msg: str) -> None: print(f"  {yellow('!')}  {msg}")
def info(msg: str) -> None: print(f"  {dim('→')}  {msg}")


# ── Version comparison ─────────────────────────────────────────────────────────
class _Ver(NamedTuple):
    major: int
    minor: int
    patch: int

    @staticmethod
    def parse(s: str) -> "_Ver":
        parts = s.strip().lstrip("v").split(".")
        def _i(x: str) -> int:
            try:
                return int(x)
            except ValueError:
                return 0
        return _Ver(_i(parts[0]),
                    _i(parts[1]) if len(parts) > 1 else 0,
                    _i(parts[2]) if len(parts) > 2 else 0)


# ── pip helper ─────────────────────────────────────────────────────────────────
def _pip(*args: str) -> subprocess.CompletedProcess:
    """Run a pip command using the current interpreter."""
    return subprocess.run(
        [sys.executable, "-m", "pip", *args,
         "--quiet", "--no-warn-script-location"],
        capture_output=True,
        text=True,
    )


# Map import names that differ from their PyPI distribution names
_DIST_MAP: dict[str, str] = {
    "dotenv":         "python-dotenv",
    "prompt_toolkit": "prompt-toolkit",
    "cv2":            "opencv-python",
    "sklearn":        "scikit-learn",
}


def _installed_ver(import_name: str) -> str | None:
    """Return the installed version string, or None if not found."""
    candidates = [
        _DIST_MAP.get(import_name, import_name),
        import_name,
        import_name.replace("_", "-"),
        import_name.replace("-", "_"),
    ]
    for name in candidates:
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def _ensure(import_name: str, pip_spec: str, min_ver: str) -> None:
    """Install or upgrade *pip_spec* when the installed version is below *min_ver*."""
    label     = pip_spec.split(">=")[0].split("==")[0]
    installed = _installed_ver(import_name)

    if installed and _Ver.parse(installed) >= _Ver.parse(min_ver):
        ok(f"{label:<24} {green(installed)}")
        return

    if installed:
        warn(f"{label:<24} {yellow(installed)} → upgrading to ≥ {min_ver}")
    else:
        warn(f"{label:<24} {red('not installed')} → installing")

    result = _pip("install", "--upgrade", pip_spec)
    if result.returncode != 0:
        fail(f"Could not install {pip_spec}:\n{result.stderr.strip()}")
        sys.exit(1)

    new_ver = _installed_ver(import_name) or "unknown"
    ok(f"{label:<24} {green(new_ver)}  ← installed")


# ── Step 1 — Python version ────────────────────────────────────────────────────
def step_python() -> None:
    banner("Step 1 / 6  —  Python version")
    cur = sys.version_info[:2]
    if cur < MIN_PYTHON:
        fail(
            f"Python {'.'.join(map(str, MIN_PYTHON))}+ required "
            f"(found {'.'.join(map(str, cur))})."
        )
        sys.exit(1)
    ok(f"Python {'.'.join(map(str, cur))}  —  {sys.executable}")
    info(f"OS  : {platform.system()} {platform.release()} ({platform.machine()})")


# ── Step 2 — Build tools ───────────────────────────────────────────────────────
def step_build_tools() -> None:
    banner("Step 2 / 6  —  Build tools")
    for imp, spec, minv in BUILD_TOOLS:
        _ensure(imp, spec, minv)


# ── Step 3 — Runtime deps ──────────────────────────────────────────────────────
def step_runtime_deps() -> None:
    banner("Step 3 / 6  —  Runtime dependencies")
    for imp, spec, minv in RUNTIME_DEPS:
        _ensure(imp, spec, minv)


# ── Step 4 — Import sanity check ──────────────────────────────────────────────
def step_sanity() -> None:
    banner("Step 4 / 6  —  Import sanity check")

    root = Path(__file__).resolve().parent
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    checks = [
        ("core.config",    "load_config"),
        ("core.logger",    "logger"),
        ("core.cache_db",  "get"),
        ("core.utils",     "read_file"),
        ("core.ui",        "ui"),
        ("core.ai",        "ask"),
        ("core.checker",   "check_file"),
        ("core.commands",  "dispatch_command"),
        ("core.completer", "OmgaCompleter"),
        ("core.shell",     "run_shell"),
        ("core.cli",       "main"),
    ]

    errors: list[str] = []
    for mod_name, attr in checks:
        try:
            mod = importlib.import_module(mod_name)
            if not hasattr(mod, attr):
                raise AttributeError(f"'{attr}' not found in '{mod_name}'")
            ok(f"{mod_name}.{attr}")
        except Exception as exc:
            fail(f"{mod_name}: {exc}")
            errors.append(mod_name)

    if errors:
        fail(
            f"\n  {len(errors)} module(s) failed the import check — "
            "fix the errors above and retry."
        )
        sys.exit(1)


# ── Clean helper ───────────────────────────────────────────────────────────────
def _clean(silent: bool = False) -> None:
    targets = [
        "dist",
        "build",
        f"{NAME.replace('-', '_')}.egg-info",
        f"{NAME}.egg-info",
    ]
    for t in targets:
        p = Path(t)
        if p.exists():
            shutil.rmtree(p) if p.is_dir() else p.unlink()
            if not silent:
                ok(f"Removed  {t}/")

    removed = 0
    for pc in Path(".").rglob("__pycache__"):
        shutil.rmtree(pc, ignore_errors=True)
        removed += 1
    if not silent and removed:
        ok(f"Removed {removed} __pycache__ director{'y' if removed == 1 else 'ies'}.")


# ── Step 5 — Build distributions ──────────────────────────────────────────────
def step_build() -> Path:
    banner("Step 5 / 6  —  Build  (sdist + wheel)")

    _clean(silent=True)

    result = subprocess.run(
        [sys.executable, "-m", "build", "--sdist", "--wheel", "."],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        fail("Build failed:\n")
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    dist = Path("dist")
    arts = sorted(dist.iterdir()) if dist.exists() else []

    if not arts:
        fail("Build reported success but dist/ is empty.")
        sys.exit(1)

    for a in arts:
        size = a.stat().st_size / 1024
        ok(f"{a.name:<50} {dim(f'{size:.1f} KB')}")

    return dist


# ── Step 6 — twine check ──────────────────────────────────────────────────────
def step_verify(dist: Path) -> None:
    banner("Step 6 / 6  —  Verify distributions  (twine check)")

    files  = [str(f) for f in dist.glob("*") if f.is_file()]
    result = subprocess.run(
        [sys.executable, "-m", "twine", "check", *files],
        capture_output=True,
        text=True,
    )
    output = (result.stdout + result.stderr).strip()

    if result.returncode != 0:
        fail("twine check failed:\n" + output)
        sys.exit(1)

    for line in output.splitlines():
        if line.strip():
            ok(line.strip())


# ── Upload ─────────────────────────────────────────────────────────────────────
def step_upload(dist: Path, *, test: bool = False) -> None:
    label = "TestPyPI" if test else "PyPI"
    banner(f"Upload  —  Publishing to {label}")

    files = [str(f) for f in dist.glob("*") if f.is_file()]
    cmd   = [sys.executable, "-m", "twine", "upload"]
    if test:
        cmd += ["--repository", "testpypi"]
    cmd += files

    result = subprocess.run(cmd)
    if result.returncode != 0:
        fail("Upload failed. Check your ~/.pypirc credentials and try again.")
        sys.exit(1)

    ok(f"Published {NAME} {VERSION} to {label}!")
    if test:
        info(f"pip install --index-url https://test.pypi.org/simple/ {NAME}")
    else:
        info(f"pip install --upgrade {NAME}")


# ── Summary ────────────────────────────────────────────────────────────────────
def _summary(dist: Path) -> None:
    whl = next((a.name for a in dist.iterdir() if a.suffix == ".whl"), "*.whl")
    print(f"\n{green('═' * 62)}")
    print(f"  {bold(green('🎉  Build complete!'))}")
    print(f"{green('═' * 62)}\n")
    print(f"  {bold('Package')} : {NAME}  v{VERSION}")
    print(f"  {bold('Author')}  : {AUTHOR}  <{EMAIL}>")
    print(f"  {bold('Output')}  : {dist.resolve()}/\n")
    for a in sorted(dist.iterdir()):
        print(f"    {cyan('•')}  {a.name}")
    print(f"""
  {bold('Next steps')}

  {dim('# Install locally to test')}
  pip install dist/{whl}

  {dim('# Upload to TestPyPI first (recommended)')}
  python setup.py --upload-test

  {dim('# Upload to PyPI')}
  python setup.py --upload
""")


# ── CLI ────────────────────────────────────────────────────────────────────────
def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="setup.py",
        description="Build & publish script for omga-cli",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--check",       action="store_true",
                   help="Dependency check only — no build.")
    p.add_argument("--clean",       action="store_true",
                   help="Remove build artefacts and exit.")
    p.add_argument("--upload",      action="store_true",
                   help="Build + upload to PyPI.")
    p.add_argument("--upload-test", action="store_true", dest="upload_test",
                   help="Build + upload to TestPyPI.")
    p.add_argument("--skip-sanity", action="store_true", dest="skip_sanity",
                   help="Skip import check (useful in CI).")
    return p.parse_args()


def main() -> None:
    args = _parse_args()

    # ── --clean ────────────────────────────────────────────────────────────────
    if args.clean:
        banner("Clean  —  removing build artefacts")
        _clean(silent=False)
        print(f"\n  {green('Done.')}  Working tree is clean.\n")
        return

    # ── Header ─────────────────────────────────────────────────────────────────
    print(f"\n{bold(cyan('╔' + '═' * 60 + '╗'))}")
    print(f"{bold(cyan('║'))}{bold(f'  🚀  omga-cli  v{VERSION}  —  Build System'):^60}{bold(cyan('║'))}")
    print(f"{bold(cyan('╚' + '═' * 60 + '╝'))}\n")
    info(f"Python : {sys.version.split()[0]}")
    info(f"OS     : {platform.system()} {platform.release()}")
    info(f"CWD    : {Path.cwd()}")

    # ── Steps ──────────────────────────────────────────────────────────────────
    step_python()
    step_build_tools()
    step_runtime_deps()

    if not args.skip_sanity:
        step_sanity()
    else:
        warn("Import sanity check skipped (--skip-sanity).")

    if args.check:
        print(f"\n  {green('✔  All dependencies satisfied.')}  (--check mode; no build)\n")
        return

    dist = step_build()
    step_verify(dist)

    if args.upload or args.upload_test:
        step_upload(dist, test=args.upload_test)
    else:
        _summary(dist)


if __name__ == "__main__":
    main()