"""
Command handlers for omga-cli.

Each handler is a pure function: accepts typed arguments, does its
work, and communicates only through *ui*.  Handlers never call
sys.exit(); that is the caller's responsibility.

Removed: status_handler, config_handler  (no longer part of the UI).
"""

import os
from typing import Optional, Tuple

from core.ai import (
    ask_stream,
    explain_code,
    fix_code,
    generate_documentation,
    generate_project_code,
    suggest_improvements,
)
from core.checker import check_file
from core.config import get_config_value
from core.logger import logger
from core.ui import MessageType, ui
from core.utils import detect_language, read_file, run_subprocess, write_file


# ── Command dispatcher ─────────────────────────────────────────────────────────

def dispatch_command(text: str) -> None:
    """Parse *text* and delegate to the appropriate handler."""
    parts = text.strip().split()
    if not parts:
        return

    cmd  = parts[0].lower()
    args = parts[1:]

    try:
        if cmd == "help":
            help_handler()

        elif cmd == "check":
            check_handler(args[0] if args else "")

        elif cmd == "explain":
            explain_handler(args[0] if args else "")

        elif cmd == "ask":
            ask_handler(" ".join(args))

        elif cmd == "fix":
            fix_handler(args[0] if args else "")

        elif cmd == "improve":
            improve_handler(args[0] if args else "")

        elif cmd == "docs":
            docs_handler(args[0] if args else "")

        elif cmd == "run":
            run_handler(" ".join(args))

        elif cmd == "generate":
            if len(args) >= 3 and args[0] == "project":
                generate_handler(template=args[1], name=args[2])
            else:
                ui.print_error("Usage: generate project <template> <name>")

        elif cmd == "snippet":
            action  = args[0] if args else ""
            sname   = args[1] if len(args) > 1 else None
            content = " ".join(args[2:]) if len(args) > 2 else None
            snippet_handler(action, sname, content)

        else:
            ui.print_error(
                f"Unknown command: '{cmd}'. Type 'help' for available commands."
            )

    except Exception as exc:
        logger.exception("Error executing command '%s'", cmd)
        ui.print_error(f"Command '{cmd}' failed: {exc}")


# ── Handlers ───────────────────────────────────────────────────────────────────

def help_handler() -> None:
    commands = {
        "help":                               "Show this help message",
        "check <file>":                       "Syntax & lint analysis",
        "explain <file>":                     "AI-powered code explanation",
        "ask <question>":                     "Ask the AI anything",
        "fix <file>":                         "AI-assisted bug fixing",
        "improve <file>":                     "Refactoring suggestions",
        "docs <file>":                        "Generate documentation",
        "run <shell command>":                "Execute a shell command safely",
        "generate project <template> <name>": "Scaffold a new project",
        "snippet add|list|remove [name]":     "Manage code snippets",
        "exit / quit":                        "Exit the shell",
    }
    ui.print_help(commands)


def check_handler(file: str) -> None:
    if not file:
        ui.print_error("Please provide a file path. Usage: check <file>")
        return

    ok, messages = check_file(file)

    if ok and not messages:
        ui.print_success(f"{file} — no issues found.", "Code Analysis")
    elif ok:
        ui.print_warning(
            f"{file} — syntax OK, {len(messages)} style warning(s).", "Code Analysis"
        )
        for msg in messages:
            ui.print_message(f"  {msg}", MessageType.WARNING)
    else:
        ui.print_error(
            f"{file} — {len(messages)} error(s) found.", "Code Analysis"
        )
        for msg in messages:
            ui.print_message(f"  {msg}", MessageType.ERROR)


def explain_handler(file: str) -> None:
    if not file:
        ui.print_error("Please provide a file path. Usage: explain <file>")
        return
    try:
        code = read_file(file)
        lang = detect_language(file)
        ui.print_code_block(code, lang, title=f"Source: {file}")
        stream = ask_stream(
            f"Explain this {lang} code in detail:\n\n```{lang}\n{code}\n```"
        )
        ui.print_ai_response_stream(stream, "Code Explanation")
    except FileNotFoundError:
        ui.print_error(f"File not found: {file}")
    except Exception as exc:
        logger.exception("explain_handler error")
        ui.print_error(str(exc))


def ask_handler(question: str) -> None:
    if not question.strip():
        ui.print_error("Please provide a question. Usage: ask <question>")
        return
    try:
        stream = ask_stream(question)
        ui.print_ai_response_stream(stream, "AI Assistant")
    except Exception as exc:
        logger.exception("ask_handler error")
        ui.print_error(str(exc))


def fix_handler(file: str) -> None:
    if not file:
        ui.print_error("Please provide a file path. Usage: fix <file>")
        return
    try:
        code = read_file(file)
        lang = detect_language(file)

        ui.print_code_block(code, lang, title=f"Original: {file}")

        ok, msgs = check_file(file)
        issues   = "; ".join(msgs) if msgs else None

        new_code = fix_code(code, lang, issues)

        if get_config_value("features.show_diffs", True):
            ui.print_diff(code, new_code, "Proposed Changes")
        else:
            ui.print_code_block(new_code, lang, title="Fixed Code")

        if get_config_value("security.confirm_destructive", True):
            if ui.confirm("Apply fixes to the file?", default=False):
                write_file(file, new_code)
                ui.print_success(f"Fixes written to {file}")
            else:
                ui.print_info("Changes discarded — original file unchanged.")
        else:
            write_file(file, new_code)
            ui.print_success(f"Fixes written to {file}")

    except FileNotFoundError:
        ui.print_error(f"File not found: {file}")
    except Exception as exc:
        logger.exception("fix_handler error")
        ui.print_error(str(exc))


def improve_handler(file: str) -> None:
    if not file:
        ui.print_error("Please provide a file path. Usage: improve <file>")
        return
    try:
        code   = read_file(file)
        lang   = detect_language(file)
        ui.print_code_block(code, lang, title=f"Source: {file}")
        result = suggest_improvements(code, lang)
        ui.print_ai_response(result, "Improvement Suggestions")
    except FileNotFoundError:
        ui.print_error(f"File not found: {file}")
    except Exception as exc:
        logger.exception("improve_handler error")
        ui.print_error(str(exc))


def docs_handler(file: str) -> None:
    if not file:
        ui.print_error("Please provide a file path. Usage: docs <file>")
        return
    try:
        code   = read_file(file)
        lang   = detect_language(file)
        ui.print_code_block(code, lang, title=f"Source: {file}")
        result = generate_documentation(code, lang)
        ui.print_ai_response(result, "Generated Documentation")
    except FileNotFoundError:
        ui.print_error(f"File not found: {file}")
    except Exception as exc:
        logger.exception("docs_handler error")
        ui.print_error(str(exc))


def run_handler(command: str) -> Tuple[int, str, str]:
    if not command.strip():
        ui.print_error("Please provide a command. Usage: run <command>")
        return 1, "", "No command given"
    try:
        result    = run_subprocess(command, timeout=120)
        stdout    = result.stdout.decode(errors="replace")
        stderr    = result.stderr.decode(errors="replace")
        exit_code = result.returncode

        if exit_code == 0:
            ui.print_success("Command completed.", "Execution")
        else:
            ui.print_error(f"Command exited with code {exit_code}.", "Execution")

        if stdout:
            ui.print_code_block(stdout.rstrip(), "text", title="stdout")
        if stderr:
            ui.print_code_block(stderr.rstrip(), "text", title="stderr")

        return exit_code, stdout, stderr

    except Exception as exc:
        logger.exception("run_handler error")
        ui.print_error(str(exc))
        return 1, "", str(exc)


def generate_handler(template: str, name: str) -> None:
    """
    Scaffold a new project.

    Built-in template: *fastapi*
    Any other value is treated as a natural-language description and
    sent to the AI to generate the project files.
    """
    try:
        if template == "fastapi":
            template_src = os.path.join(
                os.path.dirname(__file__), "resources", "fastapi_template.py"
            )
            try:
                code = read_file(template_src)
            except FileNotFoundError:
                code = (
                    "from fastapi import FastAPI\n\n"
                    "app = FastAPI()\n\n\n"
                    "@app.get(\"/\")\ndef root():\n"
                    "    return {\"message\": \"Hello, World!\"}\n"
                )

            os.makedirs(name, exist_ok=True)
            write_file(os.path.join(name, "main.py"), code)
            write_file(
                os.path.join(name, "requirements.txt"),
                "fastapi>=0.110.0\nuvicorn[standard]>=0.29.0\n",
            )
            ui.print_success(
                f"FastAPI project '{name}' created at {os.path.abspath(name)}"
            )
            ui.print_code_block(code, "python", title=f"{name}/main.py")

        else:
            ui.print_info(
                f"Generating '{name}' project with AI (template: {template})…"
            )
            files = generate_project_code(template, template)

            os.makedirs(name, exist_ok=True)
            for rel_path, content in files.items():
                full_path = os.path.join(name, rel_path)
                write_file(full_path, content)
                ui.print_info(f"  Created: {full_path}")

            ui.print_success(f"Project '{name}' generated with {len(files)} file(s).")

    except Exception as exc:
        logger.exception("generate_handler error")
        ui.print_error(str(exc))


def snippet_handler(
    action: str, name: Optional[str], content: Optional[str]
) -> None:
    from core.config import CONFIG_DIR

    snippets_dir = os.path.join(CONFIG_DIR, "snippets")
    os.makedirs(snippets_dir, exist_ok=True)

    try:
        if action == "add":
            if not name or not content:
                ui.print_error("Usage: snippet add <name> <content>")
                return
            # Prevent path traversal: name must be a plain filename
            safe_name = os.path.basename(name)
            if safe_name != name or "/" in name or "\\" in name:
                ui.print_error("Snippet name must be a plain filename (no path separators).")
                return
            write_file(os.path.join(snippets_dir, safe_name), content)
            ui.print_success(f"Snippet '{safe_name}' saved.")

        elif action == "list":
            items = os.listdir(snippets_dir)
            if not items:
                ui.print_info("No snippets saved yet. Use 'snippet add <name> <content>'.")
                return
            data = []
            for item in sorted(items):
                src = os.path.join(snippets_dir, item)
                with open(src, encoding="utf-8") as fh:
                    body = fh.read()
                preview = (body[:60] + "…") if len(body) > 60 else body
                data.append({"Name": item, "Preview": preview})
            ui.print_table(data, title="Saved Snippets")

        elif action == "remove":
            if not name:
                ui.print_error("Usage: snippet remove <name>")
                return
            safe_name = os.path.basename(name)
            if safe_name != name or "/" in name or "\\" in name:
                ui.print_error("Snippet name must be a plain filename.")
                return
            target = os.path.join(snippets_dir, safe_name)
            if os.path.exists(target):
                os.remove(target)
                ui.print_success(f"Snippet '{safe_name}' removed.")
            else:
                ui.print_error(f"Snippet '{safe_name}' not found.")

        else:
            ui.print_error(
                f"Unknown snippet action: '{action}'. Valid: add, list, remove"
            )

    except Exception as exc:
        logger.exception("snippet_handler error")
        ui.print_error(str(exc))