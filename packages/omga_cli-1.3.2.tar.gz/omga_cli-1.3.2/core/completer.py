"""
Tab-completion engine for omga-cli's interactive shell.

Provides:
- Static command completions with metadata
- File path completions for file-based commands
- Snippet name completions for 'snippet remove'

AI-powered completions are intentionally DISABLED during active input.
Reason: any background thread that touches the network or stderr/stdout
while prompt_toolkit owns the terminal causes visual corruption
(flashing lines, cursor jumps, colour artifacts).

The fix: completions are 100% local and synchronous — no threads,
no network calls, no Rich/console output of any kind inside this module.
"""

import glob
import os
from typing import Iterable

from prompt_toolkit.completion import CompleteEvent, Completer, Completion
from prompt_toolkit.document import Document

from core.logger import logger

# ── Static command registry ────────────────────────────────────────────────────
_COMMANDS: dict[str, str] = {
    "check":    "Syntax & lint analysis",
    "explain":  "AI code explanation",
    "ask":      "Ask the AI anything",
    "fix":      "AI-assisted bug fixing",
    "improve":  "Refactoring suggestions",
    "docs":     "Generate documentation",
    "run":      "Execute a shell command",
    "generate": "Scaffold a new project",
    "snippet":  "Manage code snippets",
    "config":   "Show configuration",
    "status":   "System diagnostics",
    "help":     "Show help",
    "exit":     "Exit the shell",
    "quit":     "Exit the shell",
}

_FILE_COMMANDS = {"check", "explain", "fix", "improve", "docs"}

# Config dir resolved once at import time — no per-keystroke disk reads
_CONFIG_DIR: str = os.path.join(os.path.expanduser("~"), ".omga_cli")


class OmgaCompleter(Completer):
    """
    Purely local, synchronous completer.

    No threads, no network, no console output.
    Safe to run on every keystroke inside prompt_toolkit.
    """

    # ── Prompt-toolkit entry point ─────────────────────────────────────────────

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        text  = document.text_before_cursor
        words = text.split()

        if not text.strip():
            for cmd, meta in _COMMANDS.items():
                yield Completion(cmd, start_position=0, display_meta=meta)
            return

        partial = words[-1] if not text.endswith(" ") else ""
        context = words[:-1] if partial else words

        if not context:
            # First token: complete command names
            yield from self._complete_commands(partial)

        elif context[0] in _FILE_COMMANDS:
            # File-based commands: complete filesystem paths
            yield from self._complete_paths(partial)

        elif context[0] == "generate":
            if len(context) == 1:
                for kw in ("project",):
                    if kw.startswith(partial):
                        yield Completion(
                            kw, start_position=-len(partial), display_meta="keyword"
                        )
            elif len(context) == 2 and context[1] == "project":
                for tpl in ("fastapi",):
                    if tpl.startswith(partial):
                        yield Completion(
                            tpl, start_position=-len(partial), display_meta="template"
                        )

        elif context[0] == "snippet":
            if len(context) == 1:
                for act in ("add", "list", "remove"):
                    if act.startswith(partial):
                        yield Completion(
                            act, start_position=-len(partial), display_meta="action"
                        )
            elif len(context) == 2 and context[1] == "remove":
                yield from self._complete_snippets(partial)

        # NOTE: AI-powered completions removed entirely.
        # They required background threads + network calls while prompt_toolkit
        # owns the terminal, which caused visual corruption on every keystroke.

    # ── Helper generators (all pure-local, no I/O side-effects) ───────────────

    def _complete_commands(self, partial: str) -> Iterable[Completion]:
        for cmd, meta in _COMMANDS.items():
            if cmd.startswith(partial):
                yield Completion(
                    cmd, start_position=-len(partial), display_meta=meta
                )

    def _complete_paths(self, partial: str) -> Iterable[Completion]:
        """Complete filesystem paths — uses glob (pure local, no network)."""
        pattern = (partial or "") + "*"
        try:
            matches = glob.glob(pattern)
            py   = [m for m in matches if m.endswith(".py")]
            rest = [m for m in matches if not m.endswith(".py")]
            for path in (py + rest)[:12]:
                yield Completion(
                    path,
                    start_position=-len(partial),
                    display_meta="file" if os.path.isfile(path) else "dir",
                )
        except Exception:
            pass

    def _complete_snippets(self, partial: str) -> Iterable[Completion]:
        """Complete saved snippet names from disk."""
        snippets_dir = os.path.join(_CONFIG_DIR, "snippets")
        try:
            if os.path.isdir(snippets_dir):
                for name in os.listdir(snippets_dir):
                    if name.startswith(partial):
                        yield Completion(
                            name,
                            start_position=-len(partial),
                            display_meta="snippet",
                        )
        except Exception:
            pass