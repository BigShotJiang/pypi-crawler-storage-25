"""
AI client for omga-cli.

Request flow
────────────
ask_stream(prompt)
  → cache hit?  yield cached chunks directly (very fast)
  → cache miss? yield from _stream() directly

The caller passes the iterator to ui.print_ai_response_stream()
→ ui.stream_response(), which:
  1. Opens Live immediately (spinner visible from ms 0).
  2. Runs _producer thread that consumes the iterator.
  3. Main thread animates spinner until first chunk, then streams text.
  4. Final Markdown render when stream exhausts.

ask() (blocking) uses thinking_spinner + direct _stream() collection.

Security
─────────
• API key: memory-only via core.config, never in logs or on disk.
• User content never appears in URLs or at INFO log level.
• Timeouts enforced; HTTP streams always closed after use.
• Retries only on transient errors (429, 5xx), max 3×.
"""

import json
import time
from typing import Iterator, List, Optional

import requests

from core.cache_db import get as cache_get, set_ as cache_set
from core.config import get_api_key, get_config_value
from core.logger import logger

# ── Constants ──────────────────────────────────────────────────────────────────
_BASE_URL = "https://api.gapgpt.app/v1/responses"
_REFERER  = "https://github.com/omga-cli"
_APP_NAME = "omga-cli"

_SYSTEM_PROMPT_EN = """\
You are an expert AI coding assistant integrated into omga-cli, \
developed by Pouria Hosseini (@isPoori — PouriaHosseini.ir).

ABSOLUTE RULES — never break these:
1. Write your COMPLETE answer every single time. Never truncate.
2. Never write "continued below", "see next message", or "# ... rest unchanged".
3. Never summarise code with placeholders — always write every line in full.
4. Wrap all code in the correct markdown code fence.
5. Think step-by-step before answering complex questions.
6. Be direct, precise, and technically accurate.\
"""

_SYSTEM_PROMPT_FA = """\
You are an expert AI coding assistant integrated into omga-cli, \
developed by Pouria Hosseini (@isPoori — PouriaHosseini.ir).

ABSOLUTE RULES — never break these:
1. Write your COMPLETE answer every single time. Never truncate.
2. Never write "continued below", "see next message", or "# ... rest unchanged".
3. Never summarise code with placeholders — always write every line in full.
4. Wrap all code in the correct markdown code fence.
5. Think step-by-step before answering complex questions.
6. Be direct, precise, and technically accurate.

LANGUAGE RULE: The user is writing in Persian (Farsi — فارسی).
Reply ENTIRELY in Persian. Use proper Persian grammar, punctuation, and
technical vocabulary. Code identifiers stay in English; all prose in Persian.\
"""

_RETRYABLE = frozenset({429, 500, 502, 503, 504})


# ── Helpers ────────────────────────────────────────────────────────────────────

def _has_persian(text: str) -> bool:
    for ch in text:
        cp = ord(ch)
        if (0x0600 <= cp <= 0x06FF or
                0xFB50 <= cp <= 0xFDFF or
                0xFE70 <= cp <= 0xFEFF):
            return True
    return False


def _sys_prompt(prompt: str) -> str:
    return _SYSTEM_PROMPT_FA if _has_persian(prompt) else _SYSTEM_PROMPT_EN


def _headers() -> dict:
    return {
        "Content-Type":  "application/json",
        "Authorization": f"Bearer {get_api_key()}",
        "HTTP-Referer":  _REFERER,
        "X-Title":       _APP_NAME,
    }


def _payload(prompt: str, *, stream: bool = False) -> dict:
    return {
        "model":       get_config_value("api.model",
                                        "arcee-ai/trinity-large-preview:free"),
        "max_tokens":  get_config_value("api.max_tokens", 8192),
        "temperature": get_config_value("api.temperature", 0.7),
        "stream":      stream,
        "messages": [
            {"role": "system", "content": _sys_prompt(prompt)},
            {"role": "user",   "content": prompt},
        ],
    }


def _parse_error(resp: requests.Response) -> str:
    try:
        return resp.json().get("error", {}).get("message", resp.text[:300])
    except Exception:
        return resp.text[:300]


# ── Low-level SSE stream ───────────────────────────────────────────────────────

def _stream(prompt: str, retries: int = 3) -> Iterator[str]:
    """
    POST to OpenRouter with stream=True.
    Yields SSE content chunks as they arrive.
    Retries on transient HTTP errors with exponential back-off.
    """
    timeout = get_config_value("api.timeout", 60)

    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(
                _BASE_URL,
                json=_payload(prompt, stream=True),
                headers=_headers(),
                timeout=timeout,
                stream=True,
            )

            if not resp.ok:
                detail = _parse_error(resp)
                logger.error("API %s attempt %d: %s",
                             resp.status_code, attempt, detail)
                if resp.status_code not in _RETRYABLE:
                    raise RuntimeError(
                        f"API error {resp.status_code}: {detail}"
                    )
            else:
                for raw in resp.iter_lines(decode_unicode=True):
                    if not raw or not raw.startswith("data: "):
                        continue
                    payload = raw[6:].strip()
                    if payload == "[DONE]":
                        return
                    try:
                        data  = json.loads(payload)
                        delta = (data.get("choices") or [{}])[0].get(
                            "delta", {}
                        )
                        chunk = delta.get("content", "")
                        if chunk:
                            yield chunk
                    except (json.JSONDecodeError, IndexError):
                        continue
                return  # clean EOF

        except RuntimeError:
            raise
        except (requests.ConnectionError, requests.Timeout) as exc:
            logger.warning("Network error attempt %d/%d: %s",
                           attempt, retries, exc)
        except Exception:
            raise

        if attempt < retries:
            time.sleep(min(2 ** attempt, 16))

    raise RuntimeError("AI service unavailable after multiple retries.")


# ── Public: ask_stream ─────────────────────────────────────────────────────────

def ask_stream(prompt: str, context: Optional[str] = None) -> Iterator[str]:
    """
    Yield response chunks for *prompt*.

    Cache hit  → yield stored text in small chunks (immediate, no network).
    Cache miss → yield from _stream() directly.

    The caller passes this iterator to ui.print_ai_response_stream()
    → ui.stream_response(), which manages ALL spinner/rendering.
    Do NOT add any spinner or Live context here.
    """
    full = f"Context:\n{context}\n\n{prompt}" if context else prompt

    # ── Cache hit ──────────────────────────────────────────────────────────────
    if get_config_value("features.cache_responses", True):
        cached = cache_get(full)
        if cached:
            logger.debug("Cache hit (%d chars)", len(cached))
            chunk_size = 12
            for i in range(0, len(cached), chunk_size):
                yield cached[i:i + chunk_size]
            return

    # ── Network stream — yield directly, let ui own the spinner ───────────────
    collected: List[str] = []
    try:
        for chunk in _stream(full):
            collected.append(chunk)
            yield chunk
    except Exception as exc:
        logger.error("Stream error: %s", exc)
        if not collected:
            raise

    # ── Cache the completed response ───────────────────────────────────────────
    full_text = "".join(collected)
    if full_text and get_config_value("features.cache_responses", True):
        cache_set(full, full_text)


# ── Public: ask (blocking) ────────────────────────────────────────────────────

def ask(
    prompt:    str,
    context:   Optional[str] = None,
    *,
    use_cache: bool = True,
) -> str:
    """
    Blocking version — collects the full response and returns it as a string.
    Shows thinking_spinner while waiting (used by fix/docs/improve commands).
    use_cache=False forces a fresh network call.
    """
    from core.ui import ui  # lazy to avoid circular import

    full    = f"Context:\n{context}\n\n{prompt}" if context else prompt
    persian = _has_persian(full)

    # Cache check
    if use_cache and get_config_value("features.cache_responses", True):
        cached = cache_get(full)
        if cached:
            return cached

    # Collect from network behind spinner
    collected: List[str] = []
    with ui.thinking_spinner(persian=persian):
        for chunk in _stream(full):
            collected.append(chunk)

    result = "".join(collected)
    if result and use_cache and get_config_value("features.cache_responses", True):
        cache_set(full, result)
    return result


# ── Specialised helpers ────────────────────────────────────────────────────────

def explain_code(code: str, language: str = "python") -> str:
    return ask(
        f"Explain the following {language} code in full detail. "
        f"Do NOT truncate — write the complete explanation.\n\n"
        f"```{language}\n{code}\n```\n\n"
        f"Structure:\n"
        f"1. **Overview** – what it does\n"
        f"2. **Step-by-step breakdown** – every significant block\n"
        f"3. **Key concepts** – patterns and techniques used\n"
        f"4. **Potential issues** – bugs, edge-cases, security\n"
        f"5. **Improvement suggestions** – concrete ideas with snippets\n"
    )


def fix_code(
    code:     str,
    language: str = "python",
    issues:   Optional[str] = None,
) -> str:
    issue_block = f"\nKnown issues:\n{issues}\n" if issues else ""
    return _strip_fence(ask(
        f"Fix ALL problems in this {language} code.{issue_block}\n\n"
        f"```{language}\n{code}\n```\n\n"
        f"Requirements:\n"
        f"- Fix every syntax error, logic bug, and style violation.\n"
        f"- Improve error handling and input validation.\n"
        f"- Add inline comments for non-obvious changes.\n"
        f"- Return the COMPLETE corrected file in one code fence.\n"
        f"- Never omit any line. Never write '# ... rest unchanged'.\n"
    ))


def suggest_improvements(code: str, language: str = "python") -> str:
    return ask(
        f"Review this {language} code and provide thorough improvements.\n\n"
        f"```{language}\n{code}\n```\n\n"
        f"Cover ALL sections:\n"
        f"1. **Performance** – bottlenecks and alternatives\n"
        f"2. **Readability** – naming, structure, comments\n"
        f"3. **Maintainability** – modularity, testability\n"
        f"4. **Modern practices** – idiomatic {language} patterns\n"
        f"5. **Security** – validation, injection risks, secrets\n"
        f"6. **Error handling** – robustness\n\n"
        f"Include code snippets for each suggestion.\n"
    )


def generate_documentation(code: str, language: str = "python") -> str:
    return ask(
        f"Generate complete, production-ready documentation for this "
        f"{language} code.\n\n"
        f"```{language}\n{code}\n```\n\n"
        f"Include ALL — never truncate:\n"
        f"1. Module/class/function docstrings (Google style)\n"
        f"2. Parameter types and descriptions\n"
        f"3. Return types and descriptions\n"
        f"4. Raises sections where applicable\n"
        f"5. Usage examples for every public function\n\n"
        f"Return the COMPLETE documented source in one code fence.\n"
    )


def generate_project_code(
    description: str,
    template:    str = "fastapi",
) -> dict[str, str]:
    """Generate a complete project scaffold. Returns {rel_path: content}."""
    raw = _strip_fence(ask(
        f"Generate a complete, production-ready {template} project for:\n\n"
        f'"{description}"\n\n'
        f"Return a JSON object: keys = relative file paths, "
        f"values = complete file contents.\n"
        f"Include:\n"
        f"- All application files — complete, not abbreviated\n"
        f"- requirements.txt with pinned versions\n"
        f"- Detailed README.md\n"
        f"- Proper error handling and logging\n"
        f"- Inline comments explaining the structure\n\n"
        f"Return ONLY raw JSON — no markdown fences, no prose.\n"
        f"CRITICAL: Write every file in full. Never truncate.\n",
        use_cache=False,
    )).strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"main.py": raw}


# ── Utility ────────────────────────────────────────────────────────────────────

def _strip_fence(text: str) -> str:
    if not text:
        return ""
    lines = text.strip().splitlines()
    if lines and lines[0].lstrip().startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].lstrip().startswith("```"):
        lines = lines[:-1]
    return "\n".join(lines).strip()