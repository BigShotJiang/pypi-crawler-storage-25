"""
Configuration management for omga-cli.

Security model
──────────────
• The API key lives ONLY in this module's memory.
  It is NEVER written to config.json on disk — a user or process
  reading the config file cannot obtain the key.
• get_config_value() returns from an in-memory cache; the config
  file is read from disk exactly once per process lifetime, preventing
  per-keystroke I/O that corrupted the terminal in earlier versions.
"""

import os
import json
import threading
from typing import Any, Dict

HOME         = os.path.expanduser("~")
CONFIG_DIR   = os.path.join(HOME, ".omga_cli")
HISTORY_FILE = os.path.join(CONFIG_DIR, "history.txt")
CACHE_DB     = os.path.join(CONFIG_DIR, "cache.sqlite")
LOG_FILE     = os.path.join(CONFIG_DIR, "omga.log")
CONFIG_FILE  = os.path.join(CONFIG_DIR, "config.json")

os.makedirs(CONFIG_DIR, exist_ok=True)

# ── API key — memory-only, never persisted to disk ────────────────────────────
_API_KEY = "sk-6AbHSvIwESYQLoXJCL2aydYexxMtyb6z02DMfJhhCJpGRSL0"

# ── Default configuration (no api_key field — key stays out of files) ─────────
DEFAULT_CONFIG: Dict[str, Any] = {
    "api": {
        "base_url":    "https://api.gapgpt.app/v1/responses",
        "model":       "gapgpt-qwen-3.5",
        "timeout":     60,
        "max_tokens":  8192,
        "temperature": 0.7,
    },
    "ui": {
        "theme":             "monokai",
        "show_line_numbers": True,
        "word_wrap":         True,
        "show_icons":        True,
    },
    "features": {
        "cache_responses": True,
        "show_diffs":      True,
    },
    "security": {
        "confirm_destructive": True,
    },
}

# ── In-memory config cache (loaded once, protected by a lock) ─────────────────
_cache_lock:   threading.Lock         = threading.Lock()
_config_cache: Dict[str, Any] | None = None


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """Recursively merge *override* into a copy of *base*."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_from_disk() -> Dict[str, Any]:
    """
    Read config.json and merge with defaults.
    Strips any api_key field from disk data before merging so a
    tampered config file cannot inject a different key.
    """
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
                user_cfg = json.load(fh)
            if isinstance(user_cfg.get("api"), dict):
                user_cfg["api"].pop("api_key", None)
            return _deep_merge(DEFAULT_CONFIG, user_cfg)
        except (json.JSONDecodeError, OSError):
            pass
    _write_config(DEFAULT_CONFIG)
    return DEFAULT_CONFIG.copy()


def _write_config(cfg: Dict[str, Any]) -> None:
    """Write config to disk, explicitly omitting the API key."""
    safe = json.loads(json.dumps(cfg))
    if isinstance(safe.get("api"), dict):
        safe["api"].pop("api_key", None)
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
            json.dump(safe, fh, indent=2)
    except OSError as exc:
        print(f"[omga] Warning: cannot save config – {exc}")


def load_config() -> Dict[str, Any]:
    """
    Return the active configuration dict from the in-memory cache.
    Disk is read exactly once per process lifetime.  Thread-safe.
    """
    global _config_cache
    with _cache_lock:
        if _config_cache is None:
            _config_cache = _load_from_disk()
        return _config_cache


def get_config_value(key_path: str, default: Any = None) -> Any:
    """
    Retrieve a config value using dot-notation.  Zero disk I/O.
    Example: get_config_value('api.model')
    """
    cfg = load_config()
    for key in key_path.split("."):
        if not isinstance(cfg, dict):
            return default
        cfg = cfg.get(key, default)
        if cfg is default:
            return default
    return cfg


def set_config_value(key_path: str, value: Any) -> None:
    """Persist a single config value using dot-notation."""
    global _config_cache
    with _cache_lock:
        cfg = load_config()
        keys = key_path.split(".")
        node = cfg
        for key in keys[:-1]:
            node = node.setdefault(key, {})
        node[keys[-1]] = value
        _config_cache = cfg
    _write_config(cfg)


def get_api_key() -> str:
    """
    Return the API key from memory only.
    Cannot be overridden by config file or environment variables.
    """
    return _API_KEY


# Warm the cache at import time (one disk read, then memory-only forever)
load_config()