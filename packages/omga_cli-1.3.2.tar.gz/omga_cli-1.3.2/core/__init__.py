"""
omga-cli – AI-Powered Development Assistant
"""

__version__ = "1.0.0"
__author__  = "Pouria Hosseini"
__email__   = "PouriaHosseini@outlook.com"