"""
Utility helpers for omga-cli.

Functions
─────────
read_file()      – smart path resolution + read
write_file()     – safe write with parent-dir creation
find_file()      – recursive file search from a base directory
run_subprocess() – execute shell command with timeout
diff_text()      – produce a unified diff between two strings
detect_language()– guess programming language from file extension
"""

import difflib
import os
import subprocess
from pathlib import Path
from typing import Optional


# ── File I/O ───────────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    """
    Read and return the text content of *path*.

    Tries (in order):
    1. Absolute path as given
    2. Relative to cwd
    3. Relative to home directory
    4. Expanded ~ path
    5. One and two levels up from cwd (for mono-repo layouts)

    Raises FileNotFoundError if nothing matches.
    """
    candidates = [
        Path(path),
        Path.cwd() / path,
        Path.home() / path,
        Path(path).expanduser(),
        Path.cwd().parent / path,
        Path.cwd().parent.parent / path,
    ]
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
            if resolved.is_file():
                return resolved.read_text(encoding="utf-8")
        except (OSError, ValueError):
            continue
    raise FileNotFoundError(f"File not found: {path}")


def write_file(path: str, content: str) -> None:
    """Write *content* to *path*, creating parent directories as needed."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def find_file(name: str, base_dir: Optional[str] = None) -> Optional[str]:
    """
    Recursively search for *name* under *base_dir* (defaults to cwd).
    Returns the first absolute match, or None.
    """
    root = Path(base_dir) if base_dir else Path.cwd()
    for dirpath, _dirs, files in os.walk(root):
        if name in files:
            return str(Path(dirpath) / name)
    return None


# ── Shell ──────────────────────────────────────────────────────────────────────

def run_subprocess(cmd: str, timeout: int = 120) -> subprocess.CompletedProcess:
    """
    Execute *cmd* in a shell with the given *timeout* (seconds).
    Always captures stdout/stderr; never raises on non-zero exit.
    """
    return subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        timeout=timeout,
    )


# ── Diff ───────────────────────────────────────────────────────────────────────

def diff_text(old: str, new: str, from_label: str = "original", to_label: str = "fixed") -> str:
    """Return a unified diff string comparing *old* to *new*."""
    lines = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=from_label,
        tofile=to_label,
    )
    return "".join(lines)


# ── Language detection ─────────────────────────────────────────────────────────

_EXT_LANG: dict[str, str] = {
    ".py":    "python",
    ".js":    "javascript",
    ".ts":    "typescript",
    ".jsx":   "jsx",
    ".tsx":   "tsx",
    ".java":  "java",
    ".c":     "c",
    ".cpp":   "cpp",
    ".cs":    "csharp",
    ".go":    "go",
    ".rs":    "rust",
    ".rb":    "ruby",
    ".php":   "php",
    ".swift": "swift",
    ".kt":    "kotlin",
    ".sh":    "bash",
    ".bash":  "bash",
    ".zsh":   "bash",
    ".html":  "html",
    ".css":   "css",
    ".scss":  "scss",
    ".sql":   "sql",
    ".json":  "json",
    ".yaml":  "yaml",
    ".yml":   "yaml",
    ".toml":  "toml",
    ".md":    "markdown",
    ".r":     "r",
    ".lua":   "lua",
    ".dart":  "dart",
}


def detect_language(path: str) -> str:
    """Return the Pygments language name for *path*'s extension, or 'text'."""
    ext = Path(path).suffix.lower()
    return _EXT_LANG.get(ext, "text")