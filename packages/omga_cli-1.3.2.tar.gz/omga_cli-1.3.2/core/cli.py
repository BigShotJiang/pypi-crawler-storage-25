"""
omga-cli — AI-Powered Development Assistant

Entry point and Click command definitions.
status and config commands have been removed from the CLI.
"""

import sys
import click

from core.shell import run_shell
from core.commands import (
    ask_handler,
    check_handler,
    docs_handler,
    explain_handler,
    fix_handler,
    generate_handler,
    improve_handler,
    run_handler,
    snippet_handler,
)
from core.ui import ui


# ── Root group ─────────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True, help=__doc__)
@click.pass_context
def main(ctx: click.Context) -> None:
    if ctx.invoked_subcommand is None:
        run_shell()


# ── Sub-commands ───────────────────────────────────────────────────────────────

@main.command()
@click.argument("file", type=click.Path(exists=True))
def check(file: str) -> None:
    """Check syntax and linting of a source file."""
    check_handler(file)


@main.command()
@click.argument("file", type=click.Path(exists=True))
def explain(file: str) -> None:
    """Get a detailed AI explanation of a source file."""
    explain_handler(file)


@main.command()
@click.argument("question", nargs=-1, required=True)
def ask(question: tuple[str, ...]) -> None:
    """Ask the AI any question."""
    ask_handler(" ".join(question))


@main.command()
@click.argument("file", type=click.Path(exists=True))
def fix(file: str) -> None:
    """Detect and apply AI-suggested fixes to a source file."""
    fix_handler(file)


@main.command()
@click.argument("file", type=click.Path(exists=True))
def improve(file: str) -> None:
    """Get AI-powered refactoring suggestions for a source file."""
    improve_handler(file)


@main.command()
@click.argument("file", type=click.Path(exists=True))
def docs(file: str) -> None:
    """Generate documentation for a source file."""
    docs_handler(file)


@main.command()
@click.argument("command", nargs=-1, required=True)
def run(command: tuple[str, ...]) -> None:
    """Execute a shell command safely and show output."""
    exit_code, _out, _err = run_handler(" ".join(command))
    sys.exit(exit_code)


@main.command("generate")
@click.argument("type_", metavar="TYPE", default="project")
@click.argument("template")
@click.argument("name")
def generate_cmd(type_: str, template: str, name: str) -> None:
    """Scaffold a new project from a template (e.g. fastapi)."""
    if type_ != "project":
        ui.print_error("Only 'project' type is currently supported.")
        sys.exit(1)
    generate_handler(template, name)


@main.command("snippet")
@click.argument("action", type=click.Choice(["add", "list", "remove"]))
@click.argument("name",    required=False, default=None)
@click.argument("content", required=False, nargs=-1)
def snippet_cmd(
    action: str, name: str | None, content: tuple[str, ...]
) -> None:
    """Manage reusable code snippets (add / list / remove)."""
    snippet_handler(action, name, " ".join(content) if content else None)


if __name__ == "__main__":
    main()