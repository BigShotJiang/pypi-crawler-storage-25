"""
Interactive REPL shell for omga-cli.

Launches a prompt_toolkit session with:
- Persistent command history
- Tab completion (OmgaCompleter)
- Graceful handling of Ctrl-C / Ctrl-D
- Keyboard interrupt clears the current line without quitting
"""

import os
import sys

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.patch_stdout import patch_stdout

from core.commands import dispatch_command
from core.completer import OmgaCompleter
from core.config import CONFIG_DIR, HISTORY_FILE
from core.logger import logger
from core.ui import ui


def run_shell() -> None:
    """Start the interactive REPL loop."""
    os.makedirs(CONFIG_DIR, exist_ok=True)

    session: PromptSession = PromptSession(
        history=FileHistory(HISTORY_FILE),
        mouse_support=False,
    )
    completer = OmgaCompleter()

    ui.print_welcome()

    while True:
        try:
            with patch_stdout():
                text: str = session.prompt("omga ❯ ", completer=completer)
        except KeyboardInterrupt:
            # Ctrl-C clears the current line
            ui.print_warning("Input cleared — type 'exit' to quit.")
            continue
        except EOFError:
            # Ctrl-D exits cleanly
            ui.print_info("👋  Goodbye! Happy coding!")
            break

        text = text.strip()
        if not text:
            continue

        if text.lower() in ("exit", "quit", "bye"):
            ui.print_info("👋  Goodbye! Happy coding!")
            break

        try:
            dispatch_command(text)
        except Exception as exc:
            logger.exception("Unhandled shell error")
            ui.print_error(f"Unexpected error: {exc}")