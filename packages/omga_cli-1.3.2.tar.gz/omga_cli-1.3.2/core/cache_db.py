"""
SQLite-backed response cache with thread-safe access and automatic TTL expiry.

Each entry stores a prompt hash → response text with a timestamp.
Entries older than TTL_HOURS (default: 24 h) are pruned automatically:
  • on every write  (set_)
  • on every read   (get) — stale entries return None
  • on explicit     (clear_expired)

This keeps the database lightweight and prevents stale AI answers
from being served indefinitely.
"""

import sqlite3
import hashlib
import datetime
import threading
from typing import Optional

from core.config import CACHE_DB

_lock    = threading.Lock()
TTL_HOURS: int = 24   # cache entries expire after this many hours

# ── Schema ─────────────────────────────────────────────────────────────────────
_DDL = """
CREATE TABLE IF NOT EXISTS cache (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
"""


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(CACHE_DB, check_same_thread=False)
    conn.execute(_DDL)
    conn.commit()
    return conn


def _hash(text: str) -> str:
    """Return a stable SHA-256 hex digest of *text* for use as cache key."""
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _cutoff_iso() -> str:
    """Return the ISO timestamp that is exactly TTL_HOURS ago."""
    cutoff = datetime.datetime.now() - datetime.timedelta(hours=TTL_HOURS)
    return cutoff.isoformat(sep=" ", timespec="seconds")


# ── Public API ─────────────────────────────────────────────────────────────────

def get(key: str) -> Optional[str]:
    """
    Return cached value for *key*, or None if absent or expired.

    Expired entries are deleted on access (lazy eviction) so they
    never accumulate silently.
    """
    with _lock:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT value, updated_at FROM cache WHERE key = ?",
                (_hash(key),),
            ).fetchone()

            if row is None:
                return None

            value, updated_at_str = row

            # Parse stored timestamp and check TTL
            try:
                updated_at = datetime.datetime.fromisoformat(updated_at_str)
                age = datetime.datetime.now() - updated_at
                if age.total_seconds() > TTL_HOURS * 3600:
                    # Expired — delete and return None
                    conn.execute("DELETE FROM cache WHERE key = ?", (_hash(key),))
                    conn.commit()
                    return None
            except ValueError:
                # Unparseable timestamp: treat as expired
                conn.execute("DELETE FROM cache WHERE key = ?", (_hash(key),))
                conn.commit()
                return None

            return value
        finally:
            conn.close()


def set_(key: str, value: str) -> None:
    """
    Insert or replace a cache entry.

    Also runs a background sweep to remove all entries older than TTL_HOURS,
    keeping the database compact without ever blocking the caller for long.
    """
    with _lock:
        conn = _connect()
        try:
            now = datetime.datetime.now().isoformat(sep=" ", timespec="seconds")
            conn.execute(
                "INSERT OR REPLACE INTO cache (key, value, updated_at) VALUES (?, ?, ?)",
                (_hash(key), value, now),
            )
            # Sweep stale rows on every write — cheap because updated_at is indexed
            conn.execute(
                "DELETE FROM cache WHERE updated_at < ?",
                (_cutoff_iso(),),
            )
            conn.commit()
        finally:
            conn.close()


def count() -> int:
    """Return total number of non-expired cached entries."""
    with _lock:
        conn = _connect()
        try:
            return conn.execute(
                "SELECT COUNT(*) FROM cache WHERE updated_at >= ?",
                (_cutoff_iso(),),
            ).fetchone()[0]
        finally:
            conn.close()


def clear() -> None:
    """Remove ALL cache entries (expired and non-expired)."""
    with _lock:
        conn = _connect()
        try:
            conn.execute("DELETE FROM cache")
            conn.commit()
        finally:
            conn.close()


def clear_expired() -> int:
    """
    Remove only the entries that have exceeded TTL_HOURS.
    Returns the number of rows deleted.
    """
    with _lock:
        conn = _connect()
        try:
            cursor = conn.execute(
                "DELETE FROM cache WHERE updated_at < ?",
                (_cutoff_iso(),),
            )
            conn.commit()
            return cursor.rowcount
        finally:
            conn.close()