"""
Centralized logger for omga-cli.
Writes to a rotating log file only — no console noise.
"""

import logging
from logging.handlers import RotatingFileHandler
from core.config import LOG_FILE

logger = logging.getLogger("omga")
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    _handler = RotatingFileHandler(
        LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _handler.setLevel(logging.DEBUG)
    _handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    )
    logger.addHandler(_handler)