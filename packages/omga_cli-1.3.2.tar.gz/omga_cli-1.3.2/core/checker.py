"""
Static analysis for source files.

check_file()           – language-aware syntax + lint check
quick_fix_suggestion() – ask AI for a summary of detected issues
"""

import ast
import importlib.util
import os
from typing import Optional

from core.utils import detect_language, find_file, read_file
from core.logger import logger


# ── Language dispatchers ───────────────────────────────────────────────────────

def _check_python(path: str) -> tuple[bool, list[str]]:
    """Parse Python source with ast; optionally run flake8 for style issues."""
    try:
        source = read_file(path)
    except FileNotFoundError as exc:
        return False, [str(exc)]

    # AST syntax check
    try:
        ast.parse(source, filename=path)
    except SyntaxError as exc:
        return False, [f"SyntaxError at line {exc.lineno}: {exc.msg}"]

    messages: list[str] = []

    # Optional flake8 style check (installed separately)
    if importlib.util.find_spec("flake8"):
        try:
            from flake8.api import legacy as flake8
            guide  = flake8.get_style_guide(max_line_length=120, ignore=["E501", "W503"])
            report = guide.check_files([path])
            messages = report.get_statistics("E") + report.get_statistics("W")
        except Exception as exc:
            logger.warning("flake8 check failed: %s", exc)

    return True, messages


def _check_generic(path: str) -> tuple[bool, list[str]]:
    """Fallback checker: just verifies the file is readable UTF-8 text."""
    try:
        read_file(path)
        return True, []
    except FileNotFoundError as exc:
        return False, [str(exc)]
    except UnicodeDecodeError:
        return False, [f"File is not valid UTF-8: {path}"]


# ── Public API ─────────────────────────────────────────────────────────────────

_CHECKERS = {
    "python": _check_python,
}


def check_file(path: str) -> tuple[bool, list[str]]:
    """
    Check *path* for syntax/style issues.

    Returns (ok, messages) where *ok* is False only when the file
    cannot be parsed at all.  Style warnings leave *ok* as True.
    """
    # Resolve the path if it is not absolute
    if not os.path.isabs(path) and not os.path.exists(path):
        resolved = find_file(os.path.basename(path))
        if resolved:
            path = resolved

    lang = detect_language(path)
    checker = _CHECKERS.get(lang, _check_generic)
    return checker(path)


def quick_fix_suggestion(path: str) -> str:
    """
    Run check_file() and ask the AI to summarise detected problems.
    Returns a plain-text suggestion string.
    """
    # Import here to avoid circular dependency at module load time
    from core.ai import ask

    ok, messages = check_file(path)

    if ok and not messages:
        return "✅ No issues found – the file looks clean."

    summary = "; ".join(messages[:20])  # cap at 20 to keep the prompt concise
    prompt  = (
        f"The following issues were detected in a source file:\n\n{summary}\n\n"
        "Summarise these issues clearly and suggest precise fixes for each one."
    )
    return ask(prompt)