"""
Terminal UI layer for omga-cli.

Rendering architecture
───────────────────────
stream_response() is the single rendering engine for all AI output:

  1. Opens Live immediately (spinner visible from the first millisecond).
  2. Launches a background thread that consumes the network stream and
     pushes chunks into a queue.
  3. Main thread drains the queue, updates the Live panel:
       • No chunks yet  → spinner animation
       • Chunks arriving → live text with cursor ▌
       • Stream done    → final Markdown render, Live exits (transient=False)

This guarantees:
  • Spinner is visible BEFORE the first HTTP byte arrives.
  • No double-spinner (thinking_spinner + stream_response).
  • Full panel stays in the scroll buffer (vertical_overflow="visible").
  • Exactly ONE Live context is ever open at a time.

print_ai_response_stream() simply calls stream_response() — no peeking,
no pre-consumption, no race between network and Live open.
"""

import os
import queue
import sys
import time
import threading
from contextlib import contextmanager
from enum import Enum
from typing import Any, Callable, Dict, Iterator, List, Optional, TypeVar

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console, Group
from rich.live import Live
from rich.markdown import Markdown
from rich.padding import Padding
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

from core.logger import logger

T = TypeVar("T")
_SENTINEL = object()   # marks end-of-stream in the queue


# ── Persian helpers ────────────────────────────────────────────────────────────

def _has_persian(text: str) -> bool:
    for ch in text:
        cp = ord(ch)
        if (0x0600 <= cp <= 0x06FF or
                0xFB50 <= cp <= 0xFDFF or
                0xFE70 <= cp <= 0xFEFF):
            return True
    return False


def _body_text(content: str, persian: bool = False) -> Text:
    t = Text(content, style="white", no_wrap=False, overflow="fold")
    if persian:
        t.justify = "right"
    return t


# ── Colour palette ─────────────────────────────────────────────────────────────

class _C:
    ACCENT     = "#7C5CBF"
    ACCENT_LT  = "#A07DD4"
    CYAN_DIM   = "#4A9EAE"
    CYAN_BRT   = "#5BC8DC"
    OK         = "#50C878"
    ERR        = "#E05555"
    WRN        = "#D4A017"
    INF        = "#5A9FD4"
    CODE       = "#5A9FD4"
    DOLD       = "#C0505A"
    DNEW       = "#50A878"
    TBL        = "#5A9FD4"
    SP         = ["#7C5CBF", "#A07DD4", "#5BC8DC", "#A07DD4", "#7C5CBF", "#4A9EAE"]


# ── Spinner frames ─────────────────────────────────────────────────────────────

_BRAILLE   = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
_LABELS_EN = ["Thinking", "Processing", "Analyzing", "Generating"]
_LABELS_FA = ["در حال فکر کردن", "در حال پردازش", "در حال تحلیل", "در حال تولید"]


# ── Message types ──────────────────────────────────────────────────────────────

class MessageType(Enum):
    SUCCESS = "success"
    ERROR   = "error"
    WARNING = "warning"
    INFO    = "info"
    DEBUG   = "debug"


_ICONS: Dict[MessageType, str] = {
    MessageType.SUCCESS: "✓",
    MessageType.ERROR:   "✗",
    MessageType.WARNING: "⚠",
    MessageType.INFO:    "·",
    MessageType.DEBUG:   "◈",
}
_MSG_C: Dict[MessageType, str] = {
    MessageType.SUCCESS: _C.OK,
    MessageType.ERROR:   _C.ERR,
    MessageType.WARNING: _C.WRN,
    MessageType.INFO:    _C.INF,
    MessageType.DEBUG:   "white",
}
_THEME = Theme({
    "success": f"bold {_C.OK}",
    "error":   f"bold {_C.ERR}",
    "warning": f"bold {_C.WRN}",
    "info":    f"bold {_C.INF}",
    "debug":   "dim white",
    "accent":  _C.ACCENT,
    "muted":   "dim white",
})


# ── ASCII logo ─────────────────────────────────────────────────────────────────

_LOGO = """\
  ██████╗ ███╗   ███╗ ██████╗  █████╗ 
 ██╔═══██╗████╗ ████║██╔════╝ ██╔══██╗
 ██║   ██║██╔████╔██║██║  ███╗███████║
 ██║   ██║██║╚██╔╝██║██║   ██║██╔══██║
 ╚██████╔╝██║ ╚═╝ ██║╚██████╔╝██║  ██║
  ╚═════╝ ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝"""


# ── Panel builders ─────────────────────────────────────────────────────────────

def _mk_spinner(fi: int, elapsed: float, title: str,
                persian: bool = False) -> Panel:
    """Animated thinking panel — shown while waiting for the first token."""
    colour = _C.SP[fi % len(_C.SP)]
    arc    = _BRAILLE[fi % len(_BRAILLE)]
    labels = _LABELS_FA if persian else _LABELS_EN
    label  = labels[(fi // 10) % len(labels)]

    bar_len = 18
    filled  = fi % (bar_len + 1)
    bar     = "█" * filled + "░" * (bar_len - filled)

    line = Text(justify="center")
    line.append(f"  {arc}  ", style=f"bold {colour}")
    line.append(label, style=colour)
    line.append(f"  {elapsed:.1f}s\n\n", style="dim white")
    line.append(f"  {bar}  ", style=f"dim {colour}")

    inner: Any = Align.right(line) if persian else Align.center(line)
    return Panel(
        inner,
        title=f"[bold {_C.ACCENT_LT}]◈  {title}[/]",
        border_style=colour,
        box=box.ROUNDED,
        padding=(1, 4),
    )


def _mk_stream(text: str, title: str, final: bool = False,
               persian: bool = False) -> Panel:
    """
    Streaming/final response panel.
    final=False → plain text + ▌ (fast, no Markdown parse on every chunk).
    final=True  → Markdown with syntax highlighting.
    """
    if persian is False:
        persian = _has_persian(text)

    if not final:
        body: Any = _body_text(text + " ▌", persian)
        inner: Any = Align.right(body) if persian else body
    else:
        if persian:
            inner = Align.right(_body_text(text, persian=True))
        else:
            try:
                inner = Markdown(text, code_theme="monokai")
            except Exception:
                inner = _body_text(text)

    return Panel(
        inner,
        title=f"[bold {_C.ACCENT_LT}]◈  {title}[/]",
        border_style=_C.ACCENT,
        box=box.ROUNDED,
        padding=(1, 3),
    )


# ── OmgaUI ─────────────────────────────────────────────────────────────────────

class OmgaUI:
    """Single-console, single-Live-context terminal UI."""

    def __init__(self) -> None:
        self._dumb: bool = (
            not sys.stdout.isatty()
            or bool(os.getenv("NO_COLOR"))
            or os.getenv("TERM") == "dumb"
        )
        self.console = Console(
            theme=_THEME,
            soft_wrap=True,
            highlight=False,
            markup=True,
            file=sys.stdout,
        )

    def _print(self, *args: Any, **kwargs: Any) -> None:
        self.console.print(*args, **kwargs)

    # ── Core: stream_response ──────────────────────────────────────────────────

    def stream_response(
        self,
        stream:  Iterator[str],
        title:   str  = "AI Response",
        persian: bool = False,
    ) -> str:
        """
        The single rendering engine for all AI output.

        Architecture:
        ─────────────
        • Live opens FIRST — spinner is visible from the very first ms.
        • A background thread consumes `stream` and pushes chunks to a queue.
        • Main thread drains the queue and updates Live:
            no chunks → spinner animation
            chunks    → growing text with ▌ cursor
            done      → Markdown final render, Live exits
        • vertical_overflow='visible' keeps full content in scroll buffer.
        """
        if self._dumb:
            labels = _LABELS_FA if persian else _LABELS_EN
            sys.stdout.write(f"{labels[0]}...\n")
            sys.stdout.flush()
            acc: List[str] = []
            for chunk in stream:
                if chunk:
                    acc.append(chunk)
                    sys.stdout.write(chunk)
                    sys.stdout.flush()
            sys.stdout.write("\n")
            return "".join(acc).strip()

        q: queue.Queue = queue.Queue()
        err_ref: List[BaseException] = []

        def _producer() -> None:
            try:
                for chunk in stream:
                    if chunk:
                        q.put(chunk)
            except BaseException as exc:
                err_ref.append(exc)
            finally:
                q.put(_SENTINEL)

        threading.Thread(target=_producer, daemon=True).start()

        accumulated: List[str] = []
        streaming   = False
        start_ts    = time.monotonic()
        fi          = 0

        try:
            with Live(
                _mk_spinner(0, 0.0, title, persian),
                console=self.console,
                refresh_per_second=20,
                vertical_overflow="visible",
                transient=False,
            ) as live:
                while True:
                    try:
                        item = q.get(timeout=0.06)
                    except queue.Empty:
                        # No chunk yet — animate spinner
                        if not streaming:
                            fi += 1
                            live.update(_mk_spinner(
                                fi, time.monotonic() - start_ts, title, persian
                            ))
                        continue

                    if item is _SENTINEL:
                        break

                    if not streaming:
                        streaming = True

                    accumulated.append(item)
                    live.update(
                        _mk_stream("".join(accumulated), title,
                                   final=False, persian=persian)
                    )

                # Final render
                full_text = "".join(accumulated).strip()
                if full_text:
                    live.update(
                        _mk_stream(full_text, title, final=True, persian=persian)
                    )
                else:
                    live.update(Panel(
                        Text("No response received.", style="dim white"),
                        title=f"[bold {_C.ACCENT_LT}]◈  {title}[/]",
                        border_style=_C.WRN,
                        box=box.ROUNDED,
                        padding=(1, 3),
                    ))

        except Exception as exc:
            logger.error("stream_response error: %s", exc)
            if accumulated:
                self._print(_mk_stream(
                    "".join(accumulated).strip(), title, final=True
                ))
            else:
                self.print_error(f"Stream error: {exc}")

        if err_ref and not accumulated:
            raise err_ref[0]

        return "".join(accumulated).strip()

    # ── thinking_spinner (for blocking ask() calls only) ──────────────────────

    @contextmanager
    def thinking_spinner(self, persian: bool = False):
        """
        Standalone spinner used by the blocking ask() function.
        transient=True — erases on exit.
        NOT used by ask_stream() — stream_response() owns the spinner there.
        """
        if self._dumb:
            labels = _LABELS_FA if persian else _LABELS_EN
            sys.stdout.write(f"{labels[0]}...\n")
            sys.stdout.flush()
            yield
            return

        start_ts = time.monotonic()
        stop_evt = threading.Event()
        fi_ref   = [0]

        try:
            with Live(
                _mk_spinner(0, 0.0, "omga", persian),
                console=self.console,
                refresh_per_second=15,
                vertical_overflow="visible",
                transient=True,
            ) as live:
                def _tick() -> None:
                    while not stop_evt.is_set():
                        fi_ref[0] += 1
                        live.update(_mk_spinner(
                            fi_ref[0],
                            time.monotonic() - start_ts,
                            "omga", persian,
                        ))
                        time.sleep(0.06)

                threading.Thread(target=_tick, daemon=True).start()
                yield
        finally:
            stop_evt.set()

    def with_thinking(
        self,
        fn:      Callable[..., T],
        *args:   Any,
        persian: bool = False,
        **kwargs: Any,
    ) -> T:
        if not persian:
            for a in args:
                if isinstance(a, str) and _has_persian(a):
                    persian = True
                    break
        with self.thinking_spinner(persian=persian):
            return fn(*args, **kwargs)

    # ── print_ai_response_stream ───────────────────────────────────────────────

    def print_ai_response_stream(
        self,
        stream: Iterator[str],
        title:  str = "AI Response",
    ) -> str:
        """
        Pass stream directly to stream_response().
        Live opens BEFORE any chunk is pulled from the network —
        spinner is visible from the first millisecond.
        """
        # Detect Persian from the prompt title hint if possible,
        # otherwise stream_response will detect from content.
        persian = _has_persian(title)
        return self.stream_response(stream, title=title, persian=persian)

    # ── Static AI response ─────────────────────────────────────────────────────

    def print_ai_response(self, response: str, title: str = "AI Response") -> None:
        if not response or not response.strip():
            return
        self._print(_mk_stream(response.strip(), title, final=True))

    # ── Message panels ─────────────────────────────────────────────────────────

    def print_message(
        self,
        message:  str,
        msg_type: MessageType = MessageType.INFO,
        title:    Optional[str] = None,
    ) -> None:
        colour = _MSG_C[msg_type]
        icon   = _ICONS[msg_type]
        label  = title or msg_type.value.capitalize()
        is_fa  = _has_persian(message)

        body = Text(no_wrap=False, overflow="fold")
        body.append(f"{icon}  ", style=f"bold {colour}")
        body.append(message, style="white")
        if is_fa:
            body.justify = "right"

        self._print(Panel(
            body,
            title=f"[bold {colour}]{label}[/]",
            border_style=colour,
            box=box.ROUNDED,
            padding=(0, 2),
        ))

    def print_success(self, msg: str, title: str = "Success") -> None:
        self.print_message(msg, MessageType.SUCCESS, title)

    def print_error(self, msg: str, title: str = "Error") -> None:
        self.print_message(msg, MessageType.ERROR, title)

    def print_warning(self, msg: str, title: str = "Warning") -> None:
        self.print_message(msg, MessageType.WARNING, title)

    def print_info(self, msg: str, title: str = "Info") -> None:
        self.print_message(msg, MessageType.INFO, title)

    # ── Code block ─────────────────────────────────────────────────────────────

    def print_code_block(
        self,
        code:         str,
        language:     str  = "python",
        title:        Optional[str] = None,
        line_numbers: bool = True,
    ) -> None:
        syntax = Syntax(
            code, language,
            line_numbers=line_numbers,
            theme="monokai",
            word_wrap=True,
        )
        self._print(Panel(
            syntax,
            title=(f"[bold {_C.CODE}]{title}[/]" if title else ""),
            border_style=_C.CODE,
            box=box.ROUNDED,
            padding=(1, 2),
        ))

    # ── Diff ───────────────────────────────────────────────────────────────────

    def print_diff(self, old: str, new: str, title: str = "Proposed Changes") -> None:
        self._print(Rule(
            f"[bold {_C.ACCENT_LT}]{title}[/]",
            style=_C.ACCENT,
        ))
        self._print(Columns([
            Panel(Syntax(old, "python", theme="monokai"),
                  title=f"[bold {_C.DOLD}]Original[/]",
                  border_style=_C.DOLD, box=box.ROUNDED),
            Panel(Syntax(new, "python", theme="monokai"),
                  title=f"[bold {_C.DNEW}]Fixed[/]",
                  border_style=_C.DNEW, box=box.ROUNDED),
        ], equal=True, expand=True))
        self._print()

    # ── Table ──────────────────────────────────────────────────────────────────

    def print_table(
        self,
        data:          List[Dict[str, Any]],
        title:         str = "Results",
        highlight_col: Optional[str] = None,
    ) -> None:
        if not data:
            self.print_warning("No data to display.")
            return
        table = Table(
            title=title,
            show_header=True,
            header_style=f"bold {_C.TBL}",
            border_style=_C.ACCENT,
            box=box.ROUNDED,
            show_lines=False,
            expand=False,
        )
        for col in data[0]:
            table.add_column(
                col,
                style="bold white" if col == highlight_col else "white",
                overflow="fold",
            )
        for row in data:
            table.add_row(*[str(row.get(c, "")) for c in data[0]])
        self._print(table)

    # ── Help ───────────────────────────────────────────────────────────────────

    def print_help(self, commands: Dict[str, str]) -> None:
        table = Table(
            title="Commands",
            show_header=True,
            header_style=f"bold {_C.TBL}",
            border_style=_C.ACCENT,
            box=box.ROUNDED,
            min_width=60,
            expand=False,
        )
        table.add_column("Command",     style=f"bold {_C.CYAN_BRT}", no_wrap=True, min_width=34)
        table.add_column("Description", style="white")
        for cmd, desc in commands.items():
            table.add_row(cmd, desc)
        self._print(table)

    # ── Welcome ────────────────────────────────────────────────────────────────

    def print_welcome(self) -> None:
        logo = Text(_LOGO, style=f"bold {_C.ACCENT}", justify="center", no_wrap=False)

        sub = Text(justify="center")
        sub.append("AI-Powered Development Assistant\n", style=f"dim {_C.ACCENT_LT}")
        sub.append("\n")
        sub.append("by ", style="dim white")
        sub.append("Pouria Hosseini", style=f"bold {_C.CYAN_BRT}")
        sub.append("  ·  ", style="dim white")
        sub.append("PouriaHosseini.ir\n", style=f"dim {_C.CYAN_DIM}")
        sub.append("\n")
        sub.append("type ", style="dim white")
        sub.append("help", style=f"bold {_C.CYAN_BRT}")
        sub.append("  for commands  ·  ", style="dim white")
        sub.append("exit", style=f"bold {_C.CYAN_BRT}")
        sub.append("  to quit", style="dim white")

        content = Group(
            Align.center(logo),
            Align.center(Padding(sub, (1, 0, 0, 0))),
        )

        self._print(Panel(
            Padding(content, (1, 4)),
            border_style=_C.ACCENT,
            box=box.DOUBLE_EDGE,
            padding=(0, 2),
        ))
        self._print()

    # ── Prompts ────────────────────────────────────────────────────────────────

    def confirm(self, message: str, default: bool = False) -> bool:
        hint = "Y/n" if default else "y/N"
        raw  = input(f"\n  {message} [{hint}]: ").strip().lower()
        return default if not raw else raw in ("y", "yes")

    def prompt(self, message: str, default: str = "") -> str:
        hint = f" [{default}]" if default else ""
        return input(f"\n  {message}{hint}: ").strip() or default


# ── Singleton ──────────────────────────────────────────────────────────────────
ui = OmgaUI()