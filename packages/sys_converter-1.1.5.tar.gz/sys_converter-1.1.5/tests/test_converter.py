"""
Tests for the sys_converter module
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sys_converter import sys


class TestSysConverter(unittest.TestCase):
    """Tests for the number system conversion function"""

    def test_integer_conversion(self):
        """Test integer conversion"""
        self.assertEqual(sys(0, 2), "0")
        self.assertEqual(sys(10, 2), "1010")
        self.assertEqual(sys(255, 16), "FF")
        self.assertEqual(sys(36, 36), "10")

    def test_float_conversion(self):
        """Test float number conversion"""
        self.assertEqual(sys(10.5, 2), "1010.1")
        self.assertEqual(sys(10.625, 2), "1010.101")

    def test_error_handling(self):
        """Test error handling"""
        self.assertIn("greater than 36", sys(10, 37))
        self.assertIn("less than 2", sys(10, 1))
        self.assertIn("float number", sys(10, 2.5))
        self.assertIn("negative number", sys(-10, 2))

    def test_edge_cases(self):
        """Test edge cases"""
        self.assertEqual(sys(0, 2), "0")
        self.assertEqual(sys(1, 2), "1")
        self.assertEqual(sys(35, 36), "Z")


if __name__ == '__main__':
    unittest.main()