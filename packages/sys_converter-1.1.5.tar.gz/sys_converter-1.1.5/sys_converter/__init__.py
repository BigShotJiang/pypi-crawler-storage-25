"""
Sys Converter - a library for converting numbers between different number systems.

Main features:
- Convert integers to any number system (2-36)
- Convert fractional numbers with precision limit
- Error handling and input validation
"""

__version__ = "1.1.1"
__author__ = "BasicSweater"

from .converter import sys, resys

__all__ = ["sys", "resys"]