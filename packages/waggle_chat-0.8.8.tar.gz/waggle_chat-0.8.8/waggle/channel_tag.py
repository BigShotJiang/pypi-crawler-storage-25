"""Channel-tag wire format v1.

Every inbound message handed to the agent is wrapped in a `<channel …>` tag so
the agent can tell where it came from without the runtime needing a special
prompt-construction protocol per platform.

Format (v1, frozen):

    <channel source="telegram" chat="-1001234" user="908624017" ts="2026-04-29T10:00:00Z">
    body
    </channel>

Attributes are escaped with the standard XML attribute rules (we limit
ourselves to the four chars XML cares about). The body is wrapped verbatim;
agent prompts that contain the literal string `</channel>` are an attack
surface — callers must reject those upstream, not us.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone


_ATTR_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}


def _escape_attr(value: str) -> str:
    out = []
    for c in value:
        out.append(_ATTR_ESCAPES.get(c, c))
    return "".join(out)


@dataclass(frozen=True, slots=True)
class ChannelTag:
    """Identifies the platform-side origin of one inbound message."""

    source: str  # "telegram", "matrix", "external", …
    chat: str  # platform-native chat id (string for safety even when numeric)
    user: str  # platform-native sender id; "" for synthetic / external sources
    ts: datetime

    @staticmethod
    def now(source: str, chat: str | int, user: str | int) -> "ChannelTag":
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=datetime.now(timezone.utc),
        )

    @staticmethod
    def at(source: str, chat: str | int, user: str | int,
           ts: datetime) -> "ChannelTag":
        """Build a tag with an explicit timestamp — use this when the
        source provides one (e.g. Telegram's `message.date`) so the
        channel-tag carries when the user actually sent the message,
        not when waggle received it."""
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=ts.astimezone(timezone.utc) if ts.tzinfo else ts.replace(tzinfo=timezone.utc),
        )

    def render(
        self,
        body: str,
        attachments: tuple[dict, ...] | list[dict] = (),
    ) -> str:
        """Render the full `<channel …>body</channel>` block.

        `attachments` is the same shape `_extract_attachments` returns —
        `({"kind": "photo", "file_id": "AAA", "mime_type": "..."}, ...)`.
        When non-empty, a single "[attachments] …" line is prepended to the
        body so the agent knows there's media bound to this message and
        can call the `download_attachment` MCP tool with the file_id to
        fetch it. The agent must call download_attachment itself — waggle
        does NOT pre-download (would fight large files / wasted bandwidth
        on attachments the agent never opens).
        """
        ts_iso = self.ts.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        opening = (
            f'<channel source="{_escape_attr(self.source)}" '
            f'chat="{_escape_attr(self.chat)}" '
            f'user="{_escape_attr(self.user)}" '
            f'ts="{ts_iso}">'
        )
        attach_line = ""
        if attachments:
            parts = []
            paths_present = False
            for a in attachments:
                kind = a.get("kind", "file")
                path = a.get("path") or ""
                fid = a.get("file_id", "")
                mime = a.get("mime_type", "")
                bits = [kind]
                if path:
                    bits.append(f"path={path}")
                    paths_present = True
                if fid:
                    bits.append(f"file_id={fid}")
                if mime:
                    bits.append(f"mime={mime}")
                parts.append(" ".join(bits))
            # When at least one path is present (the common case — waggle
            # eagerly downloads on inbound), the agent should Read the
            # local file directly. file_id remains as fallback for the
            # rare cases where the eager fetch failed.
            hint = (
                " — Read the local path(s) directly; fall back to "
                "the `download_attachment` tool if a path is missing."
                if paths_present
                else " — call the `download_attachment` tool with the "
                "file_id to fetch each one to a local path before reading it."
            )
            attach_line = "[attachments] " + "; ".join(parts) + hint + "\n"
        return f"{opening}\n{attach_line}{body}\n</channel>"


# Parser — used only by tests today. Production agents speak text; this lets
# unit tests verify round-trip without exposing internal struct.
_TAG_RE = re.compile(
    r'^<channel\s+source="(?P<source>[^"]*)"\s+chat="(?P<chat>[^"]*)"\s+'
    r'user="(?P<user>[^"]*)"\s+ts="(?P<ts>[^"]*)">\n(?P<body>.*)\n</channel>$',
    re.DOTALL,
)


def parse(rendered: str) -> tuple[ChannelTag, str]:
    m = _TAG_RE.match(rendered)
    if not m:
        raise ValueError("not a channel-tag v1 block")
    ts = datetime.strptime(m.group("ts"), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    tag = ChannelTag(
        source=m.group("source"),
        chat=m.group("chat"),
        user=m.group("user"),
        ts=ts,
    )
    return tag, m.group("body")
