"""Tests for recursive-refine depth-cap behavior (ENH-1347) and cycle detection (ENH-1338).

Tests the depth-tracking and cycle-detection bash/python logic for parse_input,
dequeue_next, check_depth, enqueue_children / enqueue_or_skip, and done states by
executing shell snippets directly against a tmp_path environment.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


def _bash(script: str, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["bash", "-c", script], cwd=cwd, capture_output=True, text=True)


class TestDepthMapInit:
    """parse_input depth-map initialization."""

    def test_root_ids_written_at_depth_zero(self, tmp_path: Path) -> None:
        """parse_input writes all root IDs to depth-map at depth 0."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-001\nENH-002\n")

        _bash(
            r"""
            while IFS= read -r id; do echo "$id 0"; done \
              < .loops/tmp/recursive-refine-queue.txt \
              > .loops/tmp/recursive-refine-depth-map.txt
            > .loops/tmp/recursive-refine-skipped-depth.txt
            """,
            tmp_path,
        )

        depth_map = (loops_tmp / "recursive-refine-depth-map.txt").read_text()
        assert "ENH-001 0" in depth_map
        assert "ENH-002 0" in depth_map

    def test_skipped_depth_file_is_cleared(self, tmp_path: Path) -> None:
        """parse_input clears any stale recursive-refine-skipped-depth.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("stale-entry\n")

        _bash(
            r"""
            while IFS= read -r id; do echo "$id 0"; done \
              < .loops/tmp/recursive-refine-queue.txt \
              > .loops/tmp/recursive-refine-depth-map.txt
            > .loops/tmp/recursive-refine-skipped-depth.txt
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-skipped-depth.txt").read_text() == ""

    def test_skipped_decomposed_file_is_initialized(self, tmp_path: Path) -> None:
        """parse_input initializes recursive-refine-skipped-decomposed.txt to empty."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("stale-entry\n")

        _bash(
            r"""
            printf '' > .loops/tmp/recursive-refine-skipped-decomposed.txt
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-skipped-decomposed.txt").read_text() == ""

    def test_skipped_deadend_file_is_initialized(self, tmp_path: Path) -> None:
        """parse_input initializes recursive-refine-skipped-deadend.txt to empty."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("stale-entry\n")

        _bash(
            r"""
            printf '' > .loops/tmp/recursive-refine-skipped-deadend.txt
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-skipped-deadend.txt").read_text() == ""


class TestParseInputDedup:
    """parse_input deduplication of comma-separated input."""

    def test_duplicate_ids_written_once_to_queue(self, tmp_path: Path) -> None:
        """parse_input deduplicates the comma-split queue via sort -u."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        _bash(
            r"""
            INPUT="ENH-001,ENH-002,ENH-001,ENH-003,ENH-002"
            mkdir -p .loops/tmp
            printf '' > .loops/tmp/recursive-refine-visited.txt
            echo "$INPUT" | tr ',' '\n' \
              | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
              | grep -v '^[[:space:]]*$' \
              | sort -u \
              > .loops/tmp/recursive-refine-queue.txt
            """,
            tmp_path,
        )

        queue = (loops_tmp / "recursive-refine-queue.txt").read_text()
        lines = [ln for ln in queue.splitlines() if ln.strip()]
        assert lines.count("ENH-001") == 1
        assert lines.count("ENH-002") == 1
        assert lines.count("ENH-003") == 1
        assert len(lines) == 3

    def test_visited_file_created_empty_by_parse_input(self, tmp_path: Path) -> None:
        """parse_input creates (or clears) recursive-refine-visited.txt for the new run."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("stale-entry\n")

        _bash(
            r"""
            printf '' > .loops/tmp/recursive-refine-visited.txt
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-visited.txt").read_text() == ""


class TestDequeueDepth:
    """dequeue_next depth lookup."""

    def test_writes_depth_from_map_to_current_depth_file(self, tmp_path: Path) -> None:
        """dequeue_next reads depth from depth-map and writes to recursive-refine-current-depth.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-010\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("ENH-010 1\n")

        result = _bash(
            r"""
            CURRENT=$(head -1 .loops/tmp/recursive-refine-queue.txt)
            tail -n +2 .loops/tmp/recursive-refine-queue.txt \
              > .loops/tmp/recursive-refine-queue.tmp
            mv .loops/tmp/recursive-refine-queue.tmp .loops/tmp/recursive-refine-queue.txt
            DEPTH=$(grep "^$CURRENT " .loops/tmp/recursive-refine-depth-map.txt 2>/dev/null \
              | awk '{print $2}')
            printf '%s' "${DEPTH:-0}" > .loops/tmp/recursive-refine-current-depth.txt
            echo "$CURRENT"
            """,
            tmp_path,
        )

        assert result.stdout.strip() == "ENH-010"
        assert (loops_tmp / "recursive-refine-current-depth.txt").read_text() == "1"

    def test_defaults_to_zero_when_id_absent_from_map(self, tmp_path: Path) -> None:
        """dequeue_next defaults depth to 0 when issue ID is not in depth-map."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-999\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("")

        _bash(
            r"""
            CURRENT=$(head -1 .loops/tmp/recursive-refine-queue.txt)
            tail -n +2 .loops/tmp/recursive-refine-queue.txt \
              > .loops/tmp/recursive-refine-queue.tmp
            mv .loops/tmp/recursive-refine-queue.tmp .loops/tmp/recursive-refine-queue.txt
            DEPTH=$(grep "^$CURRENT " .loops/tmp/recursive-refine-depth-map.txt 2>/dev/null \
              | awk '{print $2}')
            printf '%s' "${DEPTH:-0}" > .loops/tmp/recursive-refine-current-depth.txt
            echo "$CURRENT"
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-current-depth.txt").read_text() == "0"


class TestVisitedSetAppend:
    """dequeue_next appends dequeued ID to recursive-refine-visited.txt."""

    def test_dequeued_id_appears_in_visited_file(self, tmp_path: Path) -> None:
        """dequeue_next appends current ID to visited.txt on each dequeue."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-042\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("ENH-042 0\n")
        (loops_tmp / "recursive-refine-visited.txt").write_text("")

        result = _bash(
            r"""
            CURRENT=$(head -1 .loops/tmp/recursive-refine-queue.txt)
            tail -n +2 .loops/tmp/recursive-refine-queue.txt \
              > .loops/tmp/recursive-refine-queue.tmp
            mv .loops/tmp/recursive-refine-queue.tmp .loops/tmp/recursive-refine-queue.txt
            echo "$CURRENT" >> .loops/tmp/recursive-refine-visited.txt
            DEPTH=$(grep "^$CURRENT " .loops/tmp/recursive-refine-depth-map.txt 2>/dev/null \
              | awk '{print $2}')
            printf '%s' "${DEPTH:-0}" > .loops/tmp/recursive-refine-current-depth.txt
            echo "$CURRENT"
            """,
            tmp_path,
        )

        assert result.stdout.strip() == "ENH-042"
        assert "ENH-042" in (loops_tmp / "recursive-refine-visited.txt").read_text()

    def test_multiple_dequeues_accumulate_visited(self, tmp_path: Path) -> None:
        """Each dequeue appends to visited.txt; two dequeues produce two entries."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-001\nENH-002\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("ENH-001 0\nENH-002 0\n")
        (loops_tmp / "recursive-refine-visited.txt").write_text("")

        _bash(
            r"""
            for _ in 1 2; do
              CURRENT=$(head -1 .loops/tmp/recursive-refine-queue.txt)
              tail -n +2 .loops/tmp/recursive-refine-queue.txt \
                > .loops/tmp/recursive-refine-queue.tmp
              mv .loops/tmp/recursive-refine-queue.tmp .loops/tmp/recursive-refine-queue.txt
              echo "$CURRENT" >> .loops/tmp/recursive-refine-visited.txt
            done
            """,
            tmp_path,
        )

        visited = (loops_tmp / "recursive-refine-visited.txt").read_text()
        assert "ENH-001" in visited
        assert "ENH-002" in visited


def _check_depth_script(current_id: str, max_depth: int = 2) -> str:
    return rf"""
    MAX_DEPTH={max_depth}
    CURRENT_DEPTH=$(cat .loops/tmp/recursive-refine-current-depth.txt 2>/dev/null || echo 0)
    if [ "$CURRENT_DEPTH" -ge "$MAX_DEPTH" ]; then
      echo "{current_id}" >> .loops/tmp/recursive-refine-skipped-depth.txt
      echo "{current_id}" >> .loops/tmp/recursive-refine-skipped.txt
      echo 1
    else
      echo 0
    fi
    """


class TestCheckDepth:
    """check_depth gate state."""

    def _setup(self, tmp_path: Path, depth: int) -> Path:
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True, exist_ok=True)
        (loops_tmp / "recursive-refine-current-depth.txt").write_text(str(depth))
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")
        return loops_tmp

    def test_at_max_depth_echoes_1_and_writes_both_skip_files(self, tmp_path: Path) -> None:
        """Depth == max_depth: echoes 1 and writes ID to both skip files."""
        loops_tmp = self._setup(tmp_path, depth=2)

        result = _bash(_check_depth_script("ENH-999", max_depth=2), tmp_path)

        assert result.stdout.strip() == "1"
        assert "ENH-999" in (loops_tmp / "recursive-refine-skipped-depth.txt").read_text()
        assert "ENH-999" in (loops_tmp / "recursive-refine-skipped.txt").read_text()

    def test_above_max_depth_also_echoes_1(self, tmp_path: Path) -> None:
        """Depth > max_depth is also capped."""
        loops_tmp = self._setup(tmp_path, depth=3)

        result = _bash(_check_depth_script("ENH-888", max_depth=2), tmp_path)

        assert result.stdout.strip() == "1"
        assert "ENH-888" in (loops_tmp / "recursive-refine-skipped-depth.txt").read_text()

    def test_below_max_depth_echoes_0_and_no_skip_writes(self, tmp_path: Path) -> None:
        """Depth < max_depth: echoes 0 and does not write to skip files."""
        loops_tmp = self._setup(tmp_path, depth=1)

        result = _bash(_check_depth_script("ENH-100", max_depth=2), tmp_path)

        assert result.stdout.strip() == "0"
        assert "ENH-100" not in (loops_tmp / "recursive-refine-skipped-depth.txt").read_text()
        assert "ENH-100" not in (loops_tmp / "recursive-refine-skipped.txt").read_text()

    def test_four_level_decomposition_grandchildren_capped(self, tmp_path: Path) -> None:
        """Synthetic 4-level tree with max_depth=2: depth>=2 issues are capped.

        Tree: ROOT(0) → CHILD(1) → GRAND(2) → GREAT(3)
        ROOT and CHILD pass; GRAND and GREAT are depth-capped.
        """
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")

        for issue_id, depth, expected_echo in [
            ("ROOT", 0, "0"),
            ("CHILD", 1, "0"),
            ("GRAND", 2, "1"),
            ("GREAT", 3, "1"),
        ]:
            (loops_tmp / "recursive-refine-current-depth.txt").write_text(str(depth))
            result = _bash(_check_depth_script(issue_id, max_depth=2), tmp_path)
            assert result.stdout.strip() == expected_echo, (
                f"{issue_id} at depth {depth} should echo {expected_echo}"
            )

        depth_skipped = (loops_tmp / "recursive-refine-skipped-depth.txt").read_text()
        assert "GRAND" in depth_skipped
        assert "GREAT" in depth_skipped
        assert "ROOT" not in depth_skipped
        assert "CHILD" not in depth_skipped


def _check_attempt_budget_script(issue_id: str, max_count: int = 5) -> str:
    return rf"""
    python3 << 'PYEOF'
import sys
from pathlib import Path
issue_id = '{issue_id}'
cap = {max_count}
attempts_file = '.loops/tmp/recursive-refine-attempts.txt'
try:
    lines = Path(attempts_file).read_text().splitlines()
except FileNotFoundError:
    lines = []
count = sum(1 for ln in lines if ln.strip() == issue_id)
if count >= cap:
    with open('.loops/tmp/recursive-refine-skipped-budget.txt', 'a') as f:
        f.write(issue_id + '\n')
    with open('.loops/tmp/recursive-refine-skipped.txt', 'a') as f:
        f.write(issue_id + '\n')
    sys.exit(1)
with open(attempts_file, 'a') as f:
    f.write(issue_id + '\n')
sys.exit(0)
PYEOF
    """


class TestCheckAttemptBudget:
    """check_attempt_budget gate state."""

    def _setup(self, tmp_path: Path, attempts: int, issue_id: str = "ENH-001") -> Path:
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True, exist_ok=True)
        content = "\n".join([issue_id] * attempts) + ("\n" if attempts else "")
        (loops_tmp / "recursive-refine-attempts.txt").write_text(content)
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")
        return loops_tmp

    def test_below_cap_exits_0_and_appends_to_attempts(self, tmp_path: Path) -> None:
        """Below cap: exits 0 and appends issue_id to attempts file."""
        loops_tmp = self._setup(tmp_path, attempts=2, issue_id="ENH-500")

        result = _bash(_check_attempt_budget_script("ENH-500", max_count=5), tmp_path)

        assert result.returncode == 0
        attempts = (loops_tmp / "recursive-refine-attempts.txt").read_text()
        assert attempts.count("ENH-500") == 3
        assert "ENH-500" not in (loops_tmp / "recursive-refine-skipped-budget.txt").read_text()
        assert "ENH-500" not in (loops_tmp / "recursive-refine-skipped.txt").read_text()

    def test_at_cap_exits_1_and_writes_both_skip_files(self, tmp_path: Path) -> None:
        """At cap: exits 1 and writes ID to both skipped-budget and skipped files."""
        loops_tmp = self._setup(tmp_path, attempts=5, issue_id="ENH-600")

        result = _bash(_check_attempt_budget_script("ENH-600", max_count=5), tmp_path)

        assert result.returncode == 1
        assert "ENH-600" in (loops_tmp / "recursive-refine-skipped-budget.txt").read_text()
        assert "ENH-600" in (loops_tmp / "recursive-refine-skipped.txt").read_text()
        attempts = (loops_tmp / "recursive-refine-attempts.txt").read_text()
        assert attempts.count("ENH-600") == 5

    def test_above_cap_also_exits_1(self, tmp_path: Path) -> None:
        """Above cap (count > cap): also exits 1."""
        loops_tmp = self._setup(tmp_path, attempts=7, issue_id="ENH-700")

        result = _bash(_check_attempt_budget_script("ENH-700", max_count=5), tmp_path)

        assert result.returncode == 1
        assert "ENH-700" in (loops_tmp / "recursive-refine-skipped-budget.txt").read_text()

    def test_exactly_max_refine_count_attempts_then_budget_skip(self, tmp_path: Path) -> None:
        """Synthetic issue that always fails: produces exactly max_refine_count attempts then is budget-skipped."""
        loops_tmp = self._setup(tmp_path, attempts=0, issue_id="ENH-EXHAUST")
        cap = 5

        for i in range(cap):
            result = _bash(_check_attempt_budget_script("ENH-EXHAUST", max_count=cap), tmp_path)
            assert result.returncode == 0, f"Attempt {i + 1} should be allowed"

        result = _bash(_check_attempt_budget_script("ENH-EXHAUST", max_count=cap), tmp_path)
        assert result.returncode == 1, "Attempt beyond cap should be budget-skipped"

        attempts = (loops_tmp / "recursive-refine-attempts.txt").read_text()
        assert attempts.count("ENH-EXHAUST") == cap
        assert "ENH-EXHAUST" in (loops_tmp / "recursive-refine-skipped-budget.txt").read_text()
        assert "ENH-EXHAUST" in (loops_tmp / "recursive-refine-skipped.txt").read_text()


class TestEnqueueChildDepths:
    """Child depth appending in enqueue_children / enqueue_or_skip."""

    def test_children_get_parent_depth_plus_one(self, tmp_path: Path) -> None:
        """Children of a depth-0 parent are appended to depth-map at depth 1."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-current-depth.txt").write_text("0")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-010\nENH-011\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("ENH-001 0\n")

        _bash(
            r"""
            PARENT_DEPTH=$(cat .loops/tmp/recursive-refine-current-depth.txt 2>/dev/null || echo 0)
            while IFS= read -r child; do
              echo "$child $((PARENT_DEPTH + 1))" >> .loops/tmp/recursive-refine-depth-map.txt
            done < .loops/tmp/recursive-refine-new-children.txt
            """,
            tmp_path,
        )

        depth_map = (loops_tmp / "recursive-refine-depth-map.txt").read_text()
        assert "ENH-010 1" in depth_map
        assert "ENH-011 1" in depth_map

    def test_depth_1_parent_produces_depth_2_children(self, tmp_path: Path) -> None:
        """Children of a depth-1 parent are appended at depth 2."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-current-depth.txt").write_text("1")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-021\n")
        (loops_tmp / "recursive-refine-depth-map.txt").write_text("ENH-010 1\n")

        _bash(
            r"""
            PARENT_DEPTH=$(cat .loops/tmp/recursive-refine-current-depth.txt 2>/dev/null || echo 0)
            while IFS= read -r child; do
              echo "$child $((PARENT_DEPTH + 1))" >> .loops/tmp/recursive-refine-depth-map.txt
            done < .loops/tmp/recursive-refine-new-children.txt
            """,
            tmp_path,
        )

        depth_map = (loops_tmp / "recursive-refine-depth-map.txt").read_text()
        assert "ENH-021 2" in depth_map


_VISITED_FILTER_SCRIPT = r"""
python3 << 'PYEOF'
from pathlib import Path
import sys
visited = set()
for f in ['recursive-refine-visited.txt', 'recursive-refine-passed.txt']:
    p = Path(f'.loops/tmp/{f}')
    if p.exists():
        visited.update(ln.strip() for ln in p.read_text().splitlines() if ln.strip())
queue_p = Path('.loops/tmp/recursive-refine-queue.txt')
if queue_p.exists():
    visited.update(ln.strip() for ln in queue_p.read_text().splitlines() if ln.strip())
candidates_p = Path('.loops/tmp/recursive-refine-new-children.txt')
candidates = []
if candidates_p.exists():
    candidates = [ln.strip() for ln in candidates_p.read_text().splitlines() if ln.strip()]
for cid in candidates:
    if cid in visited:
        print(f'WARN: refusing to re-enqueue {cid} (already visited / passed)', file=sys.stderr)
survivors = [cid for cid in candidates if cid not in visited]
candidates_p.write_text(''.join(f'{c}\n' for c in survivors))
PYEOF
"""

_CYCLE_FILTER_SCRIPT = r"""
python3 << 'PYEOF'
from pathlib import Path
import sys
visited = set()
for f in ['recursive-refine-visited.txt', 'recursive-refine-passed.txt']:
    p = Path(f'.loops/tmp/{f}')
    if p.exists():
        visited.update(ln.strip() for ln in p.read_text().splitlines() if ln.strip())
queue_p = Path('.loops/tmp/recursive-refine-queue.txt')
if queue_p.exists():
    visited.update(ln.strip() for ln in queue_p.read_text().splitlines() if ln.strip())
candidates_p = Path('.loops/tmp/recursive-refine-new-children.txt')
candidates = []
if candidates_p.exists():
    candidates = [ln.strip() for ln in candidates_p.read_text().splitlines() if ln.strip()]
for cid in candidates:
    if cid in visited:
        print(f'WARN: refusing to re-enqueue {cid} (already visited / passed)', file=sys.stderr)
survivors = [cid for cid in candidates if cid not in visited]
candidates_p.write_text(''.join(f'{c}\n' for c in survivors))
if len(candidates) > 0 and len(survivors) == 0:
    with open('.loops/tmp/recursive-refine-skipped-cycle.txt', 'a') as cf:
        cf.write('ENH-PARENT\n')
PYEOF
"""


class TestVisitedSetFilter:
    """enqueue_children / enqueue_or_skip filter candidate children against the visited set."""

    def test_visited_id_is_filtered_and_warns(self, tmp_path: Path) -> None:
        """Candidate ID already in visited.txt is dropped and a WARN is printed to stderr."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("ENH-010\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-010\nENH-020\n")

        result = _bash(_VISITED_FILTER_SCRIPT, tmp_path)

        survivors = (loops_tmp / "recursive-refine-new-children.txt").read_text()
        assert "ENH-010" not in survivors
        assert "ENH-020" in survivors
        assert "WARN: refusing to re-enqueue ENH-010" in result.stderr

    def test_passed_id_is_filtered(self, tmp_path: Path) -> None:
        """Candidate ID already in passed.txt is dropped."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("")
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-030\n")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-030\nENH-040\n")

        result = _bash(_VISITED_FILTER_SCRIPT, tmp_path)

        survivors = (loops_tmp / "recursive-refine-new-children.txt").read_text()
        assert "ENH-030" not in survivors
        assert "ENH-040" in survivors
        assert "WARN: refusing to re-enqueue ENH-030" in result.stderr

    def test_queue_id_is_filtered(self, tmp_path: Path) -> None:
        """Candidate ID already in the live queue is dropped."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("ENH-050\n")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-050\nENH-060\n")

        result = _bash(_VISITED_FILTER_SCRIPT, tmp_path)

        survivors = (loops_tmp / "recursive-refine-new-children.txt").read_text()
        assert "ENH-050" not in survivors
        assert "ENH-060" in survivors
        assert "WARN: refusing to re-enqueue ENH-050" in result.stderr

    def test_unvisited_id_passes_through(self, tmp_path: Path) -> None:
        """Candidate ID not in any tracking set is written back to new-children.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-099\n")

        result = _bash(_VISITED_FILTER_SCRIPT, tmp_path)

        survivors = (loops_tmp / "recursive-refine-new-children.txt").read_text()
        assert "ENH-099" in survivors
        assert result.stderr == ""


class TestCycleSkipReason:
    """enqueue_or_skip writes parent to skipped-cycle.txt when all children are cycle-filtered."""

    def test_all_filtered_children_writes_to_skipped_cycle(self, tmp_path: Path) -> None:
        """All candidate children already visited → parent is written to skipped-cycle.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("ENH-010\nENH-011\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-010\nENH-011\n")

        _bash(_CYCLE_FILTER_SCRIPT, tmp_path)

        cycle_file = (loops_tmp / "recursive-refine-skipped-cycle.txt").read_text()
        assert "ENH-PARENT" in cycle_file
        assert (loops_tmp / "recursive-refine-new-children.txt").read_text().strip() == ""

    def test_partial_filter_does_not_write_to_skipped_cycle(self, tmp_path: Path) -> None:
        """Only partially filtered children (some survive) do not trigger cycle-skip."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("ENH-010\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("ENH-010\nENH-099\n")

        _bash(_CYCLE_FILTER_SCRIPT, tmp_path)

        assert not (loops_tmp / "recursive-refine-skipped-cycle.txt").exists()
        survivors = (loops_tmp / "recursive-refine-new-children.txt").read_text()
        assert "ENH-099" in survivors

    def test_no_candidates_does_not_write_to_skipped_cycle(self, tmp_path: Path) -> None:
        """Empty new-children.txt (pre-filter count = 0) does not create skipped-cycle.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-visited.txt").write_text("ENH-010\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("")
        (loops_tmp / "recursive-refine-queue.txt").write_text("")
        (loops_tmp / "recursive-refine-new-children.txt").write_text("")

        _bash(_CYCLE_FILTER_SCRIPT, tmp_path)

        assert not (loops_tmp / "recursive-refine-skipped-cycle.txt").exists()


class TestDecomposedDualWrite:
    """enqueue_children and enqueue_or_skip write parent to both skipped.txt and skipped-decomposed.txt."""

    def test_enqueue_children_writes_to_decomposed_file(self, tmp_path: Path) -> None:
        """enqueue_children appends parent ID to skipped-decomposed.txt alongside skipped.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")

        _bash(
            r"""
            PARENT="ENH-001"
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped.txt
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped-decomposed.txt
            """,
            tmp_path,
        )

        assert "ENH-001" in (loops_tmp / "recursive-refine-skipped.txt").read_text()
        assert "ENH-001" in (loops_tmp / "recursive-refine-skipped-decomposed.txt").read_text()

    def test_enqueue_or_skip_children_branch_writes_to_decomposed_file(
        self, tmp_path: Path
    ) -> None:
        """enqueue_or_skip children branch appends parent to both skipped.txt and skipped-decomposed.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")

        _bash(
            r"""
            PARENT="ENH-002"
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped.txt
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped-decomposed.txt
            """,
            tmp_path,
        )

        assert "ENH-002" in (loops_tmp / "recursive-refine-skipped.txt").read_text()
        assert "ENH-002" in (loops_tmp / "recursive-refine-skipped-decomposed.txt").read_text()

    def test_enqueue_or_skip_deadend_branch_writes_to_deadend_file(self, tmp_path: Path) -> None:
        """enqueue_or_skip dead-end branch appends parent to both skipped.txt and skipped-deadend.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")

        _bash(
            r"""
            PARENT="ENH-003"
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped.txt
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped-deadend.txt
            """,
            tmp_path,
        )

        assert "ENH-003" in (loops_tmp / "recursive-refine-skipped.txt").read_text()
        assert "ENH-003" in (loops_tmp / "recursive-refine-skipped-deadend.txt").read_text()

    def test_decomposed_does_not_appear_in_deadend_file(self, tmp_path: Path) -> None:
        """enqueue_children writes to skipped-decomposed.txt but NOT skipped-deadend.txt."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")

        _bash(
            r"""
            PARENT="ENH-004"
            echo "$PARENT" >> .loops/tmp/recursive-refine-skipped-decomposed.txt
            """,
            tmp_path,
        )

        assert "ENH-004" in (loops_tmp / "recursive-refine-skipped-decomposed.txt").read_text()
        assert "ENH-004" not in (loops_tmp / "recursive-refine-skipped-deadend.txt").read_text()


class TestDoneSummary:
    """Per-category summary rows in done state (Decomposed, Dead-ends, Depth-cap, Cycle, Budget)."""

    # Mirrors the done state action body after FSM interpolation.
    # ${TREE_SUMMARY:-true} represents the FSM-interpolated ${context.tree_summary} value.
    _DONE_SCRIPT = r"""
    PASSED_IDS=$(cat .loops/tmp/recursive-refine-passed.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)
    DECOMPOSED_IDS=$(cat .loops/tmp/recursive-refine-skipped-decomposed.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)
    DEADEND_IDS=$(cat .loops/tmp/recursive-refine-skipped-deadend.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)
    DEPTH_SKIPPED_IDS=$(cat .loops/tmp/recursive-refine-skipped-depth.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)
    CYCLE_SKIPPED_IDS=$(cat .loops/tmp/recursive-refine-skipped-cycle.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)
    BUDGET_SKIPPED_IDS=$(cat .loops/tmp/recursive-refine-skipped-budget.txt 2>/dev/null \
      | grep -v '^[[:space:]]*$' | sort -u || true)

    PASSED_COUNT=$(echo "$PASSED_IDS" | grep -c '[^[:space:]]' || echo 0)
    DECOMPOSED_COUNT=$(echo "$DECOMPOSED_IDS" | grep -c '[^[:space:]]' || echo 0)
    DEADEND_COUNT=$(echo "$DEADEND_IDS" | grep -c '[^[:space:]]' || echo 0)
    DEPTH_COUNT=$(echo "$DEPTH_SKIPPED_IDS" | grep -c '[^[:space:]]' || echo 0)
    CYCLE_COUNT=$(echo "$CYCLE_SKIPPED_IDS" | grep -c '[^[:space:]]' || echo 0)
    BUDGET_COUNT=$(echo "$BUDGET_SKIPPED_IDS" | grep -c '[^[:space:]]' || echo 0)

    PASSED_LIST=$(echo "$PASSED_IDS" | tr '\n' ',' | sed 's/,$//')
    DECOMPOSED_LIST=$(echo "$DECOMPOSED_IDS" | tr '\n' ',' | sed 's/,$//')
    DEADEND_LIST=$(echo "$DEADEND_IDS" | tr '\n' ',' | sed 's/,$//')
    DEPTH_LIST=$(echo "$DEPTH_SKIPPED_IDS" | tr '\n' ',' | sed 's/,$//')
    CYCLE_LIST=$(echo "$CYCLE_SKIPPED_IDS" | tr '\n' ',' | sed 's/,$//')
    BUDGET_LIST=$(echo "$BUDGET_SKIPPED_IDS" | tr '\n' ',' | sed 's/,$//')

    printf '\n=== Recursive Refine Summary ===\n\n'
    printf 'Passed       (%d): %s\n' "$PASSED_COUNT"     "${PASSED_LIST:-none}"
    printf 'Decomposed   (%d): %s\n' "$DECOMPOSED_COUNT" "${DECOMPOSED_LIST:-none}"
    printf 'Dead-ends    (%d): %s\n' "$DEADEND_COUNT"    "${DEADEND_LIST:-none}"
    printf 'Depth-cap    (%d): %s\n' "$DEPTH_COUNT"      "${DEPTH_LIST:-none}"
    printf 'Cycle        (%d): %s\n' "$CYCLE_COUNT"      "${CYCLE_LIST:-none}"
    printf 'Budget       (%d): %s\n' "$BUDGET_COUNT"     "${BUDGET_LIST:-none}"
    if [ "${TREE_SUMMARY:-true}" != "false" ]; then
      python3 << 'PYEOF'
import subprocess, sys, json, os, re
from pathlib import Path

def read_ids(path):
    try:
        return [ln.strip() for ln in Path(path).read_text().splitlines() if ln.strip()]
    except FileNotFoundError:
        return []

roots = read_ids('.loops/tmp/recursive-refine-original-queue.txt')
if not roots:
    sys.exit(0)

passed = set(read_ids('.loops/tmp/recursive-refine-passed.txt'))
skipped = set(read_ids('.loops/tmp/recursive-refine-skipped.txt'))
depth_skipped = set(read_ids('.loops/tmp/recursive-refine-skipped-depth.txt'))
cycle_skipped = set(read_ids('.loops/tmp/recursive-refine-skipped-cycle.txt'))
budget_skipped = set(read_ids('.loops/tmp/recursive-refine-skipped-budget.txt'))
all_ids = passed | skipped

def build_parent_map():
    parent_to_children = {}
    for iid in all_ids:
        r = subprocess.run(
            ['grep', '-rl', f'parent_issue: {iid}', '.issues/'],
            capture_output=True, text=True
        )
        children = []
        for f in r.stdout.splitlines():
            m = re.search(r'(BUG|FEAT|ENH)-(\d+)', os.path.basename(f))
            if m:
                children.append(f'{m.group(1)}-{m.group(2)}')
        if children:
            parent_to_children[iid] = children
    return parent_to_children

parent_to_children = build_parent_map()

def get_scores(iid):
    try:
        r = subprocess.run(
            ['ll-issues', 'show', iid, '--json'],
            capture_output=True, text=True
        )
        d = json.loads(r.stdout)
        return int(d.get('confidence') or 0), int(d.get('outcome') or 0)
    except Exception:
        return 0, 0

def get_skip_reason(iid):
    if iid in depth_skipped:
        return 'depth-cap'
    if iid in cycle_skipped:
        return 'cycle'
    if iid in budget_skipped:
        return 'budget'
    return 'refinement'

lines = []

def render(iid, prefix, is_last):
    connector = '└── ' if is_last else '├── '
    children = parent_to_children.get(iid, [])
    if children:
        lines.append(f'{prefix}{connector}{iid} [decomposed]')
        child_prefix = prefix + ('    ' if is_last else '│   ')
        for j, child in enumerate(children):
            render(child, child_prefix, j == len(children) - 1)
    elif iid in passed:
        conf, outcome = get_scores(iid)
        lines.append(f'{prefix}{connector}{iid} (passed, conf={conf}, outcome={outcome})')
    else:
        reason = get_skip_reason(iid)
        lines.append(f'{prefix}{connector}{iid} (skipped: {reason})')

for root in roots:
    children = parent_to_children.get(root, [])
    if children:
        lines.append(f'{root} [decomposed]')
        for j, child in enumerate(children):
            render(child, '  ', j == len(children) - 1)
    elif root in passed:
        conf, outcome = get_scores(root)
        lines.append(f'{root} (passed, conf={conf}, outcome={outcome})')
    else:
        reason = get_skip_reason(root)
        lines.append(f'{root} (skipped: {reason})')

if lines:
    print('\n=== Decomposition Tree ===')
    for line in lines:
        print(line)
PYEOF
    fi
    printf '\n'
    """

    def test_depth_cap_line_shows_capped_ids(self, tmp_path: Path) -> None:
        """done includes 'Depth-cap (N): IDs' when depth-capped issues exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("ENH-003\n")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Passed       (1):" in result.stdout
        assert "Depth-cap    (1):" in result.stdout
        assert "ENH-003" in result.stdout

    def test_depth_cap_line_shows_none_when_no_capped_issues(self, tmp_path: Path) -> None:
        """done emits 'Depth-cap (0): none' when no depth-capped issues."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Depth-cap    (0): none" in result.stdout

    def test_cycle_line_shows_cycle_ids(self, tmp_path: Path) -> None:
        """done includes 'Cycle (N): IDs' when cycle-detected issues exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("ENH-002\n")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Cycle        (1):" in result.stdout
        assert "ENH-002" in result.stdout

    def test_cycle_line_shows_none_when_no_cycle_issues(self, tmp_path: Path) -> None:
        """done emits 'Cycle (0): none' when no cycle-detected issues."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Cycle        (0): none" in result.stdout

    def test_budget_line_shows_budget_ids(self, tmp_path: Path) -> None:
        """done includes 'Budget (N): IDs' when budget-exceeded issues exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("ENH-002\n")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Budget       (1):" in result.stdout
        assert "ENH-002" in result.stdout

    def test_budget_line_shows_none_when_no_budget_issues(self, tmp_path: Path) -> None:
        """done emits 'Budget (0): none' when no budget-exceeded issues."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Budget       (0): none" in result.stdout

    def test_decomposed_line_shows_decomposed_ids(self, tmp_path: Path) -> None:
        """done includes 'Decomposed (N): IDs' when decomposed parents exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-002\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed   (1):" in result.stdout
        assert "ENH-001" in result.stdout

    def test_decomposed_line_shows_none_when_no_decomposed(self, tmp_path: Path) -> None:
        """done emits 'Decomposed (0): none' when no decomposed parents exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed   (0): none" in result.stdout

    def test_deadend_line_shows_deadend_ids(self, tmp_path: Path) -> None:
        """done includes 'Dead-ends (N): IDs' when dead-end issues exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("ENH-002\n")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Dead-ends    (1):" in result.stdout
        assert "ENH-002" in result.stdout

    def test_deadend_line_shows_none_when_no_deadends(self, tmp_path: Path) -> None:
        """done emits 'Dead-ends (0): none' when no dead-end issues exist."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Dead-ends    (0): none" in result.stdout

    def test_decomposition_tree_three_levels(self, tmp_path: Path) -> None:
        """done renders a 3-level decomposition tree when original-queue.txt is present.

        Scenario: ENH-100 (root) decomposes into ENH-200 and ENH-201.
        ENH-201 further decomposes into ENH-300 (grandchild).
        ENH-200 and ENH-300 pass; ENH-100 and ENH-201 are skipped (decomposed).
        """
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        # Tracking files
        (loops_tmp / "recursive-refine-original-queue.txt").write_text("ENH-100\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-200\nENH-300\n")
        (loops_tmp / "recursive-refine-skipped.txt").write_text("ENH-100\nENH-201\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("ENH-100\nENH-201\n")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("")

        # Stub issue files with parent_issue frontmatter so grep can find them
        issues_dir = tmp_path / ".issues" / "enhancements"
        issues_dir.mkdir(parents=True)
        (issues_dir / "P3-ENH-200-child-a.md").write_text(
            "---\nid: ENH-200\nparent_issue: ENH-100\n---\n"
        )
        (issues_dir / "P3-ENH-201-child-b.md").write_text(
            "---\nid: ENH-201\nparent_issue: ENH-100\n---\n"
        )
        (issues_dir / "P3-ENH-300-grandchild.md").write_text(
            "---\nid: ENH-300\nparent_issue: ENH-201\n---\n"
        )

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "=== Decomposition Tree ===" in result.stdout
        assert "ENH-100 [decomposed]" in result.stdout
        assert "ENH-200" in result.stdout
        assert "ENH-201 [decomposed]" in result.stdout
        assert "ENH-300" in result.stdout
        assert "passed" in result.stdout

    def test_decomposition_tree_suppressed_when_flag_false(self, tmp_path: Path) -> None:
        """done omits the tree block when TREE_SUMMARY=false."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-original-queue.txt").write_text("ENH-100\n")
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-100\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("")

        script = "TREE_SUMMARY=false\n" + self._DONE_SCRIPT
        result = _bash(script, tmp_path)

        assert result.returncode == 0
        assert "=== Decomposition Tree ===" not in result.stdout

    def test_decomposition_tree_absent_when_no_original_queue(self, tmp_path: Path) -> None:
        """done omits the tree block gracefully when original-queue.txt is missing."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")
        (loops_tmp / "recursive-refine-skipped-decomposed.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-deadend.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-depth.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-cycle.txt").write_text("")
        (loops_tmp / "recursive-refine-skipped-budget.txt").write_text("")

        result = _bash(self._DONE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "=== Decomposition Tree ===" not in result.stdout
        assert "Passed       (1):" in result.stdout


class TestAggregateDecomposition:
    """aggregate_decomposition state: parent→children rollup from decomposition.tsv."""

    # Mirrors the aggregate_decomposition state's action body after FSM interpolation.
    _AGGREGATE_SCRIPT = r"""
    if [ ! -s .loops/tmp/recursive-refine-decomposition.tsv ]; then
      exit 0
    fi
    python3 << 'PYEOF'
from pathlib import Path

def read_ids(path):
    try:
        return [ln.strip() for ln in Path(path).read_text().splitlines() if ln.strip()]
    except FileNotFoundError:
        return []

passed = set(read_ids('.loops/tmp/recursive-refine-passed.txt'))

rows = []
try:
    for line in Path('.loops/tmp/recursive-refine-decomposition.tsv').read_text().splitlines():
        parts = line.strip().split('\t')
        if len(parts) >= 2:
            parent_id = parts[0]
            child_ids = [c for c in parts[1].split(',') if c]
            rows.append((parent_id, child_ids))
except FileNotFoundError:
    import sys; sys.exit(0)

if not rows:
    import sys; sys.exit(0)

print(f'\nDecomposed ({len(rows)}):')
for parent_id, child_ids in rows:
    passed_children = [c for c in child_ids if c in passed]
    other_children = [c for c in child_ids if c not in passed]
    status_parts = []
    if passed_children:
        status_parts.append(f'{len(passed_children)} passed')
    if other_children:
        status_parts.append(f'{len(other_children)} not passed')
    status = f' ({", ".join(status_parts)})' if status_parts else ''
    child_list = ', '.join(child_ids)
    print(f'  {parent_id} → [{child_list}]{status}')
PYEOF
    """

    def test_one_parent_three_children_all_passed(self, tmp_path: Path) -> None:
        """1-parent-3-children fixture: all children passed produces correct rollup line."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        (loops_tmp / "recursive-refine-decomposition.tsv").write_text(
            "ENH-100\tENH-200,ENH-201,ENH-202\tsub-loop\t2026-05-03T12:00:00Z\n"
        )
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-200\nENH-201\nENH-202\n")

        result = _bash(self._AGGREGATE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed (1):" in result.stdout
        assert "ENH-100" in result.stdout
        assert "ENH-200" in result.stdout
        assert "ENH-201" in result.stdout
        assert "ENH-202" in result.stdout
        assert "3 passed" in result.stdout

    def test_one_parent_three_children_partial_pass(self, tmp_path: Path) -> None:
        """Partial pass: some children passed, some did not."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        (loops_tmp / "recursive-refine-decomposition.tsv").write_text(
            "ENH-100\tENH-200,ENH-201,ENH-202\tsize-review\t2026-05-03T12:00:00Z\n"
        )
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-200\n")

        result = _bash(self._AGGREGATE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed (1):" in result.stdout
        assert "1 passed" in result.stdout
        assert "2 not passed" in result.stdout

    def test_multiple_parents(self, tmp_path: Path) -> None:
        """Multiple decomposed parents produce N=2 rollup."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        (loops_tmp / "recursive-refine-decomposition.tsv").write_text(
            "ENH-100\tENH-200,ENH-201\tsub-loop\t2026-05-03T12:00:00Z\n"
            "ENH-300\tENH-400,ENH-401\tsize-review\t2026-05-03T12:01:00Z\n"
        )
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-200\nENH-201\nENH-400\n")

        result = _bash(self._AGGREGATE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed (2):" in result.stdout
        assert "ENH-100" in result.stdout
        assert "ENH-300" in result.stdout

    def test_empty_tsv_exits_cleanly(self, tmp_path: Path) -> None:
        """Empty decomposition.tsv produces no output and exits 0."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)

        (loops_tmp / "recursive-refine-decomposition.tsv").write_text("")
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")

        result = _bash(self._AGGREGATE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed" not in result.stdout

    def test_missing_tsv_exits_cleanly(self, tmp_path: Path) -> None:
        """Missing decomposition.tsv (no decompositions this run) exits 0 silently."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-passed.txt").write_text("ENH-001\n")

        result = _bash(self._AGGREGATE_SCRIPT, tmp_path)

        assert result.returncode == 0
        assert "Decomposed" not in result.stdout

    def test_decomposition_tsv_initialized_empty_by_parse_input(self, tmp_path: Path) -> None:
        """parse_input creates (or clears) recursive-refine-decomposition.tsv for the new run."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "recursive-refine-decomposition.tsv").write_text(
            "stale-parent\tchild1,child2\tsub-loop\t2026-01-01T00:00:00Z\n"
        )

        _bash(
            r"""
            printf '' > .loops/tmp/recursive-refine-decomposition.tsv
            """,
            tmp_path,
        )

        assert (loops_tmp / "recursive-refine-decomposition.tsv").read_text() == ""


# ---------------------------------------------------------------------------
# ENH-1348: dequeue_next progress line
# ---------------------------------------------------------------------------

_DEQUEUE_NEXT_SCRIPT = r"""
if [ ! -s .loops/tmp/recursive-refine-queue.txt ]; then
  exit 1
fi
CURRENT=$(head -1 .loops/tmp/recursive-refine-queue.txt)
tail -n +2 .loops/tmp/recursive-refine-queue.txt \
  > .loops/tmp/recursive-refine-queue.tmp
mv .loops/tmp/recursive-refine-queue.tmp \
  .loops/tmp/recursive-refine-queue.txt
echo "$CURRENT" >> .loops/tmp/recursive-refine-visited.txt
DEPTH=$(grep "^$CURRENT " .loops/tmp/recursive-refine-depth-map.txt 2>/dev/null | awk '{print $2}')
printf '%s' "${DEPTH:-0}" > .loops/tmp/recursive-refine-current-depth.txt
DEQUEUED=$(cat .loops/tmp/recursive-refine-dequeued-count.txt 2>/dev/null || echo 0)
DEQUEUED=$((DEQUEUED + 1))
printf '%s' "$DEQUEUED" > .loops/tmp/recursive-refine-dequeued-count.txt
TOTAL=$(cat .loops/tmp/recursive-refine-total-enqueued.txt 2>/dev/null || echo '?')
PASSED=$(grep -c '[^[:space:]]' .loops/tmp/recursive-refine-passed.txt 2>/dev/null || echo 0)
QUEUED=$(grep -c '[^[:space:]]' .loops/tmp/recursive-refine-queue.txt 2>/dev/null || echo 0)
SKIPPED=$(grep -c '[^[:space:]]' .loops/tmp/recursive-refine-skipped.txt 2>/dev/null || echo 0)
DEPTH_STR=${DEPTH:+" (depth: $DEPTH)"}
printf '[%s/%s] → %s%s | passed: %d | queued: %d | skipped: %d\n' \
  "$DEQUEUED" "$TOTAL" "$CURRENT" "$DEPTH_STR" "$PASSED" "$QUEUED" "$SKIPPED" >&2
echo "$CURRENT"
"""


def _setup_dequeue_env(
    loops_tmp: Path,
    *,
    queue: list[str],
    total: int | None = None,
    dequeued: int = 0,
    passed: list[str] | None = None,
    skipped: list[str] | None = None,
    depth_map: dict[str, int] | None = None,
) -> None:
    """Populate tmp files for a dequeue_next test."""
    (loops_tmp / "recursive-refine-queue.txt").write_text("".join(f"{id}\n" for id in queue))
    (loops_tmp / "recursive-refine-visited.txt").write_text("")
    (loops_tmp / "recursive-refine-passed.txt").write_text(
        "".join(f"{id}\n" for id in (passed or []))
    )
    (loops_tmp / "recursive-refine-skipped.txt").write_text(
        "".join(f"{id}\n" for id in (skipped or []))
    )
    effective_total = total if total is not None else len(queue)
    (loops_tmp / "recursive-refine-total-enqueued.txt").write_text(str(effective_total))
    (loops_tmp / "recursive-refine-dequeued-count.txt").write_text(str(dequeued))
    if depth_map is not None:
        (loops_tmp / "recursive-refine-depth-map.txt").write_text(
            "".join(f"{id} {d}\n" for id, d in depth_map.items())
        )
    else:
        (loops_tmp / "recursive-refine-depth-map.txt").write_text(
            "".join(f"{id} 0\n" for id in queue)
        )


class TestDequeueProgressLine:
    """dequeue_next emits [N/M] → ID ... progress line to stderr (ENH-1348)."""

    def test_progress_line_emitted_to_stderr(self, tmp_path: Path) -> None:
        """A single dequeue emits one progress line on stderr."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(loops_tmp, queue=["ENH-001"], total=3)

        result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)

        assert "[1/3] → ENH-001" in result.stderr

    def test_progress_line_not_on_stdout(self, tmp_path: Path) -> None:
        """Progress line goes to stderr only; stdout carries the dequeued ID for capture."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(loops_tmp, queue=["ENH-001"], total=3)

        result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)

        assert result.stdout.strip() == "ENH-001"
        assert "[1/3]" not in result.stdout

    def test_three_issue_run_emits_three_progress_lines(self, tmp_path: Path) -> None:
        """Synthetic 3-issue run: all 3 progress lines appear in stderr output."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(loops_tmp, queue=["ENH-001", "ENH-002", "ENH-003"], total=3)

        combined_stderr = ""
        for _ in range(3):
            result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)
            combined_stderr += result.stderr

        assert "[1/3] → ENH-001" in combined_stderr
        assert "[2/3] → ENH-002" in combined_stderr
        assert "[3/3] → ENH-003" in combined_stderr

    def test_progress_line_includes_passed_and_queued_counts(self, tmp_path: Path) -> None:
        """Progress line includes current passed and queued counts."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(
            loops_tmp,
            queue=["ENH-003"],
            total=3,
            dequeued=2,
            passed=["ENH-001", "ENH-002"],
        )

        result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)

        assert "passed: 2" in result.stderr
        assert "queued: 0" in result.stderr

    def test_depth_shown_when_in_depth_map(self, tmp_path: Path) -> None:
        """Depth field appears in progress line when issue is in the depth map."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(
            loops_tmp,
            queue=["ENH-010"],
            total=5,
            depth_map={"ENH-010": 2},
        )

        result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)

        assert "(depth: 2)" in result.stderr

    def test_depth_omitted_when_not_in_depth_map(self, tmp_path: Path) -> None:
        """Depth field is absent when issue ID has no entry in the depth map."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(
            loops_tmp,
            queue=["ENH-999"],
            total=1,
            depth_map={},
        )

        result = _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)

        assert "(depth:" not in result.stderr
        assert "[1/1] → ENH-999" in result.stderr

    def test_dequeued_counter_increments_across_calls(self, tmp_path: Path) -> None:
        """dequeued-count.txt is incremented on each successive dequeue."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_dequeue_env(loops_tmp, queue=["ENH-001", "ENH-002", "ENH-003"], total=3)

        for expected in [1, 2, 3]:
            _bash(_DEQUEUE_NEXT_SCRIPT, tmp_path)
            count = int((loops_tmp / "recursive-refine-dequeued-count.txt").read_text())
            assert count == expected


# --- ENH-1349: Queue Peek After Enqueue ---

_ENQUEUE_CHILDREN_PEEK_SCRIPT = r"""
PEEK_COUNT=5
QUEUE_LINES=$(grep -c '[^[:space:]]' .loops/tmp/recursive-refine-queue.txt 2>/dev/null || echo 0)
if [ "$QUEUE_LINES" -gt 0 ]; then
  PEEK=$(head -"$PEEK_COUNT" .loops/tmp/recursive-refine-queue.txt | tr '\n' ',' | sed 's/,$//')
  if [ "$QUEUE_LINES" -gt "$PEEK_COUNT" ]; then
    REMAINING=$((QUEUE_LINES - PEEK_COUNT))
    printf '  Next up: %s [+%d more]\n' "$PEEK" "$REMAINING" >&2
  else
    printf '  Next up: %s\n' "$PEEK" >&2
  fi
fi
"""

_ENQUEUE_OR_SKIP_PEEK_SCRIPT = r"""
if [ -s .loops/tmp/recursive-refine-new-children.txt ]; then
  PEEK_COUNT=5
  QUEUE_LINES=$(grep -c '[^[:space:]]' .loops/tmp/recursive-refine-queue.txt 2>/dev/null || echo 0)
  if [ "$QUEUE_LINES" -gt 0 ]; then
    PEEK=$(head -"$PEEK_COUNT" .loops/tmp/recursive-refine-queue.txt | tr '\n' ',' | sed 's/,$//')
    if [ "$QUEUE_LINES" -gt "$PEEK_COUNT" ]; then
      REMAINING=$((QUEUE_LINES - PEEK_COUNT))
      printf '  Next up: %s [+%d more]\n' "$PEEK" "$REMAINING" >&2
    else
      printf '  Next up: %s\n' "$PEEK" >&2
    fi
  fi
else
  echo "Skipped: no children"
fi
"""


def _setup_enqueue_env(
    loops_tmp: Path,
    *,
    queue: list[str],
    children: list[str] | None = None,
) -> None:
    """Populate tmp files for an enqueue peek test."""
    (loops_tmp / "recursive-refine-queue.txt").write_text("".join(f"{id}\n" for id in queue))
    (loops_tmp / "recursive-refine-new-children.txt").write_text(
        "".join(f"{id}\n" for id in (children or []))
    )


class TestEnqueuePeekLine:
    """enqueue_children and enqueue_or_skip emit a 'Next up:' peek line to stderr (ENH-1349)."""

    def test_enqueue_children_peek_on_stderr(self, tmp_path: Path) -> None:
        """enqueue_children emits Next up line on stderr."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(loops_tmp, queue=["ENH-001", "ENH-002", "ENH-003"])

        result = _bash(_ENQUEUE_CHILDREN_PEEK_SCRIPT, tmp_path)

        assert "Next up:" in result.stderr

    def test_enqueue_or_skip_children_branch_peek_on_stderr(self, tmp_path: Path) -> None:
        """enqueue_or_skip children branch emits Next up line on stderr."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(
            loops_tmp,
            queue=["ENH-001", "ENH-002"],
            children=["ENH-001", "ENH-002"],
        )

        result = _bash(_ENQUEUE_OR_SKIP_PEEK_SCRIPT, tmp_path)

        assert "Next up:" in result.stderr

    def test_peek_lists_all_ids_when_le_five(self, tmp_path: Path) -> None:
        """All IDs listed without suffix when queue has 5 or fewer items."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(loops_tmp, queue=["ENH-001", "ENH-002", "ENH-003", "ENH-004", "ENH-005"])

        result = _bash(_ENQUEUE_CHILDREN_PEEK_SCRIPT, tmp_path)

        assert "ENH-001" in result.stderr
        assert "ENH-005" in result.stderr
        assert "[+" not in result.stderr

    def test_peek_with_more_suffix_when_gt_five(self, tmp_path: Path) -> None:
        """[+K more] suffix appended when queue has more than 5 items."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(
            loops_tmp,
            queue=["ENH-001", "ENH-002", "ENH-003", "ENH-004", "ENH-005", "ENH-006", "ENH-007"],
        )

        result = _bash(_ENQUEUE_CHILDREN_PEEK_SCRIPT, tmp_path)

        assert "Next up:" in result.stderr
        assert "[+2 more]" in result.stderr

    def test_peek_omitted_when_queue_empty(self, tmp_path: Path) -> None:
        """No peek line emitted when queue is empty after enqueue."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(loops_tmp, queue=[])

        result = _bash(_ENQUEUE_CHILDREN_PEEK_SCRIPT, tmp_path)

        assert "Next up:" not in result.stderr

    def test_enqueue_or_skip_no_children_branch_no_peek(self, tmp_path: Path) -> None:
        """enqueue_or_skip no-children branch does not emit a peek line."""
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        _setup_enqueue_env(
            loops_tmp,
            queue=["ENH-001", "ENH-002"],
            children=[],
        )

        result = _bash(_ENQUEUE_OR_SKIP_PEEK_SCRIPT, tmp_path)

        assert "Next up:" not in result.stderr
