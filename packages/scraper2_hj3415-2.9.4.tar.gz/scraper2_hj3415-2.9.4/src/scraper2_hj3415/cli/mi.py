from __future__ import annotations

import typer

app = typer.Typer(no_args_is_help=True, help="(reserved) MI commands")


@app.callback(invoke_without_command=True)
def mi() -> None:
    return
