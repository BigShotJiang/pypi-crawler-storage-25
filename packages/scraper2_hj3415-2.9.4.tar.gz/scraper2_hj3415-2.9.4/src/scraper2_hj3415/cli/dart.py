from __future__ import annotations

import asyncio

import typer
from scraper2_hj3415.cli.common import (
    OptDartEDate,
    OptDartSDate,
    OptShow,
    aclose_cli_usecases,
    build_cli_usecases,
    pretty,
)

app = typer.Typer(no_args_is_help=True, help="OpenDART 공시 수집")


@app.command("reports")
def dart_reports(
    sdate: OptDartSDate = "",
    edate: OptDartEDate = "",
    show: OptShow = True,
) -> None:
    """
    OpenDART 공시 리스트를 수집한다.
    """

    async def _run() -> None:
        ucs = build_cli_usecases()
        try:
            result = await ucs.dart.collect_reports.execute(
                sdate=sdate,
                edate=edate,
            )

            typer.echo("\n=== DART REPORTS DONE ===")
            if show:
                typer.echo(pretty(result))
        finally:
            await aclose_cli_usecases(ucs)

    asyncio.run(_run())


@app.command("today")
def dart_today(
    show: OptShow = True,
) -> None:
    """
    OpenDART 오늘 공시를 수집한다.
    """

    async def _run() -> None:
        ucs = build_cli_usecases()
        try:
            result = await ucs.dart.collect_reports.execute()

            typer.echo("\n=== DART TODAY DONE ===")
            if show:
                typer.echo(pretty(result))
        finally:
            await aclose_cli_usecases(ucs)

    asyncio.run(_run())
