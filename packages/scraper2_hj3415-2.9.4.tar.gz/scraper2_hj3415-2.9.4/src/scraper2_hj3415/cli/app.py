from __future__ import annotations

import typer
from scraper2_hj3415.cli.dart import app as dart_app
from scraper2_hj3415.cli.mi import app as mi_app
from scraper2_hj3415.cli.nfs import app as nfs_app

app = typer.Typer(no_args_is_help=True)

app.add_typer(nfs_app, name="nfs")
app.add_typer(dart_app, name="dart")
app.add_typer(mi_app, name="mi")


@app.callback()
def main() -> None:
    """
    scraper2 CLI
    """
    return


if __name__ == "__main__":
    app()
