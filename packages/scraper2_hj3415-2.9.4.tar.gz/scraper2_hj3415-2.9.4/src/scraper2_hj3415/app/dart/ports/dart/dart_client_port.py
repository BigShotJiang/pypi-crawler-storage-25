# scraper2_hj3415/app/ports/dart/dart_client_port.py
from __future__ import annotations

from typing import Protocol

from scraper2_hj3415.app.dart.adapters.out.dto.dart_list_page_dto import (
    DartListPageDto,
)


class DartClientPort(Protocol):
    async def list_reports(
        self,
        *,
        sdate: str | None,
        edate: str | None,
        corp_code: str | None,
        page_no: int,
    ) -> DartListPageDto: ...
