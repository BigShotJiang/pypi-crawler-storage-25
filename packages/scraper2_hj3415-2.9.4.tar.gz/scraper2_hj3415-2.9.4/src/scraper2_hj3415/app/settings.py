# scraper2_hj3415/app/settings.py
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal, TypeAlias

from pydantic_settings import BaseSettings, SettingsConfigDict

# .env file is located at the package root (one level up from src/)
_PKG_ROOT = Path(__file__).resolve().parent.parent.parent.parent

SinkSetting: TypeAlias = Literal["mongo", "memory"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=_PKG_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # app
    app_name: str = "scraper2"
    app_env: str = "prod"
    log_level: str = "INFO"

    # db
    MONGO_URI: str = "mongodb://localhost:27017"
    MONGO_DB_NAME: str = "hj3415"
    MONGO_CONNECT_TIMEOUT_MS: int = 5_000
    MONGO_SERVER_SELECTION_TIMEOUT_MS: int = 5_000
    SNAPSHOT_TTL_DAYS: int | None = 730

    # nfs
    nfs_sink: SinkSetting = "mongo"
    scraper_headless: bool = True
    scraper_timeout_ms: int = 20_000
    scraper_max_concurrency: int = 2
    scraper_sleep_sec_default: float = 2.0

    # dart
    dart_api_key: str = ""


@lru_cache
def get_settings() -> Settings:
    return Settings()
