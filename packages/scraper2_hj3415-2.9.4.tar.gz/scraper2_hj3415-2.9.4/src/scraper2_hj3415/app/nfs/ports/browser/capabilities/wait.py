from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import Any, Protocol


class BrowserWaitPort(Protocol):
    """대기/동기화 유틸"""

    async def sleep_ms(self, ms: int) -> None:
        """
        ms에 1000을 넣으면 1초 쉼.
        구현체가 없을 때를 대비해 기본 구현 제공.
        """
        await asyncio.sleep(ms / 1000)

    async def wait_attached(
        self,
        selector: str,
        *,
        timeout_ms: int = 10_000,
    ) -> None: ...

    async def wait_visible(
        self,
        selector: str,
        *,
        timeout_ms: int = 10_000,
    ) -> None: ...

    async def wait_table_nth_ready(
        self,
        table_selector: str,
        *,
        index: int,
        min_rows: int = 1,
        timeout_ms: int = 20_000,
        poll_ms: int = 200,
        context: Mapping[str, Any] | None = None,  # pyright: ignore[reportExplicitAny]
    ) -> None: ...

    async def wait_table_text_changed(
        self,
        table_selector: str,
        *,
        index: int,
        prev_text: str | None,
        min_rows: int = 1,
        min_lines: int = 50,
        timeout_sec: float = 12.0,
        poll_sec: float = 0.2,
        context: Mapping[str, Any] | None = None,  # pyright: ignore[reportExplicitAny]
    ) -> str: ...