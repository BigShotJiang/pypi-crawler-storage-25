# scraper2_hj3415/app/nfs/domain/types.py
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Literal, TypeAlias

BlockKey: TypeAlias = str
MetricKey: TypeAlias = str
Period: TypeAlias = str
Num: TypeAlias = float | int | None

Record: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]
Records: TypeAlias = Sequence[Record]
RawLabel: TypeAlias = str
LabelsMap: TypeAlias = dict[MetricKey, RawLabel]

Sink: TypeAlias = Literal["memory", "mongo"]
