# scraper2_hj3415/app/parsing/c103_parser.py
from __future__ import annotations

from scraper2_hj3415.app.nfs.domain.types import Records
from scraper2_hj3415.app.nfs.parsing.tables.html_table import (
    df_to_c1034_metric_list,
    try_html_table_to_df,
)
from scraper2_hj3415.app.nfs.ports.browser.browser_port import BrowserPort

TABLE_XPATH = "xpath=//div[@id='wrapper']//div//table"
TABLE_INDEX = 2


async def parse_c103_current_table(browser: BrowserPort) -> Records:
    """
    ✅ 현재 화면 상태(탭/연간/분기/검색 결과)가 이미 준비되었다는 전제.
    이 상태에서 TABLE_INDEX 테이블만 읽어서 rows로 변환한다.
    """
    html = await browser.outer_html_nth(TABLE_XPATH, TABLE_INDEX)
    df = try_html_table_to_df(html)
    if df is None:
        return []
    else:
        return df_to_c1034_metric_list(df)
