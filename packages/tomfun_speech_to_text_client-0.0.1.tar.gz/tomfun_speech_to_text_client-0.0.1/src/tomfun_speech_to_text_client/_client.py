"""Minimal async client for the tomfun speech-to-text web API.

Protocol (see src/web-api.ts):
    POST   /api/uploads                  { size }             -> { uploadId }
    PATCH  /api/uploads/:id              bytes                -> { received, total }
    POST   /api/uploads/:id/submit       { language? }        -> { jobId, position }
    POST   /api/jobs/url                 { url, language? }   -> { jobId, position }
    GET    /api/jobs/:id/events          (SSE)                -> stream of RemoteJob

Auth is `Authorization: Bearer <token>`.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, List, Optional

import aiohttp

__all__ = ["Client", "TranscriptionError", "TranscriptionResult"]

# Must match CHUNK_BYTES on the server side (src/web-api.ts).
_DEFAULT_CHUNK_BYTES = 10 * 1024 * 1024


class TranscriptionError(RuntimeError):
    """Raised when a job ends in `failed` state or the server returns an error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        job: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.job = job


@dataclass
class TranscriptionResult:
    job_id: str
    text: str
    srt: Optional[str]
    vtt: Optional[str]
    csv: Optional[str]
    raw: Dict[str, Any]


ProgressCallback = Callable[[Dict[str, Any]], Awaitable[None]]


class Client:
    """Async client.

    Example:
        async with Client("https://speech.example.com", token="...") as c:
            r = await c.transcribe_file("audio.mp3", language="en")
            print(r.text)
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        chunk_bytes: int = _DEFAULT_CHUNK_BYTES,
        timeout: float = 60.0,
        session: Optional[aiohttp.ClientSession] = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        if not token:
            raise ValueError("token is required")
        self._base = base_url.rstrip("/")
        self._token = token
        self._chunk = chunk_bytes
        self._timeout = aiohttp.ClientTimeout(total=None, sock_read=timeout, sock_connect=timeout)
        self._session = session
        self._owns_session = session is None

    async def __aenter__(self) -> "Client":
        if self._session is None:
            self._session = aiohttp.ClientSession(
                headers={"Authorization": f"Bearer {self._token}"},
                timeout=self._timeout,
            )
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    # --- public API ---------------------------------------------------------

    async def transcribe_file(
        self,
        path: str,
        *,
        language: Optional[str] = None,
        on_status: Optional[ProgressCallback] = None,
    ) -> TranscriptionResult:
        size = os.path.getsize(path)
        upload_id = await self._create_upload(size)
        with open(path, "rb") as fh:
            offset = 0
            while offset < size:
                chunk = fh.read(self._chunk)
                if not chunk:
                    break
                await self._upload_chunk(upload_id, chunk, offset, size)
                offset += len(chunk)
        job_id = await self._submit_upload(upload_id, language=language)
        return await self._await_job(job_id, on_status)

    async def transcribe_url(
        self,
        url: str,
        *,
        language: Optional[str] = None,
        on_status: Optional[ProgressCallback] = None,
    ) -> TranscriptionResult:
        body: Dict[str, Any] = {"url": url}
        if language:
            body["language"] = language
        resp = await self._request("POST", "/api/jobs/url", json_body=body)
        return await self._await_job(resp["jobId"], on_status)

    async def cancel(self, job_id: str) -> None:
        await self._request("DELETE", f"/api/jobs/{job_id}")

    # --- internals ----------------------------------------------------------

    def _require_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            raise RuntimeError("Client is not open. Use `async with Client(...)` or call __aenter__().")
        return self._session

    async def _create_upload(self, size: int) -> str:
        resp = await self._request("POST", "/api/uploads", json_body={"size": size})
        return resp["uploadId"]

    async def _upload_chunk(self, upload_id: str, chunk: bytes, offset: int, total: int) -> None:
        headers = {
            "Content-Type": "application/octet-stream",
            "Content-Range": f"bytes {offset}-{offset + len(chunk) - 1}/{total}",
        }
        await self._request("PATCH", f"/api/uploads/{upload_id}", body=chunk, headers=headers)

    async def _submit_upload(self, upload_id: str, *, language: Optional[str]) -> str:
        body: Dict[str, Any] = {}
        if language:
            body["language"] = language
        resp = await self._request("POST", f"/api/uploads/{upload_id}/submit", json_body=body)
        return resp["jobId"]

    async def _await_job(
        self,
        job_id: str,
        on_status: Optional[ProgressCallback],
    ) -> TranscriptionResult:
        final = await self._stream_events(job_id, on_status)
        if final.get("status") == "failed":
            raise TranscriptionError(final.get("error") or "transcription failed", job=final)
        result = final.get("result") or {}
        return TranscriptionResult(
            job_id=job_id,
            text=result.get("text", ""),
            srt=result.get("srt"),
            vtt=result.get("vtt"),
            csv=result.get("csv"),
            raw=final,
        )

    async def _stream_events(
        self,
        job_id: str,
        on_status: Optional[ProgressCallback],
    ) -> Dict[str, Any]:
        session = self._require_session()
        last: Dict[str, Any] = {}
        async with session.get(
            f"{self._base}/api/jobs/{job_id}/events",
            headers={"Accept": "text/event-stream"},
            timeout=aiohttp.ClientTimeout(total=None),
        ) as resp:
            if resp.status >= 400:
                text = await resp.text()
                info = _safe_json(text) or {}
                raise TranscriptionError(
                    f"HTTP {resp.status}: {info.get('error') or text}",
                    status_code=resp.status,
                    job=info,
                )
            event_name = "message"
            data_lines: list[str] = []
            async for raw in resp.content:
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                if line == "":
                    if data_lines:
                        payload = "\n".join(data_lines)
                        if event_name == "error":
                            info = _safe_json(payload)
                            raise TranscriptionError(
                                (info or {}).get("error") or payload,
                                job=info,
                            )
                        parsed = _safe_json(payload)
                        if parsed is not None:
                            last = parsed
                            if on_status is not None:
                                await on_status(parsed)
                            if parsed.get("status") in ("done", "failed"):
                                return parsed
                    event_name = "message"
                    data_lines = []
                    continue
                if line.startswith(":"):
                    continue  # heartbeat / comment
                if line.startswith("event:"):
                    event_name = line[len("event:"):].strip() or "message"
                elif line.startswith("data:"):
                    data_lines.append(line[len("data:"):].lstrip())
        return last

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        body: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        session = self._require_session()
        url = f"{self._base}{path}"
        hdrs = dict(headers) if headers else {}
        data: Any = None
        if json_body is not None:
            data = json.dumps(json_body).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/json")
        elif body is not None:
            data = body
        async with session.request(method, url, data=data, headers=hdrs) as resp:
            text = await resp.text()
            if resp.status >= 400:
                info = _safe_json(text) or {}
                msg = info.get("error") or text or resp.reason or ""
                raise TranscriptionError(
                    f"HTTP {resp.status}: {msg}",
                    status_code=resp.status,
                    job=info,
                )
            if not text:
                return {}
            return _safe_json(text) or {}


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None
    if isinstance(obj, dict):
        return obj
    return None