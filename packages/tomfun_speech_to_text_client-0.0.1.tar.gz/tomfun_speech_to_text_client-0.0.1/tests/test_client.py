from __future__ import annotations

import json

import pytest

from tomfun_speech_to_text_client import Client, TranscriptionError


async def _drive_events(fake_server, *events):
    for ev in events:
        await fake_server.events_queue.put(("data", ev))


async def test_transcribe_file_sends_language_and_chunks(fake_server, token, tmp_path):
    audio = tmp_path / "clip.bin"
    audio.write_bytes(b"x" * (400 * 1024 + 37))  # one full chunk + leftover
    await _drive_events(
        fake_server,
        {"status": "processing"},
        {"status": "done", "result": {"text": "hello world", "srt": "1\n..."}},
    )

    async with Client(fake_server.url, token=token, chunk_bytes=400 * 1024) as c:
        r = await c.transcribe_file(str(audio), language="uk")

    assert r.text == "hello world"
    assert r.srt == "1\n..."

    methods = [(req.method, req.path) for req in fake_server.requests]
    assert ("POST", "/api/uploads") in methods
    assert sum(1 for m, p in methods if m == "PATCH" and p.startswith("/api/uploads/")) == 2

    submit = next(r for r in fake_server.requests if r.path.endswith("/submit"))
    assert json.loads(submit.body) == {"language": "uk"}
    assert submit.headers["Authorization"] == f"Bearer {token}"


async def test_transcribe_url_sends_language(fake_server, token):
    await _drive_events(
        fake_server,
        {"status": "done", "result": {"text": "ok"}},
    )
    async with Client(fake_server.url, token=token) as c:
        r = await c.transcribe_url("https://example.com/a.mp3", language="en")

    assert r.text == "ok"
    submit = next(req for req in fake_server.requests if req.path == "/api/jobs/url")
    assert json.loads(submit.body) == {"url": "https://example.com/a.mp3", "language": "en"}


async def test_on_status_callback_receives_events(fake_server, token):
    seen = []

    async def on_status(ev):
        seen.append(ev["status"])

    await _drive_events(
        fake_server,
        {"status": "processing"},
        {"status": "processing", "progressLast": "50%"},
        {"status": "done", "result": {"text": "x"}},
    )
    async with Client(fake_server.url, token=token) as c:
        await c.transcribe_url("https://x", on_status=on_status)

    assert seen == ["processing", "processing", "done"]


async def test_failed_job_raises(fake_server, token):
    await _drive_events(
        fake_server,
        {"status": "failed", "error": "boom"},
    )
    async with Client(fake_server.url, token=token) as c:
        with pytest.raises(TranscriptionError) as excinfo:
            await c.transcribe_url("https://x")
    assert "boom" in str(excinfo.value)


async def test_missing_token_rejected(fake_server):
    async with Client(fake_server.url, token="wrong") as c:
        with pytest.raises(TranscriptionError) as excinfo:
            await c.transcribe_url("https://x")
    assert excinfo.value.status_code == 401


async def test_cancel(fake_server, token):
    async with Client(fake_server.url, token=token) as c:
        await c.cancel("job-123")
    cancel_req = next(r for r in fake_server.requests if r.method == "DELETE")
    assert cancel_req.path == "/api/jobs/job-123"


def test_constructor_validation():
    with pytest.raises(ValueError):
        Client("", token="t")
    with pytest.raises(ValueError):
        Client("https://x", token="")