"""Fake tomfun-web-api mock for client tests.

Exposes the same endpoints as src/web-api.ts (upload/submit, jobs/url, SSE events,
cancel) and records every request so assertions can check bodies/headers.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import pytest
import pytest_asyncio
from aiohttp import web


@dataclass
class RequestLog:
    method: str
    path: str
    query: Dict[str, str]
    headers: Dict[str, str]
    body: bytes


@dataclass
class FakeServer:
    url: str
    token: str
    requests: List[RequestLog] = field(default_factory=list)
    uploads: Dict[str, bytearray] = field(default_factory=dict)
    upload_total: Dict[str, int] = field(default_factory=dict)
    events_queue: "asyncio.Queue[Tuple[str, Dict[str, Any]]]" = field(
        default_factory=lambda: asyncio.Queue()
    )
    # If set, /submit returns this jobId instead of a fresh one.
    next_job_id: Optional[str] = None


def _record(request: web.Request, body: bytes, srv: FakeServer) -> RequestLog:
    log = RequestLog(
        method=request.method,
        path=request.path,
        query=dict(request.query),
        headers={k: v for k, v in request.headers.items()},
        body=body,
    )
    srv.requests.append(log)
    return log


def _build_app(srv: FakeServer) -> web.Application:
    app = web.Application()

    @web.middleware
    async def auth_mw(request: web.Request, handler):
        if request.headers.get("Authorization") != f"Bearer {srv.token}":
            return web.json_response({"error": "no-session"}, status=401)
        return await handler(request)

    app.middlewares.append(auth_mw)

    async def create_upload(request: web.Request) -> web.Response:
        body = await request.read()
        _record(request, body, srv)
        data = json.loads(body)
        total = int(data["size"])
        upload_id = str(uuid.uuid4())
        srv.uploads[upload_id] = bytearray()
        srv.upload_total[upload_id] = total
        return web.json_response({"uploadId": upload_id})

    async def patch_upload(request: web.Request) -> web.Response:
        body = await request.read()
        _record(request, body, srv)
        upload_id = request.match_info["id"]
        buf = srv.uploads.get(upload_id)
        if buf is None:
            return web.json_response({"error": "unknown upload"}, status=404)
        buf.extend(body)
        return web.json_response({"received": len(buf), "total": srv.upload_total[upload_id]})

    async def submit_upload(request: web.Request) -> web.Response:
        body = await request.read()
        _record(request, body, srv)
        upload_id = request.match_info["id"]
        if upload_id not in srv.uploads:
            return web.json_response({"error": "unknown upload"}, status=404)
        job_id = srv.next_job_id or f"job-{uuid.uuid4().hex[:8]}"
        return web.json_response({"jobId": job_id, "position": 1})

    async def submit_url(request: web.Request) -> web.Response:
        body = await request.read()
        _record(request, body, srv)
        data = json.loads(body)
        if "url" not in data:
            return web.json_response({"error": "url required"}, status=400)
        job_id = srv.next_job_id or f"job-{uuid.uuid4().hex[:8]}"
        return web.json_response({"jobId": job_id, "position": 1})

    async def events(request: web.Request) -> web.StreamResponse:
        _record(request, b"", srv)
        resp = web.StreamResponse(
            status=200,
            reason="OK",
            headers={"Content-Type": "text/event-stream", "Cache-Control": "no-cache"},
        )
        await resp.prepare(request)
        while True:
            kind, payload = await srv.events_queue.get()
            if kind == "close":
                break
            if kind == "error":
                await resp.write(f"event: error\ndata: {json.dumps(payload)}\n\n".encode())
                break
            await resp.write(f"data: {json.dumps(payload)}\n\n".encode())
            if payload.get("status") in ("done", "failed"):
                break
        return resp

    async def cancel(request: web.Request) -> web.Response:
        _record(request, b"", srv)
        return web.json_response({"cancelled": True})

    app.router.add_post("/api/uploads", create_upload)
    app.router.add_patch("/api/uploads/{id}", patch_upload)
    app.router.add_post("/api/uploads/{id}/submit", submit_upload)
    app.router.add_post("/api/jobs/url", submit_url)
    app.router.add_get("/api/jobs/{id}/events", events)
    app.router.add_delete("/api/jobs/{id}", cancel)
    return app


@pytest_asyncio.fixture
async def fake_server() -> FakeServer:
    token = "test-token"
    srv = FakeServer(url="", token=token)
    app = _build_app(srv)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]
    srv.url = f"http://127.0.0.1:{port}"
    try:
        yield srv
    finally:
        await runner.cleanup()


@pytest.fixture
def token() -> str:
    return "test-token"