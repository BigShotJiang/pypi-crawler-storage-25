# tomfun-speech-to-text-client

Minimal async Python client for the tomfun speech-to-text web API.

- Token authentication (`Authorization: Bearer <token>`)
- Language hint passed to Whisper
- Upload local files (chunked) or submit a remote URL
- Streams status via Server-Sent Events

Single runtime dependency: `aiohttp`.

## Install

```bash
pip install tomfun-speech-to-text-client
```

## Usage

```python
import asyncio
from tomfun_speech_to_text_client import Client

async def main():
    async with Client("https://speech-to-text.tomfun.co", token="YOUR_TOKEN") as c:
        r = await c.transcribe_file("audio.mp3", language="en")
        print(r.text)

        r = await c.transcribe_url("https://example.com/clip.wav", language="uk")
        print(r.srt)

asyncio.run(main())
```

With progress callback:

```python
async def on_status(ev):
    print(ev["status"], ev.get("progressLast"))

await c.transcribe_file("audio.mp3", language="en", on_status=on_status)
```

Cancel a job:

```python
await c.cancel(job_id)
```

## Development (uv)

```bash
cd python_client
uv sync --group dev
uv run pytest
```

## Publishing to PyPI

1. Create a PyPI API token at https://pypi.org/manage/account/token/.
2. Bump `version` in `pyproject.toml`.
3. Build:
   ```bash
   uv build
   ```
4. Upload:
   ```bash
   uv publish --token "$PYPI_TOKEN"
   ```
   Or via `twine`:
   ```bash
   uv tool run --with twine twine upload dist/*
   ```