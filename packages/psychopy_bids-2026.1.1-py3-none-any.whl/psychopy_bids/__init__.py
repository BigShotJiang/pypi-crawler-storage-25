"""
Package to support the creation of valid bids-datasets.
"""

from importlib.metadata import version

__version__ = version("psychopy_bids")

from .components.bids_event import BidsEventComponent
from .routines.bids_export import BidsExportRoutine

try:
    from .routines.bids_onset import BidsOnsetRoutine
except ImportError:
    import logging as _logging

    _logging.getLogger(__name__).warning(
        "[psychopy-bids] BidsOnsetRoutine is not available in this PsychoPy version."
    )
    BidsOnsetRoutine = None

__all__ = ["BidsEventComponent", "BidsExportRoutine", "BidsOnsetRoutine"]
