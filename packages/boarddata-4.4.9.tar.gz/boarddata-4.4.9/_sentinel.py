"""Sentinel analysis methods."""

from __future__ import annotations

from typing import Any

from .types.core import PaginatedResponse
from .types.sentinel import AnalysisDetail, PressArticleItem


class SentinelMixin:
    """Sentinel analysis API methods."""

    def list_analyses(self, **params: Any) -> PaginatedResponse:
        """List sentinel analyses.

        Args:
            company: Filter by company UUID.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with AnalysisDetail results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("sentinel/analyses/", **params)  # type: ignore[attr-defined]

    def get_analysis(self, uid: str) -> AnalysisDetail:
        """Retrieve a sentinel analysis by UUID.

        Args:
            uid: Analysis UUID.

        Returns:
            AnalysisDetail with full analysis data including press extractions.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"sentinel/analyses/{uid}/")  # type: ignore[attr-defined]

    def create_analysis(
        self,
        company_id: str,
        name: str,
        *,
        press_since: str | None = None,
    ) -> AnalysisDetail:
        """Create a sentinel analysis.

        Args:
            company_id: Company UUID.
            name: Analysis name.
            press_since: Only fetch press articles after this date (``"YYYY-MM-DD"``).

        Returns:
            Created AnalysisDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company_id=company_id,
            name=name,
            press_since=press_since,
        )
        return self._post("sentinel/analyses/", payload)  # type: ignore[attr-defined]

    def update_analysis(
        self,
        uid: str,
        *,
        name: str | None = None,
    ) -> AnalysisDetail:
        """Partial update a sentinel analysis.

        Args:
            uid: Analysis UUID.
            name: Analysis name.

        Returns:
            Updated AnalysisDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(name=name)  # type: ignore[attr-defined]
        return self._patch(f"sentinel/analyses/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_analysis(self, uid: str) -> None:
        """Delete a sentinel analysis."""
        self._delete(f"sentinel/analyses/{uid}/")  # type: ignore[attr-defined]

    def retry_press_extraction(
        self, analysis_uid: str, extraction_pk: str,
    ) -> Any:
        """Retry a failed press extraction.

        Args:
            analysis_uid: Analysis UUID.
            extraction_pk: Press extraction ID.

        Returns:
            Updated press extraction data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._post(  # type: ignore[attr-defined]
            f"sentinel/analyses/{analysis_uid}/press/{extraction_pk}/retry/", {},
        )

    def update_press_article(
        self,
        analysis_uid: str,
        extraction_pk: str,
        article_pk: str,
        *,
        summary: str | None = None,
        confidence: str | None = None,
    ) -> PressArticleItem:
        """Partial update a press article.

        Args:
            analysis_uid: Analysis UUID.
            extraction_pk: Press extraction ID.
            article_pk: Article ID.
            summary: Updated summary text.
            confidence: Updated confidence level.

        Returns:
            Updated PressArticleItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(summary=summary, confidence=confidence)  # type: ignore[attr-defined]
        return self._patch(  # type: ignore[attr-defined]
            f"sentinel/analyses/{analysis_uid}/press/{extraction_pk}/articles/{article_pk}/",
            payload,
        )
