"""Board mandate (director) and board compensation types."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict

from .core import FieldSourceItem, FieldSourcePayload


# -- Shared nested types --

class _PersonSummary(TypedDict):
    id: str
    first_name: str
    last_name: str


class _CompanySummary(TypedDict):
    id: str
    name: str


# -- Board compensation (different from comex compensation!) --
# Board compensation uses token/attendance fields, NOT fixed/variable/stock fields.
# See BoardCompensationInlineSerializer in backend/apps/mandates/serializers.py:1014-1046

class DirectorCompensationItem(TypedDict):
    id: str
    fiscal_year: int
    nature: str
    currency: str
    token_personal: str | None
    token_personal_paid: str | None
    token_company: str | None
    token_company_paid: str | None
    token_others: str | None
    token_others_paid: str | None
    token_others_explain: str
    stock_personal: str | None
    stock_company: str | None
    attendance: str | None
    ratio_average: str | None
    ratio_median: str | None
    bsa: str | None
    bsaar: str | None
    bspce: str | None
    collective: str | None
    benefits_in_kind: str | None
    total_tokens: str | None


class CreateDirectorCompensationPayload(TypedDict):
    fiscal_year: int
    nature: str
    assembly: NotRequired[str | None]
    token_personal: NotRequired[str | None]
    token_personal_paid: NotRequired[str | None]
    token_company: NotRequired[str | None]
    token_company_paid: NotRequired[str | None]
    token_others: NotRequired[str | None]
    token_others_paid: NotRequired[str | None]
    token_others_explain: NotRequired[str]
    stock_personal: NotRequired[str | None]
    stock_company: NotRequired[str | None]
    attendance: NotRequired[str | None]
    ratio_average: NotRequired[str | None]
    ratio_median: NotRequired[str | None]
    bsa: NotRequired[str | None]
    bsaar: NotRequired[str | None]
    bspce: NotRequired[str | None]
    collective: NotRequired[str | None]
    benefits_in_kind: NotRequired[str | None]
    currency: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateDirectorCompensationPayload(TypedDict, total=False):
    fiscal_year: int
    nature: str
    assembly: str | None
    token_personal: str | None
    token_personal_paid: str | None
    token_company: str | None
    token_company_paid: str | None
    token_others: str | None
    token_others_paid: str | None
    token_others_explain: str
    stock_personal: str | None
    stock_company: str | None
    attendance: str | None
    ratio_average: str | None
    ratio_median: str | None
    bsa: str | None
    bsaar: str | None
    bspce: str | None
    collective: str | None
    benefits_in_kind: str | None
    currency: str
    field_sources: list[FieldSourcePayload]


# -- Directors --
# See BoardListSerializer (serializers.py:1070-1091) and BoardDetailSerializer (1115-1143)

class DirectorListItem(TypedDict):
    id: str
    person: _PersonSummary
    company: _CompanySummary
    title: str
    valid_from: str | None
    valid_to: str | None
    is_independent: bool
    is_executive: bool
    is_chairman: bool
    is_lead_independent: bool
    is_employee_representative: bool
    is_employee_shareholder_representative: bool
    appointment_method: str
    entity_type: str
    representative_name: str
    company_country: str
    company_sectors: str
    governance_code: str
    company_index: str
    turnover_eur: str | None
    nationality: str
    seniority: float | None
    compensation: dict[str, Any] | None


class DirectorDetail(TypedDict):
    id: str
    person: _PersonSummary
    company: _CompanySummary
    title: str
    valid_from: str | None
    valid_to: str | None
    cause_end: str
    is_independent: bool
    is_executive: bool
    is_chairman: bool
    is_lead_independent: bool
    is_employee_representative: bool
    is_employee_shareholder_representative: bool
    appointment_method: str
    entity_type: str
    representative_name: str
    assembly_leave: str | None
    resolution_nominated: str | None
    seniority: float | None
    _sources: list[FieldSourceItem]


class CreateDirectorPayload(TypedDict):
    company: str
    person: str
    title: NotRequired[str]
    valid_from: NotRequired[str]
    valid_to: NotRequired[str | None]
    is_independent: NotRequired[bool]
    is_executive: NotRequired[bool]
    is_chairman: NotRequired[bool]
    is_lead_independent: NotRequired[bool]
    is_employee_representative: NotRequired[bool]
    is_employee_shareholder_representative: NotRequired[bool]
    appointment_method: NotRequired[str]
    entity_type: NotRequired[str]
    representative_name: NotRequired[str]
    cause_end: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateDirectorPayload(TypedDict, total=False):
    title: str
    valid_from: str
    valid_to: str | None
    is_independent: bool
    is_executive: bool
    is_chairman: bool
    is_lead_independent: bool
    is_employee_representative: bool
    is_employee_shareholder_representative: bool
    appointment_method: str
    entity_type: str
    representative_name: str
    cause_end: str
    field_sources: list[FieldSourcePayload]


class DirectorStats(TypedDict):
    """Shape depends on query params. Use dict access for flexibility."""
    pass  # Server returns dynamic keys based on filters
