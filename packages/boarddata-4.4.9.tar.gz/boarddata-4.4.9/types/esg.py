"""ESG types: IRO, Transition Plan, and Benchmark."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict

from .core import FieldSourcePayload


# -- IRO Types --

class IROTypeItem(TypedDict):
    """An IRO classification type."""
    id: int
    name: str
    description: str


class IRODetail(TypedDict):
    """An Impact/Risk/Opportunity record (used for both list and detail)."""
    id: str
    company: str
    date_publication: str
    name: str
    description: str
    iro_types: list[IROTypeItem]
    esg_type: str
    page_number: int | None
    evidence_text: str


class IROBatchItemPayload(TypedDict):
    """Payload for a single item in a batch IRO upsert."""
    company: str
    date_publication: str
    name: str
    esg_type: str
    description: NotRequired[str]
    iro_types: NotRequired[list[int]]
    field_sources: NotRequired[list[FieldSourcePayload]]


class IROBatchResultItem(TypedDict):
    """Result for a single item in a batch IRO upsert response."""
    name: str
    iro_id: str
    action: str


# -- Transition Plan children --

class TransitionTargetItem(TypedDict):
    """A GHG reduction target within a transition plan."""
    id: str
    display_label: str
    target_name: str
    scope: str
    reduction_value: str | None
    unit: str
    target_year: int
    baseline_year: int | None
    target_type: str
    sbti_validation: bool | None
    sbti_pathway: str
    source_page: int | None
    evidence_text: str


class TransitionTargetPayload(TypedDict):
    """Payload for creating/updating a transition target (nested in plan)."""
    display_label: NotRequired[str]
    target_name: NotRequired[str]
    scope: NotRequired[str]
    reduction_value: NotRequired[str | None]
    unit: NotRequired[str]
    target_year: NotRequired[int]
    baseline_year: NotRequired[int | None]
    target_type: NotRequired[str]
    sbti_validation: NotRequired[bool | None]
    sbti_pathway: NotRequired[str]
    source_page: NotRequired[int | None]
    evidence_text: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class TransitionLeverItem(TypedDict):
    """A decarbonisation lever within a transition plan."""
    id: str
    display_label: str
    program_name: str
    description: str
    impacted_scopes: list[str]
    timeframe: str
    kpi_or_milestone: str
    source_page: int | None
    evidence_text: str


class TransitionLeverPayload(TypedDict):
    """Payload for creating/updating a transition lever (nested in plan)."""
    display_label: NotRequired[str]
    program_name: NotRequired[str]
    description: NotRequired[str]
    impacted_scopes: NotRequired[list[str]]
    timeframe: NotRequired[str]
    kpi_or_milestone: NotRequired[str]
    source_page: NotRequired[int | None]
    evidence_text: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class TransitionFinanceItem(TypedDict):
    """A financial commitment within a transition plan."""
    id: str
    display_label: str
    finance_category: str
    amount: str | None
    currency: str
    financial_type: str
    volume_tco2e: str | None
    credit_type: str
    description: str
    source_page: int | None
    evidence_text: str


class TransitionFinancePayload(TypedDict):
    """Payload for creating/updating a transition finance (nested in plan)."""
    display_label: NotRequired[str]
    finance_category: NotRequired[str]
    amount: NotRequired[str | None]
    currency: NotRequired[str]
    financial_type: NotRequired[str]
    volume_tco2e: NotRequired[str | None]
    credit_type: NotRequired[str]
    description: NotRequired[str]
    source_page: NotRequired[int | None]
    evidence_text: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class TransitionGovernanceItem(TypedDict):
    """A governance mechanism within a transition plan."""
    id: str
    display_label: str
    governance_type: str
    body_or_role: str
    responsibility: str
    plan_type: str
    weighting_percent: str | None
    metric: str
    source_page: int | None
    evidence_text: str


class TransitionGovernancePayload(TypedDict):
    """Payload for creating/updating a transition governance (nested in plan)."""
    display_label: NotRequired[str]
    governance_type: NotRequired[str]
    body_or_role: NotRequired[str]
    responsibility: NotRequired[str]
    plan_type: NotRequired[str]
    weighting_percent: NotRequired[str | None]
    metric: NotRequired[str]
    source_page: NotRequired[int | None]
    evidence_text: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


# -- Transition Plan --

class TransitionPlanDetail(TypedDict):
    """A company transition plan with nested children."""
    id: str
    company: str
    date_publication: str
    explanation: str
    ghg_baseline_year: int | None
    ghg_baseline_value: str | None
    ghg_baseline_unit: str
    net_zero_target_year: int | None
    paris_alignment_pathway: str
    sbti_validated: bool | None
    targets: list[TransitionTargetItem]
    levers: list[TransitionLeverItem]
    finances: list[TransitionFinanceItem]
    governances: list[TransitionGovernanceItem]


# -- Benchmark --

class CompanyESGBenchmarkItem(TypedDict):
    """A company row in the ESG benchmark list."""
    id: str
    name: str
    country: str
    isin: str
    sectors: str
    indexes: str
    iros: list[IRODetail]
    transition_plan: TransitionPlanDetail | None
