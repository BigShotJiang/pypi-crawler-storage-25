"""Shared types used across multiple domains."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict


# -- Shared input types --


class AddressPayload(TypedDict, total=False):
    country: str
    country_code: str
    state: str
    city: str
    postal_code: str
    address: str


class FieldSourcePayload(TypedDict):
    document: str
    field_name: str
    page_number: NotRequired[int | None]
    extracted_value: NotRequired[str]
    confidence: NotRequired[str]


# -- Shared response types --


class PaginatedResponse(TypedDict):
    """Non-generic paginated response. results is list[Any] at the type level.
    Generic TypedDict requires Python 3.13; we target 3.12+."""

    count: int
    next: str | None
    previous: str | None
    results: list[Any]


class AddressItem(TypedDict):
    id: str
    country: str
    country_code: str
    state: str
    city: str
    postal_code: str
    address: str


class FieldSourceItem(TypedDict):
    id: int
    field_name: str
    document_id: str | None
    document_title: str
    document_type: str
    document_fiscal_year: int | None
    document_publication_date: str | None
    page_number: int | None
    confidence: str
    extracted_value: str


class FieldSourceDisputeDetail(TypedDict):
    id: int
    field_source_id: int
    remark: str
    resolved: bool
    created_at: str


class CreateFieldSourceDisputePayload(TypedDict):
    field_source_id: int
    remark: str


class SearchResult(TypedDict):
    companies: list[dict[str, Any]]
    persons: list[dict[str, Any]]


class UpsertResult(TypedDict):
    """Standardised return type for all upsert methods."""

    action: str  # "created" or "updated"
    id: str  # UUID of the created/updated entity
    data: dict[str, Any]  # Full entity detail dict
