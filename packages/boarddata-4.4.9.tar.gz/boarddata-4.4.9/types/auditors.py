"""Auditor mandate and auditor company types."""

from __future__ import annotations

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict

from .core import FieldSourceItem, FieldSourcePayload


class _AuditorCompanySummary(TypedDict):
    id: str
    name: str


class _CompanySummary(TypedDict):
    id: str
    name: str


# -- Auditor companies --

class AuditorCompanyItem(TypedDict):
    id: str
    name: str
    country: str


# -- Auditor compensations --

class AuditorCompensationItem(TypedDict):
    id: str
    fiscal_year: int
    assembly: str | None
    currency: str
    audit: str | None
    related: str | None
    advisory: str | None
    audit_total: str | None
    auditout_total: str | None
    ratio_advisory: str | None
    total_fees: str | None
    _sources: list[FieldSourceItem]


class CreateAuditorCompensationPayload(TypedDict):
    fiscal_year: int
    audit: NotRequired[str | None]
    related: NotRequired[str | None]
    advisory: NotRequired[str | None]
    assembly: NotRequired[str | None]
    currency: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateAuditorCompensationPayload(TypedDict, total=False):
    fiscal_year: int
    audit: str | None
    related: str | None
    advisory: str | None
    assembly: str | None
    currency: str
    field_sources: list[FieldSourcePayload]


# -- Auditor mandates --

class AuditorListItem(TypedDict):
    id: str
    auditor_company: _AuditorCompanySummary
    company: _CompanySummary
    auditor_type: str
    title: str
    valid_from: str | None
    valid_to: str | None


class AuditorDetail(TypedDict):
    id: str
    auditor_company: _AuditorCompanySummary
    company: _CompanySummary
    auditor_type: str
    title: str
    valid_from: str | None
    valid_to: str | None
    cause_end: str
    _sources: list[FieldSourceItem]


class AuditorCreateResponse(TypedDict):
    """Server-side upsert response from POST auditors/."""
    id: str
    action: str


class CreateAuditorPayload(TypedDict):
    auditor_company: str
    company: str
    auditor_type: str
    title: NotRequired[str]
    valid_from: NotRequired[str]
    valid_to: NotRequired[str | None]
    cause_end: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateAuditorPayload(TypedDict, total=False):
    title: str
    valid_from: str
    valid_to: str | None
    cause_end: str
    field_sources: list[FieldSourcePayload]
