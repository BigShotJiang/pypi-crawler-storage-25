"""Person, Nationality, and School types."""

from __future__ import annotations

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict

from .core import AddressItem, AddressPayload, FieldSourcePayload


# -- Nationalities --

class NationalityItem(TypedDict):
    id: int
    code: str
    name: str


# -- Schools --

class SchoolItem(TypedDict):
    id: int
    name: str
    country: str


class CreateSchoolPayload(TypedDict):
    name: str
    country: str


# -- Persons --

class CreatePersonPayload(TypedDict):
    first_name: str
    last_name: str
    gender: NotRequired[str]
    date_of_birth: NotRequired[str | None]
    bio: NotRequired[str]
    nationalities: NotRequired[list[int]]
    schools: NotRequired[list[int]]
    professional_address: NotRequired[AddressPayload | None]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdatePersonPayload(TypedDict, total=False):
    first_name: str
    last_name: str
    gender: str
    date_of_birth: str | None
    bio: str
    nationalities: list[int]
    schools: list[int]
    professional_address: AddressPayload | None
    field_sources: list[FieldSourcePayload]


class PersonListItem(TypedDict):
    id: str
    first_name: str
    last_name: str
    gender: str
    date_of_birth: str | None
    nationalities: list[NationalityItem]
    professional_address: AddressItem | None


class _CompanySummary(TypedDict):
    id: str
    name: str


class _MandateInline(TypedDict):
    id: str
    company: _CompanySummary
    title: str
    valid_from: str | None
    valid_to: str | None
    is_independent: bool
    executive_role: str
    auditor_type: str


class PersonSimilarityItem(TypedDict):
    """Returned by the similarity search endpoint."""
    id: str
    first_name: str
    last_name: str
    gender: str
    date_of_birth: str | None
    similarity: float


class PersonDetail(TypedDict):
    id: str
    first_name: str
    last_name: str
    gender: str
    date_of_birth: str | None
    bio: str
    nationalities: list[NationalityItem]
    professional_address: AddressItem | None
    board_mandates: list[_MandateInline]
    comex_mandates: list[_MandateInline]
