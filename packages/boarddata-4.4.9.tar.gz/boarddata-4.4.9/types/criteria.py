"""Criteria catalog types."""

from __future__ import annotations

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict


class CriteriaThemeItem(TypedDict):
    """Criteria theme as returned by the criteria-themes endpoint."""

    id: str
    name: str
    description: str
    category: str


class CriteriaCatalogItem(TypedDict):
    """Criteria catalog entry as returned by the criteria endpoint."""

    id: str
    name: str
    theme_id: str | None
    theme_name: str
    theme_category: str


class CreateCriteriaPayload(TypedDict, total=False):
    """Payload for creating a criteria catalog entry."""

    name: str
    theme_id: str | None
