"""Sentinel analysis types."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict


class _CompanyInline(TypedDict):
    id: str
    name: str
    isin: str
    index: str


class PressArticleItem(TypedDict):
    id: str
    citation_index: int
    title: str
    url: str
    source_name: str
    date: str | None
    summary: str
    content: str
    confidence: str | None
    document: dict[str, Any] | None
    created_at: str
    updated_at: str


class PressExtractionDetail(TypedDict):
    id: str
    scope: str
    status: str
    error_message: str
    articles: list[PressArticleItem]
    created_at: str
    updated_at: str


class AnalysisListItem(TypedDict):
    id: str
    company: _CompanyInline
    name: str
    status: str
    press_completed: int
    press_total: int
    analyst_name: str
    analyst_initials: str
    created_at: str
    updated_at: str


class AnalysisDetail(TypedDict):
    """Extends AnalysisListItem with nested press extractions and assemblies."""
    id: str
    company: _CompanyInline
    name: str
    status: str
    press_completed: int
    press_total: int
    analyst_name: str
    analyst_initials: str
    created_at: str
    updated_at: str
    press_extractions: list[PressExtractionDetail]
    assemblies: list[dict[str, Any]]


class CreateAnalysisPayload(TypedDict):
    company_id: str
    name: str
    press_since: NotRequired[str]


class UpdateAnalysisPayload(TypedDict, total=False):
    name: str


class UpdatePressArticlePayload(TypedDict, total=False):
    summary: str
    confidence: str
