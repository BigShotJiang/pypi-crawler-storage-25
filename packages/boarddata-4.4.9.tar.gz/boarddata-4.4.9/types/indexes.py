"""TypedDict definitions for Index and IndexMembership API types."""

from __future__ import annotations

from typing import Any

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict


# -- Response types --


class IndexItem(TypedDict):
    id: str
    name: str
    description: str
    data_source_url: str
    data_source_type: str
    data_source_config: dict[str, Any]
    display_source_url: str


class IndexMembershipItem(TypedDict):
    id: str
    company: str
    company_name: str
    company_ticker: str
    index: str
    index_name: str
    valid_from: str | None
    valid_to: str | None


# -- Create/Update payloads --


class CreateIndexPayload(TypedDict):
    name: str
    description: NotRequired[str]
    data_source_url: NotRequired[str]
    data_source_type: NotRequired[str]
    data_source_config: NotRequired[dict[str, Any]]
    display_source_url: NotRequired[str]


class UpdateIndexPayload(TypedDict, total=False):
    name: str
    description: str
    data_source_url: str
    data_source_type: str
    data_source_config: dict[str, Any]
    display_source_url: str


class CreateIndexMembershipPayload(TypedDict):
    company: str
    index: str
    valid_from: NotRequired[str | None]
    valid_to: NotRequired[str | None]


class UpdateIndexMembershipPayload(TypedDict, total=False):
    valid_from: str | None
    valid_to: str | None
