"""BoardDataClient — single-class facade composing all domain mixins."""

from __future__ import annotations

from ._assemblies import AssemblyMixin
from ._auditors import AuditorMixin
from ._base import Base
from ._comex import ComexMixin
from ._companies import CompanyMixin
from ._criteria import CriteriaMixin
from ._directors import DirectorMixin
from ._documents import DocumentMixin
from ._esg import ESGMixin
from ._indexes import IndexMixin
from ._persons import PersonMixin
from ._sentinel import SentinelMixin
from ._utilities import UtilitiesMixin


class BoardDataClient(
    CompanyMixin,
    PersonMixin,
    DirectorMixin,
    ComexMixin,
    AuditorMixin,
    DocumentMixin,
    AssemblyMixin,
    ESGMixin,
    SentinelMixin,
    CriteriaMixin,
    IndexMixin,
    UtilitiesMixin,
    Base,
):
    """Full-featured client for the BoardData V2 REST API.

    Composes all domain mixins into a single class. Authenticates via Auth0
    machine-to-machine (client_credentials) flow with automatic token refresh.

    Quick start::

        from boarddata import BoardDataClient

        client = BoardDataClient.from_env()
        companies = client.list_companies(country="FR")
    """
