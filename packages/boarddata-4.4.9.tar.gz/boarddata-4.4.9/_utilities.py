"""Cross-domain utility methods: search, assistant, field sources, pagination."""

from __future__ import annotations

from typing import Any

from .types.core import (
    CreateFieldSourceDisputePayload,
    FieldSourceDisputeDetail,
    PaginatedResponse,
    SearchResult,
)


class UtilitiesMixin:
    """Cross-domain utility API methods."""

    # ------------------------------------------------------------------
    # Pagination
    # ------------------------------------------------------------------

    def paginate(
        self,
        method: Any,
        *args: Any,
        page_size: int = 25,
        max_pages: int | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Auto-paginate a list endpoint and return all results.

        Args:
            method: A list method to call (e.g. ``client.list_companies``).
            *args: Positional arguments forwarded to the method.
            page_size: Number of results per page.
            max_pages: Maximum number of pages to fetch (``None`` for unlimited).
            **kwargs: Keyword arguments forwarded to the method as filters.

        Returns:
            Flat list of all result dicts collected across pages.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        results: list[dict[str, Any]] = []
        page = 1
        while True:
            resp = method(*args, page=page, page_size=page_size, **kwargs)
            if isinstance(resp, dict) and "results" in resp:
                results.extend(resp["results"])
                if not resp.get("next"):
                    break
            elif isinstance(resp, list):
                results.extend(resp)
                break
            else:
                results.append(resp)
                break
            page += 1
            if max_pages and page > max_pages:
                break
        return results

    # ------------------------------------------------------------------
    # Field Sources
    # ------------------------------------------------------------------

    def get_field_sources(
        self,
        content_type: str,
        object_ids: list[str],
        *,
        fields: list[str] | None = None,
    ) -> Any:
        """Batch-fetch field sources for objects of a given content type.

        Args:
            content_type: Content type in ``"app_label.model"`` format
                (e.g. ``"mandates.compensation"``).
            object_ids: List of object UUIDs to fetch sources for (max 500).
            fields: Optional list of field names to filter by.

        Returns:
            Dict mapping ``object_id -> field_name -> list`` of source dicts.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        params: dict[str, str] = {
            "content_type": content_type,
            "object_ids": ",".join(object_ids),
        }
        if fields:
            params["fields"] = ",".join(fields)
        return self._get("field-sources/", **params)  # type: ignore[attr-defined]

    def create_field_source_dispute(self, data: CreateFieldSourceDisputePayload) -> FieldSourceDisputeDetail:
        """Create a field source dispute.

        Args:
            data: Dispute payload with ``field_source_id`` and ``remark``.

        Returns:
            Created FieldSourceDisputeDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._post("field-source-disputes/", data)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, **params: Any) -> SearchResult:
        """Global search across companies and persons.

        Args:
            q: Search query string.

        Returns:
            SearchResult with matching ``companies`` and ``persons`` lists.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("search/", **params)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Assistant
    # ------------------------------------------------------------------

    def query_assistant(
        self,
        *,
        query: str | None = None,
        messages: list[dict[str, str]] | None = None,
    ) -> Any:
        """Query the AI module assistant.

        Args:
            query: A single query string (convenience shorthand).
            messages: Full conversation history as list of ``{role, content}`` dicts.
                Takes precedence over ``query`` if both provided.

        Returns:
            Dict with ``"message"`` (str) and ``"modules"`` (list of module keys).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload: dict[str, Any] = {}
        if messages is not None:
            payload["messages"] = messages
        elif query is not None:
            payload["query"] = query
        return self._post("assistant/", payload)  # type: ignore[attr-defined]
