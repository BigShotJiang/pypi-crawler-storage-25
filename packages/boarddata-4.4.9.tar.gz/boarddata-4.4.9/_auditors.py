"""Auditor mandate and auditor company methods."""

from __future__ import annotations

import logging
from typing import Any

from .types.auditors import AuditorCompanyItem, AuditorCompensationItem, AuditorCreateResponse, AuditorDetail
from .types.core import FieldSourcePayload, PaginatedResponse

logger = logging.getLogger("boarddata")


class AuditorMixin:
    """Auditor mandate and compensation API methods."""

    # ------------------------------------------------------------------
    # Auditor mandates
    # ------------------------------------------------------------------

    def list_auditors(self, **params: Any) -> PaginatedResponse:
        """List auditor mandates.

        Args:
            company: Filter by company UUID.
            auditor_type: Filter by auditor type.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with auditor mandate results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("auditors/", **params)  # type: ignore[attr-defined]

    def get_auditor(self, uid: str) -> AuditorDetail:
        """Retrieve an auditor mandate by UUID.

        Args:
            uid: Auditor mandate UUID.

        Returns:
            AuditorDetail with full mandate data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"auditors/{uid}/")  # type: ignore[attr-defined]

    def create_auditor(
        self,
        auditor_company: str,
        company: str,
        auditor_type: str,
        *,
        title: str | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        cause_end: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> AuditorCreateResponse:
        """Create an auditor mandate.

        Args:
            auditor_company: Auditor company UUID.
            company: Company UUID.
            auditor_type: Auditor type.
            title: Mandate title.
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``).
            cause_end: Reason the mandate ended.
            field_sources: Document provenance for fields.

        Returns:
            AuditorCreateResponse with id and action (``"created"`` or ``"updated"``).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            auditor_company=auditor_company,
            company=company,
            auditor_type=auditor_type,
            title=title,
            valid_from=valid_from,
            valid_to=valid_to,
            cause_end=cause_end,
            field_sources=field_sources,
        )
        return self._post("auditors/", payload)  # type: ignore[attr-defined]

    def update_auditor(
        self,
        uid: str,
        *,
        title: str | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        cause_end: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> AuditorDetail:
        """Partial update an auditor mandate.

        Args:
            uid: Auditor mandate UUID.
            title: Mandate title.
            valid_from: Start date.
            valid_to: End date.
            cause_end: Reason the mandate ended.
            field_sources: Document provenance for fields.

        Returns:
            Updated AuditorDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            title=title,
            valid_from=valid_from,
            valid_to=valid_to,
            cause_end=cause_end,
            field_sources=field_sources,
        )
        return self._patch(f"auditors/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_auditor(self, uid: str) -> None:
        """Soft-delete an auditor mandate.

        Args:
            uid: Auditor mandate UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"auditors/{uid}/")  # type: ignore[attr-defined]

    def list_auditor_companies(self, **params: Any) -> PaginatedResponse:
        """List auditor companies.

        Args:
            search: Search by auditor company name.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with auditor company results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("auditor-companies/", **params)  # type: ignore[attr-defined]

    def create_auditor_company(
        self,
        name: str,
        country: str = "",
    ) -> AuditorCompanyItem:
        """Create an auditor company (get-or-create on the server).

        Args:
            name: Audit firm name (e.g. ``"Deloitte & Associés"``).
            country: ISO 3166-1 alpha-2 country code (e.g. ``"FR"``).

        Returns:
            AuditorCompanyItem with id, name, and country.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(name=name, country=country)  # type: ignore[attr-defined]
        return self._post("auditor-companies/", payload)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Auditor compensations
    # ------------------------------------------------------------------

    def list_auditor_compensations(self, auditor_uid: str, **params: Any) -> PaginatedResponse:
        """List compensations for an auditor mandate.

        Args:
            auditor_uid: Auditor mandate UUID.
            fiscal_year: Filter by fiscal year.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with AuditorCompensationItem results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"auditors/{auditor_uid}/compensations/", **params)  # type: ignore[attr-defined]

    def get_auditor_compensation(self, auditor_uid: str, pk: str) -> AuditorCompensationItem:
        """Retrieve a single auditor compensation.

        Args:
            auditor_uid: Auditor mandate UUID.
            pk: Compensation entry ID.

        Returns:
            AuditorCompensationItem with full compensation data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"auditors/{auditor_uid}/compensations/{pk}/")  # type: ignore[attr-defined]

    def create_auditor_compensation(
        self,
        auditor_uid: str,
        fiscal_year: int,
        *,
        audit: str | None = None,
        related: str | None = None,
        advisory: str | None = None,
        assembly: str | None = None,
        currency: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> AuditorCompensationItem:
        """Create a compensation entry for an auditor mandate.

        Args:
            auditor_uid: Auditor mandate UUID.
            fiscal_year: Fiscal year.
            audit: Audit fees (decimal).
            related: Related fees (decimal).
            advisory: Advisory fees (decimal).
            assembly: Assembly UUID.
            currency: Currency code.
            field_sources: Document provenance for fields.

        Returns:
            Created AuditorCompensationItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            fiscal_year=fiscal_year,
            audit=audit,
            related=related,
            advisory=advisory,
            assembly=assembly,
            currency=currency,
            field_sources=field_sources,
        )
        return self._post(f"auditors/{auditor_uid}/compensations/", payload)  # type: ignore[attr-defined]

    def update_auditor_compensation(
        self,
        auditor_uid: str,
        pk: str,
        *,
        fiscal_year: int | None = None,
        audit: str | None = None,
        related: str | None = None,
        advisory: str | None = None,
        assembly: str | None = None,
        currency: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> AuditorCompensationItem:
        """Partial update an auditor compensation.

        Args:
            auditor_uid: Auditor mandate UUID.
            pk: Compensation entry ID.
            fiscal_year: Fiscal year.
            audit: Audit fees (decimal).
            related: Related fees (decimal).
            advisory: Advisory fees (decimal).
            assembly: Assembly UUID.
            currency: Currency code.
            field_sources: Document provenance for fields.

        Returns:
            Updated AuditorCompensationItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            fiscal_year=fiscal_year,
            audit=audit,
            related=related,
            advisory=advisory,
            assembly=assembly,
            currency=currency,
            field_sources=field_sources,
        )
        return self._patch(f"auditors/{auditor_uid}/compensations/{pk}/", payload)  # type: ignore[attr-defined]

    def delete_auditor_compensation(self, auditor_uid: str, pk: str) -> None:
        """Delete an auditor compensation.

        Args:
            auditor_uid: Auditor mandate UUID.
            pk: Compensation entry ID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"auditors/{auditor_uid}/compensations/{pk}/")  # type: ignore[attr-defined]
