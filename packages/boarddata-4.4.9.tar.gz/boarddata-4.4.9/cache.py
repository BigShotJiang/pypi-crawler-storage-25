"""Token cache implementations."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("boarddata")


class FileTokenCache:
    """Persists Auth0 tokens to a local JSON file.

    Creates parent directories automatically. Reads return None
    if the file is missing or contains invalid JSON.

    Usage::

        cache = FileTokenCache("~/.boarddata/token.json")
        bd = BoardDataClient.from_env(token_cache=cache)
    """

    def __init__(self, path: str) -> None:
        self._path = str(Path(path).expanduser().resolve())

    def read(self) -> dict[str, Any] | None:
        """Return cached token data or None."""
        try:
            return json.loads(Path(self._path).read_text())  # type: ignore[no-any-return]
        except (FileNotFoundError, json.JSONDecodeError):
            return None

    def write(self, data: dict[str, Any]) -> None:
        """Persist token data."""
        import os

        p = Path(self._path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data))
        os.chmod(p, 0o600)


class ScalewaySecretTokenCache:
    """Persists Auth0 tokens to Scaleway Secret Manager.

    Shares a single cached token across all job runs, so only one
    Auth0 M2M token request is made per token lifetime.

    Requires ``SCW_SECRET_KEY`` and ``SCW_PROJECT_ID`` env vars (already
    available in Scaleway Job containers).

    Usage::

        cache = ScalewaySecretTokenCache(secret_name="boarddata-m2m-token")
        bd = BoardDataClient.from_env(token_cache=cache)
    """

    _API_BASE = "https://api.scaleway.com/secret-manager/v1beta1/regions/{region}"

    def __init__(
        self,
        secret_name: str = "boarddata-m2m-token",
        region: str | None = None,
    ) -> None:
        import os

        self._secret_name = secret_name
        self._region = region or os.environ.get("SCW_REGION", "fr-par")
        self._base_url = self._API_BASE.format(region=self._region)

    def _headers(self) -> dict[str, str]:
        import os

        secret_key = os.environ.get("SCW_SECRET_KEY", "")
        return {"X-Auth-Token": secret_key}

    def _project_id(self) -> str:
        import os

        return os.environ.get("SCW_PROJECT_ID", "")

    def _find_secret_id(self) -> str | None:
        """Find the secret ID by name, or None if it doesn't exist."""
        import requests as _requests

        try:
            resp = _requests.get(
                f"{self._base_url}/secrets",
                headers=self._headers(),
                params={"name": self._secret_name, "project_id": self._project_id()},
                timeout=10,
            )
            if not resp.ok:
                return None
            secrets = resp.json().get("secrets", [])
            return secrets[0]["id"] if secrets else None
        except Exception:
            logger.debug("Failed to look up secret %s", self._secret_name)
            return None

    def _create_secret(self) -> str | None:
        """Create the secret and return its ID."""
        import requests as _requests

        try:
            resp = _requests.post(
                f"{self._base_url}/secrets",
                headers=self._headers(),
                json={
                    "name": self._secret_name,
                    "project_id": self._project_id(),
                    "description": "Cached Auth0 M2M token for BoardData client",
                },
                timeout=10,
            )
            if not resp.ok:
                return None
            return resp.json().get("id")
        except Exception:
            logger.debug("Failed to create secret %s", self._secret_name)
            return None

    def read(self) -> dict[str, Any] | None:
        """Read the latest secret version from Scaleway Secret Manager."""
        import base64

        import requests as _requests

        secret_id = self._find_secret_id()
        if not secret_id:
            return None

        try:
            resp = _requests.get(
                f"{self._base_url}/secrets/{secret_id}/versions/latest/access",
                headers=self._headers(),
                timeout=10,
            )
            if not resp.ok:
                return None
            raw = base64.b64decode(resp.json()["data"]).decode()
            return json.loads(raw)  # type: ignore[no-any-return]
        except Exception:
            logger.debug("Failed to read token from Scaleway Secret Manager")
            return None

    def write(self, data: dict[str, Any]) -> None:
        """Write a new secret version to Scaleway Secret Manager."""
        import base64

        import requests as _requests

        secret_id = self._find_secret_id()
        if not secret_id:
            secret_id = self._create_secret()
        if not secret_id:
            return

        try:
            encoded = base64.b64encode(json.dumps(data).encode()).decode()
            _requests.post(
                f"{self._base_url}/secrets/{secret_id}/versions",
                headers=self._headers(),
                json={"data": encoded},
                timeout=10,
            )
        except Exception:
            logger.debug("Failed to write token to Scaleway Secret Manager")
