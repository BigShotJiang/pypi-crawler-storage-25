"""Index and IndexMembership API methods."""

from __future__ import annotations

from typing import Any


class IndexMixin:
    """Index and IndexMembership CRUD.

    Requires ``Base`` in the MRO (provides ``_get``, ``_post``, ``_patch``,
    ``_delete``, ``_build_payload``).
    """

    # -- Index CRUD --

    def list_indexes(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
    ) -> Any:
        return self._get(  # type: ignore[attr-defined]
            "indexes/",
            page=page,
            page_size=page_size,
        )

    def get_index(self, index_id: str) -> Any:
        return self._get(f"indexes/{index_id}/")  # type: ignore[attr-defined]

    def create_index(
        self,
        name: str,
        *,
        description: str | None = None,
        data_source_url: str | None = None,
        data_source_type: str | None = None,
        data_source_config: dict[str, Any] | None = None,
        display_source_url: str | None = None,
    ) -> Any:
        payload = self._build_payload(  # type: ignore[attr-defined]
            name=name,
            description=description,
            data_source_url=data_source_url,
            data_source_type=data_source_type,
            data_source_config=data_source_config,
            display_source_url=display_source_url,
        )
        return self._post("indexes/", payload)  # type: ignore[attr-defined]

    def update_index(
        self,
        index_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        data_source_url: str | None = None,
        data_source_type: str | None = None,
        data_source_config: dict[str, Any] | None = None,
        display_source_url: str | None = None,
    ) -> Any:
        payload = self._build_payload(  # type: ignore[attr-defined]
            name=name,
            description=description,
            data_source_url=data_source_url,
            data_source_type=data_source_type,
            data_source_config=data_source_config,
            display_source_url=display_source_url,
        )
        return self._patch(f"indexes/{index_id}/", payload)  # type: ignore[attr-defined]

    # -- IndexMembership CRUD --

    def list_index_memberships(
        self,
        *,
        index_id: str | None = None,
        company_id: str | None = None,
        active_only: bool | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> Any:
        params: dict[str, Any] = {}
        if index_id is not None:
            params["index"] = index_id
        if company_id is not None:
            params["company"] = company_id
        if active_only is not None:
            params["active_only"] = "true" if active_only else "false"
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        return self._get("index-memberships/", **params)  # type: ignore[attr-defined]

    def create_index_membership(
        self,
        company_id: str,
        index_id: str,
        *,
        valid_from: str | None = None,
        valid_to: str | None = None,
    ) -> Any:
        payload: dict[str, Any] = {
            "company": company_id,
            "index": index_id,
            "valid_from": valid_from,
            "valid_to": valid_to,
        }
        return self._post("index-memberships/", payload)  # type: ignore[attr-defined]

    def update_index_membership(
        self,
        membership_id: str,
        *,
        valid_from: str | None = None,
        valid_to: str | None = None,
    ) -> Any:
        payload = self._build_payload(  # type: ignore[attr-defined]
            valid_from=valid_from,
            valid_to=valid_to,
        )
        return self._patch(  # type: ignore[attr-defined]
            f"index-memberships/{membership_id}/",
            payload,
        )
