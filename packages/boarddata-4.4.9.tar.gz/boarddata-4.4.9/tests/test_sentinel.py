"""Tests for SentinelMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._sentinel import SentinelMixin
    from boarddata._base import Base

    class TestClient(SentinelMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateAnalysis:
    def test_sends_required_fields(self):
        c = make_client()
        c._request.return_value = {"id": "a1", "name": "Test Analysis"}
        c.create_analysis("comp-uuid", "Test Analysis", press_since="2024-01-01")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["company_id"] == "comp-uuid"
        assert payload["name"] == "Test Analysis"
        assert payload["press_since"] == "2024-01-01"


class TestRetryPressExtraction:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"id": "ext1", "status": "pending"}
        c.retry_press_extraction("a-uuid", "ext-pk")
        args, kwargs = c._request.call_args
        assert args == ("POST", "sentinel/analyses/a-uuid/press/ext-pk/retry/")


class TestUpdatePressArticle:
    def test_sends_payload(self):
        c = make_client()
        c._request.return_value = {"id": "art1"}
        c.update_press_article("a-uuid", "ext-pk", "art-pk", summary="Updated", confidence="HIGH")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["summary"] == "Updated"
        assert payload["confidence"] == "HIGH"
