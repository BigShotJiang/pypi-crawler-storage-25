"""Tests for FileTokenCache."""

import json
from pathlib import Path

from boarddata.cache import FileTokenCache


class TestFileTokenCache:
    def test_read_returns_none_when_file_missing(self, tmp_path: Path) -> None:
        cache = FileTokenCache(str(tmp_path / "token.json"))
        assert cache.read() is None

    def test_write_then_read(self, tmp_path: Path) -> None:
        path = str(tmp_path / "token.json")
        cache = FileTokenCache(path)
        data = {"access_token": "tok123", "expires_at": 9999999999.0}
        cache.write(data)
        assert cache.read() == data

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        path = str(tmp_path / "deep" / "nested" / "token.json")
        cache = FileTokenCache(path)
        cache.write({"access_token": "tok"})
        assert Path(path).exists()

    def test_read_returns_none_on_corrupt_json(self, tmp_path: Path) -> None:
        path = tmp_path / "token.json"
        path.write_text("not json{{{")
        cache = FileTokenCache(str(path))
        assert cache.read() is None

    def test_tilde_expansion(self) -> None:
        cache = FileTokenCache("~/test-token.json")
        assert "~" not in cache._path
