"""Shared test fixtures for boarddata tests."""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from boarddata.client import BoardDataClient


@pytest.fixture
def client() -> BoardDataClient:
    """Return a BoardDataClient with mocked HTTP transport."""
    c = BoardDataClient.__new__(BoardDataClient)
    c._request = MagicMock()
    c._get_token = MagicMock(return_value="fake-token")
    c.base_url = "https://api.example.com"
    c.timeout = 30
    return c
