"""Tests for the _build_payload helper."""

from boarddata.client import BoardDataClient


class TestBuildPayload:
    def test_excludes_none_values(self) -> None:
        client = object.__new__(BoardDataClient)
        result = client._build_payload(name="Total", isin="FR123", country=None)
        assert result == {"name": "Total", "isin": "FR123"}

    def test_includes_all_non_none(self) -> None:
        client = object.__new__(BoardDataClient)
        result = client._build_payload(name="Total", isin="FR123", country="FR")
        assert result == {"name": "Total", "isin": "FR123", "country": "FR"}

    def test_empty_when_all_none(self) -> None:
        client = object.__new__(BoardDataClient)
        result = client._build_payload(a=None, b=None)
        assert result == {}

    def test_preserves_falsy_non_none(self) -> None:
        client = object.__new__(BoardDataClient)
        result = client._build_payload(name="", count=0, flag=False, items=[])
        assert result == {"name": "", "count": 0, "flag": False, "items": []}
