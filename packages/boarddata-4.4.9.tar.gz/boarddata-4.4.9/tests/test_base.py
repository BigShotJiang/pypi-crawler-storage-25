"""Tests for _base.py: auth, HTTP, payload building."""
from __future__ import annotations

import pytest

from boarddata._base import Base
from boarddata.errors import BoardDataError


class TestBuildPayload:
    def test_excludes_none(self):
        b = Base.__new__(Base)
        assert b._build_payload(a=1, b=None, c="x") == {"a": 1, "c": "x"}

    def test_preserves_falsy(self):
        b = Base.__new__(Base)
        assert b._build_payload(a=0, b=False, c="", d=[]) == {
            "a": 0, "b": False, "c": "", "d": []
        }

    def test_empty_when_all_none(self):
        b = Base.__new__(Base)
        assert b._build_payload(a=None, b=None) == {}


class TestUrl:
    def test_builds_url(self):
        b = Base.__new__(Base)
        b.base_url = "https://api.example.com"
        assert b._url("companies/") == "https://api.example.com/api/companies/"

    def test_strips_leading_slash(self):
        b = Base.__new__(Base)
        b.base_url = "https://api.example.com"
        assert b._url("/companies/") == "https://api.example.com/api/companies/"
