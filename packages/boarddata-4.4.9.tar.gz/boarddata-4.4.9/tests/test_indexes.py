"""Tests for IndexMixin methods.

Uses the shared ``client`` fixture from ``conftest.py`` which creates a
``BoardDataClient`` with mocked ``_request`` and ``_get_token``.
"""

from __future__ import annotations

import pytest


class TestListIndexes:
    def test_calls_correct_path(self, client):
        client._request.return_value = {"count": 0, "results": []}
        client.list_indexes()
        args, kwargs = client._request.call_args
        assert args == ("GET", "indexes/")

    def test_returns_paginated_response(self, client):
        client._request.return_value = {
            "count": 1,
            "next": None,
            "previous": None,
            "results": [{"id": "uuid1", "name": "CAC 40"}],
        }
        result = client.list_indexes()
        assert result["count"] == 1


class TestGetIndex:
    def test_calls_correct_path(self, client):
        client._request.return_value = {"id": "uuid1", "name": "CAC 40"}
        client.get_index("uuid1")
        args, kwargs = client._request.call_args
        assert args == ("GET", "indexes/uuid1/")


class TestCreateIndex:
    def test_sends_payload(self, client):
        client._request.return_value = {"id": "uuid1", "name": "CAC 40"}
        client.create_index(name="CAC 40", data_source_type="wikipedia")
        args, kwargs = client._request.call_args
        assert args == ("POST", "indexes/")
        assert kwargs["json"]["name"] == "CAC 40"
        assert kwargs["json"]["data_source_type"] == "wikipedia"

    def test_excludes_none_values(self, client):
        client._request.return_value = {"id": "uuid1", "name": "CAC 40"}
        client.create_index(name="CAC 40")
        _, kwargs = client._request.call_args
        assert "data_source_type" not in kwargs["json"]


class TestUpdateIndex:
    def test_sends_patch(self, client):
        client._request.return_value = {"id": "uuid1", "name": "CAC 40"}
        client.update_index("uuid1", description="French blue-chip")
        args, kwargs = client._request.call_args
        assert args == ("PATCH", "indexes/uuid1/")
        assert kwargs["json"]["description"] == "French blue-chip"


class TestListIndexMemberships:
    def test_calls_correct_path(self, client):
        client._request.return_value = {"count": 0, "results": []}
        client.list_index_memberships()
        args, kwargs = client._request.call_args
        assert args == ("GET", "index-memberships/")

    def test_passes_filters(self, client):
        client._request.return_value = {"count": 0, "results": []}
        client.list_index_memberships(index_id="uuid1", active_only=True)
        _, kwargs = client._request.call_args
        assert kwargs["params"]["index"] == "uuid1"
        assert kwargs["params"]["active_only"] == "true"


class TestCreateIndexMembership:
    def test_sends_payload(self, client):
        client._request.return_value = {"id": "m-uuid"}
        client.create_index_membership(
            company_id="c-uuid", index_id="i-uuid"
        )
        args, kwargs = client._request.call_args
        assert args == ("POST", "index-memberships/")
        assert kwargs["json"]["company"] == "c-uuid"
        assert kwargs["json"]["index"] == "i-uuid"

    def test_sends_valid_from_none(self, client):
        client._request.return_value = {"id": "m-uuid"}
        client.create_index_membership(
            company_id="c-uuid", index_id="i-uuid", valid_from=None
        )
        _, kwargs = client._request.call_args
        assert kwargs["json"]["valid_from"] is None


class TestUpdateIndexMembership:
    def test_sends_patch(self, client):
        client._request.return_value = {"id": "m-uuid"}
        client.update_index_membership("m-uuid", valid_to="2026-04-07")
        args, kwargs = client._request.call_args
        assert args == ("PATCH", "index-memberships/m-uuid/")
        assert kwargs["json"]["valid_to"] == "2026-04-07"


class TestListCompaniesTickerFilter:
    def test_passes_ticker_param(self, client):
        client._request.return_value = {"count": 0, "results": []}
        client.list_companies(ticker="AI")
        _, kwargs = client._request.call_args
        assert kwargs["params"]["ticker"] == "AI"
