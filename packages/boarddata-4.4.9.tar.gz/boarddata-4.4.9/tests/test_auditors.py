"""Tests for AuditorMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._auditors import AuditorMixin
    from boarddata._base import Base

    class TestClient(AuditorMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListAuditors:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_auditors(company="uuid1")
        args, kwargs = c._request.call_args
        assert args == ("GET", "auditors/")

class TestCreateAuditor:
    def test_sends_required_fields(self):
        c = make_client()
        c._request.return_value = {"id": "aud1", "action": "created"}
        c.create_auditor("aud-comp-uuid", "comp-uuid", "PRINCIPAL")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["auditor_company"] == "aud-comp-uuid"
        assert payload["auditor_type"] == "PRINCIPAL"


class TestCreateAuditorCompany:
    def test_sends_name_and_country(self):
        c = make_client()
        c._request.return_value = {"id": "ac1", "name": "Deloitte", "country": "FR"}
        result = c.create_auditor_company("Deloitte", "FR")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["name"] == "Deloitte"
        assert payload["country"] == "FR"
        assert result["id"] == "ac1"

    def test_country_defaults_to_empty(self):
        c = make_client()
        c._request.return_value = {"id": "ac2", "name": "KPMG", "country": ""}
        c.create_auditor_company("KPMG")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["country"] == ""


class TestCreateAuditorCompensation:
    def test_sends_audit_fields(self):
        c = make_client()
        c._request.return_value = {"id": "comp1"}
        c.create_auditor_compensation(
            "aud-uuid", 2024, audit="100000.00", currency="EUR",
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["audit"] == "100000.00"
        assert payload["fiscal_year"] == 2024
