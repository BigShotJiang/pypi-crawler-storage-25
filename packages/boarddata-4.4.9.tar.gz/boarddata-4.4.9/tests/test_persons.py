"""Tests for PersonMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._persons import PersonMixin
    from boarddata._base import Base

    class TestClient(PersonMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListPersons:
    def test_passes_explicit_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_persons(search="Jean", gender="M", page=1)
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {"search": "Jean", "gender": "M", "page": 1}


class TestFindPersonBySimilarity:
    def test_returns_best_match(self):
        c = make_client()
        c._request.return_value = {
            "count": 1, "results": [{"id": "p1", "first_name": "Jean", "last_name": "Dupont"}]
        }
        result = c.find_person_by_similarity("Jean Dupont")
        assert result["id"] == "p1"

    def test_returns_none_when_no_match(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        assert c.find_person_by_similarity("Unknown") is None


class TestUpsertPerson:
    def test_creates_when_not_found(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},  # similarity search
            {"id": "new-uuid", "first_name": "Jean", "last_name": "Dupont"},  # create
        ]
        result = c.upsert_person("Jean Dupont", first_name="Jean", last_name="Dupont")
        assert result["action"] == "created"
        assert result["id"] == "new-uuid"

    def test_updates_when_found(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 1, "results": [{"id": "existing"}]},  # similarity search
            {"id": "existing", "first_name": "Jean", "last_name": "Dupont"},  # update
        ]
        result = c.upsert_person("Jean Dupont", first_name="Jean", last_name="Dupont")
        assert result["action"] == "updated"
        assert result["id"] == "existing"
