"""Tests for BoardDataClient.from_env()."""

import os
from unittest.mock import patch

import pytest

from boarddata.client import BoardDataClient


ENV = {
    "BOARDDATA_BACKEND_URL": "https://api.example.com",
    "BOARDDATA_CLIENT_ID": "cid",
    "BOARDDATA_CLIENT_SECRET": "csecret",
}


class TestFromEnv:
    @patch.dict(os.environ, ENV, clear=False)
    def test_creates_client_from_env(self) -> None:
        client = BoardDataClient.from_env()
        assert client.base_url == "https://api.example.com"
        assert client._client_id == "cid"
        assert client._client_secret == "csecret"

    @patch.dict(os.environ, {}, clear=True)
    def test_raises_when_env_missing(self) -> None:
        with pytest.raises(ValueError, match="BOARDDATA_BACKEND_URL"):
            BoardDataClient.from_env()

    @patch.dict(os.environ, {**ENV, "BOARDDATA_BACKEND_URL": ""}, clear=False)
    def test_raises_when_env_empty(self) -> None:
        with pytest.raises(ValueError, match="BOARDDATA_BACKEND_URL"):
            BoardDataClient.from_env()

    @patch.dict(os.environ, ENV, clear=False)
    def test_passes_token_cache(self) -> None:
        from boarddata.cache import FileTokenCache
        cache = FileTokenCache("/tmp/test-token.json")
        client = BoardDataClient.from_env(token_cache=cache)
        assert client._token_cache is cache

    @patch.dict(os.environ, ENV, clear=False)
    def test_custom_timeout(self) -> None:
        client = BoardDataClient.from_env(timeout=60)
        assert client.timeout == 60
