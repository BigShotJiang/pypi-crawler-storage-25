"""Tests for UtilitiesMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._utilities import UtilitiesMixin
    from boarddata._base import Base

    class TestClient(UtilitiesMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestPaginate:
    def test_collects_all_pages(self):
        c = make_client()
        page1 = {"count": 3, "next": "?page=2", "results": [{"id": "1"}, {"id": "2"}]}
        page2 = {"count": 3, "next": None, "results": [{"id": "3"}]}
        call_count = 0

        def mock_list(*, page=1, page_size=25):
            nonlocal call_count
            call_count += 1
            return page1 if page == 1 else page2

        results = c.paginate(mock_list, page_size=2)
        assert len(results) == 3
        assert results[2]["id"] == "3"

    def test_respects_max_pages(self):
        c = make_client()

        def mock_list(*, page=1, page_size=25):
            return {"count": 100, "next": f"?page={page + 1}", "results": [{"id": str(page)}]}

        results = c.paginate(mock_list, max_pages=2)
        assert len(results) == 2


class TestSearch:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"companies": [], "persons": []}
        c.search(q="Total")
        args, _ = c._request.call_args
        assert args == ("GET", "search/")


class TestGetFieldSources:
    def test_sends_params(self):
        c = make_client()
        c._request.return_value = {}
        c.get_field_sources("mandates.compensation", ["uuid1", "uuid2"], fields=["amount"])
        _, kwargs = c._request.call_args
        assert kwargs["params"]["content_type"] == "mandates.compensation"
        assert kwargs["params"]["object_ids"] == "uuid1,uuid2"
        assert kwargs["params"]["fields"] == "amount"


class TestQueryAssistant:
    def test_sends_query(self):
        c = make_client()
        c._request.return_value = {"message": "Response", "modules": ["board"]}
        c.query_assistant(query="What is the board composition?")
        _, kwargs = c._request.call_args
        assert kwargs["json"]["query"] == "What is the board composition?"
