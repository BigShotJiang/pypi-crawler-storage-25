"""Tests for CompanyMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest


def make_client():
    """Create a BoardDataClient with mocked _request."""
    from boarddata._companies import CompanyMixin
    from boarddata._base import Base

    class TestClient(CompanyMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListCompanies:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_companies()
        c._request.assert_called_once()
        args, kwargs = c._request.call_args
        assert args == ("GET", "companies/")

    def test_passes_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_companies(country="FR", page=2, page_size=10)
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {"country": "FR", "page": 2, "page_size": 10}

    def test_excludes_none_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_companies(country="FR", isin=None)
        _, kwargs = c._request.call_args
        assert "isin" not in kwargs["params"]


class TestGetCompany:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"id": "abc", "name": "Test"}
        c.get_company("abc")
        args, _ = c._request.call_args
        assert args == ("GET", "companies/abc/")


class TestCreateCompany:
    def test_sends_required_and_optional(self):
        c = make_client()
        c._request.return_value = {"id": "abc", "name": "Test", "isin": "FR000"}
        c.create_company("Test", "FR000", country="FR")
        args, kwargs = c._request.call_args
        assert args == ("POST", "companies/")
        payload = kwargs["json"]
        assert payload["name"] == "Test"
        assert payload["isin"] == "FR000"
        assert payload["country"] == "FR"

    def test_excludes_none_fields(self):
        c = make_client()
        c._request.return_value = {"id": "abc"}
        c.create_company("Test", "FR000")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert "country" not in payload
        assert "ticker" not in payload


class TestUpsertCompany:
    def test_creates_when_not_found(self):
        c = make_client()
        # First call: list returns empty
        # Second call: create returns company
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid", "name": "Test", "isin": "FR000"},
        ]
        result = c.upsert_company("FR000", "Test")
        assert result["action"] == "created"
        assert result["id"] == "new-uuid"

    def test_updates_when_found(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 1, "results": [{"id": "existing-uuid", "name": "Old"}]},
            {"id": "existing-uuid", "name": "Test"},
        ]
        result = c.upsert_company("FR000", "Test")
        assert result["action"] == "updated"
        assert result["id"] == "existing-uuid"


class TestDeleteCompany:
    def test_calls_delete(self):
        c = make_client()
        c._request.return_value = None
        c.delete_company("abc")
        args, _ = c._request.call_args
        assert args == ("DELETE", "companies/abc/")
