"""Tests for DocumentMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._documents import DocumentMixin
    from boarddata._base import Base

    class TestClient(DocumentMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateDocument:
    def test_sends_required_and_optional(self):
        c = make_client()
        c._request.return_value = {"id": "doc1", "title": "Report"}
        c.create_document("Annual Report", "annual_report", fiscal_year=2024, isin="FR000")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["title"] == "Annual Report"
        assert payload["document_type"] == "annual_report"
        assert payload["fiscal_year"] == 2024


class TestUpdateDocument:
    def test_sends_patch_with_payload(self):
        c = make_client()
        c._request.return_value = {"id": "doc1", "title": "Updated"}
        c.update_document("doc-uuid", title="Updated", fiscal_year=2025)
        args, kwargs = c._request.call_args
        assert args == ("PATCH", "documents/doc-uuid/")
        payload = kwargs["json"]
        assert payload["title"] == "Updated"
        assert payload["fiscal_year"] == 2025
        assert "document_type" not in payload

    def test_ignores_none_values(self):
        c = make_client()
        c._request.return_value = {"id": "doc1", "title": "T"}
        c.update_document("doc-uuid", title="T")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert "fiscal_year" not in payload
        assert "isin" not in payload


class TestGetPresignedUrl:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"url": "https://s3.example.com/doc.pdf"}
        c.get_document_presigned_url("doc-uuid")
        args, _ = c._request.call_args
        assert args == ("GET", "documents/doc-uuid/presigned-url/")


class TestListDocuments:
    """Regression guards: filter kwargs must round-trip to query params."""

    def test_forwards_original_url_as_query_param(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": [], "next": None}
        c.list_documents(original_url="https://example.com/article")
        args, kwargs = c._request.call_args
        assert args[0] == "GET"
        assert args[1] == "documents/"
        assert kwargs["params"] == {"original_url": "https://example.com/article"}

    def test_forwards_isin_as_query_param(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": [], "next": None}
        c.list_documents(isin="FR0000120578")
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {"isin": "FR0000120578"}

    def test_forwards_multiple_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": [], "next": None}
        c.list_documents(
            isin="FR0000120578", document_type="press_release", fiscal_year=2024
        )
        _, kwargs = c._request.call_args
        assert kwargs["params"] == {
            "isin": "FR0000120578",
            "document_type": "press_release",
            "fiscal_year": 2024,
        }

    def test_no_params_sends_no_query_string(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": [], "next": None}
        c.list_documents()
        _, kwargs = c._request.call_args
        # _get drops None values and passes params=None when filtered is empty
        assert kwargs["params"] is None
