"""Tests for CriteriaMixin methods."""

from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._criteria import CriteriaMixin
    from boarddata._base import Base

    class TestClient(CriteriaMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListCriteriaThemes:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = [{"id": "t1", "name": "Financial"}]
        result = c.list_criteria_themes()
        args, _ = c._request.call_args
        assert args == ("GET", "criteria-themes/")
        assert result[0]["name"] == "Financial"


class TestListCriteria:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = [{"id": "c1", "name": "Revenue Growth"}]
        result = c.list_criteria()
        args, _ = c._request.call_args
        assert args == ("GET", "criteria/")
        assert result[0]["name"] == "Revenue Growth"

    def test_filters_by_theme(self):
        c = make_client()
        c._request.return_value = []
        c.list_criteria(theme="theme-uuid")
        _, kwargs = c._request.call_args
        assert kwargs["params"]["theme"] == "theme-uuid"


class TestCreateCriteria:
    def test_sends_payload(self):
        c = make_client()
        c._request.return_value = {"id": "c1", "name": "Revenue Growth"}
        result = c.create_criteria("Revenue Growth", theme_id="theme-uuid")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["name"] == "Revenue Growth"
        assert payload["theme_id"] == "theme-uuid"
        assert result["id"] == "c1"

    def test_without_theme(self):
        c = make_client()
        c._request.return_value = {"id": "c2", "name": "Safety Rate"}
        c.create_criteria("Safety Rate")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["name"] == "Safety Rate"
        assert "theme_id" not in payload
