"""Tests for ComexMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._comex import ComexMixin
    from boarddata._base import Base

    class TestClient(ComexMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateComexCompensation:
    def test_sends_explicit_fields(self):
        c = make_client()
        c._request.return_value = {"id": "comp1"}
        c.create_comex_compensation(
            "comex-uuid", 2024, "REAL",
            fixed="500000.00", variable="200000.00", currency="EUR",
            remuneration_via_holding=True,
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["fixed"] == "500000.00"
        assert payload["variable"] == "200000.00"
        assert payload["currency"] == "EUR"
        assert payload["remuneration_via_holding"] is True
        assert "token_personal" not in payload  # board field, not comex


class TestUpsertComex:
    def test_creates_when_not_found(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid", "title": "CEO"},
        ]
        result = c.upsert_comex("comp-uuid", "pers-uuid", title="CEO")
        assert result["action"] == "created"
        assert result["id"] == "new-uuid"

    def test_updates_when_found(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 1, "results": [{"id": "existing"}]},
            {"id": "existing", "title": "CEO"},
        ]
        result = c.upsert_comex("comp-uuid", "pers-uuid", title="CEO")
        assert result["action"] == "updated"
        assert result["id"] == "existing"


class TestListBulkComexCompensations:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_bulk_comex_compensations(company="uuid1", fiscal_year=2024)
        args, kwargs = c._request.call_args
        assert args == ("GET", "comex/compensations/")
