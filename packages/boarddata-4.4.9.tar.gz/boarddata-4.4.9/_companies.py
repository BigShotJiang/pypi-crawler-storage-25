"""Company, sector, and temporal attribute methods."""

from __future__ import annotations

import logging
from typing import Any

from .types.companies import (
    CompanyDetail,
    CompanyListItem,
    CompanyResolveResult,
    TemporalAttributePayload,
)
from .types.core import AddressPayload, FieldSourcePayload, PaginatedResponse, UpsertResult

logger = logging.getLogger("boarddata")


class CompanyMixin:
    """Company, sector, and temporal attribute API methods.

    Requires ``Base`` in the MRO (provides ``_get``, ``_post``, ``_patch``,
    ``_delete``, ``_build_payload``).
    """

    # ------------------------------------------------------------------
    # Sectors
    # ------------------------------------------------------------------

    def list_sectors(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
    ) -> PaginatedResponse:
        """List all sectors.

        Args:
            page: Page number (1-indexed).
            page_size: Results per page.

        Returns:
            PaginatedResponse with ``results`` list of SectorItem::

                {"count": 24, "next": null, "previous": null, "results": [
                    {"id": 1, "name": "Technology"},
                    {"id": 2, "name": "Finance"}, ...
                ]}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("sectors/", page=page, page_size=page_size)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Companies
    # ------------------------------------------------------------------

    def list_companies(
        self,
        *,
        search: str | None = None,
        isin: str | None = None,
        country: str | None = None,
        sector: str | None = None,
        ticker: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> PaginatedResponse:
        """List companies.

        Args:
            search: Search by name, ISIN, or ticker.
            isin: Filter by exact ISIN code.
            country: Filter by ISO country code (e.g. ``"FR"``).
            sector: Filter by sector name(s), comma-separated.
            ticker: Filter by exact stock ticker symbol.
            page: Page number (1-indexed).
            page_size: Results per page (default 25).

        Returns:
            PaginatedResponse with ``results`` list of CompanyListItem::

                {"count": 120, "next": "...?page=2", "previous": null, "results": [
                    {"id": "uuid", "name": "TotalEnergies", "isin": "FR0000120271",
                     "country": "FR", "ticker": "TTE", "sectors": [...], ...}
                ]}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(  # type: ignore[attr-defined]
            "companies/",
            search=search,
            isin=isin,
            country=country,
            sector=sector,
            ticker=ticker,
            page=page,
            page_size=page_size,
        )

    def get_company(self, uid: str) -> CompanyDetail:
        """Retrieve a single company by UUID.

        Args:
            uid: Company UUID.

        Returns:
            CompanyDetail with full company data including nested mandates
            and assemblies.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"companies/{uid}/")  # type: ignore[attr-defined]

    def create_company(
        self,
        name: str,
        isin: str,
        *,
        country: str | None = None,
        ticker: str | None = None,
        logo: str | None = None,
        since: str | None = None,
        description: str | None = None,
        purpose: str | None = None,
        website: str | None = None,
        governance_code: str | None = None,
        sectors: list[int] | None = None,
        headquarter: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> CompanyDetail:
        """Create a company.

        Args:
            name: Company name.
            isin: ISIN identifier (e.g. ``"FR0000120271"``).
            country: ISO country code (e.g. ``"FR"``).
            ticker: Stock ticker symbol (e.g. ``"TTE"``).
            logo: URL to company logo.
            since: Date the company was added (``"YYYY-MM-DD"``).
            description: Company description text.
            purpose: Corporate purpose statement.
            website: Company website URL.
            governance_code: Governance code reference.
            sectors: List of sector IDs to associate.
            headquarter: Headquarters address payload.
            field_sources: Document provenance for fields.

        Returns:
            CompanyDetail with full company data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            name=name,
            isin=isin,
            country=country,
            ticker=ticker,
            logo=logo,
            since=since,
            description=description,
            purpose=purpose,
            website=website,
            governance_code=governance_code,
            sectors=sectors,
            headquarter=headquarter,
            field_sources=field_sources,
        )
        return self._post("companies/", payload)  # type: ignore[attr-defined]

    def update_company(
        self,
        uid: str,
        *,
        name: str | None = None,
        country: str | None = None,
        isin: str | None = None,
        ticker: str | None = None,
        logo: str | None = None,
        since: str | None = None,
        description: str | None = None,
        purpose: str | None = None,
        website: str | None = None,
        governance_code: str | None = None,
        sectors: list[int] | None = None,
        headquarter: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> CompanyDetail:
        """Partial update a company.

        Args:
            uid: Company UUID.
            name: Company name.
            country: ISO country code.
            isin: ISIN identifier.
            ticker: Stock ticker symbol.
            logo: URL to company logo.
            since: Date the company was added (``"YYYY-MM-DD"``).
            description: Company description text.
            purpose: Corporate purpose statement.
            website: Company website URL.
            governance_code: Governance code reference.
            sectors: List of sector IDs.
            headquarter: Headquarters address.
            field_sources: Document provenance for fields.

        Returns:
            Updated CompanyDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            name=name,
            country=country,
            isin=isin,
            ticker=ticker,
            logo=logo,
            since=since,
            description=description,
            purpose=purpose,
            website=website,
            governance_code=governance_code,
            sectors=sectors,
            headquarter=headquarter,
            field_sources=field_sources,
        )
        return self._patch(f"companies/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_company(self, uid: str) -> None:
        """Soft-delete a company.

        Args:
            uid: Company UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"companies/{uid}/")  # type: ignore[attr-defined]

    def get_company_by_isin(self, isin: str) -> CompanyListItem | None:
        """Find a company by ISIN.

        Args:
            isin: ISIN identifier to search for.

        Returns:
            CompanyListItem if found, or ``None`` if no match.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        resp = self.list_companies(isin=isin)
        results = resp.get("results", []) if isinstance(resp, dict) else resp
        return results[0] if results else None

    def resolve_company(
        self,
        *,
        ticker: str | None = None,
        isin: str | None = None,
        exchange: str | None = None,
        name: str | None = None,
    ) -> CompanyResolveResult | None:
        """Resolve a company by ticker and/or ISIN.

        Cascading resolution: DB → OpenFIGI → Perplexity.
        At least one of ticker or isin is required.

        Args:
            ticker: Stock ticker symbol (e.g. ``"TTE"``).
            isin: ISIN identifier (e.g. ``"FR0000120271"``).
            exchange: Optional OpenFIGI exchange code (e.g. ``"FP"`` for
                Euronext Paris) to disambiguate short tickers.
            name: Optional company name hint to improve Perplexity resolution.

        Returns:
            CompanyResolveResult if found, or ``None`` if not found.

        Raises:
            BoardDataError: On non-2xx API response (except 404).
            ValueError: If neither ticker nor isin is provided.
        """
        if not ticker and not isin:
            raise ValueError("Provide at least one of: ticker, isin")

        from .errors import BoardDataError

        try:
            return self._get(  # type: ignore[attr-defined]
                "companies/resolve/",
                ticker=ticker,
                isin=isin,
                exchange=exchange,
                name=name,
            )
        except BoardDataError as exc:
            if exc.status_code == 404:
                return None
            raise

    def upsert_company(
        self,
        isin: str,
        name: str,
        *,
        country: str | None = None,
        ticker: str | None = None,
        logo: str | None = None,
        since: str | None = None,
        description: str | None = None,
        purpose: str | None = None,
        website: str | None = None,
        governance_code: str | None = None,
        sectors: list[int] | None = None,
        headquarter: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
        temporal_data: list[TemporalAttributePayload] | None = None,
    ) -> UpsertResult:
        """Find company by ISIN, create or update. Optionally upsert temporal attributes.

        Args:
            isin: ISIN identifier (used for lookup).
            name: Company name.
            country: ISO country code.
            ticker: Stock ticker symbol.
            logo: URL to company logo.
            since: Date the company was added (``"YYYY-MM-DD"``).
            description: Company description text.
            purpose: Corporate purpose statement.
            website: Company website URL.
            governance_code: Governance code reference.
            sectors: List of sector IDs.
            headquarter: Headquarters address.
            field_sources: Document provenance for fields.
            temporal_data: List of temporal attribute payloads to upsert.

        Returns:
            UpsertResult::

                {"action": "created", "id": "uuid", "data": {<CompanyDetail>}}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        company = self.get_company_by_isin(isin)
        company_uid = company.get("id") if company else None

        payload = self._build_payload(  # type: ignore[attr-defined]
            name=name,
            isin=isin,
            country=country,
            ticker=ticker,
            logo=logo,
            since=since,
            description=description,
            purpose=purpose,
            website=website,
            governance_code=governance_code,
            sectors=sectors,
            headquarter=headquarter,
            field_sources=field_sources,
        )

        if company_uid:
            logger.info("Updating company %s", company_uid)
            data = self._patch(f"companies/{company_uid}/", payload)  # type: ignore[attr-defined]
            action = "updated"
        else:
            logger.info("Creating company with ISIN %s", isin)
            data = self._post("companies/", payload)  # type: ignore[attr-defined]
            company_uid = data["id"]
            action = "created"

        if temporal_data:
            logger.info("Upserting %d temporal attribute(s)", len(temporal_data))
            self.update_temporal_attributes(company_uid, temporal_data)

        return UpsertResult(action=action, id=company_uid, data=data)

    # -- Temporal attributes --

    def update_temporal_attributes(
        self,
        company_uid: str,
        data: list[TemporalAttributePayload],
    ) -> Any:
        """Upsert temporal attributes for a company.

        Args:
            company_uid: Company UUID.
            data: List of temporal attribute payloads.

        Returns:
            Server response.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._patch(f"companies/{company_uid}/temporal-attributes/", data)  # type: ignore[attr-defined]
