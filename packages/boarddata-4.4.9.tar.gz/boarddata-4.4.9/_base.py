"""OAuth2, HTTP transport, and shared helpers for BoardDataClient."""

from __future__ import annotations

import logging
import time
from typing import Any, Protocol, runtime_checkable

import requests

from .errors import BoardDataError

logger = logging.getLogger("boarddata")


@runtime_checkable
class TokenCache(Protocol):
    """Optional persistent token cache."""

    def read(self) -> dict[str, Any] | None:
        """Return cached token data or None."""
        ...

    def write(self, data: dict[str, Any]) -> None:
        """Persist token data."""
        ...


class Base:
    """OAuth2 Client Credentials authentication and HTTP transport layer.

    All domain mixins inherit from this class and use ``self._get()``,
    ``self._post()``, ``self._patch()``, ``self._put()``, ``self._delete()``.
    """

    _DEFAULT_CACHE = object()  # sentinel for auto-detection

    @classmethod
    def from_env(
        cls,
        *,
        token_cache: TokenCache | str | None | object = _DEFAULT_CACHE,
        timeout: int = 30,
    ) -> Base:
        """Create a client from environment variables.

        Reads:
            BOARDDATA_BACKEND_URL: Base URL of the BoardData API.
            BOARDDATA_CLIENT_ID: OAuth2 client ID.
            BOARDDATA_CLIENT_SECRET: OAuth2 client secret.

        Args:
            token_cache: File path string (e.g. ``"~/.boarddata/token.json"``)
                or a ``TokenCache`` instance. When a string is passed, a
                ``FileTokenCache`` is created automatically. Defaults to
                auto-detection: uses Scaleway Secret Manager if ``SCW_SECRET_KEY``
                and ``SCW_PROJECT_ID`` are set, otherwise a local file cache at
                ``/tmp/boarddata_token.json``. Pass ``None`` to disable caching.
            timeout: HTTP request timeout in seconds.

        Returns:
            A configured client instance.

        Raises:
            ValueError: If any required environment variable is missing or empty.
        """
        import os

        from .cache import FileTokenCache, ScalewaySecretTokenCache

        env_vars = {
            "BOARDDATA_BACKEND_URL": "base_url",
            "BOARDDATA_CLIENT_ID": "client_id",
            "BOARDDATA_CLIENT_SECRET": "client_secret",
        }
        kwargs: dict[str, str] = {}
        for env_key, param_name in env_vars.items():
            value = os.environ.get(env_key, "").strip()
            if not value:
                msg = f"{env_key} environment variable is required but missing or empty"
                raise ValueError(msg)
            kwargs[param_name] = value

        if token_cache is cls._DEFAULT_CACHE:
            if os.environ.get("SCW_SECRET_KEY") and os.environ.get("SCW_PROJECT_ID"):
                cache: TokenCache | None = ScalewaySecretTokenCache()
            else:
                cache = FileTokenCache("/tmp/boarddata_token.json")
        elif isinstance(token_cache, str):
            cache = FileTokenCache(token_cache)
        else:
            cache = token_cache  # type: ignore[assignment]

        return cls(
            **kwargs,
            timeout=timeout,
            token_cache=cache,
        )

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: str,
        timeout: int = 30,
        token_cache: TokenCache | None = None,
    ) -> None:
        if not base_url.startswith("https://"):
            logger.warning("base_url does not use HTTPS — credentials will be sent in plaintext")
        self.base_url = base_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self.timeout = timeout
        self._token_cache = token_cache

        self._token: str | None = None
        self._token_expires_at: float = 0

    def __repr__(self) -> str:
        return f"<{type(self).__name__} base_url={self.base_url!r}>"

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    def _get_token(self) -> str:
        """Obtain or return a cached OAuth2 access token."""
        if self._token and time.time() < self._token_expires_at:
            return self._token

        if self._token_cache:
            try:
                cached = self._token_cache.read()
                if cached and cached.get("access_token") and time.time() < cached.get("expires_at", 0):
                    self._token = cached["access_token"]
                    self._token_expires_at = cached["expires_at"]
                    logger.debug("Loaded cached OAuth2 token from storage")
                    return self._token
            except Exception:
                logger.warning("Could not read token from cache", exc_info=True)

        resp = requests.post(
            f"{self.base_url}/api/oauth/token/",
            data={
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "grant_type": "client_credentials",
                "scope": "read write",
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data["access_token"]
        self._token_expires_at = time.time() + data.get("expires_in", 3600) - 60

        if self._token_cache:
            try:
                self._token_cache.write({
                    "access_token": self._token,
                    "expires_at": self._token_expires_at,
                })
                logger.debug("Persisted OAuth2 token to storage")
            except Exception:
                logger.warning("Could not persist token to cache", exc_info=True)

        return self._token  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
        }

    def _url(self, path: str) -> str:
        path = path.lstrip("/")
        if ".." in path.split("/"):
            msg = f"Path traversal detected in URL path: {path!r}"
            raise ValueError(msg)
        return f"{self.base_url}/api/{path}"

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
    ) -> Any:
        resp = requests.request(
            method,
            self._url(path),
            headers=self._headers(),
            params=params,
            json=json,
            timeout=self.timeout,
        )
        if not resp.ok:
            try:
                detail = resp.json()
            except ValueError:
                detail = resp.text
            raise BoardDataError(resp.status_code, detail)
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    def _get(self, path: str, **params: Any) -> Any:
        filtered = {k: v for k, v in params.items() if v is not None}
        return self._request("GET", path, params=filtered or None)

    def _post(self, path: str, data: Any) -> Any:
        return self._request("POST", path, json=data)

    def _patch(self, path: str, data: Any) -> Any:
        return self._request("PATCH", path, json=data)

    def _put(self, path: str, data: Any) -> Any:
        return self._request("PUT", path, json=data)

    def _delete(self, path: str) -> None:
        self._request("DELETE", path)

    def _build_payload(self, **kwargs: Any) -> dict[str, Any]:
        """Build a request payload from kwargs, excluding None values."""
        return {k: v for k, v in kwargs.items() if v is not None}
