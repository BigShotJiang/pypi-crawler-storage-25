# boarddata

Python SDK for the BoardData V2 REST API.

## Installation

```bash
pip install boarddata
```

## Quick Start

```python
from boarddata import BoardDataClient

# From environment variables
client = BoardDataClient.from_env()

# Or explicit configuration
client = BoardDataClient(
    base_url="https://api.boarddata.scalens.com",
    client_id="your-client-id",
    client_secret="your-client-secret",
)

# List companies
companies = client.list_companies(country="FR", page_size=10)

# Get a specific company
company = client.get_company("company-uuid")

# Create or update a company
result = client.upsert_company("FR0000120271", "TotalEnergies", country="FR")
print(result["action"])  # "created" or "updated"
print(result["id"])      # company UUID
```

## Environment Variables

| Variable | Description |
|---|---|
| `BOARDDATA_BACKEND_URL` | Base URL of the BoardData API |
| `BOARDDATA_CLIENT_ID` | OAuth2 client ID (from Django admin) |
| `BOARDDATA_CLIENT_SECRET` | OAuth2 client secret (from Django admin) |

## Token Caching

```python
from boarddata import BoardDataClient, FileTokenCache

# File-based cache
client = BoardDataClient.from_env(token_cache="~/.boarddata/token.json")

# Or with explicit cache object
cache = FileTokenCache("~/.boarddata/token.json")
client = BoardDataClient.from_env(token_cache=cache)
```

## Pagination

```python
# Auto-paginate any list endpoint
all_companies = client.paginate(client.list_companies, country="FR")

# Limit pages
first_100 = client.paginate(client.list_companies, max_pages=4, page_size=25)
```

## Available Domains

- **Companies** — `list_companies`, `get_company`, `create_company`, `update_company`, `delete_company`, `upsert_company`
- **Persons** — `list_persons`, `get_person`, `create_person`, `update_person`, `delete_person`, `upsert_person`
- **Directors** — `list_directors`, `get_director`, `create_director`, `update_director`, `delete_director`, `upsert_director`
- **Comex** — `list_comex`, `get_comex`, `create_comex`, `update_comex`, `delete_comex`, `upsert_comex`
- **Auditors** — `list_auditors`, `get_auditor`, `create_auditor`, `update_auditor`, `delete_auditor`
- **Documents** — `list_documents`, `get_document`, `create_document`, `update_document`, `delete_document`
- **Assemblies** — `list_assemblies`, `get_assembly`, `create_assembly`, `update_assembly`, `delete_assembly`
- **Resolutions** — `list_resolutions`, `get_resolution`, `update_resolution`, `delete_resolution`
- **ESG** — `list_iros`, `create_iro`, `list_transition_plans`, `create_transition_plan`, `list_esg_benchmark`
- **Sentinel** — `list_analyses`, `create_analysis`, `retry_press_extraction`, `update_press_article`
- **Utilities** — `search`, `query_assistant`, `get_field_sources`, `paginate`

## License

MIT
