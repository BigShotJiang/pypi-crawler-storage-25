"""Person, nationality, and school methods."""

from __future__ import annotations

import logging
from typing import Any

from .types.core import AddressPayload, FieldSourcePayload, PaginatedResponse, UpsertResult
from .types.persons import PersonDetail, PersonSimilarityItem, SchoolItem

logger = logging.getLogger("boarddata")


class PersonMixin:
    """Person, nationality, and school API methods."""

    def list_persons(
        self,
        *,
        search: str | None = None,
        similarity: str | None = None,
        gender: str | None = None,
        nationality: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> PaginatedResponse:
        """List persons.

        Args:
            search: Search by first/last name.
            similarity: Trigram similarity search (returns best matches by name).
            gender: Filter by gender code.
            nationality: Filter by nationality code(s), comma-separated.
            page: Page number (1-indexed).
            page_size: Results per page.

        Returns:
            PaginatedResponse with ``results`` list of PersonListItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(  # type: ignore[attr-defined]
            "persons/",
            search=search,
            similarity=similarity,
            gender=gender,
            nationality=nationality,
            page=page,
            page_size=page_size,
        )

    def get_person(self, uid: str) -> PersonDetail:
        """Retrieve a person by UUID.

        Args:
            uid: Person UUID.

        Returns:
            PersonDetail with full person data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"persons/{uid}/")  # type: ignore[attr-defined]

    def create_person(
        self,
        first_name: str,
        last_name: str,
        *,
        gender: str | None = None,
        date_of_birth: str | None = None,
        bio: str | None = None,
        nationalities: list[int] | None = None,
        schools: list[int] | None = None,
        professional_address: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> PersonDetail:
        """Create a person.

        Args:
            first_name: First name.
            last_name: Last name.
            gender: Gender code (``"M"``, ``"F"``).
            date_of_birth: Date of birth (``"YYYY-MM-DD"``).
            bio: Biography text.
            nationalities: List of nationality IDs.
            schools: List of school IDs.
            professional_address: Professional address payload.
            field_sources: Document provenance for fields.

        Returns:
            Created PersonDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            first_name=first_name,
            last_name=last_name,
            gender=gender,
            date_of_birth=date_of_birth,
            bio=bio,
            nationalities=nationalities,
            schools=schools,
            professional_address=professional_address,
            field_sources=field_sources,
        )
        return self._post("persons/", payload)  # type: ignore[attr-defined]

    def update_person(
        self,
        uid: str,
        *,
        first_name: str | None = None,
        last_name: str | None = None,
        gender: str | None = None,
        date_of_birth: str | None = None,
        bio: str | None = None,
        nationalities: list[int] | None = None,
        schools: list[int] | None = None,
        professional_address: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> PersonDetail:
        """Partial update a person.

        Args:
            uid: Person UUID.
            first_name: First name.
            last_name: Last name.
            gender: Gender code.
            date_of_birth: Date of birth (``"YYYY-MM-DD"``).
            bio: Biography text.
            nationalities: List of nationality IDs.
            schools: List of school IDs.
            professional_address: Professional address.
            field_sources: Document provenance for fields.

        Returns:
            Updated PersonDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            first_name=first_name,
            last_name=last_name,
            gender=gender,
            date_of_birth=date_of_birth,
            bio=bio,
            nationalities=nationalities,
            schools=schools,
            professional_address=professional_address,
            field_sources=field_sources,
        )
        return self._patch(f"persons/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_person(self, uid: str) -> None:
        """Soft-delete a person.

        Args:
            uid: Person UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"persons/{uid}/")  # type: ignore[attr-defined]

    def list_nationalities(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
    ) -> PaginatedResponse:
        """List all nationalities.

        Args:
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with nationality results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("nationalities/", page=page, page_size=page_size)  # type: ignore[attr-defined]

    def list_schools(
        self,
        *,
        country: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> PaginatedResponse:
        """List schools.

        Args:
            country: Filter by ISO country code.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with SchoolItem results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("schools/", country=country, page=page, page_size=page_size)  # type: ignore[attr-defined]

    def create_school(self, name: str, country: str) -> SchoolItem:
        """Create a school.

        Args:
            name: School name.
            country: ISO country code.

        Returns:
            Created SchoolItem::

                {"id": 42, "name": "HEC Paris", "country": "FR"}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._post("schools/", {"name": name, "country": country})  # type: ignore[attr-defined]

    def find_person_by_similarity(self, full_name: str) -> PersonSimilarityItem | None:
        """Find the best-matching person by trigram similarity.

        Args:
            full_name: Full name to search for (e.g. ``"Jean Dupont"``).

        Returns:
            PersonSimilarityItem for the best match, or ``None`` if no match found.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        resp = self.list_persons(similarity=full_name)
        if isinstance(resp, dict) and "results" in resp:
            results = resp["results"]
        elif isinstance(resp, list):
            results = resp
        else:
            return resp if resp else None
        return results[0] if results else None

    def upsert_person(
        self,
        person_name: str,
        *,
        first_name: str,
        last_name: str,
        gender: str | None = None,
        date_of_birth: str | None = None,
        bio: str | None = None,
        nationalities: list[int] | None = None,
        schools: list[int] | None = None,
        professional_address: AddressPayload | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> UpsertResult:
        """Find person by similarity, create or update.

        Args:
            person_name: Full name used for similarity search.
            first_name: First name.
            last_name: Last name.
            gender: Gender code.
            date_of_birth: Date of birth (``"YYYY-MM-DD"``).
            bio: Biography text.
            nationalities: List of nationality IDs.
            schools: List of school IDs.
            professional_address: Professional address.
            field_sources: Document provenance for fields.

        Returns:
            UpsertResult::

                {"action": "created", "id": "uuid", "data": {<PersonDetail>}}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        person = self.find_person_by_similarity(person_name)
        person_uid = person["id"] if person else None

        payload = self._build_payload(  # type: ignore[attr-defined]
            first_name=first_name,
            last_name=last_name,
            gender=gender,
            date_of_birth=date_of_birth,
            bio=bio,
            nationalities=nationalities,
            schools=schools,
            professional_address=professional_address,
            field_sources=field_sources,
        )

        if person_uid:
            logger.info("Updating person %s (%s)", person_uid, person_name)
            data = self._patch(f"persons/{person_uid}/", payload)  # type: ignore[attr-defined]
            return UpsertResult(action="updated", id=person_uid, data=data)

        logger.info("Creating person '%s'", person_name)
        data = self._post("persons/", payload)  # type: ignore[attr-defined]
        return UpsertResult(action="created", id=data["id"], data=data)
