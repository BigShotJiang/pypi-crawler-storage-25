"""Criteria catalog and theme methods."""

from __future__ import annotations

from typing import Any

from .types.criteria import CriteriaCatalogItem, CriteriaThemeItem


class CriteriaMixin:
    """Criteria catalog and theme API methods.

    Provides access to the shared criteria catalog used by compensation
    records across all comex mandates.
    """

    def list_criteria_themes(self) -> list[CriteriaThemeItem]:
        """List all criteria themes.

        Returns:
            List of criteria themes (not paginated).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("criteria-themes/")  # type: ignore[attr-defined]

    def list_criteria(
        self,
        theme: str | None = None,
    ) -> list[CriteriaCatalogItem]:
        """List all criteria catalog entries.

        Args:
            theme: Filter by criteria theme UUID.

        Returns:
            List of criteria (not paginated).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        params: dict[str, Any] = {}
        if theme is not None:
            params["theme"] = theme
        return self._get("criteria/", **params)  # type: ignore[attr-defined]

    def create_criteria(
        self,
        name: str,
        theme_id: str | None = None,
    ) -> CriteriaCatalogItem:
        """Create a criteria catalog entry.

        Args:
            name: Standardized criterion name (e.g. ``"Revenue Growth"``).
            theme_id: UUID of the criteria theme.

        Returns:
            Created criteria entry.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload: dict[str, Any] = {"name": name}
        if theme_id is not None:
            payload["theme_id"] = theme_id
        return self._post("criteria/", payload)  # type: ignore[attr-defined]
