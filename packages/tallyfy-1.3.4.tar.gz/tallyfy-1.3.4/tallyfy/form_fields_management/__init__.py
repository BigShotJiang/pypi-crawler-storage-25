"""
Form Fields Management Package

This package provides a modular approach to form field management
functionality with specialized components for better maintainability
and separation of concerns.

Classes:
    FormFieldCRUD: Basic CRUD operations for form fields
    FormFieldOptions: Dropdown options management
    FormFieldManager: Unified interface combining all functionality
"""

from .base import FormFieldManagerBase
from .crud_operations import FormFieldCRUD
from .options_management import FormFieldOptions


class FormFieldManager:
    """
    Unified interface for form field management functionality.

    This class provides access to all form field management capabilities
    through a single interface while maintaining the modular structure
    underneath.
    """

    def __init__(self, sdk):
        """
        Initialize form field manager with SDK instance.

        Args:
            sdk: Main SDK instance
        """
        self.crud = FormFieldCRUD(sdk)
        self.options = FormFieldOptions(sdk)

        # For backward compatibility, expose common methods at the top level
        self.add_form_field_to_step = self.crud.add_form_field_to_step
        self.update_form_field = self.crud.update_form_field
        self.move_form_field = self.crud.move_form_field
        self.delete_form_field = self.crud.delete_form_field
        self.get_step = self.crud.get_step
        self.reorder_form_fields = self.crud.reorder_form_fields

        # Options management methods
        self.get_dropdown_options = self.options.get_dropdown_options
        self.update_dropdown_options = self.options.update_dropdown_options
        self.add_dropdown_option = self.options.add_dropdown_option
        self.remove_dropdown_option = self.options.remove_dropdown_option
        self.reorder_dropdown_options = self.options.reorder_dropdown_options


# For backward compatibility, create an alias
FormFieldManagement = FormFieldManager

__all__ = [
    'FormFieldManagerBase',
    'FormFieldCRUD',
    'FormFieldOptions',
    'FormFieldManager',
    'FormFieldManagement'  # Backward compatibility alias
]
