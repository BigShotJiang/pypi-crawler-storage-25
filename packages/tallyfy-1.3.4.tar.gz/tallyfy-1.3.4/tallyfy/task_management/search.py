"""
Task/process search — thin delegation layer.
All search logic lives in tallyfy/search_management/.
"""

from typing import List
from .base import TaskManagerBase
from ..models import SearchResult, SearchResultsList


class TaskSearch(TaskManagerBase):
    """Delegates search operations to SearchManager for backward compatibility."""

    def search_processes_by_name(self, org_id: str, process_name: str) -> str:
        return self.sdk.searches.search_processes_by_name(org_id, process_name)

    def search(
        self,
        org_id: str,
        search_query: str,
        search_type: str = "process",
        page: int = 1,
        per_page: int = 20,
    ) -> SearchResultsList:
        return self.sdk.searches.search(
            org_id, search_query, on=search_type, page=page, per_page=per_page
        )

    def search_processes(
        self, org_id: str, search_query: str, page: int = 1, per_page: int = 20
    ) -> SearchResultsList:
        return self.sdk.searches.search_processes(org_id, search_query, page=page, per_page=per_page)

    def search_templates(
        self, org_id: str, search_query: str, page: int = 1, per_page: int = 20
    ) -> SearchResultsList:
        return self.sdk.searches.search_templates(org_id, search_query, page=page, per_page=per_page)

    def search_tasks(
        self, org_id: str, search_query: str, page: int = 1, per_page: int = 20
    ) -> SearchResultsList:
        return self.sdk.searches.search_tasks(org_id, search_query, page=page, per_page=per_page)

    def find_process_by_name(
        self, org_id: str, process_name: str, exact_match: bool = True
    ) -> List[SearchResult]:
        return self.sdk.searches.find_process_by_name(org_id, process_name, exact_match=exact_match)
