"""
Search management module for Tallyfy SDK
"""

from .operations import SearchManager

__all__ = ["SearchManager"]
