"""
Base class for search management operations
"""

from ..validation import validate_id
from ..models import TallyfyError


class SearchManagerBase:
    """Base class providing common functionality for search management"""

    def __init__(self, sdk: object) -> None:
        self.sdk = sdk

    def _validate_org_id(self, org_id: str) -> None:
        validate_id(org_id, "org_id")

    def _handle_api_error(self, error: Exception, operation: str, **context: object) -> None:
        context_str = ", ".join(f"{k}={v}" for k, v in context.items())
        msg = f"Failed to {operation}"
        if context_str:
            msg += f" ({context_str})"
        msg += f": {error}"
        self.sdk.logger.error(msg)
        if isinstance(error, TallyfyError):
            raise error
        raise TallyfyError(msg)
