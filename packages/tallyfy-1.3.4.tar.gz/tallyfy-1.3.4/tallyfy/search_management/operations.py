"""
Global search operations across templates, processes, tasks, and snippets
"""

from typing import Dict, List, Optional, Any
from .base import SearchManagerBase
from ..models import SearchResult, SearchResultsList, TallyfyError

VALID_SEARCH_TYPES = ["blueprint", "process", "task", "snippet", "capture", "step"]


class SearchManager(SearchManagerBase):
    """Handles global search operations across all entity types"""

    def search(
        self,
        org_id: str,
        search_query: str,
        on: str = "process",
        page: int = 1,
        per_page: int = 20,
        tags: bool = False,
        filter_: Optional[str] = None,
    ) -> SearchResultsList:
        """
        Search a single entity type in the organization.

        Args:
            org_id: Organization ID
            search_query: Text to search for
            on: Entity type — one of 'blueprint', 'process', 'task', 'snippet',
                'capture', 'step' (default: 'process'). 'blueprint' = template.
            page: Page number (default: 1)
            per_page: Results per page, max 100 (default: 20)
            tags: Include tags in results (default: False)
            filter_: Advanced filter string (field/operator/value, e.g. 'title=Foo')

        Returns:
            SearchResultsList with results and pagination metadata

        Raises:
            TallyfyError: If the request fails
            ValueError: If arguments are invalid
        """
        self._validate_org_id(org_id)
        if not search_query or not isinstance(search_query, str):
            raise ValueError("search_query must be a non-empty string")
        if on not in VALID_SEARCH_TYPES:
            raise ValueError(f"on must be one of: {', '.join(VALID_SEARCH_TYPES)}")
        if per_page <= 0 or per_page > 100:
            raise ValueError("per_page must be between 1 and 100")

        try:
            endpoint = f"organizations/{org_id}/search"
            params: Dict[str, Any] = {
                "on": on,
                "page": page,
                "per_page": per_page,
                "search": search_query,
            }
            if tags:
                params["tags"] = "true"
            if filter_ is not None:
                params["filter"] = filter_

            response_data = self.sdk._make_request("GET", endpoint, params=params)
            return SearchResultsList.from_dict(response_data, on)

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "search", org_id=org_id, query=search_query, on=on)

    def search_all(
        self,
        org_id: str,
        search_query: str,
        page: int = 1,
        per_page: int = 20,
        tags: bool = False,
        types: Optional[List[str]] = None,
    ) -> Dict[str, SearchResultsList]:
        """
        Search multiple entity types in a single request.

        Args:
            org_id: Organization ID
            search_query: Text to search for
            page: Page number (default: 1)
            per_page: Results per page, max 100 (default: 20)
            tags: Include tags in results (default: False)
            types: List of entity types to search. Defaults to
                   ['blueprint', 'process', 'task', 'snippet'].

        Returns:
            Dict keyed by entity type, each value a SearchResultsList

        Raises:
            TallyfyError: If the request fails
            ValueError: If arguments are invalid
        """
        self._validate_org_id(org_id)
        if not search_query or not isinstance(search_query, str):
            raise ValueError("search_query must be a non-empty string")
        if types is None:
            types = ["blueprint", "process", "task", "snippet"]
        for t in types:
            if t not in VALID_SEARCH_TYPES:
                raise ValueError(f"Invalid type '{t}'. Must be one of: {', '.join(VALID_SEARCH_TYPES)}")

        try:
            endpoint = f"organizations/{org_id}/search"
            params: Dict[str, Any] = {
                "on": ",".join(types),
                "page": page,
                "per_page": per_page,
                "search": search_query,
            }
            if tags:
                params["tags"] = "true"

            response_data = self.sdk._make_request("GET", endpoint, params=params)
            return {t: SearchResultsList.from_dict(response_data, t) for t in types}

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "search_all", org_id=org_id, query=search_query)

    def search_templates(
        self,
        org_id: str,
        search_query: str,
        page: int = 1,
        per_page: int = 20,
        tags: bool = False,
    ) -> SearchResultsList:
        """Search for templates (blueprints) in the organization."""
        return self.search(org_id, search_query, on="blueprint", page=page, per_page=per_page, tags=tags)

    def search_processes(
        self,
        org_id: str,
        search_query: str,
        page: int = 1,
        per_page: int = 20,
        tags: bool = False,
    ) -> SearchResultsList:
        """Search for processes (runs) in the organization."""
        return self.search(org_id, search_query, on="process", page=page, per_page=per_page, tags=tags)

    def search_tasks(
        self,
        org_id: str,
        search_query: str,
        page: int = 1,
        per_page: int = 20,
        tags: bool = False,
    ) -> SearchResultsList:
        """Search for standalone tasks in the organization."""
        return self.search(org_id, search_query, on="task", page=page, per_page=per_page, tags=tags)

    def search_snippets(
        self,
        org_id: str,
        search_query: str,
        page: int = 1,
        per_page: int = 20,
    ) -> SearchResultsList:
        """Search for text snippets (text templates) in the organization."""
        return self.search(org_id, search_query, on="snippet", page=page, per_page=per_page)

    def search_templates_by_name(self, org_id: str, template_name: str) -> str:
        """
        Resolve a template name to its ID using the search endpoint.

        Tries an exact match first; falls back to a single fuzzy result.

        Args:
            org_id: Organization ID
            template_name: Name or partial name of the template

        Returns:
            Template ID string

        Raises:
            TallyfyError: If no match found or result is ambiguous
        """
        self._validate_org_id(org_id)
        if not template_name or not isinstance(template_name, str):
            raise ValueError("template_name must be a non-empty string")

        try:
            endpoint = f"organizations/{org_id}/search"
            params: Dict[str, Any] = {
                "on": "blueprint",
                "per_page": "20",
                "search": template_name,
            }
            response = self.sdk._make_request("GET", endpoint, params=params)

            if isinstance(response, dict) and "blueprint" in response:
                items = response["blueprint"].get("data", [])
                if items:
                    exact = [t for t in items if t.get("title", "").lower() == template_name.lower()]
                    if exact:
                        return exact[0]["id"]
                    if len(items) == 1:
                        return items[0]["id"]
                    names = [f"'{t['title']}'" for t in items[:10]]
                    raise TallyfyError(
                        f"Multiple templates found matching '{template_name}': "
                        f"{', '.join(names)}. Please be more specific."
                    )
            raise TallyfyError(f"No template found matching name: {template_name}")

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "search templates by name", org_id=org_id, template_name=template_name)

    def search_processes_by_name(self, org_id: str, process_name: str) -> str:
        """
        Resolve a process name to its ID using the search endpoint.

        Tries an exact match first; falls back to a single fuzzy result.

        Args:
            org_id: Organization ID
            process_name: Name or partial name of the process

        Returns:
            Process ID string

        Raises:
            TallyfyError: If no match found or result is ambiguous
        """
        self._validate_org_id(org_id)
        if not process_name or not isinstance(process_name, str):
            raise ValueError("process_name must be a non-empty string")

        try:
            endpoint = f"organizations/{org_id}/search"
            params: Dict[str, Any] = {
                "on": "process",
                "per_page": "20",
                "search": process_name,
            }
            response = self.sdk._make_request("GET", endpoint, params=params)
            if isinstance(response, dict) and "process" in response:
                items = response["process"].get("data", [])
                if items:
                    exact = [p for p in items if p.get("name", "").lower() == process_name.lower()]
                    if exact:
                        return exact[0]["id"]
                    if len(items) == 1:
                        return items[0]["id"]
                    names = [f"'{p['name']}'" for p in items[:5]]
                    raise TallyfyError(
                        f"Multiple processes found matching '{process_name}': "
                        f"{', '.join(names)}. Please be more specific."
                    )
            raise TallyfyError(f"No process found matching name: {process_name}")

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "search processes by name", org_id=org_id, process_name=process_name)

    def find_process_by_name(
        self,
        org_id: str,
        process_name: str,
        exact_match: bool = True,
    ) -> List[SearchResult]:
        """
        Find processes by name with flexible matching.

        Args:
            org_id: Organization ID
            process_name: Name to search for
            exact_match: If True, only return case-insensitive exact matches

        Returns:
            List of matching SearchResult objects
        """
        results = self.search_processes(org_id, process_name)
        if exact_match:
            return [
                r for r in results.data
                if hasattr(r, "name") and r.name is not None
                and r.name.lower() == process_name.lower()
            ]
        return results.data
