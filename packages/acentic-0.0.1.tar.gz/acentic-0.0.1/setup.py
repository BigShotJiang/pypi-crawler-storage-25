from setuptools import setup, Extension

core_module = Extension(
    'acentic.libcalc',
    sources=['acentic/internal.c'],
    libraries=['m'],
)

setup(
    name='acentic',
    version='0.0.1',
    description='A high-performance linear equation solver with C-engine acceleration',
    author='Gurumayum Bryan Sharma',
    packages=['acentic'],
    ext_modules=[core_module],
    python_requires='>=3.6',
)