import base64
import json

import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from truemarkets.auth import (
    load_key_file,
    load_private_key_jwk,
    sign_challenge,
    turnkey_stamp,
)


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64u_decode(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


@pytest.fixture
def bundle(tmp_path):
    """Generate a fresh P-256 keypair and write a TM-style JSON bundle."""
    key = ec.generate_private_key(ec.SECP256R1())
    nums = key.public_key().public_numbers()
    priv_int = key.private_numbers().private_value
    jwk = {
        "kty": "EC", "crv": "P-256",
        "d": _b64u(priv_int.to_bytes(32, "big")),
        "x": _b64u(nums.x.to_bytes(32, "big")),
        "y": _b64u(nums.y.to_bytes(32, "big")),
    }
    path = tmp_path / "key.json"
    path.write_text(json.dumps({
        "key_id": "deadbeef-0000-0000-0000-000000000000",
        "private_key": jwk,
        "algorithm": "ES256",
    }))
    return path, key


def test_load_key_file_returns_keyid_and_matching_key(bundle):
    path, original = bundle
    key_id, key = load_key_file(path)
    assert key_id == "deadbeef-0000-0000-0000-000000000000"
    assert key.private_numbers().private_value == original.private_numbers().private_value


def test_load_private_key_jwk_rejects_unsupported_curve():
    with pytest.raises(ValueError, match="Unsupported JWK"):
        load_private_key_jwk({"kty": "EC", "crv": "P-384"})


def test_load_private_key_jwk_rejects_missing_d():
    with pytest.raises(ValueError, match="missing private scalar"):
        load_private_key_jwk({"kty": "EC", "crv": "P-256", "x": "x", "y": "y"})


def test_load_key_file_rejects_non_es256(tmp_path):
    path = tmp_path / "k.json"
    path.write_text(json.dumps({
        "key_id": "id", "algorithm": "RS256",
        "private_key": {"kty": "EC", "crv": "P-256", "d": "x", "x": "x", "y": "y"},
    }))
    with pytest.raises(ValueError, match="unsupported algorithm"):
        load_key_file(path)


def test_sign_challenge_produces_verifiable_signature(bundle):
    _, key = bundle
    sig_b64 = sign_challenge(key, "kid", 1234567890)
    sig = _b64u_decode(sig_b64)
    # JOSE r||s = 64 bytes for P-256
    assert len(sig) == 64
    r = int.from_bytes(sig[:32], "big")
    s = int.from_bytes(sig[32:], "big")
    der = encode_dss_signature(r, s)
    # If the signature was over `kid.1234567890`, this verifies cleanly.
    key.public_key().verify(der, b"kid.1234567890", ec.ECDSA(hashes.SHA256()))


def test_turnkey_stamp_envelope_shape_and_signature(bundle):
    _, key = bundle
    payload = b'{"organizationId":"abc","type":"ACTIVITY_TYPE_FOO"}'
    stamp = turnkey_stamp(key, payload)
    decoded = json.loads(_b64u_decode(stamp))

    assert decoded["scheme"] == "SIGNATURE_SCHEME_TK_API_P256"
    # Compressed pubkey: 33 bytes = 66 hex chars, prefix 02 or 03.
    assert len(decoded["publicKey"]) == 66
    assert decoded["publicKey"][:2] in ("02", "03")
    # DER signature must verify against the payload bytes.
    der = bytes.fromhex(decoded["signature"])
    key.public_key().verify(der, payload, ec.ECDSA(hashes.SHA256()))
