import pytest

from truemarkets.config import Config, PROD_BASE, UAT_BASE


@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    """Skip dotenv discovery and clear TM_* vars so tests don't leak."""
    monkeypatch.setattr("truemarkets.config.find_dotenv", lambda **kw: "")
    monkeypatch.setattr("truemarkets.config.load_dotenv", lambda *a, **kw: None)
    for var in ("TM_ENV", "TM_BASE_URL", "TM_KEY_FILE"):
        monkeypatch.delenv(var, raising=False)


def test_default_base_url_is_uat():
    assert Config.from_env().base_url == UAT_BASE


def test_prod_env_uses_prod_base(monkeypatch):
    monkeypatch.setenv("TM_ENV", "prod")
    assert Config.from_env().base_url == PROD_BASE


def test_base_url_override(monkeypatch):
    monkeypatch.setenv("TM_BASE_URL", "https://custom")
    assert Config.from_env().base_url == "https://custom"


def test_key_file_picked_up(monkeypatch):
    monkeypatch.setenv("TM_KEY_FILE", "/tmp/k.json")
    assert Config.from_env().key_file == "/tmp/k.json"


def test_endpoint_paths():
    cfg = Config.from_env()
    assert cfg.auth_base.endswith("/v1/auth")
    assert cfg.gateway_base.endswith("/v1/conductor")
    assert cfg.defi_base.endswith("/v1/defi/core")
