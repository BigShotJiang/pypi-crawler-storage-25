"""
Guards that the release pipeline's version bump actually reaches the
places we care about — User-Agent header on every outbound request, and
the `sdk_version` property on every telemetry event.

`scripts/release.sh` only edits typescript/package.json + python/pyproject.toml.
If SDK_VERSION or USER_AGENT ever stop deriving from the installed package
metadata, the next release will silently ship the old version on the wire
while the PyPI distribution claims the new one. These tests fail loudly if
that happens.
"""
import importlib
import re
from importlib.metadata import PackageNotFoundError, version

import pytest

from truemarkets.client import USER_AGENT
from truemarkets.telemetry import SDK_LANG, SDK_VERSION


SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$")


def test_sdk_version_is_non_empty_semver():
    assert isinstance(SDK_VERSION, str)
    assert SDK_VERSION  # non-empty
    # The fallback "0.0.0+unknown" is only used in source-tree-without-install
    # scenarios; in the test env the package is installed (`pip install -e .`),
    # so we expect a real semver here.
    assert SEMVER_RE.match(SDK_VERSION), SDK_VERSION


def test_sdk_version_matches_installed_package_metadata():
    """SDK_VERSION should be exactly what `importlib.metadata` reports —
    no manual constants drifting from pyproject.toml."""
    assert SDK_VERSION == version("truemarkets")


def test_sdk_lang_is_static_python_tag():
    assert SDK_LANG == "python"


def test_user_agent_format():
    assert USER_AGENT == f"truemarkets-python/{SDK_VERSION}"
    # Also asserts the lang tag is encoded in the UA — guards against a
    # rename of the package without updating the UA prefix.
    assert USER_AGENT.startswith("truemarkets-python/")


def test_sdk_version_falls_back_when_package_not_installed(monkeypatch):
    """If `truemarkets` is not installed (raw source tree, no `pip install -e`),
    importlib.metadata raises PackageNotFoundError and we fall back to a
    sentinel so headers/events stay identifiable rather than crashing.

    We patch `importlib.metadata.version` (the parent module's binding) so
    that when `truemarkets.telemetry` is reloaded, its
    `from importlib.metadata import version` rebinds to the patched func.
    Patching only the alias in `truemarkets.telemetry` wouldn't survive the
    reload, because the reload reruns the `from ... import` line.
    """
    import importlib.metadata as md
    import truemarkets.telemetry as tele

    def _raise(_name: str) -> str:
        raise PackageNotFoundError("truemarkets")

    monkeypatch.setattr(md, "version", _raise)
    reloaded = importlib.reload(tele)
    try:
        assert reloaded.SDK_VERSION == "0.0.0+unknown"
    finally:
        # Restore real metadata for downstream tests sharing the process.
        monkeypatch.undo()
        importlib.reload(tele)
