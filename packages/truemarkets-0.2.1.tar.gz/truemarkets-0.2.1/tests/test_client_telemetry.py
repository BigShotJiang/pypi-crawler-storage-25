"""
Integration tests for the Client ↔ Telemetry wiring.

We inject a SpyTelemetry that records every method call so we can assert
that Client invokes the right Telemetry methods in the right order. For
the authenticate() path we monkeypatch load_key_file + mint_token so no
real network or filesystem reads are needed.
"""
import base64
import importlib
import json
from typing import Any

import pytest

from truemarkets.config import Config


FAKE_KEY_ID = "deadbeef-0000-0000-0000-000000000000"
FAKE_SUB = "user@example.com"
FAKE_UID = "363d2b2e-8799-4d71-8ecc-8eab40b7351f"


def _fake_jwt(sub: str = FAKE_SUB, uid: str = FAKE_UID) -> str:
    payload = base64.urlsafe_b64encode(
        json.dumps({"sub": sub, "uid": uid, "iat": 1}).encode()
    )
    return f"header.{payload.rstrip(b'=').decode()}.sig"


class SpyTelemetry:
    """Duck-types the public Telemetry surface. Records every call; never
    touches posthog."""

    enabled = True
    distinct_id = "spy-distinct-id"

    def __init__(self) -> None:
        self.calls: list[tuple[str, tuple, dict]] = []

    def set_api_key_id(self, key_id: str) -> None:
        self.calls.append(("set_api_key_id", (key_id,), {}))

    def set_user_identity(self, uid: str, sub: str | None) -> None:
        self.calls.append(("set_user_identity", (uid, sub), {}))

    def capture(self, event: str, properties: dict[str, Any] | None = None) -> None:
        self.calls.append(("capture", (event,), dict(properties or {})))

    def shutdown(self) -> None:
        self.calls.append(("shutdown", (), {}))

    def event_names(self) -> list[str]:
        return [c[1][0] for c in self.calls if c[0] == "capture"]


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    for k in ("TM_TELEMETRY", "DO_NOT_TRACK", "TM_POSTHOG_HOST", "TM_KEY_FILE"):
        monkeypatch.delenv(k, raising=False)
    # Default to "" so the baked key is overridden — keeps test runs from
    # instantiating a real PostHog client.
    monkeypatch.setenv("TM_POSTHOG_KEY", "")


@pytest.fixture
def patched_auth(monkeypatch):
    """Replace load_key_file + mint_token on the client module so authenticate()
    runs without touching disk or network."""
    monkeypatch.setattr(
        "truemarkets.client.load_key_file",
        lambda path: (FAKE_KEY_ID, "fake-private-key"),
    )
    monkeypatch.setattr(
        "truemarkets.client.mint_token",
        lambda cfg, key, key_id: {"access_token": _fake_jwt(), "refresh_token": "rt"},
    )


# ---------------------------------------------------------------------------
# Positive path: methods are called properly
# ---------------------------------------------------------------------------

def test_constructor_fires_sdk_initialized_exactly_once():
    from truemarkets.client import Client

    spy = SpyTelemetry()
    Client(cfg=Config(base_url="https://test", key_file=None), telemetry=spy)

    assert spy.event_names() == ["sdk_initialized"]
    init_call = spy.calls[0]
    assert isinstance(init_call[2].get("runtime"), str)


def test_authenticate_promotes_identity_keyid_to_user_identity(patched_auth):
    from truemarkets.client import Client

    spy = SpyTelemetry()
    client = Client(
        cfg=Config(base_url="https://test", key_file="/fake/key.json"),
        telemetry=spy,
    )
    spy.calls.clear()  # drop the constructor's sdk_initialized

    client.authenticate()

    # Order matters: set_api_key_id (pre-mint), then set_user_identity
    # (post-mint, with JWT claims), then capture("sdk_authenticated").
    methods = [c[0] for c in spy.calls]
    assert methods == ["set_api_key_id", "set_user_identity", "capture"]

    assert spy.calls[0][1] == (FAKE_KEY_ID,)
    assert spy.calls[1][1] == (FAKE_UID, FAKE_SUB)
    assert spy.calls[2][1][0] == "sdk_authenticated"
    assert spy.calls[2][2] == {"is_refresh": False}


def test_second_authenticate_marks_refresh_and_skips_set_api_key_id(patched_auth):
    from truemarkets.client import Client

    spy = SpyTelemetry()
    client = Client(
        cfg=Config(base_url="https://test", key_file="/fake/key.json"),
        telemetry=spy,
    )
    client.authenticate()
    spy.calls.clear()

    client.authenticate()

    # Key already cached → set_api_key_id is NOT invoked again. set_user_identity
    # IS invoked (Telemetry's own logic no-ops when uid is unchanged).
    methods = [c[0] for c in spy.calls]
    assert methods == ["set_user_identity", "capture"]
    assert spy.calls[1][2] == {"is_refresh": True}


# ---------------------------------------------------------------------------
# Negative path: env-disable means no PostHog ingestion
# ---------------------------------------------------------------------------

def test_tm_telemetry_zero_disables_telemetry_at_client_level(monkeypatch):
    monkeypatch.setenv("TM_TELEMETRY", "0")
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_dummy_should_not_be_used")

    from truemarkets.client import Client

    client = Client(cfg=Config(base_url="https://test", key_file=None))
    # No spy injected → real Telemetry, which read env. enabled=False
    # guarantees its inner posthog client was never instantiated.
    assert client.telemetry.enabled is False


def test_do_not_track_disables_telemetry_at_client_level(monkeypatch):
    monkeypatch.setenv("DO_NOT_TRACK", "1")
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_dummy_should_not_be_used")

    from truemarkets.client import Client

    client = Client(cfg=Config(base_url="https://test", key_file=None))
    assert client.telemetry.enabled is False


def test_empty_posthog_key_disables_telemetry():
    """TM_POSTHOG_KEY='' (set by autouse fixture) overrides the baked key."""
    from truemarkets.client import Client

    client = Client(cfg=Config(base_url="https://test", key_file=None))
    assert client.telemetry.enabled is False


def test_disabled_telemetry_never_instantiates_posthog(monkeypatch):
    """Strongest assertion: even with a valid-looking key present, when env
    disables telemetry the Posthog class is never instantiated."""
    monkeypatch.setenv("TM_TELEMETRY", "0")
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_dummy_should_not_be_used")

    import posthog as posthog_module
    call_count = {"n": 0}
    real_ctor = posthog_module.Posthog

    class TrackingPosthog(real_ctor):  # type: ignore[misc]
        def __init__(self, *a, **kw):
            call_count["n"] += 1
            super().__init__(*a, **kw)

    monkeypatch.setattr("posthog.Posthog", TrackingPosthog)
    importlib.reload(__import__("truemarkets.telemetry", fromlist=["dummy"]))
    from truemarkets.client import Client

    client = Client(cfg=Config(base_url="https://test", key_file="/fake/key.json"))
    assert client.telemetry.enabled is False
    assert call_count["n"] == 0


def test_authenticate_with_disabled_telemetry_makes_no_posthog_calls(monkeypatch, patched_auth):
    """End-to-end: TM_TELEMETRY=0 plus authenticate() → still zero PostHog."""
    monkeypatch.setenv("TM_TELEMETRY", "0")
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_dummy_should_not_be_used")

    import posthog as posthog_module
    capture_count = {"n": 0}
    alias_count = {"n": 0}
    identify_count = {"n": 0}
    real_ctor = posthog_module.Posthog

    class TrackingPosthog(real_ctor):  # type: ignore[misc]
        def capture(self, *a, **kw):
            capture_count["n"] += 1
        def alias(self, *a, **kw):
            alias_count["n"] += 1
        def identify(self, *a, **kw):
            identify_count["n"] += 1

    monkeypatch.setattr("posthog.Posthog", TrackingPosthog)
    importlib.reload(__import__("truemarkets.telemetry", fromlist=["dummy"]))
    from truemarkets.client import Client

    client = Client(cfg=Config(base_url="https://test", key_file="/fake/key.json"))
    client.authenticate()

    assert client.telemetry.enabled is False
    assert capture_count["n"] == 0
    assert alias_count["n"] == 0
    assert identify_count["n"] == 0
