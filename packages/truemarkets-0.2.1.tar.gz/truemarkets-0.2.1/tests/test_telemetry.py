import base64
import importlib
import json

import pytest


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    for k in ("TM_TELEMETRY", "DO_NOT_TRACK", "TM_POSTHOG_HOST"):
        monkeypatch.delenv(k, raising=False)
    # Default to "" so the baked key is overridden and no real PostHog
    # client is constructed during the test suite. Individual tests can
    # override via monkeypatch.setenv.
    monkeypatch.setenv("TM_POSTHOG_KEY", "")


def _fresh_telemetry():
    """Telemetry reads env at construction; reload the module so each test
    sees a clean BAKED_POSTHOG_KEY/env interaction."""
    import truemarkets.telemetry as t
    return importlib.reload(t)


def test_tm_posthog_key_empty_disables():
    """Empty TM_POSTHOG_KEY overrides baked key — kill-switch for tests/CI."""
    t = _fresh_telemetry()
    assert t.Telemetry().enabled is False


def test_tm_telemetry_zero_disables_even_with_key(monkeypatch):
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_test_dummy")
    monkeypatch.setenv("TM_TELEMETRY", "0")
    t = _fresh_telemetry()
    assert t.Telemetry().enabled is False


def test_do_not_track_disables_even_with_key(monkeypatch):
    monkeypatch.setenv("TM_POSTHOG_KEY", "phc_test_dummy")
    monkeypatch.setenv("DO_NOT_TRACK", "1")
    t = _fresh_telemetry()
    assert t.Telemetry().enabled is False


def test_capture_and_id_methods_are_noop_when_disabled():
    t = _fresh_telemetry()
    inst = t.Telemetry()
    # None of these may raise even though there's no PostHog client behind it.
    inst.capture("anything")
    inst.set_api_key_id("key-id-xyz")
    inst.set_user_identity("user-uid-abc", "user@example.com")
    inst.set_user_identity("user-uid-abc", None)
    inst.shutdown()


def test_jwt_subject_extracts_sub():
    t = _fresh_telemetry()
    payload = base64.urlsafe_b64encode(
        json.dumps({"sub": "user-42", "iat": 1}).encode()
    ).rstrip(b"=").decode()
    token = f"header.{payload}.sig"
    assert t.jwt_subject(token) == "user-42"


def test_jwt_uid_extracts_uid():
    t = _fresh_telemetry()
    payload = base64.urlsafe_b64encode(
        json.dumps({
            "sub": "user@example.com",
            "uid": "363d2b2e-8799-4d71-8ecc-8eab40b7351f",
        }).encode()
    ).rstrip(b"=").decode()
    token = f"header.{payload}.sig"
    assert t.jwt_uid(token) == "363d2b2e-8799-4d71-8ecc-8eab40b7351f"


def test_jwt_helpers_return_none_when_claim_absent_or_malformed():
    t = _fresh_telemetry()
    assert t.jwt_subject("not-a-jwt") is None
    assert t.jwt_subject("a.b") is None  # only 2 segments
    assert t.jwt_subject("a.!!!notbase64!!!.c") is None

    # sub present, uid absent → jwt_uid returns None
    only_sub = base64.urlsafe_b64encode(json.dumps({"sub": "x"}).encode()).rstrip(b"=").decode()
    assert t.jwt_uid(f"h.{only_sub}.s") is None
