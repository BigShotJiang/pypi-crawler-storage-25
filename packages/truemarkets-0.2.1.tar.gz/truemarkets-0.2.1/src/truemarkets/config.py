import os
from dataclasses import dataclass

from dotenv import find_dotenv, load_dotenv


PROD_BASE = "https://api.truemarkets.co"
UAT_BASE = "https://api.uat.truemarkets.co"


@dataclass(frozen=True)
class Config:
    base_url: str
    key_file: str | None

    @property
    def auth_base(self) -> str:
        return f"{self.base_url}/v1/auth"

    @property
    def gateway_base(self) -> str:
        return f"{self.base_url}/v1/conductor"

    @property
    def defi_base(self) -> str:
        return f"{self.base_url}/v1/defi/core"

    @classmethod
    def from_env(cls) -> "Config":
        load_dotenv(find_dotenv(usecwd=True))
        env = os.environ.get("TM_ENV", "uat").lower()
        base = PROD_BASE if env == "prod" else UAT_BASE
        return cls(
            base_url=os.environ.get("TM_BASE_URL", base),
            key_file=os.environ.get("TM_KEY_FILE"),
        )
