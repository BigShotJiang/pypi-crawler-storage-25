"""
SDK usage telemetry.

No-op when disabled (env opt-out, missing key, or PostHog import/init failure).
All capture and identity changes are best-effort and never raise — telemetry
must not be able to break user code.

Identity strategy:
  1. Construction → ephemeral process UUID.
  2. load_key_file(key_id) → distinct_id = sha256(key_id)[:16].
  3. authenticate() → distinct_id = the JWT's raw `uid` claim (a stable
     user UUID — already opaque, no need to hash). PostHog `identify`
     attaches { hashed_email: sha256(jwt.sub)[:16], uid } to the person.
     `alias` links the previous id so historic events stay attributed.

Opt-out env vars (case-insensitive truthy/falsy):
  TM_TELEMETRY=0|false|no|off   → disable
  DO_NOT_TRACK=1|true|yes|on    → disable (industry convention)

Override env vars (kept for kill-switch / testing — not documented publicly):
  TM_POSTHOG_KEY    → overrides baked key; set to "" to force-disable
  TM_POSTHOG_HOST   → overrides default host
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import uuid
from importlib.metadata import PackageNotFoundError, version
from typing import Any


# Baked PostHog project key (write-only "public" key — safe to ship in
# source) and ingest host.
BAKED_POSTHOG_KEY: str | None = "phc_l7C4DhmNFvg6BgQ5By0GLzF03U6aqJ2ltHODYA16Pi1"
DEFAULT_POSTHOG_HOST = "https://d.truemarkets.co"

SDK_LANG = "python"
try:
    SDK_VERSION = version("truemarkets")
except PackageNotFoundError:
    # Running from a source tree that wasn't installed (e.g. `python -m` on a
    # checkout without `pip install -e .`). Fall back to a sentinel so headers
    # and telemetry events still carry *something* identifiable.
    SDK_VERSION = "0.0.0+unknown"


def _disabled_by_env() -> bool:
    tm = os.environ.get("TM_TELEMETRY", "").lower()
    if tm in {"0", "false", "no", "off"}:
        return True
    dnt = os.environ.get("DO_NOT_TRACK", "").lower()
    if dnt in {"1", "true", "yes", "on"}:
        return True
    return False


def _short_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def _jwt_claims(token: str) -> dict[str, Any] | None:
    """Decode a JWT payload (signature NOT verified — server vouched for it
    over TLS; we read claims only as identity hints)."""
    parts = token.split(".")
    if len(parts) != 3:
        return None
    try:
        payload = parts[1]
        padding = "=" * (-len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload + padding).decode("utf-8")
        claims = json.loads(decoded)
        return claims if isinstance(claims, dict) else None
    except Exception:
        return None


def jwt_subject(token: str) -> str | None:
    """Return the JWT's `sub` claim (typically the user's email)."""
    claims = _jwt_claims(token)
    sub = claims.get("sub") if claims else None
    return sub if isinstance(sub, str) else None


def jwt_uid(token: str) -> str | None:
    """Return the JWT's `uid` claim (typically a stable user UUID)."""
    claims = _jwt_claims(token)
    uid = claims.get("uid") if claims else None
    return uid if isinstance(uid, str) else None


class Telemetry:
    enabled: bool
    distinct_id: str

    def __init__(self) -> None:
        self.distinct_id = str(uuid.uuid4())
        self._bound_uid: str | None = None
        self._client: Any = None

        # `os.environ.get(name, default)` returns "" if name is set to empty,
        # which our `not key` check below then treats as disabled — exactly
        # the kill-switch semantics we want.
        key = os.environ.get("TM_POSTHOG_KEY", BAKED_POSTHOG_KEY)
        host = os.environ.get("TM_POSTHOG_HOST", DEFAULT_POSTHOG_HOST)

        if _disabled_by_env() or not key:
            self.enabled = False
            return

        try:
            # Imported lazily so a missing posthog install (or import-time
            # crash on a weird platform) doesn't break the SDK.
            from posthog import Posthog  # type: ignore[import-not-found]

            self._client = Posthog(project_api_key=key, host=host)
            self.enabled = True
        except Exception:
            self._client = None
            self.enabled = False

    def set_api_key_id(self, key_id: str) -> None:
        """Set identity from the API key id. Skipped once a uid has pinned us."""
        if not self.enabled or self._bound_uid:
            return
        next_id = _short_hash(key_id)
        if next_id == self.distinct_id:
            return
        self._alias(self.distinct_id, next_id)
        self.distinct_id = next_id

    def set_user_identity(self, uid: str, sub: str | None) -> None:
        """Set identity from a JWT's claims.

        `uid` becomes the new `distinct_id` (raw — a UUID, not PII). `sub`
        is hashed into the `hashed_email` person property. Aliases the
        previous distinct_id under uid so pre-auth events stay attributed
        to the same user.
        """
        if not self.enabled or self._client is None:
            return
        if uid == self._bound_uid:
            return
        self._alias(self.distinct_id, uid)
        self.distinct_id = uid
        self._bound_uid = uid

        try:
            person_props: dict[str, Any] = {"uid": uid}
            if sub:
                person_props["hashed_email"] = _short_hash(sub)
            self._client.identify(distinct_id=uid, properties=person_props)
        except Exception:
            pass

    def capture(self, event: str, properties: dict[str, Any] | None = None) -> None:
        if not self.enabled or self._client is None:
            return
        props: dict[str, Any] = {"sdk_lang": SDK_LANG, "sdk_version": SDK_VERSION}
        if properties:
            props.update(properties)
        try:
            self._client.capture(
                distinct_id=self.distinct_id,
                event=event,
                properties=props,
            )
        except Exception:
            pass

    def shutdown(self) -> None:
        if not self.enabled or self._client is None:
            return
        try:
            self._client.shutdown()
        except Exception:
            pass

    def _alias(self, previous_id: str, distinct_id: str) -> None:
        if self._client is None:
            return
        try:
            self._client.alias(previous_id=previous_id, distinct_id=distinct_id)
        except Exception:
            pass
