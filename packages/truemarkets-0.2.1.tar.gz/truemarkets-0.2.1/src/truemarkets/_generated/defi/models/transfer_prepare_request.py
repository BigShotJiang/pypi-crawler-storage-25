from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.transfer_prepare_request_qty_unit import TransferPrepareRequestQtyUnit






T = TypeVar("T", bound="TransferPrepareRequest")



@_attrs_define
class TransferPrepareRequest:
    """ 
        Attributes:
            chain (str): Blockchain chain (e.g., solana, base)
            asset (str): Asset contract address
            to (str): Recipient address
            qty (str): Transfer quantity
            qty_unit (TransferPrepareRequestQtyUnit): Unit of quantity (base for token amount, quote for USD)
     """

    chain: str
    asset: str
    to: str
    qty: str
    qty_unit: TransferPrepareRequestQtyUnit
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        chain = self.chain

        asset = self.asset

        to = self.to

        qty = self.qty

        qty_unit = self.qty_unit.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "chain": chain,
            "asset": asset,
            "to": to,
            "qty": qty,
            "qty_unit": qty_unit,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        chain = d.pop("chain")

        asset = d.pop("asset")

        to = d.pop("to")

        qty = d.pop("qty")

        qty_unit = TransferPrepareRequestQtyUnit(d.pop("qty_unit"))




        transfer_prepare_request = cls(
            chain=chain,
            asset=asset,
            to=to,
            qty=qty,
            qty_unit=qty_unit,
        )


        transfer_prepare_request.additional_properties = d
        return transfer_prepare_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
