from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="TradeResponse")



@_attrs_define
class TradeResponse:
    """ Synchronous trade response with order ID, transaction hash, and execution amounts

        Attributes:
            order_id (UUID | Unset): The created order ID
            tx_hash (str | Unset): The blockchain transaction hash
            executed_qty (str | Unset): Base-asset quantity filled, as a decimal string. "0" when execution amounts are not
                available at trade time (e.g. Hypercore orders awaiting reconciliation).
            leaves_qty (str | Unset): Base-asset quantity remaining unfilled, as a decimal string. "0" when execution
                amounts are not available at trade time.
            executed_vwap (str | Unset): Volume-weighted execution price, as a decimal string. "0" when execution amounts
                are not available at trade time.
            fee (str | Unset): Fee charged for the trade, as a decimal string.
     """

    order_id: UUID | Unset = UNSET
    tx_hash: str | Unset = UNSET
    executed_qty: str | Unset = UNSET
    leaves_qty: str | Unset = UNSET
    executed_vwap: str | Unset = UNSET
    fee: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        order_id: str | Unset = UNSET
        if not isinstance(self.order_id, Unset):
            order_id = str(self.order_id)

        tx_hash = self.tx_hash

        executed_qty = self.executed_qty

        leaves_qty = self.leaves_qty

        executed_vwap = self.executed_vwap

        fee = self.fee


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if order_id is not UNSET:
            field_dict["order_id"] = order_id
        if tx_hash is not UNSET:
            field_dict["tx_hash"] = tx_hash
        if executed_qty is not UNSET:
            field_dict["executed_qty"] = executed_qty
        if leaves_qty is not UNSET:
            field_dict["leaves_qty"] = leaves_qty
        if executed_vwap is not UNSET:
            field_dict["executed_vwap"] = executed_vwap
        if fee is not UNSET:
            field_dict["fee"] = fee

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _order_id = d.pop("order_id", UNSET)
        order_id: UUID | Unset
        if isinstance(_order_id,  Unset):
            order_id = UNSET
        else:
            order_id = UUID(_order_id)




        tx_hash = d.pop("tx_hash", UNSET)

        executed_qty = d.pop("executed_qty", UNSET)

        leaves_qty = d.pop("leaves_qty", UNSET)

        executed_vwap = d.pop("executed_vwap", UNSET)

        fee = d.pop("fee", UNSET)

        trade_response = cls(
            order_id=order_id,
            tx_hash=tx_hash,
            executed_qty=executed_qty,
            leaves_qty=leaves_qty,
            executed_vwap=executed_vwap,
            fee=fee,
        )


        trade_response.additional_properties = d
        return trade_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
