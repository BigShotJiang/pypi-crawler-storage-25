from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.ramp_detail_response_direction import RampDetailResponseDirection
from ..models.ramp_detail_response_provider import RampDetailResponseProvider
from ..models.ramp_detail_response_status import RampDetailResponseStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="RampDetailResponse")



@_attrs_define
class RampDetailResponse:
    """ Ramp transaction details and status

        Attributes:
            id (str | Unset): Ramp transaction UUID
            provider (RampDetailResponseProvider | Unset): Ramp provider
            direction (RampDetailResponseDirection | Unset): Direction of the ramp transaction
            status (RampDetailResponseStatus | Unset): Current lifecycle status of the ramp transaction
            fiat_currency (str | Unset): Fiat currency code (e.g., USD)
            fiat_amount (str | Unset): Fiat amount
            asset_symbol (str | Unset): Crypto asset symbol or address
            asset_amount (None | str | Unset): Crypto amount received or sent
            fee_amount (None | str | Unset): Fee amount
            fee_currency (None | str | Unset): Fee currency code
            exchange_rate (None | str | Unset): Exchange rate used for the transaction
            tx_hash (None | str | Unset): Blockchain transaction hash
            provider_wallet_address (None | str | Unset): Provider wallet address for offramp transfers
            created_at (datetime.datetime | Unset): Creation timestamp
            completed_at (datetime.datetime | None | Unset): Completion timestamp
     """

    id: str | Unset = UNSET
    provider: RampDetailResponseProvider | Unset = UNSET
    direction: RampDetailResponseDirection | Unset = UNSET
    status: RampDetailResponseStatus | Unset = UNSET
    fiat_currency: str | Unset = UNSET
    fiat_amount: str | Unset = UNSET
    asset_symbol: str | Unset = UNSET
    asset_amount: None | str | Unset = UNSET
    fee_amount: None | str | Unset = UNSET
    fee_currency: None | str | Unset = UNSET
    exchange_rate: None | str | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    provider_wallet_address: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        provider: str | Unset = UNSET
        if not isinstance(self.provider, Unset):
            provider = self.provider.value


        direction: str | Unset = UNSET
        if not isinstance(self.direction, Unset):
            direction = self.direction.value


        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        fiat_currency = self.fiat_currency

        fiat_amount = self.fiat_amount

        asset_symbol = self.asset_symbol

        asset_amount: None | str | Unset
        if isinstance(self.asset_amount, Unset):
            asset_amount = UNSET
        else:
            asset_amount = self.asset_amount

        fee_amount: None | str | Unset
        if isinstance(self.fee_amount, Unset):
            fee_amount = UNSET
        else:
            fee_amount = self.fee_amount

        fee_currency: None | str | Unset
        if isinstance(self.fee_currency, Unset):
            fee_currency = UNSET
        else:
            fee_currency = self.fee_currency

        exchange_rate: None | str | Unset
        if isinstance(self.exchange_rate, Unset):
            exchange_rate = UNSET
        else:
            exchange_rate = self.exchange_rate

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        provider_wallet_address: None | str | Unset
        if isinstance(self.provider_wallet_address, Unset):
            provider_wallet_address = UNSET
        else:
            provider_wallet_address = self.provider_wallet_address

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if provider is not UNSET:
            field_dict["provider"] = provider
        if direction is not UNSET:
            field_dict["direction"] = direction
        if status is not UNSET:
            field_dict["status"] = status
        if fiat_currency is not UNSET:
            field_dict["fiat_currency"] = fiat_currency
        if fiat_amount is not UNSET:
            field_dict["fiat_amount"] = fiat_amount
        if asset_symbol is not UNSET:
            field_dict["asset_symbol"] = asset_symbol
        if asset_amount is not UNSET:
            field_dict["asset_amount"] = asset_amount
        if fee_amount is not UNSET:
            field_dict["fee_amount"] = fee_amount
        if fee_currency is not UNSET:
            field_dict["fee_currency"] = fee_currency
        if exchange_rate is not UNSET:
            field_dict["exchange_rate"] = exchange_rate
        if tx_hash is not UNSET:
            field_dict["tx_hash"] = tx_hash
        if provider_wallet_address is not UNSET:
            field_dict["provider_wallet_address"] = provider_wallet_address
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _provider = d.pop("provider", UNSET)
        provider: RampDetailResponseProvider | Unset
        if isinstance(_provider,  Unset):
            provider = UNSET
        else:
            provider = RampDetailResponseProvider(_provider)




        _direction = d.pop("direction", UNSET)
        direction: RampDetailResponseDirection | Unset
        if isinstance(_direction,  Unset):
            direction = UNSET
        else:
            direction = RampDetailResponseDirection(_direction)




        _status = d.pop("status", UNSET)
        status: RampDetailResponseStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = RampDetailResponseStatus(_status)




        fiat_currency = d.pop("fiat_currency", UNSET)

        fiat_amount = d.pop("fiat_amount", UNSET)

        asset_symbol = d.pop("asset_symbol", UNSET)

        def _parse_asset_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        asset_amount = _parse_asset_amount(d.pop("asset_amount", UNSET))


        def _parse_fee_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fee_amount = _parse_fee_amount(d.pop("fee_amount", UNSET))


        def _parse_fee_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fee_currency = _parse_fee_currency(d.pop("fee_currency", UNSET))


        def _parse_exchange_rate(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange_rate = _parse_exchange_rate(d.pop("exchange_rate", UNSET))


        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("tx_hash", UNSET))


        def _parse_provider_wallet_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_wallet_address = _parse_provider_wallet_address(d.pop("provider_wallet_address", UNSET))


        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)



                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))


        ramp_detail_response = cls(
            id=id,
            provider=provider,
            direction=direction,
            status=status,
            fiat_currency=fiat_currency,
            fiat_amount=fiat_amount,
            asset_symbol=asset_symbol,
            asset_amount=asset_amount,
            fee_amount=fee_amount,
            fee_currency=fee_currency,
            exchange_rate=exchange_rate,
            tx_hash=tx_hash,
            provider_wallet_address=provider_wallet_address,
            created_at=created_at,
            completed_at=completed_at,
        )


        ramp_detail_response.additional_properties = d
        return ramp_detail_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
