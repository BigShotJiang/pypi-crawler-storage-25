from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateWalletRequest")



@_attrs_define
class CreateWalletRequest:
    """ Request to create a wallet. Either WebAuthn fields (for passkey wallets) or publicKey (for API key wallets) must be
    provided.

        Attributes:
            challenge (str | Unset): WebAuthn challenge string (required for passkey wallets)
            credential_id (str | Unset): WebAuthn credential ID (required for passkey wallets)
            client_data (str | Unset): WebAuthn client data JSON (required for passkey wallets)
            attestation (str | Unset): WebAuthn attestation object (required for passkey wallets)
            public_key (str | Unset): API key public key in Turnkey format (required for API key wallets)
     """

    challenge: str | Unset = UNSET
    credential_id: str | Unset = UNSET
    client_data: str | Unset = UNSET
    attestation: str | Unset = UNSET
    public_key: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        challenge = self.challenge

        credential_id = self.credential_id

        client_data = self.client_data

        attestation = self.attestation

        public_key = self.public_key


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if challenge is not UNSET:
            field_dict["challenge"] = challenge
        if credential_id is not UNSET:
            field_dict["credential_id"] = credential_id
        if client_data is not UNSET:
            field_dict["client_data"] = client_data
        if attestation is not UNSET:
            field_dict["attestation"] = attestation
        if public_key is not UNSET:
            field_dict["public_key"] = public_key

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        challenge = d.pop("challenge", UNSET)

        credential_id = d.pop("credential_id", UNSET)

        client_data = d.pop("client_data", UNSET)

        attestation = d.pop("attestation", UNSET)

        public_key = d.pop("public_key", UNSET)

        create_wallet_request = cls(
            challenge=challenge,
            credential_id=credential_id,
            client_data=client_data,
            attestation=attestation,
            public_key=public_key,
        )


        create_wallet_request.additional_properties = d
        return create_wallet_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
