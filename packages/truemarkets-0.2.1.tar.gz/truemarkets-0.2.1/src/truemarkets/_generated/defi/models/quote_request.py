from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.quote_request_order_side import QuoteRequestOrderSide
from ..models.quote_request_order_type import QuoteRequestOrderType
from ..models.quote_request_qty_unit import QuoteRequestQtyUnit
from ..types import UNSET, Unset






T = TypeVar("T", bound="QuoteRequest")



@_attrs_define
class QuoteRequest:
    """ 
        Attributes:
            chain (str):
            base_asset (str):
            order_side (QuoteRequestOrderSide):
            qty (str):
            quote_asset (str | Unset): Optional. Defaults to the chain's configured quote asset. When provided, must match
                the chain's configured quote asset.
            qty_unit (QuoteRequestQtyUnit | Unset): Unit of `qty`. `base` means token amount, `quote` means USDC amount.
                Hypercore only accepts `base`. Defaults to `base` for Hypercore, `quote` for buy on AMM chains, `base` for sell.
            order_type (QuoteRequestOrderType | Unset): Order type. `market` (default) uses IOC for Hypercore and an AMM-
                priced execution on Solana/Base. `limit` is Hypercore-only today and requires `limit_price`.
            limit_price (str | Unset): Limit price in quote currency (USDC) per 1 base unit. Required when
                `order_type=limit`.
     """

    chain: str
    base_asset: str
    order_side: QuoteRequestOrderSide
    qty: str
    quote_asset: str | Unset = UNSET
    qty_unit: QuoteRequestQtyUnit | Unset = UNSET
    order_type: QuoteRequestOrderType | Unset = UNSET
    limit_price: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        chain = self.chain

        base_asset = self.base_asset

        order_side = self.order_side.value

        qty = self.qty

        quote_asset = self.quote_asset

        qty_unit: str | Unset = UNSET
        if not isinstance(self.qty_unit, Unset):
            qty_unit = self.qty_unit.value


        order_type: str | Unset = UNSET
        if not isinstance(self.order_type, Unset):
            order_type = self.order_type.value


        limit_price = self.limit_price


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "chain": chain,
            "base_asset": base_asset,
            "order_side": order_side,
            "qty": qty,
        })
        if quote_asset is not UNSET:
            field_dict["quote_asset"] = quote_asset
        if qty_unit is not UNSET:
            field_dict["qty_unit"] = qty_unit
        if order_type is not UNSET:
            field_dict["order_type"] = order_type
        if limit_price is not UNSET:
            field_dict["limit_price"] = limit_price

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        chain = d.pop("chain")

        base_asset = d.pop("base_asset")

        order_side = QuoteRequestOrderSide(d.pop("order_side"))




        qty = d.pop("qty")

        quote_asset = d.pop("quote_asset", UNSET)

        _qty_unit = d.pop("qty_unit", UNSET)
        qty_unit: QuoteRequestQtyUnit | Unset
        if isinstance(_qty_unit,  Unset):
            qty_unit = UNSET
        else:
            qty_unit = QuoteRequestQtyUnit(_qty_unit)




        _order_type = d.pop("order_type", UNSET)
        order_type: QuoteRequestOrderType | Unset
        if isinstance(_order_type,  Unset):
            order_type = UNSET
        else:
            order_type = QuoteRequestOrderType(_order_type)




        limit_price = d.pop("limit_price", UNSET)

        quote_request = cls(
            chain=chain,
            base_asset=base_asset,
            order_side=order_side,
            qty=qty,
            quote_asset=quote_asset,
            qty_unit=qty_unit,
            order_type=order_type,
            limit_price=limit_price,
        )


        quote_request.additional_properties = d
        return quote_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
