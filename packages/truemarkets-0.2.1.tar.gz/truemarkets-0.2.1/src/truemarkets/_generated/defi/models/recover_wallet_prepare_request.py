from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="RecoverWalletPrepareRequest")



@_attrs_define
class RecoverWalletPrepareRequest:
    """ Request to prepare wallet recovery

        Attributes:
            recovery_id (str): Recovery attempt ID
            challenge (str): WebAuthn challenge
            attestation (str): WebAuthn attestation object
            credential_id (str | Unset): WebAuthn credential ID
            client_data (str | Unset): WebAuthn client data JSON
     """

    recovery_id: str
    challenge: str
    attestation: str
    credential_id: str | Unset = UNSET
    client_data: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        recovery_id = self.recovery_id

        challenge = self.challenge

        attestation = self.attestation

        credential_id = self.credential_id

        client_data = self.client_data


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "recovery_id": recovery_id,
            "challenge": challenge,
            "attestation": attestation,
        })
        if credential_id is not UNSET:
            field_dict["credential_id"] = credential_id
        if client_data is not UNSET:
            field_dict["client_data"] = client_data

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        recovery_id = d.pop("recovery_id")

        challenge = d.pop("challenge")

        attestation = d.pop("attestation")

        credential_id = d.pop("credential_id", UNSET)

        client_data = d.pop("client_data", UNSET)

        recover_wallet_prepare_request = cls(
            recovery_id=recovery_id,
            challenge=challenge,
            attestation=attestation,
            credential_id=credential_id,
            client_data=client_data,
        )


        recover_wallet_prepare_request.additional_properties = d
        return recover_wallet_prepare_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
