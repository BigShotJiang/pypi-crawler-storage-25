from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateWalletOTPResponse")



@_attrs_define
class CreateWalletOTPResponse:
    """ Response from initiating wallet recovery OTP

        Attributes:
            recovery_id (str | Unset): Unique identifier for the recovery attempt
     """

    recovery_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        recovery_id = self.recovery_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if recovery_id is not UNSET:
            field_dict["recovery_id"] = recovery_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        recovery_id = d.pop("recovery_id", UNSET)

        create_wallet_otp_response = cls(
            recovery_id=recovery_id,
        )


        create_wallet_otp_response.additional_properties = d
        return create_wallet_otp_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
