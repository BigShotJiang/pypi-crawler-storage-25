from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.unsigned_payload import UnsignedPayload





T = TypeVar("T", bound="TransferPrepareResponse")



@_attrs_define
class TransferPrepareResponse:
    """ 
        Attributes:
            transfer_id (UUID | Unset):
            payloads (list[UnsignedPayload] | Unset):
     """

    transfer_id: UUID | Unset = UNSET
    payloads: list[UnsignedPayload] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.unsigned_payload import UnsignedPayload
        transfer_id: str | Unset = UNSET
        if not isinstance(self.transfer_id, Unset):
            transfer_id = str(self.transfer_id)

        payloads: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.payloads, Unset):
            payloads = []
            for payloads_item_data in self.payloads:
                payloads_item = payloads_item_data.to_dict()
                payloads.append(payloads_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if transfer_id is not UNSET:
            field_dict["transfer_id"] = transfer_id
        if payloads is not UNSET:
            field_dict["payloads"] = payloads

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unsigned_payload import UnsignedPayload
        d = dict(src_dict)
        _transfer_id = d.pop("transfer_id", UNSET)
        transfer_id: UUID | Unset
        if isinstance(_transfer_id,  Unset):
            transfer_id = UNSET
        else:
            transfer_id = UUID(_transfer_id)




        _payloads = d.pop("payloads", UNSET)
        payloads: list[UnsignedPayload] | Unset = UNSET
        if _payloads is not UNSET:
            payloads = []
            for payloads_item_data in _payloads:
                payloads_item = UnsignedPayload.from_dict(payloads_item_data)



                payloads.append(payloads_item)


        transfer_prepare_response = cls(
            transfer_id=transfer_id,
            payloads=payloads,
        )


        transfer_prepare_response.additional_properties = d
        return transfer_prepare_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
