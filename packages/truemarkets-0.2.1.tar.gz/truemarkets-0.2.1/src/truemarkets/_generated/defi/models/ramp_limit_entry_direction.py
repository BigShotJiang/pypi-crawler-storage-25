from enum import Enum

class RampLimitEntryDirection(str, Enum):
    OFFRAMP = "offramp"
    ONRAMP = "onramp"

    def __str__(self) -> str:
        return str(self.value)
