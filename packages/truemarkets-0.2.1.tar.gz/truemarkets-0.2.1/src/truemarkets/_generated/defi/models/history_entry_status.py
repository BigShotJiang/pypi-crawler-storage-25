from enum import Enum

class HistoryEntryStatus(str, Enum):
    APPROVED = "APPROVED"
    CANCELLED = "CANCELLED"
    CREATED = "CREATED"
    FAILED = "FAILED"
    IN_PROGRESS = "IN_PROGRESS"
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    SUCCESS = "SUCCESS"

    def __str__(self) -> str:
        return str(self.value)
