from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="ExportWalletPrepareRequest")



@_attrs_define
class ExportWalletPrepareRequest:
    """ 
        Attributes:
            address (str): Wallet address to export
            target_public_key (str | Unset): Client-side public key that will receive the encrypted bundle
     """

    address: str
    target_public_key: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        address = self.address

        target_public_key = self.target_public_key


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "address": address,
        })
        if target_public_key is not UNSET:
            field_dict["target_public_key"] = target_public_key

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        target_public_key = d.pop("target_public_key", UNSET)

        export_wallet_prepare_request = cls(
            address=address,
            target_public_key=target_public_key,
        )


        export_wallet_prepare_request.additional_properties = d
        return export_wallet_prepare_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
