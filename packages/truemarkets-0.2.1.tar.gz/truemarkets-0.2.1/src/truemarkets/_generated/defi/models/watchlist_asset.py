from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.asset import Asset





T = TypeVar("T", bound="WatchlistAsset")



@_attrs_define
class WatchlistAsset:
    """ 
        Attributes:
            id (UUID | Unset): Unique identifier for the watchlist asset entry
            watchlist_id (UUID | Unset): ID of the watchlist this asset belongs to
            asset_id (UUID | Unset): ID of the asset
            highlighted (bool | Unset): Whether this asset is highlighted in the watchlist
            asset (Asset | Unset): Asset response for V1 API (2026-01-14), snake_case, full metadata
     """

    id: UUID | Unset = UNSET
    watchlist_id: UUID | Unset = UNSET
    asset_id: UUID | Unset = UNSET
    highlighted: bool | Unset = UNSET
    asset: Asset | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.asset import Asset
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        watchlist_id: str | Unset = UNSET
        if not isinstance(self.watchlist_id, Unset):
            watchlist_id = str(self.watchlist_id)

        asset_id: str | Unset = UNSET
        if not isinstance(self.asset_id, Unset):
            asset_id = str(self.asset_id)

        highlighted = self.highlighted

        asset: dict[str, Any] | Unset = UNSET
        if not isinstance(self.asset, Unset):
            asset = self.asset.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if watchlist_id is not UNSET:
            field_dict["watchlist_id"] = watchlist_id
        if asset_id is not UNSET:
            field_dict["asset_id"] = asset_id
        if highlighted is not UNSET:
            field_dict["highlighted"] = highlighted
        if asset is not UNSET:
            field_dict["asset"] = asset

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset import Asset
        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        _watchlist_id = d.pop("watchlist_id", UNSET)
        watchlist_id: UUID | Unset
        if isinstance(_watchlist_id,  Unset):
            watchlist_id = UNSET
        else:
            watchlist_id = UUID(_watchlist_id)




        _asset_id = d.pop("asset_id", UNSET)
        asset_id: UUID | Unset
        if isinstance(_asset_id,  Unset):
            asset_id = UNSET
        else:
            asset_id = UUID(_asset_id)




        highlighted = d.pop("highlighted", UNSET)

        _asset = d.pop("asset", UNSET)
        asset: Asset | Unset
        if isinstance(_asset,  Unset):
            asset = UNSET
        else:
            asset = Asset.from_dict(_asset)




        watchlist_asset = cls(
            id=id,
            watchlist_id=watchlist_id,
            asset_id=asset_id,
            highlighted=highlighted,
            asset=asset,
        )


        watchlist_asset.additional_properties = d
        return watchlist_asset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
