from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.ramp_limit_entry_direction import RampLimitEntryDirection






T = TypeVar("T", bound="RampLimitEntry")



@_attrs_define
class RampLimitEntry:
    """ Amount limits for a provider and ramp direction

        Attributes:
            provider (str): Ramp provider name Example: paypal.
            direction (RampLimitEntryDirection): Ramp direction Example: onramp.
            min_amount (str): Minimum amount in fiat currency Example: 5.00.
            max_amount (str): Maximum amount in fiat currency Example: 10000.00.
     """

    provider: str
    direction: RampLimitEntryDirection
    min_amount: str
    max_amount: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        provider = self.provider

        direction = self.direction.value

        min_amount = self.min_amount

        max_amount = self.max_amount


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "provider": provider,
            "direction": direction,
            "min_amount": min_amount,
            "max_amount": max_amount,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        provider = d.pop("provider")

        direction = RampLimitEntryDirection(d.pop("direction"))




        min_amount = d.pop("min_amount")

        max_amount = d.pop("max_amount")

        ramp_limit_entry = cls(
            provider=provider,
            direction=direction,
            min_amount=min_amount,
            max_amount=max_amount,
        )


        ramp_limit_entry.additional_properties = d
        return ramp_limit_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
