from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.trade_request_auth_type import TradeRequestAuthType
from typing import cast






T = TypeVar("T", bound="TradeRequest")



@_attrs_define
class TradeRequest:
    """ Trade request for v2 API. Follows the same pattern as transfer/execute - only signatures required, payloads are
    cached server-side.

        Attributes:
            quote_id (str): The quote ID returned from the quote endpoint
            signatures (list[str]): Signatures for the payloads returned from the quote endpoint (in order)
            auth_type (TradeRequestAuthType): The authentication type used for signing
     """

    quote_id: str
    signatures: list[str]
    auth_type: TradeRequestAuthType
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        quote_id = self.quote_id

        signatures = self.signatures



        auth_type = self.auth_type.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "quote_id": quote_id,
            "signatures": signatures,
            "auth_type": auth_type,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        quote_id = d.pop("quote_id")

        signatures = cast(list[str], d.pop("signatures"))


        auth_type = TradeRequestAuthType(d.pop("auth_type"))




        trade_request = cls(
            quote_id=quote_id,
            signatures=signatures,
            auth_type=auth_type,
        )


        trade_request.additional_properties = d
        return trade_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
