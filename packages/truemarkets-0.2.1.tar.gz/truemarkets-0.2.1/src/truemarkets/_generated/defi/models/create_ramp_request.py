from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_ramp_request_direction import CreateRampRequestDirection
from ..models.create_ramp_request_provider import CreateRampRequestProvider
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateRampRequest")



@_attrs_define
class CreateRampRequest:
    """ Request to create a ramp transaction

        Attributes:
            provider (CreateRampRequestProvider): Ramp provider
            direction (CreateRampRequestDirection): Direction of the ramp transaction
            amount (str): Fiat amount as a numeric string
            payment_method (None | str | Unset): Optional payment method identifier
     """

    provider: CreateRampRequestProvider
    direction: CreateRampRequestDirection
    amount: str
    payment_method: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        provider = self.provider.value

        direction = self.direction.value

        amount = self.amount

        payment_method: None | str | Unset
        if isinstance(self.payment_method, Unset):
            payment_method = UNSET
        else:
            payment_method = self.payment_method


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "provider": provider,
            "direction": direction,
            "amount": amount,
        })
        if payment_method is not UNSET:
            field_dict["payment_method"] = payment_method

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        provider = CreateRampRequestProvider(d.pop("provider"))




        direction = CreateRampRequestDirection(d.pop("direction"))




        amount = d.pop("amount")

        def _parse_payment_method(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payment_method = _parse_payment_method(d.pop("payment_method", UNSET))


        create_ramp_request = cls(
            provider=provider,
            direction=direction,
            amount=amount,
            payment_method=payment_method,
        )


        create_ramp_request.additional_properties = d
        return create_ramp_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
