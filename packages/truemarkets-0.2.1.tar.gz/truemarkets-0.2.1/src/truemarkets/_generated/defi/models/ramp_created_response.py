from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="RampCreatedResponse")



@_attrs_define
class RampCreatedResponse:
    """ Response from creating a ramp transaction

        Attributes:
            id (str | Unset): Ramp transaction ID
            redirect_url (str | Unset): URL to redirect the user to complete the ramp
     """

    id: str | Unset = UNSET
    redirect_url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        redirect_url = self.redirect_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if redirect_url is not UNSET:
            field_dict["redirect_url"] = redirect_url

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        redirect_url = d.pop("redirect_url", UNSET)

        ramp_created_response = cls(
            id=id,
            redirect_url=redirect_url,
        )


        ramp_created_response.additional_properties = d
        return ramp_created_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
