from enum import Enum

class RampDetailResponseStatus(str, Enum):
    COMPLETED = "completed"
    CREATED = "created"
    EXPIRED = "expired"
    FAILED = "failed"
    PENDING = "pending"

    def __str__(self) -> str:
        return str(self.value)
