from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.cancel_order_execute_request_auth_type import CancelOrderExecuteRequestAuthType
from typing import cast






T = TypeVar("T", bound="CancelOrderExecuteRequest")



@_attrs_define
class CancelOrderExecuteRequest:
    """ 
        Attributes:
            signatures (list[str]):
            auth_type (CancelOrderExecuteRequestAuthType):
     """

    signatures: list[str]
    auth_type: CancelOrderExecuteRequestAuthType
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        signatures = self.signatures



        auth_type = self.auth_type.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "signatures": signatures,
            "auth_type": auth_type,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        signatures = cast(list[str], d.pop("signatures"))


        auth_type = CancelOrderExecuteRequestAuthType(d.pop("auth_type"))




        cancel_order_execute_request = cls(
            signatures=signatures,
            auth_type=auth_type,
        )


        cancel_order_execute_request.additional_properties = d
        return cancel_order_execute_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
