from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="RecoverWalletPrepareResponse")



@_attrs_define
class RecoverWalletPrepareResponse:
    """ Response from preparing wallet recovery

        Attributes:
            web_authn_payload (str | Unset): Payload to be signed with WebAuthn
     """

    web_authn_payload: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        web_authn_payload = self.web_authn_payload


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if web_authn_payload is not UNSET:
            field_dict["web_authn_payload"] = web_authn_payload

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        web_authn_payload = d.pop("web_authn_payload", UNSET)

        recover_wallet_prepare_response = cls(
            web_authn_payload=web_authn_payload,
        )


        recover_wallet_prepare_response.additional_properties = d
        return recover_wallet_prepare_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
