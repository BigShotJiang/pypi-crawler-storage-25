from enum import Enum

class RampTransferExecuteRequestAuthType(str, Enum):
    API_KEY = "api_key"
    WEB_AUTHN = "web_authn"

    def __str__(self) -> str:
        return str(self.value)
