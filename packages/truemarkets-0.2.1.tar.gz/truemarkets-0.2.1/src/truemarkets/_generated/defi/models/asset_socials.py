from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="AssetSocials")



@_attrs_define
class AssetSocials:
    """ 
        Attributes:
            x_username (str | Unset):
            facebook_username (str | Unset):
            subreddit_url (str | Unset):
            official_forum_url (str | Unset):
     """

    x_username: str | Unset = UNSET
    facebook_username: str | Unset = UNSET
    subreddit_url: str | Unset = UNSET
    official_forum_url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        x_username = self.x_username

        facebook_username = self.facebook_username

        subreddit_url = self.subreddit_url

        official_forum_url = self.official_forum_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if x_username is not UNSET:
            field_dict["x_username"] = x_username
        if facebook_username is not UNSET:
            field_dict["facebook_username"] = facebook_username
        if subreddit_url is not UNSET:
            field_dict["subreddit_url"] = subreddit_url
        if official_forum_url is not UNSET:
            field_dict["official_forum_url"] = official_forum_url

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        x_username = d.pop("x_username", UNSET)

        facebook_username = d.pop("facebook_username", UNSET)

        subreddit_url = d.pop("subreddit_url", UNSET)

        official_forum_url = d.pop("official_forum_url", UNSET)

        asset_socials = cls(
            x_username=x_username,
            facebook_username=facebook_username,
            subreddit_url=subreddit_url,
            official_forum_url=official_forum_url,
        )


        asset_socials.additional_properties = d
        return asset_socials

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
