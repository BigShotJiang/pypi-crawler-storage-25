from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.quote_issue import QuoteIssue
  from ..models.unsigned_payload import UnsignedPayload





T = TypeVar("T", bound="QuoteResponse")



@_attrs_define
class QuoteResponse:
    """ 
        Attributes:
            quote_id (str | Unset):
            base_asset (str | Unset):
            quote_asset (str | Unset):
            order_side (str | Unset):
            qty (str | Unset): Amount the user sends (quote asset for buys, base asset for sells).
            qty_out (str | Unset): Amount the user receives (base asset for buys, quote asset for sells).
            fee_asset (str | Unset):
            fee (str | Unset):
            payloads (list[UnsignedPayload] | Unset):
            issues (list[QuoteIssue] | Unset):
     """

    quote_id: str | Unset = UNSET
    base_asset: str | Unset = UNSET
    quote_asset: str | Unset = UNSET
    order_side: str | Unset = UNSET
    qty: str | Unset = UNSET
    qty_out: str | Unset = UNSET
    fee_asset: str | Unset = UNSET
    fee: str | Unset = UNSET
    payloads: list[UnsignedPayload] | Unset = UNSET
    issues: list[QuoteIssue] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.quote_issue import QuoteIssue
        from ..models.unsigned_payload import UnsignedPayload
        quote_id = self.quote_id

        base_asset = self.base_asset

        quote_asset = self.quote_asset

        order_side = self.order_side

        qty = self.qty

        qty_out = self.qty_out

        fee_asset = self.fee_asset

        fee = self.fee

        payloads: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.payloads, Unset):
            payloads = []
            for payloads_item_data in self.payloads:
                payloads_item = payloads_item_data.to_dict()
                payloads.append(payloads_item)



        issues: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.issues, Unset):
            issues = []
            for issues_item_data in self.issues:
                issues_item = issues_item_data.to_dict()
                issues.append(issues_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if quote_id is not UNSET:
            field_dict["quote_id"] = quote_id
        if base_asset is not UNSET:
            field_dict["base_asset"] = base_asset
        if quote_asset is not UNSET:
            field_dict["quote_asset"] = quote_asset
        if order_side is not UNSET:
            field_dict["order_side"] = order_side
        if qty is not UNSET:
            field_dict["qty"] = qty
        if qty_out is not UNSET:
            field_dict["qty_out"] = qty_out
        if fee_asset is not UNSET:
            field_dict["fee_asset"] = fee_asset
        if fee is not UNSET:
            field_dict["fee"] = fee
        if payloads is not UNSET:
            field_dict["payloads"] = payloads
        if issues is not UNSET:
            field_dict["issues"] = issues

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.quote_issue import QuoteIssue
        from ..models.unsigned_payload import UnsignedPayload
        d = dict(src_dict)
        quote_id = d.pop("quote_id", UNSET)

        base_asset = d.pop("base_asset", UNSET)

        quote_asset = d.pop("quote_asset", UNSET)

        order_side = d.pop("order_side", UNSET)

        qty = d.pop("qty", UNSET)

        qty_out = d.pop("qty_out", UNSET)

        fee_asset = d.pop("fee_asset", UNSET)

        fee = d.pop("fee", UNSET)

        _payloads = d.pop("payloads", UNSET)
        payloads: list[UnsignedPayload] | Unset = UNSET
        if _payloads is not UNSET:
            payloads = []
            for payloads_item_data in _payloads:
                payloads_item = UnsignedPayload.from_dict(payloads_item_data)



                payloads.append(payloads_item)


        _issues = d.pop("issues", UNSET)
        issues: list[QuoteIssue] | Unset = UNSET
        if _issues is not UNSET:
            issues = []
            for issues_item_data in _issues:
                issues_item = QuoteIssue.from_dict(issues_item_data)



                issues.append(issues_item)


        quote_response = cls(
            quote_id=quote_id,
            base_asset=base_asset,
            quote_asset=quote_asset,
            order_side=order_side,
            qty=qty,
            qty_out=qty_out,
            fee_asset=fee_asset,
            fee=fee,
            payloads=payloads,
            issues=issues,
        )


        quote_response.additional_properties = d
        return quote_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
