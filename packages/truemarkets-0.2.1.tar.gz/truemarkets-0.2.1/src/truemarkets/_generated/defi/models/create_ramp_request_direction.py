from enum import Enum

class CreateRampRequestDirection(str, Enum):
    OFFRAMP = "offramp"
    ONRAMP = "onramp"

    def __str__(self) -> str:
        return str(self.value)
