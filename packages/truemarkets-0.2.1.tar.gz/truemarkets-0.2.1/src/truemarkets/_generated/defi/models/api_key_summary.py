from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="APIKeySummary")



@_attrs_define
class APIKeySummary:
    """ 
        Attributes:
            api_key_id (str): Unique identifier for the API key
            api_key_name (str): Human-readable name for the API key
            public_key (str): The public key associated with this API key
            created_at (str): Unix timestamp in seconds of when the API key was created
            updated_at (str): Unix timestamp in seconds of when the API key was last updated
     """

    api_key_id: str
    api_key_name: str
    public_key: str
    created_at: str
    updated_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_key_id = self.api_key_id

        api_key_name = self.api_key_name

        public_key = self.public_key

        created_at = self.created_at

        updated_at = self.updated_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "api_key_id": api_key_id,
            "api_key_name": api_key_name,
            "public_key": public_key,
            "created_at": created_at,
            "updated_at": updated_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_key_id = d.pop("api_key_id")

        api_key_name = d.pop("api_key_name")

        public_key = d.pop("public_key")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        api_key_summary = cls(
            api_key_id=api_key_id,
            api_key_name=api_key_name,
            public_key=public_key,
            created_at=created_at,
            updated_at=updated_at,
        )


        api_key_summary.additional_properties = d
        return api_key_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
