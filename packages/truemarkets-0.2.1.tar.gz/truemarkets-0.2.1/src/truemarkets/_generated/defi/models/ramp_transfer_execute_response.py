from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="RampTransferExecuteResponse")



@_attrs_define
class RampTransferExecuteResponse:
    """ Response from executing a ramp transfer

        Attributes:
            tx_hash (str | Unset): Blockchain transaction hash
            chain (str | Unset): Blockchain network
            asset (str | Unset): Asset address
            from_ (str | Unset): Sender address
            to (str | Unset): Recipient address
            sent (str | Unset): Amount sent
            fee (str | Unset): Transaction fee
            received (str | Unset): Amount received
     """

    tx_hash: str | Unset = UNSET
    chain: str | Unset = UNSET
    asset: str | Unset = UNSET
    from_: str | Unset = UNSET
    to: str | Unset = UNSET
    sent: str | Unset = UNSET
    fee: str | Unset = UNSET
    received: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        tx_hash = self.tx_hash

        chain = self.chain

        asset = self.asset

        from_ = self.from_

        to = self.to

        sent = self.sent

        fee = self.fee

        received = self.received


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if tx_hash is not UNSET:
            field_dict["tx_hash"] = tx_hash
        if chain is not UNSET:
            field_dict["chain"] = chain
        if asset is not UNSET:
            field_dict["asset"] = asset
        if from_ is not UNSET:
            field_dict["from"] = from_
        if to is not UNSET:
            field_dict["to"] = to
        if sent is not UNSET:
            field_dict["sent"] = sent
        if fee is not UNSET:
            field_dict["fee"] = fee
        if received is not UNSET:
            field_dict["received"] = received

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tx_hash = d.pop("tx_hash", UNSET)

        chain = d.pop("chain", UNSET)

        asset = d.pop("asset", UNSET)

        from_ = d.pop("from", UNSET)

        to = d.pop("to", UNSET)

        sent = d.pop("sent", UNSET)

        fee = d.pop("fee", UNSET)

        received = d.pop("received", UNSET)

        ramp_transfer_execute_response = cls(
            tx_hash=tx_hash,
            chain=chain,
            asset=asset,
            from_=from_,
            to=to,
            sent=sent,
            fee=fee,
            received=received,
        )


        ramp_transfer_execute_response.additional_properties = d
        return ramp_transfer_execute_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
