from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.history_entry_action import HistoryEntryAction
from ..models.history_entry_status import HistoryEntryStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="HistoryEntry")



@_attrs_define
class HistoryEntry:
    """ History entry

        Attributes:
            id (str | Unset): Unique transaction identifier
            submitted_date (datetime.datetime | Unset): When the transaction was submitted
            settled_date (datetime.datetime | None | Unset): When the transaction was settled (if applicable)
            status (HistoryEntryStatus | Unset): Current status of the transaction
            errors (list[str] | None | Unset): Error messages if transaction failed
            tx_hash (None | str | Unset): Blockchain transaction hash
            amount (str | Unset): Transaction amount
            to_asset (str | Unset): Destination asset symbol
            action (HistoryEntryAction | Unset): Type of action performed
            from_asset (str | Unset): Source asset symbol
            sender (str | Unset): Sender address
            recipient (str | Unset): Recipient address
     """

    id: str | Unset = UNSET
    submitted_date: datetime.datetime | Unset = UNSET
    settled_date: datetime.datetime | None | Unset = UNSET
    status: HistoryEntryStatus | Unset = UNSET
    errors: list[str] | None | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    amount: str | Unset = UNSET
    to_asset: str | Unset = UNSET
    action: HistoryEntryAction | Unset = UNSET
    from_asset: str | Unset = UNSET
    sender: str | Unset = UNSET
    recipient: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        submitted_date: str | Unset = UNSET
        if not isinstance(self.submitted_date, Unset):
            submitted_date = self.submitted_date.isoformat()

        settled_date: None | str | Unset
        if isinstance(self.settled_date, Unset):
            settled_date = UNSET
        elif isinstance(self.settled_date, datetime.datetime):
            settled_date = self.settled_date.isoformat()
        else:
            settled_date = self.settled_date

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        errors: list[str] | None | Unset
        if isinstance(self.errors, Unset):
            errors = UNSET
        elif isinstance(self.errors, list):
            errors = self.errors


        else:
            errors = self.errors

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        amount = self.amount

        to_asset = self.to_asset

        action: str | Unset = UNSET
        if not isinstance(self.action, Unset):
            action = self.action.value


        from_asset = self.from_asset

        sender = self.sender

        recipient = self.recipient


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if submitted_date is not UNSET:
            field_dict["submitted_date"] = submitted_date
        if settled_date is not UNSET:
            field_dict["settled_date"] = settled_date
        if status is not UNSET:
            field_dict["status"] = status
        if errors is not UNSET:
            field_dict["errors"] = errors
        if tx_hash is not UNSET:
            field_dict["tx_hash"] = tx_hash
        if amount is not UNSET:
            field_dict["amount"] = amount
        if to_asset is not UNSET:
            field_dict["to_asset"] = to_asset
        if action is not UNSET:
            field_dict["action"] = action
        if from_asset is not UNSET:
            field_dict["from_asset"] = from_asset
        if sender is not UNSET:
            field_dict["sender"] = sender
        if recipient is not UNSET:
            field_dict["recipient"] = recipient

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _submitted_date = d.pop("submitted_date", UNSET)
        submitted_date: datetime.datetime | Unset
        if isinstance(_submitted_date,  Unset):
            submitted_date = UNSET
        else:
            submitted_date = isoparse(_submitted_date)




        def _parse_settled_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                settled_date_type_0 = isoparse(data)



                return settled_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        settled_date = _parse_settled_date(d.pop("settled_date", UNSET))


        _status = d.pop("status", UNSET)
        status: HistoryEntryStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = HistoryEntryStatus(_status)




        def _parse_errors(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                errors_type_0 = cast(list[str], data)

                return errors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        errors = _parse_errors(d.pop("errors", UNSET))


        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("tx_hash", UNSET))


        amount = d.pop("amount", UNSET)

        to_asset = d.pop("to_asset", UNSET)

        _action = d.pop("action", UNSET)
        action: HistoryEntryAction | Unset
        if isinstance(_action,  Unset):
            action = UNSET
        else:
            action = HistoryEntryAction(_action)




        from_asset = d.pop("from_asset", UNSET)

        sender = d.pop("sender", UNSET)

        recipient = d.pop("recipient", UNSET)

        history_entry = cls(
            id=id,
            submitted_date=submitted_date,
            settled_date=settled_date,
            status=status,
            errors=errors,
            tx_hash=tx_hash,
            amount=amount,
            to_asset=to_asset,
            action=action,
            from_asset=from_asset,
            sender=sender,
            recipient=recipient,
        )


        history_entry.additional_properties = d
        return history_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
