from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="Balance")



@_attrs_define
class Balance:
    """ Balance object API version (without slug, description, website)

        Attributes:
            id (UUID | Unset):
            chain (str | Unset):
            asset (str | Unset):
            symbol (str | Unset):
            name (str | Unset):
            decimals (int | Unset):
            icon (None | str | Unset):
            tradeable (bool | Unset):
            stable (bool | Unset):
            balance (str | Unset):
     """

    id: UUID | Unset = UNSET
    chain: str | Unset = UNSET
    asset: str | Unset = UNSET
    symbol: str | Unset = UNSET
    name: str | Unset = UNSET
    decimals: int | Unset = UNSET
    icon: None | str | Unset = UNSET
    tradeable: bool | Unset = UNSET
    stable: bool | Unset = UNSET
    balance: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        chain = self.chain

        asset = self.asset

        symbol = self.symbol

        name = self.name

        decimals = self.decimals

        icon: None | str | Unset
        if isinstance(self.icon, Unset):
            icon = UNSET
        else:
            icon = self.icon

        tradeable = self.tradeable

        stable = self.stable

        balance = self.balance


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if chain is not UNSET:
            field_dict["chain"] = chain
        if asset is not UNSET:
            field_dict["asset"] = asset
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if name is not UNSET:
            field_dict["name"] = name
        if decimals is not UNSET:
            field_dict["decimals"] = decimals
        if icon is not UNSET:
            field_dict["icon"] = icon
        if tradeable is not UNSET:
            field_dict["tradeable"] = tradeable
        if stable is not UNSET:
            field_dict["stable"] = stable
        if balance is not UNSET:
            field_dict["balance"] = balance

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        chain = d.pop("chain", UNSET)

        asset = d.pop("asset", UNSET)

        symbol = d.pop("symbol", UNSET)

        name = d.pop("name", UNSET)

        decimals = d.pop("decimals", UNSET)

        def _parse_icon(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon = _parse_icon(d.pop("icon", UNSET))


        tradeable = d.pop("tradeable", UNSET)

        stable = d.pop("stable", UNSET)

        balance = d.pop("balance", UNSET)

        balance = cls(
            id=id,
            chain=chain,
            asset=asset,
            symbol=symbol,
            name=name,
            decimals=decimals,
            icon=icon,
            tradeable=tradeable,
            stable=stable,
            balance=balance,
        )


        balance.additional_properties = d
        return balance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
