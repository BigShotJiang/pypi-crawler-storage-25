from enum import Enum

class RampDetailResponseDirection(str, Enum):
    OFFRAMP = "offramp"
    ONRAMP = "onramp"

    def __str__(self) -> str:
        return str(self.value)
