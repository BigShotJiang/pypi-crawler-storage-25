from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.asset_image import AssetImage
  from ..models.asset_market_data import AssetMarketData
  from ..models.asset_socials import AssetSocials





T = TypeVar("T", bound="Asset")



@_attrs_define
class Asset:
    """ Asset response for V1 API (2026-01-14), snake_case, full metadata

        Attributes:
            id (UUID | Unset):
            chain (str | Unset):
            address (str | Unset):
            symbol (str | Unset):
            name (str | Unset):
            slug (str | Unset):
            decimals (int | Unset):
            description (str | Unset):
            website (str | Unset):
            icon (None | str | Unset):
            is_active (bool | Unset):
            tradeable (bool | Unset):
            stable (bool | Unset):
            image (AssetImage | Unset):
            market_data (AssetMarketData | Unset):
            socials (AssetSocials | Unset):
     """

    id: UUID | Unset = UNSET
    chain: str | Unset = UNSET
    address: str | Unset = UNSET
    symbol: str | Unset = UNSET
    name: str | Unset = UNSET
    slug: str | Unset = UNSET
    decimals: int | Unset = UNSET
    description: str | Unset = UNSET
    website: str | Unset = UNSET
    icon: None | str | Unset = UNSET
    is_active: bool | Unset = UNSET
    tradeable: bool | Unset = UNSET
    stable: bool | Unset = UNSET
    image: AssetImage | Unset = UNSET
    market_data: AssetMarketData | Unset = UNSET
    socials: AssetSocials | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.asset_image import AssetImage
        from ..models.asset_market_data import AssetMarketData
        from ..models.asset_socials import AssetSocials
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        chain = self.chain

        address = self.address

        symbol = self.symbol

        name = self.name

        slug = self.slug

        decimals = self.decimals

        description = self.description

        website = self.website

        icon: None | str | Unset
        if isinstance(self.icon, Unset):
            icon = UNSET
        else:
            icon = self.icon

        is_active = self.is_active

        tradeable = self.tradeable

        stable = self.stable

        image: dict[str, Any] | Unset = UNSET
        if not isinstance(self.image, Unset):
            image = self.image.to_dict()

        market_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.market_data, Unset):
            market_data = self.market_data.to_dict()

        socials: dict[str, Any] | Unset = UNSET
        if not isinstance(self.socials, Unset):
            socials = self.socials.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if chain is not UNSET:
            field_dict["chain"] = chain
        if address is not UNSET:
            field_dict["address"] = address
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if name is not UNSET:
            field_dict["name"] = name
        if slug is not UNSET:
            field_dict["slug"] = slug
        if decimals is not UNSET:
            field_dict["decimals"] = decimals
        if description is not UNSET:
            field_dict["description"] = description
        if website is not UNSET:
            field_dict["website"] = website
        if icon is not UNSET:
            field_dict["icon"] = icon
        if is_active is not UNSET:
            field_dict["is_active"] = is_active
        if tradeable is not UNSET:
            field_dict["tradeable"] = tradeable
        if stable is not UNSET:
            field_dict["stable"] = stable
        if image is not UNSET:
            field_dict["image"] = image
        if market_data is not UNSET:
            field_dict["market_data"] = market_data
        if socials is not UNSET:
            field_dict["socials"] = socials

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset_image import AssetImage
        from ..models.asset_market_data import AssetMarketData
        from ..models.asset_socials import AssetSocials
        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        chain = d.pop("chain", UNSET)

        address = d.pop("address", UNSET)

        symbol = d.pop("symbol", UNSET)

        name = d.pop("name", UNSET)

        slug = d.pop("slug", UNSET)

        decimals = d.pop("decimals", UNSET)

        description = d.pop("description", UNSET)

        website = d.pop("website", UNSET)

        def _parse_icon(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon = _parse_icon(d.pop("icon", UNSET))


        is_active = d.pop("is_active", UNSET)

        tradeable = d.pop("tradeable", UNSET)

        stable = d.pop("stable", UNSET)

        _image = d.pop("image", UNSET)
        image: AssetImage | Unset
        if isinstance(_image,  Unset):
            image = UNSET
        else:
            image = AssetImage.from_dict(_image)




        _market_data = d.pop("market_data", UNSET)
        market_data: AssetMarketData | Unset
        if isinstance(_market_data,  Unset):
            market_data = UNSET
        else:
            market_data = AssetMarketData.from_dict(_market_data)




        _socials = d.pop("socials", UNSET)
        socials: AssetSocials | Unset
        if isinstance(_socials,  Unset):
            socials = UNSET
        else:
            socials = AssetSocials.from_dict(_socials)




        asset = cls(
            id=id,
            chain=chain,
            address=address,
            symbol=symbol,
            name=name,
            slug=slug,
            decimals=decimals,
            description=description,
            website=website,
            icon=icon,
            is_active=is_active,
            tradeable=tradeable,
            stable=stable,
            image=image,
            market_data=market_data,
            socials=socials,
        )


        asset.additional_properties = d
        return asset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
