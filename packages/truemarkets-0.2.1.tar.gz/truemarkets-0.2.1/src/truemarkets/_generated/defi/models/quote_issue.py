from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.balance_issue import BalanceIssue





T = TypeVar("T", bound="QuoteIssue")



@_attrs_define
class QuoteIssue:
    """ Structured issue in a quote response

        Attributes:
            message (str): Human-readable issue description
            balance (BalanceIssue | Unset): Balance details for an insufficient balance issue
     """

    message: str
    balance: BalanceIssue | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.balance_issue import BalanceIssue
        message = self.message

        balance: dict[str, Any] | Unset = UNSET
        if not isinstance(self.balance, Unset):
            balance = self.balance.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "message": message,
        })
        if balance is not UNSET:
            field_dict["balance"] = balance

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.balance_issue import BalanceIssue
        d = dict(src_dict)
        message = d.pop("message")

        _balance = d.pop("balance", UNSET)
        balance: BalanceIssue | Unset
        if isinstance(_balance,  Unset):
            balance = UNSET
        else:
            balance = BalanceIssue.from_dict(_balance)




        quote_issue = cls(
            message=message,
            balance=balance,
        )


        quote_issue.additional_properties = d
        return quote_issue

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
