from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="WalletCreatedResponseWalletsItem")



@_attrs_define
class WalletCreatedResponseWalletsItem:
    """ 
        Attributes:
            wallet_id (str | Unset): Turnkey wallet ID
            wallet_account_id (str | Unset): Turnkey wallet account ID
            address (str | Unset): Wallet address
            address_type (str | Unset): Blockchain type (e.g., SOLANA, EVM)
     """

    wallet_id: str | Unset = UNSET
    wallet_account_id: str | Unset = UNSET
    address: str | Unset = UNSET
    address_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        wallet_id = self.wallet_id

        wallet_account_id = self.wallet_account_id

        address = self.address

        address_type = self.address_type


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if wallet_id is not UNSET:
            field_dict["wallet_id"] = wallet_id
        if wallet_account_id is not UNSET:
            field_dict["wallet_account_id"] = wallet_account_id
        if address is not UNSET:
            field_dict["address"] = address
        if address_type is not UNSET:
            field_dict["address_type"] = address_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        wallet_id = d.pop("wallet_id", UNSET)

        wallet_account_id = d.pop("wallet_account_id", UNSET)

        address = d.pop("address", UNSET)

        address_type = d.pop("address_type", UNSET)

        wallet_created_response_wallets_item = cls(
            wallet_id=wallet_id,
            wallet_account_id=wallet_account_id,
            address=address,
            address_type=address_type,
        )


        wallet_created_response_wallets_item.additional_properties = d
        return wallet_created_response_wallets_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
