from enum import Enum

class HistoryEntryAction(str, Enum):
    BUY = "BUY"
    DEPOSIT = "DEPOSIT"
    RECEIVE = "RECEIVE"
    SELL = "SELL"
    SEND = "SEND"
    WITHDRAW = "WITHDRAW"

    def __str__(self) -> str:
        return str(self.value)
