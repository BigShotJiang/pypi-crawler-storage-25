from enum import Enum

class RampDetailResponseProvider(str, Enum):
    COINBASE = "coinbase"
    PAYPAL = "paypal"

    def __str__(self) -> str:
        return str(self.value)
