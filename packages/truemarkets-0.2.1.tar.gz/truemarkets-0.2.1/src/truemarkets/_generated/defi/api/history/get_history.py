from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.transaction_history_response import TransactionHistoryResponse
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime



def _get_kwargs(
    *,
    version: str | Unset = '2026-01-26',
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["version"] = version

    params["limit"] = limit

    json_cursor: str | Unset = UNSET
    if not isinstance(cursor, Unset):
        json_cursor = cursor.isoformat()
    params["cursor"] = json_cursor


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/core/history",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | TransactionHistoryResponse | None:
    if response.status_code == 200:
        response_200 = TransactionHistoryResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | TransactionHistoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,

) -> Response[ErrorResponse | TransactionHistoryResponse]:
    """ Get transaction history

     Returns a unified view of all user transactions including trades, transfers, and onramps

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransactionHistoryResponse]
     """


    kwargs = _get_kwargs(
        version=version,
limit=limit,
cursor=cursor,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,

) -> ErrorResponse | TransactionHistoryResponse | None:
    """ Get transaction history

     Returns a unified view of all user transactions including trades, transfers, and onramps

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransactionHistoryResponse
     """


    return sync_detailed(
        client=client,
version=version,
limit=limit,
cursor=cursor,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,

) -> Response[ErrorResponse | TransactionHistoryResponse]:
    """ Get transaction history

     Returns a unified view of all user transactions including trades, transfers, and onramps

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransactionHistoryResponse]
     """


    kwargs = _get_kwargs(
        version=version,
limit=limit,
cursor=cursor,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,

) -> ErrorResponse | TransactionHistoryResponse | None:
    """ Get transaction history

     Returns a unified view of all user transactions including trades, transfers, and onramps

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransactionHistoryResponse
     """


    return (await asyncio_detailed(
        client=client,
version=version,
limit=limit,
cursor=cursor,

    )).parsed
