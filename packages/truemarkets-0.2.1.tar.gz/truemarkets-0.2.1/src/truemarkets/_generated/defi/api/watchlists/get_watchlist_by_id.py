from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.watchlist_with_assets import WatchlistWithAssets
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    version: str | Unset = '2026-01-26',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/core/watchlists/{id}".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | WatchlistWithAssets | None:
    if response.status_code == 200:
        response_200 = WatchlistWithAssets.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | WatchlistWithAssets]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | WatchlistWithAssets]:
    """ Get watchlist by ID

     Returns a specific global/public watchlist with all its assets.

    Args:
        id (UUID):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | WatchlistWithAssets]
     """


    kwargs = _get_kwargs(
        id=id,
version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | WatchlistWithAssets | None:
    """ Get watchlist by ID

     Returns a specific global/public watchlist with all its assets.

    Args:
        id (UUID):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | WatchlistWithAssets
     """


    return sync_detailed(
        id=id,
client=client,
version=version,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | WatchlistWithAssets]:
    """ Get watchlist by ID

     Returns a specific global/public watchlist with all its assets.

    Args:
        id (UUID):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | WatchlistWithAssets]
     """


    kwargs = _get_kwargs(
        id=id,
version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | WatchlistWithAssets | None:
    """ Get watchlist by ID

     Returns a specific global/public watchlist with all its assets.

    Args:
        id (UUID):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | WatchlistWithAssets
     """


    return (await asyncio_detailed(
        id=id,
client=client,
version=version,

    )).parsed
