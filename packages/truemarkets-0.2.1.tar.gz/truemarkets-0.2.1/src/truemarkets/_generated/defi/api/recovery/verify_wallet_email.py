from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_wallet_otp_response import CreateWalletOTPResponse
from ...models.error_response import ErrorResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    version: str | Unset = '2026-01-26',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/defi/core/recovery/verify-wallet-email",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateWalletOTPResponse | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = CreateWalletOTPResponse.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateWalletOTPResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',

) -> Response[CreateWalletOTPResponse | ErrorResponse]:
    """ Initiate wallet recovery via email OTP

     Sends an OTP to the user's email to begin the wallet recovery process

    Args:
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWalletOTPResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',

) -> CreateWalletOTPResponse | ErrorResponse | None:
    """ Initiate wallet recovery via email OTP

     Sends an OTP to the user's email to begin the wallet recovery process

    Args:
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWalletOTPResponse | ErrorResponse
     """


    return sync_detailed(
        client=client,
version=version,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',

) -> Response[CreateWalletOTPResponse | ErrorResponse]:
    """ Initiate wallet recovery via email OTP

     Sends an OTP to the user's email to begin the wallet recovery process

    Args:
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWalletOTPResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    version: str | Unset = '2026-01-26',

) -> CreateWalletOTPResponse | ErrorResponse | None:
    """ Initiate wallet recovery via email OTP

     Sends an OTP to the user's email to begin the wallet recovery process

    Args:
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWalletOTPResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,
version=version,

    )).parsed
