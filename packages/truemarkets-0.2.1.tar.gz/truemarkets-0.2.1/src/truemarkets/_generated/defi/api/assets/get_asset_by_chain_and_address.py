from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.asset import Asset
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    chain: str,
    address: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/core/asset/{chain}/{address}".format(chain=quote(str(chain), safe=""),address=quote(str(address), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Asset | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = Asset.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Asset | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    chain: str,
    address: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[Asset | ErrorResponse]:
    """ Get asset by chain and address

    Args:
        chain (str):
        address (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Asset | ErrorResponse]
     """


    kwargs = _get_kwargs(
        chain=chain,
address=address,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    chain: str,
    address: str,
    *,
    client: AuthenticatedClient | Client,

) -> Asset | ErrorResponse | None:
    """ Get asset by chain and address

    Args:
        chain (str):
        address (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Asset | ErrorResponse
     """


    return sync_detailed(
        chain=chain,
address=address,
client=client,

    ).parsed

async def asyncio_detailed(
    chain: str,
    address: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[Asset | ErrorResponse]:
    """ Get asset by chain and address

    Args:
        chain (str):
        address (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Asset | ErrorResponse]
     """


    kwargs = _get_kwargs(
        chain=chain,
address=address,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    chain: str,
    address: str,
    *,
    client: AuthenticatedClient | Client,

) -> Asset | ErrorResponse | None:
    """ Get asset by chain and address

    Args:
        chain (str):
        address (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Asset | ErrorResponse
     """


    return (await asyncio_detailed(
        chain=chain,
address=address,
client=client,

    )).parsed
