from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.balance_response import BalanceResponse
from ...models.error_response import ErrorResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    owner: str,
    *,
    version: str | Unset = '2026-01-26',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/core/balances/{owner}".format(owner=quote(str(owner), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BalanceResponse | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = BalanceResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 422:
        response_422 = ErrorResponse.from_dict(response.json())



        return response_422

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BalanceResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    owner: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> Response[BalanceResponse | ErrorResponse]:
    """ Get balances for a specific wallet address

    Args:
        owner (str):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BalanceResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        owner=owner,
version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    owner: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> BalanceResponse | ErrorResponse | None:
    """ Get balances for a specific wallet address

    Args:
        owner (str):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BalanceResponse | ErrorResponse
     """


    return sync_detailed(
        owner=owner,
client=client,
version=version,

    ).parsed

async def asyncio_detailed(
    owner: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> Response[BalanceResponse | ErrorResponse]:
    """ Get balances for a specific wallet address

    Args:
        owner (str):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BalanceResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        owner=owner,
version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    owner: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = '2026-01-26',

) -> BalanceResponse | ErrorResponse | None:
    """ Get balances for a specific wallet address

    Args:
        owner (str):
        version (str | Unset):  Default: '2026-01-26'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BalanceResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        owner=owner,
client=client,
version=version,

    )).parsed
