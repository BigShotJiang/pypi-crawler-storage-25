from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.trade_request import TradeRequest
from ...models.trade_response import TradeResponse
from typing import cast



def _get_kwargs(
    *,
    body: TradeRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/defi/core/trade",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | TradeResponse | None:
    if response.status_code == 200:
        response_200 = TradeResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 422:
        response_422 = ErrorResponse.from_dict(response.json())



        return response_422

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | TradeResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: TradeRequest,

) -> Response[ErrorResponse | TradeResponse]:
    """ Execute a trade synchronously

     Executes a trade using a cached quote and returns the transaction hash. Follows the same pattern as
    transfer/execute.

    Args:
        body (TradeRequest): Trade request for v2 API. Follows the same pattern as
            transfer/execute - only signatures required, payloads are cached server-side.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TradeResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: TradeRequest,

) -> ErrorResponse | TradeResponse | None:
    """ Execute a trade synchronously

     Executes a trade using a cached quote and returns the transaction hash. Follows the same pattern as
    transfer/execute.

    Args:
        body (TradeRequest): Trade request for v2 API. Follows the same pattern as
            transfer/execute - only signatures required, payloads are cached server-side.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TradeResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: TradeRequest,

) -> Response[ErrorResponse | TradeResponse]:
    """ Execute a trade synchronously

     Executes a trade using a cached quote and returns the transaction hash. Follows the same pattern as
    transfer/execute.

    Args:
        body (TradeRequest): Trade request for v2 API. Follows the same pattern as
            transfer/execute - only signatures required, payloads are cached server-side.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TradeResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: TradeRequest,

) -> ErrorResponse | TradeResponse | None:
    """ Execute a trade synchronously

     Executes a trade using a cached quote and returns the transaction hash. Follows the same pattern as
    transfer/execute.

    Args:
        body (TradeRequest): Trade request for v2 API. Follows the same pattern as
            transfer/execute - only signatures required, payloads are cached server-side.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TradeResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
