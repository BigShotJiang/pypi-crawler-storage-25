from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_wallet_request import CreateWalletRequest
from ...models.error_response import ErrorResponse
from ...models.wallet_created_response import WalletCreatedResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateWalletRequest,
    version: str | Unset = '2026-01-26',

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/defi/core/create-wallet",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | WalletCreatedResponse | None:
    if response.status_code == 201:
        response_201 = WalletCreatedResponse.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 422:
        response_422 = ErrorResponse.from_dict(response.json())



        return response_422

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | WalletCreatedResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateWalletRequest,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | WalletCreatedResponse]:
    """ Create a new wallet

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (CreateWalletRequest): Request to create a wallet. Either WebAuthn fields (for
            passkey wallets) or publicKey (for API key wallets) must be provided.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | WalletCreatedResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateWalletRequest,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | WalletCreatedResponse | None:
    """ Create a new wallet

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (CreateWalletRequest): Request to create a wallet. Either WebAuthn fields (for
            passkey wallets) or publicKey (for API key wallets) must be provided.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | WalletCreatedResponse
     """


    return sync_detailed(
        client=client,
body=body,
version=version,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateWalletRequest,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | WalletCreatedResponse]:
    """ Create a new wallet

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (CreateWalletRequest): Request to create a wallet. Either WebAuthn fields (for
            passkey wallets) or publicKey (for API key wallets) must be provided.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | WalletCreatedResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateWalletRequest,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | WalletCreatedResponse | None:
    """ Create a new wallet

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (CreateWalletRequest): Request to create a wallet. Either WebAuthn fields (for
            passkey wallets) or publicKey (for API key wallets) must be provided.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | WalletCreatedResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,
version=version,

    )).parsed
