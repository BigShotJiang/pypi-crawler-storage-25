from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.transfer_prepare_request import TransferPrepareRequest
from ...models.transfer_prepare_response import TransferPrepareResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: TransferPrepareRequest,
    version: str | Unset = '2026-01-26',

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/defi/core/transfer/prepare",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | TransferPrepareResponse | None:
    if response.status_code == 200:
        response_200 = TransferPrepareResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 422:
        response_422 = ErrorResponse.from_dict(response.json())



        return response_422

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | TransferPrepareResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: TransferPrepareRequest,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | TransferPrepareResponse]:
    """ Prepare a transfer

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (TransferPrepareRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferPrepareResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: TransferPrepareRequest,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | TransferPrepareResponse | None:
    """ Prepare a transfer

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (TransferPrepareRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferPrepareResponse
     """


    return sync_detailed(
        client=client,
body=body,
version=version,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: TransferPrepareRequest,
    version: str | Unset = '2026-01-26',

) -> Response[ErrorResponse | TransferPrepareResponse]:
    """ Prepare a transfer

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (TransferPrepareRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferPrepareResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: TransferPrepareRequest,
    version: str | Unset = '2026-01-26',

) -> ErrorResponse | TransferPrepareResponse | None:
    """ Prepare a transfer

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        body (TransferPrepareRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferPrepareResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,
version=version,

    )).parsed
