from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.recover_wallet_execute_request import RecoverWalletExecuteRequest
from ...models.recover_wallet_execute_response import RecoverWalletExecuteResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: RecoverWalletExecuteRequest,
    version: str | Unset = '2026-01-26',
    x_stamp: str | Unset = UNSET,
    x_stamp_web_authn: str | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_stamp, Unset):
        headers["X-Stamp"] = x_stamp

    if not isinstance(x_stamp_web_authn, Unset):
        headers["X-Stamp-WebAuthn"] = x_stamp_web_authn



    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/defi/core/recovery/register-wallet",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | RecoverWalletExecuteResponse | None:
    if response.status_code == 200:
        response_200 = RecoverWalletExecuteResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | RecoverWalletExecuteResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: RecoverWalletExecuteRequest,
    version: str | Unset = '2026-01-26',
    x_stamp: str | Unset = UNSET,
    x_stamp_web_authn: str | Unset = UNSET,

) -> Response[ErrorResponse | RecoverWalletExecuteResponse]:
    """ Execute wallet recovery

     Submits the signed WebAuthn payload to complete wallet recovery

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        x_stamp (str | Unset):
        x_stamp_web_authn (str | Unset):
        body (RecoverWalletExecuteRequest): Request to execute wallet recovery

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | RecoverWalletExecuteResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,
x_stamp=x_stamp,
x_stamp_web_authn=x_stamp_web_authn,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: RecoverWalletExecuteRequest,
    version: str | Unset = '2026-01-26',
    x_stamp: str | Unset = UNSET,
    x_stamp_web_authn: str | Unset = UNSET,

) -> ErrorResponse | RecoverWalletExecuteResponse | None:
    """ Execute wallet recovery

     Submits the signed WebAuthn payload to complete wallet recovery

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        x_stamp (str | Unset):
        x_stamp_web_authn (str | Unset):
        body (RecoverWalletExecuteRequest): Request to execute wallet recovery

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | RecoverWalletExecuteResponse
     """


    return sync_detailed(
        client=client,
body=body,
version=version,
x_stamp=x_stamp,
x_stamp_web_authn=x_stamp_web_authn,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: RecoverWalletExecuteRequest,
    version: str | Unset = '2026-01-26',
    x_stamp: str | Unset = UNSET,
    x_stamp_web_authn: str | Unset = UNSET,

) -> Response[ErrorResponse | RecoverWalletExecuteResponse]:
    """ Execute wallet recovery

     Submits the signed WebAuthn payload to complete wallet recovery

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        x_stamp (str | Unset):
        x_stamp_web_authn (str | Unset):
        body (RecoverWalletExecuteRequest): Request to execute wallet recovery

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | RecoverWalletExecuteResponse]
     """


    kwargs = _get_kwargs(
        body=body,
version=version,
x_stamp=x_stamp,
x_stamp_web_authn=x_stamp_web_authn,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: RecoverWalletExecuteRequest,
    version: str | Unset = '2026-01-26',
    x_stamp: str | Unset = UNSET,
    x_stamp_web_authn: str | Unset = UNSET,

) -> ErrorResponse | RecoverWalletExecuteResponse | None:
    """ Execute wallet recovery

     Submits the signed WebAuthn payload to complete wallet recovery

    Args:
        version (str | Unset):  Default: '2026-01-26'.
        x_stamp (str | Unset):
        x_stamp_web_authn (str | Unset):
        body (RecoverWalletExecuteRequest): Request to execute wallet recovery

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | RecoverWalletExecuteResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,
version=version,
x_stamp=x_stamp,
x_stamp_web_authn=x_stamp_web_authn,

    )).parsed
