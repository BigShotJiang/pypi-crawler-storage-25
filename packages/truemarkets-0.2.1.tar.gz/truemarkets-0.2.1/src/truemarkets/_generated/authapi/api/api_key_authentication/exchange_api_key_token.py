from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.access_tokens_response import AccessTokensResponse
from ...models.api_key_token_exchange_request import APIKeyTokenExchangeRequest
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    *,
    body: APIKeyTokenExchangeRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api-key/token",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> AccessTokensResponse | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = AccessTokensResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[AccessTokensResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: APIKeyTokenExchangeRequest,

) -> Response[AccessTokensResponse | ErrorResponse]:
    """ Exchange API key for tokens

     Verify an ECDSA P-256 signature and issue JWT tokens. The client signs
    the message `{key_id}.{unix_timestamp}` with their private key using ES256.
    The timestamp must be within ±30 seconds of the server time.

    Args:
        body (APIKeyTokenExchangeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AccessTokensResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: APIKeyTokenExchangeRequest,

) -> AccessTokensResponse | ErrorResponse | None:
    """ Exchange API key for tokens

     Verify an ECDSA P-256 signature and issue JWT tokens. The client signs
    the message `{key_id}.{unix_timestamp}` with their private key using ES256.
    The timestamp must be within ±30 seconds of the server time.

    Args:
        body (APIKeyTokenExchangeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AccessTokensResponse | ErrorResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: APIKeyTokenExchangeRequest,

) -> Response[AccessTokensResponse | ErrorResponse]:
    """ Exchange API key for tokens

     Verify an ECDSA P-256 signature and issue JWT tokens. The client signs
    the message `{key_id}.{unix_timestamp}` with their private key using ES256.
    The timestamp must be within ±30 seconds of the server time.

    Args:
        body (APIKeyTokenExchangeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AccessTokensResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: APIKeyTokenExchangeRequest,

) -> AccessTokensResponse | ErrorResponse | None:
    """ Exchange API key for tokens

     Verify an ECDSA P-256 signature and issue JWT tokens. The client signs
    the message `{key_id}.{unix_timestamp}` with their private key using ES256.
    The timestamp must be within ±30 seconds of the server time.

    Args:
        body (APIKeyTokenExchangeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AccessTokensResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
