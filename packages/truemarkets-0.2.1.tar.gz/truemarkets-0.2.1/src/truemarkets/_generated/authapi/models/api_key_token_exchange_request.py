from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="APIKeyTokenExchangeRequest")



@_attrs_define
class APIKeyTokenExchangeRequest:
    """ 
        Attributes:
            key_id (UUID): The API key ID
            timestamp (int): Current Unix timestamp (must be within ±30s of server time)
            signature (str): Base64url-encoded ECDSA P-256 signature of `{key_id}.{timestamp}`
     """

    key_id: UUID
    timestamp: int
    signature: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        key_id = str(self.key_id)

        timestamp = self.timestamp

        signature = self.signature


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "key_id": key_id,
            "timestamp": timestamp,
            "signature": signature,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        key_id = UUID(d.pop("key_id"))




        timestamp = d.pop("timestamp")

        signature = d.pop("signature")

        api_key_token_exchange_request = cls(
            key_id=key_id,
            timestamp=timestamp,
            signature=signature,
        )


        api_key_token_exchange_request.additional_properties = d
        return api_key_token_exchange_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
