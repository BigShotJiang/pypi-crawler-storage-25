from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PriceRangeResponse")



@_attrs_define
class PriceRangeResponse:
    """ 
        Attributes:
            symbol (str | Unset): The asset symbol
            window (str | Unset): The time window used for the query
            min_price (str | Unset): Minimum price within the window
            max_price (str | Unset): Maximum price within the window
            min_timestamp (str | Unset): ISO 8601 timestamp when the minimum price occurred
            max_timestamp (str | Unset): ISO 8601 timestamp when the maximum price occurred
     """

    symbol: str | Unset = UNSET
    window: str | Unset = UNSET
    min_price: str | Unset = UNSET
    max_price: str | Unset = UNSET
    min_timestamp: str | Unset = UNSET
    max_timestamp: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        window = self.window

        min_price = self.min_price

        max_price = self.max_price

        min_timestamp = self.min_timestamp

        max_timestamp = self.max_timestamp


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if window is not UNSET:
            field_dict["window"] = window
        if min_price is not UNSET:
            field_dict["min_price"] = min_price
        if max_price is not UNSET:
            field_dict["max_price"] = max_price
        if min_timestamp is not UNSET:
            field_dict["min_timestamp"] = min_timestamp
        if max_timestamp is not UNSET:
            field_dict["max_timestamp"] = max_timestamp

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        window = d.pop("window", UNSET)

        min_price = d.pop("min_price", UNSET)

        max_price = d.pop("max_price", UNSET)

        min_timestamp = d.pop("min_timestamp", UNSET)

        max_timestamp = d.pop("max_timestamp", UNSET)

        price_range_response = cls(
            symbol=symbol,
            window=window,
            min_price=min_price,
            max_price=max_price,
            min_timestamp=min_timestamp,
            max_timestamp=max_timestamp,
        )


        price_range_response.additional_properties = d
        return price_range_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
