from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="Candle")



@_attrs_define
class Candle:
    """ 
        Attributes:
            interval (str | Unset): Time interval for the candle (e.g., 1h, 4h, 24h)
            open_price (str | Unset): Opening price for the interval
            close_price (str | Unset): Closing price for the interval
            high_price (str | Unset): Highest price during the interval
            low_price (str | Unset): Lowest price during the interval
     """

    interval: str | Unset = UNSET
    open_price: str | Unset = UNSET
    close_price: str | Unset = UNSET
    high_price: str | Unset = UNSET
    low_price: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        interval = self.interval

        open_price = self.open_price

        close_price = self.close_price

        high_price = self.high_price

        low_price = self.low_price


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if interval is not UNSET:
            field_dict["interval"] = interval
        if open_price is not UNSET:
            field_dict["openPrice"] = open_price
        if close_price is not UNSET:
            field_dict["closePrice"] = close_price
        if high_price is not UNSET:
            field_dict["highPrice"] = high_price
        if low_price is not UNSET:
            field_dict["lowPrice"] = low_price

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        interval = d.pop("interval", UNSET)

        open_price = d.pop("openPrice", UNSET)

        close_price = d.pop("closePrice", UNSET)

        high_price = d.pop("highPrice", UNSET)

        low_price = d.pop("lowPrice", UNSET)

        candle = cls(
            interval=interval,
            open_price=open_price,
            close_price=close_price,
            high_price=high_price,
            low_price=low_price,
        )


        candle.additional_properties = d
        return candle

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
