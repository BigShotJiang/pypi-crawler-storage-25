from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.point import Point





T = TypeVar("T", bound="BatchPriceHistoryResult")



@_attrs_define
class BatchPriceHistoryResult:
    """ 
        Attributes:
            symbol (str | Unset): The asset symbol
            points (list[Point] | Unset): Price points (omitted if error)
            error (str | Unset): Error message if the symbol could not be resolved (omitted on success)
     """

    symbol: str | Unset = UNSET
    points: list[Point] | Unset = UNSET
    error: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.point import Point
        symbol = self.symbol

        points: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.points, Unset):
            points = []
            for points_item_data in self.points:
                points_item = points_item_data.to_dict()
                points.append(points_item)



        error = self.error


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if points is not UNSET:
            field_dict["points"] = points
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.point import Point
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        _points = d.pop("points", UNSET)
        points: list[Point] | Unset = UNSET
        if _points is not UNSET:
            points = []
            for points_item_data in _points:
                points_item = Point.from_dict(points_item_data)



                points.append(points_item)


        error = d.pop("error", UNSET)

        batch_price_history_result = cls(
            symbol=symbol,
            points=points,
            error=error,
        )


        batch_price_history_result.additional_properties = d
        return batch_price_history_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
