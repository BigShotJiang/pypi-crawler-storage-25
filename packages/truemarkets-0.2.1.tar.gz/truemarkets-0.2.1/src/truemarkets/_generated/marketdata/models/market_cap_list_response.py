from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.market_cap_response import MarketCapResponse





T = TypeVar("T", bound="MarketCapListResponse")



@_attrs_define
class MarketCapListResponse:
    """ 
        Attributes:
            assets (list[MarketCapResponse] | Unset): List of assets with market cap, sorted by market cap descending
     """

    assets: list[MarketCapResponse] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.market_cap_response import MarketCapResponse
        assets: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.assets, Unset):
            assets = []
            for assets_item_data in self.assets:
                assets_item = assets_item_data.to_dict()
                assets.append(assets_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if assets is not UNSET:
            field_dict["assets"] = assets

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.market_cap_response import MarketCapResponse
        d = dict(src_dict)
        _assets = d.pop("assets", UNSET)
        assets: list[MarketCapResponse] | Unset = UNSET
        if _assets is not UNSET:
            assets = []
            for assets_item_data in _assets:
                assets_item = MarketCapResponse.from_dict(assets_item_data)



                assets.append(assets_item)


        market_cap_list_response = cls(
            assets=assets,
        )


        market_cap_list_response.additional_properties = d
        return market_cap_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
