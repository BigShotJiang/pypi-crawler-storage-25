from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.batch_price_history_result import BatchPriceHistoryResult





T = TypeVar("T", bound="BatchPriceHistoryResponse")



@_attrs_define
class BatchPriceHistoryResponse:
    """ 
        Attributes:
            window (str | Unset): The time window used for the query
            resolution (str | Unset): The time resolution used for the query
            results (list[BatchPriceHistoryResult] | Unset): Per-symbol results
     """

    window: str | Unset = UNSET
    resolution: str | Unset = UNSET
    results: list[BatchPriceHistoryResult] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.batch_price_history_result import BatchPriceHistoryResult
        window = self.window

        resolution = self.resolution

        results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.results, Unset):
            results = []
            for results_item_data in self.results:
                results_item = results_item_data.to_dict()
                results.append(results_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if window is not UNSET:
            field_dict["window"] = window
        if resolution is not UNSET:
            field_dict["resolution"] = resolution
        if results is not UNSET:
            field_dict["results"] = results

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.batch_price_history_result import BatchPriceHistoryResult
        d = dict(src_dict)
        window = d.pop("window", UNSET)

        resolution = d.pop("resolution", UNSET)

        _results = d.pop("results", UNSET)
        results: list[BatchPriceHistoryResult] | Unset = UNSET
        if _results is not UNSET:
            results = []
            for results_item_data in _results:
                results_item = BatchPriceHistoryResult.from_dict(results_item_data)



                results.append(results_item)


        batch_price_history_response = cls(
            window=window,
            resolution=resolution,
            results=results,
        )


        batch_price_history_response.additional_properties = d
        return batch_price_history_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
