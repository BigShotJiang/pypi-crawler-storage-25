from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.candle import Candle





T = TypeVar("T", bound="PriceResponse")



@_attrs_define
class PriceResponse:
    """ 
        Attributes:
            symbol (str | Unset): The asset symbol
            candles (list[Candle] | Unset): List of price candles for different time intervals
     """

    symbol: str | Unset = UNSET
    candles: list[Candle] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.candle import Candle
        symbol = self.symbol

        candles: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.candles, Unset):
            candles = []
            for candles_item_data in self.candles:
                candles_item = candles_item_data.to_dict()
                candles.append(candles_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if candles is not UNSET:
            field_dict["candles"] = candles

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.candle import Candle
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        _candles = d.pop("candles", UNSET)
        candles: list[Candle] | Unset = UNSET
        if _candles is not UNSET:
            candles = []
            for candles_item_data in _candles:
                candles_item = Candle.from_dict(candles_item_data)



                candles.append(candles_item)


        price_response = cls(
            symbol=symbol,
            candles=candles,
        )


        price_response.additional_properties = d
        return price_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
