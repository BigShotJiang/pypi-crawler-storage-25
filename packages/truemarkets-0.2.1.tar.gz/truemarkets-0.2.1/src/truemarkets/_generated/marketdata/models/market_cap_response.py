from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="MarketCapResponse")



@_attrs_define
class MarketCapResponse:
    """ 
        Attributes:
            symbol (str | Unset): The asset symbol
            market_cap (str | Unset): Market capitalization in USD (as string to preserve precision)
     """

    symbol: str | Unset = UNSET
    market_cap: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        market_cap = self.market_cap


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if market_cap is not UNSET:
            field_dict["market_cap"] = market_cap

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        market_cap = d.pop("market_cap", UNSET)

        market_cap_response = cls(
            symbol=symbol,
            market_cap=market_cap,
        )


        market_cap_response.additional_properties = d
        return market_cap_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
