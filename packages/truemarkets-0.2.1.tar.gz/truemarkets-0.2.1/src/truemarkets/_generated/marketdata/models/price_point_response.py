from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PricePointResponse")



@_attrs_define
class PricePointResponse:
    """ 
        Attributes:
            symbol (str | Unset): The asset symbol
            timestamp (int | Unset): Unix timestamp of the actual data point returned
            price (str | Unset): Price at the returned timestamp
     """

    symbol: str | Unset = UNSET
    timestamp: int | Unset = UNSET
    price: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        timestamp = self.timestamp

        price = self.price


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if price is not UNSET:
            field_dict["price"] = price

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        timestamp = d.pop("timestamp", UNSET)

        price = d.pop("price", UNSET)

        price_point_response = cls(
            symbol=symbol,
            timestamp=timestamp,
            price=price,
        )


        price_point_response.additional_properties = d
        return price_point_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
