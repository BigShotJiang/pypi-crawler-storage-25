from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.batch_price_history_response import BatchPriceHistoryResponse
from ...models.error_response import ErrorResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    symbols: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["symbols"] = symbols

    params["window"] = window

    params["resolution"] = resolution


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/market/prices/history/batch",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BatchPriceHistoryResponse | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = BatchPriceHistoryResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BatchPriceHistoryResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbols: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> Response[BatchPriceHistoryResponse | ErrorResponse]:
    """ Get price history for multiple symbols

     Returns price history for multiple symbols in a single request. Each symbol
    is resolved independently — an unknown or failing symbol returns a per-symbol
    error in its result entry instead of failing the whole batch, so partial
    results are still returned.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbols (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchPriceHistoryResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        symbols=symbols,
window=window,
resolution=resolution,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    symbols: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> BatchPriceHistoryResponse | ErrorResponse | None:
    """ Get price history for multiple symbols

     Returns price history for multiple symbols in a single request. Each symbol
    is resolved independently — an unknown or failing symbol returns a per-symbol
    error in its result entry instead of failing the whole batch, so partial
    results are still returned.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbols (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchPriceHistoryResponse | ErrorResponse
     """


    return sync_detailed(
        client=client,
symbols=symbols,
window=window,
resolution=resolution,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbols: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> Response[BatchPriceHistoryResponse | ErrorResponse]:
    """ Get price history for multiple symbols

     Returns price history for multiple symbols in a single request. Each symbol
    is resolved independently — an unknown or failing symbol returns a per-symbol
    error in its result entry instead of failing the whole batch, so partial
    results are still returned.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbols (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchPriceHistoryResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        symbols=symbols,
window=window,
resolution=resolution,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    symbols: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> BatchPriceHistoryResponse | ErrorResponse | None:
    """ Get price history for multiple symbols

     Returns price history for multiple symbols in a single request. Each symbol
    is resolved independently — an unknown or failing symbol returns a per-symbol
    error in its result entry instead of failing the whole batch, so partial
    results are still returned.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbols (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchPriceHistoryResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,
symbols=symbols,
window=window,
resolution=resolution,

    )).parsed
