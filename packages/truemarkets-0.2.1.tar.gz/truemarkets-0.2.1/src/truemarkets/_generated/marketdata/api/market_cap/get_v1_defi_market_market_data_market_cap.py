from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.market_cap_response import MarketCapResponse
from typing import cast



def _get_kwargs(
    *,
    symbol: str,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["symbol"] = symbol


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/market/market-data/market-cap",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | MarketCapResponse | None:
    if response.status_code == 200:
        response_200 = MarketCapResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | MarketCapResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,

) -> Response[ErrorResponse | MarketCapResponse]:
    """ Get market cap by symbol

     Returns the latest market capitalization (in USD) for an asset.

    Args:
        symbol (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | MarketCapResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,

) -> ErrorResponse | MarketCapResponse | None:
    """ Get market cap by symbol

     Returns the latest market capitalization (in USD) for an asset.

    Args:
        symbol (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | MarketCapResponse
     """


    return sync_detailed(
        client=client,
symbol=symbol,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,

) -> Response[ErrorResponse | MarketCapResponse]:
    """ Get market cap by symbol

     Returns the latest market capitalization (in USD) for an asset.

    Args:
        symbol (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | MarketCapResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,

) -> ErrorResponse | MarketCapResponse | None:
    """ Get market cap by symbol

     Returns the latest market capitalization (in USD) for an asset.

    Args:
        symbol (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | MarketCapResponse
     """


    return (await asyncio_detailed(
        client=client,
symbol=symbol,

    )).parsed
