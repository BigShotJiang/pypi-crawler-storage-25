from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.price_history_response import PriceHistoryResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    symbol: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["symbol"] = symbol

    params["window"] = window

    params["resolution"] = resolution


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/market/prices/history",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | PriceHistoryResponse | None:
    if response.status_code == 200:
        response_200 = PriceHistoryResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | PriceHistoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> Response[ErrorResponse | PriceHistoryResponse]:
    """ Get price history for a symbol

     Returns historical price points for an asset over a configurable lookback
    window, sampled at a configurable resolution. Use for charting and
    time-series analysis.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PriceHistoryResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,
window=window,
resolution=resolution,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> ErrorResponse | PriceHistoryResponse | None:
    """ Get price history for a symbol

     Returns historical price points for an asset over a configurable lookback
    window, sampled at a configurable resolution. Use for charting and
    time-series analysis.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PriceHistoryResponse
     """


    return sync_detailed(
        client=client,
symbol=symbol,
window=window,
resolution=resolution,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> Response[ErrorResponse | PriceHistoryResponse]:
    """ Get price history for a symbol

     Returns historical price points for an asset over a configurable lookback
    window, sampled at a configurable resolution. Use for charting and
    time-series analysis.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PriceHistoryResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,
window=window,
resolution=resolution,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',
    resolution: str | Unset = '5s',

) -> ErrorResponse | PriceHistoryResponse | None:
    """ Get price history for a symbol

     Returns historical price points for an asset over a configurable lookback
    window, sampled at a configurable resolution. Use for charting and
    time-series analysis.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window` and `resolution`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.
        resolution (str | Unset):  Default: '5s'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PriceHistoryResponse
     """


    return (await asyncio_detailed(
        client=client,
symbol=symbol,
window=window,
resolution=resolution,

    )).parsed
