from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.price_range_response import PriceRangeResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    symbol: str,
    window: str | Unset = '1h',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["symbol"] = symbol

    params["window"] = window


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/defi/market/prices/range",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | PriceRangeResponse | None:
    if response.status_code == 200:
        response_200 = PriceRangeResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | PriceRangeResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',

) -> Response[ErrorResponse | PriceRangeResponse]:
    """ Get min/max price over a window

     Returns the minimum and maximum price observed for an asset within a
    configurable lookback window, along with the timestamps at which each
    extreme occurred. Useful for surfacing 24h highs/lows or computing
    period-over-period statistics.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PriceRangeResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,
window=window,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',

) -> ErrorResponse | PriceRangeResponse | None:
    """ Get min/max price over a window

     Returns the minimum and maximum price observed for an asset within a
    configurable lookback window, along with the timestamps at which each
    extreme occurred. Useful for surfacing 24h highs/lows or computing
    period-over-period statistics.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PriceRangeResponse
     """


    return sync_detailed(
        client=client,
symbol=symbol,
window=window,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',

) -> Response[ErrorResponse | PriceRangeResponse]:
    """ Get min/max price over a window

     Returns the minimum and maximum price observed for an asset within a
    configurable lookback window, along with the timestamps at which each
    extreme occurred. Useful for surfacing 24h highs/lows or computing
    period-over-period statistics.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PriceRangeResponse]
     """


    kwargs = _get_kwargs(
        symbol=symbol,
window=window,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    symbol: str,
    window: str | Unset = '1h',

) -> ErrorResponse | PriceRangeResponse | None:
    """ Get min/max price over a window

     Returns the minimum and maximum price observed for an asset within a
    configurable lookback window, along with the timestamps at which each
    extreme occurred. Useful for surfacing 24h highs/lows or computing
    period-over-period statistics.

    See the [Time Window & Resolution](#section/Time-Window-and-Resolution)
    section for the format of `window`.

    Args:
        symbol (str):
        window (str | Unset):  Default: '1h'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PriceRangeResponse
     """


    return (await asyncio_detailed(
        client=client,
symbol=symbol,
window=window,

    )).parsed
