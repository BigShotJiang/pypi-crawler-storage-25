from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.execute_transfer_request import ExecuteTransferRequest
from ...models.transfer_detail import TransferDetail
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    body: ExecuteTransferRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/transfers/{id}/execute".format(id=quote(str(id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | TransferDetail | None:
    if response.status_code == 200:
        response_200 = TransferDetail.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 409:
        response_409 = ErrorResponse.from_dict(response.json())



        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | TransferDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExecuteTransferRequest,

) -> Response[ErrorResponse | TransferDetail]:
    """ Execute pending transfer

     Executes a transfer in `awaiting_signature` status using client-provided signatures

    Args:
        id (UUID):
        body (ExecuteTransferRequest): Request to execute a transfer that is in
            `awaiting_signature` status. The client must sign each payload returned by the create
            endpoint and submit the signatures in the same order.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferDetail]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExecuteTransferRequest,

) -> ErrorResponse | TransferDetail | None:
    """ Execute pending transfer

     Executes a transfer in `awaiting_signature` status using client-provided signatures

    Args:
        id (UUID):
        body (ExecuteTransferRequest): Request to execute a transfer that is in
            `awaiting_signature` status. The client must sign each payload returned by the create
            endpoint and submit the signatures in the same order.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferDetail
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExecuteTransferRequest,

) -> Response[ErrorResponse | TransferDetail]:
    """ Execute pending transfer

     Executes a transfer in `awaiting_signature` status using client-provided signatures

    Args:
        id (UUID):
        body (ExecuteTransferRequest): Request to execute a transfer that is in
            `awaiting_signature` status. The client must sign each payload returned by the create
            endpoint and submit the signatures in the same order.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferDetail]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExecuteTransferRequest,

) -> ErrorResponse | TransferDetail | None:
    """ Execute pending transfer

     Executes a transfer in `awaiting_signature` status using client-provided signatures

    Args:
        id (UUID):
        body (ExecuteTransferRequest): Request to execute a transfer that is in
            `awaiting_signature` status. The client must sign each payload returned by the create
            endpoint and submit the signatures in the same order.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferDetail
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
