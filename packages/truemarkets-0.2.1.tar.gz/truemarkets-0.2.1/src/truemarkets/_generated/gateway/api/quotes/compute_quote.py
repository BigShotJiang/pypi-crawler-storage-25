from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.quote_request import QuoteRequest
from ...models.quote_response import QuoteResponse
from typing import cast



def _get_kwargs(
    *,
    body: QuoteRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/quotes",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | QuoteResponse | None:
    if response.status_code == 200:
        response_200 = QuoteResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if response.status_code == 503:
        response_503 = ErrorResponse.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | QuoteResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QuoteRequest,

) -> Response[ErrorResponse | QuoteResponse]:
    """ Compute market quote (CeFi only)

     Non-binding price preview for a CeFi market order. For DeFi, the quote is returned by `POST /orders`
    (see `CreateOrderResponse.quote`).

    Args:
        body (QuoteRequest): Request to compute a market quote

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | QuoteResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QuoteRequest,

) -> ErrorResponse | QuoteResponse | None:
    """ Compute market quote (CeFi only)

     Non-binding price preview for a CeFi market order. For DeFi, the quote is returned by `POST /orders`
    (see `CreateOrderResponse.quote`).

    Args:
        body (QuoteRequest): Request to compute a market quote

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | QuoteResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QuoteRequest,

) -> Response[ErrorResponse | QuoteResponse]:
    """ Compute market quote (CeFi only)

     Non-binding price preview for a CeFi market order. For DeFi, the quote is returned by `POST /orders`
    (see `CreateOrderResponse.quote`).

    Args:
        body (QuoteRequest): Request to compute a market quote

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | QuoteResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QuoteRequest,

) -> ErrorResponse | QuoteResponse | None:
    """ Compute market quote (CeFi only)

     Non-binding price preview for a CeFi market order. For DeFi, the quote is returned by `POST /orders`
    (see `CreateOrderResponse.quote`).

    Args:
        body (QuoteRequest): Request to compute a market quote

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | QuoteResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
