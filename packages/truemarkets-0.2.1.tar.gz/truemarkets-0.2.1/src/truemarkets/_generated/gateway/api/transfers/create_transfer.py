from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_transfer_request import CreateTransferRequest
from ...models.error_response import ErrorResponse
from ...models.transfer_detail import TransferDetail
from typing import cast



def _get_kwargs(
    *,
    body: CreateTransferRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/transfers",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | TransferDetail | None:
    if response.status_code == 201:
        response_201 = TransferDetail.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | TransferDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTransferRequest,

) -> Response[ErrorResponse | TransferDetail]:
    """ Create new transfer

     Creates a new on-chain transfer. Returns unsigned payloads for the client to sign before executing.

    Args:
        body (CreateTransferRequest): Request to create a new on-chain transfer

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferDetail]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateTransferRequest,

) -> ErrorResponse | TransferDetail | None:
    """ Create new transfer

     Creates a new on-chain transfer. Returns unsigned payloads for the client to sign before executing.

    Args:
        body (CreateTransferRequest): Request to create a new on-chain transfer

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferDetail
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTransferRequest,

) -> Response[ErrorResponse | TransferDetail]:
    """ Create new transfer

     Creates a new on-chain transfer. Returns unsigned payloads for the client to sign before executing.

    Args:
        body (CreateTransferRequest): Request to create a new on-chain transfer

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | TransferDetail]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateTransferRequest,

) -> ErrorResponse | TransferDetail | None:
    """ Create new transfer

     Creates a new on-chain transfer. Returns unsigned payloads for the client to sign before executing.

    Args:
        body (CreateTransferRequest): Request to create a new on-chain transfer

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | TransferDetail
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
