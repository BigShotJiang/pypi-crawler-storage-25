from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.list_transfers_response import ListTransfersResponse
from ...models.transfer_status import TransferStatus
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    status: TransferStatus | Unset = UNSET,
    cursor: str | Unset = UNSET,
    limit: int | Unset = 50,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    params["cursor"] = cursor

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/transfers",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | ListTransfersResponse | None:
    if response.status_code == 200:
        response_200 = ListTransfersResponse.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | ListTransfersResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    status: TransferStatus | Unset = UNSET,
    cursor: str | Unset = UNSET,
    limit: int | Unset = 50,

) -> Response[ErrorResponse | ListTransfersResponse]:
    """ List user transfers

     Returns a paginated list of transfers for the authenticated user

    Args:
        status (TransferStatus | Unset): The current status of the transfer.
            * **awaiting_signature** — Transfer has been created and is waiting for the client to sign
            the unsigned payloads and call the execute endpoint.
            * **pending** — Signed transaction has been submitted and is awaiting on-chain
            confirmation.
            * **completed** — Transfer has been confirmed on-chain.
            * **failed** — Transfer failed due to an on-chain error or rejection.
             Example: pending.
        cursor (str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ListTransfersResponse]
     """


    kwargs = _get_kwargs(
        status=status,
cursor=cursor,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    status: TransferStatus | Unset = UNSET,
    cursor: str | Unset = UNSET,
    limit: int | Unset = 50,

) -> ErrorResponse | ListTransfersResponse | None:
    """ List user transfers

     Returns a paginated list of transfers for the authenticated user

    Args:
        status (TransferStatus | Unset): The current status of the transfer.
            * **awaiting_signature** — Transfer has been created and is waiting for the client to sign
            the unsigned payloads and call the execute endpoint.
            * **pending** — Signed transaction has been submitted and is awaiting on-chain
            confirmation.
            * **completed** — Transfer has been confirmed on-chain.
            * **failed** — Transfer failed due to an on-chain error or rejection.
             Example: pending.
        cursor (str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ListTransfersResponse
     """


    return sync_detailed(
        client=client,
status=status,
cursor=cursor,
limit=limit,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    status: TransferStatus | Unset = UNSET,
    cursor: str | Unset = UNSET,
    limit: int | Unset = 50,

) -> Response[ErrorResponse | ListTransfersResponse]:
    """ List user transfers

     Returns a paginated list of transfers for the authenticated user

    Args:
        status (TransferStatus | Unset): The current status of the transfer.
            * **awaiting_signature** — Transfer has been created and is waiting for the client to sign
            the unsigned payloads and call the execute endpoint.
            * **pending** — Signed transaction has been submitted and is awaiting on-chain
            confirmation.
            * **completed** — Transfer has been confirmed on-chain.
            * **failed** — Transfer failed due to an on-chain error or rejection.
             Example: pending.
        cursor (str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ListTransfersResponse]
     """


    kwargs = _get_kwargs(
        status=status,
cursor=cursor,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    status: TransferStatus | Unset = UNSET,
    cursor: str | Unset = UNSET,
    limit: int | Unset = 50,

) -> ErrorResponse | ListTransfersResponse | None:
    """ List user transfers

     Returns a paginated list of transfers for the authenticated user

    Args:
        status (TransferStatus | Unset): The current status of the transfer.
            * **awaiting_signature** — Transfer has been created and is waiting for the client to sign
            the unsigned payloads and call the execute endpoint.
            * **pending** — Signed transaction has been submitted and is awaiting on-chain
            confirmation.
            * **completed** — Transfer has been confirmed on-chain.
            * **failed** — Transfer failed due to an on-chain error or rejection.
             Example: pending.
        cursor (str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ListTransfersResponse
     """


    return (await asyncio_detailed(
        client=client,
status=status,
cursor=cursor,
limit=limit,

    )).parsed
