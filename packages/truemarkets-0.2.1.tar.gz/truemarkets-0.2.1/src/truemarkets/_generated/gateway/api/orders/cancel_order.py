from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.cancel_order_response_202 import CancelOrderResponse202
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/orders/{id}".format(id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CancelOrderResponse202 | ErrorResponse | None:
    if response.status_code == 202:
        response_202 = CancelOrderResponse202.from_dict(response.json())



        return response_202

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CancelOrderResponse202 | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,

) -> Response[CancelOrderResponse202 | ErrorResponse]:
    """ Cancel a pending limit order

     Submits a cancellation request for a pending limit order on CeFi.

    Cancellation is asynchronous — the order moves to `cancel_pending` immediately,
    then the order syncer reconciles the final state:
    - `cancelled` if the CeFi exchange confirms the cancellation
    - `complete` if the order filled before the cancel landed (race condition)

    Only CeFi limit orders in `pending` or `active` status are cancellable.
    DeFi orders and market orders return 400.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelOrderResponse202 | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient,

) -> CancelOrderResponse202 | ErrorResponse | None:
    """ Cancel a pending limit order

     Submits a cancellation request for a pending limit order on CeFi.

    Cancellation is asynchronous — the order moves to `cancel_pending` immediately,
    then the order syncer reconciles the final state:
    - `cancelled` if the CeFi exchange confirms the cancellation
    - `complete` if the order filled before the cancel landed (race condition)

    Only CeFi limit orders in `pending` or `active` status are cancellable.
    DeFi orders and market orders return 400.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelOrderResponse202 | ErrorResponse
     """


    return sync_detailed(
        id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,

) -> Response[CancelOrderResponse202 | ErrorResponse]:
    """ Cancel a pending limit order

     Submits a cancellation request for a pending limit order on CeFi.

    Cancellation is asynchronous — the order moves to `cancel_pending` immediately,
    then the order syncer reconciles the final state:
    - `cancelled` if the CeFi exchange confirms the cancellation
    - `complete` if the order filled before the cancel landed (race condition)

    Only CeFi limit orders in `pending` or `active` status are cancellable.
    DeFi orders and market orders return 400.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelOrderResponse202 | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,

) -> CancelOrderResponse202 | ErrorResponse | None:
    """ Cancel a pending limit order

     Submits a cancellation request for a pending limit order on CeFi.

    Cancellation is asynchronous — the order moves to `cancel_pending` immediately,
    then the order syncer reconciles the final state:
    - `cancelled` if the CeFi exchange confirms the cancellation
    - `complete` if the order filled before the cancel landed (race condition)

    Only CeFi limit orders in `pending` or `active` status are cancellable.
    DeFi orders and market orders return 400.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelOrderResponse202 | ErrorResponse
     """


    return (await asyncio_detailed(
        id=id,
client=client,

    )).parsed
