from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.list_assets_response import ListAssetsResponse
from ...models.venue import Venue
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    venue: Venue | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_venue: str | Unset = UNSET
    if not isinstance(venue, Unset):
        json_venue = venue.value

    params["venue"] = json_venue


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/assets",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | ListAssetsResponse | None:
    if response.status_code == 200:
        response_200 = ListAssetsResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | ListAssetsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    venue: Venue | Unset = UNSET,

) -> Response[ErrorResponse | ListAssetsResponse]:
    """ List tradeable assets

     Returns a unified catalog of all active tradeable assets across DeFi and CeFi venues

    Args:
        venue (Venue | Unset): The trading venue to filter by.
            * **defi** — Decentralized exchange (on-chain swaps).
            * **cefi** — Centralized exchange (off-chain order book).
             Example: defi.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ListAssetsResponse]
     """


    kwargs = _get_kwargs(
        venue=venue,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    venue: Venue | Unset = UNSET,

) -> ErrorResponse | ListAssetsResponse | None:
    """ List tradeable assets

     Returns a unified catalog of all active tradeable assets across DeFi and CeFi venues

    Args:
        venue (Venue | Unset): The trading venue to filter by.
            * **defi** — Decentralized exchange (on-chain swaps).
            * **cefi** — Centralized exchange (off-chain order book).
             Example: defi.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ListAssetsResponse
     """


    return sync_detailed(
        client=client,
venue=venue,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    venue: Venue | Unset = UNSET,

) -> Response[ErrorResponse | ListAssetsResponse]:
    """ List tradeable assets

     Returns a unified catalog of all active tradeable assets across DeFi and CeFi venues

    Args:
        venue (Venue | Unset): The trading venue to filter by.
            * **defi** — Decentralized exchange (on-chain swaps).
            * **cefi** — Centralized exchange (off-chain order book).
             Example: defi.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ListAssetsResponse]
     """


    kwargs = _get_kwargs(
        venue=venue,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    venue: Venue | Unset = UNSET,

) -> ErrorResponse | ListAssetsResponse | None:
    """ List tradeable assets

     Returns a unified catalog of all active tradeable assets across DeFi and CeFi venues

    Args:
        venue (Venue | Unset): The trading venue to filter by.
            * **defi** — Decentralized exchange (on-chain swaps).
            * **cefi** — Centralized exchange (off-chain order book).
             Example: defi.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ListAssetsResponse
     """


    return (await asyncio_detailed(
        client=client,
venue=venue,

    )).parsed
