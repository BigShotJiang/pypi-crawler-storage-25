from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_order_request import CreateOrderRequest
from ...models.create_order_response import CreateOrderResponse
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    *,
    body: CreateOrderRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/orders",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateOrderResponse | ErrorResponse | None:
    if response.status_code == 201:
        response_201 = CreateOrderResponse.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if response.status_code == 503:
        response_503 = ErrorResponse.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateOrderResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateOrderRequest,

) -> Response[CreateOrderResponse | ErrorResponse]:
    """ Create new order

     Creates a new order. For DeFi orders, returns unsigned payloads for client signing.

    Args:
        body (CreateOrderRequest): Request to create a new order.

            **Limit orders** (`type: limit`):
            - `price` is required and must be a positive decimal string
            - `qty_unit` must be `base`
            - `chain` is not supported (CeFi only)

            **Market orders** (`type: market`):
            - `price` is not accepted
            - Buy orders require `qty_unit: quote`
            - Sell orders accept `qty_unit: base` or `qty_unit: quote`
            - `chain` is optional (omit for CeFi, include for DeFi)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateOrderResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateOrderRequest,

) -> CreateOrderResponse | ErrorResponse | None:
    """ Create new order

     Creates a new order. For DeFi orders, returns unsigned payloads for client signing.

    Args:
        body (CreateOrderRequest): Request to create a new order.

            **Limit orders** (`type: limit`):
            - `price` is required and must be a positive decimal string
            - `qty_unit` must be `base`
            - `chain` is not supported (CeFi only)

            **Market orders** (`type: market`):
            - `price` is not accepted
            - Buy orders require `qty_unit: quote`
            - Sell orders accept `qty_unit: base` or `qty_unit: quote`
            - `chain` is optional (omit for CeFi, include for DeFi)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateOrderResponse | ErrorResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateOrderRequest,

) -> Response[CreateOrderResponse | ErrorResponse]:
    """ Create new order

     Creates a new order. For DeFi orders, returns unsigned payloads for client signing.

    Args:
        body (CreateOrderRequest): Request to create a new order.

            **Limit orders** (`type: limit`):
            - `price` is required and must be a positive decimal string
            - `qty_unit` must be `base`
            - `chain` is not supported (CeFi only)

            **Market orders** (`type: market`):
            - `price` is not accepted
            - Buy orders require `qty_unit: quote`
            - Sell orders accept `qty_unit: base` or `qty_unit: quote`
            - `chain` is optional (omit for CeFi, include for DeFi)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateOrderResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateOrderRequest,

) -> CreateOrderResponse | ErrorResponse | None:
    """ Create new order

     Creates a new order. For DeFi orders, returns unsigned payloads for client signing.

    Args:
        body (CreateOrderRequest): Request to create a new order.

            **Limit orders** (`type: limit`):
            - `price` is required and must be a positive decimal string
            - `qty_unit` must be `base`
            - `chain` is not supported (CeFi only)

            **Market orders** (`type: market`):
            - `price` is not accepted
            - Buy orders require `qty_unit: quote`
            - Sell orders accept `qty_unit: base` or `qty_unit: quote`
            - `chain` is optional (omit for CeFi, include for DeFi)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateOrderResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
