from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.get_orders_response import GetOrdersResponse
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime



def _get_kwargs(
    *,
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["limit"] = limit

    json_cursor: str | Unset = UNSET
    if not isinstance(cursor, Unset):
        json_cursor = cursor.isoformat()
    params["cursor"] = json_cursor

    params["status"] = status


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/orders",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | GetOrdersResponse | None:
    if response.status_code == 200:
        response_200 = GetOrdersResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | GetOrdersResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,

) -> Response[ErrorResponse | GetOrdersResponse]:
    """ List user orders

     Returns a paginated list of completed and failed orders with execution data for the authenticated
    user

    Args:
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):
        status (str | Unset):  Example: pending,canceled.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | GetOrdersResponse]
     """


    kwargs = _get_kwargs(
        limit=limit,
cursor=cursor,
status=status,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,

) -> ErrorResponse | GetOrdersResponse | None:
    """ List user orders

     Returns a paginated list of completed and failed orders with execution data for the authenticated
    user

    Args:
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):
        status (str | Unset):  Example: pending,canceled.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | GetOrdersResponse
     """


    return sync_detailed(
        client=client,
limit=limit,
cursor=cursor,
status=status,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,

) -> Response[ErrorResponse | GetOrdersResponse]:
    """ List user orders

     Returns a paginated list of completed and failed orders with execution data for the authenticated
    user

    Args:
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):
        status (str | Unset):  Example: pending,canceled.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | GetOrdersResponse]
     """


    kwargs = _get_kwargs(
        limit=limit,
cursor=cursor,
status=status,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    cursor: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,

) -> ErrorResponse | GetOrdersResponse | None:
    """ List user orders

     Returns a paginated list of completed and failed orders with execution data for the authenticated
    user

    Args:
        limit (int | Unset):  Default: 50.
        cursor (datetime.datetime | Unset):
        status (str | Unset):  Example: pending,canceled.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | GetOrdersResponse
     """


    return (await asyncio_detailed(
        client=client,
limit=limit,
cursor=cursor,
status=status,

    )).parsed
