from enum import Enum

class Venue(str, Enum):
    CEFI = "cefi"
    DEFI = "defi"

    def __str__(self) -> str:
        return str(self.value)
