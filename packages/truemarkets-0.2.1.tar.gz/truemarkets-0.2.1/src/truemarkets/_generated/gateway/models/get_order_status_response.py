from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.order_status import OrderStatus
from ..types import UNSET, Unset






T = TypeVar("T", bound="GetOrderStatusResponse")



@_attrs_define
class GetOrderStatusResponse:
    """ Order status response

        Attributes:
            status (OrderStatus | Unset): The current status of the order.
                * **initialized** — Order has been created but not yet submitted. For DeFi orders, the client must sign the
                returned payloads and call the execute endpoint. For CeFi buy orders with insufficient balance, a funding bridge
                is prepared first.
                * **pending** — Order has been submitted but is not yet confirmed by the CeFi exchange or on-chain.
                * **active** — Order was accepted by the CeFi exchange and is open for trading. Applies to limit orders that are
                working in the order book.
                * **cancel_pending** — A cancellation request has been sent to the CeFi exchange and is awaiting confirmation.
                * **complete** — Order has been fully executed. For CeFi orders this means the CeFi exchange reported a fill;
                for DeFi orders the on-chain swap was confirmed.
                * **canceled** — Order was successfully canceled via a cancel request or by exchange/market conditions.
                * **failed** — Order was rejected by the CeFi exchange or DeFi execution failed (e.g. on-chain transaction
                reverted, balance check failed).
                 Example: complete.
     """

    status: OrderStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _status = d.pop("status", UNSET)
        status: OrderStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = OrderStatus(_status)




        get_order_status_response = cls(
            status=status,
        )


        get_order_status_response.additional_properties = d
        return get_order_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
