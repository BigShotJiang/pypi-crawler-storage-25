from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="QuoteDetails")



@_attrs_define
class QuoteDetails:
    """ Detailed quote information returned with DeFi order creation, showing expected swap output and fees

        Attributes:
            base_asset (str | Unset): Base asset identifier (e.g. `SOL`, `ETH`)
            quote_asset (str | Unset): Quote asset identifier (e.g. `USDC`)
            qty (str | Unset): Input quantity as a decimal string — the amount being swapped from
            qty_out (str | Unset): Expected output quantity as a decimal string — the amount the user will receive after
                fees
            fee (str | Unset): Platform fee amount as a decimal string
            fee_asset (str | Unset): Asset in which the fee is denominated (e.g. `USDC`)
            issues (list[str] | Unset): Warnings about the quote (e.g. high price impact, low liquidity). Empty when there
                are no issues.
     """

    base_asset: str | Unset = UNSET
    quote_asset: str | Unset = UNSET
    qty: str | Unset = UNSET
    qty_out: str | Unset = UNSET
    fee: str | Unset = UNSET
    fee_asset: str | Unset = UNSET
    issues: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        base_asset = self.base_asset

        quote_asset = self.quote_asset

        qty = self.qty

        qty_out = self.qty_out

        fee = self.fee

        fee_asset = self.fee_asset

        issues: list[str] | Unset = UNSET
        if not isinstance(self.issues, Unset):
            issues = self.issues




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if base_asset is not UNSET:
            field_dict["base_asset"] = base_asset
        if quote_asset is not UNSET:
            field_dict["quote_asset"] = quote_asset
        if qty is not UNSET:
            field_dict["qty"] = qty
        if qty_out is not UNSET:
            field_dict["qty_out"] = qty_out
        if fee is not UNSET:
            field_dict["fee"] = fee
        if fee_asset is not UNSET:
            field_dict["fee_asset"] = fee_asset
        if issues is not UNSET:
            field_dict["issues"] = issues

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        base_asset = d.pop("base_asset", UNSET)

        quote_asset = d.pop("quote_asset", UNSET)

        qty = d.pop("qty", UNSET)

        qty_out = d.pop("qty_out", UNSET)

        fee = d.pop("fee", UNSET)

        fee_asset = d.pop("fee_asset", UNSET)

        issues = cast(list[str], d.pop("issues", UNSET))


        quote_details = cls(
            base_asset=base_asset,
            quote_asset=quote_asset,
            qty=qty,
            qty_out=qty_out,
            fee=fee,
            fee_asset=fee_asset,
            issues=issues,
        )


        quote_details.additional_properties = d
        return quote_details

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
