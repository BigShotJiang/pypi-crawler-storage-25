from enum import Enum

class TransferStatus(str, Enum):
    AWAITING_SIGNATURE = "awaiting_signature"
    COMPLETED = "completed"
    FAILED = "failed"
    PENDING = "pending"

    def __str__(self) -> str:
        return str(self.value)
