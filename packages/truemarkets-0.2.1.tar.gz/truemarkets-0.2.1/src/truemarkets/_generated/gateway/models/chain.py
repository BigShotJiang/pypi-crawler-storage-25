from enum import Enum

class Chain(str, Enum):
    BASE = "base"
    SOLANA = "solana"

    def __str__(self) -> str:
        return str(self.value)
