from enum import Enum

class CreateOrderRequestQtyUnit(str, Enum):
    BASE = "base"
    QUOTE = "quote"

    def __str__(self) -> str:
        return str(self.value)
