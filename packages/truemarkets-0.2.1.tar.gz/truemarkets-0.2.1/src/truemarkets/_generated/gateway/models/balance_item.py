from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="BalanceItem")



@_attrs_define
class BalanceItem:
    """ A single asset balance on a specific venue

        Attributes:
            symbol (str | Unset): Asset ticker symbol (e.g. BTC, USDC)
            name (str | Unset): Human-readable asset name
            chain (None | str | Unset): Blockchain network ("solana", "base"), or null for exchange-held assets
            address (None | str | Unset): Token contract/mint address, or null for exchange-held assets
            decimals (int | Unset): Display precision (e.g. 8 for BTC, 6 for USDC)
            total (str | Unset): Gross balance including held amounts (decimal string)
            available (str | Unset): Usable balance after holds (decimal string)
            held (str | Unset): Amount locked in orders or transfers (decimal string)
            stable (bool | Unset): Whether this is a stablecoin
            tradeable (bool | Unset): Whether this asset is active for trading
     """

    symbol: str | Unset = UNSET
    name: str | Unset = UNSET
    chain: None | str | Unset = UNSET
    address: None | str | Unset = UNSET
    decimals: int | Unset = UNSET
    total: str | Unset = UNSET
    available: str | Unset = UNSET
    held: str | Unset = UNSET
    stable: bool | Unset = UNSET
    tradeable: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        name = self.name

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        address: None | str | Unset
        if isinstance(self.address, Unset):
            address = UNSET
        else:
            address = self.address

        decimals = self.decimals

        total = self.total

        available = self.available

        held = self.held

        stable = self.stable

        tradeable = self.tradeable


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if name is not UNSET:
            field_dict["name"] = name
        if chain is not UNSET:
            field_dict["chain"] = chain
        if address is not UNSET:
            field_dict["address"] = address
        if decimals is not UNSET:
            field_dict["decimals"] = decimals
        if total is not UNSET:
            field_dict["total"] = total
        if available is not UNSET:
            field_dict["available"] = available
        if held is not UNSET:
            field_dict["held"] = held
        if stable is not UNSET:
            field_dict["stable"] = stable
        if tradeable is not UNSET:
            field_dict["tradeable"] = tradeable

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol", UNSET)

        name = d.pop("name", UNSET)

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))


        def _parse_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        address = _parse_address(d.pop("address", UNSET))


        decimals = d.pop("decimals", UNSET)

        total = d.pop("total", UNSET)

        available = d.pop("available", UNSET)

        held = d.pop("held", UNSET)

        stable = d.pop("stable", UNSET)

        tradeable = d.pop("tradeable", UNSET)

        balance_item = cls(
            symbol=symbol,
            name=name,
            chain=chain,
            address=address,
            decimals=decimals,
            total=total,
            available=available,
            held=held,
            stable=stable,
            tradeable=tradeable,
        )


        balance_item.additional_properties = d
        return balance_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
