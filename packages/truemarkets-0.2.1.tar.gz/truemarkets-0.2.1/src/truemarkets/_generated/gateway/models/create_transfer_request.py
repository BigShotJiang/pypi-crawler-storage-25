from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_transfer_request_qty_unit import CreateTransferRequestQtyUnit
from uuid import UUID






T = TypeVar("T", bound="CreateTransferRequest")



@_attrs_define
class CreateTransferRequest:
    """ Request to create a new on-chain transfer

        Attributes:
            asset_id (UUID): Asset identifier (UUID) Example: b3d9e5f2-1a4c-4e7b-9f0d-2c8a6b3e5f91.
            qty (str): Transfer quantity as a positive decimal string Example: 100.00.
            qty_unit (CreateTransferRequestQtyUnit): Unit of the quantity.
                * **base** — Quantity is denominated in the base asset.
                * **quote** — Quantity is denominated in the quote asset.
                 Example: base.
            to (str): Destination wallet address Example: 0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045.
     """

    asset_id: UUID
    qty: str
    qty_unit: CreateTransferRequestQtyUnit
    to: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        asset_id = str(self.asset_id)

        qty = self.qty

        qty_unit = self.qty_unit.value

        to = self.to


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "asset_id": asset_id,
            "qty": qty,
            "qty_unit": qty_unit,
            "to": to,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        asset_id = UUID(d.pop("asset_id"))




        qty = d.pop("qty")

        qty_unit = CreateTransferRequestQtyUnit(d.pop("qty_unit"))




        to = d.pop("to")

        create_transfer_request = cls(
            asset_id=asset_id,
            qty=qty,
            qty_unit=qty_unit,
            to=to,
        )


        create_transfer_request.additional_properties = d
        return create_transfer_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
