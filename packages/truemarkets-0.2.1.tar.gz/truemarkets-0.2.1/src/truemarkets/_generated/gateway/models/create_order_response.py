from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.order_status import OrderStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.quote_details import QuoteDetails
  from ..models.unsigned_payload import UnsignedPayload





T = TypeVar("T", bound="CreateOrderResponse")



@_attrs_define
class CreateOrderResponse:
    """ Response from creating an order. For DeFi orders (and CeFi buy orders requiring a funding bridge), the response
    includes unsigned payloads that must be signed by the client and submitted via the execute endpoint. For CeFi sell
    orders and sufficiently funded CeFi buy orders, the order is submitted immediately and no payloads are returned.

        Attributes:
            order_id (str | Unset): Unique order identifier
            status (OrderStatus | Unset): The current status of the order.
                * **initialized** — Order has been created but not yet submitted. For DeFi orders, the client must sign the
                returned payloads and call the execute endpoint. For CeFi buy orders with insufficient balance, a funding bridge
                is prepared first.
                * **pending** — Order has been submitted but is not yet confirmed by the CeFi exchange or on-chain.
                * **active** — Order was accepted by the CeFi exchange and is open for trading. Applies to limit orders that are
                working in the order book.
                * **cancel_pending** — A cancellation request has been sent to the CeFi exchange and is awaiting confirmation.
                * **complete** — Order has been fully executed. For CeFi orders this means the CeFi exchange reported a fill;
                for DeFi orders the on-chain swap was confirmed.
                * **canceled** — Order was successfully canceled via a cancel request or by exchange/market conditions.
                * **failed** — Order was rejected by the CeFi exchange or DeFi execution failed (e.g. on-chain transaction
                reverted, balance check failed).
                 Example: complete.
            payloads (list[UnsignedPayload] | Unset): Unsigned transaction payloads that the client must sign and return via
                the execute endpoint. Present for DeFi orders and CeFi buy orders that require a funding bridge. Empty or absent
                when the order is submitted immediately (e.g. CeFi sell orders).
            quote (QuoteDetails | Unset): Detailed quote information returned with DeFi order creation, showing expected
                swap output and fees
            web_authn_payload (str | Unset): WebAuthn payload (deprecated, use payloads instead)
     """

    order_id: str | Unset = UNSET
    status: OrderStatus | Unset = UNSET
    payloads: list[UnsignedPayload] | Unset = UNSET
    quote: QuoteDetails | Unset = UNSET
    web_authn_payload: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.quote_details import QuoteDetails
        from ..models.unsigned_payload import UnsignedPayload
        order_id = self.order_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        payloads: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.payloads, Unset):
            payloads = []
            for payloads_item_data in self.payloads:
                payloads_item = payloads_item_data.to_dict()
                payloads.append(payloads_item)



        quote: dict[str, Any] | Unset = UNSET
        if not isinstance(self.quote, Unset):
            quote = self.quote.to_dict()

        web_authn_payload = self.web_authn_payload


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if order_id is not UNSET:
            field_dict["order_id"] = order_id
        if status is not UNSET:
            field_dict["status"] = status
        if payloads is not UNSET:
            field_dict["payloads"] = payloads
        if quote is not UNSET:
            field_dict["quote"] = quote
        if web_authn_payload is not UNSET:
            field_dict["web_authn_payload"] = web_authn_payload

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.quote_details import QuoteDetails
        from ..models.unsigned_payload import UnsignedPayload
        d = dict(src_dict)
        order_id = d.pop("order_id", UNSET)

        _status = d.pop("status", UNSET)
        status: OrderStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = OrderStatus(_status)




        _payloads = d.pop("payloads", UNSET)
        payloads: list[UnsignedPayload] | Unset = UNSET
        if _payloads is not UNSET:
            payloads = []
            for payloads_item_data in _payloads:
                payloads_item = UnsignedPayload.from_dict(payloads_item_data)



                payloads.append(payloads_item)


        _quote = d.pop("quote", UNSET)
        quote: QuoteDetails | Unset
        if isinstance(_quote,  Unset):
            quote = UNSET
        else:
            quote = QuoteDetails.from_dict(_quote)




        web_authn_payload = d.pop("web_authn_payload", UNSET)

        create_order_response = cls(
            order_id=order_id,
            status=status,
            payloads=payloads,
            quote=quote,
            web_authn_payload=web_authn_payload,
        )


        create_order_response.additional_properties = d
        return create_order_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
