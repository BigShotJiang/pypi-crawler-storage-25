from enum import Enum

class OrderStatus(str, Enum):
    ACTIVE = "active"
    CANCELED = "canceled"
    CANCEL_PENDING = "cancel_pending"
    COMPLETE = "complete"
    FAILED = "failed"
    INITIALIZED = "initialized"
    PENDING = "pending"

    def __str__(self) -> str:
        return str(self.value)
