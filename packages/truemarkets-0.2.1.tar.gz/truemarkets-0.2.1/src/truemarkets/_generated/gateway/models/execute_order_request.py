from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.signing_method import SigningMethod
from typing import cast






T = TypeVar("T", bound="ExecuteOrderRequest")



@_attrs_define
class ExecuteOrderRequest:
    """ Request to execute an order that is in `initialized` status. The client must sign each payload returned by the
    create endpoint and submit the signatures in the same order.

        Attributes:
            signatures (list[str]): Signed stamps for the unsigned payloads, in the same order as the payloads returned by
                the create endpoint. Each signature corresponds to one payload.
            auth_type (SigningMethod): The authentication method used to sign transaction payloads.
                * **web_authn** — Signed using a passkey (WebAuthn/FIDO2 credential) via the browser.
                * **api_key** — Signed using an API key. Suitable for programmatic/headless access.
                 Example: api_key.
     """

    signatures: list[str]
    auth_type: SigningMethod
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        signatures = self.signatures



        auth_type = self.auth_type.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "signatures": signatures,
            "auth_type": auth_type,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        signatures = cast(list[str], d.pop("signatures"))


        auth_type = SigningMethod(d.pop("auth_type"))




        execute_order_request = cls(
            signatures=signatures,
            auth_type=auth_type,
        )


        execute_order_request.additional_properties = d
        return execute_order_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
