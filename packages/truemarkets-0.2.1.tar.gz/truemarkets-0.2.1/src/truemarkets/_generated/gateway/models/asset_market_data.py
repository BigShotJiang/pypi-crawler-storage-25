from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="AssetMarketData")



@_attrs_define
class AssetMarketData:
    """ Supply-side market data

        Attributes:
            circulating_supply (int | Unset):
            total_supply (int | Unset):
            max_supply (int | Unset):
     """

    circulating_supply: int | Unset = UNSET
    total_supply: int | Unset = UNSET
    max_supply: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        circulating_supply = self.circulating_supply

        total_supply = self.total_supply

        max_supply = self.max_supply


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if circulating_supply is not UNSET:
            field_dict["circulating_supply"] = circulating_supply
        if total_supply is not UNSET:
            field_dict["total_supply"] = total_supply
        if max_supply is not UNSET:
            field_dict["max_supply"] = max_supply

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        circulating_supply = d.pop("circulating_supply", UNSET)

        total_supply = d.pop("total_supply", UNSET)

        max_supply = d.pop("max_supply", UNSET)

        asset_market_data = cls(
            circulating_supply=circulating_supply,
            total_supply=total_supply,
            max_supply=max_supply,
        )


        asset_market_data.additional_properties = d
        return asset_market_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
