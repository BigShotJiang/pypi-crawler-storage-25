from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.transfer_detail_qty_unit import TransferDetailQtyUnit
from ..models.transfer_status import TransferStatus
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
  from ..models.unsigned_payload import UnsignedPayload





T = TypeVar("T", bound="TransferDetail")



@_attrs_define
class TransferDetail:
    """ Canonical representation of a transfer.

        Attributes:
            id (UUID): Unique transfer identifier
            status (TransferStatus): The current status of the transfer.
                * **awaiting_signature** — Transfer has been created and is waiting for the client to sign the unsigned payloads
                and call the execute endpoint.
                * **pending** — Signed transaction has been submitted and is awaiting on-chain confirmation.
                * **completed** — Transfer has been confirmed on-chain.
                * **failed** — Transfer failed due to an on-chain error or rejection.
                 Example: pending.
            venue (str): Trading venue (e.g. `defi`)
            asset_id (UUID): Asset identifier
            asset_symbol (str): Asset ticker symbol (e.g. `USDC`, `SOL`)
            chain (None | str): Blockchain network (e.g. `solana`, `base`), or null when the asset has no chain
            to (str): Destination wallet address
            qty (str): Transfer quantity as a decimal string
            qty_unit (TransferDetailQtyUnit): Unit of the quantity
            sent (str): Amount sent as a decimal string
            fee (str): Fee as a decimal string
            received (str): Amount received as a decimal string
            tx_hash (str): On-chain transaction hash
            payloads (list[UnsignedPayload]): Unsigned transaction payloads for the client to sign. Present when status is
                `awaiting_signature`; empty array after execution.
            created_at (datetime.datetime): Timestamp when the transfer was created (RFC 3339)
            updated_at (datetime.datetime): Timestamp of the last status update (RFC 3339)
     """

    id: UUID
    status: TransferStatus
    venue: str
    asset_id: UUID
    asset_symbol: str
    chain: None | str
    to: str
    qty: str
    qty_unit: TransferDetailQtyUnit
    sent: str
    fee: str
    received: str
    tx_hash: str
    payloads: list[UnsignedPayload]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.unsigned_payload import UnsignedPayload
        id = str(self.id)

        status = self.status.value

        venue = self.venue

        asset_id = str(self.asset_id)

        asset_symbol = self.asset_symbol

        chain: None | str
        chain = self.chain

        to = self.to

        qty = self.qty

        qty_unit = self.qty_unit.value

        sent = self.sent

        fee = self.fee

        received = self.received

        tx_hash = self.tx_hash

        payloads = []
        for payloads_item_data in self.payloads:
            payloads_item = payloads_item_data.to_dict()
            payloads.append(payloads_item)



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "status": status,
            "venue": venue,
            "asset_id": asset_id,
            "asset_symbol": asset_symbol,
            "chain": chain,
            "to": to,
            "qty": qty,
            "qty_unit": qty_unit,
            "sent": sent,
            "fee": fee,
            "received": received,
            "tx_hash": tx_hash,
            "payloads": payloads,
            "created_at": created_at,
            "updated_at": updated_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unsigned_payload import UnsignedPayload
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        status = TransferStatus(d.pop("status"))




        venue = d.pop("venue")

        asset_id = UUID(d.pop("asset_id"))




        asset_symbol = d.pop("asset_symbol")

        def _parse_chain(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        chain = _parse_chain(d.pop("chain"))


        to = d.pop("to")

        qty = d.pop("qty")

        qty_unit = TransferDetailQtyUnit(d.pop("qty_unit"))




        sent = d.pop("sent")

        fee = d.pop("fee")

        received = d.pop("received")

        tx_hash = d.pop("tx_hash")

        payloads = []
        _payloads = d.pop("payloads")
        for payloads_item_data in (_payloads):
            payloads_item = UnsignedPayload.from_dict(payloads_item_data)



            payloads.append(payloads_item)


        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        transfer_detail = cls(
            id=id,
            status=status,
            venue=venue,
            asset_id=asset_id,
            asset_symbol=asset_symbol,
            chain=chain,
            to=to,
            qty=qty,
            qty_unit=qty_unit,
            sent=sent,
            fee=fee,
            received=received,
            tx_hash=tx_hash,
            payloads=payloads,
            created_at=created_at,
            updated_at=updated_at,
        )


        transfer_detail.additional_properties = d
        return transfer_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
