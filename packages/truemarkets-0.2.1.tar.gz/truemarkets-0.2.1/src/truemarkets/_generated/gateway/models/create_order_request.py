from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.chain import Chain
from ..models.create_order_request_qty_unit import CreateOrderRequestQtyUnit
from ..models.order_side import OrderSide
from ..models.order_type import OrderType
from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateOrderRequest")



@_attrs_define
class CreateOrderRequest:
    """ Request to create a new order.

    **Limit orders** (`type: limit`):
    - `price` is required and must be a positive decimal string
    - `qty_unit` must be `base`
    - `chain` is not supported (CeFi only)

    **Market orders** (`type: market`):
    - `price` is not accepted
    - Buy orders require `qty_unit: quote`
    - Sell orders accept `qty_unit: base` or `qty_unit: quote`
    - `chain` is optional (omit for CeFi, include for DeFi)

        Attributes:
            base_asset (str): Asset symbol for CeFi (e.g. `BTC`); token contract address on `chain` for DeFi. Example: BTC.
            quote_asset (str): Asset symbol for CeFi (e.g. `USDC`); token contract address on `chain` for DeFi. Example:
                USD.
            qty (str): Quantity as a positive decimal string Example: 100.
            qty_unit (CreateOrderRequestQtyUnit): Unit of the quantity.
                * **base** — Quantity is denominated in the base asset. Required for limit orders. Supported for market sell
                orders.
                * **quote** — Quantity is denominated in the quote asset. Required for market buy orders. For DeFi sell orders,
                `base` must be used instead.
                 Example: quote.
            type_ (OrderType): The type of order to place.
                * **market** — Execute immediately at the best available price. Buy orders require `qty_unit: quote`. Price must
                not be specified.
                * **limit** — Place an order at a specific price. Requires `price` and `qty_unit: base`. Only supported on CeFi;
                `chain` must not be specified.
                 Example: market.
            side (OrderSide): The side of the order.
                * **buy** — Purchase the base asset using the quote asset.
                * **sell** — Sell the base asset in exchange for the quote asset.
                 Example: buy.
            price (str | Unset): Limit price per unit of base asset as a decimal string. Required for limit orders; must not
                be sent for market orders.
                 Example: 67500.00.
            chain (Chain | Unset): The blockchain network for DeFi orders. Omit for CeFi orders.
                * **solana** — Execute the swap on the Solana blockchain.
                * **base** — Execute the swap on the Base (Ethereum L2) blockchain.
                 Example: solana.
     """

    base_asset: str
    quote_asset: str
    qty: str
    qty_unit: CreateOrderRequestQtyUnit
    type_: OrderType
    side: OrderSide
    price: str | Unset = UNSET
    chain: Chain | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        base_asset = self.base_asset

        quote_asset = self.quote_asset

        qty = self.qty

        qty_unit = self.qty_unit.value

        type_ = self.type_.value

        side = self.side.value

        price = self.price

        chain: str | Unset = UNSET
        if not isinstance(self.chain, Unset):
            chain = self.chain.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "base_asset": base_asset,
            "quote_asset": quote_asset,
            "qty": qty,
            "qty_unit": qty_unit,
            "type": type_,
            "side": side,
        })
        if price is not UNSET:
            field_dict["price"] = price
        if chain is not UNSET:
            field_dict["chain"] = chain

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        base_asset = d.pop("base_asset")

        quote_asset = d.pop("quote_asset")

        qty = d.pop("qty")

        qty_unit = CreateOrderRequestQtyUnit(d.pop("qty_unit"))




        type_ = OrderType(d.pop("type"))




        side = OrderSide(d.pop("side"))




        price = d.pop("price", UNSET)

        _chain = d.pop("chain", UNSET)
        chain: Chain | Unset
        if isinstance(_chain,  Unset):
            chain = UNSET
        else:
            chain = Chain(_chain)




        create_order_request = cls(
            base_asset=base_asset,
            quote_asset=quote_asset,
            qty=qty,
            qty_unit=qty_unit,
            type_=type_,
            side=side,
            price=price,
            chain=chain,
        )


        create_order_request.additional_properties = d
        return create_order_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
