from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.order_side import OrderSide
from ..models.order_status import OrderStatus
from ..models.order_type import OrderType
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="OrderDetail")



@_attrs_define
class OrderDetail:
    """ Order with execution data. Returned by the list orders endpoint for completed, canceled, and failed orders. Includes
    fill information from the CeFi exchange for CeFi orders.

        Attributes:
            order_id (str | Unset): Unique order identifier
            base_asset (str | Unset): Base asset identifier (e.g. `BTC`, `ETH`, `SOL`)
            quote_asset (str | Unset): Quote asset identifier (e.g. `USD`, `USDC`)
            type_ (OrderType | Unset): The type of order to place.
                * **market** — Execute immediately at the best available price. Buy orders require `qty_unit: quote`. Price must
                not be specified.
                * **limit** — Place an order at a specific price. Requires `price` and `qty_unit: base`. Only supported on CeFi;
                `chain` must not be specified.
                 Example: market.
            side (OrderSide | Unset): The side of the order.
                * **buy** — Purchase the base asset using the quote asset.
                * **sell** — Sell the base asset in exchange for the quote asset.
                 Example: buy.
            price (str | Unset): For limit orders, the limit price submitted. For market orders, the reference price at
                order creation.
            qty (str | Unset): Original order quantity in the denomination specified by `qty_unit` at creation
            executed_qty (str | Unset): Quantity of the base asset that has been filled so far
            leaves_qty (str | Unset): Remaining base asset quantity yet to be filled. Zero when the order is complete.
            executed_vwap (str | Unset): Volume-weighted average price across all fills for this order
            status (OrderStatus | Unset): The current status of the order.
                * **initialized** — Order has been created but not yet submitted. For DeFi orders, the client must sign the
                returned payloads and call the execute endpoint. For CeFi buy orders with insufficient balance, a funding bridge
                is prepared first.
                * **pending** — Order has been submitted but is not yet confirmed by the CeFi exchange or on-chain.
                * **active** — Order was accepted by the CeFi exchange and is open for trading. Applies to limit orders that are
                working in the order book.
                * **cancel_pending** — A cancellation request has been sent to the CeFi exchange and is awaiting confirmation.
                * **complete** — Order has been fully executed. For CeFi orders this means the CeFi exchange reported a fill;
                for DeFi orders the on-chain swap was confirmed.
                * **canceled** — Order was successfully canceled via a cancel request or by exchange/market conditions.
                * **failed** — Order was rejected by the CeFi exchange or DeFi execution failed (e.g. on-chain transaction
                reverted, balance check failed).
                 Example: complete.
            created_at (datetime.datetime | Unset): Timestamp when the order was created (RFC 3339)
     """

    order_id: str | Unset = UNSET
    base_asset: str | Unset = UNSET
    quote_asset: str | Unset = UNSET
    type_: OrderType | Unset = UNSET
    side: OrderSide | Unset = UNSET
    price: str | Unset = UNSET
    qty: str | Unset = UNSET
    executed_qty: str | Unset = UNSET
    leaves_qty: str | Unset = UNSET
    executed_vwap: str | Unset = UNSET
    status: OrderStatus | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        order_id = self.order_id

        base_asset = self.base_asset

        quote_asset = self.quote_asset

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value


        side: str | Unset = UNSET
        if not isinstance(self.side, Unset):
            side = self.side.value


        price = self.price

        qty = self.qty

        executed_qty = self.executed_qty

        leaves_qty = self.leaves_qty

        executed_vwap = self.executed_vwap

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if order_id is not UNSET:
            field_dict["order_id"] = order_id
        if base_asset is not UNSET:
            field_dict["base_asset"] = base_asset
        if quote_asset is not UNSET:
            field_dict["quote_asset"] = quote_asset
        if type_ is not UNSET:
            field_dict["type"] = type_
        if side is not UNSET:
            field_dict["side"] = side
        if price is not UNSET:
            field_dict["price"] = price
        if qty is not UNSET:
            field_dict["qty"] = qty
        if executed_qty is not UNSET:
            field_dict["executed_qty"] = executed_qty
        if leaves_qty is not UNSET:
            field_dict["leaves_qty"] = leaves_qty
        if executed_vwap is not UNSET:
            field_dict["executed_vwap"] = executed_vwap
        if status is not UNSET:
            field_dict["status"] = status
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        order_id = d.pop("order_id", UNSET)

        base_asset = d.pop("base_asset", UNSET)

        quote_asset = d.pop("quote_asset", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: OrderType | Unset
        if isinstance(_type_,  Unset):
            type_ = UNSET
        else:
            type_ = OrderType(_type_)




        _side = d.pop("side", UNSET)
        side: OrderSide | Unset
        if isinstance(_side,  Unset):
            side = UNSET
        else:
            side = OrderSide(_side)




        price = d.pop("price", UNSET)

        qty = d.pop("qty", UNSET)

        executed_qty = d.pop("executed_qty", UNSET)

        leaves_qty = d.pop("leaves_qty", UNSET)

        executed_vwap = d.pop("executed_vwap", UNSET)

        _status = d.pop("status", UNSET)
        status: OrderStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = OrderStatus(_status)




        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        order_detail = cls(
            order_id=order_id,
            base_asset=base_asset,
            quote_asset=quote_asset,
            type_=type_,
            side=side,
            price=price,
            qty=qty,
            executed_qty=executed_qty,
            leaves_qty=leaves_qty,
            executed_vwap=executed_vwap,
            status=status,
            created_at=created_at,
        )


        order_detail.additional_properties = d
        return order_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
