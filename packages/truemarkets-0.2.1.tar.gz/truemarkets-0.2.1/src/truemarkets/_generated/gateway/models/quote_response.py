from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="QuoteResponse")



@_attrs_define
class QuoteResponse:
    """ Quote computation result with the expected output quantity and execution price

        Attributes:
            qty (str | Unset): Expected output quantity as a decimal string. For a buy order this is the amount of base
                asset received; for a sell order it is the amount of quote asset received. Example: 0.01485.
            price (str | Unset): Effective execution price per unit of base asset as a decimal string Example: 67340.25.
     """

    qty: str | Unset = UNSET
    price: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        qty = self.qty

        price = self.price


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if qty is not UNSET:
            field_dict["qty"] = qty
        if price is not UNSET:
            field_dict["price"] = price

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        qty = d.pop("qty", UNSET)

        price = d.pop("price", UNSET)

        quote_response = cls(
            qty=qty,
            price=price,
        )


        quote_response.additional_properties = d
        return quote_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
