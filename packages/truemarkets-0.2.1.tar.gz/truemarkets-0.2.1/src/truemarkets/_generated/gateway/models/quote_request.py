from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.order_side import OrderSide
from ..models.quote_request_qty_unit import QuoteRequestQtyUnit






T = TypeVar("T", bound="QuoteRequest")



@_attrs_define
class QuoteRequest:
    """ Request to compute a market quote

        Attributes:
            base_asset (str): Base asset identifier (e.g. `BTC`, `ETH`, `SOL`) Example: BTC.
            quote_asset (str): Quote asset identifier (e.g. `USD`, `USDC`) Example: USD.
            qty (str): Quantity as a positive decimal string Example: 0.5.
            qty_unit (QuoteRequestQtyUnit): Unit of the quantity.
                * **base** — Quantity is denominated in the base asset (e.g. 0.5 BTC).
                * **quote** — Quantity is denominated in the quote asset (e.g. 1000 USD).
                 Example: quote.
            side (OrderSide): The side of the order.
                * **buy** — Purchase the base asset using the quote asset.
                * **sell** — Sell the base asset in exchange for the quote asset.
                 Example: buy.
     """

    base_asset: str
    quote_asset: str
    qty: str
    qty_unit: QuoteRequestQtyUnit
    side: OrderSide
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        base_asset = self.base_asset

        quote_asset = self.quote_asset

        qty = self.qty

        qty_unit = self.qty_unit.value

        side = self.side.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "base_asset": base_asset,
            "quote_asset": quote_asset,
            "qty": qty,
            "qty_unit": qty_unit,
            "side": side,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        base_asset = d.pop("base_asset")

        quote_asset = d.pop("quote_asset")

        qty = d.pop("qty")

        qty_unit = QuoteRequestQtyUnit(d.pop("qty_unit"))




        side = OrderSide(d.pop("side"))




        quote_request = cls(
            base_asset=base_asset,
            quote_asset=quote_asset,
            qty=qty,
            qty_unit=qty_unit,
            side=side,
        )


        quote_request.additional_properties = d
        return quote_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
