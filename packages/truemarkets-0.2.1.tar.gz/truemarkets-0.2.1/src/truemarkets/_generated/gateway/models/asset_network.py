from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="AssetNetwork")



@_attrs_define
class AssetNetwork:
    """ A deposit network for a cefi asset, with any additional networks whose deposits route to the same address

        Attributes:
            network (str):
            compatible_networks (list[str]):
     """

    network: str
    compatible_networks: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        network = self.network

        compatible_networks = self.compatible_networks




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "network": network,
            "compatible_networks": compatible_networks,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        network = d.pop("network")

        compatible_networks = cast(list[str], d.pop("compatible_networks"))


        asset_network = cls(
            network=network,
            compatible_networks=compatible_networks,
        )


        asset_network.additional_properties = d
        return asset_network

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
