from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="AssetImage")



@_attrs_define
class AssetImage:
    """ Asset image URLs at various resolutions

        Attributes:
            thumb (str | Unset):
            small (str | Unset):
            large (str | Unset):
     """

    thumb: str | Unset = UNSET
    small: str | Unset = UNSET
    large: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        thumb = self.thumb

        small = self.small

        large = self.large


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if thumb is not UNSET:
            field_dict["thumb"] = thumb
        if small is not UNSET:
            field_dict["small"] = small
        if large is not UNSET:
            field_dict["large"] = large

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        thumb = d.pop("thumb", UNSET)

        small = d.pop("small", UNSET)

        large = d.pop("large", UNSET)

        asset_image = cls(
            thumb=thumb,
            small=small,
            large=large,
        )


        asset_image.additional_properties = d
        return asset_image

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
