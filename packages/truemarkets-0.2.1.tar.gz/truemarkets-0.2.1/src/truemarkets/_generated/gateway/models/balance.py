from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="Balance")



@_attrs_define
class Balance:
    """ Balance for a single asset

        Attributes:
            asset_name (str | Unset): Human-readable asset name
            asset_id (str | Unset): Asset identifier
            balance (str | Unset): Balance amount as decimal string
     """

    asset_name: str | Unset = UNSET
    asset_id: str | Unset = UNSET
    balance: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        asset_name = self.asset_name

        asset_id = self.asset_id

        balance = self.balance


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if asset_name is not UNSET:
            field_dict["asset_name"] = asset_name
        if asset_id is not UNSET:
            field_dict["asset_id"] = asset_id
        if balance is not UNSET:
            field_dict["balance"] = balance

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        asset_name = d.pop("asset_name", UNSET)

        asset_id = d.pop("asset_id", UNSET)

        balance = d.pop("balance", UNSET)

        balance = cls(
            asset_name=asset_name,
            asset_id=asset_id,
            balance=balance,
        )


        balance.additional_properties = d
        return balance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
