from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.venue import Venue
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.asset_image import AssetImage
  from ..models.asset_market_data import AssetMarketData
  from ..models.asset_network import AssetNetwork
  from ..models.asset_socials import AssetSocials





T = TypeVar("T", bound="AssetItem")



@_attrs_define
class AssetItem:
    """ A single tradeable asset

        Attributes:
            networks (list[AssetNetwork]):
            id (str | Unset): Canonical asset identifier (spot_assets UUID)
            chain (None | str | Unset): Blockchain network (null for CeFi assets)
            address (None | str | Unset): Token contract address (null for CeFi assets)
            symbol (str | Unset): Asset ticker symbol (e.g. BTC, SOL)
            name (str | Unset): Human-readable asset name
            decimals (int | Unset): Token decimal precision
            slug (str | Unset): URL-safe asset identifier
            is_active (bool | Unset):
            description (str | Unset):
            website (str | Unset):
            icon (None | str | Unset): Icon image URL
            tradeable (bool | Unset): Whether this asset can be traded directly
            stable (bool | Unset): Whether this is a stablecoin
            venue (Venue | Unset): The trading venue to filter by.
                * **defi** — Decentralized exchange (on-chain swaps).
                * **cefi** — Centralized exchange (off-chain order book).
                 Example: defi.
            image (AssetImage | Unset): Asset image URLs at various resolutions
            market_data (AssetMarketData | Unset): Supply-side market data
            socials (AssetSocials | Unset): Social media links
     """

    networks: list[AssetNetwork]
    id: str | Unset = UNSET
    chain: None | str | Unset = UNSET
    address: None | str | Unset = UNSET
    symbol: str | Unset = UNSET
    name: str | Unset = UNSET
    decimals: int | Unset = UNSET
    slug: str | Unset = UNSET
    is_active: bool | Unset = UNSET
    description: str | Unset = UNSET
    website: str | Unset = UNSET
    icon: None | str | Unset = UNSET
    tradeable: bool | Unset = UNSET
    stable: bool | Unset = UNSET
    venue: Venue | Unset = UNSET
    image: AssetImage | Unset = UNSET
    market_data: AssetMarketData | Unset = UNSET
    socials: AssetSocials | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.asset_image import AssetImage
        from ..models.asset_market_data import AssetMarketData
        from ..models.asset_network import AssetNetwork
        from ..models.asset_socials import AssetSocials
        networks = []
        for networks_item_data in self.networks:
            networks_item = networks_item_data.to_dict()
            networks.append(networks_item)



        id = self.id

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        address: None | str | Unset
        if isinstance(self.address, Unset):
            address = UNSET
        else:
            address = self.address

        symbol = self.symbol

        name = self.name

        decimals = self.decimals

        slug = self.slug

        is_active = self.is_active

        description = self.description

        website = self.website

        icon: None | str | Unset
        if isinstance(self.icon, Unset):
            icon = UNSET
        else:
            icon = self.icon

        tradeable = self.tradeable

        stable = self.stable

        venue: str | Unset = UNSET
        if not isinstance(self.venue, Unset):
            venue = self.venue.value


        image: dict[str, Any] | Unset = UNSET
        if not isinstance(self.image, Unset):
            image = self.image.to_dict()

        market_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.market_data, Unset):
            market_data = self.market_data.to_dict()

        socials: dict[str, Any] | Unset = UNSET
        if not isinstance(self.socials, Unset):
            socials = self.socials.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "networks": networks,
        })
        if id is not UNSET:
            field_dict["id"] = id
        if chain is not UNSET:
            field_dict["chain"] = chain
        if address is not UNSET:
            field_dict["address"] = address
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if name is not UNSET:
            field_dict["name"] = name
        if decimals is not UNSET:
            field_dict["decimals"] = decimals
        if slug is not UNSET:
            field_dict["slug"] = slug
        if is_active is not UNSET:
            field_dict["is_active"] = is_active
        if description is not UNSET:
            field_dict["description"] = description
        if website is not UNSET:
            field_dict["website"] = website
        if icon is not UNSET:
            field_dict["icon"] = icon
        if tradeable is not UNSET:
            field_dict["tradeable"] = tradeable
        if stable is not UNSET:
            field_dict["stable"] = stable
        if venue is not UNSET:
            field_dict["venue"] = venue
        if image is not UNSET:
            field_dict["image"] = image
        if market_data is not UNSET:
            field_dict["market_data"] = market_data
        if socials is not UNSET:
            field_dict["socials"] = socials

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset_image import AssetImage
        from ..models.asset_market_data import AssetMarketData
        from ..models.asset_network import AssetNetwork
        from ..models.asset_socials import AssetSocials
        d = dict(src_dict)
        networks = []
        _networks = d.pop("networks")
        for networks_item_data in (_networks):
            networks_item = AssetNetwork.from_dict(networks_item_data)



            networks.append(networks_item)


        id = d.pop("id", UNSET)

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))


        def _parse_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        address = _parse_address(d.pop("address", UNSET))


        symbol = d.pop("symbol", UNSET)

        name = d.pop("name", UNSET)

        decimals = d.pop("decimals", UNSET)

        slug = d.pop("slug", UNSET)

        is_active = d.pop("is_active", UNSET)

        description = d.pop("description", UNSET)

        website = d.pop("website", UNSET)

        def _parse_icon(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon = _parse_icon(d.pop("icon", UNSET))


        tradeable = d.pop("tradeable", UNSET)

        stable = d.pop("stable", UNSET)

        _venue = d.pop("venue", UNSET)
        venue: Venue | Unset
        if isinstance(_venue,  Unset):
            venue = UNSET
        else:
            venue = Venue(_venue)




        _image = d.pop("image", UNSET)
        image: AssetImage | Unset
        if isinstance(_image,  Unset):
            image = UNSET
        else:
            image = AssetImage.from_dict(_image)




        _market_data = d.pop("market_data", UNSET)
        market_data: AssetMarketData | Unset
        if isinstance(_market_data,  Unset):
            market_data = UNSET
        else:
            market_data = AssetMarketData.from_dict(_market_data)




        _socials = d.pop("socials", UNSET)
        socials: AssetSocials | Unset
        if isinstance(_socials,  Unset):
            socials = UNSET
        else:
            socials = AssetSocials.from_dict(_socials)




        asset_item = cls(
            networks=networks,
            id=id,
            chain=chain,
            address=address,
            symbol=symbol,
            name=name,
            decimals=decimals,
            slug=slug,
            is_active=is_active,
            description=description,
            website=website,
            icon=icon,
            tradeable=tradeable,
            stable=stable,
            venue=venue,
            image=image,
            market_data=market_data,
            socials=socials,
        )


        asset_item.additional_properties = d
        return asset_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
