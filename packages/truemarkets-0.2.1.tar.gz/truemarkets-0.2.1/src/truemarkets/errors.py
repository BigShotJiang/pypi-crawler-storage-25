class TrueMarketsError(Exception):
    """Base exception for the truemarkets SDK."""


class APIError(TrueMarketsError):
    def __init__(self, status_code: int, body: object, message: str = ""):
        self.status_code = status_code
        self.body = body
        super().__init__(message or f"HTTP {status_code}: {body!r}")


class NotAuthenticated(TrueMarketsError):
    pass
