"""
Auth helpers — key loading, ES256 signing, Turnkey stamping, and JWT mint/
refresh via the generated auth-api client.
"""
import base64
import json
import time
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from truemarkets.config import Config
from truemarkets.errors import APIError
from truemarkets._generated.authapi.api.api_key_authentication.exchange_api_key_token import (
    sync_detailed as _exchange_token,
)
from truemarkets._generated.authapi.api.token.refresh_token import sync_detailed as _refresh_token
from truemarkets._generated.authapi.client import Client as _AuthApiClient
from truemarkets._generated.authapi.models import (
    APIKeyTokenExchangeRequest,
    RefreshTokenRequest,
)


JWK_SUPPORTED_KTY = "EC"
JWK_SUPPORTED_CRV = "P-256"


def load_private_key_jwk(jwk: dict) -> ec.EllipticCurvePrivateKey:
    if jwk.get("kty") != JWK_SUPPORTED_KTY or jwk.get("crv") != JWK_SUPPORTED_CRV:
        raise ValueError(
            f"Unsupported JWK: kty={jwk.get('kty')!r} crv={jwk.get('crv')!r} "
            f"(expected {JWK_SUPPORTED_KTY}/{JWK_SUPPORTED_CRV})."
        )
    if "d" not in jwk:
        raise ValueError("JWK is missing private scalar 'd'.")
    d = int.from_bytes(_b64u_decode(jwk["d"]), "big")
    return ec.derive_private_key(d, ec.SECP256R1())


def load_key_file(path: str | Path) -> tuple[str, ec.EllipticCurvePrivateKey]:
    """
    Load a True Markets API key JSON bundle (key_id + private_key JWK) as
    downloaded from truemarkets.co Settings → API Keys. Returns (key_id, key).
    """
    p = Path(path).expanduser()
    bundle = json.loads(p.read_text())
    key_id = bundle.get("key_id")
    pk = bundle.get("private_key")
    if not key_id or not isinstance(pk, dict):
        raise ValueError(
            f"{p}: expected JSON with 'key_id' (str) and 'private_key' (JWK dict)."
        )
    algo = bundle.get("algorithm")
    if algo and algo != "ES256":
        raise ValueError(f"{p}: unsupported algorithm {algo!r} (expected ES256).")
    return key_id, load_private_key_jwk(pk)


def turnkey_stamp(key: ec.EllipticCurvePrivateKey, payload: bytes) -> str:
    """
    Compute a Turnkey API stamp over `payload`.

    Format (per docs.turnkey.com api-key-stamper):
        base64url(JSON({
          publicKey: <P-256 compressed-point hex>,
          signature: <ECDSA DER hex>,
          scheme:    "SIGNATURE_SCHEME_TK_API_P256",
        }))
    """
    der = key.sign(payload, ec.ECDSA(hashes.SHA256()))
    pub = key.public_key().public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.CompressedPoint,
    )
    stamp = {
        "publicKey": pub.hex(),
        "signature": der.hex(),
        "scheme": "SIGNATURE_SCHEME_TK_API_P256",
    }
    return _b64u(json.dumps(stamp).encode())


def sign_challenge(
    key: ec.EllipticCurvePrivateKey, key_id: str, timestamp: int
) -> str:
    """
    ES256 signature of `{key_id}.{timestamp}` per the Auth tutorial. Converts
    the DER output `cryptography` produces into JOSE raw r||s before
    base64url-encoding.
    """
    message = f"{key_id}.{timestamp}".encode("utf-8")
    der = key.sign(message, ec.ECDSA(hashes.SHA256()))
    r, s = decode_dss_signature(der)
    raw = r.to_bytes(32, "big") + s.to_bytes(32, "big")
    return _b64u(raw)


def mint_token(cfg: Config, key: ec.EllipticCurvePrivateKey, key_id: str) -> dict:
    """POST /v1/auth/api-key/token — exchange ES256-signed challenge for tokens."""
    ts = int(time.time())
    body = APIKeyTokenExchangeRequest(
        key_id=key_id,
        timestamp=ts,
        signature=sign_challenge(key, key_id, ts),
    )
    with _AuthApiClient(base_url=cfg.auth_base, timeout=30) as auth:
        resp = _exchange_token(client=auth, body=body)
    return _unwrap_tokens(resp)


def refresh_token(cfg: Config, refresh: str) -> dict:
    """POST /v1/auth/token/refresh — exchange refresh token for fresh access/refresh pair."""
    with _AuthApiClient(base_url=cfg.auth_base, timeout=30) as auth:
        resp = _refresh_token(client=auth, body=RefreshTokenRequest(refresh_token=refresh))
    return _unwrap_tokens(resp)


def _unwrap_tokens(resp) -> dict:
    if resp.status_code >= 400:
        raise APIError(int(resp.status_code), resp.content)
    parsed = resp.parsed
    return {
        "access_token": getattr(parsed, "access_token", None),
        "refresh_token": getattr(parsed, "refresh_token", None),
    }


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)
