"""
SDK entry point.

`Client.gateway.<operation_id>(body=...)` and `Client.defi.<operation_id>(...)`
resolve to the `sync()` functions auto-generated from the True Markets
OpenAPI specs. Auth (JWT mint + 401-refresh) and Turnkey stamping are handled
here; everything else is the spec talking.
"""
import importlib
import pkgutil
import time
from functools import partial
from types import SimpleNamespace
from typing import Any

import httpx
from cryptography.hazmat.primitives.asymmetric import ec

from truemarkets.auth import load_key_file, mint_token, refresh_token, turnkey_stamp
from truemarkets.config import Config
from truemarkets.errors import NotAuthenticated
from truemarkets.telemetry import SDK_VERSION, Telemetry, jwt_subject, jwt_uid


USER_AGENT = f"truemarkets-python/{SDK_VERSION}"


class Client:
    """SDK Client: per-spec authenticated http clients + bound operation namespaces."""

    def __init__(
        self,
        cfg: Config | None = None,
        *,
        key_file: str | None = None,
        telemetry: Telemetry | None = None,
    ):
        self.cfg = cfg or Config.from_env()
        self.key_file = key_file or self.cfg.key_file
        # Tests can inject a spy; everyone else gets the env-driven default.
        self.telemetry = telemetry if telemetry is not None else Telemetry()

        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._key: ec.EllipticCurvePrivateKey | None = None
        self._key_id: str | None = None

        # Generated `AuthenticatedClient`s, configured with our auth-aware httpx.Auth.
        from truemarkets._generated.gateway import api as _gateway_api
        from truemarkets._generated.gateway.client import AuthenticatedClient as _GAuth
        from truemarkets._generated.defi import api as _defi_api
        from truemarkets._generated.defi.client import AuthenticatedClient as _DAuth

        bearer = _BearerRefreshAuth(self)
        # httpx event hooks fire on every request/response — see _on_request /
        # _on_response below. We pin the latency timer on the request object
        # under a private extension key.
        event_hooks = {
            "request": [self._on_request],
            "response": [self._on_response],
        }
        httpx_args: dict[str, Any] = {
            "auth": bearer,
            "timeout": 30,
            "headers": {"User-Agent": USER_AGENT},
            "event_hooks": event_hooks,
        }

        # Gateway server URL = base + /v1/conductor (paths in spec are bare `/orders`, etc.)
        self._gateway_authed = _GAuth(
            base_url=self.cfg.gateway_base,
            token="",  # placeholder — overridden per-request by _BearerRefreshAuth
            httpx_args=httpx_args,
        )
        # DeFi paths in the spec include the `/v1/defi/core` prefix, so baseUrl is bare.
        self._defi_authed = _DAuth(
            base_url=self.cfg.base_url,
            token="",
            httpx_args=httpx_args,
        )

        self.gateway = _bind_api(self._gateway_authed, _gateway_api)
        self.defi = _bind_api(self._defi_authed, _defi_api)

        import sys
        self.telemetry.capture(
            "sdk_initialized",
            {"runtime": f"python-{sys.version_info.major}.{sys.version_info.minor}"},
        )

    # --- auth -----------------------------------------------------------------

    def authenticate(self) -> None:
        """Load the API key (if not already cached) and mint a fresh token pair."""
        if not self.key_file:
            raise NotAuthenticated(
                "Set TM_KEY_FILE (or pass key_file= to Client) to the JSON "
                "bundle from truemarkets.co → Settings → API Keys."
            )
        was_first_auth = self._access_token is None
        if self._key is None or self._key_id is None:
            self._key_id, self._key = load_key_file(self.key_file)
            # Promote distinct_id from process-UUID → hashed key_id before
            # the JWT exists. Bridges pre-auth events to the same user.
            self.telemetry.set_api_key_id(self._key_id)
        tokens = mint_token(self.cfg, self._key, self._key_id)
        self._access_token = tokens["access_token"]
        self._refresh_token = tokens.get("refresh_token")
        # Promote identity to the JWT's raw `uid` (stable user UUID). The
        # `sub` claim (typically the user's email) is passed in so PostHog
        # attaches a hashed_email person property — handy for cohorting
        # without putting the raw email into telemetry.
        uid = jwt_uid(self._access_token)
        sub = jwt_subject(self._access_token)
        if uid:
            self.telemetry.set_user_identity(uid, sub)
        self.telemetry.capture("sdk_authenticated", {"is_refresh": not was_first_auth})

    def sign_turnkey(self, payload: bytes | str) -> str:
        """Stamp a Turnkey activity payload with the cached API key."""
        if self._key is None:
            self.authenticate()
        body = payload.encode() if isinstance(payload, str) else payload
        return turnkey_stamp(self._key, body)

    def _refresh_jwt(self) -> None:
        """Refresh the access token using the cached refresh token."""
        if not self._refresh_token:
            self.authenticate()
            return
        tokens = refresh_token(self.cfg, self._refresh_token)
        self._access_token = tokens["access_token"]
        if tokens.get("refresh_token"):
            self._refresh_token = tokens["refresh_token"]

    # --- context manager (closes the underlying httpx clients) ----------------

    def close(self) -> None:
        self._gateway_authed.get_httpx_client().close()
        self._defi_authed.get_httpx_client().close()
        self.telemetry.shutdown()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # --- telemetry httpx event hooks ------------------------------------------

    def _on_request(self, request: httpx.Request) -> None:
        # Stash the start time on the request; httpx exposes a writeable
        # `extensions` dict that round-trips to the matching response.
        request.extensions["tm_started_monotonic"] = time.monotonic()

    def _on_response(self, response: httpx.Response) -> None:
        request = response.request
        started = request.extensions.get("tm_started_monotonic")
        latency_ms = int((time.monotonic() - started) * 1000) if started is not None else None
        self.telemetry.capture(
            "sdk_request",
            {
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "latency_ms": latency_ms,
                "ok": response.is_success,
            },
        )


class _BearerRefreshAuth(httpx.Auth):
    """httpx.Auth flow that injects the SDK's current token and refreshes on 401."""

    requires_response_body = False

    def __init__(self, sdk: Client):
        self._sdk = sdk

    def auth_flow(self, request):
        # Lazily authenticate if the user has a key file but hasn't authed yet.
        if self._sdk._access_token is None and self._sdk.key_file:
            self._sdk.authenticate()
        if self._sdk._access_token:
            request.headers["Authorization"] = f"Bearer {self._sdk._access_token}"
        response = yield request

        if response.status_code == 401 and self._sdk._refresh_token:
            try:
                self._sdk._refresh_jwt()
            except Exception:
                return  # fall through with the original 401
            request.headers["Authorization"] = f"Bearer {self._sdk._access_token}"
            yield request


def _bind_api(authed_client: Any, api_pkg) -> SimpleNamespace:
    """
    Walk `api_pkg.<tag>.<operation>` modules and attach each module's `sync`
    function to the returned namespace as an attribute, with `client` pre-bound.

    Example: gateway.api.orders.create_order.sync becomes ns.create_order.
    """
    ns = SimpleNamespace()
    for _, tag_name, ispkg in pkgutil.iter_modules(api_pkg.__path__):
        if not ispkg:
            continue
        tag_module = importlib.import_module(f"{api_pkg.__name__}.{tag_name}")
        for _, op_name, _ispkg in pkgutil.iter_modules(tag_module.__path__):
            op_module = importlib.import_module(f"{tag_module.__name__}.{op_name}")
            sync_fn = getattr(op_module, "sync", None)
            if callable(sync_fn):
                setattr(ns, op_name, partial(sync_fn, client=authed_client))
    return ns
