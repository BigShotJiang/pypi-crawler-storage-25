"""
Get a Gateway quote for buying $25 of BTC with USDC.

Gateway quotes are CeFi-only. Use symbols, not addresses.
"""
from truemarkets import Client
from truemarkets._generated.gateway.models import (
    OrderSide,
    QuoteRequest,
    QuoteRequestQtyUnit,
)


with Client() as c:
    q = c.gateway.compute_quote(body=QuoteRequest(
        base_asset="BTC", quote_asset="USDC",
        qty="25", qty_unit=QuoteRequestQtyUnit.QUOTE, side=OrderSide.BUY,
    ))

print(f"buy 25 USDC of BTC  →  {q.qty} BTC @ {q.price} USDC/BTC")
