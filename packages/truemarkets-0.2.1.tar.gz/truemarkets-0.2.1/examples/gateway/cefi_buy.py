"""
Buy $5 of BTC with USDC on the Gateway.

Edit SIDE / QTY / QTY_UNIT to change the trade. To actually place the order,
set EXECUTE=True.
"""
from truemarkets import Client
from truemarkets._generated.gateway.models import (
    CreateOrderRequest,
    CreateOrderRequestQtyUnit,
    OrderSide,
    OrderType,
    QuoteRequest,
    QuoteRequestQtyUnit,
)


SIDE = OrderSide.BUY
QTY = "5"
QTY_UNIT_QUOTE = QuoteRequestQtyUnit.QUOTE
QTY_UNIT_ORDER = CreateOrderRequestQtyUnit.QUOTE
EXECUTE = False


with Client() as c:
    # 1. Quote — what would this cost right now?
    q = c.gateway.compute_quote(body=QuoteRequest(
        base_asset="BTC", quote_asset="USDC",
        qty=QTY, qty_unit=QTY_UNIT_QUOTE, side=SIDE,
    ))
    print(f"quote: {SIDE} {QTY} (quote)  →  {q.qty} BTC @ {q.price} USDC")

    if not EXECUTE:
        print("set EXECUTE=True to place the order")
        raise SystemExit

    # 2. Place a market order.
    order = c.gateway.create_order(body=CreateOrderRequest(
        base_asset="BTC", quote_asset="USDC",
        qty=QTY, qty_unit=QTY_UNIT_ORDER, side=SIDE,
        type_=OrderType.MARKET,
    ))
    print(f"order: {order}")
    if not order.order_id:
        raise RuntimeError("createOrder did not return an order_id")

    # 3. Read its final state.
    print(f"status: {c.gateway.get_order_status(id=order.order_id)}")
