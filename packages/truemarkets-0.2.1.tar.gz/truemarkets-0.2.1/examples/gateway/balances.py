"""
Show your unified Gateway balances (CeFi + DeFi aggregated).
"""
from truemarkets import Client


with Client() as c:
    result = c.gateway.list_balances()

for r in result.data or []:
    sym = (r.symbol or "?").ljust(8)
    chain = (r.chain or "cefi").ljust(8)
    print(f"  {sym} {chain} total={r.total}")
