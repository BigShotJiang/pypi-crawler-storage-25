"""
List the tradeable asset universe on Gateway.

The spec doesn't document pagination params on /assets — we just take whatever
the server returns in one call.
"""
from truemarkets import Client


with Client() as c:
    result = c.gateway.list_assets()

items = result.data or []
print(f"{len(items)} assets")
for a in items[:10]:
    sym = (a.symbol or "?").ljust(8)
    chain = (a.chain or "cefi").ljust(8)
    print(f"  {sym} {chain} {a.name}")
