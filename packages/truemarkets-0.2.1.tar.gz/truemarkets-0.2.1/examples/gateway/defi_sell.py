"""
Sell MORPHO for USDC on Base via Gateway's DeFi route.

DeFi orders return `payloads` that must be signed with a Turnkey API stamp
before /execute. The flow:
  1. create_order with addresses + chain=base   → order_id + payloads
  2. stamp each payload with the cached P-256 key
  3. execute_order                              → sends stamps back

DeFi assets must be referenced by token address. Set EXECUTE=True to actually
trade.
"""
import time

from truemarkets import Client
from truemarkets._generated.gateway.models import (
    Chain,
    CreateOrderRequest,
    CreateOrderRequestQtyUnit,
    ExecuteOrderRequest,
    OrderSide,
    OrderType,
    SigningMethod,
)


CHAIN = Chain.BASE
BASE_ASSET = "0xbaa5cc21fd487b8fcc2f632f3f4e8d37262a0842"   # MORPHO
QUOTE_ASSET = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913"  # USDC
QTY = "0.55"          # MORPHO; need ≥ ~0.5 to clear the $1 trade floor
EXECUTE = False
TERMINAL = {"complete", "canceled", "cancelled", "rejected", "expired"}


with Client() as c:
    # 1. Prepare the order. DeFi route returns `initialized` + payloads.
    created = c.gateway.create_order(body=CreateOrderRequest(
        base_asset=BASE_ASSET, quote_asset=QUOTE_ASSET,
        qty=QTY, qty_unit=CreateOrderRequestQtyUnit.BASE, side=OrderSide.SELL,
        type_=OrderType.MARKET, chain=CHAIN,
    ))
    quote = getattr(created, "quote", None)
    if quote:
        print(f"quote: sell {QTY} MORPHO  →  {quote.qty_out} USDC  (fee {quote.fee})")
        if quote.issues:
            print(f"issues: {quote.issues}")
            raise SystemExit

    # 2. Stamp each payload (P-256 ECDSA over the Turnkey activity body).
    stamps = [c.sign_turnkey(p.payload) for p in (created.payloads or [])]
    print(f"signed {len(stamps)} payload(s)")

    if not EXECUTE:
        print("set EXECUTE=True to submit /execute and finalize the trade")
        raise SystemExit
    if not created.order_id:
        raise RuntimeError("createOrder did not return an order_id")

    # 3. Submit and poll until terminal.
    c.gateway.execute_order(
        id=created.order_id,
        body=ExecuteOrderRequest(signatures=stamps, auth_type=SigningMethod.API_KEY),
    )
    deadline = time.time() + 120
    last = None
    while time.time() < deadline:
        cur = c.gateway.get_order_status(id=created.order_id)
        s = (getattr(cur, "status", "") or "").lower()
        if s != last:
            print(f"  status: {s}")
            last = s
        if s in TERMINAL:
            break
        time.sleep(2)
