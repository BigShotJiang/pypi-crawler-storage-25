"""
Place a BTC/USDC limit buy at 50% below market, then cancel it.

The order sits in `pending` (won't fill at half-market), giving us a clean
window to demonstrate cancel. Lifecycle observed on Gateway:
    pending → active → cancel_pending → canceled
Cancel is async and can take 1–2 minutes.

Set EXECUTE=True to actually place the order.
"""
import time
from decimal import Decimal

from truemarkets import Client
from truemarkets._generated.gateway.models import (
    CreateOrderRequest,
    CreateOrderRequestQtyUnit,
    OrderSide,
    OrderType,
    QuoteRequest,
    QuoteRequestQtyUnit,
)


QTY_BASE = "0.0001"
EXECUTE = False
TERMINAL = {"complete", "canceled", "cancelled", "rejected", "expired"}


with Client() as c:
    # 1. Anchor on current market price.
    ref = c.gateway.compute_quote(body=QuoteRequest(
        base_asset="BTC", quote_asset="USDC",
        qty=QTY_BASE, qty_unit=QuoteRequestQtyUnit.BASE, side=OrderSide.BUY,
    ))
    if not ref.price:
        raise RuntimeError("quote did not return a price")
    market = Decimal(ref.price)
    limit = (market / 2).quantize(Decimal("1"))
    commit = Decimal(QTY_BASE) * limit
    print(f"market ≈ {market}, limit {limit} ({QTY_BASE} BTC, commit ~${commit})")

    if not EXECUTE:
        print("set EXECUTE=True to place the order")
        raise SystemExit

    # 2. Place the limit order.
    order = c.gateway.create_order(body=CreateOrderRequest(
        base_asset="BTC", quote_asset="USDC",
        qty=QTY_BASE, qty_unit=CreateOrderRequestQtyUnit.BASE, side=OrderSide.BUY,
        type_=OrderType.LIMIT, price=str(limit),
    ))
    if not order.order_id:
        raise RuntimeError("createOrder did not return an order_id")
    print(f"placed: {order}")

    # 3. Cancel and poll until terminal.
    c.gateway.cancel_order(id=order.order_id)
    deadline = time.time() + 180
    last = None
    while time.time() < deadline:
        cur = c.gateway.get_order_status(id=order.order_id)
        s = (getattr(cur, "status", "") or "").lower()
        if s != last:
            print(f"  status: {s}")
            last = s
        if s in TERMINAL:
            break
        time.sleep(1)
