#!/bin/bash
# Regenerate _generated/{gateway,defi,authapi,marketdata}/ from the curated specs.
#
# Assumes _filtered/apis/ already exists — run `make filter` (or
# scripts/filter-specs.sh) first, or use `make codegen-py`.
set -euo pipefail

PYTHON_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK_ROOT="$(cd "$PYTHON_ROOT/.." && pwd)"
FILTERED="$SDK_ROOT/_filtered/apis"
OUT="$PYTHON_ROOT/src/truemarkets/_generated"
CFG="$PYTHON_ROOT/codegen"

if [ ! -d "$FILTERED" ]; then
  echo "error: $FILTERED not found — run \`make filter\` first." >&2
  exit 1
fi

OPC="${OPENAPI_PYTHON_CLIENT:-openapi-python-client}"

rm -rf "$OUT/gateway" "$OUT/defi" "$OUT/authapi" "$OUT/marketdata"
mkdir -p "$OUT"
touch "$OUT/__init__.py"

cd "$OUT"
"$OPC" generate --path "$FILTERED/gateway.yaml"    --meta none --config "$CFG/gateway.yaml"    --overwrite
"$OPC" generate --path "$FILTERED/defi.yaml"       --meta none --config "$CFG/defi.yaml"       --overwrite
"$OPC" generate --path "$FILTERED/auth.yaml"       --meta none --config "$CFG/auth.yaml"       --overwrite
"$OPC" generate --path "$FILTERED/marketdata.yaml" --meta none --config "$CFG/marketdata.yaml" --overwrite

echo "Generated $OUT/{gateway,defi,authapi,marketdata}/"
