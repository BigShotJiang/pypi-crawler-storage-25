#!/usr/bin/env python3
"""Mint a PyPI token via OIDC trusted publishing and upload dist/ with twine.

Replaces pypa/gh-action-pypi-publish in .github/workflows/publish-pypi.yml.
That action spawns its own Docker container via the host's docker.sock,
which breaks on our self-hosted runner because the runner can't resolve
bind-mount paths into the nested container.

Expects:
  - GitHub Actions OIDC env vars: ACTIONS_ID_TOKEN_REQUEST_URL,
    ACTIONS_ID_TOKEN_REQUEST_TOKEN (provided when the job sets
    `permissions: id-token: write`).
  - twine on PATH.
  - Built sdist + wheel in ./dist (overridable as argv[1]).
"""
import json
import os
import subprocess
import sys
import urllib.request


def main() -> int:
    dist_dir = sys.argv[1] if len(sys.argv) > 1 else "dist"

    req = urllib.request.Request(
        f"{os.environ['ACTIONS_ID_TOKEN_REQUEST_URL']}&audience=pypi",
        headers={
            "Authorization": f"bearer {os.environ['ACTIONS_ID_TOKEN_REQUEST_TOKEN']}",
        },
    )
    oidc_token = json.load(urllib.request.urlopen(req))["value"]

    req = urllib.request.Request(
        "https://pypi.org/_/oidc/mint-token",
        method="POST",
        data=json.dumps({"token": oidc_token}).encode(),
        headers={"Content-Type": "application/json"},
    )
    api_token = json.load(urllib.request.urlopen(req))["token"]

    # Workflow log mask — prevents the token from leaking via twine's output.
    print(f"::add-mask::{api_token}", flush=True)

    dist_files = sorted(
        os.path.join(dist_dir, f) for f in os.listdir(dist_dir)
    )
    if not dist_files:
        print(f"No files in {dist_dir}/ to upload", file=sys.stderr)
        return 1

    env = {**os.environ, "TWINE_USERNAME": "__token__", "TWINE_PASSWORD": api_token}
    subprocess.run(
        ["twine", "upload", "--verbose", "--non-interactive", *dist_files],
        env=env,
        check=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
