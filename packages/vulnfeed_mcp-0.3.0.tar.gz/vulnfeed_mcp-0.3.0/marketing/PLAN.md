# VulnFeed Marketing Plan

## Channels

### 1. MCP Directories (primary discovery — do first)
- mcp.so, glama.ai, Smithery — organic discovery from devs browsing MCP servers
- Free tier (10 scans/day, 1 project) lowers barrier to try
- Listing content at `marketplace/listing.md`
- **Status:** Listing content drafted, submission pending (requires manual web form/signup)

### 2. X (@InfaiHq) — starts after May 29
Power Pack batch finishes May 29. VulnFeed batch starts May 30.

**Approach:** Same 2/day cadence (14:00 + 21:00 UTC) for 5-6 days. Value-first: show what the tool finds, not "buy now." Link to vulnfeed.novadyne.ai (free rubric on landing page + buy CTA).

**Tone:** Technical, direct. Security audience expects credibility, not hype. Show real scan output, real CVE data, real EPSS scores. "Your express@4.17.1 has 2 known vulns. Here's what EPSS says about them."

### 3. Reddit / Hacker News (organic, not ads)
- r/ClaudeAI, r/MCP, r/netsec — one post each when listing is live
- "Show HN: VulnFeed — MCP server for dependency vulnerability scanning"
- Only if we have a free tier story worth telling (we do)

### 4. Claude Code community
- Claude Code Discord / community forums if they exist
- "Here's an MCP server I built that scans your deps for vulns"

---

## X Post Batch — VulnFeed (10 posts, May 30 – Jun 4)

### vf-01 (May 30, 14:00 UTC) — Launch announcement
Your dependencies have vulnerabilities you don't know about.

VulnFeed is an MCP server for Claude Code that reads your lockfile, checks NVD + GitHub Advisories, and tells you what actually matters — prioritized by exploit probability.

Free to try: vulnfeed.novadyne.ai

### vf-02 (May 30, 21:00 UTC) — EPSS angle
Most vulnerability scanners drown you in CVEs. 80% will never be exploited.

VulnFeed uses EPSS (Exploit Prediction Scoring System) to surface the ones that matter. A CVE with 0.2% EPSS is noise. A CVE with 73% EPSS is your morning priority.

vulnfeed.novadyne.ai

### vf-03 (May 31, 14:00 UTC) — Price comparison
Snyk Team: $25/dev/mo
GitHub Advanced Security: $49/committer/mo
VulnFeed: $14/mo flat — not per-seat

Same data sources (NVD, GHSA, EPSS). Native to Claude Code. Knows your actual deps.

vulnfeed.novadyne.ai

### vf-04 (May 31, 21:00 UTC) — Demo output
What VulnFeed finds in a typical Node.js project:

lodash@4.17.20 — Command Injection (EPSS: 4.3%)
  Fix: upgrade to 4.17.21

express@4.17.1 — Open Redirect (EPSS: 0.15%)
  Fix: upgrade to 4.19.2

9 lockfile formats. npm, PyPI, Go, Rust, Ruby, PHP.

### vf-05 (Jun 1, 14:00 UTC) — Monitoring angle
VulnFeed doesn't just scan — it monitors.

Register your project once. New CVE drops at 3am? It's indexed by 3:15am. Your morning coding session knows about it without you asking.

"check_alerts" — what changed since yesterday?

vulnfeed.novadyne.ai

### vf-06 (Jun 1, 21:00 UTC) — Free tier
VulnFeed has a free tier: 10 scans/day, 1 monitored project. No signup, no credit card.

Add the MCP server to your Claude Code config and start scanning. If you need unlimited: $14/mo.

vulnfeed.novadyne.ai

### vf-07 (Jun 2, 14:00 UTC) — Ecosystem breadth
VulnFeed reads 9 lockfile formats:

package-lock.json, yarn.lock, pnpm-lock.yaml, requirements.txt, Pipfile.lock, go.sum, Cargo.lock, Gemfile.lock, composer.lock

One tool, every ecosystem. "scan_project" finds them all automatically.

### vf-08 (Jun 2, 21:00 UTC) — Why not DIY
"Can't I just ask Claude to check my deps?"

You can. It'll cost you more in compute than $14/mo, it won't have EPSS data, it won't remember what it found last time, and it can't watch for new CVEs while you sleep.

vulnfeed.novadyne.ai

### vf-09 (Jun 3, 14:00 UTC) — 9 tools
VulnFeed gives Claude Code 9 security tools:

scan_project — full project scan
check_package — single package lookup
lookup_cve — deep CVE details + EPSS
monitor_project — register for alerts
check_alerts — what's new since last scan

All native MCP. No browser, no CLI switching.

### vf-10 (Jun 3, 21:00 UTC) — Closing CTA
Two products shipping vulnerabilities to your production:

1. The ones in your code
2. The ones in your dependencies

VulnFeed handles #2. $14/mo, not per-seat. Free tier to try.

vulnfeed.novadyne.ai
