# VulnFeed — Security MCP Server

Vulnerability scanning and continuous monitoring for Claude Code. Monitors your project's dependencies against NVD, GitHub Advisories, and EPSS exploit data.

## Setup

1. Install the MCP Python SDK:
   ```bash
   pip install mcp
   ```

2. Add to your Claude Code settings (`.claude/settings.json` or `~/.claude/settings.json`):
   ```json
   {
     "mcpServers": {
       "vulnfeed": {
         "type": "stdio",
         "command": "python3",
         "args": ["/path/to/server.py"],
         "env": {
           "VULNFEED_WORKER_URL": "https://...",
           "VULNFEED_API_KEY": "your-key"
         }
       }
     }
   }
   ```

3. Restart Claude Code. The tools are now available.

### Remote mode (SSE)

Run as a remote server for shared/team access:
```bash
python3 server.py --transport sse --host 0.0.0.0 --port 8383
```

Then connect from Claude Code settings:
```json
{
  "mcpServers": {
    "vulnfeed": {
      "type": "sse",
      "url": "http://your-server:8383/sse"
    }
  }
}
```

Or set `VULNFEED_TRANSPORT=sse` to default to SSE mode.

## Tools

### Scanning

#### `scan_lockfile`
Scan a specific lockfile for vulnerabilities.
```
scan_lockfile(lockfile_path="/path/to/package-lock.json")
```

#### `check_package`
Check a single package for known vulnerabilities.
```
check_package(name="express", version="4.17.1", ecosystem="npm")
```

#### `lookup_cve`
Get detailed info on a specific vulnerability.
```
lookup_cve(cve_id="CVE-2024-29041")
```

#### `scan_project`
Auto-detect and scan all lockfiles in a project directory.
```
scan_project(project_path="/path/to/project")
```

### Monitoring

#### `monitor_project`
Register a project for continuous vulnerability monitoring. Takes a baseline snapshot of current dependencies and known vulns.
```
monitor_project(project_path="/path/to/project", project_name="my-app")
```

#### `check_alerts`
Check for new vulnerabilities since the last scan. Returns only vulns that weren't in the baseline.
```
check_alerts(project_id="f47e98b0e47a")
```

#### `list_monitored`
List all projects registered for monitoring.
```
list_monitored()
```

#### `update_deps`
Update the dependency snapshot after upgrading packages (e.g. after `npm update`).
```
update_deps(project_id="f47e98b0e47a", project_path="/path/to/project")
```

#### `unmonitor_project`
Remove a project from monitoring.
```
unmonitor_project(project_id="f47e98b0e47a")
```

## Supported lockfiles

- `package-lock.json` (npm)
- `yarn.lock` (Yarn)
- `pnpm-lock.yaml` (pnpm)
- `Pipfile.lock` (Pipenv)
- `requirements.txt` (pip)
- `go.sum` / `go.mod` (Go)
- `Cargo.lock` (Rust / crates.io)
- `Gemfile.lock` (Ruby / RubyGems)
- `composer.lock` (PHP / Packagist)

## Smart filtering

By default, VulnFeed suppresses low-priority CVEs (EPSS < 10% exploit probability AND CVSS < 9.0). This cuts noise by ~80% — most CVEs are theoretical, not actively exploited.

To see everything, pass `show_all=True` to any scan tool:
```
scan_lockfile(lockfile_path="package-lock.json", show_all=True)
```

## How it works

1. Parses your lockfile to extract dependency names + versions
2. Batch-queries OSV.dev (which includes NVD + GitHub Advisories)
3. Enriches each vulnerability with EPSS exploit probability scores
4. Filters by exploitability — suppresses low-EPSS, non-critical CVEs by default
5. Sorts results by exploitability — the CVEs most likely to be used in real attacks appear first
6. Returns fix version recommendations from package registries

### Monitoring flow

1. `monitor_project` scans your deps and stores a baseline (known vulns + dep versions)
2. `check_alerts` re-scans against the same dep list and diffs — new vulns that appeared since last check are surfaced, resolved vulns are noted
3. Run `check_alerts` periodically (e.g. daily) to catch newly published CVEs affecting your deps
