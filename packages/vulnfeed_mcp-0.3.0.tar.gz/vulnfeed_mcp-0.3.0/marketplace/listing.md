# VulnFeed — Marketplace Listing Content

Use this content when submitting to MCP directories.

## Name
VulnFeed

## Tagline
Dependency vulnerability monitoring for Claude Code. Knows your lockfile, prioritizes by exploit probability, tells you what matters.

## Description (short — 280 chars)
An MCP server that scans your lockfiles (npm, PyPI, Go, Rust, Ruby, PHP) for known vulnerabilities, enriches with EPSS exploit probability scores, and recommends fix versions. $14/mo — not per-seat.

## Description (full)
VulnFeed monitors your project's dependencies for security vulnerabilities — native to Claude Code.

**What it does:**
- Reads your lockfile (package-lock.json, requirements.txt, go.sum, Cargo.lock, Gemfile.lock, composer.lock, yarn.lock, Pipfile.lock, pnpm-lock.yaml)
- Queries NVD + GitHub Advisory Database for known CVEs
- Enriches with EPSS (Exploit Prediction Scoring System) scores to filter noise
- Recommends exact fix versions from package registries
- Monitors projects continuously — get alerts when new CVEs drop

**9 tools:**
- `scan_project` — auto-detect and scan all lockfiles in a directory
- `scan_lockfile` — scan a specific lockfile
- `check_package` — check a single package for vulns
- `lookup_cve` — detailed CVE info with EPSS + fix versions
- `monitor_project` — register for continuous monitoring
- `check_alerts` — new vulns since last scan
- `update_deps` — update snapshot after upgrading packages
- `list_monitored` — see all monitored projects
- `unmonitor_project` — remove from monitoring

**Free tier:** 10 scans/day, 1 monitored project. No signup required.
**Paid:** $14/mo via Polar.sh. Unlimited scans + projects.

## Homepage
https://vulnfeed.novadyne.ai

## Purchase URL
https://buy.polar.sh/polar_cl_l2u7OfEs3L3NaMKsCQByy271MbERK5JO6ePqR0mRfBj

## Transport
stdio (local install), SSE (remote)

## Tool count
9

## Supported ecosystems
npm, PyPI, Go, crates.io, RubyGems, Packagist (9 lockfile formats)

## Author
Novadyne (an Infai company)

## Install snippet

**Free tier** (no signup, 10 scans/day):
```json
{
  "mcpServers": {
    "vulnfeed": {
      "command": "uvx",
      "args": ["vulnfeed-mcp"]
    }
  }
}
```

**Paid** ($14/mo, unlimited):
```json
{
  "mcpServers": {
    "vulnfeed": {
      "command": "uvx",
      "args": ["vulnfeed-mcp"],
      "env": {
        "VULNFEED_API_KEY": "YOUR_LICENSE_KEY_HERE"
      }
    }
  }
}
```

## Categories
- Security
- DevOps
- Dependency management
- Vulnerability scanning

---

## Submission steps

### mcp.so
1. Go to mcp.so and find their submission process (GitHub issue or web form)
2. Submit with: name, description (short), homepage URL, tool count, transport, install snippet
3. Note free tier availability

### glama.ai
1. Visit glama.ai/mcp/servers
2. Submit server URL or create a glama.json in a public repo
3. Fields: name, description, install config, homepage

### Smithery (smithery.ai)
1. Create publisher account at smithery.ai
2. Publish via web interface or CLI
3. Include: name, description, auth method (API key), tool manifest, pricing info
