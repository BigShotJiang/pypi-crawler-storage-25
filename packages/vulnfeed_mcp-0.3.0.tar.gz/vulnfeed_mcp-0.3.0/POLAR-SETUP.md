# VulnFeed — Polar.sh Setup (Nat-side, ~10 min)

Polar.sh handles licensing + payments for VulnFeed subscriptions. Free signup, 4% transaction fee.

## Steps

1. **Sign up at [polar.sh](https://polar.sh)** — use `natburke@infaicorp.com` or your preferred email. Create an organization (e.g., "Novadyne" or "Infai").

2. **Create a Product:**
   - Name: VulnFeed
   - Type: Subscription (recurring)
   - Price: $14/mo
   - Add a "License Key" benefit — this auto-generates keys for each subscriber

3. **Copy two values back to Discord:**
   - **Organization ID** — found in Settings → Developer → Organization ID (UUID format)
   - **Product URL** — the checkout link for VulnFeed (Polar provides a hosted checkout page)

4. Agent will:
   - PUT the Organization ID to the Worker as `POLAR_ORG_ID`
   - Substitute the checkout URL into the landing page (replacing `PURCHASE_URL_HERE`)
   - Deploy the updated landing page
   - The license key validation code is already built and waiting

## How it works (already built)

- Buyer completes checkout on Polar.sh → gets a license key
- Buyer sets `VULNFEED_API_KEY` in their MCP config to this key
- MCP server sends the key to the Worker on each request
- Worker validates against Polar.sh API, caches valid keys for 24h in KV
- Free tier (no key): 10 scans/day, 1 monitored project
- Paid tier: unlimited scans and projects

## What's NOT needed from you

- No API key/token needed — Polar.sh's validation endpoint is unauthenticated (safe for public clients)
- No webhook setup needed for MVP — validation is on-demand, not event-driven
- Custom domain live at `vulnfeed.novadyne.ai` (also accessible at `vulnfeed.pages.dev`)

## Timeline

Once you post the Org ID + product URL in Discord, the agent will wire everything up in one wake (~15 min of work). VulnFeed goes live immediately after.
