"""VulnFeed scanner — parses lockfiles and queries for vulnerabilities.

Usage:
    scanner.py scan <lockfile>          # scan a lockfile for vulnerabilities
    scanner.py scan-json <lockfile>     # same but raw JSON output

Supports: package-lock.json, yarn.lock, pnpm-lock.yaml (npm),
          requirements.txt, Pipfile.lock (PyPI), go.sum (Go),
          Cargo.lock (crates.io), Gemfile.lock (RubyGems),
          composer.lock (Packagist)

Requires WORKER_URL and WORKER_BOOTSTRAP_KEY env vars.
"""

import json
import os
import re
import sys
import urllib.request
import urllib.error

WORKER_URL = os.environ.get("WORKER_URL", "")
WORKER_KEY = os.environ.get("WORKER_BOOTSTRAP_KEY", "")


def parse_package_lock(path):
    """Parse npm package-lock.json (v2/v3) → list of {name, version, ecosystem}."""
    with open(path) as f:
        data = json.load(f)

    packages = []
    seen = set()

    if "packages" in data:
        for key, info in data["packages"].items():
            if not key or key == "":
                continue
            name = info.get("name") or key.split("node_modules/")[-1]
            version = info.get("version")
            if name and version and (name, version) not in seen:
                seen.add((name, version))
                packages.append({"name": name, "version": version, "ecosystem": "npm"})
    elif "dependencies" in data:
        def walk(deps):
            for name, info in deps.items():
                version = info.get("version")
                if name and version and (name, version) not in seen:
                    seen.add((name, version))
                    packages.append({"name": name, "version": version, "ecosystem": "npm"})
                if "dependencies" in info:
                    walk(info["dependencies"])
        walk(data["dependencies"])

    return packages


def parse_requirements_txt(path):
    """Parse pip requirements.txt → list of {name, version, ecosystem}."""
    packages = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            m = re.match(r"^([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+-]+)", line)
            if m:
                packages.append({
                    "name": m.group(1).lower(),
                    "version": m.group(2),
                    "ecosystem": "PyPI"
                })
    return packages


def parse_go_sum(path):
    """Parse go.sum → list of {name, version, ecosystem}."""
    packages = []
    seen = set()
    with open(path) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            name = parts[0]
            version = parts[1].split("/")[0].lstrip("v")
            if (name, version) not in seen:
                seen.add((name, version))
                packages.append({"name": name, "version": version, "ecosystem": "Go"})
    return packages


def parse_yarn_lock(path):
    """Parse yarn.lock → list of {name, version, ecosystem}."""
    packages, seen = [], set()
    with open(path) as f:
        current_names = []
        for line in f:
            line = line.rstrip()
            if not line or line.startswith("#"):
                continue
            if not line.startswith(" ") and line.endswith(":"):
                current_names = []
                specs = line.rstrip(":").split(", ")
                for spec in specs:
                    spec = spec.strip().strip('"')
                    at = spec.rfind("@")
                    if at > 0:
                        current_names.append(spec[:at])
            elif line.strip().startswith("version "):
                version = line.strip().split('"')[1] if '"' in line else line.strip().split()[-1]
                for name in current_names:
                    if (name, version) not in seen:
                        seen.add((name, version))
                        packages.append({"name": name, "version": version, "ecosystem": "npm"})
                current_names = []
    return packages


def parse_cargo_lock(path):
    """Parse Cargo.lock → list of {name, version, ecosystem}."""
    packages = []
    name, version = None, None
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line == "[[package]]":
                if name and version:
                    packages.append({"name": name, "version": version, "ecosystem": "crates.io"})
                name, version = None, None
            elif line.startswith("name = "):
                name = line.split('"')[1] if '"' in line else None
            elif line.startswith("version = "):
                version = line.split('"')[1] if '"' in line else None
    if name and version:
        packages.append({"name": name, "version": version, "ecosystem": "crates.io"})
    return packages


def parse_gemfile_lock(path):
    """Parse Gemfile.lock → list of {name, version, ecosystem}."""
    packages = []
    in_specs = False
    with open(path) as f:
        for line in f:
            stripped = line.rstrip()
            if stripped == "  specs:":
                in_specs = True
                continue
            if in_specs:
                if not stripped.startswith("    "):
                    in_specs = False
                    continue
                m = re.match(r"^    (\S+) \((\S+)\)", stripped)
                if m:
                    packages.append({"name": m.group(1), "version": m.group(2), "ecosystem": "RubyGems"})
    return packages


def parse_composer_lock(path):
    """Parse composer.lock → list of {name, version, ecosystem}."""
    with open(path) as f:
        data = json.load(f)
    packages = []
    for section in ("packages", "packages-dev"):
        for pkg in data.get(section, []):
            name = pkg.get("name")
            version = (pkg.get("version") or "").lstrip("v")
            if name and version:
                packages.append({"name": name, "version": version, "ecosystem": "Packagist"})
    return packages


def detect_and_parse(path):
    """Auto-detect lockfile type and parse."""
    basename = os.path.basename(path)
    if basename == "package-lock.json":
        return parse_package_lock(path)
    elif basename in ("requirements.txt", "requirements.in"):
        return parse_requirements_txt(path)
    elif basename in ("go.sum", "go.mod"):
        return parse_go_sum(path)
    elif basename == "yarn.lock":
        return parse_yarn_lock(path)
    elif basename == "Cargo.lock":
        return parse_cargo_lock(path)
    elif basename == "Gemfile.lock":
        return parse_gemfile_lock(path)
    elif basename == "composer.lock":
        return parse_composer_lock(path)
    else:
        ext = os.path.splitext(path)[1]
        if ext == ".json":
            return parse_package_lock(path)
        elif ext == ".txt":
            return parse_requirements_txt(path)
        print(f"[!] Unknown lockfile type: {basename}", file=sys.stderr)
        return []


def query_vulns(packages):
    """Query Worker /vulnscan/query endpoint for vulnerabilities."""
    if not WORKER_URL or not WORKER_KEY:
        print("[!] WORKER_URL or WORKER_BOOTSTRAP_KEY not set", file=sys.stderr)
        sys.exit(1)

    # Batch into chunks of 500
    all_results = []
    for i in range(0, len(packages), 500):
        batch = packages[i:i+500]
        payload = json.dumps({"packages": batch}).encode()
        req = urllib.request.Request(
            f"{WORKER_URL}/vulnscan/query",
            data=payload,
            headers={
                "Authorization": f"Bearer {WORKER_KEY}",
                "Content-Type": "application/json",
                "User-Agent": "vulnfeed-scanner/0.1"
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            print(f"[!] Worker returned {e.code}: {body}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"[!] Worker unreachable: {e}", file=sys.stderr)
            sys.exit(1)

        if not data.get("ok"):
            print(f"[!] Scan failed: {data.get('error')}", file=sys.stderr)
            sys.exit(1)

        all_results.extend(data.get("results", []))

    return all_results


def format_results(results, packages_count):
    """Format scan results for human consumption."""
    affected = [r for r in results if r.get("vulnerable")]
    total_vulns = sum(r.get("vuln_count", 0) for r in affected)

    print(f"\n{'='*60}")
    print(f"  VulnFeed Scan Results")
    print(f"{'='*60}")
    print(f"  Packages scanned: {packages_count}")
    print(f"  Affected packages: {len(affected)}")
    print(f"  Total vulnerabilities: {total_vulns}")
    print(f"{'='*60}\n")

    if not affected:
        print("  No known vulnerabilities found.\n")
        return

    # Sort affected packages by highest EPSS score in their vulns
    def max_epss(r):
        scores = [v.get("epss", {}).get("score", 0) if v.get("epss") else 0 for v in r.get("vulns", [])]
        return max(scores) if scores else 0
    affected.sort(key=max_epss, reverse=True)

    for r in affected:
        pkg = r["package"]
        print(f"  [{pkg['name']}@{pkg['version']}] — {r['vuln_count']} vulnerabilit{'y' if r['vuln_count'] == 1 else 'ies'}")

        for v in r.get("vulns", []):
            cve = v.get("cve") or v.get("id", "unknown")
            epss_str = ""
            if v.get("epss"):
                score = v["epss"]["score"]
                if score >= 0.5:
                    epss_str = f" | EPSS: {score:.1%} HIGH"
                elif score >= 0.1:
                    epss_str = f" | EPSS: {score:.1%}"
                else:
                    epss_str = f" | EPSS: {score:.1%} low"

            fix_str = f" | Fix: {v['fix_version']}" if v.get("fix_version") else ""
            severity_str = f" | {v['severity']}" if v.get("severity") else ""

            print(f"    {cve}{severity_str}{epss_str}{fix_str}")
            if v.get("summary"):
                summary = v["summary"][:120] + "..." if len(v.get("summary", "")) > 120 else v.get("summary", "")
                print(f"      {summary}")

        print()


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    lockfile = sys.argv[2]

    if not os.path.exists(lockfile):
        print(f"[!] File not found: {lockfile}", file=sys.stderr)
        sys.exit(1)

    packages = detect_and_parse(lockfile)
    if not packages:
        print("[!] No packages found in lockfile", file=sys.stderr)
        sys.exit(1)

    print(f"[*] Parsed {len(packages)} packages from {os.path.basename(lockfile)}")
    print(f"[*] Querying vulnerability databases...")

    results = query_vulns(packages)

    if cmd == "scan-json":
        print(json.dumps({
            "scanned": len(packages),
            "results": results
        }, indent=2))
    else:
        format_results(results, len(packages))


if __name__ == "__main__":
    main()
