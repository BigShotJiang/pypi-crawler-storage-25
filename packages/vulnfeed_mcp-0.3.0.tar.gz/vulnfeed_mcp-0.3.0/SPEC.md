# Bet B — Security Feed MCP

**Product:** VulnFeed (working name) — a paid MCP server that monitors your dependencies for vulnerabilities and tells you what actually matters.

**Price:** $14/mo

**One-liner:** Snyk-grade vulnerability intelligence for $14/mo, native to Claude Code.

## What it is

An MCP server that knows your project's dependencies (by reading your lockfile) and continuously monitors NVD, GitHub Advisories, and EPSS data. When a new CVE drops that affects your actual deps, it tells you: what's vulnerable, how likely it is to be exploited, and exactly which version to upgrade to.

## What it is NOT

A raw CVE lookup tool. There are 6+ free MCP servers that wrap NVD's API. We don't compete with them on data access — we compete on signal-to-noise.

## Why someone pays

1. **Context-aware.** Free servers answer "tell me about CVE-2026-XXXX." VulnFeed answers "am I vulnerable right now?" It knows your `package-lock.json` / `requirements.txt` / `go.sum` and filters to only the CVEs that hit your actual dependency tree.

2. **Prioritized.** EPSS (Exploit Prediction Scoring System) scores every CVE by real-world exploitability. Most CVEs are noise — EPSS cuts the alert volume by ~80%. VulnFeed surfaces the ones likely to be exploited, not every theoretical vuln.

3. **Actionable.** Not just "you're vulnerable" but "upgrade `express` from 4.18.2 → 4.21.0 to fix CVE-2026-XXXX (EPSS: 0.73, CVSS: 9.1)." Cross-references package registries (npm, PyPI, Go) for fix versions.

4. **Always-on.** Maintains a persistent watch list. New CVE published at 3am? Indexed by 3:15am. Your morning coding session knows about it without you asking.

5. **Cheap.** Snyk Team is $25/dev/mo. GitHub Advanced Security is $49/committer/mo. VulnFeed is $14/mo flat — not per-seat.

## Competitive positioning

| | Free MCP servers | Snyk/Socket ($25-49/dev/mo) | VulnFeed ($14/mo) |
|---|---|---|---|
| CVE lookup | ✅ | ✅ | ✅ |
| Knows your deps | ❌ | ✅ | ✅ |
| EPSS prioritization | ❌ | ✅ | ✅ |
| Fix recommendations | ❌ | ✅ | ✅ |
| Continuous monitoring | ❌ | ✅ | ✅ |
| MCP-native | ✅ | ❌ | ✅ |
| Auto-fix PRs | ❌ | ✅ | ❌ (v2) |
| Per-seat pricing | n/a | ✅ (expensive) | ❌ (flat) |

## Architecture

```
User's Claude Code session
  ↓ MCP tool call
VulnFeed MCP Server (Cloudflare Worker)
  ├── /scan — reads lockfile, returns vulns affecting your deps
  ├── /monitor — registers a project for continuous monitoring
  ├── /alerts — returns new vulns since last check
  └── /cve/{id} — detailed CVE info with fix recommendation
  ↓
Data layer (Worker KV / D1)
  ├── NVD feed (synced hourly)
  ├── GitHub Advisories (synced hourly)  
  ├── EPSS scores (synced daily)
  └── Package registry metadata (npm, PyPI, Go — cached)
```

Runs entirely on Cloudflare Workers + KV/D1. No server to maintain. Data sync runs on Worker Cron Triggers.

## Build plan

### v0.1 (wake #46) — MVP ✅
- [x] Worker `/vulnscan/query` endpoint: batch OSV.dev + EPSS enrichment
- [x] `/vulnscan/cve/{id}` endpoint: detailed CVE with fix versions
- [x] Python CLI scanner: lockfile parser + prioritized report

### v0.2 (wake #47) — MCP Server ✅
- [x] FastMCP server with stdio transport: scan_lockfile, check_package, lookup_cve, scan_project
- [x] Support for package-lock.json, requirements.txt, go.sum, yarn.lock, Pipfile.lock

### v0.3 (wake #48) — Monitoring ✅
- [x] `POST /vulnscan/monitor`: register project, store dep snapshot in KV
- [x] `GET /vulnscan/alerts`: diff current CVEs against stored snapshot
- [x] `PUT /vulnscan/monitor/:id`: update deps, preserve vuln history
- [x] MCP tools: monitor_project, check_alerts, update_deps, list_monitored, unmonitor_project
- [x] Landing page draft (products/security-mcp/landing/index.html)

### v1.0 (~1 wake) — Ship
- [x] EPSS-based smart prioritization (suppress CVEs below 0.1 EPSS unless CVSS ≥ 9) — wake #49
- [x] SSE transport for remote MCP connections — wake #49
- [x] License key validation code (Polar.sh integration) — wake #51, activates on POLAR_ORG_ID
- [x] Deploy landing page to vulnfeed.pages.dev — wake #51
- [x] Custom domain: vulnfeed.novadyne.ai — wake #56
- [x] Substitute Polar.sh purchase URL into landing page — wake #57
- [x] Set POLAR_ORG_ID on Worker — wake #57
- [x] Free tier auth fix (route order bug: general auth gate blocked free-tier vulnscan requests) — wake #59
- [ ] Listing on mcp.so + glama.ai + Smithery (listing content drafted, manual submission needed)
- [ ] MCP Marketplace listing (free tier: 1 project, 10 scans/day)

## Metrics

| Metric | Target | Timeframe |
|--------|--------|-----------|
| MCP Marketplace installs | 100 | 30 days post-listing |
| Free-to-paid conversion | 5-8% | 60 days |
| Paid subscribers | 50 | 60 days post-listing |
| MRR | $700 | 60 days |
| Churn | <10%/mo | After month 2 |

## Kill criteria

- <20 paid users after 90 days of listing
- <50 free installs after 30 days (no organic interest)
- Upstream data costs exceed revenue (shouldn't happen — all sources are free)
- Anthropic ships native vulnerability scanning in Claude Code

## Brand / marketing

**Novadyne umbrella (Nat 09:30Z).** Nat clarified: novadyne is the AI product umbrella (accounting, ledger, now MCP), infai is novadyne's parent company. Security MCP goes under novadyne alongside the bookkeeping assistant — unified AI product brand. Product name: VulnFeed by Novadyne. Marketing via @InfaiHq (parent-company channel) until novadyne has its own presence.

## Upstream costs

$0 ongoing:
- NVD API: free (no key needed, <5 req/30s)
- GitHub Advisory DB: free (public GraphQL)
- EPSS: free (open data, daily CSV)
- npm/PyPI/Go registries: free (public APIs)
- Cloudflare Workers: free tier covers initial traffic
- D1 database: free tier (5GB, 5M reads/day)

Revenue breakeven: first subscriber.
