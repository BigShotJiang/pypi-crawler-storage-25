#!/usr/bin/env bash
# Deploys the VulnFeed landing page to Cloudflare Pages.
# Project: vulnfeed (to be created on first deploy).
# Production URL: https://vulnfeed.novadyne.ai (also: https://vulnfeed.pages.dev)
#
# Required env (export before running):
#   CLOUDFLARE_API_TOKEN
#   CLOUDFLARE_ACCOUNT_ID
#
# On first deploy, create the Pages project first:
#   curl -X POST "https://api.cloudflare.com/client/v4/accounts/$CLOUDFLARE_ACCOUNT_ID/pages/projects" \
#     -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
#     -H "Content-Type: application/json" \
#     -d '{"name":"vulnfeed","production_branch":"main"}'

set -euo pipefail

PROJECT_NAME=${PROJECT_NAME:-vulnfeed}
BRANCH=${BRANCH:-main}
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

: "${CLOUDFLARE_API_TOKEN:?CLOUDFLARE_API_TOKEN required}"
: "${CLOUDFLARE_ACCOUNT_ID:?CLOUDFLARE_ACCOUNT_ID required}"

echo "Deploying $SCRIPT_DIR to Pages project '$PROJECT_NAME' (branch=$BRANCH)..."
npx --yes wrangler@latest pages deploy "$SCRIPT_DIR" \
  --project-name="$PROJECT_NAME" \
  --branch="$BRANCH" \
  --commit-dirty=true

echo
echo "Production: https://${PROJECT_NAME}.pages.dev"
echo "Latest deployment:"
curl -fsS -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  "https://api.cloudflare.com/client/v4/accounts/$CLOUDFLARE_ACCOUNT_ID/pages/projects/$PROJECT_NAME/deployments" \
  | python3 -c "
import json,sys
d=json.load(sys.stdin)
for dep in d.get('result',[])[:1]:
    print(f\"  {dep.get('id')[:8]}  {dep.get('environment')}  {dep.get('url')}\")
    for s in dep.get('stages',[]):
        if s.get('name') == 'deploy':
            print(f\"  deploy stage: {s.get('status')}\")
"
