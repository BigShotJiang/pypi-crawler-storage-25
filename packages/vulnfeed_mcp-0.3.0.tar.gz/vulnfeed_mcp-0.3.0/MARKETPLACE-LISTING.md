# VulnFeed — Marketplace Listing Draft

Ready to submit to mcp.so, glama.ai, and the MCP Marketplace when licensing is resolved.

---

## Short description (one line)

Dependency vulnerability monitoring with EPSS prioritization. Reads your lockfile, tells you what's actually exploitable.

## Description (full)

VulnFeed monitors your project's dependencies for known vulnerabilities using NVD, GitHub Advisories, and EPSS exploit probability data. Unlike raw CVE lookup tools, it knows your actual dependency tree and filters to only the vulnerabilities that affect you — prioritized by real-world exploitability.

**What it does:**
- Scans lockfiles (npm, pip, Go, Rust, Ruby, PHP) and reports vulnerabilities affecting your deps
- Prioritizes by EPSS — suppresses ~80% of noise (theoretical CVEs that are never exploited)
- Recommends exact fix versions from package registries
- Continuous monitoring: register a project once, check for new CVEs any time
- 9 tools covering the full security monitoring workflow

**Free tier:** 1 project, 10 scans/day
**Pro ($14/mo):** unlimited projects, unlimited scans, priority data sync

## Category

Security / DevOps

## Tags

security, vulnerabilities, CVE, dependencies, npm, python, go, rust, ruby, monitoring, EPSS

## Tools (9)

| Tool | Description |
|------|-------------|
| scan_lockfile | Scan a lockfile for known vulnerabilities |
| check_package | Check a single package for known vulns |
| lookup_cve | Detailed CVE info with EPSS + fix versions |
| scan_project | Auto-detect and scan all lockfiles in a project |
| monitor_project | Register for continuous vulnerability monitoring |
| check_alerts | Check for new vulns since last scan |
| list_monitored | List all monitored projects |
| update_deps | Update dep snapshot after package upgrades |
| unmonitor_project | Remove a project from monitoring |

## Transport

- stdio (local, recommended)
- SSE (remote/team access)

## Requirements

- Python 3.10+
- `mcp` package (`pip install mcp`)
- VulnFeed API key (from purchase)

## Author

Novadyne (an Infai company)

## Links

- Landing page: https://vulnfeed.novadyne.ai
- Purchase: PURCHASE_URL_HERE
