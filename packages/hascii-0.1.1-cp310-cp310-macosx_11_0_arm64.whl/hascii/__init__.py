from .hascii import *

__doc__ = hascii.__doc__
if hasattr(hascii, "__all__"):
    __all__ = hascii.__all__