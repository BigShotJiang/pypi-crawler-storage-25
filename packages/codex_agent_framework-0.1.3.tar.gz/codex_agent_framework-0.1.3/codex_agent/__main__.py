from pathlib import Path

from . import Agent


def main():
    package_dir = Path(__file__).parent
    agent = Agent(
        system=str(package_dir / 'prompts' / 'system_prompt.txt'),
        voice_instructions="You're a lively and friendly female in her mid twenties. You speak french with a easy-going and cheerful tone.",
        username="Baptiste",
        userage="40",
    )
    agent.interact()


if __name__ == '__main__':
    main()
