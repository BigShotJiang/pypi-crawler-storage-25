from prompt_toolkit import PromptSession
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.text import Text
from .event import ResponseContentDeltaEvent, ResponseDoneEvent, ResponseStartEvent, ServerToolCallEvent, ToolCallStartEvent


class TerminalChat:
    """Small terminal UI wired to agent events."""

    def __init__(self, agent, console=None):
        self.agent = agent
        self.console = console or Console()
        self.prompt_session = PromptSession(multiline=True)
        self._in_response = False
        self._has_content = False
        self._seen_tool_calls = set()

    def attach(self):
        self.agent.on(ResponseStartEvent, self._on_response_start)
        self.agent.on(ResponseContentDeltaEvent, self._on_content_delta)
        self.agent.on(ToolCallStartEvent, self._on_tool_call_start)
        self.agent.on(ServerToolCallEvent, self._on_server_tool_call)
        self.agent.on(ResponseDoneEvent, self._on_response_done)
        return self

    def run(self):
        self.attach()
        self.console.print(Panel.fit(
            "[bold]Codex Agent[/bold]\n[dim]Alt+Enter submits multiline input. Type exit or quit to stop.[/dim]",
            border_style="cyan",
        ))
        while True:
            try:
                self.print_status_bar()
                prompt = self.prompt_session.prompt(
                    [("class:prompt", "You > ")],
                    prompt_continuation="...   ",
                )
                command = prompt.strip().lower()
                if command in ["exit", "quit", "/exit", "/quit"]:
                    self.console.print("[dim]Bye.[/dim]")
                    break
                if command == "/clear":
                    self.clear_screen()
                    continue
                if not prompt.strip():
                    continue
                try:
                    result = self.agent(prompt)
                    if isinstance(result, str) and result:
                        self.console.print(result, style="dim")
                except KeyboardInterrupt:
                    self.agent.interrupt("keyboard_interrupt")
                    self.console.print("\n[dim]Interrupted.[/dim]")
                self.console.print()
            except (KeyboardInterrupt, EOFError):
                self.console.print("\n[dim]Bye.[/dim]")
                break

    def print_status_bar(self):
        try:
            status = self.agent.context_status()
        except Exception as exc:
            self.console.print(f"[dim red]status unavailable: {exc}[/dim red]")
            return

        percent = status.percent
        style = "green"
        if percent >= 90:
            style = "bold red"
        elif percent >= 75:
            style = "yellow"
        elif percent >= 50:
            style = "cyan"

        used = self._format_int(status.used_tokens)
        limit = self._format_int(status.input_token_limit)
        session = str(status.session_id or "-")[-15:]
        compact_hint = " auto-compact:on" if status.auto_compact else " auto-compact:off"
        if status.auto_compact and status.used_tokens >= status.auto_compact_threshold:
            compact_hint = " auto-compact:due"

        self.console.print(
            Text.assemble(
                ("ctx ", "dim"),
                (f"{percent:.1f}%", style),
                (f" {used}/{limit} tok", "dim"),
                (f" · hist {status.visible_history_messages}/{status.total_history_messages}", "dim"),
                (f" · msgs {status.total_session_messages}", "dim"),
                (f" · img {status.image_messages}", "dim"),
                (f" · mem {status.memory_entries}", "dim"),
                (f" · pending {status.pending_messages}", "dim"),
                (f" · {session}", "dim"),
                (compact_hint, "dim"),
            )
        )

    def clear_screen(self):
        self.console.clear()

    @staticmethod
    def _format_int(value):
        try:
            return f"{int(value):,}".replace(",", " ")
        except Exception:
            return str(value)

    def _on_response_start(self, event):
        if self._in_response:
            self.console.print()
        self._in_response = True
        self._has_content = False
        self._seen_tool_calls.clear()
        name = event.message.get("name") if event.get("message") else None
        self.console.print(Rule(Text(name or "Agent", style="bold cyan"), style="cyan"))

    def _on_content_delta(self, event):
        self._has_content = True
        self.console.print(event.delta, end="", markup=False, highlight=False, soft_wrap=True)

    def _on_tool_call_start(self, event):
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id)

    def _on_server_tool_call(self, event):
        name = event.get("name") or "unknown"
        call_id = event.get("call_id") or name
        self._print_tool_call(name, call_id)

    def _print_tool_call(self, name, call_id):
        if call_id in self._seen_tool_calls:
            return
        self._seen_tool_calls.add(call_id)
        if self._has_content:
            self.console.print()
        self.console.print(f"tool: {name}", style="dim cyan")
        self._has_content = False

    def _on_response_done(self, event):
        if self._has_content:
            self.console.print()
        self._in_response = False
