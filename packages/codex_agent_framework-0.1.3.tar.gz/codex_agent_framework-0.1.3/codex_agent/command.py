from modict import modict


COMMAND_MARKER = "__codex_agent_command__"


def command(func=None, **options):
    """Mark a function as an agent slash command for automatic discovery."""
    if func is None:
        def decorator(f):
            return command(f, **options)
        return decorator

    setattr(func, COMMAND_MARKER, modict(options))
    return func


def command_options(func):
    return getattr(func, COMMAND_MARKER, None)
