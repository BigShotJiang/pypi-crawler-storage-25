from modict import modict

from codex_backend_sdk import CodexClient, OutputItem, ReasoningDelta, ResponseAborted, ResponseFailed, TextDelta, ToolCall
from .tool import Tool


class Worker:
    """One-shot backend worker base class.

    Subclasses specialize behavior by overriding class fields such as
    ``system_prompt``, ``tools``, and model defaults.
    """

    system_prompt = "Complete the requested task directly and return only the useful result."
    model = "gpt-5.4"
    reasoning_effort = "medium"
    verbosity = "medium"
    tools = []
    tool_choice = None
    output_schema = None
    resolve_tools = True
    name = "worker"
    max_retries = 3

    def __init__(
        self,
        *,
        client=None,
        system_prompt=None,
        model=None,
        reasoning_effort=None,
        verbosity=None,
        tools=None,
        tool_choice=None,
        output_schema=None,
        resolve_tools=None,
        name=None,
        max_retries=None,
    ):
        self.system_prompt = system_prompt if system_prompt is not None else self.system_prompt
        self.model = model if model is not None else self.model
        self.reasoning_effort = reasoning_effort if reasoning_effort is not None else self.reasoning_effort
        self.verbosity = verbosity if verbosity is not None else self.verbosity
        self.tools = list(tools if tools is not None else self.tools)
        self.tool_choice = tool_choice if tool_choice is not None else self.tool_choice
        self.output_schema = output_schema if output_schema is not None else self.output_schema
        self.resolve_tools = resolve_tools if resolve_tools is not None else self.resolve_tools
        self.name = name if name is not None else self.name
        self.max_retries = max_retries if max_retries is not None else self.max_retries
        self._client = client

    @property
    def client(self):
        if self._client is None:
            self._client = CodexClient(model=self.model, max_retries=self.max_retries).authenticate()
        return self._client

    def get_tools(self):
        return [
            tool.to_response_tool() if hasattr(tool, "to_response_tool") else dict(tool)
            for tool in self.tools
        ]

    def get_local_tools(self):
        return {
            tool.name: tool
            for tool in self.tools
            if isinstance(tool, Tool)
        }

    def run(
        self,
        prompt,
        *,
        conversation_history=None,
        tools=None,
        model=None,
        reasoning_effort=None,
        verbosity=None,
        tool_choice=None,
        output_schema=None,
        resolve_tools=None,
    ):
        text = ""
        reasoning = ""
        tool_calls = []
        tool_results = []
        output_items = []

        try:
            resolved_tools = tools if tools is not None else self.get_tools()
            resolved_tool_choice = tool_choice or self.tool_choice or ("auto" if resolved_tools else "none")
            resolved_output_schema = output_schema if output_schema is not None else self.output_schema
            resolved_verbosity = verbosity or self.verbosity

            events = self.client.stream(
                prompt,
                conversation_history=conversation_history or [],
                instructions=self.system_prompt,
                model=model or self.model,
                reasoning=reasoning_effort or self.reasoning_effort,
                reasoning_summary="auto" if (reasoning_effort or self.reasoning_effort) else None,
                include_reasoning=bool(reasoning_effort or self.reasoning_effort),
                verbosity=None if resolved_output_schema is not None else resolved_verbosity,
                tools=resolved_tools,
                tool_choice=resolved_tool_choice,
                parallel_tool_calls=False,
                output_schema=resolved_output_schema,
            )
            for event in events:
                if isinstance(event, TextDelta):
                    text += event.text
                elif isinstance(event, ReasoningDelta):
                    reasoning += event.text
                elif isinstance(event, ToolCall):
                    tool_calls.append(event.raw)
                    should_resolve = self.resolve_tools if resolve_tools is None else resolve_tools
                    if should_resolve and len(tool_results) == 0:
                        tool = self.get_local_tools().get(event.name)
                        if tool is not None:
                            output = str(tool(**event.parsed_arguments()))
                            tool_results.append(modict(
                                call_id=event.call_id,
                                name=event.name,
                                output=output,
                            ))
                elif isinstance(event, OutputItem):
                    output_items.append(event.raw)
                elif isinstance(event, ResponseFailed):
                    raise RuntimeError(f"[{event.code}] {event.message}")
        except ResponseAborted:
            raise

        if tool_results:
            tool_output = "\n".join(result.output for result in tool_results)
            text = f"{text}\n{tool_output}".strip() if text else tool_output

        return modict(
            content=text,
            reasoning=reasoning,
            tool_calls=tool_calls,
            tool_results=tool_results,
            output_items=output_items,
        )

    def __call__(self, prompt, **kwargs):
        return self.run(prompt, **kwargs).content

    def abort(self):
        if self._client is not None:
            self._client.abort()


class SummarizerWorker(Worker):
    name = "summarizer"
    system_prompt = """You are a focused summarization worker.

Return a compact, faithful summary of the supplied content.
Preserve names, decisions, constraints, unresolved questions, and concrete facts.
Remove repetition and conversational filler.
"""


class TurnSummaryWorker(Worker):
    name = "turn_summary"
    model = "gpt-5.4-mini"
    system_prompt = """You are a RAG archive worker.

Summarize one complete conversation turn into exactly one dense, semantically meaningful paragraph.
This will be used to populate a long-term memory store that the AI assistant can retrieve from in future conversations.
Focus on what is worth remembering long term for the AI assistant, not on the incidental details that are only relevant in the moment.
The turn may contain the user request, assistant messages and reasoning summaries, tool calls, tool results, server-tool outputs, generated files, errors, interruptions, and the final assistant response.
Preserve the user's intent, important facts, constraints, decisions, actions performed, concrete artifacts such as file paths or commands, final outcome, and any unresolved state.
Ignore operational noise, raw payloads, base64 data, duplicate stream fragments, and incidental logs unless they changed the outcome.
If the turn does not contain anything genuinely useful to remember long term, such as a simple greeting, thanks, acknowledgement, or other exchange with no durable user information, durable decision, artifact, or unresolved state, return an empty string.
Return only the paragraph, with no title, bullets, Markdown, JSON, or commentary.
"""

    def summarize_turn(self, turn, previous_summary=None, **kwargs):
        prompt = "\n\n".join(message.as_string() for message in turn)
        if previous_summary:
            prompt = (
                "Previous turn summary for background only. Do not summarize this previous summary; "
                "use it only to understand the immediate prior context and formulate the new turn summary better.\n"
                f"<previous_turn_summary>\n{previous_summary}\n</previous_turn_summary>\n\n"
                "<turn_to_summarize>\n"
                f"{prompt}\n"
                "</turn_to_summarize>"
            )
        return self.run(prompt, **kwargs).content
