"""Built-in slash commands."""

from .command import command
from .tool import get_agent


MODEL_CONFIG_KEYS = (
    "model",
    "reasoning_effort",
    "verbosity",
    "input_token_limit",
    "max_input_tokens",
    "auto_compact",
)


def parse_config_value(value):
    if isinstance(value, bool):
        return value
    if not isinstance(value, str):
        return value

    lowered = value.lower()
    if lowered in ("true", "yes", "on", "1"):
        return True
    if lowered in ("false", "no", "off", "0"):
        return False
    if value.isdigit():
        return int(value)
    return value


def format_model_config(agent):
    return "\n".join(f"{key}: {agent.config.get(key)!r}" for key in MODEL_CONFIG_KEYS)


def update_model_config(**values):
    agent = get_agent()
    updates = {key: parse_config_value(value) for key, value in values.items()}
    unknown = sorted(key for key in updates if key not in MODEL_CONFIG_KEYS)
    if unknown:
        raise ValueError(f"Unknown model config keys: {', '.join(unknown)}")
    agent.update_config(updates)
    changed = ", ".join(f"{key}={agent.config.get(key)!r}" for key in updates)
    return f"Updated config: {changed}" if changed else format_model_config(agent)


@command
def help():
    agent = get_agent()
    names = ", ".join(f"/{name}" for name in sorted(agent.commands))
    return f"Available commands: {names}"


@command
def compact():
    agent = get_agent()
    message = agent.session.compact(
        model=agent.config.model,
        instructions=agent.get_system_message().content,
    )
    if message is None:
        return "Nothing to compact."
    return f"Compacted {message.compacted_message_count} messages."


@command
def sessions():
    agent = get_agent()
    session_ids = agent.get_sessions()
    if not session_ids:
        return "No saved sessions."
    lines = []
    for session_id in session_ids:
        prefix = "* " if session_id == agent.current_session_id else "  "
        lines.append(f"{prefix}{session_id}")
    return "\n".join(lines)


@command
def new_session():
    agent = get_agent()
    session = agent.start_new_session()
    return f"Created session: {session.session_id}"


@command
def load_session(session_id="latest"):
    agent = get_agent()
    session = agent.load_session(session_id)
    return f"Loaded session: {session.session_id}"


@command
def delete_session(session_id):
    agent = get_agent()
    deleted_id = agent.delete_session(session_id)
    return f"Deleted session: {deleted_id}"


@command
def next_session():
    session = get_agent().navigate_session("next")
    return f"Loaded session: {session.session_id}"


@command
def previous_session():
    session = get_agent().navigate_session("previous")
    return f"Loaded session: {session.session_id}"


@command
def config(**values):
    return update_model_config(**values)


@command
def model(value=None):
    if value is None:
        return f"model: {get_agent().config.model!r}"
    return update_model_config(model=value)


@command
def reasoning(value=None):
    if value is None:
        return f"reasoning_effort: {get_agent().config.reasoning_effort!r}"
    return update_model_config(reasoning_effort=value)


@command
def verbosity(value=None):
    if value is None:
        return f"verbosity: {get_agent().config.verbosity!r}"
    return update_model_config(verbosity=value)
