from .message import DeveloperMessage
from contextvars import ContextVar
from modict import modict
from typing import get_args, get_origin, Literal, Union
import json
import inspect

TOOL_MARKER = "__codex_agent_tool__"
_current_agent = ContextVar("codex_agent_current_agent", default=None)


def tool(func=None, **options):
    """Mark a function as an agent tool for automatic discovery."""
    if func is None:
        def decorator(f):
            return tool(f, **options)
        return decorator

    setattr(func, TOOL_MARKER, modict(options))
    return func


def tool_options(func):
    return getattr(func, TOOL_MARKER, None)


def get_agent():
    agent = _current_agent.get()
    if agent is None:
        raise RuntimeError("No current agent is available outside an agent tool call.")
    return agent


def set_current_agent(agent):
    return _current_agent.set(agent)


def reset_current_agent(token):
    _current_agent.reset(token)


class ServerTool(modict):
    """Responses API server-side tool without a local Python handler."""

    type = None

    def to_response_tool(self):
        return {key: value for key, value in self.items() if value is not None}


class WebSearchTool(ServerTool):
    type = "web_search"


class ImageGenerationTool(ServerTool):
    type = "image_generation"
    output_format = "png"
    size = None
    quality = None
    background = None
    moderation = None


class Tool:
    """Local tool callable exposed to the model."""

    def __init__(
        self,
        obj,
        name=None,
        description=None,
        parameters=None,
        required=None,
        type=None,
        mode=None,
        format=None,
    ):
        self.obj=obj
        self.name=name or getattr(obj,'__name__',None) or obj.__class__.__name__ 
        self.schema:modict=self.infer_schema()
        self.schema.update(self.parse_doc())
        if description:
            self.schema.description=description
        if parameters:
            self.schema.parameters=parameters
        if required:
            self.schema.required=required
        if format:
            self.schema.format=format
        self.mode = mode or self.schema.pop('mode', None) or 'api'
        self.type = type or self.schema.pop('type',None) or 'function'
        self.format = self.schema.pop('format', None)

    def __getattr__(self,name):
        return getattr(self.obj,name)

    def __call__(self,*args,**kwargs):
        return self.obj(*args,**kwargs)

    def infer_schema(self):
        try:
            signature = inspect.signature(self.obj)
        except (TypeError, ValueError):
            return modict()

        parameters = modict()
        required = []
        for name, parameter in signature.parameters.items():
            if name in ("self", "cls"):
                continue
            if parameter.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                continue

            schema = self.annotation_to_schema(parameter.annotation)
            if parameter.default is inspect.Parameter.empty:
                required.append(name)
            else:
                schema["default"] = parameter.default
            parameters[name] = schema

        return modict(parameters=parameters, required=required)

    def annotation_to_schema(self, annotation):
        if annotation is inspect.Parameter.empty:
            return {"type": "string"}

        origin = get_origin(annotation)
        args = get_args(annotation)

        if origin is Literal:
            values = list(args)
            schema = {"enum": values}
            if values:
                schema["type"] = self.json_type(type(values[0]))
            return schema

        if origin in (list, tuple, set):
            item_type = args[0] if args else str
            return {
                "type": "array",
                "items": self.annotation_to_schema(item_type),
            }

        if origin is dict:
            return {"type": "object"}

        if origin is Union:
            non_null_args = [arg for arg in args if arg is not type(None)]
            if len(non_null_args) == 1:
                schema = self.annotation_to_schema(non_null_args[0])
                schema["nullable"] = True
                return schema
            return {"anyOf": [self.annotation_to_schema(arg) for arg in non_null_args]}

        return {"type": self.json_type(annotation)}

    def json_type(self, python_type):
        return {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            dict: "object",
            list: "array",
            tuple: "array",
            set: "array",
        }.get(python_type, "string")

    def parse_doc(self):
        """Parses the YAML docstring of the tool's function to extract metadata.

        Returns:
            modict: Schema containing description, parameters, and required fields.
        """
        import yaml
        from textwrap import dedent

        doc = self.obj.__doc__
        if not doc:
            return modict()

        # Nettoie l'indentation avec dedent, puis strip les quotes et espaces
        doc_str = dedent(doc).strip().strip('"""').strip("'''").strip()

        try:
            schema = yaml.safe_load(doc_str)
            if not isinstance(schema, dict):
                return modict(description=doc_str)
        except Exception:
            return modict(description=doc_str)

        return modict(schema)

    def to_response_tool(self):
        """Converts the Tool object into a Responses API tool schema."""
        if self.type == "custom":
            tool = dict(
                type="custom",
                name=self.name,
                description=self.schema.get('description','No description provided'),
            )
            if self.format:
                tool["format"] = dict(self.format)
            return tool

        properties=dict()
        for name,param in self.schema.get('parameters',{}).items():
            if isinstance(param,dict):
                properties[name]=dict(param)
            elif isinstance(param,str):
                properties[name]=param

        tool=dict(
            type="function",
            name=self.name,
            description=self.schema.get('description','No description provided'),
            parameters=dict(
                type="object",
                properties=properties,
                required=self.schema.get('required',[])
            ),
        )
        return tool
    
    def to_developer_message(self):
        """Converts the Tool object into a developer message for parsed tool guidance.
        For tools that don't use the usual API function call pipeline, this can be used to provide the AI with the tool's schema in a more flexible way.

        Returns:
            Message: Developer message containing the tool's schema.
        """
        return DeveloperMessage(content=f"Tool: {self.name}\nSchema:\n{json.dumps(self.to_response_tool(), indent=2, ensure_ascii=False)}")
