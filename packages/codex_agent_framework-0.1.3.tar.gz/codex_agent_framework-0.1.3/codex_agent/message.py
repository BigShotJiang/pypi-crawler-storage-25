from modict import modict
from .utils import short_id, snake_case_type, timestamp, format
import base64
import json
from textwrap import dedent
from xml.sax.saxutils import escape, quoteattr


OUTPUT_ITEMS_ATTR = "_output_items"


class MessageChunk(modict):
    """Streaming chunk emitted by the model."""

    content = ''
    reasoning = ''
    tool_calls = None
    output_items = None


class Message(modict):
    """Base persisted message.

    Concrete subclasses own API formatting. The ``type`` field mirrors the
    subclass name in snake case.
    """

    content = ''
    name = ''
    reasoning = ''
    id = modict.factory(lambda: short_id())
    session_id = None
    timestamp = modict.factory(lambda: timestamp())
    lasting = 0
    turns_left = -1
    embedding = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self['type'] = snake_case_type(type(self))

    def format(self, context=None):
        msg = type(self)(self)
        if isinstance(msg.get('content'), str):
            msg.content = format(msg.content, context=context)
        return msg

    def text_part(self, output=False):
        text_type = "output_text" if output else "input_text"
        return {"type": text_type, "text": str(self.get('content') or "")}

    def content_to_response_parts(self, output=False):
        content = self.get("content", "")
        if not isinstance(content, list):
            return [self.text_part(output=output)]

        text_type = "output_text" if output else "input_text"
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append({"type": text_type, "text": part})
            elif isinstance(part, dict) and part.get("type") == "text":
                parts.append({"type": text_type, "text": part.get("text", "")})
            else:
                parts.append(dict(part))
        return parts

    def to_response_format(self):
        raise NotImplementedError(f"{type(self).__name__} must implement to_response_format()")

    def as_string(self):
        tag = type(self).__name__
        params = self.as_string_attrs()
        content = self.as_string_body()
        return dedent(
            f"""<{tag} {params}>
            {content}
            </{tag}>"""
        )

    def as_string_attrs(self):
        return self.format_as_string_attrs(self.extract('name', 'type', 'timestamp'))

    def format_as_string_attrs(self, attrs):
        return ' '.join(f"{k}={v!r}" for k, v in attrs.items() if v is not None)

    def as_string_body(self):
        return str(self.get('content') or '')


class TextMessage(Message):
    role = "user"

    def to_response_format(self):
        role = self.role
        return {
            "type": "message",
            "role": role,
            "content": self.content_to_response_parts(output=(role == "assistant")),
        }


class UserMessage(TextMessage):
    role = "user"


class SystemMessage(TextMessage):
    role = "system"

    def to_response_format(self):
        return None


class DeveloperMessage(TextMessage):
    role = "developer"


class ProviderMessage(DeveloperMessage):
    def content_to_response_parts(self, output=False):
        content = str(self.get("content") or "")
        name = self.get("name") or "provider"
        wrapped = f'<context_provider name="{name}">\n{content}\n</context_provider>'
        return [{"type": "input_text", "text": wrapped}]


class CompactionMessage(DeveloperMessage):
    name = "compaction"
    content = "Previous conversation context was compacted by the backend."
    response_id = ""
    output_items = None
    compacted_message_count = 0

    def to_response_format(self):
        return list(self.get("output_items") or [])

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["response_id"] = self.get("response_id")
        attrs["compacted_message_count"] = self.get("compacted_message_count")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        summary = next(
            (item for item in self.get("output_items") or [] if item.get("type") == "compaction_summary"),
            None,
        )
        if not summary:
            return self.content
        return dedent(
            f"""{self.content}
            <compaction_summary id={summary.get('id', '')!r}>
            opaque backend summary
            </compaction_summary>"""
        )


class AssistantMessage(TextMessage):
    role = "assistant"

    def to_response_format(self):
        items = []
        if self.get("content"):
            items.append({
                "type": "message",
                "role": "assistant",
                "content": self.content_to_response_parts(output=True),
            })
        for tool_call in self.get("tool_calls") or []:
            if tool_call.get("type") == "custom_tool_call":
                items.append({
                    "type": "custom_tool_call",
                    "call_id": tool_call.get("call_id", ""),
                    "name": tool_call.get("name", ""),
                    "input": tool_call.get("input", ""),
                })
            else:
                items.append({
                    "type": "function_call",
                    "call_id": tool_call.get("call_id", ""),
                    "name": tool_call.get("name", ""),
                    "arguments": tool_call.get("arguments", "{}"),
                })
        return items

    def get_tool_call_by_index(self, index):
        for tool_call in self.get('tool_calls', []):
            if tool_call.get('index') == index:
                return tool_call
        return None

    def add_chunk(self, msg_chunk: MessageChunk):
        self.content += msg_chunk.get('content') or ''
        self.reasoning += msg_chunk.get('reasoning') or ''
        for tool_call in msg_chunk.get('tool_calls') or []:
            existing_tool_call = self.get_tool_call_by_index(tool_call.index)
            if existing_tool_call is None:
                self.setdefault('tool_calls', []).append(tool_call)
            else:
                existing_tool_call.arguments += tool_call.get('arguments', '')
        for item in msg_chunk.get('output_items') or []:
            self.output_items.append(item)

    @property
    def output_items(self):
        items = self.get_attr(OUTPUT_ITEMS_ATTR, None)
        if items is None:
            items = []
            self.set_attr(OUTPUT_ITEMS_ATTR, items)
        return items

    def as_string_body(self):
        body = super().as_string_body()
        tool_calls = [self.tool_call_as_string(tool_call) for tool_call in self.get("tool_calls") or []]
        return "\n".join(part for part in [body, *tool_calls] if part)

    def tool_call_as_string(self, tool_call):
        params = {
            "type": tool_call.get("type") or "function_call",
            "name": tool_call.get("name", ""),
            "call_id": tool_call.get("call_id", ""),
        }
        attrs = " ".join(f"{key}={value!r}" for key, value in params.items() if value)
        content = tool_call.get("input") if tool_call.get("type") == "custom_tool_call" else tool_call.get("arguments", "")
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False, default=str)
        return dedent(
            f"""<tool_call {attrs}>
            {content}
            </tool_call>"""
        )


class ToolResultMessage(Message):
    role = "tool"
    call_id = ''
    tool_call_type = "function_call"

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["call_id"] = self.get("call_id", "")
        attrs["tool_call_type"] = self.get("tool_call_type", "")
        return self.format_as_string_attrs(attrs)

    def to_response_format(self):
        if self.get("tool_call_type") == "custom_tool_call":
            return {
                "type": "custom_tool_call_output",
                "call_id": self.get("call_id", ""),
                "output": self.get("content", ""),
            }
        return {
            "type": "function_call_output",
            "call_id": self.get("call_id", ""),
            "output": self.get("content", ""),
        }


class ToolResultWrapper(DeveloperMessage):
    name = "tool_result_wrapper"
    call_id = ""
    tool_name = ""
    status = "success"
    turns_left = 3

    def content_to_response_parts(self, output=False):
        attrs = {
            "call_id": self.get("call_id", ""),
            "tool_name": self.get("tool_name", ""),
            "status": self.get("status", ""),
            "wrapper_id": self.get("id", ""),
        }
        attr_text = " ".join(
            f"{key}={quoteattr(str(value))}"
            for key, value in attrs.items()
            if value
        )
        wrapped = (
            f"<tool_result_wrapper {attr_text}>\n"
            f"{escape(str(self.get('content') or ''))}\n"
            f"</tool_result_wrapper>"
        )
        return [{"type": "input_text", "text": wrapped}]

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["call_id"] = self.get("call_id", "")
        attrs["tool_name"] = self.get("tool_name", "")
        attrs["status"] = self.get("status", "")
        return self.format_as_string_attrs(attrs)


class ServerToolResponseMessage(Message):
    item = None

    def __init__(self, *args, **kwargs):
        args, kwargs = self._prepare_init_payload(args, kwargs)
        super().__init__(*args, **kwargs)

    @classmethod
    def _prepare_init_payload(cls, args, kwargs):
        kwargs = dict(kwargs)
        data = dict(args[0]) if args and isinstance(args[0], dict) else None

        item = kwargs.get("item")
        if data and "item" in data and "item" not in kwargs:
            item = data["item"]

        item = dict(item or {})
        if item.get("type") != "image_generation_call" or not item.get("result"):
            return args, kwargs

        from .image import persist_image_bytes

        image_bytes = base64.b64decode(item["result"])
        image_path = persist_image_bytes(image_bytes, name=f"{item.get('id') or 'image_generation'}.png")
        item.pop("result", None)

        if data is not None:
            data["item"] = item
            data.setdefault("content", image_path)
            args = (data, *args[1:])
        else:
            kwargs["item"] = item
            kwargs.setdefault("content", image_path)
        return args, kwargs

    def to_response_format(self):
        item = dict(self.item or {})
        if item.get("type") == "image_generation_call" and "result" not in item and self.get("content"):
            from .image import data_url_from_file

            return [
                {
                    "type": "message",
                    "role": "user",
                    "content": [
                        {
                            "type": "input_image",
                            "image_url": data_url_from_file(self.content),
                            "detail": "auto",
                        },
                        {
                            "type": "input_text",
                            "text": (
                                "This is an image previously generated by the image_generation tool. "
                                "Use it as the base image for any requested follow-up image edits."
                            ),
                        },
                    ],
                },
                {
                    "type": "message",
                    "role": "developer",
                    "content": [{
                        "type": "input_text",
                        "text": (
                            "The generated image has also been saved locally at: "
                            f"{self.content}\n"
                            "Use the show tool to open it for the user, or observe it if visual analysis is needed."
                        ),
                    }],
                },
            ]
        return item

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        item = self.get("item") or {}
        attrs["item_type"] = item.get("type")
        attrs["item_id"] = item.get("id")
        attrs["status"] = item.get("status")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        parts = []
        if self.get("content"):
            parts.append(str(self.content))
        if self.get("item"):
            parts.append(dedent(
                f"""<server_tool_item>
                {json.dumps(self.item, ensure_ascii=False, default=str)}
                </server_tool_item>"""
            ))
        return "\n".join(parts)

    def as_image_message(self):
        from .image import ImageMessage

        if self.get("content") and self.get("item", {}).get("type") == "image_generation_call":
            return ImageMessage(content=self.content, image_name=self.get("name") or self.get("item", {}).get("id"))
        return None


MESSAGE_TYPES = {
    snake_case_type(cls): cls
    for cls in (
        UserMessage,
        SystemMessage,
        DeveloperMessage,
        ProviderMessage,
        CompactionMessage,
        AssistantMessage,
        ToolResultMessage,
        ToolResultWrapper,
        ServerToolResponseMessage,
    )
}

def message_from_data(data=None, **kwargs):
    data = dict(data or {})
    data.update(kwargs)

    cls = MESSAGE_TYPES.get(data.get('type'))
    if cls is None:
        raise ValueError(f"Unknown or missing message type: {data.get('type')!r}")
    data.pop('type', None)
    data.pop('role', None)
    return cls(data)


def register_message_type(cls):
    MESSAGE_TYPES[snake_case_type(cls)] = cls
    return cls
