
def get_text(source, **kwargs):
    """Get text from a source using the full or simpler implementation.

    Args:
        source: The source to get text from.
        **kwargs: Additional keyword arguments.
    Returns:
        Text content from the source.
    """
    # Try to import full get_text with all document processing capabilities
    # Fall back to simpler version if dependencies are missing
    try:
        from importlib import import_module
        get_text_func = import_module(".get_text", __package__).get_text
    except ImportError:
        from importlib import import_module
        get_text_func = import_module(".simpler_get_text", __package__).get_text

    return get_text_func(source, **kwargs)
