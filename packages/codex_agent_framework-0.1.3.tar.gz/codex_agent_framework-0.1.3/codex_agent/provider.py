from modict import modict


PROVIDER_MARKER = "__codex_agent_provider__"


def provider(func=None, **options):
    """Mark a function as an agent context provider for automatic discovery."""
    if func is None:
        def decorator(f):
            return provider(f, **options)
        return decorator

    setattr(func, PROVIDER_MARKER, modict(options))
    return func


def provider_options(func):
    return getattr(func, PROVIDER_MARKER, None)
