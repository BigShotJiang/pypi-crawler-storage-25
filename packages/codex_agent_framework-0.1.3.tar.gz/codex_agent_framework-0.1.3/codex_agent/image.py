from .message import Message, register_message_type
from .utils import guess_extension_from_bytes, runtime_join, short_id, timestamp
import base64
import binascii
from collections.abc import Mapping
from io import BytesIO
import os
import re

from PIL import Image as PILImage
import requests
from urllib.parse import urlparse


IMAGE_CACHE_ATTR = 'b64_string'
IMAGE_DIR = 'images'


def ext_to_mime(ext):
    ext = ext.lower().lstrip('.')
    if ext in ('jpg', 'jpeg'):
        return 'image/jpeg'
    if ext == 'png':
        return 'image/png'
    if ext == 'webp':
        return 'image/webp'
    if ext == 'gif':
        return 'image/gif'
    return None


def _data_url(data, mime_type):
    b64 = base64.b64encode(data).decode('utf-8')
    return f"data:{mime_type};base64,{b64}"


def data_url_from_file(path):
    ext = os.path.splitext(path)[1]
    mime_type = ext_to_mime(ext) or 'image/jpeg'
    with open(path, 'rb') as f:
        return _data_url(f.read(), mime_type)


def image_request_headers(url):
    """Return browser-like headers for remote image fetches.

    Some image hosts/CDNs reject the default python-requests user agent even
    for public images. A small, stable header set makes observe() much more
    reliable without changing semantics.
    """
    parsed = urlparse(url)
    referer = f"{parsed.scheme}://{parsed.netloc}/" if parsed.scheme and parsed.netloc else None
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 codex-agent/observe"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    }
    if referer:
        headers["Referer"] = referer
    return headers


def image_mime_from_source(source, content_type=None):
    content_type = (content_type or '').split(';')[0].strip()
    if content_type.startswith('image/'):
        return content_type
    if isinstance(source, str):
        ext = os.path.splitext(source.split('?', 1)[0])[1]
        return ext_to_mime(ext) or 'image/jpeg'
    return 'image/png'


def fetch_image_bytes(url, timeout=15):
    response = requests.get(url, timeout=timeout, headers=image_request_headers(url))
    response.raise_for_status()

    data = response.content
    if not data:
        raise ValueError(f"URL resolved to an empty image response: {url!r}")

    content_type = response.headers.get('content-type')
    content_mime = (content_type or '').split(';')[0].strip()
    guessed_mime = ext_to_mime(guess_extension_from_bytes(data) or '')

    if content_mime and not content_mime.startswith('image/'):
        if not guessed_mime:
            raise ValueError(f"URL did not resolve to an image: {url!r} ({content_mime})")
        return data, guessed_mime

    return data, guessed_mime or image_mime_from_source(url, content_type)


def data_url_from_url(url):
    data, mime_type = fetch_image_bytes(url)
    return _data_url(data, mime_type)


def persist_image_url(url):
    data, mime_type = fetch_image_bytes(url)
    ext = os.path.splitext(url.split('?', 1)[0])[1] or None
    mime_ext = {
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/webp': '.webp',
        'image/gif': '.gif',
    }.get(mime_type)
    if mime_ext and ext_to_mime(ext or '') != mime_type:
        ext = mime_ext
    return persist_image_bytes(data, name=f"remote{ext or ''}")


def get_data_url(source):
    if isinstance(source, str) and os.path.isfile(source):
        return data_url_from_file(source)
    if isinstance(source, str) and source.startswith(('http://', 'https://')):
        return data_url_from_url(source)
    raise ValueError(f"Unsupported image source: {source!r}")


def persist_image_bytes(data, name=None):
    _, ext = os.path.splitext(name) if isinstance(name, str) else ('', '')
    ext = ext or guess_extension_from_bytes(data) or '.png'

    folder = runtime_join(IMAGE_DIR)
    os.makedirs(folder, exist_ok=True)

    path = runtime_join(IMAGE_DIR, f"{timestamp()}_{short_id()}{ext}")
    with open(path, 'wb') as f:
        f.write(data)
    return path


def persist_bytesio(source):
    return persist_image_bytes(source.getvalue(), name=getattr(source, 'name', None))


def image_name_from_source(source):
    if isinstance(source, BytesIO) and getattr(source, 'name', None):
        return os.path.basename(source.name)
    if isinstance(source, str) and os.path.isfile(source):
        return os.path.basename(source)
    if source:
        return str(source)
    return 'Unnamed image'


def normalize_image_content(content):
    if isinstance(content, BytesIO):
        return persist_bytesio(content)
    if isinstance(content, bytes):
        return persist_image_bytes(content)
    if content is not None and not isinstance(content, str):
        raise TypeError(f"Image content must be a path, URL, BytesIO, or bytes. Got {type(content).__name__}.")
    return content


@register_message_type
class ImageMessage(Message):
    """Image message with a lightweight serialized payload.

    The session stores only reloadable ``content``. The base64 data URL is
    cached as runtime metadata and generated only when formatting API input.
    """

    detail = "auto"
    description = None
    image_name = None
    embedding = None
    name = 'image'
    role = "user"

    def __init__(self, *args, **kwargs):
        args, kwargs, data_url, content_name = self._prepare_init_payload(args, kwargs)
        super().__init__(*args, **kwargs)

        if not self.get('image_name'):
            self.image_name = content_name or image_name_from_source(self.get('content'))

        if data_url:
            self.set_attr(IMAGE_CACHE_ATTR, data_url)

    @classmethod
    def _prepare_init_payload(cls, args, kwargs):
        kwargs = dict(kwargs)
        data_url = kwargs.pop(IMAGE_CACHE_ATTR, None)
        content = kwargs.get('content')

        if args and isinstance(args[0], Mapping):
            data = dict(args[0])
            data_url = data.pop(IMAGE_CACHE_ATTR, data_url)
            if 'content' in data:
                if 'content' not in kwargs:
                    content = data['content']
                data['content'] = normalize_image_content(data['content'])
            args = (data, *args[1:])

        if 'content' in kwargs:
            content = kwargs['content']
            kwargs['content'] = normalize_image_content(content)

        content_name = image_name_from_source(content) if content is not None else None
        return args, kwargs, data_url, content_name

    def get_base64(self):
        data_url = self.get_attr(IMAGE_CACHE_ATTR, None)
        if data_url:
            return data_url

        try:
            data_url = get_data_url(self.get('content'))
        except Exception:
            return None

        self.set_attr(IMAGE_CACHE_ATTR, data_url)
        return data_url

    def is_valid(self):
        data_url = self.get_base64()
        if not isinstance(data_url, str) or not data_url.startswith('data:image/'):
            return False
        match = re.match(r"^data:image/[^;]+;base64,(.*)$", data_url)
        if not match:
            return False
        try:
            image_bytes = base64.b64decode(match.group(1), validate=True)
        except (binascii.Error, ValueError):
            return False
        try:
            with PILImage.open(BytesIO(image_bytes)) as img:
                img.verify()
        except Exception:
            return False
        return True

    def content_to_response_parts(self, output=False):
        data_url = self.get_base64()
        if not data_url:
            return [{
                'type': 'input_text',
                'text': f"Unable to access the image ({self.image_name!r})",
            }]

        text = (
            "The following image has been made available in context for visual analysis:\n"
            + repr(self.image_name)
        )
        if self.get('description'):
            text += f"\nAlong with the following description:\n{self.description}\n"

        return [
            {
                'type': 'input_image',
                'image_url': data_url,
                'detail': self.detail,
            },
            {
                'type': 'input_text',
                'text': text,
            },
        ]

    def to_response_format(self):
        return {
            "type": "message",
            "role": self.role,
            "content": self.content_to_response_parts(),
        }

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["image_name"] = self.get("image_name")
        attrs["detail"] = self.get("detail")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        parts = []
        if self.get("content"):
            parts.append(f"<source>{self.content}</source>")
        if self.get("description"):
            parts.append(f"<description>{self.description}</description>")
        return "\n".join(parts)

    def as_bytesio(self):
        data_url = self.get_base64()
        if not data_url:
            return None

        match = re.match(r"^data:image/[^;]+;base64,(.*)$", data_url)
        if not match:
            return None
        return BytesIO(base64.b64decode(match.group(1)))

    def show(self):
        img_bytes = self.as_bytesio()
        if not img_bytes:
            print("[ImageMessage.show] Image non disponible en mémoire.")
            return

        try:
            PILImage.open(img_bytes).show()
        except Exception as e:
            print(f"[ImageMessage.show] Erreur lors de l'affichage : {e}")
