"""Built-in ephemeral context providers."""

from datetime import datetime
import os

from .memory import format_memory_results_xml
from .provider import provider
from .tool import get_agent


@provider
def date_and_time():
    now = datetime.now().astimezone()
    return f"Current date and time: {now.strftime('%Y-%m-%d %H:%M:%S %Z%z')}"


@provider
def cwd():
    return f"Current working directory: {os.getcwd()}"


@provider
def retrieved_memory():
    agent = get_agent()
    if not agent.memory.messages:
        return None

    context = [
        msg for msg in agent.session.context_messages()
        if agent.is_message_visible_in_context(msg)
    ]
    if not context:
        return None

    results = agent.memory.retrieve(
        context,
        max_tokens=agent.config.max_memory_tokens,
        until=agent.memory_retrieval_until_timestamp(),
    )
    if not results:
        return None
    return format_memory_results_xml(results, root="retrieved_memories")
