from types import SimpleNamespace

from codex_agent.ai import AIClient, MAX_EMBEDDING_INPUT_TOKENS
from codex_agent.utils import token_count


class FakeEmbeddings:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(data=[SimpleNamespace(embedding=[1.0, 0.0])])


class FakeOpenAIClient:
    def __init__(self):
        self.embeddings = FakeEmbeddings()


def test_embed_content_truncates_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_content(long_content)

    embedded_input = ai._client.embeddings.calls[0]["input"]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS


def test_embed_contents_truncates_each_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_contents([long_content])

    embedded_input = ai._client.embeddings.calls[0]["input"][0]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS
