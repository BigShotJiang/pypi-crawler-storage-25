import json
import os
from io import BytesIO

import pytest
from PIL import Image as PILImage

from codex_agent.agent import to_message
from codex_agent.image import ImageMessage


def png_bytesio(name="pixel.png"):
    stream = BytesIO()
    PILImage.new("RGB", (1, 1), (0, 255, 0)).save(stream, format="PNG")
    stream.name = name
    return stream


def test_image_message_persists_bytesio_as_serializable_content():
    message = ImageMessage(content=png_bytesio())
    payload = json.loads(json.dumps(message))

    assert payload["type"] == "image_message"
    assert payload["role"] == "user"
    assert isinstance(payload["content"], str)
    assert os.path.isfile(payload["content"])
    assert "base64" not in json.dumps(payload)
    assert isinstance(to_message(payload), ImageMessage)


def test_image_message_formats_to_response_image_parts():
    message = ImageMessage(content=png_bytesio())
    content = message.to_response_format()["content"]

    assert content[0]["type"] == "input_image"
    assert content[0]["image_url"].startswith("data:image/png;base64,")
    assert content[1]["type"] == "input_text"

def test_image_message_is_valid_for_real_image():
    message = ImageMessage(content=png_bytesio())
    assert message.is_valid() is True


def test_image_message_is_invalid_for_missing_file():
    message = ImageMessage(content="/tmp/definitely-missing-image.png")
    assert message.is_valid() is False


def test_data_url_from_url_uses_browser_like_headers(monkeypatch):
    from codex_agent import image as image_module

    captured = {}

    class Response:
        content = png_bytesio().getvalue()
        headers = {"content-type": "image/png"}

        def raise_for_status(self):
            pass

    def fake_get(url, **kwargs):
        captured["url"] = url
        captured["kwargs"] = kwargs
        return Response()

    monkeypatch.setattr(image_module.requests, "get", fake_get)

    data_url = image_module.data_url_from_url("https://example.com/pixel.png")

    assert data_url.startswith("data:image/png;base64,")
    assert captured["kwargs"]["timeout"] == 15
    assert "Mozilla/5.0" in captured["kwargs"]["headers"]["User-Agent"]
    assert captured["kwargs"]["headers"]["Referer"] == "https://example.com/"


def test_fetch_image_bytes_rejects_non_image_responses(monkeypatch):
    from codex_agent import image as image_module

    class Response:
        content = b"<html>not an image</html>"
        headers = {"content-type": "text/html"}

        def raise_for_status(self):
            pass

    monkeypatch.setattr(image_module.requests, "get", lambda *args, **kwargs: Response())

    with pytest.raises(ValueError, match="did not resolve to an image"):
        image_module.fetch_image_bytes("https://example.com/not-really.jpg")


def test_persist_image_url_downloads_remote_image_once(monkeypatch, tmp_path):
    from codex_agent import image as image_module

    calls = []

    class Response:
        content = png_bytesio("remote.png").getvalue()
        headers = {"content-type": "image/png"}

        def raise_for_status(self):
            pass

    def fake_get(url, **kwargs):
        calls.append((url, kwargs))
        return Response()

    monkeypatch.setattr(image_module.requests, "get", fake_get)
    monkeypatch.setattr(image_module, "runtime_join", lambda *parts: str(tmp_path.joinpath(*parts)))

    path = image_module.persist_image_url("https://example.com/remote.png")

    assert os.path.isfile(path)
    assert calls and calls[0][0] == "https://example.com/remote.png"
    assert path.endswith(".png")


def test_observe_persists_remote_url_before_adding_image(monkeypatch):
    from codex_agent import builtin_tools
    from codex_agent.tool import reset_current_agent, set_current_agent

    added = []

    class FakeAgent:
        def add_image(self, **kwargs):
            added.append(kwargs)

    monkeypatch.setattr(builtin_tools, "persist_image_url", lambda url: "/tmp/cached-image.png")

    token = set_current_agent(FakeAgent())
    try:
        result = builtin_tools.observe("https://example.com/image.png")
    finally:
        reset_current_agent(token)

    assert added == [{
        "source": "/tmp/cached-image.png",
        "pending": True,
        "image_name": "https://example.com/image.png",
    }]
    assert "downloaded, cached" in result


def test_observe_keeps_local_image_name_inferred(monkeypatch):
    from codex_agent import builtin_tools
    from codex_agent.tool import reset_current_agent, set_current_agent

    added = []

    class FakeAgent:
        def add_image(self, **kwargs):
            added.append(kwargs)

    token = set_current_agent(FakeAgent())
    try:
        result = builtin_tools.observe("/tmp/local-image.png")
    finally:
        reset_current_agent(token)

    assert added == [{"source": "/tmp/local-image.png", "pending": True}]
    assert "loaded" in result
