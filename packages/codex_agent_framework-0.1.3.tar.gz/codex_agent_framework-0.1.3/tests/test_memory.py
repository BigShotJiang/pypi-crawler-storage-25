from datetime import datetime

import pytest

import codex_agent.utils as utils
from codex_agent import Agent
from codex_agent.memory import RAGMemory
from codex_agent.message import AssistantMessage, CompactionMessage, UserMessage
from codex_agent.tool import reset_current_agent, set_current_agent


def embedded_message(content, embedding, timestamp="20260101T120000.000", session_id=None):
    return UserMessage(
        content=content,
        embedding=embedding,
        timestamp=timestamp,
        session_id=session_id,
    )


def test_rank_weights_recent_context_messages_more_heavily():
    memory = RAGMemory(half_life_steps=2, moment_exponent=3)
    older_match = embedded_message("older topic", [1.0, 0.0])
    recent_match = embedded_message("recent topic", [0.0, 1.0])
    context = [
        UserMessage(content="older prompt", embedding=[1.0, 0.0]),
        AssistantMessage(content="recent answer", embedding=[0.0, 1.0]),
    ]

    ranked = memory.rank(context, messages=[older_match, recent_match], recent_is_better=False)

    assert ranked == [recent_match, older_match]
    assert memory.relevance_score(recent_match, context) > memory.relevance_score(older_match, context)


def test_rank_adds_pandora_style_temporal_recency_bonus():
    memory = RAGMemory(half_life_days=2)
    old = embedded_message("same topic, old", [1.0, 0.0], timestamp="20260101T120000.000")
    recent = embedded_message("same topic, recent", [1.0, 0.0], timestamp="20260103T120000.000")
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]
    now = datetime.strptime("20260103T120000.000", "%Y%m%dT%H%M%S.%f")

    ranked = memory.rank(context, messages=[old, recent], now=now)

    assert ranked == [recent, old]
    assert memory.temporal_score(recent, now=now) == pytest.approx(1.0)
    assert memory.temporal_score(old, now=now) == pytest.approx(0.5)


def test_retrieve_limits_and_excludes_current_session_without_mutating_memory():
    current = embedded_message("current session", [1.0, 0.0], session_id="current")
    first = embedded_message("best external", [1.0, 0.0], session_id="past")
    second = embedded_message("second external", [0.8, 0.2], session_id="past")
    memory = RAGMemory(messages=[current, first, second])
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]

    retrieved = memory.retrieve(
        context,
        limit=1,
        recent_is_better=False,
        exclude_session_id="current",
    )

    assert retrieved == [first]
    assert memory.messages == [current, first, second]


def test_retrieve_filters_memory_entries_between_timestamp_cutoffs():
    older = embedded_message("older", [1.0, 0.0], timestamp="20260101T120000.000")
    middle = embedded_message("middle", [1.0, 0.0], timestamp="20260102T120000.000")
    newer = embedded_message("newer", [1.0, 0.0], timestamp="20260103T120000.000")
    memory = RAGMemory(messages=[older, middle, newer])
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]

    retrieved = memory.retrieve(
        context,
        since="20260102T120000.000",
        until="20260103T120000.000",
        recent_is_better=False,
    )

    assert retrieved == [middle, newer]


def test_missing_embedding_requires_an_agent_capable_of_embedding():
    memory = RAGMemory()
    message = UserMessage(content="not embedded")

    with pytest.raises(ValueError, match="no embedding"):
        memory.rank([message], messages=[message])


class FakeEmbeddingAI:
    def embed_message(self, message, precision=5, dimensions=128):
        content = str(message.get("content") or "").lower()
        if "python" in content:
            embedding = [1.0, 0.0]
        elif "rust" in content:
            embedding = [0.0, 1.0]
        else:
            embedding = [0.7, 0.3]
        message.embedding = embedding
        return embedding


class StaticEmbeddingAI:
    def embed_message(self, message, precision=5, dimensions=128):
        message.embedding = [1.0, 0.0]
        return message.embedding


class FakeEmbeddingAgent:
    ai = StaticEmbeddingAI()


class OneShotAI:
    def run(self, **params):
        return AssistantMessage(content="done")


class FakeTurnSummaryWorker:
    turns = []
    previous_summaries = []

    def summarize_turn(self, turn, previous_summary=None):
        self.turns.append(turn)
        self.previous_summaries.append(previous_summary)
        return "Résumé durable du dernier tour."


class SynchronousThread:
    created = []

    def __init__(self, target, daemon=False):
        self.target = target
        self.daemon = daemon
        self.started = False
        self.created.append(self)

    def start(self):
        self.started = True
        self.target()


def test_agent_initializes_persistent_runtime_memory(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new", voice_enabled=False)

    assert agent.memory.agent is agent
    assert agent.memory.file == str(tmp_path / "memory.json")
    assert agent.memory.messages == []


def test_agent_archives_completed_turn_to_memory_fire_and_forget(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    monkeypatch.setattr("codex_agent.agent.TurnSummaryWorker", FakeTurnSummaryWorker)
    monkeypatch.setattr("codex_agent.agent.BackgroundThread", SynchronousThread)
    FakeTurnSummaryWorker.turns = []
    FakeTurnSummaryWorker.previous_summaries = []
    SynchronousThread.created = []

    agent = Agent(session="new", voice_enabled=False)
    agent.ai = OneShotAI()
    agent.memory.set_attr("_agent", agent)
    agent.ai.embed_message = FakeEmbeddingAI().embed_message
    agent.memory.remember(
        "Résumé du tour précédent.",
        title="turn:previous",
        source="turn_summary",
        metadata={"session_id": agent.current_session_id},
    )
    agent.add_message(UserMessage(content="Souviens-toi de ce tour."))

    assert agent.process() is True

    assert len(SynchronousThread.created) == 1
    assert SynchronousThread.created[0].daemon is True
    assert FakeTurnSummaryWorker.turns
    assert FakeTurnSummaryWorker.previous_summaries == ["Résumé du tour précédent."]
    assert any(isinstance(message, UserMessage) for message in FakeTurnSummaryWorker.turns[0])
    assert len(agent.memory.messages) == 2
    assert agent.memory.messages[-1].content == "Résumé durable du dernier tour."
    assert agent.memory.messages[-1].source == "turn_summary"


def test_memory_tools_create_edit_delete_and_persist_entries(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    token = set_current_agent(agent)
    try:
        created = agent.tools.memory_add(
            content="Python est le langage préféré de Baptiste.",
            title="language",
        )
        entry = agent.memory.messages[0]
        assert f"Created memory {entry.id}" in created
        assert entry.title == "language"
        assert (tmp_path / "memory.json").is_file()

        loaded = RAGMemory(file=str(tmp_path / "memory.json"))
        assert loaded.messages[0].id == entry.id
        assert loaded.messages[0].embedding == [1.0, 0.0]

        updated = agent.tools.memory_edit(
            memory_id="language",
            content="Rust est aussi important pour Baptiste.",
        )
        assert f"Updated memory {entry.id}" in updated
        assert agent.memory.messages[0].content.startswith("Rust")
        assert agent.memory.messages[0].embedding == [0.0, 1.0]

        deleted = agent.tools.memory_delete(memory_id="language")
        assert f"Deleted memory {entry.id}" in deleted
        assert agent.memory.messages == []
        assert RAGMemory(file=str(tmp_path / "memory.json")).messages == []
    finally:
        reset_current_agent(token)


def test_memory_search_tool_retrieves_without_adding_entries(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    agent.memory.remember("Python doit être favorisé pour les scripts.", title="python")
    agent.memory.remember("Rust est utile pour le code système.", title="rust")
    before = list(agent.memory.messages)

    token = set_current_agent(agent)
    try:
        result = agent.tools.memory_search(query="python scripting", limit=1)
    finally:
        reset_current_agent(token)

    assert result.startswith("<memory ")
    assert " id=" in result
    assert 'title="python"' in result
    assert "score=" not in result
    assert "Python doit être favorisé" in result
    assert result.endswith("</memory>")
    assert agent.memory.messages == before


def test_memory_search_tool_excludes_entries_after_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    before = agent.memory.remember("Python avant compaction.", title="before")
    after = agent.memory.remember("Python apres compaction.", title="after")
    before.timestamp = "20260101T120000.000"
    after.timestamp = "20260103T120000.000"
    agent.session.messages = [
        CompactionMessage(
            timestamp="20260102T120000.000",
            output_items=[{"type": "compaction_summary", "id": "cs_1"}],
        ),
        UserMessage(content="python now"),
    ]

    token = set_current_agent(agent)
    try:
        result = agent.tools.memory_search(query="python", limit=5)
    finally:
        reset_current_agent(token)

    assert 'title="before"' in result
    assert 'title="after"' not in result


def test_search_defaults_to_similarity_without_temporal_bonus():
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    similar_old = embedded_message(
        "semantic match",
        [1.0, 0.0],
        timestamp="20260101T120000.000",
    )
    less_similar_recent = embedded_message(
        "newer but weaker",
        [0.0, 1.0],
        timestamp="20260103T120000.000",
    )
    memory.messages = [less_similar_recent, similar_old]

    results = memory.search(
        "semantic query",
        limit=1,
        now=datetime.strptime("20260103T120000.000", "%Y%m%dT%H%M%S.%f"),
    )

    assert results == [similar_old]


def test_search_filters_memory_entries_between_timestamp_cutoffs():
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    older = embedded_message("older", [1.0, 0.0], timestamp="20260101T120000.000")
    middle = embedded_message("middle", [1.0, 0.0], timestamp="20260102T120000.000")
    newer = embedded_message("newer", [1.0, 0.0], timestamp="20260103T120000.000")
    memory.messages = [older, middle, newer]

    results = memory.search(
        "semantic query",
        since="20260102T120000.000",
        until="20260102T120000.000",
    )

    assert results == [middle]


def test_retrieved_memory_provider_uses_context_since_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    agent.memory.remember("Python doit être favorisé pour les scripts.", title="python")
    agent.memory.remember("Rust est utile pour le code système.", title="rust")

    old = UserMessage(content="python before compaction")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_1"}])
    current = UserMessage(content="rust now")
    agent.session.messages = [old, compaction, current]

    provider_output = next(
        message.content for message in agent.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert provider_output.startswith("<retrieved_memories>")
    assert 'title="rust"' in provider_output
    assert 'title="python"' in provider_output
    assert provider_output.index('title="rust"') < provider_output.index('title="python"')
    assert old.embedding is None
    assert current.embedding == [0.0, 1.0]


def test_retrieved_memory_provider_excludes_entries_after_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    before = agent.memory.remember("Rust avant compaction.", title="before")
    after = agent.memory.remember("Rust apres compaction.", title="after")
    before.timestamp = "20260101T120000.000"
    after.timestamp = "20260103T120000.000"
    agent.session.messages = [
        CompactionMessage(
            timestamp="20260102T120000.000",
            output_items=[{"type": "compaction_summary", "id": "cs_1"}],
        ),
        UserMessage(content="rust now"),
    ]

    provider_output = next(
        message.content for message in agent.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert 'title="before"' in provider_output
    assert 'title="after"' not in provider_output


def test_retrieved_memory_provider_respects_max_memory_tokens(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False, max_memory_tokens=3)
    agent.ai = FakeEmbeddingAI()
    agent.memory.set_attr("_agent", agent)
    agent.memory.remember("rust one", title="first")
    agent.memory.remember("rust two", title="second")
    agent.session.messages = [UserMessage(content="rust now")]

    provider_output = next(
        message.content for message in agent.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert provider_output.count("<memory ") == 1
    assert ('title="first"' in provider_output) != ('title="second"' in provider_output)
