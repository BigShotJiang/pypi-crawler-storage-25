from rich.console import Console

from codex_agent import Agent
from codex_agent.chat import TerminalChat
from codex_agent.message import DeveloperMessage


class RecordingConsole(Console):
    def __init__(self):
        super().__init__(record=True, width=160)
        self.clear_count = 0

    def clear(self, *args, **kwargs):
        self.clear_count += 1
        return super().clear(*args, **kwargs)


def test_agent_context_status_is_lightweight_and_does_not_call_providers():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    called = []

    @agent.add_provider
    def expensive_provider():
        called.append(True)
        return "expensive"

    status = agent.context_status()

    assert called == []
    assert status.used_tokens > 0
    assert status.input_token_limit == 10_000
    assert 0 <= status.percent <= 100
    assert status.total_session_messages == len(agent.session.messages)
    assert status.visible_history_messages <= status.total_history_messages
    assert status.memory_entries == len(agent.memory.messages)


def test_terminal_chat_status_bar_renders_context_summary():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    console = RecordingConsole()
    chat = TerminalChat(agent, console=console)

    chat.print_status_bar()

    output = console.export_text()
    assert "ctx" in output
    assert "%" in output
    assert "tok" in output
    assert "hist" in output
    assert "msgs" in output
    assert "mem" in output

def test_terminal_chat_clear_screen_does_not_touch_agent_session():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)
    console = RecordingConsole()
    chat = TerminalChat(agent, console=console)

    chat.clear_screen()

    assert console.clear_count == 1
    assert len(agent.session.messages) == initial_count
