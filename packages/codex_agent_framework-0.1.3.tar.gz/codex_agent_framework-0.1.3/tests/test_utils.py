from codex_agent.message import AssistantMessage, DeveloperMessage, ServerToolResponseMessage, ToolResultMessage, UserMessage
from codex_agent.utils import split_history_turns


def test_split_history_turns_groups_complete_agent_loop():
    prelude = DeveloperMessage(content="session started")
    user = UserMessage(content="hello")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    tool_result = ToolResultMessage(call_id="call_1", content="42")
    final = AssistantMessage(content="done")

    turns, remainder = split_history_turns([prelude, user, tool_call, tool_result, final])

    assert turns == [[prelude, user, tool_call, tool_result, final]]
    assert remainder == []


def test_split_history_turns_keeps_current_unfinished_turn_as_remainder():
    complete_user = UserMessage(content="first")
    complete_assistant = AssistantMessage(content="done")
    current_user = UserMessage(content="second")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]

    turns, remainder = split_history_turns([complete_user, complete_assistant, current_user, tool_call])

    assert turns == [[complete_user, complete_assistant]]
    assert remainder == [current_user, tool_call]


def test_split_history_turns_keeps_messages_after_final_assistant_as_remainder():
    user = UserMessage(content="make image")
    assistant = AssistantMessage()
    server = ServerToolResponseMessage(item={"type": "image_generation_call", "id": "ig_123"})

    turns, remainder = split_history_turns([user, assistant, server])

    assert turns == [[user, assistant]]
    assert remainder == [server]


def test_split_history_turns_includes_server_tool_response_before_final_assistant():
    user = UserMessage(content="make image")
    server = ServerToolResponseMessage(item={"type": "image_generation_call", "id": "ig_123"})
    assistant = AssistantMessage(content="done")

    turns, remainder = split_history_turns([user, server, assistant])

    assert turns == [[user, server, assistant]]
    assert remainder == []


def test_split_history_turns_treats_interruption_as_completed_turn():
    user = UserMessage(content="long task")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    interrupted = DeveloperMessage(content="The previous agent response was interrupted by the user.")

    turns, remainder = split_history_turns([user, tool_call, interrupted])

    assert turns == [[user, tool_call, interrupted]]
    assert remainder == []


def test_split_history_turns_handles_plain_dict_messages():
    turns, remainder = split_history_turns([
        {"type": "user_message", "content": "hi"},
        {"type": "assistant_message", "content": "hello"},
    ])

    assert turns == [[
        {"type": "user_message", "content": "hi"},
        {"type": "assistant_message", "content": "hello"},
    ]]
    assert remainder == []
