"""
Request and response models for the Vaani SDK.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


@dataclass
class TriggerCallRequest:
    """
    Parameters for triggering an outbound call.

    Attributes:
        agent_id:         Agent UUID or agent name.
        contact_number:   Phone number in E.164 format (e.g. '+1234567890').
        name:             Display name of the contact.
        voice:            Voice identifier (optional, defaults to empty string).
        metadata:         Arbitrary key-value pairs forwarded to the agent.
        outbound_number:  Caller ID in E.164 format (optional).
        sip_trunk_id:     SIP trunk identifier (optional).
        test_mode:        When True, triggers a test-mode call (optional).
    """

    agent_id: str
    contact_number: str
    name: str
    voice: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    outbound_number: Optional[str] = None
    sip_trunk_id: Optional[str] = None
    test_mode: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "agent_id": self.agent_id,
            "contact_number": self.contact_number,
            "name": self.name,
            "voice": self.voice,
            "metadata": self.metadata,
        }
        if self.outbound_number is not None:
            data["outbound_number"] = self.outbound_number
        if self.sip_trunk_id is not None:
            data["sip_trunk_id"] = self.sip_trunk_id
        if self.test_mode is not None:
            data["test_mode"] = self.test_mode
        return data


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


@dataclass
class HealthResponse:
    """
    Response from the health-check endpoint.

    Attributes:
        status:  Status string (e.g. 'healthy').
        service: Service identifier.
        raw:     Full raw response dict.
    """

    status: str
    service: str
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HealthResponse":
        return cls(
            status=data.get("status", ""),
            service=data.get("service", ""),
            raw=data,
        )


@dataclass
class TriggerCallResponse:
    """
    Response from the trigger-call endpoint.

    Attributes:
        call_id: The ID of the newly created call (may be None if not returned).
        raw:     Full raw response dict.
    """

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TriggerCallResponse":
        call_id = (
            data.get("call_id")
            or data.get("output", {}).get("call_id")
        )
        return cls(call_id=call_id, raw=data)


@dataclass
class CallRecord:
    """A single call record within the call-history response."""

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallRecord":
        return cls(call_id=data.get("call_id"), raw=data)


@dataclass
class PaginationInfo:
    """Pagination metadata returned alongside call-history results."""

    page: int
    page_size: int
    total: int
    total_pages: int
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PaginationInfo":
        return cls(
            page=data.get("page", 1),
            page_size=data.get("page_size", 50),
            total=data.get("total", 0),
            total_pages=data.get("total_pages", 0),
            raw=data,
        )


@dataclass
class CallHistoryResponse:
    """
    Response from the call-history endpoint.

    Attributes:
        data:       List of :class:`CallRecord` objects.
        pagination: :class:`PaginationInfo` with paging metadata.
        raw:        Full raw response dict.
    """

    data: List[CallRecord]
    pagination: Optional[PaginationInfo]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallHistoryResponse":
        records = [CallRecord.from_dict(r) for r in data.get("data", [])]
        pagination = None
        if "pagination" in data:
            pagination = PaginationInfo.from_dict(data["pagination"])
        return cls(data=records, pagination=pagination, raw=data)


@dataclass
class TranscriptResponse:
    """
    Response from the transcript endpoint.

    Attributes:
        transcript: Transcript text or list of utterances (raw value from API).
        raw:        Full raw response dict.
    """

    transcript: Any
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TranscriptResponse":
        transcript = data.get("transcript", data)
        return cls(transcript=transcript, raw=data)


@dataclass
class CallDetailsResponse:
    """
    Response from the call-details endpoint.

    Attributes:
        call_id: The call ID.
        raw:     Full raw response dict.
    """

    call_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CallDetailsResponse":
        return cls(call_id=data.get("call_id"), raw=data)


@dataclass
class AudioStream:
    """
    Wrapper for a streaming audio response.

    Attributes:
        content_type: MIME type of the audio data.
        content:      Raw audio bytes (available when not using streaming iteration).
        iterator:     Iterator over raw bytes chunks (for streaming usage).
    """

    content_type: str
    content: bytes = field(default_factory=bytes)
    iterator: Optional[Iterator[bytes]] = field(default=None, repr=False)
