import { useState, useEffect } from "react";
import { Layout } from "./components/Layout";
import { LoginView } from "./views/LoginView";
import { MemoryView } from "./views/MemoryView";
import { DecisionsView } from "./views/DecisionsView";
import { SprintView } from "./views/SprintView";
import { SessionsView } from "./views/SessionsView";
import { ExplorerView } from "./views/ExplorerView";
import { ProvenanceView } from "./views/ProvenanceView";
import { MCPServersView } from "./views/MCPServersView";
import { ConnectorsView } from "./views/ConnectorsView";
import { SettingsView } from "./views/SettingsView";
import { OnboardingView } from "./views/OnboardingView";
import { useAppStore } from "./store/appStore";

// `codeledger dashboard` opens the UI with the solo token in a hash
// fragment (`#token=...`). Fragments never hit the server, so the token
// stays out of access logs. Consume it once at module load — before the
// App component mounts — move it into localStorage, and scrub the URL
// so the token doesn't linger in browser history.
(function consumeTokenFromUrl() {
  try {
    const hash = window.location.hash;
    if (!hash.startsWith("#")) return;
    const params = new URLSearchParams(hash.slice(1));
    const token = params.get("token");
    if (!token) return;
    localStorage.setItem("cl.token", token);
    const clean = window.location.pathname + window.location.search;
    window.history.replaceState(null, "", clean);
  } catch {
    // Best-effort — fall through to the normal login flow on any error.
  }
})();

type SetupState = "loading" | "onboarding" | "dashboard";

export default function App() {
  const activeTab = useAppStore((s) => s.activeTab);
  const [authed, setAuthed] = useState<boolean>(() =>
    Boolean(
      localStorage.getItem("cl.token") ||
        localStorage.getItem("cl.cookie_session"),
    ),
  );
  const [setupState, setSetupState] = useState<SetupState>("loading");

  useEffect(() => {
    // Keep auth state in sync if the token is removed elsewhere.
    const onStorage = () =>
      setAuthed(
        Boolean(
          localStorage.getItem("cl.token") ||
            localStorage.getItem("cl.cookie_session"),
        ),
      );
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    // On every load, ask the server whether the onboarding walkthrough
    // still needs to run. The endpoint is unauthenticated so this works
    // before the developer has configured any credentials.
    let cancelled = false;
    fetch("/api/setup/status")
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        setSetupState(data?.setup_complete ? "dashboard" : "onboarding");
      })
      .catch(() => {
        if (cancelled) return;
        // Server not reachable — render the login screen as a fallback.
        setSetupState("dashboard");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (setupState === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted">
        Loading CodeLedger…
      </div>
    );
  }

  if (setupState === "onboarding") {
    return (
      <OnboardingView onComplete={() => setSetupState("dashboard")} />
    );
  }

  if (!authed) {
    return <LoginView onLogin={() => setAuthed(true)} />;
  }

  return (
    <Layout>
      {activeTab === "memory" && <MemoryView />}
      {activeTab === "decisions" && <DecisionsView />}
      {activeTab === "sprint" && <SprintView />}
      {activeTab === "sessions" && <SessionsView />}
      {activeTab === "explorer" && <ExplorerView />}
      {activeTab === "provenance" && <ProvenanceView />}
      {activeTab === "mcp" && <MCPServersView />}
      {activeTab === "connectors" && <ConnectorsView />}
      {activeTab === "settings" && <SettingsView />}
    </Layout>
  );
}
