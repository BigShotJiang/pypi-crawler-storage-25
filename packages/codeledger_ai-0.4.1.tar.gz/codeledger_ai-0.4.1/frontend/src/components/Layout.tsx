import { useEffect, useRef, useState } from "react";
import {
  Brain,
  ChevronDown,
  Compass,
  GitBranch,
  Network,
  Plug,
  RefreshCw,
  Server,
  Settings2,
  Terminal,
  Zap,
  LucideIcon,
} from "lucide-react";
import { useAppStore, Tab } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { Badge } from "./ui";

const TABS: Array<{ id: Tab; label: string; icon: LucideIcon }> = [
  { id: "memory", label: "Memory", icon: Brain },
  { id: "decisions", label: "Decisions", icon: GitBranch },
  { id: "sprint", label: "Sprint", icon: Zap },
  { id: "sessions", label: "Sessions", icon: Terminal },
  { id: "explorer", label: "Explorer", icon: Compass },
  { id: "provenance", label: "Provenance", icon: Network },
  { id: "mcp", label: "MCP Servers", icon: Server },
  { id: "connectors", label: "Connectors", icon: Plug },
  { id: "settings", label: "Settings", icon: Settings2 },
];

function ProjectPicker() {
  const { activeProjectId, projects, setActiveProjectId, addProject, renameActiveProject } =
    useProjectStore();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"menu" | "rename" | "create">("menu");
  const [draft, setDraft] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setMode("menu");
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const close = () => {
    setOpen(false);
    setMode("menu");
    setDraft("");
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-[var(--border-dim)] bg-[var(--bg-elevated)] hover:bg-[var(--bg-overlay)] text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-mid)] transition-all duration-200 focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-[var(--success)]" aria-hidden="true" />
        <span>{activeProjectId}</span>
        <ChevronDown size={10} className="opacity-60" aria-hidden="true" />
      </button>
      {open && (
        <div className="absolute left-0 top-full mt-1.5 w-56 rounded-lg border border-[var(--border-mid)] bg-[var(--bg-overlay)] shadow-elevated z-20 text-sm overflow-hidden">
          {mode === "menu" && (
            <div className="py-1">
              {projects.map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setActiveProjectId(p);
                    close();
                  }}
                  className={`w-full text-left px-3 py-1.5 hover:bg-[var(--bg-hover)] transition-colors ${
                    p === activeProjectId
                      ? "text-[var(--accent-bright)]"
                      : "text-[var(--text-primary)]"
                  }`}
                >
                  {p}
                </button>
              ))}
              <div className="border-t border-[var(--border-dim)] my-1" />
              <button
                onClick={() => {
                  setDraft(activeProjectId);
                  setMode("rename");
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                Rename current…
              </button>
              <button
                onClick={() => {
                  setDraft("");
                  setMode("create");
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                New project…
              </button>
            </div>
          )}
          {(mode === "rename" || mode === "create") && (
            <form
              className="p-2 space-y-2"
              onSubmit={(e) => {
                e.preventDefault();
                const name = draft.trim();
                if (!name) return;
                if (mode === "rename") renameActiveProject(name);
                else addProject(name);
                close();
              }}
            >
              <input
                autoFocus
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder={mode === "rename" ? "New name" : "Project name"}
                className="w-full rounded-md border border-[var(--border-mid)] bg-[var(--bg-elevated)] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] px-2 py-1 text-sm focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={close}
                  className="px-2 py-1 text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-md transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 text-xs bg-gradient-to-r from-[var(--accent)] to-[var(--accent-mid)] text-white rounded-md hover:shadow-accent transition-all"
                >
                  {mode === "rename" ? "Rename" : "Create"}
                </button>
              </div>
            </form>
          )}
        </div>
      )}
    </div>
  );
}

function LiveIndicator() {
  const queryClient = useQueryClient();
  const [lastRefresh, setLastRefresh] = useState<Date>(() => new Date());
  const [online, setOnline] = useState(true);

  useEffect(() => {
    const id = window.setInterval(async () => {
      try {
        const headers: Record<string, string> = {};
        const t = localStorage.getItem("cl.token");
        if (t) headers.Authorization = `Bearer ${t}`;
        const res = await fetch("/api/security/status", {
          credentials: "include",
          headers,
        });
        if (res.ok) {
          setOnline(true);
          setLastRefresh(new Date());
          queryClient.invalidateQueries();
        } else {
          setOnline(false);
        }
      } catch {
        setOnline(false);
      }
    }, 30000);
    return () => window.clearInterval(id);
  }, [queryClient]);

  const manualRefresh = () => {
    queryClient.invalidateQueries();
    setLastRefresh(new Date());
  };

  return (
    <div className="flex items-center gap-2">
      <span
        className="flex items-center gap-1.5 text-xs text-[var(--text-tertiary)]"
        title={`Last refresh: ${lastRefresh.toLocaleTimeString()}`}
      >
        <span
          className={
            online
              ? "w-1.5 h-1.5 rounded-full bg-[var(--success)] animate-pulse"
              : "w-1.5 h-1.5 rounded-full bg-[var(--danger)]"
          }
          aria-hidden="true"
        />
        {online ? "Live" : "Disconnected"}
      </span>
      <button
        type="button"
        onClick={manualRefresh}
        title="Refresh now"
        aria-label="Refresh data"
        className="w-8 h-8 rounded-lg flex items-center justify-center border border-[var(--border-dim)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] hover:shadow-glow-sm transition-all duration-200 focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
      >
        <RefreshCw size={13} strokeWidth={2} />
      </button>
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const { activeTab, setActiveTab, theme } = useAppStore();
  const { changeDetectionBackend, setBackend } = useProjectStore();

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  const { data: securityStatus } = useQuery({
    queryKey: ["security-status"],
    queryFn: () => api.security.status(),
    retry: false,
  });
  useEffect(() => {
    if (securityStatus?.change_detection_backend) {
      setBackend(securityStatus.change_detection_backend);
    }
  }, [securityStatus, setBackend]);

  const backendVariant = changeDetectionBackend === "git" ? "cyan" : "warning";

  return (
    <div className="min-h-screen flex flex-col relative">
      <header className="sticky top-0 z-50 flex items-center gap-3 px-6 py-3 bg-[var(--glass-bg)] backdrop-blur-[12px] border-b border-[var(--border-dim)] shadow-[0_1px_0_rgba(124,92,255,0.08)]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-mid)] flex items-center justify-center shadow-accent">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
              <rect x="1" y="2" width="12" height="2" rx="1" fill="white" opacity="0.9" />
              <rect x="1" y="6" width="8" height="2" rx="1" fill="white" opacity="0.7" />
              <rect x="1" y="10" width="10" height="2" rx="1" fill="white" opacity="0.5" />
            </svg>
          </div>
          <span className="font-display text-base font-semibold text-[var(--text-primary)] tracking-tight">
            CodeLedger
          </span>
        </div>

        <ProjectPicker />

        <Badge variant={backendVariant} title="Change detection backend">
          <span className="font-mono font-medium">{changeDetectionBackend}</span>
        </Badge>

        <div className="flex-1" />

        <LiveIndicator />
      </header>

      <nav
        className="sticky top-[61px] z-40 flex items-center gap-1 px-6 py-2 border-b border-[var(--border-dim)] bg-[var(--glass-bg)] backdrop-blur-[12px] overflow-x-auto"
        role="tablist"
      >
        {TABS.map(({ id, label, icon: Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              role="tab"
              aria-selected={active}
              className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 focus:ring-2 focus:ring-[var(--accent)] focus:outline-none ${
                active
                  ? "text-white bg-gradient-to-r from-[var(--accent)] to-[var(--accent-mid)] shadow-glow-sm"
                  : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-elevated)]"
              }`}
            >
              <Icon size={14} strokeWidth={2} />
              <span>{label}</span>
              {active && (
                <span
                  aria-hidden="true"
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent"
                />
              )}
            </button>
          );
        })}
      </nav>

      <main
        className="flex-1 p-6 pb-20 overflow-auto"
        style={{ paddingBottom: "max(5rem, env(safe-area-inset-bottom))" }}
      >
        {children}
      </main>
    </div>
  );
}
