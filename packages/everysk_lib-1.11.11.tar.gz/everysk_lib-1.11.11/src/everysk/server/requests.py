###############################################################################
#
# (C) Copyright 2025 EVERYSK TECHNOLOGIES
#
# This is an unpublished work containing confidential and proprietary
# information of EVERYSK TECHNOLOGIES. Disclosure, use, or reproduction
# without authorization of EVERYSK TECHNOLOGIES is prohibited.
#
###############################################################################
__all__ = ['JSONRequest', 'Request']
from typing import Any

from starlette.requests import Request as _Request

from everysk.config import settings
from everysk.core.compress import decompress
from everysk.core.log import Logger
from everysk.core.serialize import loads

log = Logger(__name__)


###############################################################################
#   Request Class Implementation
###############################################################################
class Request(_Request):
    async def body(self) -> bytes:
        """
        Method to return the body of the request.
        If we receive a request with a Content-Encoding header, we decompress the body.
        """
        # If self._body is set then body was already read.
        if not hasattr(self, '_body'):
            body = await super().body()
            # We only decompress the body if it is not empty.
            if body:
                content_encoding = self.headers.get('Content-Encoding', '').lower()
                if 'gzip' in content_encoding:
                    try:
                        body = decompress(body, protocol='gzip', serialize=None)

                    except Exception:  # noqa: BLE001
                        log.error('Error decompressing the request body.', extra={'labels': {'body': body}})

            self._body = body
        return self._body


###############################################################################
#   JSONRequest Class Implementation
###############################################################################
class JSONRequest(Request):
    _protocol: str = settings.EVERYSK_SERVER_REQUEST_PROTOCOL

    async def json(self, loads_params: dict | None = None) -> Any:
        """
        Method to return the JSON content of the request body.
        It uses the loads function from the core.serialize module to parse the body.

        Args:
            loads_params (dict, optional): Parameters to pass to the loads function. Defaults to None.
        """
        if not hasattr(self, '_json'):
            self._json = None
            body = await self.body()
            if body and isinstance(body, (bytes, str)):
                if loads_params is None:
                    loads_params = {'protocol': self._protocol, 'use_undefined': True}

                self._json = loads(body, **loads_params)

        return self._json
