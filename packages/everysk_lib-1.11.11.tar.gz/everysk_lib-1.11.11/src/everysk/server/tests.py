###############################################################################
#
# (C) Copyright 2025 EVERYSK TECHNOLOGIES
#
# This is an unpublished work containing confidential and proprietary
# information of EVERYSK TECHNOLOGIES. Disclosure, use, or reproduction
# without authorization of EVERYSK TECHNOLOGIES is prohibited.
#
###############################################################################
# ruff: noqa: F401

try:
    from everysk.server._tests.applications import ServerApplication as EveryskLibServerApplication
    from everysk.server._tests.endpoints import BaseEndpointTestCase as EveryskLibBaseEndpointTestCase
    from everysk.server._tests.endpoints import BaseEndpointTestCaseAsync as EveryskLibBaseEndpointTestCaseAsync
    from everysk.server._tests.endpoints import DumpsParamsTestCase as EveryskLibDumpsParamsTestCase
    from everysk.server._tests.endpoints import (
        HealthCheckEndpointTestCaseAsync as EveryskLibHealthCheckEndpointTestCaseAsync,
    )
    from everysk.server._tests.endpoints import JSONEndpointTestCase as EveryskLibJSONEndpointTestCase
    from everysk.server._tests.endpoints import JSONEndpointTestCaseAsync as EveryskLibJSONEndpointTestCaseAsync
    from everysk.server._tests.endpoints import (
        NotAllowedMethodsTestCaseAsync as EveryskLibNotAllowedMethodsTestCaseAsync,
    )
    from everysk.server._tests.endpoints import RedirectEndpointTestCase as EveryskLibRedirectEndpointTestCase
    from everysk.server._tests.endpoints import RedirectEndpointTestCaseAsync as EveryskLibRedirectEndpointTestCaseAsync
    from everysk.server._tests.middlewares import GZipMiddlewareTestCaseAsync as EveryskLibGZipMiddlewareTestCaseAsync
    from everysk.server._tests.middlewares import (
        SecurityHeadersMiddlewareTestCaseAsync as EveryskLibSecurityHeadersMiddlewareTestCaseAsync,
    )
    from everysk.server._tests.middlewares import UpdateMiddlewaresTestCase as EveryskLibUpdateMiddlewaresTestCase
    from everysk.server._tests.routing import RouteLazyTestCaseAsync as EveryskLibRouteLazyTestCaseAsync

except ModuleNotFoundError as error:
    # This will prevent running these tests if requests is not installed
    if not error.args[0].startswith("No module named 'starlette'"):
        raise
