# LLM Installation Guide (Agent-Executable)

> **This document is written for an AI agent, not a human.**
> The agent should read each step, execute the Action, run the Verify check, and only proceed if verification passes.
> If any step fails, follow the On Failure instructions and stop.

---

## Preconditions

Before starting, confirm the following on the target machine:

```bash
python3.14 --version || uv python find 3.14
# Verify: prints "Python 3.14.x"
# On Failure:
#   - Preferred (any OS): uv python install 3.14
#   - macOS alternative:   brew install python@3.14
#   - Linux/WSL:           sudo apt install python3.14 || uv python install 3.14

which uv
# Verify: prints a path (e.g. /Users/.../.local/bin/uv)
# On Failure: curl -LsSf https://astral.sh/uv/install.sh | sh
```

---

## Step 0 — Create Discord Application and Bot (skip if you already have one)

### Action

1. Open [https://discord.com/developers/applications](https://discord.com/developers/applications) and log in.
2. Click **"New Application"**, give it a name (e.g. `kimi-bridge`), click **Create**.
3. In the left sidebar, click **"Bot"** tab.
4. Click **"Add Bot"** → **"Yes, do it!"**.
5. Under **Privileged Gateway Intents**, toggle **"Message Content Intent"** to **ON**.
6. Click **"Reset Token"** → **Copy** the token (a long string with two dots). This is `DISCORD_TOKEN`.
7. Click **"OAuth2"** → **"URL Generator"** in the left sidebar.
8. Under **Scopes**, check **"bot"** and **"applications.commands"**.
9. Under **Bot Permissions**, check at minimum:
   - **Send Messages**
   - **Create Public Threads**
   - **Send Messages in Threads**
   - **Embed Links**
   - **Attach Files**
   - **Read Message History**
   - **Use Slash Commands**
10. Copy the generated URL at the bottom, open it in a browser, select your target server, and **Authorize**.
11. In the target Discord server, right-click the server name → **"Copy Server ID"** (requires Developer Mode ON in Discord Settings → Advanced). This is `DISCORD_GUILD_ID`.
12. Go back to the Discord Developer Portal → **"General Information"** tab → copy **"Application ID"** (17–19 digits). This is `DISCORD_CLIENT_ID`.

### Verify

- The bot appears in your Discord server's member list (possibly offline).
- You have three values copied: `DISCORD_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`.

### On Failure

- **"Missing Access" during authorization**: you are not an admin in that server, or the server ID is wrong.
- **Bot does not appear in member list**: regenerate the OAuth2 URL and re-authorize with both `bot` and `applications.commands` scopes.

---

## Step 1 — Install the package

### Action

```bash
uv tool install --python 3.14 kimi-discord-bridge
```

### Verify

```bash
which kimi-discord-bridge
# Expected: absolute path to the executable
# Example: /Users/<user>/.local/bin/kimi-discord-bridge
```

### On Failure

- If `uv tool install` fails with "No solution found": check Python 3.14 is available (`uv python find 3.14`).
- If the executable is not on PATH: add `export PATH="$HOME/.local/bin:$PATH"` to shell profile.

---

## Step 1.5 — Choose your working directory

### Action

봇 실행 전용 디렉토리를 생성하고 이동하세요. 이 디렉토리는 `.env`, `sessions.json`, `logs/`가 저장되는 **영구적인 위치**가 됩니다.

```bash
mkdir -p ~/kimi-bridge
cd ~/kimi-bridge
pwd
# Verify: 절대경로가 출력됨. 이 경로를 기억하세요.
# Example: /Users/alice/kimi-bridge
```

> ⚠️ **이 디렉토리는 매번 봇을 시작할 때마다 동일해야 합니다.**  
> 다른 곳에서 `kimi-discord-bridge run`을 실행하면 기존 세션이 초기화됩니다.

### On Failure

- `mkdir` 실패 (Permission denied): 홈 디렉토리가 아닌 다른 경로(예: `/opt/kimi-bridge`)를 사용하세요.

---

## Step 2 — Prepare .env file

### Action

**Step 1.5에서 만든 디렉토리에서** `.env` 파일을 생성하세요.

```bash
cd ~/kimi-bridge  # 또는 Step 1.5에서 선택한 경로
cat > .env << 'ENVEOF'
# ===== REQUIRED =====
# SOURCE: https://discord.com/developers/applications → select your app → "Bot" tab → "Token" → "Reset Token" or copy existing
# FORMAT: 3 base64 segments separated by dots. e.g. MTAx...x.xxx
DISCORD_TOKEN=REPLACE_WITH_BOT_TOKEN

# SOURCE: same page, "General Information" tab → "Application ID" (17-19 digit snowflake)
# FORMAT: 17-19 digit decimal string. e.g. 1234567890123456789
DISCORD_CLIENT_ID=REPLACE_WITH_CLIENT_ID

# SOURCE: Discord app → right-click your server → "Copy Server ID" (requires Developer Mode ON in Discord settings)
# FORMAT: 17-19 digit decimal string.
DISCORD_GUILD_ID=REPLACE_WITH_GUILD_ID

# ===== OPTIONAL (sensible defaults shown) =====
# Session persistence file path (relative to working directory)
# WARNING: Always start the bot from the SAME directory. If you cd elsewhere, sessions.json will NOT be found.
SESSION_DB_PATH=./sessions.json

# cmux CLI command (leave as-is if cmux is on PATH)
CMUX_CMD=cmux

# kimi CLI command — used for version checks and external calls (leave as "kimi" if on PATH)
KIMI_CMD=kimi

# Actual executable spawned for ACP child processes. Usually identical to KIMI_CMD.
# Change only if you have a wrapper script or different binary name.
KIMI_ACP_EXECUTABLE=kimi

# Directory for Unix domain sockets used by the attach helper
BOT_ACP_SOCKET_DIR=/tmp

# Legacy socat command. Only used as a manual fallback; the bot always uses its built-in
# "attach" helper (kimi-discord-bridge attach <name>) for cmux pane bootstrap.
# You can leave this as-is or uninstall socat — it is NOT required.
SOCAT_CMD=socat

# toad CLI invocation used inside cmux panes.
# IMPORTANT: The bot runs in its own uv tool venv. toad is bundled inside the kimi-cli venv.
# "python -m toad.cli" will likely fail because it searches the bot's venv, not kimis.
# Options (try in order):
#   1. If toad is on PATH:         TOAD_CMD=toad
#   2. If kimi-cli venv is known:  TOAD_CMD=/ABSOLUTE/PATH/TO/kimi-cli-venv/bin/python -m toad.cli
#   3. Let the bot auto-detect:    leave TOAD_CMD unset (the bot tries multiple candidates)
# Default fallback: python -m toad.cli
TOAD_CMD=python -m toad.cli

# Default working directory for new sessions
# This is where Kimi bot sessions read/write files by default.
# CHANGE THIS: Replace <USERNAME> with your actual username, or use any absolute path.
# Example: /Users/alice/projects, /home/alice/workspace, /opt/workspace, etc.
DEFAULT_WORK_DIR=/Users/<USERNAME>/projects

# Discord message update debounce interval (milliseconds)
DEBOUNCE_MS=1200

# Milliseconds to wait after creating a cmux surface before sending commands
CMUX_SURFACE_READY_MS=2500

# Maximum buffered response bytes before truncation
MAX_BUFFER_BYTES=200000

# Max think-block length before truncation
THINK_TRUNCATE=3500

# Max tool-result length before truncation
TOOL_RESULT_TRUNCATE=1500

# Directory for daily rotating bridge logs and audit JSONL
LOG_DIR=./logs
ENVEOF
```

### Verify

```bash
cat .env | grep -E "^DISCORD_(TOKEN|CLIENT_ID|GUILD_ID)="
# Expected: 3 lines with non-empty values after =
# If any value is empty or still "REPLACE_WITH_...", stop and ask the user for the missing credential.
```

### On Failure

- If the file is not created: check write permissions in the working directory.
- If required values are still placeholders: **STOP.** Ask the user to provide the real token/client_id/guild_id. Do NOT guess or use dummy values.

---

## Step 3 — Validate environment (preflight)

### Action

```bash
kimi-discord-bridge doctor
```

### Verify

Output should contain one of:
- `✓ All checks passed` (all green)
- `cmux sync DISABLED` with toad/s errors (acceptable if user only wants Discord-only mode)

Specific checks performed:
- `DISCORD_TOKEN` format (3 dot-separated base64 segments)
- `DISCORD_CLIENT_ID` and `DISCORD_GUILD_ID` are 17–19 digit numeric strings
- Python version ≥ 3.14
- `toad` availability (auto-detects multiple candidates)

If the output ends with a traceback (`pydantic_core.ValidationError: Field required`), the `.env` file is missing required values. Go back to Step 2.

### On Failure

- `Invalid DISCORD_TOKEN format`: token was copied incorrectly (missing segments, wrong length). Regenerate at Discord Developer Portal.
- `DISCORD_CLIENT_ID/GUILD_ID must be 17-19 digits`: copy the correct numeric IDs from Discord.
- `toad unavailable`:
  - The bot tried `python -m toad.cli`, `python -m batrachian_toad`, `toad`, and `which toad`.
  - If all failed, set `TOAD_CMD` to the absolute path of the Python interpreter inside the kimi-cli venv, e.g.:
    ```bash
    # Find kimi venv (example for uv tool installs)
    ls ~/.local/share/uv/tools/kimi-cli/bin/python
    # Then set in .env:
    TOAD_CMD=/Users/<USER>/.local/share/uv/tools/kimi-cli/bin/python -m toad.cli
    ```
  - If you do NOT need cmux sync, this warning is safe to ignore.
- `Python x.y < 3.14`: the uv tool environment picked the wrong interpreter. Re-install with `uv tool install --python 3.14 --force kimi-discord-bridge`.

---

## Step 4 — Register Discord slash commands

### Action

```bash
kimi-discord-bridge deploy-commands
```

### Verify

Output should end with:

```
Commands synced.
```

### On Failure

- `401 Unauthorized`: `DISCORD_TOKEN` is invalid or expired. Regenerate at Discord Developer Portal.
- `404 Not Found` (Unknown Guild): `DISCORD_GUILD_ID` is wrong. Copy the correct server ID from Discord.
- `Missing Access`: the bot is not invited to the server, or the bot lacks `applications.commands` scope in its OAuth2 URL. Re-invite the bot with the correct scope (see Step 0).

---

## Step 5 — Start the bot

### Action

**반드시 Step 1.5에서 만든 디렉토리에서 실행하세요.**

```bash
cd ~/kimi-bridge  # 또는 Step 1.5에서 선택한 경로
kimi-discord-bridge run
```

### Verify

Watch stdout for:

```
[preflight] cmux sync ...
Logged in as <BotName>#<discriminator>
```

The process should stay in the foreground. Do NOT background it unless the user explicitly requests daemon mode.

**Important:** The bot creates `sessions.json` and `logs/` in the **current working directory**. You must always restart the bot from this same directory, or sessions and logs will be lost/reset.

### On Failure

- If it exits immediately with a validation error: recheck `.env` required fields.
- If it logs in but no commands appear in Discord: re-run Step 4 (`deploy-commands`).
- If `sessions.json` is corrupted on load:
  ```bash
  # Stop the bot, then:
  mv ./sessions.json ./sessions.json.bak
  # Restart the bot; sessions will start fresh.
  ```
- If anything else fails: check `./logs/bridge-YYYY-MM-DD.log` for detailed error traces.

---

## Step 6 — End-to-end verification

### Action

In the Discord server where the bot was invited, run:

1. Type `/list` and press Enter.
2. Type `/new`, select a workspace, enter a session name, and submit.

### Verify

- `/list` should reply with an embed showing "No active sessions" (or existing sessions).
- `/new` should create a new thread and the bot should post a "Session started" message.

### On Failure

- **"The application did not respond"**: the bot crashed or is not running. Check `./logs/bridge-YYYY-MM-DD.log`.
- **"Unknown integration"** or command not found: re-run Step 4 (`deploy-commands`). It may take up to 1 hour for global commands to propagate; guild-specific commands should appear within seconds.
- **Thread created but no "Session started" message**: check that `kimi` CLI is on PATH and `KIMI_CMD` / `KIMI_ACP_EXECUTABLE` are correct.

---

## Optional — Upgrade or Uninstall

```bash
# Upgrade
uv tool upgrade kimi-discord-bridge

# Uninstall
uv tool uninstall kimi-discord-bridge
```

---

## Quick Reference for Agents

| File / Directory | Purpose | 설정 시점 | 영속성 경고 |
|---|---|---|---|
| `~/kimi-bridge/` (예시) | 봇 실행/데이터 전용 디렉토리 | **처음 1회** 생성 | 매번 같은 곳에서 `run` 실행 |
| `.env` | 런타임 설정 (토큰, ID 등) | **처음 1회** 작성 | 이 디렉토리에 위치 |
| `sessions.json` | 세션 메타데이터 | 자동 생성 | 같은 디렉토리에서만 유지됨 |
| `./logs/` | 로그 파일 | 자동 생성 | 같은 디렉토리에서만 유지됨 |
| `pyproject.toml` | 패키지 메타데이터 (개발용) | — | — |
