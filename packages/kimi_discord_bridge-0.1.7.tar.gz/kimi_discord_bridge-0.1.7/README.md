# kimi-discord-bridge

Discord bridge for [Kimi CLI](https://github.com/moonshot-ai/kimi-cli) with [cmux](https://github.com/...) integration.

Run Kimi sessions inside Discord threads while simultaneously driving a `toad` TUI in a cmux pane — both views stay in sync.

## Installation

```bash
uv tool install --python 3.14 kimi-discord-bridge
```

Or install from source:

```bash
git clone https://github.com/HyeongJunMin/kimi-cli-discord.git
cd kimi-cli-discord
uv tool install --python 3.14 .
```

## Requirements

- Python 3.14+
- `uv` (recommended) or `pip`
- `cmux` (required for TUI sync)
- `kimi` CLI (required for ACP sessions)

> **Note:** `cmux` and `kimi` are listed as "required" because the core value of this bridge is bidirectional sync between Discord and the toad TUI. Without them the bot can still start, but it will operate in a limited Discord-only mode.

## Quick Start

1. **Create a Discord bot application** (if you don't have one):
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - New Application → Bot tab → Add Bot
   - Enable **Message Content Intent**
   - OAuth2 URL Generator: scopes `bot` + `applications.commands`, permissions listed in INSTALL.md
   - Authorize the bot into your server

2. **Configure environment variables**:

```bash
cp .env.example .env
# Edit .env with your Discord token, client ID, and guild ID
```

3. **Validate** (catches credential/format errors early):

```bash
kimi-discord-bridge doctor
```

4. **Register slash commands** (once per guild):

```bash
kimi-discord-bridge deploy-commands
```

5. **Run the bot**:

```bash
kimi-discord-bridge run
```

> **Persistence warning:** The bot creates `sessions.json` and `logs/` in the current working directory. Always restart the bot from the **same directory** or sessions will not be resumed.

## Commands

| Command | Description |
|---|---|
| `/new` | Create a new Kimi session (workspace select → name) |
| `/list` | List active sessions |
| `/status <name>` | Check session status |
| `/close [name]` | Close a session |
| `/steer <name> <message>` | Send follow-up message |
| `/interrupt <name>` | Interrupt active turn |
| `/peek <name> [lines]` | Preview cmux screen |

## Architecture

```
Discord Thread  <--->  Bot (discord.py)  <--->  AcpMux  <--->  kimi acp
                                               ^
                                               |
cmux pane  <--->  toad TUI  <--->  attach (unix socket)
```

## License

MIT
