# Changelog

## 0.1.0 — 2026-05-07

### Added
- Initial Python rewrite from Node.js (source: https://github.com/HyeongJunMin/kimi-discord-bridge-nosdk)
- `kimi-discord-bridge` CLI with `run`, `deploy-commands`, `attach`, `doctor`
- Discord slash commands: `/new`, `/list`, `/status`, `/close`, `/steer`, `/interrupt`, `/peek`
- ACP multiplexer with Unix socket server for multi-client support
- Session manager with `sessions.json` persistence
- Message debouncer for Discord streaming
- cmux integration: workspace/pane creation, toad TUI bootstrap
- Session auto-recovery on bot restart
- Crash detection and automatic `crashed` status marking
- Preflight checks for Python 3.14 and toad availability
