import os

os.environ.setdefault("DISCORD_TOKEN", "test-token")
os.environ.setdefault("DISCORD_CLIENT_ID", "123456789")
os.environ.setdefault("DISCORD_GUILD_ID", "987654321")
