import asyncio
import json
import os
import pytest
import tempfile

from kimi_discord_bridge.acp.mux import AcpMux


def _short_sock():
    fd, path = tempfile.mkstemp(prefix="/tmp/muxtest_", suffix=".sock")
    os.close(fd)
    os.unlink(path)
    return path


class FakeStdin:
    def __init__(self):
        self.chunks: list[bytes] = []

    def write(self, data: bytes) -> None:
        self.chunks.append(data)

    def close(self) -> None:
        pass


class FakeChild:
    def __init__(self):
        self.stdout = asyncio.StreamReader()
        self.stderr = asyncio.StreamReader()
        self.stdin = FakeStdin()
        self._returncode: int | None = None
        self._wait_event = asyncio.Event()

    def kill(self) -> None:
        pass

    async def wait(self) -> int:
        await self._wait_event.wait()
        return self._returncode or 0

    def emit_exit(self, code: int = 0) -> None:
        self._returncode = code
        self.stdout.feed_eof()
        self.stderr.feed_eof()
        self._wait_event.set()

    def lines_written(self) -> list[dict]:
        text = b"".join(self.stdin.chunks).decode("utf-8")
        return [json.loads(line) for line in text.split("\n") if line.strip()]


def make_spawn_fn(child: FakeChild):
    async def _spawn(executable, args, **kwargs):
        return child

    return _spawn


async def start_mux_with_socket(socket_path: str, child=None, **opts):
    if child is None:
        child = FakeChild()
    mux = AcpMux(
        workDir="/tmp", spawnFn=make_spawn_fn(child), socketPath=socket_path, **opts
    )
    start_task = asyncio.create_task(mux.start())
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if lines:
            break
    assert len(lines) >= 1
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": lines[0]["id"],
                    "result": {"protocolVersion": 1, "agentCapabilities": {}},
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await start_task
    return mux, child


@pytest.mark.asyncio
async def test_socket_client_can_connect_and_send_request():
    sock = _short_sock()
    mux, child = await start_mux_with_socket(sock)

    assert os.path.exists(sock)

    # Connect as a socket client
    reader, writer = await asyncio.open_unix_connection(sock)
    writer.write(
        json.dumps({"jsonrpc": "2.0", "id": 1, "method": "session/list", "params": {}}).encode("utf-8")
        + b"\n"
    )
    await writer.drain()

    # Wait for the request to reach kimi
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if any(m.get("method") == "session/list" for m in lines):
            break

    req = next((m for m in child.lines_written() if m.get("method") == "session/list"), None)
    assert req is not None

    # Reply
    child.stdout.feed_data(
        (
            json.dumps({"jsonrpc": "2.0", "id": req["id"], "result": {"sessions": []}})
            + "\n"
        ).encode("utf-8")
    )

    # Read response back on socket
    data = await asyncio.wait_for(reader.readline(), timeout=1.0)
    resp = json.loads(data.decode("utf-8"))
    assert resp["id"] == 1
    assert resp["result"] == {"sessions": []}

    writer.close()
    await mux.close()


@pytest.mark.asyncio
async def test_socket_client_receives_notifications():
    sock = _short_sock()
    mux, child = await start_mux_with_socket(sock)

    reader, writer = await asyncio.open_unix_connection(sock)

    # Yield so server-side callback registers the client
    await asyncio.sleep(0.05)

    # Send a notification from kimi
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "session/update",
                    "params": {"sessionId": "s", "sessionUpdate": "agent_message_chunk", "content": {"text": "hi"}},
                }
            )
            + "\n"
        ).encode("utf-8")
    )

    await asyncio.sleep(0.05)
    data = await asyncio.wait_for(reader.readline(), timeout=1.0)
    msg = json.loads(data.decode("utf-8"))
    assert msg["method"] == "session/update"

    writer.close()
    await mux.close()


@pytest.mark.asyncio
async def test_busy_rejected_for_second_prompt():
    sock = _short_sock()
    mux, child = await start_mux_with_socket(sock)

    # First client sends session/prompt
    r1, w1 = await asyncio.open_unix_connection(sock)
    w1.write(
        (
            json.dumps(
                {"jsonrpc": "2.0", "id": 1, "method": "session/prompt", "params": {"sessionId": "s", "prompt": []}}
            )
            + "\n"
        ).encode("utf-8")
    )
    await w1.drain()

    # Wait until kimi receives it
    for _ in range(10):
        await asyncio.sleep(0.01)
        if any(m.get("method") == "session/prompt" for m in child.lines_written()):
            break

    # Second client sends another session/prompt for same session
    r2, w2 = await asyncio.open_unix_connection(sock)
    w2.write(
        (
            json.dumps(
                {"jsonrpc": "2.0", "id": 1, "method": "session/prompt", "params": {"sessionId": "s", "prompt": []}}
            )
            + "\n"
        ).encode("utf-8")
    )
    await w2.drain()

    data = await asyncio.wait_for(r2.readline(), timeout=1.0)
    resp = json.loads(data.decode("utf-8"))
    assert resp.get("error", {}).get("code") == -32000  # ERR_BUSY

    w1.close()
    w2.close()
    await mux.close()
