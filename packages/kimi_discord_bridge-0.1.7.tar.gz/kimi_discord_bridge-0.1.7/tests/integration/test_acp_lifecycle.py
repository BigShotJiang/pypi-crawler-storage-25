import asyncio
import json
import pytest

from kimi_discord_bridge.acp.client import BotSession, BotTurn
from kimi_discord_bridge.acp.mux import AcpMux


class FakeStdin:
    def __init__(self):
        self.chunks: list[bytes] = []

    def write(self, data: bytes) -> None:
        self.chunks.append(data)

    def close(self) -> None:
        pass


class FakeChild:
    def __init__(self):
        self.stdout = asyncio.StreamReader()
        self.stderr = asyncio.StreamReader()
        self.stdin = FakeStdin()
        self._returncode: int | None = None
        self._wait_event = asyncio.Event()

    def kill(self) -> None:
        pass

    async def wait(self) -> int:
        await self._wait_event.wait()
        return self._returncode or 0

    def emit_exit(self, code: int = 0) -> None:
        self._returncode = code
        self.stdout.feed_eof()
        self.stderr.feed_eof()
        self._wait_event.set()

    def lines_written(self) -> list[dict]:
        text = b"".join(self.stdin.chunks).decode("utf-8")
        return [json.loads(line) for line in text.split("\n") if line.strip()]


def make_spawn_fn(child: FakeChild):
    async def _spawn(executable, args, **kwargs):
        return child

    return _spawn


async def start_mux(child=None, **opts):
    if child is None:
        child = FakeChild()
    mux = AcpMux(workDir="/tmp", spawnFn=make_spawn_fn(child), **opts)
    start_task = asyncio.create_task(mux.start())
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if lines:
            break
    assert len(lines) >= 1
    assert lines[0]["method"] == "initialize"
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": lines[0]["id"],
                    "result": {"protocolVersion": 1, "agentCapabilities": {}},
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await start_task
    return mux, child


@pytest.mark.asyncio
async def test_session_prompt_turn_lifecycle():
    mux, child = await start_mux()
    session = BotSession(mux=mux, workDir="/tmp")
    client = mux.registerInProcessClient(lambda msg: session._on_message(msg))
    session._set_client(client)
    session.sessionId = "sess-1"

    turn = session.prompt("hello")
    # Wait for session/prompt to be written
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if any(m.get("method") == "session/prompt" for m in lines):
            break

    req = next((m for m in child.lines_written() if m.get("method") == "session/prompt"), None)
    assert req is not None
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": req["id"],
                    "result": {"stopReason": "end_turn"},
                }
            )
            + "\n"
        ).encode("utf-8")
    )

    events = []
    async for ev in turn:
        events.append(ev)

    assert any(e["type"] == "TurnBegin" for e in events)
    assert any(e["type"] == "TurnEnd" for e in events)
    await session.close()


@pytest.mark.asyncio
async def test_session_notification_routed_to_active_turn():
    mux, child = await start_mux()
    session = BotSession(mux=mux, workDir="/tmp")
    client = mux.registerInProcessClient(lambda msg: session._on_message(msg))
    session._set_client(client)
    session.sessionId = "sess-1"

    turn = session.prompt("hello")
    # Give start() a chance to send session/prompt
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if any(m.get("method") == "session/prompt" for m in lines):
            break

    # Send a notification from kimi
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "session/update",
                    "params": {
                        "sessionId": "sess-1",
                        "sessionUpdate": "agent_message_chunk",
                        "content": {"type": "text", "text": "world"},
                    },
                }
            )
            + "\n"
        ).encode("utf-8")
    )

    # Also complete the prompt so TurnEnd fires
    req = next((m for m in child.lines_written() if m.get("method") == "session/prompt"), None)
    child.stdout.feed_data(
        (
            json.dumps(
                {"jsonrpc": "2.0", "id": req["id"], "result": {"stopReason": "end_turn"}}
            )
            + "\n"
        ).encode("utf-8")
    )

    events = []
    async for ev in turn:
        events.append(ev)

    content_parts = [e for e in events if e["type"] == "ContentPart"]
    assert len(content_parts) >= 1
    assert content_parts[0]["payload"]["text"] == "world"
    await session.close()
