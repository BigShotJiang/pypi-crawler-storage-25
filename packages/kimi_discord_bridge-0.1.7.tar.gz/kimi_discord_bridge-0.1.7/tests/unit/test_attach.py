import asyncio
import os
import tempfile

import pytest

from kimi_discord_bridge.attach import attach_session


@pytest.mark.asyncio
async def test_attach_relay(monkeypatch):
    loop = asyncio.get_event_loop()
    received = []

    async def fake_server():
        server = await asyncio.start_unix_server(
            lambda r, w: received.append("connected"),
            path="/tmp/test-attach.sock",
        )
        await asyncio.sleep(0.2)
        server.close()

    monkeypatch.setattr(
        "kimi_discord_bridge.attach.get_config",
        lambda: type("C", (), {"BOT_ACP_SOCKET_DIR": "/tmp"})(),
    )

    # Just verify import and structure; full relay needs real socket
    assert callable(attach_session)
