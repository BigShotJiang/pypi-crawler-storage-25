import asyncio
import json
import pytest

from kimi_discord_bridge.acp.mux import AcpMux


# ---------------------------------------------------------------------------
# Fake child helpers
# ---------------------------------------------------------------------------

class FakeStdin:
    def __init__(self):
        self.chunks: list[bytes] = []

    def write(self, data: bytes) -> None:
        self.chunks.append(data)

    def close(self) -> None:
        pass

    def lines_written(self) -> list[dict]:
        text = b"".join(self.chunks).decode("utf-8")
        return [json.loads(line) for line in text.split("\n") if line.strip()]


class FakeChild:
    def __init__(self):
        self.stdout = asyncio.StreamReader()
        self.stderr = asyncio.StreamReader()
        self.stdin = FakeStdin()
        self._returncode: int | None = None
        self._wait_event = asyncio.Event()

    async def wait(self) -> int:
        await self._wait_event.wait()
        return self._returncode or 0

    def kill(self) -> None:
        pass

    def terminate(self) -> None:
        pass

    def emit_exit(self, code: int = 0) -> None:
        self._returncode = code
        self.stdout.feed_eof()
        self.stderr.feed_eof()
        self._wait_event.set()

    def emit_error(self, exc: Exception) -> None:
        self.stdout.feed_eof()
        self.stderr.feed_eof()
        self._wait_event.set()


def make_spawn_fn(child: FakeChild):
    async def _spawn(executable, args, **kwargs):
        return child

    return _spawn


async def start_mux(child=None, **opts):
    if child is None:
        child = FakeChild()
    mux = AcpMux(workDir="/tmp", spawnFn=make_spawn_fn(child), **opts)
    start_task = asyncio.create_task(mux.start())
    # yield to event loop so background tasks start
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.stdin.lines_written()
        if lines:
            break
    assert len(lines) >= 1, "expected initialize to be written"
    assert lines[0]["method"] == "initialize"
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": lines[0]["id"],
                    "result": {
                        "protocolVersion": 1,
                        "agentCapabilities": {"loadSession": True},
                    },
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await start_task
    return mux


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_performs_initialize_handshake_and_caches_capabilities():
    child = FakeChild()
    mux = await start_mux(child=child)
    assert mux.capabilities == {"loadSession": True}
    await mux.close()


@pytest.mark.asyncio
async def test_sendRequest_assigns_ids_and_resolves_with_response_result():
    child = FakeChild()
    mux = await start_mux(child=child)

    client = mux.registerInProcessClient(lambda _: None)
    p = client.sendRequest("session/new", {"cwd": "/tmp"})
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.stdin.lines_written()
        if any(m.get("method") == "session/new" for m in lines):
            break

    lines = child.stdin.lines_written()
    new_req = next((m for m in lines if m.get("method") == "session/new"), None)
    assert new_req is not None
    assert new_req["params"]["cwd"] == "/tmp"

    child.stdout.feed_data(
        (
            json.dumps(
                {"jsonrpc": "2.0", "id": new_req["id"], "result": {"sessionId": "sess-1"}}
            )
            + "\n"
        ).encode("utf-8")
    )

    result = await p
    assert result["sessionId"] == "sess-1"
    await mux.close()


@pytest.mark.asyncio
async def test_notifications_are_broadcast_to_all_registered_clients():
    child = FakeChild()
    mux = await start_mux(child=child)

    seen_a = []
    seen_b = []
    mux.registerInProcessClient(lambda msg: seen_a.append(msg))
    mux.registerInProcessClient(lambda msg: seen_b.append(msg))

    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "session/update",
                    "params": {
                        "sessionId": "s",
                        "sessionUpdate": "agent_message_chunk",
                        "content": {"type": "text", "text": "hi"},
                    },
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await asyncio.sleep(0.05)

    assert len(seen_a) == 1
    assert len(seen_b) == 1
    assert seen_a[0]["kind"] == "notification"
    assert seen_a[0]["method"] == "session/update"
    assert seen_a[0]["params"]["sessionUpdate"] == "agent_message_chunk"
    await mux.close()


@pytest.mark.asyncio
async def test_server_to_client_requests_are_broadcast_with_id_and_kind_request():
    child = FakeChild()
    mux = await start_mux(child=child)

    seen = []
    mux.registerInProcessClient(lambda msg: seen.append(msg))

    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 99,
                    "method": "session/request_permission",
                    "params": {"sessionId": "s", "toolCall": {"toolCallId": "t1"}, "options": []},
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await asyncio.sleep(0.05)

    assert len(seen) == 1
    assert seen[0]["kind"] == "request"
    assert seen[0]["id"] == 99
    assert seen[0]["method"] == "session/request_permission"
    await mux.close()


@pytest.mark.asyncio
async def test_response_with_error_rejects_pending_request():
    child = FakeChild()
    mux = await start_mux(child=child)

    client = mux.registerInProcessClient(lambda _: None)
    p = client.sendRequest("session/cancel", {"sessionId": "x"})
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.stdin.lines_written()
        if any(m.get("method") == "session/cancel" for m in lines):
            break

    lines = child.stdin.lines_written()
    req = next((m for m in lines if m.get("method") == "session/cancel"), None)
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": req["id"],
                    "error": {"code": -32602, "message": "no such session"},
                }
            )
            + "\n"
        ).encode("utf-8")
    )

    with pytest.raises(Exception, match="no such session"):
        await p
    await mux.close()


@pytest.mark.asyncio
async def test_child_exit_rejects_pending_requests_and_notifies_clients_with_transport_error():
    child = FakeChild()
    mux = await start_mux(child=child)

    seen = []
    client = mux.registerInProcessClient(lambda msg: seen.append(msg))
    p = client.sendRequest("session/prompt", {"sessionId": "s", "prompt": []})
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.stdin.lines_written()
        if any(m.get("method") == "session/prompt" for m in lines):
            break

    child.emit_exit(1)
    with pytest.raises(Exception, match="exited"):
        await p
    assert any(m.get("kind") == "transport-error" for m in seen)


@pytest.mark.asyncio
async def test_client_sendResponse_writes_a_response_frame_for_a_server_request():
    child = FakeChild()
    mux = await start_mux(child=child)

    client = mux.registerInProcessClient(lambda _: None)

    # Simulate kimi sending a server-request with id=42
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 42,
                    "method": "session/request_permission",
                    "params": {"sessionId": "s", "toolCall": {"toolCallId": "tc"}, "options": []},
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await asyncio.sleep(0.05)

    client.sendResponse(42, {"outcome": {"optionId": "allow"}})
    await asyncio.sleep(0.05)

    lines = child.stdin.lines_written()
    resp = next((m for m in lines if m.get("id") == 42 and "result" in m), None)
    assert resp is not None
    assert resp["result"]["outcome"]["optionId"] == "allow"
    await mux.close()


@pytest.mark.asyncio
async def test_response_with_unknown_id_is_ignored_no_throw():
    child = FakeChild()
    mux = await start_mux(child=child)

    child.stdout.feed_data(
        (
            json.dumps({"jsonrpc": "2.0", "id": 9999, "result": {"stray": True}})
            + "\n"
        ).encode("utf-8")
    )
    await asyncio.sleep(0.05)

    # No throw, mux still functional
    client = mux.registerInProcessClient(lambda _: None)
    p = client.sendRequest("session/list", {})
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.stdin.lines_written()
        if any(m.get("method") == "session/list" for m in lines):
            break

    req = next((m for m in lines if m.get("method") == "session/list"), None)
    child.stdout.feed_data(
        (
            json.dumps({"jsonrpc": "2.0", "id": req["id"], "result": {"sessions": []}})
            + "\n"
        ).encode("utf-8")
    )
    r = await p
    assert r == {"sessions": []}
    await mux.close()
