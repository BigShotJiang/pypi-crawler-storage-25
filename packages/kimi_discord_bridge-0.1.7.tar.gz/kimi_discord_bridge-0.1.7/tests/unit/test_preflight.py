import pytest

from kimi_discord_bridge.preflight import (
    _validate_discord_credentials,
    check_cmux_sync,
)


# ---------------------------------------------------------------------------
# Discord credential validation
# ---------------------------------------------------------------------------

class FakeCfg:
    def __init__(self, token, client_id, guild_id):
        self.DISCORD_TOKEN = token
        self.DISCORD_CLIENT_ID = client_id
        self.DISCORD_GUILD_ID = guild_id


def test_validate_credentials_ok():
    cfg = FakeCfg(
        token="MTAx.a.b",
        client_id="123456789012345678",
        guild_id="987654321098765432",
    )
    errs = _validate_discord_credentials(cfg)
    assert errs == []


def test_validate_token_wrong_segments():
    cfg = FakeCfg(
        token="only_one_segment",
        client_id="123456789012345678",
        guild_id="987654321098765432",
    )
    errs = _validate_discord_credentials(cfg)
    assert any("Invalid DISCORD_TOKEN format" in e for e in errs)


def test_validate_ids_not_numeric():
    cfg = FakeCfg(
        token="MTAx.a.b",
        client_id="not_a_number",
        guild_id="too_short",
    )
    errs = _validate_discord_credentials(cfg)
    assert any("DISCORD_CLIENT_ID" in e for e in errs)
    assert any("DISCORD_GUILD_ID" in e for e in errs)


def test_validate_ids_empty():
    cfg = FakeCfg(token="MTAx.a.b", client_id="", guild_id="")
    errs = _validate_discord_credentials(cfg)
    assert any("DISCORD_CLIENT_ID is empty" in e for e in errs)
    assert any("DISCORD_GUILD_ID is empty" in e for e in errs)


# ---------------------------------------------------------------------------
# cmux sync / toad
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_preflight_with_fake_exec():
    async def fake_exec(cmd, args):
        if cmd == "python":
            return "toad 0.5.23", ""
        return "", ""

    result = await check_cmux_sync(toad_cmd="python -m toad.cli", _exec=fake_exec)
    assert result["ok"] is True
    assert "toad" in result["details"]


@pytest.mark.asyncio
async def test_preflight_toad_missing():
    async def fake_exec(cmd, args):
        raise RuntimeError("not found")

    result = await check_cmux_sync(toad_cmd="python -m toad.cli", _exec=fake_exec)
    assert result["ok"] is False
    assert any("toad unavailable" in e for e in result["errors"])


@pytest.mark.asyncio
async def test_preflight_toad_auto_detect():
    calls = []

    async def fake_exec(cmd, args):
        calls.append((cmd, args))
        if cmd == "toad" and args == ["--version"]:
            return "toad 0.5.23", ""
        raise RuntimeError("not found")

    # toad_cmd=None triggers auto-detection
    result = await check_cmux_sync(toad_cmd=None, _exec=fake_exec)
    assert result["ok"] is True
    assert result["details"].get("toad_auto_detected") == "toad"
    assert any(c[0] == "toad" for c in calls)
