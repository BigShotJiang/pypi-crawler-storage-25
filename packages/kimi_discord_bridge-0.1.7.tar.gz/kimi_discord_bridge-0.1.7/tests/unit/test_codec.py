import pytest

from kimi_discord_bridge.acp.codec import LineCodec, classify, encode


def drain(codec: LineCodec):
    return list(codec.messages())


class TestLineCodec:
    def test_single_complete_line_yields_one_message(self):
        c = LineCodec()
        c.feed('{"jsonrpc":"2.0","id":1,"method":"x"}\n')
        out = drain(c)
        assert len(out) == 1
        assert out[0]["method"] == "x"

    def test_two_lines_in_one_chunk_yield_two_messages(self):
        c = LineCodec()
        c.feed('{"a":1}\n{"b":2}\n')
        out = drain(c)
        assert len(out) == 2
        assert out[0]["a"] == 1
        assert out[1]["b"] == 2

    def test_partial_line_buffered_until_newline_arrives(self):
        c = LineCodec()
        c.feed('{"jso')
        assert len(drain(c)) == 0
        c.feed('nrpc":"2.0","id":1}\n')
        out = drain(c)
        assert len(out) == 1
        assert out[0]["id"] == 1

    def test_malformed_json_emits_parseError_but_does_not_block(self):
        c = LineCodec()
        c.feed('not-json\n{"ok":true}\n')
        out = drain(c)
        assert len(out) == 2
        assert out[0]["_parseError"] is True
        assert out[0]["raw"] == "not-json"
        assert out[1]["ok"] is True

    def test_empty_lines_are_skipped(self):
        c = LineCodec()
        c.feed('\n\n{"x":1}\n\n')
        out = drain(c)
        assert len(out) == 1
        assert out[0]["x"] == 1

    def test_handles_crlf_line_endings(self):
        c = LineCodec()
        c.feed('{"x":1}\r\n')
        out = drain(c)
        assert len(out) == 1
        assert out[0]["x"] == 1

    def test_accepts_bytes_chunks(self):
        c = LineCodec()
        c.feed(b'{"buf":true}\n')
        out = drain(c)
        assert out[0]["buf"] is True


class TestClassify:
    def test_request(self):
        assert classify({"method": "x", "id": 1}) == "request"

    def test_notification(self):
        assert classify({"method": "session/update", "params": {}}) == "notification"

    def test_response_with_result(self):
        assert classify({"id": 1, "result": {}}) == "response"

    def test_response_with_error(self):
        assert classify({"id": 1, "error": {"code": -1, "message": "x"}}) == "response"

    def test_invalid_parse_error(self):
        assert classify({"_parseError": True, "raw": "x", "error": "e"}) == "invalid"

    def test_invalid_none_of_the_above(self):
        assert classify({}) == "invalid"
        assert classify(None) == "invalid"


class TestEncode:
    def test_appends_newline(self):
        out = encode({"jsonrpc": "2.0", "id": 1, "method": "x"})
        assert out.endswith("\n")
        assert __import__("json").loads(out.strip())["method"] == "x"
