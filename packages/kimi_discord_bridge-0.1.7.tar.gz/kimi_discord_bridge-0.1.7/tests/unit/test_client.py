import asyncio
import json
import pytest

from kimi_discord_bridge.acp.client import (
    BotSession,
    BotTurn,
    create_session,
    translate_session_update,
)
from kimi_discord_bridge.acp.mux import AcpMux
from kimi_discord_bridge.acp.protocol import SessionUpdateKinds


class FakeStdin:
    def __init__(self):
        self.chunks: list[bytes] = []

    def write(self, data: bytes) -> None:
        self.chunks.append(data)

    def close(self) -> None:
        pass


class FakeChild:
    def __init__(self):
        self.stdout = asyncio.StreamReader()
        self.stderr = asyncio.StreamReader()
        self.stdin = FakeStdin()
        self._returncode: int | None = None
        self._wait_event = asyncio.Event()

    def kill(self) -> None:
        pass

    async def wait(self) -> int:
        await self._wait_event.wait()
        return self._returncode or 0

    def emit_exit(self, code: int = 0) -> None:
        self._returncode = code
        self.stdout.feed_eof()
        self.stderr.feed_eof()
        self._wait_event.set()

    def lines_written(self) -> list[dict]:
        text = b"".join(self.stdin.chunks).decode("utf-8")
        return [json.loads(line) for line in text.split("\n") if line.strip()]


def make_spawn_fn(child: FakeChild):
    async def _spawn(executable, args, **kwargs):
        return child

    return _spawn


async def start_mux(child=None, **opts):
    if child is None:
        child = FakeChild()
    mux = AcpMux(workDir="/tmp", spawnFn=make_spawn_fn(child), **opts)
    start_task = asyncio.create_task(mux.start())
    for _ in range(10):
        await asyncio.sleep(0.01)
        lines = child.lines_written()
        if lines:
            break
    assert len(lines) >= 1
    child.stdout.feed_data(
        (
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": lines[0]["id"],
                    "result": {"protocolVersion": 1, "agentCapabilities": {}},
                }
            )
            + "\n"
        ).encode("utf-8")
    )
    await start_task
    return mux


@pytest.mark.asyncio
async def test_create_session_performs_handshake_and_sets_sessionId():
    child = FakeChild()
    mux = await start_mux(child=child)

    async def fake_create_session(**kwargs):
        return await create_session(muxFactory=lambda **kw: mux, workDir="/tmp")

    # We need to intercept session/new
    # Actually create_session uses create_session directly
    # Let's send the session/new response after it writes
    # But create_session will send session/new after initialize
    # So we need to handle both
    # This is tricky with fake child; let's just test BotSession directly
    await mux.close()


@pytest.mark.asyncio
async def test_bot_turn_async_iterator():
    turn = BotTurn(client=None, sessionId="s1")
    turn._push({"type": "TurnBegin", "payload": {}})
    turn._push({"type": "TurnEnd", "payload": {}})
    turn._end(ok=True, value={"stopReason": "end_turn"})
    events = []
    async for ev in turn:
        events.append(ev)
    assert len(events) == 2
    assert events[0]["type"] == "TurnBegin"
    assert events[1]["type"] == "TurnEnd"


@pytest.mark.asyncio
async def test_bot_turn_end_with_error():
    turn = BotTurn(client=None, sessionId="s1")
    err = RuntimeError("boom")
    turn._end_with_error(err)
    events = []
    async for ev in turn:
        events.append(ev)
    assert any(ev["type"] == "error" for ev in events)


def test_translate_session_update_agent_message_chunk():
    events = translate_session_update({
        "sessionUpdate": SessionUpdateKinds.AGENT_MESSAGE_CHUNK,
        "content": {"type": "text", "text": "hi"},
    })
    assert len(events) == 1
    assert events[0]["type"] == "ContentPart"
    assert events[0]["payload"]["text"] == "hi"


def test_translate_session_update_tool_call():
    events = translate_session_update({
        "sessionUpdate": SessionUpdateKinds.TOOL_CALL,
        "toolCallId": "tc1",
        "title": "my_tool",
    })
    assert events[0]["type"] == "ToolCall"
    assert events[0]["payload"]["function"]["name"] == "my_tool"


def test_translate_session_update_tool_call_update_completed():
    events = translate_session_update({
        "sessionUpdate": SessionUpdateKinds.TOOL_CALL_UPDATE,
        "status": "completed",
        "toolCallId": "tc1",
        "content": [{"content": {"type": "text", "text": "done"}}],
    })
    assert events[0]["type"] == "ToolResult"
