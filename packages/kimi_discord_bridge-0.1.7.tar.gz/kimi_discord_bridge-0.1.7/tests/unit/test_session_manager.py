import os
import tempfile

import pytest

from kimi_discord_bridge.session_manager import SessionManager


@pytest.fixture
def sm(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "kimi_discord_bridge.session_manager.get_config",
        lambda: type("C", (), {"SESSION_DB_PATH": str(tmp_path / "sessions.json")})(),
    )
    return SessionManager()


@pytest.mark.asyncio
async def test_create_and_get(sm):
    meta = await sm.create("test", 123, "/tmp")
    assert meta["name"] == "test"
    assert meta["discordThreadId"] == 123
    assert meta["status"] == "idle"
    assert sm.get("test") == meta


@pytest.mark.asyncio
async def test_duplicate_name_raises(sm):
    await sm.create("dup", 1, "/tmp")
    with pytest.raises(ValueError, match="already exists"):
        await sm.create("dup", 2, "/tmp")


@pytest.mark.asyncio
async def test_invalid_name_raises(sm):
    with pytest.raises(ValueError, match="Invalid session name"):
        await sm.create("", 1, "/tmp")


@pytest.mark.asyncio
async def test_get_by_thread(sm):
    await sm.create("t1", 111, "/tmp")
    await sm.create("t2", 222, "/tmp")
    assert sm.get_by_thread(111)["name"] == "t1"
    assert sm.get_by_thread(999) is None


@pytest.mark.asyncio
async def test_update_status(sm):
    await sm.create("s", 1, "/tmp")
    await sm.update_status("s", "running")
    assert sm.get("s")["status"] == "running"


@pytest.mark.asyncio
async def test_set_session_id(sm):
    await sm.create("s", 1, "/tmp")
    await sm.set_session_id("s", "sid-1")
    assert sm.get("s")["sessionId"] == "sid-1"


@pytest.mark.asyncio
async def test_delete(sm):
    await sm.create("del", 1, "/tmp")
    assert await sm.delete("del") is True
    assert sm.get("del") is None
    assert await sm.delete("del") is False


@pytest.mark.asyncio
async def test_list(sm):
    await sm.create("a", 1, "/tmp")
    await sm.create("b", 2, "/tmp")
    assert len(sm.list()) == 2


@pytest.mark.asyncio
async def test_load_persists(sm, tmp_path):
    await sm.create("persist", 1, "/tmp")
    sm2 = SessionManager()
    await sm2.load()
    assert sm2.get("persist") is not None
