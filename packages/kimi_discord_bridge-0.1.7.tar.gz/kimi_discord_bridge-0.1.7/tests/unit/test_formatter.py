import pytest

from kimi_discord_bridge.formatter import (
    format_content_part,
    format_tool_call,
    format_tool_result,
    split_message,
)


class TestFormatContentPart:
    def test_text(self):
        assert format_content_part({"type": "text", "text": "hello"}) == {"text": "hello"}

    def test_think_truncation(self, monkeypatch):
        monkeypatch.setattr(
            "kimi_discord_bridge.formatter.get_config",
            lambda: type("C", (), {"THINK_TRUNCATE": 10})(),
        )
        result = format_content_part({"type": "think", "think": "123456789012345"})
        assert result["text"].startswith("*💭 Thinking...*")
        assert "..." in result["text"]

    def test_image_url(self):
        result = format_content_part({"type": "image_url", "image_url": {"url": "http://x"}})
        assert "http://x" in result["text"]

    def test_audio_url(self):
        result = format_content_part({"type": "audio_url", "audio_url": {"url": "http://a"}})
        assert "http://a" in result["text"]

    def test_unknown(self):
        assert format_content_part({"type": "xyz"}) == {"text": "[unknown: xyz]"}


class TestFormatToolCall:
    def test_basic(self):
        assert "my_tool" in format_tool_call({"function": {"name": "my_tool"}})


class TestFormatToolResult:
    def test_success(self, monkeypatch):
        monkeypatch.setattr(
            "kimi_discord_bridge.formatter.get_config",
            lambda: type("C", (), {"TOOL_RESULT_TRUNCATE": 1000})(),
        )
        result = format_tool_result({"return_value": "ok"})
        assert "✅" in result["text"]

    def test_error(self, monkeypatch):
        monkeypatch.setattr(
            "kimi_discord_bridge.formatter.get_config",
            lambda: type("C", (), {"TOOL_RESULT_TRUNCATE": 1000})(),
        )
        result = format_tool_result({"return_value": "ERROR happened"})
        assert "❌" in result["text"]


class TestSplitMessage:
    def test_empty(self):
        assert split_message("") == []

    def test_short(self):
        assert split_message("hi") == ["hi"]

    def test_long_splits(self):
        text = "a" * 5000
        chunks = split_message(text, max_len=4000)
        assert len(chunks) > 1
        assert all(len(c) <= 4000 + 10 for c in chunks)  # margin for code fences
