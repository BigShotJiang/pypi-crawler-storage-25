import pytest

from kimi_discord_bridge.session_manager import SessionManager


@pytest.fixture
def sm(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "kimi_discord_bridge.session_manager.get_config",
        lambda: type("C", (), {"SESSION_DB_PATH": str(tmp_path / "sessions.json")})(),
    )
    return SessionManager()


@pytest.mark.asyncio
async def test_session_without_sessionId_marked_crashed_on_recover(sm):
    await sm.create("no-sid", 1, "/tmp")
    # Simulate load with no sessionId
    assert sm.get("no-sid").get("sessionId") is None


@pytest.mark.asyncio
async def test_shutdown_session_clears_in_memory_refs(sm, monkeypatch):
    await sm.create("s", 1, "/tmp")
    sm.set_sdk_session("s", "fake-sdk")
    sm.set_active_turn("s", "fake-turn")

    # Point bot module's session_manager to our test instance
    import kimi_discord_bridge.bot as bot_mod
    monkeypatch.setattr(bot_mod, "session_manager", sm)

    from kimi_discord_bridge.bot import shutdown_session
    await shutdown_session("s")
    assert sm.get_sdk_session("s") is None
    assert sm.get_active_turn("s") is None
    assert sm.get("s") is not None
