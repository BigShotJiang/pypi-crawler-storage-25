import pytest

from kimi_discord_bridge.debouncer import MessageDebouncer


class FakeChannel:
    def __init__(self):
        self.messages = []
        self.files = []

    async def send(self, **kwargs):
        self.messages.append(kwargs)
        if "file" in kwargs:
            self.files.append(kwargs["file"])
        return type("Msg", (), {"edit": lambda **kw: None})()


@pytest.fixture
def channel():
    return FakeChannel()


@pytest.mark.asyncio
async def test_update_buffers(channel, monkeypatch):
    monkeypatch.setattr(
        "kimi_discord_bridge.debouncer.get_config",
        lambda: type("C", (), {"DEBOUNCE_MS": 50, "MAX_BUFFER_BYTES": 1000, "max_embed_description": 4096})(),
    )
    d = MessageDebouncer(channel)
    await d.update("hello")
    await d.update(" world")
    # flush is async deferred; wait
    import asyncio

    await asyncio.sleep(0.1)
    assert len(channel.messages) >= 1
    d.dispose()


@pytest.mark.asyncio
async def test_finalize_sends_complete(channel, monkeypatch):
    monkeypatch.setattr(
        "kimi_discord_bridge.debouncer.get_config",
        lambda: type("C", (), {"DEBOUNCE_MS": 50, "MAX_BUFFER_BYTES": 1000, "max_embed_description": 4096, "max_message_content": 2000})(),
    )
    d = MessageDebouncer(channel)
    await d.update("hello")
    await d.finalize()
    assert any(
        (m.get("embed") and getattr(m["embed"], "title", "") == "✅ 완료")
        for m in channel.messages
    )
    d.dispose()


@pytest.mark.asyncio
async def test_cap_buffer(channel, monkeypatch):
    monkeypatch.setattr(
        "kimi_discord_bridge.debouncer.get_config",
        lambda: type("C", (), {"DEBOUNCE_MS": 50, "MAX_BUFFER_BYTES": 10, "max_embed_description": 4096})(),
    )
    d = MessageDebouncer(channel)
    await d.update("0123456789abcdefghij")
    # internal buffer should be capped
    assert len(d._buffer) <= 40  # marker + cap
    d.dispose()
