"""Typer CLI entry point."""

import asyncio

import typer

from kimi_discord_bridge.attach import attach_session
from kimi_discord_bridge.config import get_config

app = typer.Typer(name="kimi-discord-bridge")


def _validate_cfg():
    cfg = get_config()
    missing = [k for k in ("DISCORD_TOKEN", "DISCORD_CLIENT_ID", "DISCORD_GUILD_ID") if not getattr(cfg, k)]
    if missing:
        raise typer.BadParameter(f"Missing required config: {', '.join(missing)}. Set them in .env or environment.")
    return cfg


@app.command()
def run() -> None:
    """Start the Discord bot."""
    import signal

    from kimi_discord_bridge.bot import KimiBot, shutdown_bot

    cfg = _validate_cfg()
    bot = KimiBot()

    def _handle_signal(sig, frame):
        asyncio.create_task(shutdown_bot(bot))

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    asyncio.run(bot.start(cfg.DISCORD_TOKEN))


@app.command()
def deploy_commands() -> None:
    """Register Discord slash commands."""
    import discord

    from kimi_discord_bridge.bot import KimiBot

    cfg = _validate_cfg()

    async def _sync():
        bot = KimiBot()
        await bot.login(cfg.DISCORD_TOKEN)
        await bot.tree.sync(guild=discord.Object(id=int(cfg.DISCORD_GUILD_ID)))
        await bot.close()

    asyncio.run(_sync())
    typer.echo("Commands synced.")


@app.command()
def attach(name: str) -> None:
    """Attach stdio to a session socket (socat replacement)."""
    asyncio.run(attach_session(name))


@app.command()
def doctor() -> None:
    """Run preflight checks."""
    from kimi_discord_bridge.preflight import run_preflight

    result = asyncio.run(run_preflight())
    if result["ok"]:
        typer.echo("✓ All checks passed")
    else:
        typer.echo("✗ Some checks failed:")
        for e in result["errors"]:
            typer.echo(f"  - {e}")
