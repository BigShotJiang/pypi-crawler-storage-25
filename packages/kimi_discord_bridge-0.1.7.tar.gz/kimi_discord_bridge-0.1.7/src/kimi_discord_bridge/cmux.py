"""cmux CLI wrapper."""

import asyncio
import logging
import re
from typing import Any

from kimi_discord_bridge.config import get_config

logger = logging.getLogger("kimi_discord_bridge.cmux")


async def cmux_exec(args: list[str], *, silent: bool = False, timeout: float | None = 10.0) -> str | None:
    cfg = get_config()
    try:
        proc = await asyncio.create_subprocess_exec(
            cfg.CMUX_CMD, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        if timeout is not None:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        else:
            stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            msg = f"[cmux] exec failed (args: {' '.join(args)}): {stderr.decode().strip() or 'unknown error'}"
            if silent:
                logger.debug(msg)
            else:
                logger.error(msg)
            return None
        return stdout.decode()
    except Exception as exc:
        msg = f"[cmux] exec failed (args: {' '.join(args)}): {exc}"
        if silent:
            logger.debug(msg)
        else:
            logger.error(msg)
        return None


async def create_surface(workspace_ref: str | None = None) -> str | None:
    args = ["new-pane", "--type", "terminal", "--direction", "right"]
    if workspace_ref:
        args += ["--workspace", workspace_ref]
    stdout = await cmux_exec(args, timeout=5.0)
    if not stdout:
        return None
    match = re.search(r"surface:\d+", stdout)
    if not match:
        logger.error("[cmux] createSurface: could not parse surface ref from output: %s", stdout.strip())
        return None
    await asyncio.sleep(get_config().CMUX_SURFACE_READY_MS / 1000)
    return match.group(0)


async def wait_for_terminal_ready(surface_ref: str, timeout_ms: int = 8000) -> bool:
    start = asyncio.get_event_loop().time()
    while (asyncio.get_event_loop().time() - start) * 1000 < timeout_ms:
        out = await cmux_exec(
            ["read-screen", "--surface", surface_ref, "--lines", "1"],
            silent=True,
        )
        if out is not None:
            return True
        await asyncio.sleep(0.4)
    return False


async def send_to_surface(surface_ref: str, text: str, *, silent: bool = False) -> bool:
    return await cmux_exec(["send", "--surface", surface_ref, text], silent=silent) is not None


async def send_enter_to_surface(surface_ref: str, *, silent: bool = False) -> bool:
    return await cmux_exec(["send-key", "--surface", surface_ref, "enter"], silent=silent) is not None


async def read_screen(surface_ref: str, lines: int = 30) -> str | None:
    try:
        return await cmux_exec(["read-screen", "--surface", surface_ref, "--lines", str(lines)])
    except Exception as exc:
        logger.error("[cmux] readScreen error: %s", exc)
        return None


async def is_surface_alive(surface_ref: str) -> bool:
    try:
        result = await cmux_exec(["read-screen", "--surface", surface_ref, "--lines", "1"])
        return result is not None
    except Exception:
        return False


_KIMI_SUCCESS_PATTERNS = (
    "Loading agent",
    "agent (kimi",
    "connecting to mcp",
)
_KIMI_FAILURE_PATTERNS = (
    "command not found",
    "No module named",
    "ModuleNotFoundError",
    "Traceback (most recent call last)",
    ": not found",
)


async def verify_kimi_started(
    surface_ref: str,
    timeout_ms: int = 15000,
    poll_interval_ms: int = 500,
) -> tuple[str, str]:
    """Poll surface screen until kimi-cli is detected as running, failed, or timeout.

    Returns (status, screen_tail):
      - "ok": one of the success markers appeared
      - "failed": a known shell/python failure marker appeared
      - "timeout": neither within timeout_ms
    """
    start = asyncio.get_event_loop().time()
    last_screen = ""
    while (asyncio.get_event_loop().time() - start) * 1000 < timeout_ms:
        screen = await read_screen(surface_ref, lines=40)
        if screen:
            last_screen = screen
            if any(p in screen for p in _KIMI_SUCCESS_PATTERNS):
                return "ok", screen
            if any(p in screen for p in _KIMI_FAILURE_PATTERNS):
                return "failed", screen
        await asyncio.sleep(poll_interval_ms / 1000)
    return "timeout", last_screen


async def list_workspaces() -> list[dict[str, Any]]:
    stdout = await cmux_exec(["list-workspaces"])
    if not stdout:
        return []
    result = []
    for line in stdout.split("\n"):
        line = line.strip()
        if not line:
            continue
        stripped = re.sub(r"^\*\s+", "", line)
        stripped = re.sub(r"\s+\[selected\]\s*$", "", stripped)
        m = re.match(r"^(workspace:[\w-]+)\s+(.*)$", stripped)
        if not m:
            continue
        result.append({"ref": m.group(1), "name": m.group(2)})
    return result


async def create_workspace(name: str | None = None, cwd: str | None = None, description: str | None = None) -> str | None:
    args = ["new-workspace"]
    if name:
        args += ["--name", name]
    if cwd:
        args += ["--cwd", cwd]
    if description:
        args += ["--description", description]
    stdout = await cmux_exec(args)
    if not stdout:
        return None
    match = re.search(r"workspace:[\w-]+", stdout)
    if not match:
        logger.error("[cmux] createWorkspace: could not parse workspace ref from output: %s", stdout.strip())
        return None
    return match.group(0)
