"""Pydantic-settings based configuration."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Discord
    DISCORD_TOKEN: str = ""
    DISCORD_CLIENT_ID: str = ""
    DISCORD_GUILD_ID: str = ""

    # Bridge
    SESSION_DB_PATH: str = "./sessions.json"
    CMUX_CMD: str = "cmux"
    KIMI_CMD: str = "kimi"
    KIMI_ACP_EXECUTABLE: str = "kimi"
    BOT_ACP_SOCKET_DIR: str = "/tmp"
    SOCAT_CMD: str = "socat"
    TOAD_CMD: str = "python -m toad.cli"
    DEFAULT_WORK_DIR: str = "."
    DEBOUNCE_MS: int = 1200
    CMUX_SURFACE_READY_MS: int = 2500
    MAX_BUFFER_BYTES: int = 200_000
    THINK_TRUNCATE: int = 3500
    TOOL_RESULT_TRUNCATE: int = 1500
    LOG_DIR: str = "./logs"

    @property
    def max_embed_description(self) -> int:
        return 4096

    @property
    def max_message_content(self) -> int:
        return 2000


_config: Config | None = None


def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config()
    return _config
