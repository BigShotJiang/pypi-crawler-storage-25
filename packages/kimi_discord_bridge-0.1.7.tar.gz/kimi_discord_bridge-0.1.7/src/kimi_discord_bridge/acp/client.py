"""Drop-in replacement for SDK createSession.

Wraps an AcpMux and translates ACP messages into Session/Turn/StreamEvent
shapes that the bot consumes.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Callable

from kimi_discord_bridge.logger import get_logger

from .mux import AcpMux
from .protocol import Methods, ServerRequests, SessionUpdateKinds

logger = get_logger()

SDK_EVENT_TYPES = {
    "TURN_BEGIN": "TurnBegin",
    "TURN_END": "TurnEnd",
    "CONTENT_PART": "ContentPart",
    "TOOL_CALL": "ToolCall",
    "TOOL_CALL_PART": "ToolCallPart",
    "TOOL_RESULT": "ToolResult",
    "APPROVAL_REQUEST": "ApprovalRequest",
    "STATUS_UPDATE": "StatusUpdate",
    "ERROR": "error",
    "UNKNOWN": "UnknownEvent",
    "STEP_BEGIN": "StepBegin",
    "STEP_INTERRUPTED": "StepInterrupted",
    "COMPACTION_BEGIN": "CompactionBegin",
    "COMPACTION_END": "CompactionEnd",
    "SUBAGENT_EVENT": "SubagentEvent",
    "STEER_INPUT": "SteerInput",
    "APPROVAL_RESPONSE": "ApprovalResponse",
    "HOOK_TRIGGERED": "HookTriggered",
    "HOOK_RESOLVED": "HookResolved",
    "QUESTION_REQUEST": "QuestionRequest",
    "PARSE_ERROR": "ParseError",
}


async def create_session(
    *,
    workDir: str,
    sessionId: str | None = None,
    model: str | None = None,
    thinking: bool = False,
    yoloMode: bool = False,
    spawnFn: Callable | None = None,
    muxFactory: Callable | None = None,
    socketPath: str | None = None,
    executable: str = "kimi",
    onCrash: Callable | None = None,
) -> BotSession:
    if not workDir:
        raise ValueError("createSession: workDir is required")

    mux = (
        muxFactory(workDir=workDir, spawnFn=spawnFn, socketPath=socketPath, executable=executable)
        if muxFactory
        else AcpMux(workDir=workDir, spawnFn=spawnFn, socketPath=socketPath, executable=executable)
    )
    await mux.start()

    session = BotSession(mux=mux, workDir=workDir, model=model, thinking=thinking, yoloMode=yoloMode, onCrash=onCrash)
    client = mux.registerInProcessClient(lambda msg: session._on_message(msg))
    session._set_client(client)

    sid: str
    if sessionId:
        await client.sendRequest(Methods.SESSION_RESUME, {"cwd": workDir, "sessionId": sessionId})
        sid = sessionId
    else:
        result = await client.sendRequest(Methods.SESSION_NEW, {"cwd": workDir, "mcpServers": []})
        sid = result.get("sessionId") if isinstance(result, dict) else None
        if not sid:
            raise ValueError("session/new returned no sessionId")
    session.sessionId = sid
    return session


class BotSession:
    def __init__(
        self,
        *,
        mux: AcpMux,
        workDir: str,
        model: str | None = None,
        thinking: bool = False,
        yoloMode: bool = False,
        onCrash: Callable | None = None,
    ) -> None:
        self.sessionId: str | None = None
        self.workDir = workDir
        self.state = "idle"
        self.model = model
        self.thinking = thinking
        self.yoloMode = yoloMode

        self._mux = mux
        self._client: Any = None
        self._active_turn: BotTurn | None = None
        self._closed = False
        self._onCrash = onCrash

    def _set_client(self, client: Any) -> None:
        self._client = client

    def prompt(self, content: str) -> BotTurn:
        if self._closed:
            raise RuntimeError("Session is closed")
        turn = BotTurn(client=self._client, sessionId=self.sessionId)
        self._active_turn = turn
        asyncio.create_task(turn.start(content))
        return turn

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self.state = "closed"
        if self._active_turn:
            self._active_turn._end_with_error(RuntimeError("Session closed"))
            self._active_turn = None
        await self._mux.close()

    def _on_message(self, msg: dict[str, Any]) -> None:
        kind = msg.get("kind")
        if kind == "notification":
            self._handle_notification(msg["method"], msg.get("params"))
        elif kind == "request":
            self._handle_server_request(msg["id"], msg["method"], msg.get("params"))
        elif kind == "transport-error":
            err = Exception(msg.get("error", "transport error"))
            if self.state != "crashed":
                self.state = "crashed"
                if self._onCrash:
                    try:
                        self._onCrash(err)
                    except Exception:
                        pass
            if self._active_turn:
                self._active_turn._end_with_error(err)
                self._active_turn = None

    def _handle_notification(self, method: str, params: dict[str, Any] | None) -> None:
        if method != "session/update":
            return
        if params and params.get("sessionId") and params["sessionId"] != self.sessionId:
            return
        if not self._active_turn:
            return
        for event in translate_session_update(params):
            self._active_turn._push(event)

    def _handle_server_request(self, id: int, method: str, params: dict[str, Any] | None) -> None:
        if method == ServerRequests.REQUEST_PERMISSION:
            if params and params.get("sessionId") and params["sessionId"] != self.sessionId:
                self._client.sendResponse(id, None, {"code": -32602, "message": "wrong session"})
                return
            if self._active_turn:
                self._active_turn._register_approval_request(id, params)
            else:
                self._client.sendResponse(id, None, {"code": -32002, "message": "no active turn"})
            return

        if method == ServerRequests.FS_READ:
            self._handle_fs_read(id, params)
            return
        if method == ServerRequests.FS_WRITE:
            self._handle_fs_write(id, params)
            return

        self._client.sendResponse(id, None, {"code": -32601, "message": f"method not supported: {method}"})

    def _handle_fs_read(self, id: int, params: dict[str, Any] | None) -> None:
        try:
            abs_path = self._resolve_safe_path(params.get("path") if params else None)
            content = Path(abs_path).read_text(encoding="utf-8")
            if isinstance(params.get("line"), int) or isinstance(params.get("limit"), int):
                lines = content.split("\n")
                start = max(0, (params.get("line", 1) or 1) - 1)
                end = start + params["limit"] if params.get("limit") is not None else len(lines)
                content = "\n".join(lines[start:end])
            self._client.sendResponse(id, {"content": content})
        except Exception as exc:
            self._client.sendResponse(id, None, {"code": -32000, "message": str(exc)})

    def _handle_fs_write(self, id: int, params: dict[str, Any] | None) -> None:
        try:
            abs_path = self._resolve_safe_path(params.get("path") if params else None)
            Path(abs_path).parent.mkdir(parents=True, exist_ok=True)
            Path(abs_path).write_text(params.get("content", "") if params else "", encoding="utf-8")
            self._client.sendResponse(id, None)
        except Exception as exc:
            self._client.sendResponse(id, None, {"code": -32000, "message": str(exc)})

    def _resolve_safe_path(self, p: Any) -> str:
        if not isinstance(p, str) or len(p) == 0:
            raise ValueError("path is required")
        if not os.path.isabs(p):
            raise ValueError("path must be absolute")
        root = str(Path(self.workDir).resolve())
        target = str(Path(p).resolve())
        if target != root and not target.startswith(root + os.sep):
            raise ValueError(f"path outside workDir is not allowed: {p}")
        return target


class BotTurn:
    def __init__(self, *, client: Any, sessionId: str | None) -> None:
        self._client = client
        self._sessionId = sessionId
        self._queue: list[dict[str, Any]] = []
        self._waiters: list[asyncio.Future] = []
        self._done = False
        self._cancelled = False
        self._pending_approval_request_id: int | None = None
        self._pending_approval_options: list[Any] = []
        self._result_future: asyncio.Future[Any] = asyncio.get_event_loop().create_future()
        self._result_future.add_done_callback(lambda _: None)

    async def start(self, content: str) -> None:
        self._push({"type": SDK_EVENT_TYPES["TURN_BEGIN"], "payload": {}})
        try:
            res = await self._client.sendRequest(
                Methods.SESSION_PROMPT,
                {"sessionId": self._sessionId, "prompt": _to_acp_prompt_content(content)},
            )
            stop_reason = res.get("stopReason", "end_turn") if isinstance(res, dict) else "end_turn"
            self._push({"type": SDK_EVENT_TYPES["TURN_END"], "payload": {"stopReason": stop_reason}})
            self._end(ok=True, value={"stopReason": stop_reason})
        except Exception as err:
            self._push({
                "type": SDK_EVENT_TYPES["ERROR"],
                "code": getattr(err, "code", "PROMPT_FAILED"),
                "message": str(err),
            })
            self._push({"type": SDK_EVENT_TYPES["TURN_END"], "payload": {"stopReason": "error"}})
            self._end(ok=False, error=err)

    async def interrupt(self) -> None:
        if self._cancelled or self._done:
            return
        self._cancelled = True
        try:
            await self._client.sendRequest(Methods.SESSION_CANCEL, {"sessionId": self._sessionId})
        except Exception as exc:
            logger.warning("[BotTurn] cancel failed: %s", exc)

    async def steer(self, content: str) -> Any:
        if not self._done:
            try:
                await self._client.sendRequest(Methods.SESSION_CANCEL, {"sessionId": self._sessionId})
            except Exception:
                pass
        return await self._client.sendRequest(
            Methods.SESSION_PROMPT,
            {"sessionId": self._sessionId, "prompt": _to_acp_prompt_content(content)},
        )

    async def approve(self, requestId: str, response: str) -> None:
        if self._pending_approval_request_id is None:
            raise RuntimeError("no pending approval request")
        acp_id = self._pending_approval_request_id
        self._pending_approval_request_id = None
        outcome = _map_approval_to_outcome(response, self._pending_approval_options)
        self._client.sendResponse(acp_id, outcome)

    def _register_approval_request(self, acp_id: int, params: dict[str, Any]) -> None:
        self._pending_approval_request_id = acp_id
        self._pending_approval_options = params.get("options", []) if params else []
        self._push({
            "type": SDK_EVENT_TYPES["APPROVAL_REQUEST"],
            "payload": _translate_permission(acp_id, params),
        })

    def _push(self, event: dict[str, Any]) -> None:
        if self._done:
            return
        if self._waiters:
            fut = self._waiters.pop(0)
            fut.set_result({"value": event, "done": False})
            return
        self._queue.append(event)

    def _end(self, *, ok: bool, value: Any = None, error: Exception | None = None) -> None:
        if self._done:
            return
        self._done = True
        if ok:
            self._result_future.set_result(value)
        else:
            self._result_future.set_exception(error or RuntimeError("turn failed"))
        for fut in self._waiters:
            fut.set_result({"value": None, "done": True})
        self._waiters.clear()

    def _end_with_error(self, err: Exception) -> None:
        if self._done:
            return
        self._push({
            "type": SDK_EVENT_TYPES["ERROR"],
            "code": "TRANSPORT_ERROR",
            "message": str(err),
        })
        self._end(ok=False, error=err)

    def __aiter__(self) -> BotTurn:
        return self

    async def __anext__(self) -> dict[str, Any]:
        if self._queue:
            return self._queue.pop(0)
        if self._done:
            raise StopAsyncIteration
        fut: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._waiters.append(fut)
        result = await fut
        if result.get("done"):
            raise StopAsyncIteration
        return result["value"]


# ---------------------------------------------------------------------------
# Translation helpers
# ---------------------------------------------------------------------------


def _to_acp_prompt_content(content: Any) -> list[dict[str, Any]]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    if isinstance(content, list):
        return content
    return [{"type": "text", "text": str(content)}]


def _extract_text_from_content(c: Any) -> str:
    if not c:
        return ""
    if isinstance(c, str):
        return c
    if isinstance(c, dict) and isinstance(c.get("text"), str):
        return c["text"]
    return ""


def translate_session_update(params: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not params:
        return []
    kind = params.get("sessionUpdate")
    if kind == SessionUpdateKinds.AGENT_MESSAGE_CHUNK:
        return [{
            "type": SDK_EVENT_TYPES["CONTENT_PART"],
            "payload": {"type": "text", "text": _extract_text_from_content(params.get("content"))},
        }]
    if kind == SessionUpdateKinds.AGENT_THOUGHT_CHUNK:
        return [{
            "type": SDK_EVENT_TYPES["CONTENT_PART"],
            "payload": {"type": "think", "think": _extract_text_from_content(params.get("content"))},
        }]
    if kind == SessionUpdateKinds.TOOL_CALL:
        return [{
            "type": SDK_EVENT_TYPES["TOOL_CALL"],
            "payload": {
                "id": params.get("toolCallId"),
                "function": {"name": params.get("title") or params.get("kind") or "tool"},
            },
        }]
    if kind == SessionUpdateKinds.TOOL_CALL_UPDATE:
        status = params.get("status")
        if status in ("completed", "failed"):
            out = _collect_tool_result_text(params.get("content"))
            return [{
                "type": SDK_EVENT_TYPES["TOOL_RESULT"],
                "payload": {"id": params.get("toolCallId"), "return_value": out},
            }]
        return [{"type": SDK_EVENT_TYPES["TOOL_CALL_PART"], "payload": params}]
    if kind == SessionUpdateKinds.PLAN:
        return [{"type": SDK_EVENT_TYPES["STATUS_UPDATE"], "payload": {"plan": params.get("entries")}}]
    if kind in (SessionUpdateKinds.AVAILABLE_COMMANDS_UPDATE, SessionUpdateKinds.USER_MESSAGE_CHUNK):
        return []
    return [{"type": SDK_EVENT_TYPES["UNKNOWN"], "payload": params}]


def _collect_tool_result_text(content: Any) -> str:
    if not isinstance(content, list):
        return ""
    parts = []
    for entry in content:
        if not entry:
            continue
        if isinstance(entry, str):
            parts.append(entry)
            continue
        if isinstance(entry, dict):
            if entry.get("content") and isinstance(entry["content"].get("text"), str):
                parts.append(entry["content"]["text"])
                continue
            if isinstance(entry.get("text"), str):
                parts.append(entry["text"])
                continue
        try:
            parts.append(json.dumps(entry, ensure_ascii=False))
        except Exception:
            parts.append(str(entry))
    return "\n".join(p for p in parts if p)


def _translate_permission(acp_id: int, params: dict[str, Any] | None) -> dict[str, Any]:
    tool_call = params.get("toolCall", {}) if params else {}
    return {
        "id": str(acp_id),
        "sender": "kimi",
        "action": tool_call.get("title") or tool_call.get("kind") or "tool call",
        "description": tool_call.get("title", ""),
        "options": params.get("options", []) if params else [],
    }


def _map_approval_to_outcome(response: str, options: list[Any]) -> dict[str, Any]:
    if response == "reject":
        return {"outcome": {"reason": "rejected by user"}}
    desired_kinds = (
        ["allow_always", "allow_for_session", "always_allow"]
        if response == "approve_for_session"
        else ["allow_once", "allow", "allowed"]
    )
    option = next(
        (
            o
            for o in options
            if (o.get("kind") or o.get("name") or o.get("optionId")) in desired_kinds
        ),
        None,
    )
    if option is None:
        option = next(
            (o for o in options if "allow" in str(o.get("optionId", "") or o.get("name", "")).lower()),
            None,
        )
    if option is None and options:
        option = options[0]
    return {"outcome": {"optionId": option.get("optionId", "allow") if option else "allow"}}
