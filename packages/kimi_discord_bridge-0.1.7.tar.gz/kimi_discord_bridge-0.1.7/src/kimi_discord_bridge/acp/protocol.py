"""ACP (Agent Client Protocol) constants."""


class Methods:
    INITIALIZE = "initialize"
    AUTHENTICATE = "authenticate"
    SESSION_NEW = "session/new"
    SESSION_LOAD = "session/load"
    SESSION_RESUME = "session/resume"
    SESSION_LIST = "session/list"
    SESSION_PROMPT = "session/prompt"
    SESSION_CANCEL = "session/cancel"
    SESSION_SET_MODE = "session/set_mode"
    SESSION_SET_MODEL = "session/set_model"


class ServerNotifs:
    SESSION_UPDATE = "session/update"


class ServerRequests:
    REQUEST_PERMISSION = "session/request_permission"
    FS_READ = "fs/read_text_file"
    FS_WRITE = "fs/write_text_file"
    TERMINAL_CREATE = "terminal/create"
    TERMINAL_OUTPUT = "terminal/output"
    TERMINAL_WAIT_FOR_EXIT = "terminal/wait_for_exit"
    TERMINAL_KILL = "terminal/kill"
    TERMINAL_RELEASE = "terminal/release"


class SessionUpdateKinds:
    USER_MESSAGE_CHUNK = "user_message_chunk"
    AGENT_MESSAGE_CHUNK = "agent_message_chunk"
    AGENT_THOUGHT_CHUNK = "agent_thought_chunk"
    TOOL_CALL = "tool_call"
    TOOL_CALL_UPDATE = "tool_call_update"
    PLAN = "plan"
    AVAILABLE_COMMANDS_UPDATE = "available_commands_update"


PROTOCOL_VERSION = 1
