"""AcpMux — owns one `kimi acp` child process and fans messages out to N clients."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any, Callable

from .codec import LineCodec, classify, encode
from .protocol import Methods, PROTOCOL_VERSION

logger = logging.getLogger(__name__)

ERR_BUSY = -32000
ERR_CLOSED = -32001


class AcpMux:
    """Multiplexer for ACP (line-delimited JSON-RPC 2.0)."""

    def __init__(
        self,
        *,
        workDir: str,
        env: dict[str, str] | None = None,
        args: list[str] | None = None,
        executable: str = "kimi",
        spawnFn: Callable | None = None,
        socketPath: str | None = None,
    ) -> None:
        if not workDir:
            raise ValueError("AcpMux: workDir is required")
        self.workDir = workDir
        self.env = env or {}
        self.args = args or []
        self.executable = executable
        self._spawn = spawnFn
        self.socketPath = socketPath

        # PYTHONPATH patch for OAuth-less ACP operation
        # sitecustomize.py is auto-imported by every Python process on startup
        self._sitecustomize_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "sitecustomize",
        )

        self._child: asyncio.subprocess.Process | None = None
        self._codec = LineCodec()

        # Routing state
        self._kimi_id = 0
        self._pending_from_kimi: dict[int, dict[str, Any]] = {}
        self._server_request_pending: set[int] = set()
        self._busy_by_prompt: dict[str, int] = {}

        self._clients: set[InProcessClient] = set()
        self._init_result: dict[str, Any] | None = None
        self._closed = False
        self._socket_server = None

        self._tasks: list[asyncio.Task] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        if self._child is not None:
            raise RuntimeError("AcpMux already started")

        # Merge env with PYTHONPATH auth patch
        merged_env = {**os.environ}
        if os.path.isdir(self._sitecustomize_dir):
            old_pp = merged_env.get("PYTHONPATH", "")
            merged_env["PYTHONPATH"] = (
                f"{self._sitecustomize_dir}{os.pathsep}{old_pp}" if old_pp else self._sitecustomize_dir
            )
        merged_env.update(self.env)

        if self._spawn:
            self._child = await self._spawn(
                self.executable,
                ["acp", *self.args],
                cwd=self.workDir,
                env=merged_env,
            )
        else:
            self._child = await asyncio.create_subprocess_exec(
                self.executable,
                "acp",
                *self.args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.workDir,
                env=merged_env,
            )

        self._tasks.append(asyncio.create_task(self._read_stdout()))
        self._tasks.append(asyncio.create_task(self._read_stderr()))
        self._tasks.append(asyncio.create_task(self._wait_child()))

        self._init_result = await self._bootstrap_initialize()

        if self.socketPath:
            await self._start_socket_server()

    @property
    def capabilities(self) -> dict[str, Any] | None:
        return self._init_result.get("agentCapabilities") if self._init_result else None

    def registerInProcessClient(
        self, handler: Callable[[dict[str, Any]], None]
    ) -> Any:
        if self._closed:
            raise RuntimeError("AcpMux is closed")
        client = InProcessClient(self, handler)
        self._clients.add(client)
        # Return a duck-typed handle so tests can do client.sendRequest(...)
        class _Handle:
            pass
        handle = _Handle()
        handle.sendRequest = client.sendRequest
        handle.sendResponse = client.sendResponse
        handle.close = lambda: self._remove_client(client)
        return handle

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if self._socket_server:
            self._socket_server.close()
            self._socket_server = None

        for t in self._tasks:
            t.cancel()
        self._tasks.clear()

        for c in list(self._clients):
            try:
                c.destroy()
            except Exception:
                pass
        self._clients.clear()

        for mux_id, m in list(self._pending_from_kimi.items()):
            try:
                m["client"].receive(
                    {
                        "jsonrpc": "2.0",
                        "id": m["originalId"],
                        "error": {"code": ERR_CLOSED, "message": "AcpMux closed"},
                    }
                )
            except Exception:
                pass
        self._pending_from_kimi.clear()
        self._busy_by_prompt.clear()
        self._server_request_pending.clear()

        if self._child:
            try:
                if self._child.stdin:
                    self._child.stdin.close()
            except Exception:
                pass
            try:
                self._child.kill()
            except Exception:
                pass
            self._child = None

    # ------------------------------------------------------------------
    # Internal — child I/O
    # ------------------------------------------------------------------

    async def _read_stdout(self) -> None:
        assert self._child is not None
        assert self._child.stdout is not None
        while True:
            try:
                line = await self._child.stdout.readline()
                if not line:
                    break
                self._on_kimi_stdout(line)
            except Exception:
                break

    async def _read_stderr(self) -> None:
        assert self._child is not None
        assert self._child.stderr is not None
        while True:
            try:
                line = await self._child.stderr.readline()
                if not line:
                    break
                text = line.decode("utf-8").strip()
                if text:
                    logger.warning("[AcpMux] stderr: %s", text)
            except Exception:
                break

    async def _wait_child(self) -> None:
        assert self._child is not None
        try:
            returncode = await self._child.wait()
        except Exception as exc:
            returncode = -1
            self._on_transport_error(exc)
            return
        if not self._closed:
            self._on_transport_error(
                Exception(f"kimi acp exited (code={returncode})")
            )

    # ------------------------------------------------------------------
    # Internal — protocol
    # ------------------------------------------------------------------

    async def _bootstrap_initialize(self) -> dict[str, Any]:
        self._kimi_id += 1
        mux_id = self._kimi_id
        future: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()

        class _Phantom:
            def receive(self, frame: dict[str, Any]) -> None:
                if frame.get("error"):
                    future.set_exception(self._frame_error(frame["error"]))
                else:
                    future.set_result(frame.get("result", {}))

        phantom = _Phantom()
        self._pending_from_kimi[mux_id] = {
            "client": phantom,
            "originalId": mux_id,
            "sid": None,
        }
        self._write_to_kimi(
            {
                "jsonrpc": "2.0",
                "id": mux_id,
                "method": Methods.INITIALIZE,
                "params": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "clientCapabilities": {
                        "fs": {"readTextFile": True, "writeTextFile": True},
                        "terminal": False,
                    },
                },
            }
        )
        return await future

    async def _start_socket_server(self) -> None:
        if self.socketPath and os.path.exists(self.socketPath):
            try:
                os.unlink(self.socketPath)
            except OSError:
                pass
        self._socket_server = await asyncio.start_unix_server(
            self._on_socket_client_connected,
            path=self.socketPath,
        )
        if self.socketPath:
            try:
                os.chmod(self.socketPath, 0o600)
            except OSError:
                pass

    def _on_socket_client_connected(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self._closed:
            writer.close()
            return
        client = SocketClient(reader, writer, self)
        self._clients.add(client)

    def _remove_client(self, client: InProcessClient | SocketClient) -> None:
        if client not in self._clients:
            return
        self._clients.discard(client)
        for mux_id, m in list(self._pending_from_kimi.items()):
            if m.get("client") is client:
                self._pending_from_kimi.pop(mux_id, None)
                if m.get("sid"):
                    self._busy_by_prompt.pop(m["sid"], None)
        try:
            client.destroy()
        except Exception:
            pass

    def _on_kimi_stdout(self, chunk: bytes) -> None:
        self._codec.feed(chunk)
        for msg in self._codec.messages():
            self._handle_kimi_message(msg)

    def _handle_kimi_message(self, msg: dict[str, Any]) -> None:
        kind = classify(msg)
        if kind == "response":
            m = self._pending_from_kimi.pop(msg.get("id"), None)
            if not m:
                logger.warning("[AcpMux] kimi response for unknown id=%s", msg.get("id"))
                return
            if m.get("sid"):
                self._busy_by_prompt.pop(m["sid"], None)
            try:
                m["client"].receive({**msg, "id": m["originalId"]})
            except Exception as exc:
                logger.error("[AcpMux] client.receive threw: %s", exc)
            return
        if kind == "notification":
            self._broadcast(msg)
            return
        if kind == "request":
            self._server_request_pending.add(msg["id"])
            self._broadcast(msg)
            return
        if kind == "invalid":
            logger.warning("[AcpMux] dropped invalid frame from kimi")
            return

    def _broadcast(self, msg: dict[str, Any]) -> None:
        for c in self._clients:
            try:
                c.receive(msg)
            except Exception as exc:
                logger.error("[AcpMux] broadcast failed: %s", exc)

    def _handle_client_incoming(self, client: InProcessClient, msg: dict[str, Any]) -> None:
        kind = classify(msg)
        if kind == "request":
            sid = msg.get("params", {}).get("sessionId")
            if msg.get("method") == Methods.SESSION_PROMPT and sid and sid in self._busy_by_prompt:
                client.receive(
                    {
                        "jsonrpc": "2.0",
                        "id": msg["id"],
                        "error": {
                            "code": ERR_BUSY,
                            "message": "busy: another turn is already in progress for this session",
                        },
                    }
                )
                return
            self._kimi_id += 1
            mux_id = self._kimi_id
            pending = {"client": client, "originalId": msg["id"], "sid": None}
            if msg.get("method") == Methods.SESSION_PROMPT and sid:
                pending["sid"] = sid
                self._busy_by_prompt[sid] = mux_id
            self._pending_from_kimi[mux_id] = pending
            self._write_to_kimi({**msg, "id": mux_id})
            return
        if kind == "response":
            if msg["id"] not in self._server_request_pending:
                logger.debug("[AcpMux] late response from client for id=%s (already resolved)", msg["id"])
                return
            self._server_request_pending.discard(msg["id"])
            self._write_to_kimi(msg)
            return
        if kind == "notification":
            self._write_to_kimi(msg)
            return
        if kind == "invalid":
            logger.warning("[AcpMux] invalid frame from client; ignoring")
            return

    def _remove_client(self, client: InProcessClient) -> None:
        if client not in self._clients:
            return
        self._clients.discard(client)
        for mux_id, m in list(self._pending_from_kimi.items()):
            if m.get("client") is client:
                self._pending_from_kimi.pop(mux_id, None)
                if m.get("sid"):
                    self._busy_by_prompt.pop(m["sid"], None)
        try:
            client.destroy()
        except Exception:
            pass

    def _write_to_kimi(self, frame: dict[str, Any]) -> None:
        if self._child is None or self._child.stdin is None:
            return
        try:
            self._child.stdin.write(encode(frame).encode("utf-8"))
        except Exception as exc:
            logger.warning("[AcpMux] write to kimi failed: %s", exc)

    def _on_transport_error(self, err: Exception) -> None:
        if self._closed:
            return
        self._closed = True

        if self._socket_server:
            try:
                self._socket_server.close()
            except Exception:
                pass
            self._socket_server = None

        for mux_id, m in list(self._pending_from_kimi.items()):
            try:
                m["client"].receive(
                    {
                        "jsonrpc": "2.0",
                        "id": m["originalId"],
                        "error": {"code": ERR_CLOSED, "message": str(err)},
                    }
                )
            except Exception:
                pass
        self._pending_from_kimi.clear()
        self._busy_by_prompt.clear()
        self._server_request_pending.clear()

        for c in list(self._clients):
            try:
                c.notify_transport_error(err)
            except Exception:
                pass
        self._clients.clear()
        self._child = None

    @staticmethod
    def _frame_error(error: dict[str, Any]) -> Exception:
        e = Exception(error.get("message", "kimi acp error"))
        e.code = error.get("code")  # type: ignore[attr-defined]
        e.data = error.get("data")  # type: ignore[attr-defined]
        return e


# ---------------------------------------------------------------------------
# Client adapters
# ---------------------------------------------------------------------------

class InProcessClient:
    def __init__(self, mux: AcpMux, handler: Callable[[dict[str, Any]], None]) -> None:
        self._mux = mux
        self._handler = handler
        self._local_id = 0
        self._pending: dict[int, asyncio.Future[Any]] = {}

    def sendRequest(self, method: str, params: dict[str, Any] | None = None) -> asyncio.Future[Any]:
        if self._mux._closed:
            raise RuntimeError("AcpMux is closed")
        self._local_id += 1
        local_id = self._local_id
        future: asyncio.Future[Any] = asyncio.get_event_loop().create_future()
        self._pending[local_id] = future
        self._mux._handle_client_incoming(
            self, {"jsonrpc": "2.0", "id": local_id, "method": method, "params": params or {}}
        )
        return future

    def sendResponse(self, id: int, result: Any = None, error: dict[str, Any] | None = None) -> None:
        frame: dict[str, Any] = {"jsonrpc": "2.0", "id": id}
        if error:
            frame["error"] = error
        else:
            frame["result"] = result if result is not None else None
        self._mux._handle_client_incoming(self, frame)

    def receive(self, frame: dict[str, Any]) -> None:
        if frame.get("id") is not None and ("result" in frame or "error" in frame):
            future = self._pending.pop(frame["id"], None)
            if future is None:
                return
            if frame.get("error"):
                future.set_exception(self._mux._frame_error(frame["error"]))
            else:
                future.set_result(frame["result"])
            return
        if isinstance(frame.get("method"), str):
            try:
                self._handler(
                    {
                        "kind": "notification" if frame.get("id") is None else "request",
                        "method": frame["method"],
                        "params": frame.get("params"),
                        "id": frame.get("id"),
                    }
                )
            except Exception as exc:
                logger.warning("[AcpMux] in-process handler threw: %s", exc)

    def notify_transport_error(self, err: Exception) -> None:
        for future in list(self._pending.values()):
            future.set_exception(err)
        self._pending.clear()
        try:
            self._handler({"kind": "transport-error", "error": str(err)})
        except Exception:
            pass

    def destroy(self) -> None:
        for future in list(self._pending.values()):
            future.set_exception(RuntimeError("client closed"))
        self._pending.clear()


class SocketClient:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, mux: AcpMux) -> None:
        self._reader = reader
        self._writer = writer
        self._mux = mux
        self._codec = LineCodec()
        self._task = asyncio.create_task(self._read_loop())

    async def _read_loop(self) -> None:
        try:
            while True:
                line = await self._reader.readline()
                if not line:
                    break
                self._codec.feed(line)
                for msg in self._codec.messages():
                    try:
                        self._mux._handle_client_incoming(self, msg)
                    except Exception as exc:
                        logger.warning("[AcpMux] socket client incoming error: %s", exc)
        except Exception as exc:
            logger.warning("[AcpMux] socket read error: %s", exc)
        finally:
            self._mux._remove_client(self)

    def receive(self, frame: dict[str, Any]) -> None:
        if self._writer.is_closing():
            return
        try:
            self._writer.write(encode(frame).encode("utf-8"))
            asyncio.create_task(self._writer.drain())
        except Exception as exc:
            logger.warning("[AcpMux] socket write failed: %s", exc)

    def notify_transport_error(self, _err: Exception) -> None:
        try:
            self._writer.close()
        except Exception:
            pass

    def destroy(self) -> None:
        try:
            self._writer.close()
        except Exception:
            pass
        if self._task and not self._task.done():
            self._task.cancel()
