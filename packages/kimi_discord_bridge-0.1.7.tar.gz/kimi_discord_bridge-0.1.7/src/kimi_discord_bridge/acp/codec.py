"""Line-delimited JSON-RPC 2.0 codec."""

from typing import Iterator, Any


class LineCodec:
    """Accumulates incoming bytes/strings and yields parsed JSON objects per line."""

    def __init__(self) -> None:
        self._buffer = ""

    def feed(self, chunk: str | bytes | None) -> None:
        if chunk is None:
            return
        if isinstance(chunk, bytes):
            self._buffer += chunk.decode("utf-8")
        else:
            self._buffer += chunk

    def messages(self) -> Iterator[dict[str, Any]]:
        while True:
            idx = self._buffer.find("\n")
            if idx == -1:
                break
            line = self._buffer[:idx]
            self._buffer = self._buffer[idx + 1 :]
            # strip trailing \r for \r\n compatibility
            if line.endswith("\r"):
                line = line[:-1]
            if len(line) == 0:
                continue
            try:
                yield dict(__line_obj := __import__("json").loads(line))
            except Exception as exc:
                yield {"_parseError": True, "raw": line, "error": str(exc)}


def classify(msg: Any) -> str:
    """Classify a JSON-RPC message.

    Returns one of: 'request', 'response', 'notification', 'invalid'.
    """
    if not isinstance(msg, dict) or msg.get("_parseError"):
        return "invalid"
    if isinstance(msg.get("method"), str):
        return "request" if "id" in msg else "notification"
    if "id" in msg and ("result" in msg or "error" in msg):
        return "response"
    return "invalid"


def encode(msg: dict[str, Any]) -> str:
    """Encode a JSON-RPC message as a single line with trailing newline."""
    import json

    return json.dumps(msg) + "\n"
