"""sessions.json CRUD with atomic write."""

import asyncio
import json
import os
import re
from pathlib import Path
from typing import Any

from kimi_discord_bridge.config import get_config

NAME_RE = re.compile(r"^[a-zA-Z0-9가-힣_-]{1,32}$")


class SessionManager:
    def __init__(self) -> None:
        self._sessions: dict[str, dict[str, Any]] = {}
        self._sdk_sessions: dict[str, Any] = {}
        self._active_turns: dict[str, Any] = {}
        self._lock = asyncio.Lock()

    async def load(self) -> None:
        path = Path(get_config().SESSION_DB_PATH)
        try:
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw)
            self._sessions.clear()
            for name, meta in data.items():
                self._sessions[name] = meta
        except FileNotFoundError:
            pass
        except Exception:
            raise

    def save(self) -> asyncio.Task:
        return asyncio.create_task(self._do_save())

    async def _do_save(self) -> None:
        async with self._lock:
            path = Path(get_config().SESSION_DB_PATH)
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(dict(self._sessions), ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, path)

    async def create(
        self, name: str, discord_thread_id: int, work_dir: str, surface_ref: str | None = None
    ) -> dict[str, Any]:
        if not isinstance(name, str) or not NAME_RE.match(name):
            raise ValueError(
                f'Invalid session name "{name}". Must match {NAME_RE.pattern} (1-32 chars).'
            )
        if not isinstance(work_dir, str) or len(work_dir) == 0:
            raise ValueError("Invalid workDir: must be a non-empty string.")
        if not os.path.isdir(work_dir):
            raise ValueError(f'workDir does not exist or is not accessible: "{work_dir}"')
        if name in self._sessions:
            raise ValueError(f'Session "{name}" already exists')

        meta = {
            "name": name,
            "discordThreadId": discord_thread_id,
            "workDir": work_dir,
            "surfaceRef": surface_ref,
            "status": "idle",
            "createdAt": datetime.now().isoformat(),
        }
        self._sessions[name] = meta
        await self.save()
        return meta

    def get(self, name: str) -> dict[str, Any] | None:
        return self._sessions.get(name)

    def get_by_thread(self, thread_id: int) -> dict[str, Any] | None:
        for meta in self._sessions.values():
            if meta.get("discordThreadId") == thread_id:
                return meta
        return None

    def get_by_surface(self, surface_ref: str | None) -> dict[str, Any] | None:
        if surface_ref is None:
            return None
        for meta in self._sessions.values():
            if meta.get("surfaceRef") == surface_ref:
                return meta
        return None

    def list(self) -> list[dict[str, Any]]:
        return list(self._sessions.values())

    async def update_status(self, name: str, status: str) -> None:
        meta = self._sessions.get(name)
        if not meta:
            raise ValueError(f'Session "{name}" not found')
        meta["status"] = status
        await self.save()

    async def set_session_id(self, name: str, session_id: str) -> None:
        meta = self._sessions.get(name)
        if not meta:
            raise ValueError(f'Session "{name}" not found')
        if not isinstance(session_id, str) or len(session_id) == 0:
            return
        if meta.get("sessionId") == session_id:
            return
        meta["sessionId"] = session_id
        await self.save()

    async def delete(self, name: str) -> bool:
        if name not in self._sessions:
            return False
        sdk = self._sdk_sessions.pop(name, None)
        if sdk and hasattr(sdk, "close"):
            try:
                await sdk.close()
            except Exception:
                pass
        self._sessions.pop(name, None)
        self._active_turns.pop(name, None)
        await self.save()
        return True

    def set_sdk_session(self, name: str, sdk_session: Any) -> None:
        self._sdk_sessions[name] = sdk_session

    def get_sdk_session(self, name: str) -> Any | None:
        return self._sdk_sessions.get(name)

    def set_active_turn(self, name: str, turn: Any) -> None:
        self._active_turns[name] = turn

    def get_active_turn(self, name: str) -> Any | None:
        return self._active_turns.get(name)

    def clear_active_turn(self, name: str) -> None:
        self._active_turns.pop(name, None)


from datetime import datetime

session_manager = SessionManager()
