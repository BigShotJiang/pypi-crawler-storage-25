"""kimi-discord-bridge — Discord bridge for Kimi CLI."""

__version__ = "0.1.0"
