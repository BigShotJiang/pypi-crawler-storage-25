"""Logging setup with daily rotation (keeps only today)."""

import json
import logging
import os
import re
from datetime import datetime
from pathlib import Path

from kimi_discord_bridge.config import get_config


class _DailyFileHandler(logging.FileHandler):
    def __init__(self, log_dir: str) -> None:
        self._log_dir = Path(log_dir)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._cleanup_old()
        path = self._log_dir / f"bridge-{datetime.now().strftime('%Y-%m-%d')}.log"
        super().__init__(path, encoding="utf-8")

    def _cleanup_old(self) -> None:
        today = datetime.now().strftime("%Y-%m-%d")
        pat = re.compile(r"^bridge-(\d{4}-\d{2}-\d{2})\.log$")
        try:
            for entry in self._log_dir.iterdir():
                m = pat.match(entry.name)
                if m and m.group(1) != today:
                    try:
                        entry.unlink()
                    except OSError:
                        pass
        except OSError:
            pass


def _safe_str(arg: object) -> str:
    if isinstance(arg, str):
        return arg
    if isinstance(arg, Exception):
        return arg.stack or f"{arg.__class__.__name__}: {arg}"
    try:
        return json.dumps(arg, ensure_ascii=False)
    except Exception:
        try:
            return str(arg)
        except Exception:
            return "[unserializable]"


def _format_args(args: tuple[object, ...]) -> str:
    if not args:
        return ""
    return " " + " ".join(_safe_str(a) for a in args)


def setup_logging() -> logging.Logger:
    cfg = get_config()
    logger = logging.getLogger("kimi_discord_bridge")
    logger.setLevel(logging.DEBUG)

    # Console
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    console.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(console)

    # File
    file_handler = _DailyFileHandler(cfg.LOG_DIR)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(file_handler)

    return logger


# Lazy init
_logger: logging.Logger | None = None


def get_logger() -> logging.Logger:
    global _logger
    if _logger is None:
        _logger = setup_logging()
    return _logger
