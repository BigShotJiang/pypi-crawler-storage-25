"""sitecustomize — auto-imported by Python on every startup.
Patches kimi-cli ACP auth check to bypass OAuth requirement.
"""

try:
    import kimi_cli.acp.server as _server
    import logging

    logger = logging.getLogger("kimi_discord_bridge.patch_auth")

    patched = False
    for cls_name in ("ACPServer", "AcpServer"):
        cls = getattr(_server, cls_name, None)
        if cls is not None and hasattr(cls, "_check_auth"):
            original = cls._check_auth
            def _patched(self, *args, **kwargs):
                return True
            cls._check_auth = _patched
            patched = True
            logger.info("[patch_auth] %s._check_auth patched", cls_name)
            break

    if not patched:
        logger.debug("[patch_auth] kimi_cli.acp.server not found or already patched")
except Exception:
    pass  # silently skip if kimi-cli is not installed
