"""Monkey-patch kimi-cli ACP auth check to allow OAuth-less operation.

This file is injected via PYTHONSTARTUP when spawning the `kimi acp` child
process. It disables the _check_auth check that normally requires a web
login session.
"""

import logging

logger = logging.getLogger("kimi_discord_bridge.patch_auth")

try:
    import kimi_cli.acp.server as _server

    # Try both capitalizations — kimi CLI has changed this before
    for cls_name in ("ACPServer", "AcpServer"):
        cls = getattr(_server, cls_name, None)
        if cls is not None and hasattr(cls, "_check_auth"):
            original = cls._check_auth

            def _patched(self, *args, **kwargs):
                logger.debug("[patch_auth] %s._check_auth bypassed", cls_name)
                return True

            cls._check_auth = _patched
            logger.info("[patch_auth] %s._check_auth patched (was %s)", cls_name, original)
            break
    else:
        logger.warning("[patch_auth] Could not find ACPServer/AcpServer in kimi_cli.acp.server")
except Exception as exc:
    logger.warning("[patch_auth] Failed to import/patch: %s", exc)
