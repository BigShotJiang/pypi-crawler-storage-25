from kimi_discord_bridge.cli import app

if __name__ == "__main__":
    app()
