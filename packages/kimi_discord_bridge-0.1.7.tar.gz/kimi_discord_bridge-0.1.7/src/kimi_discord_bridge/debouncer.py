"""Discord message debouncer / throttle."""

import asyncio
from typing import Any

import discord

from kimi_discord_bridge.config import get_config
from kimi_discord_bridge.formatter import split_message
from kimi_discord_bridge.logger import get_logger

logger = get_logger()


class MessageDebouncer:
    def __init__(self, channel: discord.TextChannel | discord.Thread, interval_ms: int | None = None) -> None:
        self._channel = channel
        self._interval_ms = interval_ms or get_config().DEBOUNCE_MS
        self._buffer = ""
        self._status = ""
        self._status_msg: discord.Message | None = None
        self._last_edit_time = asyncio.get_event_loop().time()
        self._timer: asyncio.Task | None = None
        self._disposed = False
        self._max_buffer_bytes = get_config().MAX_BUFFER_BYTES

    async def update(self, text: str = "", attachment: discord.File | None = None) -> None:
        if self._disposed:
            return
        if text:
            self._buffer += text
            self._cap_buffer()
        if attachment:
            try:
                await self._channel.send(file=attachment)
            except Exception as exc:
                logger.error("[Debouncer] Failed to send attachment: %s", exc)
        if text:
            await self._schedule_flush()

    async def set_status(self, status: str) -> None:
        if self._disposed:
            return
        self._status = status
        await self._schedule_flush()

    async def finalize(self) -> None:
        if self._disposed:
            return
        if self._timer:
            self._timer.cancel()
            self._timer = None

        try:
            embed = discord.Embed(color=0x2ECC71, title="✅ 완료")
            if self._status_msg:
                await self._status_msg.edit(embed=embed)
            else:
                self._status_msg = await self._channel.send(embed=embed)
        except Exception as exc:
            logger.error("[Debouncer] Failed to edit status to complete: %s", exc)

        if self._buffer:
            self._cap_buffer()
            chunks = split_message(self._buffer, get_config().max_message_content)
            for chunk in chunks:
                try:
                    embed = discord.Embed(description=chunk, color=0x2ECC71)
                    await self._channel.send(embed=embed)
                except Exception as exc:
                    logger.error("[Debouncer] Failed to send final chunk: %s", exc)

        self._disposed = True

    def dispose(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None
        self._disposed = True

    def _cap_buffer(self) -> None:
        cap = self._max_buffer_bytes
        if not cap or len(self._buffer) <= cap:
            return
        prev_marker = re.match(r"^\[…trimmed \d+ bytes…\]\n", self._buffer)
        stripped = self._buffer[len(prev_marker.group(0)) :] if prev_marker else self._buffer
        if len(stripped) <= cap:
            if prev_marker and len(stripped) == cap:
                return
            self._buffer = stripped
            return
        overflow = len(stripped) - cap
        marker = f"[…trimmed {overflow} bytes…]\n"
        self._buffer = marker + stripped[-cap:]

    async def _schedule_flush(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = (now - self._last_edit_time) * 1000
        if elapsed >= self._interval_ms:
            await self._flush()
        elif self._timer is None:
            remaining = (self._interval_ms - elapsed) / 1000
            self._timer = asyncio.create_task(self._deferred_flush(remaining))

    async def _deferred_flush(self, delay: float) -> None:
        await asyncio.sleep(delay)
        self._timer = None
        if not self._disposed:
            try:
                await self._flush()
            except Exception as exc:
                logger.error("[Debouncer] Deferred flush failed: %s", exc)

    async def _flush(self) -> None:
        if self._disposed:
            return
        self._last_edit_time = asyncio.get_event_loop().time()
        self._cap_buffer()
        slice_len = get_config().max_embed_description - 296
        tail = self._buffer[-slice_len:] if len(self._buffer) > slice_len else self._buffer

        embed = discord.Embed(color=0xFFC107)
        if self._status:
            embed.title = self._status
        if tail:
            embed.description = tail

        await self._edit_status_message(embed)

    async def _edit_status_message(self, embed: discord.Embed) -> None:
        try:
            if self._status_msg:
                await self._status_msg.edit(embed=embed)
            else:
                self._status_msg = await self._channel.send(embed=embed)
        except Exception as exc:
            logger.error("[Debouncer] Failed to edit status message: %s", exc)


import re
