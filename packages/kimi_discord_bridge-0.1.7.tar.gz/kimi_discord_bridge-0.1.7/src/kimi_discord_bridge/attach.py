"""`kimi-discord-bridge attach <name>` — socat replacement."""

import asyncio
import sys

from kimi_discord_bridge.config import get_config


async def attach_session(name: str) -> None:
    cfg = get_config()
    socket_path = f"{cfg.BOT_ACP_SOCKET_DIR}/bot-acp-{name}.sock"

    reader, writer = await asyncio.open_unix_connection(socket_path)

    async def stdin_to_socket() -> None:
        try:
            while True:
                line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
                if not line:
                    break
                writer.write(line.encode("utf-8"))
                await writer.drain()
        except Exception:
            pass
        finally:
            writer.close()

    async def socket_to_stdout() -> None:
        try:
            while True:
                data = await reader.read(4096)
                if not data:
                    break
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
        except Exception:
            pass

    await asyncio.gather(stdin_to_socket(), socket_to_stdout())
