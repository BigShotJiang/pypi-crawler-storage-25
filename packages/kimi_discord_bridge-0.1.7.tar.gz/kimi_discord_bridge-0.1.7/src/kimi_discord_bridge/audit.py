"""JSONL audit log."""

import json
import os
import re
from datetime import datetime
from pathlib import Path

from kimi_discord_bridge.config import get_config


class AuditLog:
    def __init__(self) -> None:
        self._log_dir = Path(get_config().LOG_DIR)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._cleanup_old()

    def _cleanup_old(self) -> None:
        today = datetime.now().strftime("%Y-%m-%d")
        pat = re.compile(r"^audit-(\d{4}-\d{2}-\d{2})\.jsonl$")
        try:
            for entry in self._log_dir.iterdir():
                m = pat.match(entry.name)
                if m and m.group(1) != today:
                    try:
                        entry.unlink()
                    except OSError:
                        pass
        except OSError:
            pass

    def _path(self) -> Path:
        return self._log_dir / f"audit-{datetime.now().strftime('%Y-%m-%d')}.jsonl"

    def log_event(self, event: dict) -> None:
        record = {"ts": datetime.now().isoformat(), **event}
        try:
            line = json.dumps(record, ensure_ascii=False, default=str)
        except Exception:
            line = json.dumps(
                {
                    "ts": record.get("ts", datetime.now().isoformat()),
                    "type": record.get("type", "unknown"),
                    "_serializeError": "unserializable",
                }
            )
        try:
            self._log_dir.mkdir(parents=True, exist_ok=True)
            with open(self._path(), "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass


_audit: AuditLog | None = None


def get_audit() -> AuditLog:
    global _audit
    if _audit is None:
        _audit = AuditLog()
    return _audit


def log_event(event: dict) -> None:
    get_audit().log_event(event)
