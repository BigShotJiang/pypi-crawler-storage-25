"""Discord bot — slash commands, modals, buttons, thread messages."""

from __future__ import annotations

import asyncio
import random
import string
import uuid
from datetime import datetime
from typing import Any

import discord
from discord import app_commands

from kimi_discord_bridge.acp.client import create_session
from kimi_discord_bridge.config import get_config
from kimi_discord_bridge.cmux import (
    create_surface,
    create_workspace,
    is_surface_alive,
    list_workspaces,
    read_screen,
    send_enter_to_surface,
    send_to_surface,
    verify_kimi_started,
    wait_for_terminal_ready,
)
from kimi_discord_bridge.debouncer import MessageDebouncer
from kimi_discord_bridge.formatter import (
    format_approval_request,
    format_content_part,
    format_question_request,
    format_tool_call,
    format_tool_result,
    split_message,
)
from kimi_discord_bridge.logger import get_logger
from kimi_discord_bridge.preflight import run_preflight
from kimi_discord_bridge.session_manager import session_manager

logger = get_logger()

# Pending /new requests
_pending_new_sessions: dict[str, dict[str, Any]] = {}
_PENDING_TTL_MS = 14 * 60 * 1000
_NEW_WORKSPACE_VALUE = "__new__"


def _reap_pending() -> None:
    cutoff = datetime.now().timestamp() * 1000 - _PENDING_TTL_MS
    for key in list(_pending_new_sessions.keys()):
        if _pending_new_sessions[key]["createdAt"] < cutoff:
            _pending_new_sessions.pop(key, None)


def _random_request_id() -> str:
    return "".join(random.choices(string.ascii_letters + string.digits, k=16))


class KimiBot(discord.Client):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.guild_messages = True
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self) -> None:
        await self._register_commands()

    async def _register_commands(self) -> None:
        cfg = get_config()
        guild = discord.Object(id=int(cfg.DISCORD_GUILD_ID))

        @app_commands.command(name="new", description="새 Kimi 세션 — 워크스페이스 선택 후 세션 이름 입력")
        async def cmd_new(interaction: discord.Interaction) -> None:
            await self._handle_new(interaction)

        @app_commands.command(name="list", description="활성 세션 목록을 표시합니다")
        async def cmd_list(interaction: discord.Interaction) -> None:
            await self._handle_list(interaction)

        @app_commands.command(name="status", description="세션 상태를 확인합니다")
        @app_commands.describe(name="세션 이름")
        async def cmd_status(interaction: discord.Interaction, name: str) -> None:
            await self._handle_status(interaction, name)

        @app_commands.command(name="close", description="세션을 종료합니다 (옵션 생략 시 활성 세션 목록 표시)")
        @app_commands.describe(name="세션 이름 (생략 가능)")
        async def cmd_close(interaction: discord.Interaction, name: str | None = None) -> None:
            await self._handle_close(interaction, name)

        @app_commands.command(name="steer", description="실행 중인 세션에 추가 메시지를 전송합니다")
        @app_commands.describe(name="세션 이름", message="전송할 메시지")
        async def cmd_steer(interaction: discord.Interaction, name: str, message: str) -> None:
            await self._handle_steer(interaction, name, message)

        @app_commands.command(name="interrupt", description="실행 중인 세션을 중단합니다")
        @app_commands.describe(name="세션 이름")
        async def cmd_interrupt(interaction: discord.Interaction, name: str) -> None:
            await self._handle_interrupt(interaction, name)

        @app_commands.command(name="peek", description="cmux surface의 현재 화면을 미리봅니다")
        @app_commands.describe(name="세션 이름", lines="표시할 줄 수 (1-100, 기본 30)")
        async def cmd_peek(interaction: discord.Interaction, name: str, lines: int = 30) -> None:
            await self._handle_peek(interaction, name, lines)

        self.tree.add_command(cmd_new, guild=guild)
        self.tree.add_command(cmd_list, guild=guild)
        self.tree.add_command(cmd_status, guild=guild)
        self.tree.add_command(cmd_close, guild=guild)
        self.tree.add_command(cmd_steer, guild=guild)
        self.tree.add_command(cmd_interrupt, guild=guild)
        self.tree.add_command(cmd_peek, guild=guild)
        self.tree.copy_global_to(guild=guild)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    async def on_ready(self) -> None:
        await run_preflight()
        await session_manager.load()
        await recover_sessions(self)
        logger.info("Logged in as %s", self.user)

    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot:
            return
        if not isinstance(message.channel, discord.Thread):
            return
        meta = session_manager.get_by_thread(message.channel.id)
        if not meta:
            return
        try:
            await self._send_prompt(meta["name"], message.content, message.channel)
        except Exception as exc:
            try:
                await message.reply(f"Error: {exc}")
            except Exception:
                pass

    async def on_interaction(self, interaction: discord.Interaction) -> None:
        if interaction.type == discord.InteractionType.component:
            custom_id = interaction.data.get("custom_id", "") if interaction.data else ""
            parts = custom_id.split(":")
            action = parts[0]
            try:
                if action == "new_workspace_select":
                    await self._handle_workspace_select(interaction, parts[1])
                elif action == "close_select":
                    await self._handle_close_select(interaction, parts[1])
                elif action in ("approve", "approve_session", "reject"):
                    await self._handle_button(interaction)
                else:
                    return
            except Exception as exc:
                logger.error("[bot] component handler error: %s", exc)
            return

        if interaction.type == discord.InteractionType.modal_submit:
            try:
                await self._handle_modal_submit(interaction)
            except Exception as exc:
                logger.error("[bot] modal submit error: %s", exc)
                try:
                    if interaction.response.is_done():
                        await interaction.edit_original_response(content=f"Error: {exc}")
                    else:
                        await interaction.response.send_message(f"Error: {exc}", ephemeral=True)
                except Exception:
                    pass
            return

    # ------------------------------------------------------------------
    # /new flow
    # ------------------------------------------------------------------

    async def _handle_new(self, interaction: discord.Interaction) -> None:
        _reap_pending()
        workspaces = []
        try:
            workspaces = await list_workspaces()
        except Exception as exc:
            logger.warning("[handleNew] listWorkspaces failed: %s", exc)

        request_id = _random_request_id()
        _pending_new_sessions[request_id] = {
            "userId": interaction.user.id,
            "createdAt": datetime.now().timestamp() * 1000,
        }

        if not workspaces:
            # No workspaces — show modal directly for new workspace + session
            modal = discord.ui.Modal(title="새 워크스페이스 + 세션 만들기")
            modal.add_item(discord.ui.TextInput(label="워크스페이스 이름", custom_id="ws_name", max_length=50, required=True))
            modal.add_item(
                discord.ui.TextInput(
                    label="작업 디렉토리 (절대경로)",
                    custom_id="ws_cwd",
                    placeholder="/Users/me/project",
                    max_length=200,
                    required=True,
                )
            )
            modal.add_item(discord.ui.TextInput(label="세션 이름", custom_id="session_name", max_length=32, required=True))
            modal.custom_id = f"new_workspace_modal:{request_id}"
            await interaction.response.send_modal(modal)
            return

        # Show workspace select menu
        opts = [
            discord.SelectOption(label=((ws.get("name") or ws["ref"]) + "")[:100], value=ws["ref"], description=f"Ref: {ws['ref']}"[:100])
            for ws in workspaces[:24]
        ]
        opts.append(discord.SelectOption(label="+ 새 워크스페이스 만들기", value="__new__", description="새 cmux 워크스페이스를 생성하고 세션 시작"))
        select = discord.ui.Select(
            custom_id=f"new_workspace_select:{request_id}",
            placeholder="워크스페이스를 선택하세요",
            options=opts,
        )
        view = discord.ui.View()
        view.add_item(select)
        await interaction.response.send_message(
            "워크스페이스를 선택하거나 새로 만드세요:",
            view=view,
            ephemeral=True,
        )

    async def _handle_workspace_select(self, interaction: discord.Interaction, request_id: str) -> None:
        pending = _pending_new_sessions.get(request_id)
        if not pending:
            await interaction.response.send_message("⏰ 만료되었거나 이미 처리된 요청입니다. `/new`를 다시 실행하세요.", ephemeral=True)
            return
        if interaction.user.id != pending["userId"]:
            await interaction.response.send_message("이 메뉴는 다른 사용자가 시작한 요청입니다.", ephemeral=True)
            return

        value = interaction.data.get("values", [""])[0] if interaction.data else ""  # type: ignore[attr-defined]

        if value == "__new__":
            modal = discord.ui.Modal(title="새 워크스페이스 + 세션 만들기")
            modal.add_item(discord.ui.TextInput(label="워크스페이스 이름", custom_id="ws_name", max_length=50, required=True))
            modal.add_item(
                discord.ui.TextInput(
                    label="작업 디렉토리 (절대경로)",
                    custom_id="ws_cwd",
                    placeholder="/Users/me/project",
                    max_length=200,
                    required=True,
                )
            )
            modal.add_item(discord.ui.TextInput(label="세션 이름", custom_id="session_name", max_length=32, required=True))
            modal.custom_id = f"new_workspace_modal:{request_id}"
            await interaction.response.send_modal(modal)
            return

        pending["workspaceRef"] = value
        modal = discord.ui.Modal(title="세션 이름 입력")
        modal.add_item(discord.ui.TextInput(label=f"세션 이름 (workspace: {value})", custom_id="session_name", max_length=32, required=True))
        modal.custom_id = f"session_name_modal:{request_id}"
        await interaction.response.send_modal(modal)

    async def _handle_modal_submit(self, interaction: discord.Interaction) -> None:
        custom_id = interaction.data.get("custom_id", "") if interaction.data else ""  # type: ignore[attr-defined]
        parts = custom_id.split(":")
        action = parts[0]
        if action not in ("new_workspace_modal", "session_name_modal", "new_session_modal"):
            return
        request_id = parts[1]
        pending = _pending_new_sessions.get(request_id)
        if not pending:
            await interaction.response.send_message("⏰ 만료된 요청입니다. `/new`를 다시 실행하세요.", ephemeral=True)
            return
        if interaction.user.id != pending["userId"]:
            await interaction.response.send_message("다른 사용자의 요청입니다.", ephemeral=True)
            return
        _pending_new_sessions.pop(request_id, None)

        await interaction.response.defer(ephemeral=True)

        name = ""
        work_dir = ""
        workspace_ref = pending.get("workspaceRef")

        if action == "new_workspace_modal":
            ws_name = ""
            ws_cwd = ""
            for component in interaction.data.get("components", []):  # type: ignore[attr-defined]
                for row in component.get("components", []):
                    if row.get("custom_id") == "ws_name":
                        ws_name = row.get("value", "").strip()
                    elif row.get("custom_id") == "ws_cwd":
                        ws_cwd = row.get("value", "").strip()
                    elif row.get("custom_id") == "session_name":
                        name = row.get("value", "").strip()
            ws_ref = await create_workspace(ws_name, ws_cwd, "")
            if not ws_ref:
                await interaction.edit_original_response(content=f"❌ 워크스페이스 생성 실패. (이름: {ws_name}, cwd: {ws_cwd})")
                return
            workspace_ref = ws_ref
            work_dir = ws_cwd
        elif action == "session_name_modal":
            for component in interaction.data.get("components", []):  # type: ignore[attr-defined]
                for row in component.get("components", []):
                    if row.get("custom_id") == "session_name":
                        name = row.get("value", "").strip()
            work_dir = get_config().DEFAULT_WORK_DIR
        else:
            # new_session_modal (Phase B fallback)
            for component in interaction.data.get("components", []):  # type: ignore[attr-defined]
                for row in component.get("components", []):
                    if row.get("custom_id") == "session_name":
                        name = row.get("value", "").strip()
                    elif row.get("custom_id") == "work_dir":
                        work_dir = row.get("value", "").strip()

        if not name or not work_dir:
            await interaction.edit_original_response(content="❌ 이름과 작업 디렉토리는 필수입니다.")
            return

        await self._create_session_from_modal(interaction, name, work_dir, workspace_ref)

    async def _create_session_from_modal(
        self, interaction: discord.Interaction, name: str, work_dir: str, workspace_ref: str | None = None
    ) -> None:
        if session_manager.get(name):
            await interaction.edit_original_response(content=f'❌ Session "{name}" already exists.')
            return

        thread = None
        try:
            thread = await interaction.channel.create_thread(name=name, auto_archive_duration=10080)  # type: ignore[union-attr]
        except Exception as exc:
            await interaction.edit_original_response(content=f"❌ Failed to create thread: {exc}")
            return

        surface_ref = None
        if workspace_ref:
            surface_ref = await create_surface(workspace_ref)

        try:
            await session_manager.create(name, thread.id, work_dir, surface_ref)
        except Exception as exc:
            try:
                await thread.delete()
            except Exception:
                pass
            await interaction.edit_original_response(content=f"❌ Failed to register session: {exc}")
            return

        try:
            await start_session(name, work_dir, {}, thread)

            kimi_status: str | None = None
            kimi_screen_tail = ""
            if surface_ref:
                ready = await wait_for_terminal_ready(surface_ref)
                if ready:
                    sock_path = socket_path_for_session(name)
                    if sock_path:
                        toad_cmd = f"{get_config().TOAD_CMD} acp \"exec kimi-discord-bridge attach {name}\""
                        ok1 = await send_to_surface(surface_ref, f"cd {work_dir} && {toad_cmd}")
                        ok2 = await send_enter_to_surface(surface_ref)
                        if not ok1 or not ok2:
                            logger.error(
                                "[createSessionFromModal] toad bootstrap failed (send=%s, enter=%s) for %s",
                                ok1, ok2, name,
                            )
                            kimi_status = "send_failed"
                        else:
                            status, screen = await verify_kimi_started(surface_ref)
                            kimi_status = status
                            kimi_screen_tail = (screen or "")[-600:]
                            if status == "ok":
                                logger.info("[createSessionFromModal] kimi-cli running on %s for %s", surface_ref, name)
                            elif status == "failed":
                                logger.error(
                                    "[createSessionFromModal] kimi-cli failed on %s for %s. Screen tail:\n%s",
                                    surface_ref, name, kimi_screen_tail,
                                )
                            else:
                                logger.warning(
                                    "[createSessionFromModal] kimi-cli verify timeout on %s for %s. Screen tail:\n%s",
                                    surface_ref, name, kimi_screen_tail,
                                )
                    else:
                        logger.warning("[createSessionFromModal] cmux sync disabled — pane will be empty for %s", name)
                        kimi_status = "no_socket"

            if surface_ref:
                status_marker = {
                    "ok": "✅ kimi 실행 확인",
                    "failed": "⚠️ kimi 실행 실패",
                    "timeout": "⚠️ kimi 실행 미확인 (timeout)",
                    "send_failed": "⚠️ surface send 실패",
                    "no_socket": "⚠️ ACP 소켓 미설정",
                }.get(kimi_status or "", "")
                surface_line = f"\n💻 surface: `{surface_ref}`"
                if status_marker:
                    surface_line += f" — {status_marker}"
                if kimi_status in ("failed", "timeout") and kimi_screen_tail:
                    surface_line += f"\n```\n{kimi_screen_tail[-400:]}\n```"
            else:
                surface_line = ""
            await interaction.edit_original_response(
                content=f"✅ Session **{name}** created → {thread.mention}\n🗂️ workspace: `{workspace_ref}`{surface_line}"
            )
        except Exception as exc:
            await interaction.edit_original_response(content=f"❌ Failed to start session: {exc}")
            await session_manager.delete(name)

    # ------------------------------------------------------------------
    # Other commands
    # ------------------------------------------------------------------

    async def _handle_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        sessions = session_manager.list()
        if not sessions:
            await interaction.edit_original_response(content="No active sessions.")
            return
        text = "\n".join(
            f"• **{s['name']}** — {s['status']} — <#{s['discordThreadId']}>" for s in sessions
        )
        await interaction.edit_original_response(content=text)

    async def _handle_status(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        meta = session_manager.get(name)
        if not meta:
            await interaction.edit_original_response(content=f'Session "{name}" not found.')
            return
        await interaction.edit_original_response(
            content=(
                f"**{meta['name']}**\n"
                f"Status: {meta['status']}\n"
                f"WorkDir: {meta['workDir']}\n"
                f"Created: {meta['createdAt']}"
            )
        )

    async def _handle_close(self, interaction: discord.Interaction, name: str | None) -> None:
        if name:
            await interaction.response.defer()
            if not session_manager.get(name):
                await interaction.edit_original_response(content=f'Session "{name}" not found.')
                return
            try:
                await close_session(name)
                await interaction.edit_original_response(content=f'Session "{name}" closed.')
            except Exception as exc:
                await interaction.edit_original_response(content=f"Error closing: {exc}")
            return

        sessions = session_manager.list()
        if not sessions:
            await interaction.response.send_message("No active sessions.", ephemeral=True)
            return

        # Phase B simplified: just close first or send list
        opts = [
            discord.SelectOption(label=s["name"], value=s["name"], description=f"{s['status']} — {s['workDir']}")
            for s in sessions[:25]
        ]
        select = discord.ui.Select(
            custom_id=f"close_select:{interaction.user.id}",
            placeholder="종료할 세션을 선택하세요",
            options=opts,
        )
        view = discord.ui.View()
        view.add_item(select)
        await interaction.response.send_message(
            f"종료할 세션을 선택하세요 ({len(sessions)}개 활성):",
            view=view,
            ephemeral=True,
        )

    async def _handle_close_select(self, interaction: discord.Interaction, owner_user_id: str) -> None:
        if str(interaction.user.id) != owner_user_id:
            await interaction.response.send_message("이 메뉴는 다른 사용자가 시작한 요청입니다.", ephemeral=True)
            return
        await interaction.response.defer()
        name = interaction.data.get("values", [""])[0] if interaction.data else ""  # type: ignore[attr-defined]
        if not session_manager.get(name):
            await interaction.edit_original_response(content=f'Session "{name}" not found.')
            return
        try:
            await close_session(name)
            await interaction.edit_original_response(content=f'✅ Session "{name}" closed.')
        except Exception as exc:
            await interaction.edit_original_response(content=f'❌ Error closing "{name}": {exc}')

    async def _handle_steer(self, interaction: discord.Interaction, name: str, message: str) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            await steer(name, message, self)
            await interaction.edit_original_response(content=f'Steered "{name}".')
        except Exception as exc:
            await interaction.edit_original_response(content=f"Error: {exc}")

    async def _handle_interrupt(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            await interrupt(name)
            await interaction.edit_original_response(content=f'Interrupted "{name}".')
        except Exception as exc:
            await interaction.edit_original_response(content=f"Error: {exc}")

    async def _handle_peek(self, interaction: discord.Interaction, name: str, lines: int) -> None:
        await interaction.response.defer(ephemeral=True)

        if not 1 <= lines <= 100:
            lines = max(1, min(lines, 100))

        meta = session_manager.get(name)
        if not meta:
            await interaction.edit_original_response(content=f'Session "{name}" not found.')
            return
        if not meta.get("surfaceRef"):
            await interaction.edit_original_response(content=f'Session "{name}" has no cmux surface.')
            return

        content = await read_screen(meta["surfaceRef"], lines)
        if content is None:
            await interaction.edit_original_response(content="cmux returned no output (surface dead or error).")
            return
        if not content:
            await interaction.edit_original_response(content="(screen is empty)")
            return

        safe = content.replace("```", "``​`")
        wrapped = f"```\n{safe}\n```"
        chunks = split_message(wrapped, 1900)
        if not chunks:
            await interaction.edit_original_response(content="(no content)")
            return

        await interaction.edit_original_response(content=chunks[0])
        for chunk in chunks[1:]:
            await interaction.followup.send(content=chunk, ephemeral=True)

    async def _handle_button(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        custom_id = interaction.data.get("custom_id", "") if interaction.data else ""  # type: ignore[attr-defined]
        parts = custom_id.split(":")
        if len(parts) < 3:
            return
        action, session_name, request_id = parts[0], parts[1], parts[2]
        response_map = {
            "approve": "approve",
            "approve_session": "approve_for_session",
            "reject": "reject",
        }
        response = response_map.get(action)
        if not response:
            return
        try:
            await handle_approval(session_name, request_id, response)
            label = {
                "approve": "✅ 승인됨",
                "reject": "❌ 거부됨",
                "approve_session": "🔄 세션 전체 승인됨",
            }.get(action, action)
            await interaction.edit_original_response(content=label)
        except Exception as exc:
            await interaction.edit_original_response(content=f"Error: {exc}")

    # ------------------------------------------------------------------
    # Prompt handling
    # ------------------------------------------------------------------

    async def _send_prompt(self, session_name: str, content: str, thread: discord.Thread) -> None:
        session = session_manager.get_sdk_session(session_name)
        if not session:
            raise RuntimeError(f'SDK session "{session_name}" not found.')
        existing_turn = session_manager.get_active_turn(session_name)
        if existing_turn:
            raise RuntimeError(
                f'Session "{session_name}" is already running. Use /steer or /interrupt.'
            )
        await session_manager.update_status(session_name, "running")
        turn = session.prompt(content)
        session_manager.set_active_turn(session_name, turn)
        debouncer = MessageDebouncer(thread)

        try:
            async for event in turn:
                etype = event.get("type")
                if etype == "TurnBegin":
                    await debouncer.set_status("⏳ 생각 중...")
                elif etype == "ContentPart":
                    payload = event.get("payload", {})
                    fmt = format_content_part(payload)
                    if fmt.get("text"):
                        await debouncer.update(fmt["text"], fmt.get("attachment"))
                    elif fmt.get("attachment"):
                        await debouncer.update("", fmt.get("attachment"))
                elif etype == "ToolCall":
                    await debouncer.set_status(format_tool_call(event.get("payload", {})))
                elif etype == "ToolResult":
                    fmt = format_tool_result(event.get("payload", {}))
                    await debouncer.update(fmt["text"])
                elif etype == "StepBegin":
                    await debouncer.set_status(f"📍 Step {event.get('payload', {}).get('n', '')}")
                elif etype == "StepInterrupted":
                    await debouncer.set_status("⚠️ Step interrupted")
                elif etype == "CompactionBegin":
                    await debouncer.set_status("📦 Compacting context...")
                elif etype == "SubagentEvent":
                    await debouncer.update(f"\n> [sub-agent] {event.get('payload', {}).get('event', {}).get('type', 'event')}\n")
                elif etype == "error":
                    code = event.get("code", "UNKNOWN")
                    msg = event.get("message", "unknown error")
                    if code in ("UNKNOWN_EVENT_TYPE", "UNKNOWN_REQUEST_TYPE"):
                        logger.debug("protocol drift (%s): %s", code, msg)
                    elif code == -32000 and "busy" in msg.lower():
                        await debouncer.update(
                            "\n⏳ 다른 클라이언트가 이미 turn 진행 중입니다. `/interrupt`로 취소하거나 잠시 기다려주세요.\n"
                        )
                    elif code in ("TRANSPORT_ERROR", -32001):
                        logger.warning("transport error: %s", msg)
                        await debouncer.update(
                            f"\n💥 kimi acp 연결이 끊겼습니다: {msg}\n세션이 `crashed`로 마킹됩니다.\n"
                        )
                    else:
                        logger.warning("error event (%s): %s", code, msg)
                        await debouncer.update(f"\n⚠️ kimi {code}: {msg}\n")
                elif etype == "TurnEnd":
                    await debouncer.finalize()
                elif etype == "ApprovalRequest":
                    await self._send_approval_buttons(session_name, event.get("payload", {}), thread)
                elif etype == "QuestionRequest":
                    await self._send_question_embed(session_name, event.get("payload", {}), thread)
                else:
                    logger.warning("Unknown event type: %s %s", etype, event)
        except Exception as exc:
            logger.error("Error in session %s: %s", session_name, exc)
            debouncer.dispose()
            try:
                await thread.send(f"❌ 오류가 발생했습니다: {exc}")
            except Exception:
                pass
        finally:
            session_manager.clear_active_turn(session_name)
            await session_manager.update_status(session_name, "idle")

    async def _send_approval_buttons(
        self, session_name: str, payload: dict[str, Any], thread: discord.Thread
    ) -> None:
        embed = format_approval_request(payload)
        view = discord.ui.View()
        view.add_item(
            discord.ui.Button(
                label="✅ 승인",
                style=discord.ButtonStyle.success,
                custom_id=f"approve:{session_name}:{payload.get('id')}",
            )
        )
        view.add_item(
            discord.ui.Button(
                label="🔄 세션 전체 승인",
                style=discord.ButtonStyle.primary,
                custom_id=f"approve_session:{session_name}:{payload.get('id')}",
            )
        )
        view.add_item(
            discord.ui.Button(
                label="❌ 거부",
                style=discord.ButtonStyle.danger,
                custom_id=f"reject:{session_name}:{payload.get('id')}",
            )
        )
        try:
            await thread.send(embed=embed, view=view)
        except Exception as exc:
            logger.error("Failed to send approval buttons: %s", exc)

    async def _send_question_embed(
        self, session_name: str, payload: dict[str, Any], thread: discord.Thread
    ) -> None:
        embed = format_question_request(payload)
        try:
            await thread.send(embed=embed)
        except Exception as exc:
            logger.error("Failed to send question embed: %s", exc)


# ---------------------------------------------------------------------------
# Kimi client helpers (mirrors kimi-client.js)
# ---------------------------------------------------------------------------


def socket_path_for_session(name: str) -> str | None:
    cfg = get_config()
    return f"{cfg.BOT_ACP_SOCKET_DIR}/bot-acp-{name}.sock"


async def start_session(
    name: str, work_dir: str, options: dict[str, Any] = None, thread: discord.Thread | None = None
) -> Any:
    options = options or {}
    session = None
    try:
        session = await create_session(
            workDir=work_dir,
            sessionId=options.get("sessionId"),
            model=options.get("model"),
            thinking=options.get("thinking", False),
            yoloMode=options.get("yolo", False),
            socketPath=socket_path_for_session(name),
            executable=get_config().KIMI_ACP_EXECUTABLE,
            onCrash=lambda err: asyncio.create_task(_on_session_crash(name, err)),
        )
    except Exception as exc:
        if thread:
            try:
                await session_manager.delete(name)
            except Exception:
                pass
            try:
                await thread.delete()
            except Exception:
                pass
        raise

    session_manager.set_sdk_session(name, session)
    if session and isinstance(session.sessionId, str) and session.sessionId:
        try:
            await session_manager.set_session_id(name, session.sessionId)
        except Exception as exc:
            logger.warning('Failed to persist sessionId for "%s": %s', name, exc)
    await session_manager.update_status(name, "idle")
    return session


async def send_prompt(session_name: str, content: str, thread: discord.Thread) -> None:
    session = session_manager.get_sdk_session(session_name)
    if not session:
        raise RuntimeError(f'SDK session "{session_name}" not found.')
    existing_turn = session_manager.get_active_turn(session_name)
    if existing_turn:
        raise RuntimeError(
            f'Session "{session_name}" is already running. Use /steer or /interrupt.'
        )
    await session_manager.update_status(session_name, "running")
    turn = session.prompt(content)
    session_manager.set_active_turn(session_name, turn)
    debouncer = MessageDebouncer(thread)
    try:
        async for event in turn:
            etype = event.get("type")
            if etype == "TurnBegin":
                await debouncer.set_status("⏳ 생각 중...")
            elif etype == "ContentPart":
                payload = event.get("payload", {})
                fmt = format_content_part(payload)
                if fmt.get("text"):
                    await debouncer.update(fmt["text"], fmt.get("attachment"))
                elif fmt.get("attachment"):
                    await debouncer.update("", fmt.get("attachment"))
            elif etype == "ToolCall":
                await debouncer.set_status(format_tool_call(event.get("payload", {})))
            elif etype == "ToolResult":
                fmt = format_tool_result(event.get("payload", {}))
                await debouncer.update(fmt["text"])
            elif etype == "StepBegin":
                await debouncer.set_status(f"📍 Step {event.get('payload', {}).get('n', '')}")
            elif etype == "StepInterrupted":
                await debouncer.set_status("⚠️ Step interrupted")
            elif etype == "CompactionBegin":
                await debouncer.set_status("📦 Compacting context...")
            elif etype == "SubagentEvent":
                await debouncer.update(
                    f"\n> [sub-agent] {event.get('payload', {}).get('event', {}).get('type', 'event')}\n"
                )
            elif etype == "error":
                code = event.get("code", "UNKNOWN")
                msg = event.get("message", "unknown error")
                if code in ("UNKNOWN_EVENT_TYPE", "UNKNOWN_REQUEST_TYPE"):
                    logger.debug("protocol drift (%s): %s", code, msg)
                elif code == -32000 and "busy" in msg.lower():
                    await debouncer.update(
                        "\n⏳ 다른 클라이언트가 이미 turn 진행 중입니다. `/interrupt`로 취소하거나 잠시 기다려주세요.\n"
                    )
                elif code in ("TRANSPORT_ERROR", -32001):
                    logger.warning("transport error: %s", msg)
                    await debouncer.update(
                        f"\n💥 kimi acp 연결이 끊겼습니다: {msg}\n세션이 `crashed`로 마킹됩니다.\n"
                    )
                else:
                    logger.warning("error event (%s): %s", code, msg)
                    await debouncer.update(f"\n⚠️ kimi {code}: {msg}\n")
            elif etype == "TurnEnd":
                await debouncer.finalize()
            elif etype == "ApprovalRequest":
                # Approval buttons are sent by _send_prompt above
                pass
            elif etype == "QuestionRequest":
                pass
            else:
                logger.warning("Unknown event type: %s %s", etype, event)
    except Exception as exc:
        logger.error("Error in session %s: %s", session_name, exc)
        debouncer.dispose()
        try:
            await thread.send(f"❌ 오류가 발생했습니다: {exc}")
        except Exception:
            pass
    finally:
        session_manager.clear_active_turn(session_name)
        await session_manager.update_status(session_name, "idle")


async def steer(session_name: str, content: str, client: discord.Client | None = None) -> Any:
    turn = session_manager.get_active_turn(session_name)
    if turn:
        return await turn.steer(content)
    meta = session_manager.get(session_name)
    if not meta:
        raise RuntimeError(f'Session "{session_name}" not found.')
    if not client:
        raise RuntimeError(f'Session "{session_name}" has no active turn and no client fallback.')
    thread = await client.fetch_channel(meta["discordThreadId"])
    if not thread:
        raise RuntimeError(f'Thread {meta["discordThreadId"]} not found.')
    return await send_prompt(session_name, content, thread)


async def interrupt(session_name: str) -> None:
    turn = session_manager.get_active_turn(session_name)
    if not turn:
        raise RuntimeError(f'Session "{session_name}" has no active turn to interrupt.')
    await turn.interrupt()


async def handle_approval(session_name: str, request_id: str, response: str) -> None:
    turn = session_manager.get_active_turn(session_name)
    if not turn:
        raise RuntimeError(f'Session "{session_name}" has no active turn.')
    await turn.approve(request_id, response)


async def _on_session_crash(name: str, err: Exception) -> None:
    logger.warning('session "%s" transport crashed: %s', name, err)
    try:
        await session_manager.update_status(name, "crashed")
    except Exception:
        pass


async def recover_sessions(bot: discord.Client) -> dict[str, int]:
    metas = session_manager.list()
    if not metas:
        return {"recovered": 0, "crashed": 0, "skipped": 0}

    recovered = 0
    crashed = 0
    for meta in metas:
        if not meta.get("sessionId"):
            logger.warning('[recover] "%s" has no stored sessionId; marking crashed.', meta["name"])
            try:
                await session_manager.update_status(meta["name"], "crashed")
            except Exception:
                pass
            crashed += 1
            continue
        try:
            await start_session(meta["name"], meta["workDir"], {"sessionId": meta["sessionId"]}, None)
            await rebootstrap_tui(meta)
            logger.info('[recover] "%s" restored (sessionId=%s).', meta["name"], meta["sessionId"])
            recovered += 1
        except Exception as exc:
            logger.warning('[recover] "%s" failed to resume: %s', meta["name"], exc)
            try:
                await session_manager.update_status(meta["name"], "crashed")
            except Exception:
                pass
            crashed += 1

    logger.info("[recover] done — %d recovered, %d crashed.", recovered, crashed)
    return {"recovered": recovered, "crashed": crashed, "skipped": 0}


async def rebootstrap_tui(meta: dict[str, Any]) -> None:
    if not meta.get("surfaceRef"):
        return
    try:
        alive = await is_surface_alive(meta["surfaceRef"])
        if not alive:
            logger.info('[recover] "%s" surface %s is dead; skipping TUI re-bootstrap.', meta["name"], meta["surfaceRef"])
            return
        sock_path = socket_path_for_session(meta["name"])
        if not sock_path:
            return
        toad_cmd = f"{get_config().TOAD_CMD} acp \"exec kimi-discord-bridge attach {meta['name']}\""
        ok1 = await send_to_surface(meta["surfaceRef"], f"cd {meta['workDir']} && {toad_cmd}")
        ok2 = await send_enter_to_surface(meta["surfaceRef"])
        if not (ok1 and ok2):
            logger.error('[recover] toad bootstrap failed (send=%s, enter=%s) for "%s".', ok1, ok2, meta["name"])
            return
        status, screen = await verify_kimi_started(meta["surfaceRef"])
        if status == "ok":
            logger.info('[recover] "%s" kimi-cli running on %s.', meta["name"], meta["surfaceRef"])
        elif status == "failed":
            logger.error('[recover] "%s" kimi-cli failed on %s. Screen tail:\n%s',
                         meta["name"], meta["surfaceRef"], (screen or "")[-600:])
        else:
            logger.warning('[recover] "%s" kimi-cli verify timeout on %s. Screen tail:\n%s',
                           meta["name"], meta["surfaceRef"], (screen or "")[-600:])
    except Exception as exc:
        logger.warning('[recover] "%s" TUI re-bootstrap failed: %s', meta["name"], exc)


async def close_session(session_name: str) -> None:
    session = session_manager.get_sdk_session(session_name)
    if session:
        try:
            await session.close()
        except Exception:
            pass
    await session_manager.delete(session_name)


async def shutdown_session(session_name: str) -> None:
    session = session_manager.get_sdk_session(session_name)
    if session:
        try:
            await session.close()
        except Exception:
            pass
    session_manager._sdk_sessions.pop(session_name, None)
    session_manager._active_turns.pop(session_name, None)
    try:
        await session_manager.update_status(session_name, "idle")
    except Exception:
        pass


async def shutdown_bot(bot: discord.Client) -> None:
    logger.info("Shutting down — preserving sessions for next boot.")
    for meta in session_manager.list():
        try:
            await shutdown_session(meta["name"])
        except Exception as exc:
            logger.warning('[shutdown] "%s" cleanup failed: %s', meta["name"], exc)
    try:
        await bot.close()
    except Exception:
        pass
