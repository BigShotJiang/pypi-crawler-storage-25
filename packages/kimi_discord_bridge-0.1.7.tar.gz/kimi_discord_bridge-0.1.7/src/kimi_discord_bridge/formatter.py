"""ContentPart / ToolCall → Discord embed formatting."""

import base64
import re
from typing import Any

import discord

from kimi_discord_bridge.config import get_config


def data_uri_to_attachment(data_uri: str, filename: str = "attachment") -> discord.File | None:
    try:
        m = re.match(r"^data:([^;]+);base64,(.+)$", data_uri)
        if not m:
            return None
        mime_type = m.group(1)
        b64_data = m.group(2)
        ext = mime_type.split("/")[1] if "/" in mime_type else "bin"
        buffer = base64.b64decode(b64_data)
        return discord.File(__import__("io").BytesIO(buffer), filename=f"{filename}.{ext}")
    except Exception:
        return None


def format_content_part(part: dict[str, Any]) -> dict[str, Any]:
    ptype = part.get("type")
    if ptype == "text":
        return {"text": part.get("text", "")}

    if ptype == "think":
        limit = get_config().THINK_TRUNCATE
        think = part.get("think", "")
        truncated = think[:limit] + "..." if len(think) > limit else think
        return {"text": f"*💭 Thinking...*\n```\n{truncated}\n```"}

    if ptype == "image_url":
        url = part.get("image_url", {}).get("url") or part.get("url", "")
        if url.startswith("data:"):
            attachment = data_uri_to_attachment(url)
            if attachment:
                return {"text": "", "attachment": attachment}
            return {"text": "🖼️ [Image](data URI — failed to parse)"}
        return {"text": f"🖼️ [Image]({url})"}

    if ptype == "audio_url":
        url = part.get("audio_url", {}).get("url") or part.get("url", "")
        return {"text": f"🔊 [Audio]({url})"}

    if ptype == "video_url":
        url = part.get("video_url", {}).get("url") or part.get("url", "")
        return {"text": f"🎬 [Video]({url})"}

    return {"text": f"[unknown: {ptype}]"}


def format_tool_call(tool_call: dict[str, Any]) -> str:
    func = tool_call.get("function", {})
    return f"🔧 `{func.get('name', 'unknown')}`"


def format_tool_result(tool_result: dict[str, Any]) -> dict[str, str]:
    raw = tool_result.get("return_value", "")
    if isinstance(raw, str):
        as_string = raw
    else:
        try:
            as_string = json.dumps(raw, indent=2, ensure_ascii=False)
        except Exception:
            as_string = str(raw)
    is_error = "error" in as_string.lower()
    icon = "❌" if is_error else "✅"
    limit = get_config().TOOL_RESULT_TRUNCATE
    truncated = as_string[:limit] + "..." if len(as_string) > limit else as_string
    return {"text": f"\n{icon} Result:\n```\n{truncated}\n```\n"}


def format_approval_request(payload: dict[str, Any]) -> discord.Embed:
    embed = discord.Embed(color=0xFFA500, title="🔒 승인 요청")
    embed.add_field(name="Sender", value=payload.get("sender", "unknown"), inline=True)
    embed.add_field(name="Action", value=payload.get("action", "unknown"), inline=True)
    embed.add_field(
        name="Description", value=payload.get("description", "No description provided")
    )
    return embed


def format_question_request(payload: dict[str, Any]) -> discord.Embed:
    embed = discord.Embed(color=0x3498DB, title="❓ 질문")
    questions = payload.get("questions", [])
    for i, q in enumerate(questions):
        embed.add_field(name=f"Q{i + 1}", value=q or "(empty)")
    return embed


def split_message(text: str, max_len: int = 4000) -> list[str]:
    if not text:
        return []
    if len(text) <= max_len:
        return [text]

    chunks = []
    remaining = text
    while remaining:
        if len(remaining) <= max_len:
            chunks.append(remaining)
            break

        split_at = max_len
        last_newline = remaining.rfind("\n", 0, max_len)
        if last_newline > max_len * 0.5:
            split_at = last_newline + 1

        chunk = remaining[:split_at]
        remaining = remaining[split_at:]

        fence_count = chunk.count("```")
        inside_code_block = fence_count % 2 != 0
        if inside_code_block:
            chunk += "\n```"
            remaining = "```\n" + remaining

        chunks.append(chunk)

    return chunks
