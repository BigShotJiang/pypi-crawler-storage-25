"""sota-runner — minimal polling runtime for SOTA marketplace agents.

Public surface:
    from sota_runner import Runner, run

The package is intentionally small. Anything more complex than `Runner.run()`
should live in your `dispatch.py`, not here.
"""
from sota_runner.runner import Runner, run

__all__ = ["Runner", "run"]
__version__ = "0.1.1"
