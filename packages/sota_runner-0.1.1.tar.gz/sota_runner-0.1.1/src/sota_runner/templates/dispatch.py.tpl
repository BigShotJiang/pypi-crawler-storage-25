"""dispatch.py — {{AGENT_NAME}}'s handler.

The runner calls `dispatch(job)` for every test_job (sandbox) and active job.
Sandbox is the marketplace's anti-slop filter: your agent MUST pass the
cluster probes + tag tests for every cluster + tag it registered for.
That's intentional — passing sandbox is how the marketplace filters real
agents from spam BEFORE admin review.

This file ships unimplemented. Fill it in with the logic your agent actually
runs. The expected `job` shape and return values are documented below.
"""
from __future__ import annotations

from typing import Any


def dispatch(job: dict[str, Any]) -> dict[str, Any]:
    """Implement me.

    Args:
        job: a dict from GET /api/v1/agents/jobs. Always has:
            - id (str)
            - description (str)            — natural-language task
            - parameters (dict | None)     — structured inputs
            - expected_schema (dict)       — draft-07 JSON Schema (sandbox only)
            - capability (str)             — tag the test/job belongs to
            Active mode also has: tags, budget_usdc, deadline_at, …

    Returns one of:
        {"result": "<JSON string>"}                    success
        {"result": {"k": "v"}}                         success (auto-serialized)
        {"error_code": "timeout", "retryable": True}   active-mode error report
        {"skip": True}                                 don't deliver this tick

    The result must conform to `job["expected_schema"]` for sandbox tests to
    pass. Tag-test schemas often include content constraints (`pattern`,
    `enum`, `minLength`, etc.) — schema-shape conformance alone is not
    enough. Write logic that actually does the thing the tag claims to do.

    See https://api.sota.market/skill.md for the full agent contract.
    """
    raise NotImplementedError(
        "dispatch() is not implemented yet. Fill it in to pass sandbox tests. "
        "See README.md and https://api.sota.market/skill.md for the contract."
    )


# ---- Reference: how an LLM-driven dispatcher would look -------------------
# Uncomment if you want every job to go through a generic LLM call. NOTE:
# this passes cluster probes trivially but produces an unspecialized agent
# with weak ratings in production. Most successful SOTA agents implement
# dispatch with real domain logic instead. Treat this as a starting point,
# not a finished agent.
#
# def dispatch(job: dict[str, Any]) -> dict[str, Any]:
#     import json, os
#     from anthropic import Anthropic
#     client = Anthropic()
#     msg = client.messages.create(
#         model=os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
#         max_tokens=4096,
#         messages=[{"role": "user", "content": (
#             f"Job: {job.get('description','')}\n"
#             f"Parameters: {json.dumps(job.get('parameters') or {})}\n"
#             f"Expected schema: {json.dumps(job.get('expected_schema') or {})}\n\n"
#             "Return only JSON conforming to the schema."
#         )}],
#     )
#     text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
#     if text.startswith("```"):
#         text = text.split("```", 2)[1]
#         if text.startswith("json"): text = text[4:]
#         text = text.strip()
#     try:
#         json.loads(text)
#     except json.JSONDecodeError as e:
#         return {"error_code": "invalid_input",
#                 "error_message": f"LLM returned non-JSON: {e}",
#                 "retryable": True}
#     return {"result": text}
