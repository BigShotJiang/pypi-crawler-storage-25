sota-runner>=0.1.0
# anthropic>=0.40.0   # only needed if you use the LLM reference dispatcher
