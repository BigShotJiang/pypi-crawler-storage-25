# Jacloud

Jacloud is a web application with a Vue.js frontend and a FastAPI backend. The frontend is built statically during the Python build process, ensuring that no Javascript runtime is required on the server or when the Python package is used.

## Deployment Instructions

Follow these steps to deploy Jacloud:

### Prerequisites

Ensure the following tools are installed on your system:

- **Python `uvx`**: [UV's installation guide](https://docs.astral.sh/uv/getting-started/installation/)
- **Javascript `deno`**: [Deno's installation guide](https://docs.deno.com/runtime/getting_started/installation/) (`npm` and `bun` are also supported)
- **Git tools**: Ensure Git is installed and configured.

### Authenticate to `git.zi.fi`

`uvx` cannot prompt for your Git credentials, so it may hang if authentication is required. To avoid this, store your Git credentials beforehand:

1. Configure Git to store credentials globally:

   ```bash
   git config --global credential.helper store
   ```

2. Add your credentials to the `.git-credentials` file:
   ```bash
   echo "https://youruser:yourpassword@git.zi.fi" >> ~/.git-credentials
   ```

> **Note** GUI-based authentication may be possible depending on your system's toolkit.

### Running in Production

To run a specific version of Jacloud from the Git repository:

```bash
uvx --from git+https://git.zi.fi/Vasanko/jacloud.git@v0.6.7 jacloud
```

The application will now be running and accessible at `http://localhost:8077`. FastAPI serves both the backend API and the statically built frontend.

If you need to expose the application to the Internet, consider using [Caddy](https://caddyserver.com/) as a reverse proxy. Configuration examples (Caddyfiles) are provided in the caddy folder.

When running behind a proxy that is not at localhost, configure its IP by the environment variable `FORWARDED_ALLOW_IPS`. Set it empty to disable proxy headers. The default is to trust localhost.

### Running in Development Mode

To set up a development environment:

1. Clone the repository:

   ```bash
   git clone https://git.zi.fi/Vasanko/jacloud.git
   cd jacloud
   ```

2. Enable the repository-managed Git hooks:

   ```bash
   git config core.hooksPath .githooks
   ```

3. Start the development server:
   ```bash
   uvx --with-editable . jacloud --dev
   ```

The development server will now be accessible at `http://localhost:8077`. In this mode:

- **Frontend**: Vite serves the frontend with live updates on port `8077`.
- **Backend**: FastAPI serves the API, proxied through Vite, on port `8078`.

Any changes to the code will automatically trigger updates for both the frontend and backend.

The application should now be running and accessible at `http://localhost:8077`. Use a reverse proxy like [Caddy](https://caddyserver.com/) to expose it to the Internet if needed.

### Building a Python Package for Production

This method is ideal for deploying on a separate server without installing all development tools. Only a Python or UV installation is required on the server.

1. Clone the repository and optionally check out a specific version:

   ```bash
   git clone https://git.zi.fi/Vasanko/jacloud.git
   cd jacloud
   git checkout v0.3.4  # Replace with your desired version
   ```

2. Build the Python package:

   ```bash
   uv build
   ```

3. Transfer the package to your production server:

   ```bash
   scp dist/jacloud-*.tar.gz user@yourserver:
   ```

4. Install and run the package on the server:
   - Using `uvx`:
     ```bash
     uvx --from jacloud-*.tar.gz jacloud
     ```
   - Or globally with `pip` (not recommended):
     ```bash
     pip install jacloud-*.tar.gz --break-system-packages
     ~/.local/bin/jacloud
     ```
