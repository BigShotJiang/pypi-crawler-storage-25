"""Flow graph for pipe network calculations.

Converts the UI-oriented PipeNet structure into a calculation-oriented graph.

Input model (PipeNet):
- Pipes: each record represents BOTH supply and return (combined storage)
- Radiators: terminal components at dead-end nodes
- HX (heat exchanger + pump): implicit at root in current data, explicit here

Output model (FlowGraph):
- Each combined pipe expands to supply + return physical segments
- Supply = away from HX (toward radiators), Return = toward HX
- All components (pipes, radiators, HX) treated uniformly
- Components in circuits, no special anchor — just components in loops
- Disconnected circuits are possible (though not in current data)

Supply/return labeling is explicit at each build site: the branch
builder knows whether it is constructing a supply leg or a return leg
and passes that information directly.  BFS depth from the HX root is
used only for topological orientation (determining which junction is
nearer to the HX in backbone branches).
"""

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from jacloud.project import PipeNet, Project


@dataclass
class Branch:
    """Ordered sequence of components connecting two junctions.

    All components in a branch carry the same flow (series connection).
    Components are identified by string keys:
    - "supply pipekey" or "return pipekey" for physical pipe segments
    - radiator key (as-is) for radiators
    - "HX:<hx_key>" for the heat exchanger/pump

    Junctions are typed as "supply nodekey" or "return nodekey" to keep
    supply and return networks separate.  RAD bridges S→R, HX bridges R→S.
    """

    key: str
    junctions: tuple[str, str]  # (from_junction, to_junction) node keys
    components: list[str] = field(default_factory=list)

    @property
    def is_loop(self) -> bool:
        """True if branch starts and ends at same junction."""
        return self.junctions[0] == self.junctions[1]


@dataclass
class FlowGraph:
    """Flow calculation graph with physical pipe segments.

    Junctions are typed: "supply nodekey" and "return nodekey" are separate.
    Supply connects only to supply, return only to return.
    RAD bridges S→R, HX bridges R→S.
    """

    junctions: set[str]
    branches: dict[str, Branch]
    junction_branches: dict[str, list[str]] = field(default_factory=dict)
    num_supply_pipes: int = 0
    num_return_pipes: int = 0
    component_nodes: dict[str, tuple[str, str]] = field(default_factory=dict)
    """Pipe component key → (from_node, to_node) in branch traversal order.

    Only populated for pipe components ("supply pipekey" / "return pipekey").
    For multi-segment pipes the endpoints are the first from_node and last
    to_node of the traversal.
    """

    pruned_pipes: set[str] = field(default_factory=set)
    """Pipe keys removed during dangling-end pruning.

    These pipes are disconnected (one or both ends dangling) and carry
    no flow.  Stored so that result extraction can report zero-flow
    entries for them.
    """

    def get_branches_at(self, junction: str) -> list[Branch]:
        """Get all branches connected to a junction."""
        return [self.branches[k] for k in self.junction_branches.get(junction, [])]


HX_COMPONENT_PREFIX = "HX:"


def is_hx_component(comp: str) -> bool:
    """True for keyed HX component labels."""
    return comp.startswith(HX_COMPONENT_PREFIX)


def hx_key_from_component(comp: str) -> str | None:
    """Extract HX key from "HX:<key>" labels, else None."""
    if comp.startswith(HX_COMPONENT_PREFIX):
        key = comp[len(HX_COMPONENT_PREFIX) :]
        return key or None
    return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_adjacency_sets(pipenet: PipeNet) -> dict[str, set[str]]:
    """Build node adjacency map from pipe routes as mutable sets."""
    adj_set: dict[str, set[str]] = {node: set() for node in pipenet.nodes}
    for pipe in pipenet.pipes.values():
        route = pipe.route()
        for i, node in enumerate(route):
            if i > 0:
                adj_set[node].add(route[i - 1])
            if i < len(route) - 1:
                adj_set[node].add(route[i + 1])
    return adj_set


def _build_edge_map(
    pipenet: PipeNet,
) -> dict[tuple[str, str], tuple[str, int]]:
    """Map directed edge (node_a, node_b) → (pipe_key, segment_index).

    For multi-node pipes each consecutive node pair is a separate segment
    so that different segments can appear in different branches when the
    pipe passes through a junction.
    """
    edge_map: dict[tuple[str, str], tuple[str, int]] = {}
    for pipe_key, pipe in pipenet.pipes.items():
        route = pipe.route()
        for i in range(len(route) - 1):
            a, b = route[i], route[i + 1]
            edge_map[(a, b)] = (pipe_key, i)
            edge_map[(b, a)] = (pipe_key, i)
    return edge_map


def _build_radiator_map(radiators: dict) -> dict[str, list[str]]:
    """Map node key → list of radiator keys at that node.

    Works with both PipeNet.radiators (old) and CalcPipeNet.radiators.
    Each radiator value must have a ``node`` attribute.
    """
    rad_at: dict[str, list[str]] = {}
    for rad_key, rad in radiators.items():
        rad_at.setdefault(rad.node, []).append(rad_key)
    return rad_at


def _build_hx_map(pipenet: PipeNet) -> dict[str, list[str]]:
    """Map node key → list of HX keys for nodes within HX connection regions.

    Each HX has its own (x, y, floor) position. Pipe endpoints (degree-1 nodes
    or any node) within a 1000x1000 square centered at the HX position are
    implicitly connected to that HX.

    For calc-time networks that expose absolute node heights and floor metadata,
    the mapping is floor-aware. Additionally, if a vertical riser segment passes
    through the HX floor at h=2100 mm, the segment endpoints are also marked as
    HX-connected so through-risers are anchored even without an open-end node.
    """
    hx_at: dict[str, list[str]] = {}
    half_size = 500  # 1000x1000 square → ±500 from center

    node_floor_ids = getattr(pipenet, "node_floor_ids", None)
    floor_base_heights = getattr(pipenet, "floor_base_heights", None)

    def _add(node_key: str, hx_key: str) -> None:
        lst = hx_at.setdefault(node_key, [])
        if hx_key not in lst:
            lst.append(hx_key)

    def _on_hx_floor(node_key: str, hx_floor: str) -> bool:
        if isinstance(node_floor_ids, dict):
            return node_floor_ids.get(node_key) == hx_floor
        return True

    for hx_key, hx in pipenet.hxs.items():
        hx_x, hx_y = hx.x, hx.y
        # Find nodes within the HX's connection region
        for node_key, node in pipenet.nodes.items():
            if (
                abs(node.x - hx_x) <= half_size
                and abs(node.y - hx_y) <= half_size
                and _on_hx_floor(node_key, hx.floor)
            ):
                _add(node_key, hx_key)

        # Through-riser support: if a vertical segment at HX (x,y) crosses
        # h=2100 mm of the HX floor, treat it as HX-connected.
        if isinstance(floor_base_heights, dict) and hx.floor in floor_base_heights:
            z_target = floor_base_heights[hx.floor] + 2100
            for pipe in pipenet.pipes.values():
                route = pipe.route()
                for i in range(len(route) - 1):
                    n1_key = route[i]
                    n2_key = route[i + 1]
                    n1 = pipenet.nodes.get(n1_key)
                    n2 = pipenet.nodes.get(n2_key)
                    if n1 is None or n2 is None:
                        continue
                    # Vertical riser-like segment at HX x/y location.
                    if n1.x != n2.x or n1.y != n2.y:
                        continue
                    if abs(n1.x - hx_x) > half_size or abs(n1.y - hx_y) > half_size:
                        continue

                    z1 = getattr(n1, "z", getattr(n1, "h", 0))
                    z2 = getattr(n2, "z", getattr(n2, "h", 0))
                    z_min = min(z1, z2)
                    z_max = max(z2, z1)
                    if z_min <= z_target <= z_max:
                        # Only mark the endpoint that is actually on the
                        # HX floor.  Adding both endpoints would cause
                        # HX-collapse to merge nodes on different floors,
                        # eliminating the edge (riser segment) between them.
                        if _on_hx_floor(n1_key, hx.floor):
                            _add(n1_key, hx_key)
                        if _on_hx_floor(n2_key, hx.floor):
                            _add(n2_key, hx_key)

    return hx_at


def _prune_dangling(
    adj_set: dict[str, set[str]],
    edge_map: dict[tuple[str, str], tuple[str, int]],
    radiator_nodes: set[str],
    hx_nodes: set[str],
) -> set[str]:
    """Remove dangling dead-end nodes from the adjacency graph.

    Iteratively peels degree-1 nodes that are neither radiator nor HX
    endpoints.  This prevents disconnected or spur pipes from creating
    spurious junctions and altering the network topology.

    Mutates *adj_set* and *edge_map* in place.

    Returns the set of pipe keys whose edges were fully removed (all
    segments pruned).
    """
    # Track which (pipe_key, seg_idx) have been pruned
    pruned_segments: set[tuple[str, int]] = set()
    # Collect all segments per pipe key for later "fully pruned" check
    all_segments: dict[str, set[int]] = {}
    for (a, b), (pk, seg) in edge_map.items():
        if a < b:  # avoid double-counting
            all_segments.setdefault(pk, set()).add(seg)

    changed = True
    while changed:
        changed = False
        # Snapshot keys — set may change during iteration
        for node in list(adj_set):
            neighbors = adj_set.get(node)
            if neighbors is None:
                continue
            if len(neighbors) != 1:
                continue
            if node in radiator_nodes or node in hx_nodes:
                continue
            # Degree-1 dangling node — prune it
            (neighbor,) = neighbors
            # Record the pruned edge
            info = edge_map.get((node, neighbor))
            if info:
                pruned_segments.add(info)
            # Remove edge from both sides of adjacency
            adj_set[neighbor].discard(node)
            del adj_set[node]
            # Remove both directions from edge_map
            edge_map.pop((node, neighbor), None)
            edge_map.pop((neighbor, node), None)
            changed = True

    # A pipe is fully pruned if every segment was removed
    pruned_pipes: set[str] = set()
    for pk, segs in all_segments.items():
        if segs and segs <= {s for p, s in pruned_segments if p == pk}:
            pruned_pipes.add(pk)
    return pruned_pipes


def _prune_to_hx_connected(
    adj_set: dict[str, set[str]],
    edge_map: dict[tuple[str, str], tuple[str, int]],
    hx_nodes: set[str],
) -> set[str]:
    """Remove components that are not reachable from any HX node.

    Hydraulic solve is only meaningful for topology connected to a heat source.
    Mutates *adj_set* and *edge_map* in place and returns fully removed pipe keys.
    """
    if not adj_set:
        return set()

    # Snapshot existing segments for "fully removed" detection.
    all_segments: dict[str, set[int]] = {}
    for (a, b), (pk, seg) in edge_map.items():
        if a < b:  # avoid double-counting bidirectional edges
            all_segments.setdefault(pk, set()).add(seg)

    roots = [node for node in hx_nodes if node in adj_set]
    reachable: set[str] = set()
    if roots:
        queue = deque(roots)
        reachable.update(roots)
        while queue:
            node = queue.popleft()
            for neighbor in adj_set.get(node, set()):
                if neighbor not in reachable:
                    reachable.add(neighbor)
                    queue.append(neighbor)

    unreachable = set(adj_set) - reachable

    removed_segments: set[tuple[str, int]] = set()
    for node in list(unreachable):
        for neighbor in list(adj_set.get(node, set())):
            info = edge_map.get((node, neighbor))
            if info:
                removed_segments.add(info)
            edge_map.pop((node, neighbor), None)
            edge_map.pop((neighbor, node), None)
            if neighbor in adj_set:
                adj_set[neighbor].discard(node)
        adj_set.pop(node, None)

    pruned_pipes: set[str] = set()
    for pk, segs in all_segments.items():
        if segs and segs <= {s for p, s in removed_segments if p == pk}:
            pruned_pipes.add(pk)
    return pruned_pipes


def _find_hx_root(
    adj: dict[str, list[str]], radiator_nodes: set[str], hx_nodes: set[str]
) -> str | None:
    """Find the implied HX root: a degree-1 node that is not a radiator.

    If hx_nodes contains a degree-1 node, prefer that.
    Returns None if all degree-1 nodes are radiators (HX at a junction).
    """
    # Prefer explicit HX nodes that are degree-1 (dead ends)
    for node in hx_nodes:
        if node in adj and len(adj[node]) == 1:
            return node
    # Otherwise prefer any explicit HX node still present in the graph.
    # Picking a true HX node avoids drifting root selection to unrelated
    # dead-ends when topology has no degree-1 HX endpoint.
    present_hx_nodes = [node for node in hx_nodes if node in adj]
    if present_hx_nodes:
        return min(present_hx_nodes, key=lambda node: (len(adj[node]), node))
    # Fallback: any degree-1 non-radiator node
    for node, neighbors in adj.items():
        if len(neighbors) == 1 and node not in radiator_nodes:
            return node
    return None


def _bfs_depth(root: str, adj: dict[str, list[str]]) -> dict[str, int]:
    """BFS from root, returning depth (distance) of each reachable node."""
    depth = {root: 0}
    queue = deque([root])
    while queue:
        node = queue.popleft()
        for neighbor in adj[node]:
            if neighbor not in depth:
                depth[neighbor] = depth[node] + 1
                queue.append(neighbor)
    return depth


# ---------------------------------------------------------------------------
# Main builder
# ---------------------------------------------------------------------------

# Type alias for an edge: (from_node, to_node, (pipe_key, segment_index))
_Edge = tuple[str, str, tuple[str, int]]


def build_flow_graph(pipenet: PipeNet) -> FlowGraph:
    """Build flow calculation graph from PipeNet.

    Algorithm:
    1. Build adjacency from pipes
    2. BFS from HX root to get depth of every node
    3. Find junctions (pipe-degree ≥ 3, or ≥ 2 with a radiator)
    4. Trace radiator loops:  junction → supply pipes → RAD → return pipes → junction
    5. Trace backbone paths:  HX dead-end → loop with return/supply by depth
                              junction-to-junction → separate supply and return branches
    6. If HX is at a junction, add it as a self-loop component

    Vertical pipes (risers) appear as regular Pipe objects in the
    instantiated CalcPipeNet.
    """
    if not pipenet.pipes:
        return FlowGraph(junctions=set(), branches={})

    # Build adjacency and edge map
    adj_set = _build_adjacency_sets(pipenet)
    edge_map = _build_edge_map(pipenet)

    radiator_at = _build_radiator_map(pipenet.radiators)
    radiator_nodes = set(radiator_at)

    hx_at = _build_hx_map(pipenet)
    hx_nodes = set(hx_at)

    # --- Detect HX root before collapse (degree-1 HX nodes still exist) ---
    _adj_pre = {node: sorted(neighbors) for node, neighbors in adj_set.items()}
    hx_root_pre = _find_hx_root(_adj_pre, radiator_nodes, hx_nodes)

    # --- Collapse HX-box nodes into single representatives ---
    # Multiple pipe endpoints within the same HX's 1000×1000 box are
    # implicitly connected through the heat exchanger.  Merge them into
    # one representative node so the graph is naturally connected.
    _hx_groups: dict[str, list[str]] = {}
    for node, hx_keys in hx_at.items():
        for hk in hx_keys:
            _hx_groups.setdefault(hk, []).append(node)

    collapse: dict[str, str] = {}  # old_node → representative
    for group_nodes in _hx_groups.values():
        if len(group_nodes) <= 1:
            continue
        rep = min(group_nodes)
        for node in group_nodes:
            if node != rep:
                collapse[node] = rep

    if collapse:
        # Remap adjacency
        for old, rep in collapse.items():
            for nb in adj_set.pop(old, set()):
                mapped = collapse.get(nb, nb)
                if mapped == rep:
                    continue
                adj_set.setdefault(rep, set()).add(mapped)
                nbr = adj_set.get(mapped)
                if nbr is not None:
                    nbr.discard(old)
                    nbr.add(rep)
        collapsed_nodes = set(collapse)
        for adj_neighbors in adj_set.values():
            adj_neighbors.difference_update(collapsed_nodes)

        # Remap edge_map
        new_em: dict[tuple[str, str], tuple[str, int]] = {}
        for (a, b), info in edge_map.items():
            ra, rb = collapse.get(a, a), collapse.get(b, b)
            if ra != rb:
                new_em[(ra, rb)] = info
        edge_map.clear()
        edge_map.update(new_em)

        # Update hx_at / hx_nodes
        new_hx: dict[str, list[str]] = {}
        for node, keys in hx_at.items():
            r = collapse.get(node, node)
            lst = new_hx.setdefault(r, [])
            for k in keys:
                if k not in lst:
                    lst.append(k)
        hx_at = new_hx
        hx_nodes = set(hx_at)

        # Remap radiator_at if a radiator sits inside an HX box
        for old, rep in collapse.items():
            if old in radiator_at:
                radiator_at.setdefault(rep, []).extend(radiator_at.pop(old))
                radiator_nodes.discard(old)
                radiator_nodes.add(rep)

    # --- Prune dangling dead-ends ---
    # Remove degree-1 nodes (not RAD/HX) iteratively so that spur
    # pipes do not create spurious junctions or alter the topology.
    pruned_pipes = _prune_dangling(adj_set, edge_map, radiator_nodes, hx_nodes)
    # Keep only topology connected to at least one HX node.
    pruned_pipes |= _prune_to_hx_connected(adj_set, edge_map, hx_nodes)

    adj = {node: sorted(neighbors) for node, neighbors in adj_set.items()}

    if not adj:
        return FlowGraph(
            junctions=set(),
            branches={},
            junction_branches={},
            component_nodes={},
            pruned_pipes=pruned_pipes,
        )

    # --- HX root and depth ---
    # Use the pre-collapse root (remapped through collapse) so that
    # the HX identity survives even when collapsing raises its degree.
    if hx_root_pre is not None:
        hx_root = collapse.get(hx_root_pre, hx_root_pre)
    else:
        hx_root = _find_hx_root(adj, radiator_nodes, hx_nodes)

    hx_at_junction = hx_root is None

    if hx_root is None:
        # No explicit HX - shouldn't happen, but fall back to first node
        hx_root = next(iter(adj))

    # HX is at a junction if it has degree > 1
    hx_at_junction = len(adj.get(hx_root, [])) > 1

    depth = _bfs_depth(hx_root, adj)

    # --- Junctions ---
    # degree ≥ 3 in the pipe graph, OR degree ≥ 2 with a radiator attached
    # (radiator at a degree-2 node splits flow: some to radiator, rest onward)
    junctions: set[str] = set()
    for node, neighbors in adj.items():
        deg = len(neighbors)
        if deg >= 3 or (deg >= 2 and node in radiator_nodes):
            junctions.add(node)

    if hx_at_junction:
        junctions.add(hx_root)

    # Ensure each connected component has at least one junction seed.
    # This keeps disconnected HX networks solvable independently.
    seen_nodes: set[str] = set()
    for start in sorted(adj):
        if start in seen_nodes:
            continue
        queue = deque([start])
        component_nodes: list[str] = []
        while queue:
            node = queue.popleft()
            if node in seen_nodes:
                continue
            seen_nodes.add(node)
            component_nodes.append(node)
            for nb in adj[node]:
                if nb not in seen_nodes:
                    queue.append(nb)

        if any(node in junctions for node in component_nodes):
            continue

        roots = [
            node
            for node in component_nodes
            if len(adj[node]) == 1 and node not in radiator_nodes
        ]
        if roots:
            junctions.add(min(roots))
        elif component_nodes:
            junctions.add(min(component_nodes))

    # --- Edge labeling ---
    supply_count = 0
    return_count = 0

    component_nodes: dict[str, tuple[str, str]] = {}

    def label_edge(
        side: str, from_node: str, to_node: str, edge_info: tuple[str, int]
    ) -> str:
        """Label a pipe edge as supply or return.

        *side* must be ``"supply"`` or ``"return"`` — the caller knows
        which leg of the circuit is being built.

        *edge_info* is ``(pipe_key, segment_index)`` from the edge map.
        The resulting component key is ``"{side} {pipe_key}:{seg_idx}"``.

        Also records the traversal endpoints in *component_nodes*.
        For multi-segment pipes (route with >2 nodes) successive calls
        extend the recorded range: the first from_node and last to_node
        are kept.
        """
        nonlocal supply_count, return_count
        if side == "supply":
            supply_count += 1
        else:
            return_count += 1
        pipe_key, seg_idx = edge_info
        comp = f"{side} {pipe_key}:{seg_idx}"
        # Record traversal endpoints
        if comp in component_nodes:
            component_nodes[comp] = (component_nodes[comp][0], to_node)
        else:
            component_nodes[comp] = (from_node, to_node)
        return comp

    def hx_component_for_node(node_key: str) -> str:
        """Return a keyed HX component label for a pipe node."""
        keys = sorted(hx_at.get(node_key, []))
        if keys:
            return f"{HX_COMPONENT_PREFIX}{keys[0]}"
        raise ValueError(f"Missing HX key for HX-connected node: {node_key}")

    # --- Trace helpers ---

    def trace_to_junction(start: str) -> tuple[str, list[_Edge]]:
        """Walk from *start* toward the nearest junction.

        Returns (junction_key, edges) where edges go from start toward
        the junction.  If start IS a junction, returns (start, []).
        """
        if start in junctions:
            return start, []

        if start not in adj:
            # Node has no pipe connections — disconnected radiator stub.
            return start, []

        edges: list[_Edge] = []
        current = start
        visited = {start}

        while current not in junctions:
            if current not in adj:
                break
            moved = False
            for neighbor in adj[current]:
                if neighbor not in visited:
                    pk = edge_map.get((current, neighbor))
                    if pk:
                        edges.append((current, neighbor, pk))
                    visited.add(neighbor)
                    current = neighbor
                    moved = True
                    break
            if not moved:
                break

        if current in junctions:
            return current, edges
        return start, []

    def trace_from_junction(
        junction: str, first_neighbor: str, visited_canon: set[tuple[str, str]]
    ) -> tuple[list[_Edge], str | None, str]:
        """Trace from a junction outward until hitting another junction or dead-end.

        Marks traversed edges in *visited_canon* (canonical undirected pairs).

        Returns:
            (edges, end_node, end_type)
            end_type is 'junction', 'hx', 'radiator', 'dangling', or 'none'
        """
        edges: list[_Edge] = []
        current = junction
        next_node = first_neighbor

        while True:
            canon = (min(current, next_node), max(current, next_node))
            if canon in visited_canon:
                return edges, None, "none"
            visited_canon.add(canon)

            pk = edge_map.get((current, next_node))
            if pk:
                edges.append((current, next_node, pk))

            if next_node in junctions:
                return edges, next_node, "junction"

            if len(adj[next_node]) == 1:
                if next_node in radiator_nodes:
                    kind = "radiator"
                elif next_node in hx_nodes or next_node == hx_root:
                    kind = "hx"
                else:
                    kind = "dangling"
                return edges, next_node, kind

            prev = current
            current = next_node
            others = [n for n in adj[current] if n != prev]
            if not others:
                return edges, None, "none"
            next_node = others[0]

    # =======================================================================
    # Build branches
    # =======================================================================
    branches: dict[str, Branch] = {}
    branch_counter = 0

    # --- 1. Radiator loop branches ---
    visited_radiators: set[str] = set()

    for rad_node in sorted(radiator_at.keys()):
        rad_keys = radiator_at[rad_node]
        junction, path_from_rad = trace_to_junction(rad_node)

        if junction not in junctions:
            # Radiator is on a disconnected stub that never reaches a
            # real junction — skip it; it cannot carry flow.
            continue

        for rad_key in sorted(rad_keys):
            if rad_key in visited_radiators:
                continue
            visited_radiators.add(rad_key)

            components: list[str] = []

            # Outward leg: junction → radiator (supply)
            # path_from_rad goes rad→junction; reverse order & flip direction
            for fn, tn, pk in reversed(path_from_rad):
                components.append(label_edge("supply", tn, fn, pk))

            components.append(rad_key)

            # Return leg: radiator → junction (return)
            for fn, tn, pk in path_from_rad:
                components.append(label_edge("return", fn, tn, pk))

            key = f"loop_{branch_counter}"
            branch_counter += 1
            branches[key] = Branch(
                key=key,
                junctions=(f"supply {junction}", f"return {junction}"),
                components=components,
            )

    # --- 2. Backbone branches ---
    visited_backbone: set[tuple[str, str]] = set()
    hx_added: set[str] = set()

    for junction in sorted(junctions):
        for neighbor in adj[junction]:
            # Quick skip: if first neighbor is a radiator dead-end
            if neighbor in radiator_nodes and len(adj[neighbor]) == 1:
                continue

            canon = (min(junction, neighbor), max(junction, neighbor))
            if canon in visited_backbone:
                continue

            path_edges, end_node, end_type = trace_from_junction(
                junction, neighbor, visited_backbone
            )

            if not path_edges or end_node is None:
                continue

            if end_type == "radiator":
                # Radiator dead-end spur — already handled by radiator loops
                continue

            if end_type == "dangling":
                # Dangling pipe — not connected to anything useful; skip
                continue

            components: list[str] = []

            if end_type == "hx":
                # HX loop: junction →(return)→ HX →(supply)→ junction
                for fn, tn, pk in path_edges:
                    components.append(label_edge("return", fn, tn, pk))

                hx_comp = hx_component_for_node(end_node)
                if hx_comp not in hx_added:
                    components.append(hx_comp)
                    hx_added.add(hx_comp)

                # Supply leg: HX→junction; reversed & flipped
                for fn, tn, pk in reversed(path_edges):
                    components.append(label_edge("supply", tn, fn, pk))

                key = f"backbone_{branch_counter}"
                branch_counter += 1
                branches[key] = Branch(
                    key=key,
                    junctions=(f"return {junction}", f"supply {junction}"),
                    components=components,
                )

            elif end_type == "junction":
                # Junction-to-junction backbone edge
                # Normalize: j_near (closer to HX) first
                j_start, j_end = junction, end_node
                edges = path_edges

                if depth.get(j_start, 0) > depth.get(j_end, 0):
                    # We traced away-from-supply; flip to make supply first
                    edges = [(tn, fn, pk) for fn, tn, pk in reversed(edges)]
                    j_start, j_end = j_end, j_start

                # Supply branch: j_near:S → pipes:S → j_far:S
                supply_comps: list[str] = []
                for fn, tn, pk in edges:
                    supply_comps.append(label_edge("supply", fn, tn, pk))

                key_s = f"backbone_{branch_counter}"
                branch_counter += 1
                branches[key_s] = Branch(
                    key=key_s,
                    junctions=(f"supply {j_start}", f"supply {j_end}"),
                    components=supply_comps,
                )

                # Return branch: j_far:R → pipes:R → j_near:R
                return_comps: list[str] = []
                for fn, tn, pk in reversed(edges):
                    return_comps.append(label_edge("return", tn, fn, pk))

                key_r = f"backbone_{branch_counter}"
                branch_counter += 1
                branches[key_r] = Branch(
                    key=key_r,
                    junctions=(f"return {j_end}", f"return {j_start}"),
                    components=return_comps,
                )

    # --- 3. Ensure explicit HX presence for every HX key ---
    present_hx_keys = {
        hx_key_from_component(comp)
        for branch in branches.values()
        for comp in branch.components
        if is_hx_component(comp)
    }
    present_hx_keys.discard(None)

    for hx_key in sorted(pipenet.hxs):
        if hx_key in present_hx_keys:
            continue

        anchors = [
            node for node, keys in hx_at.items() if hx_key in keys and node in adj
        ]
        if not anchors:
            continue

        anchor = min(
            anchors,
            key=lambda node: (0 if node in junctions else 1, len(adj[node]), node),
        )

        hx_comp = f"{HX_COMPONENT_PREFIX}{hx_key}"
        supply_j = f"supply {anchor}"
        return_j = f"return {anchor}"
        matching_loop_keys = [
            bkey
            for bkey, branch in branches.items()
            if bkey.startswith("loop_")
            and set(branch.junctions) == {supply_j, return_j}
            and not any(is_hx_component(comp) for comp in branch.components)
        ]
        if len(matching_loop_keys) == 1:
            loop_key = matching_loop_keys[0]
            loop_branch = branches[loop_key]
            branches[loop_key] = Branch(
                key=loop_branch.key,
                junctions=(return_j, return_j),
                components=[*loop_branch.components, hx_comp],
            )
            present_hx_keys.add(hx_key)
            hx_added.add(hx_comp)
            continue

        junctions.add(anchor)

        key = f"hx_{branch_counter}"
        branch_counter += 1
        branches[key] = Branch(
            key=key,
            junctions=(f"return {anchor}", f"supply {anchor}"),
            components=[hx_comp],
        )
        present_hx_keys.add(hx_key)
        hx_added.add(hx_comp)

    # --- Typed junctions and lookup ---
    typed_junctions: set[str] = set()
    for j in sorted(junctions):
        typed_junctions.add(f"supply {j}")
        typed_junctions.add(f"return {j}")

    junction_branches: dict[str, list[str]] = {j: [] for j in typed_junctions}
    for branch_key, branch in branches.items():
        j1, j2 = branch.junctions
        if j1 in junction_branches:
            junction_branches[j1].append(branch_key)
        if j2 != j1 and j2 in junction_branches:
            junction_branches[j2].append(branch_key)

    return FlowGraph(
        junctions=typed_junctions,
        branches=branches,
        junction_branches=junction_branches,
        num_supply_pipes=supply_count,
        num_return_pipes=return_count,
        component_nodes=component_nodes,
        pruned_pipes=pruned_pipes,
    )


# ---------------------------------------------------------------------------
# Calculation result (placeholder)
# ---------------------------------------------------------------------------


@dataclass
class PipeNetworkResult:
    """Derived/calculated values for a pipe network (not persisted)."""

    node_pressures: dict[str, int]
    pipe_flows: dict[str, float]
    pump_flows: dict[str, float]
    radiator_flows: dict[str, float]


def calculate_pipes(proj: Project) -> PipeNetworkResult | None:
    """Calculate pipe network flows and pressures."""
    if not proj.pipenet or not proj.pipenet.pipes:
        return None

    from jacloud.instantiate import instantiate_pipenet
    from jacloud.pipenet_cycles import solve_flows
    from jacloud.pipenet_resistance import compute_branch_resistance

    calc_pn = instantiate_pipenet(proj)
    graph = build_flow_graph(calc_pn)

    # Precompute resistance before solver runs
    branch_keys = sorted(graph.branches.keys(), key=lambda k: k.startswith("loop_"))
    resistance, exponent = compute_branch_resistance(
        graph, calc_pn, proj.valve, branch_keys, valvebal=proj.valvebal
    )

    arrays, cm = solve_flows(graph, resistance, exponent)

    # Extract per-branch flows into result dicts
    pipe_flows: dict[str, float] = {}
    radiator_flows: dict[str, float] = {}
    pump_flows: dict[str, float] = {}

    for bkey in cm.branch_keys:
        branch = graph.branches.get(bkey)
        if branch is None:
            continue
        idx = cm.branch_index[bkey]
        flow = float(arrays.flows[idx])
        for comp in branch.components:
            if is_hx_component(comp):
                pump_flows[comp] = flow
            elif comp.startswith(("supply ", "return ")):
                pipe_flows[comp] = flow
            elif comp.startswith("rad:"):
                radiator_flows[comp] = flow

    return PipeNetworkResult(
        node_pressures={},  # TODO: compute from flows
        pipe_flows=pipe_flows,
        pump_flows=pump_flows,
        radiator_flows=radiator_flows,
    )
