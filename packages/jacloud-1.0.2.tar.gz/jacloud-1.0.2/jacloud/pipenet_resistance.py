"""Resistance calculation for pipe network branches.

Converts FlowGraph component keys + PipeNet data into a resistance array
(one value per branch) suitable for the Hardy-Cross solver.

Resistance model:
    dp = k * Q * |Q|      (Pa, with Q in l/s)

Component resistances:
- Pipe segment:  k = (dp_r / flow_r²) * length_m
  where dp_r (Pa/m) and flow_r (l/s) come from the pipe type table.
  Length is the 3D distance between the pipe's route nodes.
  Each "supply pipekey" or "return pipekey" is one physical pipe segment.

- Radiator valve:  k = 1e5 * 3.6² / kv²
  Converts Kv (m³/h per √bar) to the dp = k*Q*|Q| form.
  Uses the project's default valve type with middle preset.

- Inline valve (BalancingValve):  same Kv formula using valve's preset/max Kv.
  Uses the valve's locked preset if set, otherwise the maximum preset (last
  in list).  Resistance is added to the return pipe segment where the valve
  sits.

- HX:  k = 0 (pump has no flow resistance in this model).

- Radiator body:  k = 0 (pressure drop is in the valve, not the panel).

Branch resistance is the sum of component resistances (series).
"""

import math
from typing import TYPE_CHECKING

import numpy as np

from jacloud.pipenet import is_hx_component
from jacloud.project import strip_dn
from jacloud.sci.core import g as gravity
from jacloud.sci.pipetable import Material, pipetypes
from jacloud.sci.tables.bvalve import bvalves, resolve_valve_key
from jacloud.sci.water import density as water_density

if TYPE_CHECKING:
    from jacloud.pipenet import FlowGraph
    from jacloud.project import BalancingValve, Pipe, PipeEvent, PipeNet

# Minimum effective pipe length (meters) to avoid zero resistance from
# coincident nodes or very short pipe segments. Equivalent to ~10cm of pipe.
MIN_PIPE_LENGTH_M: float = 0.1

# Minimum branch resistance to ensure numerical stability. This is a very
# small value that prevents division-by-zero without affecting real flows.
# Equivalent to a very short, large-diameter pipe segment.
MIN_BRANCH_RESISTANCE: float = 1e-6

# ---------------------------------------------------------------------------
# Valve Kv table (from radvalve.ts, duplicated here for backend use)
# ---------------------------------------------------------------------------

# {model: {preset_label: kv}} — ordered by preset from lowest to highest flow
RADVALVE: dict[str, dict[str, float]] = {
    "RA-N10": {
        "1.0": 0.04,
        "1.5": 0.054,
        "2.0": 0.076,
        "2.5": 0.094,
        "3.0": 0.115,
        "3.5": 0.144,
        "4.0": 0.184,
        "4.5": 0.22,
        "5.0": 0.26,
        "5.5": 0.29,
        "6.0": 0.32,
        "6.5": 0.34,
        "7.0": 0.36,
        "N": 0.54,
    },
    "RA-N15": {
        "1.0": 0.04,
        "1.5": 0.054,
        "2.0": 0.076,
        "2.5": 0.094,
        "3.0": 0.115,
        "3.5": 0.148,
        "4.0": 0.191,
        "4.5": 0.24,
        "5.0": 0.29,
        "5.5": 0.34,
        "6.0": 0.4,
        "6.5": 0.43,
        "7.0": 0.47,
        "N": 0.72,
    },
    "RA-N20": {
        "1.0": 0.094,
        "1.5": 0.119,
        "2.0": 0.148,
        "2.5": 0.155,
        "3.0": 0.166,
        "3.5": 0.21,
        "4.0": 0.25,
        "4.5": 0.3,
        "5.0": 0.34,
        "5.5": 0.36,
        "6.0": 0.4,
        "6.5": 0.54,
        "7.0": 0.72,
        "N": 0.97,
    },
}


def kv_to_k(kv: float) -> float:
    """Convert valve Kv (m³/h @ 1 bar) to resistance k (Pa·s²/l²).

    Kv definition:  Q_m3h = Kv * sqrt(dp_bar)
    So:  dp_bar = (Q_m3h / Kv)²
         dp_Pa  = 1e5 * (3.6 * Q_lps / Kv)²
         dp_Pa  = (1e5 * 3.6² / Kv²) * Q_lps²

    Since dp = k * Q * |Q| and Q*|Q| = Q² for positive Q:
        k = 1e5 * 12.96 / Kv²
    """
    if kv <= 0:
        return 0.0
    return 1e5 * 12.96 / (kv * kv)


def preset_kv(valve_model: str, preset: str) -> float:
    """Get Kv for a valve model at a specific preset."""
    presets = RADVALVE.get(valve_model)
    if not presets:
        return 0.0
    return presets.get(preset, 0.0)


def middle_kv(valve_model: str) -> float:
    """Get the middle preset Kv for a valve model."""
    presets = RADVALVE.get(valve_model)
    if not presets:
        return 0.0
    kvs = list(presets.values())
    return kvs[len(kvs) // 2]


# ---------------------------------------------------------------------------
# Balancing valve Kv resolution
# ---------------------------------------------------------------------------


def _resolve_bvalve_kv(valve: BalancingValve, valvebal: str) -> float:
    """Resolve a balancing valve's effective Kv (m³/h @ 1 bar).

    Resolution order for the valve model key:
    1. ``valve.kind`` if set (explicit model override)
    2. ``resolve_valve_key(valvebal, valve.dn)`` using the project group

    Preset selection:
    - If ``valve.preset`` is set (locked), use that preset's Kv.
    - Otherwise use the maximum preset (last entry in the ordered dict).

    Returns 0.0 if the valve model or preset cannot be resolved.
    """
    # Resolve valve model key in bvalves
    valve_key = valve.kind or resolve_valve_key(valvebal, valve.dn)

    if not valve_key:
        return 0.0

    presets = bvalves.get(valve_key)
    if not presets:
        return 0.0

    if valve.preset is not None and valve.preset in presets:
        return presets[valve.preset]

    # Use maximum preset (last value in ordered dict)
    kvs = list(presets.values())
    return kvs[-1] if kvs else 0.0


def build_balancing_valve_k_map(pipenet: PipeNet, valvebal: str) -> dict[str, float]:
    """Build a map of return-pipe component keys to balancing valve resistance.

    Iterates every pipe's timeline, finds valve events, resolves their Kv,
    and maps the corresponding ``"return pipe_key:seg_idx"`` component key
    to the valve resistance ``k`` (via :func:`kv_to_k`).

    Multiple valves on the same return segment are summed (series).

    Returns:
        ``{"return pipe_key:seg_idx": k_total, ...}``
    """
    valve_k_map: dict[str, float] = {}

    for pipe_key, pipe in pipenet.pipes.items():
        for _tl_key, ev, seg_idx in _iter_valve_events(pipe):
            valve = pipenet.valves.get(ev.valve)  # type: ignore[arg-type]
            if valve is None:
                continue
            kv = _resolve_bvalve_kv(valve, valvebal)
            if kv > 0:
                comp_key = f"return {pipe_key}:{seg_idx}"
                valve_k_map[comp_key] = valve_k_map.get(comp_key, 0.0) + kv_to_k(kv)

    return valve_k_map


def build_valve_info_map(
    pipenet: PipeNet, valvebal: str
) -> dict[str, dict[str, object]]:
    """Build per-valve info for calc result output.

    Returns ``{valve_id: {"valve_key": ..., "preset": ..., "kv": ..., "k": ..., "comp_key": ...}}``
    where *comp_key* is the return-pipe component key (e.g. ``"return pipe:0"``)
    that carries the valve resistance.
    """
    info_map: dict[str, dict[str, object]] = {}

    for pipe_key, pipe in pipenet.pipes.items():
        for _tl_key, ev, seg_idx in _iter_valve_events(pipe):
            valve_id = ev.valve
            if valve_id is None:
                continue
            valve = pipenet.valves.get(valve_id)
            if valve is None:
                continue

            valve_key = valve.kind or resolve_valve_key(valvebal, valve.dn)
            presets = bvalves.get(valve_key) if valve_key else None

            if valve.preset is not None and presets and valve.preset in presets:
                preset = valve.preset
                kv = presets[valve.preset]
            elif presets:
                # Max preset (last in ordered dict)
                preset_items = list(presets.items())
                preset = preset_items[-1][0]
                kv = preset_items[-1][1]
            else:
                preset = ""
                kv = 0.0

            info_map[valve_id] = {
                "valve_key": valve_key or "",
                "preset": preset,
                "kv": round(kv, 4),
                "k": round(kv_to_k(kv), 1) if kv > 0 else 0.0,
                "comp_key": f"return {pipe_key}:{seg_idx}",
            }

    return info_map


def _iter_valve_events(pipe: Pipe) -> list[tuple[int, PipeEvent, int]]:
    """Yield ``(timeline_key, event, segment_index)`` for valve events."""
    events = sorted(pipe.timeline.items())

    # Collect node positions: (timeline_key, route_index)
    node_positions: list[tuple[int, int]] = []
    route_idx = 0
    for tl_key, ev in events:
        if ev.node is not None:
            node_positions.append((tl_key, route_idx))
            route_idx += 1

    if len(node_positions) < 2:
        return []

    result: list[tuple[int, PipeEvent, int]] = []
    for tl_key, ev in events:
        if ev.valve is None:
            continue

        seg_idx = 0
        for i in range(len(node_positions) - 1):
            if node_positions[i][0] <= tl_key <= node_positions[i + 1][0]:
                seg_idx = node_positions[i][1]
                break

        result.append((tl_key, ev, seg_idx))

    return result


# ---------------------------------------------------------------------------
# Pipe segment resistance
# ---------------------------------------------------------------------------

# Material-specific flow exponents (from legacy pipe physics)
_PIPE_EXPONENT = {
    Material.PLASTIC: 1.8,
    Material.STEEL: 1.9,
    Material.COPPER: 1.9,
}


def _pipe_exponent(dn: str) -> float:
    """Flow exponent for a pipe DN based on material."""
    entry = pipetypes.get(strip_dn(dn))
    if not entry:
        return 2.0
    _dp_r, _flow_r, _diam, material = entry
    return _PIPE_EXPONENT.get(material, 2.0)


def _pipe_resistance_per_meter(dn: str) -> tuple[float, float]:
    """Resistance coefficient k per meter and exponent for a pipe DN.

    Strips the ``" Ins"`` insulation suffix before lookup.

    For dp = k * Q^n:  k_per_m = dp_r / flow_r^n

    Returns (k_per_m, n).
    """
    entry = pipetypes.get(strip_dn(dn))
    if not entry:
        return 0.0, 2.0
    dp_r, flow_r, _diam, material = entry
    if flow_r <= 0:
        return 0.0, 2.0
    n = _PIPE_EXPONENT.get(material, 2.0)
    return dp_r / (flow_r**n), n


def _pipe_k(
    comp_key: str,
    pipenet: PipeNet,
) -> tuple[float, float]:
    """Resistance k and exponent n for a pipe.

    *comp_key* is either a plain pipe UUID (uses the whole pipe) or
    ``"pipe_key:N"`` where *N* is a zero-based segment index (uses only
    that segment of a multi-node pipe).

    After instantiation, node ``h`` values are absolute, so no floor
    height lookup is needed.

    Returns (k, n) where n is a resistance-weighted average exponent.
    """
    seg_idx: int | None = None
    pipe_key = comp_key
    colon = comp_key.rfind(":")
    if colon >= 0:
        tail = comp_key[colon + 1 :]
        if tail.isdigit():
            pipe_key = comp_key[:colon]
            seg_idx = int(tail)

    pipe = pipenet.pipes.get(pipe_key)
    if not pipe:
        return 0.0, 2.0

    dn_list = pipe.dn_keys()  # sorted (timeline_key, dn)
    if not dn_list:
        return 0.0, 2.0

    route = pipe.route()
    node_tl_keys = pipe.node_keys()  # sorted (timeline_key, node_id)

    total_k = 0.0
    weighted_n = 0.0
    for i in range(len(route) - 1):
        if seg_idx is not None and i != seg_idx:
            continue
        n1 = pipenet.nodes.get(route[i])
        n2 = pipenet.nodes.get(route[i + 1])
        if not n1 or not n2:
            continue
        dx = n2.x - n1.x
        dy = n2.y - n1.y
        dh = n2.z - n1.z
        seg_len_mm = math.sqrt(dx * dx + dy * dy + dh * dh)
        seg_len_m = seg_len_mm / 1000.0

        # Find applicable dn: largest dn timeline key ≤ this node's timeline key
        node_key = node_tl_keys[i][0]
        section_dn = ""
        for dk, dn_val in dn_list:
            if dk <= node_key:
                section_dn = dn_val
            else:
                break
        if not section_dn:
            section_dn = dn_list[0][1]

        k_per_m, n = _pipe_resistance_per_meter(section_dn)
        seg_k = k_per_m * seg_len_m
        total_k += seg_k
        weighted_n += seg_k * n

    # Ensure minimum effective length for numerical stability
    if total_k == 0.0:
        first_dn = dn_list[0][1]
        k_per_m, n = _pipe_resistance_per_meter(first_dn)
        return max(k_per_m * MIN_PIPE_LENGTH_M, MIN_PIPE_LENGTH_M * 1e-3), n

    avg_n = weighted_n / total_k if total_k > 0 else 2.0
    return max(total_k, MIN_PIPE_LENGTH_M * 1e-3), avg_n


# ---------------------------------------------------------------------------
# Component → resistance
# ---------------------------------------------------------------------------


def component_k(
    comp: str,
    pipenet: PipeNet,
    default_rad_k: float,
    radiator_k_map: dict[str, float] | None = None,
    balancing_k_map: dict[str, float] | None = None,
) -> tuple[float, float]:
    """Resistance k and exponent n for a single component key.

    comp formats:
    - "supply pipekey" / "return pipekey" → pipe segment resistance
    - "rad:..." → radiator valve resistance
    - "HX" → 0 (pump, no resistance)

    After instantiation, node heights are absolute so no floor_heights
    parameter is needed.

    Returns (k, n).
    """
    if is_hx_component(comp):
        return 0.0, 2.0

    if comp.startswith(("supply ", "return ")):
        comp_key = comp.split(" ", 1)[1]
        k, n = _pipe_k(comp_key, pipenet)
        # Add balancing valve resistance on return pipes
        if balancing_k_map and comp in balancing_k_map:
            valve_k = balancing_k_map[comp]
            # Weighted-average exponent: valve uses n=2.0
            total_k = k + valve_k
            if total_k > 0:
                n = (k * n + valve_k * 2.0) / total_k
            k = total_k
        return k, n

    if comp.startswith("rad:"):
        if radiator_k_map and comp in radiator_k_map:
            return radiator_k_map[comp], 2.0
        return default_rad_k, 2.0

    return 0.0, 2.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compute_branch_resistance(
    graph: FlowGraph,
    pipenet: PipeNet,
    valve_model: str,
    branch_keys: list[str],
    preset: str = "2.0",
    radiator_k_map: dict[str, float] | None = None,
    valvebal: str = "",
) -> tuple[np.ndarray, np.ndarray]:
    """Compute resistance and exponent arrays for all branches.

    After instantiation, node heights are absolute.

    Args:
        graph: FlowGraph with typed branches.
        pipenet: CalcPipeNet (or PipeNet) with pipe/node/radiator data.
        valve_model: Radiator valve model (e.g. "RA-N10").
        branch_keys: Ordered branch keys matching solver column order.
        preset: Radiator valve preset value (default "2.0").
        radiator_k_map: Optional per-radiator resistance overrides
            (radiator component key → k value), built from room
            calculations.  Radiators not in the map use the default
            ``valve_model``/``preset`` value.
        valvebal: Balancing valve group name (e.g. ``"Stad/Staf"``).
            Used to resolve balancing valve Kv on return pipes.

    Returns:
        (resistance[num_branches], exponent[num_branches])
        resistance: k values for dp = k * |Q|^n
        exponent: n values (1.8-1.9 for pipes, 2.0 for valves)
    """
    rad_kv = preset_kv(valve_model, preset)
    if rad_kv <= 0:
        rad_kv = middle_kv(valve_model)  # fallback
    rad_k = kv_to_k(rad_kv)

    # Build balancing valve resistance map (return pipes only)
    balancing_k_map = build_balancing_valve_k_map(pipenet, valvebal) if valvebal else {}

    nb = len(branch_keys)
    resistance = np.zeros(nb, dtype=np.float64)
    exponent = np.full(nb, 2.0, dtype=np.float64)

    for i, bkey in enumerate(branch_keys):
        branch = graph.branches[bkey]
        total_k = 0.0
        weighted_n = 0.0
        for comp in branch.components:
            k, n = component_k(comp, pipenet, rad_k, radiator_k_map, balancing_k_map)
            total_k += k
            weighted_n += k * n
        # Ensure minimum resistance for numerical stability
        resistance[i] = max(total_k, MIN_BRANCH_RESISTANCE)
        exponent[i] = weighted_n / total_k if total_k > 0 else 2.0

    return resistance, exponent


# ---------------------------------------------------------------------------
# Hydrostatic head
# ---------------------------------------------------------------------------


def _node_absolute_height_m(
    node_key: str,
    pipenet: PipeNet,
) -> float:
    """Absolute height of a node in metres.

    After instantiation, node ``z`` is the absolute world height.
    """
    node = pipenet.nodes.get(node_key)
    if node is not None:
        return node.z / 1000.0  # mm → m
    return 0.0


def compute_branch_hydrostatic_head(
    graph: FlowGraph,
    pipenet: PipeNet,
    branch_keys: list[str],
    t_supply: float,
    t_return: float = 40.0,
    component_supply_temp: dict[str, float] | None = None,
) -> np.ndarray:
    """Compute per-branch hydrostatic head pressure (Pa).

    After instantiation, node heights are absolute.
    """
    rho_return = water_density(t_return)
    component_supply_temp = component_supply_temp or {}

    nb = len(branch_keys)
    head = np.zeros(nb, dtype=np.float64)

    for i, bkey in enumerate(branch_keys):
        branch = graph.branches[bkey]
        total_head = 0.0
        for comp in branch.components:
            nodes = graph.component_nodes.get(comp)
            if nodes is None:
                continue  # non-pipe component (radiator, HX)
            from_node, to_node = nodes
            h_start = _node_absolute_height_m(from_node, pipenet)
            h_end = _node_absolute_height_m(to_node, pipenet)
            dh = h_end - h_start  # positive = uphill in traversal dir
            if comp.startswith("supply "):
                rho = water_density(component_supply_temp.get(comp, t_supply))
            else:
                rho = rho_return
            # Uphill → negative head (opposes flow); downhill → positive
            total_head += -rho * gravity * dh
        head[i] = total_head

    return head
