import logging

from uvicorn.logging import DefaultFormatter

UVICORN_FORMAT = "%(levelprefix)s %(message)s"


def setup_logger(name: str) -> logging.Logger:
    """
    Return a logger configured with Uvicorn's DefaultFormatter.
    Does not manage levels, colors, or environment variables.
    """
    logger = logging.getLogger(name)
    # Don't reset levels or clear existing handlers except avoid duplicates.
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(DefaultFormatter())
        logger.addHandler(handler)
    # Avoid double logging if parent/root also has handlers.
    logger.propagate = False
    return logger


# Pre-configured module-level logger
logger = setup_logger("jacloud")

__all__ = ["logger", "setup_logger"]
