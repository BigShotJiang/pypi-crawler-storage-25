"""One-time migration: convert old JSONL format to new ChangeRecord/Snapshot format.

Old format records use {"patch": ..., "mtime": ..., "actor": ..., "migration": ...}
New format records use ChangeRecord(ts=, a=, v=, u=, diff=) and Snapshot(ts=, v=, state=).

Run as:  python -m jacloud.migrate_format [data_dir]

Processes all .jsonl and .jsonl.deleted files under data_dir/projects/ (default: ./data).
Renames the entire projects/ folder to projects.{date}/ as backup, then writes a fresh
projects/ folder with new-format data preserving original file mtimes.

Delete this module once all instances have been migrated.
"""

import copy
import os
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import jsondiff
import msgspec
import msgspec.json

from .dbformat import SNAPSHOT_PREFIX, ChangeRecord, Snapshot
from .migrations import DBVER, MigrationCtx, _migrations


def _is_old_format(data: bytes) -> bool:
    """Check if file data uses the old record format (patch/mtime keys)."""
    for raw in data.split(b"\n"):
        line = raw.strip()
        if not line or line.startswith(SNAPSHOT_PREFIX):
            continue
        try:
            rec = msgspec.json.decode(line)
        except Exception as e:
            raise ValueError(f"Invalid JSON line in data: {line}") from e
        if isinstance(rec, dict):
            return "patch" in rec
    return False


def _apply_schema_migrations(
    data: bytes, filename: str = "<unknown>", project_id: str | None = None
) -> bytes | None:
    """Apply schema migrations to an already new-format file.

    Replays the log to build state, applies pending migrations, and appends
    ChangeRecords + a new snapshot. Returns None if no migrations were needed.
    """
    if not data.strip():
        return None

    lines = data.split(b"\n")
    state: dict = {}
    current_v: int = 0
    last_ts = datetime(1970, 1, 1, tzinfo=UTC)
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith(SNAPSHOT_PREFIX):
            snap = msgspec.json.decode(line[len(SNAPSHOT_PREFIX) :], type=Snapshot)
            state = snap.state
            current_v = snap.v
            last_ts = snap.ts
        else:
            change = msgspec.json.decode(line, type=ChangeRecord)
            state = jsondiff.patch(state, change.diff, marshal=True)
            current_v = change.v
            last_ts = change.ts

    if current_v >= DBVER:
        return None  # Already up to date

    # Apply pending migrations
    ctx = MigrationCtx(project_id=project_id)
    extra_lines: list[bytes] = []
    while current_v < DBVER:
        pre = copy.deepcopy(state)
        _migrations[current_v](state, ctx)
        current_v += 1
        diff = jsondiff.diff(pre, state, marshal=True)
        if diff:
            rec = ChangeRecord(
                ts=last_ts,
                a=f"migrate:v{current_v}",
                v=current_v,
                diff=diff,
            )
            extra_lines.append(msgspec.json.encode(rec))
            print(f"    {filename}: schema migrate v{current_v - 1}→v{current_v}")

    if not extra_lines:
        return None

    # Append migration records and a new snapshot
    snap = Snapshot(ts=last_ts, v=current_v, state=state)
    extra_lines.append(SNAPSHOT_PREFIX + msgspec.json.encode(snap))
    # Append to existing data (strip trailing newline to avoid double)
    return data.rstrip(b"\n") + b"\n" + b"\n".join(extra_lines) + b"\n"


def _convert_data(
    data: bytes, filename: str = "<unknown>", project_id: str | None = None
) -> bytes | None:
    """Convert old-format file bytes to new format. Returns None if already new or empty.

    Raises on any conversion error with diagnostics (filename, line number, record).
    """
    if not data.strip():
        return None
    if not _is_old_format(data):
        return None

    new_lines: list[bytes] = []
    last_ts = datetime(1970, 1, 1, tzinfo=UTC)
    lines = data.split(b"\n")
    for _lineno, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            continue

        if line.startswith(SNAPSHOT_PREFIX):
            snap_json = line[len(SNAPSHOT_PREFIX) :]
            old_snap = msgspec.json.decode(snap_json)
            mtime = old_snap.get("mtime", 0)
            ts = (
                datetime.fromtimestamp(mtime, tz=UTC)
                if mtime
                else datetime(1970, 1, 1, tzinfo=UTC)
            )
            new_snap = Snapshot(ts=ts, v=0, state=old_snap["state"])
            new_lines.append(SNAPSHOT_PREFIX + msgspec.json.encode(new_snap))
            last_ts = ts
        else:
            old_rec = msgspec.json.decode(line)
            if not isinstance(old_rec, dict):
                continue

            mtime = old_rec.get("mtime", 0)
            if mtime:
                ts = datetime.fromtimestamp(mtime, tz=UTC)
            else:
                patch = old_rec.get("patch", {})
                modified = patch.get("modified")
                if not modified:
                    replace = patch.get("$replace")
                    if isinstance(replace, dict):
                        modified = replace.get("modified")
                if isinstance(modified, (int, float)) and modified > 0:
                    ts = datetime.fromtimestamp(modified, tz=UTC)
                else:
                    ts = last_ts  # Use last known timestamp

            actor = old_rec.get("actor")
            is_migration = old_rec.get("migration", False)
            patch = old_rec.get("patch", {})

            if is_migration:
                a = f"migrate:{actor}" if actor else "migrate:old"
                u = None
            else:
                a = ""
                u = actor

            new_rec = ChangeRecord(
                ts=ts,
                a=a,
                u=u,
                diff=patch,
            )
            new_lines.append(msgspec.json.encode(new_rec))
            last_ts = ts

    # Replay, validate, migrate, and add final snapshot
    if new_lines:
        _replay_and_finalize(new_lines, last_ts, filename, project_id)

    return b"\n".join(new_lines) + b"\n"


def _replay_and_finalize(
    new_lines: list[bytes],
    last_ts: datetime,
    filename: str,
    project_id: str | None,
) -> None:
    """Replay converted lines, apply schema migrations, append final snapshot.

    Mutates new_lines in place by appending migration records and a snapshot.
    """
    state: dict = {}
    for i, line in enumerate(new_lines):
        if line.startswith(SNAPSHOT_PREFIX):
            snap_json = line[len(SNAPSHOT_PREFIX) :]
            snap = msgspec.json.decode(snap_json, type=Snapshot)
            state = snap.state
        else:
            change = msgspec.json.decode(line, type=ChangeRecord)
            try:
                state = jsondiff.patch(state, change.diff, marshal=True)
            except (KeyError, TypeError, IndexError) as e:
                raise ValueError(
                    f"{filename}: replay failed at converted line {i + 1}: "
                    f"{type(e).__name__}: {e}\n"
                    f"  diff: {line.decode(errors='replace')[:500]}"
                ) from e

    # Apply schema migrations, emitting a ChangeRecord per version step
    ctx = MigrationCtx(project_id=project_id)
    current_v = state.get("v", 0)
    while current_v < DBVER:
        pre = copy.deepcopy(state)
        _migrations[current_v](state, ctx)
        current_v += 1
        diff = jsondiff.diff(pre, state, marshal=True)
        if diff:
            rec = ChangeRecord(
                ts=last_ts,
                a=f"migrate:v{current_v}",
                v=current_v,
                diff=diff,
            )
            new_lines.append(msgspec.json.encode(rec))
            print(f"    {filename}: schema migrate v{current_v - 1}→v{current_v}")

    # Add final snapshot
    final_snap = Snapshot(ts=last_ts, v=current_v, state=state)
    try:
        encoded = msgspec.json.encode(final_snap)
    except TypeError as e:
        # Find problematic keys for diagnostics
        def find_bad_keys(d, path=""):
            if isinstance(d, dict):
                for k, v in d.items():
                    if not isinstance(k, str):
                        yield f"{path}[{k!r}] (type={type(k).__name__})"
                    yield from find_bad_keys(v, f"{path}.{k}" if path else str(k))
            elif isinstance(d, list):
                for j, v in enumerate(d):
                    yield from find_bad_keys(v, f"{path}[{j}]")

        bad = list(find_bad_keys(state))
        raise ValueError(
            f"{filename}: final snapshot encoding failed: {e}\n"
            f"  Non-string keys found: {bad[:20]}"
        ) from e
    new_lines.append(SNAPSHOT_PREFIX + encoded)


@dataclass
class ConvertedFile:
    """A file ready to be written in new format."""

    rel: Path  # path relative to projects_dir
    new_data: bytes  # converted content
    mtime_ns: int  # original st_mtime_ns


def main() -> None:
    data_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd() / "data"
    projects_dir = data_dir / "projects"

    if not projects_dir.is_dir():
        print(f"Projects directory not found: {projects_dir}", file=sys.stderr)
        sys.exit(1)

    # --- Phase 1: read and convert everything in RAM ---
    print(f"Reading all JSONL files in {projects_dir} ...")
    converted: list[ConvertedFile] = []
    # Collect all files that should be preserved as-is (already new format)
    passthrough: list[tuple[Path, bytes, int]] = []  # (rel, data, mtime_ns)

    jsonl_files = sorted(projects_dir.rglob("*.jsonl")) + sorted(
        projects_dir.rglob("*.jsonl.deleted")
    )

    if not jsonl_files:
        print("No JSONL files found.")
        return

    for path in jsonl_files:
        if not path.is_file():
            continue
        rel = path.relative_to(projects_dir)
        data = path.read_bytes()
        stat = path.stat()
        mtime_ns = stat.st_mtime_ns

        # Extract project_id from filename (e.g. "org/proj.jsonl" -> "proj")
        pid = path.stem.removesuffix(".deleted").removesuffix(".jsonl")

        new_data = _convert_data(data, filename=str(rel), project_id=pid)
        if new_data is not None:
            converted.append(
                ConvertedFile(rel=rel, new_data=new_data, mtime_ns=mtime_ns)
            )
            print(f"  convert: {rel}")
        else:
            # Already new format — check if schema migrations are needed
            migrated = _apply_schema_migrations(data, filename=str(rel), project_id=pid)
            if migrated is not None:
                converted.append(
                    ConvertedFile(rel=rel, new_data=migrated, mtime_ns=mtime_ns)
                )
                print(f"  schema:  {rel}")
            else:
                passthrough.append((rel, data, mtime_ns))
                print(f"  keep:    {rel}")

    if not converted:
        print("All files already current (no format or schema migrations needed).")
        return

    print(f"\n{len(converted)} file(s) to migrate, {len(passthrough)} already current.")

    # --- Phase 2: atomic swap - rename old folder, write new one ---
    _atomic_swap(data_dir, projects_dir, converted, passthrough)


def _atomic_swap(
    data_dir: Path,
    projects_dir: Path,
    converted: list[ConvertedFile],
    passthrough: list[tuple[Path, bytes, int]],
) -> None:
    """Rename old projects dir to backup, write converted + passthrough files."""
    backup_dir = data_dir / f"projects.{datetime.now(tz=UTC).isoformat()}"
    if backup_dir.exists():
        print(f"Backup directory already exists: {backup_dir}", file=sys.stderr)
        print("Remove or rename it before running migration again.", file=sys.stderr)
        sys.exit(1)

    print(f"Renaming {projects_dir} → {backup_dir} ...")
    projects_dir.rename(backup_dir)

    print(f"Writing new {projects_dir} ...")
    projects_dir.mkdir(parents=True)

    for cf in converted:
        out = projects_dir / cf.rel
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(cf.new_data)
        os.utime(out, ns=(cf.mtime_ns, cf.mtime_ns))

    for rel, data, mtime_ns in passthrough:
        out = projects_dir / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        os.utime(out, ns=(mtime_ns, mtime_ns))

    print(f"Done. Migrated {len(converted)} file(s). Old data in {backup_dir}/")


if __name__ == "__main__":
    main()
