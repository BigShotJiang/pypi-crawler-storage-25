import copy
import logging
import re
import shutil
import time
from collections import Counter
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import jsondiff
import msgspec
import msgspec.json
from fastapi import FastAPI, WebSocket, WebSocketDisconnect

# Import to trigger self-registration of pipenet compute function
from . import calcpipenet as _calcpipenet  # noqa: F401
from ._version import __version__
from .calcrunner import CalcResult, calc_runner
from .dbformat import SNAPSHOT_PREFIX, ChangeRecord, Snapshot
from .fastapi_logging import format_client_ip, log_ws_close, log_ws_open
from .migrations import DBVER, MigrationCtx, apply_migrations
from .project import Project
from .sync_logging import log_sync_change
from .util import compact_user_agent

logger = logging.getLogger(__name__)

# In-memory canonical state per (org_id, project_id)


class _ProjectEntry(msgspec.Struct):
    project: Project
    m: datetime | None = None


PROJECTS: dict[tuple[str, str], _ProjectEntry] = {}

PUBLIC_ORG_ID = "Public"

# Snapshot heuristics: create a snapshot if at least this many seconds have passed
# since the last patch mtime, and there have been patches since the last snapshot.
SNAPSHOT_STALE_THRESHOLD = 3600  # 1 hour since last patch mtime


@dataclass
class Client:
    id: int
    ws: WebSocket
    org_id: str
    pids: set[tuple[str, str]]
    # Optional user context forwarded by upstream auth proxy
    user: dict[str, str] | None = None


CLIENTS: dict[int, Client] = {}

# Cached calculation results per (org_id, project_id).
# Populated by _deliver_calc_result, sent to clients on get_project.
CALC_RESULTS: dict[tuple[str, str], dict[str, Any]] = {}


def _total_project_count() -> int:
    return len(PROJECTS)


def _clean_org_name(value: Any) -> str | None:
    if isinstance(value, str):
        cleaned = value.strip()
        if cleaned:
            return cleaned
    return None


def _strip_project_metadata(project_b: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of project builtins without server-managed metadata.

    Fields like org_id and org_name are managed by the server and must not
    be part of the sync'd project state sent to clients.
    """
    out = dict(project_b)
    out.pop("org_id", None)
    out.pop("org_name", None)
    return out


def _finalize_project_metadata(
    candidate: dict[str, Any], *, org_id: str, org_name_candidates: list[Any]
) -> tuple[Project, dict[str, Any], str | None]:
    data = dict(candidate)
    data["org_id"] = org_id
    resolved: str | None = None
    for source in org_name_candidates:
        resolved = _clean_org_name(source)
        if resolved:
            break
    if not resolved and isinstance(org_id, str) and org_id:
        resolved = org_id
    data["org_name"] = resolved
    project = msgspec.convert(data, type=Project, strict=False)
    return project, data, resolved


async def _deliver_calc_result(result: CalcResult) -> None:
    """Broadcast a completed calculation result to subscribed clients."""
    # Cache the result so new subscribers get it immediately
    CALC_RESULTS[(result.org_id, result.project_id)] = result.data
    await broadcast(
        result.org_id,
        result.project_id,
        {
            "type": "calc_result",
            "project_id": result.project_id,
            "result": result.data,
        },
    )


calc_runner.set_delivery(_deliver_calc_result)


@asynccontextmanager
async def _lifespan(_app: FastAPI):
    """Startup: replay persisted project patches to rebuild state."""
    try:
        _replay_all_projects()
        logger.info(
            "persistence: loaded %d projects from %s",
            _total_project_count(),
            PERSIST_DIR,
        )
    except Exception as exc:
        logger.error("persistence: failed to load projects: %r", exc)

    # Pre-compute pipenet results for all loaded projects so the cache
    # is warm when the first client connects.
    for (org_id, pid), entry in PROJECTS.items():
        await calc_runner.trigger(org_id, pid, entry.project)
    logger.info("calc: triggered startup calculations for %d projects", len(PROJECTS))

    yield


app = FastAPI(title="jacloud-sync", lifespan=_lifespan)

DATA_DIR: Path = Path.cwd() / "data"
PERSIST_DIR: Path = DATA_DIR / "projects"
SYMLINKS_DIR: Path = DATA_DIR / "by-name"


def _project_to_builtins(struct: Any) -> dict[str, Any]:
    """Convert a Project struct to a plain dict with JSON-compatible string keys.

    ``msgspec.to_builtins`` emits ``int`` keys for ``dict[int, …]`` fields
    (e.g. ``Pipe.timeline``), but JSON only has string keys.  jsondiff treats
    ``0`` and ``"0"`` as different keys, so mixing the two causes duplicates
    and ``$delete`` symbols to leak into the patched result.

    Using ``str_keys=True`` ensures all dict keys are coerced to strings,
    matching what the client and persisted patches use.
    """
    return msgspec.to_builtins(struct, str_keys=True)


def _sanitize_display_name(name: str) -> str:
    """Sanitize display name for use as filesystem path component."""
    if not name or not isinstance(name, str):
        return "Unnamed"
    # Replace problematic characters with underscores
    sanitized = re.sub(r"[<>:\"/\\|?*\x00-\x1f]", "_", name.strip())
    # Remove leading/trailing dots and spaces
    sanitized = sanitized.strip(". ")
    # Ensure it's not empty and not a reserved name
    if not sanitized or sanitized.upper() in {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        "COM1",
        "COM2",
        "COM3",
        "COM4",
        "COM5",
        "COM6",
        "COM7",
        "COM8",
        "COM9",
        "LPT1",
        "LPT2",
        "LPT3",
        "LPT4",
        "LPT5",
        "LPT6",
        "LPT7",
        "LPT8",
        "LPT9",
    }:
        sanitized = f"_{sanitized}_"
    return sanitized[:100]  # Limit length


def _remove_display_name_symlink(org_display: str, project_display: str) -> None:
    """Remove an existing project symlink under a sanitized org directory."""
    try:
        org_dir = SYMLINKS_DIR / org_display
        link = org_dir / f"{project_display}.jsonl"
        if link.is_symlink() or link.exists():
            link.unlink()
        if org_dir.exists():
            try:
                next(org_dir.iterdir())
            except StopIteration:
                org_dir.rmdir()
    except FileNotFoundError:
        return
    except Exception as exc:
        logger.debug(
            "Failed to remove display name symlink %s/%s: %r",
            org_display,
            project_display,
            exc,
        )


def _rebuild_symlink_tree() -> None:
    """Recreate the by-name symlink hierarchy from in-memory projects."""
    try:
        if SYMLINKS_DIR.exists():
            shutil.rmtree(SYMLINKS_DIR)
    except Exception as exc:
        logger.debug("Failed to clear by-name directory: %r", exc)
    for (org_id, project_id), entry in PROJECTS.items():
        try:
            _ensure_display_name_symlinks(
                org_id,
                project_id,
                getattr(entry.project, "org_name", None),
                getattr(entry.project, "name", None),
            )
        except Exception as exc:
            logger.debug(
                "Failed to rebuild symlink for %s/%s: %r",
                org_id,
                project_id,
                exc,
            )


def _ensure_display_name_symlinks(
    org_id: str,
    project_id: str,
    org_name: str | None = None,
    project_name: str | None = None,
) -> None:
    """Create or update symlinks for display name hierarchy."""
    try:
        SYMLINKS_DIR.mkdir(parents=True, exist_ok=True)

        # Prefer supplied display names but fall back to stable identifiers
        org_display_source = org_name or org_id
        proj_display_source = project_name or project_id
        org_display = _sanitize_display_name(org_display_source)
        proj_display = _sanitize_display_name(proj_display_source)

        # Create org directory (not symlink) if it doesn't exist
        org_dir = SYMLINKS_DIR / org_display
        org_dir.mkdir(parents=True, exist_ok=True)
        logger.debug("Ensured org directory: %s", org_dir)

        # Create project symlink within org directory
        proj_symlink = org_dir / f"{proj_display}.jsonl"
        proj_target = PERSIST_DIR / org_id / f"{project_id}.jsonl"

        if not proj_symlink.exists() and proj_target.exists():
            try:
                proj_symlink.symlink_to(proj_target)
                logger.debug(
                    "Created project symlink: %s -> %s", proj_symlink, proj_target
                )
            except OSError, FileExistsError:
                # Symlink might have been created by another process
                pass

    except Exception as exc:
        logger.debug(
            "Failed to create display name symlinks for %s/%s: %r",
            org_id,
            project_id,
            exc,
        )


@app.websocket("/sync")
async def ws_sync(websocket: WebSocket):
    await websocket.accept()
    ws_started = time.perf_counter()
    raw_user = _get_user_info(websocket)
    ua = _get_user_agent(websocket)
    org_id = raw_user.get("org_id") or PUBLIC_ORG_ID
    user_internal = dict(raw_user)
    user_internal["org_id"] = org_id
    if raw_user:
        ws_extra = "{} {} ({}) {} ({})".format(
            ua,
            user_internal["name"],
            user_internal["id"][-6:],
            user_internal["org_name"],
            org_id[-6:],
        )
    else:
        ws_extra = ua
    ws_log_id = log_ws_open(websocket, ws_extra)
    ws_closed_logged = False
    client_id = ws_log_id
    try:
        # Create new client session
        CLIENTS[client_id] = Client(client_id, websocket, org_id, set(), user_internal)
        user_public = {k: v for k, v in user_internal.items() if k != "org_id"}
        # Send initial hello including current project list; client is already registered for broadcasts.
        await websocket.send_json(
            {
                "type": "hello",
                "projects": _projects_snapshot(org_id),
                "user": user_public,
            }
        )
        while True:
            msg = await websocket.receive_json()
            if isinstance(msg, dict):
                await _handle_message(websocket, msg, client_id)
    except WebSocketDisconnect:
        log_ws_close(ws_log_id, 1000, time.perf_counter() - ws_started)
        ws_closed_logged = True
    except Exception as exc:
        logger.debug("[#%d] WebSocket exception: %r", client_id, exc)
    finally:
        if not ws_closed_logged:
            log_ws_close(ws_log_id, None, time.perf_counter() - ws_started)
        CLIENTS.pop(client_id, None)


def _validate_created_timestamp(created: Any) -> str | None:
    """Validate created timestamp (ISO datetime string). Returns error message or None if valid."""
    if created is None:
        return None
    if not isinstance(created, str):
        return f"invalid created type: {type(created).__name__}"
    if not created:
        return "invalid created timestamp: empty string"
    try:
        dt = datetime.fromisoformat(created)
        # Validate timestamp is within reasonable range (2025-2080)
        if dt.year < 2025 or dt.year > 2080:
            return f"created timestamp out of valid range (2025-2080): {created}"
    except ValueError:
        return f"invalid created timestamp format: {created}"
    return None


def _build_struct_and_validate(
    rebased_b: dict[str, Any],
    project_id: str,
) -> tuple[Project | None, dict[str, Any] | None, str | None]:
    """Convert rebased builtins to Project, compute derived values, and validate.

    Returns (new_struct, candidate_builtins, error_reason).
    If error_reason is not None, conversion/validation failed.

    Migrations are NOT applied here — they run only at startup during
    replay.  At runtime all data is already at DBVER.
    """
    # Validate minimal fields prior to conversion (no normalization)
    rb = dict(rebased_b) if isinstance(rebased_b, dict) else {}

    # Validate project ID format
    if (
        not isinstance(project_id, str)
        or not project_id
        or not _B64URL_RE.fullmatch(project_id)
    ):
        return None, None, f"invalid id {project_id!r}"

    # Validate created timestamp (immutable field)
    if error := _validate_created_timestamp(rb.get("created")):
        return None, None, error

    try:
        new_struct = msgspec.convert(rb, type=Project, strict=False)
    except Exception as exc:  # conversion failed
        # Dump the rejected data for debugging (use repr to handle non-JSON types like jsondiff Symbols)
        try:
            import pprint

            dump_name = f"syncerr-{project_id}-{int(time.time())}.txt"
            dump_path = DATA_DIR / dump_name if DATA_DIR else Path(dump_name)
            dump_path.write_text(pprint.pformat(rb, width=120))
            logger.warning(
                "sync conversion failed for %s, dumped to %s: %s",
                project_id,
                dump_path,
                exc,
            )
        except Exception as dump_exc:
            logger.warning(
                "sync conversion failed for %s (dump failed: %s): %s",
                project_id,
                dump_exc,
                exc,
            )
        return None, None, f"conversion failed: {exc!r}"
    candidate_b = _project_to_builtins(new_struct)
    is_valid, reason = _valid_project_minimal(
        project_id, {"name": candidate_b.get("name")}
    )
    if not is_valid:
        return None, None, reason or "invalid project fields"
    return new_struct, candidate_b, None


def _apply_valid_struct(
    current_struct: Project | None,
    current_b: dict[str, Any],
    new_struct: Project,
    candidate_b: dict[str, Any],
    ctx: _ApplyCtx,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Apply a validated struct to in-memory store.

    Created timestamp is immutable; raise if it changes.
    Returns (final_project_builtins, applied_patch)
    """
    # Validate immutable fields haven't changed
    if current_struct is not None and new_struct.created != current_struct.created:
        raise ValueError(
            f"immutable field 'created' changed: {current_struct.created} -> {new_struct.created}"
        )

    old_org_source = None
    if current_b:
        old_org_source = _clean_org_name(current_b.get("org_name")) or current_b.get(
            "org_id"
        )
    if not isinstance(old_org_source, str) or not old_org_source:
        old_org_source = ctx.org_id
    old_org_display = (
        _sanitize_display_name(str(old_org_source)) if old_org_source else None
    )
    old_proj_display = None
    if old_org_display:
        old_basis = current_b.get("name")
        if isinstance(old_basis, str) and old_basis:
            old_proj_display = _sanitize_display_name(old_basis)

    client = CLIENTS.get(ctx.client_id)
    org_name_sources = [
        ctx.websocket.headers.get("remote-org-name") if ctx.websocket else None,
        client.user.get("org_name") if client and client.user else None,
        candidate_b.get("org_name"),
        current_b.get("org_name"),
        current_b.get("org_id"),
        ctx.org_id,
    ]
    new_struct, candidate_b, org_name = _finalize_project_metadata(
        candidate_b, org_id=ctx.org_id, org_name_candidates=org_name_sources
    )

    raw_new_name = candidate_b.get("name")
    new_basis = (
        raw_new_name
        if isinstance(raw_new_name, str) and raw_new_name
        else ctx.project_id
    )
    new_proj_display = _sanitize_display_name(new_basis)
    new_org_value = org_name or ctx.org_id
    new_org_display = _sanitize_display_name(new_org_value)

    if (
        old_org_display
        and old_proj_display
        and (old_org_display != new_org_display or old_proj_display != new_proj_display)
    ):
        _remove_display_name_symlink(old_org_display, old_proj_display)

    prev_entry = PROJECTS.get((ctx.org_id, ctx.project_id))
    prev_m = prev_entry.m if prev_entry else None
    applied_patch = jsondiff.diff(current_b or {}, candidate_b, marshal=True)
    # Persist applied patches in append-only JSONL for replay on startup
    if applied_patch:
        # For brand-new projects use the creation timestamp; otherwise now().
        m = new_struct.created if current_struct is None else datetime.now(UTC)
        PROJECTS[(ctx.org_id, ctx.project_id)] = _ProjectEntry(new_struct, m)
        try:
            _persist_append_patch(
                ctx.org_id,
                ctx.project_id,
                applied_patch,
                actor=ctx.actor,
                m=m,
            )
        except Exception as exc:
            logger.error(
                "persistence: append failed for %s/%s: %r",
                ctx.org_id,
                ctx.project_id,
                exc,
            )
    else:
        PROJECTS[(ctx.org_id, ctx.project_id)] = _ProjectEntry(new_struct, prev_m)
    try:
        _ensure_display_name_symlinks(
            ctx.org_id, ctx.project_id, org_name, candidate_b.get("name")
        )
    except Exception as exc:
        logger.debug(
            "Failed to ensure display name symlink for %s/%s: %r",
            ctx.org_id,
            ctx.project_id,
            exc,
        )
    return candidate_b, applied_patch


class _ApplyCtx(msgspec.Struct):
    project_id: str
    client_id: int
    org_id: str
    websocket: WebSocket
    actor: str


async def broadcast(
    org_id: str, project_id: str, payload: dict, exclude: int | None = None
) -> None:
    """Broadcast a message to all clients subscribed to a specific project."""
    dead: list[int] = []
    for client_id, client in CLIENTS.items():
        if exclude is not None and client_id == exclude:
            continue
        if client.org_id != org_id:
            continue
        if (org_id, project_id) in client.pids:
            try:
                await client.ws.send_json(payload)
            except Exception:
                dead.append(client_id)
    for client_id in dead:
        CLIENTS.pop(client_id, None)


async def broadcast_all(
    payload: dict, exclude: int | None = None, org_id: str | None = None
) -> None:
    """Broadcast a message to all connected clients, optionally filtered by org."""
    dead: list[int] = []
    for client_id, client in CLIENTS.items():
        if exclude is not None and client_id == exclude:
            continue
        if org_id is not None and client.org_id != org_id:
            continue
        try:
            await client.ws.send_json(payload)
        except Exception:
            dead.append(client_id)
    for client_id in dead:
        CLIENTS.pop(client_id, None)


_B64URL_RE = re.compile(r"^[A-Za-z0-9_-]{8}$")


def _valid_project_minimal(
    project_id: str, data: dict[str, Any]
) -> tuple[bool, str | None]:
    """Validate only fields required for project-list broadcasts.

    Rules:
    - project_id: non-empty base64url string (URL-safe chars only)
    - name: present (empty string is OK, but None/missing is not)
    """
    if (
        not isinstance(project_id, str)
        or not project_id
        or not _B64URL_RE.fullmatch(project_id)
    ):
        return False, "invalid id"
    # Name can be empty string, but must be present and a string (not None)
    if "name" not in data or not isinstance(data.get("name"), str):
        return False, "invalid name"
    return True, None


def _projects_snapshot(org_id: str) -> list[dict[str, object]]:
    items: list[dict[str, object]] = []
    for (oid, pid), entry in PROJECTS.items():
        if oid != org_id:
            continue
        item: dict[str, object] = {
            "id": pid,
            "name": entry.project.name,
            "notes": entry.project.notes,
            "created": msgspec.to_builtins(entry.project.created),
        }
        if entry.m is not None:
            item["ts"] = msgspec.to_builtins(entry.m)
        org_id_val = getattr(entry.project, "org_id", None)
        if isinstance(org_id_val, str):
            item["org_id"] = org_id_val
        org_name_val = getattr(entry.project, "org_name", None)
        if isinstance(org_name_val, str):
            item["org_name"] = org_name_val
        ok, reason = _valid_project_minimal(pid, item)
        if ok:
            items.append(item)
        else:
            logger.info(
                "snapshot skip invalid project: id=%r name=%r created=%r reason=%s",
                pid,
                item.get("name"),
                item.get("created"),
                reason,
            )
    return items


def store_project(proj: Project, project_id: str, org_id: str | None = None) -> None:
    # Validate minimal fields to avoid introducing invalid states server-side
    pb_any = _project_to_builtins(proj)
    assert isinstance(pb_any, dict)
    pb: dict[str, Any] = pb_any
    ok, reason = _valid_project_minimal(project_id, {"name": pb.get("name")})
    if not ok:
        logger.info(
            "store_project reject: %s | id=%r name=%r",
            reason,
            project_id,
            pb.get("name"),
        )
        return
    org_key = org_id or PUBLIC_ORG_ID
    _, pb_final, _ = _finalize_project_metadata(
        pb, org_id=org_key, org_name_candidates=[pb.get("org_name")]
    )
    proj_final = msgspec.convert(pb_final, type=Project, strict=False)
    PROJECTS[(org_key, project_id)] = _ProjectEntry(proj_final, m=proj_final.created)


def get_project(project_id: str, org_id: str | None = None) -> Project | None:
    org_key = org_id or PUBLIC_ORG_ID
    entry = PROJECTS.get((org_key, project_id))
    return entry.project if entry else None


async def projects_broadcast(org_id: str, item: dict[str, object]) -> None:
    # Broadcast project list updates to all clients
    payload = {"type": "upsert", "project": item}
    await broadcast_all(payload, org_id=org_id)


def _get_user_agent(websocket: WebSocket) -> str:
    ua_raw = websocket.headers.get("user-agent")  # type: ignore[attr-defined]
    return compact_user_agent(ua_raw)


def _get_user_info(websocket: WebSocket) -> dict[str, str]:
    """Extract user identity from upstream auth headers.

    Expected headers (case-insensitive):
    - Remote-User: UUID of the user
    - Remote-Org: UUID of the organization
    - Remote-Name: display name of the user
    - Remote-Org-Name: display name of the organization
    """
    h = websocket.headers  # type: ignore[attr-defined]
    # Starlette headers are case-insensitive mapping
    user_id = (h.get("remote-user") or h.get("Remote-User") or "").strip()
    org_id = (h.get("remote-org") or h.get("Remote-Org") or "").strip()
    name = (h.get("remote-name") or h.get("Remote-Name") or "").strip()
    org_name = (h.get("remote-org-name") or h.get("Remote-Org-Name") or "").strip()
    out: dict[str, str] = {}
    if user_id:
        out["id"] = user_id
    if org_id:
        out["org_id"] = org_id
    if name:
        out["name"] = name
    if org_name:
        out["org_name"] = org_name
    return out


async def _handle_get_project(websocket: WebSocket, msg: dict, client_id: int) -> None:
    """Handle get_project request."""
    req_id = msg["id"]
    req = msg["req"]
    assert req_id
    client = CLIENTS.get(client_id)
    if client is None:
        raise ValueError("client not registered")
    # Validate id format early; reject malformed identifiers explicitly
    if not isinstance(req_id, str) or not _B64URL_RE.fullmatch(req_id):
        await websocket.send_json(
            {
                "type": "reject",
                "project_id": req_id,
                "reason": "invalid_id",
                "message": f"Invalid project ID format: {req_id!r}",
                "req": req,
            }
        )
        logger.warning("[#%d] invalid project id (get_project): %s", client_id, req_id)
        return
    logger.debug(
        "[#%d] get_project request id=%s org=%s",
        client_id,
        req_id,
        client.org_id,
    )

    # Check if project was deleted
    try:
        log_path = _project_log_path(client.org_id, req_id)
        deleted_path = log_path.with_suffix(".jsonl.deleted")
        if deleted_path.exists():
            await websocket.send_json(
                {
                    "type": "reject",
                    "project_id": req_id,
                    "reason": "deleted",
                    "message": f"Project {req_id!r} has been deleted",
                    "req": req,
                }
            )
            logger.warning("[#%d] project was deleted: %s", client_id, req_id)
            return
    except Exception as e:
        logger.debug("[#%d] Error checking if project deleted: %s", client_id, e)

    proj = PROJECTS.get((client.org_id, req_id))
    if proj is None:
        # Send reject message for non-existent project
        await websocket.send_json(
            {
                "type": "reject",
                "project_id": req_id,
                "reason": "not_found",
                "message": f"Project {req_id!r} not found",
                "req": req,
            }
        )
        logger.warning("[#%d] project not found: %s", client_id, req_id)
        return
    state = _project_to_builtins(proj.project)
    await websocket.send_json(
        {
            "type": "project",
            "req": req,
            "project_id": req_id,
            "project": _strip_project_metadata(state),
            "ts": msgspec.to_builtins(proj.m) if proj.m else None,
            "org_id": state.get("org_id"),
            "org_name": state.get("org_name"),
        }
    )

    # Subscribe this client so they receive future calc results / patches
    client.pids.add((client.org_id, req_id))

    # Send cached calc result if available.  If not cached but a calc is
    # already in-flight, just wait — the result will broadcast to all
    # subscribers (including this one) when it finishes.  Only trigger a
    # new calc when nothing is cached AND nothing is running.
    key = (client.org_id, req_id)
    cached = CALC_RESULTS.get(key)
    if cached is not None:
        await websocket.send_json(
            {
                "type": "calc_result",
                "project_id": req_id,
                "result": cached,
            }
        )
    elif not calc_runner.is_running(client.org_id, req_id):
        await calc_runner.trigger(client.org_id, req_id, proj.project)


async def _handle_message(websocket: WebSocket, msg: dict, client_id: int) -> None:
    try:
        t = msg.get("type")
        # Get full project snapshot
        if t == "get_project":
            await _handle_get_project(websocket, msg, client_id)
            return

        # Main sync path
        if t == "sync":
            await sync(msg, websocket, client_id)
            return

        # Delete project
        if t == "delete":
            await delete_project(msg, websocket, client_id)
            return

        # Undelete project
        if t == "undelete":
            await undelete_project(msg, websocket, client_id)
            return

        # List deleted projects
        if t == "list_deleted":
            await list_deleted_projects(msg, websocket, client_id)
            return

        raise ValueError(f"unknown type {t}")
    except Exception as exc:
        logger.exception("[#%d] exception handling %s", client_id, msg)
        await websocket.send_json({"type": "error", "error": f"{exc!r}"})


async def sync(msg: dict, websocket: WebSocket, client_id: int) -> None:
    pid = msg["project_id"]
    working = msg["working"]
    shadow = msg["shadow"]
    req = msg["req"]

    if not isinstance(pid, str) or not pid:
        raise ValueError("project_id required")
    if not isinstance(working, dict) or not isinstance(shadow, dict):
        raise TypeError("working and shadow must be dicts")

    # Validate project_id format
    if not _B64URL_RE.fullmatch(pid):
        await websocket.send_json(
            {
                "type": "reject",
                "project_id": pid,
                "reason": "invalid_id",
                "message": f"Invalid project ID format: {pid!r}",
                "req": req,
            }
        )
        logger.warning("[#%d] invalid project id: %s", client_id, pid)
        return

    client = CLIENTS.get(client_id)
    if client is None:
        raise ValueError("client not registered")
    org_id = client.org_id

    # Check if project was deleted
    try:
        log_path = _project_log_path(org_id, pid)
        deleted_path = log_path.with_suffix(".jsonl.deleted")
        if deleted_path.exists():
            await websocket.send_json(
                {
                    "type": "reject",
                    "project_id": pid,
                    "reason": "deleted",
                    "message": f"Project {pid!r} has been deleted",
                    "req": req,
                }
            )
            logger.warning(
                "[#%d] sync rejected: project was deleted: %s", client_id, pid
            )
            return
    except Exception as e:
        logger.debug("[#%d] Error checking if project deleted: %s", client_id, e)

    client.pids.add((org_id, pid))

    uinfo = client.user if client else None
    actor = (uinfo.get("id") if uinfo else None) or (
        websocket.client[0] if websocket.client else "unknown"
    )
    project_id = pid
    entry = PROJECTS.get((org_id, pid))
    previous_project = _project_to_builtins(entry.project) if entry else {}
    shadow_b = msgspec.to_builtins(shadow)
    working_b = msgspec.to_builtins(working)

    # Compute and apply sync result
    ctx = _ApplyCtx(
        project_id=project_id,
        client_id=client_id,
        org_id=org_id,
        websocket=websocket,
        actor=actor,
    )
    try:
        res = _compute_sync(ctx, shadow_b, working_b)
    except ValueError as exc:
        await _handle_sync_error(exc, ctx, req)
        return

    actor_label = (uinfo.get("name") if uinfo else None) or format_client_ip(
        websocket.client[0] if websocket.client else "unknown"
    )
    if res.created:
        log_sync_change(
            "create",
            f"project [{pid}]",
            client_id,
            actor_label,
            previous_project,
            res.project,
        )
    elif res.patch:
        log_sync_change(
            "update",
            f"{res.project['name']} ({pid})",
            client_id,
            actor_label,
            previous_project,
            res.project,
        )

    # Timestamp for metadata: only use current time if there are actual changes;
    # otherwise preserve the existing modification timestamp.
    if res.created or res.patch:
        now_ts = msgspec.to_builtins(datetime.now(UTC))
    else:
        entry = PROJECTS.get((org_id, pid))
        now_ts = msgspec.to_builtins(entry.m) if entry and entry.m else None

    # Project-list upsert if needed
    if res.created or res.patch:
        await projects_broadcast(
            org_id,
            {
                "id": pid,
                "name": res.project["name"],
                "notes": res.project.get("notes"),
                "created": res.project.get("created"),
                "ts": now_ts,
                "org_id": res.project.get("org_id"),
                "org_name": res.project.get("org_name"),
            },
        )

    # Strip server-managed metadata from the project payload; send as
    # top-level fields so the frontend can update its project list without
    # polluting the sync'd project state.
    client_proj = _strip_project_metadata(res.project)
    meta = {
        "org_id": res.project.get("org_id"),
        "org_name": res.project.get("org_name"),
    }

    # Notify peers and ack sender
    await broadcast(
        org_id,
        pid,
        {
            "type": "patch",
            "project_id": pid,
            "patch": res.patch,
            "project": client_proj,
            "ts": now_ts,
            "actor": actor,
            **meta,
        },
        exclude=client_id,
    )
    await websocket.send_json(
        {
            "type": "ack",
            "req": req,
            "project_id": pid,
            "project": client_proj,
            "patch": res.patch,
            "ts": now_ts,
            "actor": actor,
            **meta,
        }
    )

    # Trigger background pipenet calculation (fire-and-forget).
    # Uses the authoritative Project struct already stored in PROJECTS.
    if res.created or res.patch:
        # Invalidate stale cached calc result — data has changed.
        CALC_RESULTS.pop((org_id, pid), None)
        entry = PROJECTS.get((org_id, pid))
        if entry is not None:
            await calc_runner.trigger(org_id, pid, entry.project)
    else:
        # No changes — client just subscribed.  Send cached calc result
        # immediately so they don't have to wait for a future edit.
        key = (org_id, pid)
        cached = CALC_RESULTS.get(key)
        if cached is not None:
            await websocket.send_json(
                {
                    "type": "calc_result",
                    "project_id": pid,
                    "result": cached,
                }
            )
        elif not calc_runner.is_running(org_id, pid):
            entry = PROJECTS.get(key)
            if entry is not None:
                await calc_runner.trigger(org_id, pid, entry.project)


async def _handle_sync_error(exc: ValueError, ctx: _ApplyCtx, req: object) -> None:
    """Handle a validation error from _compute_sync by resetting or rejecting."""
    error_msg = str(exc)
    pid = ctx.project_id
    current_struct = PROJECTS.get((ctx.org_id, pid))
    if current_struct is not None:
        current_proj = _project_to_builtins(current_struct.project)
        await ctx.websocket.send_json(
            {
                "type": "ack",
                "req": req,
                "project_id": pid,
                "project": _strip_project_metadata(current_proj),
                "patch": {},
                "actor": ctx.actor,
                "error": error_msg,
                "org_id": current_proj.get("org_id"),
                "org_name": current_proj.get("org_name"),
            }
        )
        logger.warning(
            "[#%d] sync rejected for %s, reset to server state: %s",
            ctx.client_id,
            pid,
            error_msg,
        )
    else:
        await ctx.websocket.send_json(
            {
                "type": "reject",
                "project_id": pid,
                "reason": "validation_failed",
                "message": error_msg,
                "req": req,
            }
        )
        logger.error(
            "[#%d] project validation failed for %s (no server state): %s",
            ctx.client_id,
            pid,
            error_msg,
        )


class _SyncResult(msgspec.Struct):
    project: dict
    patch: dict
    created: bool


def _compute_sync(
    ctx: _ApplyCtx,
    shadow_b: dict,
    working_b: dict,
) -> _SyncResult:
    project_id = ctx.project_id
    entry = PROJECTS.get((ctx.org_id, project_id))
    current_struct = entry.project if entry else None
    current_b = _project_to_builtins(current_struct) if current_struct else {}

    client_patch = jsondiff.diff(shadow_b or {}, working_b or {}, marshal=True)
    # If the server has no record of the project, create it from the client's
    # working snapshot regardless of whether the client computed a non-empty patch.
    if current_struct is None:
        rebased_b = dict(working_b) if working_b else {}
    else:
        rebased_b = (
            jsondiff.patch(current_b, client_patch, marshal=True)
            if client_patch
            else current_b
        )
    new_struct, candidate_b, reason = _build_struct_and_validate(rebased_b, project_id)
    if reason is not None or new_struct is None or candidate_b is None:
        raise ValueError(f"invalid project: {reason or 'invalid'}")
    project, patch = _apply_valid_struct(
        current_struct, current_b, new_struct, candidate_b, ctx
    )
    created = current_struct is None
    return _SyncResult(project, patch, created)


async def delete_project(msg: dict, websocket: WebSocket, client_id: int) -> None:
    """Handle project deletion request."""
    project_id = msg.get("project_id")
    req = msg.get("req")

    if not isinstance(project_id, str) or not project_id:
        raise ValueError("project_id required")

    if not _B64URL_RE.fullmatch(project_id):
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Invalid project ID format: {project_id!r}",
                "req": req,
            }
        )
        logger.warning("[#%d] invalid project id (delete): %s", client_id, project_id)
        return

    client = CLIENTS.get(client_id)
    if client is None:
        raise ValueError("client not registered")

    org_id = client.org_id

    # Check if project exists
    key = (org_id, project_id)
    if key not in PROJECTS:
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Project {project_id!r} not found",
                "req": req,
            }
        )
        logger.warning("[#%d] delete: project not found: %s", client_id, project_id)
        return

    # Get project data before deletion for symlink cleanup
    entry = PROJECTS[key]
    proj_data = _project_to_builtins(entry.project)

    # Cancel any running calculation for this project
    await calc_runner.cancel(org_id, project_id)

    # Remove from in-memory store
    del PROJECTS[key]
    CALC_RESULTS.pop(key, None)

    # Rename the file with .deleted extension
    try:
        log_path = _project_log_path(org_id, project_id)
        if log_path.exists():
            deleted_path = log_path.with_suffix(".jsonl.deleted")
            log_path.rename(deleted_path)
            logger.info(
                "[#%d] deleted project file: %s -> %s",
                client_id,
                log_path,
                deleted_path,
            )
    except Exception as exc:
        logger.error(
            "[#%d] failed to rename project file %s: %r",
            client_id,
            project_id,
            exc,
        )

    # Remove display name symlinks
    try:
        org_name = proj_data.get("org_name") or org_id
        proj_name = proj_data.get("name") or project_id
        _remove_display_name_symlink(
            _sanitize_display_name(org_name), _sanitize_display_name(proj_name)
        )
    except Exception as exc:
        logger.debug(
            "[#%d] failed to remove symlink for %s: %r",
            client_id,
            project_id,
            exc,
        )

    # Broadcast deletion to all clients in the org
    await broadcast_all(
        {"type": "delete", "id": project_id},
        org_id=org_id,
    )

    # Acknowledge to sender
    await websocket.send_json(
        {
            "type": "delete_ack",
            "req": req,
            "project_id": project_id,
        }
    )

    logger.info("[#%d] deleted project: %s", client_id, project_id)


async def list_deleted_projects(
    msg: dict, websocket: WebSocket, client_id: int
) -> None:
    """Handle list deleted projects request."""
    req = msg.get("req")
    client = CLIENTS.get(client_id)
    if client is None:
        raise ValueError("client not registered")

    org_id = client.org_id
    deleted = []

    # Scan for .jsonl.deleted files in org directory
    org_dir = PERSIST_DIR / org_id
    if org_dir.is_dir():
        for file in org_dir.glob("*.jsonl.deleted"):
            project_id = file.stem.replace(".jsonl", "")
            if not _B64URL_RE.fullmatch(project_id):
                continue

            # Try to read the project name from the deleted file
            try:
                data = file.read_bytes()
                rr = _replay_from_data(org_id, project_id, data)
                current_b = rr.state

                deleted.append(
                    {
                        "id": project_id,
                        "name": current_b.get("name", ""),
                        "created": current_b.get("created"),
                        "org_id": org_id,
                    }
                )
            except Exception as exc:
                logger.debug("Failed to read deleted project %s: %r", project_id, exc)

    # Send response
    await websocket.send_json(
        {
            "type": "deleted_projects",
            "req": req,
            "projects": deleted,
        }
    )

    logger.info(
        "[#%d] listed %d deleted projects for org %s", client_id, len(deleted), org_id
    )


async def _restore_deleted_file(org_id: str, project_id: str) -> Path:
    """Restore a deleted project file by removing .deleted extension.

    Returns:
        Path to the restored file

    Raises:
        FileNotFoundError: If deleted file doesn't exist
        OSError: If file operation fails
    """
    log_path = _project_log_path(org_id, project_id)
    deleted_path = log_path.with_suffix(".jsonl.deleted")

    if not deleted_path.exists():
        raise FileNotFoundError(f"Deleted project {project_id!r} not found")

    deleted_path.rename(log_path)
    return log_path


async def _reload_project_from_disk(
    org_id: str, project_id: str
) -> tuple[Project, dict]:
    """Reload project from disk and add to in-memory store.

    Returns:
        Tuple of (Project struct, candidate_b dict)

    Raises:
        ValueError: If project data is invalid
    """
    log_path = _project_log_path(org_id, project_id)
    data = log_path.read_bytes()
    rr = _replay_from_data(org_id, project_id, data)

    apply_migrations(
        rr.state,
        MigrationCtx(project_id=project_id),
        version=rr.version,
    )
    new_struct, candidate_b, reason = _build_struct_and_validate(rr.state, project_id)
    if reason is not None or new_struct is None or candidate_b is None:
        raise ValueError(f"invalid project: {reason or 'invalid'}")

    new_struct, candidate_b, _ = _finalize_project_metadata(
        candidate_b,
        org_id=org_id,
        org_name_candidates=[
            candidate_b.get("org_name"),
            rr.state.get("org_name"),
        ],
    )

    # Restore to in-memory store
    PROJECTS[(org_id, project_id)] = _ProjectEntry(new_struct, rr.m)

    return new_struct, candidate_b


async def undelete_project(msg: dict, websocket: WebSocket, client_id: int) -> None:
    """Handle project undelete request."""
    project_id = msg.get("project_id")
    req = msg.get("req")

    if not isinstance(project_id, str) or not project_id:
        raise ValueError("project_id required")

    if not _B64URL_RE.fullmatch(project_id):
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Invalid project ID format: {project_id!r}",
                "req": req,
            }
        )
        logger.warning("[#%d] invalid project id (undelete): %s", client_id, project_id)
        return

    client = CLIENTS.get(client_id)
    if client is None:
        raise ValueError("client not registered")

    org_id = client.org_id

    # Restore the deleted file
    try:
        log_path = await _restore_deleted_file(org_id, project_id)
        logger.info("[#%d] restored project file: %s", client_id, log_path)
    except FileNotFoundError:
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Deleted project {project_id!r} not found",
                "req": req,
            }
        )
        logger.warning(
            "[#%d] undelete: deleted project not found: %s", client_id, project_id
        )
        return
    except Exception as exc:
        logger.error(
            "[#%d] failed to restore project file %s: %r",
            client_id,
            project_id,
            exc,
        )
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Failed to restore project: {exc!r}",
                "req": req,
            }
        )
        return

    # Reload the project from disk
    try:
        _new_struct, candidate_b = await _reload_project_from_disk(org_id, project_id)

        # Recreate display name symlinks
        try:
            _ensure_display_name_symlinks(
                org_id, project_id, candidate_b.get("org_name"), candidate_b.get("name")
            )
        except Exception as exc:
            logger.debug(
                "Failed to recreate display name symlink for %s/%s: %r",
                org_id,
                project_id,
                exc,
            )

        # Broadcast restoration to all clients in the org
        entry = PROJECTS.get((org_id, project_id))
        await projects_broadcast(
            org_id,
            {
                "id": project_id,
                "name": candidate_b.get("name"),
                "notes": candidate_b.get("notes"),
                "created": candidate_b.get("created"),
                "ts": msgspec.to_builtins(entry.m) if entry and entry.m else None,
                "org_id": candidate_b.get("org_id"),
                "org_name": candidate_b.get("org_name"),
            },
        )

        # Acknowledge to sender
        await websocket.send_json(
            {
                "type": "undelete_ack",
                "req": req,
                "project_id": project_id,
            }
        )

        logger.info("[#%d] undeleted project: %s", client_id, project_id)

    except Exception as exc:
        logger.error(
            "[#%d] failed to reload undeleted project %s: %r",
            client_id,
            project_id,
            exc,
        )
        await websocket.send_json(
            {
                "type": "error",
                "error": f"Failed to reload project: {exc!r}",
                "req": req,
            }
        )


# ------- Persistence helpers (append-only JSONL of patches) -------


def _project_log_path(org_id: str, project_id: str) -> Path:
    if not _B64URL_RE.fullmatch(project_id):
        # Defensive: avoid unsafe filenames
        raise ValueError("invalid project id for persistence")
    return PERSIST_DIR / org_id / f"{project_id}.jsonl"


def _persist_append_patch(
    org_id: str,
    project_id: str,
    patch: dict,
    *,
    actor: str,
    migration: bool = False,
    m: datetime | None = None,
) -> None:
    path = _project_log_path(org_id, project_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    record = ChangeRecord(
        a="migrate" if migration else "",
        v=DBVER,
        u=actor,
        m=m,
        diff=patch,
    )
    data = msgspec.json.encode(record)
    with path.open("ab") as f:
        f.write(data + b"\n")


def _persist_snapshot(
    org_id: str,
    project_id: str,
    state: dict[str, Any],
    m: datetime | None = None,
) -> None:
    """Append a SNAPSHOT line containing the full project state.

    The line format is: SNAPSHOT <json>\n
    This allows fast lookup by scanning for lines starting with 'SNAPSHOT '
    without parsing JSON.
    """
    path = _project_log_path(org_id, project_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    snap = Snapshot(ts=datetime.now(UTC), v=DBVER, state=state, m=m)
    data = msgspec.json.encode(snap)
    with path.open("ab") as f:
        f.write(SNAPSHOT_PREFIX + data + b"\n")
    logger.debug("persistence: wrote snapshot for %s/%s", org_id, project_id)


def _maybe_write_snapshot(
    org_id: str,
    project_id: str,
    current_state: dict[str, Any],
    last_patch_mtime: float | None,
    last_snapshot_mtime: float | None,
) -> None:
    """Conditionally write a snapshot based on heuristics.

    Write a snapshot if:
    1. There have been patches since the last snapshot (or no snapshot exists)
    2. AND enough time has passed since the last patch (SNAPSHOT_STALE_THRESHOLD)

    This avoids creating snapshots right after each other - only after the
    project has been modified and then left idle for a while.
    """
    now = time.time()

    # If we have no last patch mtime, skip (nothing to snapshot)
    if last_patch_mtime is None:
        return

    # If there's a snapshot and no patches after it, skip
    # (last_patch_mtime <= last_snapshot_mtime means no new patches)
    if last_snapshot_mtime is not None and last_patch_mtime <= last_snapshot_mtime:
        return

    # Check if enough time has passed since the last patch
    time_since_patch = now - last_patch_mtime
    if time_since_patch < SNAPSHOT_STALE_THRESHOLD:
        return

    # Write the snapshot
    entry = PROJECTS.get((org_id, project_id))
    try:
        _persist_snapshot(
            org_id, project_id, current_state, m=entry.m if entry else None
        )
    except Exception as exc:
        logger.error(
            "persistence: failed to write snapshot for %s/%s: %r",
            org_id,
            project_id,
            exc,
        )


def _find_last_snapshot_offset(data: bytes) -> int | None:
    """Find the byte offset of the last SNAPSHOT line in file data.

    Scans backwards through lines to find the last one starting with 'SNAPSHOT '.
    Returns the offset to start of that line, or None if no snapshot found.
    """
    # Split into lines and find last snapshot
    lines = data.split(b"\n")
    offset = 0
    last_snapshot_offset = None

    for line in lines:
        if line.startswith(SNAPSHOT_PREFIX):
            last_snapshot_offset = offset
        offset += len(line) + 1  # +1 for the newline

    return last_snapshot_offset


class _SnapshotState(msgspec.Struct):
    """State loaded from the last snapshot in a project log."""

    state: dict[str, Any]
    has_migration: bool
    snapshot_mtime: float | None
    version: int
    replay_offset: int  # byte offset to start replaying patches from
    m: datetime | None  # last non-migration modification time


def _load_snapshot(org_id: str, project_id: str, data: bytes) -> _SnapshotState:
    """Find and parse the last snapshot in data, returning initial replay state."""
    snapshot_offset = _find_last_snapshot_offset(data)

    if snapshot_offset is not None:
        snapshot_end = data.find(b"\n", snapshot_offset)
        if snapshot_end == -1:
            snapshot_end = len(data)
        snapshot_line = data[snapshot_offset:snapshot_end]
        snapshot_json = snapshot_line[len(SNAPSHOT_PREFIX) :]
        try:
            snap = msgspec.json.decode(snapshot_json, type=Snapshot)
            logger.debug("persistence: using snapshot for %s/%s", org_id, project_id)
            next_newline = data.find(b"\n", snapshot_offset)
            replay_offset = next_newline + 1 if next_newline != -1 else len(data)
            return _SnapshotState(
                state=snap.state,
                has_migration=True,
                snapshot_mtime=snap.ts.timestamp(),
                version=snap.v,
                replay_offset=replay_offset,
                m=snap.m,
            )
        except Exception as exc:
            logger.warning(
                "persistence: failed to parse snapshot for %s/%s: %r, falling back to full replay",
                org_id,
                project_id,
                exc,
            )

    return _SnapshotState(
        state={},
        has_migration=False,
        snapshot_mtime=None,
        version=0,
        replay_offset=0,
        m=None,
    )


class _ReplayResult(msgspec.Struct):
    """Result of replaying a project log file."""

    state: dict[str, Any]
    has_migration: bool
    last_patch_mtime: float | None
    last_snapshot_mtime: float | None
    version: int
    m: datetime | None  # last non-migration modification time


def _replay_from_data(org_id: str, project_id: str, data: bytes) -> _ReplayResult:
    """Replay project state from file data, using snapshot if available.

    The ``m`` field is read from change records and snapshots.
    Each non-migration ChangeRecord stores the modification time in ``m``;
    Snapshots preserve it across compaction.
    """
    ss = _load_snapshot(org_id, project_id, data)
    current_b = ss.state
    has_migration_record = ss.has_migration
    last_patch_mtime: float | None = None
    last_snapshot_mtime = ss.snapshot_mtime
    version = ss.version
    m: datetime | None = ss.m  # from snapshot

    # Replay patches from snapshot onward
    remaining = data[ss.replay_offset :]
    lineno = data[: ss.replay_offset].count(b"\n") + 1 if ss.replay_offset else 1
    for raw in remaining.split(b"\n"):
        line = raw.strip()
        if not line:
            lineno += 1
            continue
        # Skip snapshot lines (shouldn't be any after our start point, but be safe)
        if line.startswith(SNAPSHOT_PREFIX):
            try:
                snap = msgspec.json.decode(line[len(SNAPSHOT_PREFIX) :], type=Snapshot)
                last_snapshot_mtime = snap.ts.timestamp()
                if snap.m is not None:
                    m = snap.m
            except Exception as e:
                raise ValueError(f"line {lineno}: invalid snapshot record") from e
            lineno += 1
            continue
        try:
            change = msgspec.json.decode(line, type=ChangeRecord)
        except Exception:
            if lineno == 1:
                raise ValueError("old format, run: python -m jacloud.migrate") from None
            raise ValueError(f"line {lineno}: invalid record") from None
        if change.a.startswith("migrate"):
            has_migration_record = True
        if change.m is not None:
            m = change.m
        last_patch_mtime = change.ts.timestamp()
        version = change.v
        current_b = jsondiff.patch(current_b, change.diff, marshal=True)
        lineno += 1

    return _ReplayResult(
        state=current_b,
        has_migration=has_migration_record,
        last_patch_mtime=last_patch_mtime,
        last_snapshot_mtime=last_snapshot_mtime,
        version=version,
        m=m,
    )


def _replay_file(
    org_id: str,
    file: Path,
    errors: list[str],
    migrated: list[tuple[str, list[str]]],
) -> None:
    """Replay a single project file at startup."""
    project_id = file.stem
    try:
        data = file.read_bytes()

        rr = _replay_from_data(org_id, project_id, data)

        # Apply schema migrations (only relevant at startup)
        pre_migration_b = copy.deepcopy(rr.state)
        migration_applied, _, migration_descriptions = apply_migrations(
            rr.state,
            MigrationCtx(project_id=project_id),
            silent=rr.has_migration,
            version=rr.version,
        )

        new_struct, candidate_b, reason = _build_struct_and_validate(
            rr.state,
            project_id,
        )
        if reason is not None or new_struct is None or candidate_b is None:
            errors.append(f"{file}: {reason}")
            return

        # Persist migrations if needed
        if migration_applied:
            migration_patch = jsondiff.diff(pre_migration_b, candidate_b, marshal=True)
            if migration_patch:
                name = candidate_b.get("name") or project_id
                migrated.append((name, migration_descriptions))
                _persist_append_patch(
                    org_id,
                    project_id,
                    migration_patch,
                    actor=f"jacloud {__version__}",
                    migration=True,
                    m=rr.m,
                )

        new_struct, candidate_b, _ = _finalize_project_metadata(
            candidate_b,
            org_id=org_id,
            org_name_candidates=[
                candidate_b.get("org_name"),
                rr.state.get("org_name"),
            ],
        )
        PROJECTS[(org_id, project_id)] = _ProjectEntry(new_struct, rr.m)

        _maybe_write_snapshot(
            org_id,
            project_id,
            candidate_b,
            rr.last_patch_mtime,
            rr.last_snapshot_mtime,
        )

    except Exception as exc:
        logger.exception(
            "persistence: failed to replay %s/%s",
            org_id,
            file.name,
        )
        errors.append(f"{file}: {exc}")


def _log_replay_summary(
    migrated: list[tuple[str, list[str]]], errors: list[str]
) -> None:
    """Log migration and error summaries after replaying all projects."""
    if migrated:
        all_descs = [set(d) for _, d in migrated]
        common = set.intersection(*all_descs) if all_descs else set()
        if common and len(migrated) > 1:
            ordered = [d for d in migrated[0][1] if d in common]
            names = ", ".join(name for name, _ in migrated)
            logger.info(
                "Migrated %d projects [%s]: %s",
                len(migrated),
                names,
                ", ".join(ordered),
            )
        else:
            for name, descs in migrated:
                logger.info("Migrated [%s]: %s", name, ", ".join(descs))

    if errors:
        reasons = Counter(e.split(": ", 1)[-1] if ": " in e else e for e in errors)
        for reason, cnt in reasons.items():
            if cnt > 1:
                logger.error("%d projects failed: %s", cnt, reason)
            else:
                full = next(e for e in errors if e.endswith(reason))
                logger.error("Failed to load %s", full)


def _replay_all_projects() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PERSIST_DIR.mkdir(parents=True, exist_ok=True)
    PROJECTS.clear()

    errors: list[str] = []
    migrated: list[tuple[str, list[str]]] = []

    for org_dir in PERSIST_DIR.iterdir():
        if org_dir.is_dir():
            org_id = org_dir.name
            for file in org_dir.glob("*.jsonl"):
                _replay_file(org_id, file, errors, migrated)

    for file in PERSIST_DIR.glob("*.jsonl"):
        if file.is_file():
            _replay_file(PUBLIC_ORG_ID, file, errors, migrated)

    _log_replay_summary(migrated, errors)
    _rebuild_symlink_tree()


def load_projects_from_jsonl() -> int:
    """Public API: load all projects from persisted JSONL logs.

    Returns the number of projects loaded. Safe to call multiple times; it will
    rebuild in-memory state from logs.
    """
    _replay_all_projects()
    return _total_project_count()
