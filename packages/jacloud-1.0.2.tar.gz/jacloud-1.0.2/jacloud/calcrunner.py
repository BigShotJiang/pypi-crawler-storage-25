"""Background calculation runner for pipe network analysis.

Runs heavy calculations (pipenet solver) in a background thread, with
support for cancellation when the project is modified before a result
is ready.  Results are delivered back to the asyncio event loop for
broadcast over WebSocket.

Usage from sync.py (minimal integration)::

    from .calcrunner import calc_runner

    # After a successful sync that mutated the project:
    await calc_runner.trigger(org_id, project_id, project_struct)

    # The runner will:
    # 1. Cancel any in-flight calculation for (org_id, project_id)
    # 2. Snapshot the project and start a new calculation in a thread
    # 3. On completion, call the registered delivery callback which
    #    broadcasts the result to subscribed WS clients.
"""

from __future__ import annotations

import asyncio
import copy
import logging
import threading
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from .project import Project

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Cancellation primitive
# ---------------------------------------------------------------------------


class CancelledError(Exception):
    """Raised inside a worker thread when the calculation is cancelled."""


class CancelToken:
    """Thread-safe cancellation token.

    The async side calls ``cancel()``; the worker thread calls
    ``check()`` periodically (e.g. every N solver iterations).
    """

    __slots__ = ("_event",)

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        """Signal cancellation (called from async side)."""
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    def check(self) -> None:
        """Raise ``CancelledError`` if cancellation was requested."""
        if self._event.is_set():
            raise CancelledError


# ---------------------------------------------------------------------------
# Calculation result envelope
# ---------------------------------------------------------------------------


@dataclass
class CalcResult:
    """Wrapper for a completed calculation result.

    ``data`` holds the solver output as a JSON-serialisable dict ready
    to be sent over WebSocket.  The exact shape is defined by the
    processing function — the runner is agnostic.
    """

    org_id: str
    project_id: str
    data: dict[str, Any]


# Type alias for the async delivery callback.
# Signature: async def deliver(result: CalcResult) -> None
DeliveryCallback = Callable[[CalcResult], Awaitable[None]]

# Type alias for the synchronous compute function run in a thread.
# Signature: def compute(project: Project, token: CancelToken) -> dict | None
ComputeFunc = Callable[[Project, CancelToken], dict[str, Any] | None]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


@dataclass
class _Job:
    """Bookkeeping for one in-flight calculation."""

    token: CancelToken
    task: asyncio.Task[None]


class CalcRunner:
    """Manages at-most-one background calculation per project.

    * ``set_compute(fn)`` — register the (sync) compute function.
    * ``set_delivery(fn)`` — register the async delivery callback.
    * ``trigger(org_id, pid, project)`` — cancel previous & start new calc.
    """

    def __init__(self) -> None:
        self._jobs: dict[tuple[str, str], _Job] = {}
        self._compute: ComputeFunc | None = None
        self._deliver: DeliveryCallback | None = None

    # -- configuration ------------------------------------------------------

    def set_compute(self, fn: ComputeFunc) -> None:
        """Register the synchronous compute function.

        ``fn(project, cancel_token)`` is called in a worker thread.
        It should return a JSON-serialisable dict on success, or None
        to silently skip (e.g. empty pipenet).  It should call
        ``cancel_token.check()`` periodically and let ``CancelledError``
        propagate.
        """
        self._compute = fn

    def set_delivery(self, fn: DeliveryCallback) -> None:
        """Register the async callback that delivers results to clients."""
        self._deliver = fn

    # -- public API ---------------------------------------------------------

    async def trigger(self, org_id: str, project_id: str, project: Project) -> None:
        """Cancel any running calc for this project and start a fresh one.

        Safe to call from the async event loop.  The actual computation
        runs in ``asyncio.to_thread`` on a deep-copied snapshot of the
        project so it is fully isolated from later mutations.
        """
        if self._compute is None:
            return  # no compute function registered yet

        key = (org_id, project_id)

        # Snapshot before handing off to the worker thread — avoids
        # races with subsequent sync mutations without any locking.
        project = copy.deepcopy(project)

        # Cancel existing job (if any)
        old = self._jobs.pop(key, None)
        if old is not None:
            old.token.cancel()
            old.task.cancel()
            logger.debug("calc: cancelled previous job for %s/%s", org_id, project_id)

        # Create new cancellation token and launch
        token = CancelToken()
        task = asyncio.create_task(
            self._run(org_id, project_id, project, token),
            name=f"calc:{org_id}/{project_id}",
        )
        self._jobs[key] = _Job(token=token, task=task)

    def is_running(self, org_id: str, project_id: str) -> bool:
        """Return True if a calculation is currently in-flight for this project."""
        return (org_id, project_id) in self._jobs

    async def cancel(self, org_id: str, project_id: str) -> None:
        """Cancel a running calculation (e.g. on project deletion)."""
        key = (org_id, project_id)
        old = self._jobs.pop(key, None)
        if old is not None:
            old.token.cancel()
            old.task.cancel()

    # -- internals ----------------------------------------------------------

    async def _run(
        self,
        org_id: str,
        project_id: str,
        project: Project,
        token: CancelToken,
    ) -> None:
        """Execute the compute function in a thread and deliver the result."""
        assert self._compute is not None
        key = (org_id, project_id)
        try:
            result_data = await asyncio.to_thread(self._compute, project, token)
        except CancelledError:
            logger.debug("calc: job cancelled for %s/%s", org_id, project_id)
            return
        except asyncio.CancelledError:
            logger.debug("calc: task cancelled for %s/%s", org_id, project_id)
            return
        except Exception:
            logger.exception("calc: error computing %s/%s", org_id, project_id)
            return
        finally:
            # Remove from active jobs (only if we are still the current job)
            current = self._jobs.get(key)
            if current is not None and current.token is token:
                del self._jobs[key]

        if token.is_cancelled:
            return  # result is stale

        if result_data is None:
            return  # nothing to deliver (e.g. empty pipenet)

        # Deliver
        if self._deliver is not None:
            try:
                await self._deliver(
                    CalcResult(
                        org_id=org_id,
                        project_id=project_id,
                        data=result_data,
                    )
                )
            except Exception:
                logger.exception("calc: delivery failed for %s/%s", org_id, project_id)


# Module-level singleton — imported by sync.py
calc_runner = CalcRunner()
