"""Startup configuration box formatting utilities."""

import os
from sys import stderr

from jacloud._version import __version__

BOX_WIDTH = 60  # Inner width (excluding box chars)


def line(text: str = "") -> str:
    """Format a line inside the box with proper padding, truncating if needed."""
    if len(text) > BOX_WIDTH:
        text = text[: BOX_WIDTH - 1] + "…"
    return f"┃ {text:<{BOX_WIDTH}} ┃\n"


def top() -> str:
    return "┏" + "━" * (BOX_WIDTH + 2) + "┓\n"


def bottom() -> str:
    return "┗" + "━" * (BOX_WIDTH + 2) + "┛\n"


def print_startup_config(endpoints: list[dict]) -> None:
    """Print server configuration on startup."""
    # Format listen address
    if len(endpoints) == 1:
        ep = endpoints[0]
        if "uds" in ep:
            listen = f"unix:{ep['uds']}"
        else:
            listen = f"http://{ep['host']}:{ep['port']}"
    else:
        # Multiple endpoints (e.g. 0.0.0.0 + [::])
        port = endpoints[0]["port"]
        listen = f"http://0.0.0.0:{port} + [::]:{port}"

    dev_url = os.environ.get("JACLOUD_VITE_URL")
    url = f"{dev_url} (vite)" if dev_url else listen
    lines = [top()]
    lines.append(line("╭●▄▄▄▄▄"))
    lines.append(line("│ █▓█▓█  Jacloud " + __version__))
    lines.append(line("│ █▓█▓█    " + url))
    if dev_url:
        lines.append(line(f"           {listen} (backend)"))
    lines.append(bottom())
    stderr.write("".join(lines))
