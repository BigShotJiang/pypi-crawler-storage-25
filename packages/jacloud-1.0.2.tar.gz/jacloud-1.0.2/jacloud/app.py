import asyncio
import datetime
import logging
import os
from asyncio import get_running_loop
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from email.utils import parsedate_to_datetime
from os import cpu_count
from pathlib import Path
from sys import stderr
from time import perf_counter
from urllib.parse import unquote

import msgspec.json
import tracerite
from blake3 import blake3
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi_vue import Frontend

from jacloud import jacfile
from jacloud import sync as sync_module
from jacloud.__main__ import DEVMODE
from jacloud._version import __version__
from jacloud.fastapi_logging import AccessLogMiddleware, configure_access_logging
from jacloud.migrations import DBVER, MigrationCtx, apply_migrations
from jacloud.preview import process_pdf, process_plan
from jacloud.project import Coords, Plan, Project
from jacloud.sync_logging import configure_sync_logging
from jacloud.util import sanitize_filename

tracerite.patch_fastapi()

logger = logging.getLogger(__name__)
if not logger.handlers:
    logging.basicConfig(
        level=logging.INFO, format="%(levelname)s %(name)s: %(message)s"
    )

configure_access_logging()
configure_sync_logging()

# Vue Frontend static files
frontend = Frontend(
    Path(__file__).with_name("frontend-build"),
    spa=True,
    favicon="/assets/jacloud*.png",
    cached=["/assets/", "/radiators/"],
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage app startup and shutdown resources."""
    # Startup
    if app.debug:
        logging.getLogger("uvicorn").setLevel(logging.INFO)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
    try:
        await frontend.load()
        await asyncio.to_thread(plandir.mkdir, parents=True, exist_ok=True)
    except Exception as e:
        stderr.write(f"🛑 {e}\n")
        os._exit(1)
    try:
        loaded = sync_module.load_projects_from_jsonl()
        logger.info("persistence: loaded %d projects (main app)", loaded)
    except Exception as exc:
        logger.error("persistence: failed in main app startup: %r", exc)
    with ThreadPoolExecutor(max_workers=min(4, cpu_count() or 1)) as executor:
        app.state.threadexec = executor
        yield


app = FastAPI(title="jacloud", lifespan=lifespan, debug=DEVMODE)
app.add_middleware(AccessLogMiddleware)
JACONI_MAGIC = b"JAC File"

plandir: Path = sync_module.DATA_DIR / "plans"
by_name_dir: Path = sync_module.DATA_DIR / "by-name" / "plans"

app.mount("/api/ws", sync_module.app)


@app.get("/auth/api/validate")
async def validate_auth():
    """Public access: always return 200 OK to client side verification calls.

    Actual authentication should capture /auth/ for itself such that requests never land here."""
    return {"valid": True}


def _convert_jacloud_payload(filename: str, body: bytes) -> bytes:
    try:
        payload = msgspec.json.decode(body)
    except Exception as exc:
        raise ValueError("Invalid JSON in .jacloud file") from exc

    if not isinstance(payload, dict):
        raise ValueError("Invalid .jacloud payload: expected object")

    data = dict(payload)
    file_version = data.pop("_v", 0)
    if isinstance(file_version, bool) or not isinstance(file_version, int):
        raise ValueError("Invalid .jacloud version: _v must be an integer")
    if file_version < 0:
        raise ValueError("Invalid .jacloud version: _v must be >= 0")
    if file_version > DBVER:
        raise ValueError(
            f"Unsupported .jacloud version {file_version}; server supports up to {DBVER}"
        )

    apply_migrations(
        data,
        MigrationCtx(project_id=filename),
        silent=True,
        version=file_version,
    )
    project = msgspec.convert(data, type=Project, strict=False)
    out = msgspec.to_builtins(project, str_keys=True)
    out.pop("_v", None)
    out.pop("v", None)
    encoded = msgspec.json.encode(out)
    stderr.write(
        f"[project-upload] jacloud {filename} v{file_version} -> v{DBVER} ({len(encoded)} bytes)\n"
    )
    return encoded


def _convert_jac_payload(
    filename: str,
    body: bytes,
    *,
    created: datetime.datetime | None = None,
) -> bytes:
    jac = jacfile.JacLoader(body).jac
    encoded = msgspec.json.encode(jacfile.convert(jac, filename, created=created))
    stderr.write(f"[project-upload] jac {filename} -> {len(encoded)} bytes\n")
    return encoded


def _parse_last_modified_datetime(value: str) -> datetime.datetime:
    value = value.strip()
    if not value:
        raise ValueError(
            "Malformed x-last-modified header; expected ISO 8601 or HTTP-date"
        )

    try:
        dt = datetime.datetime.fromisoformat(value)
    except ValueError as err:
        try:
            dt = parsedate_to_datetime(value)
        except TypeError, ValueError, IndexError, OverflowError:
            raise ValueError(
                "Malformed x-last-modified header; expected ISO 8601 or HTTP-date"
            ) from err

    if dt.tzinfo is None:
        return dt.replace(tzinfo=datetime.UTC)
    return dt.astimezone(datetime.UTC)


@app.post("/api/project/{filename}")
async def create_project(filename: str, request: Request):
    body = await request.body()
    is_jac_magic = body.startswith(JACONI_MAGIC)
    uploaded_last_modified_raw = request.headers.get("x-last-modified")
    try:
        if is_jac_magic:
            created = None
            if uploaded_last_modified_raw is not None:
                created = _parse_last_modified_datetime(uploaded_last_modified_raw)
                stderr.write(
                    f"[project-upload] file-mtime {filename} {created.isoformat()}\n"
                )
            encoded = _convert_jac_payload(filename, body, created=created)
        else:
            encoded = _convert_jacloud_payload(filename, body)
    except Exception as exc:
        return JSONResponse(
            {"detail": f"Project import failed: {exc}"}, status_code=400
        )
    return Response(content=encoded, media_type="application/json")


@app.put("/api/plan/{filename}")
async def create_plan(filename: str, request: Request):
    body = await request.body()
    content_type = request.headers.get("content-type", "")
    try:
        t0 = perf_counter()
        res, converted = await get_running_loop().run_in_executor(
            app.state.threadexec, _create_plan, body, content_type, unquote(filename)
        )
        t1 = perf_counter()
        if converted:
            stderr.write(f"[preview] {filename} -> {res.image} {t1 - t0:.3f}s\n")
        return Response(content=msgspec.json.encode(res), media_type="application/json")
    except ValueError as e:
        return JSONResponse({"detail": str(e)}, status_code=400)
    except Exception as e:
        logger.exception("Error converting plan file %s: %s", filename, e)
        return JSONResponse({"detail": "Internal server error"}, status_code=500)


def _create_plan(
    body: bytes,
    content_type: str,
    filename: str,
) -> tuple[Plan, bool]:
    h = blake3(body).hexdigest(8)
    if content_type == "application/pdf":
        ext = "pdf"
    elif content_type.startswith("image/"):
        ext = content_type.split("/", maxsplit=1)[1]
    else:
        raise ValueError("Unsupported file format / mime type")

    sanitized = sanitize_filename(filename)

    orig_file = plandir.joinpath(f"{h}.{ext}")
    if not orig_file.exists():
        orig_file.write_bytes(body)
        # Create symlink for original file immediately
        if sanitized:
            by_name_dir.mkdir(parents=True, exist_ok=True)
            orig_link = by_name_dir / sanitized
            if not orig_link.exists():
                orig_link.symlink_to(orig_file)

    dpi: int = 127
    avif_file = plandir.joinpath(f"{h}.{dpi}.avif")
    converted = not avif_file.exists()
    if converted:
        if content_type == "application/pdf":
            avif_file.write_bytes(process_pdf(orig_file, dpi=dpi))
        else:
            avif_file.write_bytes(process_plan(orig_file, dpi=dpi))
        # Create symlink for AVIF file
        if sanitized:
            stem = Path(sanitized).stem
            avif_link = by_name_dir / f"{stem}.avif"
            if not avif_link.exists():
                avif_link.symlink_to(avif_file)

    return (
        Plan(
            image=f"/api/plan/{h}.{dpi}.avif",
            scale=50,
            pos=Coords(x=0, y=0),
            sort=0.0,
            dpi=dpi,
        ),
        converted,
    )


@app.get("/api/plan/{name}")
async def preview(name: str, request: Request):
    """Preview a file"""
    headers: dict[str, str] = {
        "etag": name,
        "cache-control": "max-age=604800, immutable, private",
        "content-type": "image/avif",
    }
    if request.headers.get("if-none-match") == name:
        # The client has it cached, respond 304 Not Modified
        return Response(status_code=304, headers=headers)

    path = plandir.joinpath(name)
    if not path.is_file():
        # Backwards compatibility for <v0.9.2
        path = plandir.joinpath(f"{name}.127.avif")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(path, headers=headers, media_type="image/avif")


@app.get("/api/version")
async def get_version():
    """Return the backend version"""
    response: dict = {"version": __version__}
    if app.debug:
        response["dev"] = True
    return response


frontend.route(app, "/")
