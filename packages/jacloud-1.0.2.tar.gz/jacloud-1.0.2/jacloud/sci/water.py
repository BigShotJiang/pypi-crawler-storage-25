from __future__ import annotations

from .core import g

c = 4180.0  # J/kgK


def power(flow, dt):
    """Power transferred by water flow with a given temperature difference."""
    return c * flow * dt


def mix(x, y, p):
    """Generic blend equation. p for proportion 0 = all x, 1 = all y."""
    return x + (y - x) * p


def density(celsius):
    """Approximate kg/m^3 at 1 atm (very little difference with much higher pressures)"""
    return 1e3 * (1.0 - (celsius / 580.0) ** 1.8)


def hydrostatic(celsius, height):
    return density(celsius) * g * height


class Pressure:
    @staticmethod
    def from_bar(value) -> Pressure:
        return Pressure(1e5 * value)

    @staticmethod
    def from_kPa(value) -> Pressure:
        return Pressure(1e3 * value)

    def __init__(self, pascals=0.0):
        self.pascals = float(pascals)

    def __str__(self):
        return f"{self.kPa:.1f} kPa"

    def __repr__(self):
        return f"Pressure({self.pascals:.0f})"

    @property
    def bar(self) -> float:
        return 1e-5 * self.pascals

    @property
    def kPa(self) -> float:
        return 1e-3 * self.pascals

    def flow(self, kv: Kv) -> Flow:
        return kv.flow(self)

    def __add__(self, other: Pressure) -> Pressure:
        return Pressure(self.pascals + other.pascals)

    def __sub__(self, other: Pressure) -> Pressure:
        return Pressure(self.pascals - other.pascals)

    def __mul__(self, k: float) -> Pressure:
        return Pressure(k * self.pascals)


class Flow:
    @staticmethod
    def from_cubic(value) -> Flow:
        return Flow(value / 3.6)

    @staticmethod
    def from_lph(value) -> Flow:
        return Flow(value / 3600.0)

    def __init__(self, lps=0.0):
        self.lps = float(lps)

    def __str__(self):
        return f"{self.lph:.0f} l/h"

    def __repr__(self):
        return f"Flow({self.lps:.4f})"

    @property
    def cubic(self) -> float:
        return 3.6 * self.lps

    @property
    def lph(self) -> float:
        return 3600.0 * self.lps

    def pressure(self, kv: Kv) -> Pressure:
        return kv.pressure(self)

    def __add__(self, other: Flow) -> Flow:
        return Flow(self.lps + other.lps)

    def __sub__(self, other: Flow) -> Flow:
        return Flow(self.lps - other.lps)


class Kv:
    @staticmethod
    def calc(flow: Flow, dp: Pressure, n=2.0) -> Kv:
        return Kv(flow.cubic / dp.bar ** (1 / n), n=n)

    def __init__(self, kv: float, n=2.0):
        self.kv = kv
        self.n = n

    def __str__(self):
        return f"{self.kv:.3f}"

    def __repr__(self):
        return f"Kv({self!s})"

    def flow(self, dp: Pressure) -> Flow:
        return Flow.from_cubic(self.kv * dp.bar ** (1 / self.n))

    def pressure(self, flow: Flow) -> Pressure:
        return Pressure.from_bar((flow.cubic / self.kv) ** self.n)
