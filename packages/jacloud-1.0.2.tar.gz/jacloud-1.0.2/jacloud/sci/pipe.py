"""Pipe heat transfer calculations.

Port of the C++ jaconi Pipe::getOutTemp method for calculating
pipe outlet temperature after heat loss during flow simulation.

All lengths and diameters are in mm to match the rest of the application.
"""

from __future__ import annotations

import math
from typing import NamedTuple

from . import water
from .pipetable import Material, pipetypes

# Insulation suffixes (matching project.py)
INS_SUFFIX = " Ins"
LIGHT_INS_SUFFIX = " InsL"


class TempAndFlow(NamedTuple):
    """Temperature and flow rate pair."""

    temperature: float  # °C
    flow: float  # kg/s


def pipe_kv(model: str) -> water.Kv:
    """Get Kv for a pipe model, using material-specific exponents."""
    dp_r, flow_r, _diam, material = pipetypes[model]
    n = 1.8 if material == Material.PLASTIC else 1.9
    return water.Kv.calc(water.Flow(flow_r), water.Pressure(dp_r), n=n)


def resistance(model: str, length: float, flow: water.Flow) -> water.Pressure:
    """Pressure drop for flow through a pipe segment.

    Args:
        model: Pipe type name (e.g. "DN 15", "Cu 22", "Upo 20")
        length: Pipe length in mm
        flow: Water flow rate

    Returns:
        Pressure drop
    """
    kv = pipe_kv(model)
    # dp_r is Pa/m, so convert length from mm to m
    return flow.pressure(kv) * (length / 1000)


def hydrostatic(temperature: float, height: float) -> water.Pressure:
    """Hydrostatic pressure from water column.

    Args:
        temperature: Water temperature (°C)
        height: Height difference (m), positive = upward

    Returns:
        Hydrostatic pressure (positive for upward flow against gravity)
    """
    return water.hydrostatic(temperature, height)


def parse_kind(kind: str) -> tuple[str, str]:
    """Parse pipe kind string into base type and insulation suffix.

    Returns:
        Tuple of (base_type, insulation) where insulation is:
        - "" for uninsulated
        - "Ins" for fully insulated
        - "InsL" for lightly insulated
    """
    if kind.endswith(INS_SUFFIX):
        return kind.removesuffix(INS_SUFFIX), "Ins"
    if kind.endswith(LIGHT_INS_SUFFIX):
        return kind.removesuffix(LIGHT_INS_SUFFIX), "InsL"
    return kind, ""


def _get_alpha(
    theta: float,
    material: Material,
    diam_mm: float,
    vertical: bool,
) -> float:
    """Calculate heat transfer coefficient for uninsulated pipes (W/m²K).

    Args:
        theta: Temperature difference from environment (°C)
        material: Pipe material (affects emissivity)
        diam_mm: Outer diameter (mm)
        vertical: True if pipe is vertical, False if horizontal

    Returns:
        Heat transfer coefficient (W/m²K)
    """
    # Emissivity based on material
    emissivity = 0.9 if material == Material.PLASTIC else 0.8

    # Radiation: W/(m²K)
    # Approximation good enough for heating calculations
    hr = 5.7 * emissivity * (1.0 + 0.006 * theta)

    # Convection: depends on pipe orientation
    # Formula expects diameter in meters
    delta_t = abs(theta)
    diam_m = diam_mm / 1000
    if vertical:
        hc = 1.3 * math.pow(delta_t, 1.0 / 3.0)
    else:  # Horizontal
        hc = 1.3 * math.pow(delta_t / diam_m, 0.25)

    return hr + hc


def _insulated_theta(
    theta1: float,
    flow: float,
    length_mm: float,
    d_pipe: float,
    d_insulation: float,
) -> float:
    """Calculate outlet theta for insulated pipe.

    Uses cylindrical heat conduction model through insulation layer.

    Args:
        theta1: Inlet temperature difference from environment (°C)
        flow: Mass flow rate (kg/s)
        length_mm: Pipe length (mm)
        d_pipe: Pipe outer diameter (mm)
        d_insulation: Insulation outer diameter (mm)

    Returns:
        Outlet theta (°C)
    """
    k = 0.04  # Thermal conductivity of insulation (W/mK)
    # Ratio is dimensionless, units cancel
    K_per_length = math.tau * k / math.log(d_insulation / d_pipe)
    # K_per_length is W/mK, length must be in m
    length_m = length_mm / 1000
    K_total = K_per_length * length_m
    return theta1 * math.exp(-K_total / (flow * water.c))


def _convection_theta(
    theta1: float,
    flow: float,
    length_mm: float,
    material: Material,
    diam_mm: float,
    vertical: bool,
) -> float:
    """Calculate outlet theta for uninsulated pipe via surface convection.

    Args:
        theta1: Inlet temperature difference from environment (°C)
        flow: Mass flow rate (kg/s)
        length_mm: Pipe length (mm)
        material: Pipe material
        diam_mm: Outer diameter (mm)
        vertical: True if pipe is vertical

    Returns:
        Outlet theta (°C)
    """
    # Convert to meters for surface area calculation
    diam_m = diam_mm / 1000
    length_m = length_mm / 1000
    surf_area = math.pi * diam_m * length_m
    thermal_capacity = flow * water.c
    alpha = _get_alpha(theta1, material, diam_mm, vertical)
    return theta1 * math.exp(-surf_area * alpha / thermal_capacity)


def get_out_temp(
    inlet_temp: float,
    flow: float,
    length: float,
    kind: str,
    *,
    env_temp: float = 20.0,
    vertical: bool = False,
) -> float:
    """Calculate pipe outlet temperature after heat loss.

    Args:
        inlet_temp: Inlet water temperature (°C)
        flow: Mass flow rate (kg/s)
        length: Pipe length (mm)
        kind: Pipe type string, optionally with " Ins" or " LIns" suffix
        env_temp: Environment temperature (°C)
        vertical: True if pipe is vertical, False if horizontal

    Returns:
        Outlet temperature (°C)
    """
    pipe_type, insulation = parse_kind(kind)

    if pipe_type not in pipetypes:
        raise ValueError(f"Unknown pipe type: {pipe_type}")

    _, _, d_pipe, material = pipetypes[pipe_type]
    theta1 = inlet_temp - env_temp

    # Full insulation: thickness scales with pipe size per European standards, min 30mm
    if insulation == "Ins":
        d_insulation = d_pipe + max(60, d_pipe)
        theta2 = _insulated_theta(theta1, flow, length, d_pipe, d_insulation)
        return env_temp + theta2

    # Light insulation: fixed 20mm thickness (plastic pipes always run in insulation)
    if insulation == "InsL" or material == Material.PLASTIC:
        d_insulation = d_pipe + 40
        theta2 = _insulated_theta(theta1, flow, length, d_pipe, d_insulation)
        return env_temp + theta2

    # Surface convection model for uninsulated metal pipes
    theta2 = _convection_theta(theta1, flow, length, material, d_pipe, vertical)
    return env_temp + theta2
