"""Hardy-Cross iterative solver for hydraulic networks.

Implements the Hardy-Cross method for computing steady-state flows
in pipe networks.  The solver adjusts flows around independent cycles
until pressure balance is achieved in each cycle.

The algorithm relies on:
- Cycle matrix C[num_cycles, num_branches]
- Flow arrays (flows, resistances, exponents, head sources)

Pressure drop model: dp = k * sign(Q) * |Q|^n  (turbulent flow)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from scipy import sparse

# ---------------------------------------------------------------------------
# Numerical stability constants
# ---------------------------------------------------------------------------

_MIN_FLOW_ABS: float = 1e-8  # Minimum |Q| for derivative calculation (l/s)
_MAX_FLOW_ABS: float = 100.0  # Maximum allowed |Q| to prevent runaway (l/s)
_MAX_CORRECTION: float = 0.1  # Maximum per-iteration flow correction (l/s)


# ---------------------------------------------------------------------------
# Flow arrays
# ---------------------------------------------------------------------------


@dataclass
class FlowArrays:
    """Numpy arrays for vectorized Hardy-Cross calculation.

    All arrays indexed by branch index (matching cycle matrix columns).
    """

    flows: np.ndarray  # [num_branches] current flow (l/s)
    resistance: np.ndarray  # [num_branches] k: dp = k * |Q|^n
    exponent: np.ndarray  # [num_branches] n: flow exponent (1.8-2.0)
    head: (
        np.ndarray
    )  # [num_branches] constant pressure source (Pa, positive = produces)


# ---------------------------------------------------------------------------
# Hardy-Cross solver
# ---------------------------------------------------------------------------


def hardy_cross_iteration(
    cycle_matrix: sparse.csr_matrix, arrays: FlowArrays, damping: float = 0.5
) -> float:
    """Perform one Hardy-Cross iteration.

    For each cycle, the pressure equation around the loop must sum to zero:
        Σ (k_i * sign(Q_i) * |Q_i|^n_i * dir_i) - Σ (head_i * dir_i) = 0

    The head term is subtracted because a positive head *opposes* the
    pressure drop (pump produces pressure, pipe consumes it).

    Args:
        cycle_matrix: Sparse cycle matrix C[num_cycles, num_branches].
            +1 for branches traversed in their natural direction,
            -1 for branches traversed opposite.
        arrays: FlowArrays containing flows, resistance, exponent, head.
        damping: Damping factor (0-1) for stability.

    Updates flows in-place. Returns max absolute residual (Pa).
    """
    Q = arrays.flows.astype(np.float64)  # Ensure float64
    k = arrays.resistance.astype(np.float64)
    n = arrays.exponent.astype(np.float64)
    h = arrays.head.astype(np.float64)
    C = cycle_matrix

    # Use a minimum flow magnitude for derivative stability
    Q_abs = np.maximum(np.abs(Q), _MIN_FLOW_ABS)

    # Pressure drop per branch: dp = k * sign(Q) * |Q|^n  (signed, turbulent)
    dp = k * np.sign(Q) * np.power(Q_abs, n)

    # Net pressure per branch: drop minus head source
    net_dp = dp - h

    # Loop residuals: Σ around each cycle (should be zero)
    residuals = C @ net_dp  # [num_cycles]

    # Derivative of dp w.r.t. Q: d(dp)/dQ = n * k * |Q|^(n-1)
    # Use the stabilized Q_abs to prevent division issues
    ddp = n * k * np.power(Q_abs, n - 1)

    # Sum of |derivatives| around each cycle
    # C.power(2) gives element-wise squared (turns ±1 into 1)
    loop_ddp = C.power(2) @ ddp  # [num_cycles]

    # Ensure minimum denominator for numerical stability
    loop_ddp = np.maximum(loop_ddp, 1.0)

    # Flow correction per cycle
    corrections = -residuals / loop_ddp

    # Clip corrections to prevent explosive changes
    corrections = np.clip(corrections, -_MAX_CORRECTION, _MAX_CORRECTION)

    # Distribute corrections to branches
    flow_delta = C.T @ corrections  # [num_branches]

    # Apply damped correction
    arrays.flows = (Q + damping * flow_delta).astype(np.float64)

    # Clip flows to prevent runaway values
    arrays.flows = np.clip(arrays.flows, -_MAX_FLOW_ABS, _MAX_FLOW_ABS)

    if residuals.size == 0:
        return 0.0
    return float(np.max(np.abs(residuals)))


def solve_hardy_cross(
    cycle_matrix: sparse.csr_matrix,
    arrays: FlowArrays,
    max_iterations: int = 1000,
    tolerance: float = 50.0,
    initial_damping: float = 0.15,
) -> int:
    """Run Hardy-Cross iterations to convergence.

    Args:
        cycle_matrix: Sparse cycle matrix C[num_cycles, num_branches].
        arrays: FlowArrays with initial flows satisfying mass balance.
        max_iterations: Maximum iteration count.
        tolerance: Convergence threshold on max residual (Pa). Default 100 Pa.
        initial_damping: Starting damping factor (0-1) for stability.

    Returns:
        Number of iterations performed.

    The ``arrays.flows`` are updated in-place with the converged solution.
    """
    damping = initial_damping
    prev_residual = float("inf")

    for iteration in range(max_iterations):
        residual = hardy_cross_iteration(cycle_matrix, arrays, damping)

        if residual < tolerance:
            return iteration + 1

        # If residual increases significantly, reduce damping for stability
        if residual > prev_residual * 1.2:
            damping = max(0.05, damping * 0.8)

        prev_residual = residual

    return max_iterations
