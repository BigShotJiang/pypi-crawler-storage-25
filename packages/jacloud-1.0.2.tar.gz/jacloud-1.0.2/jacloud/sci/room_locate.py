"""
Determine which building face (room/zone) a given (x, y) point belongs to.

Uses the planar subdivision of each building's boundary, holes, and inner
walls to identify enclosed faces, then performs point-in-face tests.
Also provides pipe splitting at room boundaries.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from jacloud.sci.subdivide import Point, SubdivisionResult, point_in_face, subdivide

if TYPE_CHECKING:
    from jacloud.project import Building, Project


@dataclass
class RoomHit:
    """Result of a point-in-room query."""

    building_id: str
    face_index: int  # index into SubdivisionResult.faces


def _is_building_closed(building: Building) -> bool:
    """Check if a building's boundary forms a closed loop."""
    route = building.route()
    return len(route) >= 4 and route[0] == route[-1]


def _point_on_ring(px: float, py: float, ring: list[Point], snap: float = 50) -> bool:
    """Check if point lies on any vertex or edge of a closed ring."""
    import math

    n = len(ring)
    for i in range(n):
        a = ring[i]
        b = ring[(i + 1) % n]
        if math.hypot(a.x - px, a.y - py) < snap:
            return True
        dx = b.x - a.x
        dy = b.y - a.y
        len_sq = dx * dx + dy * dy
        if len_sq < 1:
            continue
        t = ((px - a.x) * dx + (py - a.y) * dy) / len_sq
        if t <= 0.01 or t >= 0.99:
            continue
        cx = a.x + t * dx
        cy = a.y + t * dy
        if math.hypot(px - cx, py - cy) < snap:
            return True
    return False


def subdivide_building(
    building: Building,
    all_buildings: dict[str, Building] | None = None,
) -> SubdivisionResult:
    """Subdivide a building into faces using its boundary, holes, and inners.

    When *all_buildings* is provided, open buildings on the same plan whose
    both endpoints touch this building's boundary or holes are included as
    extra inner divider chains.
    """
    verts = building.vertices
    boundary_ids = building.route()
    boundary = [
        Point(verts[vid].x, verts[vid].y) for vid in boundary_ids if vid in verts
    ]
    if len(boundary) < 3:
        return SubdivisionResult(vertices=[], faces=[])

    holes: list[list[Point]] = []
    for hole in building.holes.values():
        hole_ids = hole.route()
        pts = [Point(verts[vid].x, verts[vid].y) for vid in hole_ids if vid in verts]
        if len(pts) >= 3:
            holes.append(pts)

    dividers: list[list[Point]] = []
    for inner in building.inners.values():
        inner_ids = inner.route()
        pts = [Point(verts[vid].x, verts[vid].y) for vid in inner_ids if vid in verts]
        if len(pts) >= 2:
            dividers.append(pts)

    # Open buildings on same plan whose endpoints touch boundary/holes
    if all_buildings:
        for other in all_buildings.values():
            if other is building:
                continue
            if other.plan != building.plan:
                continue
            if _is_building_closed(other):
                continue
            oroute = other.route()
            opts = [
                Point(other.vertices[vid].x, other.vertices[vid].y)
                for vid in oroute
                if vid in other.vertices
            ]
            if len(opts) < 2:
                continue
            first, last = opts[0], opts[-1]
            rings = [boundary, *holes]
            first_ok = any(_point_on_ring(first.x, first.y, r) for r in rings)
            last_ok = any(_point_on_ring(last.x, last.y, r) for r in rings)
            if first_ok and last_ok:
                dividers.append(opts)

    return subdivide(boundary, dividers, holes)


def point_in_room(
    project: Project,
    x: float,
    y: float,
    plan_id: str | None = None,
    cache: dict[str, SubdivisionResult] | None = None,
) -> RoomHit | None:
    """Find which building face contains the point (x, y).

    Args:
        project: The project containing buildings.
        x: X coordinate in mm.
        y: Y coordinate in mm.
        plan_id: If given, only consider buildings on this plan.
        cache: Optional dict mapping building_id → SubdivisionResult to
            avoid recomputing subdivision for repeated queries.

    Returns:
        RoomHit with building_id and face_index, or None if the point
        is not inside any building face.
    """
    for bid, building in project.buildings.items():
        if plan_id is not None and building.plan != plan_id:
            continue

        if cache is not None and bid in cache:
            result = cache[bid]
        else:
            result = subdivide_building(building, project.buildings)
            if cache is not None:
                cache[bid] = result

        for fi, face in enumerate(result.faces):
            if point_in_face(x, y, face.ring, result.vertices):
                return RoomHit(building_id=bid, face_index=fi)

    return None


def classify_nodes(
    project: Project,
    plan_id: str,
    node_ids: list[str],
    cache: dict[str, SubdivisionResult] | None = None,
) -> dict[str, RoomHit | None]:
    """Classify a set of pipe nodes by which building face they belong to.

    Returns a dict mapping node_id → RoomHit (or None if outside all faces).
    """
    if cache is None:
        cache = {}
    pn = project.pipenet
    result: dict[str, RoomHit | None] = {}
    for nid in node_ids:
        node = pn.nodes.get(nid)
        if node is None:
            result[nid] = None
            continue
        result[nid] = point_in_room(project, node.x, node.y, plan_id, cache)
    return result


# ── Boundary edges for a plan ────────────────────────────────────────


@dataclass
class BoundaryEdge:
    """An edge from building boundary, hole, or inner wall."""

    x1: float
    y1: float
    x2: float
    y2: float


def _collect_boundary_edges(project: Project, plan_id: str) -> list[BoundaryEdge]:
    """Collect all boundary/hole/inner edges for buildings on a plan."""
    edges: list[BoundaryEdge] = []
    for building in project.buildings.values():
        if building.plan != plan_id:
            continue
        verts = building.vertices

        # Outer boundary edges
        route = building.route()
        for i in range(len(route) - 1):
            va = verts.get(route[i])
            vb = verts.get(route[i + 1])
            if va and vb:
                edges.append(BoundaryEdge(va.x, va.y, vb.x, vb.y))

        # Hole edges
        for hole in building.holes.values():
            hroute = hole.route()
            for i in range(len(hroute) - 1):
                va = verts.get(hroute[i])
                vb = verts.get(hroute[i + 1])
                if va and vb:
                    edges.append(BoundaryEdge(va.x, va.y, vb.x, vb.y))

        # Inner wall edges
        for inner in building.inners.values():
            iroute = inner.route()
            for i in range(len(iroute) - 1):
                va = verts.get(iroute[i])
                vb = verts.get(iroute[i + 1])
                if va and vb:
                    edges.append(BoundaryEdge(va.x, va.y, vb.x, vb.y))

    return edges


def _seg_seg_intersect(
    ax1: float,
    ay1: float,
    ax2: float,
    ay2: float,
    bx1: float,
    by1: float,
    bx2: float,
    by2: float,
) -> float | None:
    """Return parameter t along segment A where it crosses segment B.

    Returns None if no interior crossing (endpoints excluded).
    """
    dx1 = ax2 - ax1
    dy1 = ay2 - ay1
    dx2 = bx2 - bx1
    dy2 = by2 - by1
    det = dx1 * dy2 - dy1 * dx2
    if abs(det) < 1e-6:
        return None  # parallel
    t = ((bx1 - ax1) * dy2 - (by1 - ay1) * dx2) / det
    u = ((bx1 - ax1) * dy1 - (by1 - ay1) * dx1) / det
    # Strict interior: exclude exact endpoints to avoid splitting at nodes
    # that already sit on a boundary
    if 0.001 < t < 0.999 and 0.001 < u < 0.999:
        return t
    return None


# ── Pipe splitting ───────────────────────────────────────────────────


@dataclass
class SplitPoint:
    """A point where a pipe segment crosses a room boundary."""

    t: float  # parameter along the pipe segment (0..1)
    x: float  # crossing x coordinate (mm)
    y: float  # crossing y coordinate (mm)


def find_segment_splits(
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    boundary_edges: list[BoundaryEdge],
) -> list[SplitPoint]:
    """Find all crossing points of a pipe segment with boundary edges.

    Returns split points sorted by parameter t.
    """
    splits: list[SplitPoint] = []
    for edge in boundary_edges:
        t = _seg_seg_intersect(x1, y1, x2, y2, edge.x1, edge.y1, edge.x2, edge.y2)
        if t is not None:
            sx = x1 + t * (x2 - x1)
            sy = y1 + t * (y2 - y1)
            # Deduplicate crossings at nearly the same t
            if not any(abs(sp.t - t) < 0.001 for sp in splits):
                splits.append(SplitPoint(t=t, x=sx, y=sy))
    splits.sort(key=lambda sp: sp.t)
    return splits


@dataclass
class PipeSplitResult:
    """Result of splitting pipes at room boundaries."""

    pipe_id: str
    segment_index: int  # which segment (0-based) in the pipe's route
    node_a: str  # original start node
    node_b: str  # original end node
    split_points: list[SplitPoint]


def find_pipe_splits(
    project: Project,
    plan_id: str,
) -> list[PipeSplitResult]:
    """Find all pipe segments that cross room boundaries on a plan.

    Returns a list of PipeSplitResult for each segment that needs splitting.
    Only segments with at least one crossing point are included.
    """
    boundary_edges = _collect_boundary_edges(project, plan_id)
    if not boundary_edges:
        return []

    pn = project.pipenet
    results: list[PipeSplitResult] = []

    for pid, pipe in pn.pipes.items():
        # Only consider pipes on this floor
        if plan_id not in pipe.floors:
            continue

        route = pipe.route()
        for si in range(len(route) - 1):
            na, nb = route[si], route[si + 1]
            node_a = pn.nodes.get(na)
            node_b = pn.nodes.get(nb)
            if node_a is None or node_b is None:
                continue

            splits = find_segment_splits(
                node_a.x,
                node_a.y,
                node_b.x,
                node_b.y,
                boundary_edges,
            )
            if splits:
                results.append(
                    PipeSplitResult(
                        pipe_id=pid,
                        segment_index=si,
                        node_a=na,
                        node_b=nb,
                        split_points=splits,
                    )
                )

    return results
