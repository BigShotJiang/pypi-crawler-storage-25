"""Wall-based room heat loss from building geometry.

Computes per-face heat loss for each subdivided building and sizes
PlanRadiators assigned to each face.  The output format is compatible
with the old ``compile_room`` / ``_room_calc_to_dict`` pipeline so
that ``_compile_rooms`` and ``_extract_results`` can consume it
without changes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from jacloud.sci.radiator import (
    emit_power,
    radiator_calculate,
    radiator_calculate_for_theta2,
    radiator_find,
    theta2_for_flow,
)
from jacloud.sci.radvalve import radvalve
from jacloud.sci.room_locate import subdivide_building
from jacloud.sci.subdivide import point_in_face
from jacloud.sci.water import Flow, Kv, Pressure

if TYPE_CHECKING:
    from jacloud.project import Project

VENTILATION_FACTOR = 0.005


def _missing_height_error() -> dict[str, Any]:
    """Return a room-parser-compatible missing-height error entry."""
    return {
        "line": 0,
        "col": 0,
        "length": 1,
        "message": "Height missing",
    }


# ---------------------------------------------------------------------------
# Shared heat-loss helpers (used by both building-geometry and manual rooms)
# ---------------------------------------------------------------------------


def _finalize_heat_loss(
    power_surfaces: float,
    ventilation_ua: float,
    total_area: float,
    vent_rate: float,
    intheat_rate: float,
    t_outdoor: float,
    t_env: float,
    extra_power: float = 0.0,
) -> tuple[float, float, float, float]:
    """Compute ventilation + internal heat and total room power.

    *total_area* is the reference area for internal heat gains: polygon
    area for building-geometry rooms, sum of surface areas for manual rooms.

    Returns ``(ventilation, power_ventilation, power_internal, total_power)``.
    """
    ventilation = ventilation_ua * VENTILATION_FACTOR * vent_rate
    power_ventilation = 1.2 * ventilation * (t_outdoor - t_env)
    power_internal = 0.04 * total_area * intheat_rate
    total_power = power_surfaces + power_internal + power_ventilation + extra_power
    return ventilation, power_ventilation, power_internal, total_power


def _size_one_radiator(
    cond: tuple,
    power_req: float,
    theta1: float,
    dp_rad_pa: float,
    thermostat: bool,
    valve_name: str,
    preset: str,
    room_id: str,
    code: str,
    share: float = 1.0,
) -> dict[str, Any] | None:
    """Size a single radiator: compute valve, flow, temperatures.

    Returns a result dict on success or ``None`` on failure.
    """
    simple = radiator_calculate(cond, power_req, theta1)
    try:
        if preset:
            from jacloud.sci.radvalve import table as valve_table

            vt = valve_table[valve_name]
            kv_idx = vt["ps"].index(preset)
            kv = vt["kv"][kv_idx]
            preset_locked = True
        else:
            kv_want = Kv.calc(Flow(simple["flow"]), Pressure(dp_rad_pa)).kv
            v = radvalve(valve_name, kv_want)
            preset = v["ps"]
            kv = v["kv"]
            preset_locked = False

        flow = Kv(kv).flow(Pressure(dp_rad_pa)).lps
        if (flow > simple["flow"] and not thermostat) or flow < simple["flow"]:
            simple["flow"] = flow
            simple["theta2"] = theta2_for_flow(cond, theta1, flow)
            simple["power"] = emit_power(cond, theta1, simple["theta2"])

        return {
            "room_id": room_id,
            "code": code.lower(),
            "valve": valve_name,
            "theta1": simple["theta1"],
            "theta2": simple["theta2"],
            "flow": simple["flow"],
            "power": simple["power"],
            "p": power_req,
            "share": share,
            "preset": preset,
            "kv": kv,
            "preset_locked": preset_locked,
        }
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Wall segment extraction from timeline
# ---------------------------------------------------------------------------


@dataclass
class _EdgeOpening:
    """An opening (window/door) on a wall edge."""

    offset_frac: float  # center position as fraction along the edge [0..1]
    width: float  # width in mm
    material: str  # surface material key (e.g. "window")
    height_override: str | None = None


@dataclass
class _WallSeg:
    x1: float
    y1: float
    x2: float
    y2: float
    material: str
    openings: list[_EdgeOpening]
    is_divider: bool = False


def _timeline_segments(
    timeline: dict, vertices: dict, *, closed: bool, is_divider: bool = False
) -> list[_WallSeg]:
    """Extract wall segments (with openings) from a building timeline.

    Material events propagate forward: the material active at a node
    position is the most recent ``material`` event at or before that key.

    Openings sitting between two node keys are attached to the corresponding
    wall segment with their fractional offset along the edge.

    *closed*: True for boundary/hole (last node connects back to first).
    """
    sorted_ev = sorted(timeline.items(), key=lambda kv: int(kv[0]))

    nodes: list[tuple[int, str]] = []  # (timeline_key, vertex_id)
    cur_mat = ""
    mat_at: dict[int, str] = {}  # key → cumulative material

    # Collect opening events: (timeline_key, WallOpening)
    opening_events: list[tuple[int, Any]] = []

    for key, ev in sorted_ev:
        k = int(key)
        if ev.material is not None:
            cur_mat = ev.material
        mat_at[k] = cur_mat
        if ev.node is not None:
            nodes.append((k, ev.node))
        if ev.opening is not None and ev.opening.material and ev.opening.width:
            opening_events.append((k, ev.opening))

    segs: list[_WallSeg] = []
    n = len(nodes)
    if n < 2:
        return segs

    count = n if closed else n - 1
    for i in range(count):
        k1, vid1 = nodes[i]
        k2, vid2 = nodes[(i + 1) % n]
        if closed and i == count - 1:
            # Last edge wraps around; effective span needs NODE_SPACING
            from jacloud.project import NODE_SPACING

            k2_eff = k1 + NODE_SPACING
        else:
            k2_eff = k2
        v1 = vertices.get(vid1)
        v2 = vertices.get(vid2)
        if v1 is None or v2 is None:
            continue

        # Gather openings on this edge
        span = k2_eff - k1
        edge_openings: list[_EdgeOpening] = []
        if span > 0:
            for ok, op in opening_events:
                if ok > k1 and ok < k2_eff:
                    frac = (ok - k1) / span
                    edge_openings.append(
                        _EdgeOpening(
                            offset_frac=frac,
                            width=float(op.width),
                            material=op.material,
                            height_override=getattr(op, "height", None),
                        )
                    )

        segs.append(
            _WallSeg(
                v1.x,
                v1.y,
                v2.x,
                v2.y,
                mat_at.get(k1, ""),
                edge_openings,
                is_divider=is_divider,
            )
        )

    return segs


# ---------------------------------------------------------------------------
# Face-edge → wall-segment matching
# ---------------------------------------------------------------------------


def _edge_params_on_segment(
    x1: float, y1: float, x2: float, y2: float, seg: _WallSeg
) -> tuple[float, float] | None:
    """Return endpoint projection params on *seg* if the full edge lies on it.

    This is a topology-style shared-edge attribution: face edge endpoints must
    lie on the same source segment line and project inside segment bounds.
    """
    dx = seg.x2 - seg.x1
    dy = seg.y2 - seg.y1
    len_sq = dx * dx + dy * dy
    if len_sq < 1:
        return None

    seg_len = math.sqrt(len_sq)
    tol_mm = 1.0

    def proj(px: float, py: float) -> tuple[float, float]:
        t = ((px - seg.x1) * dx + (py - seg.y1) * dy) / len_sq
        cx = seg.x1 + t * dx
        cy = seg.y1 + t * dy
        dist = math.sqrt((px - cx) ** 2 + (py - cy) ** 2)
        return t, dist

    t1, d1 = proj(x1, y1)
    t2, d2 = proj(x2, y2)
    tol_t = tol_mm / max(seg_len, 1e-6)
    if d1 > tol_mm or d2 > tol_mm:
        return None
    if t1 < -tol_t or t1 > 1 + tol_t or t2 < -tol_t or t2 > 1 + tol_t:
        return None
    return max(0.0, min(1.0, t1)), max(0.0, min(1.0, t2))


def _match_wall_seg_topological(
    x1: float, y1: float, x2: float, y2: float, segs: list[_WallSeg]
) -> tuple[_WallSeg, float, float] | None:
    """Match a face edge to its source wall segment by shared-edge topology."""
    best: tuple[_WallSeg, float, float] | None = None
    best_span = -1.0
    for seg in segs:
        params = _edge_params_on_segment(x1, y1, x2, y2, seg)
        if params is None:
            continue
        t1, t2 = params
        span = abs(t2 - t1)
        if span > best_span:
            best_span = span
            best = (seg, t1, t2)
    return best


def _openings_for_face_edge(seg: _WallSeg, t1: float, t2: float) -> list[_EdgeOpening]:
    """Return only openings whose centers lie on this face-edge slice.

    When a boundary segment is split across multiple faces, all openings were
    previously applied on each slice. We project the face-edge endpoints onto
    the parent segment and keep only openings whose offset fraction is inside
    that projected interval.
    """
    t_min, t_max = (t1, t2) if t1 <= t2 else (t2, t1)
    eps = 1e-6
    return [
        op for op in seg.openings if (t_min - eps) <= op.offset_frac <= (t_max + eps)
    ]


def _face_is_hole_interior(
    ring: list[int],
    vertices: list,
    hole_rings: list[list[tuple[float, float]]],
) -> bool:
    """Mirror frontend hole-interior face filtering for backend parity."""
    snap = 50.0
    for hole in hole_rings:
        all_on_hole = True
        for vidx in ring:
            v = vertices[vidx]
            vx, vy = v.x, v.y
            on_hole = False
            for i in range(len(hole)):
                ax, ay = hole[i]
                bx, by = hole[(i + 1) % len(hole)]
                if math.hypot(ax - vx, ay - vy) < snap:
                    on_hole = True
                    break
                dx = bx - ax
                dy = by - ay
                len_sq = dx * dx + dy * dy
                if len_sq < 1:
                    continue
                t = ((vx - ax) * dx + (vy - ay) * dy) / len_sq
                if t < -0.01 or t > 1.01:
                    continue
                px = ax + t * dx
                py = ay + t * dy
                if math.hypot(vx - px, vy - py) < snap:
                    on_hole = True
                    break
            if not on_hole:
                all_on_hole = False
                break
        if all_on_hole:
            return True
    return False


# ---------------------------------------------------------------------------
# Floor/ceiling cold-area helpers
# ---------------------------------------------------------------------------


def _compute_uncovered_area(
    ring: list[int],
    vertices: list,
    face_area: float,
    adjacent_faces: list[tuple[list[int], list]],
    grid_step: float = 100.0,
) -> float:
    """Compute the area of *ring* not covered by any polygon in *adjacent_faces*.

    Uses point-sampling on a regular grid.  Returns area in m².
    *face_area* is the known signed area of the face (m²).
    *grid_step* is the sampling resolution in mm (default 100 mm).
    """
    if not adjacent_faces:
        return face_area

    xs = [vertices[i].x for i in ring]
    ys = [vertices[i].y for i in ring]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)

    total_inside = 0
    uncovered_count = 0

    x = min_x + grid_step * 0.5
    while x < max_x:
        y = min_y + grid_step * 0.5
        while y < max_y:
            if point_in_face(x, y, ring, vertices):
                total_inside += 1
                covered = any(
                    point_in_face(x, y, adj_ring, adj_verts)
                    for adj_ring, adj_verts in adjacent_faces
                )
                if not covered:
                    uncovered_count += 1
            y += grid_step
        x += grid_step

    if total_inside == 0:
        return face_area

    return face_area * uncovered_count / total_inside


def _add_horizontal_surface(
    mat_key: str,
    area: float,
    project: Project,
    t_outdoor: float,
    t_env: float,
    surfaces_agg: dict[str, dict[str, Any]],
) -> tuple[float, float]:
    """Add a horizontal surface (floor/ceiling) to *surfaces_agg*.

    Returns ``(power, ua)`` contribution, or ``(0, 0)`` when the
    surface material is not defined.
    """
    surf = project.surfaces.get(mat_key)
    if surf is None or area <= 0:
        return 0.0, 0.0
    u = float(surf.u)
    t = float(surf.t) if surf.t not in (None, "", "0") else t_outdoor
    power = u * area * (t - t_env)
    ua = u * area
    if mat_key in surfaces_agg:
        surfaces_agg[mat_key]["area"] += area
        surfaces_agg[mat_key]["power"] += power
    else:
        surfaces_agg[mat_key] = {"material": mat_key, "area": area, "power": power}
    return power, ua


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def compile_building_rooms(
    project: Project,
    room_t_supply: dict[str, float] | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Compute room heat loss from building faces and size PlanRadiators.

    For each building the boundary/hole/inner walls are subdivided into
    faces.  Each face edge is matched back to the original wall segment
    to recover its material and U-value.  Heat loss is computed per face
    per floor, and PlanRadiators whose start point falls within a face
    are sized against its power demand.

    Returns:
        ``(rooms_out, rad_face_map)``

        *rooms_out*: ``{face_key: room_calc_dict}`` — same dict shape as
        ``_room_calc_to_dict`` for seamless integration.

        *rad_face_map*: ``{calc_rad_key: face_key}`` — maps each
        ``"rad:<id>:<floor>"`` key to its face room, so that
        ``CalcRadiator.room_id`` can be set accordingly.
    """
    t_env = float(project.t_env)
    t_outdoor = float(project.t_outdoor)
    t_supply_default = float(project.t_supply)
    vent_rate = float(project.ventilation) if project.ventilation else 0.0
    intheat_rate = float(project.intheat or 0)
    dp_rad_pa = float(project.dp_rad) * 1000.0
    thermostat = project.thermostat

    rooms_out: dict[str, dict[str, Any]] = {}
    rad_face_map: dict[str, str] = {}

    # plan → floors
    plan_floors: dict[str, list] = {}
    for f in project.floors:
        if f.plan:
            plan_floors.setdefault(f.plan, []).append(f)

    # ── Pass 1: subdivide all buildings, collect indoor faces per floor ──
    sorted_floors = sorted(project.floors, key=lambda f: float(f.baseHeight))
    floor_order = {f.id: i for i, f in enumerate(sorted_floors)}

    # Indoor face polygons per floor: (ring, vertices) tuples
    floor_indoor_faces: dict[str, list[tuple[list[int], list]]] = {}

    # Cache subdivision results for pass 2
    _bld_cache: list[tuple[str, Any, str, list[_WallSeg], Any, list, list]] = []

    for bid, building in project.buildings.items():
        plan_id = building.plan
        floors = plan_floors.get(plan_id, [])
        if not floors:
            continue

        # --- wall segments with materials ---
        wall_segs: list[_WallSeg] = []
        wall_segs.extend(
            _timeline_segments(building.timeline, building.vertices, closed=True)
        )
        for hole in building.holes.values():
            wall_segs.extend(
                _timeline_segments(hole.timeline, building.vertices, closed=True)
            )
        for inner in building.inners.values():
            wall_segs.extend(
                _timeline_segments(
                    inner.timeline,
                    building.vertices,
                    closed=False,
                    is_divider=True,
                )
            )

        # --- subdivide ---
        subdiv = subdivide_building(building, project.buildings)
        if not subdiv.faces:
            continue

        hole_rings: list[list[tuple[float, float]]] = []
        for hole in building.holes.values():
            pts: list[tuple[float, float]] = []
            for vid in hole.route():
                v = building.vertices.get(vid)
                if v is not None:
                    pts.append((v.x, v.y))
            if len(pts) >= 3:
                hole_rings.append(pts)

        _bld_cache.append(
            (bid, building, plan_id, wall_segs, subdiv, hole_rings, floors)
        )

        # Register valid indoor faces for each floor of this building
        for floor in floors:
            for face in subdiv.faces:
                if not _face_is_hole_interior(face.ring, subdiv.vertices, hole_rings):
                    floor_indoor_faces.setdefault(floor.id, []).append(
                        (face.ring, subdiv.vertices)
                    )

    # ── Pass 2: compute heat loss per face per floor ──
    for bid, _building, plan_id, wall_segs, subdiv, hole_rings, floors in _bld_cache:
        for floor in floors:
            floor_height_m = float(floor.height)  # already in metres
            t_supply = (room_t_supply or {}).get(f"bld:{bid}", t_supply_default)
            theta1 = t_supply - t_env
            errors: list[dict[str, Any]] = []

            # Radiators visible on this floor + plan
            floor_rads: list[tuple[str, Any, str]] = []
            for rad_id, rad in project.radiators.items():
                if (rad.plan or "") != plan_id:
                    continue
                floor_ov = rad.floors.get(floor.id) if rad.floors else None
                if rad.floors is not None and floor_ov is None:
                    # Has explicit floors but this one isn't listed
                    continue
                eff_code = (
                    floor_ov.code if floor_ov and floor_ov.code else None
                ) or rad.code
                floor_rads.append((rad_id, rad, eff_code))

            for fi, face in enumerate(subdiv.faces):
                if _face_is_hole_interior(face.ring, subdiv.vertices, hole_rings):
                    continue
                face_key = f"bld:{bid}:f{fi}:{floor.id}"
                ring = face.ring
                nv = len(ring)

                # ── surface heat loss ──
                power_surfaces = 0.0
                ventilation_ua = 0.0
                surfaces_agg: dict[str, dict[str, Any]] = {}

                for ei in range(nv):
                    v1 = subdiv.vertices[ring[ei]]
                    v2 = subdiv.vertices[ring[(ei + 1) % nv]]
                    edge_len_m = (
                        math.sqrt((v2.x - v1.x) ** 2 + (v2.y - v1.y) ** 2) / 1000.0
                    )

                    match = _match_wall_seg_topological(
                        v1.x, v1.y, v2.x, v2.y, wall_segs
                    )
                    if match is None:
                        continue
                    wseg, edge_t1, edge_t2 = match
                    if wseg.is_divider:
                        # Keep divider geometry for subdivision/splitting only;
                        # exclude from heat-loss and visible surface statistics.
                        continue
                    mat_key = wseg.material
                    surf = project.surfaces.get(mat_key)
                    if surf is None:
                        continue

                    u = float(surf.u)
                    t_surf = (
                        float(surf.t) if surf.t not in (None, "", "0") else t_outdoor
                    )
                    # Full wall area (before opening subtraction)
                    wall_area = edge_len_m * floor_height_m

                    # Subtract openings and add them as separate surfaces
                    opening_area_total = 0.0
                    for op in _openings_for_face_edge(wseg, edge_t1, edge_t2):
                        op_width_m = op.width / 1000.0
                        op_surf = project.surfaces.get(op.material)
                        if op_surf is None:
                            continue
                        raw_height = (
                            op.height_override
                            if op.height_override not in (None, "", "0")
                            else op_surf.default_y
                        )
                        if raw_height in (None, "", "0"):
                            err = _missing_height_error()
                            if err not in errors:
                                errors.append(err)
                            continue
                        try:
                            op_height_m = float(raw_height)
                        except TypeError, ValueError:
                            err = _missing_height_error()
                            if err not in errors:
                                errors.append(err)
                            continue
                        if op_height_m <= 0:
                            err = _missing_height_error()
                            if err not in errors:
                                errors.append(err)
                            continue
                        op_area = op_width_m * op_height_m
                        opening_area_total += op_area
                        op_u = float(op_surf.u)
                        op_t = (
                            float(op_surf.t)
                            if op_surf.t not in (None, "", "0")
                            else t_outdoor
                        )
                        op_power = op_u * op_area * (op_t - t_env)
                        ventilation_ua += op_u * op_area
                        power_surfaces += op_power
                        if op.material in surfaces_agg:
                            surfaces_agg[op.material]["area"] += op_area
                            surfaces_agg[op.material]["power"] += op_power
                        else:
                            surfaces_agg[op.material] = {
                                "material": op.material,
                                "area": op_area,
                                "power": op_power,
                            }

                    # Wall area with openings subtracted
                    area = max(0.0, wall_area - opening_area_total)
                    power = u * area * (t_surf - t_env)

                    ventilation_ua += u * area
                    power_surfaces += power

                    if mat_key in surfaces_agg:
                        surfaces_agg[mat_key]["area"] += area
                        surfaces_agg[mat_key]["power"] += power
                    else:
                        surfaces_agg[mat_key] = {
                            "material": mat_key,
                            "area": area,
                            "power": power,
                        }

                # ── ceiling / floor cold-area heat loss ──
                floor_idx = floor_order.get(floor.id, -1)
                n_floors = len(sorted_floors)

                # Ceiling
                ceiling_area = 0.0
                if floor_idx == n_floors - 1:
                    # Top floor → entire face area is cold ceiling
                    ceiling_area = face.area
                elif floor_idx >= 0 and floor_idx < n_floors - 1:
                    above = sorted_floors[floor_idx + 1]
                    adj_indoor = floor_indoor_faces.get(above.id, [])
                    if not adj_indoor:
                        # Floor above has no buildings → no ceiling loss
                        ceiling_area = 0.0
                    elif above.plan == floor.plan:
                        # Same plan → same buildings → fully covered
                        ceiling_area = 0.0
                    else:
                        ceiling_area = _compute_uncovered_area(
                            ring, subdiv.vertices, face.area, adj_indoor
                        )

                # Floor
                cold_floor_area = 0.0
                if floor_idx == 0:
                    # Bottom floor → entire face area is cold floor
                    cold_floor_area = face.area
                elif floor_idx > 0:
                    below = sorted_floors[floor_idx - 1]
                    adj_indoor = floor_indoor_faces.get(below.id, [])
                    if not adj_indoor:
                        # Floor below has no buildings → no floor loss
                        cold_floor_area = 0.0
                    elif below.plan == floor.plan:
                        cold_floor_area = 0.0
                    else:
                        cold_floor_area = _compute_uncovered_area(
                            ring, subdiv.vertices, face.area, adj_indoor
                        )

                if ceiling_area > 0:
                    p, ua = _add_horizontal_surface(
                        "ceiling",
                        ceiling_area,
                        project,
                        t_outdoor,
                        t_env,
                        surfaces_agg,
                    )
                    power_surfaces += p
                    ventilation_ua += ua

                if cold_floor_area > 0:
                    floor_mat_key = "foundation" if floor_idx == 0 else "floor"
                    if (
                        floor_mat_key == "foundation"
                        and floor_mat_key not in project.surfaces
                    ):
                        # Backward compatibility for older projects that do not
                        # define foundation separately.
                        floor_mat_key = "floor"
                    p, ua = _add_horizontal_surface(
                        floor_mat_key,
                        cold_floor_area,
                        project,
                        t_outdoor,
                        t_env,
                        surfaces_agg,
                    )
                    power_surfaces += p
                    ventilation_ua += ua

                # ── ventilation + internal ──
                ventilation, power_ventilation, power_internal, total_power = (
                    _finalize_heat_loss(
                        power_surfaces,
                        ventilation_ua,
                        face.area,
                        vent_rate,
                        intheat_rate,
                        t_outdoor,
                        t_env,
                    )
                )

                # ── radiators in this face ──
                rads_in_face: list[tuple[str, Any, str]] = []
                for rad_id, rad, eff_code in floor_rads:
                    if point_in_face(rad.x1, rad.y1, ring, subdiv.vertices):
                        rads_in_face.append((rad_id, rad, eff_code))
                        rad_face_map[f"rad:{rad_id}:{floor.id}"] = face_key

                # ── size radiators ──
                hsum = 0.0
                conductances: list[tuple[str, Any, str, tuple | None]] = []
                for rad_id, rad, code in rads_in_face:
                    cond = radiator_find(code.lower())
                    conductances.append((rad_id, rad, code, cond))
                    if cond:
                        hsum += cond[0]

                sized_rads: list[dict[str, Any]] = []
                for _rad_id, rad, code, cond in conductances:
                    if cond is None:
                        continue

                    valve_name = rad.valve or project.valve
                    share = cond[0] / (hsum + 1e-6)
                    power_req = -total_power * share

                    sized_rad = _size_one_radiator(
                        cond,
                        power_req,
                        theta1,
                        dp_rad_pa,
                        thermostat,
                        valve_name,
                        rad.preset,
                        face_key,
                        code,
                        share,
                    )

                    if sized_rad is not None:
                        sized_rads.append(sized_rad)

                if sized_rads or total_power != 0:
                    rooms_out[face_key] = {
                        "errors": errors,
                        "surfaces": list(surfaces_agg.values()),
                        "conditions": None,
                        "ventilation": ventilation,
                        "power_internal": power_internal,
                        "power_surfaces": power_surfaces,
                        "power_ventilation": power_ventilation,
                        "power": total_power,
                        "radiators": sized_rads,
                        "directives": [],
                    }

    return rooms_out, rad_face_map


# ---------------------------------------------------------------------------
# Manual (Room v2) heat-loss compilation
# ---------------------------------------------------------------------------


def _surface_temp(surf_type, t_outdoor: float) -> float:
    """Resolve exterior temperature for a surface type."""
    if surf_type.t not in (None, "", "0"):
        return float(surf_type.t)
    return t_outdoor


def _resolve_y_m(y_mm: int, surf_type) -> float | None:
    """Resolve the second dimension to metres.

    If *y_mm* is 0, falls back to the surface type's ``default_y``
    (stored as a string in metres).  Returns ``None`` when no valid
    value is available.
    """
    if y_mm:
        return y_mm / 1000.0
    if surf_type.default_y not in (None, "", "0"):
        return float(surf_type.default_y)
    return None


def compile_manual_rooms(
    project: Project,
    room_t_supply: dict[str, float] | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Compute heat loss for manual (Room v2) rooms and size bound radiators.

    PlanRadiators are bound to rooms via :attr:`Radiator.room`.
    Each bound radiator's ``room.millis`` specifies the share of the
    room's total heat demand it handles (1000 = 100%).

    Returns ``(rooms_out, rad_room_map)`` with the same dict shape as
    :func:`compile_building_rooms`.
    """
    t_env = float(project.t_env)
    t_outdoor = float(project.t_outdoor)
    t_supply_default = float(project.t_supply)
    vent_rate = float(project.ventilation) if project.ventilation else 0.0
    intheat_rate = float(project.intheat or 0)
    dp_rad_pa = float(project.dp_rad) * 1000.0
    thermostat = project.thermostat

    rooms_out: dict[str, dict[str, Any]] = {}
    rad_room_map: dict[str, str] = {}  # "rad:id:floor" → room_id

    # Index: room_id → list of (rad_id, Radiator)
    room_rads: dict[str, list[tuple[str, Any]]] = {}
    for rad_id, rad in project.radiators.items():
        if rad.room and rad.room.id:
            room_rads.setdefault(rad.room.id, []).append((rad_id, rad))

    for room_id, room in project.rooms.items():
        if not room.surfaces:
            continue

        t_supply = (room_t_supply or {}).get(room_id, t_supply_default)
        theta1 = t_supply - t_env

        # ── surface heat loss ──
        power_surfaces = 0.0
        ventilation_ua = 0.0
        total_area = 0.0
        surfaces_agg: dict[str, dict[str, Any]] = {}

        for surf in room.surfaces:
            s = project.surfaces.get(surf.material)
            if s is None:
                continue

            u = float(s.u)
            t_surf = _surface_temp(s, t_outdoor)
            x_m = surf.x / 1000.0
            y_m = _resolve_y_m(surf.y, s)
            if y_m is None or y_m <= 0:
                continue
            wall_area = x_m * y_m

            # Subtract openings and add them as separate surfaces
            opening_area_total = 0.0
            for op in surf.openings:
                op_surf = project.surfaces.get(op.material)
                if op_surf is None:
                    continue
                op_width_m = op.width / 1000.0
                op_height_m = _resolve_y_m(op.height, op_surf)
                if op_height_m is None or op_height_m <= 0:
                    continue
                op_area = op_width_m * op_height_m
                opening_area_total += op_area
                op_u = float(op_surf.u)
                op_t = _surface_temp(op_surf, t_outdoor)
                op_power = op_u * op_area * (op_t - t_env)
                ventilation_ua += op_u * op_area
                power_surfaces += op_power
                if op.material in surfaces_agg:
                    surfaces_agg[op.material]["area"] += op_area
                    surfaces_agg[op.material]["power"] += op_power
                else:
                    surfaces_agg[op.material] = {
                        "material": op.material,
                        "area": op_area,
                        "power": op_power,
                    }

            area = max(0.0, wall_area - opening_area_total)
            power = u * area * (t_surf - t_env)
            ventilation_ua += u * area
            total_area += wall_area
            power_surfaces += power

            mat_key = surf.material
            if mat_key in surfaces_agg:
                surfaces_agg[mat_key]["area"] += area
                surfaces_agg[mat_key]["power"] += power
            else:
                surfaces_agg[mat_key] = {
                    "material": mat_key,
                    "area": area,
                    "power": power,
                }

        # ── heat sources ──
        extra_power = 0.0
        for hs in room.heat:
            if hs.power:
                extra_power += hs.power

        ventilation, power_ventilation, power_internal, total_power = (
            _finalize_heat_loss(
                power_surfaces,
                ventilation_ua,
                total_area,
                vent_rate,
                intheat_rate,
                t_outdoor,
                t_env,
                extra_power,
            )
        )

        # ── size bound radiators (using millis share) ──
        bound = room_rads.get(room_id, [])
        sized_rads: list[dict[str, Any]] = []
        for rad_id, rad in bound:
            millis = rad.room.millis if rad.room else 1000
            share = millis / 1000.0
            power_req = -total_power * share

            # Determine target floors for this radiator
            if rad.floors is not None:
                target_floor_ids = list(rad.floors)
            elif rad.plan:
                target_floor_ids = [f.id for f in project.floors if f.plan == rad.plan]
            else:
                target_floor_ids = []

            for floor_id in target_floor_ids:
                floor_ov = rad.floors.get(floor_id) if rad.floors else None
                eff_code = (
                    (floor_ov.code if floor_ov and floor_ov.code else rad.code)
                    .split()[0]
                    .lower()
                )
                cond = radiator_find(eff_code)
                if cond is None:
                    continue

                valve_name = rad.valve or project.valve
                preset = (
                    floor_ov.preset if floor_ov and floor_ov.preset else rad.preset
                ) or ""

                sized_rad = _size_one_radiator(
                    cond,
                    power_req,
                    theta1,
                    dp_rad_pa,
                    thermostat,
                    valve_name,
                    preset,
                    room_id,
                    eff_code,
                    share,
                )
                if sized_rad is not None:
                    sized_rads.append(sized_rad)
                    calc_key = f"rad:{rad_id}:{floor_id}"
                    rad_room_map[calc_key] = room_id

        if sized_rads or total_power != 0:
            rooms_out[room_id] = {
                "errors": [],
                "surfaces": list(surfaces_agg.values()),
                "conditions": None,
                "ventilation": ventilation,
                "power_internal": power_internal,
                "power_surfaces": power_surfaces,
                "power_ventilation": power_ventilation,
                "power": total_power,
                "radiators": sized_rads,
                "directives": [],
            }

    return rooms_out, rad_room_map


def compile_roomless_radcond_radiators(
    project: Project,
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Compile roomless radiators using dedicated radiator conditions.

    This special-case path handles PlanRadiators that are not bound to any
    room (``Radiator.room is None``) and applies the dedicated
    conditions stored in ``project.radcond``.
    """
    radcond = project.radcond
    if radcond is None:
        return {}, {}

    t_supply_cond = float(radcond.supply)
    t_return_cond = float(radcond.return_)
    t_env_cond = float(radcond.env)

    theta1_cond = t_supply_cond - t_env_cond
    theta2_cond = t_return_cond - t_env_cond
    if theta1_cond <= 0:
        return {}, {}

    dp_rad_pa = float(project.dp_rad) * 1000.0
    thermostat = project.thermostat

    plan_floor_ids: dict[str, list[str]] = {}
    for f in project.floors:
        if f.plan:
            plan_floor_ids.setdefault(f.plan, []).append(f.id)

    rooms_out: dict[str, dict[str, Any]] = {}
    rad_room_map: dict[str, str] = {}

    for rad_id, rad in project.radiators.items():
        if rad.room and rad.room.id:
            continue

        if rad.floors is not None:
            target_floor_ids = list(rad.floors.keys())
        elif rad.plan:
            target_floor_ids = plan_floor_ids.get(rad.plan, [])
        else:
            target_floor_ids = []

        for floor_id in target_floor_ids:
            floor_ov = rad.floors.get(floor_id) if rad.floors else None
            eff_code = (
                (floor_ov.code if floor_ov and floor_ov.code else rad.code)
                .split()[0]
                .lower()
            )
            cond = radiator_find(eff_code)
            if cond is None:
                continue

            try:
                design = radiator_calculate_for_theta2(cond, theta1_cond, theta2_cond)
                power_req = float(design["power"])
            except KeyError, TypeError, ValueError, ZeroDivisionError:
                continue

            valve_name = (
                floor_ov.valve if floor_ov and floor_ov.valve else rad.valve
            ) or project.valve
            preset = (
                floor_ov.preset if floor_ov and floor_ov.preset else rad.preset
            ) or ""

            pseudo_room_id = f"radcond-roomless:{rad_id}:{floor_id}"
            sized_rad = _size_one_radiator(
                cond,
                power_req,
                theta1_cond,
                dp_rad_pa,
                thermostat,
                valve_name,
                preset,
                pseudo_room_id,
                eff_code,
            )
            if sized_rad is None:
                continue

            rooms_out[pseudo_room_id] = {
                "errors": [],
                "surfaces": [],
                "conditions": {
                    "supply": t_supply_cond,
                    "return": t_return_cond,
                    "env": t_env_cond,
                },
                "ventilation": 0.0,
                "power_internal": 0.0,
                "power_surfaces": 0.0,
                "power_ventilation": 0.0,
                "power": -power_req,
                "radiators": [sized_rad],
                "directives": [],
            }
            rad_room_map[f"rad:{rad_id}:{floor_id}"] = pseudo_room_id

    return rooms_out, rad_room_map
