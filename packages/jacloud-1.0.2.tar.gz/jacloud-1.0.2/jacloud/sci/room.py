"""Room heat-loss compilation from structured Room v2 data."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .radiator import (
    emit_power,
    radiator_calculate,
    radiator_find,
    theta2_for_flow,
)
from .radvalve import radvalve
from .radvalve import table as valve_table
from .water import Flow, Kv, Pressure

VENTILATION_FACTOR = 0.005


@dataclass
class AreaSurface:
    material: str
    area: float
    power: float


@dataclass
class Radiator:
    room_id: str
    code: str
    valve: str
    theta1: float
    theta2: float
    flow: float
    power: float
    p: float
    preset: str
    kv: float = 0.0
    preset_locked: bool = False


@dataclass
class RoomCalc:
    errors: list[dict[str, Any]] = field(default_factory=list)
    surfaces: list[AreaSurface] = field(default_factory=list)
    conditions: tuple[float, float, float] | None = None
    ventilation: float = 0.0
    power_internal: float = 0.0
    power_surfaces: float = 0.0
    power_ventilation: float = 0.0
    power: float = 0.0
    radiators: list[Radiator] = field(default_factory=list)
    directives: list[dict[str, Any]] = field(default_factory=list)
    wall_coords: list[dict[str, Any]] = field(default_factory=list)
    radiator_coords: list[dict[str, Any]] = field(default_factory=list)


def compile_room(
    proj: Any,
    room_id: str,
    t_supply_override: float | None = None,
) -> RoomCalc:
    """Compile a single room from structured Room v2 surfaces + heat."""
    room = (
        proj.rooms.get(room_id) if isinstance(proj.rooms, dict) else proj.rooms[room_id]
    )
    if room is None:
        raise ValueError("Room not found")

    t_supply = float(proj.t_supply) if t_supply_override is None else t_supply_override
    theta1 = t_supply - float(proj.t_env)
    t_env = float(proj.t_env)
    t_outdoor = float(proj.t_outdoor)
    dp_rad_pa = float(getattr(proj, "dp_rad", 10)) * 1000.0  # kPa -> Pa

    errors: list[dict[str, Any]] = []
    power_surfaces = 0.0
    rsurfaces: list[AreaSurface] = []
    ventilation_ua = 0.0
    total_area = 0.0

    surfaces_raw = proj.surfaces if isinstance(proj.surfaces, dict) else {}
    room_surfaces = getattr(room, "surfaces", None) or []
    room_heat = getattr(room, "heat", None) or []

    for surf in room_surfaces:
        material = getattr(surf, "material", None)
        s = surfaces_raw.get(material) if material else None
        if s is None:
            continue

        u = float(s.u)
        t_surf = (
            float(s.t) if getattr(s, "t", None) not in (None, "", "0") else t_outdoor
        )
        x_m = float(getattr(surf, "x", 0) or 0) / 1000.0
        y_raw = float(getattr(surf, "y", 0) or 0)
        if y_raw > 0:
            y_m = y_raw / 1000.0
        elif getattr(s, "default_y", None) not in (None, "", "0"):
            y_m = float(s.default_y)
        else:
            y_m = 0.0
        if y_m <= 0:
            continue

        wall_area = x_m * y_m
        opening_area_total = 0.0

        for op in getattr(surf, "openings", None) or []:
            op_mat = getattr(op, "material", None)
            op_surf = surfaces_raw.get(op_mat) if op_mat else None
            if op_surf is None:
                continue

            op_w = float(getattr(op, "width", 0) or 0) / 1000.0
            op_h_raw = float(getattr(op, "height", 0) or 0)
            if op_h_raw > 0:
                op_h = op_h_raw / 1000.0
            elif getattr(op_surf, "default_y", None) not in (None, "", "0"):
                op_h = float(op_surf.default_y)
            else:
                op_h = 0.0
            if op_h <= 0:
                continue

            op_area = op_w * op_h
            opening_area_total += op_area
            op_u = float(op_surf.u)
            op_t = (
                float(op_surf.t)
                if getattr(op_surf, "t", None) not in (None, "", "0")
                else t_outdoor
            )
            op_power = op_u * op_area * (op_t - t_env)
            ventilation_ua += op_u * op_area
            power_surfaces += op_power

            existing = next((x for x in rsurfaces if x.material == op_mat), None)
            if existing:
                existing.area += op_area
                existing.power += op_power
            else:
                rsurfaces.append(
                    AreaSurface(material=op_mat, area=op_area, power=op_power)
                )

        net_area = max(0.0, wall_area - opening_area_total)
        p = u * net_area * (t_surf - t_env)
        ventilation_ua += u * net_area
        total_area += wall_area
        power_surfaces += p

        existing = next((x for x in rsurfaces if x.material == material), None)
        if existing:
            existing.area += net_area
            existing.power += p
        else:
            rsurfaces.append(AreaSurface(material=material, area=net_area, power=p))

    vent_rate = float(proj.ventilation) if getattr(proj, "ventilation", None) else 0.0
    ventilation = ventilation_ua * VENTILATION_FACTOR * vent_rate
    power_ventilation = 1.2 * ventilation * (t_outdoor - t_env)
    intheat_rate = float(getattr(proj, "intheat", None) or 0)
    global_internal_heat = 0.04 * total_area * intheat_rate
    power = power_surfaces + global_internal_heat + power_ventilation

    for hs in room_heat:
        hs_power = getattr(hs, "power", None)
        if hs_power is not None:
            power += float(hs_power)

    sized: list[tuple[Any, str, str, str | None, float]] = []
    for rad in (getattr(proj, "radiators", None) or {}).values():
        room_ref = getattr(rad, "room", None)
        if not room_ref or getattr(room_ref, "id", None) != room_id:
            continue

        millis = getattr(room_ref, "millis", 1000) or 1000
        power_req = (-power * float(millis)) / 1000.0
        floors = getattr(rad, "floors", None) or {}

        for floor_ov in floors.values():
            if floor_ov is None:
                continue
            ov_code = getattr(floor_ov, "code", None)
            eff_code = ((ov_code or getattr(rad, "code", "")) or "").split()[0].lower()
            if not eff_code:
                continue

            cond = radiator_find(eff_code)
            if not cond:
                errors.append(
                    {
                        "line": 0,
                        "col": 0,
                        "length": 0,
                        "message": f"Unknown radiator code: {eff_code}",
                    }
                )
                continue

            valve_name = (
                getattr(floor_ov, "valve", None)
                or getattr(rad, "valve", None)
                or getattr(proj, "valve", "")
            )
            preset = getattr(floor_ov, "preset", None) or getattr(rad, "preset", None)
            sized.append((cond, eff_code, valve_name, preset, power_req))

    hsum = sum(item[0][0] for item in sized)
    radiators: list[Radiator] = []

    for cond, code, valve_name, preset, power_req in sized:
        p_req = power_req if hsum == 0 else power_req * (cond[0] / (hsum + 1e-6))
        simple = radiator_calculate(cond, p_req, theta1)
        simple["room_id"] = room_id
        simple["code"] = code

        try:
            if preset:
                t = valve_table[valve_name]
                kv_idx = t["ps"].index(preset)
                kv = t["kv"][kv_idx]
                simple["preset"] = preset
            else:
                kv_want = Kv.calc(Flow(simple["flow"]), Pressure(dp_rad_pa)).kv
                v = radvalve(valve_name, kv_want)
                simple["preset"] = v["ps"]
                kv = v["kv"]

            flow = Kv(kv).flow(Pressure(dp_rad_pa)).lps
            thermostat = getattr(proj, "thermostat", False)
            if (flow > simple["flow"] and not thermostat) or flow < simple["flow"]:
                simple["flow"] = flow
                simple["theta2"] = theta2_for_flow(cond, theta1, simple["flow"])
                simple["power"] = emit_power(cond, theta1, simple["theta2"])

            radiators.append(
                Radiator(
                    room_id=simple["room_id"],
                    code=simple["code"],
                    valve=valve_name,
                    theta1=simple["theta1"],
                    theta2=simple["theta2"],
                    flow=simple["flow"],
                    power=simple["power"],
                    p=p_req,
                    preset=simple.get("preset", ""),
                    kv=kv,
                    preset_locked=bool(preset),
                )
            )
        except Exception as e:
            errors.append(
                {
                    "line": 0,
                    "col": 0,
                    "length": 0,
                    "message": f"Radiator {code}: {e}",
                }
            )

    return RoomCalc(
        errors=errors,
        surfaces=rsurfaces,
        conditions=None,
        ventilation=ventilation,
        power_internal=global_internal_heat,
        power_surfaces=power_surfaces,
        power_ventilation=power_ventilation,
        power=power,
        radiators=radiators,
        directives=[],
        wall_coords=[],
        radiator_coords=[],
    )
