from enum import Enum

pipetypes = {}


class Material(Enum):
    STEEL, COPPER, PLASTIC = 1, 2, 3


STEEL, COPPER, PLASTIC = Material["STEEL"], Material["COPPER"], Material["PLASTIC"]

# Pipe type definitions use the following format:
# types[name] = dp_r(Pa/m), flow_r(l/s), diam_out(mm), material

# Note: names cannot be changed(breaks compatibility with old .jac files)

# Steel
pipetypes["DN 10"] = 17.0, 0.0126, 17, STEEL
pipetypes["DN 15"] = 17.0, 0.02275, 20, STEEL
pipetypes["DN 20"] = 17.0, 0.05166, 27, STEEL
pipetypes["DN 25"] = 17.0, 0.0969, 33, STEEL
pipetypes["DN 32"] = 17.0, 0.2053, 42, STEEL
pipetypes["DN 40"] = 17.0, 0.3094, 48, STEEL
pipetypes["DN 50"] = 17.0, 0.586, 60, STEEL
pipetypes["DN 57"] = 17.0, 0.54, 57, STEEL
pipetypes["DN 64"] = 17.0, 0.97, 64, STEEL
pipetypes["DN 65"] = 17.0, 1.2483, 76, STEEL
pipetypes["DN 80"] = 17.0, 1.9136, 89, STEEL
pipetypes["DN 88"] = 17.0, 2.26, 88, STEEL
pipetypes["DN 100"] = 17.0, 3.833, 114, STEEL
pipetypes["DN 125"] = 17.0, 6.639, 140, STEEL
pipetypes["DN 150"] = 17.0, 10.97, 168, STEEL
# Copper
pipetypes["Cu 10"] = 70.0, 0.09, 10, COPPER
pipetypes["Cu 12"] = 72.0, 0.015, 12, COPPER
pipetypes["Cu 15"] = 75.0, 0.03, 15, COPPER
pipetypes["Cu 18"] = 65.0, 0.05, 18, COPPER
pipetypes["Cu 22"] = 72.0, 0.1, 22, COPPER
pipetypes["Cu 28"] = 77.0, 0.2, 28, COPPER
pipetypes["Cu 35"] = 51.0, 0.3, 35, COPPER
pipetypes["Cu 42"] = 50.0, 0.5, 42, COPPER
pipetypes["Cu 54"] = 52.0, 1.0, 54, COPPER
pipetypes["Cu 63"] = 50.0, 1.5, 63, COPPER
pipetypes["Cu 76"] = 52.0, 2.5, 76, COPPER
# Uponor Comfort Pipe/evalPEX, Uponor Comfort, Pipe PLUS PN 6, Uponor Combi Pipe PN 10 (luettu graafisesti)
# https://www.uponor.fi/-/media/country-specific/finland/download-centre/tap-water-pex/brochures/1010-pex-putket-10-2015.pdf
# PEX pipe naming uses outer diameter
pipetypes["Upo 12"] = 100.0, 0.011, 12, PLASTIC
pipetypes["Upo 15"] = 100.0, 0.019, 15, PLASTIC
pipetypes["Upo 17"] = 100.0, 0.040, 17, PLASTIC
pipetypes["Upo 18"] = 100.0, 0.040, 18, PLASTIC
pipetypes["Upo 20"] = 100.0, 0.069, 20, PLASTIC
pipetypes["Upo 22"] = 100.0, 0.069, 22, PLASTIC
pipetypes["Upo 25"] = 100.0, 0.13, 25, PLASTIC
pipetypes["Upo 32"] = 100.0, 0.26, 32, PLASTIC
pipetypes["Upo 40"] = 100.0, 0.46, 40, PLASTIC
pipetypes["Upo 50"] = 100.0, 0.85, 50, PLASTIC
pipetypes["Upo 63"] = 100.0, 1.6, 63, PLASTIC
pipetypes["Upo 75"] = 100.0, 2.5, 75, PLASTIC
pipetypes["Upo 90"] = 100.0, 4.1, 90, PLASTIC
pipetypes["Upo 110"] = 100.0, 6.9, 110, PLASTIC
# Komposiittiputket(Uponor 2010, luettu graafisesti)
pipetypes["Upo K 16x2"] = 1300.0, 0.1, 16, PLASTIC
pipetypes["Upo K 20x2.25"] = 1000.0, 0.2, 20, PLASTIC
pipetypes["Upo K 25x2.5"] = 700.0, 0.3, 25, PLASTIC
pipetypes["Upo K 32x3"] = 600.0, 0.5, 32, PLASTIC
pipetypes["Upo K 40x4"] = 350.0, 0.8, 40, PLASTIC
pipetypes["Upo K 50x4.5"] = 280.0, 1.1, 50, PLASTIC
pipetypes["Upo K 63x6"] = 220.0, 2.0, 63, PLASTIC
pipetypes["Upo K 75x7.5"] = 170.0, 2.6, 75, PLASTIC
pipetypes["Upo K 90x8.5"] = 130.0, 4.0, 90, PLASTIC
pipetypes["Upo K 110x10"] = 100.0, 6.0, 110, PLASTIC

# Riser diameters: dn<size> → outer diameter in mm (for heat gain calc)
riser_diameters: dict[str, float] = {}
for _s in (10, 15, 20, 25, 32, 40, 50, 65):
    _key = f"DN {_s}"
    if _key in pipetypes:
        riser_diameters[f"dn{_s}"] = pipetypes[_key][2]
