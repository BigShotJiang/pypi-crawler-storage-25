g = 9.8065


def mix(x, y, p):
    """Generic blend equation. p for proportion 0 = all x, 1 = all y."""
    return x + (y - x) * p
