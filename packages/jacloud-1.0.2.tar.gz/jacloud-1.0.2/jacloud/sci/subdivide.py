"""
Planar subdivision: given a closed boundary polygon, optional holes,
and interior wall chains (polylines), detect all minimal enclosed
faces (rooms/zones).

Algorithm:
  1. Snap-merge all vertices into a shared pool (spatial grid).
  2. Build edge set from boundary ring, hole rings, and inner chains.
  3. Split edges at vertex projections and edge-edge crossings.
  4. Extract minimal faces via half-edge walking ("prev in CCW list").
  5. Filter to interior faces (positive signed area = CCW winding).
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Point:
    x: float
    y: float


@dataclass
class Face:
    ring: list[int]
    area: float  # signed area in m² (positive = CCW = interior)


@dataclass
class SubdivisionResult:
    vertices: list[Point]
    faces: list[Face]


# ── Vertex pool with spatial grid ────────────────────────────────────

SNAP_TOL = 50  # mm


class VertexPool:
    def __init__(self, tol: float = SNAP_TOL) -> None:
        self.pool: list[Point] = []
        self._grid: dict[tuple[int, int], list[int]] = {}
        self._cell = tol * 2
        self._tol_sq = tol * tol

    def add(self, x: float, y: float) -> int:
        cell = self._cell
        cx = math.floor(x / cell)
        cy = math.floor(y / cell)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                bucket = self._grid.get((cx + dx, cy + dy))
                if bucket:
                    for idx in bucket:
                        q = self.pool[idx]
                        if (q.x - x) ** 2 + (q.y - y) ** 2 <= self._tol_sq:
                            return idx
        idx = len(self.pool)
        self.pool.append(Point(x, y))
        key = (cx, cy)
        lst = self._grid.get(key)
        if lst is None:
            lst = []
            self._grid[key] = lst
        lst.append(idx)
        return idx


# ── Edge building with intersection detection ───────────────────────


def _build_edges(
    vp: VertexPool,
    boundary_ring: list[int],
    hole_rings: list[list[int]],
    inner_chains: list[list[int]],
) -> list[tuple[int, int]]:
    raw_segs: list[tuple[int, int]] = []

    def add_ring_segs(ring: list[int]) -> None:
        for i in range(len(ring)):
            a, b = ring[i], ring[(i + 1) % len(ring)]
            if a != b:
                raw_segs.append((a, b))

    add_ring_segs(boundary_ring)
    for ring in hole_rings:
        add_ring_segs(ring)
    for chain in inner_chains:
        raw_segs.extend(
            (chain[i], chain[i + 1])
            for i in range(len(chain) - 1)
            if chain[i] != chain[i + 1]
        )

    all_verts: set[int] = set()
    for a, b in raw_segs:
        all_verts.add(a)
        all_verts.add(b)

    seg_splits: list[list[tuple[float, int]]] = [[] for _ in raw_segs]

    # 1) Vertex-on-segment projections
    tol_sq = SNAP_TOL * SNAP_TOL
    for si, (a_idx, b_idx) in enumerate(raw_segs):
        a = vp.pool[a_idx]
        b = vp.pool[b_idx]
        dx = b.x - a.x
        dy = b.y - a.y
        len_sq = dx * dx + dy * dy
        if len_sq < 1:
            continue
        for p_idx in all_verts:
            if p_idx in (a_idx, b_idx):
                continue
            p = vp.pool[p_idx]
            t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len_sq
            if t <= 0.001 or t >= 0.999:
                continue
            px = a.x + t * dx
            py = a.y + t * dy
            if (p.x - px) ** 2 + (p.y - py) ** 2 <= tol_sq:
                seg_splits[si].append((t, p_idx))

    # 2) Interior segment-segment crossings
    for i in range(len(raw_segs)):
        a1, b1 = raw_segs[i]
        p1 = vp.pool[a1]
        q1 = vp.pool[b1]
        d1x = q1.x - p1.x
        d1y = q1.y - p1.y
        for j in range(i + 1, len(raw_segs)):
            a2, b2 = raw_segs[j]
            if a1 in (a2, b2) or b1 in (a2, b2):
                continue
            p2 = vp.pool[a2]
            q2 = vp.pool[b2]
            d2x = q2.x - p2.x
            d2y = q2.y - p2.y
            det = d1x * d2y - d1y * d2x
            if abs(det) < 1e-6:
                continue  # parallel
            t = ((p2.x - p1.x) * d2y - (p2.y - p1.y) * d2x) / det
            u = ((p2.x - p1.x) * d1y - (p2.y - p1.y) * d1x) / det
            if t <= 0.001 or t >= 0.999 or u <= 0.001 or u >= 0.999:
                continue
            ix = p1.x + t * d1x
            iy = p1.y + t * d1y
            idx = vp.add(ix, iy)
            seg_splits[i].append((t, idx))
            seg_splits[j].append((u, idx))

    # 3) Build final edges, splitting segments and deduplicating
    edge_set: set[tuple[int, int]] = set()
    edges: list[tuple[int, int]] = []

    def add_edge(a: int, b: int) -> None:
        if a == b:
            return
        key = (a, b) if a < b else (b, a)
        if key in edge_set:
            return
        edge_set.add(key)
        edges.append((a, b))

    for si, (a_idx, b_idx) in enumerate(raw_segs):
        splits = seg_splits[si]
        if not splits:
            add_edge(a_idx, b_idx)
        else:
            splits.sort()
            prev = a_idx
            last_idx = -1
            for _t_val, s_idx in splits:
                if s_idx == last_idx:
                    continue
                add_edge(prev, s_idx)
                prev = s_idx
                last_idx = s_idx
            add_edge(prev, b_idx)

    return edges


# ── Half-edge face extraction ────────────────────────────────────────


def _extract_faces(
    vertices: list[Point],
    edges: list[tuple[int, int]],
) -> list[Face]:
    adj: dict[int, list[int]] = {}
    for a, b in edges:
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    for v, nbrs in adj.items():
        p = vertices[v]
        nbrs.sort(key=lambda n: math.atan2(vertices[n].y - p.y, vertices[n].x - p.x))

    used: set[tuple[int, int]] = set()
    faces: list[Face] = []
    max_steps = len(vertices) * 2 + len(edges) + 10

    for a, b in edges:
        for start, nxt in ((a, b), (b, a)):
            if (start, nxt) in used:
                continue

            ring: list[int] = []
            cur = start
            nxt_ = nxt
            steps = 0

            while steps < max_steps:
                used.add((cur, nxt_))
                ring.append(cur)

                nbrs = adj.get(nxt_)
                if not nbrs:
                    break

                idx = -1
                for i, n in enumerate(nbrs):
                    if n == cur:
                        idx = i
                        break
                if idx < 0:
                    break

                prev_idx = (idx - 1) % len(nbrs)
                cur = nxt_
                nxt_ = nbrs[prev_idx]
                steps += 1

                if cur == start and nxt_ == nxt:
                    break

            if len(ring) >= 3:
                area = 0.0
                for i in range(len(ring)):
                    p1 = vertices[ring[i]]
                    p2 = vertices[ring[(i + 1) % len(ring)]]
                    area += p1.x * p2.y - p2.x * p1.y
                faces.append(Face(ring=ring, area=area / 2))

    return faces


# ── Public API ───────────────────────────────────────────────────────


def subdivide(
    boundary: list[Point],
    dividers: list[list[Point]],
    holes: list[list[Point]] | None = None,
) -> SubdivisionResult:
    if len(boundary) < 3:
        return SubdivisionResult(vertices=list(boundary), faces=[])

    if holes is None:
        holes = []

    vp = VertexPool()

    boundary_ring = [vp.add(p.x, p.y) for p in boundary]
    hole_rings = [[vp.add(p.x, p.y) for p in ring] for ring in holes]
    inner_chains = [
        chain_ids
        for chain in dividers
        if len(chain) >= 2
        for chain_ids in [[vp.add(p.x, p.y) for p in chain]]
    ]

    edges = _build_edges(vp, boundary_ring, hole_rings, inner_chains)
    all_faces = _extract_faces(vp.pool, edges)

    # Interior faces have positive signed area (CCW winding)
    interior_faces = [f for f in all_faces if f.area > 0]

    # Convert mm² → m²
    for f in interior_faces:
        f.area /= 1_000_000

    return SubdivisionResult(vertices=vp.pool, faces=interior_faces)


def point_in_face(
    px: float,
    py: float,
    ring: list[int],
    vertices: list[Point],
) -> bool:
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        vi = vertices[ring[i]]
        vj = vertices[ring[j]]
        if (vi.y > py) != (vj.y > py) and px < (vj.x - vi.x) * (py - vi.y) / (
            vj.y - vi.y
        ) + vi.x:
            inside = not inside
        j = i
    return inside
