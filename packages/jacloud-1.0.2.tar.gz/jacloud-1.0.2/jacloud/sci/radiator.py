"""Radiator thermal model and type database.

Scalar Python port of frontend/src/sci/radiator.ts — all functions
operate on plain floats (no numpy).
"""

from __future__ import annotations

import msgspec

from .tables import rad
from .water import c

# ---------------------------------------------------------------------------
# Thermal model
# ---------------------------------------------------------------------------

# RadConductance is a (h, n) tuple:  h = conductance, n = exponent
RadConductance = tuple[float, float]


class C(msgspec.Struct, frozen=True):
    """Test condition temperatures in °C."""

    s: float  # supply (inlet)
    r: float  # return (outlet)
    e: float = 20  # environment

    @property
    def t1(self):
        return self.s - self.e

    @property
    def t2(self):
        return self.r - self.e


conditions: dict[str, C] = {
    "en442": C(75, 65),
    "dT20": C(45, 35),
    "dT30": C(55, 45),
    "dT35": C(70, 40),
    "dT45": C(80, 50),
    "dT60": C(90, 70),
}


def radcoeff(theta1: float, theta2: float, n: float) -> float:
    """Emission coefficient based on Karkkainen radiator equation."""
    dT = theta1 - theta2
    q = n - 1.0
    if abs(dT) < 0.001:
        return theta1**n / q
    if abs(theta2) < 0.001:
        return 0.0
    return dT / (theta2 ** (-q) - theta1 ** (-q))


def emit_power(rad: RadConductance, theta1: float, theta2: float) -> float:
    """Emission power for a pair of temperature differences (above room)."""
    h, n = rad
    s = 1
    if theta1 < 0 and theta2 < 0:
        s = -1
    return s * h * radcoeff(s * theta1, s * theta2, n)


def theta2_for_power(rad: RadConductance, theta1: float, power: float) -> float:
    """Binary search for return-temperature-difference giving *power*."""
    if power * theta1 <= 0.0:
        return 0.0
    theta2 = 0.0
    step = theta1
    start = emit_power(rad, theta1, theta2) < power
    while abs(step) > 0.01:
        step *= 0.5
        nxt = emit_power(rad, theta1, theta2 + step) < power
        if start == nxt:
            theta2 += step
    return theta2


def theta2_for_flow(rad: RadConductance, theta1: float, flow: float) -> float:
    """Binary search for return-temperature-difference at a given flow."""
    theta2 = 0.0
    step = theta1
    s = -1 if theta1 < 0 else 1
    while abs(step) > 0.01:
        step *= 0.5
        t2test = theta2 + step
        if s * emit_power(rad, theta1, t2test) < s * c * flow * (theta1 - t2test):
            theta2 = t2test
    return theta2


def theta2_for_conditions(theta1: float, ctheta1: float, ctheta2: float) -> float:
    """Scale condition return temperature to the actual inlet delta."""
    if abs(ctheta1) < 0.001:
        return 0.0
    theta2 = theta1 * ctheta2 / ctheta1
    limit = 0.9 * abs(theta1)
    if abs(theta2) > limit:
        theta2 = limit * (1.0 if theta1 >= 0.0 else -1.0)
    return theta2


def water_flow(power: float, deltaT: float) -> float:
    return power / (c * deltaT + 1e-6)


def radiator_calculate(rad: RadConductance, power_req: float, theta1: float) -> dict:
    """Calculate operating point for a required power demand."""
    r: dict = {}
    r["theta1"] = theta1
    r["theta2"] = theta2_for_power(rad, theta1, power_req)
    if abs(r["theta2"]) > 0.9 * abs(r["theta1"]):
        r["theta2"] = 0.9 * r["theta1"]
    r["power"] = emit_power(rad, r["theta1"], r["theta2"])
    r["flow"] = water_flow(r["power"], r["theta1"] - r["theta2"])
    return r


def radiator_calculate_for_theta2(
    rad: RadConductance, theta1: float, theta2: float
) -> dict:
    """Calculate operating point for a target return-temperature-difference."""
    r: dict = {}
    r["theta1"] = theta1
    r["theta2"] = theta2
    r["power"] = emit_power(rad, r["theta1"], r["theta2"])
    r["flow"] = water_flow(r["power"], r["theta1"] - r["theta2"])
    return r


# ---------------------------------------------------------------------------
# Radiator type database
# ---------------------------------------------------------------------------
def _radtype(power: float, cond: C, n: float = 1.3) -> RadConductance:
    return (round(power / radcoeff(cond.t1, cond.t2, n), 3), n)


radtypes: dict[str, RadConductance] = {
    subtype.pattern.replace("*", h): _radtype(e.power, conditions[e.cond], e.n)
    for group in rad.groups
    for subtype in group.codes
    for h, e in subtype.h.items()
}

old_code_map: dict[str, str] = {
    entry.old_code: subtype.pattern.replace("*", h)
    for group in rad.groups
    for subtype in group.codes
    for h, entry in subtype.h.items()
    if entry.old_code is not None
}

# Collect unique patterns (with wildcards) for pattern-based parsing
_patterns: list[str] = list(
    {subtype.pattern for group in rad.groups for subtype in group.codes}
)

# Set of patterns from unlisted groups (lowercased)
_unlisted_patterns: set[str] = {
    subtype.pattern.lower()
    for group in rad.groups
    if group.is_unlisted
    for subtype in group.codes
}


def _match_pattern(suffix: str, pattern: str) -> str | None:
    """Match suffix against a glob pattern, returning the variant or None.

    Case-insensitive.  The wildcard ``*`` only matches digits.
    """
    suffix = suffix.lower()
    pattern = pattern.lower()
    idx = pattern.find("*")
    if idx == -1:
        return "" if suffix == pattern else None
    prefix = pattern[:idx]
    end = pattern[idx + 1 :]
    if not suffix.startswith(prefix) or not suffix.endswith(end):
        return None
    variant = suffix[len(prefix) : len(suffix) - len(end) if end else len(suffix)]
    if not variant.isdigit():
        return None
    return variant


def _unlisted_variant(suffix: str) -> str | None:
    """If *suffix* matches an unlisted group pattern return the variant.

    Returns ``''`` for no-wildcard patterns (e.g. ``W``), a digit string
    for wildcard patterns (e.g. ``-*W``), or ``None`` if not unlisted.
    """
    for group in rad.groups:
        if not group.is_unlisted:
            continue
        for sub in group.codes:
            v = _match_pattern(suffix, sub.pattern)
            if v is not None:
                return v
    return None


def parse_radiator_code(code: str) -> tuple[int, str] | None:
    """Parse a radiator code into (length, suffix) using group patterns.

    Each pattern uses ``*`` as a numeric wildcard for the variant (height).
    We build a regex from each pattern to unambiguously split the code,
    preferring the longest (most specific) suffix match.

    Patterns without ``*`` (e.g. ``W``) match ``^(\\d+){pattern}$`` exactly.
    """
    import re as _re

    best: tuple[int, str] | None = None
    for pattern in _patterns:
        idx = pattern.find("*")
        if idx == -1:
            # No wildcard (e.g. "W"): match ^(\d+){pattern}$ exactly
            escaped = _re.escape(pattern)
            m = _re.match(rf"^(\d+){escaped}$", code, _re.IGNORECASE)
            if m:
                length = int(m.group(1))
                suffix = pattern.lower()
                if best is None or len(suffix) > len(best[1]):
                    best = (length, suffix)
        else:
            before = _re.escape(pattern[:idx])
            after = _re.escape(pattern[idx + 1 :])
            m = _re.match(rf"^(\d+){before}(\d+){after}$", code, _re.IGNORECASE)
            if m:
                length = int(m.group(1))
                variant = m.group(2)
                suffix = (pattern[:idx] + variant + pattern[idx + 1 :]).lower()
                is_valid = suffix in radtypes or pattern.lower() in _unlisted_patterns
                if is_valid and (best is None or len(suffix) > len(best[1])):
                    best = (length, suffix)
    return best


def radiator_find(code: str) -> RadConductance | None:
    """Look up a radiator by its type code string.

    Returns (h, n) conductance tuple, or None if not found.
    """
    parsed = parse_radiator_code(code.lower())
    if not parsed:
        return None
    length, suffix = parsed

    # Normal listed radiator
    if suffix in radtypes:
        h, n = radtypes[suffix]
        return (0.001 * length * h, n)

    # Check unlisted groups (e.g. W, -*W)
    v = _unlisted_variant(suffix)
    if v is not None:
        # v == '' → no-wildcard (W): length is total power in watts
        # v != '' → wildcard (-*W): v is power/metre, length is mm
        power = float(int(v) * length * 0.001) if v else float(length)
        return _radtype(power, conditions["en442"], 1.3)

    return None
