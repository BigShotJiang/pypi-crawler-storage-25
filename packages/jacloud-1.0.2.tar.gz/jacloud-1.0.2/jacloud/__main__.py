import argparse
import os

from fastapi_vue import server
from fastapi_vue.hostutil import parse_endpoints

from .startupbox import print_startup_config

DEFAULT_PORT = 8077
DEVMODE = os.getenv("JACLOUD_DEV") == "1"


def main():
    parser = argparse.ArgumentParser(description="Run the jacloud server.")
    parser.add_argument(
        "-l",
        "--listen",
        action="append",
        help=f"Endpoint (default: localhost:{DEFAULT_PORT}).",
    )
    args = parser.parse_args()
    dev = {"reload": True, "reload_dirs": ["jacloud"]} if DEVMODE else {}
    endpoints = parse_endpoints(args.listen, DEFAULT_PORT)
    print_startup_config(endpoints)
    server.run(
        "jacloud.app:app",
        listen=args.listen,
        default_port=DEFAULT_PORT,
        access_log=False,
        **dev,
    )


if __name__ == "__main__":
    main()
