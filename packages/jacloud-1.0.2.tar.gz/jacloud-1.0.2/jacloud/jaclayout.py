"""Layout and geometry emission for pipe networks.

This module handles:
- Phase 2: Collision-aware direction assignment for horizontal pipes
- Phase 3: Emitting PipeNet geometry from oriented chain trees
"""

import math
import re
from dataclasses import dataclass, field

from jacloud.project import (
    NODE_SPACING,
    BalancingValve,
    Floor,
    Pipe,
    PipeEvent,
    PipeNet,
    PipeNode,
    Riser,
)
from jacloud.sci.radiator import _unlisted_variant, parse_radiator_code
from jacloud.util import create_id
from jacloud.util import merge_names as _merge_names

# =====================================================================
# _PipeChain – logical pipeline segment for layout
# =====================================================================


@dataclass
class _PipeChain:
    """A logical pipeline laid out as a single straight line.

    Built during Phase 1 by walking the JAC tree.  Each chain becomes
    one :class:`Pipe` in the output.  The *orientation* is assigned in
    Phase 2 (layout).
    """

    length_mm: int
    is_vertical: bool
    vert_up: bool  # only meaningful when *is_vertical*
    dn_events: list[tuple[int, str]]  # (cumul_mm, dn)
    names: list[str]
    valve_events: list[tuple[int, str, str]]  # (cumul_mm, valve_dn, valve_name)
    terminal_rad: dict | None
    subtree_weight: float
    # Branches splitting off at specific offsets along this chain
    branches: list[tuple[int, list[_PipeChain]]] = field(default_factory=list)
    # Assigned during Phase 2
    orientation: tuple | None = None


# =====================================================================
# Phase 2 – skeleton-first direction assignment
# =====================================================================

# Cardinal directions in preferred order: right, left, up, down
# Directions are 2D (dx, dy) on the horizontal floor plan.
CARDINAL_DIRS = (
    (1, 0),  # right
    (-1, 0),  # left
    (0, 1),  # up (on floor plan)
    (0, -1),  # down (on floor plan)
)


def _opposite_dir(d: tuple) -> tuple:
    """Return the direction opposite to *d*."""
    return (-d[0], -d[1])


def _make_radial_fan(n: int) -> list[tuple]:
    """Generate *n* evenly-spaced directions around the full circle.

    Used when a junction has more than 4 horizontal exits.
    """
    dirs: list[tuple] = []
    for i in range(n):
        angle = 2 * math.pi * i / n
        dx = round(math.cos(angle), 4)
        dy = round(math.sin(angle), 4)
        dirs.append((dx, dy))
    return dirs


class _SegmentTracker:
    """Per-floor tracking of placed pipe segments for overlap detection.

    Detects colinear overlap (segments on the same line sharing extent).
    Far simpler than proximity-based approaches — only direct overlaps
    are penalised.
    """

    def __init__(self) -> None:
        self.floors: dict[int, list[tuple[float, float, float, float]]] = {}

    def add(self, floor_idx: int, x1: float, y1: float, x2: float, y2: float) -> None:
        """Register a placed segment on a floor."""
        self.floors.setdefault(floor_idx, []).append((x1, y1, x2, y2))

    def count_overlaps(
        self, floor_idx: int, x1: float, y1: float, x2: float, y2: float
    ) -> int:
        """Count existing segments that colinearly overlap with the proposed one."""
        count = 0
        for seg in self.floors.get(floor_idx, []):
            if _segments_colinear_overlap(x1, y1, x2, y2, *seg):
                count += 1
        return count


_COLINEAR_EPS = 1.0  # mm tolerance for colinearity checks


def _segments_colinear_overlap(
    ax1: float,
    ay1: float,
    ax2: float,
    ay2: float,
    bx1: float,
    by1: float,
    bx2: float,
    by2: float,
) -> bool:
    """Return True if two segments are colinear and share extent.

    Checks parallelism, then colinearity (perpendicular distance ≈ 0),
    then range overlap along the shared direction.
    """
    adx, ady = ax2 - ax1, ay2 - ay1
    alen = (adx * adx + ady * ady) ** 0.5
    bdx, bdy = bx2 - bx1, by2 - by1
    blen = (bdx * bdx + bdy * bdy) ** 0.5

    if alen < _COLINEAR_EPS or blen < _COLINEAR_EPS:
        return False

    # Parallelism: |cross product of unit vectors| ≈ 0
    cross = abs(adx * bdy - ady * bdx) / (alen * blen)
    if cross > 0.1:
        return False

    # Colinearity: perpendicular distance from B's start to A's line ≈ 0
    axn, ayn = adx / alen, ady / alen
    vx, vy = bx1 - ax1, by1 - ay1
    perp_dist = abs(vx * ayn - vy * axn)
    if perp_dist > _COLINEAR_EPS:
        return False

    # Range overlap along the shared direction
    b1_proj = vx * axn + vy * ayn
    b2_proj = (bx2 - ax1) * axn + (by2 - ay1) * ayn
    b_lo, b_hi = min(b1_proj, b2_proj), max(b1_proj, b2_proj)
    return min(alen, b_hi) - max(0.0, b_lo) > _COLINEAR_EPS


def _chain_radiator_length(chain: _PipeChain) -> int:
    """Get the radiator length in mm from a chain's *terminal_rad*."""
    if chain.terminal_rad is None:
        return 0
    rad_code = ""
    radt = chain.terminal_rad.get("radt")
    if isinstance(radt, dict):
        rad_code = radt.get("code", "")
    return _extract_radiator_length(rad_code)


def _chain_effective_length(chain: _PipeChain) -> int:
    """Pipe length plus radiator length when the chain terminates at one.

    For layout purposes a pipe that only leads to a radiator is treated
    as extended by the radiator's body length.
    """
    length = chain.length_mm
    if chain.terminal_rad is not None and not chain.branches:
        length += _chain_radiator_length(chain)
    return length


def _layout_chains(
    chains: list[_PipeChain],
    start_x_mm: float,
    start_y_mm: float,
    floor_idx: int,
    floor_height_mm: int,
    tracker: _SegmentTracker,
    incoming_dir: tuple,
) -> None:
    """Assign orientations to all chains in a two-pass approach.

    Directions are 2D ``(dx, dy)`` on the horizontal floor plan.
    Vertical chains (risers) have no layout direction; only their
    sub-branches are recursed into.

    **Pass 1 (skeleton):** at each junction only the heaviest horizontal
    chain is assigned a direction and recursed into.  This lays out the
    network of longest pipelines first so that risers and radiators end
    up as far apart as possible.

    **Pass 2 (fill):** all remaining unassigned chains receive directions
    that avoid overlapping the skeleton.
    """
    _walk_assign(
        chains,
        start_x_mm,
        start_y_mm,
        floor_idx,
        floor_height_mm,
        tracker,
        incoming_dir,
        skeleton_only=True,
    )
    _walk_assign(
        chains,
        start_x_mm,
        start_y_mm,
        floor_idx,
        floor_height_mm,
        tracker,
        incoming_dir,
        skeleton_only=False,
    )


def _walk_assign(
    chains: list[_PipeChain],
    x: float,
    y: float,
    floor_idx: int,
    floor_height_mm: int,
    tracker: _SegmentTracker,
    incoming_dir: tuple,
    skeleton_only: bool,
) -> None:
    """Recursively assign directions to chains at a junction point.

    In *skeleton_only* mode only the single heaviest unassigned
    horizontal chain is processed at each junction.  Otherwise all
    unassigned chains are processed.
    """
    h_chains = [c for c in chains if not c.is_vertical]
    v_chains = [c for c in chains if c.is_vertical]

    # --- Vertical chains: no layout direction, just recurse ---
    for vc in v_chains:
        for off, sub_chains in vc.branches:
            if floor_height_mm:
                sub_floor = (
                    floor_idx + (off * (1 if vc.vert_up else -1)) // floor_height_mm
                )
            else:
                sub_floor = floor_idx
            _walk_assign(
                sub_chains,
                x,
                y,
                sub_floor,
                floor_height_mm,
                tracker,
                (0, 0),  # no horizontal bias from vertical
                skeleton_only,
            )

    if not h_chains:
        return

    # --- Sort by subtree weight: heaviest first ---
    h_chains.sort(key=lambda c: -c.subtree_weight)

    # Decide which chains to assign in this pass
    unassigned = [c for c in h_chains if c.orientation is None]
    to_assign = unassigned[:1] if skeleton_only else unassigned

    # Directions already used at this junction
    used_dirs: set[tuple] = {
        c.orientation for c in h_chains if c.orientation is not None
    }
    n_total = len(h_chains)

    for chain in to_assign:
        direction = _pick_direction(
            chain,
            x,
            y,
            floor_idx,
            tracker,
            incoming_dir,
            used_dirs,
            n_total,
        )
        chain.orientation = direction
        used_dirs.add(direction)
        _register_chain_segment(tracker, chain, direction, x, y, floor_idx)

    # --- Recurse into all assigned horizontal chains ---
    for chain in h_chains:
        if chain.orientation is None:
            continue
        dx, dy = chain.orientation
        for off, sub_chains in chain.branches:
            if chain.length_mm > 0:
                jx = x + dx * off
                jy = y + dy * off
            else:
                jx, jy = x, y
            _walk_assign(
                sub_chains,
                jx,
                jy,
                floor_idx,
                floor_height_mm,
                tracker,
                chain.orientation,
                skeleton_only,
            )


def _pick_direction(
    chain: _PipeChain,
    x: float,
    y: float,
    floor_idx: int,
    tracker: _SegmentTracker,
    incoming_dir: tuple,
    used_dirs: set[tuple],
    n_total_h: int,
) -> tuple:
    """Choose the best direction for *chain* at a junction.

    Uses cardinal directions (right, left, up, down) when the junction
    has ≤ 4 horizontal exits; falls back to a radial fan otherwise.
    Avoids directions already used at the junction, penalises colinear
    overlaps, and prefers directions that maximise angular spread from
    the incoming direction and already-used directions (repulsive force).
    """
    candidates = list(CARDINAL_DIRS) if n_total_h <= 4 else _make_radial_fan(n_total_h)

    # Remove directions already used at this junction
    candidates = [d for d in candidates if d not in used_dirs]
    if not candidates:
        candidates = list(CARDINAL_DIRS)

    eff_len = _chain_effective_length(chain)

    # Directions to repel from: incoming + already used at this junction
    repel_dirs = [d for d in used_dirs if d != (0, 0)]
    if incoming_dir != (0, 0):
        repel_dirs.append(incoming_dir)

    best_dir = candidates[0]
    best_score = float("inf")

    for d in candidates:
        score = 0.0
        # Colinear overlap penalty
        if eff_len > 0:
            ddx, ddy = d
            end_x = x + ddx * eff_len
            end_y = y + ddy * eff_len
            score += tracker.count_overlaps(floor_idx, x, y, end_x, end_y) * 100

        # Angular spread: prefer the direction farthest from all
        # already-placed directions (repulsive force).  Use the minimum
        # angular distance to any repel direction — we want to maximise
        # the worst case.
        if repel_dirs:
            dx, dy = d
            min_ang = math.pi  # best possible
            for rx, ry in repel_dirs:
                dot = dx * rx + dy * ry
                # clamp for numerical safety
                cos_a = max(-1.0, min(1.0, dot))
                ang = math.acos(cos_a)
                min_ang = min(min_ang, ang)
            # Penalise: smaller min-angle → higher penalty.
            # Scale so 0° → +10, 180° → 0.
            score += (math.pi - min_ang) / math.pi * 10

        if score < best_score:
            best_score = score
            best_dir = d

    return best_dir


def _register_chain_segment(
    tracker: _SegmentTracker,
    chain: _PipeChain,
    direction: tuple,
    x: float,
    y: float,
    floor_idx: int,
) -> None:
    """Register a chain's pipe (+ optional radiator extent) in *tracker*."""
    dx, dy = direction
    eff_len = _chain_effective_length(chain)
    if eff_len > 0:
        tracker.add(floor_idx, x, y, x + dx * eff_len, y + dy * eff_len)


def _extract_radiator_length(code: str) -> int:
    """Extract radiator body length in mm from a type code, or 1000 as fallback.

    Codes start with length digits (e.g., "1200-500-21VM") or are power-based
    (e.g., "1500w").  The leading number is the length in mm.
    The returned length is body-only; the 200 mm valve symbol is not included.
    """
    if not code:
        return 1000

    parsed = parse_radiator_code(code.lower())
    if parsed:
        length, suffix = parsed
        v = _unlisted_variant(suffix)
        if v is not None:
            if v:
                # Wildcard unlisted (e.g. -{power}W): length is actual length
                return length
            # No-wildcard unlisted (e.g. {power}W): length is power, approximate
            return max(200, length)
        if length > 0:
            return length
    # Fallback: extract leading digits as length
    match = re.match(r"(\d+)", code)
    if match:
        length = int(match.group(1))
        if length > 0:
            return length
    return 1000


# =====================================================================
# Phase 3 – emit PipeNet objects from oriented chains
# =====================================================================


def _range_name(names: list[str]) -> str:
    """Compute a display name from a list of segment names.

    Uses the same overlap-removing en-dash range logic as _merge_names.
    """
    if not names:
        return ""
    return _merge_names(names)


_GENERIC_RADIATOR_TYPE_RE = re.compile(
    r"^(?:radiator\s+type|patterityyppi)\s+\d+$", re.IGNORECASE
)


def _is_generic_radiator_type_name(name: str) -> bool:
    """Return True for generic radiator type labels that should be hidden."""
    return bool(_GENERIC_RADIATOR_TYPE_RE.match(name.strip()))


@dataclass
class CollectedRadiator:
    """Radiator info collected during chain emission for room code."""

    room_id: str
    room_rad: str  # code + optional description
    name: str
    code: str  # raw radiator code (e.g. "21-160-1000")
    x: int  # mm, position on plan
    y: int  # mm, position on plan
    endpoint: tuple[int, int]  # radiator body extent
    floor_id: str


class _PipeConvCtx:
    """Accumulator for chain → PipeNet emission (Phase 3)."""

    def __init__(
        self,
        net: PipeNet,
        floor_height_mm: int,
        radt_room_map: dict[int, tuple[str, str]] | None = None,
    ):
        self.net = net
        self.floor_height_mm = floor_height_mm
        self.radt_room_map: dict[int, tuple[str, str]] = radt_room_map or {}
        self.node_coords: dict[str, tuple[float, float, float]] = {}  # (x, y, h)
        self.floor_levels: dict[int, str] = {}
        self.collected_radiators: list[CollectedRadiator] = []

    def add_node(self, x: float, y: float, h: float) -> str:
        x_mm = int(x * 1000)
        y_mm = int(y * 1000)
        h_mm = int(h * 1000)
        nid = create_id()
        self.node_coords[nid] = (x, y, h)
        if self.floor_height_mm:
            floor_idx = (
                h_mm // self.floor_height_mm
                if h_mm >= 0
                else -(-h_mm // self.floor_height_mm + 1)
            )
        else:
            floor_idx = 0
        if floor_idx not in self.floor_levels:
            self.floor_levels[floor_idx] = create_id()
        h_within = h_mm - floor_idx * self.floor_height_mm
        self.net.nodes[nid] = PipeNode(x=x_mm, y=y_mm, h=h_within)
        return nid

    def floor_id_for_node(self, nid: str) -> str:
        """Return the floor ID for a node based on its vertical position."""
        _, _, h = self.node_coords[nid]
        h_mm = int(h * 1000)
        if self.floor_height_mm:
            floor_idx = (
                h_mm // self.floor_height_mm
                if h_mm >= 0
                else -(-h_mm // self.floor_height_mm + 1)
            )
        else:
            floor_idx = 0
        if floor_idx not in self.floor_levels:
            self.floor_levels[floor_idx] = create_id()
        return self.floor_levels[floor_idx]


def _emit_chain(
    ctx: _PipeConvCtx,
    chain: _PipeChain,
    start_nid: str,
) -> None:
    """Recursively emit PipeNet objects from an oriented chain tree."""
    ori = chain.orientation or (1, 0)
    sx, sy, sh = ctx.node_coords[start_nid]

    # --- Zero-length chain (junction or radiator leaf) ---
    if chain.length_mm <= 0:
        # Collect radiator info for room code (not emitted to PipeNet)
        if chain.terminal_rad is not None:
            end_dn = chain.dn_events[-1][1] if chain.dn_events else ""
            _collect_radiator(ctx, chain.terminal_rad, start_nid, ori, end_dn)
        # Emit valve events attached at this junction
        for _, v_dn, v_name in chain.valve_events:
            _attach_valve(ctx, start_nid, v_dn, v_name)
        # Gather all sub-chains, separating verticals for merge pairing
        all_subs: list[_PipeChain] = []
        for _off, sub_chains in chain.branches:
            all_subs.extend(sub_chains)
        v_up = [sc for sc in all_subs if sc.is_vertical and sc.vert_up]
        v_down = [sc for sc in all_subs if sc.is_vertical and not sc.vert_up]
        h_chains_sub = [sc for sc in all_subs if not sc.is_vertical]
        # Pair up+down verticals and merge into single risers
        _emit_paired_risers(ctx, v_up, v_down, start_nid)
        # Emit remaining horizontal chains
        for sc in h_chains_sub:
            _emit_chain(ctx, sc, start_nid)
        return

    # --- Vertical chains become Riser objects ---
    if chain.is_vertical:
        _emit_riser(ctx, chain, start_nid)
        return

    # --- Absorb very short horizontal stubs into parent junction ---
    _SHORT_STUB_MM = 300
    if (
        chain.length_mm < _SHORT_STUB_MM
        and chain.terminal_rad is None
        and not chain.valve_events
    ):
        for _off, sub_chains in chain.branches:
            for sc in sub_chains:
                _emit_chain(ctx, sc, start_nid)
        return

    # --- Collect junction offsets to determine intermediate nodes ---
    junction_map: dict[int, list[_PipeChain]] = {}
    for off, subs in chain.branches:
        junction_map.setdefault(off, []).extend(subs)
    offsets = sorted(set(junction_map) | {0, chain.length_mm})
    # always include start (0) and end

    # --- Build route nodes (horizontal: only x, y change; h stays) ---
    dx, dy = ori
    route: list[tuple[int, str]] = []  # (offset_mm, node_id)
    for off in offsets:
        if off == 0:
            route.append((0, start_nid))
        else:
            frac = off / chain.length_mm
            nx = sx + dx * chain.length_mm / 1000 * frac
            ny = sy + dy * chain.length_mm / 1000 * frac
            nid = ctx.add_node(nx, ny, sh)
            route.append((off, nid))

    # --- Build pipe timeline ---
    if len(route) >= 2:
        timeline: dict[int, PipeEvent] = {}
        current_dn: str | None = None

        for idx, (off, nid) in enumerate(route):
            key = idx * NODE_SPACING
            # Determine DN at this offset
            dn_here: str | None = None
            for dn_off, dn_val in chain.dn_events:
                if dn_off <= off:
                    dn_here = dn_val
            if dn_here is not None and dn_here != current_dn:
                timeline[key] = PipeEvent(node=nid, kind=dn_here)
                current_dn = dn_here
            else:
                timeline[key] = PipeEvent(node=nid)

        # Place valves
        for v_off, v_dn, v_name in chain.valve_events:
            # Find surrounding route segment
            prev_idx = 0
            for idx, (off, _) in enumerate(route):
                if off <= v_off:
                    prev_idx = idx
                else:
                    break
            next_idx = min(prev_idx + 1, len(route) - 1)
            prev_off = route[prev_idx][0]
            next_off = route[next_idx][0]
            seg_len = next_off - prev_off
            if seg_len > 0:
                frac = min(max((v_off - prev_off) / seg_len, 0.05), 0.95)
            else:
                frac = 0.5
            prev_key = prev_idx * NODE_SPACING
            next_key = next_idx * NODE_SPACING
            vk = prev_key + round(frac * (next_key - prev_key))
            while vk in timeline:
                vk += 1
            valve_id = create_id()
            ctx.net.valves[valve_id] = BalancingValve(name=v_name, dn=v_dn)
            timeline[vk] = PipeEvent(valve=valve_id)

        name = _range_name(chain.names) if chain.names else ""
        floor_id = ctx.floor_id_for_node(start_nid)
        ctx.net.pipes[create_id()] = Pipe(
            timeline=timeline,
            name=name,
            floors=[floor_id],
        )

    # --- Collect terminal radiator info for room code ---
    end_nid = route[-1][1]
    if chain.terminal_rad is not None:
        end_dn = chain.dn_events[-1][1] if chain.dn_events else ""
        _collect_radiator(ctx, chain.terminal_rad, end_nid, ori, end_dn)

    # --- Recurse into branches ---
    for off, nid in route:
        if off in junction_map:
            for sc in junction_map[off]:
                _emit_chain(ctx, sc, nid)


def _collect_radiator(
    ctx: _PipeConvCtx,
    rad_info: dict,
    node_nid: str,
    orientation: tuple,
    dn: str = "",
) -> None:
    """Collect radiator information into *ctx.collected_radiators*.

    Instead of emitting a Radiator object into PipeNet, we store the
    radiator metadata so that room code instantiation can create
    CalcRadiator objects at calc time.

    A short connecting pipe (500 mm) is emitted from *node_nid* to the
    offset radiator position so that the PipeNet topology is explicit.
    """
    rad_code = ""
    rad_name = ""
    radt = rad_info.get("radt")
    if isinstance(radt, dict):
        rad_code = radt.get("code", "")
        if not rad_code and "nominalP" in radt and "dT" in radt:
            power = radt["nominalP"] * (50.0 / radt["dT"]) ** 1.3
            rad_code = f"{power:.0f}W"
    info_name = rad_info.get("name", "").strip()
    if info_name.lower() not in (
        "radiator",
        "patteri",
    ) and not _is_generic_radiator_type_name(info_name):
        rad_name = info_name
    if not rad_name and isinstance(radt, dict):
        radt_name = radt.get("name", "").strip()
        if radt_name and not _is_generic_radiator_type_name(radt_name):
            rad_name = radt_name

    rad_length = _extract_radiator_length(rad_code)
    px, py = orientation
    if abs(px) < 0.01 and abs(py) < 0.01:
        dir_x, dir_y = 1.0, 0.0
    else:
        mag = (px * px + py * py) ** 0.5
        dir_x, dir_y = px / mag, py / mag
    rad_endpoint = (round(rad_length * dir_x), round(rad_length * dir_y))

    node = ctx.net.nodes[node_nid]
    room_id = ""
    room_rad = ""
    if isinstance(radt, dict):
        rm = ctx.radt_room_map.get(id(radt))
        if rm is not None:
            room_id, room_rad = rm

    floor_id = ctx.floor_id_for_node(node_nid)

    # Offset the radiator 500 mm along its direction so that multiple
    # radiators branching from the same junction don't overlap.
    # Emit a short connecting pipe from the junction to the offset point.
    _RAD_OFFSET_MM = 500
    ox = round(_RAD_OFFSET_MM * dir_x)
    oy = round(_RAD_OFFSET_MM * dir_y)

    # Create offset node and a connecting pipe stub
    _, _, h = ctx.node_coords[node_nid]
    rad_nid = ctx.add_node(
        (node.x + ox) / 1000.0,
        (node.y + oy) / 1000.0,
        h,
    )
    stub_timeline: dict[int, PipeEvent] = {
        0: PipeEvent(node=node_nid, kind=dn) if dn else PipeEvent(node=node_nid),
        NODE_SPACING: PipeEvent(node=rad_nid),
    }
    ctx.net.pipes[create_id()] = Pipe(
        timeline=stub_timeline, name="", floors=[floor_id]
    )

    rad_node = ctx.net.nodes[rad_nid]
    ctx.collected_radiators.append(
        CollectedRadiator(
            room_id=room_id,
            room_rad=room_rad,
            name=rad_name,
            code=rad_code,
            x=rad_node.x,
            y=rad_node.y,
            endpoint=rad_endpoint,
            floor_id=floor_id,
        )
    )


def _build_riser_floors(
    ctx: _PipeConvCtx,
    chain: _PipeChain,
    route: list[tuple[int, str]],
) -> dict[str, str]:
    """Build a floor_id → DN mapping for a riser chain's route.

    For each route node we resolve its floor and the DN active at that
    offset along the chain.
    """
    result: dict[str, str] = {}
    current_dn = chain.dn_events[0][1] if chain.dn_events else ""
    for off, nid in route:
        # Resolve DN at this offset
        dn_here = current_dn
        for dn_off, dn_val in chain.dn_events:
            if dn_off <= off:
                dn_here = dn_val
        fid = ctx.floor_id_for_node(nid)
        if fid not in result:
            result[fid] = dn_here
    return result


def _emit_paired_risers(
    ctx: _PipeConvCtx,
    v_up: list[_PipeChain],
    v_down: list[_PipeChain],
    start_nid: str,
) -> None:
    """Merge up and down vertical chains into risers.

    Any up+down pair from the same junction is merged into a single riser.
    Unpaired verticals (when counts differ) become standalone risers.

    Risers can only be offset by dedup logic if there are multiple ups or
    multiple downs at this junction (rare special case).
    """
    can_offset = len(v_up) > 1 or len(v_down) > 1

    # Pair up as many up+down combinations as possible
    paired_down: set[int] = set()
    for uc in v_up:
        # Find first unpaired down chain
        for dc in v_down:
            if id(dc) not in paired_down:
                paired_down.add(id(dc))
                _emit_merged_riser(ctx, uc, dc, start_nid)
                break
        else:
            # No unpaired down found, emit up as standalone
            _emit_riser(ctx, uc, start_nid, can_offset=can_offset)

    # Emit unpaired down chains
    for dc in v_down:
        if id(dc) not in paired_down:
            _emit_riser(ctx, dc, start_nid, can_offset=can_offset)


def _emit_merged_riser(
    ctx: _PipeConvCtx,
    up_chain: _PipeChain,
    down_chain: _PipeChain,
    start_nid: str,
) -> None:
    """Emit a single Riser from a paired up + down vertical chain.

    Builds route nodes for both directions from the shared start node,
    collects floors from both, and emits one Riser.  Terminal radiators
    and branches from both chains are recursed into.
    """

    def _build_riser_route(
        chain: _PipeChain,
    ) -> tuple[list[tuple[int, str]], dict[int, list[_PipeChain]]]:
        sx, sy, sh = ctx.node_coords[start_nid]
        sign = 1 if chain.vert_up else -1
        junction_map: dict[int, list[_PipeChain]] = {}
        for off, subs in chain.branches:
            junction_map.setdefault(off, []).extend(subs)
        offsets = sorted(set(junction_map) | {0, chain.length_mm})
        route: list[tuple[int, str]] = []
        for off in offsets:
            if off == 0:
                route.append((0, start_nid))
            else:
                frac = off / chain.length_mm
                nh = sh + sign * chain.length_mm / 1000 * frac
                nid = ctx.add_node(sx, sy, nh)
                route.append((off, nid))
        return route, junction_map

    up_route, up_jmap = _build_riser_route(up_chain)
    down_route, down_jmap = _build_riser_route(down_chain)

    # Build floors dict from both routes
    riser_floors: dict[str, str] = {}
    for chain, route in [
        (down_chain, list(reversed(down_route))),
        (up_chain, up_route),
    ]:
        riser_floors.update(_build_riser_floors(ctx, chain, route))

    start_node = ctx.net.nodes[start_nid]
    # Combine names from both directions and merge into a single range name
    names = (down_chain.names or []) + (up_chain.names or [])
    name = _range_name(names) if names else ""

    ctx.net.risers[create_id()] = Riser(
        x=start_node.x,
        y=start_node.y,
        floors=riser_floors,
        name=name,
        _can_offset=False,  # Merged risers are always kept at (0,0)
    )

    # Terminal radiators
    if up_chain.terminal_rad is not None:
        end_nid = up_route[-1][1]
        up_dn = up_chain.dn_events[-1][1] if up_chain.dn_events else ""
        _collect_radiator(
            ctx, up_chain.terminal_rad, end_nid, up_chain.orientation or (1, 0), up_dn
        )
    if down_chain.terminal_rad is not None:
        end_nid = down_route[-1][1]
        down_dn = down_chain.dn_events[-1][1] if down_chain.dn_events else ""
        _collect_radiator(
            ctx,
            down_chain.terminal_rad,
            end_nid,
            down_chain.orientation or (1, 0),
            down_dn,
        )

    # Recurse into branches for both chains
    for off, nid in up_route:
        if off in up_jmap:
            for sc in up_jmap[off]:
                _emit_chain(ctx, sc, nid)
    for off, nid in down_route:
        if off in down_jmap:
            for sc in down_jmap[off]:
                _emit_chain(ctx, sc, nid)


def _dedup_risers(ctx: _PipeConvCtx) -> None:
    """Offset risers that overlap at the same (x, y) coordinates.

    After all chains are emitted, risers sharing the same (x, y) that are
    marked as can_offset are moved in 500 mm steps to avoid overlap.
    For each offset riser a short connector pipe is created linking the
    original position to the new one.

    Risers are only marked as can_offset when they are unpaired and there
    are multiple ups or multiple downs at their junction.
    """
    _OFFSET_STEP = 500  # mm
    # Cardinal offset directions to try
    _DIRS = [(1, 0), (0, 1), (-1, 0), (0, -1)]

    # Group riser IDs by (x, y)
    by_pos: dict[tuple[int, int], list[str]] = {}
    for rid, riser in ctx.net.risers.items():
        by_pos.setdefault((riser.x, riser.y), []).append(rid)

    # All occupied positions (for avoiding further collisions)
    occupied: set[tuple[int, int]] = set(by_pos)

    for pos, rids in by_pos.items():
        if len(rids) <= 1:
            continue

        # Only offset risers that are marked as can_offset
        offsettable = [rid for rid in rids if ctx.net.risers[rid]._can_offset]
        if not offsettable:
            # No offsettable risers, leave all in place
            continue

        # Keep the first riser in place, offset the rest if they're offsettable
        for _i, rid in enumerate(rids[1:], 1):
            riser = ctx.net.risers[rid]
            if not riser._can_offset:
                # This riser can't be offset, skip it
                continue

            # Find an unoccupied offset position
            placed = False
            for step in range(1, 20):
                for dxi, dyi in _DIRS:
                    nx = pos[0] + dxi * _OFFSET_STEP * step
                    ny = pos[1] + dyi * _OFFSET_STEP * step
                    if (nx, ny) not in occupied:
                        occupied.add((nx, ny))
                        old_x, old_y = riser.x, riser.y
                        # Create connector pipe from old position to new
                        _create_riser_connector(ctx, old_x, old_y, nx, ny, riser)
                        # Move riser
                        ctx.net.risers[rid] = Riser(
                            x=nx,
                            y=ny,
                            floors=riser.floors,
                            name=riser.name,
                            _can_offset=False,  # Already positioned, don't offset again
                        )
                        placed = True
                        break
                if placed:
                    break


def _create_riser_connector(
    ctx: _PipeConvCtx,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    riser: Riser,
) -> None:
    """Create a short horizontal pipe connecting an original riser position
    to its offset location.  Uses the first floor's DN."""
    # Find or create nodes at both positions.
    # Use the riser's first floor to determine the h value.
    floor_ids = list(riser.floors.keys())
    floor_id = floor_ids[0] if floor_ids else ""
    dn = riser.floors[floor_id] if floor_id else ""
    h_mm = 0

    nid1 = create_id()
    ctx.net.nodes[nid1] = PipeNode(x=x1, y=y1, h=h_mm)
    nid2 = create_id()
    ctx.net.nodes[nid2] = PipeNode(x=x2, y=y2, h=h_mm)

    timeline = {
        0: PipeEvent(node=nid1, kind=dn or None),
        NODE_SPACING: PipeEvent(node=nid2),
    }
    ctx.net.pipes[create_id()] = Pipe(
        timeline=timeline,
        name="",
        floors=[floor_id] if floor_id else [],
    )


def _emit_riser(
    ctx: _PipeConvCtx,
    chain: _PipeChain,
    start_nid: str,
    can_offset: bool = False,
) -> None:
    """Convert a vertical chain into a Riser object.

    Collects all floor levels spanned by the chain and emits a Riser
    with the appropriate (x, y), DN, floor range, and name.
    Also creates nodes at each floor level for future pipe connections,
    and recurses into any branches (horizontal chains at each floor).
    """
    sx, sy, sh = ctx.node_coords[start_nid]
    sign = 1 if chain.vert_up else -1

    # Build route nodes along the riser (only height changes)
    junction_map: dict[int, list[_PipeChain]] = {}
    for off, subs in chain.branches:
        junction_map.setdefault(off, []).extend(subs)
    offsets = sorted(set(junction_map) | {0, chain.length_mm})

    route: list[tuple[int, str]] = []
    for off in offsets:
        if off == 0:
            route.append((0, start_nid))
        else:
            frac = off / chain.length_mm
            nh = sh + sign * chain.length_mm / 1000 * frac
            nid = ctx.add_node(sx, sy, nh)
            route.append((off, nid))

    # Build floors dict (floor_id → DN at that floor)
    riser_floors = _build_riser_floors(ctx, chain, route)

    # Get x, y from start node (all riser nodes share x, y)
    start_node = ctx.net.nodes[start_nid]
    name = _range_name(chain.names) if chain.names else ""

    ctx.net.risers[create_id()] = Riser(
        x=start_node.x,
        y=start_node.y,
        floors=riser_floors,
        name=name,
        _can_offset=can_offset,
    )

    # Collect terminal radiator at the end of the riser (if any)
    end_nid = route[-1][1]
    if chain.terminal_rad is not None:
        end_dn = chain.dn_events[-1][1] if chain.dn_events else ""
        _collect_radiator(
            ctx, chain.terminal_rad, end_nid, chain.orientation or (1, 0), end_dn
        )

    # Recurse into branches at each junction along the riser
    for off, nid in route:
        if off in junction_map:
            for sc in junction_map[off]:
                _emit_chain(ctx, sc, nid)


def _attach_valve(ctx: _PipeConvCtx, nid: str, valve_dn: str, valve_name: str) -> None:
    """Create a standalone BalancingValve object near *nid*.

    Used when a valve sits at a zero-length junction that has no
    associated Pipe timeline to host it.  The valve is not placed on any
    pipe — it exists only as metadata.
    """
    # We simply record it; downstream code may attach it to an adjacent pipe.
    # For now the valve is stored but not placed on a timeline.
    valve_id = create_id()
    ctx.net.valves[valve_id] = BalancingValve(name=valve_name, dn=valve_dn)


def _build_floors(ctx: _PipeConvCtx) -> list[Floor]:
    """Create Floor objects for all levels in range, including intermediaries."""
    if not ctx.floor_levels:
        return []
    min_idx = min(ctx.floor_levels)
    max_idx = max(ctx.floor_levels)
    # Ensure all intermediary floors exist
    for idx in range(min_idx, max_idx + 1):
        if idx not in ctx.floor_levels:
            ctx.floor_levels[idx] = create_id()
    floors = []
    for idx in range(min_idx, max_idx + 1):
        floor_id = ctx.floor_levels[idx]
        base_mm = idx * ctx.floor_height_mm
        floors.append(
            Floor(
                id=floor_id,
                name=str(idx),
                height=f"{ctx.floor_height_mm / 1000:.1f}",
                baseHeight=f"{base_mm / 1000:.1f}",
            )
        )
    return floors
