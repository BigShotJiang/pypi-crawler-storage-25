from io import BytesIO
from logging import getLogger
from typing import TYPE_CHECKING

import fitz  # PyMuPDF
from PIL import Image

if TYPE_CHECKING:
    from pathlib import Path

# Silence decompression bomb warnings for large images (e.g., TIFFs)
Image.MAX_IMAGE_PIXELS = None

logger = getLogger("jacloud")


def _get_image_dpi(img: Image.Image) -> tuple[int, int]:
    """Extract DPI from image metadata, defaulting to 300 if not present."""
    dpi_x, dpi_y = 300, 300
    if "dpi" in img.info:
        dpi = img.info["dpi"]
        if isinstance(dpi, tuple):
            dpi_x, dpi_y = dpi
        else:
            dpi_x = dpi_y = dpi
    return dpi_x, dpi_y


def _fix_exif_rotation(img: Image.Image, path: Path) -> Image.Image:
    """Fix image rotation based on EXIF orientation data."""
    try:
        rotate_values = {3: 180, 6: 270, 8: 90}
        orientation = img._getexif().get(274)
        if orientation in rotate_values:
            logger.debug("Rotating preview %s by %s", path, rotate_values[orientation])
            img = img.rotate(rotate_values[orientation], expand=True)
    except AttributeError:
        ...
    except Exception as e:
        logger.error("Error rotating preview image: %s", e)
    return img


def process_image(path: Path, *, maxsize: int) -> bytes:
    """Process image for thumbnail preview, scaling to maxsize."""
    img = Image.open(path)
    w, h = img.size
    img.thumbnail((min(w, maxsize), min(h, maxsize)), Image.Resampling.LANCZOS)
    img = _fix_exif_rotation(img, path)
    # Save as AVIF with fast encoding settings
    imgdata = BytesIO()
    img.save(imgdata, format="avif", quality=60, speed=8)
    return imgdata.getvalue()


def process_plan(path: Path, *, dpi: int) -> bytes:
    """Process floor plan image, scaling to requested DPI output."""
    img = Image.open(path)
    w, h = img.size
    dpi_x, dpi_y = _get_image_dpi(img)
    scale_x = dpi / dpi_x
    scale_y = dpi / dpi_y
    new_w = round(w * scale_x)
    new_h = round(h * scale_y)
    img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
    img = _fix_exif_rotation(img, path)
    # Save as AVIF with fast encoding settings
    imgdata = BytesIO()
    img.save(imgdata, format="avif", quality=60, speed=8, dpi=(dpi, dpi))
    return imgdata.getvalue()


def process_pdf(path: Path, *, dpi: int, page_number: int = 0) -> bytes:
    """Convert PDF page to AVIF image at requested DPI."""
    pdf = fitz.open(path)
    page = pdf.load_page(page_number)
    pix = page.get_pixmap(dpi=dpi)
    # Convert to PIL Image to set DPI metadata
    img = Image.frombytes(
        "RGBA" if pix.alpha else "RGB", (pix.width, pix.height), pix.samples
    )
    imgdata = BytesIO()
    img.save(imgdata, format="avif", quality=60, speed=8, dpi=(dpi, dpi))
    return imgdata.getvalue()
