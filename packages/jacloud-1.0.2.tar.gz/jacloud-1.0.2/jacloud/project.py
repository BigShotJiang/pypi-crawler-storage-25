from datetime import datetime

from msgspec import Struct, field

from jacloud.sci.pipe import INS_SUFFIX, LIGHT_INS_SUFFIX

# --- Pipe network data structures ---

NODE_SPACING = 65536  # Default timeline key spacing between nodes


def strip_dn(dn: str) -> str:
    """Strip the insulation suffix from a DN string for pipe-table lookups."""
    return dn.removesuffix(INS_SUFFIX).removesuffix(LIGHT_INS_SUFFIX)


def dn_insulated(dn: str) -> bool:
    """Return True if the DN string carries any insulation suffix."""
    return dn.endswith((INS_SUFFIX, LIGHT_INS_SUFFIX))


def get_insulation(dn: str) -> int:
    """Return insulation level from DN string: 0=none, 1=normal, 2=light."""
    if dn.endswith(INS_SUFFIX):
        return 1
    if dn.endswith(LIGHT_INS_SUFFIX):
        return 2
    return 0


def with_insulation(dn: str, level: int) -> str:
    """Add insulation suffix to DN string based on level (0=none, 1=normal, 2=light)."""
    base = strip_dn(dn)
    if level == 1:
        return base + INS_SUFFIX
    if level == 2:
        return base + LIGHT_INS_SUFFIX
    return base


class PipeNode(Struct):
    """Any point in the pipe network: junction, bend, component terminal."""

    x: int  # mm, horizontal position on floor plan
    y: int  # mm, horizontal position on floor plan
    h: int  # mm, height from floor base level


class PipeEvent(Struct, omit_defaults=True):
    """What exists at a timeline position on a pipe.

    Each timeline key can carry any combination of:
    - **node**: a geometry point (junction, bend, terminal) — the key
      references a PipeNode in ``PipeNet.nodes``.
    - **kind**: pipe specification (e.g. ``"Cu 22"`` or ``"Cu 22 Ins"``
      for insulated) that takes effect from this key onward until the
      next kind event (or end of pipe).  Append ``" Ins"`` suffix for
      insulation; use :func:`strip_dn` to get the bare type for lookups.
    - **valve**: key into ``PipeNet.valves`` for a balancing valve here.

    The very first event (lowest key) must define both *node* and *kind*
    so the pipe has initial geometry and properties.
    """

    node: str | None = None  # End, curve or junction
    kind: str | None = None  # Pipe type change
    valve: str | None = None  # Balancing valve key (ref into PipeNet.valves)


class Pipe(Struct, omit_defaults=True):
    """Horizontal pipe run as a single component.

    ``timeline`` maps arbitrary int keys → events.  Keys are ordered but
    the spacing is abstract (not mm).  Convention: nodes are placed at
    multiples of NODE_SPACING (0, 65536, 131072, …); events between nodes
    (property changes, valves) use intermediate keys proportional to their
    physical position within the span.

    The first event (smallest key) must have both ``node`` and ``dn``.
    """

    timeline: dict[int, PipeEvent]  # ordered int key → event
    name: str = ""  # Computed name (range heuristic)
    floors: list[str] = []  # Floor IDs where this pipe exists

    # -- Convenience helpers -----------------------------------------------

    def node_keys(self) -> list[tuple[int, str]]:
        """Sorted (timeline_key, node_id) pairs for events that carry a node."""
        return sorted(
            ((k, ev.node) for k, ev in self.timeline.items() if ev.node is not None),
            key=lambda t: t[0],
        )

    def route(self) -> list[str]:
        """Ordered node IDs."""
        return [nid for _, nid in self.node_keys()]

    def dn_keys(self) -> list[tuple[int, str]]:
        """Sorted (timeline_key, dn) for events that set a dn."""
        return sorted(
            ((k, ev.kind) for k, ev in self.timeline.items() if ev.kind is not None),
            key=lambda t: t[0],
        )

    def first_dn(self) -> str:
        """Return the initial DN specification, or empty string."""
        dks = self.dn_keys()
        return dks[0][1] if dks else ""


class BalancingValve(Struct, omit_defaults=True):
    """Balancing valve on the pipe network.

    The actual valve model is determined at calculation time by
    combining ``project.valvebal`` (group name, e.g. ``"Stad/Staf"``)
    with this valve's ``dn`` (e.g. ``"20"``).  If the group does not
    carry the exact DN, the nearest available size is used.

    ``kind`` may be set to lock a specific valve model key
    (e.g. ``"Stad20"``), overriding the project default.
    """

    name: str = ""  # Component name from design file
    dn: str = ""  # Valve DN size (e.g. "20"), derived from adjacent pipe
    preset: str | None = None  # Preset value (if locked)
    kind: str = ""  # Full valve key override (empty = use project.valvebal + dn)


class Riser(Struct, omit_defaults=True):
    """Vertical riser connecting pipe nodes across floors."""

    x: int  # mm, horizontal position on plan
    y: int  # mm, horizontal position on plan
    floors: dict[
        str, str
    ]  # floor_id → DN (pipe type passing through that floor's ceiling)
    name: str = ""
    _can_offset: bool = (
        False  # Internal flag: whether this riser can be offset by dedup
    )


class HX(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Heat exchanger point (HX) with its own position.

    Pipe ends within a 1000x1000 square centered at (x, y) are implicitly connected.
    """

    x: int  # X coordinate in mm
    y: int  # Y coordinate in mm
    floor: str  # Floor ID
    name: str = ""  # HX name/label
    t_supply: str = ""  # Optional supply temperature override (degC)


class PipeNet(Struct, forbid_unknown_fields=True):
    """Complete pipe network."""

    nodes: dict[str, PipeNode]
    pipes: dict[str, Pipe]
    valves: dict[str, BalancingValve]
    hxs: dict[str, HX] = {}  # Heat exchanger points
    risers: dict[str, Riser] = {}  # Vertical risers


class SurfaceType(Struct, forbid_unknown_fields=True, omit_defaults=True):
    u: str
    default_y: str | None = None
    t: str | None = None


class Coords(Struct, forbid_unknown_fields=True):
    x: int
    y: int


class RoomOpening(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """An opening (window/door) subtracted from the preceding surface."""

    material: str  # Opening material key (refs project.surfaces)
    width: int  # Width in mm
    height: int = 0  # Height in mm (0 = use material default_y)


class RoomSurface(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """A surface element (wall, floor, ceiling, …) in a room.

    ``x`` and ``y`` are dimensions in millimetres.  Area = x * y (mm²).
    Whether y represents height, depth, or a second side is unspecified —
    they are simply the two coordinates multiplied for heat-loss area.
    If ``y`` is 0, the material's ``default_y`` is used.
    """

    material: str  # Surface material key (refs project.surfaces)
    x: int  # First dimension in mm
    y: int = 0  # Second dimension in mm (0 = use material default_y)
    openings: list[RoomOpening] = []  # Openings cut from this surface


class RoomHeatSource(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Internal heat source or riser heat gain/loss."""

    power: int = 0  # Direct power in watts (positive = gain)
    riser: str = ""  # Riser pipe type, e.g. "Cu 22"
    length: int = 0  # Riser length in mm


class RadiatorRoomRef(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Binding of a Radiator to a room.

    ``millis`` is the share of the room's total heat-loss that this
    radiator handles, expressed in thousandths (1000 = 100%).
    """

    id: str  # Room ID
    millis: int = 1000  # Thousandths of room total output (1000 = 100%)


class Room(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Room v2: structured surfaces defining the thermal envelope.

    ``surfaces`` defines the thermal envelope (shared across all floors).
    Radiator binding is stored on each :class:`Radiator` via its
    ``room`` field, not here.
    """

    name: str
    surfaces: list[RoomSurface] = []
    heat: list[RoomHeatSource] = []  # Internal heat gains/losses


class RadiatorValues(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Shared radiator value fields used for base definition and per-floor overrides.

    For floor overrides, omitted fields fall back to the base.
    """

    code: str = ""  # Radiator type code, e.g. "1000c22"; "" = use base
    valve: str = ""  # Valve override (empty = project default)
    preset: str = ""  # Preset value if locked (empty = auto)
    name: str = ""  # Optional label


class Radiator(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """A radiator placed on a floor plan (or standalone without a plan).

    Position is an anchor point ``(x1, y1)`` plus an ``angle`` in
    milliturns (0–999, where 1000 ≡ one full turn / 2π).  The rendered
    length is derived from the radiator code.

    ``plan`` links the radiator to a specific plan image.  When empty the
    radiator exists independently (for projects with only floors).

    ``floors`` maps floor IDs to per-floor overrides.  When set (even empty),
    only listed floor IDs get the radiator.  When ``None`` (absent), the
    radiator appears on all floors of its ``plan``.
    """

    code: str  # Required base radiator type code
    x1: int  # Anchor point X (mm)
    y1: int  # Anchor point Y (mm)
    angle: int = 0  # Orientation in milliturns (0–999; 1000 = 2π)
    length: int | None = (
        None  # Override geometric length (mm); None = derived from code
    )
    plan: str = ""  # Plan ID (empty = not linked to any plan)
    name: str = ""  # Optional label
    valve: str = ""  # Valve override (empty = project default)
    preset: str = ""  # Preset value if locked (empty = auto)
    floors: dict[str, RadiatorValues] | None = (
        None  # floor_id → overrides; None = all plan floors
    )
    room: RadiatorRoomRef | None = None  # Room binding + power share


class Plan(Struct, forbid_unknown_fields=True):
    image: str
    scale: int
    pos: Coords
    sort: float
    dpi: int = 127


class Floor(Struct, forbid_unknown_fields=True, omit_defaults=True):
    id: str
    name: str
    height: str
    baseHeight: str  # noqa: N815
    plan: str | None = None


# --- Building geometry system ---


class Vertex(Struct, forbid_unknown_fields=True):
    """A shared vertex in the envelope coordinate system (mm)."""

    x: int
    y: int


class WallOpening(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Opening definition attached to a wall timeline event."""

    material: str  # Opening material/kind (e.g. "window", "door")
    width: int  # Opening width in mm (fixed)
    height: str | None = None  # Optional opening height override (m)
    side: int = 0  # 0=right side of wall (default), 1=left side
    hand: str = "right"  # Door hinge handedness on the opening side
    style: str = "single"  # Opening style (e.g. single/double/sliding)


class WallEvent(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """What exists at a timeline position on a wall (boundary, hole, or divider).

    Each timeline key can carry any combination of:
    - **node**: a geometry point (vertex key) — the corner of a wall.
    - **material**: surface material override that takes effect from this
      key onward until the next material event (or end of wall).
    - **opening**: an opening (window/door) starting at
      this timeline position with a fixed width in mm.  The position is
      interpolated linearly between the two surrounding node events.
    """

    node: str | None = None  # Vertex ID (corner point)
    material: str | None = None  # Material change from here onward
    opening: WallOpening | None = None


class Hole(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """A hole (void) within an outer boundary.  CW winding order.

    ``timeline`` maps int keys → WallEvent, forming a closed polygon.
    Nodes are placed at multiples of NODE_SPACING.
    """

    timeline: dict[int, WallEvent]

    def node_keys(self) -> list[tuple[int, str]]:
        """Sorted (timeline_key, vertex_id) pairs for node events."""
        return sorted(
            ((k, ev.node) for k, ev in self.timeline.items() if ev.node),
            key=lambda t: t[0],
        )

    def route(self) -> list[str]:
        """Ordered vertex IDs forming the hole polygon."""
        return [vid for _, vid in self.node_keys()]


class Inner(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Inner wall within a boundary.

    ``timeline`` maps int keys → WallEvent, forming an open segment.
    Must have at least two node events (start and end).
    """

    timeline: dict[int, WallEvent]

    def node_keys(self) -> list[tuple[int, str]]:
        """Sorted (timeline_key, vertex_id) pairs for node events."""
        return sorted(
            ((k, ev.node) for k, ev in self.timeline.items() if ev.node),
            key=lambda t: t[0],
        )

    def route(self) -> list[str]:
        """Ordered vertex IDs (start → end)."""
        return [vid for _, vid in self.node_keys()]


class Building(Struct, forbid_unknown_fields=True, omit_defaults=True):
    """Self-contained building geometry on one floorplan.

    ``timeline`` maps int keys → WallEvent, forming a closed polygon.
    Nodes at multiples of NODE_SPACING.  CCW winding = exterior.

    Vertices are local to this building. Holes and inner walls are stored
    directly here.
    """

    vertices: dict[str, Vertex]
    timeline: dict[int, WallEvent]
    plan: str
    holes: dict[str, Hole] = {}
    inners: dict[str, Inner] = {}

    def node_keys(self) -> list[tuple[int, str]]:
        """Sorted (timeline_key, vertex_id) pairs for node events."""
        return sorted(
            ((k, ev.node) for k, ev in self.timeline.items() if ev.node),
            key=lambda t: t[0],
        )

    def route(self) -> list[str]:
        """Ordered vertex IDs forming the boundary polygon."""
        return [vid for _, vid in self.node_keys()]


class RadCond(Struct, forbid_unknown_fields=True):
    """Dedicated radiator condition regime for roomless radiators."""

    supply: float
    return_: float = field(name="return")
    env: float


class Project(Struct, forbid_unknown_fields=True, kw_only=True):
    created: datetime
    name: str
    t_supply: str
    t_outdoor: str
    t_env: str
    ventilation: str
    intheat: str = "0"
    valve: str
    valve1p: str
    valvebal: str
    thermostat: bool
    dp_rad: str = "10"  # Radiator supply/return dp in kPa
    notes: str = ""
    surfaces: dict[str, SurfaceType] = {}
    rooms: dict[str, Room] = {}
    plans: dict[str, Plan] = {}
    floors: list[Floor] = []
    org_id: str | None = None
    org_name: str | None = None
    pipe1s: dict = {}
    radiators: dict[str, Radiator] = {}
    pipenet: PipeNet = field(
        default_factory=lambda: PipeNet(nodes={}, pipes={}, valves={})
    )
    buildings: dict[str, Building] = {}
    # Optional dedicated radiator conditions for roomless radiators.
    radcond: RadCond | None = None
