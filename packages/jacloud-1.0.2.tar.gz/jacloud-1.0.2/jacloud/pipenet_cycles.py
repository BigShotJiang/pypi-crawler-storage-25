"""Cycle matrix construction for hydraulic network analysis.

Uses DFS spanning tree + chord algorithm to find fundamental cycles.

DFS starts from the HX branch's junction and visits backbone branches
first (sorted before RAD branches in adjacency).  This makes backbone
branches tree edges and RAD branches chords.  Every fundamental cycle
therefore contains the HX backbone (first) and one RAD chord (last).

The Hardy-Cross solver is in :mod:`jacloud.sci.hardy_cross`.
"""

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from scipy import sparse

# Import from sci module
from .pipenet import is_hx_component
from .sci.hardy_cross import FlowArrays, solve_hardy_cross
from .sci.hardy_cross import hardy_cross_iteration as _hardy_cross_iteration_core

if TYPE_CHECKING:
    from jacloud.pipenet import FlowGraph


logger = logging.getLogger(__name__)


def hardy_cross_iteration(
    cm: CycleMatrix, arrays: FlowArrays, damping: float = 0.5
) -> float:
    """Perform one Hardy-Cross iteration (backward-compatible wrapper).

    Delegates to :func:`jacloud.sci.hardy_cross.hardy_cross_iteration`
    after extracting the sparse matrix from *cm*.
    """
    return _hardy_cross_iteration_core(cm.matrix, arrays, damping)


# ---------------------------------------------------------------------------
# Cycle matrix
# ---------------------------------------------------------------------------


@dataclass
class CycleMatrix:
    """Sparse cycle matrix for hydraulic calculations.

    C[num_cycles, num_branches] where each row encodes a cycle:
    +1 for branches traversed in their natural direction,
    -1 for branches traversed opposite.

    Each cycle goes through the HX backbone and one RAD chord.
    """

    matrix: sparse.csr_matrix  # [num_cycles, num_branches]
    branch_keys: list[str]  # Branch key for each column
    branch_index: dict[str, int]  # Branch key -> column index
    junction_keys: list[str]
    junction_index: dict[str, int]

    @property
    def num_cycles(self) -> int:
        return self.matrix.shape[0]

    @property
    def num_branches(self) -> int:
        return self.matrix.shape[1]


def _find_hx_branch(
    graph: FlowGraph, branch_keys: list[str] | None = None
) -> str | None:
    """Find the branch containing the HX component."""
    keys = branch_keys if branch_keys is not None else list(graph.branches.keys())
    for key in keys:
        branch = graph.branches.get(key)
        if branch is None:
            continue
        if any(is_hx_component(comp) for comp in branch.components):
            return key
    return None


def _build_adjacency(
    graph: FlowGraph,
    junction_index: dict[str, int],
    num_junctions: int,
    branch_keys: list[str],
) -> dict[int, list[tuple[int, str, int]]]:
    """Build adjacency for all branches, same-side backbone first.

    Sorts adjacency lists in three tiers:
    0. Same-side backbone (supply→supply or return→return) — tree edges
    1. Cross-side backbone (HX bridge: return→supply) — explored after
       each side is fully spanned, so loop_ edges stay as chords
    2. RAD loop branches (supply→return) — chords, producing HX cycles

    Without this ordering, the DFS may cross to the other side (via HX)
    before spanning the current side, forcing loop_ edges into the tree
    and producing fundamental cycles that lack the HX component.
    """
    adj: dict[int, list[tuple[int, str, int]]] = {i: [] for i in range(num_junctions)}
    for bkey in branch_keys:
        branch = graph.branches[bkey]
        j1, j2 = branch.junctions
        i1, i2 = junction_index[j1], junction_index[j2]
        adj[i1].append((i2, bkey, +1))
        adj[i2].append((i1, bkey, -1))

    def _edge_priority(edge: tuple[int, str, int]) -> int:
        """Sort key: same-side backbone(0) < cross-side backbone(1) < loop(2)."""
        bkey = edge[1]
        if bkey.startswith("loop_"):
            return 2
        branch = graph.branches[bkey]
        j1_side = branch.junctions[0].split(" ", 1)[0]
        j2_side = branch.junctions[1].split(" ", 1)[0]
        return 0 if j1_side == j2_side else 1

    for edges in adj.values():
        edges.sort(key=_edge_priority)
    return adj


def _build_spanning_tree(
    adj: dict[int, list[tuple[int, str, int]]],
    start: int,
    graph: FlowGraph,
) -> tuple[dict[int, tuple[int, str, int] | None], dict[str, bool]]:
    """Prim-like spanning tree preferring same-side backbone edges.

    Uses a priority heap to process edges globally in priority order:
      0. Same-side backbone (supply→supply or return→return)
      1. Cross-side backbone (HX bridge: return→supply)
      2. Loop branches (supply→return RAD bridges)

    This ensures the spanning tree uses maximum backbone edges, leaving
    all loop_ branches as chords.  Every fundamental cycle from a loop_
    chord then traverses the HX bridge (the only supply↔return tree
    crossing), giving each cycle exactly one HX and one RAD.

    A plain DFS fails because depth-first backtracking can reach a
    dead-end junction and cross sides via a loop_ edge before the
    current side is fully spanned.

    Uses dict[str, bool] instead of set for deterministic iteration order.
    """
    import heapq

    parent: dict[int, tuple[int, str, int] | None] = {start: None}
    tree_edges: dict[str, bool] = {}  # Ordered dict for determinism

    heap: list[tuple[int, int, int, int, str, int]] = []
    counter = 0

    def _priority(bkey: str) -> int:
        if bkey.startswith("loop_"):
            return 2
        branch = graph.branches[bkey]
        j1_side = branch.junctions[0].split(" ", 1)[0]
        j2_side = branch.junctions[1].split(" ", 1)[0]
        return 0 if j1_side == j2_side else 1

    def _add_edges(node: int) -> None:
        nonlocal counter
        for neighbor, bkey, direction in adj[node]:
            if neighbor not in parent:
                heapq.heappush(
                    heap, (_priority(bkey), counter, node, neighbor, bkey, direction)
                )
                counter += 1

    _add_edges(start)

    while heap:
        _, _, from_node, neighbor, bkey, direction = heapq.heappop(heap)
        if neighbor in parent:
            continue
        parent[neighbor] = (from_node, bkey, direction)
        tree_edges[bkey] = True
        _add_edges(neighbor)

    return parent, tree_edges


def _trace_to_root(
    node: int, parent: dict[int, tuple[int, str, int] | None]
) -> list[tuple[int, str | None, int]]:
    """Trace from node to spanning-tree root.

    Returns [(node, branch_key, direction_toward_root), ...].
    """
    path: list[tuple[int, str | None, int]] = []
    current = node
    while current in parent:
        p = parent[current]
        if p is None:
            path.append((current, None, 0))
            break
        parent_node, bkey, direction = p
        path.append((current, bkey, -direction))
        current = parent_node
    return path


def _build_cycle_from_chord(
    chord_key: str,
    graph: FlowGraph,
    junction_index: dict[str, int],
    branch_index: dict[str, int],
    parent: dict[int, tuple[int, str, int] | None],
) -> list[tuple[int, int]] | None:
    """Build fundamental cycle from a chord (non-tree) edge.

    The cycle is: chord(j1→j2, +1) closed by tree path j2→LCA→j1.
    _trace_to_root gives directions toward root; we negate path1
    (j1→root becomes root→j1) and keep path2 as-is (j2→root
    direction, which serves as j2→LCA).
    """
    branch = graph.branches.get(chord_key)
    if branch is None:
        return None
    j1, j2 = branch.junctions
    if j1 not in junction_index or j2 not in junction_index:
        logger.warning(
            "pipenet_cycles: skipping chord %s with unknown junction(s): %s, %s",
            chord_key,
            j1,
            j2,
        )
        return None
    i1, i2 = junction_index[j1], junction_index[j2]

    path1 = _trace_to_root(i1, parent)
    path2 = _trace_to_root(i2, parent)

    set1 = {node for node, _, _ in path1}
    lca = next((node for node, _, _ in path2 if node in set1), None)
    if lca is None:
        return None

    # Tree: LCA → j1 (reversed path1 with negated directions)
    tree_j1: list[tuple[int, int]] = []
    for node, bkey, direction in path1:
        if node == lca:
            break  # Stop BEFORE adding edge from LCA
        if bkey is not None:
            tree_j1.append((branch_index[bkey], -direction))

    # Tree: j2 → LCA (path2 directions as-is, j2-toward-root)
    tree_j2: list[tuple[int, int]] = []
    for node, bkey, direction in path2:
        if node == lca:
            break  # Stop BEFORE adding edge from LCA
        if bkey is not None:
            tree_j2.append((branch_index[bkey], direction))

    # Cycle order: tree(j2→LCA) + tree(LCA→j1) + chord(j1→j2)
    cycle: list[tuple[int, int]] = tree_j2 + list(reversed(tree_j1))
    cycle.append((branch_index[chord_key], +1))
    return cycle


def _cycles_to_sparse(
    cycles: list[list[tuple[int, int]]], num_branches: int
) -> sparse.csr_matrix:
    """Convert cycle list to sparse CSR matrix."""
    rows: list[int] = []
    cols: list[int] = []
    data: list[int] = []
    for cycle_idx, cycle in enumerate(cycles):
        for branch_idx, direction in cycle:
            rows.append(cycle_idx)
            cols.append(branch_idx)
            data.append(direction)
    return sparse.csr_matrix(
        (data, (rows, cols)), shape=(len(cycles), num_branches), dtype=np.int8
    )


def build_cycle_matrix(graph: FlowGraph) -> CycleMatrix:
    """Build cycle matrix from FlowGraph using DFS spanning tree.

    Starts DFS from the HX branch's junction and visits backbone
    branches first, so they become tree edges.  RAD branches become
    chords, producing fundamental cycles that each go through the HX
    backbone (backbone first in cycle, RAD chord last).
    """
    raw_branch_keys = sorted(graph.branches.keys(), key=lambda k: k.startswith("loop_"))

    # Sort junction keys for deterministic ordering
    junction_keys = sorted(graph.junctions)
    junction_index = {k: i for i, k in enumerate(junction_keys)}

    # Tolerate corrupted graphs where a branch references a junction key
    # that is absent from graph.junctions; skip those branches.
    invalid_branches: list[tuple[str, str, str]] = []
    branch_keys: list[str] = []
    for bkey in raw_branch_keys:
        branch = graph.branches[bkey]
        j1, j2 = branch.junctions
        if j1 not in junction_index or j2 not in junction_index:
            invalid_branches.append((bkey, j1, j2))
            continue
        branch_keys.append(bkey)

    if invalid_branches:
        missing = sorted(
            {
                j
                for _, j1, j2 in invalid_branches
                for j in (j1, j2)
                if j not in junction_index
            }
        )
        sample = ", ".join(f"{b}:{j1}->{j2}" for b, j1, j2 in invalid_branches[:5])
        logger.warning(
            "pipenet_cycles: skipped %d/%d branches with missing junction refs; "
            "missing_junctions=%s sample=%s",
            len(invalid_branches),
            len(raw_branch_keys),
            missing[:20],
            sample,
        )

    branch_index = {k: i for i, k in enumerate(branch_keys)}
    num_branches = len(branch_keys)

    adj = _build_adjacency(graph, junction_index, len(junction_keys), branch_keys)

    # Start DFS from HX branch's first junction (return side)
    start = 0
    hx_key = _find_hx_branch(graph, branch_keys)
    if hx_key:
        hx_j1 = graph.branches[hx_key].junctions[0]
        start = junction_index.get(hx_j1, 0)

    parent: dict[int, tuple[int, str, int] | None] = {}
    tree_edges: dict[str, bool] = {}  # Ordered dict for determinism
    if junction_keys:
        remaining: set[int] = set(range(len(junction_keys)))
        seed_order: list[int] = [start]

        while remaining:
            seed = seed_order.pop(0) if seed_order else min(remaining)
            if seed not in remaining:
                continue
            comp_parent, comp_tree_edges = _build_spanning_tree(adj, seed, graph)
            parent.update(comp_parent)
            for edge_key in comp_tree_edges:
                tree_edges[edge_key] = True
            remaining -= set(comp_parent)

    chords = [bkey for bkey in branch_keys if bkey not in tree_edges]

    cycles: list[list[tuple[int, int]]] = []
    for chord_key in chords:
        cycle = _build_cycle_from_chord(
            chord_key, graph, junction_index, branch_index, parent
        )
        if cycle:
            cycles.append(cycle)

    matrix = (
        _cycles_to_sparse(cycles, num_branches)
        if cycles
        else sparse.csr_matrix((0, num_branches), dtype=np.int8)
    )

    return CycleMatrix(
        matrix=matrix,
        branch_keys=branch_keys,
        branch_index=branch_index,
        junction_keys=junction_keys,
        junction_index=junction_index,
    )


# ---------------------------------------------------------------------------
# Flow arrays
# ---------------------------------------------------------------------------

HX_HEAD_PRESSURE = 20_000.0  # Default pressure produced by HX (Pa) = 0.2 bar


def build_flow_arrays(
    graph: FlowGraph,
    cm: CycleMatrix,
    resistance: np.ndarray,
    exponent: np.ndarray | None = None,
    *,
    head_pressure: float = HX_HEAD_PRESSURE,
) -> FlowArrays:
    """Build numpy arrays for flow calculation.

    Initial flows must satisfy Kirchhoff's current law (mass balance at
    every junction).  We assign a small initial flow to each chord (the
    RAD branches), then derive tree-edge flows from junction balance.

    The cycle matrix C encodes this: each chord appears in exactly one
    cycle, and the tree edges shared by multiple cycles carry the sum.
    Specifically, tree-edge flow = Σ (chord flows x cycle directions).
    """
    nb = cm.num_branches
    C = cm.matrix  # [num_cycles, num_branches]

    # Assign initial flow to each cycle (will flow through its chord)
    # Tree edges get sum of cycle flows * direction
    # This satisfies mass balance: A @ (C^T @ chord_flows) = 0
    # because A @ C^T = 0 (fundamental property of cycle matrix)
    chord_flow = 0.01  # l/s per chord
    chord_flows_per_cycle = np.ones(cm.num_cycles, dtype=np.float64) * chord_flow
    flows = (C.T @ chord_flows_per_cycle).astype(np.float64)

    # Some flows may be negative (opposing cycle directions cancel)
    # This is correct for mass balance; Hardy-Cross will adjust magnitudes

    head = np.zeros(nb, dtype=np.float64)
    for bkey in cm.branch_keys:
        branch = graph.branches.get(bkey)
        if branch is None:
            continue
        idx = cm.branch_index[bkey]
        if any(is_hx_component(comp) for comp in branch.components):
            head[idx] = head_pressure

    # Default to n=2.0 if exponent array not provided
    if exponent is None:
        exponent = np.full(nb, 2.0, dtype=np.float64)

    return FlowArrays(flows=flows, resistance=resistance, exponent=exponent, head=head)


def set_hx_head(
    arrays: FlowArrays, graph: FlowGraph, cm: CycleMatrix, head_pressure: float
) -> None:
    """Update the HX head pressure in-place."""
    for bkey in cm.branch_keys:
        branch = graph.branches.get(bkey)
        if branch is None:
            continue
        if any(is_hx_component(comp) for comp in branch.components):
            arrays.head[cm.branch_index[bkey]] = head_pressure
            break


def solve_flows(
    graph: FlowGraph,
    resistance: np.ndarray,
    exponent: np.ndarray | None = None,
    max_iterations: int = 2000,
    tolerance: float = 100.0,
    initial_damping: float = 0.15,
) -> tuple[FlowArrays, CycleMatrix]:
    """Run Hardy-Cross iteration to convergence.

    Args:
        graph: FlowGraph from build_flow_graph().
        resistance: Precomputed resistance array from pipenet_resistance.
        exponent: Precomputed exponent array (1.8-2.0). Defaults to 2.0.
        max_iterations: Maximum iteration count.
        tolerance: Convergence threshold on max residual (Pa). Default 100 Pa.
        initial_damping: Starting damping factor (0-1) for stability.

    Returns:
        (FlowArrays with solved flows, CycleMatrix for reference)
    """
    cm = build_cycle_matrix(graph)

    # Ensure resistance is float64
    resistance = np.asarray(resistance, dtype=np.float64)
    if exponent is not None:
        exponent = np.asarray(exponent, dtype=np.float64)
    arrays = build_flow_arrays(graph, cm, resistance, exponent)

    # Use the core Hardy-Cross solver from sci
    solve_hardy_cross(cm.matrix, arrays, max_iterations, tolerance, initial_damping)

    return arrays, cm


# ---------------------------------------------------------------------------
# Solution verification
# ---------------------------------------------------------------------------


@dataclass
class CycleInfo:
    """Details about a cycle for verification reporting."""

    index: int
    residual: float  # Pa
    relative_error: float  # residual / total_dp
    branch_keys: list[str]  # Branches in this cycle
    chord_branch: str  # The RAD branch that defines the cycle


@dataclass
class VerificationResult:
    """Results of solution verification checks."""

    # Mass balance (Kirchhoff's current law at junctions)
    mass_balance_ok: bool
    max_mass_imbalance: float  # l/s, should be ~0
    mass_imbalance_junctions: list[tuple[str, float]]  # Worst offenders

    # Cycle pressure consistency (Kirchhoff's voltage law)
    cycle_pressure_ok: bool
    max_cycle_residual: float  # Pa
    max_cycle_relative_error: float  # Relative to total dp in cycle
    worst_cycles: list[CycleInfo]  # Detailed info about worst cycles

    # Energy balance (power in vs power dissipated)
    energy_balance_ok: bool
    total_hx_power: float  # Pa·l/s (power input from HX)
    total_dissipation: float  # Pa·l/s (power dissipated in network)
    energy_error: float  # Relative error

    # Flow sanity
    negative_flow_count: int
    flow_range: tuple[float, float]  # (min, max) in l/s

    @property
    def all_ok(self) -> bool:
        """True if all verification checks pass."""
        return (
            self.mass_balance_ok
            and self.cycle_pressure_ok
            and self.energy_balance_ok
            and self.negative_flow_count == 0
        )


def _build_incidence_matrix(graph: FlowGraph, cm: CycleMatrix) -> sparse.csr_matrix:
    """Build junction-branch incidence matrix A[j, b].

    A[j, b] = +1 if branch b starts at junction j (flow leaves)
    A[j, b] = -1 if branch b ends at junction j (flow enters)
    A[j, b] = 0 otherwise

    For mass conservation: A @ flows = 0 at every junction.
    """
    num_junctions = len(cm.junction_keys)
    num_branches = cm.num_branches

    rows: list[int] = []
    cols: list[int] = []
    data: list[int] = []

    for bkey, branch in graph.branches.items():
        if bkey not in cm.branch_index:
            continue
        b_idx = cm.branch_index[bkey]
        j1, j2 = branch.junctions

        # Skip self-loops (RAD branches) - they don't affect junction mass balance
        if j1 == j2:
            continue

        if j1 in cm.junction_index:
            rows.append(cm.junction_index[j1])
            cols.append(b_idx)
            data.append(+1)  # Flow leaves j1

        if j2 in cm.junction_index:
            rows.append(cm.junction_index[j2])
            cols.append(b_idx)
            data.append(-1)  # Flow enters j2

    return sparse.csr_matrix(
        (data, (rows, cols)), shape=(num_junctions, num_branches), dtype=np.int8
    )


# Numerical stability constants (re-exported for verification)
_MIN_FLOW_ABS: float = 1e-8  # Minimum |Q| for derivative calculation (l/s)


def verify_solution(
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    mass_tol: float = 1e-6,  # l/s tolerance for mass balance
    relative_tol: float = 0.10,  # 10% relative tolerance for cycle pressure
    energy_tol: float = 0.10,  # 10% relative tolerance for energy
) -> VerificationResult:
    """Verify the solved flow solution.

    Checks:
    1. Mass conservation at each junction (Kirchhoff's current law)
    2. Pressure balance around each cycle (Kirchhoff's voltage law)
    3. Energy balance: HX head production equals system pressure drop
    4. Flow sanity: counts negative flows, reports range

    Args:
        graph: The FlowGraph used for solving.
        arrays: Solved FlowArrays from solve_flows().
        cm: CycleMatrix from solve_flows().
        mass_tol: Tolerance for mass imbalance at junctions (l/s).
        relative_tol: Relative tolerance for cycle pressure error (default 10%).
        energy_tol: Relative tolerance for energy balance.

    Returns:
        VerificationResult with all check results.
    """
    Q = arrays.flows
    k = arrays.resistance
    h = arrays.head
    C = cm.matrix

    # -------------------------------------------------------------------------
    # 1. Mass conservation at junctions
    # -------------------------------------------------------------------------
    A = _build_incidence_matrix(graph, cm)
    mass_imbalance = A @ Q  # [num_junctions], should be ~0

    max_mass_imb = float(np.max(np.abs(mass_imbalance)))
    mass_ok = max_mass_imb < mass_tol

    # Find worst offenders
    worst_mass_indices = np.argsort(np.abs(mass_imbalance))[-5:][::-1]
    mass_imb_junctions = [
        (cm.junction_keys[i], float(mass_imbalance[i]))
        for i in worst_mass_indices
        if abs(mass_imbalance[i]) > mass_tol * 0.1
    ]

    # -------------------------------------------------------------------------
    # 2. Cycle pressure consistency
    # -------------------------------------------------------------------------
    Q_abs = np.maximum(np.abs(Q), _MIN_FLOW_ABS)
    dp = k * Q * Q_abs  # Pressure drop per branch
    net_dp = dp - h  # Net (drop - head source)

    cycle_residuals = C @ net_dp  # [num_cycles], should be ~0

    # Compute total absolute dp per cycle for relative error
    abs_net_dp = np.abs(net_dp)
    cycle_total_dp = np.abs(C) @ abs_net_dp  # Sum of |dp| in each cycle

    # Relative error: |residual| / total_dp (0 if no dp)
    with np.errstate(divide="ignore", invalid="ignore"):
        cycle_rel_errors = np.abs(cycle_residuals) / np.maximum(cycle_total_dp, 1.0)

    max_cycle_res = float(np.max(np.abs(cycle_residuals)))
    max_cycle_rel = float(np.max(cycle_rel_errors))
    cycle_ok = max_cycle_rel < relative_tol  # Use relative tolerance

    # Build detailed info for worst cycles
    worst_indices = np.argsort(cycle_rel_errors)[-5:][::-1].astype(int).tolist()
    worst_cycles: list[CycleInfo] = []
    C_dense = C.toarray()
    for idx in worst_indices:
        # Get branch keys involved in this cycle
        cycle_row = C_dense[idx]
        branch_indices = np.nonzero(cycle_row)[0]
        branch_keys_in_cycle = [cm.branch_keys[i] for i in branch_indices]

        # The chord (RAD branch) is typically the last one added (loop_ prefix)
        chord = next(
            (bk for bk in branch_keys_in_cycle if bk.startswith("loop_")),
            branch_keys_in_cycle[-1] if branch_keys_in_cycle else "",
        )

        worst_cycles.append(
            CycleInfo(
                index=idx,
                residual=float(cycle_residuals[idx]),
                relative_error=float(cycle_rel_errors[idx]),
                branch_keys=branch_keys_in_cycle,
                chord_branch=chord,
            )
        )

    # -------------------------------------------------------------------------
    # 3. Energy balance
    # -------------------------------------------------------------------------
    # In steady state: HX head × flow = total energy dissipation
    # Power_in = h × Q for HX branch (Pa × l/s = mW in our units)
    # Power_dissipated = Σ dp_i × |Q_i| = Σ k_i × |Q_i|³
    #
    # Note: This is approximate because multiple paths exist.
    # The fundamental check is cycle pressure (Kirchhoff's voltage law).

    # HX branch: find branch with head source
    hx_mask = h > 0
    hx_q = np.abs(Q[hx_mask])  # Flow through HX
    total_hx_power = float(np.sum(h[hx_mask] * hx_q))  # Pa × l/s

    # Total dissipation: dp × |Q| for each branch
    # dp = k × Q × |Q|, so |dp × Q| = k × |Q|³
    total_dissipation = float(np.sum(k * np.abs(Q) ** 3))

    # For energy balance: input power ≈ dissipation
    if total_hx_power > 0:
        energy_error = abs(total_hx_power - total_dissipation) / total_hx_power
    else:
        energy_error = 0.0 if total_dissipation < 1e-10 else float("inf")

    # Energy balance may have large apparent error due to parallel paths
    # having different dp. Use a generous tolerance; cycle pressure check
    # is the more rigorous energy verification.
    energy_ok = energy_error < energy_tol

    # -------------------------------------------------------------------------
    # 4. Flow sanity
    # -------------------------------------------------------------------------
    negative_count = int(np.sum(Q < 0))
    flow_min = float(np.min(Q))
    flow_max = float(np.max(Q))

    return VerificationResult(
        mass_balance_ok=mass_ok,
        max_mass_imbalance=max_mass_imb,
        mass_imbalance_junctions=mass_imb_junctions,
        cycle_pressure_ok=cycle_ok,
        max_cycle_residual=max_cycle_res,
        max_cycle_relative_error=max_cycle_rel,
        worst_cycles=worst_cycles,
        energy_balance_ok=energy_ok,
        total_hx_power=total_hx_power,
        total_dissipation=total_dissipation,
        energy_error=energy_error,
        negative_flow_count=negative_count,
        flow_range=(flow_min, flow_max),
    )


def print_verification(result: VerificationResult, verbose: bool = True) -> None:
    """Print verification results in human-readable format."""
    status = "✓ PASS" if result.all_ok else "✗ FAIL"
    print(f"\n{'=' * 60}")
    print(f"Solution Verification: {status}")
    print(f"{'=' * 60}")

    # Mass balance
    mass_status = "✓" if result.mass_balance_ok else "✗"
    print(f"\n{mass_status} Mass Balance (Kirchhoff's Current Law)")
    print(f"  Max imbalance: {result.max_mass_imbalance:.2e} l/s")
    if verbose and result.mass_imbalance_junctions:
        print("  Worst junctions:")
        for junc, imb in result.mass_imbalance_junctions[:3]:
            print(f"    {junc}: {imb:.2e} l/s")

    # Cycle pressure
    cycle_status = "✓" if result.cycle_pressure_ok else "✗"
    print(f"\n{cycle_status} Cycle Pressure (Kirchhoff's Voltage Law)")
    print(
        f"  Max residual: {result.max_cycle_residual / 1000:.1f} kPa ({result.max_cycle_relative_error:.1%} relative)"
    )
    if verbose and result.worst_cycles:
        print("  Worst cycles:")
        for cyc in result.worst_cycles[:3]:
            # Get a short name for the cycle from its chord branch
            chord_name = cyc.chord_branch.replace("loop_", "RAD ")
            backbone_count = sum(
                1 for b in cyc.branch_keys if b.startswith("backbone_")
            )
            print(f"    #{cyc.index}: {chord_name}")
            print(
                f"      Residual: {cyc.residual / 1000:.1f} kPa ({cyc.relative_error:.1%})"
            )
            print(f"      Branches: {len(cyc.branch_keys)} ({backbone_count} backbone)")

    # Energy balance
    energy_status = "✓" if result.energy_balance_ok else "✗"
    print(f"\n{energy_status} Energy Balance")
    print(f"  HX power input:     {result.total_hx_power:.1f} Pa·l/s")
    print(f"  System dissipation:  {result.total_dissipation:.1f} Pa·l/s")
    print(f"  Relative error:      {result.energy_error:.2%}")

    # Flow sanity
    neg_status = "✓" if result.negative_flow_count == 0 else "⚠"
    print(f"\n{neg_status} Flow Sanity")
    print(
        f"  Range: {result.flow_range[0] * 3600:.1f} to {result.flow_range[1] * 3600:.1f} l/h"
    )
    print(f"  Negative flows: {result.negative_flow_count}")

    print(f"\n{'=' * 60}\n")
