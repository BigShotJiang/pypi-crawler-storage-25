"""Pipenet compute function for the background calculation runner.

Bridges the calcrunner framework with the actual pipenet solver.
Registered once at import time via ``calc_runner.set_compute()``.

The compute function:
1. Builds the flow graph (branch/junction topology)
2. Builds the cycle matrix
3. Computes branch resistances
4. Runs the Hardy-Cross solver (with cancellation checks)
5. Extracts per-pipe, per-radiator and per-branch results
6. Returns a JSON-serialisable dict for WS delivery
"""

from __future__ import annotations

import contextlib
import logging
import math
from collections import defaultdict, deque
from typing import Any

import numpy as np

from .calcrunner import CancelledError, CancelToken, calc_runner
from .instantiate import CalcPipeNet, instantiate_pipenet
from .pipenet import (
    Branch,
    FlowGraph,
    build_flow_graph,
    hx_key_from_component,
    is_hx_component,
)
from .pipenet_cycles import (
    CycleMatrix,
    FlowArrays,
    build_cycle_matrix,
    build_flow_arrays,
    hardy_cross_iteration,
)
from .pipenet_resistance import (
    _iter_valve_events,
    build_balancing_valve_k_map,
    build_valve_info_map,
    component_k,
    compute_branch_hydrostatic_head,
    compute_branch_resistance,
    kv_to_k,
    middle_kv,
    preset_kv,
)
from .project import PipeNet, Project  # noqa: TC001 — used at runtime
from .sci.core import g as gravity
from .sci.pipe import get_out_temp
from .sci.radiator import (
    radiator_calculate,
    radiator_calculate_for_theta2,
    radiator_find,
    theta2_for_conditions,
    theta2_for_flow,
)
from .sci.radvalve import radvalve
from .sci.radvalve import table as valve_table_data
from .sci.room_calc import (
    compile_building_rooms,
    compile_manual_rooms,
    compile_roomless_radcond_radiators,
)
from .sci.tables.bvalve import bvalves, resolve_valve_key
from .sci.water import Flow, Kv, Pressure
from .sci.water import c as water_c
from .sci.water import density as water_density

logger = logging.getLogger(__name__)


def _log_graph_integrity_debug(graph: FlowGraph, *, context: str) -> None:
    """Emit concise diagnostics for malformed flow-graph topology."""
    invalid_refs: list[tuple[str, str, str]] = []
    for bkey, branch in graph.branches.items():
        j1, j2 = branch.junctions
        if j1 not in graph.junctions or j2 not in graph.junctions:
            invalid_refs.append((bkey, j1, j2))

    orphan_junctions = [
        j for j in graph.junctions if not graph.junction_branches.get(j)
    ]

    logger.warning(
        "%s graph summary: junctions=%d branches=%d invalid_branch_refs=%d orphans=%d",
        context,
        len(graph.junctions),
        len(graph.branches),
        len(invalid_refs),
        len(orphan_junctions),
    )

    if invalid_refs:
        sample = ", ".join(f"{b}:{j1}->{j2}" for b, j1, j2 in invalid_refs[:10])
        missing = sorted(
            {
                j
                for _, j1, j2 in invalid_refs
                for j in (j1, j2)
                if j not in graph.junctions
            }
        )
        logger.warning(
            "%s invalid refs sample=%s missing_junctions=%s",
            context,
            sample,
            missing[:20],
        )

    if orphan_junctions:
        logger.warning("%s orphan junctions sample=%s", context, orphan_junctions[:20])


def _parse_pipe_comp(comp_key: str) -> tuple[str, int | None]:
    """Parse ``'pipe_key:seg_idx'`` into ``(pipe_key, seg_idx)``.

    If *comp_key* has no segment suffix, returns ``(comp_key, None)``.
    """
    colon = comp_key.rfind(":")
    if colon >= 0:
        tail = comp_key[colon + 1 :]
        if tail.isdigit():
            return comp_key[:colon], int(tail)
    return comp_key, None


def _segment_dn(pipe, seg_idx: int) -> str:
    """Return the DN applicable to segment *seg_idx* of *pipe*."""
    dn_list = pipe.dn_keys()
    node_keys = pipe.node_keys()
    if not dn_list or seg_idx >= len(node_keys):
        return pipe.first_dn() or "?"
    tl_key = node_keys[seg_idx][0]
    dn = ""
    for dk, dv in dn_list:
        if dk <= tl_key:
            dn = dv
        else:
            break
    return dn or (dn_list[0][1] if dn_list else "?")


def _resolve_component_nodes(
    comp: str,
    pipenet: CalcPipeNet | PipeNet,
    graph_nodes: tuple[str, str] | None,
) -> tuple[str, str] | None:
    """Resolve a pipe component's endpoints to original segment nodes.

    For rendering/debug output we prefer the real segment endpoints from the
    originating pipe route. This preserves distinct geometry points inside HX
    connection boxes even when flow-graph construction collapses those nodes.

    Orientation is chosen to best match *graph_nodes* when available so branch
    traversal continuity is preserved.
    """
    if not comp.startswith(("supply ", "return ")):
        return None

    def _segment_nodes_for_component() -> tuple[str, str] | None:
        comp_key = comp.split(" ", 1)[1]
        pipe_key, seg_idx = _parse_pipe_comp(comp_key)
        pipe = pipenet.pipes.get(pipe_key)
        if not pipe:
            return None

        route = pipe.route()
        if len(route) < 2:
            return None

        if seg_idx is None:
            return (route[0], route[-1])
        if seg_idx < 0 or seg_idx >= len(route) - 1:
            return None
        return (route[seg_idx], route[seg_idx + 1])

    segment_nodes = _segment_nodes_for_component()
    if segment_nodes is None:
        return None

    n0, n1 = segment_nodes

    if graph_nodes is None:
        return segment_nodes

    g0, g1 = graph_nodes

    def _coord(nid: str) -> tuple[float, float, float] | None:
        n = pipenet.nodes.get(nid)
        if n is None:
            return None
        z_or_h = getattr(n, "z", getattr(n, "h", 0))
        return (float(n.x), float(n.y), float(z_or_h))

    c_n0 = _coord(n0)
    c_n1 = _coord(n1)
    c_g0 = _coord(g0)
    c_g1 = _coord(g1)
    if c_n0 is None or c_n1 is None or c_g0 is None or c_g1 is None:
        return (n0, n1)

    def _d(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
        return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)

    # Choose orientation that best aligns to flow-graph traversal endpoints.
    score_keep = _d(c_n0, c_g0) + _d(c_n1, c_g1)
    score_flip = _d(c_n1, c_g0) + _d(c_n0, c_g1)
    if score_flip < score_keep:
        return (n1, n0)
    return segment_nodes


def _vnode_height(
    node_key: str,
    pipenet: PipeNet,
) -> float:
    """Absolute height (m) for a node key.

    After instantiation, all nodes (including riser nodes) have absolute
    ``z`` values.
    """
    node = pipenet.nodes.get(node_key)
    if node is not None:
        return node.z / 1000.0
    return 0.0


def _hx_supply_map(project: Project, calc_pn: CalcPipeNet) -> dict[str, float]:
    """Resolve HX-specific supply temperatures with project fallback."""
    default_supply = float(project.t_supply)
    out: dict[str, float] = {}
    for hx_key, hx in calc_pn.hxs.items():
        raw = getattr(hx, "t_supply", "")
        value = default_supply
        if raw not in (None, ""):
            with contextlib.suppress(TypeError, ValueError):
                value = float(raw)
        out[hx_key] = value
    return out


def _build_hx_node_map(calc_pn: CalcPipeNet) -> dict[str, list[str]]:
    """Map pipe nodes to HX keys using the same geometric rule as graph build."""
    hx_at: dict[str, list[str]] = {}
    half_size = 500

    def _add(node_key: str, hx_key: str) -> None:
        items = hx_at.setdefault(node_key, [])
        if hx_key not in items:
            items.append(hx_key)

    for hx_key, hx in calc_pn.hxs.items():
        for node_key, node in calc_pn.nodes.items():
            if abs(node.x - hx.x) > half_size or abs(node.y - hx.y) > half_size:
                continue
            if calc_pn.node_floor_ids.get(node_key) != hx.floor:
                continue
            _add(node_key, hx_key)

        z_target = calc_pn.floor_base_heights.get(hx.floor)
        if z_target is None:
            continue
        z_target += 2100

        for pipe in calc_pn.pipes.values():
            route = pipe.route()
            for i in range(len(route) - 1):
                n1_key = route[i]
                n2_key = route[i + 1]
                n1 = calc_pn.nodes.get(n1_key)
                n2 = calc_pn.nodes.get(n2_key)
                if n1 is None or n2 is None:
                    continue
                if n1.x != n2.x or n1.y != n2.y:
                    continue
                if abs(n1.x - hx.x) > half_size or abs(n1.y - hx.y) > half_size:
                    continue
                z_min = min(n1.z, n2.z)
                z_max = max(n1.z, n2.z)
                if not (z_min <= z_target <= z_max):
                    continue
                if calc_pn.node_floor_ids.get(n1_key) == hx.floor:
                    _add(n1_key, hx_key)
                if calc_pn.node_floor_ids.get(n2_key) == hx.floor:
                    _add(n2_key, hx_key)

    return hx_at


def _build_node_hx_map(calc_pn: CalcPipeNet) -> dict[str, str]:
    """Assign each node to the nearest connected HX by graph distance."""
    hx_at = _build_hx_node_map(calc_pn)
    if not hx_at:
        return {}

    adj: dict[str, set[str]] = {}
    for pipe in calc_pn.pipes.values():
        route = pipe.route()
        for i in range(len(route) - 1):
            a = route[i]
            b = route[i + 1]
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)

    owner: dict[str, str] = {}
    dist: dict[str, int] = {}
    queue: deque[tuple[str, str]] = deque()

    for node_key, hx_keys in sorted(hx_at.items()):
        for hx_key in sorted(hx_keys):
            prev_dist = dist.get(node_key)
            prev_owner = owner.get(node_key)
            if (
                prev_dist is None
                or prev_dist > 0
                or (prev_dist == 0 and prev_owner is not None and hx_key < prev_owner)
            ):
                dist[node_key] = 0
                owner[node_key] = hx_key
            queue.append((node_key, hx_key))

    while queue:
        node_key, hx_key = queue.popleft()
        base_dist = dist.get(node_key)
        if base_dist is None or owner.get(node_key) != hx_key:
            continue
        next_dist = base_dist + 1
        for nb in adj.get(node_key, ()):
            prev_dist = dist.get(nb)
            prev_owner = owner.get(nb)
            better = prev_dist is None or next_dist < prev_dist
            tie_break = (
                prev_dist is not None
                and next_dist == prev_dist
                and prev_owner is not None
                and hx_key < prev_owner
            )
            if better or tie_break:
                dist[nb] = next_dist
                owner[nb] = hx_key
                queue.append((nb, hx_key))

    return owner


def _build_component_hx_map(
    graph: FlowGraph,
    calc_pn: CalcPipeNet,
    node_hx: dict[str, str],
) -> dict[str, str]:
    """Map components/radiators to their connected HX key."""
    comp_hx: dict[str, str] = {}

    for comp, nodes in graph.component_nodes.items():
        if not comp.startswith(("supply ", "return ")):
            continue
        from_node, to_node = nodes
        hx_key = node_hx.get(from_node) or node_hx.get(to_node)
        if hx_key:
            comp_hx[comp] = hx_key

    for rad_key, rad in calc_pn.radiators.items():
        hx_key = node_hx.get(rad.node)
        if hx_key:
            comp_hx[rad_key] = hx_key

    return comp_hx


def _build_room_supply_map(
    project: Project,
    calc_pn: CalcPipeNet,
    comp_hx_map: dict[str, str],
    hx_supply: dict[str, float],
) -> dict[str, float]:
    """Resolve room-level supply from connected radiator HX sources."""
    room_supply: dict[str, float] = {}
    default_supply = float(project.t_supply)

    for rad_key, rad in calc_pn.radiators.items():
        if not rad.room_id:
            continue
        hx_key = comp_hx_map.get(rad_key)
        if not hx_key:
            continue
        room_supply.setdefault(rad.room_id, hx_supply.get(hx_key, default_supply))

    return room_supply


# ---------------------------------------------------------------------------
# Pipe heat → room attribution
# ---------------------------------------------------------------------------


def _pipe_segment_nodes(
    comp: str,
    pipenet: PipeNet,
) -> list[tuple[str, str]]:
    """Return ``[(node_id_a, node_id_b), ...]`` for a pipe component.

    Usually returns a single pair, but multi-segment pipes (no seg_idx)
    return one pair per segment.
    """
    comp_key = comp.split(" ", 1)[1]  # strip "supply " / "return "
    pipe_key = comp_key
    seg_idx: int | None = None
    colon = comp_key.rfind(":")
    if colon >= 0:
        tail = comp_key[colon + 1 :]
        if tail.isdigit():
            pipe_key = comp_key[:colon]
            seg_idx = int(tail)

    pipe = pipenet.pipes.get(pipe_key)
    if not pipe:
        return []
    route = pipe.route()
    pairs: list[tuple[str, str]] = []
    for i in range(len(route) - 1):
        if seg_idx is not None and i != seg_idx:
            continue
        pairs.append((route[i], route[i + 1]))
    return pairs


def _compute_pipe_heat_to_rooms(
    comp_temps: dict[str, tuple[float, float]],
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    calc_pn: CalcPipeNet,
    project: Project,
) -> dict[str, dict[str, tuple[float, float]]]:
    """Compute pipe heat loss attributed to each room, grouped by pipe kind.

    Returns ``{room_key: {kind: (watts, length_mm)}}`` where room_key
    matches the keys in ``rooms_out`` (e.g. ``"bld:B1:f2:F1"``).
    """
    from .sci.room_locate import (
        _collect_boundary_edges,
        find_segment_splits,
        point_in_room,
    )
    from .sci.water import c as water_c

    heat_by_room: dict[str, dict[str, tuple[float, float]]] = defaultdict(
        lambda: defaultdict(lambda: (0.0, 0.0))
    )

    # Build floor_id → plan_id mapping
    floor_plan: dict[str, str | None] = {f.id: f.plan for f in project.floors}

    # Cache boundary edges per plan and subdivision results for point_in_room
    boundary_cache: dict[str, list] = {}
    subdiv_cache: dict[str, Any] = {}

    # Build flow lookup: component → flow_ls
    comp_flow: dict[str, float] = {}
    for bkey in cm.branch_keys:
        branch = graph.branches[bkey]
        idx = cm.branch_index[bkey]
        flow_ls = abs(float(arrays.flows[idx]))
        for comp in branch.components:
            comp_flow[comp] = flow_ls

    for comp, (t_in, t_out) in comp_temps.items():
        if not comp.startswith(("supply ", "return ")):
            continue

        dt = t_in - t_out
        if abs(dt) < 1e-6:
            continue

        flow_ls = comp_flow.get(comp, 0.0)
        if flow_ls < 1e-9:
            continue

        # Total heat loss for this component
        t_avg = (t_in + t_out) / 2.0
        mass_flow = flow_ls * water_density(t_avg) / 1000.0
        q_total = mass_flow * water_c * dt  # Watts

        # Resolve segment node pairs
        pairs = _pipe_segment_nodes(comp, calc_pn)
        if not pairs:
            continue

        # Get pipe kind (DN) for this component
        _, comp_kind = _pipe_segment_info(comp, calc_pn)

        # Collect sub-lengths and room assignments
        sub_segments: list[tuple[float, str | None]] = []  # (length, room_key)

        for nid_a, nid_b in pairs:
            na = calc_pn.nodes.get(nid_a)
            nb = calc_pn.nodes.get(nid_b)
            if not na or not nb:
                continue

            dx = nb.x - na.x
            dy = nb.y - na.y
            dz = nb.z - na.z
            seg_len = math.sqrt(dx * dx + dy * dy + dz * dz)
            if seg_len < 1:
                continue

            # Determine floor from node_floor_ids (use start node)
            floor_id = calc_pn.node_floor_ids.get(nid_a)
            if not floor_id:
                floor_id = calc_pn.node_floor_ids.get(nid_b)
            if not floor_id:
                # Can't attribute — count as unassigned
                sub_segments.append((seg_len, None))
                continue

            plan_id = floor_plan.get(floor_id)
            if not plan_id:
                sub_segments.append((seg_len, None))
                continue

            # Get boundary edges for wall-crossing detection
            if plan_id not in boundary_cache:
                boundary_cache[plan_id] = _collect_boundary_edges(project, plan_id)
            edges = boundary_cache[plan_id]

            # Find wall crossings to split segment into room sub-segments
            splits = find_segment_splits(
                float(na.x), float(na.y), float(nb.x), float(nb.y), edges
            )

            # Build list of sub-segment midpoints
            t_params = [0.0] + [sp.t for sp in splits] + [1.0]
            for k in range(len(t_params) - 1):
                ta, tb = t_params[k], t_params[k + 1]
                sub_len = seg_len * (tb - ta)
                if sub_len < 1:
                    continue
                # Midpoint in 2D for room lookup
                tmid = (ta + tb) / 2.0
                mx = na.x + tmid * (nb.x - na.x)
                my = na.y + tmid * (nb.y - na.y)
                hit = point_in_room(project, mx, my, plan_id, subdiv_cache)
                if hit:
                    room_key = f"bld:{hit.building_id}:f{hit.face_index}:{floor_id}"
                    sub_segments.append((sub_len, room_key))
                else:
                    sub_segments.append((sub_len, None))

        # Distribute heat proportionally by length
        total_len = sum(sl for sl, _ in sub_segments)
        if total_len < 1:
            continue
        kind = comp_kind or "pipe"
        for sl, room_key in sub_segments:
            if room_key is not None:
                prev_w, prev_l = heat_by_room[room_key][kind]
                heat_by_room[room_key][kind] = (
                    prev_w + q_total * (sl / total_len),
                    prev_l + sl,
                )

    result = {k: dict(v) for k, v in heat_by_room.items()}
    if result:
        logger.info(
            "Pipe heat to rooms: %s",
            {
                k: {kind: f"{w:.0f}W/{ln:.0f}mm" for kind, (w, ln) in v.items()}
                for k, v in result.items()
            },
        )
    return result


# ---------------------------------------------------------------------------
# Pipe segment info for temperature calculation
# ---------------------------------------------------------------------------


def _pipe_segment_info(
    comp: str,
    pipenet: PipeNet,
) -> tuple[float, str]:
    """Return ``(length_mm, kind)`` for a pipe component.

    *comp* is a full component key like ``"supply pipeX:0"``.
    After instantiation, node heights are absolute.
    """
    comp_key = comp.split(" ", 1)[1]  # strip "supply " / "return "

    pipe_key = comp_key
    seg_idx: int | None = None
    colon = comp_key.rfind(":")
    if colon >= 0:
        tail = comp_key[colon + 1 :]
        if tail.isdigit():
            pipe_key = comp_key[:colon]
            seg_idx = int(tail)

    pipe = pipenet.pipes.get(pipe_key)
    if not pipe:
        return 0.0, ""

    dn_list = pipe.dn_keys()
    if not dn_list:
        return 0.0, ""

    route = pipe.route()
    node_tl_keys = pipe.node_keys()

    total_length = 0.0
    kind = dn_list[0][1]

    for i in range(len(route) - 1):
        if seg_idx is not None and i != seg_idx:
            continue
        n1 = pipenet.nodes.get(route[i])
        n2 = pipenet.nodes.get(route[i + 1])
        if not n1 or not n2:
            continue
        dx = n2.x - n1.x
        dy = n2.y - n1.y
        dh = n2.z - n1.z
        total_length += math.sqrt(dx * dx + dy * dy + dh * dh)

        # Applicable kind at this segment start
        node_key = node_tl_keys[i][0]
        for dk, dv in dn_list:
            if dk <= node_key:
                kind = dv
            else:
                break

    return total_length, kind


# ---------------------------------------------------------------------------
# Temperature propagation
# ---------------------------------------------------------------------------


def _compute_temperatures(
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    proj: Project,
    calc_pn: CalcPipeNet,
    comp_t_supply: dict[str, float] | None = None,
    hx_supply: dict[str, float] | None = None,
) -> dict[str, tuple[float, float]]:
    """Propagate water temperatures through the solved flow network."""
    t_supply_default = float(proj.t_supply)
    t_env = float(proj.t_env)
    comp_t_supply = comp_t_supply or {}
    hx_supply = hx_supply or {}

    junction_temp: dict[str, float] = {}
    comp_temps: dict[str, tuple[float, float]] = {}

    # Seed: each HX branch outputs its own supply-side temperature.
    for bkey in cm.branch_keys:
        branch = graph.branches[bkey]
        for comp in branch.components:
            if not is_hx_component(comp):
                continue
            hx_key = hx_key_from_component(comp)
            if hx_key is None:
                continue
            t_sup = hx_supply.get(hx_key, t_supply_default)
            junction_temp[branch.junctions[1]] = t_sup
            break

    # Count expected incoming branches per junction
    incoming_expected: dict[str, int] = defaultdict(int)
    for bkey in cm.branch_keys:
        branch = graph.branches[bkey]
        j0, j1 = branch.junctions
        if j0 != j1:
            incoming_expected[j1] += 1

    # Accumulated inflows: junction → [(temp, abs_flow)]
    junction_inflows: dict[str, list[tuple[float, float]]] = defaultdict(list)

    processed: set[str] = set()
    changed = True
    while changed:
        changed = False
        for bkey in cm.branch_keys:
            if bkey in processed:
                continue
            branch = graph.branches[bkey]
            j0 = branch.junctions[0]
            if j0 not in junction_temp:
                continue

            processed.add(bkey)
            changed = True

            idx = cm.branch_index[bkey]
            flow_ls = abs(float(arrays.flows[idx]))  # l/s
            temp = junction_temp[j0]

            for comp in branch.components:
                t_in = temp
                if is_hx_component(comp):
                    hx_key = hx_key_from_component(comp)
                    if hx_key is None:
                        comp_temps[comp] = (t_in, temp)
                        continue
                    temp = hx_supply.get(hx_key, t_supply_default)
                elif comp.startswith(("supply ", "return ")):
                    if flow_ls > 1e-9:
                        length, kind = _pipe_segment_info(
                            comp,
                            calc_pn,
                        )
                        if length > 1 and kind:  # min 1mm
                            mass_flow = flow_ls * water_density(temp) / 1000.0
                            with contextlib.suppress(ValueError, ZeroDivisionError):
                                temp = get_out_temp(
                                    temp,
                                    mass_flow,
                                    length,
                                    kind,
                                    env_temp=t_env,
                                )
                elif comp in calc_pn.radiators and flow_ls > 1e-9:
                    crad = calc_pn.radiators[comp]
                    code = crad.code.split()[0].lower() if crad.code else ""
                    rad_cond = radiator_find(code) if code else None
                    if rad_cond:
                        theta1 = temp - t_env
                        theta2 = theta2_for_flow(rad_cond, theta1, flow_ls)
                        temp = theta2 + t_env
                elif comp in comp_t_supply:
                    # Fallback for unmodelled components mapped to an HX.
                    temp = comp_t_supply[comp]

                comp_temps[comp] = (t_in, temp)

            # Register arrival at destination junction
            j1 = branch.junctions[1]
            if j0 != j1:
                junction_inflows[j1].append((temp, flow_ls))
                # Set junction temp when ALL incoming branches are done
                if len(junction_inflows[j1]) >= incoming_expected[j1]:
                    total_flow = sum(f for _, f in junction_inflows[j1])
                    if total_flow > 1e-9:
                        junction_temp[j1] = (
                            sum(t * f for t, f in junction_inflows[j1]) / total_flow
                        )
                    elif junction_inflows[j1]:
                        junction_temp[j1] = junction_inflows[j1][0][0]

    return comp_temps


# ---------------------------------------------------------------------------
# Cancellation-aware solver
# ---------------------------------------------------------------------------

# Check cancellation every N iterations.
_CANCEL_CHECK_INTERVAL: int = 200


def _solve_flows_cancellable(
    graph: FlowGraph,
    resistance: np.ndarray,
    token: CancelToken,
    *,
    exponent: np.ndarray | None = None,
    max_iterations: int = 2000,
    tolerance: float = 100.0,
    initial_damping: float = 0.15,
    head_pressure: float | None = None,
    hydrostatic_head: np.ndarray | None = None,
) -> tuple[FlowArrays, CycleMatrix]:
    """Hardy-Cross solver with periodic cancellation checks.

    Same algorithm as ``pipenet_cycles.solve_flows`` but calls
    ``token.check()`` every ``_CANCEL_CHECK_INTERVAL`` iterations so
    the worker thread can be interrupted promptly when the project is
    modified.
    """
    cm = build_cycle_matrix(graph)
    resistance = np.asarray(resistance, dtype=np.float64)
    if exponent is not None:
        exponent = np.asarray(exponent, dtype=np.float64)
    kw = {}
    if head_pressure is not None:
        kw["head_pressure"] = head_pressure
    arrays = build_flow_arrays(graph, cm, resistance, exponent, **kw)

    # Add hydrostatic head (per-branch gravity term) on top of HX head
    if hydrostatic_head is not None:
        arrays.head = arrays.head + np.asarray(hydrostatic_head, dtype=np.float64)

    _converge(cm, arrays, token, max_iterations, tolerance, initial_damping)

    return arrays, cm


def _converge(
    cm: CycleMatrix,
    arrays: FlowArrays,
    token: CancelToken,
    max_iterations: int = 2000,
    tolerance: float = 100.0,
    initial_damping: float = 0.15,
) -> None:
    """Run Hardy-Cross iterations until convergence."""
    damping = initial_damping
    prev_residual = float("inf")
    for iteration in range(max_iterations):
        if iteration % _CANCEL_CHECK_INTERVAL == 0:
            token.check()
        residual = hardy_cross_iteration(cm, arrays, damping)
        if residual < tolerance:
            break
        if residual > prev_residual * 1.2:
            damping = max(0.05, damping * 0.8)
        prev_residual = residual


# ---------------------------------------------------------------------------
# Head-pressure adjustment
# ---------------------------------------------------------------------------

# Number of initial rounds before starting radiator preset recalculation
_RADIATOR_ADJUST_START_ROUND: int = 4

# Number of initial rounds before starting balancing valve adjustment
_BALANCING_VALVE_ADJUST_START_ROUND: int = 0

# Very high resistance used to represent thermostat fully closed (flow ~ 0).
_THERMOSTAT_CLOSED_K: float = 1e12


def _effective_rad_k_from_kv(kv: float) -> float:
    """Convert Kv to resistance, including near-zero Kv thermostat closure."""
    if kv <= 1e-9:
        return _THERMOSTAT_CLOSED_K
    return kv_to_k(kv)


def _find_bvalve_preset_for_kv(
    valve_key: str, kv_target: float, *, closest: bool = False
) -> tuple[str, float]:
    """Find balancing valve preset for a target Kv.

    By default returns the smallest preset with Kv >= *kv_target*.
    With ``closest=True``, returns the preset whose Kv is nearest to
    *kv_target* (useful for display / round-trip lookup).

    Returns ``(preset_label, kv_actual)``, or ``("", 0.0)`` when
    *valve_key* is unknown.
    """
    presets = bvalves.get(valve_key)
    if not presets:
        return "", 0.0

    if closest:
        best_preset = ""
        best_kv = 0.0
        best_diff = float("inf")
        for preset, kv in presets.items():
            diff = abs(kv - kv_target)
            if diff < best_diff:
                best_diff = diff
                best_preset = preset
                best_kv = kv
        return best_preset, best_kv

    # Smallest preset with kv >= kv_target
    sorted_presets = sorted(presets.items(), key=lambda x: x[1])
    for preset, kv in sorted_presets:
        if kv >= kv_target:
            return preset, kv
    # kv_target larger than max – return max preset
    return sorted_presets[-1]


def _adjust_balancing_valves(
    proj: Project,
    calc_pn: CalcPipeNet,
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    balancing_k_map: dict[str, float],
    dp_rad_pa: float,
    *,
    snap_to_preset: bool = False,
) -> dict[str, float]:
    """Adjust balancing valve presets to bring dp_sr closer to dp_rad.

    For each balancing valve:
    1. Compute the dp_sr (pressure available to radiator side)
    2. If dp_sr > dp_rad, the valve needs to absorb the excess
    3. Calculate the required Kv to create dp_excess at current flow
    4. Find and apply the appropriate preset

    When *snap_to_preset* is False (default), continuous Kv values are
    used with dampening to allow smooth convergence.  On the final
    iteration *snap_to_preset* should be True so that every valve
    lands on a real discrete preset without dampening.

    Returns an updated balancing_k_map.
    """
    valvebal = proj.valvebal

    # Build component -> branch map and component dp map (like in _extract_results)
    comp_to_branch: dict[str, str] = {}
    comp_dp_map: dict[str, float] = {}

    for bkey in cm.branch_keys:
        branch = graph.branches[bkey]
        idx = cm.branch_index[bkey]
        flow = float(arrays.flows[idx])

        for comp in branch.components:
            comp_to_branch[comp] = bkey
            if comp.startswith(("supply ", "return ")):
                # Get resistance for this component (includes balancing valve if present)
                k, n = component_k(
                    comp,
                    calc_pn,
                    0.0,  # default_rad_k not needed for pipes
                    None,  # radiator_k_map
                    balancing_k_map,
                )
                dp = k * abs(flow) ** n
                comp_dp_map[comp] = dp

    # Compute junction pressures for backbone valve dp_sr calculation
    junction_pressures = _compute_junction_pressures(graph, arrays, cm)

    # New balancing k map
    new_balancing_k_map = dict(balancing_k_map)

    # Iterate through balancing valves and adjust
    for valve_id, valve in calc_pn.valves.items():
        # Find the component key for this valve
        comp_key = None
        for pipe_key, pipe in calc_pn.pipes.items():
            for _tl_key, ev, seg_idx in _iter_valve_events(pipe):
                if ev.valve == valve_id:
                    comp_key = f"return {pipe_key}:{seg_idx}"
                    break
            if comp_key:
                break

        if not comp_key:
            continue

        # Get flow through this component
        branch_key = comp_to_branch.get(comp_key)
        if not branch_key:
            continue
        idx = cm.branch_index.get(branch_key)
        if idx is None:
            continue
        flow = abs(float(arrays.flows[idx]))
        if flow < 1e-9:
            continue

        # Compute dp_sr at this valve position
        dp_sr = _compute_valve_dp_sr(
            comp_key,
            graph,
            comp_to_branch,
            comp_dp_map,
            arrays,
            cm,
            junction_pressures,
        )

        if dp_sr is None:
            continue

        # Resolve valve model
        valve_key = valve.kind or resolve_valve_key(valvebal, valve.dn)
        if not valve_key:
            continue

        # If dp_sr is already close to or below dp_rad, valve should be fully open
        dp_excess = dp_sr - dp_rad_pa
        if dp_excess <= 0:
            presets = bvalves.get(valve_key)
            if presets:
                max_kv = max(presets.values())
                target_k = kv_to_k(max_kv)
            else:
                continue
        else:
            # Calculate required Kv to create dp_excess at current flow
            kv_target = Kv.calc(Flow(flow), Pressure(dp_excess)).kv
            if snap_to_preset:
                # Final round: snap to a real discrete preset
                _preset, kv_actual = _find_bvalve_preset_for_kv(valve_key, kv_target)
                if kv_actual <= 0:
                    continue
                target_k = kv_to_k(kv_actual)
            else:
                # Intermediate rounds: use continuous Kv for smooth convergence
                target_k = kv_to_k(kv_target)

        if snap_to_preset:
            # Final round: use exact target, no dampening
            new_balancing_k_map[comp_key] = target_k
        else:
            # Dampen: blend old and new k to avoid oscillation
            old_k = balancing_k_map.get(comp_key, target_k)
            new_balancing_k_map[comp_key] = old_k + 0.5 * (target_k - old_k)

    return new_balancing_k_map


def _recalculate_radiator_presets(
    proj: Project,
    calc_pn: CalcPipeNet,
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    rooms_out: dict[str, Any],
    comp_temps: dict[str, tuple[float, float]],
    comp_t_supply: dict[str, float] | None = None,
    pipe_heat_by_room: dict[str, float] | None = None,
    prev_kv_want: dict[str, float] | None = None,
) -> tuple[dict[str, float], dict[str, dict[str, Any]]]:
    """Recalculate radiator presets based on actual operating conditions.

    Returns:
        (radiator_k_map, radiator_preset_map)
        - radiator_k_map: hydraulic resistance per radiator (for simulation)
        - radiator_preset_map: {rad_key: {"preset": str, "kv": float}}
          with the *design* (installed) preset, not thermostat-throttled.
    """
    t_env = float(proj.t_env)
    t_supply_default = float(proj.t_supply)
    comp_t_supply = comp_t_supply or {}
    thermostat = proj.thermostat
    radiator_k_map: dict[str, float] = {}
    radiator_preset_map: dict[str, dict[str, Any]] = {}

    # Build (room_id, rad_code) → share from rooms_out
    share_map: dict[tuple[str, str], float] = {}
    lock_kv_map: dict[tuple[str, str], tuple[bool, float]] = {}
    conditions_map: dict[str, tuple[float, float, float]] = {}
    for room_id, rdata in rooms_out.items():
        cond = rdata.get("conditions")
        if isinstance(cond, dict):
            with contextlib.suppress(TypeError, ValueError, KeyError):
                conditions_map[room_id] = (
                    float(cond["supply"]),
                    float(cond["return"]),
                    float(cond["env"]),
                )
        elif isinstance(cond, list | tuple) and len(cond) == 3:
            with contextlib.suppress(TypeError, ValueError):
                conditions_map[room_id] = (
                    float(cond[0]),
                    float(cond[1]),
                    float(cond[2]),
                )
        for rad in rdata.get("radiators", []):
            code = rad.get("code", "")
            share = rad.get("share")
            if code and share is not None:
                share_map[(room_id, code)] = float(share)
            if code:
                key = (room_id, code)
                locked = bool(rad.get("preset_locked", False))
                kv_locked = 0.0
                try:
                    kv_locked = float(rad.get("kv") or 0.0)
                except TypeError, ValueError:
                    kv_locked = 0.0
                prev = lock_kv_map.get(key)
                # Prefer locked entry if duplicates exist.
                if prev is None or (locked and not prev[0]):
                    lock_kv_map[key] = (locked, kv_locked)

    logger.info("share_map: %s", share_map)

    for rad_key, crad in calc_pn.radiators.items():
        if not crad.room_id or not crad.code:
            continue

        code = crad.code.split()[0].lower()
        rad_cond = radiator_find(code)
        if rad_cond is None:
            continue

        # Compute required power from share and room demand minus pipe heat
        share = share_map.get((crad.room_id, code))
        if share is None:
            logger.info(
                "No share for rad %s room=%s code=%s", rad_key, crad.room_id, code
            )
            continue
        room_data = rooms_out.get(crad.room_id)
        room_power = float(room_data.get("power", 0.0)) if room_data else 0.0
        # room_power is negative for heating need; pipe heat reduces that need
        pipe_heat = (
            pipe_heat_by_room.get(crad.room_id, 0.0) if pipe_heat_by_room else 0.0
        )
        net_demand = -(room_power + pipe_heat)  # positive = heating demand remaining
        power_req = max(0.0, share * net_demand)
        logger.info(
            "Rad %s: share=%.3f room_power=%.0f pipe_heat=%.0f net=%.0f power_req=%.0f",
            rad_key,
            share,
            room_power,
            pipe_heat,
            net_demand,
            power_req,
        )

        # Get actual supply temperature at the radiator from propagated temps.
        # Do not fall back to design t_supply: preset recalculation must use
        # post-loss operating conditions only.
        temps = comp_temps.get(rad_key)
        if temps is None:
            continue
        t_supply_actual = temps[0]

        theta1_actual = t_supply_actual - t_env
        if theta1_actual <= 0:
            continue  # Invalid condition

        # Get current flow through this radiator's branch
        flow = 0.0
        for bkey in cm.branch_keys:
            branch = graph.branches[bkey]
            if rad_key in branch.components:
                idx = cm.branch_index[bkey]
                flow = abs(float(arrays.flows[idx]))
                break

        if flow < 1e-9:
            continue

        # Calculate required flow at actual theta1
        try:
            room_conditions = conditions_map.get(crad.room_id)
            if room_conditions is not None:
                # Conditions define a fixed temperature regime (e.g. 70/40).
                # Compute the design power at design t_supply, then find
                # the flow needed to deliver that same power at the actual
                # (lower) supply temperature.
                cond_env = (
                    t_env if math.isnan(room_conditions[2]) else room_conditions[2]
                )
                cond_theta1 = room_conditions[0] - cond_env
                cond_theta2 = room_conditions[1] - cond_env
                t_supply_design = comp_t_supply.get(rad_key, t_supply_default)
                theta1_design = t_supply_design - t_env
                target_theta2 = theta2_for_conditions(
                    theta1_design, cond_theta1, cond_theta2
                )
                design = radiator_calculate_for_theta2(
                    rad_cond, theta1_design, target_theta2
                )
                design_power = design["power"]
                simple = radiator_calculate(rad_cond, design_power, theta1_actual)
            else:
                simple = radiator_calculate(rad_cond, power_req, theta1_actual)
            flow_required = simple["flow"]
        except KeyError, TypeError, ValueError, ZeroDivisionError:
            continue

        if flow_required < 1e-9:
            if thermostat:
                radiator_k_map[rad_key] = _THERMOSTAT_CLOSED_K
            continue

        dp_rad_pa = float(proj.dp_rad) * 1000.0  # kPa → Pa

        # Find preset Kv that delivers required flow at dp_rad.
        # radvalve() rounds UP: smallest preset with Kv >= kv_want.
        try:
            valve_name = proj.valve
            kv_want = Kv.calc(Flow(flow_required), Pressure(dp_rad_pa)).kv
            # Dampen kv_want to avoid thermostat ↔ pipe_heat oscillation
            if prev_kv_want and rad_key in prev_kv_want:
                kv_want = 0.5 * prev_kv_want[rad_key] + 0.5 * kv_want
            if prev_kv_want is not None:
                prev_kv_want[rad_key] = kv_want
            v = radvalve(valve_name, kv_want)
            kv = float(v["kv"])
            ps = str(v["ps"])
        except KeyError, TypeError, ValueError, ZeroDivisionError:
            continue

        preset_locked, kv_locked = lock_kv_map.get((crad.room_id, code), (False, 0.0))

        if preset_locked:
            # Locked preset acts as maximum opening. Without thermostat, keep it
            # fixed. With thermostat, allow throttling from that max down to zero.
            kv_max = kv_locked if kv_locked > 0 else kv
            if thermostat:
                kv_effective = min(kv_max, max(kv_want, 0.0))
                radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv_effective)
            else:
                radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv_max)
            # For locked presets, report the locked Kv as the design preset
            locked_v = radvalve(valve_name, kv_max)
            radiator_preset_map[rad_key] = {
                "preset": str(locked_v["ps"]),
                "kv": round(float(locked_v["kv"]), 3),
            }
            continue

        # Record design (installed) preset — always from radvalve() round-up
        radiator_preset_map[rad_key] = {"preset": ps, "kv": round(kv, 3)}

        if thermostat and kv > kv_want:
            # Thermostat limits flow: use the exact Kv for the required
            # power instead of the (larger) valve preset Kv.
            logger.info(
                "Rad %s thermostat: kv_preset=%.3f kv_want=%.4f flow_req=%.6f power_req=%.0f k=%.0f",
                rad_key,
                kv,
                kv_want,
                flow_required,
                power_req,
                _effective_rad_k_from_kv(kv_want),
            )
            radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv_want)
        else:
            radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv)

    return radiator_k_map, radiator_preset_map


def _update_branch_resistance(
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    pipenet: PipeNet,
    default_rad_k: float,
    radiator_k_map: dict[str, float],
    balancing_k_map: dict[str, float] | None,
) -> None:
    """Update resistance array in-place with new radiator k values."""
    from .pipenet_resistance import MIN_BRANCH_RESISTANCE

    for i, bkey in enumerate(cm.branch_keys):
        branch = graph.branches[bkey]
        total_k = 0.0
        weighted_n = 0.0
        for comp in branch.components:
            k, n = component_k(
                comp,
                pipenet,
                default_rad_k,
                radiator_k_map,
                balancing_k_map,
            )
            total_k += k
            weighted_n += k * n
        arrays.resistance[i] = max(total_k, MIN_BRANCH_RESISTANCE)
        if total_k > 0:
            arrays.exponent[i] = weighted_n / total_k


def _adjust_head_for_radiator_dp(
    proj: Project,
    calc_pn: CalcPipeNet,
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    radiator_k_map: dict[str, float] | None,
    token: CancelToken,
    dp_rad_pa: float,
    *,
    balancing_k_map: dict[str, float] | None = None,
    max_rounds: int = 16,
    rooms_out: dict[str, Any] | None = None,
    comp_t_supply: dict[str, float] | None = None,
    hx_supply: dict[str, float] | None = None,
) -> tuple[
    dict[str, float] | None, dict[str, float] | None, dict[str, dict[str, Any]] | None
]:
    """Iterative adjustment of pump, balancing valves, and radiator presets.

    Each iteration:
    1. Adjust HX head (pump) so median radiator valve dp ≈ dp_rad_pa
    2. Adjust balancing valves to reduce branch dp_sr toward dp_rad_pa
    3. From round 4 onwards, recalculate radiator presets with actual temps

    After each adjustment phase, the network is re-converged with Hardy-Cross
    to find the actual operating point before the next iteration.

    Args:
        proj: Project with pipenet, valve, floors, etc.
        graph: FlowGraph topology.
        arrays: FlowArrays with current solution.
        cm: CycleMatrix for branch indexing.
        radiator_k_map: Initial per-radiator resistance map.
        token: CancelToken for interruptibility.
        dp_rad_pa: Target radiator valve pressure drop (Pa).
        balancing_k_map: Optional balancing valve resistance map.
        max_rounds: Maximum adjustment rounds (default 16).
        rooms_out: Room calculation results for power requirements.

    Returns:
        (updated_radiator_k_map, updated_balancing_k_map,
         radiator_preset_map) after adjustment.
    """
    valve = proj.valve
    rad_kv = preset_kv(valve, "2.0")
    if rad_kv <= 0:
        rad_kv = middle_kv(valve)
    default_rad_k = kv_to_k(rad_kv)

    # Make mutable copies
    current_rad_k_map: dict[str, float] = dict(radiator_k_map) if radiator_k_map else {}
    current_balancing_k_map: dict[str, float] = (
        dict(balancing_k_map) if balancing_k_map else {}
    )
    current_preset_map: dict[str, dict[str, Any]] = {}
    prev_pipe_heat: dict[str, float] = {}  # dampened pipe heat across rounds
    prev_kv_want: dict[str, float] = {}  # dampened kv_want across rounds

    # Find HX branch index once
    hx_idx: int | None = None
    for bkey in cm.branch_keys:
        branch = graph.branches.get(bkey)
        if branch is None:
            continue
        if any(is_hx_component(comp) for comp in branch.components):
            hx_idx = cm.branch_index[bkey]
            break

    for round_idx in range(max_rounds):
        token.check()

        # ---------------------------------------------------------------------
        # Step 1: Adjust pump (HX head) based on median radiator dp
        # ---------------------------------------------------------------------
        rad_dps: list[float] = []
        for bkey in cm.branch_keys:
            branch = graph.branches[bkey]
            idx = cm.branch_index[bkey]
            flow = float(arrays.flows[idx])
            for comp in branch.components:
                if comp in calc_pn.radiators:
                    k, n = component_k(
                        comp,
                        calc_pn,
                        default_rad_k,
                        current_rad_k_map,
                        current_balancing_k_map,
                    )
                    dp = abs(k * abs(flow) ** n)
                    rad_dps.append(dp)

        if rad_dps and hx_idx is not None:
            rad_dps.sort()
            median_dp = rad_dps[len(rad_dps) // 2]
            current_head = float(arrays.head[hx_idx])
            if not math.isfinite(current_head):
                current_head = 20_000.0
                arrays.head[hx_idx] = current_head
            ratio = dp_rad_pa / max(median_dp, 1.0)
            # Cap ratio to prevent exponential blowup when flows are
            # near-zero (e.g. one side disconnected → no cycles → 0 flow).
            ratio = min(ratio, 10.0)
            target_head = max(1000.0, min(current_head * ratio, 1_000_000.0))
            # Dampen to avoid oscillation
            new_head = current_head + 0.5 * (target_head - current_head)
            arrays.head[hx_idx] = new_head

        # ---------------------------------------------------------------------
        # Step 2: Adjust balancing valves to reduce dp_sr toward dp_rad
        # ---------------------------------------------------------------------
        if round_idx >= _BALANCING_VALVE_ADJUST_START_ROUND and calc_pn.valves:
            is_final = round_idx == max_rounds - 1
            new_balancing_k_map = _adjust_balancing_valves(
                proj,
                calc_pn,
                graph,
                arrays,
                cm,
                current_balancing_k_map,
                dp_rad_pa,
                snap_to_preset=is_final,
            )
            if new_balancing_k_map != current_balancing_k_map:
                current_balancing_k_map = new_balancing_k_map
                # Update resistance array with new balancing valve k values
                _update_branch_resistance(
                    graph,
                    arrays,
                    cm,
                    calc_pn,
                    default_rad_k,
                    current_rad_k_map,
                    current_balancing_k_map,
                )

        # ---------------------------------------------------------------------
        # Step 2b: Seed initial pipe heat estimate from round 3 (last
        # pre-thermostat round) so the first thermostat round has a stable
        # starting point.
        # ---------------------------------------------------------------------
        if round_idx == _RADIATOR_ADJUST_START_ROUND - 1 and rooms_out:
            seed_temps = _compute_temperatures(
                graph,
                arrays,
                cm,
                proj,
                calc_pn,
                comp_t_supply=comp_t_supply,
                hx_supply=hx_supply,
            )
            seed_detail = _compute_pipe_heat_to_rooms(
                seed_temps, graph, arrays, cm, calc_pn, proj
            )
            prev_pipe_heat = {
                rk: sum(w for w, _ in kinds.values())
                for rk, kinds in seed_detail.items()
            }

        # ---------------------------------------------------------------------
        # Step 3: From round 4+, recalculate radiator presets with actual temps
        # ---------------------------------------------------------------------
        if round_idx >= _RADIATOR_ADJUST_START_ROUND and rooms_out:
            # Compute temperatures through the network
            comp_temps = _compute_temperatures(
                graph,
                arrays,
                cm,
                proj,
                calc_pn,
                comp_t_supply=comp_t_supply,
                hx_supply=hx_supply,
            )

            # Compute pipe heat, dampened to avoid thermostat oscillation.
            # 90% previous + 10% new for slow, stable convergence.
            raw_pipe_heat_detail = _compute_pipe_heat_to_rooms(
                comp_temps, graph, arrays, cm, calc_pn, proj
            )
            raw_pipe_heat: dict[str, float] = {
                rk: sum(w for w, _ in kinds.values())
                for rk, kinds in raw_pipe_heat_detail.items()
            }
            pipe_heat: dict[str, float] = {}
            for rk in set(raw_pipe_heat) | set(prev_pipe_heat):
                pipe_heat[rk] = 0.9 * prev_pipe_heat.get(
                    rk, 0.0
                ) + 0.1 * raw_pipe_heat.get(rk, 0.0)
            prev_pipe_heat = dict(pipe_heat)

            # Recalculate radiator presets with actual supply temps
            new_rad_k_map, new_preset_map = _recalculate_radiator_presets(
                proj,
                calc_pn,
                graph,
                arrays,
                cm,
                rooms_out,
                comp_temps,
                comp_t_supply=comp_t_supply,
                pipe_heat_by_room=pipe_heat,
                prev_kv_want=prev_kv_want,
            )

            if new_preset_map:
                current_preset_map.update(new_preset_map)
            if new_rad_k_map:
                current_rad_k_map.update(new_rad_k_map)
                # Update resistance array with new radiator k values
                _update_branch_resistance(
                    graph,
                    arrays,
                    cm,
                    calc_pn,
                    default_rad_k,
                    current_rad_k_map,
                    current_balancing_k_map,
                )

        # ---------------------------------------------------------------------
        # Step 4: Re-converge the network with updated resistances
        # ---------------------------------------------------------------------
        _converge(cm, arrays, token)

        # Check for early termination - if median dp is close enough
        rad_dps_check: list[float] = []
        bvalve_dps: list[float] = []
        for bkey in cm.branch_keys:
            branch = graph.branches[bkey]
            idx = cm.branch_index[bkey]
            flow = float(arrays.flows[idx])
            for comp in branch.components:
                if comp in calc_pn.radiators:
                    k, n = component_k(
                        comp,
                        calc_pn,
                        default_rad_k,
                        current_rad_k_map,
                        current_balancing_k_map,
                    )
                    dp = abs(k * abs(flow) ** n)
                    rad_dps_check.append(dp)
                elif comp.startswith("return ") and current_balancing_k_map.get(comp):
                    bv_k = current_balancing_k_map[comp]
                    bv_dp = abs(bv_k * flow * flow)
                    bvalve_dps.append(bv_dp)

        pump_pa = float(arrays.head[hx_idx]) if hx_idx is not None else 0.0
        n_rad = len(rad_dps_check)
        rad_p5 = rad_p50 = rad_p95 = 0.0
        if rad_dps_check:
            rad_dps_check.sort()
            rad_p5 = rad_dps_check[max(0, int(n_rad * 0.05))]
            rad_p50 = rad_dps_check[n_rad // 2]
            rad_p95 = rad_dps_check[min(n_rad - 1, int(n_rad * 0.95))]
        bv_min = bv_max = 0.0
        if bvalve_dps:
            bvalve_dps.sort()
            bv_min = bvalve_dps[0]
            bv_max = bvalve_dps[-1]
        logger.info(
            "adjust round %d: pump=%.1f kPa, "
            "rad dp %.1f/%.1f/%.1f kPa, "
            "bvalve dp=%.1f..%.1f kPa",
            round_idx,
            pump_pa / 1000,
            rad_p5 / 1000,
            rad_p50 / 1000,
            rad_p95 / 1000,
            bv_min / 1000,
            bv_max / 1000,
        )

    return (
        current_rad_k_map or None,
        current_balancing_k_map or None,
        current_preset_map or None,
    )


# ---------------------------------------------------------------------------
# Junction pressures
# ---------------------------------------------------------------------------


def _compute_junction_pressures(
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
) -> dict[str, float]:
    """Compute absolute pressure at each typed junction (Pa).

    Reference: return side of HX root junction = 0 Pa.
    Traverses backbone (non-loop) branches by BFS from the HX branch.
    """
    pressures: dict[str, float] = {}

    # Find HX branch
    hx_bkey: str | None = None
    for bkey in cm.branch_keys:
        branch = graph.branches.get(bkey)
        if branch is None:
            continue
        if any(is_hx_component(comp) for comp in branch.components):
            hx_bkey = bkey
            break
    if hx_bkey is None:
        return pressures

    hx_branch = graph.branches[hx_bkey]
    j1, j2 = hx_branch.junctions
    idx = cm.branch_index[hx_bkey]
    flow = float(arrays.flows[idx])
    k = float(arrays.resistance[idx])
    n = float(arrays.exponent[idx])
    h = float(arrays.head[idx])
    Q_abs = max(abs(flow), 1e-12)
    # Signed friction dp: positive when flow goes j1→j2
    dp_friction = k * math.copysign(Q_abs**n, flow)

    # P(j1) - P(j2) = dp_friction - h
    pressures[j1] = 0.0
    pressures[j2] = pressures[j1] - dp_friction + h

    # BFS through non-loop branches
    queue: deque[str] = deque([j1, j2])
    visited = {hx_bkey}

    while queue:
        j = queue.popleft()
        for bkey in graph.junction_branches.get(j, []):
            if bkey in visited:
                continue
            branch = graph.branches[bkey]
            if bkey.startswith("loop_"):
                continue

            j_a, j_b = branch.junctions
            if j_a in pressures and j_b not in pressures:
                known_j = j_a
            elif j_b in pressures and j_a not in pressures:
                known_j = j_b
            else:
                continue

            visited.add(bkey)
            if bkey not in cm.branch_index:
                continue
            bidx = cm.branch_index[bkey]
            bflow = float(arrays.flows[bidx])
            bk = float(arrays.resistance[bidx])
            bn = float(arrays.exponent[bidx])
            bh = float(arrays.head[bidx])
            bQ = max(abs(bflow), 1e-12)
            bdp = bk * math.copysign(bQ**bn, bflow)

            # P(j_a) - P(j_b) = bdp - bh
            if known_j == j_a:
                pressures[j_b] = pressures[j_a] - bdp + bh
                queue.append(j_b)
            else:
                pressures[j_a] = pressures[j_b] + bdp - bh
                queue.append(j_a)

    return pressures


# ---------------------------------------------------------------------------
# Valve supply–return delta-p
# ---------------------------------------------------------------------------


def _compute_valve_dp_sr(
    comp_key: str,
    graph: FlowGraph,
    comp_to_branch: dict[str, str],
    comp_dp_map: dict[str, float],
    arrays: FlowArrays,
    cm: CycleMatrix,
    junction_pressures: dict[str, float] | None,
) -> float | None:
    """Compute supply–return pressure difference at a valve position.

    *comp_key* is the return-pipe component carrying the valve (e.g.
    ``"return pipe:0"``).  The corresponding supply pipe is obtained by
    replacing ``"return "`` with ``"supply "``.

    **Loop branch** (both pipes in the same branch):
    ``dp_sr = dp_branch - dp(supply_comp) - dp(return_comp)``
    which equals the sum of dp of all components between the two pipes,
    i.e. the pressure driving the inner circuit (radiator + inner pipes).

    **Backbone** (pipes in different branches): uses *junction_pressures*
    to compute ``P(supply J_far) - P(return J_far)`` at the junction on
    the radiator side of the valve.

    Returns ``None`` when the result cannot be computed.
    """
    # Derive the matching supply component key
    if not comp_key.startswith("return "):
        return None
    supply_comp = "supply " + comp_key[7:]

    branch_r = comp_to_branch.get(comp_key)
    branch_s = comp_to_branch.get(supply_comp)
    if not branch_r or not branch_s:
        return None

    if branch_r == branch_s:
        return _dp_sr_loop(graph.branches[branch_r], supply_comp, comp_key, comp_dp_map)

    # Backbone case: supply and return pipes in different branches.
    if junction_pressures is None:
        return None  # caller will retry after computing junction pressures

    # Supply branch: radiator-side junction = j2; return branch: j1
    j_supply_far = graph.branches[branch_s].junctions[1]
    j_return_far = graph.branches[branch_r].junctions[0]

    p_supply = junction_pressures.get(j_supply_far)
    p_return = junction_pressures.get(j_return_far)
    if p_supply is None or p_return is None:
        return None
    return p_supply - p_return


def _dp_sr_loop(
    branch: Branch,
    supply_comp: str,
    return_comp: str,
    comp_dp_map: dict[str, float],
) -> float | None:
    """dp_sr for a loop branch where both pipes are in the same branch."""
    comps = branch.components
    try:
        idx_s = comps.index(supply_comp)
        idx_r = comps.index(return_comp)
    except ValueError:
        return None
    if idx_s >= idx_r:
        return None
    # Sum dp of all components between the two (exclusive)
    return sum(comp_dp_map.get(c, 0.0) for c in comps[idx_s + 1 : idx_r])


def _valve_radiator_direction(
    comp_key: str,
    graph: FlowGraph,
    pipenet: PipeNet,
) -> float | None:
    """Return world-space angle (radians) toward the radiator side.

    The valve sits on a return-pipe component whose ``component_nodes``
    gives ``(from_node, to_node)`` in branch traversal order.  For return
    pipes, ``from_node`` is the radiator side.

    Returns ``atan2(dy, dx)`` pointing from the valve toward the
    radiator-side node, or ``None`` if it cannot be determined.
    """
    nodes = graph.component_nodes.get(comp_key)
    if nodes is None:
        return None

    from_key, to_key = nodes
    n_from = pipenet.nodes.get(from_key)
    n_to = pipenet.nodes.get(to_key)
    if not n_from or not n_to:
        return None

    # Direction from to_node toward from_node (= toward radiator)
    dx = n_from.x - n_to.x
    dy = n_from.y - n_to.y
    if dx == 0 and dy == 0:
        return None

    return round(math.atan2(dy, dx), 4)


# ---------------------------------------------------------------------------
# Result extraction
# ---------------------------------------------------------------------------


def _extract_results(
    proj: Project,
    calc_pn: CalcPipeNet,
    graph: FlowGraph,
    arrays: FlowArrays,
    cm: CycleMatrix,
    radiator_k_map: dict[str, float] | None = None,
    rooms_out: dict[str, Any] | None = None,
    comp_temps: dict[str, tuple[float, float]] | None = None,
    balancing_k_map: dict[str, float] | None = None,
    radiator_preset_map: dict[str, dict[str, Any]] | None = None,
    comp_t_supply: dict[str, float] | None = None,
    comp_hx_map: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Extract solver results into a JSON-serialisable dict.

    Result shape (sent to client as ``calc_result.result``)::

        {
          "branches": {
            "<branch_key>": {
              "junctions": ["supply N1", "return N1"],
              "flow": 0.0118,            # litres per second
              "dp": 1234.0,              # total branch pressure drop (Pa)
              "components": [
                {"key": "supply P1", "kind": "pipe", "pipe": "P1",
                 "dn": "Cu15", "k": 1234, "dp": 567.0},
                {"key": "RAD1", "kind": "radiator", "k": ..., "dp": ...},
                                {"key": "HX:<hx_key>", "kind": "hx", "k": 0, "dp": 0},
                ...
              ]
            },
            ...
          },
          "pipes": {"<comp_key>": {"flow": ..., "dp": ...}, ...},
                    "radiators": {"<rad_key>": {"flow": ..., "dp": ..., ...}, ...},
                    "hxs": {"<hx_key>": {"flow": ..., "head": ...}, ...},
                    "hx": {"flow": ..., "head": ...},  # legacy single-HX alias
        }
    """
    valve = proj.valve
    rad_kv = preset_kv(valve, "2.0")
    if rad_kv <= 0:
        rad_kv = middle_kv(valve)
    default_rad_k = kv_to_k(rad_kv)

    # Build room-calc lookup: (room_id, rad_code) → room-calc radiator info
    # for enriching pipenet radiator results with preset, return temp, etc.
    t_supply_default = float(proj.t_supply)
    t_env = float(proj.t_env)
    comp_t_supply = comp_t_supply or {}
    comp_hx_map = comp_hx_map or {}
    room_rad_info: dict[tuple[str, str], dict[str, Any]] = {}
    if rooms_out:
        for room_id, rdata in rooms_out.items():
            for rad in rdata.get("radiators", []):
                code = rad.get("code", "")
                if code:
                    room_rad_info[(room_id, code)] = rad

    branches_out: dict[str, Any] = {}
    pipes_out: dict[str, Any] = {}
    radiators_out: dict[str, Any] = {}
    hxs_out: dict[str, dict[str, Any]] = {}
    hx_rad_power: dict[str, float] = defaultdict(float)
    hx_rad_power_req: dict[str, float] = defaultdict(float)

    # Maps for valve dp_sr computation
    comp_to_branch: dict[str, str] = {}  # component key → branch key
    comp_dp_map: dict[str, float] = {}  # component key → friction dp

    for bkey in cm.branch_keys:
        branch = graph.branches[bkey]
        idx = cm.branch_index[bkey]
        flow = float(arrays.flows[idx])
        k_total = float(arrays.resistance[idx])
        n_branch = float(arrays.exponent[idx])
        dp_total = k_total * abs(flow) ** n_branch
        head = float(arrays.head[idx])

        comp_list: list[dict[str, Any]] = []
        for comp in branch.components:
            comp_to_branch[comp] = bkey
            k, n = component_k(
                comp,
                calc_pn,
                default_rad_k,
                radiator_k_map,
                balancing_k_map,
            )
            dp = k * abs(flow) ** n

            comp_dp_map[comp] = dp

            if is_hx_component(comp):
                entry: dict[str, Any] = {
                    "key": comp,
                    "kind": "hx",
                    "k": 0,
                    "dp": 0,
                }
                hx_flow = flow if math.isfinite(flow) else 0.0
                hx_head = head if math.isfinite(head) else 0.0
                hx_key = hx_key_from_component(comp)
                if hx_key is not None:
                    hx_item = {"flow": round(hx_flow, 6), "head": hx_head}
                    if comp_temps and comp in comp_temps:
                        hx_item["t_supply"] = round(comp_temps[comp][1], 1)
                        hx_item["t_return"] = round(comp_temps[comp][0], 1)
                    hxs_out[hx_key] = hx_item
            elif comp.startswith(("supply ", "return ")):
                comp_key = comp.split(" ", 1)[1]
                # Parse pipe_key and optional segment index
                pipe_base_key, seg_idx = _parse_pipe_comp(comp_key)
                pipe = calc_pn.pipes.get(pipe_base_key)
                if pipe:
                    if seg_idx is not None:
                        dn = _segment_dn(pipe, seg_idx)
                    else:
                        dn = pipe.first_dn() or "?"
                else:
                    dn = "?"
                pipe_key = pipe_base_key
                # Prefer original segment endpoints for render/debug output.
                # Flow graph may collapse HX-box nodes to one representative.
                graph_nodes = graph.component_nodes.get(comp)
                resolved_nodes = _resolve_component_nodes(comp, calc_pn, graph_nodes)

                # Hydrostatic head for this pipe component
                hydro_dp = 0.0
                if resolved_nodes is not None:
                    from_key, to_key = resolved_nodes
                    n1 = calc_pn.nodes.get(from_key)
                    n2 = calc_pn.nodes.get(to_key)
                    if n1 and n2:
                        h1 = n1.z / 1000.0
                        h2 = n2.z / 1000.0
                    else:
                        h1 = _vnode_height(from_key, calc_pn)
                        h2 = _vnode_height(to_key, calc_pn)
                    t_supply = comp_t_supply.get(comp, t_supply_default)
                    rho = water_density(
                        t_supply if comp.startswith("supply ") else 40.0
                    )
                    hydro_dp = rho * gravity * (h2 - h1)  # Pa, positive = uphill
                entry = {
                    "key": comp,
                    "kind": "pipe",
                    "pipe": pipe_key,
                    "dn": dn,
                    "k": round(k, 1),
                    "dp": round(dp, 1),
                    "dp_hydro": round(hydro_dp, 1),
                }
                if resolved_nodes is not None:
                    entry["from_node"] = resolved_nodes[0]
                    entry["to_node"] = resolved_nodes[1]
                    entry["from_floor"] = calc_pn.node_floor_ids[resolved_nodes[0]]
                    entry["to_floor"] = calc_pn.node_floor_ids[resolved_nodes[1]]
                pipe_result: dict[str, Any] = {
                    "flow": round(flow, 6),
                    "dp": round(dp, 1),
                    "dp_hydro": round(hydro_dp, 1),
                }
                if comp_temps and comp in comp_temps:
                    pipe_result["t_in"] = round(comp_temps[comp][0], 1)
                    pipe_result["t_out"] = round(comp_temps[comp][1], 1)
                pipes_out[comp] = pipe_result
                # Also publish under plain pipe-level key (without segment
                # suffix) so that the frontend can look up results by pipe
                # UUID.  When multiple segments of the same pipe appear in
                # different branches we accumulate dp / dp_hydro.
                side = comp.split(" ", 1)[0]
                plain_key = f"{side} {pipe_base_key}"
                if plain_key != comp:
                    if plain_key in pipes_out:
                        existing = pipes_out[plain_key]
                        existing["dp"] = round(existing["dp"] + dp, 1)
                        existing["dp_hydro"] = round(existing["dp_hydro"] + hydro_dp, 1)
                        # Keep first t_in, update t_out to latest segment
                        if comp_temps and comp in comp_temps:
                            existing["t_out"] = round(comp_temps[comp][1], 1)
                    else:
                        plain_result: dict[str, Any] = {
                            "flow": round(flow, 6),
                            "dp": round(dp, 1),
                            "dp_hydro": round(hydro_dp, 1),
                        }
                        if comp_temps and comp in comp_temps:
                            plain_result["t_in"] = round(comp_temps[comp][0], 1)
                            plain_result["t_out"] = round(comp_temps[comp][1], 1)
                        pipes_out[plain_key] = plain_result
            elif comp in calc_pn.radiators:
                entry = {
                    "key": comp,
                    "kind": "radiator",
                    "k": round(k, 1),
                    "dp": round(dp, 1),
                }
                rad_out: dict[str, Any] = {
                    "flow": round(flow, 6),
                    "dp": round(dp, 1),
                }
                # Enrich with room info and return temperature
                crad = calc_pn.radiators[comp]
                if crad.room_id:
                    room = proj.rooms.get(crad.room_id)
                    if room:
                        rad_out["room_name"] = room.name
                    elif comp.startswith("rad:"):
                        # New-style Radiator — use radiator name
                        parts = comp.split(":")
                        if len(parts) >= 2:
                            plan_rad = proj.radiators.get(parts[1])
                            if plan_rad and plan_rad.name:
                                rad_out["room_name"] = plan_rad.name
                    room_calc = rooms_out.get(crad.room_id) if rooms_out else None
                    if room_calc is not None:
                        rad_out["has_conditions"] = bool(room_calc.get("conditions"))
                    # Look up room-calc radiator for preset/kv
                    code = crad.code.split()[0].lower() if crad.code else ""
                    rinfo = room_rad_info.get((crad.room_id, code))
                    if rinfo:
                        rad_out["valve"] = rinfo.get("valve", proj.valve)
                        rad_out["code"] = code
                        share = rinfo.get("share")
                        if share is not None and room_calc:
                            room_power = float(room_calc.get("power", 0.0))
                            rad_out["power_req"] = round(
                                max(0.0, -room_power * share), 0
                            )
                        elif rinfo.get("p") is not None:
                            rad_out["power_req"] = rinfo.get("p")

                    # Report design (installed) preset from iterative
                    # adjustment, which accounts for actual supply temps.
                    if radiator_preset_map and comp in radiator_preset_map:
                        pi = radiator_preset_map[comp]
                        rad_out["preset"] = pi["preset"]
                        rad_out["kv"] = pi["kv"]
                    # Use propagated temperatures if available
                    if comp_temps and comp in comp_temps:
                        t_sup = comp_temps[comp][0]
                        t_ret = comp_temps[comp][1]
                        rad_out["t_supply"] = round(t_sup)
                        rad_out["t_return"] = round(t_ret)
                        rad_out["power"] = round(water_c * flow * (t_sup - t_ret), 0)
                    else:
                        rad_cond = radiator_find(code) if code else None
                        if rad_cond and flow > 1e-9:
                            t_supply = comp_t_supply.get(comp, t_supply_default)
                            theta1 = t_supply - t_env
                            theta2 = theta2_for_flow(rad_cond, theta1, flow)
                            rad_out["t_return"] = round(theta2 + t_env)
                            rad_out["t_supply"] = round(t_supply)
                            rad_out["power"] = round(
                                water_c * flow * (theta1 - theta2), 0
                            )
                radiators_out[comp] = rad_out
                hx_key = comp_hx_map.get(comp)
                if hx_key:
                    hx_rad_power[hx_key] += float(rad_out.get("power", 0.0) or 0.0)
                    hx_rad_power_req[hx_key] += float(
                        rad_out.get("power_req", 0.0) or 0.0
                    )
            else:
                entry = {
                    "key": comp,
                    "kind": "unknown",
                    "k": round(k, 1),
                    "dp": round(dp, 1),
                }

            comp_list.append(entry)

        branches_out[bkey] = {
            "junctions": list(branch.junctions),
            "flow": round(flow, 6),
            "dp": round(dp_total, 1),
            "head": round(head, 1),
            "components": comp_list,
        }

    # Build per-valve results: resolved type, preset, kv, flow, dp, dp_sr
    valves_out: dict[str, Any] = {}
    junction_pressures: dict[str, float] | None = None  # computed lazily
    if proj.valvebal and calc_pn.valves:
        valve_info = build_valve_info_map(calc_pn, proj.valvebal)
        for valve_id, info in valve_info.items():
            comp_key = str(info["comp_key"])
            # Find flow through the return pipe segment carrying this valve
            pipe_result = pipes_out.get(comp_key)
            flow_valve = abs(pipe_result["flow"]) if pipe_result else 0.0

            # Use adjusted k if available, otherwise original
            if balancing_k_map and comp_key in balancing_k_map:
                k_valve = balancing_k_map[comp_key]
            else:
                k_valve = float(info["k"])
            dp_valve = k_valve * flow_valve * flow_valve  # k * Q² (n=2)

            # Compute dp_sr: supply–return pressure difference on the
            # radiator side of the valve.  This is the available
            # differential pressure driving flow through the circuit
            # "behind" the valve.
            dp_sr = _compute_valve_dp_sr(
                comp_key,
                graph,
                comp_to_branch,
                comp_dp_map,
                arrays,
                cm,
                junction_pressures,
            )
            if junction_pressures is None and dp_sr is None:
                # Lazily compute junction pressures for backbone case
                junction_pressures = _compute_junction_pressures(graph, arrays, cm)
                dp_sr = _compute_valve_dp_sr(
                    comp_key,
                    graph,
                    comp_to_branch,
                    comp_dp_map,
                    arrays,
                    cm,
                    junction_pressures,
                )

            valve_obj = calc_pn.valves.get(valve_id)

            # Determine preset and kv to display: use adjusted values if available
            valve_key = info["valve_key"]
            if balancing_k_map and comp_key in balancing_k_map:
                adjusted_k = balancing_k_map[comp_key]
                adjusted_kv_target = Kv.calc(Flow(1.0), Pressure(adjusted_k)).kv
                adjusted_preset, adjusted_kv = _find_bvalve_preset_for_kv(
                    valve_key,
                    adjusted_kv_target,
                    closest=True,
                )
                display_preset = adjusted_preset or info["preset"]
                display_kv = round(adjusted_kv, 2) if adjusted_kv > 0 else info["kv"]
            else:
                display_preset = info["preset"]
                display_kv = info["kv"]

            valve_out: dict[str, Any] = {
                "name": valve_obj.name if valve_obj else "",
                "valve_key": valve_key,
                "preset": display_preset,
                "kv": display_kv,
                "flow": round(flow_valve, 6),
                "dp": round(dp_valve, 1),
            }
            if dp_sr is not None:
                valve_out["dp_sr"] = round(dp_sr, 1)
            # Direction toward the radiator side (the "behind" side of
            # the valve on the return pipe).  Encoded as +1 or -1
            # relative to the pipe's geometric angle.
            # Return pipe component_nodes: from_node is radiator side.
            rad_dir = _valve_radiator_direction(
                comp_key,
                graph,
                calc_pn,
            )
            if rad_dir is not None:
                valve_out["rad_dir"] = rad_dir
            valves_out[valve_id] = valve_out

    # --- Zero-flow entries for pruned (disconnected) pipes ---
    for pipe_key in sorted(graph.pruned_pipes):
        for side in ("supply", "return"):
            comp_key = f"{side} {pipe_key}"
            if comp_key not in pipes_out:
                pipes_out[comp_key] = {
                    "flow": 0.0,
                    "dp": 0.0,
                    "dp_hydro": 0.0,
                    "t_in": t_env,
                    "t_out": t_env,
                }

    # HX power and per-HX radiator aggregates.
    for hx_key, hx_out in hxs_out.items():
        t_sup = hx_out.get("t_supply")
        t_ret = hx_out.get("t_return")
        hx_flow_val = float(hx_out.get("flow", 0.0) or 0.0)
        if t_sup is not None and t_ret is not None and hx_flow_val > 0:
            # flow in l/s, cp ≈ 4186 J/(kg·K), ρ ≈ 1 kg/l
            hx_out["power"] = round(hx_flow_val * (t_sup - t_ret) * 4186, 0)
        else:
            hx_out["power"] = 0.0

        rad_power = hx_rad_power.get(hx_key, 0.0)
        rad_power_req = hx_rad_power_req.get(hx_key, 0.0)
        hx_out["rad_power"] = round(rad_power, 0)
        hx_out["rad_power_req"] = round(rad_power_req, 0)
        hx_out["power_req"] = round(rad_power_req, 0)

    # --- Stub entries for PlanRadiators that weren't calculated ---
    # Every Radiator must appear in radiators_out so the frontend can
    # display a reason when a radiator couldn't be solved.
    plan_floor_ids: dict[str, list[str]] = {}
    for f in proj.floors:
        if f.plan:
            plan_floor_ids.setdefault(f.plan, []).append(f.id)

    for rad_id, rad in proj.radiators.items():
        if rad.floors is not None:
            target_floor_ids = list(rad.floors.keys())
        elif rad.plan:
            target_floor_ids = plan_floor_ids.get(rad.plan, [])
        else:
            target_floor_ids = []

        if not target_floor_ids:
            # No target floors: plan mismatch or floor missing plan field.
            # Emit a stub keyed without a floor so the frontend can show
            # the reason for the missing radiator.
            stub_key = f"rad:{rad_id}:?"
            if stub_key not in radiators_out:
                radiators_out[stub_key] = {
                    "error": (
                        f"No floor references plan '{rad.plan}'"
                        if rad.plan
                        else "Radiator has no plan"
                    )
                }
            continue

        for floor_id in target_floor_ids:
            calc_rad_key = f"rad:{rad_id}:{floor_id}"
            if calc_rad_key in radiators_out:
                continue
            if calc_rad_key in calc_pn.radiators:
                msg = "Network not connected"
            else:
                msg = "Not connected"
            radiators_out[calc_rad_key] = {"error": msg}

    return {
        "branches": branches_out,
        "pipes": pipes_out,
        "radiators": radiators_out,
        "valves": valves_out,
        "hxs": hxs_out,
    }


# ---------------------------------------------------------------------------
# Compute entry point
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Room compilation helpers
# ---------------------------------------------------------------------------


def _compile_rooms(
    project: Project,
    token: CancelToken,
    calc_pn: CalcPipeNet | None = None,
    room_t_supply: dict[str, float] | None = None,
) -> tuple[dict[str, Any], dict[str, float]]:
    """Compile all rooms and build a per-radiator Kv map.

    Returns:
        (rooms_result, radiator_k_map)
        - rooms_result: {room_id: serialised RoomCalc} for WS delivery.
        - radiator_k_map: {pipenet_radiator_key: resistance_k} built by
          matching pipenet radiators to room-calculated radiator presets
          via the ``room_id`` / ``room_rad`` link fields.

    When ``project.thermostat`` is enabled, the effective Kv is capped at
    the value needed for the power-required flow (thermostat head throttles
    down when the valve preset would admit more flow than necessary).
    """
    rooms_out: dict[str, Any] = {}
    thermostat = project.thermostat
    dp_rad_pa = float(project.dp_rad) * 1000.0  # kPa → Pa
    # (room_id, rad_code_lower) → (kv_preset, flow)  from room compilation
    room_kv: dict[tuple[str, str], tuple[float, float]] = {}

    # Room v2: rooms carry structured surfaces — compile them.
    token.check()
    try:
        manual_rooms, manual_rad_map = compile_manual_rooms(project, room_t_supply)
        rooms_out.update(manual_rooms)
        if calc_pn:
            for rad_key, room_key in manual_rad_map.items():
                crad = calc_pn.radiators.get(rad_key)
                if crad is not None:
                    crad.room_id = room_key
        for room_key, rdata in manual_rooms.items():
            for rad in rdata.get("radiators", []):
                code = rad.get("code", "")
                kv = rad.get("kv", 0)
                flow = rad.get("flow", 0)
                if kv and code:
                    room_kv[(room_key, code)] = (kv, flow)
    except Exception:
        logger.debug("manual room compile failed", exc_info=True)

    # --- Building-geometry rooms (wall-based heat loss + PlanRadiators) ---
    token.check()
    try:
        face_rooms, rad_face_map = compile_building_rooms(project, room_t_supply)
        rooms_out.update(face_rooms)
        # Set CalcRadiator.room_id to face key for downstream lookups
        if calc_pn:
            for rad_key, face_key in rad_face_map.items():
                crad = calc_pn.radiators.get(rad_key)
                if crad is not None:
                    crad.room_id = face_key
        # Merge radiator kv data from face rooms
        for face_key, fdata in face_rooms.items():
            for rad in fdata.get("radiators", []):
                code = rad.get("code", "")
                kv = rad.get("kv", 0)
                flow = rad.get("flow", 0)
                if kv and code:
                    room_kv[(face_key, code)] = (kv, flow)
    except Exception:
        logger.debug("building room compile failed", exc_info=True)

    # --- Roomless radiators with dedicated condition regime ---
    token.check()
    try:
        radcond_rooms, radcond_rad_map = compile_roomless_radcond_radiators(project)
        rooms_out.update(radcond_rooms)
        if calc_pn:
            for rad_key, room_key in radcond_rad_map.items():
                crad = calc_pn.radiators.get(rad_key)
                if crad is not None:
                    crad.room_id = room_key
        for room_key, rdata in radcond_rooms.items():
            for rad in rdata.get("radiators", []):
                code = rad.get("code", "")
                kv = rad.get("kv", 0)
                flow = rad.get("flow", 0)
                if kv and code:
                    room_kv[(room_key, code)] = (kv, flow)
    except Exception:
        logger.debug("roomless radcond radiator compile failed", exc_info=True)

    # Build pipenet radiator key → resistance k via structural links
    radiator_k_map: dict[str, float] = {}
    if calc_pn:
        for rad_key, crad in calc_pn.radiators.items():
            if not crad.code:
                continue
            code = crad.code.split()[0].lower()

            # Try room-computed kv first (building-geometry rooms)
            if crad.room_id:
                entry = room_kv.get((crad.room_id, code))
                if entry is not None:
                    kv_preset, flow = entry
                    if thermostat and flow > 0:
                        kv_power = Kv.calc(Flow(flow), Pressure(dp_rad_pa)).kv
                        kv = min(kv_preset, kv_power)
                    else:
                        kv = kv_preset
                    radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv)
                    continue

            # Fallback: Radiator with locked preset (no room calc needed)
            parts = rad_key.split(":")
            if len(parts) >= 2:
                plan_rad = project.radiators.get(parts[1])
                if plan_rad:
                    # Resolve effective preset (per-floor override or base)
                    floor_id = parts[2] if len(parts) > 2 else ""
                    floor_ov = (
                        plan_rad.floors.get(floor_id)
                        if plan_rad.floors and floor_id
                        else None
                    )
                    preset = (
                        floor_ov.preset
                        if floor_ov and floor_ov.preset
                        else plan_rad.preset
                    ) or ""
                    valve_name = (
                        floor_ov.valve
                        if floor_ov and floor_ov.valve
                        else plan_rad.valve
                    ) or project.valve
                    if preset:
                        try:
                            vt = valve_table_data[valve_name]
                            kv_idx = vt["ps"].index(preset)
                            kv = vt["kv"][kv_idx]
                            radiator_k_map[rad_key] = _effective_rad_k_from_kv(kv)
                        except KeyError, ValueError:
                            pass
                    # No preset → no kv constraint; solver uses unconstrained resistance

    return rooms_out, radiator_k_map


def _rooms_only_result(
    project: Project,
    token: CancelToken,
    rooms_out: dict[str, dict[str, Any]] | None = None,
    calc_pn: CalcPipeNet | None = None,
) -> dict[str, Any] | None:
    """Return a rooms-only payload, compiling rooms when needed.

    When *calc_pn* is provided (late-stage failures where pipe topology was
    already built), radiators that appear in the instantiated network get
    ``"Network not connected"`` (server-side issue) while radiators absent
    from the network get ``"Not connected"`` (client can compute standalone).
    Without *calc_pn* (no pipes / no HX at all), every radiator gets
    ``"Not connected"`` so the client computes standalone.
    """
    if rooms_out is None:
        rooms_out, _ = _compile_rooms(project, token)
    if not rooms_out and not project.radiators:
        return None

    # Include stub entries for every Radiator so the frontend can show
    # why radiators couldn't be calculated (no pipes / no HX).
    plan_floor_ids: dict[str, list[str]] = {}
    for f in project.floors:
        if f.plan:
            plan_floor_ids.setdefault(f.plan, []).append(f.id)

    calc_rad_keys = set(calc_pn.radiators) if calc_pn else set()

    radiators_out: dict[str, Any] = {}
    for rad_id, rad in project.radiators.items():
        if rad.floors is not None:
            target_floor_ids = list(rad.floors.keys())
        elif rad.plan:
            target_floor_ids = plan_floor_ids.get(rad.plan, [])
        else:
            target_floor_ids = []

        if not target_floor_ids:
            stub_key = f"rad:{rad_id}:?"
            radiators_out[stub_key] = {
                "error": (
                    f"No floor references plan '{rad.plan}'"
                    if rad.plan
                    else "Radiator has no plan"
                )
            }
        else:
            for floor_id in target_floor_ids:
                calc_rad_key = f"rad:{rad_id}:{floor_id}"
                if calc_rad_key in calc_rad_keys:
                    msg = "Network not connected"
                else:
                    msg = "Not connected"
                radiators_out[calc_rad_key] = {"error": msg}

    result: dict[str, Any] = {}
    if rooms_out:
        result["rooms"] = rooms_out
    if radiators_out:
        result["radiators"] = radiators_out
    return result or None


# ---------------------------------------------------------------------------
# Compute entry point
# ---------------------------------------------------------------------------


def compute_pipenet(project: Project, token: CancelToken) -> dict[str, Any] | None:
    """Compute function for ``CalcRunner``.

    Called in a worker thread.  Returns a JSON-serialisable dict or
    ``None`` if the project has no pipenet data.
    """
    if not project.pipenet or not project.pipenet.pipes:
        return _rooms_only_result(project, token)

    token.check()

    # 0. Instantiate: expand UI PipeNet into calc-time CalcPipeNet
    calc_pn = instantiate_pipenet(project)

    logger.info(
        "calc_pipenet: instantiated — pipes=%d  nodes=%d  hxs=%d  radiators=%d  plan_radiators=%d",
        len(calc_pn.pipes),
        len(calc_pn.nodes),
        len(calc_pn.hxs),
        len(calc_pn.radiators),
        len(project.radiators),
    )

    token.check()

    # 1. Build topology from the expanded calc pipenet
    graph = build_flow_graph(calc_pn)

    logger.info(
        "calc_pipenet: flow graph — branches=%d  junctions=%d  pruned_pipes=%d",
        len(graph.branches),
        len(graph.junctions),
        len(graph.pruned_pipes),
    )
    # Log which radiator keys appear in branch components
    rad_in_branches = {
        comp
        for branch in graph.branches.values()
        for comp in branch.components
        if comp in calc_pn.radiators
    }
    logger.info(
        "calc_pipenet: radiators in branches=%d / instantiated=%d",
        len(rad_in_branches),
        len(calc_pn.radiators),
    )

    if not graph.branches:
        logger.warning("calc_pipenet: no branches — returning rooms-only result")
        return _rooms_only_result(project, token, calc_pn=calc_pn)

    if not any(
        any(is_hx_component(comp) for comp in branch.components)
        for branch in graph.branches.values()
    ):
        logger.warning(
            "calc_pipenet: skipping hydraulic solve because no HX-connected "
            "branch is present"
        )
        return _rooms_only_result(project, token, calc_pn=calc_pn)

    hx_supply = _hx_supply_map(project, calc_pn)
    node_hx_map = _build_node_hx_map(calc_pn)
    comp_hx_map = _build_component_hx_map(graph, calc_pn, node_hx_map)
    comp_t_supply: dict[str, float] = {
        comp: hx_supply[hx_key]
        for comp, hx_key in comp_hx_map.items()
        if hx_key in hx_supply
    }
    room_t_supply = _build_room_supply_map(project, calc_pn, comp_hx_map, hx_supply)

    token.check()

    # 0b. Compile rooms (with calc_pn so radiator_k_map uses expanded keys)
    rooms_out, radiator_k_map = _compile_rooms(
        project,
        token,
        calc_pn,
        room_t_supply=room_t_supply,
    )

    token.check()

    # 2. Build cycle matrix & resistance (using per-radiator Kv from rooms)
    try:
        cm = build_cycle_matrix(graph)
        if not cm.branch_keys:
            logger.warning(
                "calc_pipenet: no valid branches available for cycle matrix; "
                "skipping hydraulic solve"
            )
            _log_graph_integrity_debug(graph, context="calc_pipenet:no-valid-branches")
            return _rooms_only_result(project, token, rooms_out, calc_pn=calc_pn)

        resistance, exponent = compute_branch_resistance(
            graph,
            calc_pn,
            project.valve,
            cm.branch_keys,
            "2.0",
            radiator_k_map=radiator_k_map,
            valvebal=project.valvebal,
        )
    except CancelledError:
        raise
    except Exception:
        logger.exception(
            "calc_pipenet: failed to prepare cycle matrix/resistance; "
            "skipping hydraulic solve"
        )
        _log_graph_integrity_debug(graph, context="calc_pipenet:prepare-failed")
        return _rooms_only_result(project, token, rooms_out, calc_pn=calc_pn)

    # Pre-build balancing valve k map for result extraction / head adjustment
    balancing_k_map = (
        build_balancing_valve_k_map(calc_pn, project.valvebal)
        if project.valvebal
        else {}
    )

    token.check()

    # 2b. Compute per-branch hydrostatic head from pipe height differences
    hydrostatic_head = compute_branch_hydrostatic_head(
        graph,
        calc_pn,
        cm.branch_keys,
        t_supply=float(project.t_supply),
        t_return=40.0,
        component_supply_temp=comp_t_supply,
    )

    token.check()

    # 3. Solve (with cancellation checks inside the loop)
    arrays, cm = _solve_flows_cancellable(
        graph, resistance, token, exponent=exponent, hydrostatic_head=hydrostatic_head
    )

    token.check()

    # 3b. Iteratively adjust pump, balancing valves, and radiator presets
    # This runs up to 16 iterations to stabilize the network
    dp_rad_pa = float(project.dp_rad) * 1000.0  # kPa → Pa
    updated_radiator_k_map, updated_balancing_k_map, radiator_preset_map = (
        _adjust_head_for_radiator_dp(
            project,
            calc_pn,
            graph,
            arrays,
            cm,
            radiator_k_map,
            token,
            dp_rad_pa,
            balancing_k_map=balancing_k_map,
            rooms_out=rooms_out,
            comp_t_supply=comp_t_supply,
            hx_supply=hx_supply,
        )
    )
    # Use updated maps for result extraction
    if updated_radiator_k_map is not None:
        radiator_k_map = updated_radiator_k_map
    if updated_balancing_k_map is not None:
        balancing_k_map = updated_balancing_k_map

    token.check()

    # 4. Compute temperatures through the network
    comp_temps = _compute_temperatures(
        graph,
        arrays,
        cm,
        project,
        calc_pn,
        comp_t_supply=comp_t_supply,
        hx_supply=hx_supply,
    )

    token.check()

    # 4b. Compute pipe heat contribution to rooms
    pipe_heat_by_room = _compute_pipe_heat_to_rooms(
        comp_temps, graph, arrays, cm, calc_pn, project
    )
    # Inject pipe heat as pseudo-radiator entries into rooms_out (one per kind)
    if rooms_out and pipe_heat_by_room:
        for room_key, kind_data in pipe_heat_by_room.items():
            if room_key not in rooms_out:
                continue
            rdata = rooms_out[room_key]
            for kind, (q_watts, length_mm) in sorted(kind_data.items()):
                rdata.setdefault("radiators", []).append(
                    {
                        "code": kind,
                        "label": kind,
                        "power": round(q_watts),
                        "length_mm": round(length_mm),
                        "pipe_heat": True,
                    }
                )

    token.check()

    # 5. Extract results
    result = _extract_results(
        project,
        calc_pn,
        graph,
        arrays,
        cm,
        radiator_k_map,
        rooms_out,
        comp_temps,
        balancing_k_map=balancing_k_map,
        radiator_preset_map=radiator_preset_map,
        comp_t_supply=comp_t_supply,
        comp_hx_map=comp_hx_map,
    )
    result["rooms"] = rooms_out
    return result


# ---------------------------------------------------------------------------
# Self-register with the global calc runner
# ---------------------------------------------------------------------------

calc_runner.set_compute(compute_pipenet)
