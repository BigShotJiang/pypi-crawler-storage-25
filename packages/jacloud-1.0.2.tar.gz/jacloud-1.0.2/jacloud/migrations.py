"""Project schema migrations.

Migrations are numbered functions (migrate_v1, migrate_v2, ...) discovered
automatically via globals(). Each runs exactly once based on the project's
version field ``v``.  Existing projects without a version start at v=0
and run through all migrations (they are idempotent).

Add new migrations by defining ``migrate_vN`` where N = DBVER + 1.
"""

import base64
import datetime
import hashlib
from sys import stderr
from typing import Any

import msgspec


class MigrationCtx(msgspec.Struct):
    """Context passed to each migration function."""

    project_id: str | None = None


def _generate_pipe_id(project_id: str | None, name: str, index: int) -> str:
    """Generate a deterministic 8-char ID for a pipe based on project_id, name and index."""
    data = f"pipe1s:{project_id or ''}:{index}:{name}".encode()
    return base64.urlsafe_b64encode(hashlib.sha256(data).digest()[:6]).decode()


# ---------------------------------------------------------------------------
# Numbered migration functions - looked up automatically by prefix.
# Each receives (rb, ctx) and mutates rb in place.
# ---------------------------------------------------------------------------


def migrate_v1(rb: dict, ctx: MigrationCtx) -> None:
    """Rename t_inlet to t_supply, normalize valve names, remove legacy fields."""
    if "t_inlet" in rb:
        rb["t_supply"] = rb.pop("t_inlet")
    rb.pop("modified", None)
    rb.pop("id", None)
    rb.pop("v", None)
    rb.pop("pipenet", None)

    # Normalize valve names: old name → current canonical name.
    _VALVE_RENAME: dict[str, str] = {
        "oras": "Stabila10",
        "stabila10/15": "Stabila10",
        "ra-n20/25": "RA-N20",
    }

    def _norm_valve(name: str) -> str:
        return _VALVE_RENAME.get(name.lower(), name)

    if "valve" in rb:
        rb["valve"] = _norm_valve(rb["valve"])

    # Scale legacy ventilation setting to the new reduced percent scale.
    try:
        vent = int(rb["ventilation"], 10) / 5
        rb["ventilation"] = f"{vent:.0f}"
    except KeyError, TypeError, ValueError:
        pass

    # Convert created from unix timestamp int to ISO 8601 string ending with Z.
    created = rb.get("created")
    if isinstance(created, int):
        dt = datetime.datetime.fromtimestamp(created, tz=datetime.UTC)
        rb["created"] = msgspec.json.encode(dt).decode().strip('"')

    # Remove all legacy rooms (cannot convert old room.code format to new system).
    rb.pop("rooms", None)


# ---------------------------------------------------------------------------
# Auto-discovery of migrate_vN functions, sorted by N.
# ---------------------------------------------------------------------------

_migrations = sorted(
    [f for n, f in globals().items() if n.startswith("migrate_v")],
    key=lambda f: int(f.__name__.removeprefix("migrate_v")),
)

DBVER = len(_migrations)  # Current schema version (= number of migrations)


def apply_migrations(
    rb: dict[str, Any],
    ctx: MigrationCtx,
    *,
    silent: bool = False,
    version: int | None = None,
) -> tuple[bool, int, list[str]]:
    """Apply pending migrations to a project dict *rb* in place.

    The starting version is taken from *version* if given, otherwise
    from ``rb.get("v", 0)`` for backwards compatibility with pre-v13 data
    that still carries the version inline.

    Returns (migrated, new_version, descriptions).
    """
    current_version = version if version is not None else rb.get("v", 0)
    if current_version >= DBVER:
        return False, current_version, []

    descriptions: list[str] = []
    while current_version < DBVER:
        fn = _migrations[current_version]
        fn(rb, ctx)
        current_version += 1
        desc = (fn.__doc__ or fn.__name__).split("\n")[0].rstrip(".")
        descriptions.append(f"v{current_version}: {desc}")

    if not silent:
        name = rb.get("name") or ctx.project_id or "?"
        stderr.write(f"[{name}] {', '.join(descriptions)}\n")
    return True, current_version, descriptions
