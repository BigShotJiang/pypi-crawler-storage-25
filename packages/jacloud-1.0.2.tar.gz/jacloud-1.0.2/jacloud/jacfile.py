import datetime
import math
import re
import struct
from collections import OrderedDict, defaultdict
from contextlib import contextmanager, suppress
from pathlib import Path

from jacloud.jaclayout import (
    CollectedRadiator,
    _build_floors,
    _dedup_risers,
    _emit_chain,
    _layout_chains,
    _PipeChain,
    _PipeConvCtx,
    _SegmentTracker,
)
from jacloud.project import (
    HX,
    Floor,
    PipeNet,
    Project,
    RadCond,
    Radiator,
    RadiatorRoomRef,
    RadiatorValues,
    Room,
    RoomHeatSource,
    RoomOpening,
    RoomSurface,
    SurfaceType,
    get_insulation,
    strip_dn,
    with_insulation,
)
from jacloud.sci.room_calc import VENTILATION_FACTOR
from jacloud.util import create_id
from jacloud.util import format_ranges as _format_ranges
from jacloud.util import merge_names as _merge_names

HEADER_V1 = b"JAC File0\r\n\x1b\0\0\0\x01"

VALVES = [
    None,  # 0: no override
    "RA-N10",  # 1
    "Stabila10",  # 2
    "TRV-2",  # 3
    "RA-U",  # 4
    "TRV-2S",  # 5
    "Eclipse",  # 6
    "TRV-3",  # 7
    "RA-N15",  # 8
    "RA-N20",  # 9
]

VALVEBAL = [
    "Oras 4100",  # 0: Oras 4100
    "MSV-BD",  # 1: IMI Hydronic MSV-BD
    "Stad/Staf",  # 2: IMI Stad/Staf (default)
]

# ---------------------------------------------------------------------------
# Pipe type → balancing valve DN mapping
# ---------------------------------------------------------------------------
# Steel pipes use DN directly.  Copper and plastic pipe names use outer
# diameter (mm) which must be mapped to the nearest standard valve DN.
# fmt: off
_PIPE_TYPE_DN: dict[str, str] = {
    # Steel — already DN
    "DN 10": "10",  "DN 15": "15",  "DN 20": "20",  "DN 25": "25",
    "DN 32": "32",  "DN 40": "40",  "DN 50": "50",  "DN 57": "50",
    "DN 64": "65",  "DN 65": "65",  "DN 80": "80",  "DN 88": "80",
    "DN 100": "100", "DN 125": "125", "DN 150": "150",
    # Copper — outer diameter → DN
    "Cu 10": "10",  "Cu 12": "10",  "Cu 15": "15",  "Cu 18": "15",
    "Cu 22": "20",  "Cu 28": "25",  "Cu 35": "32",  "Cu 42": "40",
    "Cu 54": "50",  "Cu 63": "65",  "Cu 76": "65",
    # PEX (Uponor plain) — outer diameter → DN
    "Upo 12": "10", "Upo 15": "10", "Upo 17": "15", "Upo 18": "15",
    "Upo 20": "20", "Upo 22": "20", "Upo 25": "20", "Upo 32": "25",
    "Upo 40": "32", "Upo 50": "40", "Upo 63": "50", "Upo 75": "65",
    "Upo 90": "80", "Upo 110": "100",
    # Uponor composite — outer diameter → DN
    "Upo K 16x2": "10",     "Upo K 20x2.25": "15",
    "Upo K 25x2.5": "20",   "Upo K 32x3": "25",
    "Upo K 40x4": "32",     "Upo K 50x4.5": "40",
    "Upo K 63x6": "50",     "Upo K 75x7.5": "65",
    "Upo K 90x8.5": "80",   "Upo K 110x10": "100",
}
# fmt: on


def _pipe_type_to_valve_dn(pipe_type: str) -> str:
    """Map a pipe type string (e.g. ``"Cu 22"``) to a valve DN label.

    Strips insulation suffixes before lookup.  Falls back to extracting
    the first number from the pipe type name if not in the table.
    """
    bare = strip_dn(pipe_type)
    dn = _PIPE_TYPE_DN.get(bare)
    if dn:
        return dn
    # Fallback: extract leading integer from the type name
    m = re.search(r"\d+", bare)
    return m.group() if m else ""


class JacLoader:
    def __init__(self, d: bytes):
        self.refs: list[None | object] = [None]
        if not d.startswith(HEADER_V1):
            raise ValueError("Not a JAC file")
        self.d = bytearray(d[len(HEADER_V1) :])
        del d
        with self(">>>>"):
            with self("Head"), self("Lic1"):
                lic = self.text()
            with self("Proj"):
                proj = self.project()
                with self("rtps"):
                    rtps = [self.roomtype() for i in range(self.u())]
                with self("dtrt"):
                    dtrt = [self.radtype() for i in range(self.u())]
                with self("Boil"):  # Boiler and pipes
                    boil = self.boiler()
        del self.d
        self.jac = {
            "License": lic,
            "Project": proj,
            "RoomTypes": rtps,
            "RecRadTypes": dtrt,
            "Pipes": boil,
        }

    def boiler(self):
        with self("v001"):
            boil = {
                "name": self.text(),
                "dp": self.f(),
                "inletTemp": self.f(),
            }
        with self("v002"):
            boil["min_valve_dp"] = self.f()
        with self("tgts"):
            tgts = [self.pipeobj() for i in range(self.u())]
        return {"Boil": boil, "T": tgts}

    def pipeobj(self):
        with self("Pipe", "LVal", "Radr") as typ:
            ret = {}
            if typ == "Pipe":
                with self("v001", "v002") as fmt:
                    ret["Pipe"] = {
                        "name": self.text(),
                        "length": self.f(),
                        "type": self.u() if fmt == "v001" else self.text(),
                        "direction": self.u(),
                        "insulation": self.c(),
                        "envTemp": self.f(),
                    }
            elif typ == "LVal":
                ret["LVal"] = {"name": "Balancing valve"}
                with suppress(KeyError), self("v001"):
                    ret["LVal"]["name"] = self.text()
            elif typ == "Radr":
                with self("v001", "v002") as fmt:
                    ret["Radr"] = {
                        "name": self.text(),
                        "radt": self.refs[self.u()],
                        "fixedFlow": None if fmt == "v001" else self.f(),
                    }
                if ret["Radr"]["fixedFlow"] is None:
                    del ret["Radr"]["fixedFlow"]
                return ret
            with self("tgts"):
                ret["T"] = [self.pipeobj() for i in range(self.u())]
        return ret

    def insulation(self):
        return {
            k: v
            for k, v in {
                "wall": self.f(),
                "window": self.f(),
                "ceiling": self.f(),
                "floor": self.f(),
            }.items()
            if v is not None
        }

    def project(self):
        with self("v001"):
            ret = {
                "name": self.text(),
                "outdoorTemp": self.f(),
                "airTemp": self.f(),
                "roomTemp": self.f(),
                "insulation": self.insulation(),
                "wallHeight": self.f(),
                "ventilationCubicM": self.b(),
                "valveType": VALVES[self.u()],
                "roomNumber": self.u(),
                # Default values for old files
                "floorTemp": -20.0,
                "balancingType": 2,
                "extraResistance": 1.0,
            }
        with suppress(KeyError):
            with self("v002"):
                ret["floorTemp"] = self.f()
            with self("v003"):
                ret["balancingType"] = self.u()
            with self("v004"):
                ret["extraResistance"] = self.f()
        return ret

    def roomtype(self):
        with self("Room"):
            with self("v001", "v002") as fmt:
                room = {
                    "name": self.text(),
                    "lengthWall": self.f(),
                    "areaWindow": self.f(),
                    "areaCeiling": self.f(),
                    "areaFloor": self.f(),
                    "pipeLen": self.f(),
                    "pipeType": self.u() if fmt == "v001" else self.text(),
                    "ventilation": self.f(),
                    "freeP": self.f(),
                    "insulation": self.insulation(),
                }
                room["temps"] = {
                    k: v
                    for k, v in {
                        "wall": self.f(),
                        "window": self.f(),
                        "ceiling": self.f(),
                        "floor": self.f(),
                        "air": self.f(),
                        "room": self.f(),
                    }.items()
                    if v is not None
                }
                room["wallHeight"] = self.f()
                if room["wallHeight"] is None:
                    del room["wallHeight"]
                room["radiatorNumber"] = self.u()
            with self("RDTS"):
                room["rdts"] = [self.radtype(is_room=True) for i in range(self.u())]
        return room

    def radtype(self, *, is_room=False):
        with self("RadT"):
            with self("v001"):
                ret: dict = {
                    "name": self.text(),
                    "useCode": self.b(),
                    "code": self.text(),
                    "nominalP": self.f(),
                    "dT": self.f(),
                    "rec": None,
                }
            with suppress(KeyError), self("v002"):
                ret["rec"] = self.f()
            with self("Valv"), self("v001"):
                v = VALVES[self.u()]
                if v:
                    ret["valveType"] = v
        if ret["useCode"]:
            del ret["nominalP"], ret["dT"], ret["useCode"]
            # Fix wrong radiator codes prior to Jaconi 2.4
            ret["code"] = (
                ret["code"]
                .replace("-210-pk22", "-210-pk24")
                .replace("-210-pk34", "-210-pk36")
            )
        else:
            del ret["code"], ret["useCode"]
        if is_room:
            del ret["rec"]
        self.refs.append(ret)
        return ret

    @contextmanager
    def __call__(self, *names):
        d = self.d[:]  # A backup copy to rollback on exception
        try:
            name, size = self.take(4).decode(), self.u()
            if names and name not in names:
                raise KeyError(f"JAC file error, expected {names} but found {name}")
            data = self.take(size)
            rest, self.d = self.d, data
        except:
            self.d = d
            raise
        try:
            yield name
        finally:
            self.d = rest

    def take(self, n):
        if len(self.d) < n:
            raise ValueError("JAC file unexpected end")
        ret = self.d[:n]
        del self.d[:n]
        return ret

    def b(self):
        return bool(self.c())

    def c(self):
        return self.take(1)[0]

    def u(self):
        return int.from_bytes(self.take(4), "big")

    def f(self):
        val = struct.unpack(">d", self.take(8))[0]
        return None if math.isnan(val) else val

    def text(self):
        size = self.u()
        text = self.take(size)
        try:
            return text.decode()
        except UnicodeDecodeError:
            return text.decode("CP1252")


def load(filename):
    return JacLoader(Path(filename).read_bytes()).jac


# ---------------------------------------------------------------------------
# Room-type merging and floor-section helpers
# ---------------------------------------------------------------------------

_MERGE_SUFFIX_RE = re.compile(r"^(.+\d)\s*[a-zA-Z]$")


def _merge_key(name: str) -> str:
    """Compute merge key by stripping a trailing single-letter suffix.

    ``"Huoneistotyyppi 12a"`` → ``"Huoneistotyyppi 12"``.  Names that do
    not end with ``<digit><letter>`` are returned unchanged.
    """
    m = _MERGE_SUFFIX_RE.match(name.strip())
    return m.group(1).strip() if m else name.strip()


def _merge_names(names: list[str]) -> str:  # noqa: F811 — shadows util import for backwards compat
    """Merge a list of room-type names by collapsing differing parts.

    Finds the longest common prefix and suffix across all *names*, then
    formats the differing middle parts as ranges when possible.

    Examples::

        ["Room 12 fl. 3 bedroom", "Room 12 fl. 4 bedroom",
         "Room 12 fl. 5 bedroom"]
        → "Room 12 fl. 3\u20135 bedroom"

        ["Type 1a", "Type 1b", "Type 1c"]
        → "Type 1a\u2013c"

        ["A", "B"]
        → "A, B"
    """
    if len(names) <= 1:
        return names[0] if names else ""

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for n in names:
        if n not in seen:
            seen.add(n)
            unique.append(n)
    if len(unique) == 1:
        return unique[0]

    # Find longest common prefix (character-level)
    min_len = min(len(n) for n in unique)
    prefix_len = 0
    for i in range(min_len):
        if all(n[i] == unique[0][i] for n in unique):
            prefix_len = i + 1
        else:
            break

    # Find longest common suffix (character-level), not overlapping prefix
    suffix_len = 0
    for i in range(1, min_len - prefix_len + 1):
        if all(n[-i] == unique[0][-i] for n in unique):
            suffix_len = i
        else:
            break

    prefix = unique[0][:prefix_len]
    suffix = unique[0][-suffix_len:] if suffix_len else ""

    # Extract differing middle parts
    diffs = [
        n[prefix_len : len(n) - suffix_len if suffix_len else len(n)] for n in unique
    ]

    # Try to interpret diffs as integers → compact range
    try:
        int_vals = [int(d) for d in diffs]
        return prefix + _format_ranges(int_vals) + suffix
    except ValueError:
        pass

    # Try single lowercase letters → letter range
    if all(len(d) == 1 and d.isalpha() for d in diffs):
        letters = sorted(diffs)
        ords = [ord(c) for c in letters]
        if ords == list(range(ords[0], ords[-1] + 1)):
            return prefix + f"{letters[0]}\u2013{letters[-1]}" + suffix
        return prefix + ", ".join(letters) + suffix

    # Fallback: comma-separated
    return prefix + ", ".join(diffs) + suffix


def _surface_fingerprint(rt: dict) -> tuple:
    """Hashable key for room-type surface / heat-loss properties.

    Two room types with the same fingerprint have identical room code
    (ignoring radiators) and can safely be merged.
    """
    ptype = rt["pipeType"]
    if isinstance(ptype, int):
        ptype = str(ptype)
    return (
        round(rt["lengthWall"], 2),
        rt.get("wallHeight"),
        round(rt["areaWindow"], 2),
        round(rt["areaCeiling"], 2),
        round(rt["areaFloor"], 2),
        round(rt["pipeLen"], 2) if rt["pipeLen"] else 0,
        ptype,
        round(rt["freeP"], 0) if rt["freeP"] else 0,
        round(rt["ventilation"], 2) if rt["ventilation"] else 0,
        tuple(sorted(rt.get("insulation", {}).items())),
        tuple(sorted(rt.get("temps", {}).items())),
    )


def _radiator_fingerprint(rt: dict) -> tuple:
    """Hashable key for the set of radiator types in a room type."""
    return tuple(sorted(convrad(rad).split("#")[0].strip() for rad in rt["rdts"]))


def _group_room_types(room_types: list[dict]) -> list[tuple[str, list[dict]]]:
    """Group JAC room types that can be merged.

    Merging criteria: same merge-key, identical surface fingerprint, and
    identical radiator fingerprint.  Returns a list of
    ``(group_name, [room_types])`` tuples.
    """
    groups: OrderedDict[tuple, list[dict]] = OrderedDict()
    for rt in room_types:
        key = (
            _merge_key(rt["name"]),
            _surface_fingerprint(rt),
            _radiator_fingerprint(rt),
        )
        groups.setdefault(key, []).append(rt)

    result: list[tuple[str, list[dict]]] = []
    for rts in groups.values():
        # Merge names from all variants in the group
        name = _merge_names([rt["name"] for rt in rts])
        result.append((name, rts))
    return result


def _build_room_data(
    rt: dict,
) -> tuple[list[RoomSurface], list[RoomHeatSource]]:
    """Build Room v2 surfaces and heat sources from a JAC room type.

    Dimensions are stored as int mm.  When only an area (m²) is known,
    it is encoded as ``x = round(area_m2 * 1000), y = 1000`` so that
    ``x * y / 1e6 == area_m2``.
    """
    surfaces: list[RoomSurface] = []
    heat: list[RoomHeatSource] = []

    def _area_to_x(area_m2: float) -> int:
        """Encode an area-only value as x dimension (mm), paired with y=1000."""
        return round(area_m2 * 1000)

    # Wall + window opening
    wall_x = round(rt["lengthWall"] * 1000)
    wall_y = round(rt["wallHeight"] * 1000) if "wallHeight" in rt else 0
    openings: list[RoomOpening] = []
    if rt["areaWindow"]:
        openings.append(
            RoomOpening(
                material="window", width=_area_to_x(rt["areaWindow"]), height=1000
            )
        )
    surfaces.append(RoomSurface(material="wall", x=wall_x, y=wall_y, openings=openings))

    # Ceiling / floor (area only)
    if rt["areaCeiling"]:
        surfaces.append(
            RoomSurface(material="ceiling", x=_area_to_x(rt["areaCeiling"]), y=1000)
        )
    if rt["areaFloor"]:
        surfaces.append(
            RoomSurface(material="floor", x=_area_to_x(rt["areaFloor"]), y=1000)
        )

    # Heat sources
    ptype = rt["pipeType"]
    if isinstance(ptype, int):
        ptype = str(ptype)
    if rt["pipeLen"]:
        heat.append(
            RoomHeatSource(
                riser=ptype.lower().replace(" ", ""), length=round(rt["pipeLen"] * 1000)
            )
        )
    if rt["freeP"]:
        heat.append(RoomHeatSource(power=round(rt["freeP"])))

    return surfaces, heat


def _milliturns_from_endpoint(dx: int, dy: int) -> int:
    """Convert radiator endpoint offset to milliturns angle."""
    if dx == 0 and dy == 0:
        return 0
    return round((math.atan2(dy, dx) / (2 * math.pi)) * 1000) % 1000


def _distribute_millis(weights: list[float]) -> list[int]:
    """Distribute 1000 millis proportionally to *weights*.

    Returns a list of int millis summing to exactly 1000.
    """
    total = sum(weights)
    if total <= 0 or not weights:
        return [1000 // len(weights) if weights else 0] * len(weights)
    raw = [w / total * 1000 for w in weights]
    result = [int(r) for r in raw]
    remainder = 1000 - sum(result)
    # distribute remainder to largest fractional parts
    fracs = [(raw[i] - result[i], i) for i in range(len(weights))]
    fracs.sort(reverse=True)
    for j in range(remainder):
        result[fracs[j][1]] += 1
    return result


def _create_plan_radiators(
    project: Project,
    collected_radiators: list[CollectedRadiator],
    radt_room_map: dict[int, tuple[str, str]],
    radt_weight: dict[int, float],
) -> None:
    """Create Radiator objects from collected radiators and link to rooms.

    Each CollectedRadiator becomes one Radiator with a single floor
    entry.  Room binding is set via ``Radiator.room`` with millis
    shares computed from the original radtype nominal powers.
    """
    # Compute millis per room.
    # Group radt weights by room_id; each radt in the room gets a share.
    room_radt_ids: dict[str, list[int]] = defaultdict(list)
    for radt_id, (room_id, _room_code) in radt_room_map.items():
        room_radt_ids[room_id].append(radt_id)

    # Compute millis per radt object id
    radt_millis: dict[int, int] = {}
    for radt_ids in room_radt_ids.values():
        weights = [radt_weight.get(rid, 1.0) for rid in radt_ids]
        millis_list = _distribute_millis(weights)
        radt_millis.update(zip(radt_ids, millis_list, strict=True))

    # Build plan → floor mapping for floor resolution
    floor_plan_map: dict[str, str] = {}
    for f in project.floors:
        if f.plan:
            floor_plan_map[f.id] = f.plan

    for crad in collected_radiators:
        rad_id = create_id()
        code = (crad.code or "").split()[0]
        if not code:
            continue

        angle = _milliturns_from_endpoint(*crad.endpoint)
        plan_id = floor_plan_map.get(crad.floor_id, "")

        # Determine millis from the radt that this radiator came from.
        # The radt_room_map keys are Python object ids; we need to find
        # which radt this collected radiator came from.  Since multiple
        # collected radiators can come from the same radt, we look up by
        # room_id + base radiator code match.
        millis = 1000
        room_ref: RadiatorRoomRef | None = None
        if crad.room_id:
            for radt_id, (room_id, room_code) in radt_room_map.items():
                if room_id == crad.room_id and room_code and code == room_code:
                    millis = radt_millis.get(radt_id, 1000)
                    break
            room_ref = RadiatorRoomRef(id=crad.room_id, millis=millis)

        floor_entry = RadiatorValues(code=code)
        project.radiators[rad_id] = Radiator(
            code=code,
            x1=crad.x,
            y1=crad.y,
            angle=angle,
            plan=plan_id,
            name=crad.name,
            floors={crad.floor_id: floor_entry},
            room=room_ref,
        )


def _iter_jac_nodes(nodes: list[dict]):
    """Yield all nodes recursively from a JAC pipe subtree."""
    for node in nodes:
        yield node
        children = node.get("T", [])
        if children:
            yield from _iter_jac_nodes(children)


def _compute_radcond(
    jac: dict,
) -> RadCond | None:
    """Compute roomless radiator conditions from JAC RecRadTypes.

    Legacy condition-room radiators use the classic 70/return/20 regime,
    where ``return = 70 - rec * 50``.  When multiple ``rec`` values are
    present, use a radiator-count-weighted average of ``rec``.  Counts are
    derived from actual radiator occurrences in the pipe tree; when no
    occurrences are found, fall back to one count per RecRadType entry.
    """
    rec_counts: dict[float, int] = defaultdict(int)

    boil = jac.get("Pipes", {}).get("Boil", {})
    top_nodes = boil.get("T", []) if isinstance(boil, dict) else []
    if isinstance(top_nodes, list):
        for node in _iter_jac_nodes(top_nodes):
            radr = node.get("Radr")
            if not isinstance(radr, dict):
                continue
            radt = radr.get("radt")
            if not isinstance(radt, dict):
                continue
            rec = radt.get("rec")
            if rec is None:
                continue
            with suppress(TypeError, ValueError):
                rec_counts[float(rec)] += 1

    if not rec_counts:
        for radt in jac.get("RecRadTypes", []):
            if not isinstance(radt, dict):
                continue
            rec = radt.get("rec")
            if rec is None:
                continue
            with suppress(TypeError, ValueError):
                rec_counts[float(rec)] += 1

    total = sum(rec_counts.values())
    if total <= 0:
        return None

    rec_avg = sum(rec * count for rec, count in rec_counts.items()) / total
    t_supply = 70.0
    t_room = 20.0
    t_return = t_supply - rec_avg * 50.0
    return RadCond(supply=t_supply, return_=t_return, env=t_room)


def convert(
    jac,
    filename,
    *,
    created: datetime.datetime | None = None,
):
    now = created or datetime.datetime.now(tz=datetime.UTC)

    # Helper functions for formatting values as strings
    def fmt_temp(v: float | None) -> str:
        """Format temperature as string with 0 decimals."""
        return f"{v:.0f}" if v is not None else "0"

    def fmt_u(v: float | None) -> str:
        """Format U-value as string with 2 decimals."""
        return f"{v:.2f}" if v is not None else "0.00"

    def fmt_height(v: float | None) -> str:
        """Format height as string with 1 decimal."""
        return f"{v:.1f}" if v is not None else "0.0"

    jacins = jac["Project"]["insulation"]
    boil = jac["Pipes"]["Boil"]
    project = Project(
        created=now,
        name=jac["Project"]["name"],
        notes=f"Converted from {filename}",
        t_supply=fmt_temp(boil["inletTemp"]),
        t_outdoor=fmt_temp(jac["Project"]["outdoorTemp"]),
        t_env=fmt_temp(jac["Project"]["roomTemp"]),
        ventilation="0",
        valve=jac["Project"]["valveType"],
        valve1p="TA-UNI",
        valvebal=VALVEBAL[jac["Project"]["balancingType"]],
        thermostat=True,
        surfaces={
            "wall": SurfaceType(
                u=fmt_u(jacins["wall"]),
                default_y=fmt_height(jac["Project"]["wallHeight"]),
            ),
            "window": SurfaceType(u=fmt_u(jacins["window"])),
            "door": SurfaceType(u=fmt_u(jacins["window"]), default_y="2.1"),
            "floor": SurfaceType(
                u=fmt_u(jacins["floor"]), t=fmt_temp(jac["Project"]["floorTemp"])
            ),
            "ceiling": SurfaceType(u=fmt_u(jacins["ceiling"])),
        },
        rooms={},
        pipe1s={},
        pipenet=PipeNet({}, {}, {}),
        dp_rad=f"{boil['dp'] / 1000:.1f}",  # JAC stores Pa, we store kPa
    )
    ventilation = 0.0
    ventscale = 0.0
    for r in jac["RoomTypes"]:
        ventilation += r["ventilation"] / (
            3.6 if jac["Project"]["ventilationCubicM"] else 1.0
        )
        ventscale += (
            r["lengthWall"] * jac["Project"]["wallHeight"] - r["areaWindow"]
        ) * r["insulation"].get("wall", jacins["wall"])
        ventscale += r["areaWindow"] * r["insulation"].get("window", jacins["window"])
        ventscale += r["areaCeiling"] * r["insulation"].get(
            "ceiling", jacins["ceiling"]
        )
        ventscale += r["areaFloor"] * r["insulation"].get("floor", jacins["floor"])
    if ventilation and ventscale:
        project.ventilation = f"{ventilation / (VENTILATION_FACTOR * ventscale):.0f}"

    # JAC condition-radiator regime (70/return/20 from RecRadTypes).
    # This is used only for roomless radiators in calc, not as a
    # replacement for normal project-global temperatures.
    project.radcond = _compute_radcond(jac)

    # Build radt -> (room_id, base_code) map for linking pipe radiators
    # directly to structured room radiator entries. Keyed by Python object *id* of the
    # radtype dict (the same objects are referenced by pipe ``Radr``
    # nodes via the ``radt`` field).
    radt_room_map: dict[int, tuple[str, str]] = {}

    # Collect nominal power weights per radt object for millis computation.
    # Code-based rads: try radiator database lookup for conductance h.
    # Power-based rads: use the normalised nominal power as weight.
    radt_weight: dict[int, float] = {}

    def _radt_nominal_weight(radt: dict) -> float:
        """Estimate relative heating output for millis computation."""
        if "code" in radt:
            try:
                from jacloud.sci.radiator import radiator_find

                cond = radiator_find(radt["code"].lower())
                if cond:
                    return cond[0]  # h coefficient ≈ proportional to power
            except Exception:  # noqa: S110
                pass
            return 1.0  # fallback
        # Power-based: normalise to ΔT=50K
        return radt["nominalP"] * (50.0 / radt["dT"]) ** 1.3

    # --- RoomType rooms (merged where possible) ---

    for group_name, group_rts in _group_room_types(jac["RoomTypes"]):
        rid = create_id()
        representative = group_rts[0]
        surfaces, heat = _build_room_data(representative)
        project.rooms[rid] = Room(name=group_name, surfaces=surfaces, heat=heat)

        for rt in group_rts:
            for rad in rt["rdts"]:
                raw_code = rad.get("code")
                if raw_code:
                    base_code = str(raw_code).split()[0].lower()
                else:
                    power = rad["nominalP"] * (50.0 / rad["dT"]) ** 1.3
                    base_code = f"{power:.0f}w"
                radt_room_map[id(rad)] = (rid, base_code)
                radt_weight[id(rad)] = _radt_nominal_weight(rad)

    # RecRadType (conditions-based) radiators are NOT given rooms.
    # They use project-global conditions for sizing instead of room geometry.

    project.pipenet, extra_floors, collected_radiators = convpipes(jac, radt_room_map)
    project.floors.extend(extra_floors)

    # --- Create PlanRadiators from collected radiators and link to rooms ---
    _create_plan_radiators(project, collected_radiators, radt_room_map, radt_weight)

    return project


def convrad(rad, coord: str = ""):
    """Format a radiator as a room-code line.

    *coord* is an optional ``[x1:x2/y1:y2]`` coordinate string that is
    appended as the final token on the line.
    """
    if "code" in rad:
        ret = f"{rad['code']}"
    else:
        power = rad["nominalP"] * (50.0 / rad["dT"]) ** 1.3
        ret = f"{power:.0f}W"
    if "valveType" in rad:
        valve = rad["valveType"].lower()
        ret += f" {valve}"
    if coord:
        ret += f" {coord}"
    if "code" not in rad or rad["name"] != rad["code"]:
        ret += f"  # {rad['name']}"
    ret += "\n"
    return ret


def _compute_subtree_weight(node: dict) -> float:
    """Compute total pipe length in a subtree (metres).

    Used to identify "major" branches that should get priority for cardinal
    directions. Includes all pipe segments, not just horizontal ones.
    """
    weight = 0.0
    if "Pipe" in node:
        weight += node["Pipe"]["length"]
    elif "Radr" in node:
        return 0.0  # Radiators are leaves with no pipe length
    for child in node.get("T", []):
        weight += _compute_subtree_weight(child)
    return weight


# =====================================================================
# Phase 1 – build a logical tree of pipe chains from the JAC tree
# =====================================================================

_DIGITS_RE = re.compile(r"\d+")


def _names_compatible(a: str, b: str) -> bool:
    """Two segment names are compatible if they share the same text skeleton.

    All digit sequences are replaced by ``#``.  If the resulting strings
    are identical the names are considered compatible (they differ only in
    numbering, e.g. ``"Nousu, krs. 1"`` vs ``"Nousu, krs. 6"``).
    """
    return _DIGITS_RE.sub("#", a) == _DIGITS_RE.sub("#", b)


def _should_break_between(dn_a: str, name_a: str, dn_b: str, name_b: str) -> bool:
    """Return *True* when the transition from segment *a* to *b* should start a new pipe.

    Checks material family change, large DN jump, insulation + DN
    change, and name pattern incompatibility.

    DN-based rules (2 and 3) are suppressed when both names are present
    and compatible — a consistent name means the same physical pipeline
    even if DN changes dramatically (e.g. designer error).
    """
    # 1. Material change — always breaks regardless of name
    mat_a = _pipe_material(dn_a)
    mat_b = _pipe_material(dn_b)
    if mat_a and mat_b and mat_a != mat_b:
        return True

    names_ok = name_a and name_b and _names_compatible(name_a, name_b)

    # 2. Large DN jump (ratio > 1.6) — only when names differ or absent
    num_a = _parse_dn_numeric(dn_a)
    num_b = _parse_dn_numeric(dn_b)
    if (
        not names_ok
        and num_a
        and num_b
        and min(num_a, num_b) > 0
        and max(num_a, num_b) / min(num_a, num_b) > 1.6
    ):
        return True

    # 3. Insulation change combined with any DN size change — only when names differ
    if (
        not names_ok
        and get_insulation(dn_a) != get_insulation(dn_b)
        and num_a
        and num_b
        and num_a != num_b
    ):
        return True

    # 4. Name incompatibility (names differ by more than numbers)
    return bool(name_a and name_b and not names_ok)


def _build_pipe_chains(boiler_children: list[dict]) -> list[_PipeChain]:
    """Convert top-level JAC pipe tree children into :class:`_PipeChain` trees."""
    chains: list[_PipeChain] = []
    for child in boiler_children:
        c = _build_chain_node(child, "", "")
        if c is not None:
            chains.append(c)
    return chains


def _build_chain_node(
    node: dict, parent_dn: str, parent_name: str
) -> _PipeChain | None:
    """Recursively build a :class:`_PipeChain` starting from a JAC node."""
    if "Radr" in node:
        return _PipeChain(
            length_mm=0,
            is_vertical=False,
            vert_up=False,
            dn_events=[],
            names=[],
            valve_events=[],
            terminal_rad=node["Radr"],
            subtree_weight=0,
        )

    if "LVal" in node:
        return _build_chain_from_lval(node, parent_dn, parent_name)

    if "Pipe" not in node:
        return None

    pipe = node["Pipe"]
    length = pipe["length"]
    ptype = pipe["type"]
    if isinstance(ptype, int):
        ptype = str(ptype)
    dn = with_insulation(ptype, pipe["insulation"])
    name = pipe["name"]
    direction = pipe["direction"]
    is_vertical = direction in (2, 3)
    seg_mm = max(0, round(length * 1000))

    chain = _PipeChain(
        length_mm=seg_mm,
        is_vertical=is_vertical,
        vert_up=(direction == 2),
        dn_events=[(0, dn)],
        names=[name] if name else [],
        valve_events=[],
        terminal_rad=None,
        subtree_weight=_compute_subtree_weight(node),
    )

    _extend_chain(chain, node.get("T", []), dn, name, seg_mm)
    return chain


def _build_chain_from_lval(
    node: dict, parent_dn: str, parent_name: str
) -> _PipeChain | None:
    """Build chain(s) starting from an LVal (balancing valve) node."""
    valve_dn = _pipe_type_to_valve_dn(parent_dn) if parent_dn else ""
    valve_name = node["LVal"].get("name", "Balancing valve")
    children = node.get("T", [])
    if not children:
        return None

    if len(children) == 1:
        chain = _build_chain_node(children[0], parent_dn, parent_name)
        if chain is not None:
            chain.valve_events.insert(0, (0, valve_dn, valve_name))
        return chain

    # Multiple children at valve: zero-length junction
    child_chains: list[_PipeChain] = []
    for child in children:
        c = _build_chain_node(child, parent_dn, parent_name)
        if c is not None:
            child_chains.append(c)
    if not child_chains:
        return None
    return _PipeChain(
        length_mm=0,
        is_vertical=False,
        vert_up=False,
        dn_events=[],
        names=[],
        valve_events=[(0, valve_dn, valve_name)],
        terminal_rad=None,
        subtree_weight=sum(c.subtree_weight for c in child_chains),
        branches=[(0, child_chains)],
    )


def _extend_chain(
    chain: _PipeChain,
    children: list[dict],
    current_dn: str,
    current_name: str,
    cumul_mm: int,
):
    """Process children of a JAC node, extending *chain* or adding branches."""
    if not children:
        return

    if len(children) == 1:
        _process_child(chain, children[0], current_dn, current_name, cumul_mm)
        return

    # Multiple children → junction
    continuation = _find_chain_continuation(children, chain.is_vertical)
    branch_chains: list[_PipeChain] = []
    for child in children:
        if child is continuation:
            continue
        c = _build_chain_node(child, current_dn, current_name)
        if c is not None:
            branch_chains.append(c)
    if branch_chains:
        chain.branches.append((cumul_mm, branch_chains))

    if continuation is not None:
        _process_child(chain, continuation, current_dn, current_name, cumul_mm)


def _process_child(  # noqa: PLR0911
    chain: _PipeChain,
    child: dict,
    current_dn: str,
    current_name: str,
    cumul_mm: int,
):
    """Extend *chain* with *child* or start a new branch."""
    if "Radr" in child:
        chain.terminal_rad = child["Radr"]
        return

    if "LVal" in child:
        valve_dn = _pipe_type_to_valve_dn(current_dn) if current_dn else ""
        valve_name = child["LVal"].get("name", "Balancing valve")
        chain.valve_events.append((cumul_mm, valve_dn, valve_name))
        _extend_chain(chain, child.get("T", []), current_dn, current_name, cumul_mm)
        return

    if "Pipe" not in child:
        return

    pipe = child["Pipe"]
    child_ptype = pipe["type"]
    if isinstance(child_ptype, int):
        child_ptype = str(child_ptype)
    child_dn = with_insulation(child_ptype, pipe["insulation"])
    child_name = pipe["name"]
    child_direction = pipe["direction"]
    child_is_vertical = child_direction in (2, 3)
    child_mm = max(0, round(pipe["length"] * 1000))

    # --- Break conditions ---

    # H ↔ V change
    if chain.is_vertical != child_is_vertical:
        c = _build_chain_node(child, current_dn, current_name)
        if c is not None:
            chain.branches.append((cumul_mm, [c]))
        return

    # Vertical direction reversal
    if chain.is_vertical and chain.vert_up != (child_direction == 2):
        c = _build_chain_node(child, current_dn, current_name)
        if c is not None:
            chain.branches.append((cumul_mm, [c]))
        return

    # Pipe-property break (material, DN, insulation, name)
    if _should_break_between(current_dn, current_name, child_dn, child_name):
        c = _build_chain_node(child, current_dn, current_name)
        if c is not None:
            chain.branches.append((cumul_mm, [c]))
        return

    # --- Continue the chain ---

    if child_mm <= 0:
        # Zero-length segment: absorb DN / name, skip geometry
        if child_dn != current_dn:
            chain.dn_events.append((cumul_mm, child_dn))
        if child_name and (not chain.names or child_name != chain.names[-1]):
            chain.names.append(child_name)
        _extend_chain(chain, child.get("T", []), child_dn, child_name, cumul_mm)
        return

    new_cumul = cumul_mm + child_mm
    chain.length_mm = new_cumul
    if child_dn != current_dn:
        chain.dn_events.append((cumul_mm, child_dn))
    if child_name and (not chain.names or child_name != chain.names[-1]):
        chain.names.append(child_name)
    _extend_chain(chain, child.get("T", []), child_dn, child_name, new_cumul)


def _find_chain_continuation(children: list[dict], is_vertical: bool) -> dict | None:
    """Pick the child most likely to extend the current chain (heaviest subtree)."""
    candidates: list[dict] = []
    for child in children:
        if "Pipe" in child:
            child_vert = child["Pipe"]["direction"] in (2, 3)
            if child_vert == is_vertical:
                candidates.append(child)
        elif "LVal" in child:
            candidates.append(child)
    if not candidates:
        return None
    candidates.sort(key=lambda c: -_compute_subtree_weight(c))
    return candidates[0]


# ---------------------------------------------------------------------------
# Pipe-break detection: split accumulated pipes at major transitions
# ---------------------------------------------------------------------------


def _parse_dn_numeric(dn_str: str) -> float | None:
    """Extract the standardised numeric DN value from a pipe type string.

    Uses :data:`_PIPE_TYPE_DN` to convert pipe types (e.g. ``"Cu 22"``)
    to their nominal DN in mm.  Falls back to extracting the first
    integer from the bare (insulation-stripped) pipe type name.
    """
    bare = strip_dn(dn_str)
    dn_label = _PIPE_TYPE_DN.get(bare)
    if dn_label:
        try:
            return float(dn_label)
        except ValueError:
            pass
    m = re.search(r"\d+", bare)
    return float(m.group()) if m else None


def _pipe_material(dn_str: str) -> str:
    """Extract the material / family prefix from a pipe type string.

    Returns the text prefix before the first digit, e.g. ``"DN"``,
    ``"Cu"``, ``"Upo"``, ``"Upo K"``.
    """
    bare = strip_dn(dn_str)
    m = re.match(r"([A-Za-z][A-Za-z ]*)", bare)
    return m.group().strip() if m else ""


def convpipes(
    jac, radt_room_map: dict[int, tuple[str, str]] | None = None
) -> tuple[PipeNet, list[Floor], list[CollectedRadiator]]:
    """Convert JAC pipe tree into a flat PipeNet graph.

    Three-phase conversion:

    1. **Chain building** – walk the JAC tree to produce a tree of
       :class:`_PipeChain` objects.  Pipe-break rules (name, DN,
       material, insulation) determine where to split.

    2. **Layout** – assign an orientation (one of 8 compass directions)
       to every horizontal chain using brute-force search with a
       per-floor collision grid.

    3. **Emit** – create :class:`PipeNode`, :class:`Pipe`,
       :class:`Riser` and :class:`BalancingValve` objects in the
       returned :class:`PipeNet`.  Radiator info is collected into
       :class:`CollectedRadiator` objects.

    Returns ``(PipeNet, list[Floor], list[CollectedRadiator])``.
    """
    wall_height = jac["Project"]["wallHeight"] or 3.0
    floor_height_mm = int(wall_height * 1000)

    net = PipeNet(nodes={}, pipes={}, valves={}, hxs={})
    ctx = _PipeConvCtx(
        net=net, floor_height_mm=floor_height_mm, radt_room_map=radt_room_map or {}
    )

    # Boiler node at origin, height 2100 mm (still needed for pipe connection)
    boiler_nid = ctx.add_node(0.0, 0.0, 2.1)
    hx_id = create_id()
    boiler_name = jac["Pipes"]["Boil"].get("name", "") or "HX"
    # HX stores its own coordinates; pipes within 1000x1000 are implicitly connected
    net.hxs[hx_id] = HX(
        x=0, y=0, floor=ctx.floor_id_for_node(boiler_nid), name=boiler_name
    )

    # Phase 1 — build chain tree
    chains = _build_pipe_chains(jac["Pipes"]["T"])
    if not chains:
        return net, _build_floors(ctx), ctx.collected_radiators

    # Phase 2 — assign directions via collision grid
    boiler_floor_idx = 2100 // floor_height_mm if floor_height_mm else 0
    tracker = _SegmentTracker()
    _layout_chains(chains, 0.0, 0.0, boiler_floor_idx, floor_height_mm, tracker, (0, 0))

    # Phase 3 — emit PipeNet geometry (vertical chains become Risers)
    # Wrap all root chains in a zero-length junction to enable up/down pairing
    if chains:
        root_junction = _PipeChain(
            length_mm=0,
            is_vertical=False,
            vert_up=False,
            dn_events=[],
            names=[],
            valve_events=[],
            terminal_rad=None,
            subtree_weight=0,
            branches=[(0, chains)],
        )
        _emit_chain(ctx, root_junction, boiler_nid)

    # Phase 4 — deduplicate overlapping risers (offset + connector)
    _dedup_risers(ctx)

    return net, _build_floors(ctx), ctx.collected_radiators
