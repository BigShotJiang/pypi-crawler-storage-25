"""Pretty-printed sync change logging."""

import logging
import re
import sys
from typing import Any

import jsondiff

from .fastapi_logging import (
    _METHOD_WRITE,
    format_log_left,
    format_log_method_label,
    format_log_target,
    format_log_ws_id,
)

logger = logging.getLogger("jacloud.syncdiff")

_UNSAFE_CHARS = re.compile(
    r"[\x00-\x1f\x7f-\x9f"
    r"\u200e\u200f"
    r"\u202a-\u202e"
    r"\u2066-\u2069"
    r"]"
)

_RESET = "\033[0m"
_SEP = "\033[38;5;242m"
_PATH_PREFIX = "\033[38;5;242m"
_PATH_FINAL = "\033[38;5;250m"
_DELETE = "\033[1;31m"
_ADD = "\033[0;32m"
_ACTION = _METHOD_WRITE


def _format_value(value: Any, max_len: int = 60) -> str:
    if value is None:
        result = "null"
    elif isinstance(value, bool):
        result = "true" if value else "false"
    elif isinstance(value, int | float):
        result = str(value)
    elif isinstance(value, str):
        value = _UNSAFE_CHARS.sub("", value)
        result = value[: max_len - 3] + "..." if len(value) > max_len else value
    elif isinstance(value, dict):
        if not value:
            result = "{}"
        else:
            all_true = all(v is True for v in value.values())
            parts = []
            for key, item in value.items():
                if all_true:
                    parts.append(str(key))
                else:
                    parts.append(f"{key}: {_format_value(item, max_len=30)}")
            result = "{" + ", ".join(parts) + "}"
    elif isinstance(value, list):
        if not value:
            result = "[]"
        else:
            parts = [_format_value(item, max_len=30) for item in value]
            result = "[" + ", ".join(parts) + "]"
    else:
        result = str(value)
        if len(result) > max_len:
            result = result[: max_len - 3] + "..."
    return result


def _format_path(path: list[str]) -> str:
    if not path:
        return ""
    if len(path) == 1:
        return f"{_PATH_FINAL}{path[0]}{_RESET}"
    prefix = ".".join(path[:-1])
    final = path[-1]
    return f"{_PATH_PREFIX}{prefix}.{_RESET}{_PATH_FINAL}{final}{_RESET}"


def _get_nested(data: dict | None, path: list[str]) -> Any:
    if data is None:
        return None
    current = data
    for key in path:
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current


def _collect_changes(
    diff: dict,
    path: list[str],
    changes: list[tuple[str, list[str], Any]],
    previous: dict | None,
) -> None:
    if not isinstance(diff, dict):
        existed = _get_nested(previous, path) is not None
        changes.append(("update" if existed else "add", path, diff))
        return

    for key, value in diff.items():
        if key == "$delete":
            if isinstance(value, list):
                changes.extend(
                    ("delete", [*path, str(deleted_key)], None) for deleted_key in value
                )
            else:
                changes.append(("delete", [*path, str(value)], None))
        elif key == "$replace":
            old_collection = _get_nested(previous, path)
            old_keys = (
                set(old_collection.keys())
                if isinstance(old_collection, dict)
                else set()
            )
            new_keys = set(value.keys()) if isinstance(value, dict) else set()

            changes.extend(
                ("delete", [*path, str(deleted_key)], None)
                for deleted_key in old_keys - new_keys
            )

            if isinstance(value, dict):
                for replace_key, replace_value in value.items():
                    existed = replace_key in old_keys
                    changes.append(
                        (
                            "update" if existed else "add",
                            [*path, str(replace_key)],
                            replace_value,
                        )
                    )
            elif value or not old_keys:
                changes.append(
                    ("update" if old_collection is not None else "add", path, value)
                )
        elif isinstance(key, str) and key.startswith("$"):
            changes.append(("add", path, {key: value}))
        else:
            new_path = [*path, str(key)]
            existed = _get_nested(previous, new_path) is not None
            if existed:
                _collect_changes(value, new_path, changes, previous)
            else:
                changes.append(("add", new_path, value))


def _format_change_lines(change_type: str, path: list[str], value: Any) -> list[str]:
    formatted_path = path

    if change_type == "delete":
        if len(formatted_path) == 1:
            return [f"  {_DELETE}{formatted_path[0]} x{_RESET}"]
        prefix = ".".join(formatted_path[:-1])
        final = formatted_path[-1]
        return [f"  {_PATH_PREFIX}{prefix}.{_RESET}{_DELETE}{final} x{_RESET}"]

    if change_type == "add":
        if isinstance(value, dict) and value:
            lines = []
            if len(formatted_path) == 1:
                lines.append(f"  {_ADD}{formatted_path[0]}{_RESET} {_SEP}={_RESET}")
            else:
                prefix = ".".join(formatted_path[:-1])
                final = formatted_path[-1]
                lines.append(
                    f"  {_PATH_PREFIX}{prefix}.{_RESET}{_ADD}{final}{_RESET} {_SEP}={_RESET}"
                )
            formatted_items = []
            for key, item in value.items():
                formatted_items.append((str(key), _format_value(item, max_len=30)))
            max_key_len = max(len(key) for key, _ in formatted_items)
            field_width = max(max_key_len, 12)
            for key, item in formatted_items:
                padding = " " * (field_width - len(key))
                lines.append(f"    {key}{_SEP}:{_RESET}{padding} {item}")
            return lines

        value_str = _format_value(value)
        if len(formatted_path) == 1:
            return [f"  {_ADD}{formatted_path[0]}{_RESET} {_SEP}={_RESET} {value_str}"]
        prefix = ".".join(formatted_path[:-1])
        final = formatted_path[-1]
        return [
            f"  {_PATH_PREFIX}{prefix}.{_RESET}{_ADD}{final}{_RESET} {_SEP}={_RESET} {value_str}"
        ]

    value_str = _format_value(value)
    path_str = _format_path(path)
    return [f"  {path_str} {_SEP}={_RESET} {value_str}"]


def format_diff(previous: dict | None, current: dict | None) -> list[str]:
    diff = jsondiff.diff(previous or {}, current or {}, marshal=True)
    changes: list[tuple[str, list[str], Any]] = []
    _collect_changes(diff, [], changes, previous)
    if not changes:
        return []

    lines = []
    for change_type, path, value in changes:
        lines.extend(_format_change_lines(change_type, path, value))
    return lines


def log_sync_change(
    action: str,
    target: str,
    client_id: int,
    actor_label: str,
    previous: dict | None,
    current: dict | None,
) -> None:
    header = (
        f"{format_log_left(_UNSAFE_CHARS.sub('', actor_label))} "
        f"{format_log_ws_id(client_id)} "
        f"{format_log_method_label(action, color=_ACTION)} "
        f"{format_log_target(target)}"
    )
    diff_lines = format_diff(previous, current)

    if not diff_lines:
        logger.info(header)
        return

    if len(diff_lines) == 1:
        logger.info("%s%s", header, diff_lines[0])
        return

    logger.info(header)
    for line in diff_lines:
        logger.info(line)


def configure_sync_logging() -> None:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
