from base64 import urlsafe_b64encode
from secrets import token_bytes
from time import time
from uuid import UUID

from user_agent_parser import Parser


def create_id() -> str:
    """Generate a compact 8-char ID suitable for URLs using base64url encoding.

    This matches the frontend implementation:
    createId = (): string => b64enc(crypto.getRandomValues(new Uint8Array(6)))
    """
    return urlsafe_b64encode(token_bytes(6)).decode("ascii").rstrip("=")


def uuid7() -> UUID:
    ts = int(time() * 1000).to_bytes(6, "big")
    rand = bytearray(token_bytes(10))
    rand[0] = (rand[0] & 0x0F) | 0x70
    rand[2] = (rand[2] & 0x3F) | 0x80
    return UUID(bytes=ts + rand)


def compact_user_agent(ua: str | None) -> str:
    if not ua:
        return "-"
    p = Parser(ua)
    ver = p.browser_version.split(".")[0] if p.browser_version else ""
    d = p.device_name
    dev = d if d and d not in ["Other", "Mac"] else ""
    return f"{p.browser}/{ver} {p.os} {dev}".strip()


def sanitize_filename(name: str) -> str:
    """Sanitize filename by removing dangerous Unix characters."""
    if not name:
        return ""
    # Replace dangerous characters with underscores
    name = (
        name.replace("/", "_")
        .replace("\\", "_")
        .replace(":", "_")
        .replace("*", "_")
        .replace("?", "_")
        .replace('"', "_")
        .replace("<", "_")
        .replace(">", "_")
        .replace("|", "_")
    )
    return name.strip()


def format_ranges(values: list[int]) -> str:
    """Format a sorted list of integers as compact ranges with en dashes.

    ``[3, 4, 5, 8, 9]`` → ``"3\u20135, 8\u20139"``
    """
    if not values:
        return ""
    values = sorted(set(values))
    ranges: list[str] = []
    start = prev = values[0]
    for v in values[1:]:
        if v == prev + 1:
            prev = v
        else:
            ranges.append(str(start) if start == prev else f"{start}\u2013{prev}")
            start = prev = v
    ranges.append(str(start) if start == prev else f"{start}\u2013{prev}")
    return ", ".join(ranges)


def merge_names(names: list[str]) -> str:
    """Merge a list of names by collapsing differing parts with en-dash ranges.

    Finds the longest common prefix and suffix across all *names*, then
    formats the differing middle parts as ranges when possible.

    Examples::

        ["Rise, floor 0", "Rise, floor 1", "Rise, floor 2"]
        → "Rise, floor 0\u20132"

        ["Type 1a", "Type 1b", "Type 1c"]
        → "Type 1a\u2013c"

        ["A", "B"]
        → "A, B"
    """
    if len(names) <= 1:
        return names[0] if names else ""

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for n in names:
        if n not in seen:
            seen.add(n)
            unique.append(n)
    if len(unique) == 1:
        return unique[0]

    # Find longest common prefix (character-level)
    min_len = min(len(n) for n in unique)
    prefix_len = 0
    for i in range(min_len):
        if all(n[i] == unique[0][i] for n in unique):
            prefix_len = i + 1
        else:
            break

    # Find longest common suffix (character-level), not overlapping prefix
    suffix_len = 0
    for i in range(1, min_len - prefix_len + 1):
        if all(n[-i] == unique[0][-i] for n in unique):
            suffix_len = i
        else:
            break

    prefix = unique[0][:prefix_len]
    suffix = unique[0][-suffix_len:] if suffix_len else ""

    # Extract differing middle parts
    diffs = [
        n[prefix_len : len(n) - suffix_len if suffix_len else len(n)] for n in unique
    ]

    # Try to interpret diffs as integers → compact range
    try:
        int_vals = [int(d) for d in diffs]
        return prefix + format_ranges(int_vals) + suffix
    except ValueError:
        pass

    # Try single lowercase letters → letter range
    if all(len(d) == 1 and d.isalpha() for d in diffs):
        letters = sorted(diffs)
        ords = [ord(c) for c in letters]
        if ords == list(range(ords[0], ords[-1] + 1)):
            return prefix + f"{letters[0]}\u2013{letters[-1]}" + suffix
        return prefix + ", ".join(letters) + suffix

    # Fallback: comma-separated
    return prefix + ", ".join(diffs) + suffix
