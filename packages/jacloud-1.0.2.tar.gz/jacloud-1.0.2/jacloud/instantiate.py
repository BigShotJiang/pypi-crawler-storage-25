"""Instantiate UI PipeNet into a calculation-time PipeNet.

Expands the floor-agnostic UI data model into a fully resolved 3D pipe
network suitable for the Hardy-Cross solver:

1. Node heights become absolute (h + floor.baseHeight * 1000).
2. Riser connections are materialized as regular Pipe objects.
3. Radiators are instantiated from room code with coordinate matching.

The result is an ephemeral PipeNet used only for the current calculation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import msgspec

from .project import HX, NODE_SPACING, Floor, Pipe, PipeEvent, Riser

if TYPE_CHECKING:
    from .project import Project

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Calc-time node (absolute world height)
# ---------------------------------------------------------------------------


class CalcPipeNode(msgspec.Struct):
    """Pipe node with absolute world-space height.

    Unlike :class:`~.project.PipeNode` where ``h`` is relative to the
    floor base, ``z`` here is the absolute height in millimetres above
    the project origin (z = node.h + floor.baseHeight * 1000).
    """

    x: int  # mm, horizontal position on floor plan
    y: int  # mm, horizontal position on floor plan
    z: int  # mm, absolute world height


# ---------------------------------------------------------------------------
# Calc-time radiator (instantiated from room code)
# ---------------------------------------------------------------------------


class CalcRadiator(msgspec.Struct):
    """Radiator instantiated from room code at calculation time."""

    node: str  # Pipe node key where radiator connects
    code: str  # Radiator type code (e.g. "1000-600-22")
    room_id: str  # Room key for result mapping
    floor_id: str  # Floor key for result mapping
    rad_index: int  # Index within room's radiator list


# ---------------------------------------------------------------------------
# Calc-time expanded pipe network
# ---------------------------------------------------------------------------


class CalcPipeNet(msgspec.Struct):
    """Calculation-time expanded pipe network with absolute heights.

    Produced by :func:`instantiate_pipenet`.  Nodes carry absolute ``z``
    values (world height), riser connections exist as regular pipes, and
    radiators are instantiated from room code.
    """

    nodes: dict[str, CalcPipeNode] = msgspec.field(default_factory=dict)
    pipes: dict[str, Pipe] = msgspec.field(default_factory=dict)
    valves: dict = msgspec.field(default_factory=dict)
    hxs: dict[str, HX] = msgspec.field(default_factory=dict)
    radiators: dict[str, CalcRadiator] = msgspec.field(default_factory=dict)
    node_floor_ids: dict[str, str] = msgspec.field(default_factory=dict)
    floor_base_heights: dict[str, int] = msgspec.field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _base_node_id(calc_node_id: str) -> str:
    """Strip floor qualifier from a cloned node ID."""
    if ":" in calc_node_id:
        return calc_node_id.rsplit(":", 1)[0]
    return calc_node_id


def _floor_base_h(floor: Floor) -> float:
    """Floor base height in mm."""
    return float(floor.baseHeight) * 1000.0


def _parse_floor_names(spec: str | None) -> list[str]:
    """Parse ``@floor`` value into literal floor-name tokens.

    Names are separated by whitespace.
    Hyphen has no range meaning (e.g. ``-1`` is a valid single name).
    """
    if not spec:
        return []
    return [tok for tok in spec.split() if tok]


# ---------------------------------------------------------------------------
# Main instantiation
# ---------------------------------------------------------------------------


def instantiate_pipenet(project: Project) -> CalcPipeNet:
    """Create a calc-time pipe network from the UI-oriented project data.

    The returned CalcPipeNet has:
    - CalcPipeNode ``z`` values as absolute world heights (node.h + floor.baseHeight * 1000)
    - Riser connections materialized as regular Pipe objects
    - Radiators instantiated from room code with coordinate matching
    """
    pipenet = project.pipenet
    floor_map: dict[str, Floor] = {f.id: f for f in project.floors}

    # 1. Build node → floors map from pipe.floors and hx.floor
    node_floors: dict[str, set[str]] = {}
    for pipe in pipenet.pipes.values():
        for nid in pipe.route():
            node_floors.setdefault(nid, set()).update(pipe.floors)
    # HXs now have their own x, y, floor - no node reference

    # 2. Build absolute-height nodes
    new_nodes: dict[str, CalcPipeNode] = {}
    # Track which original node ID maps to which calc node ID(s) per floor
    node_floor_map: dict[str, dict[str, str]] = {}  # orig_nid → {floor_id → calc_nid}
    # Track floor id for each calc node id (used by result export)
    calc_node_floor_ids: dict[str, str] = {}

    for nid, node in pipenet.nodes.items():
        floors_for_node = node_floors.get(nid, set())
        if len(floors_for_node) <= 1:
            fid = next(iter(floors_for_node), "")
            base_h = _floor_base_h(floor_map[fid]) if fid in floor_map else 0.0
            new_nodes[nid] = CalcPipeNode(x=node.x, y=node.y, z=int(node.h + base_h))
            if fid:
                node_floor_map.setdefault(nid, {})[fid] = nid
                calc_node_floor_ids[nid] = fid
        else:
            # Multi-floor: clone per floor
            for fid in floors_for_node:
                base_h = _floor_base_h(floor_map[fid]) if fid in floor_map else 0.0
                clone_id = f"{nid}:{fid}"
                new_nodes[clone_id] = CalcPipeNode(
                    x=node.x, y=node.y, z=int(node.h + base_h)
                )
                node_floor_map.setdefault(nid, {})[fid] = clone_id
                calc_node_floor_ids[clone_id] = fid

    # 3. Remap pipe timelines if nodes were cloned (multi-floor)
    new_pipes: dict[str, Pipe] = {}
    for pid, pipe in pipenet.pipes.items():
        # Determine the floor for node remapping (use first floor of pipe)
        pipe_floor = pipe.floors[0] if pipe.floors else ""
        needs_remap = False
        for nid in pipe.route():
            fm = node_floor_map.get(nid, {})
            if pipe_floor in fm and fm[pipe_floor] != nid:
                needs_remap = True
                break

        if not needs_remap:
            new_pipes[pid] = pipe
        else:
            # Remap node references in timeline
            new_timeline: dict[int, PipeEvent] = {}
            for tl_key, ev in pipe.timeline.items():
                if ev.node is not None:
                    fm = node_floor_map.get(ev.node, {})
                    remapped = fm.get(pipe_floor, ev.node)
                    new_timeline[tl_key] = PipeEvent(
                        node=remapped, kind=ev.kind, valve=ev.valve
                    )
                else:
                    new_timeline[tl_key] = ev
            new_pipes[pid] = Pipe(
                timeline=new_timeline, name=pipe.name, floors=pipe.floors
            )

    # 4. Materialize risers as pipe segments
    riser_pipes: dict[str, Pipe] = {}
    for rid, riser in pipenet.risers.items():
        # Expand riser floors to include intermediary floors not explicitly listed
        expanded_riser_floors = _fill_riser_intermediate_floors(riser, floor_map)

        riser_floor_objs = sorted(
            [floor_map[fid] for fid in expanded_riser_floors if fid in floor_map],
            key=lambda f: float(f.baseHeight),
        )
        if len(riser_floor_objs) < 2:
            continue

        for i in range(len(riser_floor_objs) - 1):
            lower = riser_floor_objs[i]
            upper = riser_floor_objs[i + 1]
            lower_nid = _find_or_create_riser_node(
                new_nodes, node_floor_map, calc_node_floor_ids, riser.x, riser.y, lower
            )
            upper_nid = _find_or_create_riser_node(
                new_nodes, node_floor_map, calc_node_floor_ids, riser.x, riser.y, upper
            )
            # DN for this segment: use lower floor's DN
            dn = expanded_riser_floors.get(lower.id, "")
            rpid = f"_riser:{rid}:{i}"
            riser_pipes[rpid] = Pipe(
                timeline={
                    0: PipeEvent(node=lower_nid, kind=dn),
                    NODE_SPACING: PipeEvent(node=upper_nid),
                },
                name=riser.name or f"Riser {rid}",
            )

    # 5. Instantiate radiators from room code
    calc_radiators = _instantiate_radiators(
        project,
        new_nodes,
        node_floors,
        floor_map,
        new_pipes,
    )

    return CalcPipeNet(
        nodes=new_nodes,
        pipes={**new_pipes, **riser_pipes},
        valves=dict(pipenet.valves),
        hxs=dict(pipenet.hxs),
        radiators=calc_radiators,
        node_floor_ids=calc_node_floor_ids,
        floor_base_heights={
            floor.id: int(_floor_base_h(floor)) for floor in project.floors
        },
    )


def _fill_riser_intermediate_floors(
    riser: Riser, floor_map: dict[str, Floor]
) -> dict[str, str]:
    """Expand riser.floors to include all intermediate floors.

    If a riser specifies dimensions for floors at baseHeights 1.0 and 5.0,
    but intermediate floors at 2.0, 3.0, 4.0 exist, this function adds
    those intermediate floors to the result using the dimension from the
    nearest lower floor.
    """
    if not riser.floors:
        return {}

    # Build list of (baseHeight, floor_id, dn) for riser's explicit floors
    riser_entries = []
    for floor_id, dn in riser.floors.items():
        if floor_id in floor_map:
            base_h = float(floor_map[floor_id].baseHeight)
            riser_entries.append((base_h, floor_id, dn))

    if len(riser_entries) < 2:
        return riser.floors

    riser_entries.sort(key=lambda x: x[0])

    # Get min and max baseHeight from riser's explicit floors
    min_base_h = riser_entries[0][0]
    max_base_h = riser_entries[-1][0]

    # All floors sorted by baseHeight
    all_floors = sorted(
        ((float(f.baseHeight), fid, f) for fid, f in floor_map.items()),
        key=lambda x: x[0],
    )

    result = dict(riser.floors)

    # For each floor between min and max, if not already in result,
    # add it with the dimension from the nearest lower riser floor
    for floor_base_h, floor_id, _floor_obj in all_floors:
        if not (min_base_h <= floor_base_h <= max_base_h):
            continue
        if floor_id in result:
            continue

        # Find the nearest lower riser floor
        lower_dn = ""
        for riser_base_h, _riser_fid, dn in riser_entries:
            if riser_base_h < floor_base_h:
                lower_dn = dn
            else:
                break

        if lower_dn:
            result[floor_id] = lower_dn

    return result


def _find_or_create_riser_node(
    nodes: dict[str, CalcPipeNode],
    node_floor_map: dict[str, dict[str, str]],
    calc_node_floor_ids: dict[str, str],
    x: int,
    y: int,
    floor: Floor,
    default_h: int = 2100,
) -> str:
    """Find an existing node at (x, y) on the given floor, or create one."""
    base_h = _floor_base_h(floor)

    # Look for existing nodes at matching (x, y) whose absolute height
    # falls within this floor's range
    floor_height = float(floor.height) * 1000.0
    for nid, node in nodes.items():
        if node.x == x and node.y == y:
            # Check if this node's z (absolute height) is within this floor
            z_above_floor_base = node.z - base_h
            if 0 <= z_above_floor_base <= floor_height:
                existing_floor = calc_node_floor_ids.get(nid)
                if existing_floor is not None and existing_floor != floor.id:
                    raise ValueError(
                        f"Riser node {nid} already mapped to floor {existing_floor},"
                        f" cannot remap to {floor.id}"
                    )
                calc_node_floor_ids[nid] = floor.id
                return nid

    # Create virtual node at default height above floor base
    vnid = f"_riser_node:{x},{y}:{floor.id}"
    nodes[vnid] = CalcPipeNode(x=x, y=y, z=int(base_h + default_h))
    calc_node_floor_ids[vnid] = floor.id
    return vnid


def _instantiate_radiators(
    project: Project,
    calc_nodes: dict[str, CalcPipeNode],
    node_floors: dict[str, set[str]],
    floor_map: dict[str, Floor],
    calc_pipes: dict[str, Pipe],
) -> dict[str, CalcRadiator]:
    """Instantiate radiators from room code, matching to pipe nodes.

    Uses ``radiator_coords`` from the room parser which carry per-instance
    coordinates and ``@floor`` section info.  Each coordinate entry is
    matched to the nearest pipe/riser node on the appropriate floor.
    """

    calc_radiators: dict[str, CalcRadiator] = {}

    # Build spatial index: floor_id → list of (x, y, node_id)
    # Keep all floor nodes first, then filter to suitable candidates
    # (open-end or riser nodes) to match frontend connector behavior.
    floor_node_index_all: dict[str, list[tuple[int, int, str]]] = {}
    for nid, node in calc_nodes.items():
        base_nid = _base_node_id(nid)
        floor_ids: set[str] = set()
        floor_ids.update(node_floors.get(base_nid, set()))
        # Riser virtual nodes encode floor id: _riser_node:x,y:{floor_id}
        if nid.startswith("_riser_node:"):
            parts = nid.rsplit(":", 1)
            if len(parts) == 2:
                floor_ids.add(parts[1])
        for fid in floor_ids:
            floor_node_index_all.setdefault(fid, []).append((node.x, node.y, nid))

    # Terminal (open-end) nodes per floor in calc pipes.
    endpoint_counts: dict[str, dict[str, int]] = {}
    interior_nodes: dict[str, set[str]] = {}
    for pipe in calc_pipes.values():
        if not pipe.floors:
            continue
        floor_id = pipe.floors[0]
        route = pipe.route()
        if len(route) < 2:
            continue

        first = route[0]
        last = route[-1]
        ec = endpoint_counts.setdefault(floor_id, {})
        ec[first] = ec.get(first, 0) + 1
        ec[last] = ec.get(last, 0) + 1

        if len(route) > 2:
            interior = interior_nodes.setdefault(floor_id, set())
            for nid in route[1:-1]:
                interior.add(nid)

    terminal_by_floor: dict[str, set[str]] = {}
    for floor_id, counts in endpoint_counts.items():
        interior = interior_nodes.get(floor_id, set())
        terminals = {
            nid for nid, count in counts.items() if count == 1 and nid not in interior
        }
        terminal_by_floor[floor_id] = terminals

    riser_by_floor: dict[str, set[str]] = {}
    for riser in project.pipenet.risers.values():
        expanded_riser_floors = _fill_riser_intermediate_floors(riser, floor_map)
        for floor_id in expanded_riser_floors:
            nearest_nid = _find_nearest_node_in_list(
                floor_node_index_all.get(floor_id, []),
                riser.x,
                riser.y,
            )
            if nearest_nid is not None:
                riser_by_floor.setdefault(floor_id, set()).add(nearest_nid)

    suitable_by_floor: dict[str, set[str]] = {}
    all_floors = set(floor_node_index_all.keys())
    for floor_id in all_floors:
        suitable = set()
        suitable.update(terminal_by_floor.get(floor_id, set()))
        suitable.update(riser_by_floor.get(floor_id, set()))
        suitable_by_floor[floor_id] = suitable

    floor_node_index: dict[str, list[tuple[int, int, str]]] = {}
    for floor_id, nodes_on_floor in floor_node_index_all.items():
        suitable = suitable_by_floor.get(floor_id, set())
        if not suitable:
            continue
        floor_node_index[floor_id] = [
            (nx, ny, nid) for nx, ny, nid in nodes_on_floor if nid in suitable
        ]

    # Build plan → floor_id mapping for Radiator floor resolution
    plan_floor_ids: dict[str, list[str]] = {}
    for f in project.floors:
        if f.plan:
            plan_floor_ids.setdefault(f.plan, []).append(f.id)

    # --- Path A: Radiator objects (project.radiators) ---
    for rad_id, rad in project.radiators.items():
        # Determine target floors
        if rad.floors is not None:
            # Only floors explicitly listed
            target_floor_ids = list(rad.floors.keys())
        elif rad.plan:
            # No explicit floors → all floors referencing this plan
            target_floor_ids = plan_floor_ids.get(rad.plan, [])
        else:
            # No plan, no floors — standalone radiator, skip
            target_floor_ids = []

        if not target_floor_ids:
            logger.warning(
                "Radiator %s: no target floors (plan=%r not in %s)",
                rad_id,
                rad.plan,
                list(plan_floor_ids.keys()),
            )
            continue

        rad_x = rad.x1
        rad_y = rad.y1

        for floor_id in target_floor_ids:
            # Resolve effective radiator code (per-floor override or default)
            floor_ov = rad.floors.get(floor_id) if rad.floors else None
            effective_code = (
                (floor_ov.code if floor_ov and floor_ov.code else rad.code)
                .split()[0]
                .lower()
            )

            node_id = _find_nearest_node(floor_node_index, floor_id, rad_x, rad_y)
            if node_id is None:
                n_suitable = len(floor_node_index.get(floor_id, []))
                logger.warning(
                    "Radiator %s on floor %s: no suitable pipe node "
                    "within 1000 mm of (%d, %d); %d suitable nodes on floor",
                    rad_id,
                    floor_id,
                    rad_x,
                    rad_y,
                    n_suitable,
                )
                continue

            calc_rad_key = f"rad:{rad_id}:{floor_id}"
            calc_radiators[calc_rad_key] = CalcRadiator(
                node=node_id,
                code=effective_code,
                room_id=rad.room.id if rad.room else "",
                floor_id=floor_id,
                rad_index=0,
            )

    return calc_radiators


def _find_nearest_node(
    floor_node_index: dict[str, list[tuple[int, int, str]]],
    floor_id: str,
    x: int,
    y: int,
) -> str | None:
    """Find the nearest pipe node on a floor using Euclidean distance.

    Matching rules are intentionally strict and deterministic:
    - same floor only
    - integer horizontal distance metric: ``dx*dx + dy*dy`` (squared Euclidean)
    - maximum allowed offset: 1000 mm
    """
    nodes_on_floor = floor_node_index.get(floor_id, [])
    if not nodes_on_floor:
        return None

    best_nid = None
    max_dist_sq = 1000 * 1000
    best_dist_sq = max_dist_sq + 1
    best_manhattan = 0
    for nx, ny, nid in nodes_on_floor:
        dx = nx - x
        dy = ny - y
        dist_sq = dx * dx + dy * dy
        if dist_sq > max_dist_sq:
            continue

        # Tie-breaker keeps result deterministic when Euclidean distance is equal.
        manhattan = abs(dx) + abs(dy)
        if dist_sq < best_dist_sq or (
            dist_sq == best_dist_sq and (best_nid is None or manhattan < best_manhattan)
        ):
            best_dist_sq = dist_sq
            best_manhattan = manhattan
            best_nid = nid

    return best_nid


def _find_nearest_node_in_list(
    nodes_on_floor: list[tuple[int, int, str]],
    x: int,
    y: int,
) -> str | None:
    """Find nearest node from a pre-filtered floor list using backend rules.

    Uses squared Euclidean distance with Manhattan tie-break and a hard
    1000 mm cutoff, matching _find_nearest_node semantics.
    """
    if not nodes_on_floor:
        return None

    tx = int(x)
    ty = int(y)
    best_nid = None
    max_dist_sq = 1000 * 1000
    best_dist_sq = max_dist_sq + 1
    best_manhattan = 0

    for nx, ny, nid in nodes_on_floor:
        dx = nx - tx
        dy = ny - ty
        dist_sq = dx * dx + dy * dy
        if dist_sq > max_dist_sq:
            continue

        manhattan = abs(dx) + abs(dy)
        if dist_sq < best_dist_sq or (
            dist_sq == best_dist_sq and (best_nid is None or manhattan < best_manhattan)
        ):
            best_dist_sq = dist_sq
            best_manhattan = manhattan
            best_nid = nid

    return best_nid
