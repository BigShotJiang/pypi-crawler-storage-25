"""
Schema introspection utilities.
Responsible for safely evaluating DRF serializers to extract request constraints.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Make the package framework-agnostic by treating DRF as strictly optional
try:
    from rest_framework import serializers
    DRF_AVAILABLE = True
except ImportError:
    DRF_AVAILABLE = False


def _map_field_type(field_instance: Any) -> str:
    """
    Maps DRF field classes to friendly documentation types where possible.
    """
    if not DRF_AVAILABLE:
        return "unknown"

    class_name = field_instance.__class__.__name__

    mapping = {
        'CharField': 'string',
        'EmailField': 'string (email)',
        'URLField': 'string (url)',
        'UUIDField': 'uuid',
        'SlugField': 'string (slug)',
        'IntegerField': 'integer',
        'FloatField': 'float',
        'DecimalField': 'decimal',
        'BooleanField': 'boolean',
        'DateTimeField': 'datetime',
        'DateField': 'date',
        'TimeField': 'time',
        'ChoiceField': 'string/integer (choice)',
        'MultipleChoiceField': 'array (choice)',
        'ListField': 'array',
        'DictField': 'object',
        'JSONField': 'json',
    }

    # Fallback to the raw class name if not in the friendly mapping
    return mapping.get(class_name, class_name)


def extract_serializer_fields(callback: Any) -> List[Dict[str, Any]]:
    """
    Introspects a Django view callback to find its attached DRF serializer,
    then systematically extracts detailed field-level constraints.

    Args:
        callback: The view callback mapped to a URL endpoint.

    Returns:
        List of dictionaries containing structural field metadata.
    """
    if not DRF_AVAILABLE:
        return []

    # Identify if the callback operates via a Standard Class-Based View
    view_class = getattr(callback, 'view_class', None)
    if not view_class:
        return []

    # Probe for the conventionally standard explicitly defined `serializer_class`
    serializer_class = getattr(view_class, 'serializer_class', None)

    # Sanity check evaluating dynamic bounds or edge-case overrides
    if not serializer_class or not isinstance(serializer_class, type):
        return []

    # Safeguard evaluating that it intrinsically operates as a DRF construct
    if not issubclass(serializer_class, serializers.Serializer):
        return []

    fields = []

    try:
        # Initialize the serializer statically without context to force layout evaluation
        serializer = serializer_class()

        for field_name, field_instance in serializer.get_fields().items():
            fields.append({
                'name': field_name,
                'type': _map_field_type(field_instance),
                'required': field_instance.required,
                'read_only': field_instance.read_only,
                # Gracefully cast help_text resolving translation proxies
                'help_text': str(field_instance.help_text) if field_instance.help_text else '',
            })

    except Exception as e:
        logger.warning(f"Failed to introspect evaluating serializer {serializer_class.__name__}: {e}")
        # Could fallback to BaseSerializer._declared_fields down the line if strict evaluation fails

    return fields
