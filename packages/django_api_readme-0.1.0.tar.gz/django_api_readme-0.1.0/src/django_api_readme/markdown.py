"""
Markdown generation utilities.
Converts normalized endpoint metadata into clean, readable Markdown strings.
"""
from typing import Any, Dict, List


def generate_endpoint_markdown(endpoint: Dict[str, Any]) -> str:
    """
    Generates structured Markdown documentation for a single API endpoint.
    """
    lines = []
    
    methods_str = ", ".join(endpoint.get('methods', ['UNKNOWN']))
    path_str = endpoint.get('path', '/')
    
    # Primary Header -> e.g., ### `GET, POST` /api/users/ 
    # Use H3 so it nests neatly inside a typical "## API Documentation" README block
    lines.append(f"### `{methods_str}` {path_str}")
    lines.append("")
    
    # Move docstring up immediately below the path so developers read the behavior first
    docstring = endpoint.get('docstring', '')
    if docstring:
        lines.append(f"{docstring}")
        lines.append("")
    
    # View Metadata succinctly grouped on a single secondary line to avoid unneeded vertical sprawl
    view_name = endpoint.get('view_name', 'UnknownView')
    route_name = endpoint.get('name', '')
    
    meta_line = f"- **View:** `{view_name}`"
    if route_name:
         meta_line += f" | **Name:** `{route_name}`"
         
    lines.append(meta_line)
    lines.append("")
    
    # Minimalist Request Schema Table (if parameters exist)
    request_fields = endpoint.get('request_fields', [])
    if request_fields:
        lines.append("**Request Schema**")
        lines.append("")
        
        # 4 Columns - Fold 'Read Only' seamlessly into the Description space to keep the table cleanly sized
        lines.append("| Field | Type | Required | Description |")
        lines.append("| --- | --- | --- | --- |")
        
        for field in request_fields:
            name_str = f"`{field.get('name', 'unknown')}`"
            type_str = f"`{field.get('type', 'unknown')}`"
            
            # Markdown bold highlights specifically what matters quickly
            req_str = "**Yes**" if field.get('required') else "No"
            
            help_text = field.get('help_text', '')
            # Clean up help_text so pipes don't accidentally shatter the table formatting
            help_text = help_text.replace('|', '&#124;').replace('\n', ' ') if help_text else ""
            
            desc_parts = []
            if field.get('read_only'):
                desc_parts.append("*(Read-only)*")
            if help_text:
                desc_parts.append(help_text)
                
            desc_str = " ".join(desc_parts) if desc_parts else "-"
            
            lines.append(f"| {name_str} | {type_str} | {req_str} | {desc_str} |")
            
        lines.append("") 
        
    return "\n".join(lines).strip()


def generate_markdown(endpoints: List[Dict[str, Any]]) -> str:
    """
    Iterates over a list of normalized endpoints and creates a unified Markdown string.
    """
    if not endpoints:
        return "*No API endpoints discovered.*"

    sections = []
    for ep in endpoints:
        sections.append(generate_endpoint_markdown(ep))
        
    # Join distinct endpoint blocks dynamically
    return "\n\n".join(sections)
