"""
URL introspection utilities.
Responsible for scanning Django urlpatterns and extracting endpoint metadata.
"""
from typing import Any, Dict, List, Optional, TypedDict
from django.urls import URLPattern, URLResolver, get_resolver
from django_api_readme.schema import extract_serializer_fields

class EndpointInfo(TypedDict):
    """Consistent dictionary format for extracted API endpoint metadata."""
    path: str
    name: str
    view_name: str
    module: str
    docstring: str
    methods: List[str]
    request_fields: List[Dict[str, Any]]
    callback: Any


def _clean_path(path: Any) -> str:
    """
    Cleans up Django URL pattern strings by removing regex anchors 
    (used in re_path) to provide clean readable endpoints.
    """
    path_str = str(path)
    if path_str.startswith('^'):
        path_str = path_str[1:]
    if path_str.endswith('$'):
        path_str = path_str[:-1]
    return path_str


def _extract_allowed_methods(callback: Any) -> List[str]:
    """
    Best-effort attempt to gracefully detect supported HTTP methods for a view.
    Refined to safely handle Django Class-Based Views, DRF ViewSets, and FBVs.
    """
    methods = set()
    standard_methods = ['get', 'post', 'put', 'patch', 'delete']

    # 1. Check for Class-Based Views (or DRF `@api_view` which wraps into a CBV)
    if hasattr(callback, 'view_class'):
        view_class = callback.view_class
        
        # If it's a bound ViewSet via a Router (e.g. ViewSet.as_view({'get': 'list'}))
        # The routing dictionary is passed to actions on the callback
        if hasattr(callback, 'actions') and isinstance(callback.actions, dict):
            for verb in callback.actions.keys():
                if isinstance(verb, str) and verb.lower() in standard_methods:
                    methods.add(verb.upper())
        else:
            # Standard CBV / APIView
            http_method_names = getattr(view_class, 'http_method_names', standard_methods)
            for verb in standard_methods:
                # View must explicitly implement the method (e.g., def get(self,...))
                if verb in http_method_names and hasattr(view_class, verb):
                    methods.add(verb.upper())

    # 2. Check for Function-Based Views (FBVs) and custom decorators
    if not methods:
        # Some frameworks/decorators attach metadata directly to the function
        if hasattr(callback, 'methods') and isinstance(callback.methods, (list, tuple, set)):
             for verb in callback.methods:
                 if isinstance(verb, str) and verb.lower() in standard_methods:
                     methods.add(verb.upper())
                     
        elif hasattr(callback, 'http_method_names') and isinstance(callback.http_method_names, (list, tuple, set)):
             for verb in callback.http_method_names:
                 if isinstance(verb, str) and verb.lower() in standard_methods:
                     methods.add(verb.upper())

        elif hasattr(callback, 'cls') and hasattr(callback.cls, 'http_method_names'):
             # Another layer DRF wraps sometimes exposes .cls directly
             for verb in standard_methods:
                 if verb in callback.cls.http_method_names and hasattr(callback.cls, verb):
                     methods.add(verb.upper())

    # 3. Graceful Fallback
    if not methods:
        methods.add('UNKNOWN')

    return sorted(list(methods))


def _extract_view_metadata(callback: Any) -> Dict[str, Any]:
    """
    Extracts view_name, module, docstring, valid HTTP methods, and serializer schema.
    Gracefully handles both Function-Based Views and Class-Based Views.
    """
    if hasattr(callback, 'view_class'):
        # For Class-Based Views, grab metadata safely from the underlying class
        view_class = callback.view_class
        view_name = getattr(view_class, '__name__', 'UnknownView')
        module = getattr(view_class, '__module__', '')
        docstring = getattr(view_class, '__doc__', '') or ''
    else:
        # For Function-Based Views or general callables
        view_name = getattr(callback, '__name__', callback.__class__.__name__)
        module = getattr(callback, '__module__', '')
        docstring = getattr(callback, '__doc__', '') or ''

    methods = _extract_allowed_methods(callback)
    request_fields = extract_serializer_fields(callback)

    return {
        'view_name': view_name,
        'module': module,
        'docstring': docstring.strip() if docstring else '',
        'methods': methods,
        'request_fields': request_fields,
    }


def get_api_endpoints(patterns: Optional[Any] = None, prefix: str = '') -> List[EndpointInfo]:
    """
    Recursively scans Django URL patterns and returns a structured list of endpoints.
    
    Args:
        patterns: A list of URLPattern/URLResolver objects, or a URLResolver. 
                  If None, it starts from the root URLconf.
        prefix: Accumulator for the URL path during nested recursion.
        
    Returns:
        A list of dictionaries matching the EndpointInfo TypedDict, each containing 
        extracted and normalized metadata about a resolved URL endpoint.
    """
    if patterns is None:
        # Start at the root level if no patterns are provided
        patterns = get_resolver().url_patterns
    elif isinstance(patterns, URLResolver):
        # Extract patterns if a single resolver was erroneously passed instead of a list
        patterns = patterns.url_patterns

    endpoints: List[EndpointInfo] = []

    for pattern in patterns:
        path_segment = _clean_path(pattern.pattern)
        full_path = f"{prefix}{path_segment}"

        if isinstance(pattern, URLResolver):
            # This is a nested routing group (like `include()`). Recurse down.
            endpoints.extend(get_api_endpoints(pattern.url_patterns, prefix=full_path))
            
        elif isinstance(pattern, URLPattern):
            # This is an actual endpoint leaf node
            callback = pattern.callback
            metadata = _extract_view_metadata(callback)
            
            # Normalize path structure to always contain exactly one leading slash
            normalized_path = full_path if full_path.startswith('/') else f"/{full_path}"
            # Protect against empty path leading double slash cases eg. //api
            normalized_path = normalized_path.replace('//', '/')
            
            endpoints.append({
                'path': normalized_path,
                'name': pattern.name or '',
                'view_name': metadata['view_name'],
                'module': metadata['module'],
                'docstring': metadata['docstring'],
                'methods': metadata['methods'],
                'callback': callback,
            })

    return endpoints


def filter_endpoints_by_prefix(endpoints: List[EndpointInfo], prefix: str) -> List[EndpointInfo]:
    """
    Filters a given list of endpoints to only those starting with the given path prefix.
    """
    if not prefix:
        return endpoints
        
    # Ensure prefix formatting matches the path normalization logic (leading slash)
    normalized_prefix = prefix if prefix.startswith('/') else f"/{prefix}"
    return [ep for ep in endpoints if ep['path'].startswith(normalized_prefix)]
