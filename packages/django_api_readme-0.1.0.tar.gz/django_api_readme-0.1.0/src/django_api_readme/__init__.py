"""
Django API README generator package.
"""

__version__ = "0.1.0"
