"""
Tests for schema introspection utilities isolating DRF logic.
"""
from django.test import SimpleTestCase
from django.views import View

# Safely query DRF so tests adapt to execution environments
try:
    from rest_framework import serializers
    DRF_AVAILABLE = True
except ImportError:
    DRF_AVAILABLE = False

from django_api_readme import schema
from django_api_readme.schema import extract_serializer_fields


# --- Mock Architectures ---

if DRF_AVAILABLE:
    class MockSerializer(serializers.Serializer):
        email = serializers.EmailField(required=True, help_text="User email")
        age = serializers.IntegerField(required=False, read_only=True)
        is_active = serializers.BooleanField(default=True)

    class ValidAPIView(View):
        serializer_class = MockSerializer
        
class ViewWithoutSerializer(View):
    pass


class SchemaTests(SimpleTestCase):
    
    def test_extract_serializer_fields_success(self):
        """Test extraction cleanly maps defined fields alongside accurate structural constraints."""
        if not DRF_AVAILABLE:
            self.skipTest("Django REST Framework is not conventionally installed to run extraction mock.")
            
        # Simulate introspection mapping finding a target callback class
        class MockCallback:
            view_class = ValidAPIView
            
        fields = extract_serializer_fields(MockCallback)
        self.assertEqual(len(fields), 3)
        
        # Verify specific EmailField string mappings and structural required logic
        email_field = next(f for f in fields if f['name'] == 'email')
        self.assertEqual(email_field['type'], 'string (email)')
        self.assertTrue(email_field['required'])
        self.assertFalse(email_field['read_only'])
        self.assertEqual(email_field['help_text'], "User email")
        
        # Verify read_only tracking mechanisms reliably resolve
        age_field = next(f for f in fields if f['name'] == 'age')
        self.assertEqual(age_field['type'], 'integer')
        self.assertTrue(age_field['read_only'])
        
        # Ensure default field handling correctly resolves baseline boolean types
        bool_field = next(f for f in fields if f['name'] == 'is_active')
        self.assertEqual(bool_field['type'], 'boolean')

    def test_absent_serializer_class(self):
        """Test that standard views bypassing schema constraints safely yield empty boundaries."""
        class MockCallback:
            view_class = ViewWithoutSerializer
            
        fields = extract_serializer_fields(MockCallback)
        self.assertEqual(fields, [])

    def test_drf_unavailable_fallback(self):
        """Test the graceful halting of schema extraction safely if DRF is missing off Python Path."""
        # Secure original environment state so tests cleanly teardown
        original_status = schema.DRF_AVAILABLE
        schema.DRF_AVAILABLE = False
        
        try:
            class MockCallback:
                # Even if we attempt resolution logic, flag forces a strict safe default
                view_class = ViewWithoutSerializer
            
            fields = extract_serializer_fields(MockCallback)
            self.assertEqual(fields, [])
        finally:
            schema.DRF_AVAILABLE = original_status
