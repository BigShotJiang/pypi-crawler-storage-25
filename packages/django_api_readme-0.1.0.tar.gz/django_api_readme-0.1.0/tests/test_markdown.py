"""
Tests for Markdown generation utilities.
"""
from django.test import SimpleTestCase
from django_api_readme.markdown import generate_markdown

class MarkdownTests(SimpleTestCase):
    
    def test_empty_endpoints(self):
        """Test missing API endpoints safely falls back to informative fallback phrasing."""
        md = generate_markdown([])
        self.assertIn("*No API endpoints discovered.*", md)

    def test_markdown_with_no_fields(self):
        """Test Markdown generated appropriately bounds basic functionality parameters seamlessly."""
        ep = {
            'path': '/api/test/',
            'name': 'test-route',
            'view_name': 'TestView',
            'docstring': 'Basic functionality overview.',
            'methods': ['GET'],
            'request_fields': []
        }
        
        md = generate_markdown([ep])
        self.assertIn("### `GET` /api/test/", md)
        self.assertIn("Basic functionality overview.", md)
        self.assertIn("**View:** `TestView`", md)
        self.assertIn("**Name:** `test-route`", md)
        
        # Lack of schema should implicitly bypass table boundaries natively
        self.assertNotIn("Request Schema", md)
        self.assertNotIn("| Field | Type |", md)

    def test_markdown_with_complex_schema_escaping(self):
        """Test Markdown strictly escapes fragile variables rendering inside dictionary representations."""
        ep = {
            'path': '/api/schema/',
            'methods': ['POST'],
            'request_fields': [{
                'name': 'escaped_value',
                'type': 'string',
                'required': True,
                'read_only': True,
                # The | character natively crashes Tables blindly if not dynamically escaped via engine format logic!
                'help_text': 'Valid choices: a|b|c.'
            }]
        }
        
        md = generate_markdown([ep])
        
        self.assertIn("**Request Schema**", md)
        self.assertIn("| Field | Type | Required | Description |", md)
        
        # Assert 'Yes' requirement rendered bold, '(Read-only)' logically stacked, and | completely escaped
        self.assertIn("| `escaped_value` | `string` | **Yes** | *(Read-only)* Valid choices: a&#124;b&#124;c. |", md)
