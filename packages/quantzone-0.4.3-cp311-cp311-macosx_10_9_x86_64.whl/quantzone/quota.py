"""配额查询服务。

对外暴露三层配额视图:今日基础额度(``daily_quota_bytes`` / ``daily_used_bytes``)、
扩容包余额(``extra_quota_bytes``)、合并后的精确可用余量(``available_bytes``),
以及套餐元信息(``remaining_days`` / ``license_type``)。
"""

from typing import TypedDict

from ._http import API_PREFIX, HttpClient

# 注:remaining_days 单独处理(可为 None 表示永久套餐),不放此列表
_PUBLIC_INT_FIELDS = (
    "daily_quota_bytes",
    "daily_used_bytes",
    "extra_quota_bytes",
    "available_bytes",
)


class Quota(TypedDict, total=False):
    """配额信息字典。

    Attributes:
        daily_quota_bytes: 今日基础流量额度上限(字节)。次日重置。
        daily_used_bytes: 今日已用流量(字节)。次日重置。
        extra_quota_bytes: 扩容包剩余流量(字节)。永久有效,用完为止,默认 0。
        available_bytes: 当前实际可用余量(字节),三层合并扣除已用与冻结后的精确值。
        remaining_days: 套餐剩余天数;``None`` 表示永久套餐(如免费版)。
        license_type: 套餐类型(如 ``"trial"`` / ``"commercial"`` / ``"免费版"``)。
    """

    daily_quota_bytes: int
    daily_used_bytes: int
    extra_quota_bytes: int
    available_bytes: int
    remaining_days: int | None
    license_type: str


class QuotaService:
    """用户配额查询服务。"""

    def __init__(self, http: HttpClient) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
        """
        self._http = http

    def get_quota(self) -> Quota:
        """获取当前用户配额。

        Returns:
            配额字典,含 ``daily_quota_bytes`` / ``daily_used_bytes`` /
            ``extra_quota_bytes`` / ``available_bytes`` / ``remaining_days`` /
            ``license_type`` 六个字段。响应缺失的字段在结果中也会缺失;
            ``remaining_days`` 可能为 ``None`` 表示永久套餐(如免费版)。
        """
        data = self._http.get(f"{API_PREFIX}/quota")
        if not isinstance(data, dict):
            return {}

        result: Quota = {}
        for key in _PUBLIC_INT_FIELDS:
            if key in data:
                result[key] = int(data[key])
        # remaining_days 单独处理:服务端可能返 None(永久套餐),保持 None 不转 int
        if "remaining_days" in data:
            value = data["remaining_days"]
            result["remaining_days"] = None if value is None else int(value)
        if "license_type" in data:
            result["license_type"] = str(data["license_type"])
        return result
