"""模块级 ``quantzone.init(...)`` 维护的单例 ``QuantZone``。

顶层 init 风格:用户在程序启动时调用一次 ``init``,
之后通过模块顶层函数(如 ``quantzone.get_factors``)直接使用。
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import QuantZone

_INSTANCE: "QuantZone | None" = None
_LOCK = threading.Lock()


def init(
    access_key: str | None = None,
    sign_secret: str | None = None,
    *,
    base_url: str,
    timeout: float = 60.0,
    download_dir: Path | str | None = None,
) -> "QuantZone":
    """初始化模块级单例 ``QuantZone``。

    Args:
        access_key (str | None): 公开标识符,必须显式传入,不再支持 keyring。
            示例：``"AKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"``。
        sign_secret (str | None): 签名密钥,必须显式传入,不再支持 keyring。
            示例：``"sk_xxxx..."``。
        base_url (str): 服务端地址,必须显式传入。
            示例：``"https://your-api.example.com"``。
        timeout (float): 请求超时(秒),默认 ``60.0``。示例：``30.0``。
        download_dir (Path | str | None): 下载目录;``None`` 时使用 ``~/.quantzone/downloads``。
            示例：``"/tmp/quantzone-downloads"``。

    Returns:
        QuantZone: 已初始化的实例。重复调用会先关闭旧实例再创建新的;
        多线程并发调用时,只有最后一个进入临界区的线程构造的实例会被保留,
        中间被覆盖的实例都会被 close,避免连接句柄泄漏。

    Raises:
        AuthError: ``access_key`` 或 ``sign_secret`` 缺失或为空字符串。
    """
    from .client import QuantZone

    global _INSTANCE
    new_instance = QuantZone(
        access_key=access_key,
        sign_secret=sign_secret,
        base_url=base_url,
        timeout=timeout,
        download_dir=download_dir,
    )
    with _LOCK:
        old_instance = _INSTANCE
        _INSTANCE = new_instance
    if old_instance is not None:
        old_instance.close()
    return new_instance


def get_instance() -> "QuantZone":
    """获取已初始化的单例。

    Returns:
        当前单例。

    Raises:
        RuntimeError: 调用 ``init()`` 之前调用本函数。
    """
    with _LOCK:
        instance = _INSTANCE
    if instance is None:
        raise RuntimeError("尚未调用 quantzone.init(),请先初始化")
    return instance


def reset() -> None:
    """关闭并清除单例(仅用于测试隔离)。"""
    global _INSTANCE
    with _LOCK:
        old_instance = _INSTANCE
        _INSTANCE = None
    if old_instance is not None:
        old_instance.close()
