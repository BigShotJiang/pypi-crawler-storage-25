from ._signer import sign_request as sign_request
from .exceptions import ApiKeyRateLimitError as ApiKeyRateLimitError, ApiKeyRevokedError as ApiKeyRevokedError, AuthError as AuthError, IpNotAllowedError as IpNotAllowedError, NetworkError as NetworkError, QuantError as QuantError, QuotaExceededError as QuotaExceededError, SDKVersionError as SDKVersionError, SignatureError as SignatureError
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

DEFAULT_TIMEOUT: float
MAX_TIMEOUT: float
SDK_VERSION_STATUS: int
STREAM_CHUNK_SIZE: int
HEADER_API_KEY: str
HEADER_SDK_VERSION: str
HEADER_ESTIMATED_BYTES: str
HEADER_ROW_COUNT: str
API_VERSION: str
API_PREFIX: str

class HttpClient:
    def __init__(self, access_key: str, sign_secret: str, base_url: str, timeout: float = ...) -> None: ...
    def close(self) -> None: ...
    def request(self, method: str, path: str, *, params: dict[str, Any] | None = None, json_body: Any | None = None) -> Any: ...
    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any: ...
    def post(self, path: str, *, json_body: Any | None = None, params: dict[str, Any] | None = None) -> Any: ...
    def stream_post(self, path: str, json_body: dict[str, Any], out_file: Path) -> dict[str, int]: ...
    @contextmanager
    def stream_post_iter(self, path: str, json_body: dict[str, Any]) -> Iterator[Iterator[bytes]]: ...
