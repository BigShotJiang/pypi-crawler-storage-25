"""因子查询。

对外仅提供 :meth:`FactorService.get_factors` — 一次性返回完整 ``DataFrame``。

- 边收边解码 Arrow IPC stream:每个 RecordBatch 立即转 ``DataFrame``。
- 边收边落盘:HTTP 字节同时写到 ``download_dir/temp/<id>.arrow``。
- 流自然结束 → 原子重命名到 ``download_dir/factors_<ts>.arrow``。
- 失败 → temp 文件保留,不删除。

返回窄表,列固定 4 列:``date / order_book_id / value / factor``。
"""

from __future__ import annotations

import io
import os
import uuid
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path
from typing import IO, Any

import pandas as pd
import pyarrow.ipc as ipc

from ._dates import DateLike, normalize_date
from ._http import API_PREFIX, HttpClient
from ._logger import logger

DEFAULT_DOWNLOAD_DIR = Path.home() / ".quantzone" / "downloads"
PERSIST_FILENAME_PREFIX = "factors_"
TEMP_SUBDIR = "temp"
ARROW_EXT = ".arrow"

_PUBLIC_FACTOR_META_FIELDS = ("factorname", "startDate", "endDate")


class _TeeReader(io.RawIOBase):
    """把上游 chunk 流复制一份到磁盘文件,同时对外暴露 file-like ``read`` 接口。

    用于 ``pa.ipc.open_stream`` 这种需要 file-like 的解码器:它从这里 ``read``,
    我们一边给它字节、一边把字节写到 temp 文件,实现 tee。

    继承 ``io.RawIOBase`` 是为了一次性补齐 ``closed`` / ``seekable`` / ``writable``
    等 pyarrow 校验需要的属性。
    """

    def __init__(self, chunks: Iterator[bytes], sink: IO[bytes]) -> None:
        """初始化。

        Args:
            chunks: 上游 HTTP chunk 字节迭代器(``httpx.Response.iter_bytes``)。
            sink: 已打开的 temp 文件句柄(二进制写)。
        """
        super().__init__()
        self._chunks = chunks
        self._sink = sink
        self._buffer = bytearray()

    def _pull_one(self) -> bool:
        """从上游再拉一个 chunk,同时写入 sink。返回是否拉到。"""
        try:
            chunk = next(self._chunks)
        except StopIteration:
            return False
        if not chunk:
            return True
        self._buffer.extend(chunk)
        self._sink.write(chunk)
        return True

    def read(self, n: int = -1) -> bytes:
        """读取至多 n 字节;n<0 表示读到 EOF。"""
        if n is None or n < 0:
            while self._pull_one():
                pass
            data = bytes(self._buffer)
            self._buffer.clear()
            return data
        while len(self._buffer) < n:
            if not self._pull_one():
                break
        take = bytes(self._buffer[:n])
        del self._buffer[:n]
        return take

    def readall(self) -> bytes:
        return self.read(-1)

    def readinto(self, b) -> int:
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    def readable(self) -> bool:
        return True

    def writable(self) -> bool:
        return False

    def seekable(self) -> bool:
        return False


def _to_str_list(value: str | list[str] | None) -> list[str] | None:
    """把 ``str`` / ``list[str]`` / None 归一为 ``list[str]`` 或 None。"""
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    return list(value)


class FactorService:
    """因子数据查询服务。"""

    def __init__(self, http: HttpClient, download_dir: Path | None = None) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
            download_dir: 默认下载目录;None 表示 ``~/.quantzone/downloads``。
        """
        self._http = http
        self._download_dir = download_dir or DEFAULT_DOWNLOAD_DIR

    def get_factors(
        self,
        order_book_ids: str | list[str] | None = None,
        factor: str | list[str] | None = None,
        start_date: DateLike | None = None,
        end_date: DateLike | None = None,
        filename: str | None = None,
    ) -> pd.DataFrame:
        """一次性返回完整因子数据(窄表)。

        响应以 Arrow IPC 流式返回,SDK 边收边解码、边落盘到
        ``download_dir/temp/<id>.arrow``。流自然结束后原子重命名到
        ``download_dir/<filename or factors_<ts>.arrow>``;失败 → temp 文件保留,
        不删除。

        Args:
            order_book_ids: 股票代码,``str`` 或 ``list[str]``,最多 100 个,None 表示全市场。
                支持两种等价格式:

                - 纯 6 位数字:``"000001"`` / ``["000001", "600036"]``
                - 6 位 + 交易所后缀:``"000001.SZ"`` / ``["600036.SH", "430047.BJ"]``
            factor: 因子名(``str`` 或 ``list[str]``),必填,1-20 个。
                示例:``"alpha1"`` 或 ``["alpha1", "vwap"]``。省略会被服务端拒绝。
            start_date: 起始日期,必填,支持 ``int(YYYYMMDD)`` / ``str`` / ``date`` /
                ``datetime`` / ``Timestamp``。
            end_date: 截止日期,格式同上;省略 = 服务端当日。
            filename: 自定义最终文件名(落到 ``download_dir`` 下);None 时按时间戳生成。

        Returns:
            窄表 ``DataFrame``,列:``date / order_book_id / value / factor``。
            空结果时返回带正确列名的空 DataFrame。
        """
        ids_list = _to_str_list(order_book_ids)
        factor_list = _to_str_list(factor)

        body: dict[str, Any] = {}
        if factor_list:
            body["factor"] = factor_list
        if ids_list:
            body["order_book_ids"] = ids_list
        if start_date is not None:
            body["start_date"] = normalize_date(start_date)
        if end_date is not None:
            body["end_date"] = normalize_date(end_date)

        download_dir = self._download_dir
        temp_dir = download_dir / TEMP_SUBDIR
        temp_dir.mkdir(parents=True, exist_ok=True)
        download_dir.mkdir(parents=True, exist_ok=True)

        temp_path = temp_dir / f"{uuid.uuid4().hex}{ARROW_EXT}"
        if filename is not None:
            # 路径遍历防护:filename 只能是纯文件名,不允许任何路径分隔符或父目录引用
            # 注意 POSIX 下 Path("a\\b").name 返回 "a\\b",必须显式拒绝反斜杠以保证跨平台安全
            if (
                filename in ("", ".", "..")
                or "/" in filename
                or "\\" in filename
                or filename != Path(filename).name
            ):
                raise ValueError(
                    f"filename 必须是纯文件名(不含路径分隔符 / 或 \\,不含 . .. 前缀): {filename!r}"
                )
            final_name = filename
        else:
            final_name = (
                f"{PERSIST_FILENAME_PREFIX}{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:8]}{ARROW_EXT}"
            )
        final_path = download_dir / final_name
        # 最终验证:解析后的路径必须仍在 download_dir 下,防止符号链接/相对路径绕过
        if final_path.resolve().parent != download_dir.resolve():
            raise ValueError(f"filename 解析后超出下载目录: {filename!r}")

        logger.info("下载文件(temp): %s", temp_path)

        chunks_dfs = list(self._iter_batches(body, temp_path, final_path))
        if not chunks_dfs:
            return pd.DataFrame(columns=["date", "order_book_id", "value", "factor"])
        return pd.concat(chunks_dfs, ignore_index=True)

    def _iter_batches(
        self,
        body: dict[str, Any],
        temp_path: Path,
        final_path: Path,
    ) -> Iterator[pd.DataFrame]:
        """流式解码生成器:每个 RecordBatch 立即 yield ``DataFrame``,边收边写 temp。"""
        success = False
        sink = temp_path.open("wb")
        try:
            with self._http.stream_post_iter(f"{API_PREFIX}/factors/stream", body) as chunks:
                tee = _TeeReader(chunks, sink)
                reader = ipc.open_stream(tee)
                while True:
                    try:
                        batch = reader.read_next_batch()
                    except StopIteration:
                        break
                    if batch is None:
                        break
                    yield batch.to_pandas()
            success = True
        finally:
            sink.flush()
            sink.close()
            if success:
                os.replace(temp_path, final_path)
                size = final_path.stat().st_size
                logger.info("已保存到: %s (%d bytes)", final_path, size)
            else:
                logger.info("流未正常结束,temp 文件保留: %s", temp_path)

    def list_factors(self) -> list[dict]:
        """获取可用因子元信息列表。

        Returns:
            因子列表,每个元素含 ``factorname`` / ``startDate`` / ``endDate`` 三个字段。
            服务端返回的其他字段一律丢弃,不暴露未知字段。
        """
        data = self._http.get(f"{API_PREFIX}/factors")
        raw = data if isinstance(data, list) else data.get("items", data.get("factors", []))
        return [
            {k: item[k] for k in _PUBLIC_FACTOR_META_FIELDS if k in item}
            for item in raw
        ]
