# Remembering-Machine
A machine that remembers ideas.

In order to launch it from the command line or as a Python subprocess:
```bash
echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
  | uvx remembering-machine \
    --provider-api-key=sk-proj-... \
    --github-token=ghp_... 
```

Or, with a local pip installation:
```bash
pip install remembering-machine
```
Set the environment variables:
```bash
export PROVIDER_API_KEY="sk-proj-..."
export GITHUB_TOKEN="ghp_..."
```
Then:
```bash
remembering-machine multilogue.txt
```
Or:
```bash
remembering-machine multilogue.txt new_turn.txt
```
Or:
```bash
cat multilogue.txt | remembering-machine
```
Or:
```bash
cat multilogue.txt | remembering-machine > multilogue.txt
```
Or: 
```bash
(cat multilogue.txt; echo:"Theodotos: What do you think, remembering-machine?") \
  | remembering-machine
```
Or:
```bash
cat multilogue.txt new_turn.txt | remembering-machine
```
Or:
```bash
cat multilogue.txt new_turn.txt | remembering-machine > multilogue.txt
```
Or, if you have installed other machines:
```bash
cat multilogue.md | remembering-machine \
  | summarizing-machine | judging-machine > summary_judgment.md
```

Or use it in your Python code:
```Python
# Python
import remembering_machine
```
