"""CrowdSky web API client for uploading and downloading stacked FITS files.

This module wraps the CrowdSky server's HTTP Basic Auth endpoints:

- **GET /api/my_stacks.php** — list user's uploaded stacks
- **POST /api/upload_stack.php** — upload a pre-stacked FITS file
- **GET /api/download_stack.php** — download a stacked FITS by chunk_key
- **POST /api/raw_upload.php** — batch-upload raw sub-frames (start / file / finalize)

Credentials can be set via environment variables (``CROWDSKY_USERNAME``,
``CROWDSKY_PASSWORD``) or at runtime with :func:`set_credentials`.

Example::

    from seestarpy.crowdsky import server

    server.set_credentials("alice", "s3cret")

    # List existing stacks
    stacks = server.list_stacks()

    # Upload a pre-stacked result
    server.upload_stack("CrowdSky_38_M81_20.0s_LP_20260227-224500.fit")

    # Upload raw sub-frames
    token = server.raw_start_session()
    for path in raw_fits_files:
        server.raw_upload_file(token, path)
    result = server.raw_finalize(token)

    # Re-upload raw files, replacing any existing stack for the same chunk-key
    token = server.raw_start_session()
    for path in raw_fits_files:
        server.raw_upload_file(token, path)
    result = server.raw_finalize(token, overwrite=True)
"""

import os
from pathlib import Path

import requests

from .. import data as _data_mod
from .chunks import CROWDSKY_RE, CROWDSKY_RE_LEGACY

BASE_URL = "https://crowdsky.univie.ac.at"
USERNAME = os.environ.get("CROWDSKY_USERNAME", "")
PASSWORD = os.environ.get("CROWDSKY_PASSWORD", "")


def set_credentials(username, password):
    """Set CrowdSky login credentials for the session.

    Parameters
    ----------
    username : str
        CrowdSky account username.
    password : str
        CrowdSky account password.
    """
    global USERNAME, PASSWORD
    USERNAME = username
    PASSWORD = password


def set_base_url(url):
    """Override the CrowdSky server URL (for testing or staging).

    Parameters
    ----------
    url : str
        Base URL without trailing slash, e.g. ``"https://staging.crowdsky.example.com"``.
    """
    global BASE_URL
    BASE_URL = url.rstrip("/")


def _get_auth():
    """Return (username, password) tuple; raise if not configured."""
    if not USERNAME or not PASSWORD:
        raise RuntimeError(
            "CrowdSky credentials not set. Call set_credentials() or set "
            "CROWDSKY_USERNAME and CROWDSKY_PASSWORD environment variables."
        )
    return (USERNAME, PASSWORD)


def _request(method, endpoint, **kwargs):
    """Send an authenticated request to the CrowdSky API.

    Injects HTTP Basic Auth, prepends BASE_URL, sets a 30s timeout,
    and translates 401 responses into a clear RuntimeError.
    """
    url = f"{BASE_URL}{endpoint}"
    kwargs.setdefault("timeout", 30)
    kwargs["auth"] = _get_auth()

    resp = requests.request(method, url, **kwargs)

    if resp.status_code == 401:
        raise RuntimeError("CrowdSky authentication failed (401).")
    resp.raise_for_status()

    return resp


def list_stacks(object_name=None):
    """List the user's uploaded stacks on the CrowdSky server.

    Parameters
    ----------
    object_name : str, optional
        Filter results by object name (passed as ``?object=`` query param).

    Returns
    -------
    list[dict]
        Each dict contains server-side metadata such as ``chunk_key``,
        ``object_name``, ``n_frames``, etc.
    """
    params = {}
    if object_name is not None:
        params["object"] = object_name

    resp = _request("GET", "/api/my_stacks.php", params=params)
    return resp.json()


def upload_stack(fits_path, thumbnail=None, n_frames_input=None,
                 n_frames_aligned=None, date_obs_start=None,
                 date_obs_end=None, scrub_location=None):
    """Upload a stacked FITS file to the CrowdSky server.

    Parameters
    ----------
    fits_path : str or Path
        Local path to the ``.fit`` / ``.fits`` file.
    thumbnail : str or Path, optional
        Local path to a thumbnail image (JPEG/PNG).
    n_frames_input : int, optional
        Total number of input sub-frames.
    n_frames_aligned : int, optional
        Number of frames that were successfully aligned.
    date_obs_start : str, optional
        ISO 8601 timestamp of the first sub-frame.
    date_obs_end : str, optional
        ISO 8601 timestamp of the last sub-frame.
    scrub_location : int, optional
        If 1, strip SITELONG/SITELAT from the output FITS and DB.

    Returns
    -------
    dict
        Server response with keys ``ok``, ``job_id``, ``chunk_key``,
        ``status`` (``"queued"``).  The file is queued for worker
        post-processing rather than stored directly.

    Raises
    ------
    FileNotFoundError
        If *fits_path* does not exist.
    """
    fits_path = Path(fits_path)
    if not fits_path.exists():
        raise FileNotFoundError(f"FITS file not found: {fits_path}")

    files = {"file": (fits_path.name, fits_path.open("rb"))}
    if thumbnail is not None:
        thumb_path = Path(thumbnail)
        files["thumbnail"] = (thumb_path.name, thumb_path.open("rb"))

    data = {}
    if n_frames_input is not None:
        data["n_frames_input"] = str(n_frames_input)
    if n_frames_aligned is not None:
        data["n_frames_aligned"] = str(n_frames_aligned)
    if date_obs_start is not None:
        data["date_obs_start"] = date_obs_start
    if date_obs_end is not None:
        data["date_obs_end"] = date_obs_end
    if scrub_location is not None:
        data["scrub_location"] = str(scrub_location)

    resp = _request("POST", "/api/upload_stack.php", files=files, data=data)
    return resp.json()


def download_stack(chunk_keys, dest="."):
    """Download stacked FITS files from the CrowdSky server by chunk key.

    Parameters
    ----------
    chunk_keys : str or list[str]
        One or more chunk keys to download.
    dest : str or Path
        Destination directory.  Defaults to current directory.

    Returns
    -------
    list[Path]
        List of local file paths that were downloaded.
    """
    if isinstance(chunk_keys, str):
        chunk_keys = [chunk_keys]

    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)

    downloaded = []
    for key in chunk_keys:
        resp = _request(
            "GET", "/api/download_stack.php", params={"chunk_key": key},
            stream=True,
        )

        # Derive filename from Content-Disposition header or chunk key
        cd = resp.headers.get("Content-Disposition", "")
        if "filename=" in cd:
            fname = cd.split("filename=")[-1].strip('"')
        else:
            fname = f"{key}.fits"

        out_path = dest / fname
        with open(out_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
        downloaded.append(out_path)

    return downloaded


# ---------------------------------------------------------------------------
# Raw sub-frame upload (three-step: start / file / finalize)
# ---------------------------------------------------------------------------

def raw_start_session():
    """Create a new raw-upload session on the server.

    Returns
    -------
    str
        The ``session_token`` for this upload session, which must be passed
        to :func:`raw_upload_file` and :func:`raw_finalize`.

    Raises
    ------
    RuntimeError
        If credentials are not set or the server returns an error.
    """
    resp = _request("POST", "/api/raw_upload.php", params={"action": "start"})
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"raw_start_session failed: {data['error']}")
    return data["session_token"]


def raw_upload_file(session_token, fits_path):
    """Upload one raw FITS sub-frame to an open upload session.

    The file must have a valid ``DATE-OBS`` FITS header keyword; the server
    returns a 400 error if it is absent.

    Parameters
    ----------
    session_token : str
        Token returned by :func:`raw_start_session`.
    fits_path : str or Path
        Local path to the raw ``.fit`` / ``.fits`` sub-frame.

    Returns
    -------
    dict
        Server response with keys ``ok``, ``filename``, ``chunk_key``,
        ``date_obs``.

    Raises
    ------
    FileNotFoundError
        If *fits_path* does not exist.
    RuntimeError
        If the server returns an error for this file.
    """
    fits_path = Path(fits_path)
    if not fits_path.exists():
        raise FileNotFoundError(f"FITS file not found: {fits_path}")

    resp = _request(
        "POST", "/api/raw_upload.php",
        params={"action": "file"},
        data={"session_token": session_token},
        files={"file": (fits_path.name, fits_path.open("rb"))},
        timeout=120,
    )
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"raw_upload_file failed for {fits_path.name}: {data['error']}")
    return data


def raw_finalize(session_token, scrub_location=False, overwrite=False):
    """Finalize a raw-upload session and create stacking jobs.

    Groups all uploaded files by ``chunk_key + telescope_id`` and inserts
    ``stacking_jobs`` rows.  The worker will pick them up and stack them.

    Parameters
    ----------
    session_token : str
        Token returned by :func:`raw_start_session`.
    scrub_location : bool
        If ``True``, strip ``SITELONG``/``SITELAT`` from the stacked output
        FITS and database record.  Default ``False``.
    overwrite : bool
        If ``True``, delete any existing ``stacked_frames`` row (and its
        u:cloud files) for each duplicate chunk-key before creating the new
        stacking job.  If ``False`` (default), duplicate chunk-keys are
        skipped and returned in the ``skipped`` list.

    Returns
    -------
    dict
        Server response with keys:

        - ``ok`` (bool)
        - ``jobs`` (int): number of stacking jobs created
        - ``job_ids`` (list[int]): IDs of the created jobs
        - ``chunks`` (list[str]): chunk-keys that were queued
        - ``skipped`` (list[str]): chunk-keys skipped because a stack
          already existed (only populated when *overwrite* is ``False``)

    Raises
    ------
    RuntimeError
        If the server returns an error.
    """
    data = {
        "session_token": session_token,
        "scrub_location": "1" if scrub_location else "0",
    }
    if overwrite:
        data["overwrite"] = "1"

    resp = _request(
        "POST", "/api/raw_upload.php",
        params={"action": "finalize"},
        data=data,
    )
    result = resp.json()
    if "error" in result:
        raise RuntimeError(f"raw_finalize failed: {result['error']}")
    return result


# ---------------------------------------------------------------------------
# Bulk upload from Seestar or local directory
# ---------------------------------------------------------------------------

def _parse_chunk_key(filename):
    """Extract a chunk key from a CrowdSky filename, or return None."""
    m = CROWDSKY_RE.match(filename)
    if m:
        return f"{m.group(5)}_HP{m.group(6)}"
    m = CROWDSKY_RE_LEGACY.match(filename)
    if m:
        return m.group(5)
    return None


def upload_all_stacks(target=None, local_dir=None, dest=".",
                      skip_existing=True, dry_run=False):
    """Upload all CrowdSky-ready stacks to the CrowdSky server.

    Finds ``CrowdSky_*.fit`` files either on the Seestar's eMMC or in a
    local directory, and uploads each one via :func:`upload_stack`.

    Parameters
    ----------
    target : str, list[str], or None
        Which observation folders to scan on the Seestar:

        - A target name (e.g. ``"M 81"``) — that folder only.
        - A list of names — those folders.
        - ``None`` or ``"all"`` — every non-``_sub`` folder.

        Ignored when *local_dir* is set.
    local_dir : str, Path, or None
        If given, scan this local directory (recursively) for
        ``CrowdSky_*.fit`` files instead of downloading from the Seestar.
    dest : str or Path
        Local directory where files downloaded from the Seestar are saved.
        Files are kept after upload.  Default ``"."``.  Ignored when
        *local_dir* is set.
    skip_existing : bool
        If ``True`` (default), query the server first and skip files whose
        chunk key has already been uploaded.
    dry_run : bool
        If ``True``, list what would be uploaded without transferring data.

    Returns
    -------
    dict
        Summary with keys ``folders_scanned``, ``files_uploaded``,
        ``files_skipped``, ``files_failed``, ``uploaded``, ``skipped``,
        ``failed``.

    Examples
    --------
    Upload stacks from a specific target on the Seestar::

        >>> from seestarpy.crowdsky import server
        >>> server.set_credentials("alice", "s3cret")
        >>> server.upload_all_stacks("AM Leo", dest="./downloads")

    Upload from a local directory (no Seestar needed)::

        >>> server.upload_all_stacks(local_dir="./my_stacks")

    Preview without uploading::

        >>> server.upload_all_stacks(dry_run=True)
    """
    summary = {
        "folders_scanned": 0,
        "files_uploaded": 0,
        "files_skipped": 0,
        "files_failed": 0,
        "uploaded": [],
        "skipped": [],
        "failed": [],
    }

    # ---- Collect candidate files ----
    # Each item: (local_path_or_None, folder_or_None, filename)
    candidates = []

    if local_dir is not None:
        local_dir = Path(local_dir)
        for path in sorted(local_dir.rglob("CrowdSky_*.fit")):
            candidates.append((path, None, path.name))
        summary["folders_scanned"] = 1
        print(f"Found {len(candidates)} CrowdSky file(s) in {local_dir}")
    else:
        folders = _data_mod.list_folders()
        if target is None or (isinstance(target, str) and target.lower() == "all"):
            folder_names = [n for n in folders if not n.endswith("_sub")]
        elif isinstance(target, str):
            folder_names = [target]
        else:
            folder_names = list(target)

        for folder_name in folder_names:
            summary["folders_scanned"] += 1
            try:
                files = _data_mod.list_folder_contents(folder_name, filetype="fit")
            except Exception as exc:
                print(f"  Skipping {folder_name}: {exc}")
                continue
            for fname in sorted(files):
                if fname.startswith("CrowdSky_"):
                    candidates.append((None, folder_name, fname))

        print(
            f"Found {len(candidates)} CrowdSky file(s) across "
            f"{summary['folders_scanned']} folder(s)"
        )

    if not candidates:
        return summary

    # ---- Dedup against server ----
    existing_keys = set()
    if skip_existing:
        try:
            stacks = list_stacks()
            existing_keys = {s.get("chunk_key") for s in stacks}
            existing_keys.discard(None)
        except Exception as exc:
            print(f"  Warning: could not fetch existing stacks: {exc}")

    to_upload = []
    for local_path, folder, fname in candidates:
        chunk_key = _parse_chunk_key(fname)
        if chunk_key and chunk_key in existing_keys:
            summary["files_skipped"] += 1
            summary["skipped"].append(fname)
            continue
        to_upload.append((local_path, folder, fname))

    if summary["files_skipped"]:
        print(f"  Skipping {summary['files_skipped']} already-uploaded file(s)")

    if not to_upload:
        print("Nothing to upload.")
        return summary

    # ---- Dry run ----
    if dry_run:
        print(f"Dry run: {len(to_upload)} file(s) would be uploaded:")
        for _, folder, fname in to_upload:
            src = folder or "local"
            print(f"  [{src}] {fname}")
        return summary

    # ---- Upload ----
    dest = Path(dest)
    for local_path, folder, fname in to_upload:
        try:
            if local_path is not None:
                fits_path = local_path
            else:
                fits_path = Path(
                    _data_mod.download_file(folder, fname, str(dest / folder))
                )

            print(f"  Uploading {fname}...", end="", flush=True)
            upload_stack(fits_path)
            print(" OK")
            summary["files_uploaded"] += 1
            summary["uploaded"].append(fname)
        except Exception as exc:
            print(f" FAILED: {exc}")
            summary["files_failed"] += 1
            summary["failed"].append(fname)

    uploaded = summary["files_uploaded"]
    failed = summary["files_failed"]
    print(f"Done: {uploaded} uploaded, {failed} failed.")
    return summary
