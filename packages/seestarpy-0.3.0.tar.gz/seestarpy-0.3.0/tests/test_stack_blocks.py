"""Unit tests for CrowdSky time-block stacking functions in crowdsky/chunks.py."""

from datetime import datetime
from unittest.mock import patch
from zoneinfo import ZoneInfo

import pytest

from seestarpy.crowdsky.chunks import (
    _compute_chunk_key,
    _floor_to_block,
    _local_dt_to_chunk_str,
    _parse_light_filename,
    find_unstacked_blocks,
    list_targets,
    stack_all,
)

# All tests use Europe/Vienna (UTC+1 in winter) for deterministic timezone conversion
_VIENNA = ZoneInfo("Europe/Vienna")


# ---------------------------------------------------------------------------
# _parse_light_filename
# ---------------------------------------------------------------------------

class TestParseLightFilename:
    def test_standard_filename(self):
        result = _parse_light_filename(
            "Light_M 81_20.0s_LP_20260227-225203.fit"
        )
        assert result == {
            "target": "M 81",
            "exposure": "20.0s",
            "filter": "LP",
            "datetime": datetime(2026, 2, 27, 22, 52, 3),
        }

    def test_ircut_filter(self):
        result = _parse_light_filename(
            "Light_M 81_10.0s_IRCUT_20250607-221746.fit"
        )
        assert result["filter"] == "IRCUT"
        assert result["exposure"] == "10.0s"

    def test_complex_target_name(self):
        result = _parse_light_filename(
            "Light_NGC 2244 Satellite Cluster_10.0s_LP_20260227-225203.fit"
        )
        assert result["target"] == "NGC 2244 Satellite Cluster"

    def test_target_with_underscore(self):
        result = _parse_light_filename(
            "Light_Some_Target_20.0s_LP_20260227-225203.fit"
        )
        assert result["target"] == "Some_Target"

    def test_non_matching_returns_none(self):
        assert _parse_light_filename("random_file.jpg") is None
        assert _parse_light_filename("DSO_Stacked_38_M 81_20.0s_20260227_225203.fit") is None
        assert _parse_light_filename("Light_M 81_20.0s_LP_20260227-225203.jpg") is None

    def test_thumbnail_not_matched(self):
        assert _parse_light_filename(
            "Light_M 81_20.0s_LP_20260227-225203_thn.jpg"
        ) is None


# ---------------------------------------------------------------------------
# _floor_to_block
# ---------------------------------------------------------------------------

class TestFloorToBlock:
    def test_mid_block(self):
        dt = datetime(2026, 2, 27, 22, 52, 3)
        assert _floor_to_block(dt, 15) == datetime(2026, 2, 27, 22, 45, 0)

    def test_on_boundary(self):
        dt = datetime(2026, 2, 27, 23, 0, 0)
        assert _floor_to_block(dt, 15) == datetime(2026, 2, 27, 23, 0, 0)

    def test_just_after_boundary(self):
        dt = datetime(2026, 2, 27, 23, 0, 1)
        assert _floor_to_block(dt, 15) == datetime(2026, 2, 27, 23, 0, 0)

    def test_30_minute_blocks(self):
        dt = datetime(2026, 2, 27, 22, 52, 0)
        assert _floor_to_block(dt, 30) == datetime(2026, 2, 27, 22, 30, 0)

    def test_microseconds_cleared(self):
        dt = datetime(2026, 2, 27, 22, 52, 3, 500000)
        result = _floor_to_block(dt, 15)
        assert result.microsecond == 0


# ---------------------------------------------------------------------------
# find_unstacked_blocks
# ---------------------------------------------------------------------------

def _make_light_files(target, exposure, filt, times):
    """Helper to generate Light_ filenames from a list of (HH, MM, SS)."""
    files = {}
    for h, m, s in times:
        fname = f"Light_{target}_{exposure}_{filt}_20260227-{h:02d}{m:02d}{s:02d}.fit"
        files[fname] = 4050000  # dummy size
    return files


class TestFindUnstackedBlocks:
    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_basic_grouping(self, mock_data, mock_tz):
        """Frames in two 15-min blocks should produce two blocks."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            # Block 22:45
            (22, 45, 10), (22, 50, 20), (22, 55, 30),
            # Block 23:00
            (23, 0, 10), (23, 5, 20), (23, 10, 30),
        ])
        mock_data.list_folder_contents.side_effect = [
            raw,       # raw files from _sub folder
            {},        # stacked files from main folder
        ]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        assert len(blocks) == 2
        assert blocks[0]["block_start"] == datetime(2026, 2, 27, 22, 45, 0)
        assert blocks[0]["frame_count"] == 3
        assert blocks[1]["block_start"] == datetime(2026, 2, 27, 23, 0, 0)
        assert blocks[1]["frame_count"] == 3

    @patch("seestarpy.crowdsky.chunks.data")
    def test_current_block_skipped(self, mock_data):
        """The current (incomplete) block should be excluded."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            (22, 45, 10), (22, 50, 20),
        ])
        mock_data.list_folder_contents.side_effect = [raw, {}]

        # "now" is within the 22:45 block
        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 27, 22, 55, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        assert len(blocks) == 0

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_covered_block_excluded(self, mock_data, mock_tz):
        """Blocks with matching CrowdSky output files should be excluded.

        CrowdSky filenames encode the UTC chunk key and HEALPix pixel.
        Coverage matching uses (YYYYMMDD.CC, exposure, filter).
        """
        raw = _make_light_files("M 81", "20.0s", "LP", [
            (22, 45, 10), (22, 50, 20), (22, 55, 30),
            (23, 0, 10), (23, 5, 20),
        ])
        # 22:45 local Vienna = 21:45 UTC → chunk 87
        stacked = {
            "CrowdSky_3_M 81_20.0s_LP_20260227.87_HP000000.fit": 10000,
        }
        mock_data.list_folder_contents.side_effect = [raw, stacked]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        # The 22:45 block is covered; 23:00 block (2 frames) remains
        assert len(blocks) == 1
        assert blocks[0]["block_start"] == datetime(2026, 2, 27, 23, 0, 0)

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_dso_stacked_does_not_mark_coverage(self, mock_data, mock_tz):
        """Plain DSO_Stacked files should NOT mark coverage."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            (22, 45, 10), (22, 50, 20), (22, 55, 30),
        ])
        stacked = {
            # DSO_Stacked (not CrowdSky) — should be ignored for coverage
            "DSO_Stacked_3_M 81_20.0s_20260228_205636.fit": 10000,
        }
        mock_data.list_folder_contents.side_effect = [raw, stacked]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        # Block should NOT be covered — only CrowdSky files count
        assert len(blocks) == 1
        assert blocks[0]["block_start"] == datetime(2026, 2, 27, 22, 45, 0)

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_crowdsky_exact_match_handles_duplicate_frame_counts(self, mock_data, mock_tz):
        """CrowdSky coverage is by chunk key, not frame count."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            # Block 22:45 — 3 frames
            (22, 45, 10), (22, 50, 20), (22, 55, 30),
            # Block 23:00 — also 3 frames
            (23, 0, 10), (23, 5, 20), (23, 10, 30),
        ])
        stacked = {
            # Only the 22:45 block is covered (22:45 Vienna = 21:45 UTC → chunk 87)
            "CrowdSky_3_M 81_20.0s_LP_20260227.87_HP000000.fit": 10000,
        }
        mock_data.list_folder_contents.side_effect = [raw, stacked]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        # Only the 23:00 block remains — exact match, no ambiguity
        assert len(blocks) == 1
        assert blocks[0]["block_start"] == datetime(2026, 2, 27, 23, 0, 0)

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_mixed_exposure_filter_subgroups(self, mock_data, mock_tz):
        """Frames with different exposure/filter combos produce sub-blocks."""
        raw = {
            **_make_light_files("M 81", "20.0s", "LP", [(22, 45, 10), (22, 50, 20)]),
            **_make_light_files("M 81", "10.0s", "IRCUT", [(22, 46, 0), (22, 51, 0)]),
        }
        mock_data.list_folder_contents.side_effect = [raw, {}]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        assert len(blocks) == 2
        exposures = {b["exposure"] for b in blocks}
        assert exposures == {"20.0s", "10.0s"}
        filters = {b["filter"] for b in blocks}
        assert filters == {"LP", "IRCUT"}

    @patch("seestarpy.crowdsky.chunks.data")
    def test_no_raw_files_returns_empty(self, mock_data):
        mock_data.list_folder_contents.return_value = {}
        blocks = find_unstacked_blocks("M 81")
        assert blocks == []

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_files_sorted_within_block(self, mock_data, mock_tz):
        """Files within a block should be sorted by filename (chronological)."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            (22, 55, 30), (22, 45, 10), (22, 50, 20),
        ])
        mock_data.list_folder_contents.side_effect = [raw, {}]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        assert len(blocks) == 1
        # Files should be sorted
        for i in range(len(blocks[0]["files"]) - 1):
            assert blocks[0]["files"][i] < blocks[0]["files"][i + 1]


    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    @patch("seestarpy.crowdsky.chunks.data")
    def test_legacy_crowdsky_file_marks_coverage(self, mock_data, mock_tz):
        """Old-format CrowdSky files (pre-HEALPix) should still mark coverage."""
        raw = _make_light_files("M 81", "20.0s", "LP", [
            (22, 45, 10), (22, 50, 20), (22, 55, 30),
        ])
        stacked = {
            # Legacy format: 22:45 local Vienna = 21:45 UTC → chunk 87
            "CrowdSky_3_M 81_20.0s_LP_20260227-224500.fit": 10000,
        }
        mock_data.list_folder_contents.side_effect = [raw, stacked]

        with patch("seestarpy.crowdsky.chunks.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 2, 28, 12, 0, 0)
            mock_dt.strptime = datetime.strptime
            blocks = find_unstacked_blocks("M 81")

        # Legacy file covers the 22:45 block — no unstacked blocks remain
        assert len(blocks) == 0


# ---------------------------------------------------------------------------
# _local_dt_to_chunk_str / _compute_chunk_key
# ---------------------------------------------------------------------------

class TestChunkKey:
    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    def test_local_dt_to_chunk_str(self, mock_tz):
        """22:45 Vienna (UTC+1) = 21:45 UTC → chunk 87."""
        dt = datetime(2026, 2, 27, 22, 45, 0)
        assert _local_dt_to_chunk_str(dt) == "20260227.87"

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    def test_midnight_boundary(self, mock_tz):
        """00:30 Vienna (UTC+1) = 23:30 UTC previous day → chunk 94."""
        dt = datetime(2026, 2, 28, 0, 30, 0)
        # 23:30 UTC = (23*3600 + 30*60) // 900 = 84600 // 900 = 94
        assert _local_dt_to_chunk_str(dt) == "20260227.94"

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    def test_compute_chunk_key_with_coords(self, mock_tz):
        dt = datetime(2026, 2, 27, 22, 45, 0)
        key = _compute_chunk_key(dt, 83.82, -5.39)
        # Format: "YYYYMMDD.CC_HPnnnnnn"
        assert key.startswith("20260227.87_HP")
        hp_part = key.split("_HP")[1]
        assert len(hp_part) == 6
        assert hp_part.isdigit()

    @patch("seestarpy.crowdsky.chunks.get_localzone", return_value=_VIENNA)
    def test_compute_chunk_key_no_coords(self, mock_tz):
        dt = datetime(2026, 2, 27, 22, 45, 0)
        key = _compute_chunk_key(dt, None, None)
        assert key == "20260227.87_HP000000"


# ---------------------------------------------------------------------------
# list_targets
# ---------------------------------------------------------------------------

class TestListTargets:
    @patch("seestarpy.crowdsky.chunks.data")
    def test_finds_target_pairs(self, mock_data):
        mock_data.list_folders.return_value = {
            "M 81": 3,
            "M 81_sub": 1052,
            "Lunar": 2,
            "M 42": 1,
            "M 42_sub": 500,
        }
        targets = list_targets()
        assert len(targets) == 2
        assert targets[0]["target"] == "M 42"
        assert targets[0]["raw_files"] == 500
        assert targets[0]["stacked_files"] == 1
        assert targets[1]["target"] == "M 81"

    @patch("seestarpy.crowdsky.chunks.data")
    def test_orphan_sub_folder_excluded(self, mock_data):
        """A _sub folder without a matching main folder is not a target."""
        mock_data.list_folders.return_value = {
            "Orphan_sub": 100,
            "M 81": 3,
            "M 81_sub": 500,
        }
        targets = list_targets()
        assert len(targets) == 1
        assert targets[0]["target"] == "M 81"

    @patch("seestarpy.crowdsky.chunks.data")
    def test_empty_returns_empty(self, mock_data):
        mock_data.list_folders.return_value = {}
        assert list_targets() == []


# ---------------------------------------------------------------------------
# stack_all
# ---------------------------------------------------------------------------

class TestStackAll:
    @patch("seestarpy.crowdsky.chunks.stack_blocks")
    @patch("seestarpy.crowdsky.chunks.list_targets")
    def test_aggregates_multiple_targets(self, mock_list, mock_stack):
        mock_list.return_value = [
            {"target": "M 42", "raw_files": 100, "stacked_files": 1},
            {"target": "M 81", "raw_files": 200, "stacked_files": 2},
        ]
        mock_stack.side_effect = [
            {
                "target": "M 42",
                "blocks_stacked": 2,
                "blocks_failed": 0,
                "blocks_skipped": 1,
                "results": [],
            },
            {
                "target": "M 81",
                "blocks_stacked": 3,
                "blocks_failed": 1,
                "blocks_skipped": 0,
                "results": [],
            },
        ]

        result = stack_all()

        assert result["targets_processed"] == 2
        assert result["targets_with_work"] == 2
        assert result["total_blocks_stacked"] == 5
        assert result["total_blocks_failed"] == 1
        assert result["total_blocks_skipped"] == 1
        assert len(result["per_target"]) == 2

    @patch("seestarpy.crowdsky.chunks.stack_blocks")
    @patch("seestarpy.crowdsky.chunks.list_targets")
    def test_no_targets(self, mock_list, mock_stack):
        mock_list.return_value = []

        result = stack_all()

        assert result["targets_processed"] == 0
        assert result["targets_with_work"] == 0
        assert result["total_blocks_stacked"] == 0
        assert result["total_blocks_failed"] == 0
        assert result["total_blocks_skipped"] == 0
        assert result["per_target"] == []
        mock_stack.assert_not_called()

    @patch("seestarpy.crowdsky.chunks.stack_blocks")
    @patch("seestarpy.crowdsky.chunks.list_targets")
    def test_one_target_error_continues(self, mock_list, mock_stack):
        mock_list.return_value = [
            {"target": "M 42", "raw_files": 100, "stacked_files": 1},
            {"target": "M 81", "raw_files": 200, "stacked_files": 2},
        ]
        mock_stack.side_effect = [
            RuntimeError("connection lost"),
            {
                "target": "M 81",
                "blocks_stacked": 2,
                "blocks_failed": 0,
                "blocks_skipped": 0,
                "results": [],
            },
        ]

        result = stack_all()

        assert result["targets_processed"] == 2
        assert result["total_blocks_stacked"] == 2
        # Failed target has error key
        assert "error" in result["per_target"][0]
        assert result["per_target"][0]["error"] == "connection lost"
        # Second target succeeded
        assert "error" not in result["per_target"][1]

    @patch("seestarpy.crowdsky.chunks.stack_blocks")
    @patch("seestarpy.crowdsky.chunks.list_targets")
    def test_targets_with_work_count(self, mock_list, mock_stack):
        """Targets with zero blocks (stacked+failed+skipped) don't count."""
        mock_list.return_value = [
            {"target": "M 42", "raw_files": 100, "stacked_files": 1},
            {"target": "M 81", "raw_files": 200, "stacked_files": 2},
        ]
        mock_stack.side_effect = [
            {
                "target": "M 42",
                "blocks_stacked": 0,
                "blocks_failed": 0,
                "blocks_skipped": 0,
                "results": [],
            },
            {
                "target": "M 81",
                "blocks_stacked": 1,
                "blocks_failed": 0,
                "blocks_skipped": 0,
                "results": [],
            },
        ]

        result = stack_all()

        assert result["targets_processed"] == 2
        assert result["targets_with_work"] == 1

    @patch("seestarpy.crowdsky.chunks.stack_blocks")
    @patch("seestarpy.crowdsky.chunks.list_targets")
    def test_passes_parameters_through(self, mock_list, mock_stack):
        mock_list.return_value = [
            {"target": "M 42", "raw_files": 100, "stacked_files": 1},
        ]
        mock_stack.return_value = {
            "target": "M 42",
            "blocks_stacked": 0,
            "blocks_failed": 0,
            "blocks_skipped": 0,
            "results": [],
        }

        stack_all(block_minutes=30, min_exptime=120, dry_run=True)

        mock_stack.assert_called_once_with(
            "M 42", block_minutes=30, min_exptime=120, dry_run=True,
        )
