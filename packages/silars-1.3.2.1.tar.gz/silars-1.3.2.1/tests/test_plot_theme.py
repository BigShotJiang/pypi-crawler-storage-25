# tests/test_plot_theme.py
# -*- coding: utf-8 -*-
import pytest
from silars.plot.theme import COLORS, LAYOUT, AXIS, TABLE, get_colors_with_alpha

def test_colors_is_list():
    """COLORS 应为列表"""
    assert isinstance(COLORS, list)
    assert len(COLORS) > 0

def test_colors_has_rgba_format():
    """COLORS 元素应为 rgba 格式"""
    for color in COLORS[:3]:
        assert color.startswith('rgba(')
        assert color.endswith(')')

def test_layout_has_required_keys():
    """LAYOUT 应包含必要键"""
    required_keys = ['template', 'hovermode', 'hoverlabel', 'legend', 'height', 'xaxis', 'yaxis']
    for key in required_keys:
        assert key in LAYOUT, f"LAYOUT missing key: {key}"

def test_axis_has_grid_config():
    """坐标轴应包含网格配置"""
    assert 'gridcolor' in AXIS['xaxis']
    assert 'gridcolor' in AXIS['yaxis']

def test_table_has_header_and_cell():
    """TABLE 应包含 header 和 cell 配置"""
    assert 'header' in TABLE
    assert 'cell' in TABLE

def test_get_colors_with_alpha():
    """get_colors_with_alpha 应返回带透明度的颜色"""
    transparent_colors = get_colors_with_alpha(0.5)
    assert len(transparent_colors) == len(COLORS)
    for color in transparent_colors[:3]:
        assert color.startswith('rgba(')
        # 检查透明度部分
        parts = color[:-1].split(',')
        alpha = float(parts[-1].strip())
        assert alpha == 0.5
