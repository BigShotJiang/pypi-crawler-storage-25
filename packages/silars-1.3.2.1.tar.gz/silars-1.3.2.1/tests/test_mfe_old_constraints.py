import sys
sys.path.insert(0, '/tmp')

import polars as pl
from silars.alphalens import MFE

print('=' * 80)
print('旧版本 (1.2.10.13) MFE 约束条件测试')
print('=' * 80)

data = pl.read_csv('/tmp/data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')

mfe_params = {
    'weight_bias': -1.0,
    'weight_limit': 0.005,
    'tc_rate': 20e-4,
    'indust_bias': 0.02,
    'style_bias': {
        'SizeBarra': 0.2,
        'NLSizeBarra': 0.5,
    },
    'to_limit': -1.0,
    'components_ratio': -1.0,
}

MFE.set_params(**mfe_params, bm_w_name='bm_w')
weight_df = MFE.transform(data)

print(f'输出形状: {weight_df.shape}')
print(f'日期数: {weight_df["date"].n_unique()}')
avg_holdings = weight_df.group_by('date').agg(pl.len()).select(pl.col('len').mean())[0, 'len']
print(f'平均每日持仓: {avg_holdings:.1f}')
print(f'权重统计:')
print(f'  最小: {weight_df["target_weight"].min():.6f}')
print(f'  最大: {weight_df["target_weight"].max():.6f}')
print(f'  平均: {weight_df["target_weight"].mean():.6f}')

weight_df.write_csv('/tmp/mfe_old_result_with_constraints.csv')
print('\n✓ 结果已保存到 /tmp/mfe_old_result_with_constraints.csv')
