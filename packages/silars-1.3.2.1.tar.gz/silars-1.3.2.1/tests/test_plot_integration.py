# tests/test_plot_integration.py
# -*- coding: utf-8 -*-
"""Plot 模块集成测试"""
import pytest
import pandas as pd
import numpy as np


def test_theme_colors_consistency():
    """验证 Theme 颜色一致性"""
    from silars.plot.theme import COLORS
    from silars.plot.options import Options
    assert Options.colors == COLORS


def test_theme_layout_consistency():
    """验证 Theme 布局一致性"""
    from silars.plot.theme import LAYOUT
    from silars.plot.options import Options
    assert Options.layout == LAYOUT


def test_lines_function_uses_theme():
    """验证 lines 函数使用 Theme"""
    from silars.plot import lines
    from silars.plot.theme import COLORS

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    fig = lines(df)

    # 验证图表创建成功
    assert fig is not None


def test_bar_function_uses_theme():
    """验证 bar 函数使用 Theme"""
    from silars.plot import bar

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    fig = bar(df)

    assert fig is not None


def test_heatmap_function_uses_theme():
    """验证 heatmap 函数使用 Theme"""
    from silars.plot import heatmap

    data = pd.DataFrame(
        np.random.randn(5, 5),
        columns=['a', 'b', 'c', 'd', 'e']
    )
    fig = heatmap(data)

    assert fig is not None


def test_scatter_graph_uses_theme():
    """验证 ScatterGraph 使用 Theme"""
    from silars.plot import ScatterGraph

    df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
    graph = ScatterGraph(df)

    assert graph.figure is not None


def test_no_duplicate_layout_in_plotting():
    """验证 plotting.py 中无顶级 layout 定义"""
    import silars.plot.plotting as plotting

    # plotting.py 不应有顶级 _layout/_axis 定义
    assert not hasattr(plotting, '_layout')
    assert not hasattr(plotting, '_axis')


def test_no_duplicate_layout_in_alphalens():
    """验证 alphalens/plot.py 已删除（统一由 silars.plot 接管）"""
    import os
    # alphalens/plot.py 已删除，统一由 silars.plot 模块接管
    assert not os.path.exists("silars/alphalens/plot.py")


def test_no_duplicate_layout_in_report():
    """验证 alphalens/report.py 中无顶级 layout 定义"""
    import silars.alphalens.report as report

    # report.py 不应有顶级 _layout/_axis 变量
    assert not hasattr(report, '_layout')
    assert not hasattr(report, '_axis')


def test_report_imports_theme():
    """验证 report.py 正确导入 Theme"""
    from silars.alphalens.report import LAYOUT, AXIS
    from silars.plot.theme import LAYOUT as THEME_LAYOUT, AXIS as THEME_AXIS

    # report.py 应该引用 Theme 的配置
    assert LAYOUT == THEME_LAYOUT
    assert AXIS == THEME_AXIS
