# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/10
# Description: 对比新旧版本回测引擎的差异

import polars as pl
from silars.alphalens import bt

print("=" * 80)
print("回测引擎差异分析")
print("=" * 80)

# 读取测试数据
data = pl.read_csv("data/target_weight.csv")
print(f"\n✓ 加载数据: {data.shape}")
print(f"  列名: {data.columns}")
print(f"  日期范围: {data['date'].min()} -> {data['date'].max()}")
print(f"  股票数量: {data['asset'].n_unique()}")

# 使用新版本（atrs）回测
print("\n" + "=" * 80)
print("新版本回测结果 (ATRS)")
print("=" * 80)

bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
be_new = bt.transform(data)

print(f"pos 形状: {be_new.pos.shape}")
print(f"ret 形状: {be_new.ret.shape}")
print(f"\n持仓统计:")
print(f"  平均持仓数: {be_new.pos.group_by('date').agg(pl.count()).select(pl.col('count').mean())[0, 'count']:.1f}")
print(f"  日均换手率: {be_new.pos.group_by('date').agg(pl.col('change_weight').abs().sum()).select(pl.col('change_weight').mean())[0, 'change_weight']:.4%}")

print(f"\n收益统计:")
cumulative_ret = (1 + be_new.ret['long']).product() - 1
print(f"  累计收益: {cumulative_ret:.4%}")
print(f"  日均收益: {be_new.ret['long'].mean():.4%}")
print(f"  收益标准差: {be_new.ret['long'].std():.4%}")

if len(be_new.ret) > 1:
    sharpe = be_new.ret['long'].mean() / be_new.ret['long'].std() * (252 ** 0.5)
    print(f"  夏普比率: {sharpe:.4f}")

print(f"\n前5天持仓示例:")
print(be_new.pos.sort('date').head(20).select(['date', 'asset', 'beg_weight', 'target_weight', 'change_weight']))

print("\n" + "=" * 80)
print("✅ 分析完成")
print("=" * 80)
print("\n请提供旧版本的回测结果，我将进行对比分析")
