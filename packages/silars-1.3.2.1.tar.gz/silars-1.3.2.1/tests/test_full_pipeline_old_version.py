import sys
sys.path.insert(0, '/tmp')

import polars as pl
from silars.alphalens import MFE, bt

print('=' * 80)
print('旧版本 (1.2.10.13) 完整流程测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('/tmp/data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')

# MFE约束参数
mfe_params = {
    'weight_bias': -1.0,
    'weight_limit': 0.005,
    'tc_rate': 20e-4,
    'indust_bias': 0.02,
    'style_bias': {
        'SizeBarra': 0.2,
        'NLSizeBarra': 0.5,
    },
    'to_limit': -1.0,
    'components_ratio': -1.0,
}

print('\nMFE约束参数:')
for k, v in mfe_params.items():
    print(f'  {k}: {v}')

# MFE优化
print('\n运行MFE优化...')
MFE.set_params(**mfe_params, bm_w_name='bm_w')
weight_df = MFE.transform(data)

print(f'MFE完成')
print(f'  输出形状: {weight_df.shape}')
print(f'  平均每日持仓: {weight_df.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

# Join权重回原始数据
print('\nJoin权重回原始数据...')
bt_data = data.join(
    weight_df.select(['date', 'asset', 'time', 'target_weight']),
    on=['date', 'asset', 'time'],
    how='inner'
)
print(f'Join后数据: {bt_data.shape}')

# 回测
print('\n运行回测...')
bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4)
be = bt.transform(bt_data)

print(f'\n回测完成')
print(f'pos形状: {be.pos.shape}')
print(f'ret形状: {be.ret.shape}')

print(f'\nret前10行:')
print(be.ret.head(10))

print(f'\n收益统计:')
valid_ret = be.ret['long'].drop_nulls()
print(f'  null数量: {be.ret["long"].null_count()}')
print(f'  非零收益天数: {(valid_ret.abs() > 1e-6).sum()}')

if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
        
        max_dd = ((1 + valid_ret).cum_prod() / (1 + valid_ret).cum_prod().cum_max() - 1).min()
        print(f'  最大回撤: {max_dd:.4%}')
else:
    print('  ⚠ 无有效收益数据')

print(f'\n持仓统计:')
print(f'  平均持仓数: {be.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

# 保存结果
be.ret.write_csv('/tmp/backtest_result_old.csv')
print(f'\n✓ 回测结果已保存到 /tmp/backtest_result_old.csv')
