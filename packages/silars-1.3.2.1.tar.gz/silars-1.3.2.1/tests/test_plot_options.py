# tests/test_plot_options.py
# -*- coding: utf-8 -*-
import pytest
from silars.plot.options import Options

def test_options_colors_match_theme():
    """Options.colors 应与 Theme.COLORS 一致"""
    from silars.plot.theme import COLORS
    assert Options.colors == COLORS

def test_options_layout_match_theme():
    """Options.layout 应与 Theme.LAYOUT 一致"""
    from silars.plot.theme import LAYOUT
    assert Options.layout == LAYOUT

def test_options_table_header():
    """Options.Table.header 应存在"""
    assert hasattr(Options.Table, 'header')
    assert isinstance(Options.Table.header, dict)

def test_options_table_cell():
    """Options.Table.cell 应存在"""
    assert hasattr(Options.Table, 'cell')
    assert isinstance(Options.Table.cell, dict)

def test_get_colors_returns_list():
    """get_colors 应返回列表"""
    result = Options.get_colors(0.5)
    assert isinstance(result, list)
    assert len(result) > 0