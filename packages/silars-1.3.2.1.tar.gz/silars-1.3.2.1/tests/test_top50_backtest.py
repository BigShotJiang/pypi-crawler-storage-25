import polars as pl
from silars.alphalens import top_k, bt

print('=' * 80)
print('Top50 回测对比测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'日期范围: {data["date"].min()} -> {data["date"].max()}')
print(f'股票数量: {data["asset"].n_unique()}')

# Top50选股
print('\n运行Top50选股...')
top_k.set_params(num=50)
weight_df = top_k.transform(data)
print(f'Top50完成')
print(f'  输出形状: {weight_df.shape}')
print(f'  平均每日持仓: {weight_df.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

# Join权重回原始数据
print('\nJoin权重回原始数据...')
bt_data = data.join(
    weight_df.select(['date', 'asset', 'time', 'target_weight']),
    on=['date', 'asset', 'time'],
    how='inner'
)
print(f'Join后数据: {bt_data.shape}')

# 回测
print('\n运行回测...')
bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
be = bt.transform(bt_data)

print(f'\n回测完成')
print(f'pos形状: {be.pos.shape}')
print(f'ret形状: {be.ret.shape}')

print(f'\nret前10行:')
print(be.ret.head(10))

print(f'\n收益统计:')
valid_ret = be.ret['long'].drop_nulls()
print(f'  null数量: {be.ret["long"].null_count()}')
print(f'  非零收益天数: {(valid_ret.abs() > 1e-6).sum()}')

if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
        
        max_dd = ((1 + valid_ret).cum_prod() / (1 + valid_ret).cum_prod().cum_max() - 1).min()
        print(f'  最大回撤: {max_dd:.4%}')
else:
    print('  ⚠ 无有效收益数据')

print(f'\n持仓统计:')
print(f'  平均持仓数: {be.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')
print(f'  pos前10行:')
print(be.pos.sort('date').head(10).select(['date', 'asset', 'beg_weight', 'target_weight', 'change_weight']))
