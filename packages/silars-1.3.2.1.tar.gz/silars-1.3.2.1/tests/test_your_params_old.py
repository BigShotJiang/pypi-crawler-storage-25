import sys
sys.path.insert(0, '/tmp')

import polars as pl
from silars.alphalens import MFE, FactorStrategy, bt

print('=' * 80)
print('旧版本 (1.2.10.13) - 使用相同参数')
print('=' * 80)

data = pl.read_csv('/tmp/data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')

# 设置MFE参数（旧版本没有use_optimized和filtering_ratio）
print('\n设置MFE参数...')
MFE.set_params(
    bm_w_name='bm_w',  # 旧版本没有bm_w_852
    tc_rate=20e-4,
    components_ratio=-1,
    indust_bias=0.02,
    weight_limit=0.002,
    weight_bias=-1,
    style_bias={
        "SizeBarra": 0.2,
        "BetaBarra": -1,
        "ResVolBarra": -1,
        "NLSizeBarra": 0.5,
    },
    to_limit=-1,
)

print('创建FactorStrategy...')
strategy = FactorStrategy(weight_tr=MFE)

# 设置bt参数
bt.set_params(
    buy_fee=1e-4,
    sell_fee=6e-4,
    period='1d'
)

print('运行策略...')
result = strategy.run(data)

print(f'\n回测完成')
print(f'pos形状: {result.pos.shape}')
print(f'ret形状: {result.ret.shape}')

print(f'\nret前10行:')
print(result.ret.head(10))

print(f'\n收益统计:')
valid_ret = result.ret['long'].drop_nulls()
if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
        
        max_dd = ((1 + valid_ret).cum_prod() / (1 + valid_ret).cum_prod().cum_max() - 1).min()
        print(f'  最大回撤: {max_dd:.4%}')
else:
    print('  ⚠ 无有效收益数据')

print(f'\n持仓统计:')
print(f'  平均持仓数: {result.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

result.ret.write_csv('/tmp/backtest_your_params_old.csv')
print(f'\n✓ 结果已保存')
