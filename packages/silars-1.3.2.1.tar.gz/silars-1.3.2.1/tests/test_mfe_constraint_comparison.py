import polars as pl
from silars.alphalens import MFE

print('=' * 80)
print('MFE 约束条件对比测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'日期范围: {data["date"].min()} -> {data["date"].max()}')

# MFE约束参数
mfe_params = {
    'weight_bias': -1.0,             # 不限制权重偏离
    'weight_limit': 0.005,            # 个股权重上限 0.5%
    'tc_rate': 20e-4,                 # 交易成本率
    'indust_bias': 0.02,              # 行业偏离 0.02
    'style_bias': {                   # 风格约束
        'SizeBarra': 0.2,
        'NLSizeBarra': 0.5,
    },
    'to_limit': -1.0,                 # 不限制换手
    'components_ratio': -1.0,         # 不限制成分股比例
}

print('\n约束参数:')
for k, v in mfe_params.items():
    print(f'  {k}: {v}')

# ===== 测试新版本（原始模式）=====
print('\n' + '=' * 80)
print('新版本 MFE（原始模式，use_optimized=False）')
print('=' * 80)

MFE.set_params(**mfe_params, bm_w_name='bm_w', use_optimized=False)
weight_df_new_original = MFE.transform(data)

print(f'输出形状: {weight_df_new_original.shape}')
print(f'日期数: {weight_df_new_original["date"].n_unique()}')
avg_holdings = weight_df_new_original.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]
print(f'平均每日持仓: {avg_holdings:.1f}')
print(f'权重统计:')
print(f'  最小: {weight_df_new_original["target_weight"].min():.6f}')
print(f'  最大: {weight_df_new_original["target_weight"].max():.6f}')
print(f'  平均: {weight_df_new_original["target_weight"].mean():.6f}')

# ===== 测试新版本（优化模式）=====
print('\n' + '=' * 80)
print('新版本 MFE（优化模式，use_optimized=True, filtering_ratio=0.2）')
print('=' * 80)

MFE.set_params(**mfe_params, bm_w_name='bm_w', use_optimized=True, filtering_ratio=0.2)
weight_df_new_optimized = MFE.transform(data)

print(f'输出形状: {weight_df_new_optimized.shape}')
print(f'日期数: {weight_df_new_optimized["date"].n_unique()}')
avg_holdings = weight_df_new_optimized.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]
print(f'平均每日持仓: {avg_holdings:.1f}')
print(f'权重统计:')
print(f'  最小: {weight_df_new_optimized["target_weight"].min():.6f}')
print(f'  最大: {weight_df_new_optimized["target_weight"].max():.6f}')
print(f'  平均: {weight_df_new_optimized["target_weight"].mean():.6f}')

# ===== 对比两种模式 =====
print('\n' + '=' * 80)
print('对比分析')
print('=' * 80)

print(f'\n行数差异: {weight_df_new_optimized.shape[0] - weight_df_new_original.shape[0]}')
print(f'持仓数差异: {avg_holdings - weight_df_new_original.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

# 检查选股重叠度
common_dates = set(weight_df_new_original['date'].unique()) & set(weight_df_new_optimized['date'].unique())
jaccard_scores = []

for date in sorted(common_dates):
    stocks_original = set(weight_df_new_original.filter(pl.col('date') == date)['asset'].to_list())
    stocks_optimized = set(weight_df_new_optimized.filter(pl.col('date') == date)['asset'].to_list())
    
    if len(stocks_original) > 0 and len(stocks_optimized) > 0:
        intersection = len(stocks_original & stocks_optimized)
        union = len(stocks_original | stocks_optimized)
        jaccard = intersection / union if union > 0 else 0
        jaccard_scores.append(jaccard)

if jaccard_scores:
    print(f'\n选股重叠度 (Jaccard):')
    print(f'  平均: {sum(jaccard_scores) / len(jaccard_scores):.1%}')
    print(f'  最小: {min(jaccard_scores):.1%}')
    print(f'  最大: {max(jaccard_scores):.1%}')

# 保存结果
weight_df_new_original.write_csv('/tmp/mfe_new_original.csv')
weight_df_new_optimized.write_csv('/tmp/mfe_new_optimized.csv')
print(f'\n✓ 结果已保存')
print(f'  原始模式: /tmp/mfe_new_original.csv')
print(f'  优化模式: /tmp/mfe_new_optimized.csv')
