import polars as pl
from silars.alphalens import MFE, bt

print('=' * 80)
print('完整回测流程对比')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'列名: {data.columns}')

# MFE优化
print('\n运行MFE优化...')
MFE.set_params(
    weight_bias=-1.0,
    indust_bias=-1.0,
    style_bias=-1.0,
    weight_limit=-1.0,
    to_limit=-1.0,
    components_ratio=-1.0,
    tc_rate=20e-4,
    bm_w_name='bm_w',
    use_optimized=True,
    filtering_ratio=0.2
)

weight_df = MFE.transform(data)
print(f'MFE完成: {weight_df.shape}')
print(f'MFE输出列名: {weight_df.columns}')

# 关键步骤：将MFE输出的权重join回原始数据
print('\nJoin权重回原始数据...')
bt_data = data.join(
    weight_df.select(['date', 'asset', 'time', 'target_weight']),
    on=['date', 'asset', 'time'],
    how='inner'
)
print(f'Join后数据: {bt_data.shape}')
print(f'Join后列名: {bt_data.columns}')

# 回测
print('\n运行回测...')
bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
be = bt.transform(bt_data)

print(f'回测完成')
print(f'pos形状: {be.pos.shape}')
print(f'ret形状: {be.ret.shape}')

cumulative_ret = (1 + be.ret['long']).product() - 1
print(f'\n累计收益: {cumulative_ret:.4%}')
print(f'日均收益: {be.ret["long"].mean():.4%}')

if len(be.ret) > 1:
    sharpe = be.ret['long'].mean() / be.ret['long'].std() * (252 ** 0.5)
    print(f'夏普比率: {sharpe:.4f}')
    
    max_dd = ((1 + be.ret['long']).cumprod() / (1 + be.ret['long']).cumprod().cummax() - 1).min()
    print(f'最大回撤: {max_dd:.4%}')

print(f'\n平均持仓数: {be.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')
