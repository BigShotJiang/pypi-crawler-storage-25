import polars as pl
from silars.alphalens import MFE, FactorStrategy

print('=' * 80)
print('测试正确的 FactorStrategy 调用方式')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')

# 检查是否有 bm_w_852 列
if 'bm_w_852' not in data.columns:
    print('\n⚠️ 数据中没有 bm_w_852 列，使用 bm_w 代替')
    bm_w_name = 'bm_w'
else:
    bm_w_name = 'bm_w_852'

# ===== 正确的调用方式 =====
print('\n设置MFE参数...')
MFE.set_params(
    bm_w_name=bm_w_name,
    tc_rate=20e-4,
    filtering_ratio=1.0,
    use_optimized=True,  # 启用优化版本
    components_ratio=-1,
    indust_bias=0.02,
    weight_limit=0.002,
    weight_bias=-1,
    style_bias={
        "SizeBarra": 0.2,
        "BetaBarra": -1,
        "ResVolBarra": -1,
        "NLSizeBarra": 0.5,
    },
    to_limit=-1,
)

print('创建FactorStrategy...')
strategy = FactorStrategy(weight_tr=MFE)

# 设置bt参数
from silars.alphalens import bt
bt.set_params(
    buy_fee=1e-4,
    sell_fee=6e-4,
    period='1d',
    mode='rolling'
)

print('运行策略...')
result = strategy.run(data)

print(f'\n回测完成')
print(f'pos形状: {result.pos.shape}')
print(f'ret形状: {result.ret.shape}')

print(f'\nret前10行:')
print(result.ret.head(10))

print(f'\n收益统计:')
valid_ret = result.ret['long'].drop_nulls()
if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
        
        max_dd = ((1 + valid_ret).cum_prod() / (1 + valid_ret).cum_prod().cum_max() - 1).min()
        print(f'  最大回撤: {max_dd:.4%}')
else:
    print('  ⚠ 无有效收益数据')

print(f'\n持仓统计:')
print(f'  平均持仓数: {result.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')
