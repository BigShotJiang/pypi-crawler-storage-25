import polars as pl
from silars.alphalens import MFE, FactorStrategy, bt

print('=' * 80)
print('测试 silars 版本')
print('=' * 80)

import silars
print(f'silars版本: {silars.__version__}')
print(f'silars路径: {silars.__file__}')

# 读取数据
data = pl.read_csv('data.csv')
print(f'\n加载数据: {data.shape}')

# 将alpha_Archive001重命名为score（MFE需要score列）
if 'alpha_Archive001' in data.columns and 'score' not in data.columns:
    data = data.rename({'alpha_Archive001': 'score'})
    print(f'已将alpha_Archive001重命名为score')

# 设置MFE参数
print('\n设置MFE参数...')
MFE.set_params(
    bm_w_name='bm_w_852',
    tc_rate=20e-4,
    filtering_ratio=1.0,
    use_optimized=True,
    components_ratio=-1,
    indust_bias=0.02,
    weight_limit=0.002,
    weight_bias=-1,
    style_bias={
        "SizeBarra": 0.2,
        "BetaBarra": -1,
        "ResVolBarra": -1,
        "NLSizeBarra": 0.5,
    },
    to_limit=-1,
)

# 创建策略
print('创建FactorStrategy...')
strategy = FactorStrategy(weight_tr=MFE)

# 设置bt参数
bt.set_params(
    buy_fee=1e-4,
    sell_fee=6e-4,
    period='1d',
    mode='rolling'
)

# 运行策略
print('运行策略...')
result = strategy.run(data)

print(f'\n回测完成')
print(f'pos形状: {result.pos.shape}')
print(f'ret形状: {result.ret.shape}')

print(f'\n收益统计:')
valid_ret = result.ret['long'].drop_nulls()
if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
        
        max_dd = ((1 + valid_ret).cum_prod() / (1 + valid_ret).cum_prod().cum_max() - 1).min()
        print(f'  最大回撤: {max_dd:.4%}')
else:
    print('  ⚠ 无有效收益数据')

print(f'\n持仓统计:')
avg_holdings = result.pos.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]
print(f'  平均持仓数: {avg_holdings:.1f}')

# 检查MFE原始输出
print(f'\nMFE原始输出检查:')
weight_df = MFE.transform(data)
mfe_avg_holdings = weight_df.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]
print(f'  MFE平均持仓: {mfe_avg_holdings:.1f}')
print(f'  pos与MFE持仓差异: {avg_holdings - mfe_avg_holdings:.1f}')
