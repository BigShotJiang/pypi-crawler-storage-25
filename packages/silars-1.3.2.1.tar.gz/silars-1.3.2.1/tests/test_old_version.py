import polars as pl
from silars.alphalens import MFE, bt

print('=' * 80)
print('旧版本 (1.2.10.13) 完整回测测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'列名: {data.columns}')

# 检查是否有价格数据
price_fields = ['price', 'close', 'prev_close', 'open']
has_price = all(f in data.columns for f in price_fields)
print(f'包含价格数据: {has_price}')

if not has_price:
    missing = [f for f in price_fields if f not in data.columns]
    print(f'缺少字段: {missing}')
    print('\n无法执行回测，需要包含价格数据的文件')
else:
    # MFE优化
    print('\n运行MFE优化...')
    MFE.set_params(
        weight_bias=-1.0,
        indust_bias=-1.0,
        style_bias=-1.0,
        weight_limit=-1.0,
        to_limit=-1.0,
        components_ratio=-1.0,
        tc_rate=20e-4,
        bm_w_name='bm_w'
    )
    
    weight_df = MFE.transform(data)
    print(f'MFE完成: {weight_df.shape}')
    
    # 回测
    print('\n运行回测...')
    bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
    be = bt.transform(weight_df)
    
    print(f'回测完成')
    print(f'pos形状: {be.pos.shape}')
    print(f'ret形状: {be.ret.shape}')
    
    cumulative_ret = (1 + be.ret['long']).product() - 1
    print(f'\n累计收益: {cumulative_ret:.4%}')
    
    if len(be.ret) > 1:
        sharpe = be.ret['long'].mean() / be.ret['long'].std() * (252 ** 0.5)
        print(f'夏普比率: {sharpe:.4f}')
