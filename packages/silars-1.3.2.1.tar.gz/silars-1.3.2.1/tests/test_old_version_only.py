import polars as pl
from silars.alphalens import MFE, bt

print('=' * 80)
print('旧版本 (1.2.10.13) 回测测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'日期范围: {data["date"].min()} -> {data["date"].max()}')

# MFE优化（旧版本没有use_optimized参数）
print('\n运行MFE优化...')
MFE.set_params(
    weight_bias=-1.0,
    indust_bias=-1.0,
    style_bias=-1.0,
    weight_limit=-1.0,
    to_limit=-1.0,
    components_ratio=-1.0,
    tc_rate=20e-4,
    bm_w_name='bm_w'
)

weight_df = MFE.transform(data)
print(f'MFE完成: {weight_df.shape}')
print(f'平均每日持仓: {weight_df.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

# Join权重回原始数据
print('\nJoin权重回原始数据...')
bt_data = data.join(
    weight_df.select(['date', 'asset', 'time', 'target_weight']),
    on=['date', 'asset', 'time'],
    how='inner'
)
print(f'Join后数据: {bt_data.shape}')

# 回测
print('\n运行回测...')
bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4)
be = bt.transform(bt_data)

print(f'\n回测完成')
print(f'pos形状: {be.pos.shape}')
print(f'ret形状: {be.ret.shape}')

print(f'\nret前10行:')
print(be.ret.head(10))

print(f'\n收益统计:')
print(f'  null数量: {be.ret["long"].null_count()}')
print(f'  非零收益天数: {(be.ret["long"].abs() > 1e-6).sum()}')

# 计算累计收益
valid_ret = be.ret['long'].drop_nulls()
if len(valid_ret) > 0:
    cumulative_ret = (1 + valid_ret).product() - 1
    print(f'  累计收益: {cumulative_ret:.4%}')
    print(f'  日均收益: {valid_ret.mean():.4%}')
    
    if valid_ret.std() > 0:
        sharpe = valid_ret.mean() / valid_ret.std() * (252 ** 0.5)
        print(f'  夏普比率: {sharpe:.4f}')
else:
    print('  无有效收益数据')

print(f'\n持仓统计:')
print(f'  pos前10行:')
print(be.pos.sort('date').head(10).select(['date', 'asset', 'beg_weight', 'target_weight', 'change_weight']))
