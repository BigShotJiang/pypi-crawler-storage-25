import polars as pl
from silars.alphalens import MFE

print('=' * 80)
print('MFE 旧版本 (1.2.10.13) 测试')
print('=' * 80)

# 读取数据
data = pl.read_csv('data/mfe_prepare_data.csv')
print(f'\n加载数据: {data.shape}')
print(f'日期范围: {data["date"].min()} -> {data["date"].max()}')

# 运行MFE
print('\n运行MFE优化...')
MFE.set_params(
    weight_bias=-1.0,
    indust_bias=-1.0,
    style_bias=-1.0,
    weight_limit=-1.0,
    to_limit=-1.0,
    components_ratio=-1.0,
    tc_rate=20e-4,
    bm_w_name='bm_w'
)

weight_df = MFE.transform(data)
print(f'MFE完成')
print(f'  输出形状: {weight_df.shape}')
print(f'  日期数: {weight_df["date"].n_unique()}')
print(f'  平均每日持仓: {weight_df.group_by("date").agg(pl.len()).select(pl.col("len").mean())[0, "len"]:.1f}')

print(f'\n权重统计:')
print(f'  最小: {weight_df["target_weight"].min():.6f}')
print(f'  最大: {weight_df["target_weight"].max():.6f}')
print(f'  平均: {weight_df["target_weight"].mean():.6f}')

print(f'\n前10行:')
print(weight_df.sort('date').head(10))

# 保存结果
weight_df.write_csv('/tmp/mfe_old_result.csv')
print(f'\n✓ 结果已保存到 /tmp/mfe_old_result.csv')
