# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/10
# Description: 完整流程对比 - 因子数据 -> MFE -> BT

import polars as pl
from silars.alphalens import MFE, bt

print("=" * 80)
print("完整回测流程对比分析")
print("=" * 80)

# 读取MFE准备数据
data = pl.read_csv("data/mfe_prepare_data.csv")
print(f"\n✓ 加载数据: {data.shape}")
print(f"  列名: {data.columns}")
print(f"  日期范围: {data['date'].min()} -> {data['date'].max()}")
print(f"  股票数量: {data['asset'].n_unique()}")

# 检查必要字段
required_fields = ['date', 'asset', 'score', 'bm_w']
missing = [f for f in required_fields if f not in data.columns]
if missing:
    print(f"  ❌ 缺少字段: {missing}")
else:
    print(f"  ✓ 包含所有必要字段")

# ===== 步骤1: MFE优化 =====
print("\n" + "=" * 80)
print("步骤1: MFE组合优化")
print("=" * 80)

MFE.set_params(
    weight_bias=-1.0,
    indust_bias=-1.0,
    style_bias=-1.0,
    weight_limit=-1.0,
    to_limit=-1.0,
    components_ratio=-1.0,
    tc_rate=20e-4,
    bm_w_name="bm_w",
    use_optimized=True,  # 使用优化版本
    filtering_ratio=0.2
)

print("运行MFE优化...")
weight_df = MFE.transform(data)
print(f"✓ MFE完成")
print(f"  权重DataFrame形状: {weight_df.shape}")
print(f"  日期数量: {weight_df['date'].n_unique()}")
print(f"  平均每日持仓数: {weight_df.group_by('date').agg(pl.count()).select(pl.col('count').mean())[0, 'count']:.1f}")

# 准备回测数据
# 需要添加价格相关字段
print("\n检查回测所需字段...")
bt_required = ['price', 'close', 'prev_close', 'open']
bt_missing = [f for f in bt_required if f not in weight_df.columns]
if bt_missing:
    print(f"  ⚠ 缺少回测字段: {bt_missing}")
    print(f"  提示: mfe_prepare_data.csv 可能不包含价格数据")
    print(f"  当前可用字段: {weight_df.columns}")
else:
    print(f"  ✓ 包含所有回测字段")

# 如果有价格数据，继续回测
if not bt_missing:
    # ===== 步骤2: 回测 =====
    print("\n" + "=" * 80)
    print("步骤2: 回测执行 (ATRS引擎)")
    print("=" * 80)
    
    bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
    be = bt.transform(weight_df)
    
    print(f"✓ 回测完成")
    print(f"  pos 形状: {be.pos.shape}")
    print(f"  ret 形状: {be.ret.shape}")
    
    print(f"\n持仓统计:")
    avg_holdings = be.pos.group_by('date').agg(pl.count()).select(pl.col('count').mean())[0, 'count']
    print(f"  平均持仓数: {avg_holdings:.1f}")
    
    if 'change_weight' in be.pos.columns:
        daily_turnover = be.pos.group_by('date').agg(pl.col('change_weight').abs().sum())
        avg_turnover = daily_turnover.select(pl.col('change_weight').mean())[0, 'change_weight']
        print(f"  日均换手率: {avg_turnover:.4%}")
    
    print(f"\n收益统计:")
    cumulative_ret = (1 + be.ret['long']).product() - 1
    print(f"  累计收益: {cumulative_ret:.4%}")
    print(f"  日均收益: {be.ret['long'].mean():.4%}")
    print(f"  收益标准差: {be.ret['long'].std():.4%}")
    
    if len(be.ret) > 1:
        sharpe = be.ret['long'].mean() / be.ret['long'].std() * (252 ** 0.5)
        print(f"  夏普比率: {sharpe:.4f}")
        
        max_dd = ((1 + be.ret['long']).cumprod() / (1 + be.ret['long']).cumprod().cummax() - 1).min()
        print(f"  最大回撤: {max_dd:.4%}")
    
    print(f"\n前5天持仓示例:")
    print(be.pos.sort('date').head(15).select(['date', 'asset', 'beg_weight', 'target_weight', 'change_weight']))
    
    print("\n" + "=" * 80)
    print("✅ 完整流程分析完成")
    print("=" * 80)
    print("\n请提供旧版本的回测结果进行对比")
else:
    print("\n" + "=" * 80)
    print("⚠ 无法进行回测")
    print("=" * 80)
    print("mfe_prepare_data.csv 不包含价格数据，无法执行回测")
    print("\nMFE优化结果已生成，可以查看权重分布")
    print(f"\n权重统计:")
    print(f"  最小权重: {weight_df['target_weight'].min():.6f}")
    print(f"  最大权重: {weight_df['target_weight'].max():.6f}")
    print(f"  平均权重: {weight_df['target_weight'].mean():.6f}")
