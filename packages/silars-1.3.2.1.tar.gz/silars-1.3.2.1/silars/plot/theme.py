# silars/plot/theme.py
# -*- coding: utf-8 -*-
"""
统一主题配置 - Plot 模块样式单一来源
"""
from matplotlib.colors import to_rgba

# 颜色板 - 唯一颜色定义
COLORS = [
    'rgba(255, 99, 132, 1)',   # 红色
    'rgba(54, 162, 235, 1)',    # 蓝色
    'rgba(255, 193, 7, 1)',    # 黄色
    'rgba(140, 86, 75, 1)',     # 棕色
    'rgba(153, 102, 255, 1)',  # 紫色
    'rgba(227, 119, 194, 1)',  # 粉色
    'rgba(75, 192, 192, 1)',   # 绿色
    'rgba(255, 187, 120, 1)',  # 橙色
    *[f"rgba({int(r * 255)}, {int(g * 255)}, {int(b * 255)}, {int(a)})"
      for r, g, b, a in [to_rgba(c) for c in (
          "#5470c6 #91cc75 #fac858 #ee6666 #73c0de #3ba272 #fc8452 #9a60b4 #ea7ccc"
      ).split()]],
    'rgba(169, 169, 169, 1)',  # 深灰色
]

# 坐标轴样式
AXIS = dict(
    xaxis=dict(
        linecolor="black",
        linewidth=1,
        mirror=True,
        gridcolor='lightgrey',
        gridwidth=1,
        griddash='dot',
        showspikes=True,
        spikemode='across',
        spikecolor='black',
        spikethickness=1.5,
        spikedash='dot',
        tickformat="%Y-%m-%d"
    ),
    yaxis=dict(
        linecolor="black",
        linewidth=1,
        mirror=True,
        gridcolor='lightgrey',
        gridwidth=1.5,
        griddash='dot',
        showspikes=True,
        spikemode='across',
        spikecolor='black',
        spikethickness=1,
        spikedash='dot',
    ),
)

# Plotly Layout 基础配置
LAYOUT = dict(
    template='gridon',
    hovermode='x unified',
    hoverlabel=dict(bgcolor='rgba(255, 255, 255, 0.5)'),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1,
        bordercolor='lightgrey',
        borderwidth=1,
        bgcolor='rgba(255, 255, 255, 0.8)',
    ),
    height=500,
    **AXIS,
)

# 表格样式
TABLE = dict(
    header=dict(
        font=dict(color="black", size=12),
        fill_color='gold',
        align='center',
        line_color='darkslategray',
    ),
    cell=dict(
        align='center',
        line_color='darkslategray',
    ),
)


def get_colors_with_alpha(alpha: float) -> list:
    """返回带透明度的颜色列表"""
    return [f"{c[:-2]}{alpha})" for c in COLORS]


def merge_layout(**kwargs) -> dict:
    """合并自定义配置与基础布局"""
    result = dict(LAYOUT)
    result.update(kwargs)
    return result
