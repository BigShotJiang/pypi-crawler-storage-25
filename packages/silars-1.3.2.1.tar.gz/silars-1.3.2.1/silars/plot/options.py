# silars/plot/options.py
# -*- coding: utf-8 -*-
"""
绘图配置选项 - 保留向后兼容，引用 Theme
"""

from matplotlib.colors import to_rgba
from pyecharts import options as opts

# 从 Theme 导入统一配置
from .theme import COLORS, LAYOUT, TABLE, get_colors_with_alpha


class Options:
    # 颜色配置 - 引用 Theme
    colors = COLORS

    # layout plotly - 引用 Theme
    layout = LAYOUT

    class Table:
        # 表头设置 - 引用 Theme
        header = TABLE['header']
        # 单元格配置 - 引用 Theme
        cell = TABLE['cell']

    @staticmethod
    def get_colors(alpha):
        """更改透明度"""
        return get_colors_with_alpha(alpha)

    # echarts 悬停框样式 - 保留 ECharts 特有配置
    echarts_opts = dict(
        tooltip_opts=opts.TooltipOpts(
            trigger="axis",
            background_color="rgba(255, 255, 255, 0.5)",
            border_width=1,
            axis_pointer_type="cross",
            textstyle_opts=opts.TextStyleOpts(color="black")
        ),
        toolbox_opts=opts.ToolboxOpts(
            is_show=True,
        ),
        datazoom_opts=[
            opts.DataZoomOpts(type_="inside", range_start=0, range_end=100),
            opts.DataZoomOpts(type_="slider", range_start=0, range_end=100)
        ],
    )

    # 悬停十字光标样式
    axispointer_opts = dict(
        axispointer_opts=opts.AxisPointerOpts(
            is_show=True,
            linestyle_opts=opts.LineStyleOpts(
                type_="dashed",
                width=2
            )
        ),
    )

    @staticmethod
    def get_echarts_options(xaxis_name: str = None, yaxis_name: str = None, title: str = None, hidden: list = None):
        default_opts = dict()
        x_axis = {k: v for k, v in Options.axispointer_opts.items()}
        if xaxis_name is not None:
            x_axis["name"] = xaxis_name
        default_opts["xaxis_opts"] = opts.AxisOpts(**x_axis)
        y_axis = {k: v for k, v in Options.axispointer_opts.items()}
        if yaxis_name is not None:
            y_axis["name"] = yaxis_name
        default_opts["yaxis_opts"] = opts.AxisOpts(**y_axis)
        default_opts.update(Options.echarts_opts)
        if title is not None:
            default_opts["title_opts"] = opts.TitleOpts(title=title)
        if hidden is not None:
            default_opts["legend_opts"] = opts.LegendOpts(selected_map={n: False for n in hidden})
        return default_opts