# -*- coding: utf-8 -*-
"""
---------------------------------------------
Created on 2024/12/9 下午3:06
@author: ZhangYundi
@email: yundi.xxii@outlook.com
---------------------------------------------
"""

from .options import Options
from .plotting import (
    table,
    distplot,
    bar,
    violin,
    lines,
    nv_plot,
    nvs_plot,
    signal_plot,
    heatmap
)
from .graph import (
    BaseGraph,
    ScatterGraph,
    BarGraph,
    DistplotGraph,
    HeatmapGraph,
    HistogramGraph,
    SubplotsGraph,
)

__all__ = [
    # Theme 配置
    "Options",
    # 函数式 API
    "table",
    "distplot",
    "bar",
    "violin",
    "lines",
    "nv_plot",
    "nvs_plot",
    "signal_plot",
    "heatmap",
    # 类式 API
    "BaseGraph",
    "ScatterGraph",
    "BarGraph",
    "DistplotGraph",
    "HeatmapGraph",
    "HistogramGraph",
    "SubplotsGraph",
]
