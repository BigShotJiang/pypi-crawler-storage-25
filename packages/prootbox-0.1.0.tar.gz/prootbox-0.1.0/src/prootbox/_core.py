"""Core implementation: downloads, rootfs patching, proot invocation."""
import json
import os
import platform
import shlex
import shutil
import signal
import subprocess as sp
import tarfile
import tempfile
import time
import urllib.request


ARCH_MAP = {
    "x86_64": "x86_64",
    "amd64": "x86_64",
    "aarch64": "arm64",
    "arm64": "arm64",
}

RELEASE_BASE = "https://github.com/ssbagpcm/linux/releases/download/squashfs"

DISTROS = {
    "debian": "debian-trixie",
    "alpine": "alpine-23",
}
DEFAULT_DISTRO = "debian"

STORE_DIRNAME = "machines"
SESSIONS_DIRNAME = "sessions"

HOOK_MARKER = "# __prootbox_hook_v2__"
SHELL_HOOK = HOOK_MARKER + """
if [ -d "$HOME/.local/bin" ]; then PATH="$HOME/.local/bin:$PATH"; fi
if command -v sudo >/dev/null 2>&1; then
    sudo_filter(){ command sudo "$@" 2>&1 | grep -v "unable to send audit message" >&2; }
    alias sudo='sudo_filter'
fi
"""


class ProotboxError(Exception):
    """Raised for user-visible prootbox failures."""


def _workdir():
    """All prootbox state lives under the current working directory."""
    return os.getcwd()


def get_arch():
    m = platform.machine()
    if m not in ARCH_MAP:
        raise ProotboxError("unsupported architecture: " + m)
    return ARCH_MAP[m]


def _base_dir(distro):
    return os.path.join(_workdir(), "base-" + distro)


def _proot_bin(arch):
    return os.path.join(_workdir(), "proot-" + arch)


def _store_dir():
    return os.path.join(_workdir(), STORE_DIRNAME)


def _sessions_dir():
    return os.path.join(_workdir(), SESSIONS_DIRNAME)


def _machine_path(name):
    return os.path.join(_store_dir(), name)


def _session_path(name):
    return os.path.join(_sessions_dir(), name)


def _proot_url(arch):
    return RELEASE_BASE + "/proot-v5.3.0-" + arch + "-static"


def _image_url(distro, arch):
    return RELEASE_BASE + "/" + DISTROS[distro] + "-" + arch + ".tar.xz"


def _log(msg):
    print(msg)


def _download(url, dst):
    """Atomic download: writes to dst.part, renames on success."""
    if os.path.exists(dst):
        return
    _log("[+] " + os.path.basename(dst))
    tmp = dst + ".part"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
        with urllib.request.urlopen(req) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f, length=1 << 20)
        os.chmod(tmp, 0o755)
        os.rename(tmp, dst)
    except BaseException:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise


def _write_safe(path, content):
    """Write, breaking hardlinks so we don't mutate shared inodes."""
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    if os.path.lexists(path):
        os.unlink(path)
    with open(path, "w") as f:
        f.write(content)


def _read_or_empty(path):
    if not os.path.isfile(path):
        return ""
    with open(path) as f:
        return f.read()


def _fix(root):
    """Patch a rootfs so it runs cleanly under proot. Idempotent."""
    resolv = os.path.join(root, "etc", "resolv.conf")
    _write_safe(resolv, "nameserver 1.1.1.1\n")
    try:
        os.chmod(resolv, 0o644)
    except OSError:
        pass

    passwd = os.path.join(root, "etc", "passwd")
    c = _read_or_empty(passwd)
    if c:
        nc = c.replace("/bin/bash", "/bin/sh")
        if nc != c:
            _write_safe(passwd, nc)

    sudoers = os.path.join(root, "etc", "sudoers.d", "proot")
    sudoers_content = "Defaults !requiretty\nDefaults !use_pty\n"
    if _read_or_empty(sudoers) != sudoers_content:
        _write_safe(sudoers, sudoers_content)
        try:
            os.chmod(sudoers, 0o440)
        except OSError:
            pass

    apt_conf = os.path.join(root, "etc", "apt", "apt.conf.d", "99-prootbox")
    apt_content = (
        'APT::Sandbox::User "root";\n'
        'Acquire::AllowInsecureRepositories "false";\n'
        'Dpkg::Use-Pty "0";\n'
    )
    if os.path.isdir(os.path.join(root, "etc", "apt")) and _read_or_empty(apt_conf) != apt_content:
        _write_safe(apt_conf, apt_content)

    for rc_name in (".bashrc", ".profile"):
        rc = os.path.join(root, "root", rc_name)
        existing = _read_or_empty(rc)
        if HOOK_MARKER not in existing:
            tail = "" if (not existing or existing.endswith("\n")) else "\n"
            _write_safe(rc, existing + tail + SHELL_HOOK)


def _ensure_base(distro, arch):
    root = _base_dir(distro)
    if os.path.isdir(os.path.join(root, "bin")):
        return root
    _log("[+] " + DISTROS[distro] + " " + arch)
    tar = os.path.join(_workdir(), DISTROS[distro] + "-" + arch + ".tar.xz")
    _download(_image_url(distro, arch), tar)
    _log("[*] extracting...")
    os.makedirs(root, exist_ok=True)
    with tarfile.open(tar, "r:xz") as tf_:
        try:
            tf_.extractall(root, filter="tar")
        except TypeError:
            tf_.extractall(root)
    os.remove(tar)
    rf = os.path.join(root, "rootfs")
    if os.path.isdir(rf) and not os.path.exists(os.path.join(root, "bin")):
        for n in os.listdir(rf):
            shutil.move(os.path.join(rf, n), os.path.join(root, n))
        shutil.rmtree(rf, ignore_errors=True)
    _fix(root)
    return root


def _ensure_proot(arch):
    path = _proot_bin(arch)
    _download(_proot_url(arch), path)
    return path


PROOT_BINDS = ["-w", "/root", "-b", "/dev", "-b", "/proc", "-b", "/sys"]


_uts_support = None


def _can_fake_hostname():
    global _uts_support
    if _uts_support is not None:
        return _uts_support
    try:
        r = sp.run(
            ["unshare", "-Uur", "--uts", "--", "true"],
            stdout=sp.DEVNULL,
            stderr=sp.DEVNULL,
            timeout=2,
        )
        _uts_support = r.returncode == 0
    except (OSError, sp.TimeoutExpired):
        _uts_support = False
    return _uts_support


def _pick_shell(root):
    if os.path.exists(os.path.join(root, "bin", "bash")):
        return ["/bin/bash", "--noprofile", "--rcfile", "/root/.bashrc", "-i"]
    return ["/bin/sh", "-l"]


def _run_interactive_shell(proot_bin, work, user, hostname):
    _write_safe(os.path.join(work, "etc", "hostname"), hostname + "\n")
    hosts = os.path.join(work, "etc", "hosts")
    existing = _read_or_empty(hosts)
    if "127.0.1.1" not in existing or hostname not in existing:
        tail = "" if (not existing or existing.endswith("\n")) else "\n"
        _write_safe(hosts, existing + tail + "127.0.1.1\t" + hostname + "\n")

    env = {
        "PROOT_NO_SECCOMP": "1",
        "HOME": "/root",
        "TERM": os.environ.get("TERM", "xterm-256color"),
        "HOSTNAME": hostname,
        "USER": user,
        "LOGNAME": user,
        "ENV": "/root/.profile",
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    }
    proot_cmd = (
        [os.path.abspath(proot_bin), "-r", os.path.abspath(work)]
        + PROOT_BINDS
        + ["-0"]
        + _pick_shell(work)
    )
    if _can_fake_hostname():
        inner = "hostname " + shlex.quote(hostname) + ' && exec "$@"'
        cmd = ["unshare", "-Uur", "--uts", "--", "sh", "-c", inner, "_"] + proot_cmd
    else:
        cmd = proot_cmd
    sp.run(cmd, env=env)


def _write_meta(root, distro, arch):
    meta = {"distro": distro, "arch": arch, "created": time.time()}
    with open(os.path.join(root, ".prootbox-meta"), "w") as f:
        json.dump(meta, f)


def _read_meta(root):
    p = os.path.join(root, ".prootbox-meta")
    if not os.path.isfile(p):
        return {}
    try:
        with open(p) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _pid_alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _validate_distro(distro):
    if distro not in DISTROS:
        raise ProotboxError(
            "unknown distro '" + distro + "' (choices: " + ", ".join(DISTROS) + ")"
        )


# ============================================================
# Public API
# ============================================================


def run_ephemeral(distro=DEFAULT_DISTRO):
    """Start an ephemeral sandbox. Deleted on exit."""
    _validate_distro(distro)
    arch = get_arch()
    proot_bin = _ensure_proot(arch)
    base = _ensure_base(distro, arch)
    work = tempfile.mkdtemp(prefix=DISTROS[distro] + "-", dir=_workdir())
    try:
        sp.run(["cp", "-alT", base, work], check=True)
        _fix(work)
        _log("[*] ephemeral (" + distro + ")")
        _run_interactive_shell(proot_bin, work, user="root", hostname="ephemeral")
    finally:
        shutil.rmtree(work, ignore_errors=True)


def create(name, distro=DEFAULT_DISTRO):
    """Create a persistent machine. Does not open a shell."""
    if not name:
        raise ProotboxError("name is required")
    _validate_distro(distro)
    arch = get_arch()
    proot_bin = _ensure_proot(arch)
    os.makedirs(_store_dir(), exist_ok=True)
    work = _machine_path(name)
    if os.path.isdir(work):
        raise ProotboxError("machine '" + name + "' already exists")
    base = _ensure_base(distro, arch)
    sp.run(["cp", "-alT", base, work], check=True)
    _fix(work)
    _write_meta(work, distro, arch)
    _log("[+] created " + name + " (" + distro + ")")


def attach(name):
    """Open an interactive shell in an existing machine."""
    if not name:
        raise ProotboxError("name is required")
    work = _machine_path(name)
    if not os.path.isdir(work):
        raise ProotboxError("machine '" + name + "' not found")
    arch = get_arch()
    proot_bin = _ensure_proot(arch)
    _fix(work)
    _log("[*] attach " + name)
    _run_interactive_shell(proot_bin, work, user="root", hostname=name)


def delete(name):
    """Remove a persistent machine."""
    if not name:
        raise ProotboxError("name is required")
    work = _machine_path(name)
    if not os.path.isdir(work):
        raise ProotboxError("machine '" + name + "' not found")
    shutil.rmtree(work, ignore_errors=True)
    _log("[-] " + name)


def exists(name):
    """Return True if a persistent machine with this name exists."""
    return bool(name) and os.path.isdir(_machine_path(name))


def list_machines():
    """Return a list of dicts: [{'name': ..., 'distro': ...}, ...]."""
    out = []
    store = _store_dir()
    if not os.path.isdir(store):
        return out
    for d in sorted(os.listdir(store)):
        p = _machine_path(d)
        if os.path.isdir(p):
            meta = _read_meta(p)
            out.append({"name": d, "distro": meta.get("distro", "?"),
                        "arch": meta.get("arch", "?")})
    return out


def session_start(name, machine=None):
    """Start a detached session running on `machine` (defaults to `name`)."""
    if not name:
        raise ProotboxError("name is required")
    if machine is None:
        machine = name
    if not exists(machine):
        raise ProotboxError("machine '" + machine + "' not found")
    arch = get_arch()
    proot_bin = _ensure_proot(arch)
    os.makedirs(_sessions_dir(), exist_ok=True)
    ses = _session_path(name)
    os.makedirs(ses, exist_ok=True)
    with open(os.path.join(ses, "info"), "w") as f:
        json.dump({"machine": machine, "start": time.time()}, f)

    pidfile = os.path.join(ses, "pid")
    try:
        os.unlink(pidfile)
    except OSError:
        pass

    wrapper = os.path.join(ses, "session.sh")
    with open(wrapper, "w") as f:
        f.write("#!/bin/sh\n")
        f.write("trap '' HUP\n")
        f.write("echo $$ > " + shlex.quote(os.path.abspath(pidfile)) + "\n")
        f.write(
            "exec {p} -r {r} -w / -b /dev -b /proc -b /sys -0 "
            "/bin/sh -c 'while true; do sleep 3600; done'\n".format(
                p=shlex.quote(os.path.abspath(proot_bin)),
                r=shlex.quote(os.path.abspath(_machine_path(machine))),
            )
        )
    os.chmod(wrapper, 0o755)

    log = os.path.join(ses, "log")
    with open(log, "wb") as logf:
        sp.Popen(["setsid", "-f", wrapper], stdout=logf, stderr=sp.STDOUT)

    deadline = time.time() + 5.0
    pid = None
    while time.time() < deadline:
        if os.path.isfile(pidfile):
            try:
                with open(pidfile) as f:
                    pid = int(f.read().strip())
                break
            except (OSError, ValueError):
                pass
        time.sleep(0.02)

    if pid is None:
        raise ProotboxError("session " + name + " failed to start (check " + log + ")")
    _log("[*] session " + name + " on " + machine + " started (pid " + str(pid) + ")")
    return pid


def session_attach(name):
    """Open an interactive shell on the machine backing this session."""
    if not name:
        raise ProotboxError("name is required")
    ses = _session_path(name)
    if not os.path.isdir(ses):
        raise ProotboxError("session '" + name + "' not found")
    info_f = os.path.join(ses, "info")
    if not os.path.isfile(info_f):
        raise ProotboxError("session info missing for '" + name + "'")
    with open(info_f) as f:
        d = json.load(f)
    machine = d.get("machine")
    if not exists(machine):
        raise ProotboxError("machine '" + str(machine) + "' not found")
    arch = get_arch()
    proot_bin = _ensure_proot(arch)
    _log("[*] exec shell on session " + name + " (machine=" + machine + ")")
    _run_interactive_shell(proot_bin, _machine_path(machine), user="root", hostname=name)


def session_stop(name):
    """Send SIGHUP to a detached session."""
    if not name:
        raise ProotboxError("name is required")
    pidfile = os.path.join(_session_path(name), "pid")
    if not os.path.isfile(pidfile):
        raise ProotboxError("no pid for session '" + name + "'")
    try:
        with open(pidfile) as f:
            pid = int(f.read().strip())
        os.kill(pid, signal.SIGHUP)
    except (OSError, ValueError) as e:
        raise ProotboxError("stop failed: " + str(e))
    _log("[*] stopped " + name)


def session_list():
    """Return a list of dicts: [{'name', 'machine', 'running'}]."""
    out = []
    sessions = _sessions_dir()
    if not os.path.isdir(sessions):
        return out
    for s in sorted(os.listdir(sessions)):
        info_f = os.path.join(sessions, s, "info")
        if not os.path.isfile(info_f):
            continue
        try:
            with open(info_f) as f:
                d = json.load(f)
        except (OSError, ValueError):
            continue
        running = False
        pidfile = os.path.join(sessions, s, "pid")
        try:
            with open(pidfile) as pf:
                running = _pid_alive(int(pf.read().strip()))
        except (OSError, ValueError):
            pass
        out.append({"name": s, "machine": d.get("machine", "?"), "running": running})
    return out
