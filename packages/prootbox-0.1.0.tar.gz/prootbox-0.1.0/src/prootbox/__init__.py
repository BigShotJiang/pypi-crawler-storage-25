"""prootbox — lightweight proot-based Linux sandboxes.

Ergonomic API:

    import prootbox as pb

    pb.create(pb.alpine("my-box"))     # persistent alpine machine
    pb.create(pb.debian("dev"))        # persistent debian machine
    pb.attach("my-box")                # open interactive shell
    pb.delete("my-box")                # remove

    pb.run(pb.ephemeral("debian"))     # throw-away debian sandbox
    pb.run(pb.ephemeral("alpine"))
    pb.run()                           # shortcut: ephemeral debian

Lower-level API (string-based):

    pb.create("my-box", distro="alpine")
    pb.run_ephemeral(distro="debian")
    pb.list_machines()                 # -> [{'name': ..., 'distro': ...}, ...]
    pb.session_start("sess1", machine="my-box")
    pb.session_attach("sess1")
    pb.session_stop("sess1")
    pb.session_list()

All state (proot binary, rootfs images, machines, sessions) lives in the
current working directory at the time these calls execute.
"""

from prootbox._core import (
    ProotboxError,
    attach,
    exists,
    list_machines,
    session_attach,
    session_list,
    session_start,
    session_stop,
)
from prootbox._core import create as _create_impl
from prootbox._core import delete as _delete_impl
from prootbox._core import run_ephemeral as _run_ephemeral_impl

__version__ = "0.1.0"


class _Box(object):
    """Descriptor returned by alpine()/debian()/ephemeral()."""

    __slots__ = ("name", "distro", "is_ephemeral")

    def __init__(self, name, distro, is_ephemeral=False):
        self.name = name
        self.distro = distro
        self.is_ephemeral = is_ephemeral

    def __repr__(self):
        kind = "ephemeral" if self.is_ephemeral else "persistent"
        return "<Box " + kind + " " + self.distro + " name=" + (self.name or "-") + ">"


def debian(name):
    """Build a descriptor for a debian machine: create(debian('mybox'))."""
    return _Box(name=name, distro="debian")


def alpine(name):
    """Build a descriptor for an alpine machine: create(alpine('mybox'))."""
    return _Box(name=name, distro="alpine")


def ephemeral(distro="debian"):
    """Build a descriptor for an ephemeral sandbox: run(ephemeral('alpine'))."""
    if not isinstance(distro, str):
        raise ProotboxError("ephemeral(distro) expects a string")
    return _Box(name=None, distro=distro, is_ephemeral=True)


def create(spec, distro=None):
    """Create a persistent machine.

    Accepts a descriptor (from alpine()/debian()) OR a raw name + distro kwarg.
        pb.create(pb.alpine("my-box"))
        pb.create("my-box", distro="alpine")
        pb.create("my-box")  # default: debian
    """
    if isinstance(spec, _Box):
        if spec.is_ephemeral:
            raise ProotboxError("create() needs a named box; use run() for ephemeral")
        if distro is not None and distro != spec.distro:
            raise ProotboxError("distro mismatch: " + spec.distro + " vs " + distro)
        return _create_impl(spec.name, distro=spec.distro)
    return _create_impl(spec, distro=distro or "debian")


def delete(spec):
    """Remove a persistent machine (accepts a name or a descriptor)."""
    if isinstance(spec, _Box):
        if spec.is_ephemeral or not spec.name:
            raise ProotboxError("delete() needs a named box")
        return _delete_impl(spec.name)
    return _delete_impl(spec)


def run(spec=None, distro=None):
    """Start an ephemeral sandbox.

        pb.run()                       # ephemeral debian
        pb.run(pb.ephemeral("alpine"))
        pb.run(distro="alpine")
        pb.run("alpine")               # shorthand
    """
    if spec is None:
        return _run_ephemeral_impl(distro=distro or "debian")
    if isinstance(spec, _Box):
        if not spec.is_ephemeral:
            raise ProotboxError("run() expects an ephemeral box; use attach() instead")
        return _run_ephemeral_impl(distro=spec.distro)
    if isinstance(spec, str):
        return _run_ephemeral_impl(distro=spec)
    raise ProotboxError("run() got unexpected arg: " + repr(spec))


run_ephemeral = _run_ephemeral_impl


__all__ = [
    "__version__",
    "ProotboxError",
    "debian",
    "alpine",
    "ephemeral",
    "create",
    "delete",
    "attach",
    "run",
    "run_ephemeral",
    "exists",
    "list_machines",
    "session_start",
    "session_attach",
    "session_stop",
    "session_list",
]
