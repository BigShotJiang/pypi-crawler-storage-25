"""CLI entrypoint: `prootbox` and `python3 -m prootbox`."""
import sys

from prootbox._core import (
    DEFAULT_DISTRO,
    DISTROS,
    ProotboxError,
)
from prootbox import (
    attach,
    create,
    delete,
    list_machines,
    run_ephemeral,
    session_attach,
    session_list,
    session_start,
    session_stop,
)


USAGE = """Usage: prootbox <command> [args]

Machines:
  run [--distro debian|alpine]      ephemeral sandbox
  list                              list persistent machines
  create <name> [--distro D]        create persistent machine
  attach <name>                     open shell in persistent machine
  delete <name>                     remove persistent machine

Sessions:
  session list                      list sessions
  session start <name> [<machine>]  start detached session
  session attach <name>             open shell on session's machine
  session stop <name>               send SIGHUP to session

  help                              show this message
"""


def _die(msg):
    sys.stderr.write(msg.rstrip() + "\n")
    sys.exit(1)


def _take_flag(args, flag):
    i = 0
    while i < len(args):
        a = args[i]
        if a == flag:
            if i + 1 >= len(args):
                _die("[!] " + flag + " needs a value")
            val = args[i + 1]
            del args[i:i + 2]
            return val
        if a.startswith(flag + "="):
            val = a[len(flag) + 1:]
            del args[i]
            return val
        i += 1
    return None


def _parse_distro(args):
    v = _take_flag(args, "--distro")
    if v is None:
        return DEFAULT_DISTRO
    if v not in DISTROS:
        _die("[!] unknown distro '" + v + "' (choices: " + ", ".join(DISTROS) + ")")
    return v


def _expect_name(args, cmd):
    if not args:
        _die("[!] " + cmd + " requires a NAME\n\n" + USAGE)
    return args[0]


def _no_extra(args, cmd):
    if args:
        _die("[!] " + cmd + ": unexpected arguments: " + " ".join(args) + "\n\n" + USAGE)


def _cmd_list():
    for m in list_machines():
        print(m["name"] + "\t" + m["distro"])


def _cmd_session_list():
    for s in session_list():
        status = "running" if s["running"] else "stopped"
        print("{}\t{}\t{}".format(s["name"], status, s["machine"]))


def _run_with_errors(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except ProotboxError as e:
        _die("[!] " + str(e))


def main():
    argv = sys.argv[1:]
    if not argv:
        sys.stdout.write(USAGE)
        return 0

    cmd = argv[0]
    rest = list(argv[1:])

    if cmd in ("help", "-h", "--help"):
        sys.stdout.write(USAGE)
        return 0
    if cmd == "list":
        _no_extra(rest, "list")
        _cmd_list()
        return 0
    if cmd == "delete":
        name = _expect_name(rest, "delete")
        _no_extra(rest[1:], "delete")
        _run_with_errors(delete, name)
        return 0
    if cmd == "run":
        distro = _parse_distro(rest)
        _no_extra(rest, "run")
        _run_with_errors(run_ephemeral, distro=distro)
        return 0
    if cmd == "create":
        distro = _parse_distro(rest)
        name = _expect_name(rest, "create")
        _no_extra(rest[1:], "create")
        _run_with_errors(create, name, distro=distro)
        return 0
    if cmd == "attach":
        name = _expect_name(rest, "attach")
        _no_extra(rest[1:], "attach")
        _run_with_errors(attach, name)
        return 0

    if cmd == "session":
        if not rest:
            _die("[!] session requires a subcommand (list|start|attach|stop)\n\n" + USAGE)
        sub = rest[0]
        sub_rest = rest[1:]
        if sub == "list":
            _no_extra(sub_rest, "session list")
            _cmd_session_list()
            return 0
        if sub == "stop":
            name = _expect_name(sub_rest, "session stop")
            _no_extra(sub_rest[1:], "session stop")
            _run_with_errors(session_stop, name)
            return 0
        if sub == "attach":
            name = _expect_name(sub_rest, "session attach")
            _no_extra(sub_rest[1:], "session attach")
            _run_with_errors(session_attach, name)
            return 0
        if sub == "start":
            name = _expect_name(sub_rest, "session start")
            machine = sub_rest[1] if len(sub_rest) >= 2 else None
            _no_extra(sub_rest[2:] if machine else sub_rest[1:], "session start")
            _run_with_errors(session_start, name, machine=machine)
            return 0
        _die("[!] unknown session subcommand '" + sub + "'\n\n" + USAGE)

    _die("[!] unknown command '" + cmd + "'\n\n" + USAGE)


if __name__ == "__main__":
    sys.exit(main())
