from __future__ import annotations

def normalize_tool_id(tool_id: str) -> str:
    aliases = {
        "run-javascript": "run_javascript",
        "runjavascript": "run_javascript",
        "local.run_javascript": "run_javascript",
        "local.read-file": "read_file",
        "local.read_file": "read_file",
        "read-file": "read_file",
        "call_ai_claude_code": "call_local_claude_code",
        "call_ai_codex": "call_local_codex",
        "local.call_ai_claude_code": "call_local_claude_code",
        "local.call_ai_codex": "call_local_codex",
        "local.call_local_codex": "call_local_codex",
        "local.call_local_claude_code": "call_local_claude_code",
    }
    return aliases.get(tool_id.strip(), tool_id.strip())


def is_local_tool(tool_id: str) -> bool:
    return normalize_tool_id(tool_id) in {
        "run_javascript",
        "read_file",
        "call_local_codex",
        "call_local_claude_code",
    }
