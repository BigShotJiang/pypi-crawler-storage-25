"""Memory service package."""
