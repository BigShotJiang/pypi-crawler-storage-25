"""notewise CLI package."""
