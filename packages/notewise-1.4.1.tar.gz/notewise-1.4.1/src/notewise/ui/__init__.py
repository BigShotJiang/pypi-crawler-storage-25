"""UI components for notewise."""
