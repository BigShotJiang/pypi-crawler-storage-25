"""AINL CLI package."""
