__copyright__ = "Copyright (c) 2026 Villu Ruusmann"
__license__ = "GNU Affero General Public License (AGPL) version 3.0"
__version__ = "0.4.0"
