# standard
import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.providers.responses import ResponsesEngine
from sunwaee.modules.gen.engine.types import (
    FileAttachment,
    Message,
    Role,
    StopReason,
    Tool,
    ToolCall,
)

_PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")

ENGINE = ResponsesEngine(model="gpt-5.4-mini", api_key="test-key")

DUMMY_TOOL = Tool(
    name="tasks",
    description="Manage tasks.",
    parameters={"type": "object", "properties": {}, "required": []},
)


### INPUT BUILDER


def test_build_input_user():
    items = ENGINE._build_input([Message(role=Role.USER, content="Hi")])
    assert items == [{"role": "user", "content": [{"type": "input_text", "text": "Hi"}]}]


def test_build_input_system():
    items = ENGINE._build_input([Message(role=Role.SYSTEM, content="You are Sun.")])
    assert items == [{"role": "system", "content": [{"type": "input_text", "text": "You are Sun."}]}]


def test_build_input_context_role():
    items = ENGINE._build_input([Message(role=Role.CONTEXT, content="dynamic header")])
    assert items == [
        {
            "role": "system",
            "content": [{"type": "input_text", "text": "<context>\ndynamic header\n</context>"}],
        }
    ]


def test_build_input_assistant_text():
    items = ENGINE._build_input([Message(role=Role.ASSISTANT, content="Hello")])
    assert items == [
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "Hello"}],
        }
    ]


def test_build_input_assistant_with_tool_calls():
    tc = ToolCall(id="call_abc", name="tasks", arguments={"action": "list"})
    items = ENGINE._build_input([Message(role=Role.ASSISTANT, content=None, tool_calls=[tc])])
    assert items == [
        {
            "type": "function_call",
            "call_id": "call_abc",
            "name": "tasks",
            "arguments": json.dumps({"action": "list"}),
        }
    ]


def test_build_input_assistant_with_content_and_tool_calls():
    tc = ToolCall(id="call_1", name="tasks", arguments={"a": 1})
    items = ENGINE._build_input([Message(role=Role.ASSISTANT, content="thinking out loud", tool_calls=[tc])])
    assert items[0]["type"] == "message"
    assert items[0]["content"][0]["text"] == "thinking out loud"
    assert items[1]["type"] == "function_call"
    assert items[1]["call_id"] == "call_1"


def test_build_input_tool_result():
    items = ENGINE._build_input([Message(role=Role.TOOL, content='{"ok": true}', tool_call_id="call_abc")])
    assert items == [{"type": "function_call_output", "call_id": "call_abc", "output": '{"ok": true}'}]


def test_build_input_tool_result_empty_content():
    items = ENGINE._build_input([Message(role=Role.TOOL, content=None, tool_call_id="call_abc")])
    assert items[0]["output"] == ""


def test_build_input_user_with_image_attachment():
    att = FileAttachment(data=_PNG, filename="photo.png")
    items = ENGINE._build_input([Message(role=Role.USER, content="Look at this", attachments=[att])])
    content = items[0]["content"]
    assert content[0]["type"] == "input_image"
    expected_url = f"data:image/png;base64,{base64.b64encode(_PNG).decode()}"
    assert content[0]["image_url"] == expected_url
    assert content[1] == {"type": "input_text", "text": "Look at this"}


def test_build_input_user_with_text_attachment():
    att = FileAttachment(data=b"hello", filename="notes.txt")
    items = ENGINE._build_input([Message(role=Role.USER, content="see file", attachments=[att])])
    content = items[0]["content"]
    assert content[0]["type"] == "input_text"
    assert '<file name="notes.txt">' in content[0]["text"]
    assert content[1] == {"type": "input_text", "text": "see file"}


def test_build_input_user_attachment_no_text():
    att = FileAttachment(data=b"hello", filename="notes.txt")
    items = ENGINE._build_input([Message(role=Role.USER, content=None, attachments=[att])])
    content = items[0]["content"]
    assert len(content) == 1
    assert '<file name="notes.txt">' in content[0]["text"]


def test_build_input_image_on_non_vision_model_raises():
    from sunwaee.modules.gen.engine.model import Model

    engine = ResponsesEngine(
        model="fake-text-only",
        api_key="k",
        provider="deepseek",
        model_info=Model(name="fake-text-only", display_name="Fake Text Only", provider="deepseek", supports_vision=False),
    )
    att = FileAttachment(data=_PNG, filename="photo.png")
    with pytest.raises(ValueError, match="does not support vision"):
        engine._build_input([Message(role=Role.USER, content="Hi", attachments=[att])])


### REASONING ECHO


def test_build_input_encrypted_reasoning_echoed_on_last_assistant_turn():
    """Prior Responses run — reasoning_signature is a JSON list of typed reasoning items."""
    reasoning_items = [{"type": "reasoning", "id": "rs_1", "encrypted_content": "ENC_BLOB", "summary": []}]
    m = Message(
        role=Role.ASSISTANT,
        content="answer",
        reasoning_content="summary text",
        reasoning_signature=json.dumps(reasoning_items),
    )
    items = ENGINE._build_input([m])
    assert items[0] == reasoning_items[0]
    assert items[1]["type"] == "message"
    assert items[1]["content"][0]["text"] == "answer"


def test_build_input_plain_text_reasoning_signature_dropped():
    """Non-Responses history (plain-text signature) is dropped — cannot be echoed
    as a typed reasoning item without encrypted_content."""
    m = Message(
        role=Role.ASSISTANT,
        content="answer",
        reasoning_content="thought",
        reasoning_signature="raw-plain-text",
    )
    items = ENGINE._build_input([m])
    assert all(i.get("type") != "reasoning" for i in items)
    assert items[0]["type"] == "message"


def test_build_input_malformed_signature_not_list_dropped():
    m = Message(
        role=Role.ASSISTANT,
        content="answer",
        reasoning_signature=json.dumps({"not": "a list"}),
    )
    items = ENGINE._build_input([m])
    assert all(i.get("type") != "reasoning" for i in items)


def test_build_input_signature_list_filters_non_reasoning_items():
    """Only items with type=='reasoning' are echoed, even in a well-formed list."""
    mixed = [
        {"type": "reasoning", "id": "rs_1", "encrypted_content": "A", "summary": []},
        {"type": "message", "content": [{"type": "output_text", "text": "stray"}]},
    ]
    m = Message(
        role=Role.ASSISTANT,
        content="answer",
        reasoning_signature=json.dumps(mixed),
    )
    items = ENGINE._build_input([m])
    reasoning_items = [i for i in items if i.get("type") == "reasoning"]
    assert len(reasoning_items) == 1
    assert reasoning_items[0]["id"] == "rs_1"


def test_build_input_reasoning_not_echoed_on_intermediate_assistant_turn():
    reasoning_items = [{"type": "reasoning", "id": "rs_1", "encrypted_content": "A", "summary": []}]
    msgs = [
        Message(role=Role.USER, content="Q1"),
        Message(
            role=Role.ASSISTANT,
            content="A1",
            reasoning_signature=json.dumps(reasoning_items),
        ),
        Message(role=Role.USER, content="Q2"),
        Message(role=Role.ASSISTANT, content="A2"),
    ]
    items = ENGINE._build_input(msgs)
    assert all(i.get("type") != "reasoning" for i in items)


### TOOLS


def test_build_tools_flat_shape():
    tools = ENGINE._build_tools([DUMMY_TOOL])
    assert tools == [
        {
            "type": "function",
            "name": "tasks",
            "description": "Manage tasks.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        }
    ]


### PAYLOAD


def test_build_payload_basic():
    payload = ENGINE._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["model"] == "gpt-5.4-mini"
    assert payload["max_output_tokens"] == ENGINE.max_tokens
    assert payload["store"] is False
    assert payload["include"] == ["reasoning.encrypted_content"]
    assert "reasoning" not in payload
    assert "tools" not in payload
    assert "prompt_cache_key" not in payload  # no system message → no cache key


def test_build_payload_system_message_sets_prompt_cache_key():
    import hashlib
    system_text = "You are a helpful assistant."
    payload = ENGINE._build_payload(
        [Message(role=Role.SYSTEM, content=system_text), Message(role=Role.USER, content="Hi")],
        tools=None,
    )
    expected_key = hashlib.sha256(system_text.encode()).hexdigest()[:32]
    assert payload["prompt_cache_key"] == expected_key


def test_build_payload_same_system_content_produces_same_cache_key():
    text = "Same system prompt."
    p1 = ENGINE._build_payload([Message(role=Role.SYSTEM, content=text), Message(role=Role.USER, content="A")], tools=None)
    p2 = ENGINE._build_payload([Message(role=Role.SYSTEM, content=text), Message(role=Role.USER, content="B")], tools=None)
    assert p1["prompt_cache_key"] == p2["prompt_cache_key"]


def test_build_payload_with_tools():
    payload = ENGINE._build_payload([Message(role=Role.USER, content="Hi")], tools=[DUMMY_TOOL])
    assert payload["tools"][0]["name"] == "tasks"
    assert payload["tools"][0]["type"] == "function"


def test_build_payload_reasoning_effort_high():
    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k", reasoning_effort="high")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["reasoning"] == {"effort": "high", "summary": "auto"}


def test_build_payload_reasoning_effort_auto_omits_block():
    """xAI always-reasoning models reject the reasoning param — 'auto' omits it."""
    engine = ResponsesEngine(model="grok-4-1-fast", api_key="k", provider="xai", reasoning_effort="auto")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "reasoning" not in payload


def test_build_payload_reasoning_effort_none_no_block():
    payload = ENGINE._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "reasoning" not in payload


def test_build_payload_reasoning_effort_string_none_sends_block():
    """gpt-5.5 uses 'none' (string) to disable reasoning — must appear in the payload."""
    engine = ResponsesEngine(model="gpt-5.5", api_key="k", reasoning_effort="none")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["reasoning"] == {"effort": "none", "summary": "auto"}


def test_build_payload_include_omitted_for_non_reasoning_model():
    """gpt-4.1-nano is not a reasoning model — the `include` param is rejected by
    the API for such models, so it must not be sent."""
    engine = ResponsesEngine(model="gpt-4.1-nano", api_key="k")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "include" not in payload


def test_build_payload_custom_summary():
    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k", reasoning_effort="medium", reasoning_summary="detailed")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["reasoning"]["summary"] == "detailed"


### NON-STREAM PARSER (_parse_non_stream)


def _non_stream_raw(output=None, status="completed", incomplete_details=None, usage=None):
    return {
        "id": "resp_1",
        "output": output or [],
        "status": status,
        "incomplete_details": incomplete_details,
        "usage": usage or {"input_tokens": 5, "output_tokens": 8, "input_tokens_details": {"cached_tokens": 0}},
    }


def test_parse_non_stream_text():
    raw = _non_stream_raw(
        output=[
            {"type": "message", "content": [{"type": "output_text", "text": "Hello!"}]},
        ]
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.content == "Hello!"
    assert r.tool_calls is None
    assert r.stop_reason == StopReason.END_TURN
    assert r.usage.input_tokens == 5
    assert r.usage.output_tokens == 8
    assert r.reasoning_signature is None


def test_parse_non_stream_tool_calls():
    raw = _non_stream_raw(
        output=[
            {
                "type": "function_call",
                "call_id": "call_abc",
                "name": "tasks",
                "arguments": '{"action": "list"}',
            }
        ]
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.stop_reason == StopReason.TOOL_USE
    assert r.tool_calls[0].id == "call_abc"
    assert r.tool_calls[0].name == "tasks"
    assert r.tool_calls[0].arguments == {"action": "list"}


def test_parse_non_stream_reasoning_items_persisted():
    reasoning = {"type": "reasoning", "id": "rs_1", "encrypted_content": "E", "summary": [{"type": "summary_text", "text": "Thinking..."}]}
    raw = _non_stream_raw(
        output=[
            reasoning,
            {"type": "message", "content": [{"type": "output_text", "text": "Hi"}]},
        ]
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.reasoning_content == "Thinking..."
    assert r.reasoning_signature
    decoded = json.loads(r.reasoning_signature)
    assert decoded == [reasoning]


def test_parse_non_stream_max_tokens():
    raw = _non_stream_raw(
        output=[{"type": "message", "content": [{"type": "output_text", "text": "Hi"}]}],
        status="incomplete",
        incomplete_details={"reason": "max_output_tokens"},
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.stop_reason == StopReason.MAX_TOKENS


def test_parse_non_stream_usage_with_cache():
    raw = _non_stream_raw(
        output=[{"type": "message", "content": [{"type": "output_text", "text": "Hi"}]}],
        usage={"input_tokens": 100, "output_tokens": 20, "input_tokens_details": {"cached_tokens": 80}},
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.usage.cache_read_tokens == 80
    assert r.usage.total_tokens == 120


def test_parse_non_stream_unknown_status_defaults_end_turn():
    raw = _non_stream_raw(
        output=[{"type": "message", "content": [{"type": "output_text", "text": "Hi"}]}],
        status="something_else",
    )
    r = ENGINE._parse_non_stream(raw)
    assert r.stop_reason == StopReason.END_TURN


### CHAT


@pytest.mark.asyncio
async def test_chat_returns_response():
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _non_stream_raw(output=[{"type": "message", "content": [{"type": "output_text", "text": "Hello"}]}])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await ENGINE.chat([Message(role=Role.USER, content="Hi")])

    assert response.content == "Hello"
    assert response.stop_reason == StopReason.END_TURN


@pytest.mark.asyncio
async def test_chat_with_tool_call():
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _non_stream_raw(
        output=[
            {
                "type": "function_call",
                "call_id": "call_1",
                "name": "tasks",
                "arguments": '{"action": "list"}',
            }
        ]
    )

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await ENGINE.chat([Message(role=Role.USER, content="Hi")], tools=[DUMMY_TOOL])

    assert response.stop_reason == StopReason.TOOL_USE
    assert response.tool_calls[0].name == "tasks"


@pytest.mark.asyncio
async def test_chat_computes_cost_for_known_model():
    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="test-key")
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _non_stream_raw(output=[{"type": "message", "content": [{"type": "output_text", "text": "Hello"}]}])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await engine.chat([Message(role=Role.USER, content="Hi")])

    assert response.cost is not None
    assert response.cost.total > 0


@pytest.mark.asyncio
async def test_chat_raises_on_error():
    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.text = "Rate limit"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        with pytest.raises(RuntimeError, match="429"):
            await ENGINE.chat([Message(role=Role.USER, content="Hi")])


@pytest.mark.asyncio
async def test_chat_raises_auth_error_for_401():
    from sunwaee.modules.gen.engine.errors import AuthError

    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="test-key")
    engine._client = AsyncMock()
    engine._client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(AuthError):
        await engine.chat([Message(role=Role.USER, content="Hello")])


### STREAM


def _sse(obj: dict) -> str:
    return "data: " + json.dumps(obj)


def _mock_stream_client(lines: list[str]):
    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)
    return mock_client


@pytest.mark.asyncio
async def test_stream_yields_text_chunks():
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "Hello"}),
        _sse({"type": "response.output_text.delta", "delta": " world"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 8, "output_tokens": 2, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    text_chunks = [c for c in chunks if c.content]
    assert [c.content for c in text_chunks] == ["Hello", " world"]
    summary = chunks[-1]
    assert summary.stop_reason == StopReason.END_TURN
    assert summary.usage.input_tokens == 8
    assert summary.usage.output_tokens == 2


@pytest.mark.asyncio
async def test_stream_yields_reasoning_summary_and_persists_items():
    reasoning_item = {
        "type": "reasoning",
        "id": "rs_1",
        "encrypted_content": "ENC",
        "summary": [{"type": "summary_text", "text": "Thinking..."}],
    }
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_item.added", "item": {"type": "reasoning", "id": "rs_1"}}),
        _sse({"type": "response.reasoning_summary_text.delta", "delta": "Thinking"}),
        _sse({"type": "response.reasoning_summary_text.delta", "delta": "..."}),
        _sse({"type": "response.output_item.done", "item": reasoning_item}),
        _sse({"type": "response.output_text.delta", "delta": "Answer"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 6, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k", reasoning_effort="medium")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    # gpt-5.4-mini has reasoning_tokens_type="summary" -> no synthetic stub; real deltas stream.
    assert all(not c.synthetic for c in chunks)
    reasoning_deltas = [c for c in chunks if c.reasoning_content]
    assert [c.reasoning_content for c in reasoning_deltas] == ["Thinking", "..."]

    content_chunks = [c for c in chunks if c.content]
    assert content_chunks[0].content == "Answer"

    summary = chunks[-1]
    assert summary.reasoning_signature
    decoded = json.loads(summary.reasoning_signature)
    assert decoded == [reasoning_item]


@pytest.mark.asyncio
async def test_stream_reasoning_summary_delta_without_item_added_still_yields():
    """reasoning_summary_text.delta can arrive without a prior output_item.added
    reasoning event — the delta must still be yielded."""
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.reasoning_summary_text.delta", "delta": "Thinking"}),
        _sse({"type": "response.output_text.delta", "delta": "Answer"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 6, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]
    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k", reasoning_effort="medium")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    reasoning_deltas = [c for c in chunks if c.reasoning_content and not c.synthetic]
    assert [c.reasoning_content for c in reasoning_deltas] == ["Thinking"]

    content_chunks = [c for c in chunks if c.content]
    assert content_chunks[0].content == "Answer"


@pytest.mark.asyncio
async def test_stream_yields_tool_call():
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse(
            {
                "type": "response.function_call_arguments.delta",
                "output_index": 0,
                "delta": '{"title"',
            }
        ),
        _sse(
            {
                "type": "response.function_call_arguments.delta",
                "output_index": 0,
                "delta": ': "Test"}',
            }
        ),
        _sse(
            {
                "type": "response.output_item.done",
                "output_index": 0,
                "item": {
                    "type": "function_call",
                    "call_id": "call_1",
                    "name": "update_chat",
                    "arguments": '{"title": "Test"}',
                },
            }
        ),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 10, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    tc_chunk = next(c for c in chunks if c.tool_calls)
    assert tc_chunk.tool_calls[0].id == "call_1"
    assert tc_chunk.tool_calls[0].name == "update_chat"
    assert tc_chunk.tool_calls[0].arguments == {"title": "Test"}
    assert chunks[-1].stop_reason == StopReason.TOOL_USE


@pytest.mark.asyncio
async def test_stream_tool_call_falls_back_to_item_arguments_when_no_deltas():
    """Some providers omit function_call_arguments.delta and only emit the full
    arguments string in output_item.done. Those args must still be picked up."""
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse(
            {
                "type": "response.output_item.done",
                "output_index": 0,
                "item": {
                    "type": "function_call",
                    "call_id": "call_xyz",
                    "name": "tasks",
                    "arguments": '{"action": "list"}',
                },
            }
        ),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 5, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    tc_chunk = next(c for c in chunks if c.tool_calls)
    assert tc_chunk.tool_calls[0].arguments == {"action": "list"}
    assert chunks[-1].stop_reason == StopReason.TOOL_USE


@pytest.mark.asyncio
async def test_stream_stop_reason_max_tokens():
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "partial"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "incomplete",
                    "incomplete_details": {"reason": "max_output_tokens"},
                    "usage": {"input_tokens": 4, "output_tokens": 8192, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert chunks[-1].stop_reason == StopReason.MAX_TOKENS


@pytest.mark.asyncio
async def test_stream_synthetic_stub_when_silent_reasoning():
    """grok-4-1-fast has reasoning_tokens_type=None -> sentinel fires immediately
    when reasoning is requested (effort bypasses factory validation here, but the
    engine-level stub logic is what we're exercising)."""
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "Hello"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 1, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="grok-4-1-fast", api_key="k", provider="xai", reasoning_effort="high")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert chunks[0].synthetic is True
    assert chunks[0].reasoning_content


@pytest.mark.asyncio
async def test_stream_no_synthetic_stub_without_effort():
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "Hi"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 1, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert all(not c.synthetic for c in chunks)


@pytest.mark.asyncio
async def test_stream_no_synthetic_stub_when_effort_auto():
    """'auto' means we don't send the reasoning block — and the model might not reason —
    so don't pre-emit a sentinel."""
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "Hi"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 1, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="grok-4-1-fast", api_key="k", provider="xai", reasoning_effort="auto")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert all(not c.synthetic for c in chunks)


@pytest.mark.asyncio
async def test_stream_reads_body_before_raising_on_error():
    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.aread = AsyncMock(return_value=b"Too Many Requests")

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = mock_client
    with pytest.raises(RuntimeError, match="429"):
        async for _ in engine.stream([Message(role=Role.USER, content="Hi")]):
            pass


@pytest.mark.asyncio
async def test_stream_summary_performance_and_cost():
    lines = [
        _sse({"type": "response.created", "response": {"id": "resp_1"}}),
        _sse({"type": "response.output_text.delta", "delta": "Hi"}),
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_1",
                    "status": "completed",
                    "usage": {"input_tokens": 50, "output_tokens": 10, "input_tokens_details": {"cached_tokens": 0}},
                },
            }
        ),
        "data: [DONE]",
    ]

    engine = ResponsesEngine(model="gpt-5.4-mini", api_key="k")
    engine._client = _mock_stream_client(lines)
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    summary = chunks[-1]
    assert summary.performance is not None
    assert summary.performance.throughput > 0
    assert summary.cost is not None
    assert summary.cost.total > 0


### HELPERS


async def aiter(items):
    for item in items:
        yield item
