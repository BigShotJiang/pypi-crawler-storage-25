# standard
import hashlib
import json
import time
from collections.abc import AsyncIterator

# third party
import httpx

# custom
from sunwaee.utils.logger import get_logger
from ..base import BaseEngine
from ..errors import raise_api_error
from ..models import compute_cost, get_model
from ..types import (
    FileAttachment,
    Message,
    Performance,
    Response,
    Role,
    StopReason,
    Tool,
    ToolCall,
    Usage,
    make_non_stream_performance,
)

_log = get_logger("engine.responses")


class ResponsesEngine(BaseEngine):
    def __init__(
        self,
        model: str,
        api_key: str,
        provider: str = "openai",
        base_url: str = "https://api.openai.com/v1",
        max_tokens: int = 8192,
        reasoning_effort: str | None = None,
        reasoning_summary: str = "auto",
        model_info=None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_tokens = max_tokens

        # reasoning_effort values:
        #   None   — no reasoning (swap handled by factory)
        #   "off"  — explicit off; no `reasoning` block sent
        #   "auto" — model reasons at its default; no `reasoning` block sent
        #            (xAI always-reasoning models reject the param)
        #   "minimal" / "low" / "medium" / "high" / "xhigh" / "max"
        #          — sent as `reasoning.effort`
        self.reasoning_effort = reasoning_effort
        self.reasoning_summary = reasoning_summary

        # NOTE: model_info is the user-facing parent passed by the factory.
        # Falls back to get_model(model) for direct instantiation in tests.
        self._model_info = model_info if model_info is not None else get_model(model)
        self._client = client or httpx.AsyncClient()

    ### PAYLOAD BUILDERS

    def _attachment_parts(self, attachments: list[FileAttachment]) -> list[dict]:
        if any(a.is_image for a in attachments):
            if self._model_info is not None and not self._model_info.supports_vision:
                raise ValueError(f"model {self.model!r} does not support vision")

        parts: list[dict] = []
        for att in attachments:
            if att.is_image:
                parts.append(
                    {
                        "type": "input_image",
                        "image_url": f"data:{att.media_type};base64,{att.as_base64()}",
                    }
                )
            else:
                file_text = f'<file name="{att.filename}">\n{att.as_text()}\n</file>'
                parts.append({"type": "input_text", "text": file_text})

        return parts

    def _assistant_items(self, m: Message, include_reasoning: bool) -> list[dict]:
        """Emit typed output items for an assistant turn.

        When include_reasoning and m.reasoning_signature is a JSON-encoded list
        of typed reasoning items (produced by a prior ResponsesEngine turn),
        those items are reconstructed and echoed verbatim. Plain-text
        reasoning_content from a non-Responses history cannot be echoed as a
        typed reasoning item (no encrypted_content) and is dropped.
        """

        items: list[dict] = []
        if include_reasoning and m.reasoning_signature:
            try:
                decoded = json.loads(m.reasoning_signature)
            except (ValueError, TypeError):
                decoded = None
            if isinstance(decoded, list):
                for r in decoded:
                    if isinstance(r, dict) and r.get("type") == "reasoning":
                        items.append(r)
        if m.content:
            items.append(
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": m.content}],
                }
            )
        if m.tool_calls:
            for tc in m.tool_calls:
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.id,
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments),
                    }
                )

        return items

    def _build_input(self, messages: list[Message]) -> list[dict]:
        last_assistant_idx = max(
            (i for i, m in enumerate(messages) if m.role.value == "assistant"),
            default=-1,
        )
        items: list[dict] = []
        for idx, m in enumerate(messages):
            if m.role == Role.TOOL:
                items.append(
                    {
                        "type": "function_call_output",
                        "call_id": m.tool_call_id,
                        "output": m.content or "",
                    }
                )
            elif m.role == Role.ASSISTANT:
                items.extend(self._assistant_items(m, include_reasoning=(idx == last_assistant_idx)))
            elif m.role == Role.CONTEXT:
                items.append(
                    {
                        "role": "system",
                        "content": [{"type": "input_text", "text": f"<context>\n{m.content}\n</context>"}],
                    }
                )
            elif m.role == Role.SYSTEM:
                items.append(
                    {
                        "role": "system",
                        "content": [{"type": "input_text", "text": m.content or ""}],
                    }
                )
            else:  # USER
                content: list[dict] = []
                if m.attachments:
                    content.extend(self._attachment_parts(m.attachments))
                if m.content:
                    content.append({"type": "input_text", "text": m.content})
                items.append({"role": "user", "content": content})

        return items

    def _build_tools(self, tools: list[Tool]) -> list[dict]:
        return [
            {
                "type": "function",
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            }
            for t in tools
        ]

    def _build_payload(self, messages: list[Message], tools: list[Tool] | None) -> dict:
        payload: dict = {
            "model": self.model,
            "input": self._build_input(messages),
            "max_output_tokens": self.max_tokens,
            "store": False,
        }
        # NOTE: the Responses API does not do automatic prefix caching the way Chat
        # Completions does. Without prompt_cache_key, requests are routed
        # randomly across OpenAI's servers — each server maintains its own
        # isolated cache, so consecutive turns almost always miss. Setting a
        # stable key derived from the system prompt ensures all requests that
        # share the same system prompt land on the same server and benefit from
        # prefix-cache hits. SHA-256[:32] is collision-resistant at this scale
        # and stays within OpenAI's key length limit.
        system_content = next((m.content for m in messages if m.role == Role.SYSTEM and m.content), None)
        if system_content:
            payload["prompt_cache_key"] = hashlib.sha256(system_content.encode()).hexdigest()[:32]
        # `include: ["reasoning.encrypted_content"]` is only valid on reasoning
        # models — gpt-4.1-nano and other non-reasoning OpenAI models reject it.
        if self._model_info is not None and self._model_info.supports_reasoning:
            payload["include"] = ["reasoning.encrypted_content"]
        if tools:
            payload["tools"] = self._build_tools(tools)
        if self.reasoning_effort not in (None, "off", "auto"):
            payload["reasoning"] = {
                "effort": self.reasoning_effort,
                "summary": self.reasoning_summary,
            }

        return payload

    ### RESPONSE PARSERS

    def _extract_usage(self, usage: dict) -> Usage:
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        cache_read_tokens = usage.get("input_tokens_details", {}).get("cached_tokens", 0)
        total_tokens = input_tokens + output_tokens
        return Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cache_read_tokens=cache_read_tokens,
        )

    def _parse_non_stream(self, raw: dict) -> Response:
        output_items = raw.get("output", [])
        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        reasoning_items: list[dict] = []
        tool_calls: list[ToolCall] = []

        for item in output_items:
            t = item.get("type")
            if t == "reasoning":
                reasoning_items.append(item)
                for s in item.get("summary", []):
                    if s.get("type") == "summary_text" and s.get("text"):
                        reasoning_parts.append(s["text"])
            elif t == "message":
                for c in item.get("content", []):
                    if c.get("type") == "output_text":
                        content_parts.append(c.get("text", ""))
            elif t == "function_call":
                tool_calls.append(
                    ToolCall(
                        id=item.get("call_id", ""),
                        name=item.get("name", ""),
                        arguments=json.loads(item.get("arguments", "{}") or "{}"),
                    )
                )

        status = raw.get("status", "completed")
        incomplete = raw.get("incomplete_details", {}) or {}
        if tool_calls:
            stop_reason = StopReason.TOOL_USE
        elif incomplete.get("reason") == "max_output_tokens":
            stop_reason = StopReason.MAX_TOKENS
        elif status == "completed":
            stop_reason = StopReason.END_TURN
        else:
            stop_reason = StopReason.END_TURN

        usage = self._extract_usage(raw.get("usage", {}) or {})

        return Response(
            provider=self.provider,
            model=self.model,
            content="".join(content_parts) or None,
            reasoning_content="".join(reasoning_parts) or None,
            reasoning_signature=json.dumps(reasoning_items) if reasoning_items else None,
            tool_calls=tool_calls or None,
            stop_reason=stop_reason,
            usage=usage,
        )

    ### INTERFACES

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}"}

    async def chat(
        self,
        messages: list[Message],
        tools: list[Tool] | None = None,
    ) -> Response:
        _log.debug("chat: provider=%r model=%r messages=%d tools=%d", self.provider, self.model, len(messages), len(tools or []))
        t_start = time.monotonic()
        resp = await self._client.post(
            f"{self.base_url}/responses",
            headers=self._headers(),
            json=self._build_payload(messages, tools),
        )
        if not resp.is_success:
            raise_api_error(self.provider, resp.status_code, resp.text)

        response = self._parse_non_stream(resp.json())
        total_duration = time.monotonic() - t_start
        response.performance = make_non_stream_performance(response, total_duration)
        if self._model_info and response.usage:
            response.cost = compute_cost(response.usage, self._model_info)
        _log.debug(
            "chat: done stop=%r in=%d out=%d duration=%.2fs",
            response.stop_reason,
            response.usage.input_tokens if response.usage else 0,
            response.usage.output_tokens if response.usage else 0,
            total_duration,
        )
        return response

    async def stream(
        self,
        messages: list[Message],
        tools: list[Tool] | None = None,
    ) -> AsyncIterator[Response]:
        _log.debug("stream: provider=%r model=%r messages=%d tools=%d", self.provider, self.model, len(messages), len(tools or []))
        payload = self._build_payload(messages, tools)
        payload["stream"] = True

        # Streaming accumulators
        tool_buf: dict[int, dict] = {}  # keyed by output_index
        reasoning_items: list[dict] = []  # collected on output_item.done
        stop_reason: StopReason = StopReason.END_TURN
        usage: Usage | None = None

        t_start = time.monotonic()
        t_first_chunk: float | None = None
        t_reasoning_start: float | None = None
        t_reasoning_end: float | None = None
        t_content_start: float | None = None
        t_end: float | None = None

        emit_synthetic = (
            self.reasoning_effort not in (None, "off", "auto") and self._model_info is not None and self._model_info.reasoning_tokens_type is None
        )

        async with self._client.stream(
            "POST",
            f"{self.base_url}/responses",
            headers=self._headers(),
            json=payload,
        ) as resp:
            if not resp.is_success:
                body = await resp.aread()
                raise_api_error(self.provider, resp.status_code, body.decode(errors="replace"))

            if emit_synthetic:
                now = time.monotonic()
                t_first_chunk = now
                t_reasoning_start = t_start
                yield Response(
                    provider=self.provider,
                    model=self.model,
                    streaming=True,
                    synthetic=True,
                    reasoning_content="Reasoning in progress - tokens not available for this model",
                )

            async for line in resp.aiter_lines():
                if not line.startswith("data: "):  # pragma: no cover
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                now = time.monotonic()
                if t_first_chunk is None:
                    t_first_chunk = now

                evt = json.loads(data)
                et = evt.get("type", "")

                if et == "response.output_item.added":
                    item = evt.get("item", {})
                    if item.get("type") == "reasoning" and t_reasoning_start is None:
                        t_reasoning_start = now

                elif et == "response.reasoning_summary_text.delta":
                    delta = evt.get("delta", "")
                    if delta:
                        if t_reasoning_start is None:
                            t_reasoning_start = now
                        yield Response(
                            provider=self.provider,
                            model=self.model,
                            streaming=True,
                            reasoning_content=delta,
                        )

                elif et == "response.output_text.delta":
                    delta = evt.get("delta", "")
                    if delta:
                        if t_content_start is None:
                            t_content_start = now
                            if t_reasoning_start is not None and t_reasoning_end is None:
                                t_reasoning_end = now
                        yield Response(
                            provider=self.provider,
                            model=self.model,
                            streaming=True,
                            content=delta,
                        )

                elif et == "response.function_call_arguments.delta":
                    i = evt.get("output_index", 0)
                    tool_buf.setdefault(i, {"call_id": "", "name": "", "arguments": ""})
                    tool_buf[i]["arguments"] += evt.get("delta", "")

                elif et == "response.output_item.done":
                    item = evt.get("item", {})
                    item_type = item.get("type")
                    if item_type == "function_call":
                        i = evt.get("output_index", 0)
                        tool_buf.setdefault(i, {"call_id": "", "name": "", "arguments": ""})
                        tool_buf[i]["call_id"] = item.get("call_id", "")
                        tool_buf[i]["name"] = item.get("name", "")
                        if not tool_buf[i]["arguments"]:
                            tool_buf[i]["arguments"] = item.get("arguments", "") or ""
                    elif item_type == "reasoning":
                        reasoning_items.append(item)

                elif et == "response.completed":
                    r = evt.get("response", {})
                    usage = self._extract_usage(r.get("usage", {}) or {})
                    status = r.get("status", "completed")
                    incomplete = r.get("incomplete_details", {}) or {}
                    if tool_buf:
                        stop_reason = StopReason.TOOL_USE
                    elif incomplete.get("reason") == "max_output_tokens":
                        stop_reason = StopReason.MAX_TOKENS
                    elif status == "completed":
                        stop_reason = StopReason.END_TURN

        t_end = time.monotonic()

        if tool_buf:
            tcs = [
                ToolCall(
                    id=buf.get("call_id") or f"tc_{i}",
                    name=buf["name"],
                    arguments=(json.loads(buf["arguments"]) if buf["arguments"] else {}),
                )
                for i, buf in sorted(tool_buf.items())
            ]
            yield Response(
                provider=self.provider,
                model=self.model,
                streaming=True,
                tool_calls=tcs,
            )

        total_duration = t_end - t_start
        latency = (t_first_chunk - t_start) if t_first_chunk else total_duration
        reasoning_duration = ((t_reasoning_end or t_end) - t_reasoning_start) if t_reasoning_start else 0.0
        content_duration = (t_end - t_content_start) if t_content_start else 0.0
        out_tok = usage.output_tokens if usage else 0
        throughput = max(1, int(out_tok / total_duration)) if out_tok > 0 and total_duration > 0 else 0

        final_usage = usage or Usage()
        _log.debug(
            "stream: done stop=%r in=%d out=%d duration=%.2fs", stop_reason, final_usage.input_tokens, final_usage.output_tokens, total_duration
        )
        yield Response(
            provider=self.provider,
            model=self.model,
            streaming=True,
            stop_reason=stop_reason,
            reasoning_signature=json.dumps(reasoning_items) if reasoning_items else None,
            usage=final_usage,
            cost=compute_cost(final_usage, self._model_info) if self._model_info else None,
            performance=Performance(
                latency=round(latency, 2),
                reasoning_duration=round(reasoning_duration, 2),
                content_duration=round(content_duration, 2),
                total_duration=round(total_duration, 2),
                throughput=throughput,
            ),
        )
