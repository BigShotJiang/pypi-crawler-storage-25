"""Allow running ideasim as ``python -m ideasim``."""

from ideasim.cli import main

main()
