from __future__ import annotations

from typing import ClassVar

from cyberdrop_dl.crawlers._tubecorporate import TubeCorporateCrawler
from cyberdrop_dl.url_objects import AbsoluteHttpURL


class HDZogCrawler(TubeCorporateCrawler):
    DOMAIN: ClassVar[str] = "hdzog"
    FOLDER_DOMAIN: ClassVar[str] = "HDZog"
    PRIMARY_URL: ClassVar[AbsoluteHttpURL] = AbsoluteHttpURL("https://hdzog.com")
