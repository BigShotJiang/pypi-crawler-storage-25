package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/meshclaw/meshclaw/internal/aichat"
	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/doctor"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/matrixops"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/workers"
	"github.com/meshclaw/meshclaw/internal/workflow"
	"github.com/meshclaw/meshclaw/internal/workspace"
)

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}

	var err error
	switch os.Args[1] {
	case "help", "--help", "-h":
		usage()
	case "list":
		err = list(os.Args[2:])
	case "capabilities":
		err = capabilities(os.Args[2:])
	case "status":
		err = status()
	case "monitor-check":
		err = monitorCheck(os.Args[2:])
	case "monitor-agent":
		err = monitorAgent(os.Args[2:])
	case "ops-brief":
		err = opsBrief(os.Args[2:])
	case "fleet-scan":
		err = fleetScan(os.Args[2:])
	case "fleet-service-audit":
		err = fleetServiceAudit(os.Args[2:])
	case "node-inventory":
		err = nodeInventory(os.Args[2:])
	case "fleet-inventory":
		err = fleetInventory(os.Args[2:])
	case "placement-plan":
		err = placementPlan(os.Args[2:])
	case "autoheal-plan":
		err = autohealPlan(os.Args[2:])
	case "autoheal-apply-safe":
		err = autohealApplySafe()
	case "disk-investigate":
		err = diskInvestigate(os.Args[2:])
	case "process-top":
		err = processTop(os.Args[2:])
	case "data-clean-plan":
		err = dataCleanPlan(os.Args[2:])
	case "data-clean-apply":
		err = dataCleanApply(os.Args[2:])
	case "evidence-list":
		err = evidenceList(os.Args[2:])
	case "policy-check":
		err = policyCheck(os.Args[2:])
	case "policy-show":
		err = policyShow(os.Args[2:])
	case "policy-init":
		err = policyInit(os.Args[2:])
	case "policy-presets":
		err = policyPresets(os.Args[2:])
	case "matrix-plan":
		err = matrixBridgePlan(os.Args[2:])
	case "matrix-config-init":
		err = matrixConfigInit(os.Args[2:])
	case "matrix-post":
		err = matrixPost(os.Args[2:])
	case "matrix-sync-once":
		err = matrixSyncOnce(os.Args[2:])
	case "matrix-bridge":
		err = matrixBridge(os.Args[2:])
	case "matrix-ai-config-init":
		err = matrixAIConfigInit(os.Args[2:])
	case "matrix-ai-chat":
		err = matrixAIChat(os.Args[2:])
	case "matrix-ai-bridge":
		err = matrixAIBridge(os.Args[2:])
	case "workers":
		err = workersList(os.Args[2:])
	case "workspace-list":
		err = workspaceList(os.Args[2:])
	case "workspace-add":
		err = workspaceAdd(os.Args[2:])
	case "workspace-activity":
		err = workspaceActivity(os.Args[2:])
	case "ops-chat":
		err = opsChat(os.Args[2:])
	case "ops-dispatch":
		err = opsDispatch(os.Args[2:])
	case "provision-plan":
		err = provisionPlan(os.Args[2:])
	case "run":
		err = run(os.Args[2:])
	case "run-evidence":
		err = runEvidence(os.Args[2:])
	case "job-start":
		err = jobStart(os.Args[2:])
	case "job-status":
		err = jobStatus(os.Args[2:])
	case "job-logs":
		err = jobLogs(os.Args[2:])
	case "job-cancel":
		err = jobCancel(os.Args[2:])
	case "artifact-collect":
		err = artifactCollect(os.Args[2:])
	case "doctor":
		err = runDoctor(os.Args[2:])
	case "analyze-logs":
		err = analyzeLogs(os.Args[2:])
	case "service-check":
		err = serviceCheck(os.Args[2:])
	case "service-audit":
		err = serviceAudit(os.Args[2:])
	case "service-quarantine":
		err = serviceQuarantine(os.Args[2:])
	case "service-remove":
		err = serviceRemove(os.Args[2:])
	case "security-check":
		err = securityCheck(os.Args[2:])
	case "hygiene-plan":
		err = hygienePlan(os.Args[2:])
	case "hygiene-scan-host":
		err = hygieneScanHost(os.Args[2:])
	case "hygiene-scan-text":
		err = hygieneScanText(os.Args[2:])
	case "mcp":
		err = mcp()
	default:
		err = fmt.Errorf("unknown command: %s", os.Args[1])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "meshclaw:", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Println(`meshclaw - AI-native server operations control plane

Usage:
  meshclaw list
  meshclaw capabilities
  meshclaw status
  meshclaw monitor-check
  meshclaw monitor-agent [interval] [--hygiene]
  meshclaw ops-brief [--json]
  meshclaw fleet-scan [--hosts a,b] [--security] [--hygiene] [--logs] [--parallel n] [--json]
  meshclaw fleet-service-audit [--hosts a,b] [--parallel n] [--json]
  meshclaw node-inventory <host> [--json]
  meshclaw fleet-inventory [--hosts a,b] [--parallel n] [--json]
  meshclaw placement-plan <workload description> [--json]
  meshclaw autoheal-plan
  meshclaw autoheal-apply-safe
  meshclaw disk-investigate <host> [path]
  meshclaw process-top <host>
  meshclaw data-clean-plan <host> <path>
  meshclaw data-clean-apply <host> <manifest>
  meshclaw evidence-list [limit]
  meshclaw policy-check <subject> <action> <resource> [context]
  meshclaw policy-show
  meshclaw policy-init [--preset devops|strict] [--force]
  meshclaw policy-presets
  meshclaw matrix-plan
  meshclaw matrix-config-init [--force]
  meshclaw matrix-post <message>
  meshclaw matrix-sync-once [since]
  meshclaw matrix-bridge
  meshclaw matrix-ai-config-init [--force]
  meshclaw matrix-ai-chat <message>
  meshclaw matrix-ai-bridge
  meshclaw workers [--json]
  meshclaw workspace-list [--json]
  meshclaw workspace-add <id> <host> <path> [owner] [purpose]
  meshclaw workspace-activity <id> <actor> <action> <summary>
  meshclaw ops-chat [message]
  meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>
  meshclaw provision-plan <purpose> [budget-usd]
  meshclaw run <host> <command>
  meshclaw run-evidence <host> <command>
  meshclaw job-start <host> <command>
  meshclaw job-status <host> <id>
  meshclaw job-logs <host> <id> [tail-bytes]
  meshclaw job-cancel <host> <id>
  meshclaw artifact-collect <host> <path> [max-bytes]
  meshclaw doctor <host>
  meshclaw analyze-logs <host> <source>
  meshclaw service-check <host> <service>
  meshclaw service-audit <host>
  meshclaw service-quarantine <host> <service>
  meshclaw service-remove <host> <service> [working-directory]
  meshclaw security-check <host>
  meshclaw hygiene-plan <host>
  meshclaw hygiene-scan-host <host>
  meshclaw hygiene-scan-text <target> <text>
  meshclaw mcp`)
}

func monitorAgent(args []string) error {
	interval := 5 * time.Minute
	hygieneEnabled := false
	filteredArgs := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--hygiene" {
			hygieneEnabled = true
			continue
		}
		filteredArgs = append(filteredArgs, arg)
	}
	if len(filteredArgs) > 1 {
		return fmt.Errorf("usage: meshclaw monitor-agent [interval] [--hygiene]")
	}
	if len(filteredArgs) == 1 {
		parsed, err := time.ParseDuration(filteredArgs[0])
		if err != nil {
			return fmt.Errorf("invalid interval: %s", filteredArgs[0])
		}
		if parsed < 10*time.Second {
			return fmt.Errorf("interval must be at least 10s")
		}
		interval = parsed
	}

	cfg := monitor.DefaultConfig()
	cfg.CheckInterval = interval
	m, err := monitor.New(cfg)
	if err != nil {
		return err
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	fmt.Printf("meshclaw monitor-agent interval=%s hygiene=%t\n", interval, hygieneEnabled)

	runOnce := func() {
		states := m.CheckAll()
		alerts := m.DetectAlerts()
		var hygieneReports []hygiene.Report
		if hygieneEnabled {
			for name, state := range states {
				if state == nil || !state.Online {
					continue
				}
				report := hygiene.ScanHost(name)
				if report.Status == "findings" || report.Status == "failed" {
					hygieneReports = append(hygieneReports, report)
				}
			}
		}
		record, storeErr := evidence.Store("monitor-agent", "fleet", fmt.Sprintf("alerts=%d hygiene_findings=%d", len(alerts), len(hygieneReports)), monitorAgentOutput{States: states, Alerts: alerts, Hygiene: hygieneReports})
		fmt.Printf("monitor-agent check nodes=%d alerts=%d", len(states), len(alerts))
		if hygieneEnabled {
			fmt.Printf(" hygiene_findings=%d", len(hygieneReports))
		}
		if storeErr != nil {
			fmt.Printf(" evidence_error=%v", storeErr)
		} else {
			fmt.Printf(" evidence=%s", record.StoredAt)
		}
		fmt.Println()
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}

	runOnce()
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			runOnce()
		case <-stop:
			fmt.Println("meshclaw monitor-agent stopped")
			return nil
		}
	}
}

func list(args []string) error {
	if wantsJSON(args) {
		return printJSON(inventory.DefaultNodes())
	}
	fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", "NODE", "ROLE", "LOCATION", "TAILSCALE", "WIRE", "USER")
	for _, node := range inventory.DefaultNodes() {
		fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", node.Name, node.Role, node.Location, node.Tailscale, node.WireIP, node.User)
	}
	return nil
}

func fleetScan(args []string) error {
	jsonOut := wantsJSON(args)
	opts, err := parseFleetScanOptions(withoutJSONFlag(args))
	if err != nil {
		return err
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "fleet_scan", Resource: "server"})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	report, err := fleet.Scan(opts)
	if err != nil {
		return err
	}
	record, storeErr := evidence.Store("fleet-scan", "fleet", fleetScanSummary(report), report)
	if jsonOut {
		return printJSON(map[string]interface{}{"policy": decision, "report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-scan hosts=%d alerts=%d security=%t hygiene=%t logs=%t\n", len(report.Hosts), len(report.Alerts), report.Options.Security, report.Options.Hygiene, report.Options.Logs)
	for _, host := range report.Hosts {
		status := "offline"
		if host.Online {
			status = "online"
		}
		fmt.Printf("- %s %s", host.Host, status)
		if host.Error != "" {
			fmt.Printf(" error=%s", truncate(host.Error, 80))
		}
		if host.Security != nil {
			fmt.Printf(" security=%s", host.Security.Status)
		}
		if host.Logs != nil {
			fmt.Printf(" logs=%s", host.Logs.Status)
		}
		if host.Hygiene != nil {
			fmt.Printf(" hygiene=%s", host.Hygiene.Status)
		}
		fmt.Println()
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func parseFleetScanOptions(args []string) (fleet.Options, error) {
	var opts fleet.Options
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--security":
			opts.Security = true
		case "--hygiene":
			opts.Hygiene = true
		case "--logs":
			opts.Logs = true
		case "--hosts":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--hosts requires a comma-separated value")
			}
			opts.Hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &opts.MaxParallel); err != nil {
				return opts, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return opts, fmt.Errorf("unknown fleet-scan option: %s", args[i])
		}
	}
	return opts, nil
}

type fleetServiceAuditReport struct {
	Hosts       []workflow.Report `json:"hosts"`
	Findings    int               `json:"findings"`
	MaxParallel int               `json:"max_parallel"`
	Time        time.Time         `json:"time"`
}

type fleetInventoryReport struct {
	Hosts       []workflow.SoftwareInventoryReport `json:"hosts"`
	Failures    int                                `json:"failures"`
	MaxParallel int                                `json:"max_parallel"`
	Time        time.Time                          `json:"time"`
}

type placementReport struct {
	Workload    string               `json:"workload"`
	Class       string               `json:"class"`
	Candidates  []placementCandidate `json:"candidates"`
	Rejected    []placementRejection `json:"rejected"`
	Inventory   fleetInventoryReport `json:"inventory"`
	Monitor     monitorCheckOutput   `json:"monitor"`
	GeneratedAt time.Time            `json:"generated_at"`
}

type placementCandidate struct {
	Host    string   `json:"host"`
	Score   int      `json:"score"`
	Reasons []string `json:"reasons"`
	Actions []string `json:"actions"`
}

type placementRejection struct {
	Host   string `json:"host"`
	Reason string `json:"reason"`
}

type opsBriefReport struct {
	Monitor      monitorCheckOutput      `json:"monitor"`
	ServiceAudit fleetServiceAuditReport `json:"service_audit"`
	TopRisks     []string                `json:"top_risks"`
	NextActions  []string                `json:"next_actions"`
	Time         time.Time               `json:"time"`
}

func opsBrief(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw ops-brief [--json]")
	}
	report, record, storeErr, err := buildOpsBrief()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("ops-brief risks=%d next=%d nodes=%d service_findings=%d\n", len(report.TopRisks), len(report.NextActions), len(report.Monitor.States), report.ServiceAudit.Findings)
	if len(report.TopRisks) > 0 {
		fmt.Println("top risks:")
		for _, risk := range report.TopRisks {
			fmt.Println("- " + risk)
		}
	} else {
		fmt.Println("top risks: none")
	}
	if len(report.NextActions) > 0 {
		fmt.Println("next actions:")
		for _, action := range report.NextActions {
			fmt.Println("- " + action)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildOpsBrief() (opsBriefReport, evidence.Record, error, error) {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return opsBriefReport{}, evidence.Record{}, nil, err
	}
	states := m.CheckAll()
	monitorOut := monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	serviceAudit, _, serviceStoreErr := runFleetServiceAudit(nil, 4)
	report := opsBriefReport{
		Monitor:      monitorOut,
		ServiceAudit: serviceAudit,
		Time:         time.Now().UTC(),
	}
	report.TopRisks, report.NextActions = briefRisksAndActions(monitorOut, serviceAudit)
	record, storeErr := evidence.Store("ops-brief", "fleet", fmt.Sprintf("risks=%d next=%d", len(report.TopRisks), len(report.NextActions)), report)
	if storeErr == nil {
		storeErr = serviceStoreErr
	}
	return report, record, storeErr, nil
}

func briefRisksAndActions(monitorOut monitorCheckOutput, serviceAudit fleetServiceAuditReport) ([]string, []string) {
	risks := []string{}
	actions := []string{}
	for _, alert := range monitorOut.Alerts {
		risks = append(risks, fmt.Sprintf("%s/%s: %s", alert.Node, alert.Level, alert.Message))
		switch alert.Type {
		case "disk":
			actions = append(actions, fmt.Sprintf("meshclaw disk-investigate %s /", alert.Node))
		case "memory":
			actions = append(actions, fmt.Sprintf("meshclaw process-top %s", alert.Node))
		case "offline":
			actions = append(actions, fmt.Sprintf("meshclaw doctor %s", alert.Node))
		}
	}
	for _, host := range serviceAudit.Hosts {
		if host.Status == "ok" {
			continue
		}
		service := serviceFromAuditReport(host)
		if service == "" {
			risks = append(risks, fmt.Sprintf("%s/service: failed or restarting service evidence", host.Host))
			actions = append(actions, fmt.Sprintf("meshclaw service-audit %s", host.Host))
			continue
		}
		risks = append(risks, fmt.Sprintf("%s/service: %s needs review", host.Host, service))
		actions = append(actions, fmt.Sprintf("meshclaw service-check %s %s", host.Host, service))
	}
	return limitStrings(uniqueStrings(risks), 5), limitStrings(uniqueStrings(actions), 5)
}

func serviceFromAuditReport(report workflow.Report) string {
	for _, finding := range report.Findings {
		text := finding.Evidence + "\n" + finding.Next
		for _, token := range strings.Fields(text) {
			token = strings.Trim(token, "`'\".,:;()[]{}")
			if strings.HasSuffix(token, ".service") {
				return strings.TrimSuffix(token, ".service")
			}
		}
	}
	return ""
}

func uniqueStrings(values []string) []string {
	seen := map[string]bool{}
	out := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" || seen[value] {
			continue
		}
		seen[value] = true
		out = append(out, value)
	}
	return out
}

func limitStrings(values []string, limit int) []string {
	if len(values) <= limit {
		return values
	}
	return values[:limit]
}

func fleetServiceAudit(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, parallel, err := parseFleetServiceAuditOptions(args)
	if err != nil {
		return err
	}
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report, record, storeErr := runFleetServiceAudit(hosts, parallel)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-service-audit hosts=%d findings=%d parallel=%d\n", len(report.Hosts), report.Findings, parallel)
	for _, hostReport := range report.Hosts {
		fmt.Printf("- %s status=%s issues=%d\n", hostReport.Host, hostReport.Status, workflowIssueCount(hostReport))
		for _, finding := range hostReport.Findings {
			if finding.Severity == "info" && hostReport.Status == "ok" {
				continue
			}
			fmt.Printf("  [%s] %s\n  next: %s\n", finding.Severity, finding.Title, finding.Next)
			break
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func runFleetServiceAudit(hosts []string, parallel int) (fleetServiceAuditReport, evidence.Record, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report := fleetServiceAuditReport{MaxParallel: parallel, Time: time.Now().UTC()}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, parallel)
	for _, host := range hosts {
		host := host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			hostReport := workflow.ServiceAudit(host)
			mu.Lock()
			report.Hosts = append(report.Hosts, hostReport)
			if hostReport.Status == "findings" || hostReport.Status == "failed" || hostReport.Status == "unknown_node" {
				report.Findings++
			}
			mu.Unlock()
		}()
	}
	wg.Wait()
	sort.Slice(report.Hosts, func(i, j int) bool { return report.Hosts[i].Host < report.Hosts[j].Host })
	record, storeErr := evidence.Store("fleet-service-audit", "fleet", fmt.Sprintf("hosts=%d findings=%d", len(report.Hosts), report.Findings), report)
	return report, record, storeErr
}

func workflowIssueCount(report workflow.Report) int {
	count := 0
	for _, finding := range report.Findings {
		if finding.Severity != "info" || report.Status != "ok" {
			count++
		}
	}
	return count
}

func nodeInventory(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw node-inventory <host> [--json]")
	}
	report := workflow.SoftwareInventory(args[0])
	record, storeErr := evidence.Store("node-inventory", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printSoftwareInventory(report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("node-inventory failed on %s", args[0])
	}
	return nil
}

func fleetInventory(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, parallel, err := parseFleetServiceAuditOptions(args)
	if err != nil {
		return err
	}
	report, record, storeErr := runFleetInventory(hosts, parallel)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-inventory hosts=%d failures=%d parallel=%d\n", len(report.Hosts), report.Failures, report.MaxParallel)
	for _, host := range report.Hosts {
		fmt.Printf("- %s status=%s os=%s tools=%s services=%d containers=%d gpu=%d\n", host.Host, host.Status, host.OS, compactTools(host.Tools), len(host.Services), len(host.Containers), len(host.GPU))
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func placementPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw placement-plan <workload description> [--json]")
	}
	workload := strings.Join(args, " ")
	report, record, storeErr, err := buildPlacementPlan(workload)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("placement-plan class=%s workload=%q candidates=%d\n", report.Class, report.Workload, len(report.Candidates))
	for i, candidate := range report.Candidates {
		fmt.Printf("%d. %s score=%d\n", i+1, candidate.Host, candidate.Score)
		for _, reason := range candidate.Reasons {
			fmt.Println("   - " + reason)
		}
		if len(candidate.Actions) > 0 {
			fmt.Println("   next: " + strings.Join(candidate.Actions, "; "))
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildPlacementPlan(workload string) (placementReport, evidence.Record, error, error) {
	inventoryReport, _, inventoryStoreErr := runFleetInventory(nil, 4)
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return placementReport{}, evidence.Record{}, inventoryStoreErr, err
	}
	states := m.CheckAll()
	monitorOut := monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	report := scorePlacement(workload, inventoryReport, monitorOut)
	record, storeErr := evidence.Store("placement-plan", "fleet", fmt.Sprintf("class=%s candidates=%d", report.Class, len(report.Candidates)), report)
	if storeErr == nil {
		storeErr = inventoryStoreErr
	}
	return report, record, storeErr, nil
}

func scorePlacement(workload string, inventoryReport fleetInventoryReport, monitorOut monitorCheckOutput) placementReport {
	class := classifyWorkload(workload)
	report := placementReport{
		Workload:    workload,
		Class:       class,
		Inventory:   inventoryReport,
		Monitor:     monitorOut,
		GeneratedAt: time.Now().UTC(),
	}
	for _, host := range inventoryReport.Hosts {
		if host.Status != "ok" {
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: "inventory 조회 실패"})
			continue
		}
		state := monitorOut.States[host.Host]
		if state == nil || !state.Online {
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: "offline 또는 monitor 상태 없음"})
			continue
		}
		score, reasons, rejected := scoreHostForWorkload(class, host, state)
		if rejected != "" {
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: rejected})
			continue
		}
		candidate := placementCandidate{Host: host.Host, Score: score, Reasons: reasons}
		candidate.Actions = []string{
			fmt.Sprintf("meshclaw node-inventory %s", host.Host),
			fmt.Sprintf("meshclaw service-audit %s", host.Host),
		}
		report.Candidates = append(report.Candidates, candidate)
	}
	sort.Slice(report.Candidates, func(i, j int) bool {
		if report.Candidates[i].Score == report.Candidates[j].Score {
			return report.Candidates[i].Host < report.Candidates[j].Host
		}
		return report.Candidates[i].Score > report.Candidates[j].Score
	})
	if len(report.Candidates) > 5 {
		report.Candidates = report.Candidates[:5]
	}
	return report
}

func classifyWorkload(workload string) string {
	lower := strings.ToLower(workload)
	switch {
	case containsAny(lower, "local llm", "ollama", "로컬모델", "로컬 모델"):
		return "local-llm"
	case containsAny(lower, "gpu", "cuda", "nvidia", "llm", "모델", "학습", "추론"):
		return "gpu"
	case containsAny(lower, "docker", "도커", "container", "컨테이너", "compose"):
		return "docker"
	case containsAny(lower, "storage", "nas", "backup", "백업", "저장"):
		return "storage"
	case containsAny(lower, "vps", "relay", "public", "외부", "릴레이"):
		return "vps"
	default:
		return "general"
	}
}

func scoreHostForWorkload(class string, host workflow.SoftwareInventoryReport, state *monitor.NodeState) (int, []string, string) {
	score := 50
	reasons := []string{fmt.Sprintf("online, disk %.1f%%, memory %.1f%%", state.Disk, state.Memory)}
	if state.Disk >= 90 {
		return 0, nil, fmt.Sprintf("disk %.1f%%가 너무 높음", state.Disk)
	}
	if state.Memory >= 90 {
		return 0, nil, fmt.Sprintf("memory %.1f%%가 너무 높음", state.Memory)
	}
	if state.Disk < 70 {
		score += 12
	} else if state.Disk >= 75 {
		score -= 12
	}
	if state.Memory < 50 {
		score += 12
	}
	switch class {
	case "gpu":
		if len(host.GPU) == 0 {
			return 0, nil, "GPU 작업인데 GPU가 없음"
		}
		score += 50 + len(host.GPU)*10
		reasons = append(reasons, fmt.Sprintf("GPU %d개 확인", len(host.GPU)))
		if hasTool(host.Tools, "docker") {
			score += 8
			reasons = append(reasons, "docker 있음")
		}
	case "local-llm":
		if hasTool(host.Tools, "ollama") {
			score += 50
			reasons = append(reasons, "ollama 있음")
			if host.Host == "macmini" {
				score += 25
				reasons = append(reasons, "macmini 로컬 모델 워커")
			}
			if len(host.GPU) > 0 {
				score += 10
				reasons = append(reasons, fmt.Sprintf("GPU %d개 확인", len(host.GPU)))
			}
		} else if len(host.GPU) > 0 {
			score += 20
			reasons = append(reasons, "GPU가 있어 로컬 모델 후보")
		} else {
			return 0, nil, "로컬 모델 런타임이나 GPU가 없음"
		}
	case "docker":
		if !hasTool(host.Tools, "docker") {
			return 0, nil, "docker 없음"
		}
		score += 35 + len(host.Containers)*2
		reasons = append(reasons, fmt.Sprintf("docker 있음, 컨테이너 %d개", len(host.Containers)))
	case "storage":
		if host.Host == "s2" || strings.Contains(strings.ToLower(host.OS), "synology") {
			score += 60
			reasons = append(reasons, "NAS/스토리지 노드")
		} else if strings.Contains(host.Host, "v") {
			score += 10
			reasons = append(reasons, "VPS 저장소 후보")
		}
	case "vps":
		if strings.HasPrefix(host.Host, "v") || strings.HasPrefix(host.Host, "c") {
			score += 35
			reasons = append(reasons, "VPS/외부 노드")
		} else {
			score -= 10
		}
	default:
		if hasTool(host.Tools, "meshclaw") && hasTool(host.Tools, "vssh") {
			score += 15
			reasons = append(reasons, "meshclaw/vssh 준비됨")
		}
	}
	return score, reasons, ""
}

func hasTool(tools map[string]string, name string) bool {
	_, ok := tools[name]
	return ok
}

func runFleetInventory(hosts []string, parallel int) (fleetInventoryReport, evidence.Record, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") || nodeHasTag(node, "macos") || nodeHasTag(node, "synology") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report := fleetInventoryReport{MaxParallel: parallel, Time: time.Now().UTC()}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, parallel)
	for _, host := range hosts {
		host := host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			hostReport := workflow.SoftwareInventory(host)
			mu.Lock()
			report.Hosts = append(report.Hosts, hostReport)
			if hostReport.Status != "ok" {
				report.Failures++
			}
			mu.Unlock()
		}()
	}
	wg.Wait()
	sort.Slice(report.Hosts, func(i, j int) bool { return report.Hosts[i].Host < report.Hosts[j].Host })
	record, storeErr := evidence.Store("fleet-inventory", "fleet", fmt.Sprintf("hosts=%d failures=%d", len(report.Hosts), report.Failures), report)
	return report, record, storeErr
}

func printSoftwareInventory(report workflow.SoftwareInventoryReport) {
	fmt.Printf("node-inventory host=%s status=%s os=%s kernel=%s arch=%s\n", report.Host, report.Status, report.OS, report.Kernel, report.Arch)
	if len(report.Tools) > 0 {
		fmt.Println("tools: " + compactTools(report.Tools))
	}
	if len(report.GPU) > 0 {
		fmt.Println("gpu:")
		for _, gpu := range report.GPU {
			fmt.Println("- " + gpu)
		}
	}
	if len(report.Containers) > 0 {
		fmt.Println("containers:")
		for _, container := range firstN(report.Containers, 20) {
			fmt.Println("- " + container)
		}
	}
	if len(report.Services) > 0 {
		fmt.Println("running services:")
		for _, service := range firstN(report.Services, 20) {
			fmt.Println("- " + service)
		}
	}
	if report.Error != "" {
		fmt.Println("error: " + report.Error)
	}
}

func compactTools(tools map[string]string) string {
	if len(tools) == 0 {
		return "-"
	}
	names := make([]string, 0, len(tools))
	for name := range tools {
		names = append(names, name)
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func firstN(values []string, n int) []string {
	if len(values) <= n {
		return values
	}
	return values[:n]
}

func parseFleetServiceAuditOptions(args []string) ([]string, int, error) {
	var hosts []string
	parallel := 4
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--hosts":
			i++
			if i >= len(args) {
				return nil, 0, fmt.Errorf("--hosts requires a comma-separated value")
			}
			hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return nil, 0, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &parallel); err != nil {
				return nil, 0, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return nil, 0, fmt.Errorf("unknown fleet-service-audit option: %s", args[i])
		}
	}
	return hosts, parallel, nil
}

func nodeHasTag(node inventory.Node, tag string) bool {
	for _, candidate := range node.Tags {
		if candidate == tag {
			return true
		}
	}
	return false
}

func splitCSV(value string) []string {
	parts := strings.Split(value, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}

func fleetScanSummary(report fleet.Report) string {
	offline := 0
	findings := 0
	for _, host := range report.Hosts {
		if !host.Online {
			offline++
		}
		if host.Security != nil && host.Security.Status == "findings" {
			findings++
		}
		if host.Logs != nil && host.Logs.Status == "findings" {
			findings++
		}
		if host.Hygiene != nil && host.Hygiene.Status == "findings" {
			findings++
		}
	}
	return fmt.Sprintf("hosts=%d alerts=%d offline=%d findings=%d", len(report.Hosts), len(report.Alerts), offline, findings)
}

func capabilities(args []string) error {
	if wantsJSON(args) {
		return printJSON(capability.DefaultCapabilities())
	}
	fmt.Printf("%-18s %-13s %-14s %-18s %s\n", "ID", "KIND", "PROVIDER", "STATUS", "POLICY")
	for _, cap := range capability.DefaultCapabilities() {
		fmt.Printf("%-18s %-13s %-14s %-18s %s\n", cap.ID, cap.Kind, cap.Provider, cap.Status, cap.Policy)
	}
	return nil
}

func status() error {
	out, err := runtime.NewRunner().Status()
	fmt.Print(out)
	return err
}

type monitorCheckOutput struct {
	States map[string]*monitor.NodeState `json:"states"`
	Alerts []monitor.Alert               `json:"alerts"`
}

type monitorAgentOutput struct {
	States  map[string]*monitor.NodeState `json:"states"`
	Alerts  []monitor.Alert               `json:"alerts"`
	Hygiene []hygiene.Report              `json:"hygiene,omitempty"`
}

func monitorCheck(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	states := m.CheckAll()
	alerts := m.DetectAlerts()
	record, storeErr := evidence.Store("monitor-check", "fleet", fmt.Sprintf("alerts=%d", len(alerts)), monitorCheckOutput{States: states, Alerts: alerts})
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"states": states, "alerts": alerts, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("%-10s %-7s %-15s %6s %6s %s\n", "NODE", "ONLINE", "IP", "DISK", "MEM", "ERROR")
	for _, node := range inventory.DefaultNodes() {
		state := states[node.Name]
		if state == nil {
			continue
		}
		fmt.Printf("%-10s %-7t %-15s %5.1f%% %5.1f%% %s\n", state.Name, state.Online, state.IP, state.Disk, state.Memory, state.Error)
	}
	if len(alerts) > 0 {
		fmt.Println("alerts:")
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealPlan(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.Plan()
	record, storeErr := evidence.Store("autoheal-plan", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"actions": actions, "evidence": record, "store_error": errString(storeErr)})
	}
	if len(actions) == 0 {
		fmt.Println("autoheal status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal status=actions")
	for _, action := range actions {
		fmt.Printf("- [%s/%s] %s %s=%.1f mode=%s\n  command: %s\n  reason: %s\n  verify: %s\n",
			action.Severity, action.Type, action.Node, action.Metric, action.Value, action.Mode, action.Command, action.Reason, action.Verify)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealApplySafe() error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.CheckAndHeal()
	record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if len(actions) == 0 {
		fmt.Println("autoheal apply status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal apply status=done")
	for _, action := range actions {
		fmt.Printf("- [%t] %s %s\n  command: %s\n  result: %s\n", action.Success, action.Node, action.Type, action.Command, action.Result)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func diskInvestigate(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw disk-investigate <host> [path]")
	}
	host := args[0]
	path := "/"
	if len(args) == 2 {
		path = args[1]
	}
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if !strings.HasPrefix(path, "/") {
		return fmt.Errorf("path must be absolute: %s", path)
	}
	quoted := shellQuote(path)
	command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", quoted, quoted)
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("disk-investigate", host, path, result)
	fmt.Printf("disk-investigate host=%s path=%s success=%t transport=%s\n", host, path, result.Success, result.Transport)
	if result.Stdout != "" {
		fmt.Print(result.Stdout)
	}
	if result.Stderr != "" {
		fmt.Fprint(os.Stderr, result.Stderr)
	}
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("disk investigation failed on %s", host)
	}
	return nil
}

func processTop(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw process-top <host>")
	}
	report := workflow.ProcessTop(args[0])
	printReport(report)
	record, storeErr := evidence.Store("process-top", args[0], "top memory/cpu processes", report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("process-top failed on %s", args[0])
	}
	return nil
}

func dataCleanPlan(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-plan <host> <path>")
	}
	report := workflow.DataCleanPlan(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-plan", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func dataCleanApply(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-apply <host> <manifest>")
	}
	report := workflow.DataCleanApply(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-apply", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func evidenceList(args []string) error {
	limit := 20
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw evidence-list [limit]")
	}
	if len(args) == 1 {
		if _, err := fmt.Sscanf(args[0], "%d", &limit); err != nil {
			return fmt.Errorf("invalid limit: %s", args[0])
		}
	}
	records, err := evidence.List(limit)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(records)
	}
	if len(records) == 0 {
		fmt.Println("evidence records=0")
		return nil
	}
	fmt.Printf("%-20s %-18s %-10s %-22s %s\n", "TIME", "KIND", "HOST", "SUMMARY", "PATH")
	for _, record := range records {
		fmt.Printf("%-20s %-18s %-10s %-22s %s\n",
			record.Time.Local().Format("2006-01-02 15:04:05"),
			record.Kind,
			record.Host,
			truncate(record.Summary, 22),
			record.StoredAt,
		)
	}
	return nil
}

func truncate(value string, max int) string {
	if len(value) <= max {
		return value
	}
	if max <= 3 {
		return value[:max]
	}
	return value[:max-3] + "..."
}

func policyCheck(args []string) error {
	if len(args) < 3 {
		return fmt.Errorf("usage: meshclaw policy-check <subject> <action> <resource> [context]")
	}
	request := policy.Request{
		Subject:  args[0],
		Action:   args[1],
		Resource: args[2],
	}
	if len(args) > 3 {
		request.Context = strings.Join(args[3:], " ")
	}
	result := policy.Evaluate(request)
	return printJSON(result)
}

func policyShow(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-show")
	}
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "policy": cfg})
}

func policyInit(args []string) error {
	force := false
	preset := "devops"
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--force" {
			force = true
			continue
		}
		if arg == "--preset" {
			i++
			if i >= len(args) {
				return fmt.Errorf("--preset requires a value")
			}
			preset = args[i]
			continue
		}
		return fmt.Errorf("usage: meshclaw policy-init [--preset devops|strict] [--force]")
	}
	_, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("policy file already exists: %s", path)
		} else if !os.IsNotExist(err) {
			return err
		}
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	data, err := json.MarshalIndent(policy.PresetConfig(preset), "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(path, append(data, '\n'), 0600); err != nil {
		return err
	}
	fmt.Printf("policy=%s preset=%s\n", path, preset)
	return nil
}

func policyPresets(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-presets")
	}
	return printJSON(policy.PresetNames())
}

func matrixBridgePlan(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-plan")
	}
	return printJSON(map[string]interface{}{
		"role": "Matrix is an operations room, approval channel, notification channel, and optional MCP command surface. It is not the assistant brain.",
		"flow": []string{
			"human or AI operator posts an ops request in Matrix",
			"Matrix bridge normalizes the request into a MeshClaw MCP/CLI tool call",
			"MeshClaw policy decides allow, require_approval, or deny",
			"MeshClaw executes only allowed tools through vssh/runtime",
			"Matrix bridge posts concise results and evidence links back to the room",
		},
		"allowed_by_default": []string{
			"server_list",
			"capability_list",
			"monitor_check",
			"fleet_scan",
			"evidence_list",
			"policy_check",
			"policy_show",
			"analyze_logs",
			"security_check",
			"hygiene_scan_host",
		},
		"approval_gated": []string{
			"run_command",
			"autoheal_apply_safe",
			"service_remove",
			"provision_server",
			"deprovision_server",
			"rotate_secret",
		},
	})
}

func matrixConfigInit(args []string) error {
	force := false
	for _, arg := range args {
		if arg == "--force" {
			force = true
			continue
		}
		return fmt.Errorf("usage: meshclaw matrix-config-init [--force]")
	}
	target, err := matrixops.DefaultConfigPath()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(target); err == nil {
			return fmt.Errorf("matrix config already exists: %s", target)
		}
	}
	cfg, source, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	if source == target && !force {
		return fmt.Errorf("matrix config already exists: %s", target)
	}
	if err := matrixops.SaveConfig(target, cfg); err != nil {
		return err
	}
	fmt.Printf("matrix_config=%s copied_from=%s\n", target, source)
	return nil
}

func matrixPost(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw matrix-post <message>")
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	if err := matrixops.NewClient(cfg).SendText(ctx, strings.Join(args, " ")); err != nil {
		return err
	}
	fmt.Printf("posted matrix_room=%s config=%s\n", cfg.RoomID, path)
	return nil
}

func matrixSyncOnce(args []string) error {
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw matrix-sync-once [since]")
	}
	since := ""
	if len(args) == 1 {
		since = args[0]
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	result, err := matrixops.NewClient(cfg).SyncOnce(ctx, since, dispatchOpsMessage)
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"config": path, "room_id": cfg.RoomID, "result": result})
}

func matrixBridge(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-bridge")
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	fmt.Printf("matrix_bridge=running room=%s config=%s prefix=%s\n", cfg.RoomID, path, cfg.CommandPrefix)
	ctx, cancel := contextWithSignal()
	defer cancel()
	return matrixops.NewClient(cfg).Bridge(ctx, dispatchOpsMessage)
}

func matrixAIConfigInit(args []string) error {
	force := false
	for _, arg := range args {
		if arg == "--force" {
			force = true
			continue
		}
		return fmt.Errorf("usage: meshclaw matrix-ai-config-init [--force]")
	}
	path, err := aichat.DefaultConfigPath()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("matrix AI config already exists: %s", path)
		}
	}
	if err := aichat.SaveConfig(path, aichat.DefaultConfig()); err != nil {
		return err
	}
	fmt.Printf("matrix_ai_config=%s\n", path)
	return nil
}

func matrixAIChat(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw matrix-ai-chat <message>")
	}
	cfg, path, err := aichat.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	message := strings.Join(args, " ")
	reply, err := matrixAIReply(ctx, aichat.NewClient(cfg), nil, message)
	if err != nil {
		return err
	}
	fmt.Printf("ai_config=%s model=%s\n\n%s\n", path, cfg.Model, reply)
	return nil
}

func matrixAIBridge(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-ai-bridge")
	}
	matrixCfg, matrixPath, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	aiCfg, aiPath, err := aichat.LoadConfig()
	if err != nil {
		return err
	}
	client := aichat.NewClient(aiCfg)
	history := make([]aichat.Message, 0, 24)
	reply := func(message string) (string, error) {
		out, err := matrixAIReply(context.Background(), client, history, message)
		if err != nil {
			return "", err
		}
		history = append(history, aichat.Message{Role: "user", Content: message}, aichat.Message{Role: "assistant", Content: out})
		if len(history) > 24 {
			history = history[len(history)-24:]
		}
		return out, nil
	}
	fmt.Printf("matrix_ai_bridge=running room=%s matrix_config=%s ai_config=%s model=%s\n", matrixCfg.RoomID, matrixPath, aiPath, aiCfg.Model)
	ctx, cancel := contextWithSignal()
	defer cancel()
	return matrixops.NewClient(matrixCfg).BridgeReply(ctx, reply)
}

func matrixAIReply(ctx context.Context, client *aichat.Client, history []aichat.Message, message string) (string, error) {
	if isDangerousMatrixAIAction(message) {
		return dangerousMatrixAIActionResponse(message), nil
	}
	if shouldRouteMatrixAIToTool(message) {
		result, err := dispatchOpsMessage("matrix-ai", message)
		if err != nil {
			return "", err
		}
		return matrixops.FormatExplainedResultForQuery(result, message), nil
	}
	return client.Chat(ctx, history, message)
}

func isDangerousMatrixAIAction(message string) bool {
	lower := strings.ToLower(strings.TrimSpace(message))
	if lower == "" {
		return false
	}
	hasAction := containsAny(lower,
		"실행", "해줘", "삭제", "지워", "제거", "초기화", "재시작", "중지", "종료", "배포", "적용", "수정", "변경", "임대", "구매", "생성",
		"run", "execute", "delete", "remove", "wipe", "reset", "restart", "stop", "shutdown", "deploy", "apply", "modify", "change", "provision", "create",
	)
	if !hasAction {
		return false
	}
	return containsAny(lower,
		"rm -rf", "sudo", "systemctl", "docker", "kubectl", "iptables", "ufw", "chmod", "chown", "mkfs", "dd ",
		"서버", "노드", "서비스", "디스크", "파일", "폴더", "권한", "방화벽", "vps", "provider", "api key", "secret",
		"nginx", "postgres", "mysql", "redis", "docker", "ollama",
	) || mentionsKnownNode(lower)
}

func dangerousMatrixAIActionResponse(message string) string {
	return strings.Join([]string{
		"판단: 이 요청은 실제 시스템 변경 또는 파괴적 실행으로 이어질 수 있어서 대화 모델이 직접 수행하면 안 됩니다.",
		"",
		"요청:",
		message,
		"",
		"근거:",
		"- 서버 명령 실행, 삭제, 권한 변경, 서비스 재시작, 배포, VPS 임대, 외부 API 호출은 운영 상태를 바꿀 수 있습니다.",
		"- @ops-ai는 대화와 판단 정리를 맡고, 실제 실행은 @dev/MeshClaw 정책 게이트와 evidence 기록을 거쳐야 합니다.",
		"- 실행 범위, 대상 서버, 경로, 롤백 방법, 승인 주체가 명확하지 않으면 진행하면 안 됩니다.",
		"",
		"다음 행동:",
		"1. 대상 서버/서비스/경로를 정확히 지정합니다.",
		"2. 원하는 결과와 롤백 방법을 적습니다.",
		"3. 먼저 조회 명령으로 현재 상태를 확인합니다. 예: `서버 상태 보여줘`, `워크스페이스 보여줘`, `최근 기록 보여줘`.",
		"4. 실제 실행이 필요하면 @dev/MeshClaw policy-check와 evidence 기록을 거쳐 실행해야 합니다.",
	}, "\n")
}

func shouldRouteMatrixAIToTool(message string) bool {
	lower := strings.ToLower(strings.TrimSpace(message))
	if lower == "" {
		return false
	}
	hasQueryIntent := containsAny(lower,
		"보여줘", "보여 줘", "조회", "목록", "리스트", "확인", "체크", "상태", "최근", "현재",
		"어때", "왜", "높아", "문제", "이상", "알려줘", "요약", "해야", "깔려", "좋아", "돌리면",
		"show", "list", "check", "status", "current", "recent",
		"why", "problem", "issue",
	)
	if !hasQueryIntent {
		return false
	}
	return containsAny(lower,
		"workers", "worker", "작업자", "워커",
		"workspaces", "workspace", "워크스페이스", "작업공간",
		"ops-brief", "ops brief", "운영 브리핑", "운영 요약", "전체 요약", "뭐 해야", "무엇을 해야", "상태 요약",
		"node-inventory", "fleet-inventory", "software inventory", "설치", "깔려", "깔린", "인벤토리", "뭐뭐",
		"placement-plan", "workload", "배치", "어디서", "어디에", "어느 노드", "어디 노드", "돌려", "돌리면", "맡겨",
		"process-top", "process top", "top process", "프로세스", "상위 프로세스",
		"service-check", "service check", "서비스 체크", "서비스 확인",
		"service-audit", "service audit", "서비스 감사", "서비스 장애", "실패 서비스",
		"analyze-logs", "analyze logs", "로그 분석", "로그 확인",
		"security-check", "security check", "보안 점검", "보안 확인",
		"hygiene-scan-host", "hygiene scan", "민감정보", "개인정보", "시크릿", "secret scan",
		"fleet", "monitor", "서버", "모니터", "메모리", "디스크", "gpu", "cpu", "load",
		"evidence", "기록", "증거",
		"policy", "권한", "정책",
	) || mentionsKnownNode(lower)
}

func mentionsKnownNode(lower string) bool {
	return extractKnownNode(lower) != ""
}

func extractKnownNode(lower string) string {
	lower = strings.ToLower(strings.TrimSpace(lower))
	nodes := inventory.DefaultNodes()
	names := make([]string, 0, len(nodes))
	for _, node := range nodes {
		if name := strings.ToLower(strings.TrimSpace(node.Name)); name != "" {
			names = append(names, name)
		}
	}
	sort.Slice(names, func(i, j int) bool { return len(names[i]) > len(names[j]) })
	for _, name := range names {
		if strings.Contains(lower, name+" ") ||
			strings.Contains(lower, name+"에서") ||
			strings.Contains(lower, name+"에 ") ||
			strings.Contains(lower, name+"의") ||
			strings.Contains(lower, name+"가") ||
			strings.Contains(lower, name+"는") ||
			lower == name {
			return name
		}
	}
	return ""
}

func firstNonCommandToken(lower string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") {
			continue
		}
		if containsAny(token, "process-top", "process", "top", "프로세스", "상위") {
			continue
		}
		return token
	}
	return ""
}

func extractServiceName(lower, host string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") || token == host {
			continue
		}
		if containsAny(token, "service-check", "service", "check", "서비스", "체크", "확인", "상태", "보여줘") {
			continue
		}
		return token
	}
	return ""
}

func extractLogSource(lower, host string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") || token == host {
			continue
		}
		if containsAny(token, "analyze-logs", "analyze", "logs", "로그", "분석", "확인", "상태", "보여줘") {
			continue
		}
		return token
	}
	return "system"
}

func contextWithSignal() (context.Context, context.CancelFunc) {
	ctx, cancel := context.WithCancel(context.Background())
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-signals:
			cancel()
		case <-ctx.Done():
		}
		signal.Stop(signals)
	}()
	return ctx, cancel
}

func workersList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workers [--json]")
	}
	list := workers.DefaultWorkers()
	if jsonOut {
		return printJSON(list)
	}
	fmt.Printf("%-16s %-18s %-14s %-13s %s\n", "ID", "KIND", "SUBJECT", "STATUS", "SURFACE")
	for _, worker := range list {
		fmt.Printf("%-16s %-18s %-14s %-13s %s\n", worker.ID, worker.Kind, worker.Subject, worker.Status, worker.Surface)
	}
	return nil
}

func workspaceList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workspace-list [--json]")
	}
	list, path, err := workspace.List()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"path": path, "workspaces": list})
	}
	if len(list) == 0 {
		fmt.Printf("workspaces=0 path=%s\n", path)
		return nil
	}
	fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", "ID", "HOST", "PATH", "OWNER", "BRANCH", "PURPOSE")
	for _, ws := range list {
		fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", ws.ID, ws.Host, truncate(ws.Path, 32), ws.Owner, ws.Branch, ws.Purpose)
	}
	return nil
}

func workspaceAdd(args []string) error {
	if len(args) < 3 || len(args) > 5 {
		return fmt.Errorf("usage: meshclaw workspace-add <id> <host> <path> [owner] [purpose]")
	}
	ws := workspace.Workspace{ID: args[0], Host: args[1], Path: args[2]}
	if len(args) >= 4 {
		ws.Owner = args[3]
	}
	if len(args) >= 5 {
		ws.Purpose = args[4]
	}
	saved, path, err := workspace.Upsert(ws)
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "workspace": saved})
}

func workspaceActivity(args []string) error {
	if len(args) < 4 {
		return fmt.Errorf("usage: meshclaw workspace-activity <id> <actor> <action> <summary>")
	}
	activity := workspace.Activity{
		WorkspaceID: args[0],
		Actor:       args[1],
		Action:      args[2],
		Summary:     strings.Join(args[3:], " "),
	}
	record, err := workspace.RecordActivity(activity)
	if err != nil {
		return err
	}
	return printJSON(record)
}

func opsChat(args []string) error {
	if len(args) > 0 {
		return handleOpsChatMessage(strings.Join(args, " "))
	}
	fmt.Println("meshclaw ops-chat")
	fmt.Println("Try: workers, workspaces, fleet, evidence, policy, matrix, help, quit")
	scanner := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("you> ")
		if !scanner.Scan() {
			break
		}
		message := strings.TrimSpace(scanner.Text())
		if message == "" {
			continue
		}
		if message == "quit" || message == "exit" || message == "종료" {
			break
		}
		if err := handleOpsChatMessage(message); err != nil {
			fmt.Fprintf(os.Stderr, "meshclaw: %v\n", err)
		}
	}
	return scanner.Err()
}

func opsDispatch(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>")
	}
	result, err := dispatchOpsMessage(args[0], strings.Join(args[1:], " "))
	if err != nil {
		return err
	}
	return printJSON(result)
}

func dispatchOpsMessage(source, message string) (map[string]interface{}, error) {
	source = strings.ToLower(strings.TrimSpace(source))
	if source == "" {
		source = "unknown"
	}
	lower := strings.ToLower(strings.TrimSpace(message))
	result := map[string]interface{}{
		"source":  source,
		"message": message,
	}
	switch {
	case isIntroMessage(lower):
		result["route"] = "intro"
		result["result"] = introResult()
	case containsAny(lower, "workers", "worker", "!workers", "작업자", "워커"):
		result["route"] = "workers"
		result["result"] = workers.DefaultWorkers()
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		ws, path, err := workspace.Upsert(workspace.Workspace{ID: "meshclaw-local", Host: "local", Path: "/Users/dragon/meshclaw", Owner: source, Purpose: "serverops", Source: source})
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_add"
		result["result"] = map[string]interface{}{"path": path, "workspace": ws}
	case containsAny(lower, "workspaces", "workspace", "!workspaces", "워크스페이스", "작업공간"):
		list, path, err := workspace.List()
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_list"
		result["result"] = map[string]interface{}{"path": path, "workspaces": list}
	case containsAny(lower, "ops-brief", "ops brief", "운영 브리핑", "운영 요약", "전체 요약", "뭐 해야", "무엇을 해야", "상태 요약"):
		brief, record, storeErr, err := buildOpsBrief()
		if err != nil {
			return nil, err
		}
		result["route"] = "ops_brief"
		result["result"] = map[string]interface{}{"report": brief, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "node-inventory", "fleet-inventory", "software inventory", "설치", "깔려", "깔린", "인벤토리", "뭐뭐"):
		host := extractKnownNode(lower)
		if host == "" || containsAny(lower, "전체", "모든", "fleet", "서버들", "노드별") {
			report, record, storeErr := runFleetInventory(nil, 4)
			result["route"] = "fleet_inventory"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		} else {
			report := workflow.SoftwareInventory(host)
			record, storeErr := evidence.Store("node-inventory", host, report.Status, report)
			result["route"] = "node_inventory"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		}
	case containsAny(lower, "placement-plan", "workload", "배치", "어디서", "어디에", "어느 노드", "어디 노드", "돌려", "돌리면", "맡겨"):
		report, record, storeErr, err := buildPlacementPlan(message)
		if err != nil {
			return nil, err
		}
		result["route"] = "placement_plan"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "process-top", "process top", "top process", "프로세스", "상위 프로세스"):
		host := extractKnownNode(lower)
		if host == "" {
			host = firstNonCommandToken(lower)
		}
		report := workflow.ProcessTop(host)
		record, storeErr := evidence.Store("process-top", host, "top memory/cpu processes", report)
		result["route"] = "process_top"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "service-check", "service check", "서비스 체크", "서비스 확인"):
		host := extractKnownNode(lower)
		service := extractServiceName(lower, host)
		report := workflow.ServiceCheck(host, service)
		record, storeErr := evidence.Store("service-check", host, service, report)
		result["route"] = "service_check"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "service-audit", "service audit", "서비스 감사", "서비스 장애", "실패 서비스"):
		host := extractKnownNode(lower)
		if containsAny(lower, "전체", "모든", "all", "fleet") || host == "" {
			report, record, storeErr := runFleetServiceAudit(nil, 4)
			result["route"] = "fleet_service_audit"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		} else {
			report := workflow.ServiceAudit(host)
			record, storeErr := evidence.Store("service-audit", host, "failed/restarting services", report)
			result["route"] = "service_audit"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		}
	case containsAny(lower, "analyze-logs", "analyze logs", "로그 분석", "로그 확인"):
		host := extractKnownNode(lower)
		sourceName := extractLogSource(lower, host)
		report := workflow.AnalyzeLogs(host, sourceName)
		record, storeErr := evidence.Store("analyze-logs", host, sourceName, report)
		result["route"] = "analyze_logs"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "security-check", "security check", "보안 점검", "보안 확인"):
		host := extractKnownNode(lower)
		report := workflow.SecurityCheck(host)
		record, storeErr := evidence.Store("security-check", host, "read-only snapshot", report)
		result["route"] = "security_check"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "hygiene-scan-host", "hygiene scan", "민감정보", "개인정보", "시크릿", "secret scan"):
		host := extractKnownNode(lower)
		report := hygiene.ScanHost(host)
		record, storeErr := evidence.Store("hygiene-scan-host", host, report.Status, report)
		result["route"] = "hygiene_scan_host"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "fleet", "monitor", "!fleet", "서버 상태", "상태", "모니터", "메모리", "디스크", "cpu", "gpu", "load") || mentionsKnownNode(lower):
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		states := m.CheckAll()
		result["route"] = "monitor_check"
		result["result"] = monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	case containsAny(lower, "evidence", "!evidence", "기록", "증거"):
		records, err := evidence.List(10)
		if err != nil {
			return nil, err
		}
		result["route"] = "evidence_list"
		result["result"] = records
	case containsAny(lower, "policy", "!policy", "권한", "정책"):
		cfg, path, err := policy.LoadConfig()
		if err != nil {
			return nil, err
		}
		result["route"] = "policy_summary"
		result["result"] = policySummary(path, cfg)
	case containsAny(lower, "matrix", "매트릭스"):
		result["route"] = "matrix_plan"
		result["result"] = integrationDifference("matrix")
	case containsAny(lower, "openwebui", "open webui", "웹유아이"):
		result["route"] = "openwebui_plan"
		result["result"] = integrationDifference("openwebui")
	default:
		result["route"] = "chat"
		result["result"] = relaxedChatResult(source, message)
	}
	return result, nil
}

func isIntroMessage(lower string) bool {
	lower = strings.TrimSpace(lower)
	switch lower {
	case "hi", "hello", "hey", "안녕", "안녕하세요", "넌 누구지?", "너 누구야?", "누구야?", "who are you?", "대화는 불가능한거야?", "대화 가능해?", "뭐 할 수 있어?", "사용법", "!help", "help", "도움말":
		return true
	default:
		return containsAny(lower, "대화 가능", "대화는 불가능", "뭐 할 수", "무엇을 할 수", "사용법", "도움말")
	}
}

func introResult() map[string]interface{} {
	return map[string]interface{}{
		"name":         "MeshClaw Matrix bridge",
		"role":         "ServerOps control-plane bridge. I can have short operations-focused dialogue in Matrix, but I am not the general assistant brain. Codex, Claude, ChatGPT, or local LLMs should do broad reasoning; I provide policy, workspace, evidence, monitoring, and vssh-backed operations.",
		"conversation": "You can talk casually in this Matrix room. I will answer lightly and route server/workspace/policy/evidence requests into MeshClaw tools.",
		"commands": []string{
			"!workers",
			"!workspaces",
			"!fleet",
			"!policy",
			"!evidence",
		},
	}
}

func relaxedChatResult(source, message string) map[string]interface{} {
	reply := "응, 편하게 말해도 돼. 나는 일반 비서라기보다는 MeshClaw 서버 운영 브리지라서, 서버 상태/워크스페이스/정책/기록/vssh 실행 쪽으로 바로 도와줄 수 있어."
	return map[string]interface{}{
		"reply":  reply,
		"source": source,
		"heard":  message,
		"try": []string{
			"서버 상태 보여줘",
			"워크스페이스 보여줘",
			"정책 보여줘",
			"최근 기록 보여줘",
			"!workers",
		},
	}
}

func handleOpsChatMessage(message string) error {
	lower := strings.ToLower(strings.TrimSpace(message))
	fmt.Println("meshclaw>")
	switch {
	case containsAny(lower, "help", "도움", "?"):
		fmt.Println(`Available conversation checks:
- workers / 작업자: show model/operator workers
- workspaces / 워크스페이스: show server/folder ownership
- fleet / 서버 상태: run monitor-check
- evidence / 기록: show recent evidence
- policy / 권한: show current policy
- matrix / 매트릭스: show Matrix ops-room plan
- add current workspace / 현재 워크스페이스 등록: register /Users/dragon/meshclaw`)
		return nil
	case containsAny(lower, "workers", "worker", "작업자", "워커"):
		return workersList(nil)
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		return workspaceAdd([]string{"meshclaw-local", "local", "/Users/dragon/meshclaw", "human", "serverops"})
	case containsAny(lower, "workspaces", "workspace", "워크스페이스", "작업공간"):
		return workspaceList(nil)
	case containsAny(lower, "fleet", "monitor", "서버 상태", "상태", "모니터"):
		return monitorCheck(nil)
	case containsAny(lower, "evidence", "기록", "증거"):
		return evidenceList([]string{"10"})
	case containsAny(lower, "policy", "권한", "정책"):
		return opsPolicySummary()
	case containsAny(lower, "matrix", "매트릭스"):
		return matrixBridgePlan(nil)
	default:
		fmt.Println("I can route ops-room phrases to MeshClaw tools. Type help for examples.")
		return nil
	}
}

func opsPolicySummary() error {
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	summary := policySummary(path, cfg)
	fmt.Printf("policy path=%s rules=%d allow=%d require_approval=%d deny=%d\n", summary["path"], summary["rules"], summary["allow"], summary["require_approval"], summary["deny"])
	fmt.Println("Use `meshclaw policy-show` for the full policy JSON.")
	return nil
}

func policySummary(path string, cfg policy.Config) map[string]interface{} {
	allow, gate, deny := 0, 0, 0
	for _, rule := range cfg.Rules {
		switch rule.Decision {
		case policy.Allow:
			allow++
		case policy.RequireApproval:
			gate++
		case policy.Deny:
			deny++
		}
	}
	return map[string]interface{}{"path": path, "rules": len(cfg.Rules), "allow": allow, "require_approval": gate, "deny": deny}
}

func integrationDifference(name string) map[string]interface{} {
	switch name {
	case "openwebui":
		return map[string]interface{}{
			"role":        "Open WebUI is a local/private model chat frontend. It should call MeshClaw through MCP/tool bridge for server facts, workspace state, and evidence.",
			"best_for":    []string{"local model chat", "private log analysis", "single-user model experiments", "redacted summaries"},
			"not_for":     []string{"shared approvals", "team timeline", "persistent operations room"},
			"entrypoints": []string{"meshclaw mcp", "meshclaw ops-dispatch openwebui <message>", "meshclaw workspace_* tools"},
		}
	default:
		return map[string]interface{}{
			"role":        "Matrix is a shared operations room for humans, friends, Codex, Claude, local LLMs, approvals, notifications, screenshots, and evidence links.",
			"best_for":    []string{"shared timeline", "approval workflow", "multi-model handoff", "screenshots and evidence posting"},
			"not_for":     []string{"replacing Codex/Claude apps", "being the assistant brain"},
			"entrypoints": []string{"!workers", "!workspaces", "!fleet", "meshclaw ops-dispatch matrix <message>"},
		}
	}
}

func containsAny(value string, needles ...string) bool {
	for _, needle := range needles {
		if strings.Contains(value, strings.ToLower(needle)) {
			return true
		}
	}
	return false
}

func wantsJSON(args []string) bool {
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			return true
		}
	}
	return false
}

func withoutJSONFlag(args []string) []string {
	filtered := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			continue
		}
		filtered = append(filtered, arg)
	}
	return filtered
}

func printJSON(value interface{}) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	return nil
}

func printEvidenceStoreStatus(record evidence.Record, err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", err)
		return
	}
	fmt.Printf("evidence=%s\n", record.StoredAt)
}

func provisionPlan(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw provision-plan <purpose> [budget-usd]")
	}
	req := provision.Request{Purpose: args[0], TTLHours: 6, RequiredClass: "small-vps"}
	if len(args) == 2 {
		if _, err := fmt.Sscanf(args[1], "%f", &req.BudgetUSD); err != nil {
			return fmt.Errorf("invalid budget-usd: %s", args[1])
		}
	}
	plan := provision.NewPlan(req)
	record, storeErr := evidence.Store("provision-plan", "provider", req.Purpose, plan)
	if err := printJSON(map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(storeErr)}); err != nil {
		return err
	}
	return nil
}

func run(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	out, err := runtime.NewRunner().Run(host, command)
	fmt.Print(out)
	return err
}

func runEvidence(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run-evidence <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("run-evidence", host, command, result)
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("execution failed on %s", host)
	}
	return nil
}

func jobStart(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw job-start <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result, err := runtime.NewRunner().VSSHJSON("job-start", host, command)
	record, storeErr := evidence.Store("job-start", host, command, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobStatus(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-status <host> <id>")
	}
	return jobRead(args[0], args[1], "job-status")
}

func jobLogs(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw job-logs <host> <id> [tail-bytes]")
	}
	params := []string{"job-logs", args[0], args[1]}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_logs", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("job-logs", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobCancel(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-cancel <host> <id>")
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_cancel", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON("job-cancel", args[0], args[1])
	record, storeErr := evidence.Store("job-cancel", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobRead(host, id, command string) error {
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_status", Resource: "server", Context: id})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(command, host, id)
	record, storeErr := evidence.Store(command, host, id, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func artifactCollect(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw artifact-collect <host> <path> [max-bytes]")
	}
	host, path := args[0], args[1]
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "artifact_collect", Resource: "server", Context: path})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	params := []string{"artifact-collect", host, path}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("artifact-collect", host, path, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func printResultWithEvidence(result interface{}, record evidence.Record, storeErr error, err error) error {
	if printErr := printJSON(map[string]interface{}{"result": result, "evidence": record, "store_error": errString(storeErr)}); printErr != nil {
		return printErr
	}
	return err
}

func runDoctor(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw doctor <host>")
	}
	fmt.Print(doctor.Check(args[0]))
	return nil
}

func analyzeLogs(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw analyze-logs <host> <source>")
	}
	report := workflow.AnalyzeLogs(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("analyze-logs", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceCheck(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-check <host> <service>")
	}
	report := workflow.ServiceCheck(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-check", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceAudit(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw service-audit <host>")
	}
	report := workflow.ServiceAudit(args[0])
	printReport(report)
	record, storeErr := evidence.Store("service-audit", args[0], "failed/restarting services", report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("service-audit failed on %s", args[0])
	}
	return nil
}

func serviceQuarantine(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-quarantine <host> <service>")
	}
	report := workflow.ServiceQuarantine(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-quarantine", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceRemove(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw service-remove <host> <service> [working-directory]")
	}
	path := ""
	if len(args) == 3 {
		path = args[2]
	}
	report := workflow.ServiceRemove(args[0], args[1], path)
	printReport(report)
	record, storeErr := evidence.Store("service-remove", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func securityCheck(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw security-check <host>")
	}
	report := workflow.SecurityCheck(args[0])
	printReport(report)
	record, storeErr := evidence.Store("security-check", args[0], "read-only snapshot", report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygienePlan(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-plan <host>")
	}
	printHygieneReport(hygiene.Plan(args[0]))
	return nil
}

func hygieneScanHost(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-host <host>")
	}
	report := hygiene.ScanHost(args[0])
	record, storeErr := evidence.Store("hygiene-scan-host", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printHygieneReport(report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygieneScanText(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-text <target> <text>")
	}
	printHygieneReport(hygiene.ScanText(args[0], strings.Join(args[1:], " ")))
	return nil
}

func printReport(report workflow.Report) {
	fmt.Printf("%s host=%s status=%s\n", report.Name, report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- [%s] %s\n  evidence: %s\n  next: %s\n", finding.Severity, finding.Title, finding.Evidence, finding.Next)
	}
}

func printHygieneReport(report hygiene.Report) {
	fmt.Printf("hygiene host=%s status=%s\n", report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- finding [%s] %s target=%s evidence=%s\n", finding.Severity, finding.Type, finding.Target, finding.Evidence)
	}
	for _, action := range report.Actions {
		fmt.Printf("- action [%s] %s target=%s\n  command: %s\n  reason: %s\n  verify: %s\n", action.Mode, action.ID, action.Target, action.Command, action.Reason, action.Verify)
	}
}

func mcp() error {
	return cmdMCP()
}
