# setup.py

from setuptools import setup, find_packages

setup(
    name="intelliocr",
    version="0.1.0",
    description="Advanced OCR using EasyOCR, TrOCR, and NLP correction",
    author="Your Name",
    packages=find_packages(),
    install_requires=[
        "torch",
        "torchvision",
        "transformers",
        "easyocr",
        "opencv-python",
        "Pillow"
    ],
    entry_points={
        "console_scripts": [
            "intelliocr=cli:main",
        ],
    },
)