# intelliocr/__init__.py

from .pipeline import IntelliOCR

__all__ = ["IntelliOCR"]