# intelliocr/recognizer.py

from transformers import TrOCRProcessor, VisionEncoderDecoderModel

class TextRecognizer:
    def __init__(self, device: str):
        self.device = device
        self.processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
        self.model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-handwritten").to(self.device)
 
    def recognize_crop(self, cropped_image):
        """Runs TrOCR on a single text crop."""
        pixel_values = self.processor(cropped_image, return_tensors="pt").pixel_values.to(self.device)
        generated_ids = self.model.generate(pixel_values, max_new_tokens=32)
        text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)
        return text[0]