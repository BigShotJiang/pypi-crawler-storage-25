import cv2

def draw_boxes(image_path, regions, output_path="output.jpg"):
    img = cv2.imread(image_path)

    for region in regions:
        if "bbox" not in region:
            continue

        bbox = region["bbox"]

        pts = [(int(x), int(y)) for x, y in bbox]

        for i in range(len(pts)):
            cv2.line(img, pts[i], pts[(i+1) % len(pts)], (0, 255, 0), 2)

    cv2.imwrite(output_path, img)
    print(f"  Saved visualized image to {output_path}")