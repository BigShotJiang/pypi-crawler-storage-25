# # intelliocr/detector.py

import easyocr

# class TextDetector:
#     def __init__(self, device: str):
#         self.reader = easyocr.Reader(['en'], gpu=(device == 'cuda'))

#     def detect(self, image_path: str):
#         results = self.reader.readtext(image_path)

#         formatted = []
#         for res in results:
#             formatted.append({
#                 "bbox": res[0],
#                 "text": res[1],
#                 "confidence": res[2]
#             })

#         return formatted

 

import easyocr


class TextDetector:
    def __init__(self, use_gpu=True):
        self.reader = easyocr.Reader(['en'], gpu=use_gpu)

    def detect(self, image_path):
        return self.reader.readtext(image_path)