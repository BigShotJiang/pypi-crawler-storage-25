# # from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
# # import torch

# # class TextCorrector:
# #     def __init__(self, device):
# #         self.device = torch.device(device)

# #         self.tokenizer = AutoTokenizer.from_pretrained(
# #             "vennify/t5-base-grammar-correction"
# #         )

# #         self.model = AutoModelForSeq2SeqLM.from_pretrained(
# #             "vennify/t5-base-grammar-correction"
# #         ).to(self.device)

# #     def correct(self, text):
# #         if not text.strip():
# #             return ""

# #         input_text = f"gec: {text}"

# #         inputs = self.tokenizer(
# #             input_text,
# #             return_tensors="pt",
# #             truncation=True,
# #             padding=True
# #         ).to(self.device)

# #         outputs = self.model.generate(
# #             **inputs,
# #             max_new_tokens=128
# #         )

# #         corrected = self.tokenizer.decode(
# #             outputs[0],
# #             skip_special_tokens=True
# #         )

# #         return corrected

 


# from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
# import torch
# import re


# class TextCorrector:
#     def __init__(self, device):
#         self.device = torch.device(device)

#         # 🔥 NEW MODEL (SMARTER)
#         model_name = "google/flan-t5-base"

#         self.tokenizer = AutoTokenizer.from_pretrained(model_name)
#         self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)

#     def _clean_input(self, text):
#         text = text.lower()

#         # fix spacing issues
#         text = re.sub(r'\s+', ' ', text)
#         text = re.sub(r'\s+\.', '.', text)
#         text = re.sub(r'\s+,', ',', text)

#         return text.strip()

#     def correct(self, text):
#         if not text.strip():
#             return ""

#         text = self._clean_input(text)

#         # 🔥 POWERFUL PROMPT (KEY CHANGE)
#         input_text = (
#             "Rewrite the following noisy OCR text into clear, meaningful, "
#             "and grammatically correct English:\n\n"
#             f"{text}"
#         )

#         inputs = self.tokenizer(
#             input_text,
#             return_tensors="pt",
#             truncation=True,
#             padding=True
#         ).to(self.device)

#         outputs = self.model.generate(
#             **inputs,
#             max_new_tokens=200,   # allow longer sentences
#             num_beams=5,          # better quality
#             temperature=0.7,
#             early_stopping=True
#         )

#         corrected = self.tokenizer.decode(
#             outputs[0],
#             skip_special_tokens=True
#         )

#         return corrected

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch
import re


class TextCorrector:
    def __init__(self, device):
        self.device = torch.device(device)

        model_name = "google/flan-t5-base"

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)

    def _clean_input(self, text):
        text = text.lower()
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

    def correct(self, text):
        if not text.strip():
            return ""

        text = self._clean_input(text)

        input_text = (
            "Clean and rewrite this noisy OCR text into clear, correct English. "
            "Ignore meaningless or corrupted words:\n\n"
            f"{text}"
        )

        inputs = self.tokenizer(
            input_text,
            return_tensors="pt",
            truncation=True,
            padding=True
        ).to(self.device)

        outputs = self.model.generate(
            **inputs,
            max_new_tokens=150,
            num_beams=5,
            temperature=0.7,
            early_stopping=True
        )

        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)