# import torch
# import warnings
# import os
# import re
# from PIL import Image

# from transformers.utils import logging

# from .detector import TextDetector
# from .recognizer import TextRecognizer
# from .corrector import TextCorrector

# # 🔥 CLEAN LOGS
# warnings.filterwarnings("ignore")
# logging.set_verbosity_error()
# os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"


# class IntelliOCR:
#     def __init__(self, use_gpu=True):
#         self.device = "cuda" if use_gpu and torch.cuda.is_available() else "cpu"

#         self.detector = TextDetector(use_gpu)
#         self.recognizer = TextRecognizer(self.device)
#         self.corrector = TextCorrector(self.device)

#     def _crop_image(self, image, bbox):
#         xs = [p[0] for p in bbox]
#         ys = [p[1] for p in bbox]

#         left, top = int(min(xs)), int(min(ys))
#         right, bottom = int(max(xs)), int(max(ys))

#         padding = 2

#         return image.crop((
#             max(0, left - padding),
#             max(0, top - padding),
#             right + padding,
#             bottom + padding
#         ))

#     def process_image(self, image_path):
#         image = Image.open(image_path).convert("RGB")

#         #   USE ORIGINAL IMAGE FOR DETECTION (IMPORTANT FIX)
#         boxes = self.detector.reader.readtext(image_path)

#         #   SORT TOP → BOTTOM
#         boxes = sorted(boxes, key=lambda x: x[0][0][1])

#         raw_texts = []
#         regions = []

#         for idx, item in enumerate(boxes):
#             try:
#                 bbox = item[0]
#                 easy_text = item[1]
#                 prob = item[2]

#                 # 🔥 SKIP TOP REGION NOISE (calendar/header area)
#                 if bbox[0][1] < 80:
#                     continue

#                 #   HANDWRITING-FRIENDLY FILTER
#                 if prob < 0.15:
#                     continue

#                 if len(easy_text.strip()) < 2:
#                     continue

#                 crop = self._crop_image(image, bbox)

#                 raw_text = self.recognizer.recognize_crop(crop)

#                 # 🔥 HYBRID BOOST: Use EasyOCR as fallback if TrOCR is too short
#                 if len(raw_text.strip()) < 3:
#                     raw_text = easy_text

#                 raw_texts.append(raw_text)

#                 regions.append({
#                     "region_id": idx,
#                     "bbox": [[int(x), int(y)] for x, y in bbox],
#                     "text": raw_text,
#                     "confidence": float(prob)
#                 })

#             except Exception as e:
#                 regions.append({
#                     "region_id": idx,
#                     "error": str(e)
#                 })

#         # 🔥 PREPARE TEXT
#         full_raw_text = " ".join(raw_texts)
#         full_raw_text = re.sub(r'[^a-zA-Z0-9.,\s]', '', full_raw_text)
#         full_raw_text = full_raw_text.lower()

#         # 🔥 COMMON OCR SPELL FIXES
#         common_fixes = {
#             "lebpage": "webpage",
#             "ernail": "email",
#             "alsteady": "already",
#             "wden": "code",
#             "i t": "it",
#             "t h e": "the",
#             "a n d": "and",
#             "h i m": "him",
#             "h e r": "her",
#             "w a s": "was"
#         }
#         for wrong, correct in common_fixes.items():
#             full_raw_text = full_raw_text.replace(wrong, correct)

#         full_raw_text = full_raw_text.replace(",", ".")

#         # 🔥 SPLIT INTO SENTENCES
#         sentences = full_raw_text.split(".")
#         sentences = [s.strip() for s in sentences if len(s.strip()) > 5]

#         # 🔥 CORRECT EACH SENTENCE
#         corrected_sentences = []
#         for sentence in sentences:
#             corrected = self.corrector.correct(sentence)
#             corrected_sentences.append(corrected)

#         # 🔥 FINAL OUTPUT
#         full_corrected_text = " ".join(corrected_sentences)

#         return {
#             "raw_text": full_raw_text,
#             "corrected_text": full_corrected_text,
#             "regions": regions
#         }

import torch
import warnings
import os
import re
from PIL import Image

from transformers.utils import logging

from .detector import TextDetector
from .recognizer import TextRecognizer
from .corrector import TextCorrector

# CLEAN LOGS
warnings.filterwarnings("ignore")
logging.set_verbosity_error()
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"


class IntelliOCR:
    def __init__(self, use_gpu=True):
        self.device = "cuda" if use_gpu and torch.cuda.is_available() else "cpu"

        self.detector = TextDetector(use_gpu)
        self.recognizer = TextRecognizer(self.device)
        self.corrector = TextCorrector(self.device)

    def _crop_image(self, image, bbox):
        xs = [p[0] for p in bbox]
        ys = [p[1] for p in bbox]

        left, top = int(min(xs)), int(min(ys))
        right, bottom = int(max(xs)), int(max(ys))

        padding = 2

        return image.crop((
            max(0, left - padding),
            max(0, top - padding),
            right + padding,
            bottom + padding
        ))

    # 🔥 REMOVE GARBAGE WORDS
    def _remove_garbage(self, text):
        words = text.split()
        cleaned = []

        for w in words:
            if len(w) > 2 and re.match("^[a-zA-Z0-9]+$", w):
                cleaned.append(w)

        return " ".join(cleaned)

    def process_image(self, image_path):
        image = Image.open(image_path).convert("RGB")

        boxes = self.detector.reader.readtext(image_path)
        boxes = sorted(boxes, key=lambda x: x[0][0][1])

        raw_texts = []
        regions = []

        for idx, item in enumerate(boxes):
            try:
                bbox = item[0]
                easy_text = item[1]
                prob = item[2]

                # 🔥 skip header noise
                if bbox[0][1] < 80:
                    continue

                if prob < 0.15:
                    continue

                if len(easy_text.strip()) < 2:
                    continue

                crop = self._crop_image(image, bbox)
                raw_text = self.recognizer.recognize_crop(crop)

                # 🔥 fallback to EasyOCR
                if len(raw_text.strip()) < 3:
                    raw_text = easy_text

                raw_texts.append(raw_text)

                regions.append({
                    "region_id": idx,
                    "bbox": [[int(x), int(y)] for x, y in bbox],
                    "text": raw_text,
                    "confidence": float(prob)
                })

            except Exception as e:
                # Keep pipeline resilient: fallback to EasyOCR text on region-level failures.
                if easy_text and len(easy_text.strip()) >= 2:
                    raw_texts.append(easy_text)
                regions.append({
                    "region_id": idx,
                    "error": str(e)
                })

        # 🔥 JOIN TEXT
        full_raw_text = " ".join(raw_texts)

        # 🔥 BASIC CLEAN
        full_raw_text = re.sub(r'[^a-zA-Z0-9.,\s]', '', full_raw_text)
        full_raw_text = full_raw_text.lower()

        # 🔥 REMOVE GARBAGE WORDS
        full_raw_text = self._remove_garbage(full_raw_text)

        # 🔥 COMMON FIXES
        common_fixes = {
            "lebpage": "webpage",
            "ernail": "email",
            "alsteady": "already",
            "signin": "sign in"
        }

        for wrong, correct in common_fixes.items():
            full_raw_text = full_raw_text.replace(wrong, correct)

        # 🔥 BETTER SPLIT
        full_raw_text = full_raw_text.replace(",", ".")
        sentences = full_raw_text.split(".")
        sentences = [s.strip() for s in sentences if len(s.strip()) > 5]

        # 🔥 LIMIT INPUT (VERY IMPORTANT)
        sentences = sentences[:10]

        # 🔥 CORRECT EACH SENTENCE
        corrected_sentences = []

        for sentence in sentences:
            corrected = self.corrector.correct(sentence)
            corrected_sentences.append(corrected)

        full_corrected_text = " ".join(corrected_sentences)

        return {
            "raw_text": full_raw_text,
            "corrected_text": full_corrected_text,
            "regions": regions
        }