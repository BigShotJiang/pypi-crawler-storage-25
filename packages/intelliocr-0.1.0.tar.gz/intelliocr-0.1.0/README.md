# SmartOCR

Lightweight OCR tool with handwriting support and reliable text cleanup.

## Features
- Printed + Handwritten OCR
- Minimal spelling correction
- CLI support

## Usage
```bash
smartocr image.jpg
