import{w as s}from"./svelte-DMYT0arj.js";const o=s(null);export{o as s};
