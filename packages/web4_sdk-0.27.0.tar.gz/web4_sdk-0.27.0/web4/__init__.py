"""
Web4 SDK — core data types and operations.

Provides offline-capable primitives for:
- Trust tensors (T3/V3) — multi-dimensional trust and value assessment
- Linked Context Tokens (LCT) — identity and presence substrate
- ATP/ADP lifecycle — bio-inspired value metabolism
- Federation (SAL) — Society, Authority, Law governance with citizenship lifecycle,
  quorum policy, ledger types, law merge, and audit adjustments
- R7 Action Framework — Rules+Role+Request+Reference+Resource->Result+Reputation
- MRH graph — Markov Relevancy Horizon context traversal
- ACP — Agentic Context Protocol for autonomous agent workflows
- Dictionary entities — semantic bridges with trust-tracked translation
- Reputation computation — rule-based reputation engine with aggregation and decay
- Entity taxonomy — behavioral modes, energy patterns, and interaction rules
- Capability levels — 6-level LCT capability framework (Stub -> Hardware)
- Error taxonomy — RFC 9457 error types for 6 Web4 protocol categories
- Metabolic states — society operational modes with energy, trust, and witness effects
- Multi-device binding — device constellation management, trust computation, and recovery
- Society — core organizational primitive composing federation, treasury, ledger, and trust
- Society Roles — the 7 base-mandatory role taxonomy with role-LCT binding
- Security primitives — crypto suite definitions, W4ID identifiers, key policies, VCs
- Core protocol — handshake, transport, discovery, and Web4 URI types
- MCP protocol types — Web4 context headers, resources, sessions, ATP metering
- Attestation — unified hardware trust envelope, verification dispatcher
- Validation — JSON Schema validation for all Web4 JSON-LD document types
- Deserialization — generic JSON-LD dispatcher for all Web4 types
- Generation — produce minimal valid JSON-LD documents for any Web4 type

23 modules + MCP server, 369 exports, 2709 tests, 3 behavioral functions, 8 MCP tools, 7 CLI subcommands.
v0.27.0: Society roles, Constraint alignment, conformance test runner, validate_minimum_viable.
These modules define the canonical data types and algorithms specified in the web4-standard.
They work offline (no network services required) and are designed to be
imported by applications, services, and other SDKs that build on web4.

Usage::

    from web4 import T3, LCT, Society, R7Action
    from web4 import W4ID, parse_w4id
    from web4 import ATPAccount, energy_ratio
    from web4 import from_jsonld, generate

For module-specific imports (recommended for large applications)::

    from web4.trust import T3, V3
    from web4.federation import Society, LawDataset
    from web4.security import W4ID, CryptoSuite
"""

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("web4")
except Exception:
    __version__ = "0.0.0"  # fallback when not installed

# ── Trust (T3/V3) ──────────────────────────────────────────────
from .trust import (
    T3,
    V3,
    TrustProfile,
    ActionOutcome,
    RoleRequirement,
    RoleTensors,
    TrustQuery,
    TrustQueryResponse,
    DisclosureLevel,
    compute_team_t3,
    operational_health,
    is_healthy,
    diminishing_returns,
    trust_bridge,
    evaluate_trust_query,
    TrustResolution,
    resolve_trust,
    TRUST_QUERY_JSONLD_CONTEXT,
    TRUST_QUERY_MIN_STAKE,
    TRUST_QUERY_MIN_VALIDITY,
    TRUST_QUERY_MAX_VALIDITY,
    T3_JSONLD_CONTEXT,
    V3_JSONLD_CONTEXT,
)

# ── Linked Context Tokens ──────────────────────────────────────
from .lct import (
    LCT,
    EntityType,
    RevocationStatus,
    BirthCertificate,
    Attestation,
    LineageEntry,
    LCT_JSONLD_CONTEXT,
)

# LCT sub-types (aliased to avoid collision with binding/mrh modules)
from .lct import Binding as LCTBinding
from .lct import MRH as LCTMRH
from .lct import MRHPairing as LCTMRHPairing
from .lct import Policy as LCTPolicy

# ── ATP/ADP ────────────────────────────────────────────────────
from .atp import (
    ATPAccount,
    TransferResult,
    ATP_JSONLD_CONTEXT,
    energy_ratio,
    transfer,
    sliding_scale,
    check_conservation,
    sybil_cost,
    fee_sensitivity,
)

# ── Federation (SAL) ──────────────────────────────────────────
from .federation import (
    Society,
    Society as FederationSociety,
    LawDataset,
    Delegation,
    RoleType,
    CitizenshipStatus,
    CitizenshipRecord,
    valid_citizenship_transition,
    QuorumMode,
    QuorumPolicy,
    LedgerType,
    AuditRequest,
    AuditAdjustment,
    Norm,
    Procedure,
    Interpretation,
    merge_law,
    norm_to_dict,
    norm_from_dict,
    procedure_to_dict,
    procedure_from_dict,
    interpretation_to_dict,
    interpretation_from_dict,
    law_dataset_to_dict,
    law_dataset_from_dict,
    delegation_to_dict,
    delegation_from_dict,
    quorum_policy_to_dict,
    quorum_policy_from_dict,
)

# ── R7 Action Framework ───────────────────────────────────────
from .r6 import (
    R7Action,
    ActionChain,
    ActionStatus,
    ReputationDelta,
    Rules,
    Role,
    Request,
    ResourceRequirements,
    Result,
    build_action,
    R7_JSONLD_CONTEXT,
    R7Error,
    Constraint,
    ContributingFactor,
    Precedent,
    Reference,
    TensorDelta,
    ReferenceInvalid,
    ReputationComputationError,
    RequestMalformed,
    ResourceInsufficient,
    ResultInvalid,
    RoleUnauthorized,
    RuleViolation,
)

# ── MRH Graph ─────────────────────────────────────────────────
from .mrh import (
    MRHGraph,
    MRHNode,
    MRHEdge,
    RelationType,
    relation_category,
    mrh_trust_decay,
    mrh_zone,
    propagate_multiplicative,
    propagate_probabilistic,
    propagate_maximal,
)

# ── ACP (Agentic Context Protocol) ────────────────────────────
from .acp import (
    ACP_JSONLD_CONTEXT,
    ACPStateMachine,
    ACPState,
    ACPError,
    AgentPlan,
    PlanStep,
    Intent,
    Decision,
    DecisionType,
    ProofOfAgency,
    ExecutionRecord,
    ApprovalMode,
    ResourceCaps,
    Guards,
    Trigger,
    TriggerKind,
    build_intent,
    validate_plan,
    HumanApproval,
    ApprovalRequired,
    InvalidTransition,
    LedgerWriteFailure,
    NoValidGrant,
    PlanExpired,
    ResourceCapExceeded,
    ScopeViolation,
    WitnessDeficit,
)

# ── Dictionary Entities ───────────────────────────────────────
from .dictionary import (
    DICTIONARY_JSONLD_CONTEXT,
    DictionaryEntity,
    DictionarySpec,
    DictionaryType,
    DictionaryVersion,
    CompressionProfile,
    DomainCoverage,
    TranslationRequest,
    TranslationResult,
    TranslationChain,
    dictionary_selection_score,
    select_best_dictionary,
    AmbiguityHandling,
    ChainStep,
    EvolutionConfig,
    FeedbackRecord,
)

# ── Reputation ─────────────────────────────────────────────────
from .reputation import (
    ReputationRule,
    DimensionImpact,
    Modifier,
    ReputationEngine,
    ReputationStore,
    ActionOutcomeResult,
    analyze_factors,
    process_action_outcome,
)

# ── Entity Taxonomy ────────────────────────────────────────────
from .entity import (
    BehavioralMode,
    EnergyPattern,
    InteractionType,
    EntityTypeInfo,
    ENTITY_JSONLD_CONTEXT,
    behavioral_modes,
    energy_pattern,
    is_agentic,
    can_initiate,
    can_delegate,
    can_process_r6,
    valid_interaction,
    all_entity_types,
    entity_registry_to_jsonld,
    entity_registry_from_jsonld,
    entity_registry_from_jsonld_string,
    get_info,
)

# ── Capability Levels ─────────────────────────────────────────
from .capability import (
    CapabilityLevel,
    TrustTier,
    ENTITY_LEVEL_RANGES,
    LevelRequirement,
    CAPABILITY_JSONLD_CONTEXT,
    assess_level,
    validate_level,
    can_upgrade,
    level_requirements,
    trust_tier,
    entity_level_range,
    is_level_typical,
    common_ground,
    CapabilityAssessment,
    capability_assessment_to_jsonld,
    capability_assessment_from_jsonld,
    capability_assessment_from_jsonld_string,
    capability_framework_to_jsonld,
    capability_framework_from_jsonld,
    capability_framework_from_jsonld_string,
)

# ── Error Taxonomy ─────────────────────────────────────────────
from .errors import (
    ErrorCode,
    ErrorCategory,
    ErrorMeta,
    Web4Error,
    BindingError,
    PairingError,
    WitnessError,
    AuthzError,
    CryptoError,
    ProtoError,
    get_error_meta,
    codes_for_category,
    make_error,
)

# ── Metabolic States ──────────────────────────────────────────
from .metabolic import (
    MetabolicState,
    TrustEffect,
    MetabolicProfile,
    ReliabilityFactors,
    ENERGY_MULTIPLIERS,
    TRUST_EFFECTS,
    WITNESS_REQUIREMENTS,
    DORMANT_STATES,
    ACTIVE_STATES,
    reachable_states,
    transition_trigger,
    all_transitions,
    energy_cost,
    wake_penalty,
    metabolic_reliability,
    required_witnesses,
    all_profiles,
    is_dormant,
    accepts_transactions,
    accepts_new_citizens,
)

# Alias to disambiguate from other Transition types
from .metabolic import Transition as MetabolicTransition
from .metabolic import valid_transition as metabolic_valid_transition

# ── Multi-device Binding ──────────────────────────────────────
from .binding import (
    AnchorType,
    DeviceStatus,
    HardwareAnchor,
    DeviceRecord,
    DeviceConstellation,
    ANCHOR_TRUST_WEIGHT,
    ANCHOR_TYPE_TO_ATTESTATION,
    ATTESTATION_TO_ANCHOR_TYPE,
    CONSTELLATION_TRUST_CEILING,
    WITNESS_DECAY_TABLE,
    witness_freshness,
    default_recovery_quorum,
    attestation_anchor_type,
    binding_anchor_type,
    enroll_device,
    remove_device,
    coherence_bonus,
    cross_witness_density,
    constellation_trust_ceiling,
    compute_device_trust,
    compute_constellation_trust,
    record_cross_witness,
    check_recovery_quorum,
    can_recover,
)

# ── Society ────────────────────────────────────────────────────
from .society import (
    SocietyPhase,
    LedgerEventType,
    LedgerEntry,
    SocietyLedger,
    Treasury,
    SocietyState,
    create_society,
    admit_citizen,
    suspend_citizen,
    reinstate_citizen,
    terminate_citizen,
    transition_metabolic_state,
    deposit_treasury,
    allocate_treasury,
    record_law_change,
    compute_society_t3,
    society_energy_cost,
    society_health,
    incorporate_child,
    society_depth,
    society_ancestry,
)

# ── Society Roles ─────────────────────────────────────────────
from .role import (
    SocietyRole,
    RoleAssignment,
    bootstrap_society_roles,
    validate_minimum_viable,
    BASE_MANDATORY_ROLES,
)

# ── Security Primitives ───────────────────────────────────────
from .security import (
    CryptoSuiteId,
    CryptoSuite,
    EncodingProfile,
    SUITE_BASE,
    SUITE_FIPS,
    SUITES,
    get_suite,
    negotiate_suite,
    W4ID,
    W4IDError,
    parse_w4id,
    derive_pairwise_w4id,
    KNOWN_METHODS,
    KeyStorageLevel,
    KeyPolicy,
    SignatureEnvelope,
    VerifiableCredential,
)

# ── Core Protocol ─────────────────────────────────────────────
from .protocol import (
    HandshakePhase,
    ClientHello,
    ServerHello,
    ClientFinished,
    ServerFinished,
    HandshakeMessage,
    PairingMethod,
    Transport,
    TransportCompliance,
    TransportProfile,
    TRANSPORT_PROFILES,
    get_transport_profile,
    required_transports,
    negotiate_transport,
    DiscoveryMethod,
    PrivacyLevel,
    DISCOVERY_METADATA,
    required_discovery_methods,
    discovery_privacy,
    DiscoveryRequest,
    DiscoveryResponse,
    Web4URI,
    web4_uri_to_dict,
    web4_uri_from_dict,
    transport_profile_to_dict,
)

# ── Attestation (Hardware Trust) ──────────────────────────────
from .attestation import (
    AttestationEnvelope,
    AnchorInfo,
    Proof,
    PlatformState,
    VerificationResult,
    TRUST_CEILINGS,
    FRESHNESS_MAX_AGE,
    ATTESTATION_JSONLD_CONTEXT,
    verify_envelope,
)

# ── MCP Protocol Types ────────────────────────────────────────
from .mcp import (
    CommunicationPattern,
    TrustDimension,
    MCPResourceType,
    TrustRequirements,
    MCPToolResource,
    MCPPromptResource,
    TrustContext,
    Web4Context,
    WitnessedInteraction,
    WitnessAttestation,
    MCPCapabilities,
    CapabilityBroadcast,
    MCPAuthority,
    MCPSession,
    SessionHandoff,
    PricingModifiers,
    calculate_mcp_cost,
    MCPErrorContext,
    web4_context_to_json,
    web4_context_from_json,
)

# Aliases for disambiguation with r6 types
from .mcp import ResourceRequirements as MCPResourceRequirements
from .mcp import ProofOfAgency as MCPProofOfAgency

# ── Validation ────────────────────────────────────────────────
from .validation import (  # noqa: F401
    SchemaNotFound,
    SchemaValidationUnavailable,
    ValidationError,
    ValidationResult,
    get_schema,
    get_schema_dir,
    list_schemas,
    validate,
)

# ── Deserialization ──────────────────────────────────────────
from .deserialize import (
    UnknownTypeError,
    from_jsonld,
    from_jsonld_string,
    supported_types,
)

# ── Document Generation ─────────────────────────────────────
from .generate import (
    UnsupportedTypeError,
    available_types,
    generate,
    generate_string,
)


# ── Public API ─────────────────────────────────────────────────
__all__ = [
    # version
    "__version__",
    # trust
    "T3",
    "V3",
    "TrustProfile",
    "ActionOutcome",
    "RoleRequirement",
    "RoleTensors",
    "TrustQuery",
    "TrustQueryResponse",
    "DisclosureLevel",
    "TrustResolution",
    "compute_team_t3",
    "operational_health",
    "is_healthy",
    "diminishing_returns",
    "trust_bridge",
    "evaluate_trust_query",
    "resolve_trust",
    "TRUST_QUERY_JSONLD_CONTEXT",
    "TRUST_QUERY_MIN_STAKE",
    "TRUST_QUERY_MIN_VALIDITY",
    "TRUST_QUERY_MAX_VALIDITY",
    "T3_JSONLD_CONTEXT",
    "V3_JSONLD_CONTEXT",
    # lct
    "LCT",
    "EntityType",
    "RevocationStatus",
    "BirthCertificate",
    "Attestation",
    "LineageEntry",
    "LCT_JSONLD_CONTEXT",
    "LCTBinding",
    "LCTMRH",
    "LCTMRHPairing",
    "LCTPolicy",
    # atp
    "ATPAccount",
    "TransferResult",
    "ATP_JSONLD_CONTEXT",
    "energy_ratio",
    "transfer",
    "sliding_scale",
    "check_conservation",
    "sybil_cost",
    "fee_sensitivity",
    # federation
    "Society",
    "FederationSociety",
    "LawDataset",
    "Delegation",
    "RoleType",
    "CitizenshipStatus",
    "CitizenshipRecord",
    "valid_citizenship_transition",
    "QuorumMode",
    "QuorumPolicy",
    "LedgerType",
    "AuditRequest",
    "AuditAdjustment",
    "Norm",
    "Procedure",
    "Interpretation",
    "merge_law",
    "norm_to_dict",
    "norm_from_dict",
    "procedure_to_dict",
    "procedure_from_dict",
    "interpretation_to_dict",
    "interpretation_from_dict",
    "law_dataset_to_dict",
    "law_dataset_from_dict",
    "delegation_to_dict",
    "delegation_from_dict",
    "quorum_policy_to_dict",
    "quorum_policy_from_dict",
    # r6/r7
    "R7Action",
    "ActionChain",
    "ActionStatus",
    "ReputationDelta",
    "Rules",
    "Role",
    "Request",
    "ResourceRequirements",
    "Result",
    "build_action",
    "R7_JSONLD_CONTEXT",
    "R7Error",
    "Constraint",
    "ContributingFactor",
    "Precedent",
    "Reference",
    "TensorDelta",
    "ReferenceInvalid",
    "ReputationComputationError",
    "RequestMalformed",
    "ResourceInsufficient",
    "ResultInvalid",
    "RoleUnauthorized",
    "RuleViolation",
    # mrh
    "MRHGraph",
    "MRHNode",
    "MRHEdge",
    "RelationType",
    "relation_category",
    "mrh_trust_decay",
    "mrh_zone",
    "propagate_multiplicative",
    "propagate_probabilistic",
    "propagate_maximal",
    # acp
    "ACP_JSONLD_CONTEXT",
    "ACPStateMachine",
    "ACPState",
    "ACPError",
    "AgentPlan",
    "PlanStep",
    "Intent",
    "Decision",
    "DecisionType",
    "ProofOfAgency",
    "ExecutionRecord",
    "ApprovalMode",
    "ResourceCaps",
    "Guards",
    "Trigger",
    "TriggerKind",
    "build_intent",
    "validate_plan",
    "HumanApproval",
    "ApprovalRequired",
    "InvalidTransition",
    "LedgerWriteFailure",
    "NoValidGrant",
    "PlanExpired",
    "ResourceCapExceeded",
    "ScopeViolation",
    "WitnessDeficit",
    # dictionary
    "DICTIONARY_JSONLD_CONTEXT",
    "DictionaryEntity",
    "DictionarySpec",
    "DictionaryType",
    "DictionaryVersion",
    "CompressionProfile",
    "DomainCoverage",
    "TranslationRequest",
    "TranslationResult",
    "TranslationChain",
    "dictionary_selection_score",
    "select_best_dictionary",
    "AmbiguityHandling",
    "ChainStep",
    "EvolutionConfig",
    "FeedbackRecord",
    # reputation
    "ReputationRule",
    "DimensionImpact",
    "Modifier",
    "ReputationEngine",
    "ReputationStore",
    "ActionOutcomeResult",
    "analyze_factors",
    "process_action_outcome",
    # entity
    "BehavioralMode",
    "EnergyPattern",
    "InteractionType",
    "EntityTypeInfo",
    "ENTITY_JSONLD_CONTEXT",
    "behavioral_modes",
    "energy_pattern",
    "is_agentic",
    "can_initiate",
    "can_delegate",
    "can_process_r6",
    "valid_interaction",
    "all_entity_types",
    "entity_registry_to_jsonld",
    "entity_registry_from_jsonld",
    "entity_registry_from_jsonld_string",
    "get_info",
    # capability
    "CapabilityLevel",
    "TrustTier",
    "ENTITY_LEVEL_RANGES",
    "LevelRequirement",
    "CAPABILITY_JSONLD_CONTEXT",
    "assess_level",
    "validate_level",
    "can_upgrade",
    "level_requirements",
    "trust_tier",
    "entity_level_range",
    "is_level_typical",
    "common_ground",
    "CapabilityAssessment",
    "capability_assessment_to_jsonld",
    "capability_assessment_from_jsonld",
    "capability_assessment_from_jsonld_string",
    "capability_framework_to_jsonld",
    "capability_framework_from_jsonld",
    "capability_framework_from_jsonld_string",
    # errors
    "ErrorCode",
    "ErrorCategory",
    "ErrorMeta",
    "Web4Error",
    "BindingError",
    "PairingError",
    "WitnessError",
    "AuthzError",
    "CryptoError",
    "ProtoError",
    "get_error_meta",
    "codes_for_category",
    "make_error",
    # metabolic
    "MetabolicState",
    "MetabolicTransition",
    "metabolic_valid_transition",
    "TrustEffect",
    "MetabolicProfile",
    "ReliabilityFactors",
    "ENERGY_MULTIPLIERS",
    "TRUST_EFFECTS",
    "WITNESS_REQUIREMENTS",
    "DORMANT_STATES",
    "ACTIVE_STATES",
    "reachable_states",
    "transition_trigger",
    "all_transitions",
    "energy_cost",
    "wake_penalty",
    "metabolic_reliability",
    "required_witnesses",
    "all_profiles",
    "is_dormant",
    "accepts_transactions",
    "accepts_new_citizens",
    # binding
    "AnchorType",
    "DeviceStatus",
    "HardwareAnchor",
    "DeviceRecord",
    "DeviceConstellation",
    "ANCHOR_TRUST_WEIGHT",
    "ANCHOR_TYPE_TO_ATTESTATION",
    "ATTESTATION_TO_ANCHOR_TYPE",
    "CONSTELLATION_TRUST_CEILING",
    "WITNESS_DECAY_TABLE",
    "witness_freshness",
    "default_recovery_quorum",
    "attestation_anchor_type",
    "binding_anchor_type",
    "enroll_device",
    "remove_device",
    "coherence_bonus",
    "cross_witness_density",
    "constellation_trust_ceiling",
    "compute_device_trust",
    "compute_constellation_trust",
    "record_cross_witness",
    "check_recovery_quorum",
    "can_recover",
    # society
    "SocietyPhase",
    "LedgerEventType",
    "LedgerEntry",
    "SocietyLedger",
    "Treasury",
    "SocietyState",
    "create_society",
    "admit_citizen",
    "suspend_citizen",
    "reinstate_citizen",
    "terminate_citizen",
    "transition_metabolic_state",
    "deposit_treasury",
    "allocate_treasury",
    "record_law_change",
    "compute_society_t3",
    "society_energy_cost",
    "society_health",
    "incorporate_child",
    "society_depth",
    "society_ancestry",
    # society roles
    "SocietyRole",
    "RoleAssignment",
    "bootstrap_society_roles",
    "validate_minimum_viable",
    "BASE_MANDATORY_ROLES",
    # security
    "CryptoSuiteId",
    "CryptoSuite",
    "EncodingProfile",
    "SUITE_BASE",
    "SUITE_FIPS",
    "SUITES",
    "get_suite",
    "negotiate_suite",
    "W4ID",
    "W4IDError",
    "parse_w4id",
    "derive_pairwise_w4id",
    "KNOWN_METHODS",
    "KeyStorageLevel",
    "KeyPolicy",
    "SignatureEnvelope",
    "VerifiableCredential",
    # protocol
    "HandshakePhase",
    "ClientHello",
    "ServerHello",
    "ClientFinished",
    "ServerFinished",
    "HandshakeMessage",
    "PairingMethod",
    "Transport",
    "TransportCompliance",
    "TransportProfile",
    "TRANSPORT_PROFILES",
    "get_transport_profile",
    "required_transports",
    "negotiate_transport",
    "DiscoveryMethod",
    "PrivacyLevel",
    "DISCOVERY_METADATA",
    "required_discovery_methods",
    "discovery_privacy",
    "DiscoveryRequest",
    "DiscoveryResponse",
    "Web4URI",
    "web4_uri_to_dict",
    "web4_uri_from_dict",
    "transport_profile_to_dict",
    # attestation
    "AttestationEnvelope",
    "AnchorInfo",
    "Proof",
    "PlatformState",
    "VerificationResult",
    "TRUST_CEILINGS",
    "FRESHNESS_MAX_AGE",
    "ATTESTATION_JSONLD_CONTEXT",
    "verify_envelope",
    # mcp
    "CommunicationPattern",
    "TrustDimension",
    "MCPResourceType",
    "TrustRequirements",
    "MCPResourceRequirements",
    "MCPToolResource",
    "MCPPromptResource",
    "MCPProofOfAgency",
    "TrustContext",
    "Web4Context",
    "WitnessedInteraction",
    "WitnessAttestation",
    "MCPCapabilities",
    "CapabilityBroadcast",
    "MCPAuthority",
    "MCPSession",
    "SessionHandoff",
    "PricingModifiers",
    "calculate_mcp_cost",
    "MCPErrorContext",
    "web4_context_to_json",
    "web4_context_from_json",
    # validation
    "ValidationResult",
    "ValidationError",
    "SchemaValidationUnavailable",
    "SchemaNotFound",
    "validate",
    "list_schemas",
    "get_schema",
    "get_schema_dir",
    # deserialization
    "UnknownTypeError",
    "from_jsonld",
    "from_jsonld_string",
    "supported_types",
    # generation
    "UnsupportedTypeError",
    "available_types",
    "generate",
    "generate_string",
]
