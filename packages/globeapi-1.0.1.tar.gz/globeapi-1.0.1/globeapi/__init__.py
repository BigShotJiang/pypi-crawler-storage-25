"""GlobeAPI — Official Python SDK for the unified travel API platform."""

from .client import Client
from .exceptions import GlobeAPIError

__all__ = ["Client", "GlobeAPIError"]
__version__ = "1.0.0"
