"""GlobeAPI client — the main entry point for the SDK."""

from __future__ import annotations

from typing import Any, Dict, Iterator, Optional

import requests

from .exceptions import GlobeAPIError
from .resources import AI, Cities, Flights, Hotels, Moderation, Photos, Places, Trips, Voice

_DEFAULT_BASE_URL = "https://goglobe.live/api"


class Client:
    """GlobeAPI client.

    Usage::

        from globeapi import Client

        client = Client("your-api-key")
        results = client.places.search("Eiffel Tower")

    Args:
        api_key: Your GlobeAPI key (sent as ``X-API-Key`` header).
        base_url: Override the default API base URL.
        timeout: Default request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "globeapi-python/1.0.0",
            }
        )

        # Namespaced resources
        self.places = Places(self)
        self.cities = Cities(self)
        self.flights = Flights(self)
        self.hotels = Hotels(self)
        self.ai = AI(self)
        self.voice = Voice(self)
        self.moderation = Moderation(self)
        self.photos = Photos(self)
        self.trips = Trips(self)

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _handle_response(self, response: requests.Response) -> Any:
        """Parse a response and raise on HTTP errors."""
        if response.ok:
            if not response.content:
                return None
            return response.json()

        # Try to extract a meaningful message from the response body.
        try:
            body = response.json()
            message = body.get("error", body.get("message", response.reason))
        except (ValueError, KeyError):
            body = response.text
            message = response.reason or "Unknown error"

        raise GlobeAPIError(
            message=str(message),
            status_code=response.status_code,
            body=body,
        )

    def _get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Send a GET request."""
        response = self._session.get(
            self._url(path),
            params=params,
            timeout=self.timeout,
        )
        return self._handle_response(response)

    def _post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Send a POST request."""
        response = self._session.post(
            self._url(path),
            json=json,
            timeout=self.timeout,
        )
        return self._handle_response(response)

    def _post_stream(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Iterator[str]:
        """Send a POST request and stream the response line by line.

        Yields each non-empty line from the response body, suitable for
        server-sent events or newline-delimited JSON streams.
        """
        response = self._session.post(
            self._url(path),
            json=json,
            timeout=self.timeout,
            stream=True,
        )

        if not response.ok:
            try:
                body = response.json()
                message = body.get("error", body.get("message", response.reason))
            except (ValueError, KeyError):
                body = response.text
                message = response.reason or "Unknown error"
            raise GlobeAPIError(
                message=str(message),
                status_code=response.status_code,
                body=body,
            )

        for line in response.iter_lines(decode_unicode=True):
            if line:
                yield line

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Client(base_url={self.base_url!r})"
