"""Namespaced resource classes for the GlobeAPI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Optional

if TYPE_CHECKING:
    from .client import Client


class _Resource:
    """Base class for API resource namespaces."""

    def __init__(self, client: "Client") -> None:
        self._client = client


class Places(_Resource):
    """Places resource — search and geocode locations."""

    def search(
        self,
        query: str,
        limit: int = 10,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Search for places by query string.

        Args:
            query: Search term (e.g. "Eiffel Tower").
            limit: Maximum number of results to return.
            lat: Optional latitude for proximity bias.
            lng: Optional longitude for proximity bias.
            radius: Optional search radius in meters (requires lat/lng).

        Returns:
            Parsed JSON response from the API.
        """
        params: Dict[str, Any] = {"query": query, "limit": limit}
        if lat is not None:
            params["lat"] = lat
        if lng is not None:
            params["lng"] = lng
        if radius is not None:
            params["radius"] = radius
        return self._client._get("/v1/places/search", params=params)

    def geocode(self, lat: float, lng: float) -> Dict[str, Any]:
        """Reverse-geocode a coordinate pair.

        Args:
            lat: Latitude.
            lng: Longitude.

        Returns:
            Parsed JSON response from the API.
        """
        return self._client._get("/v1/places/geocode", params={"lat": lat, "lng": lng})


class Cities(_Resource):
    """Cities resource — search for cities."""

    def search(self, query: str, limit: int = 10) -> Dict[str, Any]:
        """Search for cities by name.

        Args:
            query: City name or partial name.
            limit: Maximum number of results.

        Returns:
            Parsed JSON response from the API.
        """
        return self._client._get(
            "/v1/cities/search", params={"query": query, "limit": limit}
        )


class Flights(_Resource):
    """Flights resource — search for flights."""

    def search(
        self,
        origin: str,
        destination: str,
        date: str,
        passengers: int = 1,
        cabin_class: str = "economy",
    ) -> Dict[str, Any]:
        """Search for available flights.

        Args:
            origin: Origin airport IATA code (e.g. "JFK").
            destination: Destination airport IATA code (e.g. "LHR").
            date: Departure date in ISO 8601 format (YYYY-MM-DD).
            passengers: Number of passengers.
            cabin_class: Cabin class — "economy", "business", or "first".

        Returns:
            Parsed JSON response from the API.
        """
        return self._client._post(
            "/v1/flights/search",
            json={
                "origin": origin,
                "destination": destination,
                "date": date,
                "passengers": passengers,
                "cabin_class": cabin_class,
            },
        )


class Hotels(_Resource):
    """Hotels resource — search for hotel availability."""

    def search(
        self,
        city: str,
        check_in: str,
        check_out: str,
        guests: int = 1,
        rooms: int = 1,
    ) -> Dict[str, Any]:
        """Search for available hotels.

        Args:
            city: City name or code.
            check_in: Check-in date (YYYY-MM-DD).
            check_out: Check-out date (YYYY-MM-DD).
            guests: Number of guests.
            rooms: Number of rooms.

        Returns:
            Parsed JSON response from the API.
        """
        return self._client._post(
            "/v1/hotels/search",
            json={
                "city": city,
                "check_in": check_in,
                "check_out": check_out,
                "guests": guests,
                "rooms": rooms,
            },
        )


class AI(_Resource):
    """AI resource — chat and vision endpoints."""

    def chat(
        self,
        message: str,
        history: Optional[List[Dict[str, str]]] = None,
        stream: bool = False,
    ) -> Any:
        """Send a message to the AI travel assistant.

        Args:
            message: User message text.
            history: Optional conversation history as a list of
                     ``{"role": "...", "content": "..."}`` dicts.
            stream: If True, return an iterator that yields response chunks.

        Returns:
            Parsed JSON response, or an iterator of chunks when streaming.
        """
        payload: Dict[str, Any] = {"message": message, "stream": stream}
        if history is not None:
            payload["history"] = history

        if stream:
            return self._client._post_stream("/v1/ai/chat", json=payload)

        return self._client._post("/v1/ai/chat", json=payload)

    def vision(
        self, image: str, message: str = "Describe this image"
    ) -> Dict[str, Any]:
        """Analyse an image with the AI vision model.

        Args:
            image: Base64-encoded image data.
            message: Prompt / instruction for the vision model.

        Returns:
            Parsed JSON response from the API.
        """
        return self._client._post(
            "/v1/ai/vision", json={"image": image, "message": message}
        )


class Voice(_Resource):
    """Voice resource — speech-to-text transcription."""

    def transcribe(self, audio: str) -> Dict[str, Any]:
        """Transcribe audio to text.

        Args:
            audio: Base64-encoded audio data.

        Returns:
            Parsed JSON response containing the transcription.
        """
        return self._client._post("/v1/voice/transcribe", json={"audio": audio})


class Moderation(_Resource):
    """Moderation resource — image content moderation."""

    def check(self, image: str) -> Dict[str, Any]:
        """Check an image for policy violations.

        Args:
            image: Base64-encoded image data.

        Returns:
            Parsed JSON response with moderation results.
        """
        return self._client._post("/v1/moderation/check", json={"image": image})


class Photos(_Resource):
    """Photos resource — search the community photo library."""

    def search(
        self,
        query: Optional[str] = None,
        country: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """Search for community photos.

        Args:
            query: Optional text query.
            country: Optional ISO country code filter.
            limit: Maximum number of results.

        Returns:
            Parsed JSON response from the API.
        """
        params: Dict[str, Any] = {"limit": limit}
        if query is not None:
            params["query"] = query
        if country is not None:
            params["country"] = country
        return self._client._get("/v1/photos/search", params=params)


class Trips(_Resource):
    """Trips resource — AI-powered trip planning."""

    def plan(
        self,
        destination: str,
        days: int = 3,
        interests: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate an AI trip plan.

        Args:
            destination: Destination city or region.
            days: Number of days for the trip.
            interests: Optional list of interest tags (e.g. ["food", "history"]).

        Returns:
            Parsed JSON response containing the trip plan.
        """
        payload: Dict[str, Any] = {"destination": destination, "days": days}
        if interests is not None:
            payload["interests"] = interests
        return self._client._post("/v1/trips/plan", json=payload)
