"""Exception classes for the GlobeAPI SDK."""

from typing import Any, Optional


class GlobeAPIError(Exception):
    """Raised when the GlobeAPI returns an error response.

    Attributes:
        status_code: HTTP status code from the API response.
        message: Human-readable error message.
        body: Raw response body (parsed JSON if possible, otherwise string).
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        body: Optional[Any] = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.body = body
        super().__init__(self.message)

    def __str__(self) -> str:
        parts = []
        if self.status_code is not None:
            parts.append(f"[{self.status_code}]")
        parts.append(self.message)
        return " ".join(parts)

    def __repr__(self) -> str:
        return (
            f"GlobeAPIError(message={self.message!r}, "
            f"status_code={self.status_code!r}, body={self.body!r})"
        )
