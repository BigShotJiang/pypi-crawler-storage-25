# GlobeAPI Python SDK

Official Python SDK for [GlobeAPI](https://globeapi.com) -- the unified travel API platform.

## Installation

```bash
pip install globeapi
```

## Quick Start

```python
from globeapi import Client

client = Client("your-api-key")

# Search for places
places = client.places.search("Eiffel Tower")

# Reverse geocode
location = client.places.geocode(lat=48.8584, lng=2.2945)

# Search cities
cities = client.cities.search("Paris")

# Search flights
flights = client.flights.search(
    origin="JFK",
    destination="CDG",
    date="2026-06-15",
    passengers=2,
    cabin_class="business",
)

# Search hotels
hotels = client.hotels.search(
    city="Paris",
    check_in="2026-06-15",
    check_out="2026-06-20",
    guests=2,
    rooms=1,
)

# AI travel assistant
answer = client.ai.chat("What are the best restaurants in Rome?")

# Streaming AI chat
for chunk in client.ai.chat("Plan a 3-day trip to Tokyo", stream=True):
    print(chunk, end="")

# AI vision
import base64

with open("photo.jpg", "rb") as f:
    image_b64 = base64.b64encode(f.read()).decode()

description = client.ai.vision(image_b64, message="Where was this photo taken?")

# Voice transcription
with open("audio.wav", "rb") as f:
    audio_b64 = base64.b64encode(f.read()).decode()

transcript = client.voice.transcribe(audio_b64)

# Image moderation
result = client.moderation.check(image_b64)

# Community photos
photos = client.photos.search(query="sunset", country="IT", limit=5)

# AI trip planner
trip = client.trips.plan("Barcelona", days=5, interests=["food", "architecture"])
```

## Configuration

```python
# Custom base URL
client = Client("your-api-key", base_url="https://custom.endpoint.com")

# Custom timeout (seconds)
client = Client("your-api-key", timeout=60)
```

## Context Manager

The client can be used as a context manager to automatically close the
underlying HTTP session:

```python
with Client("your-api-key") as client:
    places = client.places.search("Big Ben")
```

## Error Handling

```python
from globeapi import Client, GlobeAPIError

client = Client("your-api-key")

try:
    flights = client.flights.search("JFK", "CDG", "2026-06-15")
except GlobeAPIError as e:
    print(f"Status: {e.status_code}")
    print(f"Message: {e.message}")
    print(f"Body: {e.body}")
```

## License

MIT
