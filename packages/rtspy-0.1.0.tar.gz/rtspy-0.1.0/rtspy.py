"""
Minimal RTSP client implemented with Python standard library only.

This module offers a requests-like API:

    import rtsp

    client = rtsp.Client("rtsp://example.com/live")
    resp = client.describe()
    print(resp.status_code, resp.headers, resp.body)

And a convenience function:

    resp = rtsp.request("OPTIONS", "rtsp://example.com/live")
"""

from __future__ import annotations

import socket
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Union
from urllib.parse import urljoin, urlparse

class RTSPError(Exception):
    """Base RTSP error."""


class RTSPConnectionError(RTSPError):
    """Raised when the RTSP connection fails."""


@dataclass
class Response:
    """RTSP response object similar to requests.Response (minimal fields)."""

    status_code: int
    reason: str
    version: str
    headers: Dict[str, str]
    body: bytes
    raw: bytes

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    @property
    def body_text(self) -> str:
        """Alias for text, easier for callers expecting formatted body field."""
        return self.text

    @property
    def body_lines(self):
        """Body split by lines, convenient for SDP parsing/debug."""
        return self.text.splitlines()

    @property
    def body_kv(self) -> Dict[str, str]:
        """Parse SDP-like body lines as key=value dictionary (first key wins)."""
        out: Dict[str, str] = {}
        for line in self.body_lines:
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            if key and key not in out:
                out[key] = value.strip()
        return out

    @staticmethod
    def _parse_npt_value(value: str) -> Optional[float]:
        value = value.strip().lower()
        if not value or value == "now":
            return None
        try:
            return float(value)
        except ValueError:
            return None

    @property
    def npt_range(self) -> Optional[Tuple[Optional[float], Optional[float]]]:
        """Return SDP npt range as (start, end), None if absent.

        Example for 'a=range:npt=0-5830' -> (0.0, 5830.0)
        """
        text = self.text
        for raw_line in text.splitlines():
            line = raw_line.strip().lower()
            if not line.startswith("a=range:npt="):
                continue
            npt_part = line.split("npt=", 1)[1]
            if "-" not in npt_part:
                continue
            start_text, end_text = npt_part.split("-", 1)
            return (self._parse_npt_value(start_text), self._parse_npt_value(end_text))
        return None

    @property
    def duration_seconds(self) -> Optional[float]:
        """Return media duration in seconds parsed from SDP npt range."""
        rng = self.npt_range
        if not rng:
            return None
        start, end = rng
        if start is None or end is None:
            return None
        if end < start:
            return None
        return end - start


class Client:
    """Simple RTSP-over-TCP client."""

    def __init__(
        self,
        rtsp_server_uri: str,
        timeout: float = 8.0,
        user_agent: str = "rtspy/0.1",
        allow_redirects: bool = True,
        max_redirects: int = 5,
        auto_connect: bool = True,
    ):
        parsed = urlparse(rtsp_server_uri)
        if parsed.scheme.lower() != "rtsp":
            raise ValueError("rtsp_server_uri must start with rtsp://")

        self.base_uri = rtsp_server_uri
        self.host = parsed.hostname or ""
        self.port = parsed.port or 554
        self.timeout = timeout
        self.user_agent = user_agent
        self.allow_redirects = allow_redirects
        self.max_redirects = max_redirects

        self._sock: Optional[socket.socket] = None
        self._cseq = 1
        self.session: Optional[str] = None

        if auto_connect:
            self.connect()

    def connect(self) -> None:
        if self._sock is not None:
            return
        try:
            sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
            sock.settimeout(self.timeout)
            self._sock = sock
        except OSError as exc:
            raise RTSPConnectionError(f"Failed to connect to {self.host}:{self.port}: {exc}") from exc

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None

    def __enter__(self) -> "Client":
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _next_cseq(self) -> int:
        cseq = self._cseq
        self._cseq += 1
        return cseq

    def _resolve_uri(self, uri: Optional[str]) -> str:
        if not uri:
            return self.base_uri
        if uri.lower().startswith("rtsp://"):
            return uri
        return urljoin(self.base_uri, uri)

    def _switch_endpoint(self, uri: str) -> None:
        parsed = urlparse(uri)
        if parsed.scheme.lower() != "rtsp":
            raise RTSPError(f"Unsupported redirect target: {uri}")

        new_host = parsed.hostname or ""
        new_port = parsed.port or 554
        endpoint_changed = (new_host != self.host) or (new_port != self.port)

        self.base_uri = uri
        if endpoint_changed:
            self.close()
            self.host = new_host
            self.port = new_port
            self.session = None

    def _recv_exact(self, n: int) -> bytes:
        if self._sock is None:
            raise RTSPConnectionError("Socket is not connected")

        chunks = []
        remaining = n
        while remaining > 0:
            part = self._sock.recv(remaining)
            if not part:
                raise RTSPConnectionError("Connection closed by peer while reading body")
            chunks.append(part)
            remaining -= len(part)
        return b"".join(chunks)

    def _recv_until_headers_done(self) -> bytes:
        if self._sock is None:
            raise RTSPConnectionError("Socket is not connected")

        buf = bytearray()
        while b"\r\n\r\n" not in buf:
            part = self._sock.recv(4096)
            if not part:
                raise RTSPConnectionError("Connection closed by peer while reading headers")
            buf.extend(part)
        return bytes(buf)

    def _read_response(self) -> Response:
        raw = self._recv_until_headers_done()

        # Skip interleaved data frames if they arrive before an RTSP response.
        while raw.startswith(b"$"):
            if len(raw) < 4:
                raw += self._recv_exact(4 - len(raw))
            frame_len = int.from_bytes(raw[2:4], byteorder="big")
            payload_needed = 4 + frame_len - len(raw)
            if payload_needed > 0:
                raw += self._recv_exact(payload_needed)
            raw = self._recv_until_headers_done()

        header_blob, body_part = raw.split(b"\r\n\r\n", 1)
        header_lines = header_blob.decode("utf-8", errors="replace").split("\r\n")
        if not header_lines:
            raise RTSPError("Malformed RTSP response: empty status line")

        status_line = header_lines[0]
        bits = status_line.split(" ", 2)
        if len(bits) < 2:
            raise RTSPError(f"Malformed RTSP status line: {status_line}")

        version = bits[0].strip()
        try:
            status_code = int(bits[1])
        except ValueError as exc:
            raise RTSPError(f"Invalid RTSP status code: {bits[1]}") from exc
        reason = bits[2].strip() if len(bits) > 2 else ""

        headers: Dict[str, str] = {}
        for line in header_lines[1:]:
            if not line or ":" not in line:
                continue
            name, value = line.split(":", 1)
            headers[name.strip().lower()] = value.strip()

        content_length = int(headers.get("content-length", "0") or "0")
        if len(body_part) < content_length:
            body_part += self._recv_exact(content_length - len(body_part))
        body = body_part[:content_length] if content_length > 0 else body_part

        session_header = headers.get("session")
        if session_header:
            self.session = session_header.split(";", 1)[0].strip()

        return Response(
            status_code=status_code,
            reason=reason,
            version=version,
            headers=headers,
            body=body,
            raw=header_blob + b"\r\n\r\n" + body,
        )

    def request(
        self,
        method: str,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[Union[str, bytes]] = None,
        allow_redirects: Optional[bool] = None,
        max_redirects: Optional[int] = None,
    ) -> Response:
        follow_redirects = self.allow_redirects if allow_redirects is None else allow_redirects
        max_hops = self.max_redirects if max_redirects is None else max_redirects

        method = method.upper().strip()
        request_uri = self._resolve_uri(uri)
        body_bytes: bytes
        if body is None:
            body_bytes = b""
        elif isinstance(body, bytes):
            body_bytes = body
        else:
            body_bytes = body.encode("utf-8")

        redirect_count = 0
        while True:
            self.connect()
            if self._sock is None:
                raise RTSPConnectionError("Socket is not connected")

            req_headers = dict(headers or {})
            if not any(k.lower() == "cseq" for k in req_headers):
                req_headers["CSeq"] = str(self._next_cseq())
            if not any(k.lower() == "user-agent" for k in req_headers):
                req_headers["User-Agent"] = self.user_agent
            if self.session and method in {"PLAY", "PAUSE", "TEARDOWN", "SET_PARAMETER", "GET_PARAMETER"}:
                if not any(k.lower() == "session" for k in req_headers):
                    req_headers["Session"] = self.session
            if body_bytes and not any(k.lower() == "content-length" for k in req_headers):
                req_headers["Content-Length"] = str(len(body_bytes))

            lines = [f"{method} {request_uri} RTSP/1.0"]
            for key, value in req_headers.items():
                lines.append(f"{key}: {value}")
            payload = "\r\n".join(lines).encode("utf-8") + b"\r\n\r\n" + body_bytes

            try:
                self._sock.sendall(payload)
            except OSError as exc:
                self.close()
                raise RTSPConnectionError(f"Failed to send RTSP request: {exc}") from exc

            resp = self._read_response()
            location = resp.headers.get("location")
            is_redirect = 300 <= resp.status_code < 400 and bool(location)
            if not (follow_redirects and is_redirect):
                return resp

            redirect_count += 1
            if redirect_count > max_hops:
                raise RTSPError(f"Too many redirects (>{max_hops})")

            request_uri = self._resolve_uri(location)
            self._switch_endpoint(request_uri)

    def options(self, uri: Optional[str] = None, headers: Optional[Dict[str, str]] = None) -> Response:
        return self.request("OPTIONS", uri=uri, headers=headers)

    def describe(
        self,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Response:
        req_headers = dict(headers or {})
        req_headers.setdefault("Accept", "application/sdp")
        return self.request("DESCRIBE", uri=uri, headers=req_headers)

    def setup(
        self,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        transport: str = "RTP/AVP/TCP;unicast;interleaved=0-1",
    ) -> Response:
        req_headers = dict(headers or {})
        req_headers.setdefault("Transport", transport)
        return self.request("SETUP", uri=uri, headers=req_headers)

    def play(
        self,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        range_header: Optional[str] = None,
    ) -> Response:
        req_headers = dict(headers or {})
        if range_header:
            req_headers["Range"] = range_header
        return self.request("PLAY", uri=uri, headers=req_headers)

    def pause(self, uri: Optional[str] = None, headers: Optional[Dict[str, str]] = None) -> Response:
        return self.request("PAUSE", uri=uri, headers=headers)

    def teardown(self, uri: Optional[str] = None, headers: Optional[Dict[str, str]] = None) -> Response:
        return self.request("TEARDOWN", uri=uri, headers=headers)

    def set_parameter(
        self,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[Union[str, bytes]] = None,
    ) -> Response:
        return self.request("SET_PARAMETER", uri=uri, headers=headers, body=body)

    def get_parameter(
        self,
        uri: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[Union[str, bytes]] = None,
    ) -> Response:
        return self.request("GET_PARAMETER", uri=uri, headers=headers, body=body)

    # Backward-compatible uppercase aliases.
    OPTIONS = options
    DESCRIBE = describe
    SETUP = setup
    PLAY = play
    PAUSE = pause
    TEARDOWN = teardown
    SET_PARAMETER = set_parameter
    GET_PARAMETER = get_parameter


def request(
    method: str,
    url: str,
    headers: Optional[Dict[str, str]] = None,
    body: Optional[Union[str, bytes]] = None,
    timeout: float = 8.0,
    user_agent: str = "rtspy/0.1",
    allow_redirects: bool = True,
    max_redirects: int = 5,
) -> Response:
    """One-shot RTSP request, similar to requests.request."""
    with Client(
        url,
        timeout=timeout,
        user_agent=user_agent,
        allow_redirects=allow_redirects,
        max_redirects=max_redirects,
        auto_connect=True,
    ) as client:
        return client.request(
            method=method,
            uri=url,
            headers=headers,
            body=body,
            allow_redirects=allow_redirects,
            max_redirects=max_redirects,
        )
