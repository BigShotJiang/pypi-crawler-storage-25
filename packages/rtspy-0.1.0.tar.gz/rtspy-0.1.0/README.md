# rtspy

A minimal RTSP client implemented with the Python standard library only.

`rtspy` provides a small, requests-like API for common RTSP operations such as
`OPTIONS`, `DESCRIBE`, `SETUP`, `PLAY`, `PAUSE`, and `TEARDOWN`.

## Features

- Pure Python, no third-party runtime dependencies
- Lightweight client object with persistent session support
- One-shot request helper similar to `requests.request`
- Basic redirect handling
- Minimal SDP helpers for duration and range parsing
- RTSP-only URL validation (`rtsp://`)

## Requirements

- Python 3.8+

## Installation

This package is not published yet.

When published to PyPI, install with:

```bash
pip install rtspy
```

For local development right now:

```bash
git clone <your-repo-url>
cd rtspy
```

## Quick Start

```python
import rtspy

client = rtspy.Client("rtsp://example.com/live")
resp = client.describe()

print(resp.status_code)
print(resp.headers)
print(resp.text)

client.close()
```

One-shot request style:

```python
import rtspy

resp = rtspy.request("OPTIONS", "rtsp://example.com/live")
print(resp.status_code, resp.reason)
```

## URL Support

Only `rtsp://` URLs are supported.

If a non-RTSP URL is used, `rtspy` raises `ValueError` or `RTSPError` depending
on the operation.

## API Overview

### Client

`Client(rtsp_server_uri, timeout=8.0, user_agent="rtspy/0.1", allow_redirects=True, max_redirects=5, auto_connect=True)`

Main methods:

- `options(uri=None, headers=None)`
- `describe(uri=None, headers=None)`
- `setup(uri=None, headers=None, transport="RTP/AVP/TCP;unicast;interleaved=0-1")`
- `play(uri=None, headers=None, range_header=None)`
- `pause(uri=None, headers=None)`
- `teardown(uri=None, headers=None)`
- `set_parameter(uri=None, headers=None, body=None)`
- `get_parameter(uri=None, headers=None, body=None)`
- `request(method, uri=None, headers=None, body=None, allow_redirects=None, max_redirects=None)`

### Response

`Response` contains:

- `status_code`
- `reason`
- `version`
- `headers`
- `body`
- `raw`

Convenience properties:

- `text`
- `body_text`
- `body_lines`
- `body_kv`
- `npt_range`
- `duration_seconds`

## Error Handling

- `RTSPError`: base exception for protocol/parsing related issues
- `RTSPConnectionError`: connection and socket-level failures

## License

This project is licensed under the terms in [LICENSE](LICENSE).
