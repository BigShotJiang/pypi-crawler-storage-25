"""Unit tests for marcus_mini.board (synchronous SQLite internals).

All tests use a real SQLite database in a pytest tmp_path directory so
no mocking of sqlite3 is required.  The async Board methods are tested
via their synchronous counterparts directly to avoid needing an event
loop fixture.
"""

from __future__ import annotations

import asyncio
import threading
from datetime import datetime, timezone
from pathlib import Path

import pytest

from marcus_mini.board import Board, ProjectExistsError
from marcus_mini.models import Task

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_task(
    task_id: str,
    name: str,
    description: str = "Do something.",
    dependencies: list[str] | None = None,
    project: str = "test-project",
) -> Task:
    """Build a minimal Task for testing.

    Parameters
    ----------
    task_id : str
        Task identifier.
    name : str
        Human-readable name.
    description : str
        Task description.
    dependencies : list[str] | None
        Dependency IDs. Defaults to empty list.
    project : str
        Project slug.

    Returns
    -------
    Task
        Populated Task instance.
    """
    now = datetime.now(timezone.utc).isoformat()
    return Task(
        id=task_id,
        name=name,
        description=description,
        status="TODO",
        assigned_to=None,
        dependencies=dependencies or [],
        artifacts=[],
        decisions=[],
        created_at=now,
        updated_at=now,
        project=project,
    )


@pytest.fixture()
def db(tmp_path: Path) -> Board:
    """Create a Board backed by a temporary SQLite database.

    Parameters
    ----------
    tmp_path : Path
        pytest-provided temp directory.

    Returns
    -------
    Board
        Configured board instance.
    """
    return Board(db_path=tmp_path / "board.db")


@pytest.fixture()
def project_tasks() -> list[Task]:
    """Return a simple 3-task project: A → B → C (linear chain).

    Returns
    -------
    list[Task]
        Three tasks with linear dependencies.
    """
    return [
        _make_task("task-a", "Task A"),
        _make_task("task-b", "Task B", dependencies=["task-a"]),
        _make_task("task-c", "Task C", dependencies=["task-b"]),
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCreateProject:
    """Tests for Board.create_project."""

    def test_create_project_inserts_tasks(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that create_project inserts all tasks into the database."""
        # Arrange / Act
        asyncio.run(db.create_project("test-project", project_tasks))

        # Assert
        tasks = asyncio.run(db.get_board_state("test-project"))
        assert len(tasks) == 3
        ids = {t.id for t in tasks}
        assert ids == {"task-a", "task-b", "task-c"}

    def test_project_exists_error_on_duplicate(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that creating a project twice raises ProjectExistsError."""
        # Arrange
        asyncio.run(db.create_project("test-project", project_tasks))

        # Act / Assert
        with pytest.raises(ProjectExistsError):
            asyncio.run(db.create_project("test-project", project_tasks))

    def test_create_project_sets_todo_status(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that all inserted tasks start with status TODO."""
        asyncio.run(db.create_project("test-project", project_tasks))
        tasks = asyncio.run(db.get_board_state("test-project"))
        assert all(t.status == "TODO" for t in tasks)


class TestRequestNextTask:
    """Tests for Board.request_next_task."""

    def test_request_next_task_returns_todo_with_no_deps(self, db: Board) -> None:
        """Test that a task with no dependencies is returned immediately."""
        # Arrange
        tasks = [_make_task("root", "Root Task")]
        asyncio.run(db.create_project("proj", tasks))

        # Act
        task = asyncio.run(db.request_next_task("agent-1", "proj"))

        # Assert
        assert task is not None
        assert task.id == "root"
        assert task.status == "IN_PROGRESS"
        assert task.assigned_to == "agent-1"

    def test_request_next_task_skips_blocked_task(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that tasks with unmet dependencies are skipped."""
        # Arrange
        asyncio.run(db.create_project("test-project", project_tasks))

        # Act — first call should give task-a (only unblocked one)
        task = asyncio.run(db.request_next_task("agent-1", "test-project"))

        # Assert
        assert task is not None
        assert task.id == "task-a"
        # task-b and task-c are still blocked

        # Second call with task-a still IN_PROGRESS should return None
        task2 = asyncio.run(db.request_next_task("agent-2", "test-project"))
        assert task2 is None

    def test_request_next_task_returns_none_when_all_blocked(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that None is returned when no tasks can be claimed."""
        asyncio.run(db.create_project("test-project", project_tasks))

        # Claim task-a
        asyncio.run(db.request_next_task("agent-1", "test-project"))
        # task-b and task-c are blocked; no more tasks available
        task = asyncio.run(db.request_next_task("agent-2", "test-project"))
        assert task is None

    def test_request_next_task_assigns_agent(self, db: Board) -> None:
        """Test that request_next_task sets assigned_to on the returned task."""
        asyncio.run(db.create_project("proj", [_make_task("t1", "T1")]))
        task = asyncio.run(db.request_next_task("my-agent", "proj"))
        assert task is not None
        assert task.assigned_to == "my-agent"

    def test_atomic_assignment_no_double_claim(self, tmp_path: Path) -> None:
        """Test that 5 concurrent threads each claim a distinct task.

        Each task must be claimed exactly once under concurrent load.
        """
        # Arrange — 5 independent tasks, 5 threads racing
        board = Board(db_path=tmp_path / "board.db")
        tasks = [_make_task(f"task-{i}", f"Task {i}") for i in range(5)]
        asyncio.run(board.create_project("race", tasks))

        claimed: list[str] = []
        lock = threading.Lock()

        def _claim(agent_id: str) -> None:
            task = asyncio.run(board.request_next_task(agent_id, "race"))
            if task is not None:
                with lock:
                    claimed.append(task.id)

        threads = [
            threading.Thread(target=_claim, args=(f"agent-{i}",)) for i in range(5)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Assert — all 5 claimed, no duplicates
        assert len(claimed) == 5
        assert len(set(claimed)) == 5


class TestArtifactsAndDecisions:
    """Tests for log_artifact and log_decision."""

    def test_log_artifact_appends(self, db: Board) -> None:
        """Test that log_artifact appends content to task artifacts."""
        asyncio.run(db.create_project("proj", [_make_task("t1", "T1")]))
        asyncio.run(db.request_next_task("agent-1", "proj"))

        asyncio.run(db.log_artifact("t1", "artifact-one"))
        asyncio.run(db.log_artifact("t1", "artifact-two"))

        tasks = asyncio.run(db.get_board_state("proj"))
        t = next(t for t in tasks if t.id == "t1")
        assert "artifact-one" in t.artifacts
        assert "artifact-two" in t.artifacts
        assert len(t.artifacts) == 2

    def test_log_decision_appends(self, db: Board) -> None:
        """Test that log_decision appends content to task decisions."""
        asyncio.run(db.create_project("proj", [_make_task("t1", "T1")]))
        asyncio.run(db.log_decision("t1", "chose sqlite over postgres"))

        tasks = asyncio.run(db.get_board_state("proj"))
        t = next(t for t in tasks if t.id == "t1")
        assert "chose sqlite over postgres" in t.decisions


class TestReportStatus:
    """Tests for report_done and report_failed."""

    def test_report_done_unblocks_dependent(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that marking task-a DONE allows task-b to be claimed."""
        asyncio.run(db.create_project("test-project", project_tasks))

        # Claim and complete task-a
        asyncio.run(db.request_next_task("agent-1", "test-project"))
        asyncio.run(db.report_done("task-a"))

        # Now task-b should be available
        task = asyncio.run(db.request_next_task("agent-2", "test-project"))
        assert task is not None
        assert task.id == "task-b"

    def test_report_failed_sets_status(self, db: Board) -> None:
        """Test that report_failed marks the task as FAILED."""
        asyncio.run(db.create_project("proj", [_make_task("t1", "T1")]))
        asyncio.run(db.request_next_task("agent-1", "proj"))
        asyncio.run(db.report_failed("t1", "network timeout"))

        tasks = asyncio.run(db.get_board_state("proj"))
        t = next(t for t in tasks if t.id == "t1")
        assert t.status == "FAILED"

    def test_all_done_true_when_all_done(
        self, db: Board, project_tasks: list[Task]
    ) -> None:
        """Test that all_done returns True only after all tasks are DONE."""
        asyncio.run(db.create_project("test-project", project_tasks))

        assert not asyncio.run(db.all_done("test-project"))

        asyncio.run(db.request_next_task("a1", "test-project"))
        asyncio.run(db.report_done("task-a"))
        asyncio.run(db.request_next_task("a2", "test-project"))
        asyncio.run(db.report_done("task-b"))
        asyncio.run(db.request_next_task("a3", "test-project"))
        asyncio.run(db.report_done("task-c"))

        assert asyncio.run(db.all_done("test-project"))


class TestProjectTiming:
    """Tests for project timing and agent status methods."""

    def test_register_project_stores_timing(self, db: Board) -> None:
        """Test that _sync_register_project inserts a row retrievable by slug."""
        # Arrange / Act
        db._sync_register_project("my-proj", "marcus-my-proj", 3)

        # Assert
        timing = db._sync_get_project_timing("my-proj")
        assert timing["slug"] == "my-proj"
        assert timing["tmux_session"] == "marcus-my-proj"
        assert timing["n_agents"] == 3
        assert timing["started_at"] is not None
        assert timing["finished_at"] is None

    def test_register_project_idempotent_on_duplicate(self, db: Board) -> None:
        """Test that calling register twice does not overwrite the first record."""
        db._sync_register_project("proj", "session-1", 2)
        first_timing = db._sync_get_project_timing("proj")
        # Second call should be ignored (INSERT OR IGNORE)
        db._sync_register_project("proj", "session-2", 5)
        second_timing = db._sync_get_project_timing("proj")
        assert second_timing["tmux_session"] == "session-1"
        assert second_timing["started_at"] == first_timing["started_at"]

    def test_finish_project_sets_finished_at(self, db: Board) -> None:
        """Test that _sync_finish_project writes finished_at timestamp."""
        # Arrange
        db._sync_register_project("proj", "sess", 1)
        assert db._sync_get_project_timing("proj")["finished_at"] is None

        # Act
        db._sync_finish_project("proj")

        # Assert
        timing = db._sync_get_project_timing("proj")
        assert timing["finished_at"] is not None

    def test_finish_project_idempotent(self, db: Board) -> None:
        """Test that calling _sync_finish_project twice does not change value."""
        db._sync_register_project("proj", "sess", 1)
        db._sync_finish_project("proj")
        first_finished = db._sync_get_project_timing("proj")["finished_at"]
        db._sync_finish_project("proj")
        second_finished = db._sync_get_project_timing("proj")["finished_at"]
        assert first_finished == second_finished

    def test_get_project_timing_returns_empty_for_unknown(self, db: Board) -> None:
        """Test that an unknown project slug returns an empty dict."""
        result = db._sync_get_project_timing("no-such-project")
        assert result == {}

    def test_get_agent_status_returns_inprogress(self, db: Board) -> None:
        """Test that _sync_get_agent_status returns only IN_PROGRESS tasks."""
        # Arrange — create two tasks, claim one
        tasks = [
            _make_task("t1", "Task One"),
            _make_task("t2", "Task Two"),
        ]
        asyncio.run(db.create_project("proj", tasks))
        asyncio.run(db.request_next_task("agent-1", "proj"))

        # Act
        statuses = db._sync_get_agent_status("proj")

        # Assert
        assert len(statuses) == 1
        assert statuses[0]["agent_id"] == "agent-1"
        assert statuses[0]["task_name"] == "Task One"
        assert statuses[0]["task_id"] == "t1"

    def test_get_agent_status_includes_last_activity_artifact(self, db: Board) -> None:
        """Test that last_activity is populated when an artifact exists."""
        tasks = [_make_task("t1", "Task One")]
        asyncio.run(db.create_project("proj", tasks))
        asyncio.run(db.request_next_task("agent-1", "proj"))
        asyncio.run(db.log_artifact("t1", "wrote schema.sql"))

        statuses = db._sync_get_agent_status("proj")
        assert statuses[0]["last_activity"] == "artifact: wrote schema.sql"

    def test_get_agent_status_empty_when_none_inprogress(self, db: Board) -> None:
        """Test that _sync_get_agent_status returns empty list when no active tasks."""
        tasks = [_make_task("t1", "Task One")]
        asyncio.run(db.create_project("proj", tasks))

        statuses = db._sync_get_agent_status("proj")
        assert statuses == []


class TestContextInjection:
    """Tests for dependency context injection in request_next_task."""

    def test_context_injected_into_description(self, db: Board) -> None:
        """Test that completed dependency artifacts appear in the description."""
        tasks = [
            _make_task("parent", "Parent Task"),
            _make_task("child", "Child Task", dependencies=["parent"]),
        ]
        asyncio.run(db.create_project("ctx-proj", tasks))

        # Complete parent with artifact
        asyncio.run(db.request_next_task("a1", "ctx-proj"))
        asyncio.run(db.log_artifact("parent", "schema.sql: CREATE TABLE foo"))
        asyncio.run(db.report_done("parent"))

        # Claim child — context should be injected
        child = asyncio.run(db.request_next_task("a2", "ctx-proj"))
        assert child is not None
        assert "Context from completed dependencies" in child.description
        assert "schema.sql" in child.description

    def test_get_task_context_returns_dep_data(self, db: Board) -> None:
        """Test that get_task_context returns dependency artifacts and decisions."""
        tasks = [
            _make_task("p", "Parent"),
            _make_task("c", "Child", dependencies=["p"]),
        ]
        asyncio.run(db.create_project("ctx-proj2", tasks))
        asyncio.run(db.log_artifact("p", "data"))
        asyncio.run(db.log_decision("p", "used postgres"))

        ctx = asyncio.run(db.get_task_context("c"))
        assert "dependencies" in ctx
        assert "p" in ctx["dependencies"]
        assert "data" in ctx["dependencies"]["p"]["artifacts"]
        assert "used postgres" in ctx["dependencies"]["p"]["decisions"]
