"""Click CLI for Marcus Mini.

Entry point: ``mini``

Commands
--------
build   Decompose a goal, populate the board, and spawn agents.
board   Pretty-print the task board as an ASCII table.
tasks   List tasks with dependency info.
dag     Print an ASCII DAG by topological levels.
progress  Print completion statistics.
config  View or update persistent settings.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click

from marcus_mini.board import Board, ProjectExistsError
from marcus_mini.decomposer import _DEFAULT_API_KEY_ENV, decompose, optimal_agent_count
from marcus_mini.models import Task

_STATE_DIR = Path.home() / ".marcus-mini"
_DEFAULT_DB = _STATE_DIR / "board.db"
_LAST_PROJECT_FILE = _STATE_DIR / "last_project"
_CONFIG_FILE = _STATE_DIR / "config.json"


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------


def _load_config() -> dict[str, str]:
    """Load persistent config from ~/.marcus-mini/config.json.

    Returns
    -------
    dict[str, str]
        Config dict, empty if file does not exist or is malformed.
    """
    if _CONFIG_FILE.exists():
        try:
            data: dict[str, str] = json.loads(_CONFIG_FILE.read_text())
            return data
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_config(cfg: dict[str, str]) -> None:
    """Persist config to ~/.marcus-mini/config.json.

    Parameters
    ----------
    cfg : dict[str, str]
        Config dict to write.
    """
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def _resolve_api_key_env(flag_value: Optional[str]) -> str:
    """Return the env var name to use for the API key.

    Resolution order: CLI flag → config file → ANTHROPIC_API_KEY.

    Parameters
    ----------
    flag_value : str | None
        Value of the --apikey flag, or None if not given.

    Returns
    -------
    str
        Environment variable name.
    """
    if flag_value:
        return flag_value
    cfg = _load_config()
    return cfg.get("api_key_env", _DEFAULT_API_KEY_ENV)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _slugify(text: str, max_len: int = 24) -> str:
    """Convert text to a URL-safe lowercase slug.

    Truncates at the nearest word boundary so slugs stay short and readable
    in `mini projects` tables. With the 4-digit timestamp suffix added by
    callers, total project IDs land around 24-25 chars.

    Parameters
    ----------
    text : str
        Raw input string.
    max_len : int
        Maximum slug length before truncation (default 20).

    Returns
    -------
    str
        Hyphen-separated lowercase slug.
    """
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    text = text.strip("-")
    if len(text) <= max_len:
        return text
    # Truncate at the last hyphen within max_len so we don't slice mid-word.
    truncated = text[:max_len]
    last_hyphen = truncated.rfind("-")
    if last_hyphen >= max_len // 2:
        truncated = truncated[:last_hyphen]
    return truncated.strip("-")


def _save_last_project(project: str) -> None:
    """Persist the most recently used project slug.

    Parameters
    ----------
    project : str
        Project slug to save.
    """
    _LAST_PROJECT_FILE.parent.mkdir(parents=True, exist_ok=True)
    _LAST_PROJECT_FILE.write_text(project)


def _load_last_project() -> str | None:
    """Return the most recently saved project slug, or None.

    Returns
    -------
    str | None
        Saved slug or None if no project has been recorded.
    """
    if _LAST_PROJECT_FILE.exists():
        return _LAST_PROJECT_FILE.read_text().strip() or None
    return None


def _write_sentinel(output_dir: Path, project_slug: str) -> None:
    """Write a .mini sentinel file so CWD-based project resolution works.

    Parameters
    ----------
    output_dir : Path
        Directory that will contain the sentinel.
    project_slug : str
        Project slug to embed in the sentinel JSON.
    """
    sentinel = output_dir / ".mini"
    sentinel.write_text(json.dumps({"project": project_slug}, indent=2))


def _resolve_project(project: Optional[str]) -> str:
    """Return project slug using three-tier resolution.

    Resolution order:
    1. Explicit --project flag.
    2. .mini sentinel in CWD.
    3. Global last-used project from ~/.marcus-mini/last_project.

    Parameters
    ----------
    project : str | None
        Explicit slug from the CLI option.

    Returns
    -------
    str
        Resolved project slug.

    Raises
    ------
    click.UsageError
        If no slug can be resolved by any of the three tiers.
    """
    if project:
        return project
    # Check CWD for .mini sentinel
    mini_file = Path.cwd() / ".mini"
    if mini_file.exists():
        try:
            data: dict[str, str] = json.loads(mini_file.read_text())
            slug = data.get("project")
            if slug:
                return slug
        except (json.JSONDecodeError, OSError):
            pass
    last = _load_last_project()
    if last:
        return last
    raise click.UsageError(
        "No --project given, no .mini file in CWD, and no last project recorded. "
        "Run 'mini build' first."
    )


def _render_dag(tasks: list[Task], compact: bool = False) -> str:
    """Render tasks as a vertical ASCII DAG showing the graph structure.

    Parameters
    ----------
    compact : bool
        If True, use narrower boxes (INNER=10, GAP=3) and ellipsis-truncate
        long task names. Useful for fitting wide DAGs into 80-char terminals
        for screencasts and demos.

    Other Parameters
    ----------------
    tasks : list[Task]
        Full task list.

    Returns
    -------
    str
        Multi-line string containing the rendered DAG.
    """
    if not tasks:
        return "  (no tasks)"

    # 1. Topological levels via BFS
    level: dict[str, int] = {}
    satisfied: set[str] = set()
    remaining = list(tasks)
    lvl = 0
    while remaining:
        runnable = [t for t in remaining if all(d in satisfied for d in t.dependencies)]
        if not runnable:
            break
        for t in runnable:
            level[t.id] = lvl
            satisfied.add(t.id)
        remaining = [t for t in remaining if t.id not in satisfied]
        lvl += 1

    max_level = max(level.values(), default=0)
    by_level: dict[int, list[Task]] = {i: [] for i in range(max_level + 1)}
    for t in tasks:
        by_level[level.get(t.id, 0)].append(t)

    # 2. Layout: size nodes to fit longest name, space slots evenly
    if compact:
        INNER = 10  # narrow box for screencasts / wide DAGs
        GAP = 3
    else:
        INNER = 20
        GAP = 6
    NODE_W = INNER + 2  # including ╭ and ╮
    SLOT = NODE_W + GAP

    max_cols = max(len(v) for v in by_level.values())
    canvas_w = max_cols * SLOT + GAP  # extra margin

    # x-center of each task on the canvas
    task_x: dict[str, int] = {}
    for lv, lvl_tasks in by_level.items():
        n = len(lvl_tasks)
        total = n * NODE_W + (n - 1) * GAP
        start = (canvas_w - total) // 2
        for i, t in enumerate(lvl_tasks):
            task_x[t.id] = start + i * (NODE_W + GAP) + NODE_W // 2

    # 3. Render level by level
    lines: list[str] = []

    for lv in range(max_level + 1):
        lvl_tasks = by_level[lv]
        n = len(lvl_tasks)
        total = n * NODE_W + (n - 1) * GAP
        start = (canvas_w - total) // 2

        top = [" "] * canvas_w
        mid = [" "] * canvas_w
        bot = [" "] * canvas_w

        for i, t in enumerate(lvl_tasks):
            x = start + i * (NODE_W + GAP)
            # Ellipsis-truncate when the name doesn't fit, so you can
            # tell at a glance that it was abbreviated.
            if len(t.name) > INNER:
                label = (t.name[: INNER - 1] + "…").center(INNER)
            else:
                label = t.name.center(INNER)
            for j, ch in enumerate("╭" + "─" * INNER + "╮"):
                top[x + j] = ch
            for j, ch in enumerate("│" + label + "│"):
                mid[x + j] = ch
            for j, ch in enumerate("╰" + "─" * INNER + "╯"):
                bot[x + j] = ch

        lines += [
            "".join(top).rstrip(),
            "".join(mid).rstrip(),
            "".join(bot).rstrip(),
        ]

        if lv >= max_level:
            break

        # Collect edges to next level
        next_tasks = by_level[lv + 1]
        edges: list[tuple[int, int]] = []  # (parent_cx, child_cx)
        for t in lvl_tasks:
            for nt in next_tasks:
                if t.id in nt.dependencies:
                    edges.append((task_x[t.id], task_x[nt.id]))

        if not edges:
            lines.append("")
            continue

        parent_xs = sorted({px for px, _ in edges})
        child_xs = sorted({cx for _, cx in edges})
        all_xs = sorted(set(parent_xs) | set(child_xs))
        x_min, x_max = all_xs[0], all_xs[-1]

        # Row 1: drop │ from each parent that has children
        r1 = [" "] * canvas_w
        for px in parent_xs:
            r1[px] = "│"
        lines.append("".join(r1).rstrip())

        # Row 2: horizontal bridge + junction chars
        r2 = [" "] * canvas_w
        if x_min < x_max:
            for x in range(x_min, x_max + 1):
                r2[x] = "─"
        for x in all_xs:
            is_parent = x in parent_xs
            is_child = x in child_xs
            if is_parent and is_child:
                r2[x] = "┼"
            elif is_parent:
                r2[x] = "┴"  # line from above joins horizontal
            else:
                r2[x] = "┬"  # horizontal splits down to child
        if x_min == x_max:
            r2[x_min] = "│"  # single straight connection
        lines.append("".join(r2).rstrip())

        # Row 3: arrows into each child
        r3 = [" "] * canvas_w
        for cx in child_xs:
            r3[cx] = "▼"
        lines.append("".join(r3).rstrip())

    return "\n".join("  " + ln for ln in lines)


def _print_dag_summary(tasks: list[Task]) -> None:
    """Print the ASCII DAG to stdout.

    Parameters
    ----------
    tasks : list[Task]
        Full task list.
    """
    click.echo(_render_dag(tasks))


def _status_color(status: str) -> str:
    """Return an ANSI-colored status string.

    Parameters
    ----------
    status : str
        Raw status value.

    Returns
    -------
    str
        Colored string for terminal output.
    """
    colors = {
        "TODO": "white",
        "IN_PROGRESS": "yellow",
        "DONE": "green",
        "FAILED": "red",
    }
    return click.style(status, fg=colors.get(status, "white"))


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group()
@click.option(
    "--apikey",
    default=None,
    metavar="ENV_VAR",
    help="Name of the env var holding your Anthropic API key (e.g. CLAUDE_API_KEY).",
)
@click.pass_context
def cli(ctx: click.Context, apikey: Optional[str]) -> None:
    """Marcus Mini — minimal multi-agent coordinator."""
    ctx.ensure_object(dict)
    ctx.obj["api_key_env"] = _resolve_api_key_env(apikey)


# ---------------------------------------------------------------------------
# build
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("goal")
@click.option(
    "--agents",
    "-a",
    type=int,
    default=None,
    help="Override agent count with an exact number.",
)
@click.option(
    "--strategy",
    type=click.Choice(["avg", "max"]),
    default="avg",
    show_default=True,
    help=(
        "Recommendation strategy. 'avg' = average parallelism (utilization-honest, "
        "production default). 'max' = the widest DAG level (peak parallelism, "
        "right for benchmarks). Ignored when --agents is given."
    ),
)
@click.option(
    "--max-cap",
    type=int,
    default=None,
    metavar="N",
    help=(
        "Hard ceiling on the recommended agent count. Defaults: 'avg' "
        "strategy caps at 6 (casual safety); 'max' strategy is uncapped "
        "(you opted into peak parallelism). Pass an explicit value to "
        "bind both strategies."
    ),
)
@click.option(
    "--project",
    "-p",
    default=None,
    help="Project slug (auto-slugified from goal if omitted).",
)
@click.option(
    "--model",
    "-m",
    default="claude-sonnet-4-5",
    show_default=True,
    help="Claude model for decomposition.",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path.cwd(),
    show_default=True,
    help="Directory agents will work in.",
)
@click.option(
    "--agent-api-key-env",
    default=None,
    metavar="VAR",
    help=(
        "Env var holding an Anthropic API key for AGENTS to use (pay-per-token). "
        "Default: agents use your Claude subscription. Use this to bypass "
        "subscription quota walls — but be aware every agent call now costs money."
    ),
)
@click.option(
    "--agent-model",
    default=None,
    metavar="MODEL",
    help=(
        "Claude model for spawned agents (e.g. claude-haiku-4-5, claude-opus-4-7). "
        "Default: agents use whatever model the claude CLI defaults to."
    ),
)
@click.pass_context
def build(
    ctx: click.Context,
    goal: str,
    agents: Optional[int],
    strategy: str,
    max_cap: Optional[int],
    project: Optional[str],
    model: str,
    output_dir: Path,
    agent_api_key_env: Optional[str],
    agent_model: Optional[str],
) -> None:
    """Decompose GOAL, populate the board, and spawn agents.

    \b
    Examples:
      mini build "Snake game in Python"
      mini build "REST API with auth" --agents 3
      mini build "real-time API" --strategy max --max-cap 10  # bench
      mini build "..." --agent-api-key-env BENCH_AGENT_KEY
    """
    if agent_api_key_env is not None:
        if agent_api_key_env not in os.environ:
            raise click.ClickException(
                f"--agent-api-key-env {agent_api_key_env} given but ${agent_api_key_env} "
                f"is not set. Run: export {agent_api_key_env}=sk-ant-..."
            )
        click.echo()
        click.echo(
            click.style(
                "  ⚠  API-KEY MODE ACTIVE — agents will spend money per token.",
                fg="yellow",
                bold=True,
            )
        )
        click.echo(
            click.style(
                f"     Each agent call bills the key in ${agent_api_key_env}. "
                "A typical 3-agent build can cost $1–$5; "
                "wider runs (10+ agents) can cost $20+.",
                fg="yellow",
            )
        )
        click.echo()
    api_key_env: str = ctx.obj["api_key_env"]
    if project:
        project_slug = project
    else:
        # Second resolution prevents back-to-back builds (e.g., bench
        # loops) from colliding on the same slug.
        timestamp = datetime.now(timezone.utc).strftime("%H%M%S")
        project_slug = f"{_slugify(goal)}-{timestamp}"

    click.echo(f"Decomposing goal: {goal!r}")
    click.echo(f"  Project slug : {project_slug}")
    click.echo(f"  Model        : {model}")
    click.echo(f"  Agent model  : {agent_model or '(claude default)'}")
    click.echo(f"  API key env  : {api_key_env}")

    try:
        tasks, _avg_recommendation, decomp_usage = decompose(
            goal, model=model, project=project_slug, api_key_env=api_key_env
        )
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc

    # Compute true DAG width and both recommendation strategies. We
    # surface the true width and warn when the cap clamps the chosen
    # strategy's recommendation, so the user can see when raising the
    # cap (or passing --agents) would unlock more parallelism.
    from marcus_mini.decomposer import dag_widths

    widths = dag_widths(tasks)
    true_max_width = max(widths) if widths else 1
    rec_avg = optimal_agent_count(tasks, strategy="avg", max_cap=max_cap)
    rec_max = optimal_agent_count(tasks, strategy="max", max_cap=max_cap)

    if agents is not None:
        n_agents = agents
        chosen_label = f"explicit (--agents {agents})"
    elif strategy == "max":
        n_agents = rec_max
        chosen_label = "max parallelism"
    else:
        n_agents = rec_avg
        chosen_label = "avg parallelism"

    # Effective cap applied to the *chosen* strategy.
    # avg defaults to 6 when --max-cap unset; max is uncapped by default.
    if max_cap is not None:
        effective_cap = max_cap
    elif strategy == "max":
        effective_cap = None  # uncapped
    else:
        effective_cap = 6

    click.echo(f"\nDecomposed into {len(tasks)} tasks.")
    width_note = f"  DAG: depth={len(widths)}, max width={true_max_width}"
    if effective_cap is not None and true_max_width > effective_cap:
        clamp_msg = (
            f"  (clamped to {effective_cap} by --max-cap; raise it or "
            f"pass --strategy max to use the full width)"
            if max_cap is not None
            else f"  (avg strategy caps at {effective_cap}; "
            f"use --strategy max for the full width)"
        )
        width_note += click.style(clamp_msg, fg="yellow")
    click.echo(width_note)
    click.echo(
        f"  Recommended:  avg={rec_avg}  max={rec_max}  "
        f"(override with --agents N, --strategy max, or --max-cap N)"
    )
    click.echo(f"Using {n_agents} agent(s) — {chosen_label}.")
    # Keep recommended_agents available downstream for the print message
    # in spawn.run, which still expects an int.
    recommended_agents = rec_avg

    db = Board(_DEFAULT_DB)
    try:
        asyncio.run(db.create_project(project_slug, tasks))
    except ProjectExistsError as exc:
        raise click.ClickException(str(exc)) from exc

    _save_last_project(project_slug)

    # Init output directory and git repo
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_sentinel(output_dir, project_slug)
    git_dir = output_dir / ".git"
    if not git_dir.exists():
        subprocess.run(["git", "init", str(output_dir)], check=True)
        click.echo(f"Initialized git repo in {output_dir}")

    click.echo("\nDAG summary:")
    _print_dag_summary(tasks)

    from marcus_mini import spawn

    spawn.run(
        project_slug,
        n_agents,
        output_dir,
        _DEFAULT_DB,
        recommended_agents,
        goal,
        agent_api_key_env=agent_api_key_env,
        agent_model=agent_model,
    )

    # Persist decomposer usage now that the project row exists (register_project
    # inside spawn.run inserts it). `mini tokens` reads these columns later.
    db._sync_record_decomposer_usage(
        project_slug,
        decomp_usage["model"],
        decomp_usage["input_tokens"],
        decomp_usage["output_tokens"],
        decomp_usage["cost_usd"],
    )


# ---------------------------------------------------------------------------
# board
# ---------------------------------------------------------------------------


def _print_board(tasks: list[Task], slug: str) -> None:
    """Render the kanban board to stdout.

    Parameters
    ----------
    tasks : list[Task]
        Full task list for the project.
    slug : str
        Project slug shown in the header.
    """
    # ── Classify ────────────────────────────────────────────────────────
    done_ids = {t.id for t in tasks if t.status == "DONE"}
    backlog: list[Task] = []
    in_progress: list[Task] = []
    blocked: list[Task] = []
    done: list[Task] = []

    for t in tasks:
        if t.status == "DONE":
            done.append(t)
        elif t.status == "IN_PROGRESS":
            in_progress.append(t)
        elif t.status == "FAILED":
            blocked.append(t)
        else:  # TODO
            if all(d in done_ids for d in t.dependencies):
                backlog.append(t)
            else:
                blocked.append(t)

    # ── Layout ───────────────────────────────────────────────────────────
    term_w = shutil.get_terminal_size((120, 40)).columns
    GAP = 2
    col_w = max(24, (term_w - GAP * 3) // 4)
    card_inner = col_w - 2  # space between │ borders
    hdr_inner = term_w - 2  # space between outer header │

    # ── ANSI helpers ─────────────────────────────────────────────────────
    _ANSI = re.compile(r"\x1b\[[0-9;]*m")

    def vlen(s: str) -> int:
        return len(_ANSI.sub("", s))

    def pad(s: str, width: int) -> str:
        return s + " " * max(0, width - vlen(s))

    def pad_card(s: str) -> str:
        return s + " " * max(0, card_inner - vlen(s))

    def boxrow(content: str, color: str) -> str:
        pipe = click.style("│", fg=color)
        return pipe + pad_card(content) + pipe

    # ── Card renderer ─────────────────────────────────────────────────────
    def render_card(task: Task, color: str) -> list[str]:
        top = click.style("┌" + "─" * card_inner + "┐", fg=color)
        bot = click.style("└" + "─" * card_inner + "┘", fg=color)
        rows: list[str] = [top]

        short_id = click.style(f"#{task.id[:8]}", fg=color)
        name_budget = card_inner - 11
        name = (
            task.name
            if len(task.name) <= name_budget
            else task.name[: name_budget - 1] + "…"
        )
        rows.append(boxrow(f" {short_id} {click.style(name, bold=True)}", color))

        first_para = task.description.split("\n")[0]
        for wline in textwrap.wrap(first_para, width=card_inner - 3)[:3]:
            rows.append(boxrow("  " + click.style(wline, fg="bright_black"), color))

        meta: list[str] = []
        if task.assigned_to:
            meta.append(click.style(task.assigned_to, fg="cyan"))
        if task.artifacts:
            meta.append(click.style(f"{len(task.artifacts)} art", fg="blue"))
        if task.decisions:
            meta.append(click.style(f"{len(task.decisions)} dec", fg="magenta"))
        if meta:
            dot = click.style(" · ", fg="bright_black")
            rows.append(boxrow("  " + dot.join(meta), color))

        rows.append(bot)
        rows.append("")
        return rows

    def render_empty(color: str) -> list[str]:
        top = click.style("┌" + "─" * card_inner + "┐", fg=color)
        bot = click.style("└" + "─" * card_inner + "┘", fg=color)
        label = "(empty)"
        pad_l = max(0, (card_inner - len(label)) // 2)
        pad_r = max(0, card_inner - len(label) - pad_l)
        content = " " * pad_l + click.style(label, fg="bright_black") + " " * pad_r
        pipe = click.style("│", fg=color)
        return [top, pipe + content + pipe, bot, ""]

    # ── Build columns ─────────────────────────────────────────────────────
    cols_def = [
        ("Backlog", backlog, "yellow"),
        ("In Progress", in_progress, "cyan"),
        ("Blocked", blocked, "red"),
        ("Done", done, "green"),
    ]
    col_content: list[list[str]] = []
    for _lbl, items, color in cols_def:
        lines: list[str] = []
        if not items:
            lines += render_empty(color)
        else:
            for task in items:
                lines += render_card(task, color)
        col_content.append(lines)

    # ── Header ────────────────────────────────────────────────────────────
    click.echo()
    click.echo(click.style("┌" + "─" * hdr_inner + "┐", fg="magenta"))
    title = f" {slug} ".center(hdr_inner)
    click.echo(click.style("│", fg="magenta") + title + click.style("│", fg="magenta"))
    click.echo(click.style("└" + "─" * hdr_inner + "┘", fg="magenta"))
    click.echo()

    # ── Column headers ────────────────────────────────────────────────────
    header_parts: list[str] = []
    for label, items, color in cols_def:
        hdr = f" {label} ({len(items)}) "
        dash_l = max(0, (col_w - len(hdr)) // 2)
        dash_r = max(0, col_w - len(hdr) - dash_l)
        header_parts.append(click.style("─" * dash_l + hdr + "─" * dash_r, fg=color))
    click.echo((" " * GAP).join(header_parts))
    click.echo()

    # ── Interleave columns side-by-side ───────────────────────────────────
    max_rows = max(len(c) for c in col_content)
    for i in range(max_rows):
        row_parts: list[str] = []
        for content in col_content:
            cell = content[i] if i < len(content) else ""
            row_parts.append(pad(cell, col_w))
        click.echo((" " * GAP).join(row_parts))

    click.echo()


@cli.command(name="board")
@click.option("--project", "-p", default=None, help="Project slug.")
def board_cmd(project: Optional[str]) -> None:
    """Kanban board: Backlog | In Progress | Blocked | Done."""
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    tasks = asyncio.run(db.get_board_state(slug))
    if not tasks:
        click.echo(f"No tasks found for project '{slug}'.")
        return
    _print_board(tasks, slug)


# ---------------------------------------------------------------------------
# watch
# ---------------------------------------------------------------------------


@cli.command(name="watch")
@click.option("--project", "-p", default=None, help="Project slug.")
@click.option(
    "--interval",
    "-i",
    default=3,
    show_default=True,
    help="Refresh interval in seconds.",
)
def watch_cmd(project: Optional[str], interval: int) -> None:
    """Live-refresh the kanban board every N seconds.

    Exits automatically when all tasks are DONE or FAILED.
    Press Ctrl+C to exit early.

    \b
    Examples:
      mini watch
      mini watch --interval 5
    """
    import time

    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)

    def _progress_bar(done: int, total: int, width: int = 30) -> str:
        pct = done / total if total else 0.0
        filled = int(pct * width)
        bar = click.style("█" * filled, fg="green") + click.style(
            "░" * (width - filled), fg="bright_black"
        )
        return f"[{bar}] {done}/{total}  ({pct * 100:.0f}%)"

    try:
        while True:
            tasks = asyncio.run(db.get_board_state(slug))

            # Clear screen and redraw
            click.clear()
            if not tasks:
                click.echo(f"No tasks found for project '{slug}'. Waiting...")
            else:
                _print_board(tasks, slug)

                total = len(tasks)
                done_count = sum(1 for t in tasks if t.status == "DONE")
                failed_count = sum(1 for t in tasks if t.status == "FAILED")
                in_prog = sum(1 for t in tasks if t.status == "IN_PROGRESS")
                now_str = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")

                # Footer status bar
                bar = _progress_bar(done_count, total)
                click.echo(
                    f"  {bar}   "
                    + click.style(f"{in_prog} working", fg="cyan")
                    + click.style("  ·  ", fg="bright_black")
                    + click.style(f"refreshes every {interval}s", fg="bright_black")
                    + click.style("  ·  ", fg="bright_black")
                    + click.style(now_str, fg="bright_black")
                    + click.style("  ·  Ctrl+C to exit", fg="bright_black")
                )

                terminal_done = done_count + failed_count == total
                if terminal_done:
                    click.echo()
                    if failed_count:
                        click.echo(
                            click.style(
                                f"  ✓ Done — {done_count} completed, "
                                f"{failed_count} failed.",
                                fg="yellow",
                            )
                        )
                    else:
                        click.echo(
                            click.style(
                                "  ✓ All tasks complete!", fg="green", bold=True
                            )
                        )
                    break

            time.sleep(interval)

    except KeyboardInterrupt:
        click.echo("\n  Stopped.")


# ---------------------------------------------------------------------------
# tasks
# ---------------------------------------------------------------------------


@cli.command(name="tasks")
@click.option("--project", "-p", default=None, help="Project slug.")
def tasks_cmd(project: Optional[str]) -> None:
    """List tasks with dependency info."""
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    tasks = asyncio.run(db.get_board_state(slug))

    if not tasks:
        click.echo(f"No tasks found for project '{slug}'.")
        return

    click.echo(f"Tasks for project: {slug}\n")
    for t in tasks:
        deps = ", ".join(t.dependencies) if t.dependencies else "none"
        status_str = _status_color(t.status)
        click.echo(f"  {t.id}")
        click.echo(f"    Name   : {t.name}")
        click.echo(f"    Status : {status_str}")
        click.echo(f"    Deps   : {deps}")
        if t.assigned_to:
            click.echo(f"    Agent  : {t.assigned_to}")
        click.echo()


# ---------------------------------------------------------------------------
# dag
# ---------------------------------------------------------------------------


@cli.command(name="dag")
@click.option("--project", "-p", default=None, help="Project slug.")
@click.option(
    "--compact",
    "-c",
    is_flag=True,
    help="Narrower boxes for screencasts / wide DAGs (fits in 80 cols).",
)
def dag_cmd(project: Optional[str], compact: bool) -> None:
    """Print an ASCII DAG grouped by topological levels.

    \b
    Examples:
      mini dag                  # full-size boxes
      mini dag --compact        # narrow boxes for video / wide DAGs
    """
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    tasks = asyncio.run(db.get_board_state(slug))

    if not tasks:
        click.echo(f"No tasks found for project '{slug}'.")
        return

    click.echo(f"DAG for project: {slug}\n")
    click.echo(_render_dag(tasks, compact=compact))


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------


def _export_json(tasks: list[Task], goal: str, slug: str) -> str:
    """Serialize the task list as JSON.

    Parameters
    ----------
    tasks : list[Task]
        The decomposed task list.
    goal : str
        Original project goal.
    slug : str
        Project slug.

    Returns
    -------
    str
        Pretty-printed JSON.
    """
    payload = {
        "project": slug,
        "goal": goal,
        "tasks": [
            {
                "id": t.id,
                "name": t.name,
                "description": t.description,
                "dependencies": list(t.dependencies),
            }
            for t in tasks
        ],
    }
    return json.dumps(payload, indent=2)


def _export_markdown(tasks: list[Task], goal: str, slug: str) -> str:
    """Render the task list as a numbered markdown document.

    Parameters
    ----------
    tasks : list[Task]
        The decomposed task list.
    goal : str
        Original project goal.
    slug : str
        Project slug.

    Returns
    -------
    str
        Human-readable markdown.
    """
    lines: list[str] = []
    lines.append(f"# {slug}")
    lines.append("")
    lines.append(f"**Goal:** {goal}")
    lines.append(f"**Tasks:** {len(tasks)}")
    lines.append("")
    for i, t in enumerate(tasks, 1):
        lines.append(f"## {i}. {t.name}")
        lines.append("")
        lines.append(f"- **id:** `{t.id}`")
        if t.dependencies:
            deps_str = ", ".join(f"`{d}`" for d in t.dependencies)
            lines.append(f"- **depends on:** {deps_str}")
        else:
            lines.append("- **depends on:** (none — entry point)")
        lines.append("")
        lines.append(t.description)
        lines.append("")
    return "\n".join(lines)


def _export_prompt(tasks: list[Task], goal: str, slug: str) -> str:
    """Render a single-agent prompt suitable for testing one Claude
    against the same task list mini coordinates across multiple agents.

    Parameters
    ----------
    tasks : list[Task]
        The decomposed task list.
    goal : str
        Original project goal.
    slug : str
        Project slug.

    Returns
    -------
    str
        Plain-text prompt body for `claude < file.txt`.
    """
    parts: list[str] = []
    parts.append(
        "You are building a software project from a pre-decomposed task list. "
        "The list below was generated by marcus-mini's decomposer. Your job is "
        "to complete EVERY task in dependency order, alone, in this single "
        "session. This is the single-agent baseline used to compare against "
        "mini's multi-agent run.\n"
    )
    parts.append("Rules:")
    parts.append(
        "- Work tasks in dependency order. A task is runnable when "
        "all its dependencies are complete."
    )
    parts.append(
        "- After completing each task, briefly summarize what you built "
        "(file paths, public interfaces) before starting the next."
    )
    parts.append("- Implement real working code. No stubs. Test as you go.")
    parts.append(
        "- Commit each task: "
        '`git add -A && git commit -m "feat({task_id}): <what you built>"`.'
    )
    parts.append(
        "- Do not ask for clarification — make reasonable choices and "
        "document them inline.\n"
    )
    parts.append(f"## Project: {slug}")
    parts.append(f"**Original goal:** {goal}")
    parts.append(f"**Tasks:** {len(tasks)}\n")
    parts.append("## Task list\n")
    for i, t in enumerate(tasks, 1):
        parts.append(f"### Task {i} of {len(tasks)}: {t.name}")
        parts.append(f"- **id:** `{t.id}`")
        if t.dependencies:
            deps_str = ", ".join(f"`{d}`" for d in t.dependencies)
            parts.append(f"- **depends on:** {deps_str}")
        else:
            parts.append("- **depends on:** (none — start here)")
        parts.append("")
        parts.append(t.description)
        parts.append("")
    parts.append(
        "Begin with the first task whose dependencies are empty. Work "
        "through every task. Stop only when all tasks are complete."
    )
    return "\n".join(parts)


@cli.command(name="export")
@click.option("--project", "-p", default=None, help="Project slug.")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["json", "markdown", "prompt"]),
    default="prompt",
    show_default=True,
    help="Output format. 'prompt' is ready to feed a single Claude for baseline tests.",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, path_type=Path),
    default=None,
    help="Write to FILE instead of stdout.",
)
def export_cmd(project: Optional[str], fmt: str, output: Optional[Path]) -> None:
    """Export a project's task list for replay against a single Claude.

    The 'prompt' format produces a ready-to-feed instruction set for a
    single-agent baseline run, so you can compare mini's multi-agent
    coordination against one Claude doing the same work alone.

    \b
    Examples:
      mini export                            # prompt format to stdout
      mini export -f json                    # machine-readable JSON
      mini export -f markdown -o tasks.md    # human-readable markdown
      mini export -o baseline.txt           # save prompt for later
      mini export | claude                  # run baseline immediately
    """
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    tasks = asyncio.run(db.get_board_state(slug))
    if not tasks:
        raise click.ClickException(f"No tasks found for project '{slug}'.")

    rows = asyncio.run(db.get_all_projects())
    proj = next((p for p in rows if p.get("slug") == slug), None)
    goal = str((proj or {}).get("description") or slug)

    if fmt == "json":
        content = _export_json(tasks, goal, slug)
    elif fmt == "markdown":
        content = _export_markdown(tasks, goal, slug)
    else:  # prompt
        content = _export_prompt(tasks, goal, slug)

    if output:
        output.write_text(content)
        click.echo(f"Wrote {fmt} export to {output}", err=True)
    else:
        click.echo(content)


# ---------------------------------------------------------------------------
# progress
# ---------------------------------------------------------------------------


@cli.command(name="progress")
@click.option("--project", "-p", default=None, help="Project slug.")
def progress_cmd(project: Optional[str]) -> None:
    """Print task completion statistics."""
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    tasks = asyncio.run(db.get_board_state(slug))

    if not tasks:
        click.echo(f"No tasks found for project '{slug}'.")
        return

    total = len(tasks)
    done = sum(1 for t in tasks if t.status == "DONE")
    in_progress = sum(1 for t in tasks if t.status == "IN_PROGRESS")
    todo = sum(1 for t in tasks if t.status == "TODO")
    failed = sum(1 for t in tasks if t.status == "FAILED")

    pct = (done / total * 100) if total else 0.0
    summary = f"{done}/{total} tasks complete ({pct:.1f}%)"
    details_parts = []
    if in_progress:
        details_parts.append(f"{in_progress} in progress")
    if todo:
        details_parts.append(f"{todo} todo")
    if failed:
        details_parts.append(f"{failed} failed")

    details = ", ".join(details_parts)
    click.echo(f"{summary} — {details}" if details else summary)


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------


@cli.command(name="config")
@click.option(
    "--apikey",
    default=None,
    metavar="ENV_VAR",
    help="Set the default env var name for the API key (e.g. CLAUDE_API_KEY).",
)
def config_cmd(apikey: Optional[str]) -> None:
    """View or update persistent marcus-mini settings.

    \b
    Examples:
      mini config                          # show current settings
      mini config --apikey CLAUDE_API_KEY  # save as default
    """
    cfg = _load_config()

    if apikey:
        cfg["api_key_env"] = apikey
        _save_config(cfg)
        click.echo(f"Saved: api_key_env = {apikey}")
        click.echo(f"Config: {_CONFIG_FILE}")
    else:
        if not cfg:
            click.echo(f"No config yet. ({_CONFIG_FILE})")
            click.echo(f"Defaults: api_key_env = {_DEFAULT_API_KEY_ENV}")
        else:
            click.echo(f"Config ({_CONFIG_FILE}):")
            for k, v in cfg.items():
                click.echo(f"  {k} = {v}")


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@cli.command(name="status")
@click.option("--project", "-p", default=None)
@click.pass_context
def status_cmd(ctx: click.Context, project: Optional[str]) -> None:
    """Show live board state with per-agent activity and staleness warnings."""
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)

    tasks = asyncio.run(db.get_board_state(slug))
    agent_statuses = asyncio.run(db.get_agent_status(slug))

    if not tasks:
        click.echo(f"No tasks for project '{slug}'.")
        return

    total = len(tasks)
    done = sum(1 for t in tasks if t.status == "DONE")
    pct = done / total * 100 if total else 0.0

    click.echo(f"\nProject: {slug}  ({done}/{total} tasks, {pct:.0f}%)")
    click.echo("─" * 50)

    # Agent activity
    if agent_statuses:
        click.echo("\nAgents:")
        now_dt = datetime.now(timezone.utc)
        any_stale = False
        for ag in agent_statuses:
            updated = ag["updated_at"] or ""
            stale = ""
            if updated:
                try:
                    updated_dt = datetime.fromisoformat(updated)
                    elapsed_s = (now_dt - updated_dt).total_seconds()
                    if elapsed_s > 300:
                        stale = f"  ⚠ no activity for {int(elapsed_s // 60)}m"
                        any_stale = True
                except ValueError:
                    pass
            activity = ag.get("last_activity") or "(starting...)"
            click.echo(f"  {ag['agent_id']}  ◑ {ag['task_name']}{stale}")
            click.echo(f"      {activity[:72]}")
        if any_stale:
            click.echo(
                click.style(
                    "  Stalls are unrecoverable in mini — Marcus has automatic "
                    "stall recovery: https://github.com/lwgray/marcus",
                    fg="yellow",
                )
            )
    else:
        click.echo("\nNo agents currently working.")

    # Task list
    click.echo("\nTasks:")
    icons = {"DONE": "✓", "IN_PROGRESS": "◑", "FAILED": "✗", "TODO": "○"}
    for t in tasks:
        icon = icons.get(t.status, "?")
        agent = f" → {t.assigned_to}" if t.assigned_to else ""
        click.echo(f"  {icon} {t.name[:45]:<45}{agent}")

    click.echo()


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


@cli.command(name="logs")
@click.option(
    "--agent",
    "-a",
    default=None,
    help="Agent ID (e.g. agent-1). Omit for all.",
)
@click.option("--project", "-p", default=None)
@click.option("--lines", "-n", default=50, help="Number of tail lines.")
@click.pass_context
def logs_cmd(
    ctx: click.Context,
    agent: Optional[str],
    project: Optional[str],
    lines: int,
) -> None:
    """Tail agent log files."""
    slug = _resolve_project(project)
    log_dir = _STATE_DIR / "logs" / slug

    if not log_dir.exists():
        click.echo(f"No logs yet for project '{slug}'.")
        return

    if agent:
        log_file = log_dir / f"{agent}.log"
        if not log_file.exists():
            click.echo(f"No log file for agent '{agent}'.")
            return
        import subprocess as sp

        sp.run(["tail", "-n", str(lines), str(log_file)])
    else:
        # Show last 10 lines of each log file
        import subprocess as sp

        for log_file in sorted(log_dir.glob("*.log")):
            click.echo(f"\n{'─' * 40}")
            click.echo(f"  {log_file.stem}")
            click.echo(f"{'─' * 40}")
            sp.run(["tail", "-n", "10", str(log_file)])


# ---------------------------------------------------------------------------
# time
# ---------------------------------------------------------------------------


@cli.command(name="time")
@click.option("--project", "-p", default=None)
@click.pass_context
def time_cmd(ctx: click.Context, project: Optional[str]) -> None:
    """Show project elapsed time and completion timing."""
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    timing = asyncio.run(db.get_project_timing(slug))

    if not timing:
        click.echo(f"No timing data for project '{slug}'.")
        return

    started = timing.get("started_at")
    finished = timing.get("finished_at")

    def _fmt(seconds: float) -> str:
        """Format seconds as human-readable duration.

        Parameters
        ----------
        seconds : float
            Duration in seconds.

        Returns
        -------
        str
            Formatted string such as '2h 3m 5s'.
        """
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        if h:
            return f"{h}h {m}m {s}s"
        if m:
            return f"{m}m {s}s"
        return f"{s}s"

    click.echo(f"\nProject: {slug}")
    if started:
        click.echo(f"  Started:  {started}")
        now_dt = datetime.now(timezone.utc)
        try:
            start_dt = datetime.fromisoformat(started)
            if finished:
                end_dt = datetime.fromisoformat(finished)
                elapsed = (end_dt - start_dt).total_seconds()
                click.echo(f"  Finished: {finished}")
                click.echo(f"  Total:    {_fmt(elapsed)}")
            else:
                elapsed = (now_dt - start_dt).total_seconds()
                click.echo(f"  Elapsed:  {_fmt(elapsed)} (running)")
        except ValueError:
            pass
    click.echo()


# ---------------------------------------------------------------------------
# projects
# ---------------------------------------------------------------------------


@cli.command(name="projects")
@click.option(
    "--all", "show_all", is_flag=True, help="Show all projects, not just running."
)
@click.option("--limit", "-n", default=10, show_default=True, help="Max rows to show.")
def projects_cmd(show_all: bool, limit: int) -> None:
    """List projects. Defaults to running only; use --all to see everything.

    A ► marker indicates the project tied to the current directory.

    \b
    Examples:
      mini projects            # running projects (up to 10)
      mini projects --all      # all projects
      mini projects --all -n 5 # 5 most recent
    """
    db = Board(_DEFAULT_DB)
    all_projects: list[dict[str, str | int | None]] = asyncio.run(db.get_all_projects())

    if not all_projects:
        click.echo("No projects found. Run 'mini build' to start one.")
        return

    projects = (
        all_projects
        if show_all
        else [p for p in all_projects if p.get("status") == "running"]
    )
    hidden = len(all_projects) - len(projects)
    projects = projects[:limit]

    # Determine current project from CWD .mini sentinel
    current_slug: str | None = None
    mini_file = Path.cwd() / ".mini"
    if mini_file.exists():
        try:
            data: dict[str, str] = json.loads(mini_file.read_text())
            current_slug = data.get("project")
        except (json.JSONDecodeError, OSError):
            pass

    if not projects:
        click.echo("No running projects. Use --all to see completed projects.")
        return

    header = f"  {'':2}{'Project':<36} {'Status':<10} {'N':<4} {'Started':<20} Goal / Location"
    click.echo(f"\n{header}")
    click.echo("─" * 100)

    for p in projects:
        slug = str(p.get("slug") or "")
        status = str(p.get("status") or "unknown")
        n_agents = str(p.get("n_agents") or "?")
        started_raw = str(p.get("started_at") or "")
        started = started_raw[:16].replace("T", " ")
        description = str(p.get("description") or p.get("output_dir") or "")
        detail = description[:40] or "(no detail)"
        marker = "►" if slug == current_slug else " "
        fg = (
            "green"
            if status == "done"
            else (
                "yellow"
                if status == "running"
                else "red" if status == "stopped" else "white"
            )
        )
        status_str = click.style(f"{status:<10}", fg=fg)
        # Hard cap legacy long slugs so the table stays aligned. New slugs
        # are <= 30 chars; older ones could be 50+.
        slug_disp = slug if len(slug) <= 34 else slug[:33] + "…"
        click.echo(
            f"  {marker} {slug_disp:<36} {status_str} {n_agents:<4} {started:<20} {detail}"
        )

    click.echo()
    if hidden:
        tip = f"  {hidden} done project(s) hidden — use --all to see them."
        click.echo(click.style(tip, fg="bright_black"))


# ---------------------------------------------------------------------------
# load
# ---------------------------------------------------------------------------


def _count_live_agents() -> tuple[int, list[tuple[str, int]]]:
    """Count agents actually running (tmux panes, not DB records).

    Returns
    -------
    tuple[int, list[tuple[str, int]]]
        (total_agent_count, list of (project_slug, agent_count) tuples).
        Only counts projects whose tmux session currently exists.
    """
    db = Board(_DEFAULT_DB)
    all_projects = asyncio.run(db.get_all_projects())
    live: list[tuple[str, int]] = []
    for p in all_projects:
        if p.get("status") != "running":
            continue
        slug = str(p["slug"])
        session = f"marcus-{slug}"
        result = subprocess.run(
            ["tmux", "has-session", "-t", session], capture_output=True
        )
        if result.returncode == 0:
            n = int(p.get("n_agents") or 0)
            live.append((slug, n))
    total = sum(n for _, n in live)
    return total, live


@cli.command(name="load")
def load_cmd() -> None:
    """Show total active agents across all running projects.

    Uses tmux session existence as truth source, so stale DB records
    are not counted. Useful for checking against your API plan ceiling.

    \b
    Examples:
      mini load
    """
    total, live = _count_live_agents()

    if not live:
        click.echo("No live agents.")
        return

    click.echo(f"\n  {total} agent(s) running across {len(live)} project(s):\n")
    for slug, n in live:
        click.echo(f"    {n}  {slug}")
    click.echo()

    if total > 6:
        warn = (
            f"  ⚠  {total} concurrent agents may exceed Anthropic API limits. "
            "Consider running fewer projects in parallel."
        )
        click.echo(click.style(warn, fg="yellow"))


# ---------------------------------------------------------------------------
# open
# ---------------------------------------------------------------------------


@cli.command(name="wait")
@click.option("--project", "-p", default=None, help="Project slug.")
@click.option(
    "--interval", "-i", default=15, show_default=True, help="Poll interval in seconds."
)
@click.option(
    "--timeout",
    "-t",
    default=7200,
    show_default=True,
    help="Max seconds to wait before giving up.",
)
def wait_cmd(project: Optional[str], interval: int, timeout: int) -> None:
    """Block until all tasks are DONE or FAILED. Exit 0 on success, 1 on timeout.

    Designed for scripts — no output unless --verbose. Use mini watch for
    a live visual display instead.

    \b
    Examples:
      mini wait                        # wait for current project
      mini wait --timeout 3600         # give up after 1 hour
    """
    import sys
    import time

    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    elapsed = 0

    while elapsed < timeout:
        tasks = asyncio.run(db.get_board_state(slug))
        if tasks:
            terminal = sum(1 for t in tasks if t.status in ("DONE", "FAILED"))
            if terminal == len(tasks):
                sys.exit(0)
        time.sleep(interval)
        elapsed += interval

    click.echo(f"Timeout after {timeout}s — project '{slug}' not complete.", err=True)
    sys.exit(1)


@cli.command(name="open")
@click.option("--project", "-p", default=None, help="Project slug.")
def open_cmd(project: Optional[str]) -> None:
    """Print the output directory path for a project.

    Useful with cd: cd $(mini open)
    """
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    all_projects: list[dict[str, str | int | None]] = asyncio.run(db.get_all_projects())

    for p in all_projects:
        if p.get("slug") == slug:
            output_dir = p.get("output_dir")
            if output_dir:
                click.echo(str(output_dir))
            else:
                click.echo(
                    f"No output directory recorded for project '{slug}'.",
                    err=True,
                )
                raise SystemExit(1)
            return

    click.echo(f"Project '{slug}' not found in registry.", err=True)
    raise SystemExit(1)


# ---------------------------------------------------------------------------
# stop
# ---------------------------------------------------------------------------


@cli.command(name="stop")
@click.option(
    "--project", "-p", default=None, help="Project slug. Defaults to last project."
)
@click.option("--all", "stop_all", is_flag=True, help="Stop every running project.")
@click.option(
    "--yes", "-y", is_flag=True, help="Skip confirmation prompt (single-project only)."
)
def stop_cmd(project: Optional[str], stop_all: bool, yes: bool) -> None:
    """Kill agents by terminating tmux session(s).

    \b
    Examples:
      mini stop                       # stop current project
      mini stop --project foo --yes   # stop named project, no prompt
      mini stop --all                 # stop every running project (type STOP to confirm)
    """
    db = Board(_DEFAULT_DB)

    if stop_all:
        all_projects = asyncio.run(db.get_all_projects())
        running = [p for p in all_projects if p.get("status") == "running"]

        if not running:
            click.echo("No running projects.")
            return

        click.echo(f"\n  {len(running)} running project(s) will be stopped:")
        for p in running:
            click.echo(f"    • {p['slug']}")
        click.echo()

        typed = click.prompt("  Type STOP to confirm")
        if typed != "STOP":
            click.echo("Aborted.")
            return

        for p in running:
            slug = str(p["slug"])
            session = f"marcus-{slug}"
            subprocess.run(["tmux", "kill-session", "-t", session], capture_output=True)
            asyncio.run(db.stop_project(slug))

        click.echo(f"\n  Stopped {len(running)} project(s).")
        return

    slug = _resolve_project(project)
    session = f"marcus-{slug}"

    has_session = (
        subprocess.run(
            ["tmux", "has-session", "-t", session],
            capture_output=True,
        ).returncode
        == 0
    )

    if not has_session:
        # No tmux session, but DB may still say running — fix it.
        asyncio.run(db.stop_project(slug))
        click.echo(f"No active tmux session for project '{slug}' (DB updated).")
        return

    if not yes:
        click.confirm(f"Kill all agents in session '{session}'?", abort=True)

    subprocess.run(["tmux", "kill-session", "-t", session], check=True)
    asyncio.run(db.stop_project(slug))
    click.echo(f"Stopped '{slug}' (killed tmux session '{session}').")


# ---------------------------------------------------------------------------
# purge
# ---------------------------------------------------------------------------


@cli.command(name="purge")
def purge_cmd() -> None:
    """Destroy ALL projects and kill all running tmux sessions.

    Requires typing DELETE to confirm. This cannot be undone.

    \b
    Example:
      mini purge
    """
    db = Board(_DEFAULT_DB)
    all_projects: list[dict[str, str | int | None]] = asyncio.run(db.get_all_projects())

    if not all_projects:
        click.echo("No projects to purge.")
        return

    total = len(all_projects)
    running = [p for p in all_projects if p.get("status") == "running"]

    click.echo(f"\n  {total} project(s) will be deleted from the database.")
    if running:
        click.echo(f"  {len(running)} tmux session(s) will be killed.")
    click.echo()
    click.echo("  This cannot be undone.")
    click.echo()

    typed = click.prompt("  Type DELETE to confirm")
    if typed != "DELETE":
        click.echo("Aborted.")
        return

    killed = 0
    for p in running:
        session = f"marcus-{p['slug']}"
        result = subprocess.run(
            ["tmux", "kill-session", "-t", session], capture_output=True
        )
        if result.returncode == 0:
            killed += 1

    conn_path = _DEFAULT_DB
    import sqlite3 as _sqlite3

    conn = _sqlite3.connect(str(conn_path))
    conn.execute("DELETE FROM tasks")
    conn.execute("DELETE FROM projects")
    conn.commit()
    conn.close()

    click.echo(f"\n  Purged {total} project(s), killed {killed} tmux session(s).")


# ---------------------------------------------------------------------------
# tokens
# ---------------------------------------------------------------------------


# Anthropic list pricing per model (USD per 1M tokens). Approximate.
# Used when scraping agent logs in API mode; decomposer cost is computed
# at decompose() time so its model-specific price is already baked in.
_PRICE_PER_M: dict[str, tuple[float, float]] = {
    # model_id : (input $/M, output $/M)
    "claude-sonnet-4-5": (3.0, 15.0),
    "claude-opus-4-7": (15.0, 75.0),
    "claude-haiku-4-5": (1.0, 5.0),
}


def _scrape_agent_tokens(
    project: str,
) -> tuple[int, int, int]:
    """Sum agent token usage across all agent logs for one project.

    Best-effort. Greps each agent's log for lines like
    "tokens: <input> input, <output> output" or the JSON usage blocks
    Claude Code emits at session end. Returns (input, output, n_logs).

    When agents run under a Claude subscription the CLI does not emit
    this info, so the result will be (0, 0, n_logs). API-key mode
    typically does emit usage at session end.

    Parameters
    ----------
    project : str
        Project slug.

    Returns
    -------
    tuple[int, int, int]
        (total_input_tokens, total_output_tokens, n_logs_scanned)
    """
    log_dir = Path.home() / ".marcus-mini" / "logs" / project
    in_tot = 0
    out_tot = 0
    n_logs = 0
    if not log_dir.is_dir():
        return 0, 0, 0
    pat_pair = re.compile(r"(\d+)\s*input.*?(\d+)\s*output", re.IGNORECASE)
    for log_file in sorted(log_dir.glob("agent-*.log")):
        n_logs += 1
        try:
            text = log_file.read_text(errors="replace")
        except OSError:
            continue
        for m in pat_pair.finditer(text):
            in_tot += int(m.group(1))
            out_tot += int(m.group(2))
    return in_tot, out_tot, n_logs


@cli.command(name="tokens")
@click.option("--project", "-p", default=None, help="Project slug.")
def tokens_cmd(project: Optional[str]) -> None:
    """Report token usage for a project (decomposer + agent best-effort).

    Decomposer numbers are exact: mini owns that API call. Agent numbers
    are scraped from agent logs and only present when agents ran in
    API-key mode (Claude Code subscription does not emit usage). Treat
    agent numbers as a lower bound.

    \b
    Examples:
      mini tokens
      mini tokens --project snake-game-1146
    """
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)
    rows = asyncio.run(db.get_all_projects())
    proj = next((p for p in rows if p.get("slug") == slug), None)
    if proj is None:
        click.echo(f"No project '{slug}'.")
        return

    click.echo()
    click.echo(click.style(f"Tokens — {slug}", bold=True))
    click.echo("─" * 52)

    dec_in = int(proj.get("decomp_input_tokens") or 0)
    dec_out = int(proj.get("decomp_output_tokens") or 0)
    dec_cost = float(proj.get("decomp_cost_usd") or 0.0)
    dec_model = str(proj.get("decomp_model") or "unknown")

    if dec_in or dec_out:
        click.echo("  Decomposer (mini-owned)")
        click.echo(f"    Model         {dec_model}")
        click.echo(f"    Input         {dec_in:>10,} tokens")
        click.echo(f"    Output        {dec_out:>10,} tokens")
        click.echo(f"    Total         {dec_in + dec_out:>10,} tokens")
        click.echo(f"    Cost (est.)   ${dec_cost:>10.4f}")
    else:
        click.echo("  Decomposer    (no recorded usage)")

    agent_in, agent_out, n_logs = _scrape_agent_tokens(slug)
    click.echo()
    click.echo(f"  Agents (best-effort, {n_logs} log file(s) scanned)")
    if agent_in or agent_out:
        # Use decomposer model's pricing as a stand-in if we don't know
        # which model the agents ran. Subscription mode is opaque anyway.
        in_price, out_price = _PRICE_PER_M.get(dec_model, (3.0, 15.0))
        agent_cost = (agent_in * in_price + agent_out * out_price) / 1_000_000
        click.echo(f"    Input         {agent_in:>10,} tokens")
        click.echo(f"    Output        {agent_out:>10,} tokens")
        click.echo(f"    Total         {agent_in + agent_out:>10,} tokens")
        click.echo(f"    Cost (est.)   ${agent_cost:>10.4f}")
        click.echo(
            click.style(
                "    Note: scraped from logs — accurate only if agents "
                "ran in API-key mode and emitted usage lines.",
                fg="bright_black",
            )
        )
    else:
        click.echo(
            click.style(
                "    No usage emitted in agent logs. This is normal for "
                "Claude subscription mode (CLI does not print usage). "
                "Run with --agent-api-key-env to capture agent tokens.",
                fg="bright_black",
            )
        )

    total_in = dec_in + agent_in
    total_out = dec_out + agent_out
    if total_in or total_out:
        in_price, out_price = _PRICE_PER_M.get(dec_model, (3.0, 15.0))
        total_cost = (
            dec_cost + (agent_in * in_price + agent_out * out_price) / 1_000_000
        )
        click.echo()
        click.echo(
            f"  TOTAL           {total_in + total_out:>10,} tokens  "
            f"~${total_cost:.4f}"
        )
    click.echo()


# ---------------------------------------------------------------------------
# bench
# ---------------------------------------------------------------------------


@cli.command(name="bench")
@click.option("--project", "-p", default=None, help="Project slug.")
def bench_cmd(project: Optional[str]) -> None:
    """Coordination metrics: wall time, utilization, and coordination tax.

    Coordination tax = fraction of agent-time lost to waiting/sequencing.
    Ideal (tax=0 %): every agent is always working in parallel.
    Typical values of 30-60 % are normal for dependency-heavy projects.

    \b
    Examples:
      mini bench
      mini bench --project snake-game-1200
    """
    slug = _resolve_project(project)
    db = Board(_DEFAULT_DB)

    timing = asyncio.run(db.get_project_timing(slug))
    task_timings = asyncio.run(db.get_task_timing(slug))

    if not timing:
        click.echo(f"No timing data for project '{slug}'.")
        return

    started_raw = timing.get("started_at")
    finished_raw = timing.get("finished_at")
    n_agents = int(timing.get("n_agents") or 1)

    def _dt(s: str | None) -> datetime | None:
        if not s:
            return None
        try:
            return datetime.fromisoformat(s)
        except ValueError:
            return None

    def _fmt(seconds: float) -> str:
        """Format seconds as human-readable duration."""
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        if h:
            return f"{h}h {m}m {s}s"
        if m:
            return f"{m}m {s}s"
        return f"{s}s"

    start_dt = _dt(started_raw)
    end_dt = _dt(finished_raw)

    # Wall time: use now if project still running
    now_dt = datetime.now(timezone.utc)
    effective_end = end_dt or now_dt
    wall_seconds = (effective_end - start_dt).total_seconds() if start_dt else None

    # Per-task durations (only DONE tasks with both timestamps)
    task_durations: dict[str, float] = {}
    timed_tasks = []
    for t in task_timings:
        s = _dt(t.get("started_at"))
        f = _dt(t.get("finished_at"))
        if s and f and t.get("status") == "DONE":
            dur = (f - s).total_seconds()
            task_durations[str(t["id"])] = dur
            timed_tasks.append(t)

    total_work = sum(task_durations.values())

    # Critical path: longest weighted path through DAG
    import json as _json

    deps_map: dict[str, list[str]] = {}
    for t in task_timings:
        raw_deps = t.get("deps") or "[]"
        try:
            deps_map[str(t["id"])] = _json.loads(str(raw_deps))
        except (ValueError, TypeError):
            deps_map[str(t["id"])] = []

    # Topological longest-path using memoisation
    memo: dict[str, float] = {}

    def _longest(task_id: str) -> float:
        if task_id in memo:
            return memo[task_id]
        dur = task_durations.get(task_id, 0.0)
        dep_max = max(
            (
                _longest(d)
                for d in deps_map.get(task_id, [])
                if d in task_durations or d in deps_map
            ),
            default=0.0,
        )
        memo[task_id] = dep_max + dur
        return memo[task_id]

    critical_path_s: float | None = None
    if task_durations:
        critical_path_s = max(_longest(tid) for tid in task_durations)

    # ── Render ────────────────────────────────────────────────────────────
    click.echo()
    click.echo(click.style(f"Bench — {slug}", bold=True))
    click.echo("─" * 52)

    status_label = "finished" if finished_raw else click.style("running", fg="yellow")
    click.echo(f"  Status          {status_label}")
    click.echo(f"  Agents          {n_agents}")

    if wall_seconds is not None:
        wall_label = _fmt(wall_seconds)
        if not finished_raw:
            wall_label += "  (ongoing)"
        click.echo(f"  Wall time       {wall_label}")

    if total_work > 0:
        click.echo(
            f"  Total work      {_fmt(total_work)}  ({len(task_durations)} tasks)"
        )

    if critical_path_s is not None:
        click.echo(f"  Critical path   {_fmt(critical_path_s)}")

    # Utilization + tax (only meaningful when project is done)
    if wall_seconds and total_work > 0 and n_agents > 0:
        available = wall_seconds * n_agents
        utilization = min(total_work / available, 1.0)
        tax = 1.0 - utilization
        util_bar_w = 20
        filled = int(utilization * util_bar_w)
        util_bar = click.style("█" * filled, fg="green") + click.style(
            "░" * (util_bar_w - filled), fg="bright_black"
        )
        click.echo(f"  Utilization     [{util_bar}] {utilization * 100:.1f} %")
        tax_color = "green" if tax < 0.25 else "yellow" if tax < 0.5 else "red"
        click.echo(
            "  Coordination tax  " + click.style(f"{tax * 100:.1f} %", fg=tax_color)
        )
        if tax >= 0.5:
            click.echo(
                click.style(
                    "  High coordination tax — Marcus has predictive stall analytics "
                    "and causal analysis: https://github.com/lwgray/marcus",
                    fg="red",
                )
            )

    # ── Per-agent contribution + effective parallelism ────────────────────
    # Effective parallelism (Simpson-style index): 1 / Σ(pᵢ²) where
    # pᵢ is each agent's fraction of total work time. With perfectly
    # equal contribution across N agents, this equals N. With one agent
    # doing everything, it equals 1. The headline number that says
    # whether multi-agent actually paid off.
    agent_work: dict[str, float] = {}
    agent_tasks: dict[str, int] = {}
    for t in timed_tasks:
        agent = str(t.get("assigned_to") or "")
        if not agent:
            continue
        tid = str(t["id"])
        agent_work[agent] = agent_work.get(agent, 0.0) + task_durations[tid]
        agent_tasks[agent] = agent_tasks.get(agent, 0) + 1

    if agent_work and total_work > 0:
        click.echo()
        click.echo("  Per-agent contribution:")
        max_share = max(agent_work.values())
        bar_w = 16
        for agent, work in sorted(agent_work.items(), key=lambda kv: -kv[1]):
            share = work / total_work
            filled = int((work / max_share) * bar_w) if max_share else 0
            bar = click.style("█" * filled, fg="cyan") + click.style(
                "░" * (bar_w - filled), fg="bright_black"
            )
            click.echo(
                f"    {agent:<10}  [{bar}] {agent_tasks[agent]:>2} tasks  "
                f"{_fmt(work):<10}  ({share * 100:.0f}%)"
            )

        proportions = [w / total_work for w in agent_work.values()]
        sum_sq = sum(p * p for p in proportions)
        effective_n = 1.0 / sum_sq if sum_sq > 0 else 0.0
        ratio = effective_n / n_agents if n_agents else 0.0
        ep_color = "green" if ratio >= 0.9 else "yellow" if ratio >= 0.6 else "red"
        click.echo(
            "  Effective parallelism  "
            + click.style(f"{effective_n:.2f}", fg=ep_color)
            + f" / {n_agents}"
        )
        if ratio < 0.6:
            click.echo(
                click.style(
                    "  Low parallelism — Marcus's contract-first decomposition "
                    "extracts more structural parallelism: https://github.com/lwgray/marcus",
                    fg=ep_color,
                )
            )
        if len(agent_work) < n_agents:
            stalled = n_agents - len(agent_work)
            click.echo(
                click.style(
                    f"    ⚠  {stalled} agent(s) spawned but never claimed work — "
                    "Marcus has lease-based claiming with recovery: "
                    "https://github.com/lwgray/marcus",
                    fg="yellow",
                )
            )

    # ── Per-task table ────────────────────────────────────────────────────
    if timed_tasks:
        click.echo()
        click.echo("  Task timings:")
        max_dur = max(task_durations.values()) if task_durations else 1.0
        bar_w = 16
        name_w = max(len(str(t["name"])) for t in timed_tasks)
        name_w = min(name_w, 36)
        for t in timed_tasks:
            tid = str(t["id"])
            dur = task_durations[tid]
            filled = int((dur / max_dur) * bar_w) if max_dur else 0
            bar = click.style("█" * filled, fg="cyan") + click.style(
                "░" * (bar_w - filled), fg="bright_black"
            )
            agent = str(t.get("assigned_to") or "")
            name = str(t["name"])[:name_w]
            click.echo(f"    {name:<{name_w}}  [{bar}] {_fmt(dur):<10}  {agent}")

    click.echo()
