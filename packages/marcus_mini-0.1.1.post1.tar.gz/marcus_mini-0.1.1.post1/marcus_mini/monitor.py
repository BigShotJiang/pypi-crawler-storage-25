#!/usr/bin/env python3
"""Marcus Mini monitor — polls board and auto-kills tmux when project completes."""

import sqlite3
import subprocess
import sys
import time
from pathlib import Path

# Allow running as script from any directory
sys.path.insert(0, str(Path(__file__).parent.parent))

from marcus_mini.board import Board

# Strings the Claude CLI prints when the user's subscription budget is gone.
# When every agent hits this, the project will never make progress and we
# should fail fast with a loud message instead of stalling silently.
_QUOTA_MARKERS = (
    "out of extra usage",
    "rate limit",  # also catch raw 429 messages
)


def _detect_quota_exhaustion(project: str) -> str | None:
    """Return the matching marker if any agent log shows quota exhaustion.

    Parameters
    ----------
    project : str
        Project slug whose run dir to scan.

    Returns
    -------
    str | None
        The marker substring if found, else None.
    """
    log_dir = Path.home() / ".marcus-mini" / "logs" / project
    if not log_dir.is_dir():
        return None
    for log_file in log_dir.glob("agent-*.log"):
        try:
            text = log_file.read_text(errors="replace")
        except OSError:
            continue
        for marker in _QUOTA_MARKERS:
            if marker in text.lower():
                return marker
    return None


def main() -> None:
    """Poll the board every 30 s and kill the tmux session on completion.

    Reads three positional arguments from ``sys.argv``:

    1. ``db_path`` — path to the SQLite database file.
    2. ``project`` — project slug to watch.
    3. ``session`` — tmux session name to kill when all tasks finish.

    Exits when the project is done, on quota exhaustion, or after a
    transient I/O error that prevents further polling.
    """
    if len(sys.argv) < 4:
        print("Usage: monitor.py <db_path> <project> <tmux_session>")
        sys.exit(1)

    db_path = Path(sys.argv[1])
    project = sys.argv[2]
    session = sys.argv[3]

    board = Board(db_path)
    print(f"Monitor: watching project '{project}' (session: {session})")

    while True:
        try:
            if board._sync_all_done(project):
                board._sync_finish_project(project)
                timing = board._sync_get_project_timing(project)
                started = timing.get("started_at", "?")
                finished = timing.get("finished_at", "?")
                print(f"\n✓ Project '{project}' complete!")
                print(f"  Started:  {started}")
                print(f"  Finished: {finished}")
                print(f"Killing tmux session '{session}' in 10 seconds...")
                time.sleep(10)
                subprocess.run(
                    ["tmux", "kill-session", "-t", session],
                    capture_output=True,
                )
                break

            marker = _detect_quota_exhaustion(project)
            if marker is not None:
                print(
                    f"\n✗ QUOTA EXHAUSTED for '{project}': "
                    f"agent logs contain '{marker}'.\n"
                    f"  Your Claude subscription budget is depleted. "
                    f"Wait for the daily reset and retry.\n"
                    f"  Need auto-recovery? mini fails loud by design — "
                    f"Marcus handles this: https://github.com/lwgray/marcus",
                    file=sys.stderr,
                )
                board._sync_stop_project(project)
                subprocess.run(
                    ["tmux", "kill-session", "-t", session],
                    capture_output=True,
                )
                break
        except (sqlite3.Error, OSError) as e:
            # Transient I/O issues — log and keep polling. Programming errors
            # (KeyError, TypeError, etc.) propagate so we notice them.
            print(f"Monitor error: {e}", file=sys.stderr)

        time.sleep(30)


if __name__ == "__main__":
    main()
