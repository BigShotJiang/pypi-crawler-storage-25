"""tmux-based agent spawner for Marcus Mini."""

from __future__ import annotations

import fcntl
import json
import subprocess
import textwrap
import time
from pathlib import Path
from typing import Any

from marcus_mini.board import Board

_BOARD_SERVER_PATH = Path(__file__).parent / "board_server.py"

_AGENT_PROMPT_TEMPLATE = Path(__file__).parent.parent / "prompts" / "agent_prompt.md"

_SHELL_TEMPLATE_SUBSCRIPTION = textwrap.dedent(
    """\
    #!/bin/bash
    source ~/.zshrc 2>/dev/null || source ~/.bashrc 2>/dev/null
    unset CLAUDECODE CLAUDE_CODE_ENTRYPOINT CLAUDE_CODE_SESSION
    # Unset ANTHROPIC_API_KEY so agents use your Claude subscription,
    # not an API key — prevents unexpected charges.
    unset ANTHROPIC_API_KEY
    export TERM=xterm-256color
    cd {project_dir}
    git pull --rebase 2>/dev/null || true
    echo "Agent {agent_id} starting..."
    claude {model_flag} --mcp-config {mcp_config_path} --dangerously-skip-permissions \
< {prompt_file} 2>&1 | tee {log_file}
    echo "Agent {agent_id} complete."
    """
)

# API-key mode: agents bill the named env var per token. Use this to bypass
# subscription quota walls; the user opted in explicitly via --agent-api-key-env.
_SHELL_TEMPLATE_API_KEY = textwrap.dedent(
    """\
    #!/bin/bash
    source ~/.zshrc 2>/dev/null || source ~/.bashrc 2>/dev/null
    unset CLAUDECODE CLAUDE_CODE_ENTRYPOINT CLAUDE_CODE_SESSION
    # API-key mode: route agent calls through the named env var.
    export ANTHROPIC_API_KEY="${{{api_key_env}}}"
    if [ -z "$ANTHROPIC_API_KEY" ]; then
      echo "ERROR: ${api_key_env} is unset in the agent shell." >&2
      exit 1
    fi
    export TERM=xterm-256color
    cd {project_dir}
    git pull --rebase 2>/dev/null || true
    echo "Agent {agent_id} starting (API-key mode via ${api_key_env})..."
    claude {model_flag} --mcp-config {mcp_config_path} --dangerously-skip-permissions \
< {prompt_file} 2>&1 | tee {log_file}
    echo "Agent {agent_id} complete."
    """
)


def _pretrust_directory(project_dir: Path) -> None:
    """Add project_dir to ~/.claude.json trustedDirectories.

    Uses fcntl advisory locking to avoid concurrent-write corruption.

    Parameters
    ----------
    project_dir : Path
        Directory to mark as trusted for Claude CLI.
    """
    claude_json = Path.home() / ".claude.json"
    lock_path = claude_json.with_suffix(".lock")

    with open(lock_path, "w") as lock_file:
        fcntl.flock(lock_file, fcntl.LOCK_EX)
        try:
            config: dict[str, Any]
            if claude_json.exists():
                with open(claude_json) as f:
                    config = json.load(f)
            else:
                config = {}

            trusted: list[str] = config.get("trustedDirectories", [])
            dir_str = str(project_dir.resolve())
            if dir_str not in trusted:
                trusted.append(dir_str)
                config["trustedDirectories"] = trusted
                with open(claude_json, "w") as f:
                    json.dump(config, f, indent=2)
        finally:
            fcntl.flock(lock_file, fcntl.LOCK_UN)


def create_tmux_session(session: str) -> None:
    """Create a new detached tmux session, or do nothing if it exists.

    Parameters
    ----------
    session : str
        Session name.
    """
    result = subprocess.run(
        ["tmux", "has-session", "-t", session],
        capture_output=True,
    )
    if result.returncode != 0:
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", session],
            check=True,
        )


def spawn_agent(
    session: str,
    pane_idx: int,
    agent_id: str,
    project_dir: Path,
    prompt_file: Path,
    db_path: Path,
    project: str,
    log_file: Path,
    mcp_config_path: Path,
    run_dir: Path,
    agent_api_key_env: str | None = None,
    agent_model: str | None = None,
) -> None:
    """Launch a single Claude agent in a tmux pane.

    Agents 0 and 1 share window 0, agents 2 and 3 share window 1, etc.
    (2 panes per window via horizontal split). Output is tee'd to log_file.

    Parameters
    ----------
    session : str
        tmux session name.
    pane_idx : int
        Zero-based agent index (determines window and pane placement).
    agent_id : str
        Unique agent identifier string.
    project_dir : Path
        Repository directory agents should work in.
    prompt_file : Path
        Path to the agent prompt file (filled template).
    db_path : Path
        SQLite database path.
    project : str
        Project slug.
    log_file : Path
        File to tee agent stdout/stderr to.
    mcp_config_path : Path
        Per-agent MCP config JSON (only mini-board server).
    run_dir : Path
        Per-project run directory where the agent shell script is written.
    agent_model : str | None
        Claude model override for spawned agents (e.g. "claude-haiku-4-5").
        None lets the claude CLI use its own default.
    """
    window_idx = pane_idx // 2
    is_second_pane = pane_idx % 2 == 1
    window_target = f"{session}:{window_idx}"

    if pane_idx == 0:
        # First pane: rename the initial window
        subprocess.run(
            ["tmux", "rename-window", "-t", window_target, f"agents-{window_idx}"],
            check=False,
        )
    elif not is_second_pane:
        # Start of a new window pair
        subprocess.run(
            [
                "tmux",
                "new-window",
                "-t",
                session,
                "-n",
                f"agents-{window_idx}",
            ],
            check=True,
        )
    else:
        # Second pane in the current window — split horizontally
        subprocess.run(
            ["tmux", "split-window", "-h", "-t", window_target],
            check=True,
        )

    # Write shell script (template differs depending on whether agents use
    # the user's subscription or an explicit API key).
    template = (
        _SHELL_TEMPLATE_API_KEY if agent_api_key_env else _SHELL_TEMPLATE_SUBSCRIPTION
    )
    fmt_args: dict[str, str] = {
        "project_dir": str(project_dir.resolve()),
        "agent_id": agent_id,
        "mcp_config_path": str(mcp_config_path.resolve()),
        "prompt_file": str(prompt_file.resolve()),
        "log_file": str(log_file.resolve()),
        "model_flag": f"--model {agent_model}" if agent_model else "",
    }
    if agent_api_key_env:
        fmt_args["api_key_env"] = agent_api_key_env
    script_content = template.format(**fmt_args)
    script_path = run_dir / f"agent_{agent_id}.sh"
    script_path.write_text(script_content)
    script_path.chmod(0o755)

    pane_target = f"{window_target}.{int(is_second_pane)}"
    subprocess.run(
        ["tmux", "send-keys", "-t", pane_target, f"bash {script_path}", "Enter"],
        check=True,
    )


def spawn_monitor(session: str, db_path: Path, project: str) -> None:
    """Spawn the monitor script in a dedicated tmux window.

    Parameters
    ----------
    session : str
        tmux session name.
    db_path : Path
        Path to the SQLite database.
    project : str
        Project slug to watch.
    """
    monitor_path = Path(__file__).parent / "monitor.py"
    # New window named 'monitor'
    subprocess.run(
        ["tmux", "new-window", "-t", session, "-n", "monitor"],
        check=True,
    )
    subprocess.run(
        [
            "tmux",
            "send-keys",
            "-t",
            f"{session}:monitor",
            f"python {monitor_path} {db_path} {project} {session}",
            "Enter",
        ],
        check=True,
    )


def _write_mcp_config(
    agent_id: str,
    tmp_dir: Path,
    db_path: Path,
    project: str,
) -> Path:
    """Write a per-agent MCP config JSON containing only the mini-board server.

    Using --mcp-config instead of ``claude mcp add`` keeps the agent isolated
    from any globally-configured MCP servers (e.g. the full Marcus server),
    preventing contamination from previous experiments.

    Parameters
    ----------
    agent_id : str
        Agent identifier (used to name the config file).
    tmp_dir : Path
        Directory to write the config file.
    db_path : Path
        SQLite database path for the board server.
    project : str
        Project slug the board server should scope to.

    Returns
    -------
    Path
        Path to the written JSON config file.
    """
    config = {
        "mcpServers": {
            "mini-board": {
                "type": "stdio",
                "command": "python",
                "args": [
                    str(_BOARD_SERVER_PATH.resolve()),
                    "--db",
                    str(db_path.resolve()),
                    "--project",
                    project,
                ],
            }
        }
    }
    config_path = tmp_dir / f"mcp_config_{agent_id}.json"
    config_path.write_text(json.dumps(config, indent=2))
    return config_path


def _write_prompt(agent_id: str, tmp_dir: Path) -> Path:
    """Fill the agent prompt template and write to a temp file.

    Parameters
    ----------
    agent_id : str
        Agent identifier to substitute into the template.
    tmp_dir : Path
        Directory to write the filled prompt file.

    Returns
    -------
    Path
        Path to the written prompt file.
    """
    if _AGENT_PROMPT_TEMPLATE.exists():
        template = _AGENT_PROMPT_TEMPLATE.read_text()
    else:
        # Fallback minimal prompt
        template = (
            "You are agent {AGENT_ID}. Use mini-board MCP tools to "
            "request tasks and complete them. Loop until no tasks remain."
        )

    content = template.replace("{AGENT_ID}", agent_id)
    prompt_file = tmp_dir / f"prompt_{agent_id}.md"
    prompt_file.write_text(content)
    return prompt_file


_SPAWN_STAGGER_S = 5  # seconds between agent spawns to avoid API burst


def run(
    project: str,
    n_agents: int,
    project_dir: Path,
    db_path: Path,
    recommended: int,
    description: str = "",
    agent_api_key_env: str | None = None,
    agent_model: str | None = None,
) -> None:
    """Spawn n_agents in a tmux session, register project, and spawn monitor.

    Does not attach to the tmux session. Prints hints for manual inspection.

    Parameters
    ----------
    project : str
        Project slug (used for session name and board operations).
    n_agents : int
        Number of agent panes to spawn.
    project_dir : Path
        Repository directory for agents to work in.
    db_path : Path
        SQLite database path.
    recommended : int
        Recommended agent count from DAG analysis (displayed to user).
    description : str
        Original natural-language goal prompt (stored in project registry).
    agent_model : str | None
        Claude model override forwarded to each spawned agent. None = claude default.
    """
    session = f"marcus-{project}"

    # Per-project run directory holds ALL per-agent artifacts (scripts,
    # MCP configs, prompts, logs). Sharing one global dir caused parallel
    # `mini build` calls to overwrite each other's agent files mid-spawn.
    run_dir = Path.home() / ".marcus-mini" / "logs" / project
    run_dir.mkdir(parents=True, exist_ok=True)

    print(
        f"Spawning {n_agents} agents "
        f"(DAG recommends {recommended}) in session '{session}'"
    )

    _pretrust_directory(project_dir)
    create_tmux_session(session)

    # Register project timing before spawning agents
    board = Board(db_path)
    board._sync_register_project(
        project, session, n_agents, str(project_dir.resolve()), description
    )

    for i in range(n_agents):
        agent_id = f"agent-{i + 1}"
        prompt_file = _write_prompt(agent_id, run_dir)
        mcp_config_path = _write_mcp_config(agent_id, run_dir, db_path, project)
        log_file = run_dir / f"{agent_id}.log"
        spawn_agent(
            session,
            i,
            agent_id,
            project_dir,
            prompt_file,
            db_path,
            project,
            log_file,
            mcp_config_path,
            run_dir,
            agent_api_key_env,
            agent_model,
        )
        print(f"  Spawned {agent_id} (pane {i})")
        if i < n_agents - 1:
            time.sleep(_SPAWN_STAGGER_S)

    spawn_monitor(session, db_path, project)

    print(f"\n✓ {n_agents} agents running in tmux session '{session}'")
    print("  Status  : mini status")
    print("  Logs    : mini logs --agent agent-1")
    print("  Board   : mini board")
    print("  Time    : mini time")
    print(f"  Debug   : tmux attach -t {session}")
    print("\nAgents will auto-terminate when all tasks complete.")
