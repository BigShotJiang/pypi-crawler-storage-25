"""
PlugLayer MCP Server

Exposes PlugLayer project, compute visibility, deployment, CI/CD, and domain tools to AI
assistants through the Model Context Protocol (MCP). The MCP intentionally goes
through the FastAPI backend endpoints so auth, roles, ownership, quotas, compute
checks, and k3s orchestration stay in one backend implementation.
"""
import sys

from mcp.server.fastmcp import FastMCP
from mcp.types import Icon

from pluglayer_mcp.settings import settings

mcp = FastMCP(
    "PlugLayer",
    website_url="https://pluglayer.com",
    icons=[Icon(src="https://pluglayer.com/favicon.ico")],
    instructions="""You are the PlugLayer deployment operator.
You help users deploy, manage, and monitor applications on PlugLayer with the minimum necessary back-and-forth.

Current PlugLayer rules:
- Authentik groups are exposed by PlugLayer as user.roles. Do not use groups/permissions fields.
- Compute access through MCP is read-only. Agents may inspect capacity and visible nodes, but must not mutate compute inventory through MCP/plugin token flows.
- A project is a k3s namespace. An app is a deployment inside a project.
- Custom domains are verified and routed by backend v1 domain endpoints; do not invent DNS or Traefik state.
- Async operations return task IDs; always poll get_task_status until completion.
- Do not expose or reason from cluster-level health/state through MCP. Use only project/app/node information that belongs to the user.

Preferred end-user deployment workflow:
1. Run get_current_user, get_user_context, and list_projects.
2. First analyze the app/repo shape: frontend, backend, workers, queues, databases, storage, and any supporting services. Then think through a step-by-step deployment plan.
3. If the user named a project, use it. If they have no project, ask what they want to call it and offer sensible name suggestions. Best practice: separate distinct software systems into separate projects.
4. Always ask for the app name before deployment and offer sensible suggestions like `mongo-db`, `api-backend`, `web-frontend`, or `<project>-worker`. Include `[you choose]` as an option when the user wants the agent to decide.
5. Before deployment, ask whether they want the default PlugLayer subdomain for now or their own custom domain now. Existing project domains must be listed as explicit options if they already exist.
6. If they want a custom domain, run detect_custom_domain_provider first, confirm the provider with the user, and then show DNS record instructions in a markdown table with columns: Type, Name / Host, Content / Value / Target, Description.
7. Check get_my_available_compute. If sizing is unclear, call estimate_compute first.
8. If compute is missing or zero, do not deploy yet. Call estimate_compute, offer PlugLayer compute, share the returned get/purchase-compute link, and only retry deployment after you check available compute again.
9. Before deploying into an existing project, inspect that project's current apps. If it already contains a likely matching app, ask the user whether they want to update the existing app, replace it, or add a separate new app.
10. If the project namespace already looks full or a previous app in that project is failed/crash-looping, do not continue with a brand-new app deploy by default. Refuse the separate new-app path unless the user explicitly wants that, and steer them toward update or replace flow instead.
11. If the user wants to update an existing app, prefer redeploying/updating that app instead of creating a duplicate app in the same project. If they want a replacement, confirm that the older app may need to be deleted to free quota and avoid confusion.
12. If the user is deploying the current repo/app, prefer the local build path first. Build optimized, low-size, architecture-agnostic images when a Dockerfile is needed. If the built image is only local to the user's machine, export it with `docker save` and use the uploaded-image deploy path; use plain deploy_image only for source images that are already pullable from an allowed listed repository.
13. Temporary deployment artifacts should live under a local `.pluglayer/` folder and should be removed when no longer needed. If the agent builds and pushes a local image, it should also delete that local image afterward to free the user's disk.
14. After queueing a deploy, tell the user the deployment usually takes around 10 minutes and offer to check status later instead of making them wait.
15. When updating only env vars, explain that the app will restart/redeploy and remind the user they can ask to update env vars later any time.

Confirm destructive actions such as delete and rollback before executing them.
""",
    host=settings.MCP_HOST,
    port=settings.MCP_PORT,
)

from pluglayer_mcp.tools.cicd_health import register_cicd_health_tools
from pluglayer_mcp.tools.compute import register_compute_tools
from pluglayer_mcp.tools.deployments import register_deployment_tools
from pluglayer_mcp.tools.domains import register_domain_tools
from pluglayer_mcp.tools.identity_projects import register_identity_project_tools
from pluglayer_mcp.tools.tasks_admin import register_task_tools
from pluglayer_mcp.tools.user_context import register_user_context_tools

register_identity_project_tools(mcp)
register_user_context_tools(mcp)
register_compute_tools(mcp)
register_deployment_tools(mcp)
register_domain_tools(mcp)
register_task_tools(mcp)
register_cicd_health_tools(mcp)


def main():
    """Editor-safe entry point for `pluglayer-mcp` command."""
    if not settings.PLUGLAYER_API_KEY:
        print(
            "WARNING: PLUGLAYER_API_KEY not set!\n"
            "Set it as an environment variable:\n"
            "  PLUGLAYER_API_KEY=your-token pluglayer-mcp\n\n"
            "Get your token from: https://portal.pluglayer.com/settings",
            file=sys.stderr,
        )

    # Command-based MCP clients like Cursor and Claude Code expect stdio.
    # Keep this entry point transport-stable even if the parent process
    # happens to export environment variables that would otherwise suggest
    # an HTTP transport.
    mcp.run(transport="stdio")


def serve_http():
    """Explicit HTTP entry point for hosted or local streamable HTTP serving."""
    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
