"""Tests for slackker package"""
