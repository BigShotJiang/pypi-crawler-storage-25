# defi-analytics-py

DeFi analytics library for NEAR Protocol.

[![PyPI version](https://img.shields.io/pypi/v/defi-analytics-py)](https://pypi.org/project/defi-analytics-py/)
![Python](https://img.shields.io/pypi/pyversions/defi-analytics-py)

## Installation

pip install defi-analytics-py

**Requires Python 3.9+**

## Quick Start

from defi_analytics_py import DefiAnalyticsPyClient

client = DefiAnalyticsPyClient()

block = client.get_block()
account = client.get_account("v2.ref-finance.near")
pools = client.get_pools()
pool = client.get_pool(pool_id=1)
deposits = client.get_deposits(account_id="user.near", contract="v2.ref-finance.near")
tvl = client.pool_tvl_estimate(pool_id=1)

near = client.yocto_to_near("1000000000000000000000000")
yocto = client.near_to_yocto(1.0)

client.close()

## API Reference

### `DefiAnalyticsPyClient(rpc_url, timeout)`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `rpc_url` | NEAR mainnet RPC | Custom RPC endpoint |
| `timeout` | `30` | Request timeout in seconds |

### Methods

| Method | Description |
|--------|-------------|
| `get_block()` | Fetch latest block |
| `get_account(account_id)` | Fetch account state |
| `get_pools(contract)` | List all pools |
| `get_pool(pool_id, contract)` | Fetch a single pool |
| `get_deposits(account_id, contract)` | Fetch account deposits |
| `pool_tvl_estimate(pool_id, contract)` | Estimate pool TVL |
| `yocto_to_near(yocto)` | Convert yoctoNEAR → NEAR |
| `near_to_yocto(near)` | Convert NEAR → yoctoNEAR |
| `close()` | Close the HTTP session |

## License

MIT