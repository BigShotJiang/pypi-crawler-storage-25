"""DeFi analytics library for NEAR Protocol."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import requests

__version__ = "1.0.0"
__all__ = ["DefiAnalyticsPyClient"]

NEAR_RPC = "https://rpc.mainnet.near.org"
REF_FINANCE = "v2.ref-finance.near"
JUMBO_EXCHANGE = "v1.jumbo_exchange.near"


class DefiAnalyticsPyClient:
    """Client for DeFi analytics on NEAR Protocol."""

    def __init__(self, rpc_url: str = NEAR_RPC, timeout: int = 30) -> None:
        self.rpc_url = rpc_url
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    def _rpc(self, method: str, params: Any) -> Any:
        """Send a NEAR JSON-RPC request."""
        payload = {
            "jsonrpc": "2.0",
            "id": int(time.time() * 1000),
            "method": method,
            "params": params,
        }
        resp = self._session.post(self.rpc_url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        if "error" in data:
            raise RuntimeError(f"RPC error: {data['error']}")
        return data["result"]

    def _call(self, contract: str, method: str, args: Dict[str, Any] | None = None) -> Any:
        """Call a view method on a NEAR contract."""
        import base64, json
        encoded = base64.b64encode(json.dumps(args or {}).encode()).decode()
        result = self._rpc(
            "query",
            {
                "request_type": "call_function",
                "finality": "final",
                "account_id": contract,
                "method_name": method,
                "args_base64": encoded,
            },
        )
        import json as _json
        raw = bytes(result["result"])
        return _json.loads(raw.decode())

    # ------------------------------------------------------------------ #
    #  NEAR chain metrics                                                  #
    # ------------------------------------------------------------------ #

    def get_block(self) -> Dict[str, Any]:
        """Return the latest finalized block info."""
        result = self._rpc("block", {"finality": "final"})
        header = result["header"]
        return {
            "height": header["height"],
            "hash": header["hash"],
            "timestamp": header["timestamp"] // 10**9,
            "gas_price": header["gas_price"],
        }

    def get_account(self, account_id: str) -> Dict[str, Any]:
        """Return basic account info for a NEAR account."""
        result = self._rpc(
            "query",
            {"request_type": "view_account", "finality": "final", "account_id": account_id},
        )
        return {
            "account_id": account_id,
            "balance_near": int(result["amount"]) / 10**24,
            "storage_bytes": result["storage_usage"],
            "code_hash": result["code_hash"],
        }

    # ------------------------------------------------------------------ #
    #  Ref Finance                                                         #
    # ------------------------------------------------------------------ #

    def get_pools(self, contract: str = REF_FINANCE, limit: int = 10) -> List[Dict[str, Any]]:
        """Return top pools from a Ref Finance-compatible contract."""
        raw: List[Any] = self._call(contract, "get_pools", {"from_index": 0, "limit": limit})
        pools = []
        for i, p in enumerate(raw):
            pools.append({
                "pool_id": i,
                "pool_kind": p.get("pool_kind", "SIMPLE_POOL"),
                "token_account_ids": p.get("token_account_ids", []),
                "amounts": p.get("amounts", []),
                "total_fee": p.get("total_fee", 0),
                "shares_total_supply": p.get("shares_total_supply", "0"),
            })
        return pools

    def get_pool(self, pool_id: int, contract: str = REF_FINANCE) -> Dict[str, Any]:
        """Return details of a single pool by ID."""
        return self._call(contract, "get_pool", {"pool_id": pool_id})

    def get_deposits(self, account_id: str, contract: str = REF_FINANCE) -> Dict[str, str]:
        """Return token deposits for an account in Ref Finance."""
        return self._call(contract, "get_deposits", {"account_id": account_id})

    def get_return(
        self,
        pool_id: int,
        token_in: str,
        amount_in: str,
        token_out: str,
        contract: str = REF_FINANCE,
    ) -> str:
        """Estimate swap return amount."""
        return self._call(
            contract,
            "get_return",
            {
                "pool_id": pool_id,
                "token_in": token_in,
                "amount_in": amount_in,
                "token_out": token_out,
            },
        )

    # ------------------------------------------------------------------ #
    #  Portfolio analytics                                                 #
    # ------------------------------------------------------------------ #

    def portfolio_summary(
        self, account_id: str, contract: str = REF_FINANCE
    ) -> Dict[str, Any]:
        """Return portfolio overview: balance + DEX deposits."""
        account = self.get_account(account_id)
        try:
            deposits = self.get_deposits(account_id, contract)
        except Exception:
            deposits = {}
        return {
            "account_id": account_id,
            "near_balance": account["balance_near"],
            "dex_deposits": deposits,
            "storage_bytes": account["storage_bytes"],
        }

    def pool_tvl_estimate(self, pool_id: int, contract: str = REF_FINANCE) -> Dict[str, Any]:
        """Return raw TVL data (amounts) for a pool."""
        pool = self.get_pool(pool_id, contract)
        return {
            "pool_id": pool_id,
            "token_account_ids": pool.get("token_account_ids", []),
            "amounts": pool.get("amounts", []),
            "shares_total_supply": pool.get("shares_total_supply", "0"),
        }

    def top_pools_by_liquidity(
        self, limit: int = 20, contract: str = REF_FINANCE
    ) -> List[Dict[str, Any]]:
        """Return pools sorted by shares_total_supply descending."""
        pools = self.get_pools(contract, limit=limit)
        return sorted(pools, key=lambda p: int(p["shares_total_supply"]), reverse=True)

    # ------------------------------------------------------------------ #
    #  Utility                                                             #
    # ------------------------------------------------------------------ #

    def yocto_to_near(self, yocto: int | str) -> float:
        """Convert yoctoNEAR to NEAR."""
        return int(yocto) / 10**24

    def near_to_yocto(self, near: float) -> int:
        """Convert NEAR to yoctoNEAR."""
        return int(near * 10**24)

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self) -> "DefiAnalyticsPyClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()