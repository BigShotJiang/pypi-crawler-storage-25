# Changelog

All notable changes to the dataknobs (legacy) package will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased

## v0.1.4 - 2026-05-09

### Security
- Bumped minimum `flask` requirement from `>=3.0.0` to `>=3.1.3`
  to exclude versions affected by GHSA-68rp-wp8r-4726.
