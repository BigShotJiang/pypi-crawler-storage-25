from rich.text import Text
from rich.table import Table
from readchar import key
from ..base import BasePrompt, Emoji


class TextPrompt(BasePrompt):
    def __init__(self, message: str, password: bool = False, **kwargs):
        self.emoji = Emoji("pen")
        super().__init__(message, **kwargs)
        self.password = password
        self.buffer = ""

    def render(self) -> Table:
        table = Table.grid(padding=(0, 1))
        table.show_edge = False
        table.pad_edge = False
        table.add_row(
            self.message,
            Text(
                ("*" * len(self.buffer) if self.password else self.buffer),
                style="bold white",
            ),
        )
        return table

    def _handle_key(self, k: str) -> None:
        if k.startswith(key.ESC):
            return

        for char in k:
            if char == key.ENTER or char == "\r":
                self.result = self.buffer
                self.done = True
                return
            if char == key.BACKSPACE:
                self.buffer = self.buffer[:-1]
            elif char.isprintable():
                self.buffer += char

    def _format_result(self) -> str:
        if self.result is None:
            return ""
        if self.password:
            return "*" * len(self.result)
        return str(self.result)
