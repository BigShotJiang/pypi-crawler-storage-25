# Changelog

## [0.5.0](https://github.com/momentiq-ai/cerebe-platform/compare/cerebe-v0.4.2...cerebe-v0.5.0) (2026-04-19)


### ⚠ BREAKING CHANGES

* **sdk-python:** client.rag is a new public namespace; applications using a custom Cerebe subclass that previously defined a 'rag' attribute will conflict. Rename your attribute to avoid the clash.

### Features

* **sdk-python:** expose RAG resource for document embedding and retrieval ([302634c](https://github.com/momentiq-ai/cerebe-platform/commit/302634c6802a820127cc1756520ed9f5fea2e4b0))


### Documentation

* **rag:** design spec and implementation plans for RAG SDK integration ([#50](https://github.com/momentiq-ai/cerebe-platform/issues/50)) ([0af84c6](https://github.com/momentiq-ai/cerebe-platform/commit/0af84c62dc91688ad09ccc470f12a5aefb2d420e))

## [0.4.2](https://github.com/momentiq-ai/cerebe-platform/compare/cerebe-v0.4.1...cerebe-v0.4.2) (2026-04-13)


### Bug Fixes

* **llm:** add azure-ai-documentintelligence to requirements.txt ([#39](https://github.com/momentiq-ai/cerebe-platform/issues/39)) ([42d7bd4](https://github.com/momentiq-ai/cerebe-platform/commit/42d7bd4d9f110b4ae4ff408a4e18bc3bda4c0a18))
* **llm:** fix Azure DI provider — SDK API, field extraction, model routing ([#38](https://github.com/momentiq-ai/cerebe-platform/issues/38)) ([020f66b](https://github.com/momentiq-ai/cerebe-platform/commit/020f66b61a7e3407fcd74ac11eb52f6eb40f42d3))
* **sdk,storage:** handle string error bodies + add presigned upload complete endpoint ([#47](https://github.com/momentiq-ai/cerebe-platform/issues/47)) ([0b40307](https://github.com/momentiq-ai/cerebe-platform/commit/0b40307ef92b723938ce19eac43ccad344f83130))
* **sdk:** replace **kwargs with explicit args for mypy compatibility ([226e1b7](https://github.com/momentiq-ai/cerebe-platform/commit/226e1b7eda82194d23ad5a752e9c145667043f03))

## [0.4.1](https://github.com/momentiq-ai/cerebe-platform/compare/cerebe-v0.4.0...cerebe-v0.4.1) (2026-04-06)


### Bug Fixes

* **sdk:** add tax_document to Python SDK Capability Literal ([#35](https://github.com/momentiq-ai/cerebe-platform/issues/35)) ([af47638](https://github.com/momentiq-ai/cerebe-platform/commit/af47638264cd1dc0e43246f415b14b05ce8e59f4)), closes [#33](https://github.com/momentiq-ai/cerebe-platform/issues/33)

## [0.4.0](https://github.com/momentiq-ai/cerebe-platform/compare/cerebe-v0.3.0...cerebe-v0.4.0) (2026-04-06)


### ⚠ BREAKING CHANGES

* **cerebe:** Version 0.3.0 adds new resource modules (prompts, prompt_v2, plre, llm) that were wired in the source but never released from the cerebe-platform repo. This is the first minor release from the standalone repo.

### Features

* **cerebe:** bump Python SDK to v0.3.0 — adds prompts, plre, llm resources ([#12](https://github.com/momentiq-ai/cerebe-platform/issues/12)) ([9388ccf](https://github.com/momentiq-ai/cerebe-platform/commit/9388ccfb3310e38e74b717e8cb855fb5ca94f3b9))
* initial cerebe-platform repo setup from sage3c extraction ([edd88fc](https://github.com/momentiq-ai/cerebe-platform/commit/edd88fc4584736b8704945699bd2c1c99b5fe2bc))

## [0.2.7](https://github.com/momentiq-ai/cerebe-platform/compare/cerebe-v0.2.6...cerebe-v0.2.7) (2026-03-25)


### Features

* initial cerebe-platform repo setup from sage3c extraction ([edd88fc](https://github.com/momentiq-ai/cerebe-platform/commit/edd88fc4584736b8704945699bd2c1c99b5fe2bc))

## [0.2.6](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.5...cerebe-v0.2.6) (2026-03-16)


### Bug Fixes

* **cerebe:** add missing scopes (prompts/prompt/product-planning) + fix SDK memory.update 422 ([#822](https://github.com/alien8d/sage3c/issues/822)) ([ed556ed](https://github.com/alien8d/sage3c/commit/ed556edc2c1617ef8eb1d4da3d9c1659075fc501))

## [0.2.5](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.4...cerebe-v0.2.5) (2026-03-16)


### Bug Fixes

* **sdk:** storage SDK fixes — analyzeContent query params, extract type ([#818](https://github.com/alien8d/sage3c/issues/818)) ([83107c6](https://github.com/alien8d/sage3c/commit/83107c61d29fbff3bab7040e2153d201e43726f9))

## [0.2.4](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.3...cerebe-v0.2.4) (2026-03-14)


### Bug Fixes

* address PR review — Python SDK get(), TS test, tenant-scoped dedup ([dbd2f03](https://github.com/alien8d/sage3c/commit/dbd2f03d622a4253dc8f6177ea70c7afe37b534f))

## [0.2.3](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.2...cerebe-v0.2.3) (2026-03-14)


### Bug Fixes

* **cerebe:** fix remaining secret shopper issues — scores, get, enum ([ded8c90](https://github.com/alien8d/sage3c/commit/ded8c901c5c00b6e88030fb056d624eefd684010))

## [0.2.2](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.1...cerebe-v0.2.2) (2026-03-14)


### Features

* **cerebe:** Cycle 137 Phases 3-5 — test lifecycle, portal mode toggle, SDK env awareness ([#799](https://github.com/alien8d/sage3c/issues/799)) ([f945add](https://github.com/alien8d/sage3c/commit/f945add6cc79bc9eeae05d4aa8593fd17d3456d0))

## [0.2.1](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.0...cerebe-v0.2.1) (2026-03-13)


### Features

* Cerebe Cognitive Services Platform — productization foundation (Cycles 123-128) ([85e98b8](https://github.com/alien8d/sage3c/commit/85e98b8e4f1719c5a09b436016cc93e47ef7c3cb))
* Cycle 129 — Sage SDK migration + build integration ([adfa0d6](https://github.com/alien8d/sage3c/commit/adfa0d65e1a2fce492730c7a563b1ea434e54d56))
* **sdks:** add unit tests, CI/CD workflows, and release-please automation ([efb0c36](https://github.com/alien8d/sage3c/commit/efb0c363562da368c6597ca493abdaaa5eeb90fe))
* **sdks:** sync both SDKs to 100% API coverage + OpenAPI auto-gen pipeline ([614f69f](https://github.com/alien8d/sage3c/commit/614f69f7310ed2046b4ee1edbad4e917e27a9215))


### Bug Fixes

* **sdks:** mypy strict compliance, portal code examples, openapi-export target ([aab5e16](https://github.com/alien8d/sage3c/commit/aab5e1666c3e6ae8f7387e5a5604ffd7815375b8))


### Documentation

* **sdks:** add comprehensive README for TypeScript and Python SDKs ([f5aebf7](https://github.com/alien8d/sage3c/commit/f5aebf7d4f8f16bc7fe8120c2da540a1d222e821))
