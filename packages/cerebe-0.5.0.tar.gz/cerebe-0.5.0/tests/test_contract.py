"""Contract tests: validate SDK HTTP calls against the OpenAPI spec via Prism mock server.

Run with: pytest -m contract tests/test_contract.py -v
Requires Prism running at http://localhost:4010.
"""

from __future__ import annotations

import socket
from typing import Any

import pytest

from cerebe import Cerebe

PRISM_HOST = "localhost"
PRISM_PORT = 4010
PRISM_URL = f"http://{PRISM_HOST}:{PRISM_PORT}"


def _prism_is_reachable() -> bool:
    """Check if Prism mock server is accepting connections."""
    try:
        with socket.create_connection((PRISM_HOST, PRISM_PORT), timeout=2):
            return True
    except OSError:
        return False


@pytest.fixture(scope="module")
def client() -> Cerebe:
    """Create a Cerebe client pointing at the Prism mock server."""
    if not _prism_is_reachable():
        pytest.skip("Prism mock server not running at " + PRISM_URL)
    return Cerebe(api_key="ck_test_contract123", base_url=PRISM_URL, max_retries=0, timeout=10.0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assert_response(resp: Any) -> None:
    """Assert the response parsed without exceptions and has expected shape."""
    assert resp is not None
    assert hasattr(resp, "data")
    assert hasattr(resp, "meta")


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestMemoryContract:
    def test_add(self, client: Cerebe) -> None:
        resp = client.memory.add("test memory content", "sess_contract", type="semantic")
        _assert_response(resp)

    def test_search(self, client: Cerebe) -> None:
        resp = client.memory.search("test query", "sess_contract")
        _assert_response(resp)

    def test_session(self, client: Cerebe) -> None:
        resp = client.memory.session("sess_contract")
        _assert_response(resp)

    def test_relationships(self, client: Cerebe) -> None:
        resp = client.memory.relationships("mem_1", "mem_2", "related_to")
        _assert_response(resp)

    def test_query_tune(self, client: Cerebe) -> None:
        resp = client.memory.query_tune("sess_contract", "what do I know?")
        _assert_response(resp)

    def test_harvest(self, client: Cerebe) -> None:
        resp = client.memory.harvest(
            "sess_contract",
            [{"role": "user", "content": "hello"}],
        )
        _assert_response(resp)

    def test_consolidate(self, client: Cerebe) -> None:
        resp = client.memory.consolidate("entity_1", dry_run=True)
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Knowledge
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestKnowledgeContract:
    def test_ingest(self, client: Cerebe) -> None:
        resp = client.knowledge.ingest("Earth orbits the Sun", entity_id="ent_1")
        _assert_response(resp)

    def test_query(self, client: Cerebe) -> None:
        resp = client.knowledge.query("solar system")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism returns list, SDK expects dict envelope")
    def test_entities(self, client: Cerebe) -> None:
        resp = client.knowledge.entities(limit=5)
        _assert_response(resp)

    def test_visualize(self, client: Cerebe) -> None:
        resp = client.knowledge.visualize("solar system")
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestStorageContract:
    @pytest.mark.xfail(reason="Prism 422: multipart upload format mismatch")
    def test_upload(self, client: Cerebe) -> None:
        resp = client.storage.upload("dGVzdA==", "test.txt", "text/plain")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism 422: query param format mismatch")
    def test_check_hash(self, client: Cerebe) -> None:
        resp = client.storage.check_hash("abc123hash")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism 422: request body format mismatch")
    def test_extract(self, client: Cerebe) -> None:
        resp = client.storage.extract("https://example.com/doc.pdf")
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Graph
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestGraphContract:
    def test_traverse(self, client: Cerebe) -> None:
        resp = client.graph.traverse(entity_name="Earth", depth=1)
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism 422: temporal query param format mismatch")
    def test_temporal(self, client: Cerebe) -> None:
        resp = client.graph.temporal("entity_1", "2025-01-01")
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestSessionContract:
    def test_list(self, client: Cerebe) -> None:
        resp = client.sessions.list()
        _assert_response(resp)

    def test_get(self, client: Cerebe) -> None:
        resp = client.sessions.get("sess_contract")
        _assert_response(resp)

    def test_cleanup(self, client: Cerebe) -> None:
        resp = client.sessions.cleanup()
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Meta-learning
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestMetaLearningContract:
    def test_analyze(self, client: Cerebe) -> None:
        resp = client.meta_learning.analyze("user_1")
        _assert_response(resp)

    def test_profile(self, client: Cerebe) -> None:
        resp = client.meta_learning.profile("user_1")
        _assert_response(resp)

    def test_plre_state(self, client: Cerebe) -> None:
        resp = client.meta_learning.plre_state("user_1")
        _assert_response(resp)


# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestLLMContract:
    def test_chat(self, client: Cerebe) -> None:
        resp = client.llm.chat([{"role": "user", "content": "Hello"}])
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestAgentContract:
    def test_ingest_trace(self, client: Cerebe) -> None:
        resp = client.agents.ingest_trace("step1: searched docs", "sess_contract")
        _assert_response(resp)

    def test_set_working_memory(self, client: Cerebe) -> None:
        resp = client.agents.set_working_memory("current goal: learn math", "sess_contract")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism 422: query param format mismatch")
    def test_get_working_memory(self, client: Cerebe) -> None:
        resp = client.agents.get_working_memory("sess_contract")
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestPromptsContract:
    def test_list(self, client: Cerebe) -> None:
        resp = client.prompts.list()
        _assert_response(resp)

    def test_render(self, client: Cerebe) -> None:
        resp = client.prompts.render("greeting", {"name": "Alice"})
        _assert_response(resp)

    def test_change_requests_list(self, client: Cerebe) -> None:
        resp = client.prompts.change_requests.list()
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Prompt V2
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestPromptV2Contract:
    @pytest.mark.xfail(reason="Prism 422: enrich request body format mismatch")
    def test_enrich(self, client: Cerebe) -> None:
        resp = client.prompt_v2.enrich(
            "sess_contract",
            "Explain photosynthesis",
            {"subject": "biology", "grade": 5},
        )
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism returns None, SDK expects dict envelope")
    def test_health(self, client: Cerebe) -> None:
        resp = client.prompt_v2.health()
        _assert_response(resp)


# ---------------------------------------------------------------------------
# PLRE
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestPLREContract:
    @pytest.mark.xfail(reason="Route not in spec: PLRE patterns endpoint")
    def test_patterns(self, client: Cerebe) -> None:
        resp = client.plre.patterns("entity_1")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Route not in spec: PLRE store_event endpoint")
    def test_store_event(self, client: Cerebe) -> None:
        resp = client.plre.store_event(
            "entity_1",
            "quiz_completed",
            {"quiz_id": "q1"},
            {"score": 0.85, "time_spent": 120},
        )
        _assert_response(resp)

    @pytest.mark.xfail(reason="Route not in spec: PLRE gaps endpoint")
    def test_gaps(self, client: Cerebe) -> None:
        resp = client.plre.gaps(
            "entity_1",
            {"score": 0.7, "domain": "math"},
            [{"pattern": "declining", "domain": "math"}],
        )
        _assert_response(resp)


# ---------------------------------------------------------------------------
# Working Memory
# ---------------------------------------------------------------------------


@pytest.mark.contract
class TestWorkingMemoryContract:
    @pytest.mark.xfail(reason="Prism 405: wrong HTTP method for working memory store")
    def test_store(self, client: Cerebe) -> None:
        resp = client.working_memory.store("entity_1", "current task context")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Prism 422: query param format mismatch")
    def test_get(self, client: Cerebe) -> None:
        resp = client.working_memory.get("entity_1")
        _assert_response(resp)

    @pytest.mark.xfail(reason="Route not in spec: working memory sweep endpoint")
    def test_sweep(self, client: Cerebe) -> None:
        resp = client.working_memory.sweep()
        _assert_response(resp)
