"""Tests for storage resource extensions (get_content, upload_file)."""

from __future__ import annotations

import pytest

from cerebe import AsyncCerebe, Cerebe

# ── get_content ────────────────────────────────────────────────────


class TestStorageGetContent:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(content=b"file-bytes")
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        result = client.storage.get_content("upload_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/storage/upload_123/content"
        assert req.method == "GET"
        assert result == b"file-bytes"


@pytest.mark.anyio
class TestAsyncStorageGetContent:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(content=b"file-bytes")
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            result = await client.storage.get_content("upload_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/storage/upload_123/content"
        assert req.method == "GET"
        assert result == b"file-bytes"


# ── upload_file ────────────────────────────────────────────────────


class TestStorageUploadFile:
    def test_sends_multipart_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"upload_id": "up_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        client.storage.upload_file(b"hello", "test.txt", "text/plain", "sess_1", "user_1", tenant_id="t_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/storage/upload"
        assert req.method == "POST"
        assert req.headers["content-type"].startswith("multipart/form-data")

    def test_sends_with_required_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"upload_id": "up_2"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        client.storage.upload_file(b"data", "file.bin", "application/octet-stream", "sess_1", "user_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/storage/upload"


@pytest.mark.anyio
class TestAsyncStorageUploadFile:
    async def test_sends_multipart_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"upload_id": "up_1"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            await client.storage.upload_file(b"hello", "test.txt", "text/plain", "sess_1", "user_1", tenant_id="t_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/storage/upload"
        assert req.method == "POST"
        assert req.headers["content-type"].startswith("multipart/form-data")
