"""Tests for RagResource — sync client."""

from __future__ import annotations

import json

from cerebe import Cerebe


class TestRagSearch:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.search("how to deploy", k=10)

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/search"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["query"] == "how to deploy"
        assert data["k"] == 10

    def test_optional_fields_omitted_when_none(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.search("query")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert "doc_type" not in data
        assert "source_pattern" not in data

    def test_includes_optional_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.search("query", doc_type="markdown", source_pattern="docs/*")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["doc_type"] == "markdown"
        assert data["source_pattern"] == "docs/*"


class TestRagHybridSearch:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.hybrid_search("deployment guide", k=3, semantic_weight=0.8, keyword_weight=0.2)

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/search/hybrid"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["query"] == "deployment guide"
        assert data["k"] == 3
        assert data["semantic_weight"] == 0.8
        assert data["keyword_weight"] == 0.2

    def test_optional_doc_type_omitted_when_none(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.hybrid_search("query")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert "doc_type" not in data

    def test_includes_doc_type(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.hybrid_search("query", doc_type="code")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["doc_type"] == "code"


class TestRagFindSimilar:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.find_similar("def hello(): pass", k=3)

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/search/similar"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["content"] == "def hello(): pass"
        assert data["k"] == 3

    def test_optional_doc_type_omitted_when_none(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"results": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.find_similar("some content")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert "doc_type" not in data


class TestRagStats:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"total_chunks": 100}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.stats()

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/stats"
        assert req.method == "GET"


class TestRagEmbed:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.embed("docs/readme.md", "# Hello World", doc_type="markdown")

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/documents"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["source"] == "docs/readme.md"
        assert data["content"] == "# Hello World"
        assert data["doc_type"] == "markdown"

    def test_optional_metadata_omitted_when_none(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.embed("src/main.py", "print('hi')")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert "metadata" not in data

    def test_includes_metadata(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.embed("doc.md", "content", metadata={"author": "pj"})

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["metadata"] == {"author": "pj"}


class TestRagEmbedBatch:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        docs = [
            {"source": "a.md", "content": "alpha", "doc_type": "markdown"},
            {"source": "b.md", "content": "beta", "doc_type": "markdown"},
        ]
        client.rag.embed_batch(docs)

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/documents/batch"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["documents"] == docs


class TestRagListDocuments:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"documents": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.list_documents()

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/documents"
        assert req.method == "GET"


class TestRagDeleteDocument:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "deleted"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.delete_document("docs/readme.md")

        req = httpx_mock.get_request()
        # URL-encoded slash: raw URL contains %2F, httpx normalises .path
        assert "docs%2Freadme.md" in str(req.url.raw_path.decode())
        assert req.method == "DELETE"

    def test_simple_source_name(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "deleted"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.rag.delete_document("readme.md")

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/rag/documents/readme.md"
        assert req.method == "DELETE"
