"""RAG type definitions for the Cerebe SDK."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class RagSearchResult(BaseModel):
    source: str
    content: str
    score: float
    metadata: dict[str, Any] = Field(default_factory=dict)
    doc_type: str


class RagHybridSearchResult(RagSearchResult):
    semantic_score: float
    keyword_score: float


class RagEmbedResult(BaseModel):
    status: str
    source: str
    chunks_created: int
    doc_type: str


class RagBatchEmbedResult(BaseModel):
    status: str
    documents_processed: int
    total_chunks_created: int
    results: list[RagEmbedResult]


class RagDocument(BaseModel):
    source: str
    doc_type: str
    chunk_count: int
    last_updated: str | None = None


class RagStats(BaseModel):
    total_chunks: int
    unique_sources: int
    document_types: dict[str, int]
    embedding_model: str
    chunk_size: int
    chunk_overlap: int
