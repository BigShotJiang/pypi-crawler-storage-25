"""Working memory resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class WorkingMemoryResource:
    """Sync working memory operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def store(
        self,
        entity_id: str,
        content: str,
        *,
        ttl_seconds: int | None = None,
        scope: dict[str, Any] | None = None,
        importance: float | None = None,
    ) -> APIResponse[Any]:
        """Store content in working memory."""
        body: dict[str, Any] = {
            "entity_id": entity_id,
            "content": content,
        }
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        if scope is not None:
            body["scope"] = scope
        if importance is not None:
            body["importance"] = importance
        return self._client.request("POST", "/api/v1/memory/working", json=body)

    def get(self, entity_id: str) -> APIResponse[Any]:
        """Retrieve working memory for an entity."""
        return self._client.request("GET", "/api/v1/memory/working", params={"entity_id": entity_id})

    def sweep(self) -> APIResponse[Any]:
        """Sweep expired working memory entries."""
        return self._client.request("POST", "/api/v1/memory/working/sweep")


class AsyncWorkingMemoryResource:
    """Async working memory operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def store(
        self,
        entity_id: str,
        content: str,
        *,
        ttl_seconds: int | None = None,
        scope: dict[str, Any] | None = None,
        importance: float | None = None,
    ) -> APIResponse[Any]:
        """Store content in working memory."""
        body: dict[str, Any] = {
            "entity_id": entity_id,
            "content": content,
        }
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        if scope is not None:
            body["scope"] = scope
        if importance is not None:
            body["importance"] = importance
        return await self._client.request("POST", "/api/v1/memory/working", json=body)

    async def get(self, entity_id: str) -> APIResponse[Any]:
        """Retrieve working memory for an entity."""
        return await self._client.request("GET", "/api/v1/memory/working", params={"entity_id": entity_id})

    async def sweep(self) -> APIResponse[Any]:
        """Sweep expired working memory entries."""
        return await self._client.request("POST", "/api/v1/memory/working/sweep")
