"""PLRE (Personalized Learning & Retrieval Engine) resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class PLREResource:
    """Sync PLRE operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def patterns(
        self,
        entity_id: str,
        *,
        lookback_days: int | None = None,
    ) -> APIResponse[Any]:
        """Retrieve learning patterns for an entity."""
        body: dict[str, Any] = {"entity_id": entity_id}
        if lookback_days is not None:
            body["lookback_days"] = lookback_days
        return self._client.request("POST", "/api/v1/plre/patterns", json=body)

    def store_event(
        self,
        entity_id: str,
        event_type: str,
        content: Any,
        assessment: dict[str, Any],
        *,
        trace_id: str | None = None,
    ) -> APIResponse[Any]:
        """Store a learning event."""
        body: dict[str, Any] = {
            "entity_id": entity_id,
            "event_type": event_type,
            "content": content,
            "assessment": assessment,
        }
        if trace_id:
            body["trace_id"] = trace_id
        return self._client.request("POST", "/api/v1/plre/events", json=body)

    def gaps(
        self,
        entity_id: str,
        current_assessment: dict[str, Any],
        historical_patterns: list[dict[str, Any]],
    ) -> APIResponse[Any]:
        """Identify learning gaps from assessment and historical patterns."""
        return self._client.request(
            "POST",
            "/api/v1/plre/gaps",
            json={
                "entity_id": entity_id,
                "current_assessment": current_assessment,
                "historical_patterns": historical_patterns,
            },
        )


class AsyncPLREResource:
    """Async PLRE operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def patterns(
        self,
        entity_id: str,
        *,
        lookback_days: int | None = None,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Retrieve learning patterns for an entity."""
        body: dict[str, Any] = {"entity_id": entity_id}
        if lookback_days is not None:
            body["lookback_days"] = lookback_days
        return await self._client.request(
            "POST",
            "/api/v1/plre/patterns",
            json=body,
            timeout=timeout,
        )

    async def store_event(
        self,
        entity_id: str,
        event_type: str,
        content: Any,
        assessment: dict[str, Any],
        *,
        trace_id: str | None = None,
    ) -> APIResponse[Any]:
        """Store a learning event."""
        body: dict[str, Any] = {
            "entity_id": entity_id,
            "event_type": event_type,
            "content": content,
            "assessment": assessment,
        }
        if trace_id:
            body["trace_id"] = trace_id
        return await self._client.request("POST", "/api/v1/plre/events", json=body)

    async def gaps(
        self,
        entity_id: str,
        current_assessment: dict[str, Any],
        historical_patterns: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Identify learning gaps from assessment and historical patterns."""
        return await self._client.request(
            "POST",
            "/api/v1/plre/gaps",
            json={
                "entity_id": entity_id,
                "current_assessment": current_assessment,
                "historical_patterns": historical_patterns,
            },
            timeout=timeout,
        )
