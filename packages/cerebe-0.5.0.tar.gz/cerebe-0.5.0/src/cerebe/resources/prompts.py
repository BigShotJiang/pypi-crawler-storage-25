"""Prompt and prompt change request resources for the Cerebe SDK."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


# ── Change Request sub-resources ───────────────────────────────────


class PromptChangeRequestResource:
    """Sync prompt change request operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def list(
        self,
        *,
        status: str | None = None,
        prompt_name: str | None = None,
        environment: str | None = None,
    ) -> APIResponse[Any]:
        """List prompt change requests."""
        params: dict[str, str] = {}
        if status:
            params["status"] = status
        if prompt_name:
            params["prompt_name"] = prompt_name
        if environment:
            params["environment"] = environment
        return self._client.request("GET", "/api/v1/prompt-change-requests/", params=params or None)

    def create(
        self,
        prompt_name: str,
        system_prompt: str,
        user_prompt: str,
        version: str,
        *,
        environment: str | None = None,
        actor: str | None = None,
        metadata: dict[str, Any] | None = None,
        placeholders: Sequence[str] | None = None,
        dataset_path: str | None = None,
    ) -> APIResponse[Any]:
        """Create a prompt change request."""
        body: dict[str, Any] = {
            "prompt_name": prompt_name,
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
            "version": version,
        }
        if environment:
            body["environment"] = environment
        if actor:
            body["actor"] = actor
        if metadata:
            body["metadata"] = metadata
        if placeholders:
            body["placeholders"] = placeholders
        if dataset_path:
            body["dataset_path"] = dataset_path
        return self._client.request("POST", "/api/v1/prompt-change-requests/", json=body)

    def get(self, request_id: str) -> APIResponse[Any]:
        """Get a prompt change request by ID."""
        return self._client.request("GET", f"/api/v1/prompt-change-requests/{request_id}")

    def submit(
        self,
        request_id: str,
        *,
        actor: str | None = None,
        assigned_reviewer: str | None = None,
        auto_evaluate: bool | None = None,
    ) -> APIResponse[Any]:
        """Submit a prompt change request for review."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        if assigned_reviewer:
            body["assigned_reviewer"] = assigned_reviewer
        if auto_evaluate is not None:
            body["auto_evaluate"] = auto_evaluate
        return self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/submit",
            json=body or None,
        )

    def evaluate(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Evaluate a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/evaluate",
            json=body or None,
        )

    def approve(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Approve a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/approve",
            json=body or None,
        )

    def reject(
        self,
        request_id: str,
        *,
        actor: str | None = None,
        notes: str | None = None,
    ) -> APIResponse[Any]:
        """Reject a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        if notes:
            body["notes"] = notes
        return self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/reject",
            json=body or None,
        )

    def cancel(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Cancel a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/cancel",
            json=body or None,
        )


class AsyncPromptChangeRequestResource:
    """Async prompt change request operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def list(
        self,
        *,
        status: str | None = None,
        prompt_name: str | None = None,
        environment: str | None = None,
    ) -> APIResponse[Any]:
        """List prompt change requests."""
        params: dict[str, str] = {}
        if status:
            params["status"] = status
        if prompt_name:
            params["prompt_name"] = prompt_name
        if environment:
            params["environment"] = environment
        return await self._client.request("GET", "/api/v1/prompt-change-requests/", params=params or None)

    async def create(
        self,
        prompt_name: str,
        system_prompt: str,
        user_prompt: str,
        version: str,
        *,
        environment: str | None = None,
        actor: str | None = None,
        metadata: dict[str, Any] | None = None,
        placeholders: Sequence[str] | None = None,
        dataset_path: str | None = None,
    ) -> APIResponse[Any]:
        """Create a prompt change request."""
        body: dict[str, Any] = {
            "prompt_name": prompt_name,
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
            "version": version,
        }
        if environment:
            body["environment"] = environment
        if actor:
            body["actor"] = actor
        if metadata:
            body["metadata"] = metadata
        if placeholders:
            body["placeholders"] = placeholders
        if dataset_path:
            body["dataset_path"] = dataset_path
        return await self._client.request("POST", "/api/v1/prompt-change-requests/", json=body)

    async def get(self, request_id: str) -> APIResponse[Any]:
        """Get a prompt change request by ID."""
        return await self._client.request("GET", f"/api/v1/prompt-change-requests/{request_id}")

    async def submit(
        self,
        request_id: str,
        *,
        actor: str | None = None,
        assigned_reviewer: str | None = None,
        auto_evaluate: bool | None = None,
    ) -> APIResponse[Any]:
        """Submit a prompt change request for review."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        if assigned_reviewer:
            body["assigned_reviewer"] = assigned_reviewer
        if auto_evaluate is not None:
            body["auto_evaluate"] = auto_evaluate
        return await self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/submit",
            json=body or None,
        )

    async def evaluate(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Evaluate a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return await self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/evaluate",
            json=body or None,
        )

    async def approve(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Approve a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return await self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/approve",
            json=body or None,
        )

    async def reject(
        self,
        request_id: str,
        *,
        actor: str | None = None,
        notes: str | None = None,
    ) -> APIResponse[Any]:
        """Reject a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        if notes:
            body["notes"] = notes
        return await self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/reject",
            json=body or None,
        )

    async def cancel(self, request_id: str, *, actor: str | None = None) -> APIResponse[Any]:
        """Cancel a prompt change request."""
        body: dict[str, Any] = {}
        if actor:
            body["actor"] = actor
        return await self._client.request(
            "POST",
            f"/api/v1/prompt-change-requests/{request_id}/cancel",
            json=body or None,
        )


# ── Prompt resources ───────────────────────────────────────────────


class PromptResource:
    """Sync prompt operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client
        self.change_requests = PromptChangeRequestResource(client)

    def list(self, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """List all prompts."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return self._client.request("GET", "/api/v1/prompts/", params=params or None)

    def get(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """Get a prompt by name."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return self._client.request("GET", f"/api/v1/prompts/{name}", params=params or None)

    def render(
        self,
        name: str,
        variables: dict[str, Any],
        *,
        version: str | None = None,
        tags: Sequence[str] | None = None,
        evaluate: bool | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Render a prompt with variables."""
        body: dict[str, Any] = {"variables": variables}
        if version:
            body["version"] = version
        if tags:
            body["tags"] = tags
        if evaluate is not None:
            body["evaluate"] = evaluate
        if actor:
            body["actor"] = actor
        return self._client.request("POST", f"/api/v1/prompts/{name}/render", json=body)

    def evaluate(
        self,
        name: str,
        *,
        version: str | None = None,
        dataset_path: str | None = None,
    ) -> APIResponse[Any]:
        """Evaluate a prompt."""
        body: dict[str, Any] = {}
        if version:
            body["version"] = version
        if dataset_path:
            body["dataset_path"] = dataset_path
        return self._client.request("POST", f"/api/v1/prompts/{name}/evaluate", json=body or None)

    def delete(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """Delete a prompt."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return self._client.request("DELETE", f"/api/v1/prompts/{name}", params=params or None)

    def create_version(
        self,
        name: str,
        *,
        system_prompt: str | None = None,
        user_prompt: str | None = None,
        version: str | None = None,
        tags: Sequence[str] | None = None,
        metadata: dict[str, Any] | None = None,
        placeholders: Sequence[str] | None = None,
        status: str | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Create a new version of a prompt."""
        body: dict[str, Any] = {}
        if system_prompt:
            body["system_prompt"] = system_prompt
        if user_prompt:
            body["user_prompt"] = user_prompt
        if version:
            body["version"] = version
        if tags:
            body["tags"] = tags
        if metadata:
            body["metadata"] = metadata
        if placeholders:
            body["placeholders"] = placeholders
        if status:
            body["status"] = status
        if actor:
            body["actor"] = actor
        return self._client.request("POST", f"/api/v1/prompts/{name}/versions", json=body or None)

    def list_versions(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """List all versions of a prompt."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return self._client.request("GET", f"/api/v1/prompts/{name}/versions", params=params or None)

    def promote(
        self,
        name: str,
        *,
        version: str,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Promote a prompt version."""
        body: dict[str, Any] = {"version": version}
        if actor:
            body["actor"] = actor
        return self._client.request("POST", f"/api/v1/prompts/{name}/promote", json=body)

    def update_metadata(
        self,
        name: str,
        version: str,
        *,
        metadata: dict[str, Any] | None = None,
        status: str | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Update metadata for a prompt version."""
        body: dict[str, Any] = {}
        if metadata:
            body["metadata"] = metadata
        if status:
            body["status"] = status
        if actor:
            body["actor"] = actor
        return self._client.request(
            "PATCH",
            f"/api/v1/prompts/{name}/versions/{version}",
            json=body or None,
        )

    def bulk_upsert(self, prompts: Sequence[dict[str, Any]]) -> APIResponse[Any]:
        """Bulk upsert prompts."""
        return self._client.request(
            "POST",
            "/api/v1/prompts/bulk-upsert",
            json=prompts,  # type: ignore[arg-type]
        )


class AsyncPromptResource:
    """Async prompt operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client
        self.change_requests = AsyncPromptChangeRequestResource(client)

    async def list(self, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """List all prompts."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return await self._client.request("GET", "/api/v1/prompts/", params=params or None)

    async def get(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """Get a prompt by name."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return await self._client.request("GET", f"/api/v1/prompts/{name}", params=params or None)

    async def render(
        self,
        name: str,
        variables: dict[str, Any],
        *,
        version: str | None = None,
        tags: Sequence[str] | None = None,
        evaluate: bool | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Render a prompt with variables."""
        body: dict[str, Any] = {"variables": variables}
        if version:
            body["version"] = version
        if tags:
            body["tags"] = tags
        if evaluate is not None:
            body["evaluate"] = evaluate
        if actor:
            body["actor"] = actor
        return await self._client.request("POST", f"/api/v1/prompts/{name}/render", json=body)

    async def evaluate(
        self,
        name: str,
        *,
        version: str | None = None,
        dataset_path: str | None = None,
    ) -> APIResponse[Any]:
        """Evaluate a prompt."""
        body: dict[str, Any] = {}
        if version:
            body["version"] = version
        if dataset_path:
            body["dataset_path"] = dataset_path
        return await self._client.request("POST", f"/api/v1/prompts/{name}/evaluate", json=body or None)

    async def delete(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """Delete a prompt."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return await self._client.request("DELETE", f"/api/v1/prompts/{name}", params=params or None)

    async def create_version(
        self,
        name: str,
        *,
        system_prompt: str | None = None,
        user_prompt: str | None = None,
        version: str | None = None,
        tags: Sequence[str] | None = None,
        metadata: dict[str, Any] | None = None,
        placeholders: Sequence[str] | None = None,
        status: str | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Create a new version of a prompt."""
        body: dict[str, Any] = {}
        if system_prompt:
            body["system_prompt"] = system_prompt
        if user_prompt:
            body["user_prompt"] = user_prompt
        if version:
            body["version"] = version
        if tags:
            body["tags"] = tags
        if metadata:
            body["metadata"] = metadata
        if placeholders:
            body["placeholders"] = placeholders
        if status:
            body["status"] = status
        if actor:
            body["actor"] = actor
        return await self._client.request("POST", f"/api/v1/prompts/{name}/versions", json=body or None)

    async def list_versions(self, name: str, *, tags: Sequence[str] | None = None) -> APIResponse[Any]:
        """List all versions of a prompt."""
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return await self._client.request("GET", f"/api/v1/prompts/{name}/versions", params=params or None)

    async def promote(
        self,
        name: str,
        *,
        version: str,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Promote a prompt version."""
        body: dict[str, Any] = {"version": version}
        if actor:
            body["actor"] = actor
        return await self._client.request("POST", f"/api/v1/prompts/{name}/promote", json=body)

    async def update_metadata(
        self,
        name: str,
        version: str,
        *,
        metadata: dict[str, Any] | None = None,
        status: str | None = None,
        actor: str | None = None,
    ) -> APIResponse[Any]:
        """Update metadata for a prompt version."""
        body: dict[str, Any] = {}
        if metadata:
            body["metadata"] = metadata
        if status:
            body["status"] = status
        if actor:
            body["actor"] = actor
        return await self._client.request(
            "PATCH",
            f"/api/v1/prompts/{name}/versions/{version}",
            json=body or None,
        )

    async def bulk_upsert(self, prompts: Sequence[dict[str, Any]]) -> APIResponse[Any]:
        """Bulk upsert prompts."""
        return await self._client.request(
            "POST",
            "/api/v1/prompts/bulk-upsert",
            json=prompts,  # type: ignore[arg-type]
        )
