"""RAG resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class RagResource:
    """Sync RAG operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def search(
        self,
        query: str,
        *,
        k: int = 5,
        doc_type: str | None = None,
        source_pattern: str | None = None,
    ) -> APIResponse[Any]:
        """Search documents by semantic similarity."""
        body: dict[str, Any] = {
            "query": query,
            "k": k,
        }
        if doc_type:
            body["doc_type"] = doc_type
        if source_pattern:
            body["source_pattern"] = source_pattern
        return self._client.request("POST", "/api/v1/rag/search", json=body)

    def hybrid_search(
        self,
        query: str,
        *,
        k: int = 5,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3,
        doc_type: str | None = None,
    ) -> APIResponse[Any]:
        """Search documents using hybrid semantic + keyword matching."""
        body: dict[str, Any] = {
            "query": query,
            "k": k,
            "semantic_weight": semantic_weight,
            "keyword_weight": keyword_weight,
        }
        if doc_type:
            body["doc_type"] = doc_type
        return self._client.request("POST", "/api/v1/rag/search/hybrid", json=body)

    def find_similar(
        self,
        content: str,
        *,
        k: int = 5,
        doc_type: str | None = None,
    ) -> APIResponse[Any]:
        """Find documents similar to the given content."""
        body: dict[str, Any] = {
            "content": content,
            "k": k,
        }
        if doc_type:
            body["doc_type"] = doc_type
        return self._client.request("POST", "/api/v1/rag/search/similar", json=body)

    def stats(self) -> APIResponse[Any]:
        """Get RAG index statistics."""
        return self._client.request("GET", "/api/v1/rag/stats")

    def embed(
        self,
        source: str,
        content: str,
        *,
        doc_type: str = "markdown",
        metadata: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Embed a document into the RAG index."""
        body: dict[str, Any] = {
            "source": source,
            "content": content,
            "doc_type": doc_type,
        }
        if metadata:
            body["metadata"] = metadata
        return self._client.request("POST", "/api/v1/rag/documents", json=body)

    def embed_batch(
        self,
        documents: list[dict[str, Any]],
    ) -> APIResponse[Any]:
        """Embed multiple documents into the RAG index."""
        body: dict[str, Any] = {"documents": documents}
        return self._client.request("POST", "/api/v1/rag/documents/batch", json=body)

    def list_documents(self) -> APIResponse[Any]:
        """List all documents in the RAG index."""
        return self._client.request("GET", "/api/v1/rag/documents")

    def delete_document(self, source: str) -> APIResponse[Any]:
        """Delete a document from the RAG index by source."""
        encoded = quote(source, safe="")
        return self._client.request("DELETE", f"/api/v1/rag/documents/{encoded}")


class AsyncRagResource:
    """Async RAG operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def search(
        self,
        query: str,
        *,
        k: int = 5,
        doc_type: str | None = None,
        source_pattern: str | None = None,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Search documents by semantic similarity."""
        body: dict[str, Any] = {
            "query": query,
            "k": k,
        }
        if doc_type:
            body["doc_type"] = doc_type
        if source_pattern:
            body["source_pattern"] = source_pattern
        return await self._client.request("POST", "/api/v1/rag/search", json=body, timeout=timeout)

    async def hybrid_search(
        self,
        query: str,
        *,
        k: int = 5,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3,
        doc_type: str | None = None,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Search documents using hybrid semantic + keyword matching."""
        body: dict[str, Any] = {
            "query": query,
            "k": k,
            "semantic_weight": semantic_weight,
            "keyword_weight": keyword_weight,
        }
        if doc_type:
            body["doc_type"] = doc_type
        return await self._client.request("POST", "/api/v1/rag/search/hybrid", json=body, timeout=timeout)

    async def find_similar(
        self,
        content: str,
        *,
        k: int = 5,
        doc_type: str | None = None,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Find documents similar to the given content."""
        body: dict[str, Any] = {
            "content": content,
            "k": k,
        }
        if doc_type:
            body["doc_type"] = doc_type
        return await self._client.request("POST", "/api/v1/rag/search/similar", json=body, timeout=timeout)

    async def stats(self, *, timeout: float | None = None) -> APIResponse[Any]:
        """Get RAG index statistics."""
        return await self._client.request("GET", "/api/v1/rag/stats", timeout=timeout)

    async def embed(
        self,
        source: str,
        content: str,
        *,
        doc_type: str = "markdown",
        metadata: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Embed a document into the RAG index."""
        body: dict[str, Any] = {
            "source": source,
            "content": content,
            "doc_type": doc_type,
        }
        if metadata:
            body["metadata"] = metadata
        return await self._client.request("POST", "/api/v1/rag/documents", json=body, timeout=timeout)

    async def embed_batch(
        self,
        documents: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> APIResponse[Any]:
        """Embed multiple documents into the RAG index."""
        body: dict[str, Any] = {"documents": documents}
        return await self._client.request("POST", "/api/v1/rag/documents/batch", json=body, timeout=timeout)

    async def list_documents(self, *, timeout: float | None = None) -> APIResponse[Any]:
        """List all documents in the RAG index."""
        return await self._client.request("GET", "/api/v1/rag/documents", timeout=timeout)

    async def delete_document(self, source: str, *, timeout: float | None = None) -> APIResponse[Any]:
        """Delete a document from the RAG index by source."""
        encoded = quote(source, safe="")
        return await self._client.request("DELETE", f"/api/v1/rag/documents/{encoded}", timeout=timeout)
