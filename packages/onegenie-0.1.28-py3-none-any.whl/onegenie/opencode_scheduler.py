import subprocess
import os
import json
import asyncio
import httpx
import socket
import logging
from opencode_ai import Opencode


class OpenCodeScheduler:
    def __init__(self, port_range=range(4096, 4200)):
        self.port_range = port_range
        self.active_instances = {}  # chat_id -> {process, port, url}

    def _is_port_in_use(self, port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(("127.0.0.1", port)) == 0

    async def get_runtime_url(self, chat_id):
        # 1. 檢查是否已有實例正在運行
        if chat_id in self.active_instances:
            url = self.active_instances[chat_id]["url"]
            occlient = Opencode(base_url=url)
            sessions = occlient.session.list()
            session_id = getattr(sessions[0], "id", None)
            return url, session_id

        # 2. 尋找可用埠號
        try:
            port = next(p for p in self.port_range if not self._is_port_in_use(p))
        except StopIteration:
            raise RuntimeError("錯誤：定義的範圍內已無可用埠號。")

        # 3. 準備工作目錄 (使用絕對路徑)
        work_dir = os.path.abspath(f"/tmp/chat-{chat_id}")
        os.makedirs(work_dir, exist_ok=True)

        # 4. 生成該 Session 專屬的安全設定檔 (config.json)
        config_path = os.path.join(work_dir, "config.json")
        config_content = {
            "$schema": "https://opencode.ai/config.json",
            "autoupdate": False,
            "permission": {
                "question": "deny",
                "read": {"*": "deny", f"{work_dir}/**": "allow"},
                "external_directory": {"*": "deny", f"{work_dir}/**": "allow"},
                "edit": {"*": "deny", f"{work_dir}/**": "allow"},
            },
        }

        with open(config_path, "w") as f:
            json.dump(config_content, f, indent=2)

        # 5. 準備環境變數並啟動實例
        # 繼承目前的環境變數，並加入 OPENCODE_CONFIG 指向剛生成的檔案
        # XDG_DATA_HOME 設為 chat 專屬目錄，確保 session 資料不跨 chat 共享
        env = os.environ.copy()
        env["OPENCODE_CONFIG"] = config_path
        env["XDG_DATA_HOME"] = os.path.join(work_dir, ".local", "share")

        process = subprocess.Popen(
            ["opencode", "serve", "--port", str(port)],
            cwd=work_dir,
            env=env,  # 🚀 注入環境變數
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        url = f"http://127.0.0.1:{port}"

        # 6. 健康檢查：等待伺服器啟動完成
        async with httpx.AsyncClient() as client:
            for i in range(20):  # 最多等待 10 秒
                try:
                    resp = await client.get(f"{url}/global/health", timeout=1.0)
                    if resp.status_code == 200:
                        logging.info(
                            f"🚀 OpenCodeScheduler: 已啟動實例 {chat_id} 於 {url}"
                        )
                        break
                except (httpx.ConnectError, httpx.TimeoutException):
                    await asyncio.sleep(0.5)
            else:
                process.terminate()
                raise RuntimeError(f"無法在埠號 {port} 啟動 opencode serve")

        self.active_instances[chat_id] = {"process": process, "port": port, "url": url}

        occlient = Opencode(base_url=url)

        sessions = occlient.session.list()
        if len(sessions) > 0:
            session_id = getattr(sessions[0], "id", None)
            return url, session_id
        else:
            session_title = f"chat-{chat_id}"
            new_session = occlient.session.create(extra_body={"title": session_title})
            session_id = new_session.id
            return url, session_id

    def stop_instance(self, chat_id):
        """關閉實例並釋放資源"""
        if chat_id in self.active_instances:
            info = self.active_instances[chat_id]
            info["process"].terminate()
            logging.info(
                f"OpenCodeScheduler: 已關閉 Chat {chat_id} (Port: {info['port']})"
            )
            del self.active_instances[chat_id]
