import os
import httpx
from contextlib import AsyncExitStack
from typing import Optional

from .opencode_scheduler import OpenCodeScheduler
from .opencode_runtime import OpenCodeRuntime

mpg_url = os.environ["ASKGENIE_ENDPOINT"].replace("/api/v1", "/mpg/v1")


class OpenCodeAgent:
    """
    管理 OpenCode 生命週期 + 聊天入口。
    類似 MCPAgent 模式：daemon 注入 Context，agent handler 呼叫 chat_stream() 即可。
    """

    # 全域共用 scheduler (避免 port 衝突)
    _shared: Optional[OpenCodeScheduler] = None

    def __init__(self, chat_id: str, mpg_token: str):
        self.chat_id = chat_id
        self.mpg_token = mpg_token
        self.exit_stack = AsyncExitStack()
        self.scheduler = OpenCodeAgent._shared
        if self.scheduler is None:
            OpenCodeAgent._shared = self.scheduler = OpenCodeScheduler()
        # _base_url / _session_id 在首次 chat_stream() 時建立
        self._base_url: Optional[str] = None
        self._session_id: Optional[str] = None

    def setup_folder(self) -> str:
        path = f"/tmp/chat-{self.chat_id}"
        os.makedirs(path, exist_ok=True)
        return path

    async def _ensure_connected(self) -> None:
        """第一次聊天時自動建立 opencode instance + session"""
        if self._base_url is None:
            url, session_id = await self.scheduler.get_runtime_url(self.chat_id)
            self._base_url = url
            self._session_id = session_id

    async def patch_config(self, config) -> None:
        async with httpx.AsyncClient() as client:
            await client.patch(f"{self._base_url}/config", json=config)

    async def chat_stream(self, prompt: str, model: str, extra_config=None):
        """流式聊天入口 — 自動 connect session、yield 結果、結束時 cleanup

        Yield format:
          {"step": "Thinking ..."}   # 進入思考
          {"step": "tool_name"}      # 工具呼叫中
          "text chunk"               # 最終輸出
          {"step": "error", "chunk": "msg"}
        """
        await self._ensure_connected()

        provider_timeout = int(os.getenv("OPENCODE_PROVIDER_TIMEOUT", "300000"))
        provider_chunk_timeout = int(os.getenv("OPENCODE_PROVIDER_CHUNK_TIMEOUT", "300000"))

        config_patch = {
            "provider": {
                "mpg": {
                    "npm": "@ai-sdk/openai-compatible",
                    "options": {
                        "baseURL": mpg_url,
                        "headers": {
                            "Authorization": f"Bearer {self.mpg_token}",
                        },
                        "timeout": provider_timeout,
                        "chunkTimeout": provider_chunk_timeout,
                    },
                    "models": {
                        model: {"name": model},
                    },
                }
            }
        }
        # to test: cd /tmp/chat-xxxxxx ; OPENCODE_CONFIG=$(pwd)/config.json opencode
        await self.patch_config(config_patch)

        if extra_config is not None:
            await self.patch_config(extra_config)

        runtime = OpenCodeRuntime(base_url=self._base_url)
        in_thinking = False

        async for item in runtime.chat_stream(
            session_id=self._session_id,
            prompt=prompt,
            provider_id="mpg",
            model_id=model,
        ):
            step = item.get("step")
            chunk = item.get("chunk", "")

            if step == "thinking":
                if not in_thinking:
                    yield {"step": "Thinking ..."}
                    in_thinking = True
                continue

            in_thinking = False

            if step == "tool_calling":
                yield {"step": item.get("tool")}
            elif step in ("output", "error") and chunk:
                yield chunk

    async def stop(self):
        await self.exit_stack.aclose()
