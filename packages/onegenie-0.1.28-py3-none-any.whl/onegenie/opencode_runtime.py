import asyncio
import os
import threading
import logging
from typing import AsyncGenerator
import httpx
from opencode_ai import Opencode


class OpenCodeRuntime:
    def __init__(self, base_url: str):
        timeout_seconds = int(os.getenv("OPENCODE_TIMEOUT", "1800"))
        self.client = Opencode(
            base_url=base_url,
            timeout=httpx.Timeout(timeout=timeout_seconds, connect=5.0),
            max_retries=0,
        )
        self.active_queues: dict[str, asyncio.Queue] = {}
        self._listener_lock = threading.Lock()
        self._listener_thread = None
        self._part_types: dict[str, str] = {}
        self._reported_tools: set[str] = set()

    def _listener_worker(self, loop: asyncio.AbstractEventLoop):
        try:
            stream = self.client.event.list()
            for event in stream:
                if event.type == "message.part.updated":
                    props = getattr(event, "properties", None)
                    if props:
                        session_id = getattr(props, "sessionID", None)
                        part = getattr(props, "part", None)
                        if part:
                            part_id = getattr(part, "id", None)
                            part_type = getattr(part, "type", None)
                            if part_id and part_type:
                                self._part_types[part_id] = part_type

                                if (
                                    part_type == "tool"
                                    and part_id not in self._reported_tools
                                ):
                                    state = getattr(part, "state", None)
                                    status = (
                                        getattr(state, "status", "") if state else ""
                                    )
                                    if status == "running":
                                        description = "unknown_tool"
                                        if (
                                            state
                                            and hasattr(state, "metadata")
                                            and isinstance(state.metadata, dict)
                                        ):
                                            description = state.metadata.get(
                                                "description", description
                                            )
                                        if description == "unknown_tool":
                                            tool_name = getattr(
                                                part, "tool", "unknown_tool"
                                            )
                                            if tool_name == "skill":
                                                skill_name = getattr(
                                                    state, "input", {}
                                                ).get("name", "unknown")
                                                description = (
                                                    f"Using skill: {skill_name.title()}"
                                                )
                                            else:
                                                description = (
                                                    f"Using tool: {tool_name.title()}"
                                                )

                                        msg = {
                                            "step": "tool_calling",
                                            "tool": description,
                                        }
                                        self._reported_tools.add(part_id)
                                        if session_id in self.active_queues:
                                            queue = self.active_queues[session_id]
                                            loop.call_soon_threadsafe(
                                                queue.put_nowait, msg
                                            )

                elif event.type == "message.part.delta":
                    props = getattr(event, "properties", None)
                    if props:
                        session_id = getattr(props, "sessionID", None)
                        part_id = getattr(props, "partID", None)
                        delta = getattr(props, "delta", None)
                        if delta is not None and session_id in self.active_queues:
                            p_type = self._part_types.get(part_id, "text")
                            if p_type == "reasoning":
                                msg = {"step": "thinking", "chunk": delta}
                            else:
                                msg = {"step": "output", "chunk": delta}

                            queue = self.active_queues[session_id]
                            loop.call_soon_threadsafe(queue.put_nowait, msg)

        except Exception as e:
            logging.error(f"Listener worker encountered error: {e}")

    async def _ensure_listener_running(self):
        loop = asyncio.get_running_loop()

        def start_thread():
            with self._listener_lock:
                if self._listener_thread is None:
                    self._listener_thread = threading.Thread(
                        target=self._listener_worker, args=(loop,), daemon=True
                    )
                    self._listener_thread.start()

        await asyncio.to_thread(start_thread)

    async def chat_stream(
        self, session_id: str, prompt: str, model_id: str, provider_id: str
    ) -> AsyncGenerator[dict, None]:
        queue = asyncio.Queue()
        self.active_queues[session_id] = queue

        try:
            await self._ensure_listener_running()

            async def send_request():
                try:
                    await asyncio.to_thread(
                        self.client.session.chat,
                        session_id,
                        parts=[{"type": "text", "text": prompt}],
                        model_id=model_id,
                        provider_id=provider_id,
                        extra_body={
                            "model": {
                                "modelID": model_id,
                                "providerID": provider_id,
                            }
                        },
                    )
                except Exception as e:
                    error_msg = {"step": "error", "chunk": str(e)}
                    if session_id in self.active_queues:
                        await self.active_queues[session_id].put(error_msg)
                finally:
                    # Safety fallback: ensure the stream closes even if completion event is missed
                    await asyncio.sleep(0.5)
                    if session_id in self.active_queues:
                        await self.active_queues[session_id].put(None)

            _task = asyncio.create_task(send_request())

            while True:
                chunk = await queue.get()
                if chunk is None:
                    break
                yield chunk

        finally:
            if session_id in self.active_queues:
                del self.active_queues[session_id]
