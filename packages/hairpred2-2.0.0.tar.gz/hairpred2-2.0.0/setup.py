from setuptools import setup, find_packages
import os

# Read long description from README
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    # ── Package identity ──────────────────────────────────────────────────────
    name             = "hairpred2",
    version          = "1.0.0",
    description      = "Structure-based prediction of antibody-interacting residues in human antigens",
    long_description = long_description,
    long_description_content_type = "text/markdown",

    # ── Author ────────────────────────────────────────────────────────────────
    author       = "Naman Mehta, Raghava Lab",
    author_email = "raghava@iiitd.ac.in",
    url          = "https://webs.iiitd.edu.in/raghava/hairpred2",

    # ── License & classifiers ─────────────────────────────────────────────────
    license = "MIT",
    classifiers = [
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    keywords = "antibody epitope prediction structure bioinformatics immunoinformatics",

    # ── Package discovery ─────────────────────────────────────────────────────
    packages         = find_packages(),
    python_requires  = ">=3.8",

    # ── Include non-Python files (model, data) ────────────────────────────────
    package_data = {
        "hairpred2": [
            "data/*.pkl",     # model file (if bundled)
            "data/*.txt",     # readme
        ],
    },
    include_package_data = True,

    # ── Dependencies ──────────────────────────────────────────────────────────
    install_requires = [
        "numpy>=1.21",
        "pandas>=1.3",
        "joblib>=1.0",
        "gemmi>=0.5",
        "biopython>=1.79",
        "scipy>=1.7",
    ],

    # ── Command-line entry point ──────────────────────────────────────────────
    entry_points = {
        "console_scripts": [
            "hairpred2 = hairpred2.cli:main",
        ],
    },

    # ── Project URLs ──────────────────────────────────────────────────────────
    project_urls = {
        "Web Server"   : "https://webs.iiitd.edu.in/raghava/hairpred2",
        "Bug Reports"  : "https://github.com/raghavagps/hairpred2/issues",
        "Source"       : "https://github.com/raghavagps/hairpred2",
        "Lab Website"  : "https://webs.iiitd.edu.in/raghava/",
    },
)
