"""
HAIRpred2 — Core prediction module.

This module contains all prediction functions. The model file
(best_model_random_forest.pkl) is bundled with the package and
loaded automatically from the package data directory.
"""

import os
import sys
import numpy as np
import pandas as pd
import joblib
import gemmi

from Bio.PDB import PDBParser
from Bio.PDB.DSSP import DSSP
from scipy.spatial.distance import cdist


# ==============================================================================
# AMINO ACID PHYSICOCHEMICAL PROPERTIES
# ==============================================================================

AA_PROPERTIES = {
    "A": {"pI": 6.00,  "pKa1": 2.34, "pKa2": 9.69,  "hydrophobicity": -0.5, "steric": 0.52, "eiip": 0.0373},
    "R": {"pI": 10.76, "pKa1": 2.17, "pKa2": 9.04,  "hydrophobicity":  3.0, "steric": 0.68, "eiip": 0.0959},
    "N": {"pI": 5.41,  "pKa1": 2.02, "pKa2": 8.80,  "hydrophobicity":  0.2, "steric": 0.76, "eiip": 0.0036},
    "D": {"pI": 2.77,  "pKa1": 1.88, "pKa2": 9.60,  "hydrophobicity":  3.0, "steric": 0.76, "eiip": 0.1263},
    "C": {"pI": 5.05,  "pKa1": 1.96, "pKa2": 8.18,  "hydrophobicity": -1.0, "steric": 0.62, "eiip": 0.0829},
    "Q": {"pI": 5.65,  "pKa1": 2.17, "pKa2": 9.13,  "hydrophobicity":  0.2, "steric": 0.68, "eiip": 0.0761},
    "E": {"pI": 3.22,  "pKa1": 2.19, "pKa2": 9.67,  "hydrophobicity":  3.0, "steric": 0.68, "eiip": 0.0058},
    "G": {"pI": 5.97,  "pKa1": 2.34, "pKa2": 9.60,  "hydrophobicity":  0.0, "steric": 0.00, "eiip": 0.0050},
    "H": {"pI": 7.59,  "pKa1": 1.82, "pKa2": 9.17,  "hydrophobicity": -0.5, "steric": 0.70, "eiip": 0.0242},
    "I": {"pI": 6.02,  "pKa1": 2.36, "pKa2": 9.60,  "hydrophobicity": -1.8, "steric": 1.02, "eiip": 0.0000},
    "L": {"pI": 5.98,  "pKa1": 2.36, "pKa2": 9.60,  "hydrophobicity": -1.8, "steric": 0.98, "eiip": 0.0000},
    "K": {"pI": 9.74,  "pKa1": 2.18, "pKa2": 8.95,  "hydrophobicity":  3.0, "steric": 0.68, "eiip": 0.0371},
    "M": {"pI": 5.74,  "pKa1": 2.28, "pKa2": 9.21,  "hydrophobicity":  0.2, "steric": 0.76, "eiip": 0.0823},
    "F": {"pI": 5.48,  "pKa1": 1.83, "pKa2": 9.13,  "hydrophobicity": -2.5, "steric": 0.70, "eiip": 0.0946},
    "P": {"pI": 6.30,  "pKa1": 1.99, "pKa2": 10.60, "hydrophobicity":  0.0, "steric": 0.36, "eiip": 0.0198},
    "S": {"pI": 5.68,  "pKa1": 2.21, "pKa2": 9.15,  "hydrophobicity":  0.3, "steric": 0.53, "eiip": 0.0829},
    "T": {"pI": 5.60,  "pKa1": 2.09, "pKa2": 9.10,  "hydrophobicity": -0.4, "steric": 0.50, "eiip": 0.0941},
    "W": {"pI": 5.89,  "pKa1": 2.83, "pKa2": 9.39,  "hydrophobicity": -3.4, "steric": 0.70, "eiip": 0.0548},
    "Y": {"pI": 5.66,  "pKa1": 2.20, "pKa2": 9.11,  "hydrophobicity": -2.3, "steric": 0.70, "eiip": 0.0516},
    "V": {"pI": 5.96,  "pKa1": 2.32, "pKa2": 9.62,  "hydrophobicity": -1.5, "steric": 0.76, "eiip": 0.0057},
}

WINDOW_SIZE           = 7
INTERACTION_THRESHOLD = 0.5
PATCH_DISTANCE_CUTOFF = 10.0

# Model is bundled inside the package under hairpred2/data/
MODEL_FILENAME = "best_model_random_forest.pkl"
MODEL_PATH     = os.path.join(os.path.dirname(__file__), "data", MODEL_FILENAME)


# ==============================================================================
# VALIDATION
# ==============================================================================

def validate_pdb(pdb_file):
    """Check PDB file exists and contains ATOM records."""
    if not os.path.isfile(pdb_file):
        print(f"[ERROR] File not found: {pdb_file}")
        sys.exit(1)

    if not pdb_file.lower().endswith(".pdb"):
        print(f"[WARNING] File does not have .pdb extension: {pdb_file}")

    has_atom = False
    with open(pdb_file, "r") as f:
        for line in f:
            if line.startswith("ATOM") or line.startswith("HETATM"):
                has_atom = True
                break

    if not has_atom:
        print(f"[ERROR] No ATOM/HETATM records in: {pdb_file}")
        sys.exit(1)

    print(f"[OK] PDB file validated: {pdb_file}")


def validate_chains(pdb_file, chain_ids):
    """Check all requested chain IDs exist in the PDB."""
    found_chains = set()
    with open(pdb_file, "r") as f:
        for line in f:
            if line.startswith("ATOM"):
                found_chains.add(line[21])

    missing = [c for c in chain_ids if c not in found_chains]
    if missing:
        print(f"[ERROR] Chain(s) {missing} not found in {pdb_file}.")
        print(f"        Available chains: {', '.join(sorted(found_chains))}")
        sys.exit(1)

    print(f"[OK] Chain(s) {chain_ids} found in PDB file.")


# ==============================================================================
# STRUCTURE PROCESSING
# ==============================================================================

def extract_chains(input_pdb, chain_ids, output_pdb):
    """Extract specified chains from a PDB file."""
    st = gemmi.read_structure(input_pdb)
    for model in st:
        chains_to_remove = [chain.name for chain in model if chain.name not in chain_ids]
        for name in chains_to_remove:
            model.remove_chain(name)
    st.write_minimal_pdb(output_pdb)
    print(f"[OK] Chain(s) {chain_ids} extracted to: {output_pdb}")


def calculate_rsa(bio_model, pdb_path):
    """Compute RSA for each residue using DSSP."""
    dssp    = DSSP(bio_model, pdb_path, dssp="mkdssp")
    records = []

    for (chain_id, residue_id) in dssp.keys():
        aa  = dssp[(chain_id, residue_id)][1]
        rsa = dssp[(chain_id, residue_id)][3]
        if aa == "X":
            continue
        records.append({
            "Chain":      chain_id,
            "Residue":    aa,
            "Residue_ID": residue_id[1],
            "RSA":        rsa,
        })

    rsa_df = pd.DataFrame(records)
    print(f"[OK] RSA calculated for {len(rsa_df)} residues.")
    return rsa_df


def extract_ca_coordinates(bio_model):
    """Extract Cα coordinates for each residue."""
    coords = []
    for chain in bio_model:
        for residue in chain:
            if "CA" in residue:
                x, y, z = residue["CA"].coord
                coords.append({
                    "Chain":      chain.id,
                    "Residue_ID": residue.get_id()[1],
                    "X": x, "Y": y, "Z": z,
                })
    return pd.DataFrame(coords)


def build_residue_dataframe(pdb_file, chain_ids, work_dir=None):
    """
    Extract chains, compute RSA, extract Cα coords, and merge into one DataFrame.

    Parameters
    ----------
    pdb_file   : str  — path to antigen PDB file
    chain_ids  : list — list of chain ID strings (e.g. ['A'])
    work_dir   : str  — directory to write temp_chain.pdb (default: /tmp)

    Returns
    -------
    merged_df  : pd.DataFrame
    temp_pdb   : str — path to temporary extracted-chain PDB
    """
    if work_dir is None:
        work_dir = "/tmp"

    temp_pdb = os.path.join(work_dir, "hairpred2_temp_chain.pdb")
    extract_chains(pdb_file, chain_ids, temp_pdb)

    parser    = PDBParser(QUIET=True)
    structure = parser.get_structure("antigen", temp_pdb)
    bio_model = structure[0]

    rsa_df    = calculate_rsa(bio_model, temp_pdb)
    coord_df  = extract_ca_coordinates(bio_model)
    merged_df = pd.merge(rsa_df, coord_df, on=["Chain", "Residue_ID"], how="left")

    return merged_df, temp_pdb


# ==============================================================================
# FEATURE GENERATION
# ==============================================================================

def generate_features(df, window=WINDOW_SIZE):
    """
    Build 105-element feature vectors using a sliding window.

    7 features × 15 window positions = 105 features per residue.
    """
    n_positions = 2 * window + 1
    n_features  = 7
    all_vecs    = []

    for i in range(len(df)):
        mat = np.zeros((n_features, n_positions))

        for offset in range(-window, window + 1):
            idx = i + offset
            pos = offset + window

            if idx < 0 or idx >= len(df):
                continue

            row = df.iloc[idx]
            aa  = row["Residue"]
            if aa not in AA_PROPERTIES:
                continue

            p = AA_PROPERTIES[aa]
            mat[0, pos] = row["RSA"]
            mat[1, pos] = p["pI"]
            mat[2, pos] = p["pKa1"]
            mat[3, pos] = p["pKa2"]
            mat[4, pos] = p["hydrophobicity"]
            mat[5, pos] = p["steric"]
            mat[6, pos] = p["eiip"]

        all_vecs.append(mat.flatten())

    X = np.array(all_vecs)
    print(f"[OK] Feature matrix: {X.shape[0]} residues × {X.shape[1]} features")
    return X


# ==============================================================================
# MODEL
# ==============================================================================

def load_model(model_path=None):
    """
    Load the pre-trained Random Forest model.

    Parameters
    ----------
    model_path : str, optional
        Path to a custom .pkl model file. If None, the bundled model is used.
    """
    path = model_path or MODEL_PATH

    if not os.path.isfile(path):
        print(f"[ERROR] Model file not found: {path}")
        if model_path is None:
            print("        The model file must be downloaded separately due to its size.")
            print("        Run:  hairpred2-download-model")
            print("        Or download manually from:")
            print("        https://webs.iiitd.edu.in/raghava/hairpred2/download/best_model_random_forest.pkl")
        sys.exit(1)

    model = joblib.load(path)
    print(f"[OK] Model loaded from: {path}")
    return model


def predict_residues(model, X, threshold=INTERACTION_THRESHOLD):
    """
    Run predictions on feature matrix X.

    Returns
    -------
    probabilities : np.ndarray
    labels        : list of str
    """
    probabilities = model.predict_proba(X)[:, 1]
    labels = [
        "Interacting" if p >= threshold else "Non-interacting"
        for p in probabilities
    ]
    return probabilities, labels


# ==============================================================================
# OUTPUT FUNCTIONS
# ==============================================================================

def save_csv(df, probabilities, labels, output_path, min_rsa=None):
    """Save per-residue predictions to CSV."""
    results = pd.DataFrame({
        "Residue":     df["Residue"].astype(str) + df["Residue_ID"].astype(str),
        "RSA":         np.round(df["RSA"].values, 4),
        "Probability": np.round(probabilities, 4),
        "Prediction":  labels,
    })

    if min_rsa is not None:
        before  = len(results)
        results = results[results["RSA"] >= min_rsa].reset_index(drop=True)
        print(f"[OK] RSA filter >= {min_rsa}: kept {len(results)} / {before} residues.")

    results.to_csv(output_path, index=False)
    print(f"[OK] Predictions saved: {output_path}")
    return results


def save_summary_report(df, probabilities, labels, results_df,
                        pdb_file, chain_ids, threshold, output_path):
    """Write a plain-text summary report."""
    n_total       = len(labels)
    n_interacting = sum(1 for l in labels if l == "Interacting")
    n_non         = n_total - n_interacting
    avg_prob      = np.mean(probabilities)
    top10         = results_df.nlargest(10, "Probability")[
                        ["Residue", "RSA", "Probability", "Prediction"]]

    lines = [
        "=" * 60,
        "  HAIRpred2 — Prediction Summary Report",
        "=" * 60,
        "",
        "[ Input ]",
        f"  PDB file   : {pdb_file}",
        f"  Chain(s)   : {', '.join(chain_ids)}",
        f"  Threshold  : {threshold}",
        "",
        "[ Results ]",
        f"  Total residues  : {n_total}",
        f"  Interacting     : {n_interacting}  ({100*n_interacting/n_total:.1f}%)",
        f"  Non-interacting : {n_non}  ({100*n_non/n_total:.1f}%)",
        f"  Avg probability : {avg_prob:.4f}",
        "",
        "[ Top 10 Predicted Interacting Residues ]",
        top10.to_string(index=False),
        "",
        "=" * 60,
    ]

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[OK] Summary saved: {output_path}")
    print(f"\n  Total     : {n_total}")
    print(f"  Interacting    : {n_interacting} ({100*n_interacting/n_total:.1f}%)")
    print(f"  Non-interacting: {n_non} ({100*n_non/n_total:.1f}%)")
    print(f"  Avg probability: {avg_prob:.4f}")


def save_bfactor_pdb(input_pdb, chain_ids, df, probabilities, output_path):
    """Write PDB with probability as B-factor column."""
    prob_lookup = {}
    for i, row in df.iterrows():
        prob_lookup[(row["Chain"], int(row["Residue_ID"]))] = probabilities[i]

    out_lines = []
    with open(input_pdb, "r") as f:
        for line in f:
            if line.startswith("ATOM") or line.startswith("HETATM"):
                chain  = line[21]
                res_id = int(line[22:26].strip())
                if chain in chain_ids and (chain, res_id) in prob_lookup:
                    prob = prob_lookup[(chain, res_id)]
                    line = line[:60] + f"{prob * 100:6.2f}" + line[66:]
            out_lines.append(line)

    with open(output_path, "w") as f:
        f.writelines(out_lines)

    print(f"[OK] B-factor PDB saved: {output_path}")
    print("     PyMOL   → spectrum b, blue_white_red")
    print("     ChimeraX → color bfactor")


def save_pymol_script(bfactor_pdb, df, labels, probabilities, chain_ids, output_path):
    """Generate a PyMOL .pml coloring script."""
    inter_sel     = []
    non_inter_sel = []
    label_cmds    = []

    for i, row in df.iterrows():
        res_id     = int(row["Residue_ID"])
        chain      = row["Chain"]
        aa         = row["Residue"]
        prob       = float(probabilities[i])
        sel        = f"(chain {chain} and resi {res_id})"
        label_text = f"{aa}{res_id} ({prob:.2f})"

        if labels[i] == "Interacting":
            inter_sel.append(sel)
            label_cmds.append(
                f'label (chain {chain} and resi {res_id} and name CA), "{label_text}"'
            )
        else:
            non_inter_sel.append(sel)

    inter_str     = " or ".join(inter_sel)     if inter_sel     else "none"
    non_inter_str = " or ".join(non_inter_sel) if non_inter_sel else "none"

    lines = [
        "# HAIRpred2 — PyMOL Visualization Script",
        f"# Run in PyMOL: @{os.path.basename(output_path)}",
        "",
        f"load {os.path.abspath(bfactor_pdb)}, antigen",
        "",
        "bg_color white",
        "hide everything",
        "show cartoon, antigen",
        "color gray80, antigen",
        "",
        f"select interacting, {inter_str}",
        "color red, interacting",
        "show sticks, interacting",
        "show surface, interacting",
        "set transparency, 0.3, interacting",
        "",
        f"select non_interacting, {non_inter_str}",
        "color blue, non_interacting",
        "",
    ] + label_cmds + [
        "",
        "set label_size,     14",
        "set label_color,    black",
        "set label_font_id,  7",
        "set label_position, (0,1,1)",
        "",
        "deselect",
        "zoom antigen",
        "",
        "# hide labels  ← toggle off",
        "# show labels  ← toggle on",
        "# ray 1200, 900",
        "# png hairpred2_figure.png, dpi=300",
    ]

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[OK] PyMOL script saved: {output_path}")


def detect_epitope_patches(df, labels, probabilities,
                            distance_cutoff=PATCH_DISTANCE_CUTOFF):
    """Cluster interacting residues into spatial epitope patches."""
    inter_mask = np.array([l == "Interacting" for l in labels])
    inter_df   = df[inter_mask].copy().reset_index(drop=True)
    inter_prob = probabilities[inter_mask]

    if len(inter_df) == 0:
        return []

    if "X" not in inter_df.columns or inter_df["X"].isna().all():
        print("[WARNING] No 3D coordinates — skipping patch detection.")
        return []

    coords      = inter_df[["X", "Y", "Z"]].values
    dist_matrix = cdist(coords, coords, metric="euclidean")
    n           = len(inter_df)
    visited     = [False] * n
    patches     = []

    def bfs(start):
        patch = []
        queue = [start]
        visited[start] = True
        while queue:
            idx = queue.pop(0)
            row = inter_df.iloc[idx]
            patch.append({
                "Residue":     row["Residue"] + str(int(row["Residue_ID"])),
                "Chain":       row["Chain"],
                "RSA":         round(float(row["RSA"]), 4),
                "Probability": round(float(inter_prob[idx]), 4),
            })
            for nb in range(n):
                if not visited[nb] and dist_matrix[idx, nb] < distance_cutoff:
                    visited[nb] = True
                    queue.append(nb)
        return patch

    for i in range(n):
        if not visited[i]:
            patch = bfs(i)
            if len(patch) >= 2:
                patches.append(patch)

    return patches


def save_patch_report(patches, output_path):
    """Write epitope patch report."""
    lines = [
        "=" * 60,
        "  HAIRpred2 — Epitope Patch Detection Report",
        "=" * 60,
        "",
        f"  Total patches : {len(patches)}",
        f"  Distance cutoff: {PATCH_DISTANCE_CUTOFF} Å",
        "",
    ]

    for i, patch in enumerate(patches, 1):
        avg_p = np.mean([r["Probability"] for r in patch])
        lines.append(f"Patch {i}  ({len(patch)} residues, avg P = {avg_p:.4f})")
        lines.append("-" * 45)
        for res in sorted(patch, key=lambda x: x["Probability"], reverse=True):
            lines.append(
                f"  {res['Residue']:<8}  Chain {res['Chain']}  "
                f"RSA={res['RSA']:.3f}  P={res['Probability']:.4f}"
            )
        lines.append("")

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[OK] Patch report saved: {output_path}  ({len(patches)} patches)")


# ==============================================================================
# MAIN PIPELINE
# ==============================================================================

def run_pipeline(pdb_file, chain_ids, output_prefix,
                 threshold=INTERACTION_THRESHOLD,
                 min_rsa=None,
                 model_path=None,
                 work_dir=None):
    """
    Full HAIRpred2 prediction pipeline.

    Parameters
    ----------
    pdb_file      : str   — path to antigen PDB file
    chain_ids     : list  — list of chain IDs (e.g. ['A'] or ['A','B'])
    output_prefix : str   — prefix for all output files
    threshold     : float — probability threshold (default 0.5)
    min_rsa       : float — minimum RSA filter (default None = no filter)
    model_path    : str   — custom model path (default: bundled model)
    work_dir      : str   — working directory for temp files (default: /tmp)

    Returns
    -------
    results_df : pd.DataFrame — per-residue predictions
    """
    print("\n" + "=" * 60)
    print("  HAIRpred2 — Antibody-Interacting Residue Predictor")
    print("=" * 60 + "\n")

    # Derive work_dir from output_prefix if not given
    if work_dir is None:
        work_dir = os.path.dirname(os.path.abspath(output_prefix))

    print("[Step 1] Validating inputs...")
    validate_pdb(pdb_file)
    validate_chains(pdb_file, chain_ids)

    print("\n[Step 2] Extracting chain(s) and computing RSA...")
    residue_df, temp_pdb = build_residue_dataframe(pdb_file, chain_ids, work_dir)

    if len(residue_df) == 0:
        print("[ERROR] No valid residues found. Exiting.")
        sys.exit(1)

    print("\n[Step 3] Generating features...")
    X = generate_features(residue_df)

    print("\n[Step 4] Loading model and predicting...")
    model = load_model(model_path)
    probabilities, labels = predict_residues(model, X, threshold)
    probabilities = np.array(probabilities)

    print("\n[Step 5] Saving outputs...")
    csv_path     = f"{output_prefix}.csv"
    summary_path = f"{output_prefix}_summary.txt"
    bfactor_path = f"{output_prefix}_bfactor.pdb"
    pymol_path   = f"{output_prefix}.pml"
    patch_path   = f"{output_prefix}_patches.txt"

    results_df = save_csv(residue_df, probabilities, labels, csv_path, min_rsa)
    save_summary_report(residue_df, probabilities, labels, results_df,
                        pdb_file, chain_ids, threshold, summary_path)
    save_bfactor_pdb(pdb_file, chain_ids, residue_df, probabilities, bfactor_path)
    save_pymol_script(bfactor_path, residue_df, labels, probabilities, chain_ids, pymol_path)

    patches = detect_epitope_patches(residue_df, labels, probabilities)
    save_patch_report(patches, patch_path)

    if os.path.exists(temp_pdb):
        os.remove(temp_pdb)

    print(f"\n{'='*60}")
    print("  All outputs saved:")
    print(f"    Predictions  → {csv_path}")
    print(f"    Summary      → {summary_path}")
    print(f"    B-factor PDB → {bfactor_path}")
    print(f"    PyMOL script → {pymol_path}")
    print(f"    Patches      → {patch_path}")
    print(f"{'='*60}\n")

    return results_df
