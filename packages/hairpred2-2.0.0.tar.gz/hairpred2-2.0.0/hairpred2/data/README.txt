# Place best_model_random_forest.pkl in this directory.
# The model file is not included in the pip package due to its large size (~253MB).
# Download it using:
#   hairpred2-download-model
# Or manually from:
#   https://webs.iiitd.edu.in/raghava/hairpred2/download/best_model_random_forest.pkl
