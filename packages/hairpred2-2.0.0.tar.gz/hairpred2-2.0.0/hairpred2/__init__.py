"""
HAIRpred2 — Structure-based prediction of antibody-interacting residues in human antigens.

Usage as a library:
    from hairpred2 import run_pipeline

Usage as a command-line tool:
    hairpred2 -i antigen.pdb -c A -o results
"""

from .predictor import (
    run_pipeline,
    validate_pdb,
    validate_chains,
    build_residue_dataframe,
    generate_features,
    load_model,
    predict_residues,
    save_csv,
    save_summary_report,
    save_bfactor_pdb,
    save_pymol_script,
    detect_epitope_patches,
    save_patch_report,
)

__version__ = "1.0.0"
__author__  = "Naman Mehta, Raghava Lab, IIIT Delhi"
__email__   = "raghava@iiitd.ac.in"
