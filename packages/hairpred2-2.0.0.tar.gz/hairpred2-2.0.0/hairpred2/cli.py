"""
HAIRpred2 — Command-line interface entry point.

Installed as the `hairpred2` command when the package is installed.
"""

import argparse
import sys
from .predictor import run_pipeline, INTERACTION_THRESHOLD


def main():
    parser = argparse.ArgumentParser(
        prog="hairpred2",
        description=(
            "HAIRpred2: Predict antibody-interacting residues in antigen structures.\n"
            "Uses RSA + physicochemical features with a pre-trained Random Forest model."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  hairpred2 -i antigen.pdb -c A\n"
            "  hairpred2 -i antigen.pdb -c A -o my_results\n"
            "  hairpred2 -i antigen.pdb -c A,B\n"
            "  hairpred2 -i antigen.pdb -c A --min-rsa 0.05\n"
            "  hairpred2 -i antigen.pdb -c A -t 0.4\n\n"
            "Outputs (all share the same prefix):\n"
            "  <prefix>.csv           Per-residue predictions\n"
            "  <prefix>_summary.txt   Statistics + top 10 residues\n"
            "  <prefix>_bfactor.pdb   PDB with probability as B-factor\n"
            "  <prefix>.pml           PyMOL coloring script\n"
            "  <prefix>_patches.txt   Epitope patch clusters\n"
        ),
    )

    parser.add_argument(
        "-i", "--input",
        required=True,
        metavar="FILE",
        help="Input antigen PDB file",
    )
    parser.add_argument(
        "-c", "--chain",
        required=True,
        metavar="CHAIN",
        help="Antigen chain ID(s). Single: A   Multiple: A,B",
    )
    parser.add_argument(
        "-o", "--output",
        default="hairpred2_results",
        metavar="PREFIX",
        help="Output file prefix (default: hairpred2_results)",
    )
    parser.add_argument(
        "-t", "--threshold",
        type=float,
        default=INTERACTION_THRESHOLD,
        metavar="FLOAT",
        help=f"Probability threshold for Interacting label (default: {INTERACTION_THRESHOLD})",
    )
    parser.add_argument(
        "--min-rsa",
        type=float,
        default=None,
        metavar="FLOAT",
        help="Minimum RSA filter — removes buried residues (e.g. 0.05)",
    )
    parser.add_argument(
        "--model",
        default=None,
        metavar="FILE",
        help="Path to custom model .pkl file (default: bundled model)",
    )

    args = parser.parse_args()

    # Parse comma-separated chain IDs
    chain_ids = [c.strip() for c in args.chain.split(",")]

    run_pipeline(
        pdb_file      = args.input,
        chain_ids     = chain_ids,
        output_prefix = args.output,
        threshold     = args.threshold,
        min_rsa       = args.min_rsa,
        model_path    = args.model,
    )


if __name__ == "__main__":
    main()
