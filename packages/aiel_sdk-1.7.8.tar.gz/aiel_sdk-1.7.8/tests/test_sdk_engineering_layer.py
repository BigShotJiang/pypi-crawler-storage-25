import unittest

from src.aiel_sdk.decorators import agent, router, tool
from src.aiel_sdk.client import AielClient
from src.aiel_sdk.engenering.evals import EvalCase, run_eval_suite_sync, score_json_subset
from src.aiel_sdk.engenering.policy import (
    ActionAllowlistRule,
    PolicyEngine,
    PolicyViolation,
    RedactKeysResponseRule,
    RequirePathPrefixRule,
)
from src.aiel_sdk.engenering.regression import compare_eval_report
from src.aiel_sdk.engenering.rollback import RuntimeMetrics, RollbackThresholds, assess_rollback
from src.aiel_sdk.engenering.rollout import RolloutGate
from src.aiel_sdk.engenering.predeploy import PredeployInputs, PredeployOptions, run_predeploy_checks
from src.aiel_sdk.mcp import mcp_server
from src.aiel_sdk.registry import reset_registry
from src.aiel_sdk.engenering.tracing import TraceRecorder
from src.aiel_sdk.engenering.canary import assess_canary
from src.aiel_sdk.engenering.engine import EngineeringRunRequest, run_engineering_layer


class EngineeringLayerTests(unittest.TestCase):
    def setUp(self):
        reset_registry()

    def test_offline_evals_and_regression_diff(self):
        def target(x):
            return {"route": "research" if "billing" in x else "respond"}

        report = run_eval_suite_sync(
            "routing",
            target=target,
            cases=[
                EvalCase(id="1", input="billing case", expected={"route": "research"}),
                EvalCase(id="2", input="general case", expected={"route": "respond"}),
            ],
            scorer=score_json_subset,
        )
        self.assertEqual(report.total, 2)
        self.assertEqual(report.passed, 2)
        self.assertEqual(report.pass_rate, 1.0)

        baseline = {"pass_rate": 1.0, "avg_score": 1.0}
        diff = compare_eval_report(baseline, report)
        self.assertEqual(diff.regressed, False)

    def test_rollout_gate(self):
        report = run_eval_suite_sync(
            "g",
            target=lambda x: x,
            cases=[EvalCase(id="1", input=1, expected=1)],
        )
        decision = (
            RolloutGate.from_eval(report)
            .require_min_pass_rate(0.9)
            .require_min_avg_score(0.9)
            .require_policy_pass()
            .with_policy_result(True)
            .require_max_error_rate(0.05)
            .with_error_rate(0.01)
            .decide()
        )
        self.assertEqual(decision.ok, True)

    def test_rollback_thinking(self):
        decision = assess_rollback(
            RuntimeMetrics(error_rate=0.07, latency_p95_ms=1300, policy_violations=0),
            RollbackThresholds(max_error_rate=0.05, max_latency_p95_ms=2000, max_policy_violations=0),
        )
        self.assertEqual(decision.rollback, True)
        self.assertTrue(any("error_rate" in r for r in decision.reasons))

    def test_policy_checks_and_tracing_in_client(self):
        class _FakeTransport:
            def request(self, **kw):
                _ = kw
                return {"token": "secret", "ok": True}

        tracer = TraceRecorder()
        policy = PolicyEngine(
            request_rules=[RequirePathPrefixRule(["/v1/"])],
            response_rules=[RedactKeysResponseRule(["token"])],
        )
        client = AielClient(
            base_url="https://api.example.com",
            api_key="k",
            transport=_FakeTransport(),
            tracer=tracer,
            policy_engine=policy,
        )
        out = client._request("memory", "GET", "/v1/test", request_id="req_1")
        self.assertEqual(out["token"], "***")
        self.assertEqual(len(tracer.spans), 1)
        self.assertEqual(tracer.spans[0].attributes.get("request_id"), "req_1")

    def test_policy_allowlist_rule(self):
        class _FakeTransport:
            def request(self, **kw):
                _ = kw
                return {"ok": True}

        policy = PolicyEngine(request_rules=[ActionAllowlistRule(["slack.post_message"])])
        client = AielClient(
            base_url="https://api.example.com",
            api_key="k",
            transport=_FakeTransport(),
            policy_engine=policy,
        )

        with self.assertRaises(PolicyViolation):
            client._request(
                "integrations",
                "POST",
                "/v1/workspaces/w1/projects/p1/integrations/c1/action/postgres.query:invoke",
            )

    def test_predeploy_checks_optional_for_sandbox_to_production(self):
        report = run_eval_suite_sync(
            "deploy-gates",
            target=lambda x: x,
            cases=[EvalCase(id="1", input=1, expected=1)],
        )
        baseline = {"pass_rate": 1.0, "avg_score": 1.0}
        out = run_predeploy_checks(
            PredeployOptions(
                run_offline_evals=True,
                run_regression=True,
                run_rollout_gates=True,
                run_policy_gate=True,
                run_rollback_assessment=True,
            ),
            PredeployInputs(
                eval_report=report,
                baseline=baseline,
                policy_ok=True,
                error_rate=0.0,
                metrics=RuntimeMetrics(error_rate=0.0, latency_p95_ms=100, policy_violations=0),
                rollback_thresholds=RollbackThresholds(max_error_rate=0.1, max_latency_p95_ms=1000, max_policy_violations=0),
            ),
        )
        self.assertEqual(out.ok, True)
        self.assertTrue(any(check.name == "offline_evals" for check in out.checks))
        self.assertTrue(any(check.name == "rollout_gate" for check in out.checks))

    def test_predeploy_agent_expectations_pass(self):
        class _Schema:
            @classmethod
            def model_validate(cls, value):
                if not isinstance(value, dict) or "route" not in value:
                    raise ValueError("route required")
                return value

        @agent(
            "triage_agent",
            output_schema=_Schema,
            allowed_routes=("research", "respond"),
        )
        def triage_agent(ctx, state):
            _ = (ctx, state)
            return {"route": "research"}

        out = run_predeploy_checks(
            PredeployOptions(run_agent_expectations=True),
            PredeployInputs(agent_outputs={"triage_agent": {"route": "research"}}),
        )
        self.assertEqual(out.ok, True)
        self.assertEqual(out.agent_expectation_failures, {})

    def test_predeploy_agent_expectations_fail(self):
        @agent(
            "decision_agent",
            allowed_actions=("escalate_to_finance", "offer_payment_plan"),
        )
        def decision_agent(ctx, state):
            _ = (ctx, state)
            return {"action": "invalid"}

        out = run_predeploy_checks(
            PredeployOptions(run_agent_expectations=True),
            PredeployInputs(agent_outputs={"decision_agent": {"action": "invalid"}}),
        )
        self.assertEqual(out.ok, False)
        self.assertTrue("decision_agent" in out.agent_expectation_failures)

    def test_predeploy_tool_router_mcp_expectations_pass(self):
        class _ToolOut:
            @classmethod
            def model_validate(cls, value):
                if not isinstance(value, dict) or "action" not in value:
                    raise ValueError("action required")
                return value

        @tool("emit_action", output_schema=_ToolOut, allowed_actions=("go",))
        def emit_action(ctx, payload):
            _ = (ctx, payload)
            return {"action": "go"}

        @router("route_after_triage", allowed_routes=("research_agent", "response_agent"))
        def route_after_triage(ctx, state):
            _ = (ctx, state)
            return "research_agent"

        server = mcp_server("support")

        @server.tool("store_pref", allowed_actions=("saved",))
        def store_pref(ctx, payload):
            _ = (ctx, payload)
            return {"action": "saved"}

        out = run_predeploy_checks(
            PredeployOptions(
                run_tool_expectations=True,
                run_router_expectations=True,
                run_mcp_expectations=True,
            ),
            PredeployInputs(
                tool_outputs={"emit_action": {"action": "go"}},
                router_outputs={"route_after_triage": "research_agent"},
                mcp_outputs={"support:store_pref": {"action": "saved"}},
            ),
        )
        self.assertEqual(out.ok, True)

    def test_predeploy_tool_router_mcp_expectations_fail(self):
        @tool("emit_action", allowed_actions=("go",))
        def emit_action(ctx, payload):
            _ = (ctx, payload)
            return {"action": "stop"}

        @router("route_after_triage", allowed_routes=("research_agent", "response_agent"))
        def route_after_triage(ctx, state):
            _ = (ctx, state)
            return "other"

        server = mcp_server("support")

        @server.tool("store_pref", allowed_actions=("saved",))
        def store_pref(ctx, payload):
            _ = (ctx, payload)
            return {"action": "blocked"}

        out = run_predeploy_checks(
            PredeployOptions(
                run_tool_expectations=True,
                run_router_expectations=True,
                run_mcp_expectations=True,
            ),
            PredeployInputs(
                tool_outputs={"emit_action": {"action": "stop"}},
                router_outputs={"route_after_triage": "other"},
                mcp_outputs={"support:store_pref": {"action": "blocked"}},
            ),
        )
        self.assertEqual(out.ok, False)
        self.assertIn("emit_action", out.tool_expectation_failures)
        self.assertIn("route_after_triage", out.router_expectation_failures)
        self.assertIn("support:store_pref", out.mcp_expectation_failures)

    def test_trace_summary_and_canary_assessment(self):
        tracer = TraceRecorder()
        with tracer.start_span("ok"):
            pass

        summary = tracer.summary()
        self.assertEqual(summary.span_count, 1)
        self.assertEqual(summary.error_count, 0)

        canary = assess_canary(
            RuntimeMetrics(error_rate=0.0, latency_p95_ms=120, policy_violations=0),
            traffic_percent=10,
            thresholds=RollbackThresholds(max_error_rate=0.1, max_latency_p95_ms=1000, max_policy_violations=0),
        )
        self.assertEqual(canary.ok, True)
        self.assertEqual(canary.traffic_percent, 10)

    def test_engineering_layer_run_includes_canary(self):
        report = run_eval_suite_sync(
            "prod-candidate",
            target=lambda x: x,
            cases=[EvalCase(id="1", input=1, expected=1)],
        )

        result = run_engineering_layer(
            EngineeringRunRequest(
                version="v1.2.3",
                options=PredeployOptions(
                    run_offline_evals=True,
                    run_regression=True,
                    run_rollout_gates=True,
                    run_policy_gate=True,
                ),
                inputs=PredeployInputs(
                    eval_report=report,
                    baseline={"pass_rate": 1.0, "avg_score": 1.0},
                    policy_ok=True,
                    error_rate=0.0,
                ),
                canary_metrics=RuntimeMetrics(error_rate=0.0, latency_p95_ms=100, policy_violations=0),
                canary_traffic_percent=5,
            )
        )

        self.assertEqual(result.ok, True)
        self.assertEqual(result.version, "v1.2.3")
        self.assertIsNotNone(result.canary)
        self.assertEqual(result.canary.traffic_percent, 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
