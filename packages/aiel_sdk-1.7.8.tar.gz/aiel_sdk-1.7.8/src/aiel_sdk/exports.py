from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Tuple

@dataclass(frozen=True)
class ToolExport:
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool
    description: str | None = None
    version: str = "1.0"
    tags: tuple[str, ...] = ()
    output_schema: Any | None = None
    allowed_actions: tuple[str, ...] = ()
    allowed_routes: tuple[str, ...] = ()

@dataclass(frozen=True)
class AgentExport:
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool
    description: str | None = None
    version: str = "1.0"
    tags: tuple[str, ...] = ()
    output_schema: Any | None = None
    allowed_routes: tuple[str, ...] = ()
    allowed_actions: tuple[str, ...] = ()


@dataclass(frozen=True)
class RouterExport:
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool
    description: str | None = None
    version: str = "1.0"
    tags: tuple[str, ...] = ()
    allowed_routes: tuple[str, ...] = ()

@dataclass(frozen=True)
class FlowExport:
    name: str
    fn: Callable[..., Any] | None
    graph_builder: Callable[..., Any] | None
    module: str
    qualname: str

@dataclass(frozen=True)
class HttpHandlerExport:
    method: str
    path: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool

@dataclass
class McpServerExport:
    name: str
    tools: List[str]


@dataclass(frozen=True)
class McpToolExport:
    server: str
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool
    description: str | None = None
    version: str = "1.0"
    tags: tuple[str, ...] = ()
    output_schema: Any | None = None
    allowed_actions: tuple[str, ...] = ()
    allowed_routes: tuple[str, ...] = ()

McpToolMap = Dict[Tuple[str, str], Callable[..., Any]]
