from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .evals import EvalReport


@dataclass
class RolloutDecision:
    ok: bool
    reasons: List[str] = field(default_factory=list)


class RolloutGate:
    def __init__(self) -> None:
        self._min_pass_rate: float | None = None
        self._min_avg_score: float | None = None
        self._max_error_rate: float | None = None
        self._require_policy_pass: bool = False
        self._eval_report: EvalReport | None = None
        self._policy_ok: bool | None = None
        self._error_rate: float | None = None

    @classmethod
    def from_eval(cls, report: EvalReport) -> "RolloutGate":
        g = cls()
        g._eval_report = report
        return g

    def require_min_pass_rate(self, value: float) -> "RolloutGate":
        self._min_pass_rate = value
        return self

    def require_min_avg_score(self, value: float) -> "RolloutGate":
        self._min_avg_score = value
        return self

    def require_policy_pass(self, value: bool = True) -> "RolloutGate":
        self._require_policy_pass = value
        return self

    def with_policy_result(self, ok: bool) -> "RolloutGate":
        self._policy_ok = ok
        return self

    def require_max_error_rate(self, value: float) -> "RolloutGate":
        self._max_error_rate = value
        return self

    def with_error_rate(self, value: float) -> "RolloutGate":
        self._error_rate = value
        return self

    def decide(self) -> RolloutDecision:
        reasons: List[str] = []
        report = self._eval_report

        if self._min_pass_rate is not None:
            if report is None or report.pass_rate < self._min_pass_rate:
                reasons.append(f"pass_rate below threshold: {getattr(report, 'pass_rate', None)} < {self._min_pass_rate}")

        if self._min_avg_score is not None:
            if report is None or report.avg_score < self._min_avg_score:
                reasons.append(f"avg_score below threshold: {getattr(report, 'avg_score', None)} < {self._min_avg_score}")

        if self._require_policy_pass and self._policy_ok is not True:
            reasons.append("policy checks not passed")

        if self._max_error_rate is not None:
            if self._error_rate is None or self._error_rate > self._max_error_rate:
                reasons.append(f"error_rate above threshold: {self._error_rate} > {self._max_error_rate}")

        return RolloutDecision(ok=len(reasons) == 0, reasons=reasons)
