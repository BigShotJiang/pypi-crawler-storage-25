from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Protocol, Sequence


class PolicyViolation(Exception):
    def __init__(self, message: str, *, phase: str = "request", details: Any | None = None):
        msg = f"policy_violation[{phase}]: {message}"
        if details is not None:
            msg += f" | details={details}"
        super().__init__(msg)
        self.phase = phase
        self.details = details


@dataclass
class PolicyContext:
    service: str
    method: str
    path: str
    params: Dict[str, Any] = field(default_factory=dict)
    json_body: Any | None = None
    request_id: str | None = None


@dataclass
class PolicyCheck:
    ok: bool
    message: str
    details: Dict[str, Any] = field(default_factory=dict)


class RequestRule(Protocol):
    def check(self, ctx: PolicyContext) -> PolicyCheck:
        ...


class ResponseRule(Protocol):
    def check(self, ctx: PolicyContext, response: Any) -> PolicyCheck:
        ...

    def transform(self, ctx: PolicyContext, response: Any) -> Any:
        return response


class ActionAllowlistRule:
    _ACTION_RE = re.compile(r"/action/([^/:]+):invoke$")

    def __init__(self, allowed_actions: Sequence[str]) -> None:
        self.allowed = {str(x).strip() for x in allowed_actions if str(x).strip()}

    def check(self, ctx: PolicyContext) -> PolicyCheck:
        m = self._ACTION_RE.search(ctx.path or "")
        if not m:
            return PolicyCheck(ok=True, message="not an action invoke path")
        action = m.group(1)
        if action in self.allowed:
            return PolicyCheck(ok=True, message="allowed")
        return PolicyCheck(ok=False, message=f"action '{action}' is not allowed", details={"action": action})


class RequirePathPrefixRule:
    def __init__(self, allowed_prefixes: Sequence[str]) -> None:
        self.allowed_prefixes = [p for p in allowed_prefixes if p]

    def check(self, ctx: PolicyContext) -> PolicyCheck:
        if any(ctx.path.startswith(p) for p in self.allowed_prefixes):
            return PolicyCheck(ok=True, message="allowed")
        return PolicyCheck(ok=False, message="path is not allowed", details={"path": ctx.path})


class RedactKeysResponseRule:
    def __init__(self, keys: Sequence[str]) -> None:
        self._keys = {str(k).lower() for k in keys}

    def check(self, ctx: PolicyContext, response: Any) -> PolicyCheck:
        _ = (ctx, response)
        return PolicyCheck(ok=True, message="transform only")

    def transform(self, ctx: PolicyContext, response: Any) -> Any:
        _ = ctx
        return _redact(response, self._keys)


def _redact(obj: Any, keys: set[str]) -> Any:
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            if str(k).lower() in keys:
                out[k] = "***"
            else:
                out[k] = _redact(v, keys)
        return out
    if isinstance(obj, list):
        return [_redact(x, keys) for x in obj]
    return obj


class PolicyEngine:
    def __init__(
        self,
        *,
        request_rules: Sequence[RequestRule] | None = None,
        response_rules: Sequence[ResponseRule] | None = None,
    ) -> None:
        self.request_rules = list(request_rules or [])
        self.response_rules = list(response_rules or [])

    def enforce_request(self, ctx: PolicyContext) -> None:
        for rule in self.request_rules:
            check = rule.check(ctx)
            if not check.ok:
                raise PolicyViolation(check.message, phase="request", details=check.details)

    def enforce_response(self, ctx: PolicyContext, response: Any) -> Any:
        out = response
        for rule in self.response_rules:
            check = rule.check(ctx, out)
            if not check.ok:
                raise PolicyViolation(check.message, phase="response", details=check.details)
            out = rule.transform(ctx, out)
        return out
