from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict

from .evals import EvalReport
from ..registry import get_registry
from .regression import RegressionDiff, compare_eval_report
from .rollback import RollbackDecision, RollbackThresholds, RuntimeMetrics, assess_rollback
from .rollout import RolloutDecision, RolloutGate


@dataclass
class CheckResult:
    name: str
    ok: bool
    reasons: list[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PredeployOptions:
    run_offline_evals: bool = False
    run_regression: bool = False
    run_rollout_gates: bool = False
    run_policy_gate: bool = False
    run_rollback_assessment: bool = False
    run_agent_expectations: bool = False
    run_tool_expectations: bool = False
    run_router_expectations: bool = False
    run_mcp_expectations: bool = False


@dataclass
class PredeployInputs:
    eval_report: EvalReport | None = None
    baseline: Dict[str, Any] | None = None
    policy_ok: bool | None = None
    error_rate: float | None = None
    metrics: RuntimeMetrics | None = None
    rollback_thresholds: RollbackThresholds | None = None
    agent_outputs: Dict[str, Any] | None = None
    tool_outputs: Dict[str, Any] | None = None
    router_outputs: Dict[str, Any] | None = None
    mcp_outputs: Dict[str, Any] | None = None
    min_pass_rate: float = 0.95
    min_avg_score: float = 0.95
    max_error_rate: float = 0.02
    max_pass_rate_drop: float = 0.01
    max_avg_score_drop: float = 0.02


@dataclass
class PredeployReport:
    ok: bool
    reasons: list[str] = field(default_factory=list)
    checks: list[CheckResult] = field(default_factory=list)
    rollout: RolloutDecision | None = None
    regression: RegressionDiff | None = None
    rollback: RollbackDecision | None = None
    agent_expectation_failures: Dict[str, list[str]] = field(default_factory=dict)
    tool_expectation_failures: Dict[str, list[str]] = field(default_factory=dict)
    router_expectation_failures: Dict[str, list[str]] = field(default_factory=dict)
    mcp_expectation_failures: Dict[str, list[str]] = field(default_factory=dict)


def _extract_route(output: Any) -> str | None:
    if isinstance(output, dict):
        if isinstance(output.get("route"), str):
            return output.get("route")
    return None


def _extract_action(output: Any) -> str | None:
    if isinstance(output, dict):
        if isinstance(output.get("action"), str):
            return output.get("action")
        decision = output.get("decision")
        if isinstance(decision, dict) and isinstance(decision.get("action"), str):
            return decision.get("action")
    return None


def _validate_schema(schema: Any, output: Any) -> tuple[bool, str | None]:
    if schema is None:
        return True, None
    try:
        if hasattr(schema, "model_validate"):
            schema.model_validate(output)
            return True, None
        if callable(schema):
            res = schema(output)
            if res is False:
                return False, "custom schema callable returned False"
            return True, None
        return False, "unsupported output_schema type"
    except Exception as e:
        return False, str(e)


def evaluate_agent_expectations(agent_outputs: Dict[str, Any]) -> Dict[str, list[str]]:
    failures: Dict[str, list[str]] = {}
    reg = get_registry()
    for agent_name, output in (agent_outputs or {}).items():
        exp = reg.agents.get(agent_name)
        if exp is None:
            failures.setdefault(agent_name, []).append("agent is not registered")
            continue

        ok, err = _validate_schema(exp.output_schema, output)
        if not ok:
            failures.setdefault(agent_name, []).append(f"output_schema validation failed: {err}")

        if exp.allowed_routes:
            route = _extract_route(output)
            if route not in exp.allowed_routes:
                failures.setdefault(agent_name, []).append(
                    f"route '{route}' not allowed; expected one of {list(exp.allowed_routes)}"
                )

        if exp.allowed_actions:
            action = _extract_action(output)
            if action not in exp.allowed_actions:
                failures.setdefault(agent_name, []).append(
                    f"action '{action}' not allowed; expected one of {list(exp.allowed_actions)}"
                )
    return failures


def evaluate_tool_expectations(tool_outputs: Dict[str, Any]) -> Dict[str, list[str]]:
    failures: Dict[str, list[str]] = {}
    reg = get_registry()
    for tool_name, output in (tool_outputs or {}).items():
        exp = reg.tools.get(tool_name)
        if exp is None:
            failures.setdefault(tool_name, []).append("tool is not registered")
            continue

        ok, err = _validate_schema(exp.output_schema, output)
        if not ok:
            failures.setdefault(tool_name, []).append(f"output_schema validation failed: {err}")

        if exp.allowed_routes:
            route = _extract_route(output)
            if route not in exp.allowed_routes:
                failures.setdefault(tool_name, []).append(
                    f"route '{route}' not allowed; expected one of {list(exp.allowed_routes)}"
                )

        if exp.allowed_actions:
            action = _extract_action(output)
            if action not in exp.allowed_actions:
                failures.setdefault(tool_name, []).append(
                    f"action '{action}' not allowed; expected one of {list(exp.allowed_actions)}"
                )
    return failures


def evaluate_router_expectations(router_outputs: Dict[str, Any]) -> Dict[str, list[str]]:
    failures: Dict[str, list[str]] = {}
    reg = get_registry()
    for router_name, output in (router_outputs or {}).items():
        exp = reg.routers.get(router_name)
        if exp is None:
            failures.setdefault(router_name, []).append("router is not registered")
            continue

        route = output if isinstance(output, str) else _extract_route(output)
        if exp.allowed_routes and route not in exp.allowed_routes:
            failures.setdefault(router_name, []).append(
                f"route '{route}' not allowed; expected one of {list(exp.allowed_routes)}"
            )
    return failures


def evaluate_mcp_expectations(mcp_outputs: Dict[str, Any]) -> Dict[str, list[str]]:
    failures: Dict[str, list[str]] = {}
    reg = get_registry()
    for mcp_key, output in (mcp_outputs or {}).items():
        if ":" not in mcp_key:
            failures.setdefault(mcp_key, []).append("mcp key must be 'server:tool'")
            continue
        server, tool = mcp_key.split(":", 1)
        exp = reg.mcp_tools.get((server, tool))
        if exp is None:
            failures.setdefault(mcp_key, []).append("mcp tool is not registered")
            continue

        ok, err = _validate_schema(exp.output_schema, output)
        if not ok:
            failures.setdefault(mcp_key, []).append(f"output_schema validation failed: {err}")

        if exp.allowed_routes:
            route = _extract_route(output)
            if route not in exp.allowed_routes:
                failures.setdefault(mcp_key, []).append(
                    f"route '{route}' not allowed; expected one of {list(exp.allowed_routes)}"
                )

        if exp.allowed_actions:
            action = _extract_action(output)
            if action not in exp.allowed_actions:
                failures.setdefault(mcp_key, []).append(
                    f"action '{action}' not allowed; expected one of {list(exp.allowed_actions)}"
                )
    return failures


def _append_check(checks: list[CheckResult], reasons: list[str], name: str, ok: bool, *, details: Dict[str, Any] | None = None, check_reasons: list[str] | None = None) -> None:
    entry = CheckResult(name=name, ok=ok, reasons=list(check_reasons or []), details=dict(details or {}))
    checks.append(entry)
    if not ok:
        reasons.extend(entry.reasons or [f"{name} failed"])


def run_predeploy_checks(options: PredeployOptions, inputs: PredeployInputs) -> PredeployReport:
    reasons: list[str] = []
    checks: list[CheckResult] = []
    rollout_decision: RolloutDecision | None = None
    regression_diff: RegressionDiff | None = None
    rollback_decision: RollbackDecision | None = None
    agent_expectation_failures: Dict[str, list[str]] = {}
    tool_expectation_failures: Dict[str, list[str]] = {}
    router_expectation_failures: Dict[str, list[str]] = {}
    mcp_expectation_failures: Dict[str, list[str]] = {}

    if options.run_offline_evals:
        if inputs.eval_report is None:
            _append_check(checks, reasons, "offline_evals", False, check_reasons=["offline evals enabled but eval_report is missing"])
        else:
            _append_check(
                checks,
                reasons,
                "offline_evals",
                True,
                details={
                    "suite_name": inputs.eval_report.suite_name,
                    "pass_rate": inputs.eval_report.pass_rate,
                    "avg_score": inputs.eval_report.avg_score,
                },
            )

    if options.run_regression:
        if inputs.eval_report is None or inputs.baseline is None:
            _append_check(checks, reasons, "regression", False, check_reasons=["regression enabled but eval_report/baseline is missing"])
        else:
            regression_diff = compare_eval_report(
                inputs.baseline,
                inputs.eval_report,
                max_pass_rate_drop=inputs.max_pass_rate_drop,
                max_avg_score_drop=inputs.max_avg_score_drop,
            )
            ok = not regression_diff.regressed
            _append_check(
                checks,
                reasons,
                "regression",
                ok,
                details={
                    "pass_rate_delta": regression_diff.pass_rate_delta,
                    "avg_score_delta": regression_diff.avg_score_delta,
                },
                check_reasons=[] if ok else ["regression detected against baseline"],
            )

    if options.run_rollout_gates:
        if inputs.eval_report is None:
            _append_check(checks, reasons, "rollout_gate", False, check_reasons=["rollout gates enabled but eval_report is missing"])
        else:
            gate = (
                RolloutGate.from_eval(inputs.eval_report)
                .require_min_pass_rate(inputs.min_pass_rate)
                .require_min_avg_score(inputs.min_avg_score)
                .require_max_error_rate(inputs.max_error_rate)
            )
            if inputs.error_rate is not None:
                gate = gate.with_error_rate(inputs.error_rate)
            rollout_decision = gate.decide()
            _append_check(
                checks,
                reasons,
                "rollout_gate",
                rollout_decision.ok,
                details={"error_rate": inputs.error_rate},
                check_reasons=[f"rollout_gate: {r}" for r in rollout_decision.reasons],
            )

    if options.run_policy_gate:
        _append_check(
            checks,
            reasons,
            "policy_gate",
            inputs.policy_ok is True,
            check_reasons=[] if inputs.policy_ok is True else ["policy gate failed"],
        )

    if options.run_agent_expectations:
        if not inputs.agent_outputs:
            _append_check(checks, reasons, "agent_expectations", False, check_reasons=["agent expectation checks enabled but agent_outputs are missing"])
        else:
            agent_expectation_failures = evaluate_agent_expectations(inputs.agent_outputs)
            _append_check(
                checks,
                reasons,
                "agent_expectations",
                not agent_expectation_failures,
                details={"failures": agent_expectation_failures},
                check_reasons=[] if not agent_expectation_failures else ["agent expectation checks failed"],
            )

    if options.run_tool_expectations:
        if not inputs.tool_outputs:
            _append_check(checks, reasons, "tool_expectations", False, check_reasons=["tool expectation checks enabled but tool_outputs are missing"])
        else:
            tool_expectation_failures = evaluate_tool_expectations(inputs.tool_outputs)
            _append_check(
                checks,
                reasons,
                "tool_expectations",
                not tool_expectation_failures,
                details={"failures": tool_expectation_failures},
                check_reasons=[] if not tool_expectation_failures else ["tool expectation checks failed"],
            )

    if options.run_router_expectations:
        if not inputs.router_outputs:
            _append_check(checks, reasons, "router_expectations", False, check_reasons=["router expectation checks enabled but router_outputs are missing"])
        else:
            router_expectation_failures = evaluate_router_expectations(inputs.router_outputs)
            _append_check(
                checks,
                reasons,
                "router_expectations",
                not router_expectation_failures,
                details={"failures": router_expectation_failures},
                check_reasons=[] if not router_expectation_failures else ["router expectation checks failed"],
            )

    if options.run_mcp_expectations:
        if not inputs.mcp_outputs:
            _append_check(checks, reasons, "mcp_expectations", False, check_reasons=["mcp expectation checks enabled but mcp_outputs are missing"])
        else:
            mcp_expectation_failures = evaluate_mcp_expectations(inputs.mcp_outputs)
            _append_check(
                checks,
                reasons,
                "mcp_expectations",
                not mcp_expectation_failures,
                details={"failures": mcp_expectation_failures},
                check_reasons=[] if not mcp_expectation_failures else ["mcp expectation checks failed"],
            )

    if options.run_rollback_assessment:
        if inputs.metrics is None:
            _append_check(checks, reasons, "rollback_assessment", False, check_reasons=["rollback assessment enabled but metrics are missing"])
        else:
            rollback_decision = assess_rollback(inputs.metrics, inputs.rollback_thresholds)
            _append_check(
                checks,
                reasons,
                "rollback_assessment",
                not rollback_decision.rollback,
                details={
                    "error_rate": inputs.metrics.error_rate,
                    "latency_p95_ms": inputs.metrics.latency_p95_ms,
                    "policy_violations": inputs.metrics.policy_violations,
                },
                check_reasons=[f"rollback: {r}" for r in rollback_decision.reasons],
            )

    return PredeployReport(
        ok=len(reasons) == 0,
        reasons=reasons,
        checks=checks,
        rollout=rollout_decision,
        regression=regression_diff,
        rollback=rollback_decision,
        agent_expectation_failures=agent_expectation_failures,
        tool_expectation_failures=tool_expectation_failures,
        router_expectation_failures=router_expectation_failures,
        mcp_expectation_failures=mcp_expectation_failures,
    )
