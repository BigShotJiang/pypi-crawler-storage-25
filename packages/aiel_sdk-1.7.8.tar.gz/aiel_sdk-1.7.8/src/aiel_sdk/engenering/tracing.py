from __future__ import annotations

import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional


def _now_ms() -> int:
    return int(time.time() * 1000)


@dataclass
class Span:
    span_id: str
    trace_id: str
    name: str
    start_ms: int
    end_ms: int | None = None
    status: str = "ok"
    attributes: Dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    @property
    def duration_ms(self) -> int | None:
        if self.end_ms is None:
            return None
        return self.end_ms - self.start_ms


@dataclass
class SpanContext:
    trace_id: str
    span_id: str


@dataclass
class TraceSummary:
    trace_count: int
    span_count: int
    error_count: int
    total_duration_ms: int
    max_duration_ms: int
    average_duration_ms: float


def summarize_traces(spans: List[Span]) -> TraceSummary:
    durations = [span.duration_ms or 0 for span in spans]
    trace_ids = {span.trace_id for span in spans}
    return TraceSummary(
        trace_count=len(trace_ids),
        span_count=len(spans),
        error_count=len([span for span in spans if span.status == "error"]),
        total_duration_ms=sum(durations),
        max_duration_ms=max(durations, default=0),
        average_duration_ms=(sum(durations) / len(durations)) if durations else 0.0,
    )


class TraceRecorder:
    """
    Minimal in-memory span recorder suitable for SDK-level tracing hooks.
    """

    def __init__(self) -> None:
        self.spans: List[Span] = []
        self._last_context: SpanContext | None = None

    @property
    def last_context(self) -> SpanContext | None:
        return self._last_context

    def summary(self) -> TraceSummary:
        return summarize_traces(self.spans)

    @contextmanager
    def start_span(self, name: str, *, attributes: Optional[Dict[str, Any]] = None) -> Iterator[Span]:
        trace_id = (self._last_context.trace_id if self._last_context else None) or f"tr_{uuid.uuid4().hex}"
        span = Span(
            span_id=f"sp_{uuid.uuid4().hex}",
            trace_id=trace_id,
            name=name,
            start_ms=_now_ms(),
            attributes=dict(attributes or {}),
        )
        self._last_context = SpanContext(trace_id=trace_id, span_id=span.span_id)
        self.spans.append(span)
        try:
            yield span
        except Exception as e:
            span.status = "error"
            span.error = str(e)
            span.end_ms = _now_ms()
            raise
        else:
            span.end_ms = _now_ms()
