from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from .evals import EvalReport


@dataclass
class RegressionDiff:
    baseline_pass_rate: float
    current_pass_rate: float
    baseline_avg_score: float
    current_avg_score: float
    pass_rate_delta: float
    avg_score_delta: float
    regressed: bool


def save_eval_baseline(path: str | Path, report: EvalReport) -> None:
    p = Path(path)
    payload = {
        "suite_name": report.suite_name,
        "pass_rate": report.pass_rate,
        "avg_score": report.avg_score,
        "total": report.total,
        "passed": report.passed,
        "failed": report.failed,
    }
    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_eval_baseline(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    return json.loads(p.read_text(encoding="utf-8"))


def compare_eval_report(
    baseline: Dict[str, Any],
    current: EvalReport,
    *,
    max_pass_rate_drop: float = 0.01,
    max_avg_score_drop: float = 0.02,
) -> RegressionDiff:
    b_pass = float(baseline.get("pass_rate", 0.0))
    b_avg = float(baseline.get("avg_score", 0.0))
    c_pass = float(current.pass_rate)
    c_avg = float(current.avg_score)
    pass_drop = b_pass - c_pass
    score_drop = b_avg - c_avg
    regressed = pass_drop > max_pass_rate_drop or score_drop > max_avg_score_drop
    return RegressionDiff(
        baseline_pass_rate=b_pass,
        current_pass_rate=c_pass,
        baseline_avg_score=b_avg,
        current_avg_score=c_avg,
        pass_rate_delta=c_pass - b_pass,
        avg_score_delta=c_avg - b_avg,
        regressed=regressed,
    )
