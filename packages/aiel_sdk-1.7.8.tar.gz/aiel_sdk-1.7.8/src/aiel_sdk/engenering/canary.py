from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .rollback import RollbackThresholds, RuntimeMetrics, assess_rollback


@dataclass
class CanaryAssessment:
    ok: bool
    traffic_percent: int
    reasons: List[str] = field(default_factory=list)


def assess_canary(
    metrics: RuntimeMetrics,
    *,
    traffic_percent: int,
    thresholds: RollbackThresholds | None = None,
) -> CanaryAssessment:
    rollback = assess_rollback(metrics, thresholds)
    return CanaryAssessment(
        ok=not rollback.rollback,
        traffic_percent=traffic_percent,
        reasons=list(rollback.reasons),
    )
