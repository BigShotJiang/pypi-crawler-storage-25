from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from .canary import CanaryAssessment, assess_canary
from .predeploy import PredeployInputs, PredeployOptions, PredeployReport, run_predeploy_checks
from .rollback import RollbackThresholds, RuntimeMetrics
from .tracing import TraceSummary


@dataclass
class EngineeringRunRequest:
    version: str
    options: PredeployOptions
    inputs: PredeployInputs
    trace_summary: TraceSummary | None = None
    canary_metrics: RuntimeMetrics | None = None
    canary_traffic_percent: int | None = None
    canary_thresholds: RollbackThresholds | None = None
    metadata: Dict[str, Any] | None = None


@dataclass
class EngineeringRunResult:
    version: str
    ok: bool
    predeploy: PredeployReport
    canary: CanaryAssessment | None = None
    metadata: Dict[str, Any] | None = None


def run_engineering_layer(request: EngineeringRunRequest) -> EngineeringRunResult:
    predeploy = run_predeploy_checks(request.options, request.inputs)
    canary: CanaryAssessment | None = None
    if request.canary_metrics is not None and request.canary_traffic_percent is not None:
        canary = assess_canary(
            request.canary_metrics,
            traffic_percent=request.canary_traffic_percent,
            thresholds=request.canary_thresholds,
        )

    ok = predeploy.ok and (canary.ok if canary is not None else True)
    return EngineeringRunResult(
        version=request.version,
        ok=ok,
        predeploy=predeploy,
        canary=canary,
        metadata=request.metadata,
    )
