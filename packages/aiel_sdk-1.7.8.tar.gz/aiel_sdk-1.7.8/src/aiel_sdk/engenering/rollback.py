from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class RuntimeMetrics:
    error_rate: float
    latency_p95_ms: float
    policy_violations: int


@dataclass
class RollbackThresholds:
    max_error_rate: float = 0.05
    max_latency_p95_ms: float = 2500.0
    max_policy_violations: int = 0


@dataclass
class RollbackDecision:
    rollback: bool
    reasons: List[str] = field(default_factory=list)


def assess_rollback(metrics: RuntimeMetrics, thresholds: RollbackThresholds | None = None) -> RollbackDecision:
    t = thresholds or RollbackThresholds()
    reasons: List[str] = []

    if metrics.error_rate > t.max_error_rate:
        reasons.append(f"error_rate {metrics.error_rate} exceeds {t.max_error_rate}")
    if metrics.latency_p95_ms > t.max_latency_p95_ms:
        reasons.append(f"latency_p95_ms {metrics.latency_p95_ms} exceeds {t.max_latency_p95_ms}")
    if metrics.policy_violations > t.max_policy_violations:
        reasons.append(f"policy_violations {metrics.policy_violations} exceeds {t.max_policy_violations}")

    return RollbackDecision(rollback=len(reasons) > 0, reasons=reasons)
