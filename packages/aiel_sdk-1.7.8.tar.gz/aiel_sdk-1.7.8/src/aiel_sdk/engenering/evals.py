from __future__ import annotations

import asyncio
import inspect
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Sequence


@dataclass
class EvalCase:
    id: str
    input: Any
    expected: Any
    tags: tuple[str, ...] = ()


@dataclass
class EvalCaseResult:
    case_id: str
    passed: bool
    score: float
    output: Any
    expected: Any
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvalReport:
    suite_name: str
    total: int
    passed: int
    failed: int
    pass_rate: float
    avg_score: float
    results: List[EvalCaseResult] = field(default_factory=list)


def score_exact(output: Any, expected: Any) -> tuple[float, Dict[str, Any]]:
    ok = output == expected
    return (1.0 if ok else 0.0, {"mode": "exact"})


def score_json_subset(output: Any, expected_subset: Any) -> tuple[float, Dict[str, Any]]:
    ok = _is_subset(expected_subset, output)
    return (1.0 if ok else 0.0, {"mode": "json_subset"})


def _is_subset(needle: Any, hay: Any) -> bool:
    if isinstance(needle, dict):
        if not isinstance(hay, dict):
            return False
        for k, v in needle.items():
            if k not in hay or not _is_subset(v, hay[k]):
                return False
        return True
    if isinstance(needle, list):
        if not isinstance(hay, list) or len(needle) > len(hay):
            return False
        return all(_is_subset(n, h) for n, h in zip(needle, hay))
    return needle == hay


async def run_eval_suite(
    suite_name: str,
    *,
    target: Callable[[Any], Any],
    cases: Sequence[EvalCase],
    scorer: Callable[[Any, Any], tuple[float, Dict[str, Any]]] = score_exact,
    pass_threshold: float = 1.0,
) -> EvalReport:
    results: List[EvalCaseResult] = []
    for case in cases:
        out = target(case.input)
        if inspect.isawaitable(out):
            out = await out
        score, details = scorer(out, case.expected)
        passed = score >= pass_threshold
        results.append(
            EvalCaseResult(
                case_id=case.id,
                passed=passed,
                score=score,
                output=out,
                expected=case.expected,
                details=details,
            )
        )

    total = len(results)
    passed_n = len([r for r in results if r.passed])
    failed_n = total - passed_n
    avg_score = (sum(r.score for r in results) / total) if total else 0.0
    pass_rate = (passed_n / total) if total else 0.0
    return EvalReport(
        suite_name=suite_name,
        total=total,
        passed=passed_n,
        failed=failed_n,
        pass_rate=pass_rate,
        avg_score=avg_score,
        results=results,
    )


def run_eval_suite_sync(
    suite_name: str,
    *,
    target: Callable[[Any], Any],
    cases: Sequence[EvalCase],
    scorer: Callable[[Any, Any], tuple[float, Dict[str, Any]]] = score_exact,
    pass_threshold: float = 1.0,
) -> EvalReport:
    return asyncio.run(
        run_eval_suite(
            suite_name,
            target=target,
            cases=cases,
            scorer=scorer,
            pass_threshold=pass_threshold,
        )
    )
