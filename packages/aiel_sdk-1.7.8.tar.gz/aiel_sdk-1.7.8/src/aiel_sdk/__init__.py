from ._version import SDK_VERSION
from .context import Context
from .registry import get_registry, reset_registry
from .decorators import tool, agent, router, flow, flow_graph
from .http import http
from .mcp import mcp_server
from .validate import validate_contracts
from .client import AielClient
from .errors import AielError, ApiError, ContractViolation, RuntimeDependencyError
from .engenering.evals import (
    EvalCase,
    EvalCaseResult,
    EvalReport,
    run_eval_suite,
    run_eval_suite_sync,
    score_exact,
    score_json_subset,
)
from .engenering.regression import RegressionDiff, compare_eval_report, load_eval_baseline, save_eval_baseline
from .engenering.tracing import Span, SpanContext, TraceRecorder, TraceSummary, summarize_traces
from .engenering.policy import (
    PolicyViolation,
    PolicyContext,
    PolicyCheck,
    PolicyEngine,
    ActionAllowlistRule,
    RequirePathPrefixRule,
    RedactKeysResponseRule,
)
from .engenering.rollout import RolloutDecision, RolloutGate
from .engenering.rollback import RollbackDecision, RollbackThresholds, RuntimeMetrics, assess_rollback
from .engenering.canary import CanaryAssessment, assess_canary
from .engenering.predeploy import (
    CheckResult,
    PredeployOptions,
    PredeployInputs,
    PredeployReport,
    evaluate_agent_expectations,
    evaluate_tool_expectations,
    evaluate_router_expectations,
    evaluate_mcp_expectations,
    run_predeploy_checks,
)
from .engenering.engine import EngineeringRunRequest, EngineeringRunResult, run_engineering_layer

from aiel_integrations import IntegrationsClient # legacy


__all__ = [
    "SDK_VERSION",
    "Context",
    "get_registry", "reset_registry",
    "tool", "agent", "router", "flow", "flow_graph",
    "http", "mcp_server",
    "validate_contracts",
    "IntegrationsClient",  # legacy
    "AielClient",          # new
    "AielError",
    "ApiError",
    "ContractViolation",
    "RuntimeDependencyError",
    "PolicyViolation",
    "EvalCase",
    "EvalCaseResult",
    "EvalReport",
    "run_eval_suite",
    "run_eval_suite_sync",
    "score_exact",
    "score_json_subset",
    "RegressionDiff",
    "compare_eval_report",
    "load_eval_baseline",
    "save_eval_baseline",
    "Span",
    "SpanContext",
    "TraceRecorder",
    "TraceSummary",
    "summarize_traces",
    "PolicyContext",
    "PolicyCheck",
    "PolicyEngine",
    "ActionAllowlistRule",
    "RequirePathPrefixRule",
    "RedactKeysResponseRule",
    "RolloutDecision",
    "RolloutGate",
    "RollbackDecision",
    "RollbackThresholds",
    "RuntimeMetrics",
    "assess_rollback",
    "CanaryAssessment",
    "assess_canary",
    "CheckResult",
    "PredeployOptions",
    "PredeployInputs",
    "PredeployReport",
    "evaluate_agent_expectations",
    "evaluate_tool_expectations",
    "evaluate_router_expectations",
    "evaluate_mcp_expectations",
    "run_predeploy_checks",
    "EngineeringRunRequest",
    "EngineeringRunResult",
    "run_engineering_layer",
]
