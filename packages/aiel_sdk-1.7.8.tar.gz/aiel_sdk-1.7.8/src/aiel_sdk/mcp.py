from __future__ import annotations
import inspect
from typing import Any, Callable
from .registry import get_registry
from .exports import McpServerExport, McpToolExport

class AielMcpServer:
    def __init__(self, name: str):
        self.name = name
        reg = get_registry()
        reg.mcp_servers.setdefault(name, McpServerExport(name=name, tools=[]))

    def tool(
        self,
        name: str | None = None,
        *,
        description: str | None = None,
        version: str = "1.0",
        tags: tuple[str, ...] = (),
        output_schema: Any | None = None,
        allowed_actions: tuple[str, ...] = (),
        allowed_routes: tuple[str, ...] = (),
    ):
        def decorator(fn: Callable[..., Any]):
            reg = get_registry()
            tool_name = name or fn.__name__

            srv = reg.mcp_servers.setdefault(self.name, McpServerExport(name=self.name, tools=[]))
            if tool_name not in srv.tools:
                srv.tools.append(tool_name)

            reg.mcp_tool_fns[(self.name, tool_name)] = fn
            definition = McpToolExport(
                server=self.name,
                name=tool_name,
                fn=fn,
                module=fn.__module__,
                qualname=fn.__qualname__,
                is_async=inspect.iscoroutinefunction(fn),
                description=description,
                version=version,
                tags=tags,
                output_schema=output_schema,
                allowed_actions=allowed_actions,
                allowed_routes=allowed_routes,
            )
            reg.mcp_tools[(self.name, tool_name)] = definition
            setattr(fn, "__aiel_mcp_tool_definition__", definition)
            return fn
        return decorator

def mcp_server(name: str, tools: list[str] | None = None) -> AielMcpServer:
    reg = get_registry()
    srv = reg.mcp_servers.setdefault(name, McpServerExport(name=name, tools=[]))
    if tools:
        for t in tools:
            if t not in srv.tools:
                srv.tools.append(t)
    return AielMcpServer(name)
