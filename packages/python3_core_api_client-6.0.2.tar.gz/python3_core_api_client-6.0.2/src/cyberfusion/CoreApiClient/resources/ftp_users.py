from cyberfusion.CoreApiClient import models

from cyberfusion.CoreApiClient.interfaces import Resource
from cyberfusion.CoreApiClient._helpers import construct_includes_query_parameter
from cyberfusion.CoreApiClient.http import DtoResponse


class FtpUsers(Resource):
    def create_ftp_user(
        self,
        request: models.FtpUserCreateRequest,
    ) -> DtoResponse[models.FtpUserResource]:
        local_response = self.api_connector.send_or_fail(
            "POST",
            "/api/v1/ftp-users",
            data=request.model_dump(exclude_unset=True),
            query_parameters={},
        )

        return DtoResponse.from_responses(local_response, models.FtpUserResource)

    def list_ftp_users(
        self,
        *,
        include_filters: models.FtpUsersSearchRequest | None = None,
        includes: list[str] | None = None,
    ) -> DtoResponse[list[models.FtpUserResource]]:
        local_responses = self.api_connector.send_or_fail_with_auto_pagination(
            "GET",
            "/api/v1/ftp-users",
            data=None,
            query_parameters=(
                include_filters.model_dump(exclude_unset=True)
                if include_filters
                else {}
            )
            | construct_includes_query_parameter(includes),
        )

        return DtoResponse.from_responses(local_responses, models.FtpUserResource)

    def read_ftp_user(
        self,
        *,
        id_: int,
        includes: list[str] | None = None,
    ) -> DtoResponse[models.FtpUserResource]:
        local_response = self.api_connector.send_or_fail(
            "GET",
            f"/api/v1/ftp-users/{id_}",
            data=None,
            query_parameters=construct_includes_query_parameter(includes),
        )

        return DtoResponse.from_responses(local_response, models.FtpUserResource)

    def update_ftp_user(
        self,
        request: models.FtpUserUpdateRequest,
        *,
        id_: int,
    ) -> DtoResponse[models.FtpUserResource]:
        local_response = self.api_connector.send_or_fail(
            "PATCH",
            f"/api/v1/ftp-users/{id_}",
            data=request.model_dump(exclude_unset=True),
            query_parameters={},
        )

        return DtoResponse.from_responses(local_response, models.FtpUserResource)

    def delete_ftp_user(
        self,
        *,
        id_: int,
    ) -> DtoResponse[models.DetailMessage]:
        local_response = self.api_connector.send_or_fail(
            "DELETE", f"/api/v1/ftp-users/{id_}", data=None, query_parameters={}
        )

        return DtoResponse.from_responses(local_response, models.DetailMessage)

    def create_temporary_ftp_user(
        self,
        request: models.TemporaryFtpUserCreateRequest,
    ) -> DtoResponse[models.TemporaryFtpUserResource]:
        local_response = self.api_connector.send_or_fail(
            "POST",
            "/api/v1/ftp-users/temporary",
            data=request.model_dump(exclude_unset=True),
            query_parameters={},
        )

        return DtoResponse.from_responses(
            local_response, models.TemporaryFtpUserResource
        )
