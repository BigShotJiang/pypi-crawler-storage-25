"""Agent definitions and builders.

This module provides high-level agent interfaces for building autonomous agents with
different execution models (code-driven, config-driven, memory-aware).

Examples:
    Build a config-driven agent with Python handlers (decorator approach):

        # handlers.py
        from flowgentra_ai.agent import register_handler

        @register_handler
        def validate_input(state: dict) -> dict:
            if not state.get("input"):
                raise ValueError("Input required")
            return state

        # config.yaml includes: python_handler_module: handlers

        # main.py
        from flowgentra_ai.agent import Agent
        agent = Agent.from_config_path("config.yaml")

    Build a config-driven agent with explicit Python path in config:

        # config.yaml node handler: python.mymodule:my_func
        from flowgentra_ai.agent import Agent
        agent = Agent.from_config_path("config.yaml")

    Build a memory-aware agent:

        from flowgentra_ai.agent import MemoryAwareAgent

        agent = MemoryAwareAgent(...)
        # Automatically manages memory and conversation

    Load an agent from a YAML config file:

        from flowgentra_ai.agent import from_config_path

        agent = from_config_path("agent.yaml")
"""

from typing import Callable

from flowgentra_ai._native import agent as _a, advanced as _adv, utils as _u

Agent = _a.Agent
AgentType = _a.AgentType
ToolSpec = _a.ToolSpec
AgentBuilder = _a.AgentBuilder
GraphBasedAgent = _a.GraphBasedAgent
AgentConfig = _a.AgentConfig
StateField = _a.StateField
MemoryAwareAgent = _adv.MemoryAwareAgent
MemoryStats = _adv.MemoryStats

# Typed agent constructors — preferred over AgentBuilder for new code
ZeroShotReAct = _a.ZeroShotReAct
FewShotReAct = _a.FewShotReAct
Conversational = _a.Conversational
ToolCalling = _a.ToolCalling
StructuredChat = _a.StructuredChat
SelfAskWithSearch = _a.SelfAskWithSearch
ReactDocstore = _a.ReactDocstore

# ── Config-driven loading ─────────────────────────────────────────────────────
from_config_path = _u.py_from_config_path


def register_handler(func: Callable) -> Callable:
    """Decorator to mark a Python function as an agent handler.

    Decorated functions are auto-discovered when the containing module is
    specified via ``python_handler_module`` in the agent config YAML.

    The function must accept a ``dict`` (the agent state) and return a
    ``dict`` (full state or partial update merged into the current state).

    Example::

        from flowgentra_ai.agent import register_handler

        @register_handler
        def process_input(state: dict) -> dict:
            return {**state, "output": state["input"].upper()}

    Then in ``config.yaml``::

        python_handler_module: handlers  # module containing the above function
        graph:
          nodes:
            - name: process
              handler: process_input
    """
    func._is_handler = True  # type: ignore[attr-defined]
    return func


__all__ = [
    # Core agent classes
    "Agent",
    "GraphBasedAgent",
    # Typed agent constructors (preferred)
    "ZeroShotReAct",
    "FewShotReAct",
    "Conversational",
    "ToolCalling",
    "StructuredChat",
    "SelfAskWithSearch",
    "ReactDocstore",
    # Agent building and configuration (legacy builder)
    "AgentType",
    "ToolSpec",
    "AgentBuilder",
    "AgentConfig",
    "StateField",
    # Memory-aware agents
    "MemoryAwareAgent",
    "MemoryStats",
    # Python handler registration
    "register_handler",
    # Config-driven loading
    "from_config_path",
]
