"""Tool registry, execution, and all predefined tools.

Examples:
    from flowgentra_ai.tools import ToolRegistry, CalculatorTool, DuckDuckGoSearchTool

    registry = ToolRegistry.with_builtins()
    result = registry.call_tool("duckduckgo_search", {"query": "Rust language"})

    # Tools with API keys
    from flowgentra_ai.tools import TavilySearchTool, WikipediaTool
    wiki = WikipediaTool()
    result = wiki.call({"title": "Python (programming language)"})
"""

from flowgentra_ai._native import tools as _t

# ── Core infrastructure ───────────────────────────────────────────────────────
ToolCallRequest = _t.ToolCallRequest
ToolCallResult = _t.ToolCallResult
ToolRegistry = _t.ToolRegistry
JsonSchema = _t.JsonSchema
ToolNode = _t.ToolNode
create_tool_node = _t.py_create_tool_node
store_tool_calls = _t.py_store_tool_calls
check_tools_condition = _t.py_check_tools_condition

# ── Core built-ins ────────────────────────────────────────────────────────────
CalculatorTool = _t.CalculatorTool
WebRequestTool = _t.WebRequestTool
FilesTool = _t.FilesTool

# ── Search tools ──────────────────────────────────────────────────────────────
DuckDuckGoSearchTool = _t.DuckDuckGoSearchTool
TavilySearchTool = _t.TavilySearchTool
SerpApiSearchTool = _t.SerpApiSearchTool
GoogleSerperTool = _t.GoogleSerperTool
BraveSearchTool = _t.BraveSearchTool

# ── Knowledge tools ───────────────────────────────────────────────────────────
WikipediaTool = _t.WikipediaTool
ArxivTool = _t.ArxivTool
PubMedTool = _t.PubMedTool
WolframAlphaTool = _t.WolframAlphaTool

# ── Code execution tools ──────────────────────────────────────────────────────
PythonReplTool = _t.PythonReplTool
NodeJsReplTool = _t.NodeJsReplTool
ShellTool = _t.ShellTool

# ── Extended file tools ───────────────────────────────────────────────────────
CopyFileTool = _t.CopyFileTool
DeleteFileTool = _t.DeleteFileTool
MoveFileTool = _t.MoveFileTool
FileSearchTool = _t.FileSearchTool

# ── Data tools ────────────────────────────────────────────────────────────────
JsonGetValueTool = _t.JsonGetValueTool
JsonListKeysTool = _t.JsonListKeysTool
CsvQueryTool = _t.CsvQueryTool

# ── Human-in-the-loop ─────────────────────────────────────────────────────────
HumanInputTool = _t.HumanInputTool

# ── Communication tools ───────────────────────────────────────────────────────
GmailTool = _t.GmailTool
SlackTool = _t.SlackTool

# ── External API tools ────────────────────────────────────────────────────────
OpenWeatherMapTool = _t.OpenWeatherMapTool
NewsApiTool = _t.NewsApiTool
AlphaVantageTool = _t.AlphaVantageTool

__all__ = [
    # Infrastructure
    "ToolCallRequest", "ToolCallResult", "ToolRegistry", "JsonSchema",
    "ToolNode", "create_tool_node", "store_tool_calls", "check_tools_condition",
    # Core built-ins
    "CalculatorTool", "WebRequestTool", "FilesTool",
    # Search
    "DuckDuckGoSearchTool", "TavilySearchTool", "SerpApiSearchTool",
    "GoogleSerperTool", "BraveSearchTool",
    # Knowledge
    "WikipediaTool", "ArxivTool", "PubMedTool", "WolframAlphaTool",
    # Code execution
    "PythonReplTool", "NodeJsReplTool", "ShellTool",
    # Extended file ops
    "CopyFileTool", "DeleteFileTool", "MoveFileTool", "FileSearchTool",
    # Data
    "JsonGetValueTool", "JsonListKeysTool", "CsvQueryTool",
    # Human
    "HumanInputTool",
    # Communication
    "GmailTool", "SlackTool",
    # External APIs
    "OpenWeatherMapTool", "NewsApiTool", "AlphaVantageTool",
]
