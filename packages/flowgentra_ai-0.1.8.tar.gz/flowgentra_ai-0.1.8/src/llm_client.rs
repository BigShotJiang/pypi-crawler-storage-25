//! Python bindings for LLM client — create_llm_client(), chat(), chat_with_tools()

use pyo3::prelude::*;
use std::sync::Arc;

use flowgentra_ai::core::llm::{
    create_llm_client, LLMClient, LLMConfig, LLMProvider, Message, ToolDefinition,
    CachedLLMClient, FallbackLLMClient, RetryLLMClient,
};

use crate::error::to_py_err;
use crate::llm::{PyLLMConfig, PyMessage, PyToolDefinition, PyTokenUsage};

// ─── PyLLMClient ────────────────────────────────────────────────────────────

/// An LLM client for sending messages and receiving responses.
///
/// Create from an LLMConfig:
///     config = LLMConfig("openai", "gpt-4", api_key="sk-...")
///     client = LLMClient.from_config(config)
///     response = client.chat([Message.user("Hello!")])
///     print(response.content)
#[pyclass(name = "LLMClient")]
pub struct PyLLMClient {
    pub(crate) inner: Arc<dyn LLMClient>,
}

#[pymethods]
impl PyLLMClient {
    /// Create an LLM client directly with provider and model parameters.
    ///
    /// If ``api_key`` is not provided the constructor resolves it automatically:
    ///
    /// 1. Checks the provider's conventional environment variable
    ///    (``OPENAI_API_KEY``, ``ANTHROPIC_API_KEY``, ``MISTRAL_API_KEY``,
    ///    ``GROQ_API_KEY``, ``HUGGINGFACEHUB_API_TOKEN``, ``AZURE_OPENAI_KEY``).
    /// 2. If not found, loads a ``.env`` file from the working directory and retries.
    ///
    /// A ``ValueError`` is raised only when the key is still missing after both steps.
    ///
    /// Args:
    ///     provider: Provider name ("openai", "anthropic", "mistral", "groq", "ollama", "huggingface", "azure")
    ///     model: Model identifier (e.g. "gpt-4", "claude-3-opus-20240229")
    ///     api_key: API key for the provider (optional — falls back to env var / .env)
    ///     temperature: Response randomness 0.0-2.0 (optional, default: 0.7)
    ///     max_tokens: Maximum response tokens (optional)
    ///     top_p: Nucleus sampling parameter 0.0-1.0 (optional)
    ///
    /// Example:
    ///     client = LLMClient(provider="anthropic", model="claude-opus-4-6")
    ///     response = client.chat([Message.user("Hello!")])
    #[new]
    #[pyo3(signature = (provider, model, api_key=None, temperature=None, max_tokens=None, top_p=None))]
    fn new(
        provider: &str,
        model: String,
        api_key: Option<String>,
        temperature: Option<f32>,
        max_tokens: Option<usize>,
        top_p: Option<f32>,
    ) -> PyResult<Self> {
        let llm_provider = match provider.to_lowercase().as_str() {
            "openai" => LLMProvider::OpenAI,
            "anthropic" => LLMProvider::Anthropic,
            "mistral" => LLMProvider::Mistral,
            "groq" => LLMProvider::Groq,
            "huggingface" => LLMProvider::HuggingFace,
            "ollama" => LLMProvider::Ollama,
            "azure" => LLMProvider::Azure,
            other => LLMProvider::Custom(other.to_string()),
        };

        // Resolve key: explicit arg → env var → .env file → error
        let key = match api_key {
            Some(k) if !k.is_empty() => k,
            _ => match llm_provider.env_var() {
                None => String::new(), // Ollama / custom — no key needed
                Some(var) => {
                    // 1. Process environment
                    std::env::var(var).unwrap_or_else(|_| {
                        // 2. .env file in the working directory
                        let _ = dotenv::dotenv();
                        std::env::var(var).unwrap_or_default()
                    })
                }
            },
        };

        let requires_key = !matches!(llm_provider, LLMProvider::Ollama | LLMProvider::Custom(_));
        if requires_key && key.is_empty() {
            let var_name = llm_provider.env_var().unwrap_or("API_KEY");
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "No API key found for provider '{}'. \
                 Pass api_key=... or set the {} environment variable (or add it to a .env file).",
                provider, var_name
            )));
        }

        let mut config = LLMConfig::new(llm_provider, model, key);
        config.temperature = temperature;
        config.max_tokens = max_tokens;
        config.top_p = top_p;
        let client = create_llm_client(&config).map_err(to_py_err)?;
        Ok(PyLLMClient { inner: client })
    }

    /// Create an LLM client from config.
    ///
    /// This is useful if you want to create and reuse the same config.
    ///
    /// Example:
    ///     config = LLMConfig("openai", "gpt-4", api_key="sk-...")
    ///     client = LLMClient.from_config(config)
    #[staticmethod]
    fn from_config(config: &PyLLMConfig) -> PyResult<Self> {
        let client = create_llm_client(&config.inner).map_err(to_py_err)?;
        Ok(PyLLMClient { inner: client })
    }

    /// Send messages and get a response.
    ///
    /// Args:
    ///     messages: List of Message objects
    ///
    /// Returns:
    ///     A Message with the LLM's response
    fn chat(&self, messages: Vec<PyMessage>) -> PyResult<PyMessage> {
        let msgs: Vec<Message> = messages.into_iter().map(|m| m.inner).collect();
        let result = crate::run_async(self.inner.chat(msgs)).map_err(to_py_err)?;
        Ok(PyMessage { inner: result })
    }

    /// Send messages and get a response with token usage stats.
    ///
    /// Returns:
    ///     Tuple of (Message, optional TokenUsage)
    fn chat_with_usage(
        &self,
        py: Python<'_>,
        messages: Vec<PyMessage>,
    ) -> PyResult<(PyMessage, PyObject)> {
        let msgs: Vec<Message> = messages.into_iter().map(|m| m.inner).collect();
        
        let (msg, usage) = crate::run_async(self.inner.chat_with_usage(msgs)).map_err(to_py_err)?;
        
        let py_usage = match usage {
            Some(u) => PyTokenUsage {
                inner: u,
            }
            .into_py(py),
            None => py.None(),
        };
        Ok((PyMessage { inner: msg }, py_usage))
    }

    /// Send messages with tool definitions and get a response (function calling).
    ///
    /// Args:
    ///     messages: List of Message objects
    ///     tools: List of ToolDefinition objects
    ///
    /// Returns:
    ///     A Message (may contain tool_calls)
    fn chat_with_tools(
        &self,
        messages: Vec<PyMessage>,
        tools: Vec<PyToolDefinition>,
    ) -> PyResult<PyMessage> {
        let msgs: Vec<Message> = messages.into_iter().map(|m| m.inner).collect();
        let tool_defs: Vec<ToolDefinition> = tools.into_iter().map(|t| t.inner).collect();
        
        let result = crate::run_async(self.inner.chat_with_tools(msgs, &tool_defs)).map_err(to_py_err)?;
        
        Ok(PyMessage { inner: result })
    }

    /// Wrap this client with a response cache.
    ///
    /// Example:
    ///     cached = client.cached(max_entries=1000)
    #[pyo3(signature = (max_entries=100))]
    fn cached(&self, max_entries: usize) -> Self {
        let cached = CachedLLMClient::new(self.inner.clone()).with_max_entries(max_entries);
        PyLLMClient {
            inner: Arc::new(cached),
        }
    }

    /// Create a fallback client that tries this client first, then falls back.
    ///
    /// Example:
    ///     robust = primary.with_fallback(secondary)
    fn with_fallback(&self, fallback: &PyLLMClient) -> Self {
        let fb = FallbackLLMClient::new(self.inner.clone())
            .with_fallback(fallback.inner.clone());
        PyLLMClient {
            inner: Arc::new(fb),
        }
    }

    /// Wrap this client with automatic retry and exponential backoff.
    ///
    /// Example:
    ///     retrying = client.with_retry(max_retries=3)
    #[pyo3(signature = (max_retries=3))]
    fn with_retry(&self, max_retries: u32) -> Self {
        let retry = RetryLLMClient::new(self.inner.clone(), max_retries);
        PyLLMClient {
            inner: Arc::new(retry),
        }
    }

    fn __repr__(&self) -> String {
        "LLMClient(...)".to_string()
    }
}

// ─── Standalone create_llm_client function ───────────────────────────────────

/// Create an LLM client from a config object.
///
/// This mirrors the Rust ``create_llm_client()`` function and is the
/// recommended factory when you already have an ``LLMConfig``.
///
/// Example::
///
///     from flowgentra_ai.llm import LLMConfig, create_llm_client
///
///     config = LLMConfig(model="gpt-4", provider="openai", api_key="sk-...")
///     client = create_llm_client(config)
///     response = client.chat([Message.user("Hello!")])
#[pyfunction]
pub fn py_create_llm_client(config: &PyLLMConfig) -> PyResult<PyLLMClient> {
    let client = create_llm_client(&config.inner).map_err(to_py_err)?;
    Ok(PyLLMClient { inner: client })
}
