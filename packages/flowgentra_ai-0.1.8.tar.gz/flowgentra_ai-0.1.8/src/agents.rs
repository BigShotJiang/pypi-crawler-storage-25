//! Python bindings for prebuilt agents (AgentBuilder, AgentType, GraphBasedAgent,
//! and typed constructors ZeroShotReAct / FewShotReAct / Conversational / …)

use pyo3::prelude::*;

use flowgentra_ai::core::agents::{
    AgentBuilder, AgentType, Conversational as RsConversational, FewShotReAct as RsFewShotReAct,
    GraphBasedAgent, ReactDocstore as RsReactDocstore, SelfAskWithSearch as RsSelfAskWithSearch,
    StructuredChat as RsStructuredChat, ToolCalling as RsToolCalling, ToolSpec,
    ZeroShotReAct as RsZeroShotReAct,
};

use crate::error::to_py_err;

// ─── PyAgentType ────────────────────────────────────────────────────────────

/// Agent type: "zero_shot_react", "few_shot_react", or "conversational".
#[pyclass(name = "AgentType")]
#[derive(Clone)]
pub struct PyAgentType {
    pub(crate) inner: AgentType,
}

#[pymethods]
impl PyAgentType {
    /// Zero-shot ReAct agent (reasoning + action without examples).
    #[staticmethod]
    fn zero_shot_react() -> Self {
        PyAgentType { inner: AgentType::ZeroShotReAct }
    }

    /// Few-shot ReAct agent (with example demonstrations).
    #[staticmethod]
    fn few_shot_react() -> Self {
        PyAgentType { inner: AgentType::FewShotReAct }
    }

    /// Conversational agent (multi-turn dialogue with memory).
    #[staticmethod]
    fn conversational() -> Self {
        PyAgentType { inner: AgentType::Conversational }
    }

    /// Tool Calling agent — uses the provider's native function/tool-calling API.
    ///
    /// Supported by OpenAI, Anthropic, Mistral, Groq, and OpenAI-compatible providers.
    /// Tools are passed as structured `ToolDefinition`s; the LLM responds with structured
    /// tool calls instead of text `<action>` tags.
    ///
    /// Equivalent to LangChain's ``tool-calling`` agent.
    #[staticmethod]
    fn tool_calling() -> Self {
        PyAgentType { inner: AgentType::ToolCalling }
    }

    /// Structured Chat Zero-Shot ReAct agent — ReAct with JSON-blob actions.
    ///
    /// The LLM communicates tool calls as:
    ///
    ///     {"action": "tool_name", "action_input": "..."}
    ///
    /// The final answer is:
    ///
    ///     {"action": "Final Answer", "action_input": "your answer"}
    ///
    /// Equivalent to LangChain's ``structured-chat-zero-shot-react-description`` agent.
    #[staticmethod]
    fn structured_chat_zero_shot_react() -> Self {
        PyAgentType {
            inner: AgentType::StructuredChatZeroShotReAct,
        }
    }

    /// Self Ask With Search agent — decomposes questions into sub-questions.
    ///
    /// Requires a tool named ``"search"`` registered via ``.with_tool()``.
    /// The agent iterates Follow-up → Intermediate answer until it reaches
    /// ``"So the final answer is: ..."``.
    ///
    /// Equivalent to LangChain's ``self-ask-with-search`` agent.
    #[staticmethod]
    fn self_ask_with_search() -> Self {
        PyAgentType { inner: AgentType::SelfAskWithSearch }
    }

    /// ReAct Docstore agent — Search + Lookup loop over a document store.
    ///
    /// Requires tools named ``"search"`` and ``"lookup"`` (or a single executor
    /// that dispatches on the tool name).  Actions use the format:
    ///
    ///     Action: Search[query]
    ///     Action: Lookup[term]
    ///     Action: Finish[answer]
    ///
    /// Equivalent to LangChain's ``react-docstore`` agent.
    #[staticmethod]
    fn react_docstore() -> Self {
        PyAgentType { inner: AgentType::ReactDocstore }
    }

    fn __repr__(&self) -> String {
        format!("AgentType({})", self.inner)
    }

    fn __str__(&self) -> String {
        self.inner.to_string()
    }
}

// ─── PyToolSpec ─────────────────────────────────────────────────────────────

/// Tool specification for prebuilt agents.
///
/// Example:
///     tool = ToolSpec("search", "Search the web")
///     tool.add_parameter("query", "string")
///     tool.set_required("query")
#[pyclass(name = "ToolSpec")]
#[derive(Clone)]
pub struct PyToolSpec {
    pub(crate) inner: ToolSpec,
}

#[pymethods]
impl PyToolSpec {
    #[new]
    fn new(name: &str, description: &str) -> Self {
        PyToolSpec {
            inner: ToolSpec::new(name, description),
        }
    }

    /// Add a parameter with its type.
    fn add_parameter(&mut self, name: &str, param_type: &str) {
        self.inner.parameters.insert(name.to_string(), param_type.to_string());
    }

    /// Mark a parameter as required.
    fn set_required(&mut self, param: &str) {
        self.inner.required.push(param.to_string());
    }

    #[getter]
    fn name(&self) -> String {
        self.inner.name.clone()
    }

    #[getter]
    fn description(&self) -> String {
        self.inner.description.clone()
    }

    fn __repr__(&self) -> String {
        format!("ToolSpec(name='{}', desc='{}')", self.inner.name, self.inner.description)
    }
}

// ─── PyAgentBuilder ─────────────────────────────────────────────────────────

/// Builder for creating prebuilt agents (similar to LangChain's initialize_agent).
///
/// Example:
///     builder = AgentBuilder(AgentType.zero_shot_react())
///     builder.with_name("my_agent")
///     builder.with_llm_config("gpt-4")
///     builder.with_system_prompt("You are a helpful assistant")
///     agent = builder.build_graph()
///     result = agent.execute_input("What is 2+2?")
#[pyclass(name = "AgentBuilder")]
pub struct PyAgentBuilder {
    inner: AgentBuilder,
}

#[pymethods]
impl PyAgentBuilder {
    #[new]
    fn new(agent_type: &PyAgentType) -> Self {
        PyAgentBuilder {
            inner: AgentBuilder::new(agent_type.inner),
        }
    }

    fn with_name(&mut self, name: &str) {
        self.inner = std::mem::take(&mut self.inner).with_name(name);
    }

    fn with_llm_config(&mut self, model: &str) {
        self.inner = std::mem::take(&mut self.inner).with_llm_config(model);
    }

    fn with_temperature(&mut self, temperature: f32) {
        self.inner = std::mem::take(&mut self.inner).with_temperature(temperature);
    }

    fn with_max_tokens(&mut self, tokens: usize) {
        self.inner = std::mem::take(&mut self.inner).with_max_tokens(tokens);
    }

    fn with_tool(&mut self, tool: &PyToolSpec) {
        self.inner = std::mem::take(&mut self.inner).with_tool(tool.inner.clone());
    }

    fn with_system_prompt(&mut self, prompt: &str) {
        self.inner = std::mem::take(&mut self.inner).with_system_prompt(prompt);
    }

    fn with_memory_steps(&mut self, steps: usize) {
        self.inner = std::mem::take(&mut self.inner).with_memory_steps(steps);
    }

    fn with_evaluation(&mut self) {
        self.inner = std::mem::take(&mut self.inner).with_evaluation();
    }

    fn with_retries(&mut self, max_retries: usize) {
        self.inner = std::mem::take(&mut self.inner).with_retries(max_retries);
    }

    fn with_param(&mut self, key: &str, value: &str) {
        self.inner = std::mem::take(&mut self.inner).with_param(key, value);
    }

    /// Build the agent as a graph-based agent.
    fn build_graph(&mut self) -> PyResult<PyGraphBasedAgent> {
        let builder = std::mem::take(&mut self.inner);
        let agent = builder.build_graph().map_err(to_py_err)?;
        Ok(PyGraphBasedAgent { inner: agent })
    }

    fn __repr__(&self) -> String {
        "AgentBuilder(...)".to_string()
    }
}

// ─── PyGraphBasedAgent ──────────────────────────────────────────────────────

/// A graph-based prebuilt agent (ReAct, Conversational, etc.).
///
/// Execute with `execute_input()` for simple string in/out.
#[pyclass(name = "GraphBasedAgent")]
pub struct PyGraphBasedAgent {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyGraphBasedAgent {
    /// Execute the agent with a text input and get a text response.
    fn execute_input(&self, input: &str) -> PyResult<String> {
        let result = 
            crate::run_async(self.inner.execute_input(input))
            .map_err(to_py_err)?;
        Ok(result)
    }

    /// Get the agent name.
    #[getter]
    fn name(&self) -> String {
        self.inner.config().name.clone()
    }

    /// Get node names of the underlying graph.
    fn node_names(&self) -> Vec<String> {
        self.inner.graph().node_names()
    }

    fn __repr__(&self) -> String {
        format!("GraphBasedAgent(name='{}')", self.inner.config().name)
    }
}

// ── Typed agent constructors ──────────────────────────────────────────────────
//
// Each class accepts keyword arguments and builds the underlying graph agent
// immediately, exposing the same execute_input / name / node_names interface.
//
//   agent = ZeroShotReAct(name="my-agent", llm=llm_cfg, retries=2, tools=[search])
//   result = agent.execute_input("What is 2+2?")

/// Helper: convert a Python list of PyToolSpec into Rust ToolSpec values and
/// feed them into the typed builder.
macro_rules! apply_common_args {
    ($builder:expr, $name:expr, $llm:expr, $system_prompt:expr,
     $tools:expr, $retries:expr, $memory_steps:expr) => {{
        let mut b = $builder.name($name).llm($llm.inner.clone()).retries($retries);
        if let Some(prompt) = $system_prompt {
            b = b.system_prompt(prompt);
        }
        if let Some(ts) = $tools {
            for t in ts {
                b = b.tool(t.inner.clone());
            }
        }
        if let Some(steps) = $memory_steps {
            b = b.memory_steps(steps);
        }
        b
    }};
}

// ─── ZeroShotReAct ──────────────────────────────────────────────────────────

/// Zero-shot ReAct agent — general-purpose reasoning + action without examples.
///
/// Example::
///
///     from flowgentra_ai.agent import ZeroShotReAct
///     from flowgentra_ai.llm import LLMConfig
///
///     llm = LLMConfig("openai", "gpt-4")
///     agent = ZeroShotReAct(name="assistant", llm=llm, retries=2, tools=[search])
///     result = agent.execute_input("What is the capital of France?")
#[pyclass(name = "ZeroShotReAct")]
pub struct PyZeroShotReAct {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyZeroShotReAct {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsZeroShotReAct::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ZeroShotReAct(name='{}')", self.inner.config().name)
    }
}

// ─── FewShotReAct ───────────────────────────────────────────────────────────

/// Few-shot ReAct agent — same as ZeroShotReAct with example demonstrations.
#[pyclass(name = "FewShotReAct")]
pub struct PyFewShotReAct {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyFewShotReAct {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsFewShotReAct::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("FewShotReAct(name='{}')", self.inner.config().name)
    }
}

// ─── Conversational ─────────────────────────────────────────────────────────

/// Conversational agent — multi-turn dialogue with persistent conversation history.
#[pyclass(name = "Conversational")]
pub struct PyConversational {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyConversational {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsConversational::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("Conversational(name='{}')", self.inner.config().name)
    }
}

// ─── ToolCalling ────────────────────────────────────────────────────────────

/// Tool-calling agent — uses the provider's native function-calling API.
#[pyclass(name = "ToolCalling")]
pub struct PyToolCalling {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyToolCalling {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsToolCalling::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ToolCalling(name='{}')", self.inner.config().name)
    }
}

// ─── StructuredChat ─────────────────────────────────────────────────────────

/// Structured-chat agent — ReAct with JSON-blob tool actions and a JSON final answer.
#[pyclass(name = "StructuredChat")]
pub struct PyStructuredChat {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyStructuredChat {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsStructuredChat::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("StructuredChat(name='{}')", self.inner.config().name)
    }
}

// ─── SelfAskWithSearch ──────────────────────────────────────────────────────

/// Self-ask-with-search agent — decomposes questions via a `search` tool.
#[pyclass(name = "SelfAskWithSearch")]
pub struct PySelfAskWithSearch {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PySelfAskWithSearch {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsSelfAskWithSearch::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("SelfAskWithSearch(name='{}')", self.inner.config().name)
    }
}

// ─── ReactDocstore ──────────────────────────────────────────────────────────

/// ReAct docstore agent — Search + Lookup loop over a document store.
#[pyclass(name = "ReactDocstore")]
pub struct PyReactDocstore {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyReactDocstore {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &crate::llm::PyLLMConfig,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let builder = apply_common_args!(
            RsReactDocstore::new(), name, llm, system_prompt, tools, retries, memory_steps
        );
        Ok(Self { inner: builder.build().map_err(to_py_err)? })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.config().name.clone() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ReactDocstore(name='{}')", self.inner.config().name)
    }
}
