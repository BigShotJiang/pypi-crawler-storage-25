#!/usr/bin/env python3
"""
OmniCoder-9B 标杆测试 - 最终版本
使用新编译的二进制文件测试 moxing 核心功能
"""

import os
import sys
import time
import tempfile
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

console = Console()

OLLAMA_MODEL_PATH = Path.home() / ".ollama" / "models" / "blobs" / "sha256-550e8f7253c8e07997fbce2570d37259b69b0d21faf77e5ed518d4ee4c73d8b3"
CUDA_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-cuda-new" / "llama-server"
ROCM_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-rocm-new" / "llama-server"
VULKAN_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-vulkan-new" / "llama-server"
CPU_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-cpu-new" / "llama-server"

def test_imports():
    """测试所有导入"""
    console.print("\n[bold cyan]测试 1: 导入模块[/bold cyan]")
    
    try:
        from moxing import (
            Client, LlamaServer, ServerConfig,
            DeviceDetector, Device, BackendType,
            AutoRunner, quick_run, quick_server,
            BinaryManager, get_binary_manager,
        )
        console.print("[green]✓[/green] 所有模块导入成功")
        return True
    except Exception as e:
        console.print(f"[red]✗ 导入失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_binaries():
    """测试所有后端二进制文件"""
    console.print("\n[bold cyan]测试 2: 二进制文件检查[/bold cyan]")
    
    results = {}
    
    for backend, binary_path in [("CUDA", CUDA_BINARY), ("ROCm", ROCM_BINARY), ("Vulkan", VULKAN_BINARY), ("CPU", CPU_BINARY)]:
        if binary_path.exists():
            size_mb = binary_path.stat().st_size / 1024 / 1024
            console.print(f"[green]✓[/green] {backend}: {binary_path} ({size_mb:.1f} MB)")
            results[backend] = True
        else:
            console.print(f"[red]✗[/red] {backend}: 二进制文件不存在")
            results[backend] = False
    
    return all(results.values()), results

def test_model_file():
    """测试本地模型文件"""
    console.print("\n[bold cyan]测试 3: 检查本地 OmniCoder-9B 模型[/bold cyan]")
    
    if OLLAMA_MODEL_PATH.exists():
        size_mb = OLLAMA_MODEL_PATH.stat().st_size / 1024 / 1024
        console.print(f"[green]✓[/green] 模型文件存在: {OLLAMA_MODEL_PATH}")
        console.print(f"[green]✓[/green] 文件大小: {size_mb:.1f} MB")
        return True
    else:
        console.print(f"[red]✗[/red] 模型文件不存在: {OLLAMA_MODEL_PATH}")
        console.print("[yellow]请先使用 ollama pull carstenuhlig/omnicoder-9b[/yellow]")
        return False

def test_backend_server(backend_name, binary_path, port):
    """测试指定后端的服务器"""
    console.print(f"\n[bold cyan]测试 {backend_name} 后端[/bold cyan]")
    
    import subprocess
    import httpx
    
    if not binary_path.exists():
        console.print(f"[red]✗[/red] {backend_name} 二进制文件不存在")
        return False, None
    
    cmd = [
        str(binary_path),
        "-m", str(OLLAMA_MODEL_PATH),
        "--host", "127.0.0.1",
        "--port", str(port),
        "-c", "4096",
        "-ngl", "35" if backend_name != "CPU" else "0",
        "--log-disable"
    ]
    
    console.print(f"[blue]启动 {backend_name} 服务器...[/blue]")
    console.print(f"[dim]端口: {port}[/dim]")
    
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            cwd=str(binary_path.parent)
        )
        
        console.print(f"[blue]等待服务器就绪 (最多 60秒)...[/blue]")
        base_url = f"http://127.0.0.1:{port}"
        
        start_time = time.time()
        while time.time() - start_time < 60:
            try:
                resp = httpx.get(f"{base_url}/health", timeout=5)
                if resp.status_code == 200:
                    console.print(f"[green]✓[/green] {backend_name} 服务器就绪")
                    return True, process
            except:
                pass
            
            if process.poll() is not None:
                console.print(f"[red]✗[/red] {backend_name} 服务器启动失败")
                return False, None
            
            time.sleep(2)
        
        console.print(f"[red]✗[/red] {backend_name} 服务器启动超时")
        process.terminate()
        return False, None
        
    except Exception as e:
        console.print(f"[red]✗[/red] {backend_name} 服务器启动异常: {e}")
        return False, None

def test_inference(port, backend_name):
    """测试推理"""
    console.print(f"\n[bold cyan]测试 {backend_name} 推理[/bold cyan]")
    
    import httpx
    
    base_url = f"http://127.0.0.1:{port}"
    
    messages = [{"role": "user", "content": "What is 2+2?"}]
    
    console.print("[blue]发送推理请求...[/blue]")
    start_time = time.time()
    
    try:
        resp = httpx.post(
            f"{base_url}/v1/chat/completions",
            json={"messages": messages, "max_tokens": 50, "temperature": 0.7},
            timeout=30
        )
        
        elapsed = time.time() - start_time
        
        if resp.status_code == 200:
            data = resp.json()
            tokens = data.get("usage", {}).get("completion_tokens", 0)
            speed = tokens/elapsed if tokens > 0 and elapsed > 0 else 0
            
            console.print(f"[green]✓[/green] {backend_name} 推理成功")
            console.print(f"[blue]生成 tokens:[/blue] {tokens}")
            console.print(f"[blue]耗时:[/blue] {elapsed:.2f}s")
            console.print(f"[blue]速度:[/blue] {speed:.1f} tok/s")
            return True
        else:
            console.print(f"[red]✗[/red] {backend_name} 推理失败: {resp.status_code}")
            return False
            
    except Exception as e:
        console.print(f"[red]✗[/red] {backend_name} 推理异常: {e}")
        return False

def run_all_tests():
    """运行所有测试"""
    
    console.print(Panel.fit(
        "[bold cyan]MoXing OmniCoder-9B 标杆测试 - 最终版本[/bold cyan]\n"
        "测试所有后端的二进制文件和推理功能\n"
        "Python: /home/fred/miniconda3/envs/dev/bin/python",
        border_style="cyan"
    ))
    
    results = []
    servers = {}
    
    result = test_imports()
    results.append(("导入模块", result))
    
    result, backend_results = test_binaries()
    results.append(("二进制文件", result))
    
    result = test_model_file()
    results.append(("模型文件", result))
    
    if not all([r for _, r in results]):
        console.print("\n[red]前置测试失败，停止后续测试[/red]")
        return 1
    
    backends_to_test = [
        ("CUDA", CUDA_BINARY, 18088),
        ("ROCm", ROCM_BINARY, 18089),
        ("Vulkan", VULKAN_BINARY, 18090),
        ("CPU", CPU_BINARY, 18091),
    ]
    
    for backend_name, binary_path, port in backends_to_test:
        if not binary_path.exists():
            console.print(f"\n[yellow]跳过 {backend_name} 测试 (二进制不存在)[/yellow]")
            continue
        
        result, server = test_backend_server(backend_name, binary_path, port)
        results.append((f"{backend_name}服务器", result))
        
        if result and server:
            servers[backend_name] = (server, port)
            
            result = test_inference(port, backend_name)
            results.append((f"{backend_name}推理", result))
    
    for backend_name, (server, _) in servers.items():
        console.print(f"\n[blue]停止 {backend_name} 服务器...[/blue]")
        server.terminate()
        try:
            server.wait(timeout=5)
        except:
            server.kill()
        console.print(f"[green]✓[/green] {backend_name} 服务器已停止")
    
    console.print("\n" + "="*60)
    console.print("[bold]测试结果汇总:[/bold]")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "[green]✓ PASS[/green]" if result else "[red]✗ FAIL[/red]"
        console.print(f"{status} - {name}")
    
    console.print("\n" + "="*60)
    console.print(f"[bold]通过率:[/bold] {passed}/{total} ({passed/total*100:.0f}%)")
    
    if passed == total:
        console.print(Panel.fit(
            "[bold green]所有测试通过！[/bold green]\n"
            "moxing 可以正确运行 OmniCoder-9B 模型\n"
            "所有后端均正常工作",
            border_style="green"
        ))
        return 0
    else:
        console.print(Panel.fit(
            f"[bold red]{total - passed} 个测试失败[/bold red]",
            border_style="red"
        ))
        return 1

if __name__ == "__main__":
    sys.exit(run_all_tests())