#!/usr/bin/env python3
"""
OmniCoder-9B 标杆测试
测试 moxing 的核心功能，确保能正确运行模型
"""

import os
import sys
import time
import tempfile
from pathlib import Path

console = None

def setup():
    global console
    from rich.console import Console
    console = Console()
    
def test_imports():
    """测试所有导入"""
    console.print("\n[bold cyan]测试 1: 导入模块[/bold cyan]")
    
    try:
        from moxing import (
            Client, LlamaServer, ServerConfig,
            DeviceDetector, Device, BackendType,
            ModelDownloader, download_model,
            AutoRunner, quick_run, quick_server,
            BinaryManager, get_binary_manager,
        )
        console.print("[green]✓[/green] 所有模块导入成功")
        return True
    except Exception as e:
        console.print(f"[red]✗ 导入失败: {e}[/red]")
        return False

def test_binaries():
    """测试二进制文件"""
    console.print("\n[bold cyan]测试 2: 二进制文件检查[/bold cyan]")
    
    try:
        from moxing.binaries import get_binary_manager
        
        manager = get_binary_manager()
        console.print(f"[blue]后端:[/blue] {manager.backend}")
        console.print(f"[blue]平台:[/blue] {manager.platform_name}")
        
        if not manager.has_binaries():
            console.print("[yellow]! 二进制文件未安装，正在下载...[/yellow]")
            manager.download_binaries(progress=True)
        
        server_binary = manager.get_binary_path("llama-server")
        console.print(f"[green]✓[/green] llama-server: {server_binary}")
        
        if server_binary.exists():
            console.print(f"[green]✓[/green] 文件存在，大小: {server_binary.stat().st_size / 1024 / 1024:.1f} MB")
            return True
        else:
            console.print(f"[red]✗[/red] 文件不存在")
            return False
            
    except Exception as e:
        console.print(f"[red]✗ 二进制文件检查失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_device_detection():
    """测试设备检测"""
    console.print("\n[bold cyan]测试 3: 设备检测[/bold cyan]")
    
    try:
        from moxing.device import DeviceDetector
        
        detector = DeviceDetector()
        devices = detector.list_devices()
        
        console.print(f"[green]✓[/green] 检测到 {len(devices)} 个设备")
        
        for dev in devices:
            console.print(f"  - {dev.index}: {dev.name} ({dev.backend.value}, {dev.memory_gb:.1f}GB)")
        
        best = detector.get_best_device()
        if best:
            console.print(f"[green]✓[/green] 最佳设备: {best.name} ({best.backend.value})")
            return True
        else:
            console.print("[yellow]! 未找到 GPU，将使用 CPU[/yellow]")
            return True
            
    except Exception as e:
        console.print(f"[red]✗ 设备检测失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_model_download():
    """测试模型下载"""
    console.print("\n[bold cyan]测试 4: 下载 OmniCoder-9B 模型[/bold cyan]")
    
    try:
        from moxing.models import ModelDownloader
        
        downloader = ModelDownloader()
        model_id = "Tesslate/OmniCoder-9B-GGUF"
        filename = "OmniCoder-9B-Q4_K_M.gguf"
        
        console.print(f"[blue]模型:[/blue] {model_id}")
        console.print(f"[blue]文件:[/blue] {filename}")
        
        model_path = downloader.download(model_id, filename, progress=True)
        
        if model_path.exists():
            size_mb = model_path.stat().st_size / 1024 / 1024
            console.print(f"[green]✓[/green] 模型已下载: {model_path}")
            console.print(f"[green]✓[/green] 文件大小: {size_mb:.1f} MB")
            return True, model_path
        else:
            console.print(f"[red]✗[/red] 模型文件不存在")
            return False, None
            
    except Exception as e:
        console.print(f"[red]✗ 模型下载失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None

def test_server_start(model_path):
    """测试服务器启动"""
    console.print("\n[bold cyan]测试 5: 启动服务器[/bold cyan]")
    
    try:
        from moxing.server import LlamaServer, ServerConfig
        from moxing.device import DeviceDetector
        
        detector = DeviceDetector()
        best_device = detector.get_best_device()
        
        if best_device:
            console.print(f"[blue]使用设备:[/blue] {best_device.name} ({best_device.backend.value})")
            config = ServerConfig(
                model_path=model_path,
                device=best_device.id,
                backend=best_device.backend.value,
                port=18080,
                ctx_size=4096,
                n_gpu_layers=35,
            )
        else:
            console.print("[yellow]使用 CPU[/yellow]")
            config = ServerConfig(
                model_path=model_path,
                port=18080,
                ctx_size=2048,
                n_gpu_layers=0,
            )
        
        console.print("[blue]启动服务器...[/blue]")
        server = LlamaServer(config)
        server.start()
        
        console.print("[blue]等待服务器就绪...[/blue]")
        if server.wait_ready(timeout=60):
            console.print(f"[green]✓[/green] 服务器运行在: {server.base_url}")
            return True, server
        else:
            console.print("[red]✗[/red] 服务器启动超时")
            server.stop()
            return False, None
            
    except Exception as e:
        console.print(f"[red]✗ 服务器启动失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None

def test_inference(server):
    """测试推理"""
    console.print("\n[bold cyan]测试 6: 推理测试[/bold cyan]")
    
    try:
        from moxing.client import Client
        
        client = Client(server.base_url)
        
        messages = [
            {"role": "user", "content": "Write a Python function to calculate fibonacci numbers"}
        ]
        
        console.print("[blue]发送请求...[/blue]")
        start_time = time.time()
        
        response = client.chat_completion(
            messages=messages,
            max_tokens=200,
            temperature=0.7,
        )
        
        elapsed = time.time() - start_time
        
        if response and "choices" in response:
            content = response["choices"][0]["message"]["content"]
            tokens = response.get("usage", {}).get("completion_tokens", 0)
            
            console.print(f"[green]✓[/green] 推理成功")
            console.print(f"[blue]响应:[/blue]")
            console.print(Panel(content[:500], expand=False))
            console.print(f"[blue]生成 tokens:[/blue] {tokens}")
            console.print(f"[blue]耗时:[/blue] {elapsed:.2f}s")
            console.print(f"[blue]速度:[/blue] {tokens/elapsed:.1f} tokens/s")
            return True
        else:
            console.print("[red]✗[/red] 无效响应")
            return False
            
    except Exception as e:
        console.print(f"[red]✗ 推理失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_multiple_requests(server):
    """测试多次请求"""
    console.print("\n[bold cyan]测试 7: 多次请求测试[/bold cyan]")
    
    try:
        from moxing.client import Client
        
        client = Client(server.base_url)
        
        prompts = [
            "What is 2+2?",
            "Name three programming languages",
            "Write a haiku about coding"
        ]
        
        for i, prompt in enumerate(prompts, 1):
            messages = [{"role": "user", "content": prompt}]
            
            start = time.time()
            response = client.chat_completion(
                messages=messages,
                max_tokens=100,
                temperature=0.7,
            )
            elapsed = time.time() - start
            
            if response and "choices" in response:
                content = response["choices"][0]["message"]["content"]
                tokens = response.get("usage", {}).get("completion_tokens", 0)
                console.print(f"[green]✓[/green] 请求 {i}: {tokens} tokens, {elapsed:.2f}s, {tokens/elapsed:.1f} tok/s")
            else:
                console.print(f"[red]✗[/red] 请求 {i} 失败")
                return False
        
        console.print("[green]✓[/green] 所有请求成功")
        return True
        
    except Exception as e:
        console.print(f"[red]✗ 多次请求测试失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def run_all_tests():
    """运行所有测试"""
    from rich.console import Console
    from rich.panel import Panel
    global console
    console = Console()
    
    console.print(Panel.fit(
        "[bold cyan]MoXing OmniCoder-9B 标杆测试[/bold cyan]\n"
        "测试 moxing 核心功能",
        border_style="cyan"
    ))
    
    results = []
    model_path = None
    server = None
    
    tests = [
        ("导入模块", test_imports),
        ("二进制文件", test_binaries),
        ("设备检测", test_device_detection),
    ]
    
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            console.print(f"[red]✗ {name} 异常: {e}[/red]")
            results.append((name, False))
    
    result, path = test_model_download()
    results.append(("模型下载", result))
    if result:
        model_path = path
    
    if model_path:
        result, srv = test_server_start(model_path)
        results.append(("服务器启动", result))
        if result:
            server = srv
            
            result = test_inference(server)
            results.append(("推理测试", result))
            
            result = test_multiple_requests(server)
            results.append(("多次请求", result))
    
    if server:
        console.print("\n[blue]停止服务器...[/blue]")
        server.stop()
        console.print("[green]✓[/green] 服务器已停止")
    
    console.print("\n" + "="*60)
    console.print("[bold]测试结果:[/bold]")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "[green]✓ PASS[/green]" if result else "[red]✗ FAIL[/red]"
        console.print(f"{status} - {name}")
    
    console.print("\n" + "="*60)
    console.print(f"[bold]通过率:[/bold] {passed}/{total} ({passed/total*100:.0f}%)")
    
    if passed == total:
        console.print(Panel.fit(
            "[bold green]所有测试通过！[/bold green]",
            border_style="green"
        ))
        return 0
    else:
        console.print(Panel.fit(
            f"[bold red]{total - passed} 个测试失败[/bold red]",
            border_style="red"
        ))
        return 1

if __name__ == "__main__":
    sys.exit(run_all_tests())