#!/usr/bin/env python3
import subprocess
import time
import requests
import sys

MODEL = "/usr/share/ollama/.ollama/models/blobs/sha256-550e8f7253c8e07997fbce2570d37259b69b0d21faf77e5ed518d4ee4c73d8b3"
CTX = 4096

QUESTIONS = [
    ("Q1-计算", "What is 25 * 4?", 30),
    ("Q2-知识", "What is the capital of Japan?", 50),
    ("Q3-代码", "Write a Python function to check prime.", 80),
]

BACKENDS = [
    ("ROCm", "gpu1", "rocm", "RX 7900 XTX"),
    ("Vulkan", "gpu1", "vulkan", "RX 7900 XTX"),
    ("CUDA", "gpu0", "cuda", "RTX 4070"),
    ("Vulkan", "gpu0", "vulkan", "RTX 4070"),
    ("ROCm", "gpu2", "rocm", "Radeon 610M"),
    ("Vulkan", "gpu2", "vulkan", "Radeon 610M"),
    ("CPU", "cpu", "cpu", "7945HX"),
]

def wait_server(port, timeout=60):
    for i in range(timeout):
        try:
            r = requests.get(f"http://localhost:{port}/health", timeout=2)
            if r.status_code == 200:
                return True
        except:
            pass
        time.sleep(1)
    return False

def test_inference(port, question, max_tokens):
    try:
        start = time.time()
        r = requests.post(
            f"http://localhost:{port}/v1/chat/completions",
            json={
                "model": "test",
                "messages": [{"role": "user", "content": question}],
                "max_tokens": max_tokens
            },
            timeout=60
        )
        elapsed = time.time() - start
        
        if r.status_code == 200:
            data = r.json()
            tokens = data.get("usage", {}).get("completion_tokens", 0)
            speed = tokens / elapsed if elapsed > 0 else 0
            return tokens, speed, elapsed
        else:
            return 0, 0, 0
    except Exception as e:
        print(f"    Error: {e}")
        return 0, 0, 0

print("=" * 70)
print("MoXing Backend Speed Test")
print(f"Model: omnicoder-9b, Context: {CTX}")
print("=" * 70)

results = []
port = 9700

for backend_name, device, backend, device_name in BACKENDS:
    print(f"\n--- {backend_name} on {device_name} ({device}) ---")
    
    cmd = [
        "moxing", "serve", MODEL,
        "-d", device,
        "-b", backend,
        "-c", str(CTX),
        "--port", str(port)
    ]
    
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    if not wait_server(port):
        print("  Server failed to start!")
        proc.kill()
        continue
    
    speeds = []
    for qname, question, max_tok in QUESTIONS:
        tokens, speed, elapsed = test_inference(port, question, max_tok)
        speeds.append(speed)
        print(f"  {qname}: {tokens} tok, {speed:.1f} tok/s, {elapsed:.1f}s")
        time.sleep(1)
    
    avg = sum(speeds) / len(speeds) if speeds else 0
    results.append((backend_name, device_name, speeds, avg))
    
    proc.terminate()
    proc.wait()
    port += 10
    time.sleep(3)

print("\n" + "=" * 70)
print("RESULTS TABLE (tokens/second)")
print("=" * 70)
print(f"\n{'Backend':<20} {'Device':<15} {'Q1':>8} {'Q2':>8} {'Q3':>8} {'Avg':>8}")
print("-" * 70)

for backend, device, speeds, avg in results:
    s = [f"{x:.1f}" for x in speeds]
    print(f"{backend:<20} {device:<15} {s[0]:>8} {s[1]:>8} {s[2]:>8} {avg:>8.1f}")

print("\n" + "=" * 70)
print("RANKING (by average speed)")
print("=" * 70)

ranking = sorted(results, key=lambda x: x[3], reverse=True)
for i, (b, d, s, a) in enumerate(ranking, 1):
    print(f"{i}. {b}/{d}: {a:.1f} tok/s")