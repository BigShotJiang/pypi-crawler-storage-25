#!/usr/bin/env python3
"""
Ollama 所有模型完整测试
使用基于 Ollama 补丁版本的 llama.cpp 测试所有本地模型
"""

import os
import sys
import time
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Tuple

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

CUDA_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-cuda-new" / "llama-server"
ROCM_BINARY = Path.home() / ".cache" / "moxing" / "binaries" / "linux-x64-rocm-new" / "llama-server"

def get_ollama_models():
    """获取所有 ollama 模型信息"""
    result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
    
    models = []
    for line in result.stdout.strip().split('\n')[1:]:  # Skip header
        parts = line.split()
        if len(parts) >= 3:
            name = parts[0]
            model_id = parts[1]
            size_str = parts[2]
            
            # 获取模型路径
            show_result = subprocess.run(
                ["ollama", "show", name, "--modelfile"],
                capture_output=True,
                text=True
            )
            
            for line in show_result.stdout.split('\n'):
                if line.startswith("FROM /"):
                    path = line.split()[1]
                    models.append({
                        "name": name,
                        "id": model_id,
                        "size": size_str,
                        "path": path
                    })
                    break
    
    return models

def select_backend_for_model(model_size_gb: float) -> Tuple[Path, str]:
    """根据模型大小选择最佳后端"""
    if model_size_gb > 20:  # 大模型用 ROCm (24GB VRAM)
        return ROCM_BINARY, "ROCm"
    elif model_size_gb > 8:  # 中等模型用 ROCm 或 CUDA
        return ROCM_BINARY, "ROCm"
    else:  # 小模型可以用 CUDA
        return CUDA_BINARY, "CUDA"

def parse_size_to_gb(size_str: str) -> float:
    """将大小字符串转换为 GB"""
    size_str = size_str.lower()
    if 'gb' in size_str:
        return float(size_str.replace('gb', '').strip())
    elif 'mb' in size_str:
        return float(size_str.replace('mb', '').strip()) / 1024
    elif 'kb' in size_str:
        return float(size_str.replace('kb', '').strip()) / 1024 / 1024
    else:
        try:
            return float(size_str)  # 默认 GB
        except:
            return 0

def test_model(model_info: Dict, port: int, test_prompt: str = "What is 2+2?") -> Dict:
    """测试单个模型"""
    import httpx
    
    model_name = model_info["name"]
    model_path = model_info["path"]
    size_gb = parse_size_to_gb(model_info["size"])
    
    binary, backend_name = select_backend_for_model(size_gb)
    
    if not binary.exists():
        return {
            "model": model_name,
            "success": False,
            "error": f"{backend_name} binary not found",
            "backend": backend_name
        }
    
    # 计算合适的参数
    ctx_size = 4096 if size_gb < 10 else 2048 if size_gb < 20 else 1024
    gpu_layers = min(35, int(size_gb * 3))  # 根据模型大小估算
    
    console.print(f"\n[cyan]测试模型: {model_name}[/cyan]")
    console.print(f"[dim]大小: {model_info['size']} ({size_gb:.1f} GB)[/dim]")
    console.print(f"[dim]后端: {backend_name}[/dim]")
    console.print(f"[dim]参数: ctx={ctx_size}, gpu_layers={gpu_layers}[/dim]")
    
    cmd = [
        str(binary),
        "-m", model_path,
        "--host", "127.0.0.1",
        "--port", str(port),
        "-c", str(ctx_size),
        "-ngl", str(gpu_layers),
        "--log-disable"
    ]
    
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            cwd=str(binary.parent)
        )
        
        base_url = f"http://127.0.0.1:{port}"
        
        # 等待服务器启动（大模型需要更长时间）
        max_wait = 120 if size_gb > 20 else 90 if size_gb > 10 else 60
        
        console.print(f"[blue]等待服务器启动 (最多 {max_wait}s)...[/blue]")
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            try:
                resp = httpx.get(f"{base_url}/health", timeout=5)
                if resp.status_code == 200:
                    console.print(f"[green]✓[/green] 服务器就绪")
                    break
            except:
                pass
            
            if process.poll() is not None:
                stderr = process.stderr.read().decode() if process.stderr else ""
                return {
                    "model": model_name,
                    "success": False,
                    "error": f"Server crashed: {stderr[:200]}",
                    "backend": backend_name
                }
            
            time.sleep(2)
        
        if time.time() - start_time >= max_wait:
            process.terminate()
            return {
                "model": model_name,
                "success": False,
                "error": "Server startup timeout",
                "backend": backend_name
            }
        
        # 测试推理
        console.print(f"[blue]测试推理...[/blue]")
        inference_start = time.time()
        
        resp = httpx.post(
            f"{base_url}/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": test_prompt}],
                "max_tokens": 50,
                "temperature": 0.7
            },
            timeout=30
        )
        
        inference_time = time.time() - inference_start
        
        process.terminate()
        
        if resp.status_code == 200:
            data = resp.json()
            tokens = data.get("usage", {}).get("completion_tokens", 0)
            speed = tokens / inference_time if tokens > 0 else 0
            
            console.print(f"[green]✓[/green] 推理成功: {tokens} tokens, {inference_time:.2f}s, {speed:.1f} tok/s")
            
            return {
                "model": model_name,
                "success": True,
                "backend": backend_name,
                "tokens": tokens,
                "time": inference_time,
                "speed": speed,
                "size_gb": size_gb
            }
        else:
            return {
                "model": model_name,
                "success": False,
                "error": f"Inference failed: {resp.status_code}",
                "backend": backend_name
            }
            
    except Exception as e:
        if process:
            process.terminate()
        return {
            "model": model_name,
            "success": False,
            "error": str(e),
            "backend": backend_name
        }

def run_full_test():
    """运行完整测试"""
    
    console.print(Panel.fit(
        "[bold cyan]Ollama 所有模型完整测试[/bold cyan]\n"
        "使用基于 Ollama 补丁版本的 llama.cpp\n"
        "测试所有本地模型的推理性能",
        border_style="cyan"
    ))
    
    console.print("\n[cyan]获取模型列表...[/cyan]")
    models = get_ollama_models()
    
    # 筛选主要模型
    test_models = []
    keywords = ["gemma4", "gemma3", "qwen3.5", "qwen3", "omnicoder", "translategemma"]
    
    for model in models:
        name = model["name"].lower()
        if any(kw in name for kw in keywords) and "embedding" not in name:
            test_models.append(model)
    
    console.print(f"[green]找到 {len(test_models)} 个模型[/green]")
    
    # 显示模型列表
    table = Table(title="测试模型列表")
    table.add_column("模型名称", style="cyan")
    table.add_column("大小", style="blue")
    table.add_column("路径", style="dim")
    
    for model in test_models:
        table.add_row(model["name"], model["size"], Path(model["path"]).name[:30] + "...")
    
    console.print(table)
    
    # 开始测试
    console.print("\n[bold cyan]开始测试[/bold cyan]")
    
    results = []
    port = 18092
    
    for i, model in enumerate(test_models):
        console.print(f"\n[bold]进度: {i+1}/{len(test_models)}[/bold]")
        
        result = test_model(model, port + i)
        results.append(result)
        
        # 清理进程
        subprocess.run(["pkill", "-f", f"--port {port + i}"], capture_output=True)
        
        # 等待端口释放
        time.sleep(2)
    
    # 显示结果
    console.print("\n" + "="*60)
    console.print("[bold]测试结果汇总[/bold]")
    
    result_table = Table(title="性能测试结果")
    result_table.add_column("模型", style="cyan")
    result_table.add_column("后端", style="blue")
    result_table.add_column("状态", style="bold")
    result_table.add_column("Tokens", style="green")
    result_table.add_column("时间(s)", style="yellow")
    result_table.add_column("速度(tok/s)", style="magenta")
    result_table.add_column("错误", style="red")
    
    for r in results:
        status = "[green]✓[/green]" if r["success"] else "[red]✗[/red]"
        tokens = str(r.get("tokens", "-"))
        time_str = f"{r.get('time', 0):.2f}" if r.get("time") else "-"
        speed = f"{r.get('speed', 0):.1f}" if r.get("speed") else "-"
        error = r.get("error", "")[:30] if r.get("error") else ""
        
        result_table.add_row(
            r["model"],
            r.get("backend", ""),
            status,
            tokens,
            time_str,
            speed,
            error
        )
    
    console.print(result_table)
    
    # 统计
    passed = sum(1 for r in results if r["success"])
    total = len(results)
    
    console.print(f"\n[bold]通过率: {passed}/{total} ({passed/total*100:.0f}%)[/bold]")
    
    # 保存结果
    result_file = Path("/home/fred/Documents/GitHub/cycleuser/MoXing/benchmark_results_ollama.json")
    with open(result_file, "w") as f:
        json.dump({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "results": results,
            "summary": {
                "passed": passed,
                "total": total,
                "pass_rate": f"{passed/total*100:.0f}%"
            }
        }, f, indent=2)
    
    console.print(f"\n[green]结果已保存: {result_file}[/green]")
    
    if passed == total:
        console.print(Panel.fit(
            "[bold green]所有模型测试通过！[/bold green]\n"
            f"成功测试 {passed} 个模型",
            border_style="green"
        ))
        return 0
    else:
        console.print(Panel.fit(
            f"[bold yellow]{passed}/{total} 模型测试通过[/bold yellow]\n"
            f"有 {total - passed} 个模型失败",
            border_style="yellow"
        ))
        return 1

if __name__ == "__main__":
    sys.exit(run_full_test())