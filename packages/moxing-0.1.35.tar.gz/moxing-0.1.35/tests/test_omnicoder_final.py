#!/usr/bin/env python3
"""
OmniCoder-9B 标杆测试 - 使用本地 Ollama 模型
测试 moxing 的核心功能，确保能正确运行模型
"""

import os
import sys
import time
import tempfile
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

console = Console()

OLLAMA_MODEL_PATH = Path.home() / ".ollama" / "models" / "blobs" / "sha256-550e8f7253c8e07997fbce2570d37259b69b0d21faf77e5ed518d4ee4c73d8b3"

def test_imports():
    """测试所有导入"""
    console.print("\n[bold cyan]测试 1: 导入模块[/bold cyan]")
    
    try:
        from moxing import (
            Client, LlamaServer, ServerConfig,
            DeviceDetector, Device, BackendType,
            AutoRunner, quick_run, quick_server,
            BinaryManager, get_binary_manager,
        )
        console.print("[green]✓[/green] 所有模块导入成功")
        return True
    except Exception as e:
        console.print(f"[red]✗ 导入失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_binaries():
    """测试二进制文件"""
    console.print("\n[bold cyan]测试 2: 二进制文件检查[/bold cyan]")
    
    try:
        from moxing.binaries import get_binary_manager
        
        manager = get_binary_manager('cuda')
        console.print(f"[blue]后端:[/blue] {manager.backend}")
        console.print(f"[blue]平台:[/blue] {manager.platform_name}")
        
        if not manager.has_binaries():
            console.print("[yellow]! 二进制文件未安装，正在下载...[/yellow]")
            manager.download_binaries(progress=True)
        
        server_binary = manager.get_binary_path("llama-server")
        console.print(f"[green]✓[/green] llama-server: {server_binary}")
        
        if server_binary.exists():
            console.print(f"[green]✓[/green] 文件存在，大小: {server_binary.stat().st_size / 1024 / 1024:.1f} MB")
            return True, server_binary, manager
        else:
            console.print(f"[red]✗[/red] 文件不存在")
            return False, None, None
            
    except Exception as e:
        console.print(f"[red]✗ 二进制文件检查失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None, None

def test_device_detection():
    """测试设备检测"""
    console.print("\n[bold cyan]测试 3: 设备检测[/bold cyan]")
    
    try:
        from moxing.device import DeviceDetector
        
        detector = DeviceDetector()
        detector.detect()
        devices = detector.list_devices()
        
        if devices is None:
            console.print("[yellow]! list_devices 返回 None，调用 detect()[/yellow]")
            detector.detect()
            devices = detector.list_devices()
        
        console.print(f"[green]✓[/green] 检测到 {len(devices) if devices else 0} 个设备")
        
        if devices:
            for dev in devices:
                console.print(f"  - gpu{dev.index}: {dev.name} ({dev.backend.value}, {dev.memory_gb:.1f}GB)")
            
            best = detector.get_best_device()
            if best:
                console.print(f"[green]✓[/green] 最佳设备: {best.name} ({best.backend.value})")
                return True, best
            else:
                console.print("[yellow]! 未找到最佳 GPU，将使用 CPU[/yellow]")
                return True, None
        else:
            console.print("[yellow]! 未检测到设备[/yellow]")
            return True, None
            
    except Exception as e:
        console.print(f"[red]✗ 设备检测失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None

def test_model_file():
    """测试本地模型文件"""
    console.print("\n[bold cyan]测试 4: 检查本地 OmniCoder-9B 模型[/bold cyan]")
    
    try:
        if OLLAMA_MODEL_PATH.exists():
            size_mb = OLLAMA_MODEL_PATH.stat().st_size / 1024 / 1024
            console.print(f"[green]✓[/green] 模型文件存在: {OLLAMA_MODEL_PATH}")
            console.print(f"[green]✓[/green] 文件大小: {size_mb:.1f} MB")
            return True, OLLAMA_MODEL_PATH
        else:
            console.print(f"[red]✗[/red] 模型文件不存在: {OLLAMA_MODEL_PATH}")
            console.print("[yellow]请先使用 ollama pull carstenuhlig/omnicoder-9b[/yellow]")
            return False, None
            
    except Exception as e:
        console.print(f"[red]✗ 模型文件检查失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None

def test_server_start(model_path, best_device, binary_manager):
    """测试服务器启动"""
    console.print("\n[bold cyan]测试 5: 启动服务器[/bold cyan]")
    
    try:
        from moxing.server import LlamaServer
        
        console.print("[blue]使用 CUDA 后端[/blue]")
        server = LlamaServer(
            model=str(model_path),
            device="gpu0",
            gpu_backend="cuda",
            port=18084,
            ctx_size=4096,
            n_gpu_layers=35,
            quiet=False,
        )
        
        console.print("[blue]启动服务器...[/blue]")
        console.print(f"[blue]配置:[/blue] port={server.port}, ctx={server.ctx_size}, gpu_layers={server.n_gpu_layers}")
        
        server.start()
        
        console.print("[blue]等待服务器就绪 (最多 180秒)...[/blue]")
        if server.wait_ready(timeout=180):
            console.print(f"[green]✓[/green] 服务器运行在: {server.base_url}")
            return True, server
        else:
            console.print("[red]✗[/red] 服务器启动超时")
            server.stop()
            return False, None
            
    except Exception as e:
        console.print(f"[red]✗ 服务器启动失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False, None

def test_inference(server):
    """测试推理"""
    console.print("\n[bold cyan]测试 6: 推理测试[/bold cyan]")
    
    try:
        from moxing.client import Client
        
        client = Client(server.base_url)
        
        messages = [
            {"role": "user", "content": "Write a Python function to calculate fibonacci numbers"}
        ]
        
        console.print("[blue]发送请求...[/blue]")
        start_time = time.time()
        
        response = client.chat_completion(
            messages=messages,
            max_tokens=200,
            temperature=0.7,
        )
        
        elapsed = time.time() - start_time
        
        if response and "choices" in response:
            content = response["choices"][0]["message"]["content"]
            tokens = response.get("usage", {}).get("completion_tokens", 0)
            
            console.print(f"[green]✓[/green] 推理成功")
            console.print(f"[blue]响应:[/blue]")
            console.print(Panel(content[:500], expand=False))
            console.print(f"[blue]生成 tokens:[/blue] {tokens}")
            console.print(f"[blue]耗时:[/blue] {elapsed:.2f}s")
            if tokens > 0 and elapsed > 0:
                console.print(f"[blue]速度:[/blue] {tokens/elapsed:.1f} tokens/s")
            return True
        else:
            console.print("[red]✗[/red] 无效响应")
            console.print(f"[yellow]响应内容: {response}[/yellow]")
            return False
            
    except Exception as e:
        console.print(f"[red]✗ 推理失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def test_multiple_requests(server):
    """测试多次请求"""
    console.print("\n[bold cyan]测试 7: 多次请求测试[/bold cyan]")
    
    try:
        from moxing.client import Client
        
        client = Client(server.base_url)
        
        prompts = [
            "What is 2+2?",
            "Name three programming languages",
            "Write a haiku about coding"
        ]
        
        for i, prompt in enumerate(prompts, 1):
            messages = [{"role": "user", "content": prompt}]
            
            start = time.time()
            response = client.chat_completion(
                messages=messages,
                max_tokens=100,
                temperature=0.7,
            )
            elapsed = time.time() - start
            
            if response and "choices" in response:
                content = response["choices"][0]["message"]["content"]
                tokens = response.get("usage", {}).get("completion_tokens", 0)
                speed = tokens/elapsed if tokens > 0 and elapsed > 0 else 0
                console.print(f"[green]✓[/green] 请求 {i}: {tokens} tokens, {elapsed:.2f}s, {speed:.1f} tok/s")
            else:
                console.print(f"[red]✗[/red] 请求 {i} 失败")
                return False
        
        console.print("[green]✓[/green] 所有请求成功")
        return True
        
    except Exception as e:
        console.print(f"[red]✗ 多次请求测试失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        return False

def run_all_tests():
    """运行所有测试"""
    
    console.print(Panel.fit(
        "[bold cyan]MoXing OmniCoder-9B 标杆测试[/bold cyan]\n"
        "使用本地 Ollama 模型测试 moxing 核心功能\n"
        "Python: /home/fred/miniconda3/envs/dev/bin/python",
        border_style="cyan"
    ))
    
    results = []
    model_path = None
    server = None
    best_device = None
    binary_manager = None
    
    tests = [
        ("导入模块", test_imports),
    ]
    
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            console.print(f"[red]✗ {name} 异常: {e}[/red]")
            results.append((name, False))
    
    result, binary, manager = test_binaries()
    results.append(("二进制文件", result))
    if result:
        binary_manager = manager
    
    result, device = test_device_detection()
    results.append(("设备检测", result))
    if result:
        best_device = device
    
    result, path = test_model_file()
    results.append(("模型文件", result))
    if result:
        model_path = path
    
    if model_path and binary_manager:
        result, srv = test_server_start(model_path, best_device, binary_manager)
        results.append(("服务器启动", result))
        if result:
            server = srv
            
            result = test_inference(server)
            results.append(("推理测试", result))
            
            result = test_multiple_requests(server)
            results.append(("多次请求", result))
    
    if server:
        console.print("\n[blue]停止服务器...[/blue]")
        server.stop()
        console.print("[green]✓[/green] 服务器已停止")
    
    console.print("\n" + "="*60)
    console.print("[bold]测试结果:[/bold]")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "[green]✓ PASS[/green]" if result else "[red]✗ FAIL[/red]"
        console.print(f"{status} - {name}")
    
    console.print("\n" + "="*60)
    console.print(f"[bold]通过率:[/bold] {passed}/{total} ({passed/total*100:.0f}%)")
    
    if passed == total:
        console.print(Panel.fit(
            "[bold green]所有测试通过！[/bold green]\n"
            "moxing 可以正确运行 OmniCoder-9B 模型",
            border_style="green"
        ))
        return 0
    else:
        console.print(Panel.fit(
            f"[bold red]{total - passed} 个测试失败[/bold red]",
            border_style="red"
        ))
        return 1

if __name__ == "__main__":
    sys.exit(run_all_tests())