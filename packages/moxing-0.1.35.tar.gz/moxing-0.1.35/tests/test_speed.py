#!/usr/bin/env python3
import subprocess
import time
import requests
import json

PORT = 8300

def start_server(device, backend, ctx):
    global PORT
    port = PORT
    PORT += 10
    
    cmd = f"moxing ollama serve gemma4:e4b -d {device} -b {backend} -c {ctx} -p {port}"
    proc = subprocess.Popen(cmd.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    for _ in range(60):
        try:
            if requests.get(f"http://localhost:{port}/health", timeout=1).status_code == 200:
                return proc, port
        except:
            pass
        time.sleep(1)
    
    proc.kill()
    return None, 0

def test_speed(port, question, max_tokens):
    try:
        start = time.time()
        r = requests.post(
            f"http://localhost:{port}/v1/chat/completions",
            json={"model": "test", "messages": [{"role": "user", "content": question}], "max_tokens": max_tokens},
            timeout=60
        )
        elapsed = time.time() - start
        
        if r.status_code == 200:
            tokens = r.json().get("usage", {}).get("completion_tokens", 0)
            speed = tokens / elapsed if elapsed > 0 else 0
            return tokens, speed, elapsed
    except:
        pass
    return 0, 0, 0

print("=" * 70)
print("MoXing Speed Test - gemma4:e4b (ctx=4096)")
print("=" * 70)

backends = [
    ("gpu1", "rocm", "RX 7900 XTX"),
    ("gpu1", "vulkan", "RX 7900 XTX"),
    ("gpu0", "cuda", "RTX 4070"),
    ("gpu0", "vulkan", "RTX 4070"),
    ("gpu2", "rocm", "Radeon 610M"),
    ("gpu2", "vulkan", "Radeon 610M"),
    ("cpu", "cpu", "7945HX"),
]

questions = [
    ("Q1", "What is 25 * 4?", 30),
    ("Q2", "What is the capital of Japan?", 50),
    ("Q3", "Write a Python function to check prime.", 80),
]

results = []

for device, backend, name in backends:
    print(f"\n--- {backend.upper()} on {name} ---")
    
    proc, port = start_server(device, backend, 4096)
    if not proc:
        print("  Server failed")
        continue
    
    speeds = []
    for qname, question, max_tok in questions:
        tokens, speed, elapsed = test_speed(port, question, max_tok)
        speeds.append(speed)
        print(f"  {qname}: {tokens} tok, {speed:.1f} tok/s, {elapsed:.1f}s")
        time.sleep(1)
    
    avg = sum(speeds) / len(speeds) if speeds else 0
    results.append((backend, name, speeds, avg))
    
    proc.terminate()
    proc.wait()
    time.sleep(3)

print("\n" + "=" * 70)
print("SUMMARY (tokens/second)")
print("=" * 70)
print(f"\n{'Backend':<20} {'Device':<15} {'Q1':>8} {'Q2':>8} {'Q3':>8} {'Avg':>8}")
print("-" * 70)

for backend, name, speeds, avg in results:
    s1, s2, s3 = [f"{x:.1f}" for x in speeds]
    print(f"{backend:<20} {name:<15} {s1:>8} {s2:>8} {s3:>8} {avg:>8.1f}")

print("\nRANKING:")
ranking = sorted(results, key=lambda x: x[3], reverse=True)
for i, (b, n, s, a) in enumerate(ranking, 1):
    print(f"{i}. {b}/{n}: {a:.1f} tok/s")