#!/usr/bin/env python3
"""
使用 Ollama 补丁版本的 llama.cpp 测试所有 Ollama 模型
"""

import os
import sys
import time
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Tuple

from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

CUDA_BINARY = Path("/home/fred/Documents/GitHub/cycleuser/MoXing/binaries_ollama/linux-x64-cuda/llama-server")
ROCM_BINARY = Path("/home/fred/Documents/GitHub/cycleuser/MoXing/binaries_ollama/linux-x64-rocm/llama-server")
CPU_BINARY = Path("/home/fred/Documents/GitHub/cycleuser/MoXing/binaries_ollama/linux-x64-cpu/llama-server")

def get_ollama_models():
    """获取所有 ollama 模型"""
    result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
    
    models = []
    for line in result.stdout.strip().split('\n')[1:]:
        parts = line.split()
        if len(parts) >= 3:
            name = parts[0]
            model_id = parts[1]
            size_str = parts[2]
            
            show_result = subprocess.run(
                ["ollama", "show", name, "--modelfile"],
                capture_output=True,
                text=True
            )
            
            for line in show_result.stdout.split('\n'):
                if line.startswith("FROM /"):
                    path = line.split()[1]
                    models.append({
                        "name": name,
                        "id": model_id,
                        "size": size_str,
                        "path": path
                    })
                    break
    
    return models

def select_backend(model_size_gb: float) -> Tuple[Path, str]:
    """根据模型大小选择后端"""
    if model_size_gb > 20:
        return ROCM_BINARY, "ROCm"
    elif model_size_gb > 8:
        return ROCM_BINARY, "ROCm"
    else:
        return CUDA_BINARY, "CUDA"

def parse_size(size_str: str) -> float:
    """解析大小字符串为 GB"""
    s = size_str.lower().replace('gb', '').replace('mb', '').strip()
    try:
        val = float(s)
        if 'mb' in size_str.lower():
            return val / 1024
        return val
    except:
        return 0

def test_model(model: Dict, port: int) -> Dict:
    """测试单个模型"""
    import httpx
    
    name = model["name"]
    path = model["path"]
    size_gb = parse_size(model["size"])
    
    binary, backend = select_backend(size_gb)
    
    if not binary.exists():
        return {"model": name, "success": False, "error": f"{backend} binary not found"}
    
    ctx = 4096 if size_gb < 10 else 2048 if size_gb < 20 else 1024
    gpu_layers = min(35, int(size_gb * 3))
    
    console.print(f"\n[cyan]{name}[/cyan] ({model['size']}, {backend})")
    
    cmd = [
        str(binary), "-m", path,
        "--host", "127.0.0.1", "--port", str(port),
        "-c", str(ctx), "-ngl", str(gpu_layers),
        "--log-disable"
    ]
    
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            cwd=str(binary.parent)
        )
        
        base_url = f"http://127.0.0.1:{port}"
        max_wait = 120 if size_gb > 20 else 90 if size_gb > 10 else 60
        
        console.print(f"[blue]等待启动 ({max_wait}s)...[/blue]", end=" ")
        
        start = time.time()
        while time.time() - start < max_wait:
            try:
                r = httpx.get(f"{base_url}/health", timeout=5)
                if r.status_code == 200:
                    console.print("[green]✓[/green]")
                    break
            except:
                pass
            
            if proc.poll() is not None:
                proc.terminate()
                return {"model": name, "success": False, "error": "Server crashed"}
            
            time.sleep(2)
        else:
            proc.terminate()
            return {"model": name, "success": False, "error": "Timeout"}
        
        # 测试推理
        r = httpx.post(
            f"{base_url}/v1/chat/completions",
            json={"messages": [{"role": "user", "content": "What is 2+2?"}], "max_tokens": 50},
            timeout=30
        )
        
        proc.terminate()
        
        if r.status_code == 200:
            data = r.json()
            tokens = data.get("usage", {}).get("completion_tokens", 0)
            speed = tokens / (time.time() - start) if tokens > 0 else 0
            
            console.print(f"[green]✓ {tokens} tokens, {speed:.1f} tok/s[/green]")
            
            return {
                "model": name, "success": True,
                "backend": backend, "tokens": tokens,
                "speed": speed, "size_gb": size_gb
            }
        else:
            return {"model": name, "success": False, "error": f"HTTP {r.status_code}"}
            
    except Exception as e:
        if proc:
            proc.terminate()
        return {"model": name, "success": False, "error": str(e)}

def main():
    console.print(Panel.fit(
        "[bold cyan]Ollama 所有模型测试[/bold cyan]\n"
        "使用 Ollama 补丁版本的 llama.cpp (build 8667)",
        border_style="cyan"
    ))
    
    console.print("\n[cyan]获取模型列表...[/cyan]")
    models = get_ollama_models()
    
    # 筛选模型
    test_models = []
    keywords = ["gemma4", "gemma3", "qwen", "omnicoder", "translategemma"]
    
    for m in models:
        name = m["name"].lower()
        if any(k in name for k in keywords) and "embedding" not in name:
            test_models.append(m)
    
    console.print(f"[green]找到 {len(test_models)} 个模型[/green]")
    
    # 测试
    results = []
    port = 19000
    
    for i, m in enumerate(test_models, 1):
        console.print(f"\n[bold]{i}/{len(test_models)}[/bold]")
        r = test_model(m, port + i)
        results.append(r)
        subprocess.run(["pkill", "-f", f"--port {port + i}"], capture_output=True)
        time.sleep(2)
    
    # 结果
    console.print("\n" + "="*60)
    console.print("[bold]测试结果[/bold]")
    
    table = Table()
    table.add_column("模型", style="cyan")
    table.add_column("后端", style="blue")
    table.add_column("状态", style="bold")
    table.add_column("速度", style="green")
    table.add_column("错误", style="red")
    
    for r in results:
        status = "[green]✓[/green]" if r["success"] else "[red]✗[/red]"
        speed = f"{r.get('speed', 0):.1f}" if r.get("speed") else "-"
        error = r.get("error", "")[:30] if r.get("error") else ""
        
        table.add_row(r["model"], r.get("backend", ""), status, speed, error)
    
    console.print(table)
    
    passed = sum(1 for r in results if r["success"])
    console.print(f"\n[bold]通过: {passed}/{len(results)} ({passed/len(results)*100:.0f}%)[/bold]")
    
    # 保存
    json.dump(results, open("/home/fred/Documents/GitHub/cycleuser/MoXing/benchmark_ollama_final.json", "w"), indent=2)
    
    if passed == len(results):
        console.print(Panel("[green]所有测试通过！[/green]", border_style="green"))
        return 0
    else:
        console.print(Panel(f"[red]{len(results)-passed} 个失败[/red]", border_style="red"))
        return 1

if __name__ == "__main__":
    sys.exit(main())