import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dilnaka import Dilnaka, DilnakaAPIError  # noqa: E402


class FakeResponse:
    def __init__(self, status_code=200, json_data=None, text=None, json_error=False):
        self.status_code = status_code
        self._json_data = json_data
        self._json_error = json_error
        if text is not None:
            self.text = text
        elif json_data is None:
            self.text = ""
        else:
            self.text = json.dumps(json_data)

    def json(self):
        if self._json_error:
            raise ValueError("invalid json")
        return self._json_data


class FakeSession:
    def __init__(self, *, post_responses=None, get_responses=None, delete_responses=None, request_responses=None):
        self.post_responses = list(post_responses or [])
        self.get_responses = list(get_responses or [])
        self.delete_responses = list(delete_responses or [])
        self.request_responses = list(request_responses or [])
        self.calls = []

    def post(self, url, json, headers, timeout):
        self.calls.append(
            {
                "kind": "post",
                "url": url,
                "json": json,
                "headers": headers,
                "timeout": timeout,
            }
        )
        return self.post_responses.pop(0)

    def get(self, url, headers, timeout):
        self.calls.append(
            {
                "kind": "get",
                "url": url,
                "headers": headers,
                "timeout": timeout,
            }
        )
        return self.get_responses.pop(0)

    def delete(self, url, headers, timeout):
        self.calls.append(
            {
                "kind": "delete",
                "url": url,
                "headers": headers,
                "timeout": timeout,
            }
        )
        return self.delete_responses.pop(0)

    def request(self, method, url, data, headers, timeout):
        self.calls.append(
            {
                "kind": "request",
                "method": method,
                "url": url,
                "body": data.read(),
                "headers": headers,
                "timeout": timeout,
            }
        )
        return self.request_responses.pop(0)


class DilnakaClientTests(unittest.TestCase):
    def make_client(self, session, timeout=25):
        return Dilnaka(
            api_key="dlk_dev_test_key",
            base_url="https://api.example.com",
            timeout=timeout,
            session=session,
        )

    def uploaded_file_payload(self, **overrides):
        payload = {
            "fileId": "file_123",
            "key": "uploads/sdk-test.txt",
            "status": "uploaded",
            "originalName": "sdk-test.txt",
            "contentType": "text/plain",
            "size": 17,
            "publicUrl": None,
        }
        payload.update(overrides)
        return payload

    def test_upload_uses_presigned_flow_and_returns_completed_file(self):
        session = FakeSession(
            post_responses=[
                FakeResponse(
                    json_data={
                        "fileId": "file_123",
                        "fileKey": "uploads/sdk-test.txt",
                        "uploadUrl": "https://s3.example.com/presigned-upload",
                        "expiresIn": 300,
                        "method": "PUT",
                        "headers": {"x-amz-acl": "private"},
                    }
                ),
                FakeResponse(json_data=self.uploaded_file_payload()),
            ],
            request_responses=[FakeResponse(status_code=200, text="")],
        )
        client = self.make_client(session)

        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "sdk-test.txt"
            file_path.write_bytes(b"upload test body\n")

            uploaded = client.upload(str(file_path), folder="avatars", metadata={"origin": "tests"})

        self.assertEqual(uploaded.id, "file_123")
        self.assertEqual(uploaded.key, "uploads/sdk-test.txt")
        self.assertEqual(uploaded.status, "uploaded")
        self.assertEqual(uploaded.content_type, "text/plain")

        self.assertEqual(len(session.calls), 3)

        presign_call = session.calls[0]
        self.assertEqual(presign_call["kind"], "post")
        self.assertEqual(presign_call["url"], "https://api.example.com/v1/uploads/presign")
        self.assertEqual(presign_call["json"]["filename"], "sdk-test.txt")
        self.assertEqual(presign_call["json"]["folder"], "avatars")
        self.assertEqual(presign_call["json"]["metadata"], {"origin": "tests"})
        self.assertEqual(presign_call["json"]["contentType"], "text/plain")
        self.assertEqual(presign_call["timeout"], 25)

        upload_call = session.calls[1]
        self.assertEqual(upload_call["kind"], "request")
        self.assertEqual(upload_call["method"], "PUT")
        self.assertEqual(upload_call["url"], "https://s3.example.com/presigned-upload")
        self.assertEqual(upload_call["body"], b"upload test body\n")
        self.assertEqual(upload_call["headers"]["x-amz-acl"], "private")
        self.assertEqual(upload_call["headers"]["Content-Type"], "text/plain")
        self.assertEqual(upload_call["timeout"], 25)

        complete_call = session.calls[2]
        self.assertEqual(complete_call["kind"], "post")
        self.assertEqual(complete_call["url"], "https://api.example.com/v1/uploads/complete")
        self.assertEqual(complete_call["json"], {"fileId": "file_123"})

    def test_upload_missing_file_raises_file_not_found(self):
        session = FakeSession()
        client = self.make_client(session)

        with self.assertRaises(FileNotFoundError) as error:
            client.upload("C:/missing/file.txt")

        self.assertIn("File not found", str(error.exception))
        self.assertEqual(session.calls, [])

    def test_upload_directory_path_raises_value_error(self):
        session = FakeSession()
        client = self.make_client(session)

        with tempfile.TemporaryDirectory() as tmp_dir:
            with self.assertRaises(ValueError) as error:
                client.upload(tmp_dir)

        self.assertIn("Path is not a file", str(error.exception))
        self.assertEqual(session.calls, [])

    def test_upload_surfaces_presign_api_error(self):
        session = FakeSession(
            post_responses=[FakeResponse(status_code=403, json_data={"error": "Invalid API key"})]
        )
        client = self.make_client(session)

        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "sdk-test.txt"
            file_path.write_bytes(b"upload test body\n")

            with self.assertRaises(DilnakaAPIError) as error:
                client.upload(str(file_path))

        self.assertEqual(str(error.exception), "Invalid API key")
        self.assertEqual(error.exception.status_code, 403)
        self.assertEqual(len(session.calls), 1)
        self.assertEqual(session.calls[0]["kind"], "post")

    def test_upload_surfaces_s3_upload_failure(self):
        session = FakeSession(
            post_responses=[
                FakeResponse(
                    json_data={
                        "fileId": "file_123",
                        "fileKey": "uploads/sdk-test.txt",
                        "uploadUrl": "https://s3.example.com/presigned-upload",
                        "expiresIn": 300,
                        "method": "PUT",
                        "headers": {},
                    }
                )
            ],
            request_responses=[FakeResponse(status_code=403, text="AccessDenied")],
        )
        client = self.make_client(session)

        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "sdk-test.txt"
            file_path.write_bytes(b"upload test body\n")

            with self.assertRaises(DilnakaAPIError) as error:
                client.upload(str(file_path))

        self.assertEqual(str(error.exception), "S3 upload failed with status 403.")
        self.assertEqual(error.exception.status_code, 403)
        self.assertEqual(error.exception.response_body, "AccessDenied")
        self.assertEqual([call["kind"] for call in session.calls], ["post", "request"])

    def test_upload_surfaces_complete_upload_failure(self):
        session = FakeSession(
            post_responses=[
                FakeResponse(
                    json_data={
                        "fileId": "file_123",
                        "fileKey": "uploads/sdk-test.txt",
                        "uploadUrl": "https://s3.example.com/presigned-upload",
                        "expiresIn": 300,
                        "method": "PUT",
                        "headers": {},
                    }
                ),
                FakeResponse(status_code=500, json_data={"message": "Failed to mark upload complete"}),
            ],
            request_responses=[FakeResponse(status_code=204, text="")],
        )
        client = self.make_client(session)

        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "sdk-test.txt"
            file_path.write_bytes(b"upload test body\n")

            with self.assertRaises(DilnakaAPIError) as error:
                client.upload(str(file_path))

        self.assertEqual(str(error.exception), "Failed to mark upload complete")
        self.assertEqual(error.exception.status_code, 500)
        self.assertEqual([call["kind"] for call in session.calls], ["post", "request", "post"])

    def test_list_files_returns_wrapped_files_collection(self):
        session = FakeSession(
            get_responses=[
                FakeResponse(
                    json_data={
                        "files": [
                            self.uploaded_file_payload(),
                            self.uploaded_file_payload(
                                fileId="file_456",
                                key="uploads/second.txt",
                                originalName="second.txt",
                                size=33,
                            ),
                        ]
                    }
                )
            ]
        )
        client = self.make_client(session, timeout=15)

        files = client.list_files()

        self.assertEqual([file.id for file in files], ["file_123", "file_456"])
        self.assertEqual(files[1].key, "uploads/second.txt")
        self.assertEqual(files[1].size, 33)
        self.assertEqual(session.calls[0]["url"], "https://api.example.com/v1/files")

    def test_list_files_returns_raw_list_response(self):
        session = FakeSession(
            get_responses=[
                FakeResponse(
                    json_data=[
                        self.uploaded_file_payload(fileId="file_789", key="uploads/raw-list.txt")
                    ]
                )
            ]
        )
        client = self.make_client(session)

        files = client.list_files()

        self.assertEqual(len(files), 1)
        self.assertEqual(files[0].id, "file_789")
        self.assertEqual(files[0].key, "uploads/raw-list.txt")

    def test_get_file_returns_uploaded_file(self):
        session = FakeSession(get_responses=[FakeResponse(json_data=self.uploaded_file_payload())])
        client = self.make_client(session)

        uploaded = client.get_file("file_123")

        self.assertEqual(uploaded.id, "file_123")
        self.assertEqual(uploaded.original_name, "sdk-test.txt")
        self.assertEqual(session.calls[0]["url"], "https://api.example.com/v1/files/file_123")

    def test_get_file_surfaces_not_found_error_message(self):
        session = FakeSession(get_responses=[FakeResponse(status_code=404, json_data={"message": "File not found"})])
        client = self.make_client(session)

        with self.assertRaises(DilnakaAPIError) as error:
            client.get_file("missing-file")

        self.assertEqual(str(error.exception), "File not found")
        self.assertEqual(error.exception.status_code, 404)

    def test_get_file_rejects_response_missing_required_id(self):
        session = FakeSession(
            get_responses=[
                FakeResponse(
                    json_data={
                        "key": "uploads/sdk-test.txt",
                        "status": "uploaded",
                        "originalName": "sdk-test.txt",
                        "contentType": "text/plain",
                        "size": 17,
                    }
                )
            ]
        )
        client = self.make_client(session)

        with self.assertRaises(DilnakaAPIError) as error:
            client.get_file("file_123")

        self.assertEqual(str(error.exception), "Dilnaka API response missing file id.")

    def test_delete_file_returns_api_response(self):
        session = FakeSession(delete_responses=[FakeResponse(json_data={"deleted": True, "fileId": "file_123"})])
        client = self.make_client(session)

        response = client.delete_file("file_123")

        self.assertEqual(response, {"deleted": True, "fileId": "file_123"})
        self.assertEqual(session.calls[0]["kind"], "delete")
        self.assertEqual(session.calls[0]["url"], "https://api.example.com/v1/files/file_123")

    def test_delete_file_surfaces_clear_permission_error_message(self):
        session = FakeSession(
            delete_responses=[
                FakeResponse(
                    status_code=403,
                    json_data={"message": "You do not have permission to delete this file."},
                )
            ]
        )
        client = self.make_client(session)

        with self.assertRaises(DilnakaAPIError) as error:
            client.delete_file("file_123")

        self.assertEqual(str(error.exception), "You do not have permission to delete this file.")
        self.assertEqual(error.exception.status_code, 403)
        self.assertIn("permission", str(error.exception).lower())

    def test_list_files_raises_api_error_for_non_json_response(self):
        session = FakeSession(
            get_responses=[
                FakeResponse(
                    status_code=200,
                    text="<html><body>Redirecting to sign-in</body></html>",
                    json_error=True,
                )
            ]
        )
        client = self.make_client(session, timeout=15)

        with self.assertRaises(DilnakaAPIError) as error:
            client.list_files()

        self.assertEqual(str(error.exception), "Dilnaka API returned non-JSON response.")
        self.assertEqual(error.exception.status_code, 200)
        self.assertEqual(
            error.exception.response_body,
            "<html><body>Redirecting to sign-in</body></html>",
        )


if __name__ == "__main__":
    unittest.main()