import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dilnaka.config import load_config  # noqa: E402
from dilnaka.errors import DilnakaConfigError  # noqa: E402


class DilnakaConfigTests(unittest.TestCase):
    def write_env_file(self, directory, contents):
        env_file = Path(directory) / ".env.test"
        env_file.write_text(contents, encoding="utf-8")
        return env_file

    def test_load_config_reads_values_from_env_file(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            env_file = self.write_env_file(
                tmp_dir,
                "DILNAKA_API_KEY=dlk_dev_from_env\n"
                "DILNAKA_BASE_URL=https://uploads.example.com/\n"
                "DILNAKA_TIMEOUT=45\n",
            )

            with patch.dict("os.environ", {}, clear=True):
                config = load_config(env_file=env_file)

        self.assertEqual(config.api_key, "dlk_dev_from_env")
        self.assertEqual(config.base_url, "https://uploads.example.com")
        self.assertEqual(config.timeout, 45)

    def test_load_config_prefers_explicit_arguments_over_env_file(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            env_file = self.write_env_file(
                tmp_dir,
                "DILNAKA_API_KEY=dlk_dev_from_env\n"
                "DILNAKA_BASE_URL=https://env.example.com/\n"
                "DILNAKA_TIMEOUT=45\n",
            )

            with patch.dict("os.environ", {}, clear=True):
                config = load_config(
                    api_key="dlk_live_explicit",
                    base_url="https://explicit.example.com/",
                    timeout=99,
                    env_file=env_file,
                )

        self.assertEqual(config.api_key, "dlk_live_explicit")
        self.assertEqual(config.base_url, "https://explicit.example.com")
        self.assertEqual(config.timeout, 99)

    def test_load_config_uses_default_base_url_and_timeout(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            missing_env = Path(tmp_dir) / ".does-not-exist"

            with patch.dict("os.environ", {}, clear=True):
                config = load_config(api_key="dlk_dev_direct", env_file=missing_env)

        self.assertEqual(config.base_url, "https://dilnaka.tsnc.tech")
        self.assertEqual(config.timeout, 60)

    def test_load_config_requires_api_key(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            missing_env = Path(tmp_dir) / ".does-not-exist"

            with patch.dict("os.environ", {}, clear=True):
                with self.assertRaises(DilnakaConfigError) as error:
                    load_config(env_file=missing_env)

        self.assertEqual(
            str(error.exception),
            "Missing Dilnaka API key. Set DILNAKA_API_KEY in .env or pass api_key=... to Dilnaka().",
        )

    def test_load_config_rejects_invalid_api_key_format(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            env_file = self.write_env_file(tmp_dir, "DILNAKA_API_KEY=not-a-dilnaka-key\n")

            with patch.dict("os.environ", {}, clear=True):
                with self.assertRaises(DilnakaConfigError) as error:
                    load_config(env_file=env_file)

        self.assertEqual(
            str(error.exception),
            "Invalid Dilnaka API key format. Expected key starting with dlk_dev_ or dlk_live_.",
        )

    def test_load_config_rejects_non_integer_timeout(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            env_file = self.write_env_file(
                tmp_dir,
                "DILNAKA_API_KEY=dlk_dev_from_env\nDILNAKA_TIMEOUT=abc\n",
            )

            with patch.dict("os.environ", {}, clear=True):
                with self.assertRaises(DilnakaConfigError) as error:
                    load_config(env_file=env_file)

        self.assertEqual(str(error.exception), "DILNAKA_TIMEOUT must be an integer.")

    def test_load_config_rejects_non_positive_timeout(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            missing_env = Path(tmp_dir) / ".does-not-exist"

            with patch.dict("os.environ", {}, clear=True):
                with self.assertRaises(DilnakaConfigError) as error:
                    load_config(api_key="dlk_dev_direct", timeout=0, env_file=missing_env)

        self.assertEqual(str(error.exception), "timeout must be greater than 0.")


if __name__ == "__main__":
    unittest.main()