from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class PresignedUpload:
    file_id: str
    file_key: str
    upload_url: str
    expires_in: int
    method: str
    headers: Dict[str, str]


@dataclass(frozen=True)
class UploadedFile:
    id: str
    key: str
    status: str
    original_name: str
    content_type: str
    size: int
    public_url: Optional[str] = None
    etag: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
