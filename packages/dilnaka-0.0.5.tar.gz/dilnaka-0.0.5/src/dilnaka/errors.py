class DilnakaError(Exception):
    """Base exception for Dilnaka SDK errors."""


class DilnakaConfigError(DilnakaError):
    """Raised when required SDK configuration is missing or invalid."""


class DilnakaAPIError(DilnakaError):
    """Raised when the Dilnaka API or S3 upload returns an error."""

    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
