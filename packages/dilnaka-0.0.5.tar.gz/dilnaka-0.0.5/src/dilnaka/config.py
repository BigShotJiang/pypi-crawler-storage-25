import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

from .errors import DilnakaConfigError


@dataclass(frozen=True)
class DilnakaConfig:
    api_key: str
    base_url: str
    timeout: int


def load_config(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[int] = None,
    env_file: str | os.PathLike[str] | None = None,
) -> DilnakaConfig:
    """Load SDK config from explicit args first, then environment variables.

    By default, python-dotenv searches for `.env` from the current working
    directory upward. This matches normal app usage: the project using the SDK
    owns the `.env` file.
    """

    if env_file is not None:
        load_dotenv(dotenv_path=Path(env_file), override=False)
    else:
        load_dotenv(override=False)

    resolved_api_key = api_key or os.getenv("DILNAKA_API_KEY")
    resolved_base_url = base_url or os.getenv("DILNAKA_BASE_URL") or "https://dilnaka.tsnc.tech"

    if timeout is None:
        raw_timeout = os.getenv("DILNAKA_TIMEOUT", "60")
        try:
            resolved_timeout = int(raw_timeout)
        except ValueError as exc:
            raise DilnakaConfigError("DILNAKA_TIMEOUT must be an integer.") from exc
    else:
        resolved_timeout = timeout

    if not resolved_api_key:
        raise DilnakaConfigError(
            "Missing Dilnaka API key. Set DILNAKA_API_KEY in .env or pass api_key=... to Dilnaka()."
        )

    if not resolved_api_key.startswith(("dlk_dev_", "dlk_live_")):
        raise DilnakaConfigError(
            "Invalid Dilnaka API key format. Expected key starting with dlk_dev_ or dlk_live_."
        )

    if resolved_timeout <= 0:
        raise DilnakaConfigError("timeout must be greater than 0.")

    return DilnakaConfig(
        api_key=resolved_api_key,
        base_url=resolved_base_url.rstrip("/"),
        timeout=resolved_timeout,
    )
