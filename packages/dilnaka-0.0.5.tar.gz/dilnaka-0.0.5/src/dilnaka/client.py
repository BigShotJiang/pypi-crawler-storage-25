import mimetypes
from pathlib import Path
from typing import Any, Dict, Optional

import requests

from .config import load_config
from .errors import DilnakaAPIError
from .types import PresignedUpload, UploadedFile


class Dilnaka:
    """Python SDK client for Dilnaka uploads.

    Configuration order:
      1. Constructor args
      2. .env / environment variables

    Required environment variable:
      DILNAKA_API_KEY

    Optional environment variables:
      DILNAKA_BASE_URL
      DILNAKA_TIMEOUT
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        env_file: str | None = None,
        session: Optional[requests.Session] = None,
    ):
        self.config = load_config(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            env_file=env_file,
        )
        self.session = session or requests.Session()

    def upload(
        self,
        file_path: str,
        folder: str = "uploads",
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> UploadedFile:
        """Upload a local file through the Dilnaka presigned URL flow."""

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if not path.is_file():
            raise ValueError(f"Path is not a file: {file_path}")

        filename = path.name
        size = path.stat().st_size
        resolved_content_type = content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"

        presigned = self.create_presigned_upload(
            filename=filename,
            content_type=resolved_content_type,
            size=size,
            folder=folder,
            metadata=metadata,
        )

        upload_headers = dict(presigned.headers or {})
        upload_headers.setdefault("Content-Type", resolved_content_type)

        with open(path, "rb") as file:
            upload_response = self.session.request(
                method=presigned.method.upper(),
                url=presigned.upload_url,
                data=file,
                headers=upload_headers,
                timeout=self.config.timeout,
            )

        if upload_response.status_code not in (200, 201, 204):
            raise DilnakaAPIError(
                f"S3 upload failed with status {upload_response.status_code}.",
                status_code=upload_response.status_code,
                response_body=upload_response.text,
            )

        return self.complete_upload(presigned.file_id)

    def create_presigned_upload(
        self,
        filename: str,
        content_type: str,
        size: int,
        folder: str = "uploads",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> PresignedUpload:
        payload: Dict[str, Any] = {
            "filename": filename,
            "contentType": content_type,
            "size": size,
            "folder": folder,
        }
        if metadata:
            payload["metadata"] = metadata

        data = self._post("/v1/uploads/presign", payload)

        return PresignedUpload(
            file_id=data["fileId"],
            file_key=data.get("fileKey") or data.get("key", ""),
            upload_url=data["uploadUrl"],
            expires_in=int(data.get("expiresIn", 300)),
            method=data.get("method", "PUT"),
            headers=data.get("headers") or {"Content-Type": content_type},
        )

    def complete_upload(self, file_id: str) -> UploadedFile:
        data = self._post("/v1/uploads/complete", {"fileId": file_id})
        return self._uploaded_file_from_response(data)

    def list_files(self) -> list[UploadedFile]:
        data = self._get("/v1/files")
        if isinstance(data, list):
            items = data
        else:
            items = data.get("files", [])
        return [self._uploaded_file_from_response(item) for item in items]

    def get_file(self, file_id: str) -> UploadedFile:
        data = self._get(f"/v1/files/{file_id}")
        return self._uploaded_file_from_response(data)

    def delete_file(self, file_id: str) -> dict:
        return self._delete(f"/v1/files/{file_id}")

    def _uploaded_file_from_response(self, data: Dict[str, Any]) -> UploadedFile:
        file_id = self._require_string_field(data, "file id", "fileId", "id")
        file_key = self._require_string_field(data, "file key", "key")
        status = self._require_string_field(data, "file status", "status")

        return UploadedFile(
            id=file_id,
            key=file_key,
            status=status,
            original_name=data.get("originalName") or data.get("original_name") or "",
            content_type=data.get("contentType") or data.get("content_type") or "application/octet-stream",
            size=int(data.get("size", 0)),
            public_url=data.get("publicUrl") or data.get("public_url"),
            etag=data.get("etag"),
            metadata=data.get("metadata"),
        )

    def _require_string_field(self, data: Dict[str, Any], field_name: str, *keys: str) -> str:
        for key in keys:
            value = data.get(key)
            if isinstance(value, str) and value:
                return value

        raise DilnakaAPIError(f"Dilnaka API response missing {field_name}.")

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "dilnaka-python/0.1.0",
        }

    def _get(self, path: str) -> Any:
        response = self.session.get(
            f"{self.config.base_url}{path}",
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        return self._parse_response(response)

    def _post(self, path: str, payload: Dict[str, Any]) -> Any:
        response = self.session.post(
            f"{self.config.base_url}{path}",
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        return self._parse_response(response)

    def _delete(self, path: str) -> Any:
        response = self.session.delete(
            f"{self.config.base_url}{path}",
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        return self._parse_response(response)

    def _parse_response(self, response: requests.Response) -> Any:
        if response.status_code >= 400:
            message = response.text
            try:
                body = response.json()
                message = body.get("error") or body.get("message") or message
            except ValueError:
                pass
            raise DilnakaAPIError(
                message,
                status_code=response.status_code,
                response_body=response.text,
            )

        if not response.text:
            return {}

        try:
            return response.json()
        except ValueError as exc:
            raise DilnakaAPIError(
                "Dilnaka API returned non-JSON response.",
                status_code=response.status_code,
                response_body=response.text,
            ) from exc
