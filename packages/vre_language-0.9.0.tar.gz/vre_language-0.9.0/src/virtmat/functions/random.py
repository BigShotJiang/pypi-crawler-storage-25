"""provide properly typed and pint-wrapped numpy random sampling functions"""
import pandas
import pint_pandas
from virtmat.language.utilities.random import RandomGenerator
from virtmat.language.utilities.types import is_numeric_scalar
from virtmat.language.utilities.units import ureg


FUNCTIONS = []

_wrap_spec = {
    'integers': {'return': '=A', 'args': ('=A', '=A', None, None, None)},
    'random': {'return': '', 'args': (None, None, None)},
    'choice': {'return': '=A', 'args': ('=A', None, None, '', '', None)},
    # bytes not implemented because we do not have bytes type
    # shuffle not implemented because of in-place operation
    'permutation': {'return': None, 'args': (None, '')},
    'permuted': {'return': None, 'args': (None, '', None)},
    'beta': {'return': '', 'args': ('', '', None)},
    'binomial': {'return': '', 'args': ('', '', None)},
    'chisquare': {'return': '', 'args': ('', None)},
    'dirichlet': {'return': '', 'args': ('', None)},
    'exponential': {'return': '=A', 'args': ('=A', None)},
    'f': {'return': '', 'args': ('', '', None)},
    'gamma': {'return': '', 'args': ('', '', None)},
    'geometric': {'return': '', 'args': ('', None)},
    'gumbel': {'return': '=A', 'args': ('=A', '=A', None)},
    'hypergeometric': {'return': '', 'args': ('', '', '', None)},
    'laplace': {'return': '=A', 'args': ('=A', '=A', None)},
    'logistic': {'return': '=A', 'args': ('=A', '=A', None)},
    'lognormal': {'return': '', 'args': ('', '', None)},
    'logseries': {'return': '', 'args': ('', None)},
    'multinomial': {'return': '', 'args': ('', '', None)},
    'multivariate_hypergeometric': {'return': '', 'args': ('', '', None, None)},
    'multivariate_normal': {'return': '', 'args': ('', '', None, None, '', None)},
    'negative_binomial': {'return': '', 'args': ('', '', None)},
    'noncentral_chisquare': {'return': '', 'args': ('', '', None)},
    'noncentral_f': {'return': '', 'args': ('', '', '', None)},
    'normal': {'return': '=A', 'args': ('=A', '=A', None)},
    'pareto': {'return': '', 'args': ('', None)},
    'poisson': {'return': '', 'args': ('', None)},
    'power': {'return': '', 'args': ('', None)},
    'rayleigh': {'return': '', 'args': ('', None)},
    'standard_cauchy': {'return': '', 'args': (None, )},
    'standard_exponential': {'return': '', 'args': (None, None, None, None)},
    'standard_gamma': {'return': '', 'args': ('', None, None, None)},
    'standard_normal': {'return': '', 'args': (None, None, None)},
    'standard_t': {'return': '', 'args': ('', None)},
    'triangular': {'return': '=A', 'args': ('=A', '=A', '=A', None)},
    'uniform': {'return': '=A', 'args': ('=A', '=A', None)},
    'vonmises': {'return': '=A', 'args': ('=A', '', None)},
    'wald': {'return': '', 'args': ('', '', None)},
    'weibull': {'return': '', 'args': ('', None)},
    'zipf': {'return': '', 'args': ('', None)}
}


def _get_random_typed(func, func_name):
    """return series for outputs produced with scalar size parameter"""
    def decorator(*args, **kwargs):
        if 'size' not in kwargs or kwargs['size'] is None:
            return func(*args, **kwargs)
        if is_numeric_scalar(kwargs['size']):
            assert str(kwargs['size'].units) == 'dimensionless'
            kwargs['size'] = kwargs['size'].magnitude
            return pandas.Series(pint_pandas.PintArray(func(*args, **kwargs)), name=func_name)
        assert isinstance(kwargs['size'], (tuple, list))
        assert all(str(q.units) == 'dimensionless' for q in kwargs['size'])
        kwargs['size'] = [q.magnitude for q in kwargs['size']]
        return func(*args, **kwargs)
    return decorator


def _get_random_wrapped(rng, func):
    """wrap the numpy.random.Generator bound method 'func' to add units"""
    decorator = ureg.wraps(_wrap_spec[func]['return'], _wrap_spec[func]['args'])
    return _get_random_typed(decorator(getattr(rng, func)), func)


def _get_random_function(func):
    """evaluate a random sampling function func from numpy.random"""
    def decorator(params=None):
        if params is None:
            params = {}
        elif isinstance(params, pandas.DataFrame):
            params = {} if len(params) == 0 else params.to_dict(orient='records')[0]
        gen = RandomGenerator(params.pop('rng', None), params.pop('seed', None))
        retval = _get_random_wrapped(gen, func)(**params)
        if func in ['permutation', 'permuted']:
            if isinstance(params['x'], ureg.Quantity):
                return ureg.Quantity(retval)
        return retval
    return decorator


for _func_name in _wrap_spec:
    _wrapper = _get_random_function(_func_name)
    setattr(_wrapper, '__name__', _func_name)
    setattr(_wrapper, '__qualname__', _func_name)
    setattr(_wrapper, '__module__', __name__)
    globals()[_func_name] = _wrapper
    FUNCTIONS.append(_func_name)
