"""checkpointing class"""
import glob
import os
import tarfile
from virtmat.language.utilities.logging import get_logger


class Checkpointer:
    """Manage checkpoints of a directory in indexed compressed tarballs with basename."""
    def __init__(self, directory, basename):
        """If checkpoints exist then load the checkpoint with largest index.
           Otherwise set index to 0.

        Args:
            directory (str): relative or absolute path to directory
            basename (str): name to use as basename for the archive files
        """
        self.logger = get_logger(__name__)
        self.index = 0
        self.directory = os.path.abspath(directory)
        self.basename = basename
        self.glob = os.path.join(self.directory, basename+'.chk.*.tar.gz')
        chk_pts = glob.glob(self.glob)
        if chk_pts:
            self.logger.info('found %s checkpoint files', len(chk_pts))
            self.logger.debug('checkpoint files found: %s', chk_pts)
            chk_pt = max(chk_pts, key=lambda c: int(c.split(".")[-3]))
            self.index = int(chk_pt.split('.')[-3])
            with tarfile.open(chk_pt) as tar:
                tar.extractall(self.directory)
            self.logger.info('recovered from checkpoint file %s', chk_pt)

    def cleanup(self):
        """Remove all archives."""
        for file_ in glob.glob(self.glob):
            os.unlink(file_)
            self.logger.info('deleted checkpoint file %s', file_)

    def save(self, index):
        """Save the contents of self.directory into an archive with index."""
        tmp_path = os.path.join(self.directory, f'{self.basename}.chk.tar.gz')
        with tarfile.open(tmp_path, mode='w:gz', compresslevel=3) as tar:
            for file_ in os.listdir(self.directory):
                file_full = os.path.join(self.directory, file_)
                if file_full not in glob.glob(self.glob):
                    tar.add(file_full, arcname=file_)
        self.cleanup()
        path = os.path.join(self.directory, f'{self.basename}.chk.{index}.tar.gz')
        os.rename(tmp_path, path)
        self.index = index
        self.logger.info('created checkpoint file %s', path)
