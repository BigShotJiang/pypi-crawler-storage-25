"""Custom variant of a custodian class maintaining the interface of the custodian package."""
import os
from itertools import islice
from custodian.custodian import CustodianError, MaxCorrectionsPerJobError, MaxCorrectionsError
from virtmat.language.utilities.checkpoint import Checkpointer
from virtmat.language.utilities.logging import get_logger


class Custodian:
    """A light-weight custodian class providing a few basic features.

    The features implemented here are job processing and checkpointing. Handlers
    are accepted as parameters but not processed. Validators are not implemented.
    """

    def __init__(self, handlers, jobs, max_errors_per_job=None, max_errors=1):
        """
        Args:
            handlers ([ErrorHandler]): List of custodian handlers.
            jobs [(Job]): List of custodian jobs.
            max_errors_per_job (int): Maximum number of errors per job allowed
                before exiting. If it is None then it is set to max_errors.
            max_errors (int): Maximum number of total errors allowed before
                exiting. Defaults to 1.
        """
        self.logger = get_logger(__name__)
        self.jobs = jobs
        self.handlers = handlers
        assert all(not h.is_monitor for h in handlers)
        self.max_errors = max_errors
        self.max_errors_per_job = max_errors_per_job or max_errors
        self.directory = os.getcwd()
        self.checkpt = None
        self.restart_index = 0
        if len(jobs) > 1:
            self.checkpt = Checkpointer(self.directory, 'custodian')
            self.restart_index = self.checkpt.index
        self.total_errors = 0
        self.logger.info('starting %s jobs in directory %s', len(jobs), self.directory)
        self.logger.info('applying %s handlers', len(handlers))

    def run(self):
        """run all jobs in a sequence"""
        for job_n, job in islice(enumerate(self.jobs), self.restart_index, None):
            self.logger.info('running job # %s out of %s', job_n, len(self.jobs))
            try:
                self._run_job(job)
            except CustodianError as err:
                if err.raises:  # not covered
                    raise
            if self.checkpt and job_n + 1 < len(self.jobs):  # skip last checkpoint
                self.checkpt.save(job_n)
        if self.checkpt:
            self.checkpt.cleanup()

    def _run_job(self, job):
        """run one job"""
        errors_current_job = 0
        for handler in self.handlers:
            handler.n_applied_corrections = 0  # not covered
        job.setup(self.directory)
        while (self.total_errors < self.max_errors and
               errors_current_job < self.max_errors_per_job):
            job.run(directory=self.directory)
            has_error = False
            # not implemented: run all handlers
            # not implemented: update has_error, self.total_errors, errors_current_job
            if not has_error:
                # not implemented: run all validators
                job.postprocess(directory=self.directory)
                return
        if errors_current_job >= self.max_errors_per_job:
            raise MaxCorrectionsPerJobError(
                f'maximum errors per job reached: {self.max_errors_per_job}',
                raises=True,
                max_errors_per_job=self.max_errors_per_job,
                job=job
            )  # not covered
        raise MaxCorrectionsError(
            f'maximum errors reached: {self.max_errors}',
            raises=True,
            max_errors=self.max_errors
        )  # not covered
