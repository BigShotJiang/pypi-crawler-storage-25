"""utilities to work with random numbers"""
import uuid
from numpy import random
from virtmat.language.utilities.errors import RuntimeValueError

DEFAULT_BIT_GENERATOR = 'PCG64'
BIT_GENERATORS = ['MT19937', 'PCG64', 'PCG64DXSM', 'Philox', 'SFC64']


def get_bit_generator(rng=None, seed=None, spawn_key=tuple()):
    """create a bit generator from class name and seed"""
    rng = rng or DEFAULT_BIT_GENERATOR
    uuid_str = seed or uuid.uuid4().hex
    try:
        seed_int = int(uuid.UUID(uuid_str))
    except ValueError as err:
        raise RuntimeValueError(err) from err
    if rng not in BIT_GENERATORS:
        raise RuntimeValueError(f'unknown bit generator: {rng}')
    sseq = random.SeedSequence(entropy=seed_int, spawn_key=spawn_key)
    return getattr(random, rng)(seed=sseq)


class RandomGenerator(random.Generator):
    """a registry class holding different instances of numpy.random.Generator"""
    _instances = {}

    def __new__(cls, rng=None, seed=None, spawn_key=tuple()):
        if seed is None:
            return random.Generator(get_bit_generator(rng, seed, spawn_key))
        rng_ = rng or DEFAULT_BIT_GENERATOR
        if (rng_, seed, spawn_key) not in cls._instances:
            cls._instances[(rng_, seed, spawn_key)] = \
                random.Generator(get_bit_generator(rng_, seed, spawn_key))
        return cls._instances[(rng_, seed, spawn_key)]

    @classmethod
    def reset(cls):
        """reset the registry; needed for switching between tests"""
        cls._instances = {}
