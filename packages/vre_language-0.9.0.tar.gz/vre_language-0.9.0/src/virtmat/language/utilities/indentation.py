"""
Indentation utility for multiline input continuation

Priority policy for alignment:
(1) Align to first unmatched  parentheses/bracket;
(2) Otherwise align to the '=' assignment operator
"""


def compute_indent(buffer: str | None = None) -> str:
    """
    Compute indentation for multiline continuation lines
    """
    if not buffer:
        return ''
    # 1) HANGING PARENTHESES / BRACKETS RULE
    opens = '([{'
    closes = ')]}'
    match = {')': '(', ']': '[', '}': '{'}
    stack = []
    for line_no, line in enumerate(buffer.split("\n")):
        for col, char in enumerate(line):
            if char in opens:
                stack.append((line_no, col, char))
            elif char in closes:
                if stack and stack[-1][2] == match[char]:
                    stack.pop()
    if stack:
        max_line = max(line_no for (line_no, _, _) in stack)
        ropeners = [(col, char) for (line_no, col, char) in stack if line_no == max_line]
        max_col, _ = max(ropeners, key=lambda t: t[0])
        return ' ' * (max_col + 1)
    # 2) FALLBACK: ALIGN TO ASSIGNMENT OPERATOR '='
    first_line = buffer.split("\n", 1)[0]
    for idx, char in enumerate(first_line):
        if char != '=':
            continue
        left = first_line[idx - 1] if idx > 0 else ''
        right = first_line[idx + 1] if idx + 1 < len(first_line) else ''
        if (
            left in ('=', '!', '<', '>')
            or right == '='
        ):
            continue
        indent_size = idx + 2
        return ' ' * indent_size
    return ''
