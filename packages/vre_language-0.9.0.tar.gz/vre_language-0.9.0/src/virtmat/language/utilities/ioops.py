"""i/o operations"""
import os
import uuid
import tempfile
import yaml
import json
import numpy
import h5py
import pathlib
import zlib
from gridfs import GridFS
from fireworks import fw_config, LaunchPad
from virtmat.language.utilities.warnings import warnings, TextSUserWarning
from .errors import RuntimeTypeError

FW_CONFIG_DIR = os.path.join(os.path.expanduser('~'), '.fireworks')
DATASTORE_CONFIG_DEFAULT = {'path': os.path.join(FW_CONFIG_DIR, 'vre-language-datastore'),
                            'type': 'file',  # in ['file', 'gridfs', 'url', None]
                            'format': 'json',  # in ['json', 'yaml', 'hdf5', 'custom']
                            'name': 'vre_language_datastore',
                            'launchpad': fw_config.LAUNCHPAD_LOC,
                            'compress': True,
                            'inline-threshold': 100000}
# volatile storage, will be automatically cleaned up on exit
TEMP_STORE_DIR = tempfile.TemporaryDirectory()  # pylint: disable=R1732


def get_datastore_config(**kwargs):
    """update, set globally and return the data store configuration"""
    config = DATASTORE_CONFIG_DEFAULT
    if 'DATASTORE_CONFIG' in os.environ:
        conf_path = os.environ['DATASTORE_CONFIG']
        if not os.path.exists(conf_path):
            msg = f'The config file {conf_path} does not exist.'
            raise FileNotFoundError(msg)
    else:
        conf_path = os.path.join(FW_CONFIG_DIR, 'datastore_config.yaml')
    if os.path.exists(conf_path):
        with open(conf_path, 'r', encoding='utf-8') as inp:
            custom_config = yaml.safe_load(inp)
        config.update(custom_config)
    if config['type'] == 'file' and not os.path.exists(config['path']):
        os.makedirs(config['path'], exist_ok=True)  # not covered
    config.update(kwargs)
    globals()['DATASTORE_CONFIG'] = config
    return config


class GridFSDataStore(list):
    """store a list of unique GridFS datastores"""

    def add(self, conf, lpad=None):
        """add a datastore with a configuration and launchpad object lpad"""
        if conf['type'] != 'gridfs':
            return
        if self._get(conf) is None:
            lp_f = conf.get('launchpad')
            config = {'launchpad': lp_f, 'name': conf['name']}
            if lpad is None:
                lpad = LaunchPad() if lp_f is None else LaunchPad.from_file(lp_f)
            config['gridfs'] = GridFS(lpad.db, conf['name'])
            self.append(config)

    def get(self, conf):
        """get a datastore and add it if not yet included"""
        if conf['type'] == 'gridfs' and self._get(conf) is None:
            self.add(conf)
        return self._get(conf)

    def _get(self, conf):
        """get a datastore for specified configuration conf"""
        for entry in self:
            if (entry['launchpad'] == conf.get('launchpad')
               and entry['name'] == conf['name']):
                return entry['gridfs']
        return None


def get_uuid_filename(extension=None):
    """get a unique filename by applying evaluation mode policies"""
    basename = uuid.uuid4().hex
    filename = extension and f'{basename}.{extension}' or basename
    if 'WORKFLOW_EVALUATION_MODE' in os.environ and os.environ['WORKFLOW_EVALUATION_MODE'] == 'yes':
        if DATASTORE_CONFIG['type'] == 'file':
            directory = DATASTORE_CONFIG['path']
        else:
            msg = (f"Datastore type {DATASTORE_CONFIG['type']} cannot be used. "
                   f"Falling back to current working directory {os.getcwd()}.")
            warnings.warn(TextSUserWarning(msg))
            directory = os.path.abspath(os.getcwd())
    else:
        directory = TEMP_STORE_DIR.name
    return os.path.join(directory, filename)


def get_datastore_format_from_filename(filename):
    """return data format from filename suffix"""
    suffs = pathlib.Path(filename).suffixes
    if any(s in suffs for s in ('.yml', '.yaml')):
        return 'yaml'
    if '.json' in suffs:
        return 'json'
    if any(s in suffs for s in ('.hdf', '.h4', '.hdf4', '.he2', '.h5', '.hdf5', '.he5')):
        return 'hdf5'
    return 'custom'


def get_datastore_compress_from_filename(filename):
    """return compression from filename suffix"""
    return '.zz' in pathlib.Path(filename).suffixes


GRIDFS_DATASTORE = GridFSDataStore()
DATASTORE_CONFIG = get_datastore_config()


def write_to_file(path, data, fmt, compress):
    if fmt in ('json', 'yaml'):
        dumps_func = yaml.safe_dump if fmt == 'yaml' else json.dumps
        dump_func = yaml.safe_dump if fmt == 'yaml' else json.dump
        if compress:
            with open(path, 'xb') as out:
                out.write(zlib.compress(dumps_func(data).encode()))
        else:
            with open(path, 'x', encoding='utf-8') as out:
                dump_func(data, out)
    elif fmt == 'custom':
        if not hasattr(data, 'to_own_file'):
            raise RuntimeTypeError(
                f"type {type(data).__name__!r} does not support export to custom file format "
                f"(extension {pathlib.Path(path).suffix!r}); "
                f"supported formats: .yaml/.yml, .json, .h5/.hdf5"
            )
        data.to_own_file(path)
    else:
        assert fmt == 'hdf5'
        dump_hdf5(path, data, compress=compress)


def write_to_gridfs(gridfs, filename, data, fmt, compress):
    if fmt == 'hdf5':
        bytes_ = dumps_hdf5(data, compress=compress)
    elif fmt in ('json', 'yaml'):
        dumps_func = yaml.safe_dump if fmt == 'yaml' else json.dumps
        bytes_ = dumps_func(data).encode()
        bytes_ = zlib.compress(bytes_) if compress else bytes_
    else:
        raise NotImplementedError(f"gridfs datastore does not support format {fmt}")
    gridfs.put(bytes_, filename=filename)


def read_from_file(path, fmt, compress):
    if fmt == 'hdf5':
        return load_hdf5(path)
    load_func = yaml.safe_load if fmt == 'yaml' else json.load
    loads_func = yaml.safe_load if fmt == 'yaml' else json.loads
    if compress:
        with open(path, 'rb') as inp:
            return loads_func(zlib.decompress(inp.read()).decode())
    with open(path, 'r', encoding='utf-8') as inp:
        return load_func(inp)


def read_from_gridfs(gridfs, filename, fmt, compress):
    load_func = yaml.safe_load if fmt == 'yaml' else json.load
    loads_func = yaml.safe_load if fmt == 'yaml' else json.loads
    with gridfs.find_one({'filename': filename}) as inp:
        if fmt == 'hdf5':
            return loads_hdf5(inp.read())
        if compress:
            return loads_func(zlib.decompress(inp.read()).decode())
        return load_func(inp)


def dump_hdf5(path, data, compress=False):
    """dump JSON serializable data to HDF5"""
    value = json.dumps(data)
    str_dtype = h5py.string_dtype(encoding='utf-8')
    kwargs = {'dtype': str_dtype}
    if compress:
        kwargs.update({'compression': 'gzip', 'chunks': True})
    with h5py.File(path, 'x') as hdf5f:
        hdf5f.create_dataset('value', data=numpy.array([value], dtype=str_dtype), **kwargs)


def dumps_hdf5(data, compress=False):
    """dump JSON serializable data to HDF5 bytes"""
    import io
    value = json.dumps(data)
    str_dtype = h5py.string_dtype(encoding='utf-8')
    kwargs = {'dtype': str_dtype}
    if compress:
        kwargs.update({'compression': 'gzip', 'chunks': True})
    bio = io.BytesIO()
    with h5py.File(bio, 'w') as hdf5f:
        hdf5f.create_dataset('value', data=numpy.array([value], dtype=str_dtype), **kwargs)
    return bio.getvalue()


def load_hdf5(path):
    """load JSON serializable data from HDF5"""
    with h5py.File(path, 'r') as hdf5f:
        data = hdf5f['value'][()]
    if isinstance(data, numpy.ndarray):
        data = data.item()
    return json.loads(data)


def loads_hdf5(bytes_data):
    """load JSON serializable data from HDF5 bytes"""
    import io
    with h5py.File(io.BytesIO(bytes_data), 'r') as hdf5f:
        data = hdf5f['value'][()]
    if isinstance(data, numpy.ndarray):
        data = data.item()
    return json.loads(data)
