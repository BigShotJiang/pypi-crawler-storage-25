"""Custom classes for the AMML objects"""
import importlib
import inspect
import itertools
import os
from dataclasses import dataclass
from functools import cached_property
from copy import deepcopy
import numpy
import pandas
import pint_pandas
from pint_pandas import PintType
import ase
import ase.constraints
from ase.io import write, jsonio
from ase.geometry import wrap_positions
from ase.calculators.singlepoint import SinglePointCalculator
from ase.calculators.calculator import all_changes
from ase.config import cfg
from ase.io.trajectory import TrajectoryReader, TrajectoryWriter
from custodian.custodian import Job
from virtmat.language.utilities.ase_handlers import get_ase_property
from virtmat.language.utilities.ase_params import spec, check_params_types
from virtmat.language.utilities.ase_params import get_params_units, check_params_units
from virtmat.language.utilities.ase_params import get_params_magnitudes
from virtmat.language.utilities.ase_wrappers import set_kwargs_rng
from virtmat.language.utilities.context import in_unique_launchdir
from virtmat.language.utilities.custodian import Custodian
from virtmat.language.utilities.errors import RuntimeValueError, PropertyError
from virtmat.language.utilities.errors import ConvergenceError, ConfigurationError
from virtmat.language.utilities.errors import StructureInputError
from virtmat.language.utilities.formatters import formatter
from virtmat.language.utilities.ioops import get_uuid_filename
from virtmat.language.utilities.logging import get_logger
from virtmat.language.utilities.types import NA, is_numeric_scalar
from virtmat.language.utilities.units import ureg, get_pint_series
from virtmat.language.utilities.warnings import warnings, TextSUserWarning

pint_pandas.pint_array.DEFAULT_SUBDTYPE = None


def get_structure_dataframe(atoms):
    """create a structure dataframe from an ASE Atoms object"""
    lunit = pint_pandas.PintType('angstrom')
    munit = pint_pandas.PintType('amu')
    punit = pint_pandas.PintType('( amu * eV ) ** (1/2)')
    tunit = pint_pandas.PintType('dimensionless')

    symb = pandas.Series(atoms.get_chemical_symbols(), name='symbols')
    post = atoms.get_positions().transpose()
    posx = pandas.Series(pint_pandas.PintArray(post[0], dtype=lunit), name='x')
    posy = pandas.Series(pint_pandas.PintArray(post[1], dtype=lunit), name='y')
    posz = pandas.Series(pint_pandas.PintArray(post[2], dtype=lunit), name='z')
    momt = atoms.get_momenta().transpose()
    momx = pandas.Series(pint_pandas.PintArray(momt[0], dtype=punit), name='px')
    momy = pandas.Series(pint_pandas.PintArray(momt[1], dtype=punit), name='py')
    momz = pandas.Series(pint_pandas.PintArray(momt[2], dtype=punit), name='pz')
    tags = pandas.Series(pint_pandas.PintArray(atoms.get_tags(), dtype=tunit), name='tags')
    mass = pandas.Series(pint_pandas.PintArray(atoms.get_masses(), dtype=munit), name='masses')

    atoms_cols = [symb, posx, posy, posz, momx, momy, momz, mass, tags]
    atoms_df = pandas.concat(atoms_cols, axis=1)
    cell = ureg.Quantity(atoms.get_cell().array, 'angstrom')
    struct_cols = [{'atoms': atoms_df, 'cell': cell, 'pbc': atoms.get_pbc()}]
    return pandas.DataFrame(struct_cols)


def restore_na(df):
    """due to pandas issue https://github.com/pandas-dev/pandas/issues/61303"""
    for column in df.columns:
        if df[column].dtype.type is numpy.object_:
            if all(e is numpy.nan for e in df[column]):  # not covered
                df[column] = pandas.Series([pandas.NA]*len(df), name=column)


def merge_structures(structs):
    """create one AMML structure from an iterable of AMML structures"""
    struct_df = pandas.concat([s.tab for s in structs], ignore_index=True)
    restore_na(struct_df)
    return AMMLStructure(struct_df, next(iter(structs)).name)


def merge_calculators(calcs):
    """create one AMML calculator from an iterable of AMML calculators"""
    calc_df = pandas.concat([c.parameters for c in calcs], ignore_index=True)
    restore_na(calc_df)
    calc0 = next(iter(calcs))  # use this instead of calcs[0] because of sliced index
    return Calculator(calc0.name, calc_df, calc0.pinning, calc0.version)


def merge_algorithms(algos):
    """create one AMML algorithm from an iterable of AMML algorithms"""
    algo_df = pandas.concat([a.parameters for a in algos], ignore_index=True)
    restore_na(algo_df)
    algo0 = next(iter(algos))  # use this instead of algos[0] because of sliced index
    return Algorithm(algo0.name, algo_df, algo0.many_to_one)


class AMMLObject:
    """base class for all AMML objects"""


class AMMLIterableObject(AMMLObject):
    """base class for all iterable AMML objects"""

    def __init__(self, iterobj):
        assert isinstance(iterobj, pandas.DataFrame)
        self.iterobj = iterobj

    def __getitem__(self, key):
        if isinstance(key, int):
            dfr = self.iterobj.iloc[[key]]
            return tuple(next(dfr.itertuples(index=False, name=None)))
        raise TypeError('unknown key type')  # not covered

    def __len__(self):
        return len(self.iterobj)

    def reset_index(self, *args, **kwargs):
        """resets the index of properties table"""
        inplace = kwargs.get('inplace')
        kwargs['inplace'] = True
        self.iterobj.reset_index(*args, **kwargs)
        if inplace:  # not covered
            return None
        return self

    def dropna(self):
        """drop non-defined values from dataframe"""
        obj = deepcopy(self)
        obj.iterobj.dropna(inplace=True)
        return obj

    def iterrows(self):
        """return an iterator over dataframe rows"""
        return self.iterobj.iterrows()


class AMMLStructure(AMMLIterableObject):
    """"custom AMML Structure class"""
    intrinsics = ('name', 'kinetic_energy', 'temperature', 'distance_matrix',
                  'chemical_formula', 'number_of_atoms', 'cell_volume',
                  'center_of_mass', 'radius_of_gyration', 'moments_of_inertia',
                  'angular_momentum')

    def __init__(self, tab, name=NA, info=None):
        if 'pbc' in tab and 'cell' not in tab:
            for pbc in tab['pbc'].values:
                if any(pbc):
                    raise RuntimeValueError('cell must be specified with pbc')
        self.name = name
        self.tab = tab
        self.info = info or [{}]*len(self.tab)
        assert len(self.tab) == len(self.info)
        super().__init__(self.tab)

    def __getitem__(self, key):
        if isinstance(key, str):
            if key in self.intrinsics:
                return getattr(self, key)
            return self.tab[key]
        if isinstance(key, slice):
            return self.__class__(self.tab[key], self.name)
        return super().__getitem__(key)

    @cached_property
    def kinetic_energy(self):
        """get the kinetic energy of the nuclei"""
        kin = self.to_ase().apply(lambda x: x.get_kinetic_energy())
        return pandas.Series(kin, dtype=PintType('eV'), name='kinetic_energy')

    @cached_property
    def temperature(self):
        """get the temperature"""
        temp = self.to_ase().apply(lambda x: x.get_temperature())
        return pandas.Series(temp, dtype=PintType('kelvin'), name='temperature')

    @cached_property
    def distance_matrix(self):
        """get the matrix of interatomic distances (distance matrix)"""
        dis = self.to_ase().apply(lambda x: x.get_all_distances(mic=True))
        return pandas.Series((ureg.Quantity(a, 'angstrom') for a in dis), name='distance_matrix')

    @cached_property
    def chemical_formula(self):
        """get chemical formula as a string based on the chemical symbols"""
        chem_formula = self.to_ase().apply(lambda x: x.get_chemical_formula())
        return pandas.Series(chem_formula, name='chemical_formula')

    @cached_property
    def number_of_atoms(self):
        """get number of atoms"""
        natoms = self.to_ase().apply(len)
        return pandas.Series(natoms, dtype=PintType('dimensionless'), name='number_of_atoms')

    @cached_property
    def cell_volume(self):
        """get volume of the unit cell"""
        try:
            vol = self.to_ase().apply(lambda x: x.get_volume())
        except ValueError as err:
            if 'volume not defined' in str(err):
                raise RuntimeValueError(str(err)) from err
            raise err  # not covered
        return pandas.Series(vol, dtype=PintType('angstrom**3'), name='cell_volume')

    @cached_property
    def center_of_mass(self):
        """get the center of mass"""
        com = self.to_ase().apply(lambda x: x.get_center_of_mass())
        return pandas.Series((ureg.Quantity(a, 'angstrom') for a in com), name='center_of_mass')

    @cached_property
    def radius_of_gyration(self):
        """get the radius of gyration"""
        def rogf(pos):
            centroid = numpy.mean(pos, axis=0)
            norm_sqr = (numpy.linalg.norm(pos-centroid, axis=1))**2
            return numpy.sqrt(numpy.mean(norm_sqr, axis=0))
        rog = self.to_ase().apply(lambda x: rogf(x.get_positions()))
        return pandas.Series(rog, dtype=PintType('angstrom'), name='radius_of_gyration')

    @cached_property
    def moments_of_inertia(self):
        """get the moments of inertia along the principal axes"""
        moi = self.to_ase().apply(lambda x: x.get_moments_of_inertia())
        unit = 'amu * angstrom**2'
        return pandas.Series((ureg.Quantity(a, unit) for a in moi), name='moments_of_inertia')

    @cached_property
    def angular_momentum(self):
        """get the total angular momentum with respect to the center of mass"""
        ang = self.to_ase().apply(lambda x: x.get_angular_momentum())
        unit = '( amu * eV ) ** (1/2) * angstrom'
        return pandas.Series((ureg.Quantity(a, unit) for a in ang), name='angular_momentum')

    def to_own_file(self, filename):
        """store series of ase.Atoms objects to a file in supported format"""
        write(images=self.to_ase(), filename=filename)

    def to_ase(self):
        """create a series of ase.Atoms objects from a structure dataframe"""
        dfr_ase = self.get_ase_atoms_dataframe()
        series = dfr_ase.apply(lambda row: ase.Atoms(**row.to_dict()), axis=1)
        for atoms, info in zip(series, self.info):
            atoms.info = info
        return series.rename(self.name, inplace=True)

    def get_ase_atoms_dataframe(self):
        """return a unitless atoms dataframe from a structure dataframe with units"""
        dfr = self.tab
        dfr_ase = pandas.DataFrame()
        dfr_ase['symbols'] = dfr['atoms'].apply(lambda x: x.symbols.to_numpy())
        if 'cell' in dfr:
            dfr_ase['cell'] = dfr['cell'].apply(lambda x: x.to('angstrom').magnitude)
        else:
            dfr_ase[['cell']] = None

        dfr_ase['pbc'] = dfr['pbc'].to_numpy() if 'pbc' in dfr else None

        def xyz2pos(atoms):
            xcoord = get_pint_series(atoms['x']).pint.to('angstrom').values.data
            ycoord = get_pint_series(atoms['y']).pint.to('angstrom').values.data
            zcoord = get_pint_series(atoms['z']).pint.to('angstrom').values.data
            return numpy.array([xcoord, ycoord, zcoord]).transpose()

        def pxpypz2momenta(atoms):
            if 'px' not in atoms:
                return None
            units = '( amu * eV ) ** (1/2)'
            xcoord = get_pint_series(atoms['px']).pint.to(units).values.data
            ycoord = get_pint_series(atoms['py']).pint.to(units).values.data
            zcoord = get_pint_series(atoms['pz']).pint.to(units).values.data
            return numpy.array([xcoord, ycoord, zcoord]).transpose()

        dfr_ase['positions'] = dfr['atoms'].apply(xyz2pos)
        dfr_ase['momenta'] = dfr['atoms'].apply(pxpypz2momenta)
        dfr_ase['tags'] = dfr['atoms'].apply(lambda x: x.tags.to_numpy() if 'tags' in x else None)
        return dfr_ase

    @classmethod
    def from_ase(cls, atoms, name=NA):
        """create an AMML Structure from an ASE Atoms object"""
        if isinstance(atoms, ase.Atoms):
            return cls(get_structure_dataframe(atoms), name, info=[atoms.info])
        assert isinstance(atoms, (list, tuple, pandas.Series))
        atoms_dfs = [get_structure_dataframe(a) for a in atoms]
        return cls(pandas.concat(atoms_dfs, ignore_index=True), name,
                   info=[a.info for a in atoms])

    @classmethod
    def from_ase_calc(cls, calc, name=NA, default=NA):
        """create an AMML Structure from an ASE Calculator object"""
        if hasattr(calc, 'get_atoms'):
            return cls.from_ase(calc.get_atoms(), name)
        if calc.atoms is not None:  # not covered
            return cls.from_ase(calc.atoms, name)
        return default  # not covered

    @classmethod
    def from_ase_file(cls, filename):
        """create an AMML Structure object from a file in an ASE-supported format"""
        try:
            structs = ase.io.read(filename, index=':')
        except Exception as err:  # broad exception due to ase.io.read  # not covered
            raise StructureInputError(f'{err.__class__.__name__}: {str(err)}') from err
        struct_dfs = [get_structure_dataframe(s) for s in structs]
        return cls(pandas.concat(struct_dfs, ignore_index=True),
                   info=[a.info for a in structs])

    @classmethod
    def from_series(cls, series):
        """create an AMML Structure object from series of Structure objects"""
        tabs = (s.tab for s in series)
        tab = pandas.concat(tabs, axis='index', ignore_index=True)
        return cls(tab, name=series[0].name, info=[i for a in series for i in a.info])


class AMMLMethod(AMMLIterableObject):
    """base class for AMML Calculator and Algorithm classes"""
    def __init__(self, name, parameters):
        self.name = name
        assert parameters is not None
        if parameters is NA or len(parameters) == 0:
            p_spec = spec[self.name]['params']
            par_def = {k: v['default'] for k, v in p_spec.items() if 'default' in v}
            assert len(par_def) > 0
            self.parameters = pandas.DataFrame([par_def])
        else:
            self.parameters = parameters
            check_params_types(self.name, self.parameters)
            check_params_units(self.name, self.parameters)
        self.props = spec[self.name].get('properties') or []
        super().__init__(self.parameters)

    def __getitem__(self, key):
        if isinstance(key, str):
            if key in ('name', 'parameters'):
                return getattr(self, key)
            return self.parameters[key]
        if (isinstance(key, slice) or
           (isinstance(key, pandas.Series) and key.dtype is numpy.dtype(bool)) or
           (isinstance(key, (list, tuple)) and all(isinstance(s, str) for s in key))):
            obj = deepcopy(self)
            obj.parameters = obj.parameters[key]
            obj.iterobj = obj.parameters
            return obj
        return super().__getitem__(key)


class Calculator(AMMLMethod):
    """custom AMML Calculator class"""
    def __init__(self, name, parameters, pinning=NA, version=NA, task=NA):
        super().__init__(name, parameters)
        self.pinning = pinning
        self.version = version
        self.task = task
        self.check_task_parameters()

    def __getitem__(self, key):
        if isinstance(key, str):
            if key in ('pinning', 'version', 'task'):
                return getattr(self, key)
        return super().__getitem__(key)

    def to_ase(self):
        """create a series of ASE Calculator objects"""
        mod = __import__(spec[self.name]['module'], {}, None, [spec[self.name]['class']])
        calc_class = getattr(mod, spec[self.name]['class'])
        profile_dct = {}
        if spec[self.name].get('profile'):
            prof = spec[self.name]['profile']
            prof_mod = __import__(prof['module'], {}, None, [prof['class']])
            prof_class = getattr(prof_mod, prof['class'])
            if prof.get('envvars') and prof.get('kwargs'):
                prof_class_kwargs = {}
                for k, v in prof['kwargs'].items():
                    val = os.environ.get(v) or prof['envvars'][v]
                    if val:
                        prof_class_kwargs[k] = val  # not covered
                if prof_class_kwargs:
                    profile_dct['profile'] = prof_class(**prof_class_kwargs)  # not covered
            elif prof.get('kwargs'):  # not covered
                profile_dct['profile'] = prof_class(**prof['kwargs'])
            if not profile_dct:
                if self.name not in cfg.parser:
                    msg = f'Run-time environment of calculator {self.name} not properly configured'
                    raise ConfigurationError(msg)
                profile_dct['profile'] = prof_class.from_config(cfg, self.name)  # not covered
        calc_list = []
        for _, row in self.parameters.iterrows():
            params = get_params_magnitudes(dict(row), self.name)
            calc_list.append(calc_class(**profile_dct, **params))
        return pandas.Series(calc_list, name='calc')

    def check_task_parameters(self):
        """check whether parameters are compatible with task"""
        if self.task is NA:
            return
        assert self.task in spec[self.name]['tasks']
        for dct in pandas.DataFrame(self.parameters).to_dict(orient='records'):
            for par, func in spec[self.name]['tasks'][self.task].items():
                val = dct.get(par, NA)
                if not func(val):
                    raise RuntimeValueError(f'Parameter "{par}": {formatter(val)} '
                                            f'inconsistent with task "{self.task}"')

    def requires_dof(self):
        """determine whether the calculator requires changes of degrees of freedom"""
        if self.task is not NA:
            return self.task != 'single point'
        return None

    def run(self, struct, constrs=None, properties=None):
        """runner for objects with length 1"""
        assert len(struct.tab) == len(self.parameters) == 1
        calc_ase = self.to_ase()[0]
        struct_ase = ase.Atoms(struct.to_ase()[0])
        struct_ase.constraints = constrs
        calc_args = [struct_ase]
        # due to turbomole and free_electrons calcs
        calculate_spec = inspect.getfullargspec(calc_ase.calculate)
        if len(calculate_spec.args) == 4:
            if calculate_spec.defaults is None or len(calculate_spec.defaults) < 3:
                calc_args.extend([properties or [], all_changes])  # not covered
        calc_ase.calculate(*calc_args)
        if hasattr(calc_ase, 'converged'):
            if not calc_ase.converged:  # not covered
                raise ConvergenceError(f'calculation with {self.name} did not converge')
        return calc_ase


class Algorithm(AMMLMethod):
    """custom AMML Algorithm class"""
    def __init__(self, name, parameters, many_to_one=False):
        super().__init__(name, parameters)
        self.many_to_one = many_to_one
        module = importlib.import_module(spec[self.name]['module'])
        self._class = set_kwargs_rng(getattr(module, spec[self.name]['class']))
        self.set_params()

    def set_params(self, parameters=None):
        """create self.params (list of dicts per class and run) from parameters"""
        if parameters is None:
            parameters = self.parameters
        self.params = {k: [] for k in ('class', 'run')}
        param_spec = spec[self.name]['params']
        par_def = {k: v.get('default') for k, v in param_spec.items()}
        par_mth = {k: v.get('method') for k, v in param_spec.items()}
        for _, row in parameters.iterrows():
            params = {}
            params.update(par_def)
            params.update(dict(row))
            params = get_params_magnitudes(params, self.name)
            if params.get('trajectory'):
                params['trajectory'] = get_uuid_filename(extension='traj')
            if params.get('logfile'):
                params['logfile'] = get_uuid_filename(extension='log')
            for tp in ('class', 'run'):
                pars = {k: v for k, v in params.items() if par_mth[k] == tp}
                if 'interval' in pars:
                    pars['loginterval'] = pars.pop('interval')
                self.params[tp].append(pars)

    def run(self, struct, calc=NA, constrs=None, properties=None):
        """the algorithm runner, process objects with length 1"""
        assert len(self.params['class']) == len(self.params['run']) == 1
        atoms_list = struct.to_ase().to_list()
        for atoms in atoms_list:
            atoms.constraints = constrs
        if self.many_to_one:
            struct_ase = atoms_list
        else:
            assert len(struct.tab) == 1
            struct_ase = atoms_list[0]
        if calc is not NA:
            assert len(calc.parameters) == 1
            calc_ase = calc.to_ase()[0]
            if self.many_to_one:
                for atoms in struct_ase:
                    atoms.calc = calc_ase
            else:
                struct_ase.calc = calc_ase
        cls_params = dict(self.params['class'][0])
        traj_file = cls_params.pop('trajectory', None)
        if traj_file:
            with TrajectoryWriter(traj_file, atoms=struct_ase) as traj:
                with self._class(struct_ase, trajectory=traj, **cls_params) as algo_obj:
                    converged = algo_obj.run(**self.params['run'][0])
        else:
            with self._class(struct_ase, **cls_params) as algo_obj:
                converged = algo_obj.run(**self.params['run'][0])
        if converged is not None:
            # due to a bug in ASE 3.27.0, https://gitlab.com/ase/ase/-/issues/1857
            if not converged:  # not covered
                raise ConvergenceError(f'calculation with {self.name} did not converge')
        results = {'output_structure': struct_ase, 'algo': algo_obj}
        if calc is not NA:
            if self.many_to_one:
                results['output_structure'] = pandas.Series(algo_obj.results['final_images'])
            else:
                struct_ase.calc.calculate(struct_ase, properties or [], all_changes)
                results['calc'] = struct_ase.calc
        return results


class Property(AMMLIterableObject):
    """custom AMML Property class"""

    def __init__(self, names, structure, calculator=NA, algorithm=NA,
                 constraints=NA, results=NA, rng=NA, seed=NA):
        assert isinstance(names, list)
        self.names = names
        self.structure = structure
        self.calculator = calculator
        self.algorithm = algorithm
        if constraints is not NA:
            assert isinstance(constraints, (list, tuple))
            for constr in constraints:
                for atoms in structure.tab.atoms:
                    constr.check_consistency(len(atoms))
            self.constraints = constraints
        else:
            self.constraints = []  # not covered
        if len(self.structure) == 0:  # comes about due to slicing operations
            self.results = pandas.DataFrame(columns=['structure', 'calculator', 'algorithm'])
            super().__init__(self.results)
            return
        self.dof_vector, self.dof_number = self.get_dof()
        if self.calculator is not NA:
            self.requires_dof = self.calculator.requires_dof()
            if self.requires_dof is not None:
                if self.requires_dof and self.dof_number == 0:
                    msg = 'All degrees of freedom frozen. Hint: check task and constraints.'
                    raise RuntimeValueError(msg)
        if self.algorithm is not NA and 'rng' in spec[self.algorithm.name]['params']:
            self.algorithm.parameters['rng'] = rng
            self.algorithm.parameters['seed'] = seed
            self.algorithm.set_params()

        self.prop_map = {}
        for prop in self.names:
            if self.algorithm is not NA and prop in self.algorithm.props:
                self.prop_map[prop] = self.algorithm.name
            else:
                assert self.calculator is not NA and prop in self.calculator.props
                self.prop_map[prop] = self.calculator.name

        self.results = results if results is not NA else self.get_results()
        super().__init__(self.results)

    def __getitem__(self, key):
        keys = ('names', 'calculator', 'structure', 'algorithm', 'constraints',
                'results')
        if isinstance(key, str):
            if key in keys:
                return getattr(self, key)
            if key == 'output_structure':
                return AMMLStructure.from_series(self.results.output_structure)
            try:
                return getattr(self.results, key)
            except AttributeError as err:  # not covered
                raise PropertyError(f'property "{key}" not available') from err
        if isinstance(key, slice):
            struct = (merge_structures(self.results.structure[key])
                      if len(self.results[key]) > 0 else self.structure[0:0])
            if self.calculator is not NA:
                calc = (merge_calculators(self.results.calculator[key])
                        if len(self.results[key]) > 0 else self.calculator[0:0])
            else:
                assert all(c is NA for c in self.results.calculator[key])
                calc = NA
            if self.algorithm is not NA:
                algo = (merge_algorithms(self.results.algorithm[key])
                        if len(self.results[key]) > 0 else self.algorithm[0:0])
            else:
                assert all(a is NA for a in self.results.algorithm[key])
                algo = NA
            return self.__class__(self.names, struct, calculator=calc,
                                  algorithm=algo, constraints=self.constraints,
                                  results=self.results[key])
        return super().__getitem__(key)

    def get_dof(self):
        """return the non-frozen nuclear degrees of freedom"""
        atoms = self.structure[0:1].to_ase()[0]
        if len(self.constraints) > 0:
            new_pos = numpy.array(atoms.positions)
            for ind, (pbc, vec) in enumerate(zip(atoms.pbc, atoms.cell)):
                if pbc:
                    new_pos += 0.9*vec
                else:
                    new_pos[:, ind] += 0.9
            wrap_positions(new_pos, atoms.cell, atoms.pbc)
            for constr in self.constraints:
                for constr_ in constr.to_ase():
                    constr_.adjust_positions(atoms, new_pos)
            epsilon = numpy.finfo(numpy.float64).eps
            dof = numpy.abs(atoms.positions-new_pos) > epsilon
        else:
            dof = numpy.full((len(atoms), 3), True)
        return dof, numpy.sum(dof)

    def gen_func(self):
        """create a cartesian product of structure, calculator and algorithm"""
        calc_it = [NA] if self.calculator is NA else self.calculator
        algo_it = [NA] if self.algorithm is NA else self.algorithm
        if self.algorithm is not NA and self.algorithm.many_to_one:
            stru_it = [self.structure]
        else:
            stru_it = self.structure
        for ind, (calc, algo, struct) in enumerate(itertools.product(calc_it, algo_it, stru_it)):
            if calc is NA:
                calc_amml = NA
            else:
                calc_ = self.calculator
                calc_df = pandas.DataFrame([dict(zip(calc_.parameters, calc))])
                calc_amml = Calculator(parameters=calc_df, name=calc_.name,
                                       pinning=calc_.pinning, version=calc_.version)
            if algo is NA:
                algo_amml = NA
            else:
                algo_df = pandas.DataFrame([dict(zip(self.algorithm.parameters, algo))])
                algo_amml = Algorithm(self.algorithm.name, algo_df, self.algorithm.many_to_one)
                if 'rng' in spec[self.algorithm.name]['params']:
                    algo_amml.parameters['spawn'] = ureg.Quantity(ind)
                    algo_amml.set_params()

            if self.algorithm is not NA and self.algorithm.many_to_one:
                struct_amml = struct
            else:
                struct_df = pandas.DataFrame([dict(zip(self.structure.tab, struct))])
                struct_amml = AMMLStructure(struct_df, self.structure.name)
            yield struct_amml, calc_amml, algo_amml

    @in_unique_launchdir
    def get_results(self):
        """create a dataframe with results calculated with algorithm and calculator"""
        jobs = [PropertyJob(self, *args) for args in self.gen_func()]
        hashes = [job.basename for job in jobs]
        if len(set(hashes)) < len(hashes):  # detect duplicated jobs
            for group in pandas.Series(range(len(hashes))).groupby(hashes, sort=False).apply(list):
                if len(group) > 1:
                    lst = [(i, hashes[i]) for i in group]
                    msg = f'duplicated Property steps (jobs) found: {lst}'
                    warnings.warn(msg, TextSUserWarning)
                    for elem in group[1:]:  # avoid repeated evaluation
                        jobs[elem] = jobs[group[0]]

        Custodian(jobs=jobs, handlers=[]).run()
        out_df = pandas.DataFrame([job.output for job in jobs])
        for job in jobs:  # cleanup jobs persistence data
            job.clean_up()
        for col in out_df.columns:  # fix series of numeric scalars
            if is_numeric_scalar(out_df[col][0]):
                unit = out_df[col][0].units
                magnitudes = [e.to(unit).magnitude for e in out_df[col]]
                out_df[col] = pandas.Series(magnitudes, dtype=pint_pandas.PintType(unit))
        return out_df.replace({None: NA})


class PropertyJob(Job):
    """custodian job for property objects"""
    serializable_module = 'virtmat.language.utilities.serializable'

    def __init__(self, prop, struct, calc, algo):
        self.logger = get_logger(__name__)
        self.struct = struct
        self.calc = calc
        self.algo = algo
        self.output = {}
        self.output['structure'] = struct
        self.output['calculator'] = calc
        self.output['algorithm'] = algo
        self.prop = prop
        self.constrs = []
        for constr in self.prop.constraints:
            self.constrs.extend(constr.to_ase())
        self.completed = False
        self.saved = False
        func = getattr(importlib.import_module(self.serializable_module), 'get_stable_hash')
        self.basename = func((self.struct, self.calc, self.algo))
        self.logger.debug('property job: struct %s, calc %s, algo %s',
                          self.struct, self.calc, self.algo)
        self.logger.debug('property job: hash: %s', self.basename)
        self.filename = f'{self.__class__.__name__}_{self.basename}.yaml'

    def setup(self, directory='./'):
        path = os.path.join(directory, self.filename)
        if os.path.exists(path):
            module = importlib.import_module(self.serializable_module)
            self.output = getattr(module, 'load_value')(filename=path)
            self.completed = True
            self.saved = True
            self.logger.info('property job: recovered from file: %s', self.basename)
            return
        if os.environ.get('VRE_LANG_RECOVERY_LAUNCH') is not None:
            # enable application-level restart
            self.logger.info('property job: application-level recovery %s', self.basename)
            if self.algo is NA:
                if 'restart' in spec[self.prop.calculator.name]['params']:  # not covered
                    self.calc.parameters['restart'] = True
            elif 'restart' in spec[self.prop.algorithm.name]['params']:
                self.algo.parameters['restart'] = True  # not covered

    def run(self, directory='./'):
        if self.completed:
            return
        if self.algo is NA:
            res = self.calc.run(self.struct, constrs=self.constrs, properties=self.prop.names)
            result = {'calc': res}
            out_struct = AMMLStructure.from_ase_calc(
                  result['calc'],
                  self.prop.structure.name,
                  self.prop.structure
            )
        else:
            result = self.algo.run(self.struct, self.calc, constrs=self.constrs)
            out_struct = AMMLStructure.from_ase(
                result['output_structure'],
                self.prop.structure.name
            )
        self.output['output_structure'] = out_struct
        for p in self.prop.names:
            self.output[p] = get_ase_property(self.prop.prop_map[p], p, [result])[0]
        self.completed = True
        self.logger.info('property job: job completed %s', self.basename)

    def postprocess(self, directory='./'):
        if self.saved:
            return
        module = importlib.import_module(self.serializable_module)
        fw_obj = getattr(module, 'FWDataObject').from_obj(self.output)
        fw_obj.offload_data(
            datastore={'type': 'file'},
            filename=os.path.join(directory, self.filename)
        )
        self.saved = True
        self.logger.info('property job: saved in job file: %s', self.basename)

    def clean_up(self, directory=None):
        """cleanup persistence datastore"""
        if self.saved:
            directory = directory or os.getcwd()
            os.unlink(os.path.join(directory, self.filename))
        self.saved = False
        self.logger.info('property job: job file deleted: %s', self.basename)


class Constraint(AMMLObject):
    """custom AMML Constraint class"""
    ase_name_map = {'FixAtoms': 'FixedAtoms', 'FixedLine': 'FixedLine',
                    'FixedPlane': 'FixedPlane', 'FixScaled': 'FixScaled',
                    'FixCom': 'FixedCOM'}

    def __init__(self, name, **kwargs):
        assert name in self.ase_name_map.values()
        self.name = name
        self.kwargs = kwargs
        self.fixed = kwargs.get('fixed', NA)
        self.indices = self.fixed[self.fixed].index.values if self.fixed is not NA else None
        self.direction = kwargs.get('direction', NA)
        self.mask = kwargs.get('mask')

    def to_ase(self):
        """return ASE constraint objects"""
        if self.name == 'FixedCOM':
            return [ase.constraints.FixCom()]
        if self.name == 'FixedAtoms':
            return [ase.constraints.FixAtoms(indices=self.indices)]
        if self.name == 'FixScaled':  # not covered
            return [ase.constraints.FixScaled(self.indices, mask=self.mask)]
        direc = self.direction.magnitude
        if self.name == 'FixedLine':
            return [ase.constraints.FixedLine(self.indices, direction=direc)]
        assert self.name == 'FixedPlane'
        return [ase.constraints.FixedPlane(self.indices, direction=direc)]

    @classmethod
    def from_ase(cls, constr, natoms):
        """convert an ASE constraint object into AMML constraint"""
        constr_name = cls.ase_name_map[constr.__class__.__name__]
        if isinstance(constr, ase.constraints.FixCom):
            return cls(constr_name)
        indices = constr.get_indices()
        fixed = pandas.Series((i in indices for i in range(natoms)), name='fixed')
        if isinstance(constr, ase.constraints.FixScaled):  # not covered
            return cls(constr_name, fixed=fixed, mask=constr.mask)
        if isinstance(constr, ase.constraints.FixAtoms):
            return cls(constr_name, fixed=fixed)
        assert isinstance(constr, (ase.constraints.FixedLine, ase.constraints.FixedPlane))
        return cls(constr_name, fixed=fixed, direction=ureg.Quantity(constr.dir))

    def check_consistency(self, natoms):
        """check consistency of constraint with number of atoms"""
        if self.fixed is not NA and len(self.fixed) != natoms:
            msg = ('The list of fixed/non-fixed atoms in constraints and '
                   'atoms in structure have different lengths')
            raise RuntimeValueError(msg)  # not covered


@dataclass
class Trajectory(AMMLObject):
    """custom AMML trajectory class"""
    description: pandas.DataFrame = NA
    structure: AMMLStructure = NA
    properties: pandas.DataFrame = NA
    constraints: pandas.Series = NA
    filename: str = NA

    @classmethod
    def from_file(cls, filename, name=NA):
        """create an AMML Trajectory object from an ASE trajectory file"""
        with TrajectoryReader(filename) as traj:
            ase_desc = traj.description
            ase_structs = list(traj)
            ase_constrs = traj.constraints
        assert isinstance(ase_constrs, str)  # constraints in trajectory are JSON strings
        ase_constrs = [ase.constraints.dict2constraint(c) for c in jsonio.decode(ase_constrs)]
        return cls.from_ase(ase_desc, ase_structs, [ase_constrs]*len(ase_structs), filename, name)

    @classmethod
    def from_ase(cls, ase_desc, ase_structs, ase_constrs, filename=NA, name=NA):
        """create an AMML Trajectory object from a description, list of atoms objects,
           and list of constraints"""
        for atoms in ase_structs:
            assert hasattr(atoms, 'calc')
            assert isinstance(atoms.calc, SinglePointCalculator)
        structure = AMMLStructure.from_ase(ase_structs, name=name)
        description = pandas.DataFrame()
        if ase_desc is not None:
            description['type'] = pandas.Series(ase_desc['type'])
            if 'optimizer' in ase_desc:
                algo = description['optimizer'] = ase_desc['optimizer']
            elif 'md-type' in ase_desc:  # not covered
                algo = description['md-type'] = ase_desc['md-type']
            params = {k: v for k, v in ase_desc.items() if k in spec[algo]['params']}
            for ukey, uval in get_params_units(algo, params).items():
                if uval is not None:
                    mag = numpy.nan if ase_desc[ukey] is None else ase_desc[ukey]
                    description[ukey] = ureg.Quantity(mag, uval)
                else:  # not covered
                    description[ukey] = ase_desc[ukey]
        results = [{'calc': a.calc} for a in ase_structs]
        properties = pandas.DataFrame()
        for key in ase_structs[0].calc.export_properties().keys():
            properties[key] = get_ase_property('SinglePointCalculator', key, results)
        ase_natoms = [len(a) for a in ase_structs]
        assert len(set(ase_natoms)) == 1
        constrs = [[Constraint.from_ase(c, ase_natoms[0]) for c in cs] for cs in ase_constrs]
        constraints = pandas.Series(constrs, name='constraints')
        return cls(description, structure, properties, constraints, filename)

    def __getitem__(self, key):
        if isinstance(key, int):
            props = self.properties.iloc[[key]].itertuples(index=False, name=None)
            return tuple((*self.structure[key], *props))
        if isinstance(key, str):
            return getattr(self, key)
        if isinstance(key, slice):
            return self.__class__(self.description, self.structure[key],
                                  self.properties.iloc[key], self.constraints[key],
                                  self.filename)
        raise TypeError(f'unknown key type {type(key)}')  # not covered
