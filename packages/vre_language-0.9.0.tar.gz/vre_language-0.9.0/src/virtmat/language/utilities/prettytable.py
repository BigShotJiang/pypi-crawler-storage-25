"""module for pretty tables"""
import importlib


def get_prettytable(dataframe):
    """convert pandas dataframe to a prettytable object"""
    try:
        module = importlib.import_module('prettytable')
        class_ = getattr(module, 'PrettyTable')
    except (ImportError, AttributeError):  # not covered
        return str(dataframe)  # failover
    table = class_(list(dataframe.columns))
    for tpl in dataframe.itertuples(index=False, name=None):
        table.add_row(tpl)
    table.align = 'l'
    table.max_width = 120
    return table
