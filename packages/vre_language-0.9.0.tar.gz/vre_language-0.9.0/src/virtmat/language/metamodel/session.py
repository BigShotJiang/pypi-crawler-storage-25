"""Utilities for session metamodel and related operations"""
import os
from functools import cached_property
from textx import metamodel_from_file
from virtmat.language.metamodel.processors import table_processor, null_processor, number_processor
from virtmat.language.metamodel.properties import add_metamodel_classes_attributes
from virtmat.language.utilities.textx import GRAMMAR_LOC
from virtmat.language.utilities.errors import textxerror_wrap
from virtmat.language.utilities.typemap import typemap
from virtmat.language.utilities.typechecks import checktype_value
from virtmat.language.constraints.typechecks import (tuple_type, series_type, table_type,
                                                     dict_type, array_type, quantity_type,
                                                     alt_table_type)
from virtmat.language.interpreter.instant_executor import (tuple_value, series_value, table_value, dict_value,
                                                           bool_str_array_value, numeric_array_value, alt_table_value,
                                                           numeric_subarray_value, plain_type_value, quantity_value)


def add_value_session_model(metamodel):
    """add the value-property for objects of session manager models"""
    mapping_dict = {
        'Tuple': tuple_value,
        'Series': series_value,
        'Table': table_value,
        'Dict': dict_value,
        'AltTable': alt_table_value,
        'BoolArray': bool_str_array_value,
        'StrArray': bool_str_array_value,
        'IntArray': numeric_array_value,
        'FloatArray': numeric_array_value,
        'ComplexArray': numeric_array_value,
        'IntSubArray': numeric_subarray_value,
        'FloatSubArray': numeric_subarray_value,
        'ComplexSubArray': numeric_subarray_value,
        'String': plain_type_value,
        'Bool': plain_type_value,
        'Quantity': quantity_value
    }
    for key, func in mapping_dict.items():
        metamodel[key].value = cached_property(textxerror_wrap(checktype_value(func)))
        metamodel[key].value.__set_name__(metamodel[key], 'value')


def add_types_session_model(metamodel):
    """add the type-property for objects of session manager models"""
    mapping_dict = {
        'Tuple': tuple_type,
        'Series': series_type,
        'Table': table_type,
        'Dict': dict_type,
        'AltTable': alt_table_type,
        'BoolArray': array_type,
        'StrArray': array_type,
        'IntArray': array_type,
        'FloatArray': array_type,
        'ComplexArray': array_type,
        'IntSubArray': array_type,
        'FloatSubArray': array_type,
        'ComplexSubArray': array_type,
        'Quantity': quantity_type
    }
    for key, function in mapping_dict.items():
        metamodel[key].type_ = cached_property(textxerror_wrap(function))
        metamodel[key].type_.__set_name__(metamodel[key], 'type_')
        metamodel[key].datatypes = property(lambda x: x.type_ and getattr(x, '_datatypes', None))
        metamodel[key].datalen = property(lambda x: x.type_ and getattr(x, '_datalen', None))
    metamodel['Bool'].type_ = typemap['Boolean']
    metamodel['Bool'].datatypes = None
    metamodel['Bool'].datalen = None
    metamodel['String'].type_ = typemap['String']
    metamodel['String'].datatypes = None
    metamodel['String'].datalen = None


def get_session_metamodel():
    """set up a metamodel from session grammar"""
    session_grammar = os.path.join(os.path.dirname(GRAMMAR_LOC), 'session.tx')
    metamodel = metamodel_from_file(session_grammar, auto_init_attributes=False)
    add_metamodel_classes_attributes(metamodel)
    add_types_session_model(metamodel)
    add_value_session_model(metamodel)
    processors = {'Null': null_processor, 'Number': number_processor, 'Table': table_processor}
    metamodel.register_obj_processors(processors)
    return metamodel
