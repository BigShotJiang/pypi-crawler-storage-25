"""
Register object and model processors

Model processors are callables that are called at the end of the parsing when
the whole model is instantiated. These processors accept the model and metamodel
as parameters.

Object processors are registered for particular classes (grammar rules) and are
called when objects of the given class are instantiated. Object processors
are registered by defining a map between a rule name and the callable that will
process the instances of the metamodel class correspoding to the rule. The rule
must be a match rule and no abstract rule.

Register object processors *only here*
"""
import inspect
from textx import get_metamodel
from virtmat.language.constraints.cyclic import check_recursive_functions_processor
from virtmat.language.constraints.processors import add_constraints_processors
from virtmat.language.constraints.processors import check_variable_update_processor
from virtmat.language.interpreter.workflow_executor import workflow_model_processor
from virtmat.language.utilities.textx import isinstance_m
from virtmat.language.utilities.errors import raise_exception, StaticTypeError
from virtmat.language.utilities.warnings import warnings, TextSUserWarning
from virtmat.language.utilities.types import NA, get_function_signature
from virtmat.language.utilities.typemap import typemap, get_basetype_from_annotation
from virtmat.language.utilities.formatters import formatter
from .function import function_call_processor
from .workflow import source_code_statement_processor, qadapter_processor
from .workflow import default_worker_name_processor, resources_processor
from .workflow import parallelizable_processor, variable_update_processor
from .amml import amml_calculator_processor, amml_algorithm_processor
from .amml import amml_property_processor, chem_term_processor, chem_term_model_processor
from .io import output_processor


def object_import_processor(obj):
    """add namespace of parent ObjectImports to ObjectImport, check if callable"""
    obj.namespace = obj.parent.namespace
    if callable(obj.value):
        signature = get_function_signature(obj.value)
        if signature:
            for par in signature.parameters.values():
                if par.annotation is not inspect.Signature.empty:
                    try:
                        get_basetype_from_annotation(par.annotation)
                    except StaticTypeError:
                        msg = (f'Argument "{par.name}" of imported function "{obj.name}" '
                               f'has unsupported type {formatter(par.annotation)}.')
                        raise_exception(obj, StaticTypeError, msg)
            if signature.return_annotation is not inspect.Signature.empty:
                try:
                    get_basetype_from_annotation(signature.return_annotation)
                except StaticTypeError:
                    msg = (f'Return type {formatter(signature.return_annotation)} '
                           f'of imported function "{obj.name}" is not supported.')
                    raise_exception(obj, StaticTypeError, msg)


def object_to_processor(obj):
    """maintain backward compatibility to older grammar"""
    if not hasattr(obj, 'source'):
        gen_ref = get_metamodel(obj)['GeneralReference']()
        gen_ref.ref = obj.ref
        gen_ref.accessors = []
        obj.source = gen_ref


def table_processor(obj):
    """fill in the list of table columns"""
    if obj.columns_tuple:
        assert len(obj.columns) == 0
        obj.columns = obj.columns_tuple.params


def null_processor(obj):
    """set the attributes of Null objects"""
    obj.func = (lambda: NA, tuple())
    obj.value = NA


def number_processor(obj):
    """set the attributes of Number objects"""
    if obj.imag_ is None:
        obj.value = obj.real
        obj.type_ = typemap['Integer'] if isinstance(obj.real, int) else typemap['Float']
    else:
        imag = - obj.imag_ if obj.sign == '-' else obj.imag_
        real = type(imag)(0) if obj.real is None else obj.real
        obj.value = complex(real, imag)
        obj.type_ = typemap['Complex']


def variable_processor(obj):
    """apply constraints to variable objects in workflow mode"""
    if obj.non_strict:
        if not isinstance_m(obj.parameter, ('IfFunction', 'IfExpression', 'Or')):
            msg = 'non-strict annotation only valid with if and boolean expressions'
            raise_exception(obj, StaticTypeError, msg)


def general_reference_processor(obj):
    """check the metamodel type of the ref attribute (matched any object in RREL)"""
    classes = ['Variable', 'Dummy', 'ObjectImport', 'Series']
    if not isinstance_m(obj.ref, classes):  # not covered
        msg = f'invalid use of reference to {obj.ref.__class__.__name__}'
        raise_exception(obj, StaticTypeError, msg)


def condition_comparison_processor(obj):
    """normalize: column is on the left, operand is on the right"""
    inv_map = {'==': '==', '!=': '!=', '>': '<', '<': '>', '>=': '<=', '<=': '>='}
    if obj.operand_left is not None:
        obj.operand_right = obj.operand_left
        obj.operand_left = None
        obj.column_left = obj.column_right
        obj.column_right = None
        obj.operator = inv_map[obj.operator]


def print_parameter_processor(obj):
    """process print parameter objects"""
    if not hasattr(obj, 'inp_units'):  # compatibility to grammar version < 28
        setattr(obj, 'inp_units', getattr(obj, 'units', None))  # not covered


def tag_processor(obj):  # not covered
    """warn if tag is found in instant or in deferred evaluation modes"""
    msg = 'tags are interpreted only in workflow evaluation mode'
    warnings.warn(TextSUserWarning(msg, obj=obj))


def vary_processor(obj):
    """warn if vary is found in instant or in deferred evaluation modes"""
    warnings.warn(TextSUserWarning('vary statement has no effect', obj=obj))


def add_obj_processors(metamodel, wflow_processors=False):
    """register object processors, one per each class in the metamodel"""
    obj_processors = {'Null': null_processor,
                      'Number': number_processor,
                      'GeneralReference': general_reference_processor,
                      'ObjectImport': object_import_processor,
                      'ObjectTo': object_to_processor,
                      'Table': table_processor,
                      'ConditionComparison': condition_comparison_processor,
                      'ChemTerm': chem_term_processor,
                      'AMMLCalculator': amml_calculator_processor,
                      'AMMLAlgorithm': amml_algorithm_processor,
                      'AMMLProperty': amml_property_processor}
    if wflow_processors:
        obj_processors['Variable'] = variable_processor
        obj_processors['Resources'] = resources_processor
        obj_processors['Map'] = parallelizable_processor
        obj_processors['Filter'] = parallelizable_processor
        obj_processors['Reduce'] = parallelizable_processor
        obj_processors['PrintParameter'] = print_parameter_processor
    else:
        obj_processors['Vary'] = vary_processor
        obj_processors['Tag'] = tag_processor
    metamodel.register_obj_processors(obj_processors)


def add_mod_processors(metamodel, constr_processors=True, io_processors=True,
                       wflow_processors=False):
    """register model processors in the order of their application"""
    if constr_processors:
        metamodel.register_model_processor(check_recursive_functions_processor)
    metamodel.register_model_processor(function_call_processor)
    metamodel.register_model_processor(chem_term_model_processor)
    if constr_processors:
        metamodel.register_model_processor(check_variable_update_processor)
    if wflow_processors:
        metamodel.register_model_processor(source_code_statement_processor)
        metamodel.register_model_processor(variable_update_processor)
    if constr_processors:
        add_constraints_processors(metamodel)
    if wflow_processors:
        metamodel.register_model_processor(default_worker_name_processor)
        metamodel.register_model_processor(qadapter_processor)
        metamodel.register_model_processor(workflow_model_processor)
    elif io_processors:
        metamodel.register_model_processor(output_processor)


def add_processors(metamodel, constr_processors=True, io_processors=True,
                   wflow_processors=False):
    """register the processors on the metamodel instance"""
    add_obj_processors(metamodel, wflow_processors)
    add_mod_processors(metamodel, constr_processors=constr_processors,
                       io_processors=io_processors,
                       wflow_processors=wflow_processors)
