"""input/output processors"""
from textx import get_children_of_type


def output_processor(model, _):
    """store objects to files or urls"""
    for obj in get_children_of_type('ObjectTo', model):
        _ = obj.value
