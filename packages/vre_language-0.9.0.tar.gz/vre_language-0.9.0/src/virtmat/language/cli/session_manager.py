"""manage sessions for dynamic model processing / incremental development"""
import os
import sys
from code import InteractiveConsole
from prompt_toolkit import PromptSession
from prompt_toolkit.shortcuts import CompleteStyle
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import style_from_pygments_cls
from texts_style import VMLangStyle
from texts_lexer import VMLexer
from textx import textx_isinstance
from fireworks import LaunchPad
from fireworks.user_objects.queue_adapters.common_adapter import CommonAdapter
from virtmat.language.utilities.textx import GRAMMAR_LOC, GrammarString
from virtmat.language.utilities.textx import get_expected, TextXCompleter
from virtmat.language.utilities.help import HELP_TOP_MESSAGE
from virtmat.language.utilities.errors import error_handler, ModelNotFoundError
from virtmat.language.utilities.errors import RuntimeTypeError, QueryError
from virtmat.language.utilities.warnings import warnings, TextSUserWarning
from virtmat.language.utilities.formatters import formatter
from virtmat.language.utilities.fireworks import get_model_history, get_model_tag
from virtmat.language.utilities.fireworks import get_models_overview
from virtmat.language.utilities.fireworks import rerun_vars, cancel_vars, recover_vars
from virtmat.language.utilities.fireworks import get_lost_reserved_running
from virtmat.language.utilities.fireworks import get_wflows_from_user_query
from virtmat.language.utilities.fireworks import object_from_file
from virtmat.language.utilities.fireworks import expand_query_prefix
from virtmat.language.utilities.serializable import tag_serialize
from virtmat.language.utilities.version import VERSION
from virtmat.language.utilities import logging
from virtmat.language.utilities.indentation import compute_indent
from virtmat.language.utilities.prettytable import get_prettytable
from virtmat.language.interpreter.session import Session
from virtmat.language.metamodel.session import get_session_metamodel


def tab_handler(event):
    buff = event.app.current_buffer
    if buff.complete_state:
        buff.complete_next()
    else:
        buff.start_completion(select_first=False)


def enter_handler(event):
    buff = event.app.current_buffer
    if buff.complete_state and buff.complete_state.current_completion is not None:
        buff.apply_completion(buff.complete_state.current_completion)
    else:
        buff.validate_and_handle()


def make_key_bindings() -> KeyBindings:
    """Return KeyBindings with Tab/Enter handlers for the interactive prompt."""
    kb = KeyBindings()
    kb.add('tab')(tab_handler)
    kb.add('enter')(enter_handler)
    return kb


class SessionManager(InteractiveConsole):
    """session manager for basic interactive work using a text terminal"""
    def __init__(self, lpad, qadapter_file=None, enable_logging=False, logfile=None,
                 ignore_warnings=False, **kwargs):
        super().__init__()
        self._need_more = False  # track whether last input line is complete
        self._buffer_for_indent = ''  # cache multline buffer
        self.enable_logging = enable_logging
        self.logfile = logfile
        self.logger = logging.get_logger(__name__)
        self.logger.info('Initializing')
        self.lpad = lpad
        self.qadapter_file = qadapter_file
        self.ignore_warnings = ignore_warnings
        self.kwargs = dict(kwargs)
        del self.kwargs['uuid']
        del self.kwargs['grammar_path']
        self.session = Session(lpad, **kwargs)
        self.uuid = self.session.uuids[0]
        self.metamodel = get_session_metamodel()
        self.grammar_path = kwargs['grammar_path'] or GRAMMAR_LOC
        model_grammar = GrammarString(self.grammar_path).string
        opts1 = get_expected(self.metamodel, '%')[0]
        opts2 = get_expected(self.session.metamodel, '%')[2]
        self.completer = TextXCompleter(model_grammar, opts1+opts2, console=self)
        self.completer.model = self.session.get_model(uuid=self.uuid)
        if sys.stdin.isatty():
            kb = make_key_bindings()
            style = style_from_pygments_cls(VMLangStyle)
            self.prompt_session = PromptSession(lexer=PygmentsLexer(VMLexer),
                                                completer=self.completer,
                                                style=style,
                                                complete_while_typing=False,
                                                complete_style=CompleteStyle.COLUMN,
                                                key_bindings=kb)
        else:
            self.prompt_session = None

    def raw_input(self, prompt=''):
        """Determine continuation prompt; append indent to continuation lines"""
        indent = ''
        if self._need_more:
            indent = compute_indent(self._buffer_for_indent)
            prompt = f'{prompt}{indent}'
        if self.prompt_session is not None:
            line = self.prompt_session.prompt(prompt)
        else:
            line = input(prompt)
        return indent + line

    def main_loop(self):
        """this is the main loop of the interactive session"""
        if not sys.stdin.isatty():
            msg = 'Session running in a shell not connected to a terminal'
            self.logger.warning(msg)
            warnings.warn(msg, TextSUserWarning)
        ps1_save = getattr(sys, 'ps1', None)
        ps2_save = getattr(sys, 'ps2', None)
        try:
            sys.ps1 = 'Input > '
            sys.ps2 = '      > '
            self.interact(banner='Welcome to textS/textM. Type %help for some help.',
                          exitmsg='')
        finally:
            print('Exiting')
            self.session.stop_runner()
            sys.ps1 = ps1_save
            sys.ps2 = ps2_save

    def runsource(self, source, filename=None, symbol=None):
        """this is used by the superclass to realize a REPL"""
        if source.strip():
            try:
                need_inp = self.process_input(source)
            finally:
                self.check_session()
            #  Update continuation state and buffer for indentation policy
            self._need_more = bool(need_inp)
            if self._need_more:
                if self._buffer_for_indent:
                    self._buffer_for_indent = f'{self._buffer_for_indent}\n{source}'
                else:
                    self._buffer_for_indent = source
            else:
                self._buffer_for_indent = ''
            return need_inp
        return False

    @error_handler
    def get_model_value(self, *args, **kwargs):
        """wrapped and evaluated version of get_model() of the Session class"""
        return getattr(self.session.get_model(*args, uuid=self.uuid, **kwargs), 'value', '')

    def check_session(self):
        """check session consistency"""
        if self.uuid is None:
            self.uuid = self.session.uuids[0]
        if (self.uuid and (len(self.session.models) != len(self.session.uuids) or
           any(u is None for u in self.session.uuids))):  # not covered
            self.session = Session(self.lpad, uuid=self.uuid, **self.kwargs)
            msg = 'Session has been restarted'
            self.logger.warning(msg)
            warnings.warn(msg, TextSUserWarning)

    @error_handler
    def process_input(self, input_str):
        """create a session model from input string"""
        model = self.metamodel.model_from_str(input_str)
        self.logger.debug('process_input: session model: %s', model)
        if textx_isinstance(model, self.metamodel['Magic']):
            self._process_magic(model)
            return False
        if textx_isinstance(model, self.metamodel['Expression']):
            output = self.get_model_value(model_str=f'print({input_str})')
            if output is not None:
                print('Output >', output)
            return False
        assert textx_isinstance(model, self.metamodel['Program'])
        if self.completer.is_complete(input_str):
            output = self.get_model_value(model_str=input_str)
            if output:
                print('Output >', output)
            self.completer.model = self.session.get_model(uuid=self.uuid)
            return False
        return True  # not covered

    @error_handler
    def _process_magic(self, session_model):
        commands = {
            'uuid': self._handle_uuid,
            'help': self._handle_help,
            'stop': self._handle_stop,
            'start': self._handle_start,
            'sleep': self._handle_sleep,
            'new': self._handle_new,
            'vary': self._handle_vary,
            'hist': self._handle_history,
            'history': self._handle_history,
            'tag': self._handle_tag,
            'find': self._handle_find,
            'rerun': self._handle_rerun,
            'cancel': self._handle_cancel,
            'recover': self._handle_recover,
            'logging': self._handle_logging,
            'logfile': self._handle_logfile,
            'load': self._handle_load,
            'launchpad': self._handle_launchpad,
            'qadapter': self._handle_qadapter,
            'warnings': self._handle_warnings,
            'async': self._handle_async,
            'on_demand': self._handle_on_demand,
            'unique_launchdir': self._handle_unique_launchdir,
            'detect_duplicates': self._handle_detect_duplicates,
            'version': self._handle_version
        }
        self.logger.debug('process_magic: %s', session_model.com)
        if session_model.com in ('exit', 'bye', 'close', 'quit'):
            raise SystemExit()
        commands[session_model.com](session_model)

    def _handle_stop(self, _):
        self.session.stop_runner()
        self.kwargs['autorun'] = False

    def _handle_start(self, _):
        self.session.start_runner()
        self.kwargs['autorun'] = True

    def _handle_sleep(self, session_model):
        if self.session.wfe:
            if session_model.arg is None:
                print(self.session.wfe.sleep_time)
            else:
                self.session.wfe.sleep_time = session_model.arg
                self.kwargs['sleep_time'] = session_model.arg

    def _handle_new(self, session_model):
        self.kwargs['model_path'] = session_model.arg
        self.session.stop_runner()
        self.session = Session(self.lpad, create_new=not self.kwargs['model_path'],
                               grammar_path=self.grammar_path, **self.kwargs)
        self.uuid = self.session.uuids[0]
        model = self.session.get_model(uuid=self.uuid)
        self.completer.model = model
        print(f'Started new session with uuids {formatter(self.session.uuids)}', file=sys.stderr)
        if session_model.arg:
            print('\n' + getattr(model, 'value', ''))

    def _handle_uuid(self, session_model):
        if session_model.arg is None:
            print('uuids:', formatter(self.uuid), formatter(self.session.uuids))
        elif session_model.arg != self.uuid:
            self._switch_model(session_model.arg)
            print(f'Switched to model with UUID: {session_model.arg}')

    def _handle_vary(self, _):
        print('vary:', formatter(self.session.get_vary_df()))

    def _handle_history(self, _):
        if not self.uuid:
            print('No model is currently loaded.', file=sys.stderr)
            return
        print(get_prettytable(get_model_history(self.lpad, self.uuid)))
        if self.session.wfe:
            unres_vars, lostj_vars = get_lost_reserved_running(wfengine=self.session.wfe)
        else:
            unres_vars, lostj_vars = get_lost_reserved_running(self.lpad, self.uuid)
        print(f'Lost RESERVED: {formatter(unres_vars)}\nLost RUNNING: {formatter(lostj_vars)}')

    def _handle_tag(self, _):
        print(formatter(get_model_tag(self.lpad, self.uuid)))

    def _handle_find(self, session_model):
        self.logger.debug('process_magic: find: %s', formatter(session_model.arg.value))
        try:
            q_dict = expand_query_prefix(tag_serialize(session_model.arg.value))
        except RuntimeTypeError as err:
            self.logger.error('process_magic: %s', str(err))
            raise QueryError(err) from err
        self.logger.debug('process_magic: query: %s', q_dict)
        matching_uuids = get_wflows_from_user_query(self.lpad, q_dict)
        if matching_uuids:
            if session_model.load_one:
                if self.uuid not in matching_uuids:
                    self._switch_model(matching_uuids[0])
                    print('uuids:', formatter(self.uuid), formatter(self.session.uuids))
            else:
                print(get_prettytable(get_models_overview(self.lpad, matching_uuids)))

    def _handle_rerun(self, session_model):
        if self.uuid:
            rerun_vars(self.lpad, self.uuid, session_model.args)
        else:
            print('No model is currently loaded.', file=sys.stderr)

    def _handle_cancel(self, session_model):
        if self.uuid:
            cancel_vars(self.lpad, self.uuid, session_model.args)
        else:
            print('No model is currently loaded.', file=sys.stderr)

    def _handle_recover(self, session_model):
        if self.uuid:
            recover_vars(self.lpad, self.uuid, session_model.args)
        else:
            print('No model is currently loaded.', file=sys.stderr)

    def _handle_help(self, _):
        print(HELP_TOP_MESSAGE)

    def _handle_version(self, _):
        print(VERSION)

    def _switch_model(self, new_uuid):
        """switch from one to another model"""
        if new_uuid in self.session.uuids:
            self.uuid = new_uuid  # not covered
        else:
            self.session.stop_runner()
            try:
                self.session = Session(self.lpad, uuid=new_uuid, **self.kwargs)
            except ModelNotFoundError as err:
                if self.kwargs['autorun']:
                    self.session.start_runner()
                raise err
            self.uuid = new_uuid
            self.completer.model = self.session.get_model(uuid=self.uuid)

    def _handle_logging(self, session_model):
        """set the logging level or turn logging off"""
        level = session_model.arg
        if level is None:
            if self.enable_logging:
                curr_level = logging.logging.getLevelName(logging.LOGGING_LEVEL)
                print(f'Current level: {curr_level}')
            else:
                print('Logging not activated.')
        elif level.lower() == 'off':
            logging.disable_logging()
            self.enable_logging = False
        elif level.lower() == 'on' and not self.enable_logging:
            logging.enable_logging()
            self.enable_logging = True
        else:
            if not self.enable_logging:
                logging.enable_logging()
                self.enable_logging = True
            logging.LOGGING_LEVEL = logging.get_logging_level(level)
            if logging.LOGGING_LEVEL > 20:
                warnings.filterwarnings('ignore')
        self.logger = logging.get_logger(__name__)

    def _handle_warnings(self, session_model):
        """turn on/off warnings"""
        if session_model.arg is None:
            print('off' if self.ignore_warnings else 'on')
        elif session_model.arg.lower() == 'off':
            warnings.filterwarnings('ignore')
            self.ignore_warnings = True
        else:
            warnings.resetwarnings()
            warnings.filterwarnings('default', category=TextSUserWarning)
            self.ignore_warnings = False

    def _handle_logfile(self, session_model):
        """set a file for logging"""
        if session_model.arg:
            logging.logging.basicConfig(filename=session_model.arg)
            self.logfile = session_model.arg
        elif self.logfile is None:
            print('No logfile.')
        else:
            print(f'Current logfile: {os.path.abspath(self.logfile)}')

    def _handle_load(self, session_model):
        """load vre-language model from a file"""
        model = self.session.get_model(uuid=self.uuid, model_path=session_model.arg)
        if model:
            self.completer.model = model
            print(getattr(model, 'value', ''))

    def _handle_launchpad(self, session_model):
        """select launchpad file"""
        if session_model.arg is None:
            print(formatter(self.session.lp_path))
        else:
            lp_path = os.path.abspath(session_model.arg)
            if lp_path != os.path.abspath(self.session.lp_path):
                self.session.stop_runner()
                self.lpad = object_from_file(LaunchPad, lp_path)
                self.kwargs['lp_path'] = lp_path
                self.kwargs['config_dir'] = os.path.dirname(lp_path)
                self.session = Session(self.lpad, grammar_path=GRAMMAR_LOC, **self.kwargs)
                print(f'Switched to launchpad {lp_path}\n', file=sys.stderr)

    def _handle_qadapter(self, session_model):
        """specify default qadapter file"""
        if session_model.arg is None:
            print(formatter(self.qadapter_file) if self.qadapter_file else 'No qadapter file.')
        elif session_model.arg:
            qadapter_path = os.path.abspath(session_model.arg)
            self.kwargs['qadapter'] = object_from_file(CommonAdapter, qadapter_path)
            self.qadapter_file = qadapter_path
            if self.kwargs['async_run']:
                assert self.session.wfe
                self.session.stop_runner()
                wfe_keys = ('qadapter', 'sleep_time', 'unique_launchdir')
                wfe_kwargs = {k: v for k, v in self.kwargs.items() if k in wfe_keys}
                self.session.init_async_run(self.kwargs['config_dir'], wfe_kwargs)

    def _handle_async(self, session_model):
        """toggle async evaluation in a background thread"""
        current = 'on' if self.kwargs['async_run'] else 'off'
        if session_model.arg is None:
            print(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.session.stop_runner()
                self.session.wfe = None
                self.kwargs['async_run'] = False
                self.session.async_run = self.kwargs['async_run']
            else:
                self.kwargs['async_run'] = True
                self.session.async_run = self.kwargs['async_run']
                wfe_keys = ('qadapter', 'sleep_time', 'unique_launchdir')
                wfe_kwargs = {k: v for k, v in self.kwargs.items() if k in wfe_keys}
                self.session.init_async_run(self.kwargs['config_dir'], wfe_kwargs)

    def _handle_on_demand(self, session_model):
        """toggle on-demand evaluation"""
        current = 'on' if self.kwargs['on_demand'] else 'off'
        if session_model.arg is None:
            print(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['on_demand'] = False
                if self.session.wfe:
                    self.session.wfe.nodes_torun = None
            else:
                self.kwargs['on_demand'] = True
                if self.session.wfe:
                    self.session.wfe.nodes_torun = []
            self.session.on_demand = self.kwargs['on_demand']

    def _handle_unique_launchdir(self, session_model):
        """toggle evaluation in unique launchdir"""
        current = 'on' if self.kwargs['unique_launchdir'] else 'off'
        if session_model.arg is None:
            print(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['unique_launchdir'] = False
            else:
                self.kwargs['unique_launchdir'] = True
            self.session.unique_launchdir = self.kwargs['unique_launchdir']
            if self.session.wfe:
                self.session.wfe.unique_launchdir = self.kwargs['unique_launchdir']

    def _handle_detect_duplicates(self, session_model):
        """toggle duplicates detection"""
        current = 'on' if self.kwargs['detect_duplicates'] else 'off'
        if session_model.arg is None:
            print(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['detect_duplicates'] = False
            else:
                self.kwargs['detect_duplicates'] = True
            self.session.detect_duplicates = self.kwargs['detect_duplicates']
