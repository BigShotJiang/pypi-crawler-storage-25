"""test the command-line interface (texts)"""
import os
import re
import sys
import uuid
import subprocess as sp
import pytest
from fireworks.fw_config import LAUNCHPAD_LOC
from fireworks.user_objects.queue_adapters.common_adapter import CommonAdapter
from prompt_toolkit.output import DummyOutput
from prompt_toolkit.shortcuts import PromptSession, CompleteStyle
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.input.defaults import create_pipe_input
from virtmat.language.cli import run_model, run_session
from virtmat.language.utilities import version
from virtmat.language.interpreter.session import Session
from virtmat.language.utilities.textx import GRAMMAR_LOC, GrammarString
from virtmat.language.cli.session_manager import make_key_bindings


@pytest.fixture(name='model_file')
def model_file_fixture(tmp_path):
    """prepare a model file as a fixture"""
    path = os.path.join(tmp_path, 'model.vm')
    model = "a = 1; print(a)"
    with open(path, 'w', encoding='utf-8') as ifile:
        ifile.write(model)
    return path


@pytest.fixture(name='lpad_file')
def lpad_file_fixture(tmp_path, lpad):
    """launchpad file as fixture"""
    path = os.path.join(tmp_path, 'launchpad.yaml')
    lpad.to_file(path)
    return path


def test_script_direct_call_parse_clargs(capsys):
    """directly call the parse_clargs() function otherwise not covered"""
    msg = 'the following arguments are required: -f/--model-file'
    with pytest.raises(SystemExit, match='2'):
        run_model.parse_clargs()
    assert msg in capsys.readouterr().err


def test_session_direct_call_parse_clargs():
    """directly call the parse_clargs() function otherwise not covered"""
    if len(sys.argv) > 1:
        with pytest.raises(SystemExit, match='2'):
            run_session.parse_clargs()
    else:
        run_session.parse_clargs()


def test_texts_version():
    """test texts version flag"""
    command = ['texts', '--version']
    with sp.Popen(command, stdout=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == version.VERSION + '\n'


def test_texts_script_instant(model_file):
    """test texts script cli tool in instant evaluation mode"""
    command = ['texts', 'script', '-f', model_file]
    with sp.Popen(command, stdout=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == "program output: >>>\n1\n<<<\n"


def test_texts_script_deferred(model_file):
    """test texts script cli tool in deferred evaluation mode"""
    command = ['texts', 'script', '-f', model_file, '-m', 'deferred']
    with sp.Popen(command, stdout=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == "program output: >>>\n1\n<<<\n"


def test_texts_script_workflow(model_file, lpad_file):
    """test texts script cli tool in workflow evaluation mode"""
    command = ['texts', 'script', '-f', model_file, '-m', 'workflow',
               '-l', lpad_file, '-r']
    with sp.Popen(command, stdout=sp.PIPE, shell=False) as proc:
        assert "program output: >>>\n1\n<<<\n" in proc.stdout.read().decode()


def test_texts_script_show_model(model_file):
    """test texts script cli tool with the --show-model option"""
    command = ['texts', 'script', '-f', model_file, '--show-model']
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == ''
        assert proc.stderr.read().decode() == ''


def test_texts_script_no_interpreter(model_file):
    """test texts script cli tool with the --no-interpreter option"""
    command = ['texts', 'script', '-f', model_file, '--no-interpreter']
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == ''
        assert proc.stderr.read().decode() == ''


def test_texts_session(lpad_file, _res_config_loc):
    """test texts session cli tool"""
    model = 'a = 1; print(a)\n%exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdout=sp.PIPE, stdin=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0]
        assert 'Output > 1' in stdout.decode()


def test_texts_session_expression(lpad_file, _res_config_loc):
    """test texts session cli tool with expression"""
    model = 'a = 1 \n a + 1 \n %exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdout=sp.PIPE, stdin=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0]
        assert 'Output > 2' in stdout.decode()


def test_texts_session_magics(lpad_file, _res_config_loc):
    """test texts session cli tool with magics"""
    model = ('%uuid \n %sleep \n %new \n %start \n %stop \n %hist \n %vary \n'
             '%tag \n %help \n %version \n %exit')
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        _, stderr = proc.communicate(input=model.encode())
    assert 'Welcome to textS/textM. Type %help for some help.' in stderr.decode()
    assert 'Started new session with uuids' in stderr.decode()


def test_texts_session_magics_in_async_evaluation(lpad_file, _res_config_loc):
    """test texts session cli tool with magics in async evaluation"""
    model = '%sleep 0 \n %new \n %hist \n %exit'
    command = ['texts', 'session', '-l', lpad_file, '-r', '-a']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        _, stderr = proc.communicate(input=model.encode())
    assert 'Welcome to textS/textM. Type %help for some help.' in stderr.decode()
    assert 'Started new session with uuids' in stderr.decode()


def test_texts_session_magics_session_with_no_model(lpad_file, _res_config_loc):
    """test texts session cli tool with magics in session with no model"""
    model = '%hist \n %cancel a \n %rerun b \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        _, stderr = proc.communicate(input=model.encode())
    assert 3*'No model is currently loaded.\n' in stderr.decode()


def test_texts_session_magics_new(lpad_file, _res_config_loc, model_file):
    """test texts session cli tool with new magics"""
    model = f'%new "{model_file}" \n %exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, stderr=sp.PIPE) as proc:
        stdout, stderr = proc.communicate(input=model.encode())
    assert '1\nInput >' in stdout.decode()
    assert 'Started new session with uuids' in stderr.decode()


def test_texts_session_magics_logging(lpad_file, _res_config_loc):
    """test texts session cli tool with logging magic"""
    model = ('%logging \n %logging on \n %logging \n %logging off'
             '\n %logging CRITICAL \n %exit')
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    print(stdout.decode())
    assert 'Logging not activated.\nInput > Input > Current level: CRITICAL' in stdout.decode()


def test_texts_session_magics_warnings(lpad_file, _res_config_loc):
    """test texts session cli tool with warnings magic"""
    model = '%warnings \n %warnings off \n %warnings \n %warnings on \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'on\nInput > Input > off' in stdout.decode()


def test_texts_session_magics_logfile(lpad_file, _res_config_loc, tmp_path):
    """test texts session cli tool with logfile magic"""
    logfile = os.path.join(tmp_path, 'logfile.log')
    model = f'%logfile \n %logfile "{logfile}" \n %logfile \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert f'No logfile.\nInput > Input > Current logfile: {logfile}' in stdout.decode()


def test_texts_session_magics_load(lpad_file, _res_config_loc, model_file):
    """test texts session cli tool with load magic"""
    model = f'%load "{model_file}" \n %exit'
    command = ['texts', 'session', '-r', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert '1\nInput >' in stdout.decode()


def test_texts_session_magics_launchpad(lpad_file, _res_config_loc, tmp_path, lpad):
    """test texts session cli tool with launchpad magic"""
    lp_path = os.path.join(tmp_path, 'launchpad1.yaml')
    lpad.to_file(lp_path)
    model = f'%launchpad \n %launchpad "{lp_path}" \n %launchpad \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, stderr=sp.PIPE) as proc:
        stdout, stderr = proc.communicate(input=model.encode())
    assert f"'{lpad_file}'\nInput > Input > '{lp_path}'" in stdout.decode()
    assert f'Switched to launchpad {lp_path}' in stderr.decode()


def test_texts_session_magics_qadapter(lpad_file, _res_config_loc, tmp_path):
    """test texts session cli tool with qadapter magic"""
    qpath = os.path.join(tmp_path, 'qadapter.yaml')
    CommonAdapter('PBS').to_file(qpath)
    model = f'%qadapter \n %qadapter "{qpath}" \n %qadapter \n %exit'
    command = ['texts', 'session', '-a', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert f"No qadapter file.\nInput > Input > '{qpath}'" in stdout.decode()


def test_texts_session_magics_async(lpad_file, _res_config_loc):
    """test texts session cli tool with async magic"""
    model = '%async \n %async on \n %async \n %async off \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'off\nInput > Input > on' in stdout.decode()


def test_texts_session_magics_on_demand(lpad_file, _res_config_loc):
    """test texts session cli tool with on_demand magic"""
    model = '%on_demand \n %on_demand on \n %on_demand \n %on_demand off \n %exit'
    command = ['texts', 'session', '-a', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'off\nInput > Input > on' in stdout.decode()


def test_texts_session_magics_unique_launchdir(lpad_file, _res_config_loc):
    """test texts session cli tool with unique_launchdir magic"""
    model = ('%unique_launchdir \n %unique_launchdir off \n'
             '%unique_launchdir \n %unique_launchdir on \n %exit')
    command = ['texts', 'session', '-a', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'on\nInput > Input > off' in stdout.decode()


def test_texts_session_magics_detect_duplicates(lpad_file, _res_config_loc):
    """test texts session cli tool with detect_duplicates magic"""
    model = ('%detect_duplicates \n %detect_duplicates off \n'
             '%detect_duplicates \n %detect_duplicates on \n %exit')
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'on\nInput > Input > off' in stdout.decode()


def test_texts_session_magics_version(lpad_file, _res_config_loc):
    """test texts session cli tool with version magic"""
    model = '%version \n %exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    output = stdout.decode()
    assert 'vre-language:' in output
    assert 'grammar version:' in output
    assert 'python version:' in output


def test_texts_session_magics_rerun(lpad_file, _res_config_loc):
    """test texts session rerun magic"""
    model = 'a = 1; print(a)\n%rerun a\n%rerun b\n%exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'Variable update error: Variable "b" not found in the model.' in stderr


def test_texts_session_magics_rerun_invalid_state(lpad_file, _res_config_loc):
    """test texts session invalid rerun magic for waiting node"""
    model = 'a = 1\n%rerun a\n%exit'
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'State of variable "a" not allowed: WAITING' in stderr


def test_rerun_completed_detouring_node(lpad_file, _res_config_loc):
    """test rerun completed detouring node"""
    model = 'a = 1; b = 2; c = true; d = if(c, a, b)?\nprint(d)\n%rerun d\n%exit'
    command = ['texts', 'session', '-r', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'Variable update error: State of variable "d" cannot be changed' in stderr


def test_rerun_ancestor_of_completed_detouring_node(lpad_file, _res_config_loc):
    """test rerun ancestor of a completed detouring node"""
    model = 'a = 1; b = 2; c = true; d = if(c, a, b)?\nprint(d)\n%rerun c\n%exit'
    command = ['texts', 'session', '-r', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    msg = ('Variable update error: Variable "c" cannot be changed because of 1 '
           'completed detouring descendants')
    assert msg in stderr


def test_texts_session_magics_cancel(lpad_file, _res_config_loc):
    """test texts session cancel magic"""
    model = 'a = 1; print(a)\n%cancel a\n%cancel b\n%exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'Variable update error: Variable "b" not found in the model.' in stderr


def test_texts_session_magics_recover(lpad_file, _res_config_loc):
    """test texts session recover magic"""
    model = 'a = 1 / 0\nprint(a)\n%recover a\n%recover b, a\nprint(a)\n%recover a\nprint(a)\n%exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert ('Variable update error: Variable "b" not found in the model.\n'
            'Arithmetic error: None:1:1 --> a = 1 / 0 <--\nfloat division by zero\n'
            'Arithmetic error: None:1:1 --> a = 1 / 0 <--\nfloat division by zero\n') in stderr


def test_texts_session_magics_uuid(lpad, lpad_file, _res_config_loc):
    """test texts session switch model uuid"""
    model_uuid = Session(lpad, grammar_path=GRAMMAR_LOC, create_new=True).uuids[0]
    flag = ['-r']
    command = ['texts', 'session', '-l', lpad_file] + flag
    model = f'%uuid {model_uuid}\n%uuid\n%uuid {model_uuid}\n%exit'
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0].decode()
    assert model_uuid in stdout
    fake_uuid = '45f5f9a390b94359974661b55f5585af'
    model = f'%uuid {fake_uuid}\n%exit'
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert f'Model not found: uuid {fake_uuid}' in stderr


def test_texts_session_magics_tag_find(lpad_file, _res_config_loc):
    """test model tagging and searching in tags section"""
    model = "tag ((doping: 'Fe'), ('active site': 'M5'), (n: (5, 7)))\n%tag"
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0].decode()
    assert "((doping: 'Fe'), ('active site': 'M5'), (n: (5, 7)))" in stdout
    model = "%find ((tags: (('~doping': (('$in': ('Fe', 'Co'))) )) ))"
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'Model UUID' in stdout.decode()
    model = "%find {tags: {'~active site': {'$in': ('M1', 'M5')}}}"
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'Model UUID' in stdout.decode()


def test_texts_session_magics_tag_find_errors(lpad_file, _res_config_loc):
    """test model tagging and searching with errors"""
    model = "tag ((doping: 'Fe', 'Co'), ('active site': 'M5', 'M2'))"
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'Tag err' in stderr
    assert 'tag table must have only one row' in stderr
    model = "%find (('~doping': (('$in': ('Fe', 'Co'))) ))"
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'Query error: query must include tags, meta or data keys' in stderr


def test_texts_session_magics_find_model_data(lpad_file, _res_config_loc):
    """test searching models in data section"""
    var_a = 'a_' + uuid.uuid4().hex
    model = f"{var_a} = '{var_a}'; b = {var_a}; print(b)\n"
    model += "%find {data: {'~"
    model += var_a
    model += "': {'$exists': true}}}\n%exit"
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0].decode()
    assert var_a in stdout
    assert 'COM' in stdout


def test_texts_session_magics_find_tags_load_one(lpad_file, _res_config_loc):
    """test searching models in tags section and load one"""
    model = "tag ((doping: 'Fe'), ('active site': 'M5'))"
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, shell=False) as proc:
        proc.communicate(input=model.encode())
    model = "%find {tags: {'~doping': {'$in': ('Fe', 'Co')}}} load one"
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0].decode()
    assert "uuids: '" in stdout


def test_texts_session_magics_find_meta(lpad, lpad_file, _res_config_loc):
    """test searching models in metadata section"""
    session = Session(lpad, grammar_path=GRAMMAR_LOC, create_new=True,
                      autorun=True)
    session.get_model("tag ((doping: 'Fe'), ('active site': 'M5'))")
    command = ['texts', 'session',  '-r', '-l', lpad_file]
    model = "%find {meta: {'state': 'COMPLETED'}}"
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0].decode()
    assert session.uuids[0] in stdout


def test_texts_session_magics_find_tags_mongodb_error(lpad_file, _res_config_loc):
    """test searching models in tags section with invalid query"""
    command = ['texts', 'session', '-l', lpad_file]
    model = "%find {'tags': {'~doping': {'$in': ('Fe', 'Co'), 'blah': 1}}}"
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    assert 'pymongo.errors.OperationFailure: unknown operator: blah' in stderr


def test_texts_session_magics_find_containing_series(lpad_file, _res_config_loc):
    """test searching models with query containing series"""
    command = ['texts', 'session', '-l', lpad_file]
    model = "%find ((meta: (state: 'FIZZLED')))"
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode()
    msg = "Query error: unsupported type for query/tag: <class 'pandas.core.series.Series'>"
    assert msg in stderr


def test_texts_session_with_resources(lpad_file, _res_config_loc):
    """test texts session with resource specifications"""
    command = ['texts', 'session', '-l', lpad_file]
    model = 'a = 1 on 2 cores for 1.0 [hours]'
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input=model.encode())[1].decode().strip()
    msg = ('Warning: Session running in a shell not connected to a terminal\n'
           'Welcome to textS/textM. Type %help for some help.')
    assert stderr == msg


def test_texts_session_logfile(lpad_file, _res_config_loc, tmp_path):
    """test texts session with logging redirected to a file"""
    filename = os.path.join(tmp_path, 'texts.log')
    command = ['texts', 'session', '-l', lpad_file, '--enable-logging', '--logfile',
               filename]
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input='%exit'.encode())[1].decode()
    msg = 'Warning: Session running in a shell not connected to a terminal'
    assert msg in stderr


def test_texts_session_magics_help(lpad_file, _res_config_loc):
    """test texts session with the %help magic"""
    command = ['texts', 'session', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input='%help'.encode())[0].decode()
    assert '%exit, %bye, %close, %quit' in stdout


def test_texts_script_no_warnings(model_file):
    """test texts script cli tool with no warnings"""
    command = ['texts', 'script', '-f', model_file, '-r', '-m', 'deferred', '-w']
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode().strip() == 'program output: >>>\n1\n<<<'
        assert proc.stderr.read().decode() == ''


def test_texts_script_logfile(model_file, tmp_path):
    """test texts script with logging redirected to a file"""
    filename = os.path.join(tmp_path, 'texts.log')
    command = ['texts', 'script', '-f', model_file, '--enable-logging', '--logfile',
               filename]
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stdout = proc.stdout.read().decode()
    assert stdout.strip() == 'program output: >>>\n1\n<<<'
    assert os.path.exists(filename)


def test_texts_script_show_model_deferred_mode(model_file):
    """test texts script cli tool with the --show-model option in deferred mode"""
    command = ['texts', 'script', '-f', model_file, '--show-model', '-m', 'deferred']
    msg = 'Warning: switching to instant mode due to argument show-model'
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == ''
        assert msg in proc.stderr.read().decode()


def test_texts_script_no_interpreter_deferred_mode(model_file):
    """test texts script cli tool with the --no-interpreter option in deferred mode"""
    command = ['texts', 'script', '-f', model_file, '--no-interpreter', '-m', 'deferred']
    msg = 'Warning: switching to instant mode due to argument no-interpreter'
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == ''
        assert msg in proc.stderr.read().decode()


def test_texts_script_incompatible_grammar_instant_mode(model_file, tmp_path):
    """tests texts with incompatible grammar"""
    g_str = GrammarString(GRAMMAR_LOC).string
    regex = re.compile(r'\/\*\s*grammar version\s+(\d+)\s*\*\/', re.MULTILINE)
    g_str_ = re.sub(regex, lambda x: x.group(0).replace(x.group(1), '0'), g_str)
    g_path = os.path.join(tmp_path, 'wrong_grammar.tx')
    with open(g_path, 'w', encoding='utf-8') as ofile:
        ofile.write(g_str_)
    command = ['texts', 'script', '-f', model_file, '-g', g_path, '-m', 'instant']
    msg = 'Compatibility error: Provided grammar has version 0 but the supported'
    with sp.Popen(command, stdout=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        assert proc.stdout.read().decode() == ''
        assert msg in proc.stderr.read().decode()


def test_texts_session_traceback_logging_level_debug(lpad_file, _res_config_loc):
    """test texts session with error traceback at debug logging level"""
    command = ['texts', 'session', '-l', lpad_file, '--enable-logging',
               '--logging-level', 'DEBUG']
    with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
        stderr = proc.communicate(input='print(a)'.encode())[1].decode()
    assert 'Traceback (most recent call last)' in stderr
    assert 'textx.exceptions.TextXSemanticError:' in stderr


@pytest.mark.skipif(LAUNCHPAD_LOC is not None,
                    reason='launchpad exists outside of test environment')
def test_texts_missing_launchpad(_res_config_loc, model_file):
    """test texts with missing launchpad file"""
    commands = (['texts', 'script', '-m', 'workflow', '-f', model_file],
                ['texts', 'session'])
    for command in commands:
        with sp.Popen(command, stdin=sp.PIPE, stderr=sp.PIPE, shell=False) as proc:
            stderr = proc.communicate(input=''.encode())[1].decode()
        msg = ('Configuration error: Neither default Launchpad file configured nor '
               'custom Launchpad file is specified.')
        assert msg in stderr


def test_empty_input_in_texts_session(lpad_file, _res_config_loc):
    """test empty input line in texts session"""
    model = '\n %exit'
    command = ['texts', 'session', '-r', '-l', lpad_file]
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE) as proc:
        stdout, _ = proc.communicate(input=model.encode())
    assert 'Input >' in stdout.decode()


def test_multiline_input_indentation_in_session(lpad_file, _res_config_loc):
    """test indentation of two-line input in session cli tool"""
    model = 'a = (\n 1) \n print(a) \n %exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0]
        print(stdout.decode())
        assert 'Output > 1' in stdout.decode()


def test_multiline_input_indent_with_non_empty_buffer(lpad_file, _res_config_loc):
    """test indent of multiline input in cli tool"""
    model = 'a = (\n 1, \n 2, \n 3) \n print(a) \n %exit'
    command = ['texts', 'session', '-l', lpad_file, '-r']
    with sp.Popen(command, stdin=sp.PIPE, stdout=sp.PIPE, shell=False) as proc:
        stdout = proc.communicate(input=model.encode())[0]
        print(stdout.decode())
        assert 'Output > (1, 2, 3)' in stdout.decode()


def test_enter_submits_text_when_no_completion_selected():
    """test pressing enter to submit text when no completion selected"""
    kb = make_key_bindings()
    with create_pipe_input() as inp:
        inp.send_text('alp\r')
        session = PromptSession(
            input=inp,
            output=DummyOutput(),
            completer=WordCompleter(['dummy']),
            complete_while_typing=False,
            complete_style=CompleteStyle.COLUMN,
            key_bindings=kb,
        )
        result = session.prompt()
    assert result == 'alp'
