"""unittests for code that is called only interactively or hard to reach"""
import os
import sys
import uuid
import pytest
import numpy
import pandas
import pint
from unittest.mock import MagicMock
from prompt_toolkit.document import Document
from prompt_toolkit.completion import CompleteEvent
from ruamel.yaml.scanner import ScannerError
from fireworks import LaunchPad
from textx.exceptions import TextXSemanticError
from jsonschema.exceptions import ValidationError
from virtmat.middleware.exceptions import LmodError
from virtmat.language.interpreter.session import Session
from virtmat.language.interpreter.deferred_executor import cache_eval
from virtmat.language.utilities.context import setup_environ
from pygments.token import Keyword, Name, Operator, Token
from texts_lexer import VMLexer
from texts_style import VMLangStyle
from virtmat.language.utilities.textx import GrammarString, TextXCompleter, get_expected
from virtmat.language.utilities.textx import display_exception
from virtmat.language.utilities.ase_handlers import get_ase_property
from virtmat.language.utilities.firetasks import FunctionTask
from virtmat.language.utilities.fireworks import get_nodes_providing, get_var_names
from virtmat.language.utilities.fireworks import object_from_file
from virtmat.language.utilities.errors import PropertyError, ObjectFromFileError
from virtmat.language.utilities.errors import CompatibilityError, error_handler
from virtmat.language.utilities.errors import FilenameError, FileContentError
from virtmat.language.utilities.errors import RuntimeValueError
from virtmat.language.utilities.errors import ERROR_HANDLER_OPTIONS, get_err_type, check_raise
from virtmat.language.utilities.indentation import compute_indent
from virtmat.language.utilities.ioops import DATASTORE_CONFIG, get_uuid_filename
from virtmat.language.utilities.random import RandomGenerator
from virtmat.language.utilities.serializable import FWDataObject, FWDataFrame, get_serializable
from virtmat.language.utilities.viewers import VIEWER_IMAGES
from virtmat.language.utilities.warnings import TextSUserWarning
from tests.imports import is_negative_int, is_positive_q, func_ext, do_nothing
from tests.imports import do_something, get_bare_number, get_numpy_array
from virtmat.language.cli.session_manager import tab_handler, enter_handler


@pytest.fixture(name='tab_completer')
def completer_func(raw_meta_model):
    """factory for completer objects"""
    _, _, keywords = get_expected(raw_meta_model, '%')
    options = ['%exit', '%bye'] + keywords
    completer = TextXCompleter(GrammarString().string, options)
    completer.model = raw_meta_model.model_from_str('bar = 1; foo = true')
    return completer


def mock_event(buff):
    event = MagicMock()
    event.app.current_buffer = buff
    return event


def test_tab_open_completion():
    buff = MagicMock()
    buff.complete_state = None
    tab_handler(mock_event(buff))
    buff.start_completion.assert_called_once_with(select_first=False)
    buff.complete_next.assert_not_called()


def test_tab_cycle_completions():
    buff = MagicMock()
    buff.complete_state = MagicMock()
    tab_handler(mock_event(buff))
    buff.complete_next.assert_called_once()
    buff.start_completion.assert_not_called()


def test_enter_with_completion_selected():
    completion = MagicMock()
    buff = MagicMock()
    buff.complete_state = MagicMock()
    buff.complete_state.current_completion = completion
    enter_handler(mock_event(buff))
    buff.apply_completion.assert_called_once_with(completion)
    buff.validate_and_handle.assert_not_called()


def test_enter_with_no_completion_selected():
    buff = MagicMock()
    buff.complete_state = MagicMock()
    buff.complete_state.current_completion = None
    enter_handler(mock_event(buff))
    buff.validate_and_handle.assert_called_once()
    buff.apply_completion.assert_not_called()


def test_enter_no_complete_state():
    buff = MagicMock()
    buff.complete_state = None
    enter_handler(mock_event(buff))
    buff.validate_and_handle.assert_called_once()
    buff.apply_completion.assert_not_called()


@pytest.fixture(name='_error_handler_options')
def error_handler_options_fixture():
    """toggle the error_handler_options"""
    assert ERROR_HANDLER_OPTIONS.raise_err is False
    ERROR_HANDLER_OPTIONS.raise_err = True
    yield
    ERROR_HANDLER_OPTIONS.raise_err = False


def spaces(n: int) -> str:
    """helper function for indentation tests"""
    return ' ' * n


def test_completer(tab_completer):
    """test tab-completion"""
    tc = tab_completer

    def comps(text):
        doc = Document(text, cursor_position=len(text))
        return list(tc.get_completions(doc, None))

    def comps_tab(text):
        """simulate an explicit Tab press (completion_requested=True)"""
        doc = Document(text, cursor_position=len(text))
        return list(tc.get_completions(doc, CompleteEvent(completion_requested=True)))

    # empty prompt with Tab
    assert any(c.text == '%exit' for c in comps_tab(''))
    assert any(c.text == 'print' for c in comps_tab(''))
    # empty prompt without Tab: no completions
    assert comps('') == []
    # fallback to options list on prefix match
    assert any(c.text == '%exit' for c in comps('%'))
    # grammar-driven: 'print' leads to '(' completion (suffix appended after cursor)
    assert any('(' in c.text for c in comps('print'))
    # grammar-driven: 'print(' leads to identifier completion containing 'bar'
    assert any('bar' in c.text for c in comps('print('))
    # grammar-driven: 'print(not ' leads to 'true' or similar boolean
    assert any('true' in c.text for c in comps('print(not '))
    # grammar-driven: 'a = ' leads to identifier 'foo'
    assert any('foo' in c.text for c in comps('a = '))
    # smoke tests — must not raise
    comps('x %%')
    comps('%blah ')
    # fully-matched text yields no completions (suffix is empty)
    assert comps('print(1)') == []
    assert comps('print(a)') == []


def test_vmlexer():
    """test that VMLexer assigns the correct Pygments token type to each word class"""
    def tokens(text):
        return [(t, v) for _, t, v in VMLexer().get_tokens_unprocessed(text)
                if v.strip()]

    # keywords (TextSLexer)
    assert any(t is Keyword and v == 'from' for t, v in tokens('from'))
    assert any(t is Keyword and v == 'use' for t, v in tokens('use'))
    # type names → Keyword.Type (TextSLexer + TextMLexer for AMML types)
    assert any(t is Keyword.Type and v == 'Quantity' for t, v in tokens('Quantity'))
    assert any(t is Keyword.Type and v == 'Structure' for t, v in tokens('Structure'))
    # constants → Keyword.Constant
    assert any(t is Keyword.Constant and v == 'true' for t, v in tokens('true'))
    assert any(t is Keyword.Constant and v == 'false' for t, v in tokens('false'))
    # builtins → Name.Builtin
    assert any(t is Name.Builtin and v == 'print' for t, v in tokens('print'))
    assert any(t is Name.Builtin and v == 'vary' for t, v in tokens('vary'))
    # word operators → Operator.Word
    assert any(t is Operator.Word and v == 'and' for t, v in tokens('and'))
    assert any(t is Operator.Word and v == 'not' for t, v in tokens('not'))
    # magic commands → Keyword.Pseudo (VMLexer)
    assert any(t is Keyword.Pseudo for t, v in tokens('%exit'))
    assert any(t is Keyword.Pseudo for t, v in tokens('%help'))
    # plain identifier must NOT become a keyword token
    assert not any(t in (Keyword, Keyword.Type, Keyword.Constant) for t, v in tokens('myvar'))


def test_vmlexer_colors():
    """test that VMLangStyle assigns correct, distinct colors to all VMLexer token types"""
    def color(tok):
        return VMLangStyle.style_for_token(tok)['color']

    def bold(tok):
        return VMLangStyle.style_for_token(tok)['bold']

    # every VMLexer-produced token type must have a color (not invisible)
    for tok in (Keyword, Keyword.Type, Keyword.Constant, Keyword.Pseudo,
                Name.Builtin, Operator.Word):
        assert color(tok) is not None, f'{tok} has no color'

    # visually distinct token classes must have different colors
    assert color(Keyword.Type) != color(Keyword)        # type names ≠ keywords
    assert color(Operator.Word) != color(Keyword)       # operators ≠ keywords
    assert color(Operator.Word) != color(Name.Builtin)  # operators ≠ builtins

    # CLI-specific overrides
    assert color(Token.Number) == '007700'          # green
    assert color(Token.String) == 'BB6622'          # orange-brown
    assert color(Token.Name.Function) == '2080D0'   # blue
    assert color(Token.Name.Class) == '2080D0'      # blue (bold)
    assert bold(Token.Name.Class) is True
    assert color(Token.Name.Namespace) == '2080D0'  # blue (bold)
    assert bold(Token.Name.Namespace) is True
    # Token.Operator is noinherit → no color
    assert color(Token.Operator) is None


def test_error_handler_options(_error_handler_options):
    """test the error handler options (global settings)"""
    assert ERROR_HANDLER_OPTIONS.raise_err is True
    with pytest.raises(TextXSemanticError, match='testing') as err:
        exception = TextXSemanticError('testing')
        check_raise(exception, get_err_type(exception))
    assert err.value.err_type == 'Semantic error'


def test_display_exception(capsys):
    """test the display_exception() decorator function"""
    @display_exception
    def func_with_exception():
        raise RuntimeError()
    with pytest.raises(RuntimeError):
        func_with_exception()
    assert 'RuntimeError' in capsys.readouterr().err


def test_is_complete(tab_completer):
    """test is_complete() function"""
    assert tab_completer.is_complete('a = 3 +') is False
    assert tab_completer.is_complete('a = b +\n    4') is True
    assert tab_completer.is_complete('a = 3 +\n    4 +') is False
    assert tab_completer.is_complete('foo bar') is True
    assert tab_completer.is_complete('foo = bar') is True


def test_get_ase_property():
    """test get_ase_property function with exception"""
    msg = 'no property "magmoms" found for method "emt"'
    with pytest.raises(PropertyError, match=msg):
        get_ase_property('emt', 'magmoms', [])


@pytest.mark.skipif(sys.version_info[:2] == (3, 11), reason="segmentation fault w/python3.11")
def test_function_task_with_compatibility_exception():
    """test the FunctionTask class with a python version compatibility exception"""
    if (sys.version_info.major, sys.version_info.minor) == (3, 12):
        pytest.skip('test is written for python versions different from 3.12')
    func_str = ('gASVywAAAAAAAACMCmRpbGwuX2RpbGyUjBBfY3JlYXRlX2Z1bmN0aW9ulJOU'
                'KGgAjAxfY3JlYXRlX2NvZGWUk5QoQwCUSwBLAEsASwBLAEsDQwSXAHkAlE6F'
                'lCkpjB88aXB5dGhvbi1pbnB1dC0xMC1lNjY4NTUwMTEwZDM+lIwIPGxhbWJk'
                'YT6UaAlLAUMCgQCUaAUpKXSUUpRjX19idWlsdGluX18KX19tYWluX18KaAlO'
                'TnSUUpR9lH2UjA9fX2Fubm90YXRpb25zX1+UfZRzhpRiLg==')
    task = FunctionTask(func=func_str, inputs=[], outputs=[])
    vers = '3.12.3 (main, May 29 2024, 16:57:49) [GCC 13.3.0]'
    msg = 'This statement has been compiled with incompatible python version'
    with pytest.raises(CompatibilityError, match=msg) as err:
        task.run_task(fw_spec={'_python_version': vers})
    cause = err.value.__cause__
    assert isinstance(cause, SystemError) and 'unknown opcode' in str(cause)


def test_get_var_names(lpad):
    """test get_var_names utility function"""
    session = Session(lpad, grammar_str=GrammarString().string, model_str='a = 1')
    fw_ids = get_nodes_providing(lpad, session.uuids[0], 'a')
    var_names = get_var_names(lpad, fw_ids)
    assert len(var_names) == 1
    assert var_names[0] == 'a'


def test_read_from_empty_file_exception(capsys, tmp_path):
    """test object_from_file() with an exception with and without handler"""
    filename = os.path.join(tmp_path, uuid.uuid4().hex)
    with open(filename, 'x', encoding='utf-8'):
        pass
    error_handler(object_from_file)(LaunchPad, filename)
    out = (f'Data input error: virtmat.language.utilities.errors.FileContentError:'
           f' {filename}\nCannot load object from empty file.')
    assert out in capsys.readouterr().err
    with pytest.raises(ObjectFromFileError, match=filename) as err:
        object_from_file(LaunchPad, filename)
    assert isinstance(err.value.__cause__, FileContentError)


def test_read_from_invalid_file_extension_exception(capsys, tmp_path):
    """test object_from_file() with an exception with and without handler"""
    filename = os.path.join(tmp_path, uuid.uuid4().hex)
    with open(filename, 'w', encoding='utf-8') as fh:
        fh.write('%  %')
    error_handler(object_from_file)(LaunchPad, filename)
    out = (f'Data input error: virtmat.language.utilities.errors.FilenameError:'
           f' {filename}\nUnsupported format')
    assert out in capsys.readouterr().err
    with pytest.raises(ObjectFromFileError, match=filename) as err:
        object_from_file(LaunchPad, filename)
    assert isinstance(err.value.__cause__, FilenameError)


def test_read_from_invalid_file_exception(capsys, tmp_path):
    """test object_from_file() with an exception with and without handler"""
    filename = os.path.join(tmp_path, uuid.uuid4().hex+'.yaml')
    with open(filename, 'w', encoding='utf-8') as fh:
        fh.write('%  %')
    error_handler(object_from_file)(LaunchPad, filename)
    out1 = (f'Data input error: ruamel.yaml.scanner.ScannerError: {filename}\n'
            f'while scanning a directive\n  in "<unicode string>", line 1, column 1:\n')
    out2 = 'expected alphabetic or numeric character, but found'
    stderr = capsys.readouterr().err
    assert out1 in stderr
    assert out2 in stderr
    with pytest.raises(ObjectFromFileError, match=filename) as err:
        object_from_file(LaunchPad, filename)
    assert isinstance(err.value.__cause__, ScannerError)


def test_get_uuid_filename(monkeypatch):
    """test get_uuid_filename with non-supported datastore type"""
    monkeypatch.setenv('WORKFLOW_EVALUATION_MODE', 'yes')
    DATASTORE_CONFIG['type'] = 'file'
    assert DATASTORE_CONFIG['path'] in get_uuid_filename('json')
    DATASTORE_CONFIG['type'] = None
    assert os.environ['WORKFLOW_EVALUATION_MODE'] == 'yes'
    with pytest.warns(UserWarning, match='Falling back to current working directory'):
        get_uuid_filename('json')


def test_schema_validate_active(_schema_validate):
    """test that the validation is activated by validating an invalid instance"""
    dobj = FWDataObject(0, datastore={'type': None})
    msg = '0 is not valid under any of the given schemas'
    with pytest.raises(ValidationError, match=msg):
        dobj.to_dict()


def test_schema_validate_dict(_schema_validate):
    """test that validation is activated by a non-validating FWDict"""
    obj = FWDataObject.from_obj({'key': 'val'})
    dobj = obj.to_dict()
    del dobj['value']['_fw_name']
    msg = "{'key': 'val', '_version': \\d+} is not valid under any of the given schemas"
    with pytest.raises(ValidationError, match=msg):
        FWDataObject.from_dict(dobj)


def test_get_serializable_type_error():
    """test get_serializable with an unsupported type"""
    with pytest.raises(TypeError, match=r"cannot serialize \{1\} of type <class 'set'>"):
        get_serializable({1})


def test_imports_functions():
    """call the imports test functions"""
    assert is_negative_int(1) is False
    assert is_positive_q(pint.Quantity(1)) is True
    assert isinstance(func_ext(True, 'abc', pint.Quantity(0), numpy.array([1.]),
                      (1, 'a'), {'k': 1}, pandas.Series([1])), object)
    with pytest.raises(NotImplementedError):
        do_nothing(pint.Quantity(0))
    assert do_something(pint.Quantity(0)) is None
    assert get_bare_number(pint.Quantity(0)) == 0
    assert get_numpy_array().tolist() == [False, True]


def test_viewer_images():
    """test ViewerImages class"""
    assert VIEWER_IMAGES.return_png is False
    assert VIEWER_IMAGES.cli is True
    VIEWER_IMAGES.return_png = True
    VIEWER_IMAGES.cli = False
    assert VIEWER_IMAGES.return_png is True
    VIEWER_IMAGES.process_pyplot(show=True)
    assert len(VIEWER_IMAGES) == 1


def test_setup_environ(_res_config_loc, monkeypatch):
    """test the setup_environ() utility function"""
    setup_environ(lambda: None, {'modules': {}, 'envs': {}})()

    with pytest.warns(TextSUserWarning, match='no matching module vasp<1.2.0'):
        setup_environ(lambda: None, {'modules': {'vasp': '<1.2.0'}})()

    res = {'modules': {'vasp': '>=6.2.0'}, 'envs': {'TEST_ENVVAR_1': 'test'}}
    with pytest.raises(LmodError, match='Lmod is not available'):
        setup_environ(lambda: None, res)()

    res = {'envs': {'TEST_ENVVAR_1': 'test'}, 'modules': {}}
    assert setup_environ(lambda: os.environ['TEST_ENVVAR_1'], res)() == 'TEST'

    with pytest.raises(LmodError, match='Lmod is not available'):
        setup_environ(lambda: None, {'modules': {'elk': '>6.2.0'}, 'envs': {}})()

    monkeypatch.setenv('TEST_ENVVAR_2', 'TEST')
    res = {'envs': {'TEST_ENVVAR_2': None}, 'modules': {}}
    assert setup_environ(lambda: 'TEST_ENVVAR_2' not in os.environ, res)()


def test_random_number_generator():
    """test the random number generator"""
    g1 = RandomGenerator('MT19937', seed='90a428f341af48ba93ff03100eba68c3')
    assert g1.uniform() == pytest.approx(0.15550312209288797)
    g2 = RandomGenerator('MT19937', seed='90a428f341af48ba93ff03100eba68c3')
    assert g1 is g2
    assert g2.uniform() == pytest.approx(0.38098330526660773)
    g3 = RandomGenerator()
    g4 = RandomGenerator()
    assert g3 is not g4
    with pytest.raises(RuntimeValueError, match='invalid literal'):
        RandomGenerator(seed='red8c93f1db74abebc32d228a25f7628')
    with pytest.raises(RuntimeValueError, match='unknown bit generator'):
        RandomGenerator(rng='red8c93f1db74abebc32d228a25f7628')
    g5 = RandomGenerator('MT19937', seed='90a428f341af48ba93ff03100eba68c3', spawn_key=(0,))
    assert g5.random() == 0.1432354664717238


def test_compute_indent_different_alignment_anchors():
    """test alignment anchors of compute_indent function for multiline input"""
    b1 = ''
    assert compute_indent(b1) == ''
    b2 = 'h2o = Structure H2O (\n'
    assert compute_indent(b2) == spaces(21)
    b3 = 'tupl = (\n   1.234 [\n'
    assert compute_indent(b3) == spaces(10)
    b4 = 'Structure H2 (\n     atoms: ((symbols:'
    assert compute_indent(b4) == spaces(14)
    b5 = 'line0 (\n  obj[call(\n'
    assert compute_indent(b5) == spaces(11)
    b6 = 'print(\n      reduce(a, b)\n'
    assert compute_indent(b6) == spaces(6)
    b7 = 'a(\n ]\n'
    assert compute_indent(b7) == spaces(2)
    b8 = 'b1 = range from 1\n'
    assert compute_indent(b8) == spaces(5)
    assert compute_indent('a == 3') == ''
    assert compute_indent('a != 3') == ''
    assert compute_indent('a <= 3') == ''
    assert compute_indent('a >= 3') == ''


def test_cache_eval_argument_cached_fwdataframe_hashable():
    """test cache_eval caches calls with hashable FWDataFrame argument"""
    calls = {'n': 0}

    @cache_eval
    def make_callable(_obj):
        def ret_func(arg):
            calls['n'] += 1
            return len(arg.columns)
        return ret_func, ()

    cached_func, _ = make_callable(object())

    df = FWDataFrame(pandas.DataFrame({'x': [1, 2]}))
    assert isinstance(hash(df), int)
    assert cached_func(df) == 1
    assert cached_func(df) == 1
    assert calls['n'] == 1


def test_cache_eval_argument_not_cached_for_builtin_dict():
    """test cache_eval bypasses caching for builtin dict argument"""
    calls = {'n': 0}

    @cache_eval
    def make_callable(_obj):
        def ret_func(arg):
            calls['n'] += 1
            return arg['x']
        return ret_func, ()

    cached_func, _ = make_callable(object())

    dct = {'x': 1}
    assert cached_func(dct) == 1
    assert cached_func(dct) == 1
    assert calls['n'] == 2


def test_hdf5_datastore_roundtrip(tmp_path):
    """test HDF5 offload/load for FWDataObject"""
    value = {'array': [1, 2, 3], 'metadata': {'unit': 'eV'}}
    datastore = {'type': 'file', 'format': 'hdf5', 'path': str(tmp_path), 'compress': True}

    obj = FWDataObject.from_obj(value)
    datastore, filename = obj.offload_data(datastore=datastore)

    assert filename.endswith('.h5')
    assert os.path.exists(os.path.join(tmp_path, filename))

    loaded = FWDataObject(datastore=datastore, filename=filename, serialized=True).value
    assert loaded == value
