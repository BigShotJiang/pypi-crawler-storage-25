"""
tests for the typechecker
"""
import pytest
from textx import get_children_of_type
from textx.exceptions import TextXError, TextXSyntaxError
from virtmat.language.utilities.typemap import typemap
from virtmat.language.utilities.typemap import FloatArray, IntArray, BoolArray, IntQuantity
from virtmat.language.utilities.types import NA
from virtmat.language.utilities.errors import StaticTypeError, StaticValueError, PropertyError
from virtmat.language.utilities.errors import ExpressionTypeError, TypeMismatchError
from virtmat.language.utilities.errors import SubscriptingError, IterablePropertyError
from virtmat.language.utilities.textx import isinstance_m, isinstance_r

INT = typemap['Integer']
FLOAT = typemap['Float']
COMPLEX = typemap['Complex']
BOOL = typemap['Boolean']
STR = typemap['String']


def test_type_int_expression(meta_model_static):
    """test int type checker for arithmetic expressions and variables"""
    prog_str = "a = 10; b = -1 - a*3 + 15*(a-7)*(3+a) + 4*a*a"
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    exp_objs = get_children_of_type('Expression', prog)
    assert len(var_objs) == 2
    assert len(exp_objs) == 3
    assert len(get_children_of_type('Quantity', prog)) == 7
    assert all(issubclass(obj.type_, typemap['Quantity']) for obj in var_objs)
    assert all(issubclass(obj.type_.datatype, INT) for obj in var_objs)
    assert all(issubclass(obj.type_.datatype, INT) for obj in exp_objs)


def test_type_float_expression(meta_model_static):
    """test float type checker for arithmetic expressions and variables"""
    prog_str = "a = 10/c; b = 5*(8*a-3)/(15*(a-7.5)*(3+a)+4.1*a*a-a+6); c = 2"
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    exp_objs = get_children_of_type('Expression', prog)
    assert len(get_children_of_type('Quantity', prog)) == 10
    assert len(var_objs) == 3
    assert len(exp_objs) == 6
    assert next(issubclass(v.type_, typemap['Quantity']) for v in var_objs)
    assert next(issubclass(v.type_.datatype, FLOAT) for v in var_objs if v.name == 'a')
    assert next(issubclass(v.type_.datatype, FLOAT) for v in var_objs if v.name == 'b')
    assert next(issubclass(v.type_.datatype, INT) for v in var_objs if v.name == 'c')
    assert all(issubclass(obj.type_.datatype, FLOAT) for obj in exp_objs[:-1])


def test_type_complex_expression(meta_model_static):
    """test complex type checker for arithmetic expressions and variables"""
    prog_str = ("a = 1 [m]; b = 2 - 2 j; c = 1 - 1 j [mm];"
                "e1 = b + c; e2 = b * c; e3 = 3 + 1 j * a; e4 = a / c")
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    type_list = (COMPLEX, COMPLEX, COMPLEX, COMPLEX)
    name_list = ('e1', 'e2', 'e3', 'e4')
    for name, typ in zip(name_list, type_list):
        var = next(v for v in var_objs if v.name == name)
        assert issubclass(var.type_, typemap['Quantity'])
        assert issubclass(var.type_.datatype, typ)


def test_type_power_expression(meta_model_static):
    """test power type checker for arithmetic expressions and variables"""
    prog_str = ("z = 3; a = 5**1**3**2+1; b = 5*2**1**13; c = 0.4**-1.2; "
                "d = 0.3*-7**-3; e = z**4")
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    type_list = (INT, INT, FLOAT, FLOAT, INT)
    name_list = ('a', 'b', 'c', 'd', 'e')
    for name, typ in zip(name_list, type_list):
        var = next(v for v in var_objs if v.name == name)
        assert issubclass(var.type_, typemap['Quantity'])
        assert issubclass(var.type_.datatype, typ)


def test_type_int_expression_upcasting_to_float(meta_model_static):
    """test expression upcasting to float due to possible units conversion"""
    prog_str = ("a = 10 [kelvin]; c = 1 [kelvin]; b = 100 [celsius];"
                "e1 = a - b; e2 = c * a; e3 = a * b; e4 = 3 * b")
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    type_list = (FLOAT, INT, FLOAT, FLOAT)
    name_list = ('e1', 'e2', 'e3', 'e4')
    for name, typ in zip(name_list, type_list):
        var = next(v for v in var_objs if v.name == name)
        assert issubclass(var.type_, typemap['Quantity'])
        assert issubclass(var.type_.datatype, typ)


def test_type_boolean_expression(meta_model_static):
    """test bool type checker for boolean expression objects and variables"""
    prog_str = "c = false; a = not (b and c); b = (c or true)"
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    exp_objs = get_children_of_type('Or', prog)
    assert len(get_children_of_type('Bool', prog)) == 2
    assert len(var_objs) == 3
    assert len(exp_objs) == 4
    assert all(issubclass(obj.type_, BOOL) for obj in var_objs)
    assert all(issubclass(obj.type_, BOOL) for obj in exp_objs)


def test_type_string_objects(meta_model_static):
    """test str type checker for string objects and variables"""
    prog_str = "a = b; b = 'Abc'"
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    str_objs = get_children_of_type('String', prog)
    assert len(var_objs) == 2
    assert len(str_objs) == 1
    assert all(issubclass(obj.type_, STR) for obj in var_objs)
    assert all(issubclass(obj.type_, STR) for obj in str_objs)


def test_type_comparison_objects(meta_model_static):
    """test bool type checker for comparison objects and variables"""
    prog_str = "c = a > b; a = 1; b = 2"
    prog = meta_model_static.model_from_str(prog_str)
    var_objs = get_children_of_type('Variable', prog)
    cmp_objs = get_children_of_type('Comparison', prog)
    assert len(var_objs) == 3
    assert len(cmp_objs) == 1
    var = next(v for v in var_objs if v.name == 'c')
    assert issubclass(var.type_, BOOL)


def test_type_comparison_type_mismatch(meta_model_static):
    """test comparison with a type mismatch"""
    prog_str = "c = a != b; a = 'c'; b = 2"
    msg = 'Type mismatch:'
    with pytest.raises(TypeMismatchError, match=msg):
        meta_model_static.model_from_str(prog_str)


def test_type_comparison_invalid_type(meta_model_static):
    """test comparison with invalid type"""
    prog_str = "c = a != b; a = 'a'; b = (b: 2)"
    msg = 'invalid type used in comparison: Series'
    with pytest.raises(TextXError, match=msg) as err_info:
        meta_model_static.model_from_str(prog_str)
    assert isinstance(err_info.value.__cause__, StaticTypeError)


def test_type_comparison_string_type_invalid_operator(meta_model_static):
    """test comparison of strings with invalid operator"""
    prog_str = "c = a > b; a = 'a'; b = 'b'"
    msg = 'comparison of String not possible with ">" operator'
    with pytest.raises(TextXError, match=msg) as err_info:
        meta_model_static.model_from_str(prog_str)
    assert isinstance(err_info.value.__cause__, StaticTypeError)


def test_expression_type_error(meta_model_static):
    """test expression type error catched after parsing"""
    prog_strs = ["bar = true; mixed_0 = 3 * bar # ExpressionTypeError",
                 "bar = true; threebar = 3*bar # ExpressionTypeError",
                 "notbar = false; twobar = 2*notbar # ExpressionTypeError"]
    for prog_str in prog_strs:
        with pytest.raises(ExpressionTypeError):
            meta_model_static.model_from_str(prog_str)


def test_expression_type_error_anonymous(meta_model_static):
    """test expression type error for expressions not assigned to variables"""
    prog_strs = ["string = 'Abc'; print(3+string)",
                 "foo = false; string = 'Abc'; print(foo+string)",
                 "foo = true; string = 'Abc'; print(foo*string)",
                 "foo = true; c = 4.3e-1; print(foo-c)",
                 "a = 10; c = 2.; print((a or c))",
                 "a = 1; c = -3; print((a and c))",
                 "a = -1e-5; c = 2.; print(not (a and c))"]
    for prog_str in prog_strs:
        with pytest.raises(ExpressionTypeError):
            meta_model_static.model_from_str(prog_str)


def test_type_mismatch_error(meta_model_static):
    """test type mismatch error catched after parsing"""
    prog_strs = ["str = 'c'; twotypes = str if true else 0.5 # TypeMismatchError",
                 "str = 'c'; twotypes = if(true, str, 0.5) # TypeMismatchError"]
    for prog_str in prog_strs:
        with pytest.raises(TypeMismatchError):
            meta_model_static.model_from_str(prog_str)


def test_textx_syntax_error(meta_model_static):
    """test type errors catched during parsing"""
    prog_strs = ["bar = true; twobar = 2*(not bar)",
                 "bar = true; foo = false; mixed_2 = 'bar' + 'foo'",
                 "mixed_3 = 3 + 'foo'"]
    for prog_str in prog_strs:
        with pytest.raises(TextXSyntaxError):
            meta_model_static.model_from_str(prog_str)


def test_textx_semantic_error(meta_model_static):
    """test type errors catched during parsing"""
    prog_strs = ["mixed_1 = 3 * true # parser error",
                 "mixed_4 = 3 * 'abc' # parser error"]
    for prog_str in prog_strs:
        with pytest.raises(TextXSyntaxError):
            meta_model_static.model_from_str(prog_str)


def test_unbound_import_type_comparision(meta_model_static):
    """unbound import type in comparison expression """
    prog_inp = 'use exp from math; a = (exp(1) < exp(2))\n'
    prog = meta_model_static.model_from_str(prog_inp)
    var_list = get_children_of_type('Variable', prog)
    calls = get_children_of_type('FunctionCall', prog)
    assert len(calls) == 2
    assert all(call.type_ is typemap['Any'] for call in calls)
    assert issubclass(next(v.type_ for v in var_list if v.name == 'a'), BOOL)


def test_import_type_comparision(meta_model_static):
    """inferred import type in comparison expression"""
    prog_inp = 'use exp from math; a = (exp(2) > 1); b = (exp(2) > 1.)\n'
    prog = meta_model_static.model_from_str(prog_inp)
    var_list = get_children_of_type('Variable', prog)
    calls = get_children_of_type('FunctionCall', prog)
    assert len(calls) == 2
    assert all(issubclass(call.type_, typemap['Quantity']) for call in calls)
    assert all(issubclass(var.type_, BOOL) for var in var_list)


def test_unbound_import_type_if_function(meta_model_static):
    """unbound import type in if function"""
    prog_inp = 'use exp from math; a = if(true, exp(1), exp(2))\n'
    prog = meta_model_static.model_from_str(prog_inp)
    var_list = get_children_of_type('Variable', prog)
    calls = get_children_of_type('FunctionCall', prog)
    assert len(calls) == 2
    assert all(call.type_ is typemap['Any'] for call in calls)
    var_a = next(v for v in var_list if v.name == 'a')
    assert var_a.type_ is typemap['Any']


def test_import_type_if_function(meta_model_static):
    """inferred import type in if function"""
    prog_inp = 'use exp from math; a = if(true, exp(1), 3.1)\n'
    prog = meta_model_static.model_from_str(prog_inp)
    var_list = get_children_of_type('Variable', prog)
    calls = get_children_of_type('FunctionCall', prog)
    assert len(calls) == 1
    assert issubclass(calls[0].type_, typemap['Quantity'])
    assert issubclass(calls[0].type_.datatype, FLOAT)
    var_a = next(v for v in var_list if v.name == 'a')
    assert issubclass(var_a.type_.datatype, FLOAT)


def test_function_call_type_in_print(meta_model_static):
    """bug function call type in print builtin"""
    inp = 'f(x) = 1 + x; print(f(1))\n'
    prog = meta_model_static.model_from_str(inp)
    calls = get_children_of_type('FunctionCall', prog)
    assert issubclass(calls[0].type_, typemap['Quantity'])
    assert issubclass(calls[0].type_.datatype, INT)


def test_function_call_invalid_parameter_type(meta_model_static):
    """"test function calls with invalid parameter types"""
    inps = ['f(x) = x*x; a = f(true)\n', 'f(x) = if(x, 1, 0); a = f(1.)\n']
    match_str = 'Invalid type in expression'
    for inp in inps:
        with pytest.raises(TextXError, match=match_str):
            meta_model_static.model_from_str(inp)


def test_function_call_variable_type(meta_model_static):
    """test a function call with a variable type"""
    inp = 'f(x) = x; a = f(1); b = f(not false); c = f("Abc"); d = f(1.2e-5)\n'
    prog = meta_model_static.model_from_str(inp)
    var_list = get_children_of_type('Variable', prog)
    type_list = (INT, BOOL, STR, FLOAT)
    name_list = ('a', 'b', 'c', 'd')
    for name, typ in zip(name_list, type_list):
        var = next(v for v in var_list if v.name == name)
        if issubclass(var.type_, (BOOL, STR)):
            assert issubclass(var.type_, typ)
        else:
            assert issubclass(var.type_.datatype, typ)


def test_series_with_numeric_types_and_mismatching_type(meta_model_static):
    """check series with numeric and other, mismatching element types"""
    inp = 's = ((s: 1, 2, false))'
    match_str = 'Series elements must have one type but 2 types were found'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_types_iterable_functions_unknown_datatype(meta_model_static):
    """check type of iterable functions with parameters of unknown datatype"""
    inp = ('use exp from numpy\n'
           'ene = (v: 0.1, 0.05)\n'
           's = sum(filter((x: x>0), map((e: exp(-e)), ene)))\n'
           'r = reduce((x, y: x+y), filter((x: x>0), map((e: exp(-e)), ene)))\n'
           'b = all(map((x: x>0), map((e: exp(-e)), ene)))\n'
           'a = any(map((x: x>0), map((e: exp(-e)), ene)))\n'
           'd = sum(ene[0], ene[1]); e = sum(ene[0], s)\n'
           'print(s, r, b, a, d, e)')
    meta_model_static.model_from_str(inp)


def test_parameter_type_function_series(meta_model_static):
    """check the parameter type of functions on series"""
    inps = ['t = ((a: 1, 2, 3)); a = 5 in t\n',
            't = ((a: 1, 2, 3)); e = all(t)\n',
            't = ((a: 1, 2, 3)); f = sum(t)\n']
    match_str = 'Parameter must be series or reference to series'
    for inp in inps:
        with pytest.raises(TextXError, match=match_str):
            meta_model_static.model_from_str(inp)


def test_parameter_type_function_non_iterables(meta_model_static):
    """check the parameter type of functions on non-iterables"""
    inps = ['t = 1; b = filter((x: x > 1), t)',
            't = "abc"; c = map((x: x + 1), t)',
            't = true; d = reduce((x, y: x + y), t)']
    match_str = 'inputs* must be either series or table-like'
    for inp in inps:
        with pytest.raises(TextXError, match=match_str):
            meta_model_static.model_from_str(inp)


def test_index_error(meta_model_static):
    """test invalid indexing"""
    inps = ['s = (length: 1, 2, 3) [meter]; print(s[3])',
            't = ((number: 1, 2, 3)); print(t[4])',
            't = ((number: 1, 2, 3)); print(t.number[4])']
    for inp in inps:
        with pytest.raises(TextXError, match='Index out of range'):
            meta_model_static.model_from_str(inp)


def test_slice_step_error(meta_model_static):
    """test invalid slice step"""
    inps = ['s = (length: 1, 2, 3) [meter]; print(s[0:2:0])',
            't = ((number: 1, 2, 3)); print(t[0:1:0])']
    for inp in inps:
        with pytest.raises(TextXError, match='Slice step cannot be zero'):
            meta_model_static.model_from_str(inp)


def test_quantity_with_uncertainty_invalid_nominal_type(meta_model_static):
    """test type error: uncertainty supported only for type Float"""
    msg = 'uncertainty supported only for type Float'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('c = 10 - 3 j +/- 2')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_quantity_with_uncertainty_invalid_stddev_type(meta_model_static):
    """test type error: uncertainty must be type Float"""
    msg = 'uncertainty must be type Float'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('d = 10 +/- 2 - 3 j')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_quantity_with_uncertainty_invalid_stddev_value(meta_model_static):
    """test value error: uncertainty cannot be negative"""
    msg = 'uncertainty cannot be negative'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('d = 1.0 +/- -0.4')
    assert isinstance(err.value.__cause__, StaticValueError)


def test_import_function_call_various_parameters(meta_model_static):
    """test call an imported function with various paramters"""
    inp = ("use func_ext from tests.imports;"
           "b = 2.*func_ext(true, 'abc', 1., [true], (1,), {'k': 2}, (s: false));"
           "a = func_ext(true, 'abc', 1., [true, false], (1,), {'k': 2}, (s: false))")
    meta_model_static.model_from_str(inp)


def test_import_function_call_parameter_type_mismatch(meta_model_static):
    """test call an imported function with mismatching parameter type"""
    inp = "use is_positive_q from tests.imports; a = is_positive_q(true)"
    msg = 'Argument "q" must be Quantity but is Boolean'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_return_type_mismatch(meta_model_static):
    """test call an imported function with return type error"""
    inp = "use is_positive_q from tests.imports; a = 1*is_positive_q(1)"
    msg = 'Function call type Boolean and type Quantity of parent expression do not match.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_unsupported_parameter_type(meta_model_static):
    """test call an imported function with unsupported parameter type"""
    inp = "use is_negative_int from tests.imports; a = is_negative_int(1)"
    msg = 'Argument "x" of imported function "is_negative_int" has unsupported type Integer.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_unsupported_return_type(meta_model_static):
    """test call an imported function with unsupported return type"""
    inp = "use do_nothing from tests.imports; a = do_nothing(1)"
    msg = 'Return type typing.NoReturn of imported function "do_nothing" is not supported.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_too_few_parameters(meta_model_static):
    """test call an imported function with invalid number of parameters"""
    inp = "use is_positive_q from tests.imports; a = is_positive_q()"
    msg = 'Function "is_positive_q" takes minimum 1 parameters but 0 were given.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_import_function_call_too_many_parameters(meta_model_static):
    """test call an imported function with invalid number of parameters"""
    inp = "use is_positive_q from tests.imports; a = is_positive_q(1, 2)"
    msg = 'Function "is_positive_q" takes maximum 1 parameters but 2 were given.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_import_function_call_returning_none(meta_model_static):
    """test call an imported function returning None"""
    inp = "use do_something from tests.imports; a = do_something(1)"
    msg = 'Return type None of imported function "do_something" is not supported.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_returning_bare_number(meta_model_static):
    """test call an imported function returning a bare number"""
    inp = "use get_bare_number from tests.imports; a = get_bare_number(1)"
    msg = 'Return type Number of imported function "get_bare_number" is not supported.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_import_function_call_returning_array(meta_model_static):
    """test call an imported function returning numpy array"""
    inp = "use get_numpy_array from tests.imports; a = get_numpy_array()"
    meta_model_static.model_from_str(inp)


def test_array_property_type(meta_model_static):
    """test array property types"""
    inp = ("a = FloatArray from file 'a.yaml'; b = [1, 2]; c = [[true, false]];"
           "a0 = a[0]; b0 = b[0]; c0 = c[0]; c00 = c[0][0]")
    var_list = get_children_of_type('Variable', meta_model_static.model_from_str(inp))
    a = next(v for v in var_list if v.name == 'a')
    assert a.type_ is FloatArray
    assert a.type_.datatype is typemap['Float']
    assert a.datalen == tuple()
    a0 = next(v for v in var_list if v.name == 'a0')
    assert a0.type_ is typemap['Any']
    b = next(v for v in var_list if v.name == 'b')
    assert b.type_ is IntArray
    assert b.type_.datatype is typemap['Integer']
    assert b.datalen == (2,)
    b0 = next(v for v in var_list if v.name == 'b0')
    assert b0.type_ is IntQuantity
    assert b0.type_.datatype is typemap['Integer']
    c = next(v for v in var_list if v.name == 'c')
    assert c.type_ is BoolArray
    assert c.type_.datatype is typemap['Boolean']
    assert c.datalen == (1, 2)
    c0 = next(v for v in var_list if v.name == 'c0')
    assert c0.type_ is BoolArray
    assert c0.type_.datatype is typemap['Boolean']
    c00 = next(v for v in var_list if v.name == 'c00')
    assert c00.type_ is typemap['Boolean']


def test_if_expression_type_upcasting(meta_model_static):
    """test if expression type with datatype upcasting"""
    inp = 't = 1.2; q = 3; v = if(true, t, q); c = 1 - 3.0 j; w = if(false, t, c)'
    var_list = get_children_of_type('Variable', meta_model_static.model_from_str(inp))
    var_v = next(v for v in var_list if v.name == 'v')
    assert var_v.type_.datatype is typemap['Float']
    var_w = next(v for v in var_list if v.name == 'w')
    assert var_w.type_.datatype is typemap['Complex']


def test_if_expression_type_mismath_error(meta_model_static):
    """text expression type mismatch error in if function"""
    inp = 'e = if(true, (c: 1), 1)'
    with pytest.raises(TypeMismatchError, match='Type mismatch'):
        meta_model_static.model_from_str(inp)


def test_if_expression_type_error(meta_model_static):
    """text expression type error in if function"""
    inp = 'c =  1. + 1 j; e = if(c, 2, 1)'
    with pytest.raises(ExpressionTypeError, match='Invalid type in expression'):
        meta_model_static.model_from_str(inp)


def test_return_type_of_dict_with_valid_accessor(meta_model_static):
    """test return the property type of Dict using a valid accessor"""
    inp = "d = {k1: 1}; print(d.k1)"
    ref_keyval = {"k1": 1}
    prog = meta_model_static.model_from_str(inp)
    var_obj = get_children_of_type('Variable', prog)
    var = var_obj[0]
    assert issubclass(var.type_, typemap['Dict'])
    assert hasattr(var, 'parameter')
    assert isinstance_r(var, ['Dict'])
    assert isinstance_m(var, ['Variable'])
    for key, val in var.value.items():
        assert val == ref_keyval[key]


def test_return_type_of_dict_with_invalid_accessor(meta_model_static):
    """test return the property type of Dict using an invalid accessor"""
    inp = "d = {k1: 1}; print(d.k2)"
    msg = "value not found for key k2 in Dict d"
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, PropertyError)


def test_dict_with_repeating_keys(meta_model_static):
    """dictionary with keys with repeating names """
    inp = 'd = {k1: 1, k2: 2, k2: 3}\n'
    match_str = 'Repeating keys were found in dictionary'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_arrays_of_different_shapes_in_series(meta_model_static):
    """test arrays in series of different shapes"""
    inp = 's = (s: [1, 2], [1]); print(s:array)'
    msg = 'Arrays of one shape expected in series but 2 shapes have been found'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_arrays_of_unknown_shapes_in_series(meta_model_static):
    """test arrays in series that have unknown shapes"""
    inp = "arr1 = FloatArray from file 'arr.json'; s = (s: arr1); arr2 = s:array"
    var_list = get_children_of_type('Variable', meta_model_static.model_from_str(inp))
    arr2 = next(v for v in var_list if v.name == 'arr2')
    assert arr2.datalen == tuple()


def test_boolean_reduce_unknown_parameter_type(meta_model_static):
    """test boolean reduce with unknown parameter type"""
    inp = 's = null; t = all(s)'
    var_list = get_children_of_type('Variable', meta_model_static.model_from_str(inp))
    s = next(v for v in var_list if v.name == 's')
    assert issubclass(s.type_, typemap['Series']), s.type_
    assert s.datalen is NA, f'{s}, {s.type_}, {s.datalen}'


def test_boolean_reduce_invalid_params_type(meta_model_static):
    """test boolean reduce with invalid parameters type"""
    inp = 's1 = 1; t = any(s1, true)'
    msg = 'All parameters of "any" must be Boolean.'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_in_expression_unknown_parameter_type(meta_model_static):
    """test membership expression with unknown parameter type"""
    inp = 's = null; t = 5 in s'
    var_list = get_children_of_type('Variable', meta_model_static.model_from_str(inp))
    s = next(v for v in var_list if v.name == 's')
    assert issubclass(s.type_, typemap['Series']), s.type_
    assert s.datalen is NA, f'{s}, {s.type_}, {s.datalen}'


def test_assignment_of_tuple_with_type_mismatch(meta_model_static):
    """test assignment of tuple object with type mismatch"""
    inp = 'f(x, y) = (x*x + y*y, 1); e = f(1, true)\n'
    match_str = 'Invalid type in expression'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_series_elements_of_different_type(meta_model_static):
    """series with elements of different type"""
    inp = "s1 = (numbers: 'a', 'b', true)\n"
    match_str = 'Series elements must have one type but 2 types were found'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_table_columns_of_different_size(meta_model_static):
    """table with columns of different size """
    inp = 't = ((temperature: 0, 1, 3), (pressure: 4., 5.))\n'
    match_str = 'Table columns must have one size but 2 sizes were found'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_table_columns_with_repeating_names(meta_model_static):
    """table with columns with repeating names """
    inp = 't = ((label: 0, 1, 3), (label: 4, 5, 6))\n'
    match_str = 'Repeating column names were found in table'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_object_properties_zero_slice(meta_model_static):
    """test object slice with an invalid slice step"""
    inp = 's = (numbers: 1, 2, 3); g = s[1:2:0]\n'
    with pytest.raises(TextXError, match='Slice step cannot be zero') as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticValueError)


def test_series_properties_invalid_index(meta_model_static):
    """test series slice with invalid index"""
    inp = 's = (numbers: 1, 2, 3); g = s[11]\n'
    with pytest.raises(TextXError, match='Index out of range') as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, SubscriptingError)


def test_table_properties_invalid_index(meta_model_static):
    """test table slice with invalid index"""
    inp = 't = ((numbers: 1, 2, 3), (strings: "c", "a", "b")); g = t[7]\n'
    with pytest.raises(TextXError, match='Index out of range') as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, SubscriptingError)


def test_table_from_tuple_type_error(meta_model_static):
    """test table from a tuple with parameters of wrong types"""
    inp = 'a = 3; s = (test: 1); t = Table(a, s)\n'
    match_str = 'The type of table column must be series'
    with pytest.raises(TextXError, match=match_str) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_map_size_mismatch(meta_model_static):
    """test size mismatch in map function"""
    msg = 'map inputs must have equal size'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('maps = map((x, y: x*y), (n: 1), (m: 2, 3))')
    assert isinstance(err.value.__cause__, StaticValueError)


def test_map_arguments_number_mismatch(meta_model_static):
    """test number of function arguments mismatch in map function"""
    msg = 'number of map function arguments and map inputs must be equal'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('maps = map((x, y: x*y), (n: 1))')
    assert isinstance(err.value.__cause__, StaticValueError)


def test_map_inputs_types(meta_model_static):
    """test map inputs are of table or series types"""
    inp = 'p = (1, 2); maps = map((x, y: x*y), p, (n: 1, 2))'
    msg = 'map inputs must be either series or table-like'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str(inp)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_sum_non_numerical_types(meta_model_static, model_kwargs):
    """test use of non-numerical types in sum function"""
    msg = 'Series must be of type Number'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('invalid = sum((strings: "a", "1"))', **model_kwargs)
    assert isinstance(err.value.__cause__, StaticTypeError)
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('bsum = sum((bool: true, false))', **model_kwargs)
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_filter_wrong_arguments_number(meta_model_static):
    """test wrong number of function arguments in filter function"""
    msg = 'Filter function must have only one argument'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('fi = filter((x, y: x > y), (n: 1, 2, 3))')
    assert isinstance(err.value.__cause__, StaticValueError)


def test_filter_wrong_type(meta_model_static):
    """test wrong type of function in filter function"""
    msg = 'Filter function must be of boolean type'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('fi = filter((x: 2*x), (n: 1, 2, 3))')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_reduce_wrong_arguments_number(meta_model_static):
    """test wrong type of function arguments in reduce function"""
    msg = 'Reduce function must have exactly two arguments'
    with pytest.raises(TextXError, match=msg) as err:
        meta_model_static.model_from_str('re = reduce((x: x + 1), (n: 1, 2, 3))')
    assert isinstance(err.value.__cause__, StaticValueError)


def test_boolean_reduce_parameters_wrong_type(meta_model_static):
    """test wrong type of parameters in boolean reduce function"""
    with pytest.raises(TextXError, match='Series must be of type Boolean') as err:
        meta_model_static.model_from_str('bured = any((n: 1, 2, 3))')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_in_expression_wrong_type(meta_model_static):
    """test wrong type of parameters in in-expression"""
    with pytest.raises(TextXError, match='Parameter must be series or reference to series') as err:
        meta_model_static.model_from_str('a = 1; print(1 in a)')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_range_function_complex(meta_model_static):
    """test builtin range function with invalid complex parameter type"""
    with pytest.raises(TextXError, match='Range parameter must be real type.') as err:
        meta_model_static.model_from_str('a = range(0, 1.+1. j, 1)')
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_range_function_wrong_type(meta_model_static):
    """test builtin range function with wrong parameter type"""
    with pytest.raises(TextXError, match='Range parameter must be numeric type.') as err:
        meta_model_static.model_from_str("f(x) = x; a = range(0, f('a'), 1)")
    assert isinstance(err.value.__cause__, StaticTypeError)


def test_series_properties_invalid_columns_property(meta_model_static):
    """test series with invalid columns property"""
    inp = 's = (numbers: 1, 2, 3); g = s:columns\n'
    match_str = 'Parameter of type Series has no property "columns"'
    with pytest.raises(IterablePropertyError, match=match_str):
        meta_model_static.model_from_str(inp)


def test_table_properties_invalid_name_property(meta_model_static):
    """test table with invalid name property"""
    inp = 't = ((temperature: 0, 1, 3)); a = t:name\n'
    match_str = 'Parameter of type Table has no property "name"'
    with pytest.raises(IterablePropertyError, match=match_str):
        meta_model_static.model_from_str(inp)


def test_series_properties_invalid_array_property(meta_model_static):
    """test series with invalid array property"""
    inp = 's = (numbers: 1, 2, 3); g = s[1]:array\n'
    match_str = 'Parameter of type Quantity has no property "array"'
    with pytest.raises(IterablePropertyError, match=match_str):
        meta_model_static.model_from_str(inp)


def test_table_properties_invalid_element_array_property(meta_model_static):
    """test table with invalid element array property"""
    inp = 't = ((temperature: 0, 1, 3)); j = t[0]:array\n'
    match_str = 'Parameter of type Tuple has no property "array"'
    with pytest.raises(IterablePropertyError, match=match_str):
        meta_model_static.model_from_str(inp)


def test_table_properties_invalid_array_property(meta_model_static):
    """test table with invalid array property"""
    inp = 't = ((temperature: 0, 1, 3)); j = t:array\n'
    match_str = 'Parameter of type Table has no property "array"'
    with pytest.raises(IterablePropertyError, match=match_str):
        meta_model_static.model_from_str(inp)
