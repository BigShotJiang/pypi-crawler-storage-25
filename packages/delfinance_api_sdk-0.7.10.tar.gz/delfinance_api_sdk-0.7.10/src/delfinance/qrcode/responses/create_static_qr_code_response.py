from typing import Optional, Dict, Any, Union
from ..dtos.address_dto import AddressDTO

class CreateStaticQrCodeResponse:
    def __init__(self, data: Dict[str, Any]):
        self.transaction_id: Optional[str] = data.get('transactionId')
        self.correlation_id: Optional[str] = data.get('correlationId')
        self.amount: Optional[float] = data.get('amount')
        self.pix_key: Optional[str] = data.get('pixKey')
        self.beneficiary_name: Optional[str] = data.get('beneficiaryName')
        self.beneficiary_ispb: Optional[str] = data.get('beneficiaryIspb')
        
        address_data = data.get('address')
        self.address: Optional[Union[AddressDTO, Dict[str, Any]]] = None
        if address_data:
            if isinstance(address_data, dict) and all(k in address_data for k in ['cityName', 'zipCode', 'uf', 'state', 'street']):
                self.address = AddressDTO(**address_data)
            else:
                self.address = address_data

        self.additional_info: Optional[str] = data.get('additionalInfo')
        self.created_at: Optional[str] = data.get('createdAt')
        self.payload_pix: Optional[str] = data.get('payloadPix')
        self.base64_image: Optional[str] = data.get('base64Image')
        self.ispb_pss: Optional[str] = data.get('ispbPss')
