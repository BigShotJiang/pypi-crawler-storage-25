from typing import Optional, Dict, Any, List, Union
from ..dtos.address_dto import AddressDTO

class ImmediateQrCodeRequest:
    def __init__(
        self,
        correlation_id: str = None,
        amount: float = None,
        format_response: str = None,
        expires_in: Union[str, int] = None,
        pix_key: Optional[str] = None,
        address: Optional[Union[AddressDTO, Dict[str, Any]]] = None,
        payer: Optional[Dict[str, Any]] = None,
        final_beneficiary: Optional[Dict[str, Any]] = None,
        additional_infos: Optional[List[Dict[str, Any]]] = None,
        allow_change_amount: Optional[bool] = None,
        change: Optional[Dict[str, Any]] = None,
        withdrawal: Optional[Dict[str, Any]] = None,
        split_instructions: Optional[List[Dict[str, Any]]] = None,
        allowed_payers_account: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ):
        self.correlation_id = correlation_id
        self.amount = amount
        self.pix_key = pix_key
        self.address = address
        self.payer = payer
        self.final_beneficiary = final_beneficiary
        self.format_response = format_response
        self.additional_infos = additional_infos
        self.expires_in = expires_in
        self.allow_change_amount = allow_change_amount
        self.change = change
        self.withdrawal = withdrawal
        self.split_instructions = split_instructions
        self.allowed_payers_account = allowed_payers_account

    def to_body_request(self) -> Dict[str, Any]:
        data = {}
        if self.correlation_id:
            data['correlationId'] = self.correlation_id
        if self.amount:
            data['amount'] = self.amount
        if self.format_response:
            data['formatResponse'] = self.format_response
        if self.expires_in:
            data['expiresIn'] = self.expires_in
        if self.pix_key:
            data['pixKey'] = self.pix_key
        if self.address:
            data['address'] = self.address.to_dict() if hasattr(self.address, 'to_dict') else self.address
        if self.payer:
            data['payer'] = self.payer
        if self.final_beneficiary:
            data['finalBeneficiary'] = self.final_beneficiary
        if self.additional_infos:
            data['additionalInfos'] = self.additional_infos
        if self.allow_change_amount is not None:
            data['allowChangeAmount'] = self.allow_change_amount
        if self.change:
            data['change'] = self.change
        if self.withdrawal:
            data['withdrawal'] = self.withdrawal
        if self.split_instructions:
            data['splitInstructions'] = self.split_instructions
        if self.allowed_payers_account:
            data['allowedPayersAccount'] = self.allowed_payers_account
        return data
