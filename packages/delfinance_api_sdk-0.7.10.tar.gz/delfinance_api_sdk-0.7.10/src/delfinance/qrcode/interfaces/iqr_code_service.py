from abc import ABC, abstractmethod
from typing import List
from ..requests.static_qr_code_request import StaticQrCodeRequest
from ..requests.due_date_qr_code_request import DueDateQrCodeRequest
from ..requests.immediate_qr_code_request import ImmediateQrCodeRequest
from ..responses.create_static_qr_code_response import CreateStaticQrCodeResponse
from ..responses.create_due_date_qr_code_response import CreateDueDateQrCodeResponse
from ..responses.create_immediate_qr_code_response import CreateImmediateQrCodeResponse
from ..responses.get_qr_code_response import GetQrCodeResponse
from ..responses.qr_code_payment_response import QrCodePaymentResponse

class IQrCodeService(ABC):
    """
    Interface IQrCodeService
    """
    @abstractmethod
    def cancel_due_date_qr_code(self, id: str):
        pass

    @abstractmethod
    def cancel_immediate_qr_code(self, id: str):
        pass

    @abstractmethod
    def cancel_static_qr_code(self, transaction_identifier: str):
        pass

    @abstractmethod
    def get_static_qr_code_payments(self, identifier: str) -> List[QrCodePaymentResponse]:
        pass

    @abstractmethod
    def get_due_date_qr_code(self, id: str) -> GetQrCodeResponse:
        pass

    @abstractmethod
    def get_immediate_qr_code(self, id: str) -> GetQrCodeResponse:
        pass

    @abstractmethod
    def get_static_qr_code(self, transaction_identifier: str) -> GetQrCodeResponse:
        pass

    @abstractmethod
    def create_static_qr_code(self, request: StaticQrCodeRequest) -> CreateStaticQrCodeResponse:
        pass

    @abstractmethod
    def create_due_date_qr_code(self, request: DueDateQrCodeRequest) -> CreateDueDateQrCodeResponse:
        pass

    @abstractmethod
    def create_immediate_qr_code(self, request: ImmediateQrCodeRequest) -> CreateImmediateQrCodeResponse:
        pass
