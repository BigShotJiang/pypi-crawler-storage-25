from typing import Dict, Any, Optional

class AddressDTO:
    def __init__(self, 
                 city_name: str = None, 
                 zip_code: str = None, 
                 uf: str = None, 
                 state: str = None, 
                 street: str = None,
                 **kwargs):
        # Handle camelCase arguments from API response or kwargs
        self.city_name = city_name or kwargs.get('cityName')
        self.zip_code = zip_code or kwargs.get('zipCode')
        self.uf = uf or kwargs.get('uf')
        self.state = state or kwargs.get('state')
        self.street = street or kwargs.get('street')

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cityName": self.city_name,
            "zipCode": self.zip_code,
            "uf": self.uf,
            "state": self.state,
            "street": self.street
        }
