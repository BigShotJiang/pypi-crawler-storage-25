from typing import Optional, Dict, Any

class BillPaymentResponse:
    def __init__(self, data: Dict[str, Any]):
        self.id: Optional[str] = data.get('id')
        self.bar_code: Optional[str] = data.get('barCode')
        self.digitable_line: Optional[str] = data.get('digitableLine')
        self.identifier_number: Optional[str] = data.get('identifierNumber')
        self.bankslip_amount: Optional[float] = data.get('bankslipAmount')
        self.status: Optional[str] = data.get('status')
        self.due_date: Optional[str] = data.get('dueDate')
        self.payment_deadline: Optional[str] = data.get('paymentDeadline')
        self.total_to_be_charged_amount: Optional[float] = data.get('totalToBeChargedAmount')
        self.fee_amount: Optional[float] = data.get('feeAmount')
        self.fine_amount: Optional[float] = data.get('fineAmount')
        self.discount_amount: Optional[float] = data.get('discountAmount')
        self.rebate_amount: Optional[float] = data.get('rebateAmount')
        self.paid_amount: Optional[float] = data.get('paidAmount')
        self.created_at: Optional[str] = data.get('createdAt')
        self.paid_at: Optional[str] = data.get('paidAt')
        self.pay_at: Optional[str] = data.get('payAt')
        self.beneficiary: Optional[Dict[str, Any]] = data.get('beneficiary')
        self.payer: Optional[Dict[str, Any]] = data.get('payer')
        self.bank_issuer: Optional[Dict[str, Any]] = data.get('bankIssuer')
        self.payment_cancellation: Optional[Dict[str, Any]] = data.get('paymentCancellation')
        self.calculation: Optional[Dict[str, Any]] = data.get('calculation')
        self.category: Optional[Dict[str, Any]] = data.get('category')

