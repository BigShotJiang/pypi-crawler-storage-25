from typing import Optional, Dict, Any

class CreateChargeRequest:
    def __init__(
        self,
        type: Optional[str] = None,
        correlation_id: Optional[str] = None,
        amount: Optional[float] = None,
        rebate_amount: Optional[float] = None,
        your_number: Optional[str] = None,
        our_number: Optional[str] = None,
        description: Optional[str] = None,
        due_date: Optional[str] = None,
        void_date: Optional[str] = None,
        payer: Optional[Dict[str, Any]] = None,
        final_beneficiary: Optional[Dict[str, Any]] = None,
        discount: Optional[Dict[str, Any]] = None,
        late_fine: Optional[Dict[str, Any]] = None,
        late_payment: Optional[Dict[str, Any]] = None,
        notify_payer_of_creation: Optional[bool] = None,
        **kwargs
    ):
        self.type = type
        self.correlation_id = correlation_id
        self.amount = amount
        self.rebate_amount = rebate_amount
        self.your_number = your_number
        self.our_number = our_number
        self.description = description
        self.due_date = due_date
        self.void_date = void_date
        self.payer = payer
        self.final_beneficiary = final_beneficiary
        self.discount = discount
        self.late_fine = late_fine
        self.late_payment = late_payment
        self.notify_payer_of_creation = notify_payer_of_creation

    def to_body_request(self) -> Dict[str, Any]:
        data = {}

        if self.type is not None:
            data['type'] = self.type

        if self.correlation_id is not None:
            data['correlationId'] = self.correlation_id

        if self.amount is not None:
            data['amount'] = self.amount

        if self.rebate_amount is not None:
            data['rebateAmount'] = self.rebate_amount

        if self.your_number is not None:
            data['yourNumber'] = self.your_number

        if self.our_number is not None:
            data['ourNumber'] = self.our_number

        if self.description is not None:
            data['description'] = self.description

        if self.due_date is not None:
            data['dueDate'] = self.due_date

        if self.void_date is not None:
            data['voidDate'] = self.void_date

        if self.payer is not None:
            data['payer'] = self.payer

        if self.final_beneficiary is not None:
            data['finalBeneficiary'] = self.final_beneficiary

        if self.discount is not None:
            data['discount'] = self.discount

        if self.late_fine is not None:
            data['lateFine'] = self.late_fine

        if self.late_payment is not None:
            data['latePayment'] = self.late_payment

        if self.notify_payer_of_creation is not None:
            data['notifyPayerOfCreation'] = self.notify_payer_of_creation

        return data


