from typing import Optional, Dict, Any

class ListChargesByPeriodRequest:
    def __init__(
            self,
            page: Optional[int] = None,
            limit: Optional[int] = None,
            start_date: Optional[str] = None,
            end_date: Optional[str] = None,
            **kwargs
    ):
        self.page = page
        self.limit = limit
        self.start_date = start_date
        self.end_date = end_date

    def to_body_request(self) -> Dict[str, Any]:
        data = {}

        if self.page is not None:
            data['page'] = self.page

        if self.limit is not None:
            data['limit'] = self.limit

        if self.start_date is not None:
            data['startDate'] = self.start_date

        if self.end_date is not None:
            data['endDate'] = self.end_date

        return data