from typing import Optional, Dict, Any

class BillPaymentsRequest:
    def __init__(
        self,
        bar_code: Optional[str] = None,
        digitable_line: Optional[str] = None,
        amount: Optional[float] = None,
        pay_at: Optional[str] = None,
        category: Optional[str] = None,
        **kwargs
    ):
        self.bar_code = bar_code
        self.digitable_line = digitable_line
        self.amount = amount
        self.pay_at = pay_at
        self.category = category

    def to_body_request(self) -> Dict[str, Any]:
        data = {}

        if self.bar_code is not None:
            data['barCode'] = self.bar_code

        if self.digitable_line is not None:
            data['digitableLine'] = self.digitable_line

        if self.amount is not None:
            data['amount'] = self.amount

        if self.pay_at is not None:
            data['payAt'] = self.pay_at

        if self.category is not None:
            data['category'] = self.category

        return data

