from abc import ABC, abstractmethod

class IPixService(ABC):
    """
    Interface IPixService
    """
    @abstractmethod
    def payment_initialization(self, request):
        """
        Initializes a Pix payment using a DICT key.
        
        :param request: PaymentInitializationRequest
        :return: PaymentInitializationResponse
        """
        pass

    @abstractmethod
    def decode_qr_code(self, request):
        """
        Initializes a Pix payment using a QR Code payload.
        
        :param request: DecodeQrCodeRequest
        :return: DecodeQrCodeResponse
        """
        pass

    @abstractmethod
    def create_pix_key(self, request, idempotency_key: str):
        """
        Creates a Pix Key.
        
        :param request: CreatePixKeyRequest
        :param idempotency_key: Required UUID string
        :return: CreatePixKeyResponse
        """
        pass

    @abstractmethod
    def delete_pix_key(self, request, idempotency_key: str):
        """
        Deletes a Pix Key.
        
        :param request: DeletePixKeyRequest
        :param idempotency_key: Required UUID string
        :return: None
        """
        pass

    @abstractmethod
    def get_pix_keys(self):
        """
        List all Pix Keys.
        
        :return: GetPixKeysResponse
        """
        pass

    @abstractmethod
    def generate_auth_code(self, request):
        """
        Generates an Auth Code for email/phone Pix keys.
        
        :param request: GenerateAuthCodeRequest
        :return: GenerateAuthCodeResponse
        """
        pass
