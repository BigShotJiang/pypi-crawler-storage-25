from typing import Optional

class DeletePixKeyRequest:
    """
    Request object for deleting a Pix Key.
    """
    def __init__(
        self,
        entry_type: str,
        key: str
    ):
        """
        :param entry_type: Required. Possible values: DOCUMENT, EVP, PHONE, EMAIL
        :param key: Required. The key to be deleted.
        """
        self.entry_type = entry_type
        self.key = key

    def to_dict(self) -> dict:
        return {
            'entryType': self.entry_type,
            'key': self.key
        }
