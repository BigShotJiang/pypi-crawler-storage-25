class PaymentInitializationRequest:
    """
    Request payload for initializing a Pix payment.
    """
    def __init__(self, key: str, holder_document: str = None):
        """
        PaymentInitializationRequest constructor.
        :param key: The DICT key
        :param holder_document: (Optional) The document of the key holder
        """
        self.key = key
        self.holder_document = holder_document
