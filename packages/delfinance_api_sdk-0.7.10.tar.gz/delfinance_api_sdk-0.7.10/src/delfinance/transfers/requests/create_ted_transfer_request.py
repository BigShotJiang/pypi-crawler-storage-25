from typing import Optional
from delfinance.transfers.dto.beneficiary import Beneficiary

class CreateTedTransferRequest:
    def __init__(
        self,
        amount: float,
        beneficiary: Beneficiary,
        description: Optional[str] = None
    ):
        self.amount = amount
        self.beneficiary = beneficiary
        self.description = description

    def to_body_request(self):
        data = {
            'amount': self.amount,
            'beneficiary': self.beneficiary.to_body_request()
        }

        if self.description:
            data['description'] = self.description

        return data
