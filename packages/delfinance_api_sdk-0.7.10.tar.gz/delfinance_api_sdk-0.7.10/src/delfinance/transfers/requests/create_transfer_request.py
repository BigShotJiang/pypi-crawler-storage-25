from typing import List, Optional, Dict, Any, Union
from datetime import datetime

class CreateTransferRequest:
    def __init__(
        self,
        amount: float,
        description: Optional[str] = None,
        end_to_end_id: Optional[str] = None,
        initiation_type: Optional[str] = None,
        beneficiary_id: Optional[str] = None,
        save_favorite: bool = False,
        type: str = 'Pix',
        beneficiary: Optional[Union[Dict[str, Any], object]] = None,
        beneficiary_account: Optional[str] = None,
        transaction_id: Optional[str] = None,
        transfer_at: Optional[str] = None,
        tags: Optional[List[str]] = None,
        external_id: Optional[str] = None,
        split_instructions: Optional[List[Dict[str, Any]]] = None
    ):
        self.amount = amount
        self.description = description
        self.end_to_end_id = end_to_end_id
        self.initiation_type = initiation_type
        self.beneficiary_id = beneficiary_id
        self.save_favorite = save_favorite
        self.type = type
        self.beneficiary = beneficiary
        self.beneficiary_account = beneficiary_account
        self.transaction_id = transaction_id

        if transfer_at is None:
            self.transfer_at = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        else:
            self.transfer_at = transfer_at
            
        self.tags = tags if tags is not None else []
        self.external_id = external_id
        self.split_instructions = split_instructions if split_instructions is not None else []

    def to_body_request(self):
        data = {}

        if self.amount is not None:
            data['amount'] = self.amount
            
        if self.save_favorite is not None:
            data['saveFavorite'] = self.save_favorite
            
        if self.type:
            data['type'] = self.type
            
        if self.transfer_at:
            data['transferAt'] = self.transfer_at
            
        if self.tags:
            data['tags'] = self.tags
            
        if self.split_instructions:
            data['splitInstructions'] = self.split_instructions
        
        if self.description:
            data['description'] = self.description
            
        if self.end_to_end_id:
            data['endToEndId'] = self.end_to_end_id
            
        if self.initiation_type:
            data['initiationType'] = self.initiation_type
            
        if self.beneficiary_id:
            data['beneficiaryId'] = self.beneficiary_id
            
        if self.beneficiary:
            data['beneficiary'] = self.beneficiary
            
        if self.beneficiary_account:
            data['beneficiaryAccount'] = self.beneficiary_account
            
        if self.transaction_id:
            data['transactionId'] = self.transaction_id
            
        if self.external_id:
            data['externalId'] = self.external_id
            
        return data
