from typing import Dict, Any, Optional

class CreatePixKeyResponse:
    """
    Response object for Create Pix Key operation.
    """
    def __init__(self, data: Dict[str, Any] = None):
        self.key = None
        self.entry_type = None
        self.created_at = None
        self.status = None
        
        # Generic catch-all for unknown fields since exact response wasn't specified
        self.raw_data = data

        if data:
            self.key = data.get('key')
            self.entry_type = data.get('entryType')
            self.created_at = data.get('createdAt')
            self.status = data.get('status')
