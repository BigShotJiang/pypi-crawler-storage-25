class PaymentInitializationResponse:
    """
    Response object for Pix payment initialization.
    """
    def __init__(self, data: dict = None):
        self.end_to_end_id = None
        self.key = None
        self.beneficiary = None
        self.key_belongs_holder = None

        if data:
            self.end_to_end_id = data.get('endToEndId')
            self.key = data.get('key')
            self.beneficiary = data.get('beneficiary')
            self.key_belongs_holder = data.get('keyBelongsHolder')
