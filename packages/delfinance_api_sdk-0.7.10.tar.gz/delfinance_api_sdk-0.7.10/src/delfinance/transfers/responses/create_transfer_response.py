from ..dto.balance import Balance

class CreateTransferResponse:
    """
    Response object for Create Transfer operation.
    """
    def __init__(self, data: dict = None):
        self.id = None
        self.end_to_end_id = None
        self.transaction_nsu = None
        self.external_id = None
        self.status = None
        self.type = None
        self.amount = None
        self.created_at = None
        self.description = None
        self.updated_at = None
        self.error = None
        self.payer = None
        self.beneficiary = None
        self.paymentChannel = None
        self.balance = None

        if data:
            self.id = data.get('id')
            self.end_to_end_id = data.get('endToEndId')
            self.transaction_nsu = data.get('transactionNsu')
            self.external_id = data.get('externalId')
            self.status = data.get('status')
            self.type = data.get('type')
            self.amount = data.get('amount')
            self.created_at = data.get('createdAt')
            self.description = data.get('description')
            self.updated_at = data.get('updatedAt')
            self.error = data.get('error')
            self.payer = data.get('payer')
            self.beneficiary = data.get('beneficiary')
            self.paymentChannel = data.get('paymentChannel')
            
            balance_data = data.get('balance')
            if balance_data:
                self.balance = Balance(balance_data)
