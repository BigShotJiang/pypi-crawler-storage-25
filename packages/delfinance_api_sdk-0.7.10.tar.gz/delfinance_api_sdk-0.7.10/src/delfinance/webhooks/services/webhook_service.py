import requests
from typing import List
from ..interfaces.iwebhook_service import IWebhookService
from ..requests.create_webhook_request import CreateWebhookRequest
from ..responses.webhook_response import WebhookResponse
from ...abstractions.startup.delfinance_client import DelfinanceClient

class WebhookService(IWebhookService):
    def __init__(self, client: DelfinanceClient):
        self.client = client

    def _get_headers(self) -> dict:
        return {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id()
        }

    def _get_cert(self):
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            return (self.client.get_certificate_path(), self.client.get_private_key_path())
        return None

    def create_webhook(self, request: CreateWebhookRequest) -> WebhookResponse:
        url = f"{self.client.get_base_url()}/baas/api/v1/webhooks"
        
        try:
            response = requests.post(
                url, 
                json=request.to_dict(),
                headers=self._get_headers(), 
                cert=self._get_cert(),
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            return WebhookResponse(response.json())
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_all_webhooks(self) -> List[WebhookResponse]:
        url = f"{self.client.get_base_url()}/baas/api/v1/webhooks"
        
        try:
            response = requests.get(
                url, 
                headers=self._get_headers(), 
                cert=self._get_cert(),
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            # If data is a list, map it. If it's wrapped in a key, adjust accordingly.
            # Assuming list based on typical REST patterns for "Search all".
            if isinstance(data, list):
                return [WebhookResponse(item) for item in data]
            return []
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_webhook_by_id(self, webhook_id: str) -> WebhookResponse:
        url = f"{self.client.get_base_url()}/baas/api/v1/webhooks/{webhook_id}"
        
        try:
            response = requests.get(
                url, 
                headers=self._get_headers(), 
                cert=self._get_cert(),
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            return WebhookResponse(response.json())
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def update_webhook(self, webhook_id: str, request: CreateWebhookRequest) -> WebhookResponse:
        url = f"{self.client.get_base_url()}/baas/api/v1/webhooks/{webhook_id}"
        
        try:
            response = requests.patch(
                url, 
                json=request.to_dict(),
                headers=self._get_headers(), 
                cert=self._get_cert(),
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            return WebhookResponse(response.json())
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def delete_webhook(self, webhook_id: str) -> None:
        url = f"{self.client.get_base_url()}/baas/api/v1/webhooks/{webhook_id}"
        
        try:
            response = requests.delete(
                url, 
                headers=self._get_headers(), 
                cert=self._get_cert(),
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")
