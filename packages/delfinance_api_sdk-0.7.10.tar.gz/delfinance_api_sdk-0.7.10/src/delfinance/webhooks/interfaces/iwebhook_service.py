from abc import ABC, abstractmethod
from typing import List
from ..requests.create_webhook_request import CreateWebhookRequest
from ..responses.webhook_response import WebhookResponse

class IWebhookService(ABC):
    
    @abstractmethod
    def create_webhook(self, request: CreateWebhookRequest) -> WebhookResponse:
        """
        Creates a new Webhook.
        """
        pass

    @abstractmethod
    def get_all_webhooks(self) -> List[WebhookResponse]:
        """
        List all Webhooks for the current API Key.
        """
        pass

    @abstractmethod
    def get_webhook_by_id(self, webhook_id: str) -> WebhookResponse:
        """
        Get a specific Webhook by ID.
        """
        pass

    @abstractmethod
    def update_webhook(self, webhook_id: str, request: CreateWebhookRequest) -> WebhookResponse:
        """
        Update an existing Webhook by ID.
        """
        pass

    @abstractmethod
    def delete_webhook(self, webhook_id: str) -> None:
        """
        Delete a Webhook by ID.
        """
        pass
