from typing import Dict, Any

class WebhookResponse:
    """
    Response object representing a Webhook entity.
    """
    def __init__(self, data: Dict[str, Any]):
        self.id = data.get('id')
        self.event_type = data.get('eventType')
        self.url = data.get('url')
        self.authorization_scheme = data.get('authorizationScheme')
        self.authorization = data.get('authorization')
        self.created_at = data.get('createdAt')
        self.updated_at = data.get('updatedAt')
        self.raw_data = data
