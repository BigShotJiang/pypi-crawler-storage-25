# skytraq-ui

PyQt6 desktop GUI for downloading and exporting GPS tracks from SkyTraq Venus devices.

## Features

- Detects available serial ports and connects at configurable baud rates
- Downloads the full datalog from the device with a sector-level progress bar
- Splits the raw point stream into trips (configurable gap threshold in minutes)
- Exports selected trips as GPX files, optionally named by start timestamp

## Requirements

- Python 3.11+
- `PyQt6 >= 6.4`
- [`skytraq-datalog`](https://gitlab.com/Teigi/skytraq-datalog) (provides `skytraq.gps`, `skytraq.gpx`, `skytraq.types`)
- `pyserial` (pulled in transitively for port enumeration)

## Installation

```bash
pip install skytraq_ui
```

## Usage

```bash
skytraq-ui
# or
python -m skytraq_ui
```

1. Select the serial port and baud rate (default 9600).
2. Set the trip-gap threshold (minutes of inactivity that separate trips).
3. Click **Download from device**.
4. Check the trips you want to export.
5. Set an output directory and filename prefix, then click **Save selected trips**.

## License

MIT
