"""skytraq_ui — PyQt6 GUI for the SkyTraq GPS downloader."""
