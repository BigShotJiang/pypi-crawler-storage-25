"""skytraq_ui.main_window — PyQt6 GUI for downloading and exporting GPS tracks.

Launch::

    python -m skytraq_ui
"""

from __future__ import annotations

import os
import sys

import serial.tools.list_ports  # type: ignore[import-untyped]
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QComboBox,
    QVBoxLayout,
    QWidget,
)

from skytraq.gps import SkytraqGPS
from skytraq.gpx import split_trips, export_gpx_split
from skytraq.types import LogPoint


# ---------------------------------------------------------------------------
# Background worker — download only, no export
# ---------------------------------------------------------------------------


class DownloadWorker(QThread):
    """Downloads raw track data from the device in a background thread.

    Signals
    -------
    progress(done, total)        sector download progress
    trips_ready(trips)           list[list[LogPoint]] after split
    error(message)               failure description
    """

    progress: pyqtSignal = pyqtSignal(int, int)
    trips_ready: pyqtSignal = pyqtSignal(object)  # list[list[LogPoint]]
    error: pyqtSignal = pyqtSignal(str)

    def __init__(self, port: str, baudrate: int, gap: int) -> None:
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self.gap = gap

    def _emit_progress(self, done: int, total: int) -> None:
        self.progress.emit(done, total)  # type: ignore[union-attr]

    def run(self) -> None:
        try:
            gps = SkytraqGPS(self.port, baudrate=self.baudrate)
            points = gps.download_tracks(progress=self._emit_progress)
        except Exception as exc:
            self.error.emit(str(exc))
            return

        if not points:
            self.error.emit("No tracks found on device.")
            return

        trips = split_trips(points, route_criteria=self.gap)
        if not trips:
            self.error.emit("No valid track points after filtering.")
            return

        self.trips_ready.emit(trips)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("SkyTraq GPS Downloader")
        self.setMinimumWidth(560)
        self._worker: DownloadWorker | None = None
        self._trips: list[list[LogPoint]] = []

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setSpacing(8)

        root.addWidget(self._build_connection_group())
        root.addWidget(self._build_download_group())
        root.addWidget(self._build_trip_group())
        root.addWidget(self._build_export_group())
        root.addWidget(self._build_log_group())

        self._refresh_ports()
        self._update_save_btn()

    # ------------------------------------------------------------------
    # UI builders
    # ------------------------------------------------------------------

    def _build_connection_group(self) -> QGroupBox:
        box = QGroupBox("Connection")
        row = QHBoxLayout(box)

        row.addWidget(QLabel("Port:"))
        self._port_combo = QComboBox()
        self._port_combo.setMinimumWidth(140)
        row.addWidget(self._port_combo)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.setFixedWidth(70)
        refresh_btn.clicked.connect(self._refresh_ports)  # type: ignore[union-attr]
        row.addWidget(refresh_btn)

        row.addSpacing(16)
        row.addWidget(QLabel("Baud:"))
        self._baud_combo = QComboBox()
        for b in [4800, 9600, 19200, 38400, 57600, 115200]:
            self._baud_combo.addItem(str(b), b)
        self._baud_combo.setCurrentIndex(1)  # 9600 default
        row.addWidget(self._baud_combo)

        row.addSpacing(16)
        row.addWidget(QLabel("Trip gap (min):"))
        self._gap_spin = QSpinBox()
        self._gap_spin.setRange(1, 120)
        self._gap_spin.setValue(10)
        self._gap_spin.setFixedWidth(55)
        row.addWidget(self._gap_spin)

        row.addStretch()
        return box

    def _build_download_group(self) -> QGroupBox:
        box = QGroupBox("Download")
        layout = QVBoxLayout(box)

        self._progress_bar = QProgressBar()
        self._progress_bar.setValue(0)
        layout.addWidget(self._progress_bar)

        self._download_btn = QPushButton("Download from device")
        self._download_btn.setFixedHeight(32)
        self._download_btn.clicked.connect(self._start_download)  # type: ignore[union-attr]
        layout.addWidget(self._download_btn)

        return box

    def _build_trip_group(self) -> QGroupBox:
        box = QGroupBox("Trips  (check to select for export)")
        layout = QVBoxLayout(box)

        self._trip_list = QListWidget()
        self._trip_list.setMaximumHeight(160)
        self._trip_list.itemChanged.connect(self._update_save_btn)  # type: ignore[union-attr]
        layout.addWidget(self._trip_list)

        sel_row = QHBoxLayout()
        all_btn = QPushButton("Select all")
        none_btn = QPushButton("Select none")
        all_btn.setFixedWidth(90)
        none_btn.setFixedWidth(90)
        all_btn.clicked.connect(self._select_all)  # type: ignore[union-attr]
        none_btn.clicked.connect(self._select_none)  # type: ignore[union-attr]
        sel_row.addWidget(all_btn)
        sel_row.addWidget(none_btn)
        sel_row.addStretch()
        layout.addLayout(sel_row)

        return box

    def _build_export_group(self) -> QGroupBox:
        box = QGroupBox("Export")
        layout = QVBoxLayout(box)

        dir_row = QHBoxLayout()
        dir_row.addWidget(QLabel("Output directory:"))
        self._dir_edit = QLineEdit(os.getcwd())
        dir_row.addWidget(self._dir_edit)
        browse_btn = QPushButton("Browse…")
        browse_btn.setFixedWidth(80)
        browse_btn.clicked.connect(self._browse_dir)  # type: ignore[union-attr]
        dir_row.addWidget(browse_btn)
        layout.addLayout(dir_row)

        opts_row = QHBoxLayout()
        opts_row.addWidget(QLabel("Filename prefix:"))
        self._prefix_edit = QLineEdit("tracks")
        self._prefix_edit.setFixedWidth(110)
        opts_row.addWidget(self._prefix_edit)

        opts_row.addSpacing(16)
        self._timestamp_check = QCheckBox("Use start-time filenames")
        self._timestamp_check.setChecked(True)
        opts_row.addWidget(self._timestamp_check)

        opts_row.addStretch()
        layout.addLayout(opts_row)

        self._save_btn = QPushButton("Save selected trips")
        self._save_btn.setFixedHeight(32)
        self._save_btn.clicked.connect(self._save_selected)  # type: ignore[union-attr]
        layout.addWidget(self._save_btn)

        return box

    def _build_log_group(self) -> QGroupBox:
        box = QGroupBox("Log")
        layout = QVBoxLayout(box)
        self._log = QPlainTextEdit()
        self._log.setReadOnly(True)
        self._log.setMaximumBlockCount(500)
        layout.addWidget(self._log)
        return box

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    def _refresh_ports(self) -> None:
        self._port_combo.clear()
        ports = sorted(p.device for p in serial.tools.list_ports.comports())
        for p in ports:
            self._port_combo.addItem(p)
        if not ports:
            self._port_combo.addItem("(no ports found)")

    def _browse_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select output directory", self._dir_edit.text())
        if path:
            self._dir_edit.setText(path)

    def _start_download(self) -> None:
        if self._worker and self._worker.isRunning():
            return

        port = self._port_combo.currentText()
        if not port or port.startswith("("):
            self._log_msg("No port selected.")
            return

        self._trips = []
        self._trip_list.clear()
        self._update_save_btn()
        self._download_btn.setEnabled(False)
        self._progress_bar.setValue(0)
        self._progress_bar.setFormat("Connecting…")
        self._log_msg(f"Connecting to {port} …")

        self._worker = DownloadWorker(
            port=port,
            baudrate=self._baud_combo.currentData(),
            gap=self._gap_spin.value(),
        )
        self._worker.progress.connect(self._on_progress)  # type: ignore[union-attr]
        self._worker.trips_ready.connect(self._on_trips_ready)  # type: ignore[union-attr]
        self._worker.error.connect(self._on_error)  # type: ignore[union-attr]
        self._worker.start()

    def _on_progress(self, done: int, total: int) -> None:
        if self._progress_bar.maximum() != total:
            self._progress_bar.setMaximum(total)
            self._progress_bar.setFormat("%v / %m sectors (%p%)")
        self._progress_bar.setValue(done)

    def _on_trips_ready(self, payload: object) -> None:
        trips: list[list[LogPoint]] = payload  # type: ignore[assignment]
        self._progress_bar.setValue(self._progress_bar.maximum())
        self._progress_bar.setFormat("Done")
        self._trips = trips
        self._log_msg(f"Download complete — {len(trips)} trip(s) found.")

        self._trip_list.blockSignals(True)
        self._trip_list.clear()
        for i, trip in enumerate(trips, start=1):
            start = trip[0].utc.strftime("%Y-%m-%d  %H:%M:%S")
            end = trip[-1].utc.strftime("%H:%M:%S")
            label = f"Trip {i:02d}  |  {start} – {end}  |  {len(trip)} points"
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked)
            self._trip_list.addItem(item)
        self._trip_list.blockSignals(False)

        self._download_btn.setEnabled(True)
        self._update_save_btn()

    def _on_error(self, message: str) -> None:
        self._progress_bar.setFormat("Error")
        self._log_msg(f"Error: {message}")
        self._download_btn.setEnabled(True)

    def _select_all(self) -> None:
        self._trip_list.blockSignals(True)
        for i in range(self._trip_list.count()):
            item = self._trip_list.item(i)
            if item is not None:
                item.setCheckState(Qt.CheckState.Checked)
        self._trip_list.blockSignals(False)
        self._update_save_btn()

    def _select_none(self) -> None:
        self._trip_list.blockSignals(True)
        for i in range(self._trip_list.count()):
            item = self._trip_list.item(i)
            if item is not None:
                item.setCheckState(Qt.CheckState.Unchecked)
        self._trip_list.blockSignals(False)
        self._update_save_btn()

    def _update_save_btn(self) -> None:
        n_checked = sum(
            item.checkState() == Qt.CheckState.Checked
            for i in range(self._trip_list.count())
            if (item := self._trip_list.item(i)) is not None
        )
        self._save_btn.setEnabled(n_checked > 0)
        if n_checked:
            self._save_btn.setText(f"Save {n_checked} selected trip(s)")
        else:
            self._save_btn.setText("Save selected trips")

    def _save_selected(self) -> None:
        out_dir = self._dir_edit.text()
        prefix = self._prefix_edit.text() or "tracks"
        ts_names = self._timestamp_check.isChecked()
        full_prefix = os.path.join(out_dir, prefix)

        saved: list[str] = []
        for i in range(self._trip_list.count()):
            item = self._trip_list.item(i)
            if item is None or item.checkState() != Qt.CheckState.Checked:
                continue
            trip = self._trips[i]
            paths = export_gpx_split(
                trip,
                prefix=full_prefix,
                route_criteria=999999,  # no further splitting of a single trip
                timestamp_names=ts_names,
            )
            saved.extend(paths)

        self._log_msg(f"Saved {len(saved)} file(s):")
        for p in saved:
            self._log_msg(f"  {p}")

    def _log_msg(self, text: str) -> None:
        self._log.appendPlainText(text)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
