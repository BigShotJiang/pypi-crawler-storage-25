---
name: env-resolve
description: >
  Resolve environment variables from MCP config or AWS Secrets Manager, then
  export them into the current shell. Use when the user says /env-resolve,
  'résous cette variable', 'exporte DD_API_KEY', 'charge les variables',
  'resolve env', 'load env vars', 'exporte mes secrets', or a downstream
  skill needs a var (ex. `DD_API_KEY`, `POSTMAN_API_KEY`, `MONGO_URI_DEV`,
  `MONGO_URI_PROD`) resolved before running.
argument-hint: "<VAR> [VAR2 ...] | --all  [--json|--set|--shell posix|powershell|cmd]"
allowed-tools:
  - Bash
---

Thin gateway over `pysae-ai-tools env resolve`. Resolves env vars by trying, in order:

1. the current shell environment (kept as-is),
2. the auto-command declared for the var (e.g. `pysae-ai-tools env secret get …`),
3. the matching MCP server config in `~/.claude.json`.

The command itself never writes to the user's shell — it only emits values or shell-assignment lines for the caller to consume.

## Commands at a glance

| Goal | Command |
|---|---|
| Print one value (stdout) | `pysae-ai-tools env resolve DD_API_KEY` |
| Print several values, one per line | `pysae-ai-tools env resolve DD_API_KEY DD_APP_KEY` |
| Export into the current shell (POSIX) | `eval "$(pysae-ai-tools env resolve --set DD_API_KEY DD_APP_KEY)"` |
| Export into PowerShell | `pysae-ai-tools env resolve --shell powershell DD_API_KEY \| Invoke-Expression` |
| Best-effort: resolve every known var | `pysae-ai-tools env resolve --all` |
| Machine-readable | `pysae-ai-tools env resolve --json DD_API_KEY DD_APP_KEY` |
| Rename a var on the fly | `pysae-ai-tools env resolve DATADOG_API_KEY=DD_API_KEY` |

## Resolution order

1. **Shell env** — if `$VAR` is already set, the value is kept as-is (no re-resolution).
2. **Auto command** — declared in `pysae_ai_tools/env/config.py`. Typically runs `pysae-ai-tools env secret get …` to pull from AWS Secrets Manager. Supports fallback lists (first non-empty stdout wins).
3. **MCP config fallback** — reads `~/.claude.json` → `mcpServers[<server>].env[<key>]`. Useful when the var was previously stored by `tools-install` but is not in the shell yet.

## Exit codes

- `0` — every requested var resolved (or `--all` ran best-effort).
- `1` — at least one requested var could not be resolved (positional form only; `--all` always exits 0).
- `2` — usage error (`--json` combined with `--set`, unknown `--shell` value, missing args without `--all`).

## Known vars

The resolver knows about (defined in `pysae_ai_tools/env/config.py`):

- `DD_API_KEY`, `DD_APP_KEY` — Datadog API + app keys (MCP fallback: `datadog`).
- `POSTMAN_API_KEY` — Postman workspace key (MCP fallback: `postman`).
- `MONGO_URI_DEV` — MongoDB URI de dev (AWS → `pysae/local-dev/secrets` then `pysae/dev/secrets`; MCP fallback: `mongodb-dev`).
- `MONGO_URI_PROD` — MongoDB URI de prod (AWS → `pysae/local-prod/secrets` then `pysae/prod/secrets`; MCP fallback: `mongodb-prod`).

For any other var, declare it in `env/config.py` first; otherwise `env resolve` exits 1.

## Typical usage in other skills

```bash
eval "$(pysae-ai-tools env resolve --set DD_API_KEY DD_APP_KEY)" || {
  echo "Could not resolve Datadog keys — run /tools-install datadog-mcp first." >&2
  exit 1
}
```

## Gotchas

- `--set` auto-detects the shell (POSIX on Linux/macOS, PowerShell or cmd on Windows). Override with `--shell` when piping across shells.
- `--set` and `--shell` swallow all stderr-originated resolver notices ("✓ resolved from …") — only the assignment lines reach stdout, which is mandatory for safe `eval`.
- The `auto` command in `env/config.py` must succeed with non-empty stdout to count as resolved. If AWS auth is expired, the command exits non-zero and the resolver falls back to MCP config.
- `--all` is **best-effort** — missing vars are silently skipped, not reported. Use positional form when you need a hard failure.
- Unknown vars (not in `ENV_CONFIG` and not in the environment) are always unresolved.

## When to route elsewhere

- To **inspect** secret values rather than resolve env vars → `env-secret`.
- To **install or upgrade** an MCP that would later populate fallbacks → `tools-install`.

$ARGUMENTS
