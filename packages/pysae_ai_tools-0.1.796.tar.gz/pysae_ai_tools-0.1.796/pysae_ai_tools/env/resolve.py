"""Resolve env vars via MCP config or AWS Secrets Manager.

Exposed as ``pysae-ai-tools env resolve``. Values are produced by trying, in
order: the current process environment, then the auto-strategies declared in
:mod:`pysae_ai_tools.env.config` (shell command → MCP config).
"""

import contextlib
import io
import json
import os
import subprocess
import sys
from typing import Annotated

import typer

from . import cache
from .config import ENV_CONFIG, CommandResolver, ManualResolver, McpResolver, Resolver, get_manual_instructions


def _run_command_resolver(resolver: CommandResolver, var: str) -> str | None:
    """Run a :class:`CommandResolver` and return the value on success.

    Dependencies listed in ``resolver.depends_on`` are resolved first (and
    injected into :data:`os.environ`), so the subprocess inherits them.
    """
    for dep in resolver.depends_on:
        if not os.environ.get(dep):
            try_auto_resolve(dep)

    try:
        result = subprocess.run(
            resolver.command.split(),
            capture_output=True,
            text=True,
            timeout=resolver.timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    if result.returncode != 0 or not result.stdout.strip():
        return None

    value = result.stdout.strip()
    os.environ[var] = value
    label = resolver.label or "automatically"
    print(f"  ✓ ${var} resolved {label}", file=sys.stderr)
    return value


def _run_mcp_resolver(resolver: McpResolver, var: str) -> str | None:
    """Run an :class:`McpResolver` and return the value on success."""
    from ..install.common.mcp import get_server

    try:
        srv = get_server(resolver.server)
    except (OSError, ValueError):
        return None
    if not srv:
        return None

    env = srv.get("env")
    if not isinstance(env, dict):
        return None
    raw = env.get(resolver.env_key)
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    if not value:
        return None

    os.environ[var] = value
    label = resolver.label or f"from MCP config ({resolver.server})"
    print(f"  ✓ ${var} resolved {label}", file=sys.stderr)
    return value


def _run_resolver(resolver: Resolver, var: str) -> str | None:
    """Dispatch to the right runner for the resolver kind.

    :class:`ManualResolver` never produces a value — its instructions are
    surfaced to the user elsewhere (CLI error message, interactive prompt).
    """
    match resolver:
        case CommandResolver():
            return _run_command_resolver(resolver, var)
        case McpResolver():
            return _run_mcp_resolver(resolver, var)
        case ManualResolver():
            return None


def try_auto_resolve(var: str, *, use_cache: bool = True) -> str | None:
    """Try each configured resolver in order — first non-empty value wins.

    When ``spec.cache`` is True and ``use_cache`` is True, the on-disk cache
    (``~/.config/ai-tools/env-cache.json``) is checked first, and a
    successful resolution is persisted back for the next call.
    """
    spec = ENV_CONFIG.get(var)
    if spec is None:
        return None

    if spec.cache and use_cache:
        if (cached := cache.read(var)) is not None:
            os.environ[var] = cached
            print(f"  ✓ ${var} resolved from cache", file=sys.stderr)
            return cached

    for resolver in spec.resolvers:
        if (value := _run_resolver(resolver, var)) is not None:
            if spec.cache:
                cache.write(var, value)
            return value
    return None


def _all_known_env_vars() -> list[str]:
    """Collect the unique env vars declared by any install tool, in tier order."""
    from ..install.all import TOOLS

    seen: list[str] = []
    for tool in TOOLS:
        for var in tool.env_required:
            if var not in seen:
                seen.append(var)
    return seen


_VALID_SHELLS = ("posix", "powershell", "cmd")


def _detect_shell() -> str:
    """Best-effort detection of the invoking shell.

    Non-Windows → posix. Windows → posix if SHELL is set (Git Bash / MSYS2 /
    Cygwin / WSL), else powershell if PSModulePath is set, else cmd.
    """
    if sys.platform != "win32":
        return "posix"
    if os.environ.get("SHELL"):
        return "posix"
    if os.environ.get("PSModulePath"):
        return "powershell"
    return "cmd"


def _format_set_line(shell: str, name: str, value: str) -> str:
    """Format a single variable assignment for the given shell."""
    import shlex

    if shell == "posix":
        return f"export {name}={shlex.quote(value)}"
    if shell == "powershell":
        escaped = value.replace("'", "''")
        return f"$env:{name} = '{escaped}'"
    if shell == "cmd":
        escaped = value.replace("%", "%%").replace('"', '""')
        return f'set "{name}={escaped}"'
    raise ValueError(f"unknown shell: {shell}")


def _set_mode_hint(shell: str) -> str:
    """Shell-compatible comment telling the user how to consume the output."""
    if shell == "posix":
        return '# Pipe into `eval "$(…)"` to apply the exports in your shell.'
    if shell == "powershell":
        return "# Pipe into `Invoke-Expression` (alias `iex`) to apply: `… | iex`."
    if shell == "cmd":
        return ":: Consume via `for /f \"delims=\" %i in ('…') do @%i` to apply."
    raise ValueError(f"unknown shell: {shell}")


def resolve(
    vars: Annotated[
        list[str] | None,
        typer.Argument(
            help=(
                "Env var name(s) to resolve. Supports aliasing via "
                "`OUT=SRC` — e.g. `DATADOG_API_KEY=DD_API_KEY` resolves "
                "DD_API_KEY and emits it under DATADOG_API_KEY."
            ),
        ),
    ] = None,
    all_vars: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Resolve every env var declared by any tool. Best-effort — unresolved vars are silently skipped.",
        ),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output: {VAR: value, …}")] = False,
    set_mode: Annotated[
        bool,
        typer.Option(
            "--set",
            help=(
                "Emit shell-compatible assignment lines (auto-detected). Safe for "
                '`eval "$(…)"` (posix), `| Invoke-Expression` (powershell), or '
                "`for /f` loops (cmd). Combine with `--shell` to override the format."
            ),
        ),
    ] = False,
    shell: Annotated[
        str | None,
        typer.Option(
            "--shell",
            help="Force the output shell format: `posix`, `powershell`, or `cmd`. Implies `--set`.",
        ),
    ] = None,
    no_cache: Annotated[
        bool,
        typer.Option(
            "--no-cache",
            help="Bypass the on-disk cache — force the resolver chain to run and overwrite any cached value.",
        ),
    ] = False,
    clear_cache: Annotated[
        bool,
        typer.Option(
            "--clear-cache",
            help="Clear cached entries (for the listed VARs, or all when combined with `--all`) and exit.",
        ),
    ] = False,
) -> None:
    """Resolve env vars via MCP config or AWS Secrets Manager.

    Tries the configured auto-resolve strategies (shell / MCP config) for each
    variable. Values already present in the environment are kept as-is.

    Without `--all`, every named variable must resolve (exits 1 otherwise).
    With `--all`, the command is best-effort: unresolved vars are skipped.
    """
    emit_set_lines = set_mode or shell is not None

    if json_output and emit_set_lines:
        typer.echo("--json and --set/--shell are mutually exclusive", err=True)
        raise typer.Exit(code=2)

    if shell is not None and shell not in _VALID_SHELLS:
        typer.echo(
            f"--shell: invalid value {shell!r} (expected posix|powershell|cmd)",
            err=True,
        )
        raise typer.Exit(code=2)

    resolved_shell = shell or (_detect_shell() if emit_set_lines else None)

    if clear_cache:
        if all_vars and not vars:
            cache.clear(None)
            typer.echo("cache cleared", err=True)
            return
        if not vars:
            typer.echo("usage: --clear-cache <VAR>... | --clear-cache --all", err=True)
            raise typer.Exit(code=2)
        for spec in vars:
            target, _, _ = spec.partition("=")
            cache.clear(target)
        typer.echo(f"cache cleared for: {', '.join(v.partition('=')[0] for v in vars)}", err=True)
        return

    if all_vars:
        if vars:
            typer.echo("--all cannot be combined with positional var names", err=True)
            raise typer.Exit(code=2)
        specs = _all_known_env_vars()
    else:
        if not vars:
            typer.echo("usage: resolve <VAR>... | --all", err=True)
            raise typer.Exit(code=2)
        specs = vars

    # Parse each spec into (output_name, source_name). Plain "VAR" → both equal.
    pairs: list[tuple[str, str]] = []
    for spec in specs:
        out, sep, src = spec.partition("=")
        pairs.append((out, src if sep else out))

    # In --set mode the output is meant to be piped into `eval` (or
    # Invoke-Expression) — the only admissible display is the assignment
    # lines. Suppress every other stderr line (resolver "✓ resolved from …"
    # notices, "Could not resolve" errors); the exit code still conveys the
    # outcome to the caller.
    silence: contextlib.AbstractContextManager[object] = (
        contextlib.redirect_stderr(io.StringIO()) if emit_set_lines else contextlib.nullcontext()
    )

    resolved: dict[str, str] = {}
    missing: list[str] = []
    with silence:
        for out, src in pairs:
            value = os.environ.get(src) or try_auto_resolve(src, use_cache=not no_cache)
            if value:
                resolved[out] = value
            elif not all_vars:
                missing.append(src)

        if missing:
            typer.echo(f"Could not resolve: {', '.join(missing)}", err=True)
            for var_name in missing:
                if hint := get_manual_instructions(var_name):
                    typer.echo(f"  {var_name}: {hint}", err=True)
            raise typer.Exit(code=1)

    # Preserve request order; in --all mode, drop unresolved entries silently.
    emit = [(out, resolved[out]) for out, _ in pairs if out in resolved]

    if json_output:
        typer.echo(json.dumps(dict(emit)))
    elif resolved_shell is not None:
        typer.echo(_set_mode_hint(resolved_shell))
        for out, value in emit:
            typer.echo(_format_set_line(resolved_shell, out, value))
    else:
        for _, value in emit:
            typer.echo(value)


if __name__ == "__main__":
    _app = typer.Typer(add_completion=False)
    _app.command()(resolve)
    _app()
