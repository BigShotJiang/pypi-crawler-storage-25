"""User configuration for pysae-ai-tools.

Config lives at ``~/.config/pysae-ai-tools/config.toml``. The file is created
with default values on first access so users can easily discover and edit it.
Unknown keys are ignored; missing keys fall back to defaults.
"""

import tomllib
from dataclasses import dataclass
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "pysae-ai-tools"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_CONFIG_CONTENT = """\
# Pysae AI tools — user configuration
#
# This file is created automatically on first run. Edit freely; unknown
# keys are ignored and missing keys fall back to defaults.

# Automatically install updates when a newer version is detected.
# When false, a notification is shown instead and you update manually
# with `pysae-ai-tools self-update`.
auto_update = true
"""


@dataclass(frozen=True)
class Config:
    auto_update: bool = True


def _ensure_default_file() -> None:
    """Create the config file with default content if it does not yet exist."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.exists():
            CONFIG_FILE.write_text(DEFAULT_CONFIG_CONTENT, encoding="utf-8")
    except OSError:
        pass


def load_config(path: Path | None = None) -> Config:
    """Load the user config, creating the default file on first access.

    Args:
        path: Override the default config path (used by tests).
    """
    target = path if path is not None else CONFIG_FILE
    if path is None:
        _ensure_default_file()

    try:
        with target.open("rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return Config()

    return Config(auto_update=bool(data.get("auto_update", True)))
