"""Automatic version check + self-update with 1-hour TTL cache.

Checks if a newer version is available on PyPI (remote install) or if
``origin/main`` has new commits (git clone install). When an update is
detected and ``auto_update`` is enabled in the user config, runs
``pysae-ai-tools self-update`` automatically. Otherwise, prints a yellow
notification inviting the user to update manually.

Skipped in CI, non-interactive (piped stderr), or when ``--json`` is in the
argv — so scripted usage is never disrupted.
"""

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

CACHE_DIR = Path.home() / ".cache" / "pysae-ai-tools"
CACHE_FILE = CACHE_DIR / "version-check.json"
LOCK_FILE = CACHE_DIR / "update.lock"
TTL_SECONDS = 3600  # 1 hour
LOCK_STALE_SECONDS = 600  # A self-update should never take >10 min.
PACKAGE = "pysae-ai-tools"

YELLOW = "\033[33m"
RESET = "\033[0m"


def _acquire_update_lock() -> bool:
    """Atomically acquire the update lock. Returns True on success.

    A stale lock (older than ``LOCK_STALE_SECONDS``) is force-removed to recover
    from crashed processes. The lock file holds the owner PID for debugging.
    """
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        return False

    try:
        if LOCK_FILE.exists():
            age = time.time() - LOCK_FILE.stat().st_mtime
            if age > LOCK_STALE_SECONDS:
                LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass

    try:
        fd = os.open(str(LOCK_FILE), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return False
    except OSError:
        return False

    try:
        os.write(fd, str(os.getpid()).encode())
    finally:
        os.close(fd)
    return True


def _release_update_lock() -> None:
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _load_cache() -> dict[str, object]:
    try:
        if CACHE_FILE.exists():
            data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_cache(data: dict[str, object]) -> None:
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _is_git_checkout() -> Path | None:
    """Return repo root if running from a git checkout, else None."""
    from pysae_ai_tools import __file__ as pkg_file

    pkg_dir = Path(pkg_file).resolve().parent
    candidate = pkg_dir.parent
    if (candidate / ".git").exists():
        return candidate
    return None


def _check_git_updates(repo: Path) -> str | None:
    """Check if origin/main has new commits. Returns a message or None."""
    try:
        subprocess.run(
            ["git", "-C", str(repo), "fetch", "--quiet", "origin", "main"],
            capture_output=True,
            timeout=10,
        )
        r = subprocess.run(
            ["git", "-C", str(repo), "rev-list", "--count", "HEAD..origin/main"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0:
            count = int(r.stdout.strip())
            if count > 0:
                return f"{count} new commit(s) available on origin/main"
    except (subprocess.TimeoutExpired, ValueError, OSError):
        pass
    return None


def _check_pypi_updates() -> str | None:
    """Check if a newer version is on PyPI. Returns a message or None."""
    try:
        from pysae_ai_tools import __version__

        if ".dev" in __version__:
            return None

        import httpx

        r = httpx.get(f"https://pypi.org/pypi/{PACKAGE}/json", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        latest = r.json().get("info", {}).get("version", "")
        if latest and latest != __version__:
            return f"Update available: {__version__} → {latest}"
    except Exception:  # noqa: BLE001
        pass
    return None


def _run_self_update() -> bool:
    """Invoke ``pysae-ai-tools self-update`` in a subprocess. Returns success."""
    exe = shutil.which("pysae-ai-tools")
    cmd = [exe, "self-update"] if exe else [sys.executable, "-m", "pysae_ai_tools", "self-update"]
    try:
        return subprocess.run(cmd, timeout=180).returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def _print_notification(message: str) -> None:
    print(f"{YELLOW}  {message}{RESET}", file=sys.stderr)
    print(f"{YELLOW}  Run: pysae-ai-tools self-update{RESET}", file=sys.stderr)


def _should_skip() -> bool:
    """Return True if the check should be silently skipped for this invocation."""
    # Avoid recursion when the user (or we) just ran self-update.
    if len(sys.argv) > 1 and sys.argv[1] == "self-update":
        return True

    # Respect force override for tests / debugging.
    if os.environ.get("PYSAE_FORCE_VERSION_CHECK"):
        return False

    # Skip in CI, non-interactive stderr, or JSON-output mode.
    if os.environ.get("CI"):
        return True
    if not sys.stderr.isatty():
        return True
    if "--json" in sys.argv:
        return True
    return False


def maybe_check_version() -> None:
    """Run version check (and auto-update if enabled). Cached for 1 hour."""
    if _should_skip():
        return

    # Make the config file discoverable on first interactive use, even when
    # no update is available. Skip paths (CI, --json, …) leave $HOME untouched.
    from pysae_ai_tools.config import _ensure_default_file

    _ensure_default_file()

    cache = _load_cache()
    last_check = cache.get("last_check", 0)
    if isinstance(last_check, (int, float)) and time.time() - last_check < TTL_SECONDS:
        msg = cache.get("message")
        if msg and isinstance(msg, str):
            _print_notification(msg)
        return

    repo = _is_git_checkout()
    message = _check_git_updates(repo) if repo else _check_pypi_updates()

    _save_cache({"last_check": time.time(), "message": message or ""})

    if not message:
        return

    from pysae_ai_tools.config import CONFIG_FILE, load_config

    config = load_config()

    if not config.auto_update:
        _print_notification(message)
        return

    # Serialize concurrent updates: only one process may run self-update.
    if not _acquire_update_lock():
        # Another instance is already updating — stay silent.
        return

    try:
        print(f"{YELLOW}  {message}{RESET}", file=sys.stderr)
        print(
            f"{YELLOW}  Auto-updating… " f"(disable with auto_update = false in {CONFIG_FILE}){RESET}",
            file=sys.stderr,
        )

        if _run_self_update():
            # Clear the cached message so subsequent invocations stay silent.
            _save_cache({"last_check": time.time(), "message": ""})
        else:
            print(
                f"{YELLOW}  Auto-update failed — run 'pysae-ai-tools self-update' manually{RESET}",
                file=sys.stderr,
            )
    finally:
        _release_update_lock()
