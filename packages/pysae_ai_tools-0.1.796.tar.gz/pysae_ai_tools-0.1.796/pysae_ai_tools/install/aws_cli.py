"""Install or update AWS CLI v2."""

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import httpx
import typer

from .common import binary, platform
from .common.base import BinaryTool, InstallReport
from .common.download import download, extract


class AwsCliTool(BinaryTool):
    name = "aws-cli"
    binary_name = "aws"
    cli_help = "Install/update the AWS CLI and configure SSO profiles"

    def fetch_latest_version(self) -> str:
        r = httpx.get("https://api.github.com/repos/aws/aws-cli/tags?per_page=1", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and data:
            name = data[0].get("name", "")
            return str(name) if isinstance(name, str) else ""
        return ""

    def check_auth(self) -> dict[str, Any] | None:
        if not binary.which(self.binary_name):
            return {"auth_ok": False, "auth_message": "aws not installed", "profiles": []}
        r = subprocess.run(
            [self.binary_name, "sts", "get-caller-identity"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        profiles_r = subprocess.run(
            [self.binary_name, "configure", "list-profiles"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        profiles = [line.strip() for line in profiles_r.stdout.splitlines() if line.strip()]
        return {
            "auth_ok": r.returncode == 0,
            "auth_message": (r.stdout + r.stderr).strip(),
            "profiles": profiles,
        }

    def install_binary(self) -> InstallReport:
        try:
            plat = platform.detect()
        except ValueError as exc:
            return InstallReport(error=str(exc))

        with tempfile.TemporaryDirectory(prefix="pysae-aws-") as tmp_dir:
            tmp = Path(tmp_dir)
            try:
                if plat.is_linux:
                    path, err = self._install_linux(plat.arch.value, tmp)
                elif plat.is_macos:
                    path, err = self._install_macos(tmp)
                elif plat.is_windows:
                    path, err = self._install_windows(tmp)
                else:
                    return InstallReport(error=f"unsupported OS: {plat.os}")
            except Exception as exc:  # noqa: BLE001
                return InstallReport(error=f"install failed: {exc}")

        if err:
            return InstallReport(error=err)

        if sys.platform != "win32":
            shutil.which(self.binary_name)
        installed_v = binary.get_version(self.binary_name, version_arg="--version")
        return InstallReport(version=installed_v, path=path)

    def _install_linux(self, arch: str, tmp: Path) -> tuple[str, str]:
        arch_token = "x86_64" if arch == "x86_64" else "aarch64"
        url = f"https://awscli.amazonaws.com/awscli-exe-linux-{arch_token}.zip"
        archive = tmp / "awscliv2.zip"
        download(url, archive)
        extract(archive, tmp / "awscli")
        installer = tmp / "awscli" / "aws" / "install"
        installer.chmod(0o755)
        cmd_update = ["sudo", str(installer), "--update"]
        r = subprocess.run(cmd_update, capture_output=True, text=True, check=False)
        if r.returncode != 0:
            r = subprocess.run(["sudo", str(installer)], capture_output=True, text=True, check=False)
        if r.returncode != 0:
            return "", r.stderr.strip() or r.stdout.strip()
        return binary.which(self.binary_name) or "/usr/local/bin/aws", ""

    def _install_macos(self, tmp: Path) -> tuple[str, str]:
        pkg = tmp / "AWSCLIV2.pkg"
        download("https://awscli.amazonaws.com/AWSCLIV2.pkg", pkg)
        r = subprocess.run(
            ["sudo", "installer", "-pkg", str(pkg), "-target", "/"],
            capture_output=True,
            text=True,
            check=False,
        )
        if r.returncode != 0:
            return "", r.stderr.strip() or r.stdout.strip()
        return binary.which(self.binary_name) or "/usr/local/bin/aws", ""

    def _install_windows(self, tmp: Path) -> tuple[str, str]:
        msi = tmp / "AWSCLIV2.msi"
        download("https://awscli.amazonaws.com/AWSCLIV2.msi", msi)
        r = subprocess.run(
            ["msiexec", "/i", str(msi), "/qn", "/norestart"],
            capture_output=True,
            text=True,
            check=False,
        )
        if r.returncode != 0:
            return "", f"msiexec exited {r.returncode}: {r.stderr.strip() or r.stdout.strip()}"
        default = Path(os.environ.get("ProgramFiles", r"C:\\Program Files")) / "Amazon" / "AWSCLIV2" / "aws.exe"
        return binary.which(self.binary_name) or str(default), ""

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        lines: list[tuple[str, str | None]] = []
        msg = str(state.get("auth_message", ""))
        m = re.search(r'"Arn":\s*"arn:aws:iam::(\d+):user/([^"]+)"', msg)
        if m:
            lines.append((f"{m.group(2)} (account {m.group(1)})", typer.colors.BRIGHT_BLACK))
        for p in state.get("profiles", []):
            lines.append((f"  profile: {p}", typer.colors.BRIGHT_BLACK))
        return lines


_tool = AwsCliTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
