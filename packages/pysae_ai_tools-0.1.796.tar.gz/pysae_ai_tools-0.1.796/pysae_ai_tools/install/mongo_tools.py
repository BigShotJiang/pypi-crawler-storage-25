"""Install or update mongosh + MongoDB Database Tools.

Strategy:
- mongosh: npm global install (works on Linux, macOS, Windows when Node is available).
- Database Tools: download the platform-specific archive from fastdl.mongodb.org.

This avoids OS-specific package managers (apt/brew) so the same code path works on
every supported platform. Users who prefer `brew` or APT can still use those manually.
"""

import shutil
import subprocess
import tempfile
from pathlib import Path

import httpx
import typer

from .common import binary, platform
from .common.base import BaseTool, InstallReport, ToolState
from .common.download import download, extract, install_binary

MONGOSH_BIN = "mongosh"
DBTOOLS_BIN = "mongodump"  # representative binary
DBTOOLS_ALL = (
    "mongodump",
    "mongorestore",
    "mongoimport",
    "mongoexport",
    "mongostat",
    "mongotop",
    "bsondump",
    "mongofiles",
)
TOOLS_RELEASES_API = "https://api.github.com/repos/mongodb/mongo-tools/releases/latest"


def _arch_token(plat: platform.Platform) -> str:
    return "x86_64" if plat.arch.value == "x86_64" else "arm64"


def _distro_token(plat: platform.Platform) -> str:
    """MongoDB tools archives are keyed by distro. Pick a sensible default per OS."""
    if plat.is_linux:
        return "ubuntu2404"
    if plat.is_macos:
        return "macos"
    if plat.is_windows:
        return "windows"
    return "ubuntu2404"


def latest_tools_version(timeout: float = 5.0) -> str:
    r = httpx.get(TOOLS_RELEASES_API, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    data = r.json()
    tag = data.get("tag_name", "")
    if not isinstance(tag, str):
        return ""
    return tag.lstrip("v")


def tools_archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Return (url, archive extension)."""
    distro = _distro_token(plat)
    arch = _arch_token(plat)
    if plat.is_windows:
        return (
            f"https://fastdl.mongodb.org/tools/db/mongodb-database-tools-{distro}-{arch}-{version}.zip",
            "zip",
        )
    return (
        f"https://fastdl.mongodb.org/tools/db/mongodb-database-tools-{distro}-{arch}-{version}.tgz",
        "tgz",
    )


def _install_mongosh() -> tuple[str, str]:
    """Return (method, error)."""
    if binary.which(MONGOSH_BIN):
        return "already-installed", ""
    if not shutil.which("npm"):
        return "", "npm not available; install Node.js first or use `brew install mongosh` on macOS"
    r = subprocess.run(["npm", "install", "-g", "mongosh"], capture_output=True, text=True, check=False)
    if r.returncode != 0:
        return "", f"npm install failed: {r.stderr.strip() or r.stdout.strip()}"
    return "npm", ""


def _install_dbtools(plat: platform.Platform) -> tuple[str, str]:
    """Return (installed_version, error)."""
    try:
        version = latest_tools_version()
    except Exception as exc:  # noqa: BLE001
        return "", f"could not fetch tools version: {exc}"

    url, ext = tools_archive_url(version, plat)

    with tempfile.TemporaryDirectory(prefix="pysae-mongo-tools-") as tmp_dir:
        tmp = Path(tmp_dir)
        archive = tmp / f"tools.{ext}"
        try:
            download(url, archive)
        except Exception as exc:  # noqa: BLE001
            return "", f"download failed for {url}: {exc}"
        extract_dir = tmp / "extracted"
        try:
            extract(archive, extract_dir)
        except Exception as exc:  # noqa: BLE001
            return "", f"extract failed: {exc}"

        # Find each binary in the extracted bin/ folder and install it
        bin_suffix = ".exe" if plat.is_windows else ""
        for tool in DBTOOLS_ALL:
            tool_name = f"{tool}{bin_suffix}"
            matches = list(extract_dir.rglob(tool_name))
            if not matches:
                continue
            try:
                install_binary(matches[0], tool)
            except Exception as exc:  # noqa: BLE001
                return "", f"install {tool} failed: {exc}"

    return version, ""


class MongoToolsTool(BaseTool):
    name = "mongo-tools"
    cli_help = "Install/update MongoDB CLI tools (mongosh, mongodump, ...)"

    def get_state(self) -> ToolState:
        mongosh = binary.status(MONGOSH_BIN, version_arg="--version")
        dbtools = binary.status(DBTOOLS_BIN, version_arg="--version")
        try:
            latest = latest_tools_version()
        except Exception:  # noqa: BLE001
            latest = ""

        needs_install_mongosh = not mongosh.installed
        needs_install_dbtools = not dbtools.installed
        needs_update_dbtools = dbtools.installed and bool(latest) and binary.needs_update(dbtools.version, latest)

        return ToolState(
            needs_install=needs_install_mongosh or needs_install_dbtools,
            needs_update=needs_update_dbtools,
            extra={
                "mongosh": mongosh.to_dict(),
                "dbtools": dbtools.to_dict(),
                "latest_tools": latest,
            },
        )

    def do_install(self) -> InstallReport:
        try:
            plat = platform.detect()
        except ValueError as exc:
            return InstallReport(error=str(exc))

        method, err1 = _install_mongosh()
        version, err2 = _install_dbtools(plat)
        if err1 and err2:
            return InstallReport(error=f"mongosh: {err1}; dbtools: {err2}")
        if err2:
            return InstallReport(
                extra={"mongosh_method": method},
                error=f"dbtools: {err2}",
            )
        if err1:
            return InstallReport(
                version=version,
                extra={"mongosh_error": err1, "dbtools_version": version},
                error=f"mongosh: {err1}",
            )
        return InstallReport(
            version=version,
            extra={"mongosh_method": method, "dbtools_version": version},
        )

    def format_check(self, state: ToolState) -> None:
        d = state.to_dict()
        mongosh = d.get("mongosh", {})
        dbtools = d.get("dbtools", {})
        latest = d.get("latest_tools", "n/a")
        mongosh_version = mongosh.get("version", "") if isinstance(mongosh, dict) else ""
        dbtools_version = dbtools.get("version", "") if isinstance(dbtools, dict) else ""
        typer.echo(f"mongosh: {mongosh_version or 'NOT installed'}")
        typer.echo(f"mongodump: {dbtools_version or 'NOT installed'} (latest tools {latest})")

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
        else:
            method = report.extra.get("mongosh_method", "")
            version = report.extra.get("dbtools_version", "")
            typer.echo(f"installed mongosh ({method}) and tools v{version}")


_tool = MongoToolsTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
