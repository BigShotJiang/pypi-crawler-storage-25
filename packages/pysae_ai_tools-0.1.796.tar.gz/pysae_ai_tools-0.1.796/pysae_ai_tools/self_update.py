"""Self-update pysae-ai-tools.

Two modes:
- **Git clone** (editable install): ``git pull`` + re-run ``install.sh``
- **PyPI install** (via uv): ``uv tool upgrade pysae-ai-tools``
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import typer

import pysae_ai_tools

PACKAGE = "pysae-ai-tools"


def _repo_root() -> Path | None:
    """Return the repo root if running from a git checkout, else None."""
    pkg_dir = Path(pysae_ai_tools.__file__).resolve().parent
    candidate = pkg_dir.parent
    if (candidate / ".git").exists() and (candidate / "install.sh").exists():
        return candidate
    return None


def _run(cmd: list[str], cwd: Path | None = None) -> int:
    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    return subprocess.run(cmd, cwd=cwd).returncode


def _update_from_git(repo: Path, no_pull: bool, rebase: bool) -> None:
    """Update from git clone: pull + reinstall."""
    if not no_pull:
        pull_args = ["git", "-C", str(repo), "pull"]
        pull_args.append("--rebase" if rebase else "--ff-only")
        if _run(pull_args) != 0:
            print("FAILED: git pull failed. Resolve manually and retry.", file=sys.stderr)
            sys.exit(1)

    is_windows = os.name == "nt"
    ps1 = repo / "install.ps1"
    sh = repo / "install.sh"

    if is_windows and ps1.exists():
        rc = _run(["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ps1)])
    elif sh.exists():
        rc = _run(["bash", str(sh)])
    else:
        print(f"FAILED: no installer found in {repo}", file=sys.stderr)
        sys.exit(1)

    if rc != 0:
        print("FAILED: installer exited with errors.", file=sys.stderr)
        sys.exit(rc)


def _update_from_pypi() -> None:
    """Update from PyPI via uv tool upgrade."""
    print("Updating from PyPI...", file=sys.stderr)
    rc = _run(["uv", "tool", "upgrade", PACKAGE])
    if rc != 0:
        print("FAILED: uv tool upgrade failed.", file=sys.stderr)
        sys.exit(rc)

    # Reinstall Claude Code plugin with the new version
    print("Updating Claude Code plugin...", file=sys.stderr)
    _run(["pysae-ai-tools", "claude-plugin", "install"])

    # Update shell completion
    from .install_completion import install_completion

    install_completion()


def main(
    no_pull: Annotated[bool, typer.Option("--no-pull", help="Skip git pull (only re-run installer)")] = False,
    rebase: Annotated[bool, typer.Option("--rebase", help="Use 'git pull --rebase' instead of '--ff-only'")] = False,
) -> None:
    """Update pysae-ai-tools to the latest version."""
    repo = _repo_root()

    if repo:
        print(f"Git checkout detected at {repo}", file=sys.stderr)
        _update_from_git(repo, no_pull, rebase)
    else:
        _update_from_pypi()

    print("\npysae-ai-tools is up to date.", file=sys.stderr)
