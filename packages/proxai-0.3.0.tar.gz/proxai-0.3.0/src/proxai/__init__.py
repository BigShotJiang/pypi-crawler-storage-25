# read version from installed package
from importlib.metadata import version

from proxai.chat import Chat
from proxai.chat import Message
from proxai.chat import MessageContent
from proxai.client import FileConnector
from proxai.client import ModelConnector
from proxai.proxai import (
    CacheOptions,
    Chat,
    Client,
    ConnectionOptions,
    DefaultFilesConnector,
    DefaultModelsConnector,
    FeatureMappingStrategy,
    LoggingOptions,
    Message,
    ParameterType,
    ProviderModelType,
    MessageRoleType,
    ContentType,
    ProxDashOptions,
    OutputFormat,
    OutputFormatType,
    ThinkingType,
    Tools,
    connect,
    generate,
    generate_audio,
    generate_image,
    generate_json,
    generate_pydantic,
    generate_text,
    generate_video,
    get_current_options,
    get_default_proxai_client,
    reset_state,
    set_model,
)
from proxai.types import (
    DebugOptions,
    FeatureTag,
    InputFormatType,
    MessageRoleType,
    ModelProbeOptions,
    OutputFormatType,
    ProviderCallOptions,
    ToolTag,
)

__all__ = [
    "CacheOptions",
    "Chat",
    "Client",
    "ConnectionOptions",
    "DebugOptions",
    "DefaultFilesConnector",
    "DefaultModelsConnector",
    "FeatureMappingStrategy",
    "FileConnector",
    "files",
    "FeatureTag",
    "InputFormatType",
    "LoggingOptions",
    "ModelProbeOptions",
    "ParameterType",
    "Tools",
    "Message",
    "MessageContent",
    "MessageRoleType",
    "ModelConnector",
    "MessageRoleType",
    "ContentType",
    "OutputFormat",
    "OutputFormatType",
    "ThinkingType",
    "ProxDashOptions",
    "ProviderCallOptions",
    "ProviderModelType",
    "ToolTag",
    "connect",
    "generate",
    "generate_audio",
    "generate_image",
    "generate_json",
    "generate_pydantic",
    "generate_text",
    "generate_video",
    "get_current_options",
    "get_default_proxai_client",
    "models",
    "reset_state",
    "set_model",
]

__version__ = version("proxai")
files = DefaultFilesConnector()
models = DefaultModelsConnector()
