import json
from array import array
from datetime import datetime, timedelta
from logging import NullHandler
from sre_parse import FAILURE
from urllib import parse

import requests
from bs4 import BeautifulSoup


class FreegalMusic:
    def __init__(
        self,
        library_domain: str,
        library_id=None,
        token=None,
        username=None,
        password=None,
    ):
        self.library_domain = library_domain
        self.library_id = library_id
        self.library_name = None

        self.token = token
        self.token_valid_until = None
        self.refresh_token = None
        self.authentication_token = None

        self.username = username
        self.password = password

        self.limit_downloads = None
        self.limit_streaming = None
        self.remaining_downloads = None
        self.remaining_streaming = None

        self.root = "https://api.freegalmusic.com/v1/"
        self._session = requests.Session()

    def _call(self, method, url, params=None, payload=None):
        """Make a call to the API"""
        if not url.startswith("http"):
            url = self.root + url

        self.check_generate_token()

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Origin": self.library_domain,
            "Referer": self.library_domain,
            "Accept": "application/json, text/plain, */*",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:149.0) Gecko/20100101 Firefox/149.0",
        }

        if self.authentication_token:
            headers["authenticationtoken"] = self.authentication_token

        method = method.upper()
        if method == "GET":
            r = self._session.get(url, params=params, headers=headers)
        elif method == "POST":
            r = self._session.post(url, params=params, json=payload, headers=headers)
        elif method == "PUT":
            r = self._session.put(url, params=params, json=payload, headers=headers)
        elif method == "DELETE":
            r = self._session.delete(url, params=params, headers=headers)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")

        r.raise_for_status()
        r_json = r.json()

        if not r_json["success"]:
            raise RuntimeError(f"Request returned failue, response: {r_json}")

        return r_json

    def _get(self, url):
        return self._call("GET", url)

    def _post(self, url, payload=None):
        return self._call("POST", url, payload=payload)

    def _delete(self, url, payload=None):
        return self._call("DELETE", url, payload=payload)

    def _put(self, url, payload=None):
        return self._call("PUT", url, payload=payload)

    def token_is_valid(self):
        return (
            datetime.now() <= self.token_valid_until
            if self.token_valid_until is not None
            else False
        )

    def check_generate_token(self):
        if not self.token:
            self.generate_token()

        if not self.token_is_valid():
            print("TODO! Refresh token")

    def generate_token(self):
        """Extracts initial authToken from HTML"""
        resp = requests.get(self.library_domain)
        soup = BeautifulSoup(resp.text, "html.parser")

        auth_input = soup.find("input", {"id": "authToken"})
        if not auth_input:
            raise ValueError("authToken input not found in HTML")

        token_data = json.loads(auth_input["value"])

        self.token = token_data["accessToken"]
        self.refresh_token = token_data.get("refreshToken")
        self.token_valid_until = datetime.now() + timedelta(
            seconds=token_data["expiresIn"]
        )

    def login(self):
        """Login using username and password"""
        payload = {
            "identifier1": self.username,
            "identifier2": self.password,
            "libraryId": self.library_id,
        }
        response = self._post("login", payload=payload)
        self.authentication_token = response["data"]["authenticationToken"]

    def get_library(self):
        pass

    def get_account(self) -> dict:
        """Get Account information"""
        response = self._get("user/details")
        items = response["data"]["items"]
        library = items["library"]

        self.library_id = library["libraryId"]
        self.library_name = library["libraryName"]
        self.username = items["patronId"]
        self.limit_downloads = items["downloadLimit"]
        self.limit_streaming = items["streamingTimeLimit"]
        self.remaining_downloads = items["availabledownload"]
        self.remaining_streaming = items["streamingTimeRemaining"]

        return {
            "library_id": self.library_id,
            "library_name": self.library_name,
            "username": self.username,
            "limit_downloads": self.limit_downloads,
            "limit_streaming": self.limit_streaming,
            "remaining_downloads": self.remaining_downloads,
            "remaining_streaming": self.remaining_streaming,
        }

    def get_wishlist(self) -> list:
        """Get the user's wishlist"""
        response = self._get("user/wishlist")
        long_wishlist = response["data"]["wishlist"]

        wishlist = []

        for song in long_wishlist:
            wishlist.append(song["songId"])

        return wishlist

    def search(
        self, query: str, type="song", offset=0, limit=10, sort_order="DESC"
    ) -> dict:
        """Search something
        Args:
            query (str): the search query/keyword
            type (str, optional): the type of your search query. options:
                "song" (default), "artist", "album", "playlist", "audiobook"
            offset (int): the offset of your results for pagination
            limit (int): maximum number of results (-> pagination)
            sort_order(str): how to sort the resulst. Defaults to "DESC"
        """
        if type in ["song", "artist", "album", "playlist", "audiobook"]:
            response = self._get(
                f"search?q={query}&type={type}&offset={offset}&limit={limit}&sortOrder={sort_order}"
            )
        else:
            raise ValueError("wrong type!")

        return response["data"]

    def get_song(self):
        print("TODO!")
        pass

    def get_artist(self, artist_id: str) -> dict:
        """Get an artist"""
        response = self._get(f"artist?artist={artist_id}")
        return response["data"]["artist"]

    def get_artist_albums(
        self, artist_id: str, offset=0, limit=10, sort_order="DESC", sort_by="sortId"
    ) -> dict:
        """Get similar albums"""
        response = self._get(
            f"artist/albums?artist={artist_id}&offset={offset}&limit={limit}&sortOrder={sort_order}&sortBy={sort_by}"
        )
        return response["data"]["albums"]["items"]

    def get_artist_similar(
        self, artist_id: str, offset=0, limit=20, sort_order="DESC", sort_by="sortId"
    ) -> dict:
        """Get similar artists"""
        response = self._get(
            f"artists/similar?artist={artist_id}&offset={offset}&limit={limit}&sortOrder={sort_order}&sortBy={sort_by}&customLimit={limit}"
        )
        return response["data"]["artists"]

    def get_album(self, album_id: str, provider="1") -> dict:
        """Get an album"""
        response = self._get(f"songs?albumId={album_id}&provider={provider}")
        return response["data"]["album"]["items"][0]

    def get_album_similar(self, album_id: str, provider=1, offset=0, limit=20):
        """Get similar albums"""
        response = self._get(
            f"albums/similar?albumId={album_id}&offset={offset}&limit={limit}&customLimit={limit}"
        )
        return response["data"]["albums"]

    def download(
        self, song_id: str, provider: int = 1, filename: str = "", redownload=False
    ) -> str:
        """Download a song"""
        payload = {"songId": song_id, "provider": provider}

        if redownload:
            response = self._post("redownload/song", payload=payload)
        else:
            response = self._post("downloads/song", payload=payload)

        download_url_encoded = response["data"]["downloadUrl"]
        download_url = parse.unquote(download_url_encoded)
        if not filename:
            filename = f"{song_id}.mp3"
        r = self._session.get(download_url)
        r.raise_for_status()
        with open(filename, "wb") as f:
            f.write(r.content)
        print(
            f"Erfolgreich: {filename} (verbleibend: {response['data'].get('remainingDownloads', 'N/A')})"
        )
        return filename
        pass
