# Freegal

[Freegal Music](https://freegalmusic.com/) is a free, legal music streaming and
download service available through many public libraries.

This library maps the Freegal api into a python library.
