# aisolate-agent

AI Agent with intelligent planning and reasoning

## Local Installation

```bash
pip install path/to/aisolate_agent-0.2.0-py3-none-any.whl
```

## Usage

```python
# Import the main module
import aisolate.agent

# Use the package...
```

## Requirements

- Python 3.10+

## License

Apache License 2.0
