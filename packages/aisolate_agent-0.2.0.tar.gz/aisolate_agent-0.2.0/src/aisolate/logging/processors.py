"""Structlog processor chain building blocks.

Exported so hosts can compose their own structlog configuration using
aisolate's recommended defaults, or extend the chain with additional
processors (PII redaction, tenant context, etc.).

Nothing in this module has import-time side effects.
"""

from typing import Any, Callable, List

import structlog


def add_otel_context(
    logger: Any, method_name: str, event_dict: dict
) -> dict:
    """Attach current trace_id / span_id to every log record.

    Reads the active span from the global OTEL context. Only catches
    ImportError so observability bugs surface instead of being silently
    swallowed.
    """
    try:
        from opentelemetry import trace
    except ImportError:
        return event_dict
    span = trace.get_current_span()
    ctx = span.get_span_context() if span else None
    if ctx and ctx.trace_id:
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"] = format(ctx.span_id, "016x")
    return event_dict


def default_processor_chain() -> List[Callable]:
    """Return aisolate's recommended structlog processor chain.

    Produces an event_dict with contextvars merged, logger name and level,
    ISO timestamp, OTEL trace/span IDs when a span is active, unicode-decoded
    strings, and rendered stack info when present. Terminates with
    ``wrap_for_formatter`` so records hand off to stdlib logging for final
    rendering by a ``ProcessorFormatter`` (see
    :mod:`aisolate.logging.formatters`).
    """
    return [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
        add_otel_context,
        structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
    ]


def foreign_pre_chain() -> List[Callable]:
    """Processor chain for records emitted by non-structlog loggers.

    Django, arq, httpx, openai etc. log via stdlib ``logging.Logger``. When
    those records reach a ``ProcessorFormatter``, this pre-chain normalizes
    them into structlog-shaped event_dicts so the final renderer produces
    consistent output regardless of source.

    Excludes ``filter_by_level`` / ``add_log_level`` / ``add_logger_name``
    because stdlib has already populated the equivalent LogRecord fields
    before ``ProcessorFormatter`` is invoked. Also excludes
    ``wrap_for_formatter`` — foreign records are not structlog-wrapped.
    """
    return [
        structlog.contextvars.merge_contextvars,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
        add_otel_context,
    ]


__all__ = [
    "add_otel_context",
    "default_processor_chain",
    "foreign_pre_chain",
]
