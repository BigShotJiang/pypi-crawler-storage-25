"""Structlog formatters for stdlib ``logging.dictConfig``.

Zero-arg callables usable directly from a host's logging config::

    LOGGING = {
        'formatters': {
            'structlog_console': {
                '()': 'aisolate.logging.formatters.make_console_formatter',
            },
            'structlog_json': {
                '()': 'aisolate.logging.formatters.make_json_formatter',
            },
        },
        ...
    }

Both return a ``structlog.stdlib.ProcessorFormatter`` whose
``foreign_pre_chain`` also processes records from non-structlog loggers
(Django, arq, httpx, openai), so every line has a consistent shape.
"""

import structlog

from .processors import foreign_pre_chain


def make_console_formatter() -> structlog.stdlib.ProcessorFormatter:
    """Return a colorized key=value formatter for interactive terminals."""
    return structlog.stdlib.ProcessorFormatter(
        processor=structlog.dev.ConsoleRenderer(colors=True),
        foreign_pre_chain=foreign_pre_chain(),
    )


def make_json_formatter() -> structlog.stdlib.ProcessorFormatter:
    """Return a JSON-per-line formatter for production / log shippers."""
    return structlog.stdlib.ProcessorFormatter(
        processor=structlog.processors.JSONRenderer(),
        foreign_pre_chain=foreign_pre_chain(),
    )


__all__ = [
    "make_console_formatter",
    "make_json_formatter",
]
