"""Public logging API for hosts embedding aisolate.

Hosts compose these primitives into their own logging config (Django
``LOGGING`` dict, FastAPI startup, pytest fixtures, etc.). Nothing in
this package has import-time side effects. The only mutating function
is :func:`setup_standalone`, for CLI / test / script use.

Typical Django host usage::

    from aisolate.logging import recommended_levels

    LOGGING = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'structlog_console': {
                '()': 'aisolate.logging.formatters.make_console_formatter',
            },
            'structlog_json': {
                '()': 'aisolate.logging.formatters.make_json_formatter',
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'structlog_json' if PROD else 'structlog_console',
            },
        },
        'loggers': {
            '': {
                'handlers': ['console'],
                'level': 'WARNING',
                'propagate': False,
            },
            'django': {'level': 'INFO', 'propagate': True},
            'arq':    {'level': 'INFO', 'propagate': True},
            **recommended_levels(),
        },
    }

Typical standalone script usage::

    from aisolate.logging import setup_standalone
    setup_standalone(level="INFO", log_format="console")
"""

import logging
import sys
from typing import Dict

import structlog

from .formatters import make_console_formatter, make_json_formatter
from .processors import (
    add_otel_context,
    default_processor_chain,
    foreign_pre_chain,
)


def recommended_levels() -> Dict[str, Dict[str, object]]:
    """Return recommended log levels for the ``aisolate.*`` hierarchy.

    Hosts merge the result into their ``LOGGING['loggers']`` block. Every
    entry uses ``propagate=True`` with no ``handlers`` key, so records
    route up to the host's single root handler. Individual entries can
    be overridden by writing them explicitly *after* the merge.
    """
    return {
        "aisolate": {"level": "INFO", "propagate": True},
        "aisolate.agent": {"level": "INFO", "propagate": True},
        "aisolate.agent.core": {"level": "INFO", "propagate": True},
        "aisolate.agent.states": {"level": "INFO", "propagate": True},
        "aisolate.agent.tools": {"level": "INFO", "propagate": True},
        "aisolate.agent.strategies": {"level": "INFO", "propagate": True},
        "aisolate.sandbox": {"level": "INFO", "propagate": True},
        "aisolate.gateway": {"level": "INFO", "propagate": True},
        "aisolate.chat": {"level": "INFO", "propagate": True},
    }


def setup_standalone(
    level: str = "INFO",
    log_format: str = "console",
) -> None:
    """Configure logging for standalone aisolate use (CLIs, tests, scripts).

    Only call this from code that owns the process. In a host web app
    (Django, FastAPI) the host's logging config should be used instead —
    this function short-circuits when the root logger already has handlers
    so an accidental call inside a host does not clobber it.

    Args:
        level: Minimum log level for the root logger.
        log_format: ``"console"`` for colorized key=value output, ``"json"``
            for one JSON object per line.
    """
    root = logging.getLogger()
    if root.handlers:
        return

    structlog.configure(
        processors=default_processor_chain(),
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    handler = logging.StreamHandler(sys.stdout)
    if log_format == "json":
        handler.setFormatter(make_json_formatter())
    else:
        handler.setFormatter(make_console_formatter())

    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))


__all__ = [
    "add_otel_context",
    "default_processor_chain",
    "foreign_pre_chain",
    "make_console_formatter",
    "make_json_formatter",
    "recommended_levels",
    "setup_standalone",
]
