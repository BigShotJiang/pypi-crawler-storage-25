from dataclasses import dataclass, field
from typing import Any, Dict, List, Union


@dataclass(frozen=True)
class StreamOutput:
    """Represents text output to standard streams (stdout, stderr)."""

    name: str  # The name of the stream, e.g., 'stdout' or 'stderr'
    text: str  # The text content of the stream output


@dataclass(frozen=True)
class ExecuteResult:
    """Represents the result of a cell execution."""

    execution_count: int
    # Data is a mime-bundle. Binary data (e.g., images) will be bytes,
    # text data will be strings.
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DisplayData:
    """Represents rich data generated during execution (e.g., plots)."""

    # Data is a mime-bundle, similar to ExecuteResult.
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ErrorOutput:
    """Represents an error that occurred during code execution."""

    error_name: str
    error_value: str
    traceback: List[str]


@dataclass(frozen=True)
class KernelBusy:
    """A marker class indicating the kernel is busy executing code."""

    pass


@dataclass(frozen=True)
class KernelIdle:
    """A marker class indicating the kernel has finished execution and is idle."""

    pass


@dataclass(frozen=True)
class KernelExecutionCompleted:
    """A marker class indicating the kernel has completed execution."""

    pass


KernelMessage = Union[
    StreamOutput,
    ExecuteResult,
    DisplayData,
    ErrorOutput,
    KernelBusy,
    KernelIdle,
    KernelExecutionCompleted,
]

# A map used by the decoder to find the correct dataclass constructor.
MESSAGE_TYPE_MAP: Dict[str, type[KernelMessage]] = {
    cls.__name__: cls for cls in KernelMessage.__args__
}
