class CodecError(Exception):
    """Base class for all encoding/decoding errors in this library."""

    pass


class EncodingError(CodecError):
    """Raised when an object fails to be encoded."""

    pass


class DecodingError(CodecError):
    """Raised when a byte string fails to be decoded."""

    pass
