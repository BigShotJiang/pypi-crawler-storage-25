import base64
import logging
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, Tuple

import msgpack

from .models import (
    KernelMessage,
    StreamOutput,
    ExecuteResult,
    DisplayData,
    ErrorOutput,
    KernelBusy,
    KernelIdle,
    MESSAGE_TYPE_MAP,
)
from .errors import EncodingError, DecodingError


def _maybe_decode_binary_from_base64(mime: str, payload: Any) -> Any:
    """
    If the mime type suggests a binary format and the payload is a base64
    encoded string, this function decodes it into raw bytes. Otherwise,
    it returns the payload unchanged.
    """
    if mime.startswith(("image/", "video/", "audio/")) and isinstance(payload, str):
        try:
            return base64.b64decode(payload)
        except (ValueError, TypeError):
            logging.warning(f"Failed to base64-decode payload for mime type {mime}.")
    return payload


def jupyter_to_kernel_message(raw_jmsg: Dict[str, Any]) -> Optional[KernelMessage]:
    """
    Decodes a raw Jupyter message dictionary into a typed KernelMessage dataclass.
    This function is responsible for filtering out unnecessary data.

    Args:
        raw_jmsg: A dictionary representing a deserialized message from the
                  Jupyter Kernel Gateway.

    Returns:
        An instance of a KernelMessage dataclass, or None if the message
        is not essential for the frontend.
    """
    msg_type = raw_jmsg.get("msg_type")
    content = raw_jmsg.get("content", {})

    match msg_type:
        case "status":
            state = content.get("execution_state")
            if state == "busy":
                return KernelBusy()
            elif state == "idle":
                return KernelIdle()

        case "stream":
            return StreamOutput(name=content["name"], text=content["text"])

        case "execute_result":
            # Decode binary mime-types from base64 to raw bytes.
            decoded_bundle = {
                mime: _maybe_decode_binary_from_base64(mime, data)
                for mime, data in content["data"].items()
            }
            return ExecuteResult(
                execution_count=content["execution_count"], data=decoded_bundle
            )

        case "display_data":
            decoded_bundle = {
                mime: _maybe_decode_binary_from_base64(mime, data)
                for mime, data in content["data"].items()
            }
            return DisplayData(data=decoded_bundle)

        case "error":
            return ErrorOutput(
                error_name=content["ename"],
                error_value=content["evalue"],
                traceback=content["traceback"],
            )

        case "execute_input" | "execute_reply":
            # These message types are not needed by the frontend, so we ignore them.
            return None

        case _:
            logging.debug(f"Ignoring unhandled Jupyter message type: {msg_type}")
            return None
    return None


def encode_kernel_message(request_id: str, message: KernelMessage) -> bytes:
    """
    Encodes a KernelMessage dataclass into a msgpack byte string for transport.

    Args:
        message: An instance of a KernelMessage dataclass.

    Returns:
        A byte string representing the packed message.

    Raises:
        EncodingError: If the object is not a valid dataclass.
    """
    if not is_dataclass(message) or not isinstance(message, KernelMessage.__args__):
        raise EncodingError(
            f"Object of type '{type(message).__name__}' is not a valid KernelMessage."
        )

    wrapper = {
        "request_id": request_id,
        "type": message.__class__.__name__,
        "payload": asdict(message),
    }
    return msgpack.packb(wrapper, use_bin_type=True)


def decode_kernel_message(data: bytes) -> Tuple[str, KernelMessage]:
    """
    Decodes a msgpack byte string from the backend into a KernelMessage dataclass.

    Args:
        data: A msgpack byte string.

    Returns:
        An instance of a KernelMessage dataclass.

    Raises:
        DecodingError: If the data is malformed, has an unknown type, or
                       cannot be parsed.
    """
    try:
        wrapper = msgpack.unpackb(data, raw=False)
        type_name = wrapper.get("type")
        payload = wrapper.get("payload")
        request_id = wrapper.get("request_id")

        if not isinstance(type_name, str) or not isinstance(payload, dict):
            raise DecodingError(
                "Invalid message structure: missing 'type' or 'payload'."
            )

        dataclass_constructor = MESSAGE_TYPE_MAP.get(type_name)
        if dataclass_constructor:
            # Re-hydrate binary data that msgpack might have turned into strings.
            if "data" in payload and isinstance(payload["data"], dict):
                payload["data"] = {
                    k: _maybe_decode_binary_from_base64(k, v)
                    for k, v in payload["data"].items()
                }
            return request_id, dataclass_constructor(**payload)

        raise DecodingError(f"Received unknown message type: '{type_name}'")

    except (msgpack.exceptions.UnpackException, TypeError, ValueError) as e:
        logging.error(f"Failed to decode message: {e}")
        raise DecodingError("Message could not be unpacked or parsed.") from e
