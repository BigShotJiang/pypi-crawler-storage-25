import asyncio
import uuid
import random
import socket
import time
from typing import Dict, List
import msgpack
import pytest


from async_asgi_testclient import TestClient as AsyncTestClient


class WsAliasTestClient(AsyncTestClient):
    """`ws_connect()` alias for backwards-compatibility with old tests."""

    async def close(self):
        await self.__aexit__(None, None, None)


def _find_free_port(lo: int = 9100, hi: int = 9999) -> int:
    while True:
        port = random.randint(lo, hi)
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port


def _wait_tcp(host: str, port: int, timeout: float = 8.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.1)
    raise RuntimeError(f"nothing started listening on {host}:{port} in time")


async def collect(ws, timeout: float = 30.0) -> list[dict]:
    frames: list[dict] = []
    try:
        async with asyncio.timeout(timeout):
            async for raw in ws:
                if isinstance(raw, dict):
                    if "websocket.close" in [
                        raw.get("text", ""),
                        raw.get("type", ""),
                    ]:
                        break
                if isinstance(raw, dict) and "bytes" in raw:
                    frame = msgpack.unpackb(raw["bytes"], raw=False)
                    frames.append(frame)
                    if frame.get("type") == "KernelExecutionCompleted":
                        break
    except asyncio.TimeoutError:
        print(f"WARNING: collect() timed out after {timeout}s")
        # Return frames collected so far instead of failing completely

    if not frames:
        pytest.fail("no execute_result frame received")

    return frames


async def execute_code(
    client: AsyncTestClient,
    sandbox_id: str,
    code: str,
    language: str,
    timeout: float = 30.0,
) -> List[Dict]:
    """
    Executes code in a sandbox via websocket and returns the frames.

    Args:
        client: The test client to use for websocket connection
        sandbox_id: ID of the sandbox to execute code in
        code: The code to execute
        language: The language/kernel to use (e.g., 'python3', 'deno')
        timeout: Maximum time to wait for execution completion (default: 30s)

    Returns:
        List of message frames received during execution
    """
    websocket_cm = client.websocket_connect("/gateway/ws")
    websocket = None
    
    try:
        async with websocket_cm as websocket:
            await websocket.send_json(
                {
                    "request_id": str(uuid.uuid4()),
                    "sandbox_id": sandbox_id,
                    "type": "execute_request",
                    "payload": {"code": code, "language": language},
                }
            )
            frames = await collect(websocket, timeout=timeout)
            
            # Explicitly close the websocket to ensure proper cleanup
            if hasattr(websocket, 'close'):
                await websocket.close()
                
            return frames
            
    except Exception as e:
        # Ensure cleanup on any exception
        if websocket and hasattr(websocket, 'close'):
            try:
                await websocket.close()
            except:
                pass  # Ignore cleanup errors
        raise
    finally:
        # Additional cleanup to ensure resources are freed
        await asyncio.sleep(0.01)  # Allow any pending operations to complete
