import os
import importlib
import subprocess
from typing import AsyncGenerator, Generator
from urllib.parse import urlparse

import pytest
import pytest_asyncio
from async_asgi_testclient import TestClient as AsyncTestClient
from .utils import _find_free_port, _wait_tcp


class ASGIWebSocketAdapter:
    def __init__(self, raw_cm):
        self._raw_cm = raw_cm
        self._ws = None

    async def __aenter__(self):
        self._ws = await self._raw_cm.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return await self._raw_cm.__aexit__(exc_type, exc, tb)

    async def send(self, data: str):
        await self._ws.send_text(data)

    async def send_json(self, obj):
        await self._ws.send_json(obj)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            # Receive raw message first to check what type it is
            raw_msg = await self._ws._receive()

            # Handle different message types
            if raw_msg.get("type") == "websocket.disconnect":
                raise StopAsyncIteration
            elif raw_msg.get("type") == "websocket.send":
                # Return text if available, otherwise bytes
                if "text" in raw_msg:
                    return raw_msg["text"]
                elif "bytes" in raw_msg:
                    return raw_msg["bytes"]
                else:
                    raise ValueError(f"Message has no text or bytes: {raw_msg}")
            else:
                raise ValueError(f"Unexpected message type: {raw_msg.get('type')}")
        except Exception as e:
            # If connection is closed, stop iteration
            if "close" in str(e).lower() or "disconnect" in str(e).lower():
                raise StopAsyncIteration
            raise

    async def close(self):
        await self._ws.close()

    async def wait_closed(self):
        return


@pytest.fixture
def asgi_ws_connect(gateway_test_client):
    def factory(url: str, **_):
        # Ignore host, keep only path (and query if any)
        parsed = urlparse(url)
        path = parsed.path
        if parsed.query:
            path = f"{path}?{parsed.query}"
        raw_cm = gateway_test_client.websocket_connect(path)
        return ASGIWebSocketAdapter(raw_cm)

    return factory


@pytest_asyncio.fixture
async def gateway_client_instance(gateway_test_client, asgi_ws_connect):
    """Actual GatewayClient instance using test infrastructure."""
    from aisolate.client.gateway_client import GatewayClient
    from typing import AsyncIterator

    async with GatewayClient(
        base_url="",
        session=gateway_test_client,
        ws_connect=asgi_ws_connect,
    ) as gc:
        yield gc


@pytest.fixture
def common_api_client():
    """
    A function-scoped fixture that could represent a test client.
    """
    print("\n[Fixture setup: common_api_client]")
    # In a real scenario, this would create and configure a client instance.
    return {"client_id": 12345}


@pytest.fixture(scope="session")
def kernel_gateway_proc() -> Generator[str, None, None]:
    """Spin up a real Jupyter kernel-gateway once per test session."""
    port = _find_free_port()
    cmd = [
        "jupyter",
        "kernelgateway",
        "--port",
        str(port),
        "--KernelGatewayApp.ip=127.0.0.1",
        "--JupyterWebsocketPersonality.list_kernels=True",
        "--KernelGatewayApp.log_level=20",
    ]
    env = os.environ.copy()
    env["NO_COLOR"] = "1"
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )
    try:
        _wait_tcp("127.0.0.1", port)
    except Exception as exc:
        proc.kill()
        out, err = proc.communicate(timeout=5)
        pytest.skip(
            f"Could not start jupyter-kernel-gateway: {exc}\n"
            f"stdout:\n{out}\nstderr:\n{err}"
        )
    yield f"http://127.0.0.1:{port}"
    proc.terminate()
    try:
        proc.wait(5)
    except subprocess.TimeoutExpired:
        proc.kill()


@pytest_asyncio.fixture()
async def gateway_test_client(
    kernel_gateway_proc, monkeypatch
) -> AsyncGenerator[AsyncTestClient, None]:
    """Test client for the Gateway app."""
    gateway_app = importlib.import_module("aisolate.gateway.app.main").app
    async with AsyncTestClient(gateway_app) as client:
        yield client


@pytest_asyncio.fixture()
async def sandbox_test_client() -> AsyncGenerator[AsyncTestClient, None]:
    """
    Test client for the Sandbox app.

    """
    app = importlib.import_module("aisolate.sandbox.app.main").app
    async with AsyncTestClient(app) as client:
        yield client
