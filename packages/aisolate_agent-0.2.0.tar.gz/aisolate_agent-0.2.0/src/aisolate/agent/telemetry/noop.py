"""No-op implementations for telemetry interfaces.

This module provides no-op implementations that do nothing but satisfy
the telemetry interfaces. These are used when telemetry is disabled
to provide zero-overhead tracing operations.
"""

from typing import Any, Optional, Dict, ContextManager, Generator
from contextlib import contextmanager, AbstractContextManager

from .interface import TracerInterface, SpanInterface


class NoOpSpan(SpanInterface):
    """No-op span implementation that does nothing.

    All methods are empty implementations that provide zero overhead
    when telemetry is disabled.
    """

    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on the span (no-op)."""
        pass

    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """Set multiple attributes on the span (no-op)."""
        pass

    def record_exception(self, exception: Exception) -> None:
        """Record an exception on the span (no-op)."""
        pass

    def set_status(self, status_code: str, description: Optional[str] = None) -> None:
        """Set the status of the span (no-op)."""
        pass

    def end(self) -> None:
        """End the span (no-op)."""
        pass


class NoOpTracer(TracerInterface):
    """No-op tracer implementation that does nothing.

    All methods return no-op spans or do nothing, providing zero overhead
    when telemetry is disabled.
    """

    def start_span(self, name: str, **attributes) -> SpanInterface:
        """Start a new span (returns no-op span).

        Args:
            name: The span name (ignored)
            **attributes: Initial span attributes (ignored)

        Returns:
            A no-op span instance
        """
        return NoOpSpan()

    @contextmanager
    def span(self, name: str, **attributes):
        """Context manager for automatic span lifecycle (no-op).

        Args:
            name: The span name (ignored)
            **attributes: Initial span attributes (ignored)

        Yields:
            A no-op span instance
        """
        yield NoOpSpan()

    def current_span(self) -> Optional[SpanInterface]:
        """Get the current active span (returns None).

        Returns:
            None (no active span in no-op implementation)
        """
        return None
