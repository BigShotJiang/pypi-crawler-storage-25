"""Abstract interfaces for non-invasive telemetry.

This module defines the core interfaces that provide a consistent API
for tracing operations regardless of the underlying telemetry backend.
"""

from abc import ABC, abstractmethod
from typing import Any, Optional, Dict, Iterator, ContextManager, Generator
from contextlib import contextmanager, AbstractContextManager


class SpanInterface(ABC):
    """Abstract interface for telemetry spans.

    This interface provides a consistent API for span operations
    that works with both real telemetry backends and no-op implementations.
    """

    @abstractmethod
    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on the span.

        Args:
            key: The attribute key
            value: The attribute value
        """
        pass

    @abstractmethod
    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """Set multiple attributes on the span.

        Args:
            attributes: Dictionary of attributes to set
        """
        pass

    @abstractmethod
    def record_exception(self, exception: Exception) -> None:
        """Record an exception on the span.

        Args:
            exception: The exception to record
        """
        pass

    @abstractmethod
    def set_status(self, status_code: str, description: Optional[str] = None) -> None:
        """Set the status of the span.

        Args:
            status_code: Status code (e.g., "OK", "ERROR")
            description: Optional status description
        """
        pass

    @abstractmethod
    def end(self) -> None:
        """End the span."""
        pass


class TracerInterface(ABC):
    """Abstract interface for telemetry tracers.

    This interface provides a consistent API for creating spans
    and managing tracing operations.
    """

    @abstractmethod
    def start_span(self, name: str, **attributes) -> SpanInterface:
        """Start a new span.

        Args:
            name: The span name
            **attributes: Initial span attributes

        Returns:
            A span interface instance
        """
        pass

    @abstractmethod
    def span(self, name: str, **attributes):
        """Context manager for automatic span lifecycle.

        Args:
            name: The span name
            **attributes: Initial span attributes

        Yields:
            A span interface instance
        """
        pass

    @abstractmethod
    def current_span(self) -> Optional[SpanInterface]:
        """Get the current active span.

        Returns:
            The current span or None if no span is active
        """
        pass
