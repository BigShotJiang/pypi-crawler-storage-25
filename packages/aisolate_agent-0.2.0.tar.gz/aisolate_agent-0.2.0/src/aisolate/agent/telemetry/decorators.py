"""Decorators for automatic tracing of functions and methods.

This module provides decorators that automatically add tracing to functions
without requiring manual span management. These decorators work with both
real and no-op tracers, ensuring no conditional logic is needed.
"""

import time
import json
import os
from functools import wraps
from typing import Any, Callable, Optional

from .openinference import _truncate
from .utils import get_tracer


def _set_truncated(span, key: str, value: Any) -> None:
    """Set an attribute after truncating to the per-attribute byte cap."""
    span.set_attribute(key, _truncate(value))


def _apply_tool_status(span, result: Any) -> None:
    """Set tool span status from the result.

    Tools that return a JSON object with ``"ok": false`` and an ``"error"``
    field (e.g. ``PythonExecutorTool``) are marked as ERROR so the failure
    surfaces in Phoenix. Everything else is OK.
    """
    error = None
    if isinstance(result, str):
        try:
            parsed = json.loads(result)
        except (json.JSONDecodeError, ValueError):
            parsed = None
        if isinstance(parsed, dict) and parsed.get("ok") is False:
            raw = parsed.get("error")
            if isinstance(raw, dict):
                error = raw
            elif raw:
                error = {"name": "ToolError", "value": str(raw)}

    if error:
        name = error.get("name") or "ToolError"
        message = error.get("value") or ""
        stacktrace = error.get("traceback") or ""
        span.set_attribute("tool.success", False)
        span.set_attribute("tool.error_type", name)
        span.set_attribute("exception.type", name)
        span.set_attribute("exception.message", message)
        if stacktrace:
            span.set_attribute("exception.stacktrace", stacktrace)
        span.set_status("ERROR", message)
    else:
        span.set_attribute("tool.success", True)
        span.set_status("OK")


def log_tool_call_execution(tier: str):
    """Decorator for logging tool call input/output and telemetry.

    This decorator automatically logs tool execution details and provides
    telemetry tracing without cluttering business logic.

    Args:
        tier: The tool tier ("platform", "function", "action")

    Returns:
        Decorated function with automatic logging and tracing
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def async_wrapper(*args, **kwargs) -> Any:
            from ..utils import get_logger

            logger = get_logger("aisolate.agent.tools")
            tracer = get_tracer()

            # Extract tool name from args (assumes first arg after context is tool_name)
            tool_name = args[1] if len(args) > 1 else "unknown"
            tool_args = args[2] if len(args) > 2 else {}

            logger.debug(f"[tool_call] name={tool_name} tier={tier} args={tool_args}")

            start_time = time.time()

            try:
                result = await func(*args, **kwargs)

                # Record success metrics
                duration = time.time() - start_time

                # Log output — full payload goes on the OTEL span (see Step 8),
                # not duplicated into every JSON log line.
                logger.debug(
                    "Tool execution completed",
                    tool_name=tool_name,
                    tier=tier,
                    success=True,
                    duration=duration,
                    result_type=type(result).__name__,
                    result_length=len(str(result)) if result else 0,
                )

                return result

            except Exception as e:
                # Record failure metrics
                duration = time.time() - start_time

                # Log error
                logger.exception(f"[tool_call] {tool_name} failed")
                logger.info(
                    f"Tool execution failed",
                    tool_name=tool_name,
                    tier=tier,
                    success=False,
                    duration=duration,
                    error=str(e),
                    error_type=type(e).__name__,
                )

                raise

        return async_wrapper

    return decorator


def trace_tool_execution(tool_name: Optional[str] = None):
    """Decorator for tracing tool execution.

    This decorator automatically creates spans for tool execution,
    including success/failure status and execution metadata.

    Args:
        tool_name: Optional tool name (if not provided, uses function name)

    Returns:
        Decorated function with automatic tracing
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def async_wrapper(*args, **kwargs) -> Any:
            name = tool_name or func.__name__
            tracer = get_tracer()

            with tracer.span(f"tool.{name}") as span:
                # OpenInference TOOL attributes — vendor-neutral.
                span.set_attribute("openinference.span.kind", "TOOL")
                span.set_attribute("tool.name", name)
                span.set_attribute("tool.function", func.__name__)
                if kwargs:
                    _set_truncated(span, "input.value", kwargs)

                # Legacy attrs kept for backward-compat dashboards.
                if kwargs:
                    span.set_attribute("tool.args_count", len(kwargs))
                    span.set_attribute("tool.args_type", type(kwargs).__name__)

                start_time = time.time()

                try:
                    result = await func(*args, **kwargs)

                    span.set_attribute("tool.duration", time.time() - start_time)
                    if result is not None:
                        _set_truncated(span, "output.value", result)
                        span.set_attribute("tool.result_type", type(result).__name__)
                        if isinstance(result, str):
                            span.set_attribute("tool.result_length", len(result))

                    _apply_tool_status(span, result)
                    return result

                except Exception as e:
                    span.set_attribute("tool.success", False)
                    span.set_attribute("tool.error_type", type(e).__name__)
                    span.set_attribute("tool.duration", time.time() - start_time)
                    # Record exception.type + exception.message only — skip
                    # stacktrace to avoid leaking PII from locals.
                    span.set_attribute("exception.type", type(e).__name__)
                    span.set_attribute("exception.message", str(e))
                    span.set_status("ERROR", str(e))
                    raise

        @wraps(func)
        def sync_wrapper(*args, **kwargs) -> Any:
            name = tool_name or func.__name__
            tracer = get_tracer()

            with tracer.span(f"tool.{name}") as span:
                span.set_attribute("openinference.span.kind", "TOOL")
                span.set_attribute("tool.name", name)
                span.set_attribute("tool.function", func.__name__)
                if kwargs:
                    _set_truncated(span, "input.value", kwargs)

                if kwargs:
                    span.set_attribute("tool.args_count", len(kwargs))
                    span.set_attribute("tool.args_type", type(kwargs).__name__)

                start_time = time.time()

                try:
                    result = func(*args, **kwargs)

                    span.set_attribute("tool.duration", time.time() - start_time)
                    if result is not None:
                        _set_truncated(span, "output.value", result)
                        span.set_attribute("tool.result_type", type(result).__name__)
                        if isinstance(result, str):
                            span.set_attribute("tool.result_length", len(result))

                    _apply_tool_status(span, result)
                    return result

                except Exception as e:
                    span.set_attribute("tool.success", False)
                    span.set_attribute("tool.error_type", type(e).__name__)
                    span.set_attribute("tool.duration", time.time() - start_time)
                    span.set_attribute("exception.type", type(e).__name__)
                    span.set_attribute("exception.message", str(e))
                    span.set_status("ERROR", str(e))
                    raise

        # Return appropriate wrapper based on function type
        import asyncio

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def trace_agent_session(session_name: Optional[str] = None):
    """Decorator for tracing agent sessions.

    Args:
        session_name: Optional session name (if not provided, uses function name)

    Returns:
        Decorated function with automatic session tracing
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            name = session_name or func.__name__
            tracer = get_tracer()

            with tracer.span(f"agent.session.{name}") as span:
                span.set_attribute("agent.session_name", name)
                span.set_attribute("agent.function", func.__name__)

                start_time = time.time()

                try:
                    result = await func(*args, **kwargs)
                    span.set_attribute("agent.session_success", True)
                    span.set_attribute(
                        "agent.session_duration", time.time() - start_time
                    )
                    span.set_status("OK")
                    return result

                except Exception as e:
                    span.set_attribute("agent.session_success", False)
                    span.set_attribute("agent.session_error", str(e))
                    span.set_attribute(
                        "agent.session_duration", time.time() - start_time
                    )
                    span.record_exception(e)
                    span.set_status("ERROR", str(e))
                    raise

        return wrapper

    return decorator


def trace_llm_call(model: Optional[str] = None):
    """Decorator for tracing LLM calls.

    Args:
        model: Optional model name

    Returns:
        Decorated function with automatic LLM call tracing
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            tracer = get_tracer()

            with tracer.span("llm.generate") as span:
                span.set_attribute("llm.function", func.__name__)
                if model:
                    span.set_attribute("llm.model", model)

                # Try to extract prompt information from arguments
                if "prompt" in kwargs:
                    prompt = kwargs["prompt"]
                    if isinstance(prompt, str):
                        span.set_attribute("llm.prompt_length", len(prompt))
                elif args and isinstance(args[0], str):
                    span.set_attribute("llm.prompt_length", len(args[0]))

                start_time = time.time()

                try:
                    result = await func(*args, **kwargs)

                    span.set_attribute("llm.success", True)
                    span.set_attribute("llm.duration", time.time() - start_time)

                    # Try to extract token information from result
                    if hasattr(result, "usage"):
                        usage = result.usage
                        if hasattr(usage, "prompt_tokens"):
                            span.set_attribute("llm.prompt_tokens", usage.prompt_tokens)
                        if hasattr(usage, "completion_tokens"):
                            span.set_attribute(
                                "llm.completion_tokens", usage.completion_tokens
                            )
                        if hasattr(usage, "total_tokens"):
                            span.set_attribute("llm.total_tokens", usage.total_tokens)

                    span.set_status("OK")
                    return result

                except Exception as e:
                    span.set_attribute("llm.success", False)
                    span.set_attribute("llm.error", str(e))
                    span.set_attribute("llm.duration", time.time() - start_time)
                    span.record_exception(e)
                    span.set_status("ERROR", str(e))
                    raise

        return wrapper

    return decorator


def trace_code_execution(language: str = "python"):
    """Decorator for tracing code execution.

    Args:
        language: Programming language being executed

    Returns:
        Decorated function with automatic code execution tracing
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            tracer = get_tracer()

            with tracer.span(f"code.{language}.execute") as span:
                span.set_attribute("code.language", language)
                span.set_attribute("code.function", func.__name__)

                # Try to extract code information from arguments
                if "code" in kwargs:
                    code = kwargs["code"]
                    if isinstance(code, str):
                        span.set_attribute("code.length", len(code))
                        span.set_attribute("code.lines", len(code.splitlines()))
                elif args and isinstance(args[0], str):
                    code = args[0]
                    span.set_attribute("code.length", len(code))
                    span.set_attribute("code.lines", len(code.splitlines()))

                start_time = time.time()

                try:
                    result = await func(*args, **kwargs)

                    span.set_attribute("code.duration", time.time() - start_time)

                    # Inspect result; kernel-level failure (result.ok=False) is
                    # a real error from the telemetry standpoint, equivalent to
                    # an exception being raised.
                    ok = getattr(result, "ok", True)
                    error = getattr(result, "error", None)
                    stdout = getattr(result, "stdout", None)

                    span.set_attribute("code.success", bool(ok))
                    if hasattr(result, "ok"):
                        span.set_attribute("code.execution_ok", ok)
                    if isinstance(stdout, str):
                        span.set_attribute("code.stdout_length", len(stdout))

                    if not ok and error:
                        err_name = (
                            error.get("name") if isinstance(error, dict) else None
                        ) or "CodeExecutionError"
                        err_msg = (
                            error.get("value") if isinstance(error, dict) else str(error)
                        ) or ""
                        err_tb = (
                            error.get("traceback") if isinstance(error, dict) else ""
                        ) or ""
                        span.set_attribute("code.has_error", True)
                        span.set_attribute("code.error_type", err_name)
                        span.set_attribute("exception.type", err_name)
                        span.set_attribute("exception.message", err_msg)
                        if err_tb:
                            span.set_attribute("exception.stacktrace", err_tb)
                        span.set_status("ERROR", err_msg)
                    else:
                        span.set_status("OK")
                    return result

                except Exception as e:
                    span.set_attribute("code.success", False)
                    span.set_attribute("code.error", str(e))
                    span.set_attribute("code.duration", time.time() - start_time)
                    span.record_exception(e)
                    span.set_status("ERROR", str(e))
                    raise

        return wrapper

    return decorator
