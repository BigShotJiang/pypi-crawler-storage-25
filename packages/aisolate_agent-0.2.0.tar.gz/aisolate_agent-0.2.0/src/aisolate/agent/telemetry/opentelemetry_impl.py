"""OpenTelemetry implementation for telemetry interfaces.

This module provides real OpenTelemetry implementations that integrate
with the OpenTelemetry SDK for actual tracing operations.
"""

from typing import Any, Optional, Dict, Iterator
from contextlib import contextmanager

from .interface import TracerInterface, SpanInterface

# Optional OpenTelemetry imports
try:
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False
    trace = None
    Status = None
    StatusCode = None


class OpenTelemetrySpan(SpanInterface):
    """OpenTelemetry span implementation.

    Wraps an OpenTelemetry span to provide the SpanInterface API.
    """

    def __init__(self, otel_span):
        """Initialize with an OpenTelemetry span.

        Args:
            otel_span: The underlying OpenTelemetry span
        """
        self._span = otel_span

    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on the span.

        Args:
            key: The attribute key
            value: The attribute value
        """
        if self._span:
            self._span.set_attribute(key, value)

    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """Set multiple attributes on the span.

        Args:
            attributes: Dictionary of attributes to set
        """
        if self._span:
            self._span.set_attributes(attributes)

    def record_exception(self, exception: Exception) -> None:
        """Record an exception on the span.

        Args:
            exception: The exception to record
        """
        if self._span:
            self._span.record_exception(exception)

    def set_status(self, status_code: str, description: Optional[str] = None) -> None:
        """Set the status of the span.

        Args:
            status_code: Status code (e.g., "OK", "ERROR")
            description: Optional status description
        """
        if self._span and StatusCode:
            if status_code.upper() == "OK":
                otel_status = StatusCode.OK
            elif status_code.upper() == "ERROR":
                otel_status = StatusCode.ERROR
            else:
                otel_status = StatusCode.UNSET

            self._span.set_status(Status(otel_status, description))

    def end(self) -> None:
        """End the span."""
        if self._span:
            self._span.end()


class OpenTelemetryTracer(TracerInterface):
    """OpenTelemetry tracer implementation.

    Wraps an OpenTelemetry tracer to provide the TracerInterface API.
    """

    def __init__(self, otel_tracer):
        """Initialize with an OpenTelemetry tracer.

        Args:
            otel_tracer: The underlying OpenTelemetry tracer
        """
        self._tracer = otel_tracer

    def start_span(self, name: str, **attributes) -> SpanInterface:
        """Start a new span.

        Args:
            name: The span name
            **attributes: Initial span attributes

        Returns:
            OpenTelemetry span wrapper
        """
        if self._tracer:
            otel_span = self._tracer.start_span(name, attributes=attributes)
            return OpenTelemetrySpan(otel_span)
        return OpenTelemetrySpan(None)

    @contextmanager
    def span(self, name: str, **attributes):
        """Context manager for automatic span lifecycle.

        Args:
            name: The span name
            **attributes: Initial span attributes

        Yields:
            OpenTelemetry span wrapper
        """
        if self._tracer:
            with self._tracer.start_as_current_span(
                name, attributes=attributes
            ) as otel_span:
                yield OpenTelemetrySpan(otel_span)
        else:
            yield OpenTelemetrySpan(None)

    def current_span(self) -> Optional[SpanInterface]:
        """Get the current active span.

        Returns:
            The current span wrapper or None if no span is active
        """
        if self._tracer and trace:
            current = trace.get_current_span()
            if current and current.is_recording():
                return OpenTelemetrySpan(current)
        return None
