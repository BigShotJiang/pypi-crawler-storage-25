"""Non-invasive telemetry module for the agent.

This module provides a clean, consistent interface for tracing and observability
that works regardless of whether telemetry is enabled or disabled.

Key principles:
- No conditional logic in business code
- True no-op when telemetry disabled
- Consistent API across all telemetry operations
- Easy to swap telemetry backends
"""

from .interface import TracerInterface, SpanInterface
from .factory import TracerFactory
from .utils import get_tracer, initialize_telemetry
from .decorators import (
    trace_tool_execution,
    trace_agent_session,
    trace_llm_call,
    trace_code_execution,
)

__all__ = [
    "TracerInterface",
    "SpanInterface",
    "TracerFactory",
    "get_tracer",
    "initialize_telemetry",
    "trace_tool_execution",
    "trace_agent_session",
    "trace_llm_call",
    "trace_code_execution",
]
