"""Factory for creating tracer instances based on configuration.

This module provides a centralized factory for creating the appropriate
tracer implementation based on configuration, eliminating the need for
conditional logic in business code.
"""

from typing import Optional

from .interface import TracerInterface
from .noop import NoOpTracer


class TracerFactory:
    """Factory for creating tracer instances.

    This factory encapsulates the logic for selecting the appropriate
    tracer implementation based on configuration, ensuring that business
    code never needs to check availability or handle ImportErrors.
    """

    _instance: Optional[TracerInterface] = None
    _initialized = False

    @classmethod
    def initialize(cls) -> None:
        """Initialize the tracer from the globally-set OpenTelemetry provider.

        The host application is responsible for configuring the global
        TracerProvider before calling this method. If no provider is set,
        the SDK returns a ProxyTracer that no-ops gracefully; if
        opentelemetry is not importable at all, fall back to NoOpTracer.
        """
        if cls._initialized:
            return

        try:
            from opentelemetry import trace

            from .opentelemetry_impl import OpenTelemetryTracer

            cls._instance = OpenTelemetryTracer(trace.get_tracer("aisolate.agent"))
        except ImportError:
            cls._instance = NoOpTracer()

        cls._initialized = True

    @classmethod
    def get_tracer(cls) -> TracerInterface:
        """Get the configured tracer instance.

        Returns the tracer instance that was configured during initialization.
        If not initialized, returns a no-op tracer as a safe default.

        Returns:
            The configured tracer instance
        """
        if not cls._initialized:
            # Return no-op tracer as safe default
            return NoOpTracer()

        return cls._instance or NoOpTracer()

    @classmethod
    def reset(cls) -> None:
        """Reset the factory (primarily for testing).

        This method resets the factory state, allowing for re-initialization.
        Primarily intended for use in tests.
        """
        cls._instance = None
        cls._initialized = False

    @classmethod
    def is_initialized(cls) -> bool:
        """Check if the factory has been initialized.

        Returns:
            True if the factory has been initialized, False otherwise
        """
        return cls._initialized
