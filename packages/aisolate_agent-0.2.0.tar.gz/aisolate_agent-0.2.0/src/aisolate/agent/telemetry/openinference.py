"""OpenInference semantic-convention helpers for LLM-aware tracing.

Returns attribute dicts to pass into `tracer.start_as_current_span(...,
attributes=...)`. Vendor-neutral — aisolate does not know that the
consumer is Phoenix; any OI-aware backend gets the same attributes.
"""

from __future__ import annotations

import json
from typing import Any, Iterable, Mapping

# Caps the 4 KB per-attribute limit in many OTLP backends (Phoenix
# included). Anything larger is truncated — split into multiple
# attributes or drop to a span event.
_MAX_ATTR_BYTES = 4000


def _truncate(value: Any) -> str:
    s = value if isinstance(value, str) else json.dumps(value, default=str)
    if len(s.encode("utf-8")) <= _MAX_ATTR_BYTES:
        return s
    return s.encode("utf-8")[:_MAX_ATTR_BYTES].decode("utf-8", errors="ignore")


def agent_span_attributes(
    name: str, input: Any = None, session_id: str | None = None
) -> dict[str, Any]:
    attrs: dict[str, Any] = {
        "openinference.span.kind": "AGENT",
        "agent.name": name,
    }
    if input is not None:
        attrs["input.value"] = _truncate(input)
    if session_id:
        attrs["session.id"] = session_id
    return attrs


def chain_span_attributes(
    name: str, input: Any = None, output: Any = None
) -> dict[str, Any]:
    attrs: dict[str, Any] = {
        "openinference.span.kind": "CHAIN",
        "agent.name": name,
    }
    if input is not None:
        attrs["input.value"] = _truncate(input)
    if output is not None:
        attrs["output.value"] = _truncate(output)
    return attrs


def tool_span_attributes(
    tool_name: str, input: Any = None, output: Any = None
) -> dict[str, Any]:
    attrs: dict[str, Any] = {
        "openinference.span.kind": "TOOL",
        "tool.name": tool_name,
    }
    if input is not None:
        attrs["input.value"] = _truncate(input)
    if output is not None:
        attrs["output.value"] = _truncate(output)
    return attrs


def llm_span_attributes(
    *,
    model: str,
    system: str | None = None,
    input_messages: Iterable[Mapping[str, Any]] | None = None,
    output_messages: Iterable[Mapping[str, Any]] | None = None,
    invocation_parameters: Mapping[str, Any] | None = None,
    tools: Iterable[Mapping[str, Any]] | None = None,
    token_count_prompt: int | None = None,
    token_count_completion: int | None = None,
    token_count_total: int | None = None,
) -> dict[str, Any]:
    """Build the LLM attribute dict.

    `tools` MUST NOT be merged into `llm.invocation_parameters`: a large
    tool list blows past the 4 KB cap and truncates the rest of the
    invocation parameters with it.

    `token_count_*` SHOULD NOT be passed when an OpenInference auto-
    instrumentor (e.g. `openinference-instrumentation-openai`) covers the
    same provider call: it emits the canonical `llm.token_count.*` on its
    own span, and Phoenix's session aggregator sums every LLM-kind span,
    so duplicating numbers here doubles totals. aisolate strategies keep
    parsing usage internally for `TokenUsage` / `accumulate_usage` —
    that's the source of truth for the in-process count.
    """
    attrs: dict[str, Any] = {
        "openinference.span.kind": "LLM",
        "llm.model_name": model,
    }
    if system:
        attrs["llm.system"] = system
    if input_messages is not None:
        for i, msg in enumerate(input_messages):
            attrs[f"llm.input_messages.{i}.message.role"] = msg.get("role", "")
            attrs[f"llm.input_messages.{i}.message.content"] = _truncate(
                msg.get("content", "")
            )
    if output_messages is not None:
        for i, msg in enumerate(output_messages):
            attrs[f"llm.output_messages.{i}.message.role"] = msg.get("role", "")
            attrs[f"llm.output_messages.{i}.message.content"] = _truncate(
                msg.get("content", "")
            )
    if invocation_parameters is not None:
        attrs["llm.invocation_parameters"] = _truncate(invocation_parameters)
    if tools is not None:
        attrs["llm.tools"] = _truncate(list(tools))
    if token_count_prompt is not None:
        attrs["llm.token_count.prompt"] = token_count_prompt
    if token_count_completion is not None:
        attrs["llm.token_count.completion"] = token_count_completion
    if token_count_total is not None:
        attrs["llm.token_count.total"] = token_count_total
    return attrs


def safe_record_exception(span, exc: BaseException) -> None:
    """Record `exception.type` + `exception.message` only.

    Skips `exception.stacktrace` because stacktraces frequently embed
    local variables with PII or credentials. Call this instead of
    span.record_exception() anywhere aisolate touches user data.
    """
    span.set_attribute("exception.type", type(exc).__name__)
    span.set_attribute("exception.message", str(exc))
