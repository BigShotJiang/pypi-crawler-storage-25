"""Utility functions for telemetry operations.

This module provides convenient helper functions for common telemetry
operations, abstracting away the complexity of the factory pattern.
"""

from typing import Any, Dict, Optional

from .factory import TracerFactory
from .interface import TracerInterface


def get_tracer() -> TracerInterface:
    """Get the configured tracer instance.

    This is a convenience function that wraps TracerFactory.get_tracer()
    for easier imports and usage throughout the codebase.

    Returns:
        The configured tracer instance
    """
    return TracerFactory.get_tracer()


def initialize_telemetry() -> None:
    """Initialize the telemetry system from the global OTEL provider.

    The host application must configure the global TracerProvider
    beforehand (e.g. via `otel_setup()` in energy-monitor).
    """
    TracerFactory.initialize()


def set_span_attributes(span, attributes: Dict[str, Any]) -> None:
    """Set multiple attributes on a span.

    Args:
        span: The span to set attributes on
        attributes: Dictionary of attribute key-value pairs
    """
    for key, value in attributes.items():
        if value is not None:
            span.set_attribute(key, value)


def safe_span_attribute(span, key: str, value: Any) -> None:
    """Safely set a span attribute, handling None values.

    Args:
        span: The span to set the attribute on
        key: The attribute key
        value: The attribute value (None values are ignored)
    """
    if value is not None:
        span.set_attribute(key, value)
