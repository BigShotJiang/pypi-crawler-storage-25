"""Memory-related models and data structures."""

from typing import Any, Optional, List, Dict
from pydantic import BaseModel, Field, ConfigDict
from openai_harmony import Message, Role, Author


class MemoryEntry(BaseModel):
    """Represents a single entry in the agent's long-term memory."""

    timestamp: str = Field(..., description="When this memory was created")
    entry_type: str = Field(
        ..., description="Type of memory entry (plan, tool_call, final_answer)"
    )
    content: Dict[str, Any] = Field(..., description="The actual memory content")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional context")

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ConversationHistory(BaseModel):
    """Manages the conversation history between agent and LLM."""

    messages: List[Message] = Field(default_factory=list)
    max_length: Optional[int] = Field(
        None, description="Maximum number of messages to keep"
    )

    def add_message(self, message: Message) -> None:
        """Add a message to the conversation history."""
        self.messages.append(message)
        if self.max_length and len(self.messages) > self.max_length:
            # Remove oldest messages, keeping the first (system) message
            self.messages = [self.messages[0]] + self.messages[-(self.max_length - 1) :]

    def extend_messages(self, messages: List[Message]) -> None:
        """Add multiple messages to the conversation history."""
        for message in messages:
            self.add_message(message)

    def clear(self) -> None:
        """Clear all messages from history."""
        self.messages.clear()

    def to_list(self) -> List[Message]:
        """Get messages as a list."""
        return self.messages.copy()


class PythonExecutorResult(BaseModel):
    """Model representing the result structure from python_executor."""

    ok: bool = Field(..., description="Whether the code execution was successful")
    stdout: str = Field(..., description="Standard output from the execution")
    text: Optional[str] = Field(None, description="Additional text output")
    image_png_base64: Optional[str] = Field(
        None, description="Base64-encoded PNG image if generated"
    )
    result: Any = Field(
        None, description="The actual result/return value of the executed code"
    )
    error: Optional[dict] = Field(
        None, description="Error information if execution failed"
    )

    model_config = ConfigDict(arbitrary_types_allowed=True)
