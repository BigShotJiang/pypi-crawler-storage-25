"""Python executor platform tool and remote execution backend.

This module unifies the previous `remote_executors.py` implementation with the
platform tool interface so everything related to remote Python execution lives
in one place.

Public pieces:
    - PythonExecutorResult: Pydantic model describing execution output
        - RemotePythonExecutor: sandbox interface (install packages, send
            actions, run code)
    - PythonExecutorTool: PlatformTool exposing remote execution to the LLM
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import pickle
from textwrap import dedent
from typing import Any, Optional

from pydantic import BaseModel, Field, ConfigDict

from aisolate.common.models import ErrorOutput


def _error_result(name: str, value: str, traceback: str = "") -> "PythonExecutorResult":
    """Construct a failed PythonExecutorResult with the given error fields."""
    return PythonExecutorResult(
        ok=False,
        stdout="",
        text=None,
        image_png_base64=None,
        result=None,
        error={"name": name, "value": value, "traceback": traceback},
    )

from .base import PlatformTool
from ..actions.base import CodeAction, get_action_definition_code
from ...utils import get_logger
from ...telemetry.decorators import trace_code_execution, trace_tool_execution

logger = get_logger("aisolate.agent.tools.platform.python_executor")


class PythonExecutorResult(BaseModel):
    """Result structure from remote Python execution."""

    ok: bool = Field(..., description="Whether the code execution was successful")
    stdout: str = Field(..., description="Standard output")
    text: Optional[str] = Field(None, description="Additional text output")
    image_png_base64: Optional[str] = Field(
        None, description="Base64-encoded PNG image if generated"
    )
    result: Any = Field(None, description="Return value of executed code")
    error: Optional[dict] = Field(None, description="Error information if failed")

    # Final answer fields - populated when final_answer() is called
    is_final_answer: bool = Field(
        default=False, description="Whether this represents a final answer"
    )
    final_answer_data: Optional[dict] = Field(
        None,
        description="Structured final answer with result, sources, and metadata",
    )

    # Review request fields - populated when request_report_review() is called
    review_requested: bool = Field(
        default=False, description="Whether this requests a QA review"
    )

    model_config = ConfigDict(arbitrary_types_allowed=True)


class RemotePythonExecutor:
    """Encapsulates sandbox communication for executing Python code."""

    def __init__(self, sandbox, additional_imports: list[str]):
        self.sbx = sandbox
        self.additional_imports = additional_imports

        # Environment configuration for Python execution
        self.timeout = int(os.getenv("PYTHON_EXECUTION_TIMEOUT", "120"))
        self.max_stdout_size = int(os.getenv("PYTHON_MAX_STDOUT_SIZE", "10240"))
        self.enable_package_install = (
            os.getenv("PYTHON_ENABLE_PACKAGE_INSTALL", "true").lower() == "true"
        )

        logger.info(
            "Initializing remote python executor",
            timeout=self.timeout,
            max_stdout_size=self.max_stdout_size,
            enable_package_install=self.enable_package_install,
        )
        self.installed_packages: list[str] = []

    @trace_code_execution("python")
    async def python_exec(self, code: str) -> PythonExecutorResult:
        return await self._build_execution_result(code)

    async def _build_execution_result(self, code: str) -> PythonExecutorResult:
        if not code:
            return _error_result("ValueError", "No code provided.")
        if self.sbx is None:
            return _error_result("RuntimeError", "Sandbox not provided.")

        try:
            exe = await asyncio.wait_for(self.sbx.arun_code(code), timeout=self.timeout)
        except asyncio.TimeoutError:
            return _error_result(
                "TimeoutError",
                f"Code execution exceeded {self.timeout}s timeout.",
            )
        except Exception as e:  # pragma: no cover (transport errors)
            return _error_result(type(e).__name__, str(e))

        error_dict = None
        if getattr(exe, "has_error", False) and getattr(exe, "error", None):
            err: ErrorOutput = exe.error  # type: ignore
            error_dict = {
                "name": err.error_name,
                "value": err.error_value,
                "traceback": getattr(exe, "traceback_str", ""),
            }

        # Check if execution contains a final answer
        # The Execution object has has_final_answer property that checks for
        # DisplayData with custom MIME type 'application/vnd.aisolate.final-answer+json'
        is_final = getattr(exe, "has_final_answer", False)
        final_data = None

        if is_final:
            # Extract the final answer data from the DisplayData event
            final_data = getattr(exe, "final_answer", None)
            logger.info(
                "Final answer detected in execution",
                has_result="result" in (final_data or {}),
                has_sources="sources" in (final_data or {}),
            )

        # Check if execution contains a review request
        # Uses MIME type 'application/vnd.aisolate.review-request+json'
        is_review = getattr(exe, "has_review_request", False)
        review_data = None

        if is_review:
            review_data = getattr(exe, "review_request", None)
            logger.info(
                "Review request detected in execution",
                has_result="result" in (review_data or {}),
            )

        # Handle image output: base64-encode bytes for JSON serialization
        raw_output = getattr(exe, "output", None)
        image_b64 = None
        result_value = raw_output
        if getattr(exe, "output_is_image", False) and isinstance(raw_output, bytes):
            image_b64 = base64.b64encode(raw_output).decode("ascii")
            result_value = (
                getattr(exe, "text", None) or f"<image, {len(raw_output):,} bytes>"
            )
        elif isinstance(raw_output, bytes):
            # Non-image binary data — use text fallback to avoid serialization errors
            result_value = (
                getattr(exe, "text", None) or f"<binary, {len(raw_output):,} bytes>"
            )

        return PythonExecutorResult(
            ok=not getattr(exe, "has_error", False),
            stdout=getattr(exe, "stdout", "") or "",
            text=getattr(exe, "text", None),
            image_png_base64=image_b64,
            result=result_value,
            error=error_dict,
            is_final_answer=is_final,
            final_answer_data=final_data if is_final else review_data,
            review_requested=is_review,
        )

    async def send_actions(self, actions: dict[str, CodeAction]) -> None:
        packages_to_install = {
            pkg
            for action in actions.values()
            for pkg in action.to_dict()["requirements"]
            if pkg not in self.installed_packages
        }
        if packages_to_install:
            packages_to_install.add("pydantic")
            installed = await self.install_packages(list(packages_to_install))
            self.installed_packages += installed

        code = get_action_definition_code(list(actions.values()))
        if code:
            code_output = await self.python_exec(code)
            if code_output.ok:
                logger.info(f"Actions installed successfully: {list(actions.keys())}")
            else:
                logger.error(f"Error installing tools: {code_output.error}")
                raise RuntimeError(
                    "Failed to install actions in sandbox; aborting run."
                )
            logger.info(code_output.stdout)

    async def send_variables(self, variables: dict[str, Any]) -> None:
        if not variables:
            return
        try:
            pickled_vars = base64.b64encode(pickle.dumps(variables)).decode()
            code = dedent(
                f"""
                import pickle, base64
                vars_dict = pickle.loads(base64.b64decode('{pickled_vars}'))
                locals().update(vars_dict)
                """
            )
            result = await self.python_exec(code)
            if not result.ok:
                logger.info(f"Error sending variables: {result.error}")
        except Exception as e:  # pragma: no cover
            logger.info(f"Error serializing variables: {e}")

    async def install_packages(self, additional_imports: list[str]) -> list[str]:
        if not additional_imports:
            return []
        try:
            code_output = await self.python_exec(
                f"!pip install --no-cache-dir {' '.join(additional_imports)}"
            )
            if code_output.ok:
                logger.info(f"Successfully installed packages: {additional_imports}")
            else:
                logger.error(f"Error installing packages: {code_output.error}")
            logger.info(code_output.stdout)
            return additional_imports
        except Exception as e:  # pragma: no cover
            logger.error(f"Error during package installation: {e}")
            return []

    # ------------------------------------------------------------------
    # Kernel state checkpoint / restore
    #
    # The actual save/restore logic lives in the sandbox as a startup
    # hook (sandbox/app/checkpoint_hook.py) — installed once at kernel
    # boot, same pattern as the display hook.  These methods are thin
    # wrappers that call the pre-installed kernel functions.
    # ------------------------------------------------------------------

    _CHECKPOINT_PATH = "/tmp/_checkpoint.pkl"

    async def checkpoint_save(
        self,
        upload_url: str = "",
        path: str = "",
    ) -> dict:
        """Dump user-defined data variables and upload to presigned URL.

        Calls the ``_aisolate_checkpoint_save()`` function that was
        installed into the kernel at startup by the checkpoint hook.

        Args:
            upload_url: Presigned PUT URL for the checkpoint file.
                If empty, the checkpoint is saved locally only.
            path: Custom local path for the checkpoint file.
                When empty, the default ``_CHECKPOINT_PATH`` is used.

        Returns:
            Dict with keys: saved (list[str]), manifest (list[dict]),
            skipped_unserializable (list[str]), size_bytes (int).
            Empty dict on failure.
        """
        save_path = path or self._CHECKPOINT_PATH
        code = f"_aisolate_checkpoint_save({save_path!r}, {upload_url!r})"
        result = await self.python_exec(code)

        if not result.ok:
            logger.error("Checkpoint save failed", error=result.error)
            return {}

        try:
            info = json.loads(result.stdout.strip().splitlines()[-1])
        except (json.JSONDecodeError, IndexError):
            info = {}

        logger.info(
            "Checkpoint saved",
            saved=info.get("saved", []),
            skipped_unserializable=info.get("skipped_unserializable", []),
            size_bytes=info.get("size_bytes", 0),
            has_upload_url=bool(upload_url),
        )
        return info

    async def checkpoint_restore(
        self,
        download_url: str = "",
        namespace: str = "",
    ) -> list[str]:
        """Download checkpoint from presigned URL and restore into kernel.

        Calls the ``_aisolate_checkpoint_restore()`` function that was
        installed into the kernel at startup by the checkpoint hook.

        Args:
            download_url: Presigned GET URL for the checkpoint file.
                If empty, restores from local file only.
            namespace: When non-empty, load into a ``SimpleNamespace`` at
                this key instead of merging into ``user_ns`` directly.

        Returns:
            List of variable names that were restored. Empty on failure.
        """
        if namespace:
            code = (
                f"_aisolate_checkpoint_restore("
                f"{self._CHECKPOINT_PATH!r}, {download_url!r}, namespace={namespace!r})"
            )
        else:
            code = (
                f"_aisolate_checkpoint_restore({self._CHECKPOINT_PATH!r}, {download_url!r})"
            )
        result = await self.python_exec(code)

        if not result.ok:
            logger.error("Checkpoint restore failed", error=result.error)
            return []

        try:
            info = json.loads(result.stdout.strip().splitlines()[-1])
        except (json.JSONDecodeError, IndexError):
            info = {"restored": []}

        restored = info.get("restored", [])
        logger.info(
            "Checkpoint restored",
            restored=restored,
            has_download_url=bool(download_url),
        )
        return restored


class PythonExecutorTool(PlatformTool):
    """Platform tool for executing Python code in the sandbox."""

    def __init__(self, name: str = "python") -> None:
        super().__init__(
            name=name,
            description=(
                "Execute Python code remotely and return stdout/stderr result."
            ),
            schema={
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Python code to run",
                    }
                },
                "required": ["code"],
            },
        )

    # Maximum size (in characters) for text/result/stdout fields returned to
    # the LLM.  The kernel display hook should prevent most blowups, but this
    # acts as a safety net.  Set generously — the display hook handles the
    # common cases; this catches edge cases.
    MAX_RESULT_SIZE = int(os.getenv("PYTHON_MAX_RESULT_SIZE", "50000"))

    @staticmethod
    def _truncate(value, limit: int):
        """Truncate a string value if it exceeds the limit. Non-strings are ignored."""
        if value is None:
            return value
        s = str(value) if not isinstance(value, str) else value
        if len(s) <= limit:
            return s
        half = limit // 2
        return (
            s[:half]
            + f"\n\n... [TRUNCATED — {len(s):,} chars total, showing [0:{half}] and [{len(s)-half}:{len(s)}]] ...\n\n"
            + s[-half:]
        )

    @trace_tool_execution("python")
    async def execute(self, context, **kwargs) -> str:  # type: ignore[override]
        code = kwargs.get("code", "")
        if not code:
            return json.dumps({"error": "No code provided"})

        try:
            rpe = context.remote_python_executor  # type: ignore[attr-defined]
            exec_result = await rpe.python_exec(code)

            # Log execution summary for debugging
            logger.info(
                "Python code execution completed",
                success=exec_result.ok,
                result=len(exec_result.result) if exec_result.result else 0,
                stdout_length=len(exec_result.stdout) if exec_result.stdout else 0,
                has_error=exec_result.error is not None,
                has_result=exec_result.result is not None,
                has_image=exec_result.image_png_base64 is not None,
            )

            # Log the full execution result for debugging purposes
            logger.debug(
                "Python execution result details",
                execution_result=exec_result.model_dump(),
                code_executed=code,
            )

            # Safety-net truncation for fields that flow into conversation.
            # The kernel display hook handles most cases, but raw `result`
            # (which can be any type) and stdout can still be large.
            limit = self.MAX_RESULT_SIZE
            for field in ("text", "stdout"):
                original = getattr(exec_result, field, None)
                if original and len(original) > limit:
                    logger.warning(
                        "Truncating large execution output field",
                        field=field,
                        original_length=len(original),
                        truncated_to=limit,
                    )
                    setattr(exec_result, field, self._truncate(original, limit))

            # The `result` field is Any — coerce to string for truncation check
            if exec_result.result is not None:
                result_str = str(exec_result.result)
                if len(result_str) > limit:
                    logger.warning(
                        "Truncating large result field",
                        original_length=len(result_str),
                        truncated_to=limit,
                    )
                    exec_result.result = self._truncate(result_str, limit)

            # Strip base64 image data before sending to the LLM — the image
            # is already captured by the framework; including it in the tool
            # result wastes enormous amounts of tokens.
            dump = exec_result.model_dump()
            if dump.get("image_png_base64"):
                dump["image_png_base64"] = "<image generated>"

            # Diagnostic: log review/final-answer fields before returning
            logger.info(
                "PythonExecutorTool.execute returning result",
                is_final_answer=dump.get("is_final_answer"),
                review_requested=dump.get("review_requested"),
                has_final_answer_data=dump.get("final_answer_data") is not None,
                final_answer_data_keys=list((dump.get("final_answer_data") or {}).keys()),
                ok=dump.get("ok"),
            )
            return json.dumps(dump)
        except Exception as e:  # pragma: no cover
            logger.error("Python execution failed", error=str(e))
            return json.dumps({"error": str(e)})
