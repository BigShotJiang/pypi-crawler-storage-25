"""Platform tool base class (Tier 1).

Platform tools are framework owned capabilities (web search, python exec, etc.)
exposed to the LLM as OpenAI-compatible function tools. They are async and
receive the AgentContext on execution.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from ...core.context import AgentContext


class PlatformTool:
    """Base class for platform (built-in) tools.

    Subclasses must implement ``async execute(context, **kwargs)`` and may
    override ``schema`` if they want parameters.
    """

    def __init__(
        self,
        name: str,
        description: str,
        schema: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.name = name
        self.description = description
        self.schema: Dict[str, Any] = schema or {
            "type": "object",
            "properties": {},
            "required": [],
        }

    def to_openai_spec(self) -> Dict[str, Any]:
        """Return OpenAI-compatible function tool spec."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.schema,
            },
        }

    async def execute(
        self, context: "AgentContext", **kwargs: Any
    ) -> Any:  # pragma: no cover
        raise NotImplementedError
