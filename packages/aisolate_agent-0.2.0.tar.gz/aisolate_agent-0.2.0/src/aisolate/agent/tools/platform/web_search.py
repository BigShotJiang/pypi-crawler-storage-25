import os
from typing import Any, Dict, Optional
import requests
from textwrap import dedent

from .base import PlatformTool
from ...utils import get_logger

logger = get_logger("aisolate.agent.tools.platform.web_search")


class WebSearchTool(PlatformTool):
    """Platform tool for web searching using Brave Search API."""

    def __init__(
        self,
        endpoint: str = "",
        api_key: str = "",
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ):
        description = dedent(
            """
            Use this function to find timely, up-to-date information or data sources online.
            It performs a web search for a given query and returns a list of the most relevant results.
            This should be one of the first steps for any research task.
            """
        )
        super().__init__(
            name="web_search",
            description=description,
            schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query to perform.",
                    }
                },
                "required": ["query"],
            },
        )
        self.endpoint = endpoint or "https://api.search.brave.com/res/v1/web/search"
        self.api_key = api_key or os.getenv("BRAVE_SEARCH_API_KEY")
        self.headers = headers or {
            "X-Subscription-Token": self.api_key,
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
        }
        self.params = params or {"count": 10}

    async def execute(self, context, **kwargs) -> str:  # type: ignore[override]
        query = kwargs.get("query", "")
        if not query:
            return "Error: No search query provided"

        # Log the search query
        logger.info("Performing web search", query=query, query_length=len(query))

        result = await self._perform_search(query)

        # Log the search result
        result_length = len(result)
        num_results = result.count("\n\n") if "## Search Results" in result else 0
        logger.info(
            "Web search completed",
            query=query,
            result_length=result_length,
            num_results=num_results,
            success="No results found" not in result,
        )

        return result

    async def _perform_search(self, query: str) -> str:
        params = {**self.params, "q": query}
        logger.debug(
            "Sending web search request", endpoint=self.endpoint, params=params
        )
        response = None
        try:
            response = requests.get(
                self.endpoint, headers=self.headers, params=params, timeout=20
            )
            logger.debug(
                "Web search response received",
                status_code=response.status_code,
                content_length=len(response.content) if response.content else 0,
            )
            response.raise_for_status()
            data = response.json()
            results = self._extract_results(data)
            formatted_result = self._format_markdown(results)

            logger.debug(
                "Web search results processed",
                raw_results_count=len(results),
                formatted_length=len(formatted_result),
            )

            return formatted_result
        except requests.HTTPError as e:  # type: ignore
            logger.error(
                "Web search HTTP error",
                error=str(e),
                status_code=getattr(response, "status_code", "unknown"),
                query=query,
            )
            status = getattr(response, "status_code", "?")  # type: ignore
            return f"Search failed: HTTP {status}"
        except Exception as e:  # pragma: no cover
            logger.error("Web search unexpected error", error=str(e), query=query)
            return f"Search failed: {str(e)}"

    def _extract_results(self, data: Dict) -> list:
        results = []
        for result in data.get("web", {}).get("results", []):
            results.append(
                {
                    "title": result.get("title", ""),
                    "url": result.get("url", ""),
                    "description": result.get("description", ""),
                }
            )
        return results

    def _format_markdown(self, results: list) -> str:
        if not results:
            return "No results found."
        return "## Search Results\n\n" + "\n\n".join(
            [
                f"{idx}. [{r['title']}]({r['url']})\n{r['description']}"
                for idx, r in enumerate(results, start=1)
            ]
        )
