"""SubAgent platform tool - enables agent-as-tool pattern with template selection."""

from __future__ import annotations
import asyncio
from typing import Any, Dict, Optional, TYPE_CHECKING
from datetime import datetime
from textwrap import dedent

from .base import PlatformTool
from ...utils import get_logger

from jinja2.environment import Template
from jinja2.runtime import StrictUndefined

if TYPE_CHECKING:
    from ...agent import Agent
    from ...core.context import AgentContext

logger = get_logger("aisolate.agent.tools.platform.subagent")


def _populate_template(template: str, variables: Dict[str, Any]) -> str:
    """Helper to populate Jinja2 templates."""
    return Template(template, undefined=StrictUndefined).render(**variables)


def _latest_run_for(
    handover_runs: Optional[Dict[str, Dict[str, Any]]],
    agent_name: str,
) -> Optional[Dict[str, Any]]:
    """Return the handover_runs entry for ``agent_name``, or None.

    Under auto-resume-by-name, each agent_name has at most one active
    sub-agent conversation in the parent's scope, so the dict lookup is
    direct. Used by ``SubAgentTool.execute`` for auto-resume: when a
    prior run exists, the framework reuses its conversation_id instead
    of minting a fresh one. The LLM never picks ids itself.
    """
    if not handover_runs:
        return None
    return handover_runs.get(agent_name)


class SubAgentTool(PlatformTool):
    """Platform tool that delegates tasks to a sub-agent.

    Wraps an Agent instance as a PlatformTool, enabling agent delegation.
    Supports template selection, depth limiting, and timeout control.
    """

    def __init__(
        self,
        agent: "Agent",
        namespace_config: Optional[Dict[str, str]] = None,
    ):
        """Initialize SubAgentTool.

        Args:
            agent: Agent instance to wrap
            namespace_config: Namespace configuration from parent LLM strategy.
                            If not provided, uses agent's own strategy config.
        """
        # Get namespace from provided config or agent's LLM strategy
        if namespace_config is None:
            namespace_config = agent.llm_strategy.namespace_config

        schema = {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task to delegate to the sub-agent",
                },
            },
            "required": ["task"],
        }

        # Use namespace config to generate tool name dynamically
        super().__init__(
            name=f"{namespace_config['agent_prefix']}{agent.name}",
            description=agent.description,
            schema=schema,
        )

        self.agent = agent
        self.namespace_config = namespace_config
        self._cumulative_usage: Optional["TokenUsage"] = None

    async def execute(self, context: "AgentContext", **kwargs: Any) -> str:
        """Execute the sub-agent with an isolated context.

        Args:
            context: Parent agent's context (for traceability)
            **kwargs: ``task`` (required).

        Returns:
            Formatted result string
        """
        import uuid as _uuid
        from ...core.context import AgentContext

        # --- Identity / auto-resume-by-name ---
        # The LLM does NOT name conversation_ids. The framework decides:
        # if the parent has a prior completed run of this agent in its
        # handover_runs registry, reuse that conversation_id (resume).
        # Otherwise mint a fresh UUID. This makes the registry the
        # authoritative source of identity and removes the LLM-picks-
        # wrong-id failure mode entirely.
        prior = _latest_run_for(context.handover_runs, self.agent.name)
        if prior is not None:
            sub_conversation_id = prior["conversation_id"]
        else:
            sub_conversation_id = str(_uuid.uuid4())

        # --- Defence-in-depth re-entry check ---
        # Cycles in the static graph are caught at Agent.__init__ via
        # _validate_managed_agents_acyclic. This runtime check catches
        # post-construction graph mutations or unexpected aliasing.
        ancestor = context
        while ancestor is not None:
            if ancestor.agent_name == self.agent.name:
                raise RuntimeError(
                    f"Sub-agent re-entry detected: {self.agent.name!r} is "
                    "already on the live call stack. The static cycle "
                    "check should have caught this — report as a bug."
                )
            ancestor = ancestor.parent_context

        task = self.agent.llm_strategy.format_subagent_task(
            agent_name=self.agent.name,
            task=kwargs.get("task", ""),
            handover_runs=context.handover_runs,
        )

        bound_logger = logger.bind(
            tool_name=self.name,
            subtask=str(task)[:100],
            parent_agent=context.agent_name,
            parent_turn=context.turn,
            sub_conversation_id=sub_conversation_id,
        )

        # Banner: highlight the cross-agent boundary in the log stream so
        # the main → sub transition is easy to spot in noisy struct logs.
        if prior is not None:
            bound_logger.info(
                f"↻↻↻ AUTO-RESUME SUB-AGENT: {self.agent.name} ↻↻↻"
            )
        else:
            bound_logger.info(
                f"▶▶▶ INVOKING SUB-AGENT (fresh): {self.agent.name} ▶▶▶"
            )

        try:
            # --- Load step: check for prior snapshot of this run ---
            # Best-effort: a missing snapshot logs and falls through to a
            # fresh start. Strategy is allowed to raise; we treat that as
            # "no prior state available" rather than failing the run.
            prior_snapshot = None
            if self.agent.memory_strategy is not None:
                try:
                    prior_snapshot = (
                        await self.agent.memory_strategy
                        .load_latest_snapshot(sub_conversation_id)
                    )
                except Exception as e:
                    bound_logger.warning(
                        "Failed to load prior snapshot; starting fresh",
                        error=str(e),
                    )

            # Create fresh sandbox context from agent's root sandbox
            sub_sandbox = await self.agent.sandbox.acreate_context_bound_sandbox()

            # Create AgentContext for sub-agent. conversation_id is now
            # threaded so save_snapshot succeeds (was None before — silent
            # failure mode).
            sub_context = AgentContext(
                agent_name=self.agent.name,
                task=task,
                llm=self.agent.llm_strategy,
                memory=self.agent.memory_strategy,
                sandbox=sub_sandbox,
                max_turns=self.agent.settings.max_turns,
                conversation_id=sub_conversation_id,
                sub_agent_tools=self.agent.sub_agent_tools,
                actions=self.agent.actions,
                builtin_tools=self.agent.builtin_tools,
                function_tools=self.agent.function_tools,
                parent_context=context,
            )

            # Rehydrate from prior snapshot if one was found. Reuses the
            # same restoration helpers main_agent uses on resume:
            # 1) conversation history (synchronous)
            # 2) kernel state from checkpoint (async, best-effort)
            # 3) parent's sibling-handover registry into the kernel
            #    (so the resumed sub-agent's load_handover_data calls
            #    can find data_agent / report_agent siblings).
            if prior_snapshot is not None:
                self.agent._restore_context_from_snapshot(
                    sub_context, prior_snapshot
                )
                await self.agent._restore_checkpoint(
                    sub_context, prior_snapshot, bound_logger
                )
                # _restore_checkpoint already re-injects the SUB-AGENT's
                # own handover_runs (which under no-recursion is empty).
                # Additionally inject the PARENT's handover_runs so the
                # resumed sub-agent can access siblings' data.
                await self.agent._inject_handover_urls(
                    sub_context, context.handover_runs, bound_logger
                )

            # Lifecycle event: SubAgentStartedEvent (telemetry only —
            # does not gate execution). resumed_from_turn distinguishes
            # fresh starts (None) from resumes.
            from ...core.events import SubAgentStartedEvent
            if context is not None:
                context.event_channel.put_nowait(SubAgentStartedEvent(
                    conversation_id=sub_conversation_id,
                    agent_name=self.agent.name,
                    resumed_from_turn=(
                        prior_snapshot.turn if prior_snapshot is not None
                        else None
                    ),
                ))

            # Execute sub-agent with prepared context
            result = await self._execute_subagent(sub_context)

            # Handover: checkpoint subagent sandbox and inject URL into parent.
            # Per the framework's atomic-write contract: retry transient
            # failures, raise on irrecoverable ones. No "continue without"
            # path — half-state would let resume mount the wrong checkpoint.
            if (
                sub_context.final_answer is not None
                and sub_context.final_answer.handover
                and self.agent.checkpoint_storage
            ):
                handover_info = None
                last_exc: Optional[BaseException] = None
                for attempt in range(3):
                    try:
                        handover_info = await self._save_handover_checkpoint(
                            sub_context, context
                        )
                        break
                    except Exception as e:
                        last_exc = e
                        if attempt < 2:
                            await asyncio.sleep(0.5 * (2 ** attempt))
                            bound_logger.warning(
                                "Handover checkpoint attempt failed; retrying",
                                attempt=attempt + 1,
                                error=str(e),
                            )

                if handover_info is None:
                    bound_logger.error(
                        "Handover checkpoint failed after retries; raising",
                        error=str(last_exc),
                    )
                    raise RuntimeError(
                        f"Sub-agent {self.agent.name!r} handover persistence "
                        f"failed after retries: {last_exc}"
                    ) from last_exc

                sub_context.final_answer.handover["checkpoint_key"] = handover_info["key"]
                sub_context.final_answer.handover["manifest"] = handover_info["manifest"]
                sub_context.final_answer.handover["tmp_path"] = handover_info["tmp_path"]

                # Set the parent's handover entry for this agent_name.
                # Dict-keyed by agent_name: each agent has at most one
                # active sub-agent conversation in the parent's scope
                # under auto-resume. Re-invocations of the same agent
                # (e.g. critic-driven retries) reuse the conversation_id
                # via auto-resume, so this assignment overwrites with a
                # newer manifest / finished_at — never duplicates.
                # Persisted to the parent's snapshot.
                context.handover_runs[sub_context.agent_name] = {
                    "conversation_id": sub_context.conversation_id,
                    "checkpoint_key": handover_info["key"],
                    "manifest": handover_info["manifest"],
                    "finished_at": datetime.now().isoformat(),
                }

                # Inject download URL into parent kernel for load_handover_data
                await self._inject_handover_url(sub_context, context)

                # Re-serialize with enriched handover metadata
                from ...tools.models import serialize_final_answer
                result = serialize_final_answer(sub_context.final_answer)

                bound_logger.info(
                    f"⤴ HANDOVER SAVED: {sub_context.agent_name}",
                    key=handover_info["key"],
                    manifest_count=len(handover_info["manifest"]),
                )

            # Track sub-agent token usage
            sub_usage = sub_context.cumulative_usage
            if self._cumulative_usage is None:
                from ...core.llm_response import TokenUsage

                self._cumulative_usage = TokenUsage()
            self._cumulative_usage += sub_usage
            context.accumulate_usage(sub_usage)

            bound_logger.info(
                f"◀◀◀ SUB-AGENT FINISHED: {self.agent.name} ◀◀◀",
                result_length=len(result),
                token_usage=sub_usage.to_dict(),
            )

            # Lifecycle event: SubAgentFinishedEvent. persisted=True is
            # the success path (we got past the atomic-write block above
            # without raising).
            from ...core.events import SubAgentFinishedEvent
            if context is not None:
                context.event_channel.put_nowait(SubAgentFinishedEvent(
                    conversation_id=sub_conversation_id,
                    agent_name=self.agent.name,
                    usage=sub_usage.to_dict(),
                    persisted=True,
                ))

            # Format with report template so the parent LLM gets context.
            formatted = self.agent.llm_strategy.format_subagent_report(
                agent_name=self.agent.name, final_answer=result
            )
            return formatted

        except Exception as e:
            bound_logger.exception(
                "Sub-agent execution failed",
                error=str(e),
                error_type=type(e).__name__,
                exc_info=True,
            )

            # Content filter errors are recoverable — return an error message
            # so the coordinator can rephrase and retry the delegation.
            error_str = str(e)
            if "content_filter" in error_str or "content management policy" in error_str:
                bound_logger.warning(
                    "Content filter triggered — returning recoverable error to coordinator",
                    agent_name=self.agent.name,
                )
                return (
                    f"⚠️ The task delegation to {self.agent.name} was rejected by the "
                    f"content safety filter. This is likely a false positive caused by "
                    f"specific wording in the task description. Please rephrase the task "
                    f"avoiding words that could be misinterpreted (e.g. use 'Optimierungspotenziale' "
                    f"instead of 'Schwachstellen', 'Analyse der Effizienz' instead of "
                    f"'Schwachstellenanalyse') and retry the delegation."
                )

            raise RuntimeError(f"Sub-agent execution failed: {e}") from e

    async def _save_handover_checkpoint(
        self, sub_context: "AgentContext", parent_context: "AgentContext"
    ) -> dict:
        """Save subagent kernel state as a handover checkpoint.

        Writes to ``/tmp/handover_{name}.pkl`` (hot path) and uploads
        to object storage (cold path) via presigned URL.

        Args:
            sub_context: The subagent's execution context
            parent_context: The parent agent's context (for conversation_id)

        Returns:
            Dict with ``key``, ``manifest``, ``tmp_path``.
        """
        parent_conv_id = parent_context.conversation_id
        sub_conv_id = sub_context.conversation_id
        agent_name = sub_context.agent_name
        # Per-run tmp file: include sub_conv_id so concurrent re-invocations
        # of the same sub-agent within one kernel don't overwrite each other.
        tmp_path = f"/tmp/handover_{agent_name}_{sub_conv_id}.pkl"

        # Only checkpoint the specific variables declared in the handover,
        # not the entire kernel namespace.
        # New format: handover keys are variable names, values are descriptions.
        declared_vars = list(sub_context.final_answer.handover.keys())
        var_list = ", ".join(repr(v) for v in declared_vars)

        upload_url = await self.agent.checkpoint_storage.get_upload_url(
            self._handover_key(parent_conv_id, sub_conv_id)
        )

        # Build the descriptions dict from the handover {var_name: description}
        # Only include validated string→string pairs (final_answer already enforces this)
        descriptions = {
            k: v for k, v in sub_context.final_answer.handover.items()
            if isinstance(v, str) and k not in ('checkpoint_key', 'manifest', 'tmp_path')
        }

        # Use json.dumps (not repr) to safely serialize descriptions into kernel code
        import json as _json_mod
        descriptions_literal = _json_mod.dumps(descriptions, ensure_ascii=True)

        # Build selective pickle in the sub-agent's kernel
        code = (
            "import dill as _dill, json as _json, os as _os, requests as _requests\n"
            f"_ho_vars = [{var_list}]\n"
            "_ip = get_ipython()\n"
            "_ho_data = {}\n"
            "for _n in _ho_vars:\n"
            "    if _n in _ip.user_ns:\n"
            "        _ho_data[_n] = _ip.user_ns[_n]\n"
            f"_ho_data['__descriptions__'] = _json.loads({descriptions_literal!r})\n"
            f"with open({tmp_path!r}, 'wb') as _f:\n"
            "    _dill.dump(_ho_data, _f)\n"
            f"_sz = _os.path.getsize({tmp_path!r})\n"
            f"if {upload_url!r}:\n"
            f"    with open({tmp_path!r}, 'rb') as _f:\n"
            f"        _requests.put({upload_url!r}, data=_f, timeout=120).raise_for_status()\n"
            "_manifest = [{'name': k, 'type': type(v).__name__} for k, v in _ho_data.items()]\n"
            "print(_json.dumps({'saved': sorted(_ho_data.keys()), 'manifest': _manifest, 'size_bytes': _sz}))"
        )
        result = await sub_context.remote_python_executor.python_exec(code)

        info = {}
        if result.ok and result.stdout:
            try:
                import json
                info = json.loads(result.stdout.strip().splitlines()[-1])
            except (json.JSONDecodeError, IndexError, ValueError):
                pass

        return {
            "key": self._handover_key(parent_conv_id, sub_conv_id),
            "manifest": info.get("manifest", []),
            "tmp_path": tmp_path,
        }

    async def _inject_handover_url(
        self, sub_context: "AgentContext", parent_context: "AgentContext"
    ) -> None:
        """Sign a download URL and set the parent kernel's handover entry
        for this sub-agent's name.

        The kernel-side ``_aisolate_handover_urls`` is a dict keyed by
        agent_name. Re-invocations of the same sub-agent (under auto-
        resume) overwrite the entry with a fresher URL.
        """
        key = sub_context.final_answer.handover.get("checkpoint_key")
        if not key:
            return

        download_url = await self.agent.checkpoint_storage.get_download_url(
            key, expires_seconds=3600
        )
        record = {
            "conversation_id": sub_context.conversation_id,
            "url": download_url,
            "manifest": sub_context.final_answer.handover.get("manifest", []),
        }

        code = (
            "_aisolate_handover_urls = globals().get("
            "'_aisolate_handover_urls', {})\n"
            f"_aisolate_handover_urls[{sub_context.agent_name!r}] = {record!r}"
        )
        await parent_context.remote_python_executor.python_exec(code)

    def _handover_key(
        self, parent_conversation_id: str, sub_conversation_id: str
    ) -> str:
        """Build the object-storage key for a handover checkpoint.

        Key shape ``handovers/{parent_conv_id}/{sub_conv_id}.pkl`` ensures
        every sub-agent invocation has its own blob (no overwrites between
        re-invocations) while keeping per-conversation grouping for
        retention/cleanup.
        """
        return f"handovers/{parent_conversation_id}/{sub_conversation_id}.pkl"

    async def _execute_subagent(self, context: "AgentContext") -> str:
        """Execute sub-agent with given context (non-streaming).

        Pushes SubAgentProgressEvent to the parent context's event_channel
        after each turn so the streaming loop can relay them to the client.

        Args:
            context: Fresh AgentContext with isolated sandbox

        Returns:
            JSON string containing serialized FinalAnswerResult or
            fallback string
        """
        from ...states.planning import PlanningState
        from ...tools.models import serialize_final_answer, FinalAnswerResult
        from ...core.events import SubAgentProgressEvent, TurnCompletedEvent

        parent = context.parent_context
        bound_logger = logger.bind(
            sub_agent_name=context.agent_name,
            sub_conversation_id=context.conversation_id,
        )

        try:
            # Initialize
            await context.remote_python_executor.send_actions(self.agent.actions)
            initial_messages = self.agent.llm_strategy.prepare_initial_history(context)
            context.initialize_conversation(initial_messages)
            context.transition_to(PlanningState())

            # Execute turns
            while not context.is_finished:
                turn_result = await context.execute_turn()

                # Per-turn state persistence: save kernel checkpoint (final
                # turn only) + snapshot. Mirrors what Agent.run_streaming
                # does for the main_agent path. Without this call,
                # sub-agent snapshots are never written and resume can
                # never find prior state.
                turn_event = TurnCompletedEvent(
                    turn=context.turn,
                    state=turn_result.state,
                    is_finished=context.is_finished,
                    final_answer=context.final_answer,
                    state_metadata=turn_result.state_metadata,
                    usage=(
                        turn_result.usage.to_dict() if turn_result.usage else None
                    ),
                    reasoning=turn_result.reasoning,
                    agent_name=context.agent_name,
                )
                await self.agent._save_turn_state(context, bound_logger, turn_event)

                # Push the full sub-agent turn plus compact progress to the
                # parent stream. The top-level runner drains this queue while
                # the parent tool call is still running, so clients see the
                # sub-agent log live instead of as one final batch.
                if parent is not None:
                    parent.event_channel.put_nowait(turn_event)
                    turn_usage = context.last_turn_usage
                    parent.event_channel.put_nowait(
                        SubAgentProgressEvent(
                            agent_name=context.agent_name,
                            parent_turn=parent.turn,
                            sub_turn=context.turn,
                            sub_max_turns=self.agent.settings.max_turns,
                            state=context.execution.current_state.__class__.__name__
                            if context.execution.current_state
                            else "",
                            usage=turn_usage.to_dict() if turn_usage else None,
                            cumulative_usage=context.cumulative_usage.to_dict(),
                        )
                    )

                if context.turn >= self.agent.settings.max_turns:
                    break

            # Serialize FinalAnswerResult to JSON for inter-agent communication
            if context.final_answer is not None:
                return serialize_final_answer(context.final_answer)
            else:
                # Fallback: create a minimal FinalAnswerResult
                fallback = FinalAnswerResult(answer="No final answer provided")
                return serialize_final_answer(fallback)

        except Exception as e:
            logger.exception(
                "Error during sub-agent execution",
                agent_name=self.agent.name,
                error=str(e),
                error_type=type(e).__name__,
                turn=context.turn,
            )
            raise

    def to_code_prompt(self) -> str:
        """Generate a tool-style prompt stub for the sub-agent.

        Returns:
            A tool specification describing how to call this agent as a tool.
        """
        doc = (self.agent.description or "").strip()

        return dedent(
            f'''
            # {self.agent.name}
            """{doc}"""

            Tool ID: {self.agent.name}
            Kind: Subagent (managed)

            Call as:
              to={self.agent.name}
              args: {{
                "task": "<detailed request>",
                "additional_args": {{...optional context...}}
              }}

            Returns: string (structured summary with citations)
        '''
        ).strip()
