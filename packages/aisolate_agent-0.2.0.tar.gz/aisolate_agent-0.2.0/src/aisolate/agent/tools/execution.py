"""Tool execution logic and result processing."""

from typing import TYPE_CHECKING, Optional
import json

from .models import ToolCall, FinalAnswerResult, HITLSignal, ToolExecutionResult
from ..telemetry.decorators import log_tool_call_execution
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext

logger = get_logger("aisolate.agent.tools.execution")


@log_tool_call_execution("platform")
async def execute_builtin_tool(
    context: "AgentContext", tool_call: ToolCall
) -> str:
    """Execute a platform/builtin tool call.

    Args:
        context: AgentContext containing available tools and execution state
        tool_call: ToolCall object with name and arguments

    Returns:
        String result from tool execution

    Raises:
        ValueError: If tool is not found
    """
    for tool in context.builtin_tools:
        if hasattr(tool, "name") and tool.name == tool_call.name:
            result = await tool.execute(context, **tool_call.arguments)
            return str(result) if result is not None else ""
    raise ValueError(f"Builtin tool '{tool_call.name}' not found")


@log_tool_call_execution("function")
async def execute_function_tool(
    context: "AgentContext", tool_call: ToolCall
) -> str:
    """Execute a function tool call.

    Args:
        context: AgentContext containing available tools and execution state
        tool_call: ToolCall object with name and arguments

    Returns:
        String result from tool execution

    Raises:
        ValueError: If tool is not found
    """
    for tool in context.function_tools:
        if hasattr(tool, "name") and tool.name == tool_call.name:
            result = await tool.execute(context, **tool_call.arguments)
            return str(result) if result is not None else ""
    raise ValueError(f"Function tool '{tool_call.name}' not found")


@log_tool_call_execution("subagent")
async def execute_subagent_tool(
    context: "AgentContext", tool_call: ToolCall
) -> str:
    """Execute a sub-agent tool call.

    Args:
        context: AgentContext containing available tools and execution state
        tool_call: ToolCall object with name and arguments

    Returns:
        String result from sub-agent tool execution

    Raises:
        ValueError: If tool is not found
    """
    if tool_call.name in context.sub_agent_tools:
        tool = context.sub_agent_tools[tool_call.name]
        result = await tool.execute(context, **tool_call.arguments)
        return str(result) if result is not None else ""
    raise ValueError(f"Sub-agent tool '{tool_call.name}' not found")


def _extract_subagent_metadata(
    tool_call: ToolCall, result_str: str
) -> dict | None:
    """Extract structured subagent result for event streaming.

    When a subagent tool returns, the result_str is the formatted report
    (text + JSON + handover instructions) meant for the parent LLM.
    This extracts the clean structured JSON so the frontend can display
    it without brittle string parsing.
    """
    import json as _json
    for line in result_str.split("\n"):
        stripped = line.strip()
        if stripped.startswith("{"):
            try:
                return _json.loads(stripped)
            except _json.JSONDecodeError:
                continue
    return None


@log_tool_call_execution("action")
async def execute_action_tool(
    context: "AgentContext", tool_call: ToolCall
) -> str:
    """Execute an action tool call.

    NOTE: Actions should use Python builtin tools instead.

    Args:
        context: AgentContext containing available tools and execution state
        tool_call: ToolCall object with name and arguments

    Returns:
        Error message string
    """
    return str(
        f"Action tool '{tool_call.name}' should use Python builtin "
        f"tools call instead. Actions are only used inside the "
        f"python kernel."
    )


def extract_final_answer(
    result_str: str, tool_name: str
) -> Optional[FinalAnswerResult]:
    """Extract final answer from tool result if present.

    Checks if the result string represents a PythonExecutorResult with
    is_final_answer=True and extracts the final answer data.

    Args:
        result_str: JSON string result from tool execution
        tool_name: Name of the tool that produced the result (for logging)

    Returns:
        FinalAnswerResult if final answer detected, None otherwise
    """
    try:
        result_data = json.loads(result_str)

        if isinstance(result_data, dict):
            is_final = result_data.get("is_final_answer", False)
            final_data = result_data.get("final_answer_data")

            if is_final and final_data:
                answer_text = final_data.get("result", "")

                if not answer_text:
                    logger.warning(
                        "Final answer detected but result is empty",
                        tool_name=tool_name,
                    )
                    return None

                logger.info(
                    "Final answer extracted from tool result",
                    tool_name=tool_name,
                    answer_length=len(str(answer_text)),
                    has_sources="sources" in final_data,
                )

                return FinalAnswerResult(
                    answer=str(answer_text),
                    sources=final_data.get("sources"),
                    confidence=final_data.get("confidence"),
                    metadata=final_data.get("metadata"),
                    handover=final_data.get("handover"),
                )

    except (json.JSONDecodeError, ValueError, TypeError) as e:
        logger.debug(
            "Could not parse result as JSON (expected for non-Python tools)",
            tool_name=tool_name,
            error_type=type(e).__name__,
        )

    return None


def extract_hitl_signal(
    result_str: str, tool_name: str
) -> Optional[HITLSignal]:
    """Extract HITL signal from function tool result if present.

    Checks if the result string contains a JSON object with
    ``hitl_signal: true`` and extracts the signal data.

    Args:
        result_str: JSON string result from tool execution
        tool_name: Name of the tool that produced the result

    Returns:
        HITLSignal if detected, None otherwise
    """
    try:
        result_data = json.loads(result_str)
        if isinstance(result_data, dict) and result_data.get("hitl_signal"):
            signal_type = result_data.get("signal_type", "unknown")
            logger.debug(
                "HITL signal extracted",
                tool_name=tool_name,
                signal_type=signal_type,
            )
            return HITLSignal(
                signal_type=signal_type,
                data=result_data,
                requires_response=signal_type in ("ask_user", "confirm"),
            )
    except (json.JSONDecodeError, ValueError, TypeError):
        pass
    return None


def extract_review_request(
    result_str: str, tool_name: str
) -> Optional[FinalAnswerResult]:
    """Extract review request from tool result if present.

    Checks for ``review_requested: true`` in the result JSON (set by
    ``ScheduleReviewAction`` (request_report_review) via a dedicated MIME type).  Returns a
    ``FinalAnswerResult`` with the answer data so CriticState can
    inspect the report.

    Args:
        result_str: JSON string result from tool execution
        tool_name: Name of the tool that produced the result

    Returns:
        FinalAnswerResult if review request detected, None otherwise
    """
    try:
        result_data = json.loads(result_str)

        if not isinstance(result_data, dict):
            logger.debug(
                "extract_review_request: result is not a dict",
                tool_name=tool_name,
                result_type=type(result_data).__name__,
            )
            return None

        # Log all review-relevant fields for debugging
        logger.info(
            "extract_review_request: checking fields",
            tool_name=tool_name,
            review_requested=result_data.get("review_requested"),
            is_final_answer=result_data.get("is_final_answer"),
            has_final_answer_data=result_data.get("final_answer_data") is not None,
        )

        if not result_data.get("review_requested"):
            return None

        final_data = result_data.get("final_answer_data", {})
        answer_text = final_data.get("result", "")

        if not answer_text:
            logger.warning(
                "Review request detected but result is empty",
                tool_name=tool_name,
                final_answer_data_keys=list(final_data.keys()),
            )
            return None

        logger.info(
            "extract_review_request: SUCCESS — returning FinalAnswerResult",
            tool_name=tool_name,
            answer_length=len(str(answer_text)),
            has_sources="sources" in final_data,
        )

        return FinalAnswerResult(
            answer=str(answer_text),
            sources=final_data.get("sources"),
            confidence=final_data.get("confidence"),
            metadata=final_data.get("metadata"),
            handover=final_data.get("handover"),
        )

    except (json.JSONDecodeError, ValueError, TypeError):
        pass

    return None


async def execute_tool_call(
    context: "AgentContext", tool_call: ToolCall
) -> ToolExecutionResult:
    """Execute a tool call using the appropriate tool from the context.

    This is the main entry point for tool execution in the three-tier
    architecture. It routes tool calls to the correct executor based on
    the tool's tier.

    Args:
        context: AgentContext containing available tools and execution state
        tool_call: Type-safe ToolCall object with name, arguments, etc.

    Returns:
        ToolExecutionResult with output, optional final_answer, and
        optional error
    """
    from .routing import find_tool_tier

    logger.debug(
        f"[tool_call] name={tool_call.name} args={tool_call.arguments}"
    )

    tier = find_tool_tier(context, tool_call.name)

    if tier is None:
        logger.warning(f"[tool_call] Unknown tool {tool_call.name}")
        return ToolExecutionResult(
            output="",
            error=f"Unknown tool {tool_call.name}",
        )

    try:
        # Execute the tool based on tier
        if tier == "subagent":
            result_str = await execute_subagent_tool(context, tool_call)
        elif tier == "builtin":
            result_str = await execute_builtin_tool(context, tool_call)
        elif tier == "function":
            result_str = await execute_function_tool(context, tool_call)
        elif tier == "action":
            result_str = await execute_action_tool(context, tool_call)
        else:
            logger.error(
                f"[tool_call] Invalid tier {tier} for tool {tool_call.name}"
            )
            return ToolExecutionResult(
                output="",
                error=f"Invalid tool tier: {tier}",
            )

        # Check if result contains a final answer, HITL signal, or review request
        final_answer = extract_final_answer(result_str, tool_call.name)
        hitl_signal = extract_hitl_signal(result_str, tool_call.name)
        review_request = extract_review_request(result_str, tool_call.name)

        logger.info(
            "execute_tool_call: extraction results",
            tool_name=tool_call.name,
            tier=tier,
            has_final_answer=final_answer is not None,
            has_review_request=review_request is not None,
            has_hitl_signal=hitl_signal is not None,
            result_str_length=len(result_str),
        )

        # For subagent tools, extract structured result for event streaming
        metadata = None
        if tier == "subagent":
            subagent_result = _extract_subagent_metadata(tool_call, result_str)
            if subagent_result:
                metadata = {"subagent_result": subagent_result}

        return ToolExecutionResult(
            output=result_str,
            final_answer=final_answer,
            review_request=review_request,
            hitl_signal=hitl_signal,
            metadata=metadata,
        )

    except Exception as e:
        logger.error(
            f"[tool_call] Execution failed for {tool_call.name}",
            error=str(e),
            tier=tier,
        )
        return ToolExecutionResult(
            output="",
            error=f"Tool execution failed: {str(e)}",
        )
