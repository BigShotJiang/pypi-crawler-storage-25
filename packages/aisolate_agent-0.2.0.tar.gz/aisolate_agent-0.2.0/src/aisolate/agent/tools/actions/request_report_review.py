"""Request report review action — submits a report for QA before delivery."""

from textwrap import dedent
from typing import Any, Dict
from aisolate.agent.tools.actions.base import CodeAction

# MIME type for review requests — distinct from final-answer so
# PythonExecutorTool sets `review_requested` instead of `is_final_answer`.
REVIEW_REQUEST_MIME = "application/vnd.aisolate.review-request+json"


class ScheduleReviewAction(CodeAction):
    """Submit a report for automated QA review before delivery.

    Identical parameter schema to ``FinalAnswerAction`` (``answer`` dict
    with ``result``, ``sources``, ``metadata``, ``handover``).  The only
    difference is the return signal: the result carries
    ``review_requested: true`` instead of ``is_final_answer: true``,
    causing ``ExecutingState`` to transition to the configured review
    state rather than ``FinishedState``.
    """

    name = "request_report_review"
    description = dedent(
        """
    Submit the completed report for automated QA review.

    You are personally responsible for the quality of every report you deliver.
    Use this action to submit your report for quality review before it reaches
    the user. This is mandatory for all report deliveries.

    Two outcomes:

    • APPROVED — the report is delivered to the user (you are done).
    • REJECTED — you receive a message with specific deficiencies.
      Re-delegate to report_agent to address them, then call
      `request_report_review` again.

    The `answer` parameter has exactly the same structure as `final_answer`.
    """
    ).strip()
    parameters = {
        "type": "object",
        "properties": {
            "answer": {
                "type": ["object"],
                "description": dedent(
                    """
                    Report payload to submit for Quality Assurance (QA) review.

                    REQUIRED KEYS
                    - result: str — The complete report markdown.

                    OPTIONAL KEYS
                    - sources: list[dict] — Each source must have type, url, info.
                    - metadata: dict — Execution context and run details.
                    - handover: dict — Declared kernel variables for parent agent.
                    """
                ).strip(),
            }
        },
        "required": ["answer"],
    }
    output_type = "object"
    requirements = []

    def __init__(self):
        super().__init__()

    def execute(self, answer: Dict[str, Any]) -> Dict[str, Any]:
        """Validate the answer and emit it as a review request.

        Uses a dedicated MIME type so the framework can distinguish
        review requests from final answers at the transport layer.
        """
        if answer is None:
            raise ValueError(
                "Answer cannot be None. Expected dict with 'result' field.\n"
                "Example: {'result': 'Your report here', 'sources': [], 'metadata': {}}"
            )

        if not isinstance(answer, dict):
            raise TypeError(
                f"Answer must be a dict, got {type(answer).__name__}.\n"
                "Expected structure: {{'result': str, 'sources': list, 'metadata': dict}}"
            )

        if "result" not in answer:
            raise ValueError(
                f"Missing required field 'result' in answer dict.\n"
                f"Received keys: {list(answer.keys())}"
            )

        result = answer["result"]
        if not isinstance(result, str):
            raise TypeError(
                f"Field 'result' must be a string, got {type(result).__name__}."
            )

        if not result.strip():
            raise ValueError("Field 'result' cannot be empty or whitespace-only.")

        sources = answer.get("sources", [])
        if not isinstance(sources, list):
            raise TypeError(
                f"Field 'sources' must be a list, got {type(sources).__name__}."
            )

        for idx, source in enumerate(sources):
            if not isinstance(source, dict):
                raise TypeError(f"Source at index {idx} must be a dict.")
            missing = [f for f in ("type", "url", "info") if f not in source]
            if missing:
                raise ValueError(
                    f"Source at index {idx} is missing required fields: {missing}"
                )

        metadata = answer.get("metadata", {})
        if not isinstance(metadata, dict):
            raise TypeError(
                f"Field 'metadata' must be a dict, got {type(metadata).__name__}."
            )

        handover = answer.get("handover")
        if handover is not None:
            if not isinstance(handover, dict):
                raise TypeError(
                    f"Field 'handover' must be a dict, got {type(handover).__name__}."
                )
            if not handover:
                raise ValueError("Handover dict must not be empty.")
            for var_name, var_desc in handover.items():
                if not isinstance(var_name, str) or not var_name:
                    raise ValueError(
                        f"Handover key must be a non-empty string, got {repr(var_name)}"
                    )
                if not isinstance(var_desc, str) or not var_desc:
                    raise ValueError(
                        f"Handover value for '{var_name}' must be a non-empty "
                        f"description string, got {repr(var_desc)[:200]}"
                    )

            try:
                ip = get_ipython()  # noqa: F821
                missing = [k for k in handover if k not in ip.user_ns]
                if missing:
                    available = sorted(
                        k for k in ip.user_ns
                        if not k.startswith('_') and k not in (
                            'In', 'Out', 'exit', 'quit', 'get_ipython',
                        )
                    )
                    raise ValueError(
                        f"Handover declares variables not found in kernel: {missing}\n"
                        f"Available user variables: {available[:30]}"
                    )
            except NameError:
                pass  # Not in IPython (e.g., unit test)

        final_answer_data = {
            "result": result,
            "sources": sources,
            "metadata": metadata,
        }
        if handover is not None:
            final_answer_data["handover"] = handover

        try:
            from IPython.display import display

            display(
                {

                    "application/vnd.aisolate.review-request+json": final_answer_data,
                    "text/plain": result,
                },
                raw=True,
            )
        except ImportError:
            print(f"REQUEST_REPORT_REVIEW: {final_answer_data}")

        return final_answer_data
