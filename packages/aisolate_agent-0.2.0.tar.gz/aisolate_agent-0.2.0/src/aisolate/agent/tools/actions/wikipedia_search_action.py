from .base import CodeAction

class WikipediaSearchAction(CodeAction):
    """
    Minimal Wikipedia fetch for LLM agents (Jupyter-friendly).

    Returns a plain dict with just what an agent needs:
      {
        "ok": True/False,
        "title": str,
        "url": str,
        "summary_md": str,       # short intro (Markdown)
        "chunks_md": [str, ...], # full article (Markdown) split in 5,000-char chunks
        "redirected_from": str | None
      }

    Efficient usage:
      - Quick relevance check: read `summary_md`. If it's not useful, stop.
      - Need details: iterate `chunks_md` in order; each is ≤ 5,000 chars.
      - Only the intro? Construct with `content_type="summary"` and use `summary_md`.

    Example:
      from aisolate.action import wikipedia_search
      result = wikipedia_search(query="Python_(programming_language)")
      print(result["title"])
      print(result["summary_md"])
      for chunk in result["chunks_md"][:1]:
          print(chunk[:500])
    """

    # Tool metadata
    name = "wikipedia_search"
    description = (
        "Fetch a Wikipedia page and return a dict with summary_md and 5k-char chunks_md. "
        "Use summary for fast triage; read chunks sequentially for details."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Wikipedia page title (use underscores for spaces, e.g. 'Python_(programming_language)')."
            }
        },
        "required": ["query"],
    }
    output_type = "object"                 # return a dict (not a JSON string)
    requirements = ["wikipedia-api", "markdownify"]  # ✱ no fallback, markdownify is required

    def __init__(
        self,
        user_agent: str = "",
        language: str = "",
        content_type: str = "",
        extract_format: str = "",
    ):
        # Keep signature EXACTLY as-is; fixed behavior inside.
        import os
        self.user_agent = (
            user_agent
            or f"AiSolate/1.0 ({os.getenv('WIKIPEDIA_USER_AGENT_CONTACT', 'contact@aisolate.dev')})"
        )
        self.language = language or os.getenv("WIKIPEDIA_LANGUAGE", "en")
        self.content_type = content_type or os.getenv("WIKIPEDIA_CONTENT_TYPE", "text")
        # Ignore any passed extract_format; always use HTML and convert to Markdown.
        self.extract_format_str = "HTML"

        if self.content_type not in ("summary", "text"):
            raise ValueError("content_type must be either 'summary' or 'text'")

        # Fixed chunk size, as requested (no config/env)
        self._CHUNK_SIZE = 5000

        self.wiki = None
        super().__init__()

    def setup(self) -> None:
        """Initialize the Wikipedia API client (forced HTML extracts)."""
        try:
            import wikipediaapi
        except ImportError as e:
            raise ImportError("Install `wikipedia-api`: pip install wikipedia-api") from e

        extract_format = wikipediaapi.ExtractFormat.HTML
        self.wiki = wikipediaapi.Wikipedia(
            user_agent=self.user_agent,
            language=self.language,
            extract_format=extract_format,
        )

    # ---------- helpers (all inside the class; imports inline) ----------

    def _html_to_markdown(self, html: str) -> str:
        """Convert HTML to Markdown using markdownify (required; no fallback)."""
        if not html:
            return ""
        import markdownify  # required by `requirements`
        return markdownify.markdownify(html, heading_style="ATX", strip=["style", "script"])

    def _chunk_fixed(self, text: str):
        """Split text into fixed 5,000-char chunks (no overlap)."""
        if not text:
            return []
        size = self._CHUNK_SIZE
        return [text[i:i + size] for i in range(0, len(text), size)]

    # ---------- main ----------

    def execute(self, query: str):
        """Fetch, convert to Markdown, and return a minimal dict with 5k-chunked content."""
        if not query:
            return {"ok": False, "error": "no_query"}

        if self.wiki is None:
            return {"ok": False, "error": "client_not_initialized"}

        # Keep notebook stdout clean from library prints
        import io, contextlib
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                page = self.wiki.page(query)
        except Exception as e:
            return {"ok": False, "error": "exception", "detail": str(e), "query": query}

        if not page or not page.exists():
            return {"ok": False, "error": "not_found", "query": query}

        title = page.title
        url = page.fullurl

        # Summary (Markdown)
        summary_md = self._html_to_markdown(page.summary or "")

        # Body (Markdown) → fixed 5,000-char chunks or empty if summary-only
        if self.content_type == "summary":
            chunks_md = []
        else:
            full_html = page.text or ""
            full_md = self._html_to_markdown(full_html)
            chunks_md = self._chunk_fixed(full_md)

        return {
            "ok": True,
            "title": title,
            "url": url,
            "summary_md": summary_md,
            "chunks_md": chunks_md,  # list[str], each ≤ 5,000 chars
            "redirected_from": query if (title and query and title.strip() != query.strip()) else None,
        }
