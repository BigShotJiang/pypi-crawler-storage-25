import textwrap
import inspect
import typing as t
from typing import Any, get_args, get_origin, get_type_hints, List, Dict
from abc import ABC, abstractmethod


AUTHORIZED_OUTPUT_TYPES: set[str] = {
    "string",
    "number",
    "integer",
    "boolean",
    "object",
    "array",
    "null",
}


def _is_optional(tp: Any) -> bool:
    if tp is None or tp is inspect._empty:
        return False
    return get_origin(tp) is t.Union and type(None) in get_args(tp)


def _schema_allows_null(prop: dict) -> bool:
    tfield = prop.get("type")
    if tfield == "null":
        return True
    if isinstance(tfield, list) and "null" in tfield:
        return True
    for key in ("anyOf", "oneOf"):
        if key in prop and any(
            isinstance(i, dict) and i.get("type") == "null" for i in prop[key]
        ):
            return True
    return False


class ActionValidator:
    """External validator for Action-like objects."""

    @classmethod
    def validate(cls, action: Any) -> Any:
        """
        Validate an Action instance.
        Raises ValueError/TypeError on problems; returns the instance on success.
        """
        cls._validate_fields_shape(action)
        cls._validate_signature_vs_schema(action)
        return action

    # ---- field-level checks (no Pydantic dependency here) ----
    @classmethod
    def _validate_fields_shape(cls, action: Any) -> None:
        # name
        name = getattr(action, "name", None)
        if (
            not isinstance(name, str)
            or not name
            or (not name.isidentifier())
            or name in __import__("keyword").kwlist
        ):
            raise ValueError(
                f"Invalid action name '{name}': must be a valid Python identifier and not a keyword."
            )

        # output_type
        output_type = getattr(action, "output_type", None)
        if output_type not in AUTHORIZED_OUTPUT_TYPES:
            raise ValueError(
                f"Invalid output_type '{output_type}'. Must be one of {sorted(AUTHORIZED_OUTPUT_TYPES)}."
            )

        # parameters
        params = getattr(action, "parameters", None)
        if not isinstance(params, dict):
            raise TypeError("`parameters` must be a dict (JSON Schema).")
        if params.get("type") != "object":
            raise ValueError("`parameters.type` must be 'object'.")
        props = params.get("properties")
        if not isinstance(props, dict):
            raise ValueError("`parameters.properties` must be a dict.")
        req = params.get("required")
        if req is not None and (
            not isinstance(req, list) or not all(isinstance(x, str) for x in req)
        ):
            raise ValueError(
                "`parameters.required` must be a list of strings if provided."
            )

    # ---- signature ↔ schema checks ----
    @classmethod
    def _validate_signature_vs_schema(cls, action: Any) -> None:
        if getattr(action.__class__, "skip_execute_signature_validation", False):
            return

        # Read schema bits (safe due to _validate_fields_shape)
        schema = action.parameters
        schema_props: dict = schema.get("properties", {})
        required = set(schema.get("required", []) or [])

        # Introspect execute(...)
        sig = inspect.signature(action.__class__.execute)
        params = [p for p in sig.parameters.values() if p.name != "self"]

        # no *args/**kwargs
        bad = [
            p for p in params if p.kind not in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)
        ]
        if bad:
            names = ", ".join(p.name for p in bad)
            raise TypeError(f"`execute` has unsupported parameter kinds for: {names}.")

        # names must match schema properties
        prop_keys = set(schema_props.keys())
        actual_keys = {p.name for p in params}
        if actual_keys != prop_keys:
            raise ValueError(
                f"`execute` parameters {sorted(actual_keys)} must match JSON-Schema properties {sorted(prop_keys)}."
            )

        # names must match schema properties (only for non-**kwargs signatures)
        prop_keys = set(schema_props.keys())
        actual_keys = {p.name for p in params}
        if actual_keys != prop_keys:
            raise ValueError(
                f"`execute` parameters {sorted(actual_keys)} must match JSON-Schema properties {sorted(prop_keys)}."
            )

        # required vs default, nullability (only for non-**kwargs signatures)
        hints = get_type_hints(action.__class__.execute)
        for p in params:
            name = p.name
            schema_prop = schema_props.get(name, {})
            is_optional = _is_optional(hints.get(name, None))
            schema_nullable = _schema_allows_null(schema_prop)

            # required flag alignment
            is_required_by_sig = p.default is inspect._empty
            if is_required_by_sig and name not in required:
                raise TypeError(
                    f"Parameter '{name}' has no default but is not in JSON-Schema `required`."
                )
            if not is_required_by_sig and name in required:
                raise TypeError(
                    f"Parameter '{name}' has a default but is marked required in JSON Schema."
                )

            # nullability alignment
            if is_optional and not schema_nullable:
                raise TypeError(
                    f"Parameter '{name}' is Optional[...] but the schema does not allow null."
                )
            if schema_nullable and not is_optional:
                raise TypeError(
                    f"Schema for '{name}' allows null, but annotation for '{name}' is not Optional[...]."
                )


# Convenience free function
def validate(action: Any) -> Any:
    return ActionValidator.validate(action)


def _schema_type_as_str(prop: dict) -> str:
    t = prop.get("type")
    types: list[str] = []
    if isinstance(t, str):
        if t != "null":
            types = [t]
    elif isinstance(t, list):
        types = [x for x in t if x != "null"]
    else:
        for key in ("anyOf", "oneOf"):
            if key in prop:
                types = [
                    i.get("type", "any")
                    for i in prop[key]
                    if isinstance(i, dict) and i.get("type") != "null"
                ]
                break
    return " | ".join(types) if types else "any"


class CodeAction(ABC):
    """
    Abstract base class that all actions must implement.
    Provides clear interface and validation for action implementations.
    """

    # Required class attributes - users must set these
    name: str = ""
    description: str = ""
    parameters: Dict[str, Any] = {}
    output_type: str = "string"
    requirements: List[str] = []

    def __init__(self):
        self.is_initialized = False
        # Validate that required attributes are set
        self._validate_required_attributes()

    def _validate_required_attributes(self) -> None:
        """Ensure user provided required metadata"""
        if not self.name:
            raise ValueError(
                f"{self.__class__.__name__} must set 'name' class attribute"
            )
        if not self.description:
            raise ValueError(
                f"{self.__class__.__name__} must set 'description' class attribute"
            )
        if not isinstance(self.parameters, dict):
            raise ValueError(f"{self.__class__.__name__} must set 'parameters' as dict")

        # Validate parameters is a proper JSON schema
        self._validate_parameters_schema()

        if self.output_type not in AUTHORIZED_OUTPUT_TYPES:
            raise ValueError(
                f"Invalid output_type '{self.output_type}'. Must be one of {sorted(AUTHORIZED_OUTPUT_TYPES)}."
            )

    def _validate_parameters_schema(self) -> None:
        """Validate that parameters follows JSON schema structure"""
        if not self.parameters:
            return  # Empty dict is valid for actions with no parameters

        # Must have type: object for actions
        if self.parameters.get("type") != "object":
            raise ValueError(
                f"{self.__class__.__name__} parameters must have 'type': 'object'"
            )

        # Must have properties dict
        properties = self.parameters.get("properties")
        if not isinstance(properties, dict):
            raise ValueError(
                f"{self.__class__.__name__} parameters must have 'properties' dict"
            )

        # Validate each property has required fields
        for prop_name, prop_schema in properties.items():
            if not isinstance(prop_schema, dict):
                raise ValueError(
                    f"{self.__class__.__name__} property '{prop_name}' must be a dict"
                )
            if "type" not in prop_schema:
                raise ValueError(
                    f"{self.__class__.__name__} property '{prop_name}' must have 'type'"
                )
            if "description" not in prop_schema:
                raise ValueError(
                    f"{self.__class__.__name__} property '{prop_name}' must have 'description'"
                )

        # Validate required field if present
        required = self.parameters.get("required", [])
        if not isinstance(required, list):
            raise ValueError(f"{self.__class__.__name__} 'required' must be a list")

        # Check that all required properties exist in properties
        for req_prop in required:
            if req_prop not in properties:
                raise ValueError(
                    f"{self.__class__.__name__} required property '{req_prop}' not found in properties"
                )

    def setup(self) -> None:
        """Optional: Override for one-time initialization"""
        pass

    @abstractmethod
    def execute(self, *args, **kwargs) -> Any:
        """Required: Implement the action logic

        NOTE: While this signature allows both *args and **kwargs for flexibility,
        implementations should use typed parameters that match their JSON schema.
        The __call__ method will handle the parameter mapping.

        Examples:
        - def execute(self, query: str) -> str:  # For web search
        - def execute(self, url: str) -> str:   # For webpage visit
        - def execute(self, city: str, units: str = "metric") -> str:  # For weather
        """
        pass

    def __call__(self, *args, **kwargs) -> Any:
        """Standard call interface - users don't need to override"""
        if not self.is_initialized:
            self.setup()
            self.is_initialized = True

        # Get the execute method signature for parameter mapping
        sig = inspect.signature(self.__class__.execute)
        params = [p for p in sig.parameters.values() if p.name != "self"]

        # Map positional args to parameter names based on schema order
        if args:
            schema_props = (self.parameters or {}).get("properties", {})
            prop_names = list(schema_props.keys())
            # Fall back to execute() signature order if no schema
            if not prop_names:
                prop_names = [p.name for p in params]
            for i, val in enumerate(args):
                if i < len(prop_names):
                    kwargs[prop_names[i]] = val

        # If execute method uses **kwargs pattern, pass all kwargs
        has_var_keyword = any(p.kind == p.VAR_KEYWORD for p in params)
        if has_var_keyword:
            return self.execute(**kwargs)

        # Otherwise, map kwargs to typed parameters
        bound_args = {}
        for param in params:
            if param.name in kwargs:
                bound_args[param.name] = kwargs[param.name]
            elif param.default is not inspect.Parameter.empty:
                bound_args[param.name] = param.default
            # Required params without values caught by signature validation

        return self.execute(**bound_args)

    def to_code_prompt(self) -> str:
        """
        Render a kernel-only usage stub:
        - Shows import & signature
        - States "NOT a tool"
        """
        params = self.parameters or {}
        props: dict = params.get("properties") or {}
        required = set(params.get("required") or [])

        # Signature text
        arg_parts = []
        for name, schema in props.items():
            typ = _schema_type_as_str(schema)
            nullable = _schema_allows_null(schema)
            ann = f"Optional[{typ}]" if nullable else typ
            default = " = None" if (nullable or name not in required) else ""
            arg_parts.append(f"{name}: {ann}{default}")
        args_sig = ", ".join(arg_parts) or ""
        tool_sig = f"{self.name}({args_sig}) -> {self.output_type}"

        # Args doc
        doc_lines = [(self.description or "").strip()]
        arg_doc_lines = []
        for name, schema in props.items():
            desc = (schema.get("description") or "").strip()
            if desc:
                arg_doc_lines.append(f"{name}: {desc}")
        if arg_doc_lines:
            doc_lines.append("")
            doc_lines.append("Args:")
            doc_lines.extend(f"    {line}" for line in arg_doc_lines)
        doc = "\n".join(doc_lines)

        # Build example call with placeholders for each parameter
        example_args = ", ".join([f"{n}=..." for n in props.keys()]) if props else ""

        return textwrap.dedent(
            f'''
            # {self.name} 
            {self.name} is a CODE ACTION (python jupyter kernel-only)
            Not a tool. Do not call via `functions.*.  Execute via `to=python`.

            from aisolate.action import {self.name}

            """{doc}"""

            Signature: {tool_sig}

            Example:
            result = {self.name}({example_args})
        '''
        ).strip()

    def to_dict(self) -> dict:
        """
        Serializes the tool into a dictionary containing its source code
        and requirements.
        """
        try:
            # Get the full source code of the concrete subclass (e.g., MyTool)
            source_code = textwrap.dedent(inspect.getsource(self.__class__))
        except (TypeError, OSError) as e:
            # This can fail if the class is defined in a REPL or dynamically.
            raise RuntimeError(
                f"Could not get source code for '{self.__class__.__name__}'. "
                "Please define tools in a .py file."
            ) from e

        return {
            "name": self.name,
            "code": source_code,
            "requirements": self.requirements,
        }


# External validation function
def validate_action(action: CodeAction) -> CodeAction:
    """Validate an action implementation"""
    ActionValidator.validate(action)
    return action


# def get_action_definition_code(actions: List[CodeAction]) -> str:
#     """Generate executable code for actions using imports for core and source for custom actions"""
#     if not actions:
#         return ""

#     # Get source code for custom user-defined actions
#     action_sources = []
#     instantiations = []

#     for action in actions:
#         try:
#             source = textwrap.dedent(inspect.getsource(action.__class__))
#             action_sources.append(source)
#             instantiations.append(f"{action.name} = {action.__class__.__name__}()")
#         except (TypeError, OSError):
#             raise RuntimeError(f"Could not get source for {action.__class__.__name__}")

#     # Header with imports - use installed aisolate for base framework
#     header = (
#         "# Import base framework from installed aisolate\n"
#         "import os\n"
#         "from textwrap import dedent\n"
#         "from typing import Any, Dict, List, Union, Optional\n"
#         "from aisolate.agent.tools.actions.base import CodeAction\n\n"
#     )

#     return (
#         header
#         + "# User-defined action classes\n"
#         + "\n\n".join(action_sources)
#         + "\n\n"
#         + "# Create action instances\n"
#         + "\n".join(instantiations)
#     )


def get_action_definition_code(actions: List[CodeAction]) -> str:
    """Generate executable code for actions and expose them as `from aisolate.action import <name>`."""
    if not actions:
        return ""

    import inspect
    import textwrap

    # --- gather source + instantiations exactly like you had ---
    action_sources = []
    instantiations = []
    for action in actions:
        try:
            source = textwrap.dedent(inspect.getsource(action.__class__))
            action_sources.append(source)
            instantiations.append(f"{action.name} = {action.__class__.__name__}()")
        except (TypeError, OSError):
            raise RuntimeError(f"Could not get source for {action.__class__.__name__}")

    header = (
        "# Import base framework from installed aisolate\n"
        "import sys, types\n"
        "import os\n"
        "import time\n"
        "from textwrap import dedent\n"
        "from typing import Any, Dict, List, Union, Optional\n"
        "from aisolate.agent.tools.actions.base import CodeAction\n"
        # Common runtime libraries pre-imported into the kernel so action
        # `execute()` bodies can use them without a per-call inline import.
        # Both packages live in `aisolate/sandbox/requirements.txt` and are
        # baked into the sandbox image — actions therefore do not need to
        # declare them in their `requirements = [...]` lists.
        "import pandas as pd\n"
        "import requests\n\n"
    )

    # Build a registry mapping for export
    # e.g. {"websearch": websearch, "final_answer": final_answer}
    export_map_entries = ",\n        ".join(
        [f"{action.name!r}: {action.name}" for action in actions]
    )
    export_names_list = ", ".join([repr(a.name) for a in actions])

    module_injection = f"""
# === Export actions as importable module: `aisolate.action` ===
# Registry of instances defined above
_registry = {{
        {export_map_entries}
}}

def _make_wrapper(name, inst):
    # Turn an action instance into a plain function the agent can call.
    def _fn(*args, **kwargs):
        if hasattr(inst, "run"):
            return inst.run(*args, **kwargs)
        elif hasattr(inst, "__call__"):
            return inst(*args, **kwargs)
        elif hasattr(inst, "execute"):
            return inst.execute(*args, **kwargs)
        raise TypeError(f"Action '{{name}}' is not callable")
    _fn.__name__ = name
    _fn.__doc__ = getattr(inst, "description", None) or f"Wrapper for action '{{name}}'."
    return _fn

# Create (or replace) the submodule
try:
    import aisolate as _aisolate_pkg  # real installed top-level package
except Exception:
    _aisolate_pkg = types.ModuleType("aisolate")
    sys.modules.setdefault("aisolate", _aisolate_pkg)

_mod = types.ModuleType("aisolate.action")

# Export both wrapper functions and raw instances
for _n, _inst in _registry.items():
    setattr(_mod, _n, _make_wrapper(_n, _inst))            # callable: websearch(...)
    setattr(_mod, _n + "_instance", _inst)                  # instance: websearch_instance

_mod.__all__ = [{export_names_list}] + [n + "_instance" for n in _registry]

# Register module so `from aisolate.action import websearch` works
sys.modules["aisolate.action"] = _mod
setattr(_aisolate_pkg, "action", _mod)

# Mark framework-injected action names as hidden in the IPython user
# namespace. The checkpoint hook already excludes anything tracked in
# ``user_ns_hidden`` (same mechanism IPython uses for its own internals
# like ``In`` / ``Out``), so action instances stay out of kernel pickles
# and get re-instantiated fresh by ``send_actions`` on every kernel
# start — keeping per-turn config (e.g. scoped API tokens) current.
try:
    _ip = get_ipython()  # noqa: F821 — provided by IPython at runtime
    for _action_name in _registry:
        if _action_name in _ip.user_ns:
            _ip.user_ns_hidden[_action_name] = _ip.user_ns[_action_name]
except (NameError, AttributeError):
    pass
# === end export block ===
"""

    return (
        header
        + "# User-defined action classes\n"
        + "\n\n".join(action_sources)
        + "\n\n# Create action instances\n"
        + "\n".join(instantiations)
        + "\n\n"
        + module_injection
    )
