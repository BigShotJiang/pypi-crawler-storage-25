"""Load handover data from a sibling agent's checkpoint.

This CodeAction runs inside the kernel and loads a subagent's persisted
data into a ``types.SimpleNamespace`` so the parent LLM can use it in
subsequent notebook cells:

    data = load_handover_data(agent_name="data_agent")
    combined = data.daily_agg.merge(my_costs, on="date")

When multiple invocations of the same sub-agent have completed in this
conversation, this action picks the **most recent** matching record. The
underlying registry (``_aisolate_handover_urls``) is a list keyed by both
``agent_name`` and the sub-agent's ``conversation_id``; the action filters
by ``agent_name`` and selects the latest entry.

Hot path (same container): reads ``/tmp/handover_{agent_name}.pkl``.
Cold path (HITL resume / new container): downloads via the presigned
URL injected by the framework into ``_aisolate_handover_urls``.
"""

from textwrap import dedent

from aisolate.agent.tools.actions.base import CodeAction


class LoadHandoverAction(CodeAction):
    """Load a sibling agent's handover data into a namespace."""

    name = "load_handover_data"
    description = dedent(
        """
    Load data from a sibling subagent's handover checkpoint into a namespace.
    Returns a SimpleNamespace whose attributes are the subagent's variables.

    Usage in notebook code:
        data = load_handover_data(agent_name="data_agent")
        df = data.daily_agg
        raw = data.raw_df
    """
    ).strip()

    parameters = {
        "type": "object",
        "properties": {
            "agent_name": {
                "type": "string",
                "description": "Name of the subagent whose handover data to load",
            },
        },
        "required": ["agent_name"],
    }
    output_type = "string"
    requirements = ["dill", "requests"]

    def __init__(self):
        super().__init__()

    def execute(self, agent_name: str):
        """Load the most recent handover from this agent into a SimpleNamespace.

        Tries the local hot path first (``/tmp/handover_{agent_name}.pkl``),
        then falls back to downloading via the pre-injected presigned URL.

        Args:
            agent_name: Name of the subagent whose data to load.

        Returns:
            SimpleNamespace with the subagent's handed-over variables as attributes.
        """
        import types
        import os
        import dill

        namespace_name = f"handover_{agent_name}"
        tmp_path = f"/tmp/handover_{agent_name}.pkl"

        # Hot path: local file (same container)
        if not os.path.exists(tmp_path):
            # Cold path: look up the registry by agent_name. The registry
            # is a dict keyed by agent_name (under auto-resume each agent
            # has at most one active sub-agent conversation in this scope).
            urls = globals().get("_aisolate_handover_urls", {})
            info = urls.get(agent_name) if isinstance(urls, dict) else None
            if not info or not info.get("url"):
                available = sorted(urls.keys()) if isinstance(urls, dict) else []
                raise FileNotFoundError(
                    f"No handover data from {agent_name!r}. "
                    f"Available agents: {available}"
                )
            import requests

            resp = requests.get(info["url"], timeout=120)
            resp.raise_for_status()
            with open(tmp_path, "wb") as f:
                f.write(resp.content)

        with open(tmp_path, "rb") as f:
            variables = dill.load(f)

        # Extract descriptions (embedded by _save_handover_checkpoint)
        descriptions = variables.pop("__descriptions__", {})

        ns = types.SimpleNamespace(**variables)

        # Register in user namespace + track for auto-exclusion from checkpoints
        ip = get_ipython()  # noqa: F821 — available inside IPython kernel
        ip.user_ns[namespace_name] = ns
        tracker = ip.user_ns.get("_aisolate_handover_namespaces", set())
        tracker.add(namespace_name)
        ip.user_ns["_aisolate_handover_namespaces"] = tracker

        # Print available attributes so the LLM sees exact names + descriptions
        attrs = sorted(variables.keys())
        lines = [f"Loaded handover from '{agent_name}' with {len(attrs)} variables:"]
        for attr in attrs:
            val = variables[attr]
            type_name = type(val).__name__
            shape_info = ""
            if hasattr(val, "shape"):
                shape_info = f", shape={val.shape}"
            elif hasattr(val, "__len__"):
                shape_info = f", len={len(val)}"
            desc = descriptions.get(attr, "")
            desc_suffix = f" — {desc}" if desc else ""
            lines.append(f"  data.{attr}  ({type_name}{shape_info}){desc_suffix}")
        print("\n".join(lines))

        return ns
