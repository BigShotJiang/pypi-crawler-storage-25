import os
from typing import Any, Optional
from textwrap import dedent
from .base import CodeAction


class WebSearchAction(CodeAction):
    """Platform tool for web searching using Brave Search API."""

    # Required metadata - clear and obvious what user must provide
    name = "web_search"
    description = dedent(
        """
        Use this function to find timely, up-to-date information or data sources online.
        It performs a web search for a given query and returns a list of the most relevant results.
        This should be one of the first steps for any research task.
        
        Example usage:
        from aisolage.action import web_search
        pages = web_search(query="latest research on renewable energy 2024")
        print(pages)
        """
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search query to perform.",
            }
        },
        "required": ["query"],
    }
    output_type = "string"
    requirements = ["requests"]

    def __init__(
        self,
        endpoint: str = "",
        api_key: str = "",
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
    ):
        # Clean initialization - no Pydantic constraints
        self.api_key = api_key or os.getenv("BRAVE_SEARCH_API_KEY", "")
        self.endpoint = endpoint or "https://api.search.brave.com/res/v1/web/search"
        self.headers = headers or {
            "X-Subscription-Token": self.api_key,
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
        }
        self.params = params or {"count": 10}

        # Call parent __init__ for validation
        super().__init__()

    def execute(self, query: str) -> str:
        """Execute web search with the given query"""
        if not query:
            return "Error: No search query provided"
        return self._perform_search(query)

    def _perform_search(self, query: str) -> str:
        import requests

        params = {**self.params, "q": query}
        try:
            response = requests.get(
                self.endpoint, headers=self.headers, params=params, timeout=20
            )
            response.raise_for_status()
            data = response.json()
            results = self._extract_results(data)
            return self._format_markdown(results)
        except requests.HTTPError as e:  # type: ignore
            status = getattr(response, "status_code", "?")  # type: ignore
            return f"Search failed: HTTP {status}"
        except Exception as e:  # pragma: no cover
            return f"Search failed: {str(e)}"

    def _extract_results(self, data: dict) -> list:
        results = []
        for result in data.get("web", {}).get("results", []):
            results.append(
                {
                    "title": result.get("title", ""),
                    "url": result.get("url", ""),
                    "description": result.get("description", ""),
                }
            )
        return results

    def _format_markdown(self, results: list) -> str:
        if not results:
            return "No results found."
        return "## Search Results\n\n" + "\n\n".join(
            [
                f"{idx}. [{r['title']}]({r['url']})\n{r['description']}"
                for idx, r in enumerate(results, start=1)
            ]
        )
