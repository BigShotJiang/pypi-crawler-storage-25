"""Final answer action for the agent system with artifact support."""

from textwrap import dedent
from typing import Any, Dict, Union
from aisolate.agent.tools.actions.base import CodeAction


class FinalAnswerAction(CodeAction):
    """Action for providing final answers with structured artifact support.

    This code action is executed in the notebook environment and produces
    dict objects with rich source attribution. Self-contained implementation
    that doesn't rely on external classes.

    Accepts multiple input formats:
    1. Dict with {"result": str, "sources": [...], "metadata": {...}}
    2. Plain string (wrapped in minimal dict structure)

    Validates and normalizes to ensure consistent artifact structure.
    """

    # Required metadata
    name = "final_answer"
    description = dedent(
        """
    Provides the final answer with optional sources and metadata. 
    Use ONLY when the task is complete and you are ready to return the result.

    STRICT OUTPUT CONTRACT
    - Top-level object must be a dict with:
    - result (str, REQUIRED): The actual answer text. Must be non-empty and come from a variable computed in this notebook (do NOT hardcode previously printed text).
    - sources (list, OPTIONAL): Each item is a dict with EXACTLY the required fields:
        • type (str) — e.g., 'artifact', 'document', 'data', 'api', 'web', 'database'
        • url (str)  — a resolvable or symbolic locator. If local/ephemeral, use a scheme like 'local://system_clock' or 'file:///path/to/file'
        • info (str) — short human-readable description
        Optional source fields that MAY be added: 
        • excerpt (str) • size (str)
        DO NOT include any other keys in a source (e.g., DO NOT put 'processing_method' inside a source).
    - metadata (dict, OPTIONAL): Execution context such as 'processing_method', parameters, counts, timings, etc.

    STATEFUL KERNEL RULES
    - Reuse variables computed earlier. If you created 'result_str', set 'result = result_str' and then use 'result' in the final output.
    - Never reconstruct values by retyping printed output.

    VALIDATION HINTS
    - If you have no external documents, still provide a well-formed source for local data, e.g.:
    {'type': 'data', 'url': 'local://system_clock', 'info': 'Derived from datetime.now() with zoneinfo Europe/Berlin'}.
    - Put run details (e.g., 'processing_method') under 'metadata', NOT inside 'sources'.
    """
    ).strip()
    parameters = {
        "type": "object",
        "properties": {
            "answer": {
                "type": ["object"],
                "description": dedent(
                    """
                    Final answer payload to emit. Must follow this EXACT structure:


                    REQUIRED KEYS
                    - result: str
                    • Non-empty, human-readable final text.
                    • Must reference an existing variable (e.g., `result`), not a hardcoded copy of printed output.

                    OPTIONAL KEYS
                    - sources: list[dict]
                    • Each source MUST include ALL of the following:
                        - type: str   (e.g., 'artifact', 'document', 'data', 'api', 'web', 'database')
                        - url: str    (absolute URL or symbolic locator like 'local://system_clock' or 'file:///...'; plain strings are allowed but MUST be present)
                        - info: str   (brief human-readable description)
                    • MAY include ONLY these optional fields:
                        - excerpt: str
                        - size: str
                    • MUST NOT include any other keys (e.g., DO NOT include 'processing_method' here).

                    - metadata: dict
                    • Execution context and run details (e.g., 'processing_method', parameters, counts, timings).
                    • If you need to record how the answer was produced, put it here.

                    - handover: dict
                    • Sub-agents MUST use this to declare computed data for the parent agent.
                    • When you compute any data (variables, DataFrames, strings, dicts, etc.), always declare a handover so the parent can reuse it directly.
                    • Each key is a kernel variable name, each value is a brief description of that variable.
                    • Example: {"daily_agg": "Daily energy aggregation DataFrame grouped by zone", "raw_df": "Raw meter readings before aggregation"}
                    • Set to null ONLY if you produced zero usable data (e.g., you only answered a knowledge question with no computation).
                    STATEFUL EXAMPLE (GOOD)
                    ```python
                    # earlier cell
                    result_str = f"The current time in Germany (Europe/Berlin) is {time_str}, UTC offset {offset[:3]}:{offset[3:]}."
                    result = result_str  # reuse state rather than hardcoding text

                    answer = {
                        "result": result,
                        "sources": [
                            {
                            "type": "data",
                            "url": "local://system_clock",
                            "info": "Derived from Python datetime.now() with zoneinfo Europe/Berlin"
                            }
                        ],
                        "metadata": {
                            "processing_method": "Python datetime with zoneinfo",
                            "timezone": "Europe/Berlin"
                        }
                    }
                    ```
                    BAD EXAMPLES (DO NOT DO)

                    Missing url in a source:
                    {"type": "data", "info": "Derived from system clock"} # 'url' missing

                    Putting 'processing_method' inside a source:
                    {"type": "data", "url": "local://system_clock", "info": "...", "processing_method": "pandas"} # move to metadata

                    Hardcoding previously printed output instead of reusing the variable:
                    "result": "The current time in Germany (Europe/Berlin) is ..." # use the variable 'result' you computed
                    """
                ).strip(),
            }
        },
        "required": ["answer"],
    }
    output_type = "object"
    requirements = []

    def __init__(self):
        super().__init__()

    def execute(self, answer: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the final answer action with strict validation.

        Args:
            answer: A dict from LLM-generated notebook code:
                - Dict: {"result": "...", "sources": [...], "metadata": {...}}

        Returns:
            Dict with structure (also displayed via IPython for proper kernel delivery):
                {
                    "result": str,
                    "sources": list,
                    "metadata": dict
                }

        Raises:
            TypeError: If answer is not a dict
            ValueError: If answer is missing required fields or has invalid structure

        Note:
            This function uses IPython.display to send the final answer as DisplayData
            with a custom MIME type, ensuring the dict structure is preserved when
            sent from kernel to client (rather than being serialized to a string).
        """
        # Validate input type
        if answer is None:
            raise ValueError(
                "Answer cannot be None. Expected dict with 'result', 'sources', and 'metadata' fields.\n"
                "Example: {'result': 'Your answer here', 'sources': [], 'metadata': {}}"
            )

        if not isinstance(answer, dict):
            raise TypeError(
                f"Answer must be a dict, got {type(answer).__name__}.\n"
                "Expected structure: {{'result': str, 'sources': list, 'metadata': dict}}\n"
                f"Received value: {repr(answer)[:200]}"
            )

        # Validate required field
        if "result" not in answer:
            raise ValueError(
                f"Missing required field 'result' in answer dict.\n"
                f"Received keys: {list(answer.keys())}\n"
                "Expected structure: {{'result': str, 'sources': list, 'metadata': dict}}\n"
                "The 'result' field must contain the actual answer text."
            )

        # Validate result field type
        result = answer["result"]
        if not isinstance(result, str):
            raise TypeError(
                f"Field 'result' must be a string, got {type(result).__name__}.\n"
                f"Received value: {repr(result)[:200]}"
            )

        if not result.strip():
            raise ValueError(
                "Field 'result' cannot be empty or whitespace-only.\n"
                "Please provide a meaningful answer."
            )

        # Validate sources field if present
        sources = answer.get("sources", [])
        if not isinstance(sources, list):
            raise TypeError(
                f"Field 'sources' must be a list, got {type(sources).__name__}.\n"
                f"Received value: {repr(sources)[:200]}\n"
                "Example: [{'type': 'artifact', 'url': '...', 'info': '...'}]"
            )

        # Validate each source entry
        for idx, source in enumerate(sources):
            if not isinstance(source, dict):
                raise TypeError(
                    f"Source at index {idx} must be a dict, got {type(source).__name__}.\n"
                    f"Received value: {repr(source)[:200]}\n"
                    "Each source must have: {{'type': str, 'url': str, 'info': str}}"
                )

            # Check required source fields
            required_source_fields = ["type", "url", "info"]
            missing_fields = [f for f in required_source_fields if f not in source]
            if missing_fields:
                raise ValueError(
                    f"Source at index {idx} is missing required fields: {missing_fields}\n"
                    f"Received keys: {list(source.keys())}\n"
                    "Each source must have: {{'type': str, 'url': str, 'info': str}}"
                )

        # Validate metadata field if present
        metadata = answer.get("metadata", {})
        if not isinstance(metadata, dict):
            raise TypeError(
                f"Field 'metadata' must be a dict, got {type(metadata).__name__}.\n"
                f"Received value: {repr(metadata)[:200]}\n"
                "Example: {{'processing_method': 'pandas', 'records_processed': 1000}}"
            )

        # Validate handover field if present
        handover = answer.get("handover")
        if handover is not None:
            if not isinstance(handover, dict):
                raise TypeError(
                    f"Field 'handover' must be a dict, got {type(handover).__name__}.\n"
                    f"Received value: {repr(handover)[:200]}"
                )
            if not handover:
                raise ValueError(
                    "Handover dict must not be empty. Each key should be a kernel "
                    "variable name and each value its description string.\n"
                    "Example: {'daily_agg': 'Daily aggregation DataFrame', 'raw_df': 'Raw data'}"
                )
            for var_name, var_desc in handover.items():
                if not isinstance(var_name, str) or not var_name:
                    raise ValueError(
                        f"Handover key must be a non-empty string, got {repr(var_name)}"
                    )
                if not isinstance(var_desc, str) or not var_desc:
                    raise ValueError(
                        f"Handover value for '{var_name}' must be a non-empty description string, "
                        f"got {repr(var_desc)[:200]}"
                    )

            # Verify all declared variables actually exist in the kernel
            try:
                ip = get_ipython()  # noqa: F821
                missing = [k for k in handover if k not in ip.user_ns]
                if missing:
                    available = sorted(
                        k for k in ip.user_ns
                        if not k.startswith('_') and k not in (
                            'In', 'Out', 'exit', 'quit', 'get_ipython',
                        )
                    )
                    raise ValueError(
                        f"Handover declares variables not found in kernel: {missing}\n"
                        f"Available user variables: {available[:30]}"
                    )
            except NameError:
                pass  # Not in IPython (e.g., unit test)

        # Build the final answer structure
        final_answer_data = {
            "result": result,
            "sources": sources,
            "metadata": metadata,
        }
        if handover is not None:
            final_answer_data["handover"] = handover

        # Send via IPython display with custom MIME type
        # This ensures the dict is preserved when sent from kernel to client
        # instead of being serialized to a string representation
        try:
            from IPython.display import display

            display(
                {
                    # Custom MIME type for final answers - preserves dict structure
                    "application/vnd.aisolate.final-answer+json": final_answer_data,
                    # Fallback to plain text for compatibility
                    "text/plain": result,
                },
                raw=True,
            )
        except ImportError:
            # Fallback if IPython not available (shouldn't happen in notebook)
            print(f"FINAL_ANSWER: {final_answer_data}")

        # Also return the dict so it can be used in the notebook if needed
        return final_answer_data
