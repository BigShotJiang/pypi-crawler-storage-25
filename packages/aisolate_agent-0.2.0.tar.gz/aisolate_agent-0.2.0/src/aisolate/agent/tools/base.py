"""Base classes and protocols for the three-tier tool system."""

from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.context import AgentContext


class BaseTool(ABC):
    """Base class for all tools in the three-tier architecture.

    This is the foundational interface that all tool types must implement.
    Specific tool tiers (Platform, Function, Code Action) may extend this
    with additional requirements.
    """

    def __init__(self, name: str, description: str):
        self._name = name
        self._description = description

    @property
    def name(self) -> str:
        """The unique name of this tool."""
        return self._name

    @property
    def description(self) -> str:
        """A description of what this tool does."""
        return self._description

    @property
    @abstractmethod
    def tier(self) -> str:
        """Identify which tier this tool belongs to.

        Returns:
            One of: 'platform', 'function', 'subagent', 'action'
        """
        ...

    @abstractmethod
    async def execute(self, context: "AgentContext", **kwargs) -> Any:
        """Execute the tool with the given parameters.

        Args:
            context: Agent context containing state and other tools
            **kwargs: Tool-specific parameters

        Returns:
            Tool-specific result (usually string or JSON-serializable)
        """
        ...


# Re-export commonly used types
__all__ = ["BaseTool"]
