"""Function tool base (Tier 2) + decorator.

Function tools are user (or override) provided JSON-schema declared functions.
They can be sync or async callables. We validate their signature matches the
provided JSON schema so the LLM's arguments will align.
"""

from __future__ import annotations

import inspect
from typing import Any, Dict, Callable, Optional, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from ...core.context import AgentContext


class FunctionTool:
    def __init__(
        self,
        name: str,
        description: str,
        schema: Dict[str, Any],
        fn: Callable[..., Any],
        validate: bool = True,
    ) -> None:
        self.name = name
        self.description = description
        self.schema = schema
        self._fn = fn
        if validate:
            self._validate_signature()

    def _validate_signature(self) -> None:
        sig = inspect.signature(self._fn)
        params = [
            p
            for p in sig.parameters.values()
            if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)
        ]
        props = self.schema.get("properties", {}) or {}
        required = set(self.schema.get("required", []) or [])
        fn_param_names = {p.name for p in params}
        if fn_param_names != set(
            props.keys()
        ):  # parameter names must match schema properties
            raise ValueError(
                f"FunctionTool '{self.name}': function parameters {sorted(fn_param_names)} "
                f"must match schema properties {sorted(props.keys())}."
            )
        for p in params:
            is_required_by_sig = p.default is inspect._empty
            if is_required_by_sig and p.name not in required:
                raise ValueError(
                    f"Parameter '{p.name}' has no default but is not marked required in schema."
                )
            if (not is_required_by_sig) and p.name in required:
                raise ValueError(
                    f"Parameter '{p.name}' has a default but is marked required in schema."
                )

    def to_openai_spec(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.schema,
            },
        }

    def to_code_prompt(self) -> str:
        """Render a human-readable tool-stub for the planning prompt."""
        props = self.schema.get("properties", {}) or {}
        required = set(self.schema.get("required", []) or [])

        arg_parts = []
        for pname, pschema in props.items():
            typ = pschema.get("type", "any")
            default = "" if pname in required else " = None"
            arg_parts.append(f"{pname}: {typ}{default}")
        sig = ", ".join(arg_parts)

        doc_lines = [(self.description or "").strip()]
        for pname, pschema in props.items():
            desc = (pschema.get("description") or "").strip()
            if desc:
                doc_lines.append(f"  {pname}: {desc}")

        doc = "\n".join(doc_lines)
        return f'def {self.name}({sig}):\n    """{doc}"""'

    async def execute(self, _agent_context: "AgentContext", **kwargs: Any) -> Any:
        result = self._fn(**kwargs)
        if inspect.isawaitable(result):
            return await result
        return result


def function_tool(
    *,
    name: Optional[str] = None,
    description: str,
    schema: Dict[str, Any],
    validate: bool = True,
):
    """Decorator that converts a plain function into a FunctionTool instance."""

    def wrap(fn: Callable[..., Any]) -> FunctionTool:
        return FunctionTool(
            name=name or fn.__name__,
            description=description,
            schema=schema,
            fn=fn,
            validate=validate,
        )

    return wrap
