"""HITL (Human-in-the-Loop) function tools.

Factory functions that create ``FunctionTool`` instances for asking the user
questions or requesting confirmation. The tools return a JSON string with
``hitl_signal: true`` which is detected by ``extract_hitl_signal()`` in the
execution pipeline, causing the agent to pause and wait for user input.
"""

from __future__ import annotations

import json
from .base import FunctionTool


def _ask_user_fn(question: str, options: list = None, context: str = "", multi_select: bool = False) -> str:
    """Return a HITL signal as JSON. No sandbox execution needed."""
    return json.dumps({
        "hitl_signal": True,
        "signal_type": "ask_user",
        "question": question,
        "options": options or [],
        "context": context,
        "multi_select": multi_select,
    })


def create_ask_user_tool() -> FunctionTool:
    """Create the ``ask_user`` function tool."""
    return FunctionTool(
        name="ask_user",
        description=(
            "Ask the user a question ONLY when you absolutely cannot proceed "
            "without their input. You are an autonomous agent — make decisions "
            "yourself whenever possible. NEVER use this tool for: formatting "
            "preferences, language choices, stylistic decisions, level of "
            "detail, or anything you can reasonably decide. ONLY use this "
            "when the user's core intent is genuinely unclear and you would "
            "produce fundamentally wrong results without clarification "
            "(e.g., which specific meter to analyze when multiple exist, or "
            "the user's message is too vague to determine ANY actionable goal). "
            "Maximum 1 question per conversation — after that, proceed with "
            "your best judgment."
        ),
        schema={
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The question to ask the user",
                },
                "options": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of suggested answers",
                },
                "context": {
                    "type": "string",
                    "description": "Why this information is needed",
                },
                "multi_select": {
                    "type": "boolean",
                    "description": "If true, the user can select multiple options (checkboxes). Default false (single selection).",
                    "default": False,
                },
            },
            "required": ["question"],
        },
        fn=_ask_user_fn,
    )


def _confirm_fn(question: str, risk_level: str = "medium") -> str:
    """Return a HITL confirmation signal as JSON."""
    return json.dumps({
        "hitl_signal": True,
        "signal_type": "confirm",
        "question": question,
        "risk_level": risk_level,
    })


def create_confirm_tool() -> FunctionTool:
    """Create the ``confirm`` function tool."""
    return FunctionTool(
        name="confirm",
        description=(
            "Ask the user for explicit confirmation ONLY before destructive "
            "or irreversible actions (e.g., deleting data, overwriting "
            "records). Do NOT use for read-only operations, analysis, or "
            "report generation."
        ),
        schema={
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "What the user needs to confirm",
                },
                "risk_level": {
                    "type": "string",
                    "enum": ["low", "medium", "high"],
                    "description": "Risk level of the action",
                },
            },
            "required": ["question"],
        },
        fn=_confirm_fn,
    )
