"""Tool routing and discovery logic."""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..core.context import AgentContext


def find_tool_tier(context: "AgentContext", tool_name: str) -> Optional[str]:
    """Find which tier/registry contains the given tool.

    Args:
        context: AgentContext containing tool registries
        tool_name: Name of the tool to find

    Returns:
        Tier name ('subagent', 'builtin', 'function', 'action')
        or None if not found
    """
    # Check sub-agent tools
    if tool_name in context.sub_agent_tools:
        return "subagent"

    # Check builtin tools
    for tool in context.builtin_tools:
        if hasattr(tool, "name") and tool.name == tool_name:
            return "builtin"

    # Check function tools
    for tool in context.function_tools:
        if hasattr(tool, "name") and tool.name == tool_name:
            return "function"

    # Check actions
    if tool_name in context.actions:
        return "action"

    return None


def get_tool_by_name(context: "AgentContext", tool_name: str):
    """Get tool instance by name.

    Args:
        context: AgentContext containing tool registries
        tool_name: Name of the tool to retrieve

    Returns:
        Tool instance or None if not found
    """
    # Check sub-agent tools
    if tool_name in context.sub_agent_tools:
        return context.sub_agent_tools[tool_name]

    # Check builtin tools
    for tool in context.builtin_tools:
        if hasattr(tool, "name") and tool.name == tool_name:
            return tool

    # Check function tools
    for tool in context.function_tools:
        if hasattr(tool, "name") and tool.name == tool_name:
            return tool

    # Check actions
    if tool_name in context.actions:
        return context.actions[tool_name]

    return None
