"""Data models for the tool system."""

from dataclasses import dataclass, asdict
from typing import Any, Optional, List
import json


@dataclass
class ToolCall:
    """Represents a tool invocation from the LLM.

    This provides a type-safe way to pass tool call information
    between LLM strategies and tool execution logic.

    Attributes:
        name: Name of the tool to invoke
        arguments: Arguments to pass to the tool (as dict)
        tool_call_id: Optional provider-specific call ID
            (e.g., OpenAI's tool_call_id)
    """

    name: str
    arguments: dict[str, Any]
    tool_call_id: Optional[str] = None

    def __post_init__(self):
        """Validate tool call structure."""
        if not self.name:
            raise ValueError("Tool name cannot be empty")
        if not isinstance(self.arguments, dict):
            raise TypeError("Arguments must be a dictionary")

    @classmethod
    def from_dict(cls, data: dict) -> "ToolCall":
        """Create ToolCall from dictionary (e.g., from LLM response).

        Args:
            data: Dictionary containing tool call data

        Returns:
            ToolCall instance
        """
        return cls(
            name=data.get("name", ""),
            arguments=data.get("arguments", {}),
            tool_call_id=data.get("tool_call_id"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization.

        Returns:
            Dictionary representation of the tool call
        """
        return asdict(self)


@dataclass
class FinalAnswerResult:
    """Represents a final answer extracted from tool execution.

    This is populated when a tool (typically PythonExecutorTool) returns
    a result that indicates a final answer has been provided.

    Attributes:
        answer: The final answer text to return to the user
        sources: Optional list of sources/citations that support the answer
        confidence: Optional confidence score (0.0 to 1.0)
        metadata: Optional additional metadata about the answer
    """

    answer: str
    sources: Optional[List[dict]] = None
    confidence: Optional[float] = None
    metadata: Optional[dict] = None
    handover: Optional[dict] = None


def serialize_final_answer(result: FinalAnswerResult) -> str:
    """Serialize FinalAnswerResult to JSON string.

    Used by sub-agents to return structured results to parent agents.

    Args:
        result: FinalAnswerResult object to serialize

    Returns:
        JSON string representation of the result
    """
    return json.dumps(asdict(result))


def deserialize_final_answer(json_str: str) -> FinalAnswerResult:
    """Deserialize JSON string to FinalAnswerResult.

    Used by parent agents to reconstruct FinalAnswerResult from
    sub-agent responses.

    Args:
        json_str: JSON string containing final answer data

    Returns:
        FinalAnswerResult object

    Raises:
        ValueError: If JSON is invalid or missing required fields
    """
    try:
        data = json.loads(json_str)
        if not isinstance(data, dict):
            raise ValueError("Expected JSON object")
        if "answer" not in data:
            raise ValueError("Missing required 'answer' field")
        return FinalAnswerResult(**data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    except TypeError as e:
        raise ValueError(f"Invalid FinalAnswerResult data: {e}") from e


@dataclass
class HITLSignal:
    """A human-in-the-loop signal extracted from tool execution."""

    signal_type: str  # "ask_user" | "confirm"
    data: dict  # signal-specific payload
    requires_response: bool = True


@dataclass
class ToolExecutionResult:
    """Result of tool execution.

    Attributes:
        output: String result from tool execution
        final_answer: Optional final answer if tool produced one
        hitl_signal: Optional HITL signal if tool triggered human input
        error: Optional error message if execution failed
        metadata: Optional structured data for event streaming (e.g. subagent results)
    """

    output: str
    final_answer: Optional[FinalAnswerResult] = None
    review_request: Optional[FinalAnswerResult] = None
    hitl_signal: Optional[HITLSignal] = None
    error: Optional[str] = None
    metadata: Optional[dict] = None

    @property
    def success(self) -> bool:
        """Whether tool execution succeeded."""
        return self.error is None
