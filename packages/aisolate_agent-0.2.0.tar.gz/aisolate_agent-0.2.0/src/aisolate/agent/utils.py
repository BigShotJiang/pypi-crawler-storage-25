# utils.py
import os
import yaml
import importlib
import importlib.resources
from pathlib import Path
from dotenv import load_dotenv
import structlog

from .logging import LoggingConfig, LoggerFactory, get_logger

# Global setup state
_logging_initialized = False


def get_logger(name: str):
    """Get a unified logger that supports both standard and custom logging APIs.

    This is the primary function for getting loggers in the agent module.
    The returned logger supports:
    - Standard logging API: logger.info(), logger.error(), etc.
    - Custom methods: logger.log_model_response(), logger.log_tool_call(), etc.
    - Context binding: logger.bind(key=value)

    Args:
        name: Logger name (e.g., "aisolate.agent.core")

    Returns:
        UnifiedLogger instance
    """
    _ensure_logging_setup()
    from .logging.unified_logger import get_logger as _get_unified_logger

    return _get_unified_logger(name)


def setup_logging(config: LoggingConfig | None = None) -> None:
    """Setup the logging system.

    Args:
        config: Optional logging configuration. If None, loads from environment.
    """
    global _logging_initialized

    if config is None:
        config = LoggingConfig.from_env()
    LoggerFactory.setup_logging(config)
    _logging_initialized = True


def _ensure_logging_setup():
    """Ensure logging is initialized."""
    global _logging_initialized
    if not _logging_initialized:
        setup_logging()


# Backward compatibility aliases - these are deprecated
def get_logger_instance():
    """DEPRECATED: Use get_logger() instead.

    This function is kept for backward compatibility during migration.
    It returns a unified logger for the main agent module.
    """
    import warnings

    warnings.warn(
        "get_logger_instance() is deprecated. Use get_logger('aisolate.agent') instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return get_logger("aisolate.agent")


def setup_environment() -> dict[str, str]:
    """Loads environment variables and returns a configuration dictionary."""
    load_dotenv()
    config = {
        "BASE_URL": os.getenv("OLLAMA_BASE_URL", "http://localhost:8000"),
        "MODEL": os.getenv("OLLAMA_MODEL", "gpt-oss:20b"),
        "BRAVE_SEARCH_API_KEY": os.getenv("BRAVE_SEARCH_API_KEY", ""),
    }
    return config


def load_prompt_templates() -> dict:
    """Loads prompt templates from the embedded YAML file."""
    files = importlib.resources.files("aisolate.agent.config.prompts")
    template_path = files.joinpath("code_agent.yaml")
    return yaml.safe_load(template_path.read_text())


def truncate(s: str, n: int = 200) -> str:
    """Safely truncates a string."""
    if s is None:
        return ""
    return s if len(s) <= n else s[:n] + f"...[truncated {len(s)-n} chars]"
