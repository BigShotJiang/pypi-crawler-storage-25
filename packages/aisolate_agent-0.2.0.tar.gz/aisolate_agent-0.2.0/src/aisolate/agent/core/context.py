"""Agent execution context - runtime state container with controller."""

from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import (
    Optional,
    Any,
    List,
    Dict,
    TYPE_CHECKING,
    Protocol,
)
from aisolate.client.sandbox import Sandbox

from .protocols import LLMStrategy, MemoryStrategy, State
from .exceptions import StateTransitionError, ContextValidationError
from .llm_response import TokenUsage
from .events import AgentEvent
from ..memory.models import Message, ConversationHistory
from ..tools.platform.python_executor import RemotePythonExecutor
from ..utils import get_logger

if TYPE_CHECKING:  # pragma: no cover
    from ..tools.models import FinalAnswerResult

logger = get_logger("aisolate.agent.core.context")


# ---- Policies & Result Types ----------------------------------------------


class TransitionPolicy(Protocol):
    def allow(self, from_state: Optional[State], to_state: State) -> bool: ...


class AlwaysAllowPolicy:
    def allow(self, from_state: Optional[State], to_state: State) -> bool:
        return True


@dataclass
class TurnResult:
    turn: int
    state: str
    finished: bool
    final_answer: Optional["FinalAnswerResult"]
    state_metadata: Optional[Dict[str, Any]] = None
    usage: Optional[TokenUsage] = None
    reasoning: Optional[str] = None


# ---- Execution Controller ------------------------------------------------


@dataclass
class ExecutionState:
    """Holds mechanical lifecycle counters & current state pointer."""

    turn: int
    max_turns: int
    finished: bool
    current_state: Optional[State] = None
    previous_state_name: Optional[str] = None
    state_hints: Optional[Dict[str, Any]] = None

    def __post_init__(self) -> None:
        """Initialize mutable default."""
        if self.state_hints is None:
            self.state_hints = {}

    def advance(self) -> None:
        if self.finished:
            return
        self.turn += 1
        if self.turn >= self.max_turns:
            self.finished = True

    def set_hint(self, key: str, value: Any) -> None:
        """Set a hint for the current state.

        Args:
            key: Hint identifier (e.g., 'tool_choice', 'reasoning_effort')
            value: Hint value (strategy-specific interpretation)
        """
        if self.state_hints is None:
            self.state_hints = {}
        self.state_hints[key] = value

    def get_hint(self, key: str, default: Any = None) -> Any:
        """Get a hint value, returning default if not found.

        Args:
            key: Hint identifier
            default: Default value if hint not set

        Returns:
            Hint value or default
        """
        if self.state_hints is None:
            return default
        return self.state_hints.get(key, default)

    def clear_hints(self) -> None:
        """Clear all hints (typically called on state transition)."""
        if self.state_hints is None:
            self.state_hints = {}
        else:
            self.state_hints.clear()


class AgentContext:
    """Holds runtime data; delegates lifecycle mechanics to ExecutionState.

    Responsibilities:
    - Store task, strategies, tools, actions, memory, conversation
    - Transition between State objects (policy-guarded)
    - Execute a single turn via the active State
    """

    def __init__(
        self,
        agent_name: str,
        task: str,
        llm: LLMStrategy,
        memory: MemoryStrategy,
        sandbox: Optional[Sandbox] = None,
        max_turns: int = 10,
        conversation_id: Optional[str] = None,
        sub_agent_tools: Optional[Dict[str, Any]] = None,
        builtin_tools: Optional[List[Any]] = None,
        function_tools: Optional[List[Any]] = None,
        actions: Optional[Dict[str, Any]] = None,
        transition_policy: Optional[TransitionPolicy] = None,
        remote_python_executor: Optional[RemotePythonExecutor] = None,
        parent_context: Optional["AgentContext"] = None,
    ) -> None:
        # Strategies
        self.llm = llm
        self.memory = memory

        # Core descriptors
        self.task = task
        self.conversation_id = conversation_id
        self.conversation_history = ConversationHistory(max_length=1000)

        # Memory / result
        self.agent_name = agent_name
        self._final_answer: Optional["FinalAnswerResult"] = None

        # Sandbox / code executor (may be set later via set_sandbox for lazy init)
        self.sandbox = sandbox
        if remote_python_executor:
            self.remote_python_executor = remote_python_executor
        elif sandbox:
            self.remote_python_executor = RemotePythonExecutor(sandbox, [])
        else:
            self.remote_python_executor = None

        # Tools & actions
        self.sub_agent_tools = sub_agent_tools or {}
        self.builtin_tools = list(builtin_tools or [])
        self.function_tools = list(function_tools or [])
        self.actions = actions or {}

        # Execution controller
        self.execution = ExecutionState(
            turn=0, max_turns=max_turns, finished=False, current_state=None
        )
        self._policy: TransitionPolicy = transition_policy or AlwaysAllowPolicy()

        # Parent context for traceability (used by sub-agents)
        self.parent_context = parent_context

        # Token usage tracking
        self._cumulative_usage = TokenUsage()
        self._last_turn_usage: Optional[TokenUsage] = None
        self._last_turn_reasoning: Optional[str] = None

        # Kernel state checkpoint tracking
        self.checkpoint_key: Optional[str] = None
        self.checkpoint_manifest: Optional[List[Dict[str, Any]]] = None

        # Follow-up tracking: stores the prior final answer text when
        # the user sends a follow-up message after a completed conversation.
        self.prior_final_answer: Optional[str] = None

        # HITL (Human-in-the-Loop) state
        self.pending_hitl_signal: Optional[Any] = None
        self.hitl_resume_state: Optional[str] = None

        # Handover registry keyed by agent_name. Each value:
        # {conversation_id, checkpoint_key, manifest, finished_at}.
        # Populated by SubAgentTool.execute on completion. Under
        # auto-resume-by-name there's at most one active sub-agent
        # conversation per agent_name, so a dict is the natural shape.
        self.handover_runs: Dict[str, Dict[str, Any]] = {}

        # Review state: optional state class inserted before FinishedState.
        # When set, ExecutingState transitions here instead of FinishedState
        # on request_report_review, allowing a QA/critic review loop.
        self.review_state: Optional[type] = None
        self.review_count: int = 0
        self.max_reviews: int = 2

        # How the agent exited: "final_answer", "request_report_review", or None
        self.exit_method: Optional[str] = None

        # File resolver for URL → bytes (used by CriticState for images)
        self.file_resolver: Optional[Any] = None

        # Per-model token usage breakdown for multi-model cost attribution
        self._usage_by_model: Dict[str, TokenUsage] = {}

        # Channel for sub-agent progress events (drained by the streaming loop)
        self.event_channel: asyncio.Queue[AgentEvent] = asyncio.Queue()

    def set_sandbox(self, sandbox: Sandbox) -> None:
        """Attach sandbox and create the remote executor (for deferred init).

        Used when sandbox creation runs in parallel with planning so the
        context can be constructed before the sandbox is ready.
        """
        self.sandbox = sandbox
        if self.remote_python_executor is None:
            self.remote_python_executor = RemotePythonExecutor(sandbox, [])
        else:
            self.remote_python_executor.sbx = sandbox

    # ---- Properties (compat with previous API) ----
    @property
    def turn(self) -> int:
        return self.execution.turn

    @property
    def max_turns(self) -> int:
        return self.execution.max_turns

    @property
    def is_finished(self) -> bool:
        """Check if execution is finished.

        Returns True if execution.finished flag is set (max turns, explicit finish, or final answer).
        Single source of truth for execution control.
        """
        return self.execution.finished

    @property
    def _state(self) -> Optional[State]:  # legacy private accessor
        return self.execution.current_state

    @property
    def final_answer(self) -> Optional["FinalAnswerResult"]:
        """Get the final answer result."""
        return self._final_answer

    @final_answer.setter
    def final_answer(self, value: Optional["FinalAnswerResult"]) -> None:
        """Set the final answer.

        Args:
            value: FinalAnswerResult object or None to clear
        """
        self._final_answer = value

    # ---- Conversation helpers ----
    def initialize_conversation(self, initial_messages: List[Message]) -> None:
        """Initialize conversation history with messages from Agent."""
        self.conversation_history.extend_messages(initial_messages)

    def get_conversation_messages(self) -> List[Message]:
        return self.conversation_history.to_list()

    def add_conversation_message(self, message: Message) -> None:
        self.conversation_history.add_message(message)

    def extend_conversation_messages(self, messages: List[Message]) -> None:
        self.conversation_history.extend_messages(messages)

    # ---- Token usage tracking ----
    def accumulate_usage(self, usage: TokenUsage, model: Optional[str] = None) -> None:
        """Add a turn's token usage to the cumulative total.

        Args:
            usage: Token counts for this call.
            model: Model name for per-model breakdown. When provided,
                   usage is also recorded in ``_usage_by_model``.
        """
        self._cumulative_usage += usage
        self._last_turn_usage = usage
        if model:
            existing = self._usage_by_model.get(model, TokenUsage())
            self._usage_by_model[model] = existing + usage

    @property
    def cumulative_usage(self) -> TokenUsage:
        """Cumulative token usage across all turns."""
        return self._cumulative_usage

    @property
    def usage_by_model(self) -> Dict[str, TokenUsage]:
        """Per-model token usage breakdown."""
        return dict(self._usage_by_model)

    @property
    def last_turn_usage(self) -> Optional[TokenUsage]:
        """Token usage from the most recent LLM call, if reported."""
        return self._last_turn_usage

    def set_last_reasoning(self, reasoning: Optional[str]) -> None:
        """Store the reasoning text from the most recent LLM call."""
        self._last_turn_reasoning = reasoning

    @property
    def last_turn_reasoning(self) -> Optional[str]:
        """Reasoning / chain-of-thought from the most recent LLM call."""
        return self._last_turn_reasoning

    def set_conversation_history(self, messages: List[Message]) -> None:
        self.conversation_history.clear()
        self.conversation_history.extend_messages(messages)

    # ---- Snapshot conversion methods ----
    def create_snapshot(self) -> "AgentSnapshot":  # type: ignore
        """Create AgentSnapshot from current context state.

        Captures complete state for persistence/restoration.
        Does NOT include events - those are added by caller.

        Returns:
            AgentSnapshot with current state
        """
        from dataclasses import asdict
        from .snapshot import AgentSnapshot

        if not self.conversation_id:
            raise ContextValidationError(
                validation_type="snapshot",
                reason="Cannot create snapshot without conversation_id",
            )

        return AgentSnapshot(
            conversation_id=self.conversation_id,
            turn=self.execution.turn,
            conversation_history=[
                msg.to_dict() for msg in self.get_conversation_messages()
            ],
            finished=self.is_finished,
            final_answer=asdict(self.final_answer) if self.final_answer else None,
            turn_events=[],  # Events added by caller
            agent_name=self.agent_name,
            execution_time_ms=0,  # Will be updated by caller with actual timing
            max_turns=self.max_turns,
            token_usage=self._cumulative_usage.to_dict(),
            checkpoint_key=self.checkpoint_key,
            checkpoint_manifest=self.checkpoint_manifest,
            original_task=self.task,
            handover_runs=self.handover_runs if self.handover_runs else None,
            pending_hitl_signal=(
                self.pending_hitl_signal.__dict__
                if self.pending_hitl_signal
                else None
            ),
            hitl_resume_state=self.hitl_resume_state,
            previous_state_name=self.execution.previous_state_name,
        )

    @classmethod
    def from_snapshot(
        cls,
        snapshot: "AgentSnapshot",  # type: ignore
        agent_name: str,
        task: str,
        llm: LLMStrategy,
        memory: MemoryStrategy,
        sandbox: Optional[Sandbox] = None,
        max_turns: int = 10,
        sub_agent_tools: Optional[Dict[str, Any]] = None,
        builtin_tools: Optional[List[Any]] = None,
        function_tools: Optional[List[Any]] = None,
        actions: Optional[Dict[str, Any]] = None,
        transition_policy: Optional[TransitionPolicy] = None,
        remote_python_executor: Optional[RemotePythonExecutor] = None,
    ) -> "AgentContext":
        """Restore AgentContext from snapshot with smart state handling.

        Creates new context with state from snapshot.
        - If snapshot.finished = True: Reset to Planning (new task on completed conversation)
        - If snapshot.finished = False: Preserve turn for resumption (state reset to Planning for now)

        Args:
            snapshot: AgentSnapshot to restore from
            (other args same as __init__)

        Returns:
            AgentContext with restored state
        """
        from openai_harmony import Message
        from ..states.planning import PlanningState

        # Create base context
        context = cls(
            agent_name=agent_name,
            task=task,
            llm=llm,
            memory=memory,
            sandbox=sandbox,
            max_turns=max_turns,
            conversation_id=snapshot.conversation_id,
            sub_agent_tools=sub_agent_tools,
            builtin_tools=builtin_tools,
            function_tools=function_tools,
            actions=actions,
            transition_policy=transition_policy,
            remote_python_executor=remote_python_executor,
        )

        # Restore state from snapshot
        context.execution.turn = snapshot.turn

        # Always reset execution.finished to allow continuation
        context.execution.finished = False

        # Smart state restoration: reset to Planning if conversation was completed
        if snapshot.finished:
            # Completed conversation: start fresh with new planning
            context.transition_to(PlanningState())
        else:
            # Interrupted conversation: preserve turn, reset to Planning (TODO: restore actual state)
            context.transition_to(PlanningState())

        # Restore conversation history (using from_dict because messages are serialized with to_dict())
        messages = [
            Message.from_dict(msg_data) for msg_data in snapshot.conversation_history
        ]
        context.set_conversation_history(messages)

        # Restore final answer if present (for context/display)
        if snapshot.final_answer:
            from ..tools.models import FinalAnswerResult

            context._final_answer = FinalAnswerResult(**snapshot.final_answer)

        return context

    def set_final_answer(self, answer: "FinalAnswerResult") -> None:
        """Set the final answer and mark execution as finished.

        Args:
            answer: FinalAnswerResult object with answer text and optional metadata
        """
        self.final_answer = answer
        self.execution.finished = True

    # ---- State hints ----
    def set_state_hint(self, key: str, value: Any) -> None:
        """Set a hint for strategy behavior.

        States can use this to communicate preferences to strategies
        without creating direct dependencies.

        Args:
            key: Hint identifier (e.g., 'tool_choice', 'reasoning_effort')
            value: Hint value (strategy-specific interpretation)
        """
        self.execution.set_hint(key, value)

    def get_state_hint(self, key: str, default: Any = None) -> Any:
        """Get a state hint value.

        Strategies can read hints to adjust their behavior without
        knowing about state implementation details.

        Args:
            key: Hint identifier
            default: Default value if hint not set

        Returns:
            Hint value or default
        """
        return self.execution.get_hint(key, default)

    # ---- State transitions ----
    def transition_to(self, new_state: State) -> None:
        old = self.execution.current_state
        old_name = type(old).__name__ if old else "None"
        new_name = type(new_state).__name__
        logger.debug(f"Transitioning from {old_name} to {new_name}")
        if not self._policy.allow(old, new_state):
            raise StateTransitionError(
                from_state=old_name,
                to_state=new_name,
                reason="Transition policy rejected transition",
            )

        # Record previous state for resume detection
        self.execution.previous_state_name = old_name

        # Clear hints on transition
        self.execution.clear_hints()
        self.execution.current_state = new_state

        # Allow new state to set its hints
        if hasattr(new_state, "on_enter"):
            new_state.on_enter(self)  # Non-async hint setting

    # ---- Turn execution ----
    async def execute_turn(self) -> TurnResult:
        if self.is_finished or self.execution.finished:
            # Already done; produce terminal result (no state advance)
            return TurnResult(
                turn=self.execution.turn,
                state=(
                    type(self.execution.current_state).__name__
                    if self.execution.current_state
                    else "None"
                ),
                finished=True,
                final_answer=self.final_answer,
            )

        if self.execution.current_state is None:
            raise ContextValidationError(
                validation_type="state",
                reason="No state set for agent context",
            )

        # Advance counters
        self.execution.advance()

        # Capture state name BEFORE execution (since state may transition during handle())
        executing_state_name = type(self.execution.current_state).__name__

        logger.log_conversation_step(
            self.execution.turn,
            self.execution.max_turns,
            f"Executing {executing_state_name}",
        )

        # Pre-condition hook (optional on state)
        if hasattr(self.execution.current_state, "_pre_condition_check"):
            pre_ok = await self.execution.current_state._pre_condition_check(
                self
            )  # type: ignore[attr-defined]
            if not pre_ok:
                raise ContextValidationError(
                    validation_type="pre_condition",
                    reason=(
                        f"Pre-condition check failed for " f"{executing_state_name}"
                    ),
                )

        # Execute
        state_result = await self.execution.current_state.handle(self)  # type: ignore

        # Sync finish flag if final answer produced or max turns hit.
        # BUT: when a review state is pending (CriticState), the final_answer
        # is set as a draft for the critic to inspect — do NOT finish yet.
        from ..states.critic import CriticState as _CriticState
        review_pending = isinstance(self.execution.current_state, _CriticState)
        if (self.final_answer and not review_pending) or self.execution.finished:
            self.execution.finished = True

        # Extract metadata from state result
        state_metadata = state_result.metadata if state_result else None

        return TurnResult(
            turn=self.execution.turn,
            state=executing_state_name,  # Use captured state name from before execution
            finished=self.is_finished,
            final_answer=self.final_answer,
            state_metadata=state_metadata,
            usage=self._last_turn_usage,
            reasoning=self._last_turn_reasoning,
        )
