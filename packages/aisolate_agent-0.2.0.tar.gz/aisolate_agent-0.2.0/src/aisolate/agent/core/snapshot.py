"""AgentSnapshot - single source of truth for agent state."""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, TYPE_CHECKING
from datetime import datetime

if TYPE_CHECKING:
    from .events import AgentEvent


class AgentSnapshot(BaseModel):
    """Complete agent state snapshot - single source of truth.

    This model contains EVERYTHING needed to:
    - Restore agent execution
    - Replay events for frontend
    - Debug agent behavior
    - Display UI state

    IMPORTANT: Events are STORED, not derived. Each turn's execution produces
    real-time events with metadata that cannot be reconstructed from final state.
    """

    # Identity
    conversation_id: str = Field(..., description="Conversation identifier")
    turn: int = Field(..., description="Current turn number")
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    # Context state (REQUIRED)
    conversation_history: List[Dict[str, Any]] = Field(
        ..., description="Complete dialogue history (serialized Message objects)"
    )
    finished: bool = Field(default=False, description="Execution completed flag")
    final_answer: Optional[Dict[str, Any]] = Field(
        None, description="FinalAnswerResult if agent finished"
    )

    # Execution trace (ACTUAL events, not derived)
    turn_events: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Actual events that occurred this turn (TurnCompletedEvent, etc.)",
    )

    # Metadata
    agent_name: str = Field(..., description="Agent identifier")
    execution_time_ms: int = Field(
        0, description="Total execution time in milliseconds"
    )
    max_turns: int = Field(10, description="Maximum turns allowed")
    token_usage: Optional[Dict[str, int]] = Field(
        None,
        description="Cumulative token usage {input_tokens, output_tokens, reasoning_tokens}",
    )

    # Kernel state checkpoint (optional — present when checkpoint was taken)
    checkpoint_key: Optional[str] = Field(
        None,
        description="Object storage key for the dill checkpoint file",
    )
    checkpoint_manifest: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Variable metadata: [{name, type, shape/len}, ...] for LLM context",
    )

    # Original task (preserved across HITL round-trips)
    original_task: Optional[str] = Field(
        None,
        description="The user's original question/task, preserved so it survives HITL resume where context.task becomes the HITL answer",
    )

    # Handover registry: completed sub-agent runs in this conversation,
    # keyed by agent_name. Each value: {conversation_id, checkpoint_key,
    # manifest, finished_at}. Under auto-resume-by-name, each agent_name
    # has at most one active conversation in the parent's scope, so the
    # dict shape is the natural fit (no list/append/dedup logic needed).
    handover_runs: Optional[Dict[str, Dict[str, Any]]] = Field(
        None,
        description=(
            "Completed sub-agent runs keyed by agent_name. Values: "
            "{conversation_id, checkpoint_key, manifest, finished_at}. "
            "Used to re-sign download URLs on resume and to drive auto-"
            "resume-by-name in SubAgentTool.execute."
        ),
    )

    # HITL state (optional — present when agent is paused for user input)
    pending_hitl_signal: Optional[Dict[str, Any]] = Field(
        None,
        description="Pending HITL signal data if agent is paused for user input",
    )
    hitl_resume_state: Optional[str] = Field(
        None,
        description="State name to resume at after HITL response",
    )
    previous_state_name: Optional[str] = Field(
        None,
        description="Name of the state before the current one (for resume detection)",
    )

    def add_event(self, event: "AgentEvent") -> None:
        """Add event that occurred during this turn.

        Events contain runtime metadata (tool calls, errors, etc.) that
        cannot be reconstructed from final state alone.
        """
        self.turn_events.append(event.__dict__)

    def get_events(self) -> List[Dict[str, Any]]:
        """Get events for this turn.

        Returns stored events, not derived ones.
        """
        return self.turn_events

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }
