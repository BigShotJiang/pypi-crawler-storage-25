"""Core protocols for the agent system."""

from typing import Protocol, Any, Optional, Dict, List, TYPE_CHECKING, Union
from abc import abstractmethod

# A type-checker-only import to resolve a circular dependency,
# creating no runtime coupling and preserving dependency inversion.
if TYPE_CHECKING:
    from .context import AgentContext
    from .llm_response import LLMResponse
    from ..memory.models import Message
    from ..tools.models import ToolCall, FinalAnswerResult
    from ..states.base import StateResult


class State(Protocol):
    """Protocol for a state in the agent's lifecycle."""

    async def handle(self, context: "AgentContext") -> Optional["StateResult"]:
        """Execute the logic for this state and handle transitions.

        Returns:
            Optional StateResult with metadata about execution
        """
        ...

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        """Validate preconditions before state execution."""
        ...

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> bool:
        """Validate postconditions after state execution."""
        ...

    def on_enter(self, context: "AgentContext") -> None:
        """Called when entering this state (for setting hints).

        States can override this to set strategy hints.
        Default implementation does nothing.

        Args:
            context: AgentContext to set hints on
        """
        ...


class LLMStrategy(Protocol):
    """Protocol for interacting with an LLM using structured messages."""

    async def generate_response(self, context: "AgentContext") -> "LLMResponse":
        """Generate a response from the LLM based on the agent's history."""
        ...

    def prepare_initial_history(self, context: "AgentContext") -> List["Message"]:
        """Creates the initial message history for the planning phase."""
        ...

    def prepare_clarification_history(self, context: "AgentContext") -> List["Message"]:
        """Creates the initial message history for the clarification phase."""
        ...

    def prepare_planning_history(
        self,
        context: "AgentContext",
        expert_analysis: str,
        user_answer: str,
    ) -> List["Message"]:
        """Creates the planning history with expert context folded in."""
        ...

    def prepare_execution_history(
        self,
        context: "AgentContext",
        plan: str,
    ) -> List["Message"]:
        """Creates the message history to pivot from planning to execution."""
        ...

    def parse_assistant_response(
        self, messages: List["Message"]
    ) -> tuple[Optional["ToolCall"], Optional[str]]:
        """Parses a tool call or message content from an assistant's message.

        Returns:
            Tuple of (tool_call, message_content) where:
            - tool_call: ToolCall object if LLM wants to call a tool
            - message_content: String containing the message content
        """
        ...

    def create_tool_response_message(
        self, tool_name: str, result: Any, tool_call_id: Optional[str] = None
    ) -> Any:
        """Create a tool response message in provider-specific format.

        This method maintains model independence by allowing each strategy
        to create tool response messages in their own format (e.g., Harmony
        Message objects or OpenAI dicts).

        Args:
            tool_name: Name of the tool that was called
            result: The result returned by the tool
            tool_call_id: Optional ID of the tool call (required by some providers like OpenAI)

        Returns:
            Provider-specific message object (Message for Harmony, Dict for OpenAI)
        """
        ...

    @property
    def namespace_config(self) -> Dict[str, Any]:
        """Provider-specific namespace configuration.

        Returns:
            Dict with keys: separator, function_prefix, agent_prefix, tool_name_overrides
        """
        ...

    def get_tool_name(self, default_name: str) -> str:
        """Get provider-safe tool name, applying overrides for reserved names.

        Args:
            default_name: Default tool name

        Returns:
            Provider-specific safe name
        """
        ...

    @property
    def templates(self) -> Dict[str, Any]:
        """Template definitions for this strategy.

        Note: Strategies may or may not use templates internally.
        This property exposes templates for components that need them
        (like SubAgentTool), but doesn't mandate HOW they're used.

        Returns:
            Template dictionary, may be empty if strategy doesn't use templates
        """
        ...

    def format_subagent_task(
        self,
        agent_name: str,
        task: str,
        handover_runs: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> str:
        """Format a task for sub-agent execution (Solution 2).

        Args:
            agent_name: Name of the sub-agent
            task: Raw task description
            handover_runs: Optional registry of completed sub-agent runs in
                this conversation, keyed by agent_name. When provided, the
                formatted task will include the registry so the sub-agent
                knows which siblings it can ``load_handover_data`` from.

        Returns:
            Formatted task with provider-specific instructions
        """
        ...

    def format_subagent_report(self, agent_name: str, final_answer: str) -> str:
        """Format a sub-agent's result for the parent agent.

        Args:
            agent_name: Name of the sub-agent
            final_answer: Serialized FinalAnswerResult JSON

        Returns:
            Formatted report string for the parent LLM
        """
        ...


class MemoryStrategy(Protocol):
    """Protocol for agent state persistence using AgentSnapshot.

    Implementations manage snapshot storage (memory, database, file).
    All persistence goes through snapshots - no separate event tables.
    """

    async def save_snapshot(self, snapshot: "AgentSnapshot") -> None:  # type: ignore
        """Persist agent snapshot.

        Called automatically after each turn by Agent.

        Args:
            snapshot: Complete agent state to persist
        """
        ...

    async def load_latest_snapshot(
        self, conversation_id: str
    ) -> Optional[Any]:  # Returns AgentSnapshot
        """Load most recent snapshot for conversation.

        Args:
            conversation_id: Conversation identifier

        Returns:
            Latest snapshot or None if not found
        """
        ...

    async def load_snapshot_at_turn(
        self, conversation_id: str, turn: int
    ) -> Optional[Any]:  # Returns AgentSnapshot
        """Load snapshot at specific turn (for debugging/time-travel).

        Args:
            conversation_id: Conversation identifier
            turn: Turn number to restore

        Returns:
            Snapshot at turn or None if not found
        """
        ...

    async def get_available_turns(self, conversation_id: str) -> List[int]:
        """Get list of available turn numbers for conversation.

        Simple implementations may only return [latest_turn].
        Full implementations return complete history.

        Args:
            conversation_id: Conversation identifier

        Returns:
            List of available turn numbers (empty if conversation not found)
        """
        ...

    async def get_event_stream(self, conversation_id: str) -> List[Dict[str, Any]]:
        """Get complete event stream from all snapshots.

        This replaces querying a separate AgentEvent table.
        Events are STORED in snapshots, not computed on-demand.

        Args:
            conversation_id: Conversation identifier

        Returns:
            Complete event stream in chronological order (stored events)
        """
        ...


class Tool(Protocol):
    """Base protocol for all tool types in the three-tier architecture."""


class CheckpointStorage(Protocol):
    """Consumer-provided storage for kernel state checkpoints.

    aisolate calls get_upload_url/get_download_url and passes the resulting
    URLs into the sandbox kernel.  The kernel uploads/downloads directly —
    the binary never flows through the agent process.

    Implementations: MinIO presigned URLs, S3 presigned URLs, Azure SAS
    tokens, GCS signed URLs, or any HTTP-based object store.
    """

    async def get_upload_url(self, key: str, expires_seconds: int = 300) -> str:
        """Return a presigned PUT URL for the given object key."""
        ...

    async def get_download_url(self, key: str, expires_seconds: int = 300) -> str:
        """Return a presigned GET URL for the given object key."""
        ...

    @property
    def name(self) -> str:
        """The unique name of this tool."""
        ...

    @property
    def description(self) -> str:
        """A description of what this tool does."""
        ...

    @abstractmethod
    async def execute(self, context: "AgentContext", **kwargs) -> Any:
        """Execute the tool with the given parameters."""
        ...


class PlatformTool(Tool, Protocol):
    """Protocol for built-in platform tools."""

    @property
    def tier(self) -> str:
        """Returns 'platform' to identify this as a platform tool."""
        ...


class FileResolver(Protocol):
    """Resolve file URLs to raw bytes.

    Used by review states (e.g. CriticState) to fetch images from
    application-specific storage without the framework knowing about
    the storage backend or tenant isolation details.
    """

    async def resolve(self, url: str) -> bytes:
        """Resolve a file URL to its raw bytes."""
        ...


class FunctionTool(Tool, Protocol):
    """Protocol for JSON-schema based function tools."""

    @property
    def tier(self) -> str:
        """Returns 'function' to identify this as a function tool."""
        ...

    @property
    def schema(self) -> Dict[str, Any]:
        """JSON schema definition for this tool's parameters."""
        ...


class CodeAction(Tool, Protocol):
    """Protocol for Python kernel code actions."""

    @property
    def tier(self) -> str:
        """Returns 'action' to identify this as a code action."""
        ...

    @property
    def source_code(self) -> str:
        """Python source code for this action."""
        ...
