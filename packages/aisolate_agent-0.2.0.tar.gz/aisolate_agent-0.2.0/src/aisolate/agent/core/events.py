"""Direct typed events for agent streaming."""

from typing import Optional, Dict, Any, Union
from datetime import datetime
from dataclasses import asdict, is_dataclass
import json

from ..tools.models import FinalAnswerResult


def _serialize_event_data(obj: Any) -> Any:
    """Recursively serialize event data including dataclasses."""
    if is_dataclass(obj) and not isinstance(obj, type):
        return asdict(obj)
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: _serialize_event_data(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_serialize_event_data(item) for item in obj]
    else:
        return obj


class AgentEvent:
    """Base class for all agent events with automatic timestamping.

    Every emitted event carries the name of the emitting agent, so consumers
    can route or filter by emitter (e.g. "show only main_agent in the chat
    thread, route sub-agent traffic to a debug channel").
    """

    def __init__(self, event_type: str, agent_name: str = ""):
        self.type = event_type
        self.agent_name = agent_name
        self.timestamp = datetime.now()

    def to_sse(self) -> str:
        """Convert directly to SSE format with proper serialization."""
        data = {k: _serialize_event_data(v) for k, v in self.__dict__.items()}
        return f"data: {json.dumps(data)}\n\n"


class AgentStartedEvent(AgentEvent):
    def __init__(
        self,
        task: str = "",
        turn: int = 0,
        max_turns: int = 10,
        agent_name: str = "",
        conversation_id: Optional[str] = None,
    ):
        super().__init__("agent_started", agent_name=agent_name)
        self.task = task
        self.turn = turn
        self.max_turns = max_turns
        self.conversation_id = conversation_id


class TurnCompletedEvent(AgentEvent):
    def __init__(
        self,
        turn: int = 0,
        state: str = "",
        is_finished: bool = False,
        final_answer: Optional[FinalAnswerResult] = None,
        state_metadata: Optional[Dict[str, Any]] = None,
        usage: Optional[Dict[str, int]] = None,
        reasoning: Optional[str] = None,
        agent_name: str = "",
    ):
        super().__init__("turn_completed", agent_name=agent_name)
        self.turn = turn
        self.state = state
        self.is_finished = is_finished
        self.final_answer = final_answer
        self.state_metadata = state_metadata
        self.usage = usage
        self.reasoning = reasoning


class AgentFinishedEvent(AgentEvent):
    def __init__(
        self,
        final_answer: Optional[FinalAnswerResult] = None,
        total_turns: int = 0,
        execution_time: Optional[float] = None,
        total_usage: Optional[Dict[str, int]] = None,
        sub_agent_usage: Optional[Dict[str, Dict[str, int]]] = None,
        usage_by_model: Optional[Dict[str, Dict[str, int]]] = None,
        exit_method: Optional[str] = None,
        agent_name: str = "",
    ):
        super().__init__("agent_finished", agent_name=agent_name)
        self.final_answer = final_answer
        self.total_turns = total_turns
        self.execution_time = execution_time
        self.total_usage = total_usage
        self.sub_agent_usage = sub_agent_usage or {}
        self.usage_by_model = usage_by_model or {}
        self.exit_method = exit_method


class AgentErrorEvent(AgentEvent):
    def __init__(
        self,
        error: str = "",
        turn: int = 0,
        exception_type: Optional[str] = None,
        traceback: Optional[str] = None,
        agent_name: str = "",
    ):
        super().__init__("agent_error", agent_name=agent_name)
        self.error = error
        self.turn = turn
        self.exception_type = exception_type
        self.traceback = traceback


class HITLRequestEvent(AgentEvent):
    """Emitted when the agent pauses for human input."""

    def __init__(
        self,
        signal_type: str = "",
        question: str = "",
        options: Optional[list] = None,
        context: str = "",
        multi_select: bool = False,
        turn: int = 0,
        conversation_id: Optional[str] = None,
        agent_name: str = "",
    ):
        super().__init__("hitl_request", agent_name=agent_name)
        self.signal_type = signal_type
        self.question = question
        self.options = options
        self.context = context
        self.multi_select = multi_select
        self.turn = turn
        self.conversation_id = conversation_id


class SubAgentProgressEvent(AgentEvent):
    """Emitted per sub-agent turn for real-time progress visibility."""

    def __init__(
        self,
        agent_name: str = "",
        parent_turn: int = 0,
        sub_turn: int = 0,
        sub_max_turns: int = 0,
        state: str = "",
        usage: Optional[Dict[str, int]] = None,
        cumulative_usage: Optional[Dict[str, int]] = None,
    ):
        super().__init__("sub_agent_progress", agent_name=agent_name)
        self.parent_turn = parent_turn
        self.sub_turn = sub_turn
        self.sub_max_turns = sub_max_turns
        self.state = state
        self.usage = usage
        self.cumulative_usage = cumulative_usage or {}


class SubAgentStartedEvent(AgentEvent):
    """Emitted when a sub-agent invocation is about to begin.

    `resumed_from_turn` distinguishes fresh starts (None) from resumes (the
    snapshot's last turn number). Telemetry only — does not gate execution.
    """

    def __init__(
        self,
        conversation_id: str,
        agent_name: str,
        resumed_from_turn: Optional[int] = None,
    ):
        super().__init__("sub_agent_started", agent_name=agent_name)
        self.conversation_id = conversation_id
        self.resumed_from_turn = resumed_from_turn


class SubAgentFinishedEvent(AgentEvent):
    """Emitted when a sub-agent invocation has completed and its snapshot
    + checkpoint have been persisted.

    `persisted` is True on the success path. False indicates a write failure
    that wasn't recoverable; today the framework raises on such failures, so
    `persisted=False` reaches consumers only via future async-persistence
    backends.
    """

    def __init__(
        self,
        conversation_id: str,
        agent_name: str,
        usage: Optional[Dict[str, int]] = None,
        persisted: bool = True,
    ):
        super().__init__("sub_agent_finished", agent_name=agent_name)
        self.conversation_id = conversation_id
        self.usage = usage
        self.persisted = persisted


# Union type for all agent events
AgentStreamEvent = Union[
    AgentStartedEvent, TurnCompletedEvent, AgentFinishedEvent,
    AgentErrorEvent, HITLRequestEvent, SubAgentProgressEvent,
    SubAgentStartedEvent, SubAgentFinishedEvent,
]
