"""Unit tests for AgentSnapshot model."""

import pytest
from datetime import datetime
from aisolate.agent.core.snapshot import AgentSnapshot
from aisolate.agent.core.events import TurnCompletedEvent


class TestAgentSnapshot:
    """Test AgentSnapshot model functionality."""

    def test_create_empty_snapshot(self):
        """Test creating a snapshot with minimal data."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
        )

        assert snapshot.conversation_id == "test-123"
        assert snapshot.turn == 1
        assert snapshot.finished is False
        assert snapshot.final_answer is None
        assert len(snapshot.turn_events) == 0

    def test_add_event(self):
        """Test adding events to snapshot."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
        )

        event = TurnCompletedEvent(
            turn=1,
            state="PlanningState",
            is_finished=False,
            final_answer=None,
            state_metadata={"tool_calls": []},
        )

        snapshot.add_event(event)

        assert len(snapshot.turn_events) == 1
        stored_event = snapshot.turn_events[0]
        assert stored_event["turn"] == 1
        assert stored_event["state"] == "PlanningState"

    def test_get_events(self):
        """Test retrieving stored events."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
        )

        # Add multiple events
        for i in range(3):
            event = TurnCompletedEvent(
                turn=i + 1,
                state="PlanningState",
                is_finished=False,
            )
            snapshot.add_event(event)

        events = snapshot.get_events()
        assert len(events) == 3
        assert all(isinstance(e, dict) for e in events)

    def test_snapshot_serialization(self):
        """Test snapshot serialization to dict."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
            finished=False,
        )

        data = snapshot.model_dump()

        assert data["conversation_id"] == "test-123"
        assert data["turn"] == 1
        assert len(data["conversation_history"]) == 2
        assert "turn_events" in data

    def test_snapshot_deserialization(self):
        """Test creating snapshot from dict."""
        data = {
            "conversation_id": "test-123",
            "turn": 2,
            "timestamp": datetime.utcnow(),
            "agent_name": "test_agent",
            "conversation_history": [{"role": "user", "content": "Hello"}],
            "finished": False,
            "final_answer": None,
            "turn_events": [],
            "execution_time_ms": 1000,
            "max_turns": 10,
        }

        snapshot = AgentSnapshot(**data)

        assert snapshot.conversation_id == "test-123"
        assert snapshot.turn == 2
        assert len(snapshot.conversation_history) == 1

    def test_event_metadata_preserved(self):
        """Test that event metadata is preserved in storage."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
        )

        event = TurnCompletedEvent(
            turn=1,
            state="ExecutingState",
            is_finished=False,
            state_metadata={
                "tool_calls": [
                    {"tool": "python", "code": "print('hello')"},
                ],
                "reasoning": "Executing Python code",
            },
        )

        snapshot.add_event(event)

        stored = snapshot.turn_events[0]
        assert "state_metadata" in stored
        assert "tool_calls" in stored["state_metadata"]
        assert len(stored["state_metadata"]["tool_calls"]) == 1

    def test_snapshot_with_final_answer(self):
        """Test snapshot with final_answer."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=5,
            agent_name="test_agent",
            conversation_history=[],
            finished=True,
            final_answer={
                "answer": "The answer is 42",
                "sources": ["source1", "source2"],
                "confidence": 0.95,
            },
        )

        assert snapshot.finished is True
        assert snapshot.final_answer is not None
        assert snapshot.final_answer["answer"] == "The answer is 42"
        assert len(snapshot.final_answer["sources"]) == 2

    def test_snapshot_with_completed_state(self):
        """Test snapshot representing completed execution."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=10,
            agent_name="test_agent",
            conversation_history=[
                {"role": "user", "content": "Complete this task"},
                {"role": "assistant", "content": "Task completed"},
            ],
            finished=True,
            final_answer={"answer": "Done"},
        )

        assert snapshot.finished is True
        assert snapshot.turn == 10
        assert len(snapshot.conversation_history) == 2

    def test_large_snapshot_handling(self):
        """Test snapshot with many events."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=50,
            agent_name="test_agent",
            conversation_history=[],
        )

        # Add 50 events
        for i in range(50):
            event = TurnCompletedEvent(
                turn=i + 1,
                state="PlanningState",
                is_finished=False,
                state_metadata={"iteration": i},
            )
            snapshot.add_event(event)

        events = snapshot.get_events()
        assert len(events) == 50
        assert events[0]["state_metadata"]["iteration"] == 0
        assert events[49]["state_metadata"]["iteration"] == 49

    def test_snapshot_timestamp_handling(self):
        """Test that timestamp is set correctly."""
        before = datetime.utcnow()

        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
        )

        after = datetime.utcnow()

        assert before <= snapshot.timestamp <= after
