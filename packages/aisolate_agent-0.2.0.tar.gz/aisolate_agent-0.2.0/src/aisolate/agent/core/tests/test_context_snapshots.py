"""Test AgentContext snapshot conversion methods."""

import pytest
from unittest.mock import Mock, AsyncMock
from aisolate.agent.core.context import AgentContext
from aisolate.agent.core.snapshot import AgentSnapshot


class TestContextSnapshotConversion:
    """Test AgentContext snapshot creation and restoration."""

    @pytest.fixture
    def mock_context(self):
        """Create mock context for testing."""
        llm = Mock()
        memory = Mock()
        sandbox = Mock()

        context = AgentContext(
            agent_name="test_agent",
            task="Test task",
            llm=llm,
            memory=memory,
            sandbox=sandbox,
            conversation_id="test-123",
            max_turns=10,
        )

        return context

    def test_create_snapshot_empty(self, mock_context):
        """Test creating snapshot from fresh context."""
        snapshot = mock_context.create_snapshot()

        assert snapshot.conversation_id == "test-123"
        assert snapshot.turn == 0  # Fresh context starts at 0
        assert snapshot.agent_name == "test_agent"
        assert snapshot.finished is False
        assert len(snapshot.turn_events) == 0

    def test_create_snapshot_with_history(self, mock_context):
        """Test snapshot creation with conversation history."""
        from openai_harmony import Message, Role, Author, TextContent

        # Add messages
        messages = [
            Message(author=Author(role=Role.USER), content=[TextContent(text="Hello")]),
            Message(
                author=Author(role=Role.ASSISTANT),
                content=[TextContent(text="Hi there")],
            ),
        ]
        mock_context.set_conversation_history(messages)

        snapshot = mock_context.create_snapshot()

        assert len(snapshot.conversation_history) == 2
        # Verify messages are properly serialized (model_dump() format)
        assert snapshot.conversation_history[0]["author"]["role"] == "user"
        assert snapshot.conversation_history[1]["author"]["role"] == "assistant"

    def test_create_snapshot_finished(self, mock_context):
        """Test snapshot with finished state."""
        from aisolate.agent.tools.models import FinalAnswerResult

        # Mark as finished
        mock_context.execution.finished = True
        mock_context._final_answer = FinalAnswerResult(answer="Test answer")

        snapshot = mock_context.create_snapshot()

        assert snapshot.finished is True
        assert snapshot.final_answer is not None
        assert snapshot.final_answer["answer"] == "Test answer"

    def test_from_snapshot_restoration(self):
        """Test restoring context from snapshot."""
        # Snapshot should use model_dump() format
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=3,
            agent_name="test_agent",
            conversation_history=[
                {
                    "author": {"role": "user"},
                    "content": [{"text": "Hello", "type": "text"}],
                },
                {
                    "author": {"role": "assistant"},
                    "content": [{"text": "Hi", "type": "text"}],
                },
                {
                    "author": {"role": "user"},
                    "content": [{"text": "How are you?", "type": "text"}],
                },
            ],
            finished=False,
            final_answer=None,
            turn_events=[],
            execution_time_ms=500,
            max_turns=10,
        )

        llm = Mock()
        memory = Mock()
        sandbox = Mock()

        context = AgentContext.from_snapshot(
            snapshot=snapshot,
            agent_name="test_agent",
            llm=llm,
            memory=memory,
            sandbox=sandbox,
            task="Restored task",
        )

        assert context.conversation_id == "test-123"
        assert context.execution.turn == 3
        assert len(context.get_conversation_messages()) == 3
        assert context.is_finished is False

    def test_from_snapshot_with_final_answer(self):
        """Test restoring finished conversation (resets for continuation)."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=5,
            agent_name="test_agent",
            conversation_history=[],
            finished=True,
            final_answer={
                "answer": "Completed task",
            },
            turn_events=[],
            execution_time_ms=2000,
            max_turns=10,
        )

        llm = Mock()
        memory = Mock()
        sandbox = Mock()

        context = AgentContext.from_snapshot(
            snapshot=snapshot,
            agent_name="test_agent",
            llm=llm,
            memory=memory,
            sandbox=sandbox,
            task="Restored task",
        )

        # After restoration, execution.finished is reset to False for continuation
        assert context.is_finished is False
        # But final answer is preserved
        assert context.final_answer is not None
        assert context.final_answer.answer == "Completed task"

    def test_roundtrip_conversion(self, mock_context):
        """Test creating snapshot and restoring it."""
        from openai_harmony import Message, Role, Author, TextContent

        # Setup context state
        messages = [
            Message(author=Author(role=Role.USER), content=[TextContent(text="Test")]),
            Message(
                author=Author(role=Role.ASSISTANT),
                content=[TextContent(text="Response")],
            ),
        ]
        mock_context.set_conversation_history(messages)
        mock_context.execution.turn = 2

        # Create snapshot
        snapshot = mock_context.create_snapshot()

        # Restore to new context
        restored = AgentContext.from_snapshot(
            snapshot=snapshot,
            agent_name="test_agent",
            llm=mock_context.llm,
            memory=mock_context.memory,
            sandbox=mock_context.sandbox,
            task=mock_context.task,
        )

        # Verify state preserved
        assert restored.conversation_id == mock_context.conversation_id
        assert restored.execution.turn == 2
        assert len(restored.get_conversation_messages()) == 2

    def test_preserve_execution_state(self, mock_context):
        """Test that execution state is preserved."""
        # Advance turn
        mock_context.execution.turn = 5
        mock_context.execution.finished = False

        # Create and restore
        snapshot = mock_context.create_snapshot()

        restored = AgentContext.from_snapshot(
            snapshot=snapshot,
            agent_name="test_agent",
            llm=mock_context.llm,
            memory=mock_context.memory,
            sandbox=mock_context.sandbox,
            task=mock_context.task,
        )

        assert restored.execution.turn == 5
        assert restored.execution.finished is False

    def test_handle_missing_optional_fields(self):
        """Test handling snapshot with minimal fields."""
        snapshot = AgentSnapshot(
            conversation_id="test-123",
            turn=1,
            agent_name="test_agent",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=0,
            max_turns=10,
        )

        llm = Mock()
        memory = Mock()
        sandbox = Mock()

        context = AgentContext.from_snapshot(
            snapshot=snapshot,
            agent_name="test_agent",
            llm=llm,
            memory=memory,
            sandbox=sandbox,
            task="Test task",
        )

        assert context.final_answer is None
        assert context.is_finished is False
