"""Agent-specific exception hierarchy."""

from typing import Optional, Any


class AgentError(Exception):
    """Base exception class for all agent-related errors."""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        context: Optional[dict] = None,
    ):
        super().__init__(message)
        self.error_code = error_code
        self.context = context or {}


class StateTransitionError(AgentError):
    """Raised when a state transition fails or is invalid."""

    def __init__(self, from_state: str, to_state: str, reason: str, **kwargs):
        message = f"Failed to transition from {from_state} to {to_state}: {reason}"
        super().__init__(message, error_code="STATE_TRANSITION_ERROR", **kwargs)
        self.from_state = from_state
        self.to_state = to_state
        self.reason = reason


class ToolExecutionError(AgentError):
    """Raised when a tool execution fails."""

    def __init__(
        self,
        tool_name: str,
        reason: str,
        tool_parameters: Optional[dict] = None,
        **kwargs,
    ):
        message = f"Tool '{tool_name}' execution failed: {reason}"
        super().__init__(message, error_code="TOOL_EXECUTION_ERROR", **kwargs)
        self.tool_name = tool_name
        self.reason = reason
        self.tool_parameters = tool_parameters or {}


class ContextValidationError(AgentError):
    """Raised when agent context validation fails."""

    def __init__(self, validation_type: str, reason: str, **kwargs):
        message = f"Context validation failed ({validation_type}): {reason}"
        super().__init__(message, error_code="CONTEXT_VALIDATION_ERROR", **kwargs)
        self.validation_type = validation_type
        self.reason = reason


class LLMResponseError(AgentError):
    """Raised when LLM response parsing or generation fails."""

    def __init__(self, reason: str, response_data: Optional[Any] = None, **kwargs):
        message = f"LLM response error: {reason}"
        super().__init__(message, error_code="LLM_RESPONSE_ERROR", **kwargs)
        self.reason = reason
        self.response_data = response_data


class MemoryError(AgentError):
    """Raised when memory operations fail."""

    def __init__(self, operation: str, reason: str, **kwargs):
        message = f"Memory operation '{operation}' failed: {reason}"
        super().__init__(message, error_code="MEMORY_ERROR", **kwargs)
        self.operation = operation
        self.reason = reason


class SandboxError(AgentError):
    """Raised when sandbox operations fail."""

    def __init__(self, operation: str, reason: str, **kwargs):
        message = f"Sandbox operation '{operation}' failed: {reason}"
        super().__init__(message, error_code="SANDBOX_ERROR", **kwargs)
        self.operation = operation
        self.reason = reason
