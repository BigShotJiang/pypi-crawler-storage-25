"""Data models for LLM response metadata: token usage and reasoning."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..memory.models import Message


@dataclass
class TokenUsage:
    """Token consumption for a single LLM call.

    Tracks input, output, and reasoning tokens separately so callers
    can compute costs per-model (reasoning tokens are sometimes priced
    differently, e.g. OpenAI o-series).
    """

    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cached_tokens: int = 0  # subset of input_tokens served from cache

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def __add__(self, other: TokenUsage) -> TokenUsage:
        return TokenUsage(
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            reasoning_tokens=self.reasoning_tokens + other.reasoning_tokens,
            cached_tokens=self.cached_tokens + other.cached_tokens,
        )

    def __iadd__(self, other: TokenUsage) -> TokenUsage:
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.reasoning_tokens += other.reasoning_tokens
        self.cached_tokens += other.cached_tokens
        return self

    def to_dict(self) -> Dict[str, int]:
        return asdict(self)


@dataclass
class LLMResponse:
    """Rich return type from LLMStrategy.generate_response().

    Bundles the generated messages with metadata that was previously
    discarded (token usage) or buried in the message list (reasoning).

    Attributes:
        messages:   Assistant messages (tool calls, text, etc.)
        usage:      Token consumption for this call, if the provider reports it.
        reasoning:  Internal chain-of-thought / thinking text, if the model
                    produced it (e.g. OpenAI o-series reasoning summaries,
                    Anthropic extended thinking, Gemini thinking).
    """

    messages: List[Any] = field(default_factory=list)  # List[Message]
    usage: Optional[TokenUsage] = None
    reasoning: Optional[str] = None
