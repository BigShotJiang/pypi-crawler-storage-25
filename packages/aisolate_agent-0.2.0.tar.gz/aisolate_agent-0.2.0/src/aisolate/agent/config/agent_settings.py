"""Agent configuration settings."""

from typing import Dict, Any, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class AgentSettings(BaseSettings):
    """Core agent-specific configuration only.

    This class focuses solely on agent behaviors rather than strategy configuration.
    Strategies are configured directly when instantiated.
    """

    max_turns: int = Field(
        default=50, description="Maximum number of execution turns before agent stops"
    )
    reflection_turns: int = Field(
        default=5, description="Maximum number of execution turns before agent reflects"
    )
    enable_error_recovery: bool = Field(
        default=True, description="Whether to enable automatic error recovery"
    )

    max_recovery_attempts: int = Field(
        default=3,
        description="Maximum number of recovery attempts for failed operations",
    )

    conversation_history_max_length: Optional[int] = Field(
        default=None,
        description="Maximum number of messages to keep in conversation history",
    )

    debug_mode: bool = Field(
        default=False, description="Enable debug logging and additional validation"
    )

    enable_checkpoint: bool = Field(
        default=False,
        description="Enable kernel state checkpointing on pause/finish for resume",
    )

    enable_hitl: bool = Field(
        default=False,
        description="Whether HITL tools (ask_user, confirm) are available to the agent",
    )
    max_hitl_requests: int = Field(
        default=3,
        description="Maximum HITL requests per conversation to prevent infinite clarification loops",
    )

    enable_clarification: bool = Field(
        default=False,
        description="Enable expert panel clarification state before planning",
    )

    model_config = SettingsConfigDict(env_prefix="AGENT_", case_sensitive=False)
