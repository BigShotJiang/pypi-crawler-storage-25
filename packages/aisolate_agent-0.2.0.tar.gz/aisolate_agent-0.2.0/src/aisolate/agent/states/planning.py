"""Planning state implementation."""

from typing import List, Optional, Dict, Any, TYPE_CHECKING

from .base import AbstractState, StateResult
from ..utils import get_logger
from .executing import ExecutingState


if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.planning")


class PlanningState(AbstractState):
    """Handles the initial planning phase.

    This state prompts the LLM to create a plan for accomplishing the task
    and transitions to ExecutingState once a valid plan is received.
    """

    def on_enter(self, context: "AgentContext") -> None:
        context.set_state_hint("tool_choice", "none")
        context.set_state_hint("reasoning_effort", "high")
        logger.debug(
            "Planning state entered, set tool_choice=none, reasoning_effort=high"
        )

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        """Ensure we're in a valid state for planning."""
        if not await super()._pre_condition_check(context):
            return False

        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> bool:
        """Validate that we can extract a plan or get a valid response."""
        if not await super()._post_condition_check(context, response_messages):
            return False

        # Try to parse the response to see if we have actionable content
        try:
            _, plan = context.llm.parse_assistant_response(response_messages)
            if not plan:
                logger.warning("LLM response contains no plan")
                return False
        except Exception as e:
            logger.error("Failed to parse LLM response", error=str(e))
            return False

        return True

    async def _process_response(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> None:
        """Process the planning response and transition to execution if plan is found."""
        bound_logger = logger.bind(
            turn=context.turn,
            task_id=id(context.task),
            messages_count=len(response_messages),
        )

        context.extend_conversation_messages(response_messages)
        _, plan = context.llm.parse_assistant_response(response_messages)
        if not plan:
            bound_logger.error("No plan found in LLM response")
            raise RuntimeError("PlanningState: No plan found in LLM response")

        bound_logger.info("Plan received from LLM", plan_length=len(plan))

        # States only mutate context and emit messages - no direct memory calls

        # Prepare execution history and transition
        execution_history = context.llm.prepare_execution_history(context, plan)
        context.set_conversation_history(execution_history)

        bound_logger.info("Transitioning to execution state")
        context.transition_to(ExecutingState())

    def _get_state_metadata(self, context: "AgentContext") -> Optional[StateResult]:
        """Extract plan metadata for client streaming (NOT for persistence).

        This provides real-time visibility into the agent's planning process
        for frontend UI updates via SSE.

        Returns:
            StateResult with plan metadata, or None if no plan available
        """
        # Extract plan from recent conversation messages
        messages = context.get_conversation_messages()
        plan_text = None

        # Look for the most recent assistant message with content
        for msg in reversed(messages):
            if hasattr(msg, "author") and hasattr(msg.author, "role"):
                if msg.author.role == "assistant" and msg.content:
                    # Extract text content from Message
                    if isinstance(msg.content, str):
                        plan_text = msg.content
                    elif isinstance(msg.content, list) and len(msg.content) > 0:
                        # Content is a list of Content objects (TextContent, etc.)
                        for content_item in msg.content:
                            # TextContent has a 'text' field
                            if hasattr(content_item, "text"):
                                text_val = getattr(content_item, "text", None)
                                if text_val:
                                    plan_text = text_val
                                    break
                    if plan_text:
                        break

        if not plan_text:
            return None

        from datetime import datetime

        metadata = {
            "type": "plan",
            "plan_text": plan_text,
            "turn": context.turn,
            "timestamp": datetime.utcnow().isoformat(),
        }

        return StateResult(metadata=metadata)
