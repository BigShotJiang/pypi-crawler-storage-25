"""Error recovery state implementation."""

from typing import List, TYPE_CHECKING
from .base import AbstractState
from ..core.exceptions import StateTransitionError
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.error_recovery")


class ErrorRecoveryState(AbstractState):
    """State for handling errors and automatic recovery."""

    def __init__(
        self, error: Exception, recovery_attempt: int = 0, max_attempts: int = 3
    ):
        self.error = error
        self.recovery_attempt = recovery_attempt
        self.max_attempts = max_attempts

    def on_enter(self, context: "AgentContext") -> None:
        """Set hints for error recovery phase."""
        # During error recovery, use auto tool choice
        context.set_state_hint("tool_choice", "auto")
        logger.debug("Error recovery state entered, set tool_choice=auto")

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        # Always allow error recovery state to run
        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> bool:
        # No post-condition for error recovery
        return True

    async def _process_response(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> None:
        logger.error(
            f"Error encountered: {self.error}. Attempt {self.recovery_attempt + 1}/{self.max_attempts}"
        )
        if self.recovery_attempt < self.max_attempts:
            # Try to recover by re-executing previous state
            try:
                logger.info("Attempting recovery...")
                await context._state.handle(context)
            except Exception as e:
                logger.error(f"Recovery attempt failed: {e}")
                context.transition_to(
                    ErrorRecoveryState(e, self.recovery_attempt + 1, self.max_attempts)
                )
        else:
            logger.error(
                "Max recovery attempts reached. Transitioning to finished state."
            )
            from .finished import FinishedState

            context.transition_to(FinishedState())
