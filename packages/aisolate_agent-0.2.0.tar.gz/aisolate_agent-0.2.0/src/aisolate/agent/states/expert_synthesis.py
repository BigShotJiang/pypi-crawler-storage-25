"""ExpertSynthesisState — panel reviews the user's clarification answer."""

from typing import List, Optional, TYPE_CHECKING

from .base import AbstractState, StateResult
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.expert_synthesis")


class ExpertSynthesisState(AbstractState):
    """Second pass of the clarification loop.

    Entered from ClarificationState after the user answers the clarification
    question. Reconvenes the expert panel, shows them the user's answer,
    and asks for a consolidated discussion. The output is folded with the
    Q+A into a rich task brief that replaces ``context.task`` before
    transitioning to PlanningState.

    Instance attributes (populated by ClarificationState on transition):
        question: The clarification question the panel asked the user.
        answer: The user's reply.
        original_task: The task as it was before clarification.
        expert_ask_text: Expert analysis text from the ask pass (optional).
    """

    def __init__(
        self,
        question: str,
        answer: str,
        original_task: str,
        expert_ask_text: str = "",
    ):
        self.question = question
        self.answer = answer
        self.original_task = original_task
        self.expert_ask_text = expert_ask_text

    def on_enter(self, context: "AgentContext") -> None:
        context.set_state_hint("tool_choice", "none")
        context.set_state_hint("reasoning_effort", "medium")

        synthesis_history = context.llm.prepare_expert_synthesis_history(
            context,
            question=self.question,
            answer=self.answer,
            original_task=self.original_task,
            expert_ask_text=self.expert_ask_text,
        )
        context.set_conversation_history(synthesis_history)

    async def _process_response(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> None:
        context.extend_conversation_messages(response_messages)
        _, panel_text = context.llm.parse_assistant_response(response_messages)

        if not panel_text:
            logger.warning(
                "ExpertSynthesisState: empty panel discussion, "
                "falling through to PlanningState with raw Q+A only"
            )
            panel_text = ""

        rich_brief = (
            f"# User Task\n{self.original_task}\n\n"
            f"# Clarification Question (Expert Panel)\n{self.question}\n\n"
            f"# User Answer\n{self.answer}\n\n"
            f"# Expert Panel Synthesis\n{panel_text}"
        ).strip()

        context.task = rich_brief

        planning_history = context.llm.prepare_planning_history_from_brief(
            context, rich_brief
        )
        context.set_conversation_history(planning_history)

        from .planning import PlanningState
        context.transition_to(PlanningState())

    def _get_state_metadata(
        self, context: "AgentContext"
    ) -> Optional[StateResult]:
        return StateResult(metadata={"type": "expert_synthesis"})
