"""Enhanced base state class with lifecycle hooks and validation."""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, TYPE_CHECKING
from dataclasses import dataclass

from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.base")


@dataclass
class StateResult:
    """Result from state execution with optional metadata for transparency.

    This allows states to return structured metadata about their execution
    that can be streamed to the frontend for display.
    """

    metadata: Optional[Dict[str, Any]] = None


class AbstractState(ABC):
    """Enhanced base class for states with lifecycle hooks and validation.

    This class provides a template method pattern with pre/post-condition
    validation and error handling patterns that all states inherit.
    """

    def on_enter(self, context: "AgentContext") -> None:
        """Called when entering this state (for setting hints).

        Subclasses can override this to set state-specific hints.
        Default implementation does nothing.

        Args:
            context: AgentContext to set hints on
        """
        pass  # Default: no hints

    async def handle(self, context: "AgentContext") -> Optional[StateResult]:
        """Main template method that orchestrates state execution with validation.

        Returns:
            Optional StateResult with metadata about the state execution
        """

        # Pre-condition validation
        if not await self._pre_condition_check(context):
            logger.error(f"Pre-condition check failed for {type(self).__name__}")
            return None

        # Generate LLM response (returns LLMResponse with messages + metadata)
        llm_response = await context.llm.generate_response(context)
        response_messages = llm_response.messages

        # Accumulate token usage on the context
        if llm_response.usage is not None:
            model = getattr(context.llm, "model", None)
            context.accumulate_usage(llm_response.usage, model=model)

        # Store reasoning text on the context
        context.set_last_reasoning(llm_response.reasoning)

        # Post-condition validation
        if not await self._post_condition_check(context, response_messages):
            logger.error(f"Post-condition check failed for {type(self).__name__}")
            return None

        # Process the response
        await self._process_response(context, response_messages)

        # Return metadata if state produces any
        return self._get_state_metadata(context)

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        """Validate preconditions before state execution.

        This method can be overridden by subclasses to implement specific
        validation logic (e.g., checking tool availability, context integrity).

        Args:
            context: The agent context

        Returns:
            True if preconditions are met, False otherwise
        """
        # Default implementation - validate basic context integrity
        if not context.task:
            logger.error("No task defined in context")
            return False

        if not context.llm:
            logger.error("No LLM strategy available")
            return False

        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> bool:
        """Validate postconditions after LLM response generation.

        This method can be overridden by subclasses to implement specific
        validation logic (e.g., ensuring LLM response was parseable).

        Args:
            context: The agent context
            response_messages: Messages returned by the LLM

        Returns:
            True if postconditions are met, False otherwise
        """
        # Default implementation - ensure we got some response
        if not response_messages:
            logger.error("No response messages from LLM")
            return False

        return True

    @abstractmethod
    async def _process_response(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> None:
        """Process the LLM response and handle state transitions.

        Subclasses must implement specific parsing and transition logic.

        Args:
            context: The agent context
            response_messages: Messages returned by the LLM
        """
        ...

    def _get_state_metadata(self, context: "AgentContext") -> Optional[StateResult]:
        """Extract metadata for client streaming events.

        Purpose:
        - Provide transient execution details for Client display
        - Show current plan being executed
        - Display tool calls in progress
        - Show intermediate reasoning steps

        Data Flow:
        StateResult.metadata → TurnResult → TurnCompletedEvent → Client

        This data is ephemeral and only exists during active execution to give
        users real-time visibility into agent progress.

        Subclasses should override this to provide state-specific metadata:
        - PlanningState: Current plan text and parsed steps
        - ExecutingState: Tool name, arguments, and results
        - Other states: Relevant execution context

        Args:
            context: The agent context with current execution state

        Returns:
            Optional StateResult with streaming metadata, or None if no
            metadata is relevant for this state execution.
        """
        return None  # Default: no metadata
