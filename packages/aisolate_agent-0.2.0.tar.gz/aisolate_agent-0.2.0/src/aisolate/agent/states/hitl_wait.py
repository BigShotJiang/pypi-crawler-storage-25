"""HITL wait state — pauses agent execution for human input."""

from typing import TYPE_CHECKING, Optional

from ..core.protocols import State
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..tools.models import HITLSignal

logger = get_logger("aisolate.agent.states.hitl_wait")


class HITLWaitState:
    """Pauses agent execution to wait for human input.

    Does NOT inherit AbstractState. Does NOT call the LLM.
    Simply marks execution as finished and records the HITL signal.
    Analogous to FinishedState — a terminal state for this turn sequence.
    """

    def __init__(self, hitl_signal: "HITLSignal", resume_state_name: str = "ExecutingState"):
        self.hitl_signal = hitl_signal
        self.resume_state_name = resume_state_name

    def on_enter(self, context: "AgentContext") -> None:
        pass

    async def handle(self, context: "AgentContext") -> None:
        """Mark execution as paused (uses finished flag)."""
        logger.info(
            "Agent paused for HITL",
            signal_type=self.hitl_signal.signal_type,
            resume_state=self.resume_state_name,
        )
        context.execution.finished = True
        context.pending_hitl_signal = self.hitl_signal
        context.hitl_resume_state = self.resume_state_name

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages
    ) -> bool:
        return True
