"""Executing state implementation."""

import json
from typing import List, Any, TYPE_CHECKING, Optional, Dict

from .base import AbstractState, StateResult
from ..utils import get_logger

from ..tools.execution import execute_tool_call
from ..tools.models import ToolCall, FinalAnswerResult
from .finished import FinishedState


if TYPE_CHECKING:
    from ..core.context import AgentContext

logger = get_logger("aisolate.agent.states.executing")


class ExecutingState(AbstractState):
    """Handles the execution phase (tool calls and actions).

    This state processes LLM responses to either execute tools/actions
    or receive the final answer, transitioning to FinishedState when complete.
    """

    def __init__(self):
        """Initialize execution state with tracking for streaming metadata."""
        self._last_tool_execution: Optional[Dict[str, Any]] = None
        self._no_tool_call_count: int = 0
        self._max_no_tool_calls: int = 5

    def on_enter(self, context: "AgentContext") -> None:
        """Set hints for execution phase."""
        context.set_state_hint("tool_choice", "required")
        context.set_state_hint("reasoning_effort", "medium")

        # Remove HITL tools — clarification phase is over, the agent must
        # execute autonomously.  Keeping ask_user available tempts the LLM
        # into asking trivial preference questions mid-execution.
        hitl_names = {"ask_user", "confirm"}
        context.function_tools = [
            t for t in context.function_tools if t.name not in hitl_names
        ]

        logger.debug(
            "Executing state entered, set tool_choice=required, reasoning_effort=medium"
        )

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        """Ensure we're in a valid state for execution."""
        if not await super()._pre_condition_check(context):
            return False

        # Execution-specific validations
        if not context.sandbox:
            logger.error("No sandbox available for execution", state="executing")
            return False

        if not context.remote_python_executor:
            logger.error("No Python executor available", state="executing")
            return False

        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List[Any]
    ) -> bool:
        """Validate that LLM response was actionable."""
        if not await super()._post_condition_check(context, response_messages):
            return False

        try:
            tool_call, message_text = context.llm.parse_assistant_response(
                response_messages
            )
            if not tool_call and not message_text:
                logger.warning(
                    "LLM response contains no tool call or message",
                    state="executing",
                )
                return False
        except Exception as e:
            logger.error(
                "Failed to parse LLM response", error=str(e), state="executing"
            )
            return False

        return True

    async def _process_response(
        self, context: "AgentContext", response_messages: List[Any]
    ) -> None:
        """Process execution response - handle tool calls or message content."""
        context.extend_conversation_messages(response_messages)
        tool_call, message_content = context.llm.parse_assistant_response(
            response_messages
        )

        if message_content:
            logger.warning(
                "LLM provided message",
                state="executing",
                text_length=len(message_content),
                text_preview=(
                    message_content[:100]
                    if len(message_content) > 100
                    else message_content
                ),
            )
            # Increment no tool call counter
            self._no_tool_call_count += 1

            # Circuit breaker: if we've hit max attempts without tool calls
            if self._no_tool_call_count >= self._max_no_tool_calls:
                logger.warning(
                    "Circuit breaker triggered: too many responses "
                    "without tool calls",
                    state="executing",
                    count=self._no_tool_call_count,
                )
                # Create final answer from the message content
                context.final_answer = FinalAnswerResult(
                    answer=message_content,
                    sources=[],
                    metadata={
                        "reason": "circuit_breaker",
                        "no_tool_call_count": self._no_tool_call_count,
                    },
                )
                context.transition_to(FinishedState())
                return

        elif tool_call:
            # Reset counter on successful tool call
            self._no_tool_call_count = 0
            await self._handle_tool_call(context, tool_call)
        else:
            # Increment counter for empty responses
            self._no_tool_call_count += 1
            logger.warning(
                "No action taken by LLM, will retry",
                state="executing",
                no_tool_call_count=self._no_tool_call_count,
            )

            # Circuit breaker for empty responses
            if self._no_tool_call_count >= self._max_no_tool_calls:
                logger.error(
                    "Circuit breaker triggered: too many empty responses",
                    state="executing",
                    count=self._no_tool_call_count,
                )
                context.final_answer = FinalAnswerResult(
                    answer=(
                        "Unable to complete the task due to repeated "
                        "failures to generate tool calls."
                    ),
                    sources=None,
                    metadata={
                        "reason": "circuit_breaker_empty_response",
                        "no_tool_call_count": self._no_tool_call_count,
                    },
                )
                context.transition_to(FinishedState())
                return

    async def _handle_tool_call(
        self, context: "AgentContext", tool_call: ToolCall
    ) -> None:
        """Handle execution of a tool call."""
        tool_name = tool_call.name
        arguments = tool_call.arguments

        try:
            logger.info(
                "Executing tool call",
                tool_name=tool_name,
                arguments=arguments,
            )
            # Execute the tool - returns ToolExecutionResult
            result = await execute_tool_call(context, tool_call)

            # Track this execution for streaming metadata
            self._last_tool_execution = {
                "name": tool_name,
                "arguments": arguments,
                "success": result.success,
                "output": result.output,
                "error": result.error,
                "has_final_answer": result.final_answer is not None,
            }

            # Propagate structured metadata (e.g. subagent_result) for events
            if result.metadata:
                self._last_tool_execution.update(result.metadata)

            # Check for execution error
            if not result.success:
                error_msg = result.error or "Unknown error"
                logger.error(
                    "Tool execution failed",
                    tool_name=tool_name,
                    error=error_msg,
                )

                # Log failed tool execution
                logger.log_tool_execution(
                    tool_name=tool_name,
                    arguments=arguments,
                    output=None,
                    success=False,
                    error=error_msg,
                    agent_name=context.agent_name,
                )
                return

            # Check if tool execution produced a HITL signal (before final_answer)
            if result.hitl_signal is not None:
                from .hitl_wait import HITLWaitState

                logger.info(
                    "HITL signal detected",
                    tool_name=tool_name,
                    signal_type=result.hitl_signal.signal_type,
                )
                self._last_tool_execution["has_hitl_signal"] = True
                self._last_tool_execution["hitl_signal_type"] = (
                    result.hitl_signal.signal_type
                )

                # Add tool response to conversation so LLM sees it on resume
                tool_call_id = tool_call.tool_call_id
                tool_response_message = context.llm.create_tool_response_message(
                    tool_name=tool_name,
                    result=result.output,
                    tool_call_id=tool_call_id,
                )
                context.add_conversation_message(tool_response_message)

                context.transition_to(
                    HITLWaitState(
                        hitl_signal=result.hitl_signal,
                        resume_state_name="ExecutingState",
                    )
                )
                return

            # Per-tool-call debug trace — downgraded from info to debug
            # because it fires on every single tool invocation and was
            # drowning out the genuinely interesting state transitions.
            logger.debug(
                "_handle_tool_call: checking review/final_answer",
                tool_name=tool_name,
                has_review_request=result.review_request is not None,
                has_final_answer=result.final_answer is not None,
                has_hitl_signal=result.hitl_signal is not None,
                review_state_type=type(context.review_state).__name__,
            )
            if result.review_request is not None:
                context.final_answer = result.review_request
                context.exit_method = "request_report_review"

                if context.review_state is not None:
                    logger.info(
                        "Review requested, transitioning to CriticState",
                        tool_name=tool_name,
                        review_state_type=type(context.review_state).__name__,
                    )
                    # review_state can be a class (called to create instance)
                    # or a pre-configured instance (used directly)
                    review = context.review_state
                    if isinstance(review, type):
                        review = review()
                    context.transition_to(review)
                else:
                    # No critic configured — deliver directly
                    logger.info(
                        "Review requested but no review state configured, "
                        "delivering as final answer",
                        tool_name=tool_name,
                    )
                    context.transition_to(FinishedState())
                return

            # Check if tool execution produced a final answer
            if result.final_answer is not None:
                logger.info(
                    "Final answer detected in tool execution",
                    tool_name=tool_name,
                    final_answer_length=len(result.final_answer.answer),
                    has_sources=result.final_answer.sources is not None,
                    has_metadata=result.final_answer.metadata is not None,
                )

                # Set final answer on context (states only mutate context)
                context.final_answer = result.final_answer
                context.exit_method = "final_answer"

                context.transition_to(FinishedState())

                # Log successful completion
                logger.log_tool_execution(
                    tool_name=tool_name,
                    arguments=arguments,
                    output=result.output,
                    success=True,
                    agent_name=context.agent_name,
                )

                # Don't add to conversation - we're done
                return

            # Log complete tool execution (input + output)
            logger.log_tool_execution(
                tool_name=tool_name,
                arguments=arguments,
                output=result.output,
                success=True,
                agent_name=context.agent_name,
            )

            # Add tool response to conversation
            tool_call_id = tool_call.tool_call_id
            llm_output = self._compact_for_llm(result.output)
            tool_response_message = context.llm.create_tool_response_message(
                tool_name=tool_name,
                result=llm_output,
                tool_call_id=tool_call_id,
            )

            context.add_conversation_message(tool_response_message)

        except Exception as e:
            # Log tool execution with error
            logger.log_tool_execution(
                tool_name=tool_name,
                arguments=arguments,
                output=None,
                success=False,
                error=str(e),
                agent_name=context.agent_name,
            )

            logger.log_exception(e, f"tool_execution_{tool_name}")

    @staticmethod
    def _strip_binary_for_llm(output: str) -> str:
        """Remove large binary data from tool output before sending to the LLM.

        Replaces base64-encoded image data with a boolean flag so the LLM
        knows an image was produced without consuming context tokens on the
        raw payload.  The full output (with base64) remains available to
        the frontend via state_metadata / SSE.
        """
        try:
            parsed = json.loads(output)
            if isinstance(parsed, dict) and parsed.get("image_png_base64"):
                parsed["image_png_base64"] = True
                return json.dumps(parsed)
        except (json.JSONDecodeError, TypeError, ValueError):
            pass
        return output

    @staticmethod
    def _compact_for_llm(output: str, max_result_chars: int = 1500) -> str:
        """Compact tool output for LLM context window efficiency.

        The full, uncompacted output is always preserved in state_metadata
        for the frontend and trace files. This method only affects what the
        LLM sees in subsequent turns.

        Strategy (rule-based):
        1. Strip base64 image data → boolean flag
        2. Deduplicate text/result when identical
        3. Truncate large result/stdout fields with a size indicator
        4. Preserve error details and final_answer_data verbatim
        """
        if not output:
            return output

        # Fast path: small outputs pass through with only binary stripping
        stripped = ExecutingState._strip_binary_for_llm(output)
        if len(stripped) <= max_result_chars:
            return stripped

        try:
            parsed = json.loads(stripped)
        except (json.JSONDecodeError, TypeError, ValueError):
            # Not JSON — hard truncate
            return stripped[:max_result_chars] + f"\n… [{len(stripped)} chars total]"

        if not isinstance(parsed, dict):
            return stripped[:max_result_chars] + f"\n… [{len(stripped)} chars total]"

        # Build compact representation preserving structure
        compact: Dict[str, Any] = {
            "ok": parsed.get("ok"),
        }

        # Always preserve errors and final answer verbatim
        if parsed.get("error"):
            compact["error"] = parsed["error"]
        if parsed.get("is_final_answer"):
            compact["is_final_answer"] = parsed["is_final_answer"]
        if parsed.get("final_answer_data"):
            compact["final_answer_data"] = parsed["final_answer_data"]

        # Image flag (already stripped to True by _strip_binary_for_llm)
        if parsed.get("image_png_base64"):
            compact["image_png_base64"] = True

        # Deduplicate: prefer "text" (Jupyter display-optimized output) over
        # "result" (raw repr which can dump entire DataFrames/lists).
        # Jupyter's text/plain representation already applies pandas max_rows,
        # numpy summarization, etc.
        result_val = str(parsed.get("result") or "")
        text_val = str(parsed.get("text") or "")
        stdout_val = str(parsed.get("stdout") or "")

        # Prefer text (display-optimized), fall back to result (raw repr)
        if text_val:
            canonical_str = text_val
        else:
            canonical_str = result_val

        # Truncate canonical result if large
        half = max_result_chars // 2
        if len(canonical_str) > max_result_chars:
            compact["result"] = (
                canonical_str[:half]
                + f"\n\n… [{len(canonical_str)} chars truncated — data is in kernel, use print() to inspect]\n\n"
                + canonical_str[-300:]
            )
        else:
            compact["result"] = canonical_str

        # Only include stdout if it adds new information (not a duplicate of result)
        if stdout_val and stdout_val != text_val and stdout_val != result_val:
            if len(stdout_val) > 500:
                compact["stdout"] = stdout_val[:300] + f"\n… [{len(stdout_val)} chars]"
            else:
                compact["stdout"] = stdout_val

        return json.dumps(compact, ensure_ascii=False)

    def _get_state_metadata(self, context: "AgentContext") -> Optional[StateResult]:
        """Extract tool execution metadata for client streaming (NOT for persistence).

        This provides real-time visibility into tool executions for frontend
        UI updates via SSE, showing which tools are being called and their results.

        Returns:
            StateResult with tool execution metadata, or None if no execution yet
        """
        if not self._last_tool_execution:
            return None

        output = self._last_tool_execution.get("output", "")

        from datetime import datetime

        metadata = {
            "type": "tool_execution",
            "tool_name": self._last_tool_execution["name"],
            "arguments": self._last_tool_execution["arguments"],
            "success": self._last_tool_execution["success"],
            "output": output,  # Send full output object
            "error": self._last_tool_execution.get("error"),
            "has_final_answer": self._last_tool_execution.get(
                "has_final_answer", False
            ),
            "turn": context.turn,
            "timestamp": datetime.utcnow().isoformat(),
        }

        # Include structured subagent result if available (avoids frontend JSON parsing)
        if "subagent_result" in self._last_tool_execution:
            metadata["subagent_result"] = self._last_tool_execution["subagent_result"]

        return StateResult(metadata=metadata)
