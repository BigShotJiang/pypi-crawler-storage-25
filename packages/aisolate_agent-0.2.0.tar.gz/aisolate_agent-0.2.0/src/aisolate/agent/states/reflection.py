"""Reflection state implementation."""

from typing import List, TYPE_CHECKING
from .base import AbstractState
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.reflection")


class ReflectionState(AbstractState):
    """State for agent self-reflection and learning from experience."""

    def on_enter(self, context: "AgentContext") -> None:
        """Set hints for reflection phase."""
        context.set_state_hint("tool_choice", "auto")
        logger.debug("Reflection state entered, set tool_choice=auto")

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        # Reflection can always run after a task is finished
        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages: List["Message"]
    ) -> bool:
        # No post-condition for reflection
        return True

    async def _process_response(
        self, context: "AgentContext", response_messages: List["Message"]
    ):
        logger.info("Agent is reflecting on its recent actions and outcomes.")
        # Example: Analyze conversation history and update long-term memory
        insights = self._analyze_history(context)
        context.long_term_memory.append({"type": "reflection", "insights": insights})
        logger.info(f"Reflection insights: {insights}")
        from .finished import FinishedState

        context.transition_to(FinishedState())

    def _analyze_history(self, context: "AgentContext") -> dict:
        # Placeholder for actual analysis logic
        history = context.get_conversation_messages()
        return {
            "message_count": len(history),
            "last_message": history[-1].content if history else None,
        }
