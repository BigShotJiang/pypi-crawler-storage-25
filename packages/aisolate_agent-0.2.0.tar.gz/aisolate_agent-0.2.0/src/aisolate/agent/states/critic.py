"""CriticState — generic QA review state with independent LLM call.

Implements the State protocol directly (no AbstractState inheritance)
because it needs no sandbox, no tool routing, and makes its own LLM
call with a purpose-built prompt rather than using the conversation
history.

The system prompt is configurable — pass a custom prompt to the
constructor or override via ``review_system_prompt`` on ``AgentContext``.
"""

import base64
import json
import re
from typing import Optional, List, TYPE_CHECKING

from aisolate.agent.core.llm_response import TokenUsage
from aisolate.agent.states.base import StateResult
from aisolate.agent.states.finished import FinishedState
from aisolate.agent.states.executing import ExecutingState
from aisolate.agent.utils import get_logger

if TYPE_CHECKING:
    from aisolate.agent.core.context import AgentContext

logger = get_logger("aisolate.agent.states.critic")

DEFAULT_REVIEW_PROMPT = """\
You are a senior quality reviewer.

Your task is to review the deliverable below and decide whether it meets the
quality bar for delivery to the end user.

## Review Criteria

1. **Completeness** — Does the deliverable address the user's question fully?
2. **Accuracy** — Are facts, numbers, units, and references consistent
   throughout?
3. **Structure** — Does the deliverable follow a logical structure with clear
   sections, headings, and transitions?
4. **Visualizations** — If charts or images are present, are they referenced in
   the text with titles, axis labels, and legends?
5. **Actionable output** — Are conclusions specific, substantiated, and tied to
   the analysis?
6. **Language** — Is the language professional, concise, and free of
   placeholder text or TODOs?

## Response Format

Respond with a JSON object — no markdown fences, no prose outside the JSON:

{
  "verdict": "APPROVED" | "REJECTED",
  "deficiencies": ["..."]  // empty list if approved
}
"""


def _extract_image_urls(markdown: str) -> List[str]:
    """Extract image URLs from markdown ``![alt](url)`` patterns."""
    return re.findall(r"!\[.*?\]\(([^)]+)\)", markdown)


class CriticState:
    """QA review state — independent LLM call with multimodal support.

    Lifecycle::

        ExecutingState → request_report_review() → CriticState
            → APPROVED  → FinishedState
            → REJECTED  → ExecutingState (with feedback injected)

    The agent loop swaps ``context.llm`` to the critic model via
    ``state_model_overrides`` before calling ``handle()``.

    Args:
        system_prompt: Custom review prompt.  Falls back to
            ``DEFAULT_REVIEW_PROMPT`` if not provided.
    """

    def __init__(self, system_prompt: Optional[str] = None) -> None:
        self.system_prompt = system_prompt or DEFAULT_REVIEW_PROMPT

    def on_enter(self, context: "AgentContext") -> None:
        """No tools or hints needed for a pure LLM review call."""

    async def handle(self, context: "AgentContext") -> Optional[StateResult]:
        context.review_count += 1

        logger.info(
            f"╔══ CRITIC REVIEW (iteration {context.review_count}/"
            f"{context.max_reviews}) ══╗"
        )

        # Cap check — auto-approve after max_reviews to prevent infinite loops
        if context.review_count > context.max_reviews:
            logger.warning(
                "Review cap reached, auto-approving",
                review_count=context.review_count,
                max_reviews=context.max_reviews,
            )
            context.transition_to(FinishedState())
            return StateResult(metadata={
                "type": "review",
                "verdict": "approved",
                "review_capped": True,
            })

        report_md = context.final_answer.answer
        user_question = context.task

        # Build multimodal message content
        content_parts = self._build_content_parts(
            report_md, user_question, context
        )

        # Resolve images from report markdown
        images = await self._resolve_images(report_md, context)
        for img_bytes in images:
            b64 = base64.b64encode(img_bytes).decode("ascii")
            content_parts.append({
                "type": "input_image",
                "image_url": f"data:image/png;base64,{b64}",
            })

        # Make the LLM call using the strategy's client directly
        llm = context.llm
        client = getattr(llm, "client", None)
        model = getattr(llm, "model", "unknown")

        if client is None:
            logger.error("No LLM client available on context.llm")
            context.transition_to(FinishedState())
            return StateResult(metadata={
                "type": "review",
                "verdict": "approved",
                "error": "no_client",
            })

        response = await client.responses.create(
            model=model,
            input=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": content_parts},
            ],
        )

        # Extract usage
        raw_usage = getattr(response, "usage", None)
        if raw_usage:
            token_usage = TokenUsage(
                input_tokens=getattr(raw_usage, "input_tokens", 0) or 0,
                output_tokens=getattr(raw_usage, "output_tokens", 0) or 0,
                reasoning_tokens=0,
                cached_tokens=0,
            )
            input_details = getattr(raw_usage, "input_tokens_details", None)
            if input_details:
                token_usage.cached_tokens = (
                    getattr(input_details, "cached_tokens", 0) or 0
                )
            context.accumulate_usage(token_usage, model=model)

        # Parse verdict
        verdict_text = self._extract_response_text(response)
        verdict, deficiencies = self._parse_verdict(verdict_text)

        verdict_glyph = "✓" if verdict == "APPROVED" else "✗"
        logger.info(
            f"╚══ CRITIC VERDICT: {verdict_glyph} {verdict} "
            f"({len(deficiencies)} deficiencies) ══╝",
            review_count=context.review_count,
            model=model,
        )

        if verdict == "APPROVED":
            context.transition_to(FinishedState())
        else:
            # Clear final answer and inject feedback for the coordinator
            context.final_answer = None
            feedback = self._format_feedback(deficiencies)
            from openai_harmony import Message, Role
            context.add_conversation_message(
                Message.from_role_and_content(Role.USER, feedback)
            )
            context.transition_to(ExecutingState())

        return StateResult(metadata={
            "type": "review",
            "verdict": verdict.lower(),
            "deficiencies": deficiencies,
            "review_count": context.review_count,
        })

    # ---- Private helpers ----

    def _build_content_parts(
        self,
        report_md: str,
        user_question: str,
        context: "AgentContext",
    ) -> list:
        """Build the user-role content parts for the critic prompt."""
        return [
            {
                "type": "input_text",
                "text": (
                    f"## User Question\n\n{user_question}\n\n"
                    f"## Report\n\n{report_md}"
                ),
            },
        ]

    async def _resolve_images(
        self, report_md: str, context: "AgentContext"
    ) -> List[bytes]:
        """Resolve image URLs from report markdown to raw bytes."""
        image_urls = _extract_image_urls(report_md)
        if not image_urls or context.file_resolver is None:
            return []

        images: List[bytes] = []
        for url in image_urls:
            try:
                img_bytes = await context.file_resolver.resolve(url)
                images.append(img_bytes)
            except Exception as e:
                logger.warning(
                    "Failed to resolve image for review",
                    url=url,
                    error=str(e),
                )
        return images

    def _extract_response_text(self, response) -> str:
        """Extract text from the API response."""
        output = getattr(response, "output", None)
        if output:
            for item in output:
                if getattr(item, "type", None) == "message":
                    for content in getattr(item, "content", []):
                        if getattr(content, "type", None) == "output_text":
                            return getattr(content, "text", "")
        return ""

    def _parse_verdict(self, text: str) -> tuple[str, list[str]]:
        """Parse the JSON verdict from the critic response."""
        try:
            clean = text.strip()
            if clean.startswith("```"):
                clean = re.sub(r"^```\w*\n?", "", clean)
                clean = re.sub(r"\n?```$", "", clean)
            data = json.loads(clean)
            verdict = data.get("verdict", "APPROVED").upper()
            deficiencies = data.get("deficiencies", [])
            if verdict not in ("APPROVED", "REJECTED"):
                logger.warning("Unknown verdict %r, defaulting to APPROVED", verdict)
                verdict = "APPROVED"
            return verdict, deficiencies
        except (json.JSONDecodeError, AttributeError) as e:
            logger.warning(
                "Failed to parse critic verdict, defaulting to APPROVED",
                error=str(e),
                raw_text=text[:500],
            )
            return "APPROVED", []

    def _format_feedback(self, deficiencies: list[str]) -> str:
        """Format rejection feedback for the coordinator."""
        items = "\n".join(f"  {i+1}. {d}" for i, d in enumerate(deficiencies))
        return (
            "[QUALITY REVIEW — REJECTED]\n\n"
            "The following deficiencies were found:\n"
            f"{items}\n\n"
            "Address these issues, then call request_report_review() again."
        )
