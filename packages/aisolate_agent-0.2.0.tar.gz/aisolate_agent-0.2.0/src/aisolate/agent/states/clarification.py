"""ClarificationState — expert panel assessment before planning."""

from typing import List, Optional, TYPE_CHECKING

from .base import AbstractState, StateResult
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext

logger = get_logger("aisolate.agent.states.clarification")


class ClarificationState(AbstractState):
    """Expert panel assessment + user clarification before planning.

    This state runs once at the start of a conversation when
    ``enable_clarification`` is True.  It makes a single LLM call that
    assembles a panel of domain experts, analyses the user's task, and
    calls ``ask_user()`` with clarification questions.

    On ``ask_user``, it transitions to ``HITLWaitState`` with
    ``resume_state="ClarificationState"``.  When the user responds and
    execution resumes, ``handle()`` detects the resume via
    ``previous_state_name == "HITLWaitState"``, rebuilds the conversation
    history for planning (folding in the expert analysis and user answer),
    and transitions to ``PlanningState``.

    This follows the same pattern as PlanningState → ExecutingState:
    the outgoing state prepares the history its successor needs.
    """

    def on_enter(self, context: "AgentContext") -> None:
        # Force the model to call ask_user — the whole point of this state
        # is to produce clarification questions via the tool, not as text.
        context.set_state_hint(
            "tool_choice", {"type": "function", "name": "ask_user"}
        )
        context.set_state_hint("reasoning_effort", "medium")

    async def handle(self, context: "AgentContext") -> Optional[StateResult]:
        """Override to detect HITL resume and skip LLM call."""
        if context.execution.previous_state_name == "HITLWaitState":
            # Resumed after user answered — hand off to ExpertSynthesisState
            # so the panel can reconcile the answer with its earlier analysis
            # before the planner runs.
            expert_text = self._extract_expert_text(context)
            user_answer = self._extract_user_answer(context)
            question = self._extract_question(context)
            original_task = context.task

            logger.info(
                "HITL resume detected → ExpertSynthesisState",
                previous_state=context.execution.previous_state_name,
                has_question=bool(question),
                has_answer=bool(user_answer),
                has_expert_text=bool(expert_text),
            )

            from .expert_synthesis import ExpertSynthesisState
            context.transition_to(
                ExpertSynthesisState(
                    question=question,
                    answer=user_answer,
                    original_task=original_task,
                    expert_ask_text=expert_text,
                )
            )
            return self._get_state_metadata(context)

        # Normal flow: LLM call → ask_user
        return await super().handle(context)

    async def _process_response(
        self, context: "AgentContext", response_messages: List
    ) -> None:
        context.extend_conversation_messages(response_messages)
        tool_call, text_content = context.llm.parse_assistant_response(
            response_messages
        )

        if tool_call:
            await self._handle_tool_call(context, tool_call)
        else:
            # Fallback: LLM didn't call ask_user despite instructions.
            # Transition to PlanningState with whatever assessment we have.
            logger.warning(
                "ClarificationState: LLM did not call ask_user, "
                "falling back to PlanningState"
            )
            self._prepare_planning_history(context)
            from .planning import PlanningState
            context.transition_to(PlanningState())

    async def _handle_tool_call(self, context: "AgentContext", tool_call) -> None:
        """Execute a function tool call and check for HITL signal.

        ClarificationState has no sandbox — only host-side function tools
        (ask_user, confirm) are callable here.
        """
        from ..tools.execution import execute_function_tool, extract_hitl_signal

        result_str = await execute_function_tool(context, tool_call)
        hitl_signal = extract_hitl_signal(result_str, tool_call.name)

        if hitl_signal:
            # Add tool response to conversation before pausing
            tool_response = context.llm.create_tool_response_message(
                tool_call.name, result_str, tool_call.tool_call_id
            )
            context.add_conversation_message(tool_response)

            # Pause via HITLWaitState — resume back to ClarificationState
            # so we can rebuild history before transitioning to PlanningState
            from .hitl_wait import HITLWaitState
            context.transition_to(
                HITLWaitState(
                    hitl_signal=hitl_signal,
                    resume_state_name="ClarificationState",
                )
            )
        else:
            # ask_user didn't produce HITL signal — fallback to planning
            logger.warning(
                "ClarificationState: tool call did not produce HITL signal, "
                "falling back to PlanningState"
            )
            self._prepare_planning_history(context)
            from .planning import PlanningState
            context.transition_to(PlanningState())

    def _prepare_planning_history(self, context: "AgentContext") -> None:
        """Rebuild conversation history for PlanningState.

        Extracts the expert analysis and user answer from the current
        conversation and calls prepare_planning_history() on the LLM
        strategy, which builds the planning conversation with the
        expert context folded in.  Same pattern as PlanningState calling
        prepare_execution_history() before transitioning to ExecutingState.
        """
        expert_text = self._extract_expert_text(context)
        user_answer = self._extract_user_answer(context)

        # DEBUG: trace what flows into planning after HITL resume
        def _trunc(s, n=80): return (s[:n] + "...") if len(s) > n else s
        logger.info(
            "[HITL→Planning] inputs",
            context_task=_trunc(context.task or "<None>"),
            expert_text=_trunc(expert_text or "<empty>"),
            user_answer=_trunc(user_answer or "<empty>"),
        )

        planning_history = context.llm.prepare_planning_history(
            context, expert_text, user_answer
        )
        context.set_conversation_history(planning_history)

    @staticmethod
    def _extract_expert_text(context: "AgentContext") -> str:
        """Extract the expert analysis from conversation history.

        With forced tool_choice, GPT-4.1 puts ALL reasoning inside the
        ask_user tool call arguments (context + question fields) instead
        of companion assistant text.  We try both: first look for regular
        assistant text, then fall back to the ask_user call arguments.
        """
        from openai_harmony import Role
        from ..strategies.llm.base import message_to_text

        text_fragments = []
        tool_call_context = ""

        for msg in context.get_conversation_messages():
            role = getattr(getattr(msg, "author", None), "role", None)
            if role != Role.ASSISTANT:
                continue

            # Check for tool-call message (recipient = tool name)
            recipient = getattr(msg, "recipient", None)
            if recipient == "ask_user":
                # Extract expert analysis from the ask_user arguments.
                # The options array is the panel's curated alternatives —
                # without it the planner loses the framing the user chose
                # between and can't honour the panel's implicit scope.
                import json
                raw = message_to_text(msg)
                try:
                    args = json.loads(raw) if raw else {}
                except (json.JSONDecodeError, TypeError):
                    args = {}
                parts = []
                if args.get("context"):
                    parts.append(args["context"])
                if args.get("question"):
                    parts.append(args["question"])
                options = args.get("options") or []
                if options:
                    options_block = "\n".join(f"- {opt}" for opt in options)
                    parts.append(
                        "Expert panel offered these options:\n" + options_block
                    )
                tool_call_context = "\n\n".join(parts)
                continue

            text = message_to_text(msg)
            if text:
                text_fragments.append(text)

        # Prefer direct assistant text; fall back to ask_user arguments
        return "\n".join(text_fragments).strip() or tool_call_context.strip()

    @staticmethod
    def _extract_question(context: "AgentContext") -> str:
        """Extract the question text the panel asked via ask_user.

        Walks the conversation looking for an assistant tool call to
        ``ask_user`` and returns the ``question`` argument (plus options,
        if any) so ExpertSynthesisState can show it back to the panel.
        """
        import json
        from openai_harmony import Role
        from ..strategies.llm.base import message_to_text

        for msg in context.get_conversation_messages():
            role = getattr(getattr(msg, "author", None), "role", None)
            if role != Role.ASSISTANT:
                continue
            if getattr(msg, "recipient", None) != "ask_user":
                continue

            raw = message_to_text(msg)
            try:
                args = json.loads(raw) if raw else {}
            except (json.JSONDecodeError, TypeError):
                args = {}

            parts: List[str] = []
            if args.get("question"):
                parts.append(str(args["question"]))
            options = args.get("options") or []
            if options:
                parts.append(
                    "Options presented:\n"
                    + "\n".join(f"- {opt}" for opt in options)
                )
            return "\n\n".join(parts).strip()
        return ""

    @staticmethod
    def _extract_user_answer(context: "AgentContext") -> str:
        """Extract the last USER message (the clarification answer)."""
        from openai_harmony import Role
        from ..strategies.llm.base import message_to_text

        # Walk backwards to find the last user message
        for msg in reversed(context.get_conversation_messages()):
            role = getattr(getattr(msg, "author", None), "role", None)
            if role == Role.USER:
                return message_to_text(msg)
        return ""

    def _get_state_metadata(self, context: "AgentContext"):
        return StateResult(metadata={"type": "clarification"})
