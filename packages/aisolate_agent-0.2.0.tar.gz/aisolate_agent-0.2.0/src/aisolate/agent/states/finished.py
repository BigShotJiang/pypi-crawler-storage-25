"""Finished state implementation."""

from typing import TYPE_CHECKING

from ..core.protocols import State
from .base import AbstractState
from ..utils import get_logger

if TYPE_CHECKING:
    from ..core.context import AgentContext
    from ..memory.models import Message

logger = get_logger("aisolate.agent.states.finished")


class FinishedState:
    """A terminal state indicating the agent's work is done.

    This state simply marks the agent as finished and logs completion.
    No further processing or transitions occur from this state.
    """

    def on_enter(self, context: "AgentContext") -> None:
        pass

    async def handle(self, context: "AgentContext") -> None:
        """Mark execution as finished.

        This state is terminal - no further transitions should occur.
        """
        logger.info("Agent has finished its task.")
        context.execution.finished = True

    async def _pre_condition_check(self, context: "AgentContext") -> bool:
        """No preconditions needed for finished state."""
        return True

    async def _post_condition_check(
        self, context: "AgentContext", response_messages
    ) -> bool:
        """No postconditions needed for finished state."""
        return True
