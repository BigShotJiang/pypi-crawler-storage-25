"""Centralized logging configuration for the agent module."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class LoggingConfig:
    """Centralized logging configuration for the agent module."""

    # OpenTelemetry settings
    otel_service_name: str = "aisolate-agent"
    otel_endpoint: Optional[str] = None
    otel_headers: Optional[str] = None

    # Langfuse settings
    langfuse_public_key: Optional[str] = None
    langfuse_secret_key: Optional[str] = None
    langfuse_host: Optional[str] = None

    # Structlog settings
    log_level: str = "INFO"
    log_format: str = "json"  # "json" (production) | "console" (dev pretty-print)
    log_file: Optional[Path] = None
    console_width: int = 120

    # Agent-specific settings
    enable_file_logging: bool = True
    debug_dir: Optional[Path] = None
    enable_token_evolution: bool = True

    @classmethod
    def from_env(cls) -> "LoggingConfig":
        """Load configuration from environment variables."""
        return cls(
            # OpenTelemetry
            otel_service_name=os.getenv("OTEL_SERVICE_NAME", "aisolate-agent"),
            otel_endpoint=os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"),
            otel_headers=os.getenv("OTEL_EXPORTER_OTLP_HEADERS"),
            # Langfuse
            langfuse_public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
            langfuse_secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
            langfuse_host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
            # Structlog
            log_level=os.getenv("AISOLATE_AGENT_LOG_LEVEL", "INFO"),
            log_format=os.getenv("AISOLATE_AGENT_LOG_FORMAT", "json"),
            log_file=(
                Path(log_file)
                if (log_file := os.getenv("AISOLATE_AGENT_LOG_FILE"))
                else None
            ),
            console_width=int(os.getenv("AISOLATE_AGENT_CONSOLE_WIDTH", "120")),
            # Agent-specific
            enable_file_logging=os.getenv(
                "AISOLATE_AGENT_ENABLE_FILE_LOGGING", "true"
            ).lower()
            == "true",
            debug_dir=(
                Path(debug_dir)
                if (debug_dir := os.getenv("AISOLATE_AGENT_DEBUG_DIR", "./debug_logs"))
                else None
            ),
            enable_token_evolution=os.getenv(
                "AISOLATE_AGENT_ENABLE_TOKEN_EVOLUTION", "true"
            ).lower()
            == "true",
        )

    def get_debug_dir(self) -> Path:
        """Get the debug directory, creating it if necessary."""
        debug_dir = self.debug_dir or Path("./debug_logs")
        debug_dir.mkdir(parents=True, exist_ok=True)
        return debug_dir

    def is_langfuse_enabled(self) -> bool:
        """Check if Langfuse is properly configured."""
        return bool(self.langfuse_public_key and self.langfuse_secret_key)

    def is_otel_enabled(self) -> bool:
        """Check if OpenTelemetry is properly configured."""
        return bool(self.otel_endpoint)
