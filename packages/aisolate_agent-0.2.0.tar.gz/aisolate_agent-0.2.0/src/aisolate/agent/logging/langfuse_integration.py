"""Langfuse integration for agent LLM observability."""

from typing import Any, Dict, Optional
import uuid

from .config import LoggingConfig

# Optional Langfuse import
try:
    from langfuse import Langfuse
    from langfuse.model import CreateTrace, CreateGeneration, CreateSpan

    LANGFUSE_AVAILABLE = True
except ImportError:
    LANGFUSE_AVAILABLE = False


class AgentLangfuseObserver:
    """Langfuse integration for agent LLM observability."""

    def __init__(self, config: LoggingConfig):
        self.config = config
        self.langfuse = None
        self.current_trace = None

        if config.is_langfuse_enabled() and LANGFUSE_AVAILABLE:
            self.langfuse = Langfuse(
                public_key=config.langfuse_public_key,
                secret_key=config.langfuse_secret_key,
                host=config.langfuse_host,
            )

    def is_enabled(self) -> bool:
        """Check if Langfuse is enabled and available."""
        return self.langfuse is not None

    def trace_agent_session(self, task: str, session_id: Optional[str] = None):
        """Create a trace for an agent session."""
        if not self.is_enabled():
            return None

        trace_id = session_id or str(uuid.uuid4())

        self.current_trace = self.langfuse.trace(
            id=trace_id,
            name="agent_session",
            metadata={
                "task": task,
                "agent_type": "aisolate",
            },
        )

        return self.current_trace

    def log_llm_generation(
        self,
        model: str,
        prompt: str,
        response: str,
        usage: Optional[Dict[str, int]] = None,
        trace_id: Optional[str] = None,
    ):
        """Log an LLM generation to Langfuse."""
        if not self.is_enabled():
            return None

        trace = self.current_trace if not trace_id else self.langfuse.trace(id=trace_id)
        if not trace:
            return None

        generation = trace.generation(
            name="llm_generation",
            model=model,
            input=prompt,
            output=response,
            usage=usage or {},
            metadata={
                "provider": "harmony",
            },
        )

        return generation

    def log_tool_execution(
        self,
        tool_name: str,
        input_data: Any,
        output_data: Any,
        success: bool = True,
        error: Optional[str] = None,
        duration: Optional[float] = None,
        trace_id: Optional[str] = None,
    ):
        """Log tool execution to Langfuse."""
        if not self.is_enabled():
            return None

        trace = self.current_trace if not trace_id else self.langfuse.trace(id=trace_id)
        if not trace:
            return None

        metadata = {
            "tool_name": tool_name,
            "success": success,
        }

        if error:
            metadata["error"] = error
        if duration:
            metadata["duration_seconds"] = duration

        span = trace.span(
            name=f"tool_{tool_name}",
            input=input_data,
            output=output_data,
            metadata=metadata,
        )

        return span

    def log_state_transition(
        self,
        from_state: str,
        to_state: str,
        context: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ):
        """Log state transition to Langfuse."""
        if not self.is_enabled():
            return None

        trace = self.current_trace if not trace_id else self.langfuse.trace(id=trace_id)
        if not trace:
            return None

        span = trace.span(
            name="state_transition",
            input={"from_state": from_state},
            output={"to_state": to_state},
            metadata={
                "transition": f"{from_state} -> {to_state}",
                "context": context or {},
            },
        )

        return span

    def finalize_trace(self, result: Optional[str] = None, error: Optional[str] = None):
        """Finalize the current trace with final result."""
        if not self.is_enabled() or not self.current_trace:
            return

        self.current_trace.update(
            output=result,
            metadata={"completed": True, "error": error if error else None},
        )

        # Reset current trace
        self.current_trace = None

    def flush(self):
        """Flush pending events to Langfuse."""
        if self.is_enabled():
            self.langfuse.flush()
