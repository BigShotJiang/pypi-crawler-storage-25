"""Factory for creating and configuring structured loggers.

Architecture:
  structlog → JSON → stdout  (collected by Docker/K8s/log aggregator)
  Human display is handled separately by ConsoleTraceWriter → stderr

In dev mode (AISOLATE_AGENT_LOG_FORMAT=console), structlog uses
ConsoleRenderer for readable output. In production (default: json),
structlog emits one JSON object per line to stdout.
"""

import sys
import logging
from typing import Optional, Any

import structlog

from .config import LoggingConfig


def add_otel_context(logger, method_name, event_dict):
    """Attach current trace_id / span_id to every log record.

    Reads the active span from the global OTEL context. Only catches
    ImportError — other exceptions must propagate so observability bugs
    surface instead of being silently swallowed.
    """
    try:
        from opentelemetry import trace
    except ImportError:
        return event_dict
    span = trace.get_current_span()
    ctx = span.get_span_context() if span else None
    if ctx and ctx.trace_id:
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"] = format(ctx.span_id, "016x")
    return event_dict


class LoggerFactory:
    """Factory for creating properly configured loggers."""

    _initialized = False
    _config: Optional[LoggingConfig] = None

    @classmethod
    def setup_logging(cls, config: LoggingConfig) -> None:
        """Initialize global logging configuration."""
        if cls._initialized:
            return

        cls._config = config

        # Setup structlog
        cls._setup_structlog(config)

        cls._initialized = True

    @classmethod
    def _setup_structlog(cls, config: LoggingConfig) -> None:
        """Configure structlog pipeline.

        JSON mode (production): structured JSON lines → stdout → log collector
        Console mode (dev):     colored key=value lines → stdout (for humans)
        """
        processors: list = [
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.UnicodeDecoder(),
            add_otel_context,
        ]

        # Choose renderer: JSON for production, ConsoleRenderer for dev
        if config.log_format == "console":
            final_renderer = structlog.dev.ConsoleRenderer()
            # In console mode, suppress INFO noise so ConsoleTraceWriter
            # (the human-readable stderr output) is the primary display.
            # Raise to WARNING — errors and warnings still break through.
            effective_level = max(
                getattr(logging, config.log_level.upper(), logging.INFO),
                logging.WARNING,
            )
        else:
            # Default: JSON — one object per line, machine-parseable
            final_renderer = structlog.processors.JSONRenderer()
            effective_level = getattr(
                logging, config.log_level.upper(), logging.INFO
            )

        structlog.configure(
            processors=processors
            + [
                structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
            ],
            wrapper_class=structlog.stdlib.BoundLogger,
            logger_factory=structlog.stdlib.LoggerFactory(),
            cache_logger_on_first_use=True,
        )

        # Configure stdlib logging to go through structlog formatter
        root_logger = logging.getLogger()
        if not root_logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setLevel(effective_level)

            formatter = structlog.stdlib.ProcessorFormatter(
                processor=final_renderer,
            )
            handler.setFormatter(formatter)
            root_logger.addHandler(handler)
            root_logger.setLevel(effective_level)

    @classmethod
    def get_logger(cls, name: str) -> structlog.BoundLogger:
        """Get a logger for a specific component."""
        if not cls._initialized:
            # Initialize with default config if not already done
            cls.setup_logging(LoggingConfig.from_env())

        return structlog.get_logger(name)

    @classmethod
    def is_initialized(cls) -> bool:
        """Check if logging has been initialized."""
        return cls._initialized

    @classmethod
    def get_config(cls) -> Optional[LoggingConfig]:
        """Get the current logging configuration."""
        return cls._config
        """Get the current logging configuration."""
        return cls._config
