"""Unified logging interface — pure structured logging, no console rendering.

Architecture:
  UnifiedLogger.log_*()  →  structlog  →  JSON stdout  →  log collector
  Human-readable display is handled by ConsoleTraceWriter (trace.py → stderr)

The custom methods (log_model_response, log_tool_execution, etc.) exist to
emit rich structured events with standardized field names. They do NOT render
to the console — that responsibility belongs to the trace writers.
"""

import json
import logging
import traceback
from typing import Any, Optional

import structlog

from .config import LoggingConfig


class UnifiedLogger:
    """Structured logger for agent events.

    Wraps structlog with convenience methods for agent-specific events.
    All output goes through structlog → stdout as JSON (or console in dev).
    No Rich panels, no console.print().
    """

    def __init__(self, name: str, config: Optional[LoggingConfig] = None):
        self.config = config or LoggingConfig.from_env()
        self.name = name
        self._structlog_logger = structlog.get_logger(name)
        self._stdlib_logger = logging.getLogger(name)

    # ── Standard logging API ────────────────────────────────────────

    def debug(self, msg: str, *args, **kwargs):
        self._structlog_logger.debug(msg, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        self._structlog_logger.info(msg, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        self._structlog_logger.warning(msg, **kwargs)

    def warn(self, msg: str, *args, **kwargs):
        self.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        self._structlog_logger.error(msg, **kwargs)

    def exception(self, msg: str, *args, **kwargs):
        if "traceback" not in kwargs:
            kwargs["traceback"] = traceback.format_exc()
        self._structlog_logger.error(msg, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        self._structlog_logger.error(msg, level="critical", **kwargs)

    def fatal(self, msg: str, *args, **kwargs):
        self.critical(msg, *args, **kwargs)

    def log(self, level: int, msg: str, *args, **kwargs):
        level_name = logging.getLevelName(level).lower()
        if level_name in ("debug", "info", "warning", "error"):
            getattr(self._structlog_logger, level_name)(msg, **kwargs)
        else:
            self._structlog_logger.info(msg, level=level_name, **kwargs)

    # ── Agent-specific structured events ────────────────────────────

    def log_model_response(
        self,
        content: Optional[str] = None,
        tokens: Optional[list[int]] = None,
        metadata: Optional[dict[str, Any]] = None,
        title: str = "Model Response",
        agent_name: Optional[str] = None,
        messages: Optional[list] = None,
    ):
        """Emit structured log for an LLM response."""
        log_data: dict[str, Any] = {
            "content_length": len(content) if content else 0,
            "token_count": len(tokens) if tokens else 0,
            "metadata": metadata,
            "agent_name": agent_name,
        }

        if messages:
            log_data["message_count"] = len(messages)
            log_data["message_summary"] = [
                {
                    "role": str(
                        getattr(getattr(msg, "author", None), "role", "unknown")
                    ),
                    "channel": getattr(msg, "channel", None),
                    "recipient": getattr(msg, "recipient", None),
                    "content_type": getattr(msg, "content_type", None),
                }
                for msg in messages
            ]

        self._structlog_logger.info("Model response received", **log_data)

    def log_tool_execution(
        self,
        tool_name: str,
        arguments: Any,
        output: Optional[Any] = None,
        success: bool = True,
        error: Optional[Any] = None,
        duration: Optional[float] = None,
        agent_name: Optional[str] = None,
    ):
        """Emit structured log for a tool execution."""
        # Detect issues in output even when success=True
        has_issues = False
        if output:
            try:
                parsed = json.loads(output) if isinstance(output, str) else output
                if isinstance(parsed, dict) and parsed.get("ok") and parsed.get("error"):
                    has_issues = True
            except (json.JSONDecodeError, TypeError, ValueError):
                pass

        self._structlog_logger.debug(
            "Tool execution completed",
            tool_name=tool_name,
            agent_name=agent_name,
            success=success,
            has_issues=has_issues,
            args_type=type(arguments).__name__,
            args_count=len(arguments) if isinstance(arguments, dict) else 0,
            output_type=type(output).__name__ if output else None,
            output_length=len(output) if isinstance(output, str) else 0,
            duration=duration,
            error=str(error) if error else None,
        )

    def log_code_execution(
        self,
        code: str,
        result: Optional[Any] = None,
        success: bool = True,
        error: Optional[str] = None,
        stdout: Optional[str] = None,
        duration: Optional[float] = None,
        title: str = "Code Execution",
    ):
        """Emit structured log for code execution."""
        self._structlog_logger.debug(
            "Code execution completed",
            success=success,
            code_lines=len(code.splitlines()) if code else 0,
            stdout_length=len(stdout) if stdout else 0,
            has_result=result is not None,
            duration=duration,
            error=error if not success else None,
        )

    def log_session_start(self, config: dict[str, Any]):
        """Emit structured log for session start."""
        self._structlog_logger.info("Session started", config=config)

    def log_session_end(self, summary: dict[str, Any]):
        """Emit structured log for session end."""
        self._structlog_logger.info("Session ended", summary=summary)

    def log_exception(self, exc: Exception, context: str = ""):
        """Emit structured log for an exception."""
        self._structlog_logger.error(
            "Exception occurred",
            exception_type=type(exc).__name__,
            exception_message=str(exc),
            context=context,
            traceback=traceback.format_exc(),
        )

    def log_conversation_step(self, step_num: int, total_steps: int, description: str):
        """Emit structured log for a conversation step."""
        self._structlog_logger.debug(
            "Conversation step",
            step=step_num,
            total_steps=total_steps,
            description=description,
        )

    # ── Structlog compatibility ─────────────────────────────────────

    def bind(self, **kwargs):
        return BoundUnifiedLogger(self, kwargs)

    def get_structlog_logger(self):
        return self._structlog_logger


class BoundUnifiedLogger(UnifiedLogger):
    """A bound logger that includes additional context."""

    def __init__(self, parent_logger: UnifiedLogger, bound_context: dict[str, Any]):
        self.parent_logger = parent_logger
        self.bound_context = bound_context
        self.config = parent_logger.config
        self.name = parent_logger.name

        self._structlog_logger = parent_logger._structlog_logger.bind(**bound_context)
        self._stdlib_logger = parent_logger._stdlib_logger

    def bind(self, **kwargs):
        new_context = {**self.bound_context, **kwargs}
        return BoundUnifiedLogger(self.parent_logger, new_context)


def get_logger(name: str) -> UnifiedLogger:
    """Get a unified logger instance.

    Args:
        name: Logger name (e.g., "aisolate.agent.core")

    Returns:
        UnifiedLogger instance
    """
    return UnifiedLogger(name)
