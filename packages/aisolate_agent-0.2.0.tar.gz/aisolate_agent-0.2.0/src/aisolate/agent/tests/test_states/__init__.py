"""Tests for state metadata functionality."""
