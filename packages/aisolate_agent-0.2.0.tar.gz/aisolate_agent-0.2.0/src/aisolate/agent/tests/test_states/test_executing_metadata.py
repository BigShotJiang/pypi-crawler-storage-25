"""Tests for ExecutingState metadata generation.

Verifies that ExecutingState correctly tracks and structures tool execution
metadata for client streaming events (SSE).
"""

import pytest
from unittest.mock import AsyncMock, Mock, patch
from datetime import datetime

from aisolate.agent.states.executing import ExecutingState
from aisolate.agent.states.base import StateResult
from aisolate.agent.core.context import AgentContext
from aisolate.agent.tools.models import ToolCall, ToolExecutionResult, FinalAnswerResult


class TestExecutingStateMetadata:
    """Test suite for ExecutingState metadata generation."""

    @pytest.fixture
    def mock_sandbox(self):
        """Provide a mock sandbox."""
        sandbox = AsyncMock()
        sandbox.is_connected = True
        return sandbox

    @pytest.fixture
    def mock_memory(self):
        """Provide a mock memory strategy."""
        memory = AsyncMock()
        memory.initialize_context = AsyncMock()
        memory.persist_turn_completion = AsyncMock()
        return memory

    @pytest.fixture
    def mock_llm(self):
        """Provide a mock LLM strategy."""
        llm = Mock()
        llm.generate_response = AsyncMock()
        llm.create_tool_response_message = Mock(return_value=Mock())
        return llm

    @pytest.fixture
    def context(self, mock_sandbox, mock_memory, mock_llm):
        """Create a basic context for testing."""
        return AgentContext(
            agent_name="test_agent",
            task="Test task",
            llm=mock_llm,
            memory=mock_memory,
            sandbox=mock_sandbox,
            max_turns=10,
        )

    @pytest.fixture
    def mock_tool_call(self):
        """Create a mock tool call."""
        return ToolCall(
            name="web_search",
            arguments={"query": "test query"},
            tool_call_id="call_123",
        )

    @pytest.fixture
    def mock_tool_result_success(self):
        """Create a successful tool execution result."""
        return ToolExecutionResult(
            output="Search results: Found 10 relevant documents about test query",
            final_answer=None,
            error=None,
        )

    @pytest.fixture
    def mock_tool_result_with_final_answer(self):
        """Create a tool result with final answer."""
        return ToolExecutionResult(
            output="Final answer generated",
            final_answer=FinalAnswerResult(
                answer="The answer to your question is 42",
                sources=[{"source": "source1"}, {"source": "source2"}],
                confidence=0.95,
            ),
            error=None,
        )

    @pytest.fixture
    def mock_tool_result_error(self):
        """Create a failed tool execution result."""
        return ToolExecutionResult(
            output="", final_answer=None, error="Tool execution failed: Network timeout"
        )

    @pytest.mark.asyncio
    async def test_last_tool_execution_tracking(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Test that tool execution is tracked in instance variable."""
        state = ExecutingState()

        # Initially no execution
        assert state._last_tool_execution is None

        # Mock execute_tool_call
        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        # Should now have tracked execution
        assert state._last_tool_execution is not None
        assert state._last_tool_execution["name"] == "web_search"
        assert state._last_tool_execution["success"] is True

    @pytest.mark.asyncio
    async def test_get_state_metadata_with_tool_execution(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Test that _get_state_metadata returns correct structure."""
        state = ExecutingState()

        # Execute a tool call
        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        # Get metadata
        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None

        # Verify metadata structure
        metadata = result.metadata
        assert metadata["type"] == "tool_execution"
        assert metadata["tool_name"] == "web_search"
        assert "arguments" in metadata
        assert "success" in metadata
        assert "output" in metadata
        assert "error" in metadata
        assert "has_final_answer" in metadata
        assert "turn" in metadata
        assert "timestamp" in metadata

    @pytest.mark.asyncio
    async def test_metadata_tool_details(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Test that tool details are correctly captured."""
        state = ExecutingState()

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Verify tool details
        assert metadata["tool_name"] == "web_search"
        assert metadata["arguments"] == {"query": "test query"}
        assert metadata["success"] is True
        assert metadata["has_final_answer"] is False

    @pytest.mark.asyncio
    async def test_metadata_output_long(self, context, mock_tool_call):
        """Test that long outputs are passed through in full."""
        state = ExecutingState()

        # Create result with long output
        long_output = "A" * 1000  # 1000 characters
        long_result = ToolExecutionResult(
            output=long_output, final_answer=None, error=None
        )

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=long_result,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Full output is sent (no truncation)
        assert metadata["output"] == long_output

    @pytest.mark.asyncio
    async def test_metadata_no_execution_returns_none(self, context):
        """Test that metadata returns None when no tool has been executed."""
        state = ExecutingState()

        # No execution yet
        result = state._get_state_metadata(context)

        # Should return None
        assert result is None

    @pytest.mark.asyncio
    async def test_metadata_with_error(
        self, context, mock_tool_call, mock_tool_result_error
    ):
        """Test metadata when tool execution fails."""
        state = ExecutingState()

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_error,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Verify error details
        assert metadata["success"] is False
        assert metadata["error"] == "Tool execution failed: Network timeout"
        assert metadata["output"] is None or metadata["output"] == ""

    @pytest.mark.asyncio
    async def test_metadata_with_final_answer(
        self, context, mock_tool_call, mock_tool_result_with_final_answer
    ):
        """Test metadata when tool produces final answer."""
        state = ExecutingState()

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_with_final_answer,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Verify final answer flag
        assert metadata["has_final_answer"] is True
        assert metadata["success"] is True

    @pytest.mark.asyncio
    async def test_metadata_timestamp_format(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Test that timestamp is in correct ISO format."""
        state = ExecutingState()

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata
        timestamp = metadata["timestamp"]

        # Verify it's a valid ISO timestamp
        assert isinstance(timestamp, str)
        # Should be parseable
        datetime.fromisoformat(timestamp.replace("Z", "+00:00"))

    @pytest.mark.asyncio
    async def test_metadata_includes_turn_number(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Test that metadata includes the current turn number."""
        state = ExecutingState()

        # Set turn number
        context.execution.turn = 7

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        assert metadata["turn"] == 7

    @pytest.mark.asyncio
    async def test_metadata_non_string_output(self, context, mock_tool_call):
        """Test that non-string outputs are converted to string."""
        state = ExecutingState()

        # Create result with string representation of dict
        dict_output = '{"key": "value", "count": 42}'
        dict_result = ToolExecutionResult(
            output=dict_output, final_answer=None, error=None
        )

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=dict_result,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Should have string representation
        assert isinstance(metadata["output"], str)
        assert "key" in metadata["output"]
        assert "value" in metadata["output"]

    @pytest.mark.asyncio
    async def test_metadata_is_for_streaming_not_persistence(
        self, context, mock_tool_call, mock_tool_result_success
    ):
        """Verify that metadata is designed for streaming, not persistence.

        This test documents the architectural decision that state metadata
        is for real-time client updates via SSE, not for storage.
        """
        state = ExecutingState()

        with patch(
            "aisolate.agent.states.executing.execute_tool_call",
            return_value=mock_tool_result_success,
        ):
            await state._handle_tool_call(context, mock_tool_call)

        result = state._get_state_metadata(context)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None
        metadata = result.metadata

        # Metadata should be lightweight and client-focused
        assert "type" in metadata  # For client routing
        assert "tool_name" in metadata  # For UI display
        assert "output" in metadata  # Full output for streaming
        assert "timestamp" in metadata  # For event ordering

        # Should NOT contain persistence-specific data
        assert "conversation_id" not in metadata
        assert "execution_state" not in metadata


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
