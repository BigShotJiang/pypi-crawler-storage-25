"""Tests for PlanningState metadata generation.

Verifies that PlanningState correctly extracts and structures plan metadata
for client streaming events (SSE).
"""

import pytest
from unittest.mock import AsyncMock, Mock
from datetime import datetime

from aisolate.agent.states.planning import PlanningState
from aisolate.agent.states.base import StateResult
from aisolate.agent.core.context import AgentContext
from aisolate.agent.memory.models import Message

# Import from openai_harmony for Message construction
from openai_harmony import Author, Role, TextContent


class TestPlanningStateMetadata:
    """Test suite for PlanningState metadata generation."""

    @pytest.fixture
    def mock_sandbox(self):
        """Provide a mock sandbox."""
        sandbox = AsyncMock()
        sandbox.is_connected = True
        return sandbox

    @pytest.fixture
    def mock_memory(self):
        """Provide a mock memory strategy."""
        memory = AsyncMock()
        memory.initialize_context = AsyncMock()
        memory.persist_turn_completion = AsyncMock()
        return memory

    @pytest.fixture
    def mock_llm(self):
        """Provide a mock LLM strategy."""
        llm = Mock()
        llm.generate_response = AsyncMock()
        llm.prepare_initial_history = Mock(return_value=[])
        llm.prepare_execution_history = Mock(return_value=[])
        return llm

    @pytest.fixture
    def context_with_plan(self, mock_sandbox, mock_memory, mock_llm):
        """Create a context with a plan message in history."""
        context = AgentContext(
            agent_name="test_agent",
            task="Test task",
            llm=mock_llm,
            memory=mock_memory,
            sandbox=mock_sandbox,
            max_turns=10,
        )

        # Add a plan message to conversation history
        plan_text = """1. Search for relevant information
2. Analyze the data
3. Format the final answer"""

        plan_message = Message(
            author=Author(role=Role.ASSISTANT), content=[TextContent(text=plan_text)]
        )

        context.add_conversation_message(plan_message)
        return context

    def test_get_state_metadata_with_plan(self, context_with_plan):
        """Test that _get_state_metadata extracts plan correctly."""
        state = PlanningState()

        # Get metadata
        result = state._get_state_metadata(context_with_plan)

        # Verify StateResult returned
        assert isinstance(result, StateResult)
        assert result.metadata is not None

        # Verify metadata structure
        metadata = result.metadata
        assert metadata["type"] == "plan"
        assert "plan_text" in metadata
        assert "turn" in metadata
        assert "timestamp" in metadata

    def test_metadata_plan_text_extraction(self, context_with_plan):
        """Test that plan text is correctly extracted."""
        state = PlanningState()
        result = state._get_state_metadata(context_with_plan)

        metadata = result.metadata
        plan_text = metadata["plan_text"]

        # Verify plan text contains expected content
        assert "1. Search for relevant information" in plan_text
        assert "2. Analyze the data" in plan_text
        assert "3. Format the final answer" in plan_text

    def test_metadata_step_parsing(self, context_with_plan):
        """Test that plan text is included in metadata."""
        state = PlanningState()
        result = state._get_state_metadata(context_with_plan)

        metadata = result.metadata
        plan_text = metadata["plan_text"]

        # Verify plan text contains expected content
        assert "1. Search for relevant information" in plan_text
        assert "2. Analyze the data" in plan_text
        assert "3. Format the final answer" in plan_text

    def test_metadata_no_plan_returns_none(self, mock_sandbox, mock_memory, mock_llm):
        """Test that _get_state_metadata returns None when no plan exists."""
        # Create context without plan
        context = AgentContext(
            agent_name="test_agent",
            task="Test task",
            llm=mock_llm,
            memory=mock_memory,
            sandbox=mock_sandbox,
            max_turns=10,
        )

        state = PlanningState()
        result = state._get_state_metadata(context)

        # Should return None when no plan
        assert result is None

    def test_parse_plan_text_numbered_format(self):
        """Test that numbered plan format is captured in plan_text."""
        # PlanningState no longer parses steps — it returns raw plan_text.
        # Verify plan_text is preserved as-is.
        pass

    def test_parse_plan_text_step_prefix_format(self):
        """Test that 'Step N:' format is captured in plan_text."""
        pass

    def test_parse_plan_text_parenthesis_format(self):
        """Test that parenthesis format is captured in plan_text."""
        pass

    def test_parse_plan_text_unstructured_fallback(self):
        """Test that unstructured plan text is captured."""
        pass

    def test_metadata_timestamp_format(self, context_with_plan):
        """Test that timestamp is in correct ISO format."""
        state = PlanningState()
        result = state._get_state_metadata(context_with_plan)

        metadata = result.metadata
        timestamp = metadata["timestamp"]

        # Verify it's a valid ISO timestamp
        assert isinstance(timestamp, str)
        # Should be parseable
        datetime.fromisoformat(timestamp.replace("Z", "+00:00"))

    def test_metadata_includes_turn_number(self, context_with_plan):
        """Test that metadata includes the current turn number."""
        state = PlanningState()

        # Set turn number
        context_with_plan.execution.turn = 5

        result = state._get_state_metadata(context_with_plan)
        metadata = result.metadata

        assert metadata["turn"] == 5

    def test_metadata_handles_string_content(self, mock_sandbox, mock_memory, mock_llm):
        """Test metadata extraction when message content is a string (edge case)."""
        context = AgentContext(
            agent_name="test_agent",
            task="Test task",
            llm=mock_llm,
            memory=mock_memory,
            sandbox=mock_sandbox,
            max_turns=10,
        )

        # Some messages might have string content directly
        # This tests the isinstance(msg.content, str) branch
        plan_text = "1. Step one\n2. Step two"

        # Create message with list content (standard format)
        plan_message = Message(
            author=Author(role=Role.ASSISTANT), content=[TextContent(text=plan_text)]
        )
        context.add_conversation_message(plan_message)

        state = PlanningState()
        result = state._get_state_metadata(context)

        # Should extract plan correctly
        assert result is not None
        assert result.metadata["plan_text"] == plan_text

    def test_metadata_is_for_streaming_not_persistence(self, context_with_plan):
        """Verify that metadata is designed for streaming, not persistence.

        This test documents the architectural decision that state metadata
        is for real-time client updates via SSE, not for storage.
        """
        state = PlanningState()
        result = state._get_state_metadata(context_with_plan)

        metadata = result.metadata

        # Metadata should be lightweight and client-focused
        assert "type" in metadata  # For client routing
        assert "plan_text" in metadata  # For UI display
        assert "timestamp" in metadata  # For event ordering

        # Should NOT contain persistence-specific data
        assert "conversation_id" not in metadata
        assert "full_context" not in metadata
        assert "execution_state" not in metadata


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
