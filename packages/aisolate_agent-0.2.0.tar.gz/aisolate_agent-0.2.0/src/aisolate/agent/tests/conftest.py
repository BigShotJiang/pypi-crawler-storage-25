"""Test configuration and shared fixtures for agent tests."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock
from typing import List, Dict, Any, Optional

from aisolate.agent.core.llm_response import LLMResponse


# Mock classes for testing
class MockSandbox:
    """Mock sandbox for testing."""

    def __init__(self):
        self.is_connected = True

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass


class MockLLMStrategy:
    """Mock LLM strategy for testing."""

    def __init__(self, responses: Optional[List[str]] = None):
        self.responses = responses or ["Test response"]
        self.call_count = 0

    async def generate_response(self, context) -> LLMResponse:
        response = self.responses[min(self.call_count, len(self.responses) - 1)]
        self.call_count += 1
        return LLMResponse(messages=[Mock(content=response)])

    def prepare_initial_history(self, task: str) -> List:
        return [Mock(content=f"Initial history for: {task}")]

    def prepare_execution_history(self, task: str, plan: str) -> List:
        return [Mock(content=f"Execution history for: {task}, plan: {plan}")]

    def parse_assistant_response(self, messages: List) -> tuple:
        # Return (tool_call, final_answer) where final_answer is FinalAnswerResult
        from ..tools.models import FinalAnswerResult

        return None, FinalAnswerResult(answer="Test final answer")


class MockMemoryStrategy:
    """Mock memory strategy for testing with new interface."""

    def __init__(self):
        self.snapshots = {}

    async def initialize_context(self, context) -> None:
        """Restore context if conversation_id exists."""
        if not context.conversation_id:
            return

        snapshot = self.snapshots.get(context.conversation_id)
        if snapshot:
            # Restore conversation history
            messages = snapshot.get("conversation_history", [])
            context.set_conversation_history(messages)

            # Restore execution state
            execution = snapshot.get("execution", {})
            context.execution.turn = execution.get("turn", 0)
            context.execution.finished = execution.get("finished", False)

    async def persist_turn_completion(self, context) -> None:
        """Persist turn completion."""
        if not context.conversation_id:
            return

        self.snapshots[context.conversation_id] = {
            "conversation_history": context.get_conversation_messages(),
            "execution": {
                "turn": context.execution.turn,
                "finished": context.execution.finished,
            },
            "final_answer": context.final_answer,
        }

    async def get_available_snapshots(
        self, conversation_id: str
    ) -> List[Dict[str, Any]]:
        """Return available snapshots."""
        snapshot = self.snapshots.get(conversation_id)
        if not snapshot:
            return []

        return [
            {
                "turn": snapshot["execution"]["turn"],
                "finished": snapshot["execution"]["finished"],
            }
        ]

    async def restore_to_turn(
        self, conversation_id: str, turn_number: int, context
    ) -> bool:
        """Restore to specific turn."""
        await self.initialize_context(context)
        return True


class MockRemotePythonExecutor:
    """Mock remote Python executor for testing."""

    def __init__(self, sandbox, actions):
        self.sandbox = sandbox
        self.actions = actions

    async def python_exec(self, code: str):
        return Mock(model_dump_json=lambda: '{"result": "mock execution result"}')

    async def send_actions(self, actions):
        pass


@pytest.fixture
def mock_sandbox():
    """Provide a mock sandbox for testing."""
    return MockSandbox()


@pytest.fixture
def mock_llm_strategy():
    """Provide a mock LLM strategy for testing."""
    return MockLLMStrategy()


@pytest.fixture
def mock_memory_strategy():
    """Provide a mock memory strategy for testing."""
    return MockMemoryStrategy()


@pytest.fixture
def mock_remote_executor():
    """Provide a mock remote executor for testing."""
    return MockRemotePythonExecutor(MockSandbox(), {})


@pytest.fixture
def sample_task():
    """Provide a sample task for testing."""
    return "Calculate the sum of 1 + 1"


@pytest.fixture
def sample_plan():
    """Provide a sample plan for testing."""
    return "I will use Python to calculate 1 + 1"
