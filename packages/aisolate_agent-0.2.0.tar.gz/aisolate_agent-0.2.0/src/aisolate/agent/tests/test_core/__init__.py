"""Tests for core agent functionality."""
