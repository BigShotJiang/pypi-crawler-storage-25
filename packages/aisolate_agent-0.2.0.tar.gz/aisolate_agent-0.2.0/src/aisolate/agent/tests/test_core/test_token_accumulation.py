"""Tests for token usage accumulation across turns in AgentContext."""

import pytest

from aisolate.agent.core.context import AgentContext
from aisolate.agent.core.llm_response import TokenUsage
from aisolate.agent.strategies.memory import InMemoryStrategy
from ..conftest import MockLLMStrategy, MockSandbox


@pytest.fixture
def context():
    return AgentContext(
        agent_name="test_agent",
        task="test task",
        llm=MockLLMStrategy(),
        memory=InMemoryStrategy(),
        sandbox=MockSandbox(),
        max_turns=10,
        conversation_id="test-conv-123",
    )


def test_initial_cumulative_usage_is_zero(context):
    usage = context.cumulative_usage
    assert usage.input_tokens == 0
    assert usage.output_tokens == 0
    assert usage.reasoning_tokens == 0
    assert usage.total_tokens == 0


def test_initial_last_turn_usage_is_none(context):
    assert context.last_turn_usage is None


def test_single_accumulation(context):
    context.accumulate_usage(
        TokenUsage(input_tokens=100, output_tokens=50, reasoning_tokens=10)
    )

    assert context.cumulative_usage.input_tokens == 100
    assert context.cumulative_usage.output_tokens == 50
    assert context.cumulative_usage.reasoning_tokens == 10
    assert context.cumulative_usage.total_tokens == 150


def test_last_turn_usage_tracks_most_recent(context):
    first = TokenUsage(input_tokens=100, output_tokens=50)
    second = TokenUsage(input_tokens=200, output_tokens=80)

    context.accumulate_usage(first)
    assert context.last_turn_usage.input_tokens == 100

    context.accumulate_usage(second)
    assert context.last_turn_usage.input_tokens == 200
    assert context.last_turn_usage.output_tokens == 80


def test_multi_turn_accumulation(context):
    turns = [
        TokenUsage(input_tokens=100, output_tokens=50, reasoning_tokens=10),
        TokenUsage(input_tokens=200, output_tokens=80, reasoning_tokens=20),
        TokenUsage(input_tokens=150, output_tokens=60, reasoning_tokens=0),
    ]
    for usage in turns:
        context.accumulate_usage(usage)

    cumulative = context.cumulative_usage
    assert cumulative.input_tokens == 450
    assert cumulative.output_tokens == 190
    assert cumulative.reasoning_tokens == 30
    assert cumulative.total_tokens == 640


def test_snapshot_captures_cumulative_usage(context):
    context.accumulate_usage(
        TokenUsage(input_tokens=100, output_tokens=50, reasoning_tokens=10)
    )
    context.accumulate_usage(
        TokenUsage(input_tokens=200, output_tokens=80, reasoning_tokens=5)
    )

    snapshot = context.create_snapshot()

    assert snapshot.token_usage == {
        "input_tokens": 300,
        "output_tokens": 130,
        "reasoning_tokens": 15,
        "cached_tokens": 0,
    }


def test_accumulate_with_zero_usage_is_noop(context):
    context.accumulate_usage(TokenUsage(input_tokens=100, output_tokens=50))
    context.accumulate_usage(TokenUsage())  # all zeros

    assert context.cumulative_usage.input_tokens == 100
    assert context.cumulative_usage.output_tokens == 50
    assert context.cumulative_usage.total_tokens == 150
