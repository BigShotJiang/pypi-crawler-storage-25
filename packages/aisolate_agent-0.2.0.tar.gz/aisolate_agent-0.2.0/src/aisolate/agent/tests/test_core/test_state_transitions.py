"""Unit tests for agent state transitions and error recovery."""

import pytest
from unittest.mock import Mock
from aisolate.agent.states import (
    PlanningState,
    ExecutingState,
    FinishedState,
    ErrorRecoveryState,
    ReflectionState,
)
from aisolate.agent.core.context import AgentContext
from aisolate.agent.core.llm_response import LLMResponse
from aisolate.agent.strategies.memory import InMemoryStrategy
from aisolate.agent.strategies.llm import HarmonyLLMStrategy
from ..conftest import MockSandbox


class DummyLLM(HarmonyLLMStrategy):
    def __init__(self):
        super().__init__(templates={})

    async def generate_response(self, context):
        # Return at least one message so base _post_condition_check passes
        msg = Mock()
        msg.content = "1. Execute the task\n2. Return result"
        msg.author = Mock()
        msg.author.role = "assistant"
        return LLMResponse(messages=[msg])

    def prepare_initial_history(self, task):
        return []

    def prepare_execution_history(self, context, plan):
        return []

    def parse_assistant_response(self, messages):
        return None, "dummy plan"


@pytest.fixture
def dummy_context():
    return AgentContext(
        agent_name="test_agent",
        task="test",
        llm=DummyLLM(),
        memory=InMemoryStrategy(),
        sandbox=MockSandbox(),
        max_turns=5,
    )


@pytest.mark.asyncio
async def test_planning_to_executing(dummy_context):
    dummy_context.transition_to(PlanningState())
    await dummy_context.execute_turn()
    assert isinstance(dummy_context._state, ExecutingState)


@pytest.mark.asyncio
async def test_error_recovery(dummy_context):
    # max_attempts=0 means immediate transition to FinishedState
    dummy_context.transition_to(
        ErrorRecoveryState(Exception("fail"), recovery_attempt=0, max_attempts=0)
    )
    await dummy_context.execute_turn()
    assert isinstance(dummy_context._state, FinishedState)


@pytest.mark.asyncio
async def test_reflection_state(dummy_context):
    # ReflectionState._process_response accesses context.long_term_memory
    dummy_context.long_term_memory = []
    dummy_context.transition_to(ReflectionState())
    await dummy_context.execute_turn()
    assert isinstance(dummy_context._state, FinishedState)
