"""Integration test for full agent workflow against a real sandbox and LLM.

Requires:
    - Sandbox container running:
        docker run -e DEBUG=1 --rm --name aisolate -p 8080:8080 --device /dev/kvm chrisber/aisolate
    - LLM endpoint available at OLLAMA_BASE_URL (default http://localhost:8000)

Set environment variables to configure:
    SANDBOX_URL        = http://localhost:8080  (default)
    OLLAMA_BASE_URL    = http://localhost:8000  (default)
    OLLAMA_MODEL       = gpt-oss:20b           (default)

Skipped automatically when sandbox or LLM is unreachable.
"""

import os
import pytest
import httpx

from aisolate.client.sandbox import Sandbox
from aisolate.agent.agent import Agent
from aisolate.agent.strategies.llm import HarmonyLLMStrategy
from aisolate.agent.strategies.memory import InMemoryStrategy
from aisolate.agent.config.agent_settings import AgentSettings

SANDBOX_URL = os.environ.get("SANDBOX_URL", "http://localhost:8080")
LLM_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:8000")


def _is_reachable(url: str, path: str = "/") -> bool:
    """Check if an HTTP endpoint is reachable (synchronous, fast)."""
    try:
        r = httpx.get(f"{url.rstrip('/')}{path}", timeout=3.0)
        return r.status_code < 500
    except (httpx.ConnectError, httpx.TimeoutException, OSError):
        return False


# Skip the entire module when infrastructure isn't available
pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not _is_reachable(SANDBOX_URL, "/health"),
        reason=f"Sandbox not reachable at {SANDBOX_URL}",
    ),
    pytest.mark.skipif(
        not _is_reachable(LLM_BASE_URL, "/v1/models"),
        reason=f"LLM not reachable at {LLM_BASE_URL}",
    ),
]


@pytest.fixture
def sandbox_url():
    return SANDBOX_URL


@pytest.fixture
def llm_strategy():
    return HarmonyLLMStrategy(base_url=LLM_BASE_URL)


@pytest.fixture
def memory_strategy():
    return InMemoryStrategy()


@pytest.mark.asyncio
async def test_full_agent_workflow(sandbox_url, llm_strategy, memory_strategy):
    """Test a complete agent run: planning → executing → finished.

    The agent receives a simple arithmetic task, uses the sandbox to
    run Python code, and returns a final answer.
    """
    async with Sandbox(domain=sandbox_url) as sbx:
        settings = AgentSettings(max_turns=10, debug_mode=True)
        agent = Agent(
            name="integration_test_agent",
            description="Agent for integration testing",
            llm_strategy=llm_strategy,
            memory_strategy=memory_strategy,
            sandbox=sbx,
            settings=settings,
        )

        result = await agent.run("What is 7 * 6? Use Python to calculate it.")

        # FinalAnswerResult should be returned
        assert result is not None
        assert result.answer is not None
        assert len(str(result.answer)) > 0


@pytest.mark.asyncio
async def test_agent_streaming_events(sandbox_url, llm_strategy, memory_strategy):
    """Test that streaming events are emitted during agent execution."""
    import uuid

    async with Sandbox(domain=sandbox_url) as sbx:
        settings = AgentSettings(max_turns=10, debug_mode=True)
        agent = Agent(
            name="streaming_test_agent",
            description="Agent for streaming event testing",
            llm_strategy=llm_strategy,
            memory_strategy=memory_strategy,
            sandbox=sbx,
            settings=settings,
        )

        events = []
        conversation_id = str(uuid.uuid4())
        async for event in agent.run_streaming("What is 2 + 2?", conversation_id):
            events.append(event)

        # Should have at least started + finished events
        event_types = [getattr(e, "type", None) for e in events]
        assert "agent_started" in event_types
        assert "agent_finished" in event_types
