"""Integration tests for agent workflow."""
