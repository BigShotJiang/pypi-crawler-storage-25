"""Tests for the aisolate agent package."""
