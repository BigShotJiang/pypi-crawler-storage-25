"""Tests for three-tier tool system."""
