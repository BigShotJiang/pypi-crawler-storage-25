"""Unit tests for three-tier tool system."""

import pytest
from aisolate.agent.tools.platform import WebSearchTool, PythonExecutorTool
from aisolate.agent.tools.actions import FinalAnswerAction
from aisolate.agent.tools.actions.web_search_action import WebSearchAction
from aisolate.agent.core.context import AgentContext
from unittest.mock import Mock


@pytest.fixture
def mock_context():
    """Create a mock AgentContext for testing."""
    context = Mock(spec=AgentContext)
    context.sandbox = Mock()
    context.memory = Mock()
    return context


@pytest.mark.asyncio
async def test_platform_tool_execution(mock_context):
    """Test platform tool execution."""
    tool = WebSearchTool()
    # Platform tools should have async execute methods
    result = await tool.execute(mock_context, query="Python")
    assert isinstance(result, str)


@pytest.mark.asyncio
async def test_code_action_execution():
    """Test code action execution (synchronous)."""
    action = WebSearchAction()
    # Code actions have synchronous execute and __call__ methods
    result = action(query="Berlin weather")
    assert isinstance(result, str)


@pytest.mark.asyncio
async def test_final_answer_action():
    """Test final answer action execution."""
    action = FinalAnswerAction()
    result = action(
        answer={
            "result": "42",
            "sources": [],
            "metadata": {},
        }
    )
    assert result["result"] == "42"
