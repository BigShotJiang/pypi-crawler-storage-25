"""Unit tests for LLM provider abstraction layer."""

import pytest
from openai_harmony import Author, Message, Role
from aisolate.agent.strategies.llm import (
    BaseLLMStrategy,
    HarmonyLLMStrategy,
    OpenAILLMStrategy,
)
from aisolate.agent.core.llm_response import TokenUsage, LLMResponse
from aisolate.agent.tools.models import ToolCall


@pytest.mark.asyncio
async def test_harmony_llm_strategy():
    llm = HarmonyLLMStrategy(base_url="http://localhost:11434", templates={})
    # Should implement all required methods
    assert hasattr(llm, "generate_response")
    assert hasattr(llm, "prepare_initial_history")
    assert hasattr(llm, "prepare_execution_history")
    assert hasattr(llm, "parse_assistant_response")
    assert hasattr(llm, "create_tool_response_message")
    assert hasattr(llm, "format_subagent_task")
    assert isinstance(llm, BaseLLMStrategy)


@pytest.mark.asyncio
async def test_openai_llm_strategy():
    llm = OpenAILLMStrategy(api_key="test-key", model="gpt-4")
    assert hasattr(llm, "generate_response")
    assert hasattr(llm, "prepare_initial_history")
    assert hasattr(llm, "prepare_execution_history")
    assert hasattr(llm, "parse_assistant_response")
    assert hasattr(llm, "create_tool_response_message")
    assert hasattr(llm, "format_subagent_task")
    assert isinstance(llm, BaseLLMStrategy)


def test_base_create_tool_response_message():
    """Base class creates a standard tool response message."""
    base = BaseLLMStrategy()
    msg = base.create_tool_response_message("my_tool", "result text")
    assert msg is not None
    assert getattr(msg.author, "role", None) == Role.TOOL


def test_base_format_subagent_task():
    """Base class renders subagent task from templates."""
    base = BaseLLMStrategy(
        templates={"sub_agent": {"task": "Agent {{name}}: {{task}}"}}
    )
    result = base.format_subagent_task("researcher", "find papers")
    assert "researcher" in result
    assert "find papers" in result


def test_base_get_tool_name_with_overrides():
    """get_tool_name applies overrides from namespace_config."""
    base = BaseLLMStrategy(
        namespace_config={
            "separator": "_",
            "function_prefix": "fn_",
            "agent_prefix": "ag_",
            "tool_name_overrides": {"python": "code_interpreter"},
        }
    )
    assert base.get_tool_name("python") == "code_interpreter"
    assert base.get_tool_name("websearch") == "websearch"


def test_base_parse_assistant_response_tool_call():
    """Base parse_assistant_response extracts tool calls from messages."""
    msg = Message.from_role_and_content(Role.ASSISTANT, '{"query": "test"}')
    msg = msg.with_recipient("websearch").with_channel("tool_call")
    tool_call, text = BaseLLMStrategy().parse_assistant_response([msg])
    assert tool_call is not None
    assert tool_call.name == "websearch"
    assert text is None


def test_base_parse_assistant_response_text():
    """Base parse_assistant_response extracts final text when no tool call."""
    msg = Message.from_role_and_content(Role.ASSISTANT, "Here is the answer")
    msg = msg.with_channel("final")
    tool_call, text = BaseLLMStrategy().parse_assistant_response([msg])
    assert tool_call is None
    assert text == "Here is the answer"


def test_openai_create_tool_response_adds_recipient():
    """OpenAI strategy adds recipient and content_type to tool response."""
    llm = OpenAILLMStrategy(api_key="test-key", model="gpt-4")
    msg = llm.create_tool_response_message("my_tool", "result", tool_call_id="call_123")
    assert msg.recipient == "my_tool"


def test_harmony_inherits_format_subagent_task():
    """Harmony inherits format_subagent_task from base (no longer duplicated)."""
    llm = HarmonyLLMStrategy(
        base_url="http://localhost:11434",
        templates={"sub_agent": {"task": "Do {{task}} as {{name}}"}},
    )
    result = llm.format_subagent_task("analyst", "review data")
    assert "review data" in result
    assert "analyst" in result


# ---------------------------------------------------------------------------
# TokenUsage and LLMResponse tests
# ---------------------------------------------------------------------------


def test_token_usage_defaults():
    """TokenUsage initializes with zeros."""
    usage = TokenUsage()
    assert usage.input_tokens == 0
    assert usage.output_tokens == 0
    assert usage.reasoning_tokens == 0
    assert usage.total_tokens == 0


def test_token_usage_total():
    """total_tokens is input + output."""
    usage = TokenUsage(input_tokens=100, output_tokens=50, reasoning_tokens=20)
    assert usage.total_tokens == 150  # reasoning is separate


def test_token_usage_add():
    """TokenUsage supports addition."""
    a = TokenUsage(input_tokens=10, output_tokens=20, reasoning_tokens=5)
    b = TokenUsage(input_tokens=30, output_tokens=40, reasoning_tokens=15)
    c = a + b
    assert c.input_tokens == 40
    assert c.output_tokens == 60
    assert c.reasoning_tokens == 20


def test_token_usage_iadd():
    """TokenUsage supports in-place addition."""
    a = TokenUsage(input_tokens=10, output_tokens=20)
    a += TokenUsage(input_tokens=5, output_tokens=8)
    assert a.input_tokens == 15
    assert a.output_tokens == 28


def test_token_usage_to_dict():
    """to_dict serializes all fields."""
    usage = TokenUsage(input_tokens=100, output_tokens=50, reasoning_tokens=10)
    d = usage.to_dict()
    assert d == {"input_tokens": 100, "output_tokens": 50, "reasoning_tokens": 10, "cached_tokens": 0}


def test_llm_response_defaults():
    """LLMResponse initializes with empty messages and no metadata."""
    resp = LLMResponse()
    assert resp.messages == []
    assert resp.usage is None
    assert resp.reasoning is None


def test_llm_response_with_all_fields():
    """LLMResponse stores messages, usage, and reasoning."""
    msg = Message.from_role_and_content(Role.ASSISTANT, "Hello")
    usage = TokenUsage(input_tokens=10, output_tokens=5)
    resp = LLMResponse(
        messages=[msg],
        usage=usage,
        reasoning="I thought about this carefully.",
    )
    assert len(resp.messages) == 1
    assert resp.usage.total_tokens == 15
    assert resp.reasoning == "I thought about this carefully."
