"""Main entry point for running an AISolate agent demo."""

import os
import uuid
import asyncio
import traceback
from textwrap import dedent
from typing import Optional, Tuple

from rich.console import Console
from rich.markdown import Markdown
from rich.table import Table

from aisolate.client.sandbox import Sandbox

from .agent import Agent
from .config.agent_settings import AgentSettings
from .core.events import AgentFinishedEvent
from .strategies.llm.oai import OpenAILLMStrategy
from .strategies.memory.in_memory import InMemoryStrategy
from .tools.actions.web_search_action import WebSearchAction
from .tools.actions.visit_page_action import VisitWebpageTool
from .tools.actions.wikipedia_search_action import WikipediaSearchAction
from .tools.models import FinalAnswerResult

from .utils import setup_environment, load_prompt_templates, get_logger, setup_logging
from .logging import LoggingConfig

console = Console()


# ── Agent Setup ─────────────────────────────────────────────────────────────


async def run_agent(
    task: str,
) -> Tuple[Optional[FinalAnswerResult], Optional[AgentFinishedEvent]]:
    """Create and run an OpenAI-backed agent, returning result and finished event."""
    logging_config = LoggingConfig.from_env()
    setup_logging(logging_config)
    logger = get_logger("aisolate.agent.main")

    env_config = setup_environment()
    logger.info("Starting agent", task=task)
    logger.log_session_start(env_config)

    templates = load_prompt_templates()
    additional_env_vars = {
        "BRAVE_SEARCH_API_KEY": os.getenv("BRAVE_SEARCH_API_KEY", ""),
        "WIKIPEDIA_USER_AGENT_CONTACT": "https://github.com/chrisber",
    }
    agent_settings = AgentSettings(max_turns=200, debug_mode=True)

    async with Sandbox(additional_env_vars=additional_env_vars) as sandbox:
        main_llm = OpenAILLMStrategy(
            api_key=env_config.get("OPENAI_API_KEY", ""),
            model="gpt-5.4-mini",
            templates=templates,
        )
        search_llm = OpenAILLMStrategy(
            api_key=env_config.get("OPENAI_API_KEY", ""),
            model="gpt-5.4-nano",
            templates=templates,
        )

        # Single memory strategy shared between main and sub agents.
        # The framework convention is now: sub-agents inherit the parent's
        # strategy so resume/handover persistence works for free. Example
        # uses InMemoryStrategy because this is a CLI demo; consumers
        # configuring a Django- or Redis-backed strategy here would also
        # gain sub-agent persistence with no further code changes.
        memory_strategy = InMemoryStrategy()

        search_agent = Agent(
            name="search_agent",
            description=(
                "Finds and synthesizes the latest information from the web and Wikipedia, "
                "visiting pages as needed. Returns structured answers with clear, authoritative citations."
            ),
            settings=agent_settings,
            llm_strategy=search_llm,
            memory_strategy=memory_strategy,
            actions=[WikipediaSearchAction(), WebSearchAction(), VisitWebpageTool()],
            sandbox=await sandbox.acreate_context_bound_sandbox(),
        )

        main_agent = Agent(
            name="main_agent",
            description="The primary agent responsible for high-level tasks.",
            settings=agent_settings,
            llm_strategy=main_llm,
            memory_strategy=memory_strategy,
            managed_agents=[search_agent],
            sandbox=await sandbox.acreate_context_bound_sandbox(),
        )

        result = None
        finished_event = None
        conversation_id = str(uuid.uuid4())

        async for event in main_agent.run_streaming(task, conversation_id):
            if not hasattr(event, "type"):
                continue
            if event.type == "turn_completed":
                usage_info = f" | tokens: {event.usage}" if event.usage else ""
                logger.info(
                    "Turn completed",
                    turn=event.turn,
                    state=event.state,
                    finished=event.is_finished,
                    extra=usage_info,
                )
            elif event.type == "agent_finished":
                result = event.final_answer
                finished_event = event
            elif event.type == "agent_error":
                logger.error("Agent error", error=event.error)

        logger.info(
            "Agent execution completed",
            turns_taken=main_agent.get_turn_count(),
            completed_successfully=bool(result),
        )

        return result, finished_event


# ── Display Helpers ─────────────────────────────────────────────────────────


def print_result(result: FinalAnswerResult) -> None:
    """Print the agent's final answer with Rich formatting."""
    console.print("\n[bold cyan]Final Answer:[/bold cyan]\n")
    console.print(Markdown(result.answer))

    if result.confidence is not None:
        console.print(
            f"\n[bold yellow]Confidence:[/bold yellow] {result.confidence:.2%}"
        )

    if result.sources:
        console.print(f"\n[bold green]Sources ({len(result.sources)}):[/bold green]")
        for idx, source in enumerate(result.sources, 1):
            console.print(f"  [cyan]{idx}.[/cyan] {source}")

    if result.metadata:
        console.print(f"\n[bold magenta]Metadata:[/bold magenta]")
        for key, value in result.metadata.items():
            console.print(f"  {key}: {value}")


def print_token_stats(event: AgentFinishedEvent) -> None:
    """Print detailed per-agent token usage statistics."""
    total = event.total_usage or {}
    total_input = total.get("input_tokens", 0)
    total_output = total.get("output_tokens", 0)
    total_reasoning = total.get("reasoning_tokens", 0)

    console.print("\n[bold cyan]Token Usage Statistics[/bold cyan]\n")
    console.print(f"  Turns:          {event.total_turns}")
    console.print(f"  Execution Time: {event.execution_time:.2f}s\n")

    # Build a table with per-agent breakdown
    table = Table(title="Token Consumption by Agent", show_lines=True)
    table.add_column("Agent", style="bold")
    table.add_column("Model", style="dim")
    table.add_column("Input", justify="right")
    table.add_column("Output", justify="right")
    table.add_column("Reasoning", justify="right")
    table.add_column("Total", justify="right", style="bold")

    if event.sub_agent_usage:
        sub_input = sum(
            u.get("input_tokens", 0) for u in event.sub_agent_usage.values()
        )
        sub_output = sum(
            u.get("output_tokens", 0) for u in event.sub_agent_usage.values()
        )
        sub_reasoning = sum(
            u.get("reasoning_tokens", 0) for u in event.sub_agent_usage.values()
        )

        own_input = total_input - sub_input
        own_output = total_output - sub_output
        own_reasoning = total_reasoning - sub_reasoning

        main_model = total.get("model", "unknown")
        table.add_row(
            "[yellow]main_agent[/yellow]",
            main_model,
            f"{own_input:,}",
            f"{own_output:,}",
            f"{own_reasoning:,}",
            f"{own_input + own_output:,}",
        )

        for agent_name, usage in event.sub_agent_usage.items():
            a_in = usage.get("input_tokens", 0)
            a_out = usage.get("output_tokens", 0)
            a_reas = usage.get("reasoning_tokens", 0)
            a_model = usage.get("model", "unknown")
            table.add_row(
                f"[green]{agent_name}[/green]",
                a_model,
                f"{a_in:,}",
                f"{a_out:,}",
                f"{a_reas:,}",
                f"{a_in + a_out:,}",
            )
    else:
        main_model = total.get("model", "unknown")
        table.add_row(
            "[yellow]main_agent[/yellow]",
            main_model,
            f"{total_input:,}",
            f"{total_output:,}",
            f"{total_reasoning:,}",
            f"{total_input + total_output:,}",
        )

    table.add_section()
    table.add_row(
        "[bold]TOTAL[/bold]",
        "",
        f"{total_input:,}",
        f"{total_output:,}",
        f"{total_reasoning:,}",
        f"{total_input + total_output:,}",
    )

    console.print(table)


# ── Main ────────────────────────────────────────────────────────────────────


async def main():
    """Run the AISolate agent demo."""
    task = dedent(
        """\
        For the first time the US gov shut down the federal government.
        The online sentiment is overwhelmingly positive that because of historical precedents, the market will react favorably.
        Find relevant information and data to support or refute this hypothesis.
        I'm more interested in how something that today is 2025-10-04 is different than past shutdowns and could lead to a different outcome.
        Predict how the market will react in the next 14 days.
        Write a detail explanatory report and provide detailed arguments for every fact or claim with more than 1000 words in the report
    """
    )

    console.rule("[bold]AISolate Agent Demo[/bold]")
    console.print(f"\n[dim]Task:[/dim] {task.strip()[:200]}...\n")

    try:
        result, finished_event = await run_agent(task)

        console.rule("[bold]Agent Execution Completed[/bold]")

        if result:
            print_result(result)
        else:
            console.print("\n[bold red]No final answer provided[/bold red]")

        if finished_event:
            print_token_stats(finished_event)

        console.rule()

    except Exception as e:
        console.rule("[bold red]Error[/bold red]")
        console.print(f"[red]{type(e).__name__}: {e}[/red]")
        console.print(f"\n[dim]{traceback.format_exc()}[/dim]")


if __name__ == "__main__":
    asyncio.run(main())
