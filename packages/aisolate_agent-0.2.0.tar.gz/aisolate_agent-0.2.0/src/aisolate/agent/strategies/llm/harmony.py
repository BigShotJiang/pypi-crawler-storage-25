"""Harmony LLM Strategy with three-tier tool architecture."""

from textwrap import dedent
from typing import List, Optional, Dict, TYPE_CHECKING, Any, Tuple, Union
import aiohttp
import json


from openai_harmony import (
    load_harmony_encoding,
    HarmonyEncodingName,
    Conversation,
    SystemContent,
    DeveloperContent,
    ReasoningEffort,
    Role,
    Author,
)

from ...memory.models import Message
from ...utils import get_logger, setup_environment
from ...tools.models import ToolCall
from ...core.llm_response import LLMResponse
from .base import BaseLLMStrategy, strip_code_fences, message_to_text

if TYPE_CHECKING:
    from ...core.context import AgentContext


config = setup_environment()
logger = get_logger("aisolate.agent.strategies.llm.harmony")


def _content_to_text(parts: List[Any]) -> str:
    return "".join(getattr(p, "text", "") for p in (parts or []))


def _extract_args(parts: List[Any]) -> Union[dict, str]:
    """
    Prefer structured segments (type=json/tool_input/input) → fenced JSON → raw text.
    """
    # 1) Structured payloads
    for p in parts or []:
        ptype = getattr(p, "type", None) or ""
        if ptype in {"json", "tool_input", "input"}:
            if hasattr(p, "data") and p.data is not None:
                return p.data
            if hasattr(p, "json") and p.json is not None:
                return p.json
            if hasattr(p, "text") and p.text:
                cand = strip_code_fences(p.text)
                try:
                    return json.loads(cand) if cand else {}
                except Exception:
                    return cand

    # 2) Fenced / raw JSON in text
    raw = strip_code_fences(_content_to_text(parts))
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return raw


class HarmonyLLMStrategy(BaseLLMStrategy):
    """LLM strategy for Harmony API with three-tier tool support."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        templates: Optional[Dict] = None,
        max_tokens: int = 2048,
    ):
        super().__init__(
            templates=templates,
            namespace_config={
                "separator": ".",
                "function_prefix": "functions.",
                "agent_prefix": "functions.agents.",
                "tool_name_overrides": {},  # No restrictions - Harmony allows all names
            },
        )
        self.base_url = (base_url or config["BASE_URL"]).rstrip("/")
        self.model = model or config["MODEL"]
        self.max_tokens = max_tokens
        self.enc = load_harmony_encoding(HarmonyEncodingName.HARMONY_GPT_OSS)

    async def generate_response(self, context: "AgentContext") -> LLMResponse:
        """Generate a response from the LLM based on the agent's history."""
        prompt_tokens = self._render_history_to_tokens(
            context.get_conversation_messages()
        )
        response_tokens = await self._generate_raw_tokens(prompt_tokens)
        msgs = self.enc.parse_messages_from_completion_tokens(
            response_tokens, role=Role.ASSISTANT
        )
        logger.log_model_response(
            agent_name=context.agent_name,
            messages=msgs,
            tokens=response_tokens,
        )

        # Extract reasoning from analysis-channel messages
        reasoning_fragments: list[str] = []
        for msg in msgs:
            if getattr(msg, "channel", None) == "analysis":
                text = message_to_text(msg)
                if text:
                    reasoning_fragments.append(text)
        reasoning_text = "\n".join(reasoning_fragments) if reasoning_fragments else None

        return LLMResponse(
            messages=msgs,
            usage=None,  # Harmony API does not report token counts
            reasoning=reasoning_text,
        )

    def prepare_initial_history(self, context: "AgentContext") -> List["Message"]:
        """Creates the initial message history for the planning phase."""
        initial_plan_template = self.templates.get("planning", {}).get(
            "initial_plan", "Create a plan to accomplish this task: {task}"
        )

        initial_plan = self._render_template(
            initial_plan_template,
            self._get_template_variables(context),
        )

        sys_content = (
            SystemContent.new()
            .with_model_identity(
                "You are ChatGPT, a large language model trained by OpenAI."
            )
            .with_reasoning_effort(ReasoningEffort.HIGH)
            .with_knowledge_cutoff("2024-06")
            .with_conversation_start_date("2025-08-23")
            .with_required_channels(["analysis", "commentary", "final"])
            .with_python_tool()
        )

        dev_content = (
            DeveloperContent.new()
            .with_instructions(initial_plan)
            .with_function_tools(context.function_tools)
        )

        m = dedent(
            f"""
            Now begin! Here is your task:
            ```
            {context.task}
            ```
            First in part 1, write the facts survey, then in part 2, write your plan.
            """
        )

        return [
            Message.from_role_and_content(role=Role.SYSTEM, content=sys_content),
            Message.from_role_and_content(role=Role.DEVELOPER, content=dev_content),
            Message.from_role_and_content(role=Role.USER, content=m),
        ]

    def prepare_execution_history(
        self,
        context: "AgentContext",
        plan: str,
    ) -> List["Message"]:
        """Creates the message history to pivot from planning to execution."""
        system_prompt_template = self.templates.get("system_prompt", "")
        template_vars = self._get_template_variables(context)
        template_vars["custom_instructions"] = ""
        system_prompt = self._render_template(system_prompt_template, template_vars)

        sys_content = (
            SystemContent.new()
            .with_model_identity(
                "You are ChatGPT, a large language model trained by OpenAI."
            )
            .with_reasoning_effort(ReasoningEffort.MEDIUM)
            .with_knowledge_cutoff("2024-06")
            .with_conversation_start_date("2025-08-23")
            .with_required_channels(["analysis", "commentary", "final"])
            .with_python_tool()
        )

        dev_content = (
            DeveloperContent.new()
            .with_instructions(system_prompt)
            .with_function_tools(context.function_tools)
        )

        return [
            Message.from_role_and_content(role=Role.SYSTEM, content=sys_content),
            Message.from_role_and_content(role=Role.DEVELOPER, content=dev_content),
            Message.from_role_and_content(role=Role.USER, content=context.task),
            Message.from_role_and_content(role=Role.ASSISTANT, content=plan),
            Message.from_role_and_content(
                role=Role.USER, content="Now proceed and carry out this plan."
            ),
        ]

    def prepare_clarification_history(self, context: "AgentContext") -> List["Message"]:
        """Build conversation history for expert panel clarification."""
        template = (
            self.templates.get("clarification", {}).get("expert_panel")
            or "Analyze this task and ask the user clarifying questions using the ask_user tool: {{ task }}"
        )
        rendered = self._render_template(
            template,
            self._get_template_variables(context),
        )
        return [
            Message.from_role_and_content(Role.SYSTEM, rendered),
            Message.from_role_and_content(Role.USER, context.task),
        ]

    def prepare_planning_history(
        self,
        context: "AgentContext",
        expert_analysis: str,
        user_answer: str,
    ) -> List["Message"]:
        """Build planning history with expert context from clarification."""
        initial_plan_template = self.templates.get("planning", {}).get(
            "initial_plan", "Create a plan to accomplish this task: {task}"
        )
        initial_plan = self._render_template(
            initial_plan_template,
            self._get_template_variables(context),
        )

        if user_answer:
            m = dedent(
                f"""
                Now begin! Here is your task:
                ```
                {context.task}
                ```

                User clarification (OVERRIDES conflicting details above):
                ```
                {user_answer}
                ```

                Apply the clarification, then in part 1 write the facts survey, then in part 2 write your plan.
                IMPORTANT: Respond in the same language as the user's task and clarification above.
                """
            )
        else:
            m = dedent(
                f"""
                Now begin! Here is your task:
                ```
                {context.task}
                ```
                First in part 1, write the facts survey, then in part 2, write your plan.
                """
            )

        sys_content = (
            SystemContent.new()
            .with_model_identity(
                "You are ChatGPT, a large language model trained by OpenAI."
            )
            .with_reasoning_effort(ReasoningEffort.HIGH)
            .with_knowledge_cutoff("2024-06")
            .with_conversation_start_date("2025-08-23")
            .with_required_channels(["analysis", "commentary", "final"])
            .with_python_tool()
        )

        dev_content = (
            DeveloperContent.new()
            .with_instructions(initial_plan)
            .with_function_tools(context.function_tools)
        )

        messages = [
            Message.from_role_and_content(role=Role.SYSTEM, content=sys_content),
            Message.from_role_and_content(role=Role.DEVELOPER, content=dev_content),
        ]
        if expert_analysis:
            messages.append(
                Message.from_role_and_content(Role.ASSISTANT, expert_analysis)
            )
        messages.append(
            Message.from_role_and_content(role=Role.USER, content=m),
        )
        return messages

    def prepare_expert_synthesis_history(
        self,
        context: "AgentContext",
        question: str,
        answer: str,
        original_task: str,
        expert_ask_text: str = "",
    ) -> List["Message"]:
        """Build conversation history for ExpertSynthesisState (Harmony)."""
        template = (
            self.templates.get("clarification", {}).get("expert_synthesis")
            or (
                "You are the expert panel. The user answered your question.\n"
                "Task: {{ task }}\nQuestion: {{ question }}\nAnswer: {{ answer }}\n"
                "Reconvene, reconcile, and emit a refined task paragraph."
            )
        )
        template_vars = self._get_template_variables(context)
        template_vars.update(
            {
                "task": original_task,
                "question": question,
                "answer": answer,
                "expert_ask_text": expert_ask_text,
            }
        )
        rendered = self._render_template(template, template_vars)

        sys_content = (
            SystemContent.new()
            .with_model_identity(
                "You are ChatGPT, a large language model trained by OpenAI."
            )
            .with_reasoning_effort(ReasoningEffort.HIGH)
            .with_knowledge_cutoff("2024-06")
            .with_conversation_start_date("2025-08-23")
            .with_required_channels(["analysis", "commentary", "final"])
        )

        dev_content = DeveloperContent.new().with_instructions(rendered)

        messages = [
            Message.from_role_and_content(role=Role.SYSTEM, content=sys_content),
            Message.from_role_and_content(role=Role.DEVELOPER, content=dev_content),
            Message.from_role_and_content(role=Role.USER, content=original_task),
        ]
        if expert_ask_text:
            messages.append(
                Message.from_role_and_content(Role.ASSISTANT, expert_ask_text)
            )
        messages.append(Message.from_role_and_content(role=Role.USER, content=answer))
        return messages

    def prepare_planning_history_from_brief(
        self,
        context: "AgentContext",
        rich_brief: str,
    ) -> List["Message"]:
        """Build planning history from an already-enriched task brief (Harmony)."""
        initial_plan_template = self.templates.get("planning", {}).get(
            "initial_plan", "Create a plan to accomplish this task: {task}"
        )
        initial_plan = self._render_template(
            initial_plan_template,
            self._get_template_variables(context),
        )

        m = dedent(
            f"""
            Now begin! Here is your task:
            ```
            {rich_brief}
            ```

            The task above includes the expert panel's clarification
            round-trip with the user. Apply it, then in part 1 write
            the facts survey, then in part 2 write your plan.
            IMPORTANT: Respond in the same language as the user's task.
            """
        )

        sys_content = (
            SystemContent.new()
            .with_model_identity(
                "You are ChatGPT, a large language model trained by OpenAI."
            )
            .with_reasoning_effort(ReasoningEffort.HIGH)
            .with_knowledge_cutoff("2024-06")
            .with_conversation_start_date("2025-08-23")
            .with_required_channels(["analysis", "commentary", "final"])
            .with_python_tool()
        )

        dev_content = (
            DeveloperContent.new()
            .with_instructions(initial_plan)
            .with_function_tools(context.function_tools)
        )

        return [
            Message.from_role_and_content(role=Role.SYSTEM, content=sys_content),
            Message.from_role_and_content(role=Role.DEVELOPER, content=dev_content),
            Message.from_role_and_content(role=Role.USER, content=m),
        ]

    def parse_planner_response(
        self, messages: List["Message"]
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        """Parse a single assistant turn to extract tool calls or plan text.

        Returns:
            Tuple of (tool_call_dict, text_content) where:
            - tool_call_dict: {"name": str, "arguments": dict|str, "channel": str} if tool call
            - text_content: String containing plan (planning phase) or answer display text (executing phase)

        Preference: if any tool call exists, return that (the *last* one).
        """
        tool_call = None
        text_fragments: List[str] = []

        # Walk newest → oldest within this assistant turn
        for m in reversed(messages):
            recipient = getattr(m, "recipient", None)
            channel = getattr(m, "channel", None)

            if recipient and tool_call is None:
                args = _extract_args(getattr(m, "content", []))
                tool_call = {"name": recipient, "arguments": args, "channel": channel}
                # The last tool call wins; stop scanning for earlier ones.
                break

            if channel == "final":
                text_fragments.append(_content_to_text(getattr(m, "content", [])))

        if tool_call:
            return tool_call, None

        # Combine all text fragments into a single string
        message_text = (
            "\n".join(reversed([t for t in text_fragments if t.strip()])).strip()
            or None
        )

        if message_text:
            # Return the raw text string (will be wrapped in FinalAnswerResult by executing state)
            return None, message_text

        return None, None

    def _extract_tool_call_args(
        self, message: Message
    ) -> Tuple[Union[Dict[str, Any], str], Optional[str]]:
        """Harmony-specific: extract structured payloads from content parts."""
        args = _extract_args(getattr(message, "content", []))
        channel = getattr(message, "channel", None)
        return args, channel  # Harmony uses channel as call ID

    async def _generate_raw_tokens(self, prompt_tokens: List[int]) -> List[int]:
        """Generate raw token response from Harmony API."""
        url = f"{self.base_url}/completion"
        payload = {
            "prompt": prompt_tokens,
            "n_predict": self.max_tokens,
            "stop": ["<|return|>"],
            "stream": False,
            "return_tokens": True,
        }

        logger.debug(
            "Sending request to LLM",
            url=url,
            prompt_tokens=len(prompt_tokens),
            model=self.model,
        )
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=180)
        ) as session:
            async with session.post(url, json=payload) as resp:
                resp.raise_for_status()
                data = await resp.json()

                # Try to get tokens directly from llama.cpp response
                response_tokens = data.get("tokens")
                response_content = data.get("content", "")

                if response_tokens is None:
                    # Fallback: if server only returns text, encode it
                    # NOTE: This should rarely happen with return_tokens=True
                    if not response_content:
                        logger.error(
                            "LLM response missing both tokens and content",
                            response_data=data,
                        )
                        raise ValueError("Empty LLM response")

                    logger.warning(
                        "Server returned text instead of tokens, encoding",
                        content_preview=response_content[:100],
                    )
                    response_tokens = self.enc.encode(
                        response_content, allowed_special="all"
                    )

                if not isinstance(response_tokens, list):
                    logger.error(
                        "Invalid tokens format",
                        tokens_type=type(response_tokens),
                    )
                    raise ValueError(
                        f"Expected list of tokens, got {type(response_tokens)}"
                    )

                # Log with both loggers during transition
                logger.info(
                    "LLM response received",
                    content=response_content,
                    response_tokens=len(response_tokens),
                    model=self.model,
                    content_preview=(
                        response_content[:200] if response_content else None
                    ),
                )
                return response_tokens

    def _render_history_to_tokens(self, history: List["Message"]) -> List[int]:
        """Render message history to token list."""
        convo = Conversation.from_messages(history)
        return self.enc.render_conversation_for_completion(convo, Role.ASSISTANT)
