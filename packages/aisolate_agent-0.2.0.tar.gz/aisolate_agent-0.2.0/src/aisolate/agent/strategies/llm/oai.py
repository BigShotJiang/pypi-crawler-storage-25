"""OpenAI LLM strategy built on the Responses API with conversation bridging."""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass
from textwrap import dedent
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

from openai import AsyncOpenAI
from openai.types.responses import Response as OpenAIResponse
from openai.types.responses.response_function_tool_call import ResponseFunctionToolCall
from openai.types.responses.response_output_item import ResponseOutputItem
from openai.types.responses.response_output_message import ResponseOutputMessage
from openai.types.responses.response_output_text import ResponseOutputText
from openai.types.responses.response_reasoning_item import ResponseReasoningItem
from openai import BadRequestError
from openai_harmony import Message, Role

from opentelemetry import trace as _otel_trace

from ...utils import get_logger
from ...tools.models import ToolCall
from ...core.llm_response import TokenUsage, LLMResponse
from ...telemetry.openinference import llm_span_attributes, safe_record_exception
from .base import BaseLLMStrategy, message_to_text, safe_json_loads

if TYPE_CHECKING:  # pragma: no cover
    from ...core.context import AgentContext

__all__ = ["OpenAILLMStrategy"]


logger = get_logger("aisolate.agent.strategies.llm.oai")
_tracer = _otel_trace.get_tracer("aisolate.agent.strategies.llm.oai")


@dataclass(frozen=True)
class FunctionToolSpec:
    """Normalized representation of a function tool for the OpenAI tool schema."""

    name: str
    description: str
    parameters: Dict[str, Any]

    def as_request_payload(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


def _coerce_to_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, Mapping):
        return {str(k): v for k, v in value.items()}
    return {"type": "object", "properties": {}}


class OpenAILLMStrategy(BaseLLMStrategy):
    """Provider strategy that bridges OpenAI's Responses API with internal message models."""

    _ROLE_TO_PROVIDER = {
        Role.SYSTEM: "system",
        Role.USER: "user",
        Role.ASSISTANT: "assistant",
        Role.DEVELOPER: "system",
        Role.TOOL: "tool",
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        templates: Optional[Dict[str, Any]] = None,
        max_tokens: int = 2048,
        temperature: Optional[float] = 0.7,
        client: Optional[AsyncOpenAI] = None,
        azure_endpoint: Optional[str] = None,
        azure_api_version: Optional[str] = None,
    ) -> None:
        super().__init__(
            templates=templates,
            namespace_config={
                "separator": "_",
                "function_prefix": "functions_",
                "agent_prefix": "functions_agents_",
                "tool_name_overrides": {
                    "python": "code_interpreter",
                    "browser": "web_browser",
                    "dall_e": "image_generator",
                },
            },
        )
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError(
                "OpenAI API key must be provided or set in OPENAI_API_KEY environment variable"
            )

        self.client = client or AsyncOpenAI(api_key=self.api_key)
        self.model = model or os.getenv("OPENAI_MODEL", "o1-mini")
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.azure_endpoint = azure_endpoint
        self.azure_api_version = azure_api_version
        self.is_o1_model = self.model.startswith("o1-")

        # Reasoning models support the reasoning.effort parameter
        self.is_reasoning_model = (
            self.model.startswith("o1-")
            or self.model.startswith("o3-")
            or self.model.startswith("o4-")
            or self.model.startswith("gpt-5")
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def with_model(self, model: str, api_version: Optional[str] = None) -> "OpenAILLMStrategy":
        """Return a copy with a different model (and Azure deployment)."""
        import copy

        clone = copy.copy(self)
        clone.model = model
        clone.is_o1_model = model.startswith("o1-")
        clone.is_reasoning_model = (
            model.startswith("o1-")
            or model.startswith("o3-")
            or model.startswith("o4-")
            or model.startswith("gpt-5")
        )
        if api_version is not None:
            clone.azure_api_version = api_version
        # Azure deployments are 1:1 with model names — recreate the client
        if clone.azure_endpoint and clone.azure_api_version:
            from openai import AsyncAzureOpenAI as _AsyncAzureOpenAI

            clone.client = _AsyncAzureOpenAI(
                azure_deployment=model,
                api_key=clone.api_key,
                api_version=clone.azure_api_version,
                azure_endpoint=clone.azure_endpoint,
            )
        return clone

    async def generate_response(self, context: "AgentContext") -> LLMResponse:
        history = context.get_conversation_messages()
        serialized_history = self._serialize_history(history)
        tools_payload = self._collect_tool_payloads(context)
        tool_choice = context.get_state_hint("tool_choice", "auto")
        reasoning_effort = context.get_state_hint("reasoning_effort", "medium")

        with _tracer.start_as_current_span(
            "llm.generate",
            attributes=llm_span_attributes(
                model=self.model,
                system="openai",
                input_messages=[
                    {"role": m.get("role", ""), "content": str(m.get("content", ""))}
                    for m in serialized_history
                    if isinstance(m, dict)
                ],
                invocation_parameters={
                    "tool_choice": tool_choice,
                    "reasoning_effort": reasoning_effort,
                },
                tools=tools_payload,
            ),
        ) as span:
            try:
                response = await self._create_completion(
                    serialized_history,
                    tools_payload,
                    tool_choice=tool_choice,
                    reasoning_effort=reasoning_effort,
                )
            except Exception as exc:
                safe_record_exception(span, exc)
                raise
            assistant_messages = self._convert_response_to_messages(response)

            # --- Extract token usage ---
            raw_usage = getattr(response, "usage", None)
            token_usage: TokenUsage | None = None
            if raw_usage:
                reasoning = 0
                output_details = getattr(raw_usage, "output_tokens_details", None)
                if output_details:
                    reasoning = getattr(output_details, "reasoning_tokens", 0) or 0

                cached = 0
                input_details = getattr(raw_usage, "input_tokens_details", None)
                if input_details:
                    cached = getattr(input_details, "cached_tokens", 0) or 0

                token_usage = TokenUsage(
                    input_tokens=getattr(raw_usage, "input_tokens", 0) or 0,
                    output_tokens=getattr(raw_usage, "output_tokens", 0) or 0,
                    reasoning_tokens=reasoning,
                    cached_tokens=cached,
                )
                # Token counts are NOT mirrored onto this span: the OI
                # OpenAIInstrumentor (when active) already emits the
                # canonical llm.token_count.* attributes on its own
                # Response/ChatCompletion span, and Phoenix sums every
                # LLM-kind span — duplicating numbers here doubled session
                # totals. The framework still owns the in-process count
                # via token_usage / accumulate_usage.

            # --- Extract reasoning text from analysis-channel messages ---
            reasoning_fragments: list[str] = []
            for msg in assistant_messages:
                if getattr(msg, "channel", None) == "analysis":
                    text = message_to_text(msg)
                    if text:
                        reasoning_fragments.append(text)
            reasoning_text = (
                "\n".join(reasoning_fragments) if reasoning_fragments else None
            )

            metadata = {
                "model": response.model,
                "status": getattr(response, "status", None),
                "usage": token_usage.to_dict() if token_usage else None,
            }

            logger.log_model_response(
                agent_name=context.agent_name,
                messages=assistant_messages,
                metadata={k: v for k, v in metadata.items() if v is not None},
            )

            return LLMResponse(
                messages=assistant_messages,
                usage=token_usage,
                reasoning=reasoning_text,
            )

    def prepare_initial_history(self, context: "AgentContext") -> List[Message]:
        template = (
            self.templates.get("planning", {}).get("initial_plan")
            or "Create a plan to accomplish this task: {task}"
        )
        initial_plan = self._render_template(
            template,
            self._get_template_variables(context),
        )

        task_message = dedent(
            f"""
            Now begin! Here is your task:
            ```
            {context.task}
            ```

            First, analyze the task and identify what you need to do.
            Then, write a detailed plan with clear steps.
            """
        ).strip()

        return [
            Message.from_role_and_content(Role.SYSTEM, initial_plan),
            Message.from_role_and_content(Role.USER, task_message),
        ]

    def prepare_clarification_history(self, context: "AgentContext") -> List[Message]:
        """Build conversation history for the ClarificationState (expert panel + ask_user)."""
        template = (
            self.templates.get("clarification", {}).get("expert_panel")
            or "Analyze this task and ask the user clarifying questions using the ask_user tool: {{ task }}"
        )
        rendered = self._render_template(
            template,
            self._get_template_variables(context),
        )
        return [
            Message.from_role_and_content(Role.SYSTEM, rendered),
            Message.from_role_and_content(Role.USER, context.task),
        ]

    def prepare_planning_history(
        self,
        context: "AgentContext",
        expert_analysis: str,
        user_answer: str,
    ) -> List[Message]:
        """Build planning history with expert context folded in.

        Called by ClarificationState before transitioning to PlanningState.
        Same pattern as prepare_execution_history: swaps system prompt and
        folds predecessor output as ASSISTANT message.

        Args:
            context: Agent context (provides task + template variables)
            expert_analysis: Expert panel reasoning text (becomes ASSISTANT)
            user_answer: User's clarification response (becomes USER)
        """
        template = (
            self.templates.get("planning", {}).get("initial_plan")
            or "Create a plan to accomplish this task: {task}"
        )
        system_prompt = self._render_template(
            template,
            self._get_template_variables(context),
        )

        # Build the task message.  When the user provided a clarification
        # answer (HITL), fold it directly into the task block so the LLM
        # sees it alongside the original request — not as a separate USER
        # message that gets overshadowed by the re-stated original task.
        if user_answer:
            task_message = dedent(
                f"""
                Now begin! Here is your task:
                ```
                {context.task}
                ```

                User clarification (OVERRIDES conflicting details above):
                ```
                {user_answer}
                ```

                Apply the clarification, then write a detailed plan.
                IMPORTANT: Respond in the same language as the user's task and clarification above.
                """
            ).strip()
        else:
            task_message = dedent(
                f"""
                Now begin! Here is your task:
                ```
                {context.task}
                ```

                First, analyze the task and identify what you need to do.
                Then, write a detailed plan with clear steps.
                """
            ).strip()

        messages = [
            Message.from_role_and_content(Role.SYSTEM, system_prompt),
        ]
        if expert_analysis:
            messages.append(
                Message.from_role_and_content(Role.ASSISTANT, expert_analysis)
            )
        messages.append(
            Message.from_role_and_content(Role.USER, task_message),
        )

        logger.info(
            "[prepare_planning_history]",
            message_count=len(messages),
            has_expert=bool(expert_analysis),
            has_user_answer=bool(user_answer),
        )

        return messages

    def prepare_expert_synthesis_history(
        self,
        context: "AgentContext",
        question: str,
        answer: str,
        original_task: str,
        expert_ask_text: str = "",
    ) -> List[Message]:
        """Build conversation history for ExpertSynthesisState.

        Renders the ``clarification.expert_synthesis`` template as the system
        prompt and presents the original task, the panel's question, and the
        user's answer. The LLM's job is to emit a free-form panel discussion
        (no tool calls) that reconciles the answer with the earlier analysis.
        """
        template = (
            self.templates.get("clarification", {}).get("expert_synthesis")
            or (
                "You are the expert panel. The user answered your question.\n"
                "Task: {{ task }}\nQuestion: {{ question }}\nAnswer: {{ answer }}\n"
                "Reconvene, reconcile, and emit a refined task paragraph."
            )
        )
        template_vars = self._get_template_variables(context)
        template_vars.update(
            {
                "task": original_task,
                "question": question,
                "answer": answer,
                "expert_ask_text": expert_ask_text,
            }
        )
        system_prompt = self._render_template(template, template_vars)

        messages = [
            Message.from_role_and_content(Role.SYSTEM, system_prompt),
            Message.from_role_and_content(Role.USER, original_task),
        ]
        if expert_ask_text:
            messages.append(
                Message.from_role_and_content(Role.ASSISTANT, expert_ask_text)
            )
        messages.append(Message.from_role_and_content(Role.USER, answer))
        return messages

    def prepare_planning_history_from_brief(
        self,
        context: "AgentContext",
        rich_brief: str,
    ) -> List[Message]:
        """Build planning history from an already-enriched task brief.

        Used after ExpertSynthesisState has folded task + Q + A + panel
        discussion into ``rich_brief``. The planner sees the full brief
        as the USER message with no separate expert/clarification split.
        """
        template = (
            self.templates.get("planning", {}).get("initial_plan")
            or "Create a plan to accomplish this task: {task}"
        )
        system_prompt = self._render_template(
            template,
            self._get_template_variables(context),
        )

        task_message = dedent(
            f"""
            Now begin! Here is your task:
            ```
            {rich_brief}
            ```

            The task above includes the expert panel's clarification
            round-trip with the user. Apply it, then write a detailed plan.
            IMPORTANT: Respond in the same language as the user's task.
            """
        ).strip()

        return [
            Message.from_role_and_content(Role.SYSTEM, system_prompt),
            Message.from_role_and_content(Role.USER, task_message),
        ]

    def prepare_execution_history(
        self,
        context: "AgentContext",
        plan: str,
    ) -> List[Message]:
        system_template = self.templates.get("system_prompt", "")
        template_vars = self._get_template_variables(context)
        template_vars["plan"] = plan
        template_vars["custom_instructions"] = ""
        system_prompt = self._render_template(system_template, template_vars)

        messages = [
            Message.from_role_and_content(
                Role.SYSTEM, system_prompt or "You are a capable AI assistant."
            ),
        ]

        # If this is a follow-up on a completed conversation, inject the
        # prior final answer so the LLM knows what was already done.
        if getattr(context, "prior_final_answer", None):
            messages.append(
                Message.from_role_and_content(
                    Role.USER,
                    "Here is what you previously delivered to the user:\n\n"
                    f"{context.prior_final_answer}\n\n"
                    "The user now has a follow-up request.",
                )
            )
            messages.append(
                Message.from_role_and_content(
                    Role.ASSISTANT,
                    "Understood. I have the context from my previous analysis. "
                    "I will build on that work.",
                )
            )

        messages.extend([
            Message.from_role_and_content(Role.USER, context.task),
            Message.from_role_and_content(Role.ASSISTANT, plan),
            Message.from_role_and_content(
                Role.USER,
                "Now proceed and carry out this plan step by step.",
            ),
        ])

        return messages

    def parse_assistant_response(
        self, messages: List[Message]
    ) -> Tuple[Optional[ToolCall], Optional[str]]:
        """Parse assistant response to extract tool calls or text.

        OpenAI-specific: filters by Role.ASSISTANT and ignores non-final channels.
        """
        tool_call: Optional[ToolCall] = None
        final_text_fragments: List[str] = []
        analysis_text_fragments: List[str] = []

        for message in messages:
            role = getattr(message.author, "role", None)
            if role != Role.ASSISTANT:
                continue

            if message.recipient:
                arguments_raw = message_to_text(message)
                parsed_arguments = safe_json_loads(arguments_raw)
                # Ensure arguments is always a dict
                if not isinstance(parsed_arguments, dict):
                    parsed_arguments = {"value": parsed_arguments}
                tool_call = ToolCall(
                    name=message.recipient,
                    arguments=parsed_arguments,
                    tool_call_id=getattr(message, "content_type", None),
                )
                continue

            channel = getattr(message, "channel", None)
            if channel == "analysis":
                text = message_to_text(message)
                if text:
                    analysis_text_fragments.append(text)
                continue
            if channel not in (None, "final"):
                continue

            text = message_to_text(message)
            if text:
                final_text_fragments.append(text)

        if tool_call:
            return tool_call, None

        # Combine all final text fragments into a single string
        # Fall back to analysis (reasoning) content if no final text
        fragments = final_text_fragments or analysis_text_fragments
        answer_text = "\n".join(
            fragment for fragment in fragments if fragment.strip()
        ).strip()

        if answer_text:
            return None, answer_text

        return None, None

    def create_tool_response_message(
        self, tool_name: str, result: Any, tool_call_id: Optional[str] = None
    ) -> Message:
        """OpenAI-specific: attaches tool_call_id and recipient."""
        message = super().create_tool_response_message(tool_name, result, tool_call_id)
        if tool_call_id:
            message = message.with_content_type(tool_call_id)
        return message.with_recipient(tool_name)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _collect_tool_payloads(self, context: "AgentContext") -> List[Dict[str, Any]]:
        seen: Dict[str, FunctionToolSpec] = {}
        collections: Iterable[Iterable[Any]] = (
            context.builtin_tools,
            context.function_tools,
            context.sub_agent_tools.values(),
        )

        for group in collections:
            for tool in group:
                raw_spec: Any
                if hasattr(tool, "to_openai_spec"):
                    try:
                        raw_spec = tool.to_openai_spec()
                    except Exception as exc:  # pragma: no cover - defensive
                        logger.warning(
                            "Failed to export tool spec", tool=str(tool), error=str(exc)
                        )
                        continue
                elif isinstance(tool, Mapping):
                    raw_spec = tool
                else:
                    continue

                normalized = self._normalize_tool_spec(raw_spec)
                if not normalized:
                    continue

                safe_name = self.get_tool_name(normalized.name)
                normalized = FunctionToolSpec(
                    name=safe_name,
                    description=normalized.description,
                    parameters=normalized.parameters,
                )

                seen.setdefault(normalized.name, normalized)

        return [spec.as_request_payload() for spec in seen.values()]

    def _normalize_tool_spec(self, spec: Any) -> Optional[FunctionToolSpec]:
        if not isinstance(spec, Mapping):
            return None

        function_block = spec.get("function") if "function" in spec else spec
        if not isinstance(function_block, Mapping):
            return None

        name = function_block.get("name")
        if not name:
            return None

        description = str(function_block.get("description", ""))
        parameters = _coerce_to_dict(function_block.get("parameters") or {})
        return FunctionToolSpec(str(name), description, parameters)

    def _serialize_history(self, history: Sequence[Message]) -> List[Dict[str, Any]]:
        serialized: List[Dict[str, Any]] = []
        for message in history:
            try:
                serialized.append(self._serialize_message(message))
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "Skipping message that could not be serialized", error=str(exc)
                )
        return serialized

    def _serialize_message(self, message: Message) -> Dict[str, Any]:
        author_role = getattr(message.author, "role", Role.USER)
        provider_role = self._ROLE_TO_PROVIDER.get(author_role, "user")
        content_text = message_to_text(message)

        # For tool responses, map to 'user' role (Responses API doesn't support tool_call_id)
        # The tool result is included in the content
        if provider_role == "tool":
            tool_name = (
                message.recipient or getattr(message.author, "name", None) or "tool"
            )
            return {
                "role": "user",
                "content": f"Tool {tool_name} returned: {content_text}",
            }

        # For all other roles, only include allowed fields
        return {
            "role": provider_role,
            "content": content_text,
        }

    async def _create_completion(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]],
        tool_choice="auto",
        reasoning_effort="medium",
    ) -> OpenAIResponse:
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "input": messages,
            # "max_output_tokens": self.max_tokens,
        }

        if self.is_reasoning_model:
            kwargs["reasoning"] = {"effort": reasoning_effort}

        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = tool_choice
            kwargs["parallel_tool_calls"] = False

        # if not self.is_o1_model and self.temperature is not None:
        #     kwargs["temperature"] = self.temperature

        logger.debug(
            "Sending request to OpenAI",
            model=self.model,
            message_count=len(messages),
            has_tools=bool(tools),
        )

        # Azure content filter can reject prompts non-deterministically.
        # Retry once on content_filter errors before giving up.
        max_retries = 2
        for attempt in range(1, max_retries + 1):
            try:
                response = await self.client.responses.create(**kwargs)
                break
            except BadRequestError as e:
                is_content_filter = "content_filter" in str(e) or "content management policy" in str(e)
                if is_content_filter and attempt < max_retries:
                    logger.warning(
                        "Azure content filter triggered, retrying",
                        attempt=attempt,
                        error=str(e)[:200],
                    )
                    await asyncio.sleep(1.0)
                    continue
                raise

        usage = getattr(response, "usage", None)
        logger.info(
            "OpenAI response received",
            model=self.model,
            status=getattr(response, "status", None),
            input_tokens=getattr(usage, "input_tokens", None) if usage else None,
            output_tokens=getattr(usage, "output_tokens", None) if usage else None,
        )
        return response

    def _convert_response_to_messages(self, response: OpenAIResponse) -> List[Message]:
        messages: List[Message] = []
        for item in getattr(response, "output", []) or []:
            converted = self._convert_output_item(item)
            if converted:
                if isinstance(converted, list):
                    messages.extend(converted)
                else:
                    messages.append(converted)
        return messages

    def _convert_output_item(
        self, item: ResponseOutputItem
    ) -> Union[Message, List[Message], None]:
        if isinstance(item, ResponseOutputMessage):
            text_segments = [
                block.text
                for block in item.content
                if isinstance(block, ResponseOutputText) and block.text
            ]
            text = "\n".join(
                segment.strip() for segment in text_segments if segment.strip()
            )
            if text:
                return Message.from_role_and_content(Role.ASSISTANT, text).with_channel(
                    "final"
                )
            return None

        if isinstance(item, ResponseFunctionToolCall):
            call_id = item.id or item.call_id
            arguments = item.arguments or "{}"
            message = Message.from_role_and_content(Role.ASSISTANT, arguments)
            message = message.with_recipient(item.name).with_channel("tool_call")
            if call_id:
                message = message.with_content_type(call_id)
            return message

        if isinstance(item, ResponseReasoningItem):
            segments: List[str] = []
            if item.summary:
                segments.extend(
                    summary.text for summary in item.summary if summary.text
                )
            if item.content:
                segments.extend(
                    content.text for content in item.content if content.text
                )
            text = "\n".join(segment.strip() for segment in segments if segment.strip())
            if text:
                return Message.from_role_and_content(Role.ASSISTANT, text).with_channel(
                    "analysis"
                )
            return None

        logger.debug(
            "Ignoring unsupported OpenAI output item",
            item_type=getattr(item, "type", None),
        )
        return None
