"""Base LLM strategy with shared infrastructure for all providers."""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Mapping, Optional, Tuple, TYPE_CHECKING, Union

from jinja2.environment import Environment
from jinja2.runtime import StrictUndefined
from openai_harmony import Author, Message, Role, TextContent

from ...tools.models import ToolCall
from ...utils import get_logger

if TYPE_CHECKING:
    from ...core.context import AgentContext

__all__ = ["BaseLLMStrategy"]

logger = get_logger("aisolate.agent.strategies.llm.base")

_TEMPLATE_ENV = Environment(
    undefined=StrictUndefined, autoescape=False, trim_blocks=True, lstrip_blocks=True
)


# ---------------------------------------------------------------------------
# Shared text-extraction helpers
# ---------------------------------------------------------------------------


def strip_code_fences(value: str) -> str:
    """Remove markdown code fences from a string."""
    text = value.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\n?", "", text)
        text = re.sub(r"\n?```$", "", text)
    return text.strip()


def content_part_to_text(part: Any) -> str:
    """Convert a single message content part to text."""
    if isinstance(part, TextContent):
        return part.text
    if hasattr(part, "text") and isinstance(getattr(part, "text"), str):
        return getattr(part, "text")
    if hasattr(part, "to_dict"):
        try:
            return json.dumps(part.to_dict(), ensure_ascii=False)
        except Exception:
            pass
    if hasattr(part, "model_dump"):
        try:
            return json.dumps(part.model_dump(exclude_none=True), ensure_ascii=False)
        except Exception:
            pass
    return str(part)


def message_to_text(message: Message) -> str:
    """Extract all text content from a Message's content parts."""
    if not getattr(message, "content", None):
        return ""
    parts: List[str] = []
    for item in message.content:
        rendered = content_part_to_text(item)
        if rendered:
            parts.append(rendered)
    return "\n".join(parts).strip()


def safe_json_loads(raw: str) -> Union[Dict[str, Any], str]:
    """Try to parse JSON from a string, stripping code fences first."""
    candidate = strip_code_fences(raw)
    if not candidate:
        return {}
    try:
        return json.loads(candidate)
    except (json.JSONDecodeError, TypeError):
        return candidate


def render_template(
    template: Optional[str],
    variables: Mapping[str, Any],
    ns_config: Optional[Mapping[str, Any]] = None,
) -> str:
    """Render a Jinja2 template with namespace config injection."""
    if not template:
        return ""

    context = dict(variables)
    if ns_config:
        context.setdefault("ns", ns_config.get("separator", ""))
        context.setdefault("fn_prefix", ns_config.get("function_prefix", ""))
        context.setdefault("agent_prefix", ns_config.get("agent_prefix", ""))

    return _TEMPLATE_ENV.from_string(template).render(**context)


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class BaseLLMStrategy:
    """Shared infrastructure for LLM strategies.

    Provides default implementations for:
    - Template rendering and subagent task formatting
    - Tool response message creation
    - Namespace config / tool name resolution
    - Response parsing (extracting ToolCall or text from Message list)

    Subclasses must implement:
    - __init__() with provider-specific client setup
    - generate_response() — the actual LLM API call
    - prepare_initial_history() — provider-specific prompt construction
    - prepare_execution_history() — provider-specific prompt construction

    Subclasses may override:
    - create_tool_response_message() for provider-specific formatting
    - parse_assistant_response() if message structure differs significantly
    - _extract_tool_call_args() for provider-specific argument extraction
    """

    def __init__(
        self,
        templates: Optional[Dict[str, Any]] = None,
        namespace_config: Optional[Dict[str, Any]] = None,
    ):
        self._templates = templates or {}
        self._namespace_config = namespace_config or {
            "separator": ".",
            "function_prefix": "functions.",
            "agent_prefix": "functions.agents.",
            "tool_name_overrides": {},
        }

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def namespace_config(self) -> Dict[str, Any]:
        """Provider-specific namespace configuration."""
        return self._namespace_config

    @property
    def templates(self) -> Dict[str, Any]:
        """Template definitions for this strategy."""
        return self._templates

    def get_tool_name(self, default_name: str) -> str:
        """Get provider-specific tool name, applying overrides for reserved names."""
        overrides = self._namespace_config.get("tool_name_overrides", {})
        return overrides.get(default_name, default_name)

    def with_templates(self, templates: Dict[str, Any]) -> "BaseLLMStrategy":
        """Return a shallow copy of this strategy with different templates.

        Shares the same client, model, and config — only templates differ.
        """
        import copy

        clone = copy.copy(self)
        clone._templates = templates
        return clone

    def with_model(self, model: str) -> "BaseLLMStrategy":
        """Return a shallow copy of this strategy with a different model.

        Shares the same client, config, and templates — only model differs.
        """
        import copy

        clone = copy.copy(self)
        clone.model = model
        return clone

    # ------------------------------------------------------------------
    # Shared implementations
    # ------------------------------------------------------------------

    def create_tool_response_message(
        self, tool_name: str, result: Any, tool_call_id: Optional[str] = None
    ) -> Message:
        """Create a tool response message.

        Default implementation creates a Message with Role.TOOL and commentary channel.
        Override for provider-specific formatting (e.g. attaching tool_call_id).
        """
        return Message.from_author_and_content(
            Author.new(Role.TOOL, tool_name),
            str(result),
        ).with_channel("commentary")

    def format_subagent_task(
        self,
        agent_name: str,
        task: str,
        handover_runs: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> str:
        """Format a task for sub-agent execution.

        Looks for agent-specific template first (e.g., ``sub_agent.task.report_agent``),
        then falls back to the generic ``sub_agent.task`` template.

        When ``handover_runs`` is non-empty, an "Available handovers"
        registry is appended so the sub-agent knows which sibling agents
        have completed prior work it can pull data from via
        ``load_handover_data(agent_name)``.
        """
        sub_agent_templates = self.templates.get("sub_agent", {})
        # Try agent-specific template first, then generic
        prompt_template = (
            sub_agent_templates.get(f"task.{agent_name}")
            or sub_agent_templates.get("task")
            or "Create a plan to accomplish this task: {task}"
        )
        rendered = render_template(
            prompt_template,
            {"name": agent_name, "task": task},
            self.namespace_config,
        )
        if not handover_runs:
            return rendered
        return f"{rendered}\n\n{self._render_handover_registry(handover_runs)}"

    def _render_handover_registry(
        self, handover_runs: Dict[str, Dict[str, Any]]
    ) -> str:
        """Markdown bullet rendering of the handover registry.

        ``handover_runs`` is a dict keyed by agent_name. Strategies may
        override this to use a provider-native format.
        """
        lines = ["Available handovers in this conversation:"]
        for sibling_agent_name, run in handover_runs.items():
            lines.append(
                f"  - {sibling_agent_name} "
                f"(finished_at={run.get('finished_at', '')})"
            )
        lines.append("")
        lines.append("To load a handover: load_handover_data(agent_name)")
        return "\n".join(lines)

    def format_subagent_report(self, agent_name: str, final_answer: str) -> str:
        """Format a sub-agent's result for the parent agent.

        Uses the ``sub_agent.report`` template if available, otherwise
        returns the raw final_answer string.
        """
        prompt_template = self.templates.get("sub_agent", {}).get("report", "")
        if not prompt_template:
            return final_answer
        return render_template(
            prompt_template,
            {"name": agent_name, "final_answer": final_answer},
            self.namespace_config,
        )

    def parse_assistant_response(
        self, messages: List[Message]
    ) -> Tuple[Optional[ToolCall], Optional[str]]:
        """Parse assistant response to extract a tool call or text content.

        Walks messages looking for recipient (tool call) or final channel (text).
        Uses _extract_tool_call_args() for provider-specific argument extraction.

        Returns:
            Tuple of (tool_call, text_content) — one will be None.
        """
        tool_call: Optional[ToolCall] = None
        text_fragments: List[str] = []

        for m in reversed(messages):
            recipient = getattr(m, "recipient", None)
            channel = getattr(m, "channel", None)

            if recipient and tool_call is None:
                args, call_id = self._extract_tool_call_args(m)
                if not isinstance(args, dict):
                    args = {"value": args}
                tool_call = ToolCall(
                    name=recipient,
                    arguments=args,
                    tool_call_id=call_id,
                )
                break

            if channel in (None, "final"):
                text = message_to_text(m)
                if text:
                    text_fragments.append(text)

        if tool_call:
            return tool_call, None

        text_content = (
            "\n".join(reversed([t for t in text_fragments if t.strip()])).strip()
            or None
        )
        if text_content:
            return None, text_content

        return None, None

    def _extract_tool_call_args(
        self, message: Message
    ) -> Tuple[Union[Dict[str, Any], str], Optional[str]]:
        """Extract tool call arguments and call ID from a message.

        Override for provider-specific argument extraction.

        Returns:
            Tuple of (arguments, tool_call_id).
        """
        raw = message_to_text(message)
        args = safe_json_loads(raw)
        call_id = getattr(message, "content_type", None)
        return args, call_id

    # ------------------------------------------------------------------
    # Template rendering helpers
    # ------------------------------------------------------------------

    def _render_template(
        self,
        template: Optional[str],
        variables: Mapping[str, Any],
    ) -> str:
        """Render a Jinja2 template with this strategy's namespace config."""
        return render_template(template, variables, self.namespace_config)

    def _get_template_variables(self, context: "AgentContext") -> Dict[str, Any]:
        """Build the standard template variable dict from an AgentContext."""
        # Convert function_tools list to a dict keyed by name so Jinja
        # templates can call .values() consistently (same as sub_agents/actions).
        fn_dict = {fn.name: fn for fn in context.function_tools} if context.function_tools else {}
        return {
            "task": context.task,
            "sub_agents": context.sub_agent_tools,
            "functions": fn_dict,
            "actions": context.actions,
            "authorized_imports": "*",
        }
