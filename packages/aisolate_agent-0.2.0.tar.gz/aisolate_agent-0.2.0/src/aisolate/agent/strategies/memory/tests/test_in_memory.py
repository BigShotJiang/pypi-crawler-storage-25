"""Test InMemoryStrategy snapshot storage."""

import pytest
from aisolate.agent.strategies.memory.in_memory import InMemoryStrategy
from aisolate.agent.core.snapshot import AgentSnapshot


@pytest.mark.asyncio
class TestInMemoryStrategy:
    """Test in-memory snapshot storage."""

    async def test_save_snapshot(self):
        """Test saving a snapshot."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-1",
            turn=1,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=100,
            max_turns=10,
        )

        await strategy.save_snapshot(snapshot)

        # Verify saved
        loaded = await strategy.load_latest_snapshot("conv-1")
        assert loaded is not None
        assert loaded.conversation_id == "conv-1"
        assert loaded.turn == 1

    async def test_load_nonexistent_snapshot(self):
        """Test loading snapshot that doesn't exist."""
        strategy = InMemoryStrategy()

        loaded = await strategy.load_latest_snapshot("nonexistent")
        assert loaded is None

    async def test_save_overwrites_previous(self):
        """Test that saving a new snapshot overwrites the previous one."""
        strategy = InMemoryStrategy()

        # Save first snapshot
        snapshot1 = AgentSnapshot(
            conversation_id="conv-1",
            turn=1,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=100,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot1)

        # Save second snapshot (same conversation)
        snapshot2 = AgentSnapshot(
            conversation_id="conv-1",
            turn=2,
            agent_name="test",
            conversation_history=[
                {
                    "author": {"role": "user"},
                    "content": [{"text": "Hello", "type": "text"}],
                }
            ],
            finished=False,
            final_answer=None,
            execution_time_ms=200,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot2)

        # Only latest should be available
        loaded = await strategy.load_latest_snapshot("conv-1")
        assert loaded is not None
        assert loaded.turn == 2  # Latest turn
        assert len(loaded.conversation_history) == 1

    async def test_save_load_roundtrip(self):
        """Test complete save/load roundtrip."""
        strategy = InMemoryStrategy()

        original = AgentSnapshot(
            conversation_id="conv-roundtrip",
            turn=5,
            agent_name="test_agent",
            conversation_history=[
                {
                    "author": {"role": "user"},
                    "content": [{"text": "Hello", "type": "text"}],
                },
                {
                    "author": {"role": "assistant"},
                    "content": [{"text": "Hi", "type": "text"}],
                },
            ],
            finished=False,
            final_answer=None,
            execution_time_ms=500,
            max_turns=10,
        )

        await strategy.save_snapshot(original)
        loaded = await strategy.load_latest_snapshot("conv-roundtrip")

        assert loaded is not None
        assert loaded.conversation_id == original.conversation_id
        assert loaded.turn == original.turn
        assert loaded.agent_name == original.agent_name
        assert len(loaded.conversation_history) == 2
        assert loaded.execution_time_ms == original.execution_time_ms

    async def test_multiple_conversations(self):
        """Test storing snapshots for multiple conversations."""
        strategy = InMemoryStrategy()

        # Save snapshots for different conversations
        for i in range(1, 4):
            snapshot = AgentSnapshot(
                conversation_id=f"conv-{i}",
                turn=i,
                agent_name="test",
                conversation_history=[],
                finished=False,
                final_answer=None,
                execution_time_ms=i * 100,
                max_turns=10,
            )
            await strategy.save_snapshot(snapshot)

        # Verify all are retrievable
        for i in range(1, 4):
            loaded = await strategy.load_latest_snapshot(f"conv-{i}")
            assert loaded is not None
            assert loaded.turn == i
            assert loaded.execution_time_ms == i * 100

    async def test_load_snapshot_at_turn_latest_match(self):
        """Test load_snapshot_at_turn when latest matches requested turn."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-1",
            turn=3,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=300,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot)

        # Request the exact turn that's stored
        loaded = await strategy.load_snapshot_at_turn("conv-1", 3)
        assert loaded is not None
        assert loaded.turn == 3

    async def test_load_snapshot_at_turn_no_match(self):
        """Test load_snapshot_at_turn when turn doesn't match."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-1",
            turn=3,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=300,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot)

        # Request a different turn (in-memory only has latest)
        loaded = await strategy.load_snapshot_at_turn("conv-1", 2)
        assert loaded is None  # Turn mismatch

    async def test_get_available_turns_empty(self):
        """Test getting available turns when no snapshot exists."""
        strategy = InMemoryStrategy()

        turns = await strategy.get_available_turns("nonexistent")
        assert turns == []

    async def test_get_available_turns_single(self):
        """Test getting available turns when snapshot exists."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-1",
            turn=5,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            execution_time_ms=500,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot)

        turns = await strategy.get_available_turns("conv-1")
        assert turns == [5]  # Only latest turn available

    async def test_get_event_stream_empty(self):
        """Test getting event stream when no snapshot exists."""
        strategy = InMemoryStrategy()

        events = await strategy.get_event_stream("nonexistent")
        assert events == []

    async def test_get_event_stream_with_snapshot(self):
        """Test getting event stream from snapshot."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-1",
            turn=2,
            agent_name="test",
            conversation_history=[],
            finished=False,
            final_answer=None,
            turn_events=[
                {
                    "type": "state_transition",
                    "from_state": "planning",
                    "to_state": "execution",
                    "timestamp": "2024-01-01T00:00:00",
                },
                {
                    "type": "tool_call",
                    "tool_name": "search",
                    "timestamp": "2024-01-01T00:00:01",
                },
            ],
            execution_time_ms=200,
            max_turns=10,
        )
        await strategy.save_snapshot(snapshot)

        events = await strategy.get_event_stream("conv-1")
        assert len(events) == 2
        assert events[0]["type"] == "state_transition"
        assert events[1]["type"] == "tool_call"

    async def test_snapshot_with_final_answer(self):
        """Test saving/loading snapshot with final answer."""
        strategy = InMemoryStrategy()

        snapshot = AgentSnapshot(
            conversation_id="conv-finished",
            turn=10,
            agent_name="test",
            conversation_history=[],
            finished=True,
            final_answer={
                "answer": "Task completed successfully",
            },
            execution_time_ms=1000,
            max_turns=10,
        )

        await strategy.save_snapshot(snapshot)
        loaded = await strategy.load_latest_snapshot("conv-finished")

        assert loaded is not None
        assert loaded.finished is True
        assert loaded.final_answer is not None
        assert loaded.final_answer["answer"] == "Task completed successfully"
