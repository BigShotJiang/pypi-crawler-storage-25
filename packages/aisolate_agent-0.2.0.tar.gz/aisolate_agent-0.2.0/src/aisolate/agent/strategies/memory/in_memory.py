"""In-memory memory strategy implementation for development."""

from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ...utils import get_logger

if TYPE_CHECKING:
    from ...core.snapshot import AgentSnapshot

logger = get_logger("aisolate.agent.strategies.memory.in_memory")


class InMemoryStrategy:
    """In-memory persistence for development and testing.

    Stores latest AgentSnapshot per conversation_id.
    Simple implementation - only keeps most recent snapshot.

    For full history with time-travel, use DatabasePersistenceStrategy.
    """

    def __init__(self) -> None:
        """Initialize the in-memory storage."""
        # Map: conversation_id → AgentSnapshot
        self._snapshots: Dict[str, "AgentSnapshot"] = {}

    async def save_snapshot(self, snapshot: "AgentSnapshot") -> None:
        """Persist agent snapshot (overwrites any previous snapshot).

        Args:
            snapshot: Complete agent state to persist
        """
        self._snapshots[snapshot.conversation_id] = snapshot

        logger.debug(
            "Saved snapshot",
            conversation_id=snapshot.conversation_id,
            turn=snapshot.turn,
            finished=snapshot.finished,
        )

    async def load_latest_snapshot(
        self, conversation_id: str
    ) -> Optional["AgentSnapshot"]:
        """Load most recent snapshot for conversation.

        Args:
            conversation_id: Conversation identifier

        Returns:
            Latest snapshot or None if not found
        """
        snapshot = self._snapshots.get(conversation_id)

        if snapshot:
            logger.debug(
                "Loaded latest snapshot",
                conversation_id=conversation_id,
                turn=snapshot.turn,
            )
        else:
            logger.debug(
                "No snapshot found",
                conversation_id=conversation_id,
            )

        return snapshot

    async def load_snapshot_at_turn(
        self, conversation_id: str, turn: int
    ) -> Optional["AgentSnapshot"]:
        """Load snapshot at specific turn.

        InMemoryStrategy only stores latest, so this only works if
        the latest snapshot matches the requested turn.

        Args:
            conversation_id: Conversation identifier
            turn: Turn number to restore

        Returns:
            Snapshot at turn or None if not found
        """
        snapshot = self._snapshots.get(conversation_id)

        if not snapshot:
            logger.debug(
                "No snapshot found",
                conversation_id=conversation_id,
            )
            return None

        if snapshot.turn != turn:
            logger.warning(
                "Turn mismatch (in-memory only stores latest)",
                requested=turn,
                available=snapshot.turn,
            )
            return None

        logger.debug(
            "Loaded snapshot at turn",
            conversation_id=conversation_id,
            turn=turn,
        )

        return snapshot

    async def get_available_turns(self, conversation_id: str) -> List[int]:
        """Get list of available turn numbers.

        InMemoryStrategy only stores latest, so returns single turn or empty list.

        Args:
            conversation_id: Conversation identifier

        Returns:
            List with single turn number or empty list
        """
        snapshot = self._snapshots.get(conversation_id)

        if snapshot:
            return [snapshot.turn]

        return []

    async def get_event_stream(self, conversation_id: str) -> List[Dict[str, Any]]:
        """Get complete event stream from all snapshots.

        InMemoryStrategy only stores latest snapshot, so returns only
        events from that snapshot.

        For complete event history, use DatabasePersistenceStrategy.

        Args:
            conversation_id: Conversation identifier

        Returns:
            Events from latest snapshot (or empty list)
        """
        snapshot = self._snapshots.get(conversation_id)

        if not snapshot:
            logger.debug(
                "No snapshot found for event stream",
                conversation_id=conversation_id,
            )
            return []

        # Return events from latest snapshot
        events = snapshot.get_events()

        logger.debug(
            "Retrieved event stream",
            conversation_id=conversation_id,
            event_count=len(events),
        )

        return events
