"""Memory strategies module."""

from .in_memory import InMemoryStrategy

__all__ = [
    "InMemoryStrategy",
]
