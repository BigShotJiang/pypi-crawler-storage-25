"""Main Agent class - public API for the three-tier tool architecture."""

from typing import Optional, Dict, Any, List, Iterable, TYPE_CHECKING
import time
import traceback

from .config.agent_settings import AgentSettings
from .core.context import AgentContext
from .core.protocols import LLMStrategy, MemoryStrategy
from .core.snapshot import AgentSnapshot
from .core.events import (
    AgentStartedEvent,
    TurnCompletedEvent,
    AgentFinishedEvent,
    AgentErrorEvent,
    HITLRequestEvent,
)
from openai_harmony import Author, Message, Role, TextContent
from .states.planning import PlanningState
from .utils import get_logger, setup_logging
from .logging import LoggingConfig

from .tools.platform.subagent import SubAgentTool
from .tools.platform.python_executor import PythonExecutorTool
from .tools.actions.final_answer import FinalAnswerAction
from .tools.actions.base import validate_action

from aisolate.client.sandbox import Sandbox

from .tools.models import FinalAnswerResult

logger = get_logger("aisolate.agent")


def _validate_managed_agents_acyclic(
    agent: "Agent",
    path: tuple = (),
) -> None:
    """Reject cycles in the sub-agent dependency graph.

    Walks the ``managed_agents`` tree depth-first and raises ``ValueError``
    if a cycle is found (e.g. A -> B -> C -> A). Acyclic chains and
    diamonds (A -> {B, C}, B -> D, C -> D) are permitted.

    Detection is by ``agent.name`` on the active path, so two distinct
    agents with the same name will be reported as a cycle — a deliberately
    conservative choice given that sub-agent tool names already collide on
    name within one parent.

    Raises:
        ValueError: with a readable trace of the cycle path.
    """
    if agent.name in path:
        cycle = " -> ".join(path + (agent.name,))
        raise ValueError(f"Cyclic sub-agent dependency: {cycle}")
    new_path = path + (agent.name,)
    for managed in (getattr(agent, "managed_agents", None) or ()):
        _validate_managed_agents_acyclic(managed, new_path)


class Agent:
    """Main agent class that orchestrates the three-tier tool architecture.

    This class provides the public API for creating and running agents with
    different strategies for LLM interaction, memory and tool execution.

    Example usage:
        ```python
        # Create agent with pre-configured strategies
        harmony_llm = HarmonyLLMStrategy(base_url="https://api.harmony.ai/v1")
        in_memory = InMemoryStrategy()

        async with Sandbox() as sandbox:
            agent = Agent(
                llm_strategy=harmony_llm,
                memory_strategy=in_memory,
                sandbox=sandbox,
                settings=AgentSettings(max_turns=20),
                actions=[WebSearchAction()]
            )

            result = await agent.run("What is the weather in San Francisco?")
            print(result)
        ```
    """

    def __init__(
        self,
        name: str,
        description: str,
        llm_strategy: LLMStrategy,
        memory_strategy: MemoryStrategy,
        sandbox: Sandbox,
        settings: Optional[AgentSettings] = None,
        managed_agents: Optional[List["Agent"]] = None,
        builtin_tools: Optional[Iterable[Any]] = None,
        function_tools: Optional[Iterable[Any]] = None,
        actions: Optional[List[Any]] = None,
        checkpoint_storage: Optional[Any] = None,
        review_state: Optional[type] = None,
        state_model_overrides: Optional[Dict[str, str]] = None,
        file_resolver: Optional[Any] = None,
    ):
        """Initialize the Agent with configured strategies.

        Args:
            llm_strategy: Pre-configured LLM strategy implementation
            memory_strategy: Pre-configured memory strategy implementation
            sandbox: Active sandbox instance for code execution
            settings: Agent-specific configuration settings
            builtin_tools: Optional list of builtin platform tools
            function_tools: Optional list of function tools
            actions: List of action instances
            checkpoint_storage: Optional CheckpointStorage implementation for
                kernel state persistence via presigned URLs
            review_state: Optional state class for QA review (e.g. CriticState).
                When set, ``request_report_review()`` transitions here instead of
                ``FinishedState``.
            state_model_overrides: Map of state class name → model name.
                Before each turn, the agent swaps ``context.llm`` to a
                strategy configured for the overridden model.
            file_resolver: Optional FileResolver for resolving file URLs
                to bytes (used by review states for image content).
        """
        self.name = name
        self.description = description
        self.llm_strategy = llm_strategy
        self.memory_strategy = memory_strategy
        self.sandbox = sandbox
        self.settings = settings or AgentSettings()
        self.checkpoint_storage = checkpoint_storage
        self.review_state = review_state
        self.state_model_overrides = state_model_overrides or {}
        self.file_resolver = file_resolver
        # Stored so the cycle validator can walk nested managed_agents trees
        # at construction time (see _validate_managed_agents_acyclic call below).
        self.managed_agents = list(managed_agents or [])

        # --- Defaults & override merging ---
        def _default_builtin() -> list[Any]:
            python_tool = PythonExecutorTool()
            # Apply strategy-specific tool name override for reserved names
            python_tool.name = self.llm_strategy.get_tool_name("python")
            return [python_tool]

        if managed_agents is None:
            self.sub_agent_tools = {}
        else:
            self.sub_agent_tools = {}
            for agent in managed_agents:
                # Pass namespace config from parent's LLM strategy (Solution 1)
                sa = SubAgentTool(
                    agent=agent,
                    namespace_config=self.llm_strategy.namespace_config,
                )
                self.sub_agent_tools[sa.name] = sa

        if builtin_tools is None:
            self.builtin_tools = _default_builtin()
        else:
            # Merge: user overrides by name and apply strategy-specific name overrides
            base = {t.name: t for t in _default_builtin()}
            for t in builtin_tools:
                # Apply strategy-specific name override
                t.name = self.llm_strategy.get_tool_name(t.name)
                base[t.name] = t
            self.builtin_tools = list(base.values())

        self.function_tools = list(function_tools or [])

        # Auto-register HITL tools when enabled
        if self.settings.enable_hitl or self.settings.enable_clarification:
            # Clarification implies HITL
            if self.settings.enable_clarification:
                self.settings.enable_hitl = True
            from .tools.functions.hitl import create_ask_user_tool, create_confirm_tool

            existing_names = {t.name for t in self.function_tools}
            if "ask_user" not in existing_names:
                self.function_tools.append(create_ask_user_tool())
            if "confirm" not in existing_names:
                self.function_tools.append(create_confirm_tool())

        # Actions: register completion action(s).
        # When a review state is configured, register BOTH request_report_review
        # and final_answer.  request_report_review goes through QA review;
        # final_answer is available as a direct delivery fallback.
        if self.review_state is not None:
            from .tools.actions.request_report_review import ScheduleReviewAction

            base_actions: Dict[str, Any] = {
                "request_report_review": ScheduleReviewAction(),
                "final_answer": FinalAnswerAction(),
            }
        else:
            base_actions: Dict[str, Any] = {"final_answer": FinalAnswerAction()}

        # Register LoadHandoverAction when checkpoint storage is available.
        # Any agent (main or sub) may need to load a sibling's handover data,
        # so this only requires checkpoint_storage — not enable_checkpoint.
        if self.checkpoint_storage:
            from .tools.actions.load_handover import LoadHandoverAction

            base_actions["load_handover_data"] = LoadHandoverAction()

        if actions:
            # Convert list of actions to dict using action.name as key
            for action in actions:
                if hasattr(action, "name") and action.name:
                    base_actions[action.name] = action
                else:
                    raise ValueError(
                        f"Action {action.__class__.__name__} must have a valid 'name' attribute"
                    )

        # Validate all actions during agent initialization
        validated_actions = {}
        for name, action in base_actions.items():
            try:
                validate_action(action)
                logger.debug("Validated action", action_name=name)
                validated_actions[name] = action
            except Exception as e:
                logger.error("Action validation failed", action_name=name, error=str(e))
                raise ValueError(f"Invalid action '{name}': {e}") from e

        self.actions = validated_actions

        # Reject cyclic sub-agent dependency graphs at construction time.
        # Acyclic chains and diamonds are permitted; cycles raise with a
        # readable trace. Cheap (O(N) over reachable agents) and runs once
        # per Agent instantiation.
        _validate_managed_agents_acyclic(self)

    async def run(self, task: str) -> "FinalAnswerResult":
        """Run the agent on a single task and return the final answer.

        This is a convenience wrapper around run_streaming() that extracts
        just the final result. Creates a new conversation with a generated UUID.

        Args:
            task: The task description for the agent to accomplish

        Returns:
            FinalAnswerResult containing answer text and optional metadata (sources, confidence)

        Raises:
            RuntimeError: If agent is already running or no final answer provided
            ValueError: If task is empty
        """
        import uuid

        final_answer: Optional[FinalAnswerResult] = None

        # Generate new conversation_id for this execution
        conversation_id = str(uuid.uuid4())

        async for update in self.run_streaming(task, conversation_id):
            if hasattr(update, "type") and update.type == "agent_finished":
                final_answer = getattr(update, "final_answer", None)
                if final_answer is not None:
                    return final_answer
            elif hasattr(update, "type") and update.type == "agent_error":
                # Always raise exceptions in the synchronous run() method
                error_msg = getattr(update, "error", "Unknown error")
                raise RuntimeError(f"Agent execution failed: {error_msg}")

        # If we get here, no final answer was provided
        raise RuntimeError("Agent completed without providing a final answer")

    async def run_streaming(self, task: str, conversation_id: str):
        """Run the agent with streaming updates.

        Creates a fresh context-bound sandbox for each execution.

        Args:
            task: The task description for the agent to accomplish
            conversation_id: Conversation UUID (required)
                - New conversation: caller generates new UUID
                - Existing conversation: caller provides existing UUID

        Yields:
            Dict updates about agent state, tool calls, and progress
        """
        # Add structured logging context. Intentionally omit `task` — it
        # is already on the OTEL root span's input.value; dumping it on
        # every bound_logger.info() call floods the console.
        bound_logger = logger.bind(
            agent_id=id(self),
            llm_strategy=type(self.llm_strategy).__name__,
            memory_strategy=type(self.memory_strategy).__name__,
            conversation_id=conversation_id,
        )

        bound_logger.info("Starting agent execution")

        try:
            # Use new telemetry system for tracing
            from .telemetry import get_tracer

            tracer = get_tracer()

            with tracer.span("agent.session") as session_span:  # type: ignore
                # OpenInference AGENT attributes — vendor-neutral.
                session_span.set_attribute("openinference.span.kind", "AGENT")
                session_span.set_attribute("agent.name", self.name)
                if conversation_id:
                    session_span.set_attribute("session.id", conversation_id)
                if isinstance(task, str):
                    session_span.set_attribute("input.value", task[:4000])
                session_span.set_attribute("agent.task", task)
                session_span.set_attribute(
                    "agent.llm_strategy", type(self.llm_strategy).__name__
                )
                session_span.set_attribute(
                    "agent.memory_strategy", type(self.memory_strategy).__name__
                )
                session_span.set_attribute("agent.max_turns", self.settings.max_turns)

                # Create AgentContext without sandbox — sandbox is provisioned
                # at the Assessment→Execution barrier, not here.
                context = AgentContext(
                    agent_name=self.name,
                    task=task,
                    llm=self.llm_strategy,
                    memory=self.memory_strategy,
                    sandbox=None,
                    max_turns=self.settings.max_turns,
                    conversation_id=conversation_id,
                    sub_agent_tools=self.sub_agent_tools,
                    actions=self.actions,
                    builtin_tools=self.builtin_tools,
                    function_tools=self.function_tools,
                    parent_context=None,  # Top-level agent
                )
                context.review_state = self.review_state
                context.file_resolver = self.file_resolver
                bound_logger.info(
                    "Context created: review_state assignment",
                    review_state=repr(self.review_state),
                    review_state_is_none=self.review_state is None,
                    review_state_type=type(self.review_state).__name__ if self.review_state else "NoneType",
                    context_review_state=repr(context.review_state),
                    context_review_state_is_none=context.review_state is None,
                )

                # RESTORATION LOGIC - Load and apply snapshot if it exists
                snapshot = await context.memory.load_latest_snapshot(conversation_id)
                if snapshot:
                    self._restore_context_from_snapshot(context, snapshot)
                    bound_logger.info(
                        "Restored from snapshot",
                        turn=snapshot.turn,
                        messages_count=len(snapshot.conversation_history),
                    )
                else:
                    bound_logger.debug("No snapshot found, starting fresh")

                # Execute with prepared context
                async for result in self._execute_with_context(
                    context, bound_logger, tracer, snapshot
                ):
                    yield result
        except Exception as e:
            import traceback

            # Log with full stack trace
            bound_logger.error(
                "Agent execution failed (outer catch)",
                error=str(e),
                exception=type(e).__name__,
                traceback=traceback.format_exc(),
            )

            # Also use structured exception logging
            bound_logger.log_exception(e, "agent_execution_outer")

            yield AgentErrorEvent(
                error=str(e),
                exception_type=type(e).__name__,
                traceback=(
                    traceback.format_exc() if self.settings.debug_mode else None
                ),
                turn=0,
            )
            if self.settings.debug_mode:
                raise

    def _restore_context_from_snapshot(
        self, context: AgentContext, snapshot: "AgentSnapshot"
    ) -> None:
        """Restore context from snapshot for a follow-up turn.

        Every follow-up — whether the prior turn finished cleanly or was
        paused on a HITL signal — routes to ``PlanningState``. The new
        user message becomes the next planning input; ``context.task``
        (which carries the rendered references markdown built by the
        application boundary) is preserved so the planner sees what the
        user attached to *this* message.

        Clarification / ExpertSynthesis is a first-turn-only ritual: a
        follow-up always has full conversation history to plan from, so
        re-running the expert panel adds latency without adding signal.

        Any stale ``pending_hitl_signal`` is cleared. The earlier HITL
        question and the user's reply (if there was one) are already in
        the conversation history — the planner can use them as context.

        Args:
            context: Fresh context to restore into
            snapshot: Snapshot with saved state
        """
        from openai_harmony import Message
        from .states.planning import PlanningState

        # Restore conversation history
        messages = [
            Message.from_dict(msg_data) for msg_data in snapshot.conversation_history
        ]
        context.set_conversation_history(messages)

        # Restore execution state
        context.execution.turn = snapshot.turn
        context.execution.finished = False
        context.execution.previous_state_name = snapshot.previous_state_name

        # Restore agent-level state that is not serialized in snapshots
        context.review_state = self.review_state
        context.file_resolver = self.file_resolver

        # HITL clarification resume: the user is answering the panel's
        # ask_user question. Route through ClarificationState so its
        # previous_state_name == "HITLWaitState" branch fires and reaches
        # ExpertSynthesisState — which sets the planner's system prompt
        # via prepare_planning_history_from_brief. Without this, the
        # snapshot path jumps straight to PlanningState and the planner
        # inherits the leftover expert_panel system prompt, producing a
        # chat reply instead of a plan.
        is_hitl_clarification_resume = (
            bool(snapshot.pending_hitl_signal)
            and snapshot.hitl_resume_state == "ClarificationState"
        )

        had_pending_hitl = bool(snapshot.pending_hitl_signal)
        context.pending_hitl_signal = None
        context.hitl_resume_state = None

        # Carry the prior final answer over for reference in the planner.
        if snapshot.finished and snapshot.final_answer:
            context.prior_final_answer = snapshot.final_answer.get("answer", None)

        if is_hitl_clarification_resume:
            # context.task is the user's clarification answer; the
            # original task lives on the snapshot. ClarificationState's
            # resume handler reads context.task as original_task, so
            # restore that invariant here.
            user_answer = context.task
            context.task = snapshot.original_task or user_answer

            # Append the answer so _extract_user_answer finds it as the
            # last USER message in history.
            context.add_conversation_message(
                Message.from_role_and_content(Role.USER, user_answer)
            )

            from .states.clarification import ClarificationState
            context.transition_to(ClarificationState())
            # transition_to overwrote previous_state_name with the prior
            # current_state ("None" on a fresh restore). Re-stamp it so
            # ClarificationState.handle() takes the resume branch.
            context.execution.previous_state_name = "HITLWaitState"

            logger.info(
                "Snapshot restored — HITL clarification resume routed to ClarificationState",
                turn=snapshot.turn,
                conversation_id=snapshot.conversation_id,
                messages_count=len(messages),
                original_task=(context.task or "")[:100],
                user_answer=user_answer[:100],
            )
            return

        # Plain follow-up (no HITL pending, or HITL paused outside of
        # clarification): keep the PlanningState shortcut.
        context.add_conversation_message(
            Message.from_role_and_content(Role.USER, context.task)
        )
        context.transition_to(PlanningState())

        logger.info(
            "Snapshot restored — follow-up routed to PlanningState",
            turn=snapshot.turn,
            conversation_id=snapshot.conversation_id,
            messages_count=len(messages),
            was_finished=snapshot.finished,
            cleared_stale_hitl=had_pending_hitl,
            follow_up=(context.task or "")[:100],
        )

    async def _save_checkpoint(self, context: AgentContext, bound_logger) -> None:
        """Save kernel state checkpoint to external storage via presigned URL.

        Best-effort: failure does not block the agent. The LLM can always
        reconstruct state from conversation history.
        """
        key = f"checkpoints/{context.conversation_id}/{context.turn}.pkl"
        try:
            upload_url = await self.checkpoint_storage.get_upload_url(key)
            result = await context.remote_python_executor.checkpoint_save(
                upload_url=upload_url,
            )
            if result and result.get("saved"):
                context.checkpoint_key = key
                context.checkpoint_manifest = result.get("manifest", [])
                bound_logger.info(
                    f"▣ CHECKPOINT SAVED ({context.agent_name})",
                    key=key,
                    saved=result.get("saved", []),
                    size_bytes=result.get("size_bytes", 0),
                )
            else:
                bound_logger.debug("No variables to checkpoint")
        except Exception as e:
            bound_logger.warning(
                "Checkpoint save failed, continuing without",
                error=str(e),
            )

    async def _restore_checkpoint(
        self, context: AgentContext, snapshot: "AgentSnapshot", bound_logger
    ) -> None:
        """Restore kernel state from checkpoint via presigned URL.

        Best-effort: failure does not block the agent. The LLM will
        reconstruct state from conversation history (degraded but functional).
        """
        # Snapshots saved on non-final turns (or by agents with
        # enable_checkpoint=False) carry checkpoint_key=None. Skip the
        # restore in that case — there is no blob to fetch. We still
        # invoke the handover URL re-injection at the end of this method
        # because that's keyed by snapshot.handover_runs, not
        # checkpoint_key, and is independent of kernel state.
        if not snapshot.checkpoint_key:
            await self._inject_handover_urls(
                context, snapshot.handover_runs or {}, bound_logger
            )
            return
        try:
            download_url = await self.checkpoint_storage.get_download_url(
                snapshot.checkpoint_key
            )
            restored = await context.remote_python_executor.checkpoint_restore(
                download_url=download_url,
            )
            if restored:
                # Build a context message so the LLM knows what's in namespace
                manifest_lines = []
                for var in snapshot.checkpoint_manifest or []:
                    desc = var.get("name", "?")
                    if "shape" in var:
                        desc += f" ({var['type']}, shape={var['shape']})"
                    elif "len" in var:
                        desc += f" ({var['type']}, len={var['len']})"
                    else:
                        desc += f" ({var['type']})"
                    manifest_lines.append(desc)

                restore_msg = (
                    "Kernel state has been restored from checkpoint. "
                    "Available variables: " + ", ".join(manifest_lines) + ". "
                    "Note: modules must be re-imported. "
                    "Functions and classes must be redefined."
                )
                context.add_conversation_message(
                    Message.from_role_and_content(Role.USER, restore_msg)
                )
                bound_logger.info(
                    f"▤ CHECKPOINT RESTORED ({context.agent_name})",
                    variables=restored,
                    key=snapshot.checkpoint_key,
                )
        except Exception as e:
            bound_logger.warning(
                "Checkpoint restore failed, LLM will reconstruct from history",
                error=str(e),
            )
            context.add_conversation_message(
                Message.from_role_and_content(
                    Role.USER,
                    "Your previous computation context (variables, dataframes, "
                    "intermediate results) is no longer available — the checkpoint "
                    "has expired. You still have the full conversation history. "
                    "If the user references prior results, re-compute them from "
                    "source data using the available tools.",
                )
            )

        # Re-sign handover URLs into the parent kernel.
        await self._inject_handover_urls(
            context, snapshot.handover_runs or [], bound_logger
        )

    async def _inject_handover_urls(
        self,
        context: AgentContext,
        handover_runs: Dict[str, Dict[str, Any]],
        bound_logger,
    ) -> None:
        """Re-sign each handover_runs record's checkpoint URL and inject the
        registry into the kernel as ``_aisolate_handover_urls``.

        ``handover_runs`` is a dict keyed by agent_name. Used by both
        ``Agent.run_streaming`` (when restoring main_agent on resume) and
        ``SubAgentTool.execute`` (when a resumed sub-agent needs visibility
        into the parent's sibling-state registry).
        """
        if not handover_runs or not self.checkpoint_storage:
            return

        url_records: Dict[str, Dict[str, Any]] = {}
        for agent_name, run in handover_runs.items():
            try:
                url = await self.checkpoint_storage.get_download_url(
                    run["checkpoint_key"], expires_seconds=3600
                )
                url_records[agent_name] = {
                    "conversation_id": run["conversation_id"],
                    "url": url,
                    "manifest": run.get("manifest", []),
                }
            except Exception as e:
                bound_logger.warning(
                    "Failed to re-sign handover URL",
                    agent_name=agent_name,
                    conversation_id=run.get("conversation_id"),
                    error=str(e),
                )

        if url_records:
            code = f"_aisolate_handover_urls = {url_records!r}"
            await context.remote_python_executor.python_exec(code)
            context.handover_runs = dict(handover_runs)
            bound_logger.info(
                "═══ HANDOVER URLs re-signed ═══",
                runs=[
                    f"{name}/{rec['conversation_id']}"
                    for name, rec in url_records.items()
                ],
            )

    async def _save_turn_state(
        self,
        context: AgentContext,
        bound_logger,
        turn_event,
    ) -> None:
        """Per-turn state persistence: kernel checkpoint (final-turn only)
        + snapshot (every turn).

        Used by both ``Agent.run_streaming`` (the main_agent's turn loop)
        and ``SubAgentTool._execute_subagent`` (the sub-agent's turn loop).
        Without this helper being called from both, sub-agent snapshots
        and checkpoints would never be written, which breaks resume.
        """
        # Save kernel checkpoint on final turn (finished or max-turns hit).
        # Captured into context.checkpoint_key BEFORE the snapshot is
        # created so the key is included in the persisted snapshot.
        if (
            (context.is_finished or context.turn >= self.settings.max_turns)
            and self.checkpoint_storage
            and self.settings.enable_checkpoint
            and context.turn > 0
        ):
            await self._save_checkpoint(context, bound_logger)

        # Persist snapshot if conversation_id exists.
        if context.conversation_id:
            snapshot = context.create_snapshot()
            snapshot.add_event(turn_event)
            await context.memory.save_snapshot(snapshot)

    async def _provision_execution_environment(
        self,
        context: AgentContext,
        snapshot: "AgentSnapshot",
        bound_logger,
    ) -> None:
        """Provision sandbox, send actions, and restore checkpoint.

        Called at the Assessment→Execution transition barrier — exactly
        once per agent run, and only when the agent reaches ExecutingState.
        """
        import asyncio

        # 1. Activate container + create kernel context (with retry)
        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                # Enter the container if not already active (deferred activation)
                if not getattr(self.sandbox, "_is_active", False):
                    await self.sandbox.__aenter__()
                sandbox_ctx = await self.sandbox.acreate_context_bound_sandbox()
                context.set_sandbox(sandbox_ctx)
                break
            except Exception as e:
                if attempt < max_retries:
                    wait = 2**attempt  # 1s, 2s
                    bound_logger.warning(
                        "Sandbox creation failed, retrying",
                        attempt=attempt + 1,
                        max_retries=max_retries,
                        wait_seconds=wait,
                        error=str(e),
                    )
                    await asyncio.sleep(wait)
                else:
                    raise  # Final attempt — let it propagate

        # 2. Initialize remote executor with actions
        await context.remote_python_executor.send_actions(self.actions)

        # 3. Restore kernel checkpoint (if available)
        if (
            snapshot
            and snapshot.checkpoint_key
            and self.checkpoint_storage
            and self.settings.enable_checkpoint
        ):
            await self._restore_checkpoint(context, snapshot, bound_logger)

        bound_logger.info(
            "Execution environment provisioned",
            has_checkpoint=bool(snapshot and snapshot.checkpoint_key),
        )

    async def _execute_with_context(
        self, context: AgentContext, bound_logger, tracer, snapshot=None
    ):
        """Execute agent with given context.

        Context is assumed to be ready (fresh or restored).
        NO restoration logic here - that happens in run_streaming().

        Args:
            context: Fresh AgentContext with isolated sandbox (possibly restored)
            bound_logger: Logger with bound context
            tracer: Telemetry tracer
        """
        start_time = time.time()
        execution_env_ready = False  # Barrier flag
        try:
            # Initialize conversation history (only if not restored from snapshot)
            if not context.get_conversation_messages():
                if self.settings.enable_clarification:
                    initial_messages = self.llm_strategy.prepare_clarification_history(
                        context
                    )
                else:
                    initial_messages = self.llm_strategy.prepare_initial_history(
                        context
                    )
                context.initialize_conversation(initial_messages)

            # Set initial state (only if not restored from snapshot)
            if context.execution.current_state is None:
                if self.settings.enable_clarification:
                    from .states.clarification import ClarificationState

                    context.transition_to(ClarificationState())
                else:
                    context.transition_to(PlanningState())

            yield AgentStartedEvent(
                task=context.task,
                turn=context.turn,
                max_turns=self.settings.max_turns,
                agent_name=self.name,
                conversation_id=context.conversation_id,
            )

            # Execute agent turns until completion
            while not context.is_finished:
                # ── TRANSITION BARRIER ──
                # Provision sandbox when entering ExecutingState for the first time.
                # Assessment states (Clarification, Planning) need only the LLM.
                from .states.executing import ExecutingState as _ExecutingState

                if not execution_env_ready and isinstance(
                    context.execution.current_state, _ExecutingState
                ):
                    await self._provision_execution_environment(
                        context, snapshot, bound_logger
                    )
                    execution_env_ready = True

                # Create tracing span for individual turn (always - no conditional logic)
                with tracer.span(f"agent.turn.{context.turn}") as turn_span:  # type: ignore
                    turn_span.set_attribute("agent.turn", context.turn)
                    turn_span.set_attribute(
                        "agent.state", type(context._state).__name__
                    )
                    turn_span.set_attribute("agent.task", context.task)

                    # Swap LLM strategy if current state has a model override.
                    # Overrides can be a model name (str) or a full strategy object.
                    state_name = type(context.execution.current_state).__name__
                    override = self.state_model_overrides.get(state_name)
                    if override is not None:
                        if isinstance(override, str):
                            context.llm = self.llm_strategy.with_model(override)
                        else:
                            # Full strategy object (e.g. with_model(...).with_templates(...))
                            context.llm = override
                    else:
                        context.llm = self.llm_strategy

                    # Retry transient API errors (timeout, rate-limit, server error)
                    # so a single network blip doesn't kill a 19-turn session.
                    import asyncio
                    from openai import APITimeoutError, APIConnectionError, RateLimitError, InternalServerError

                    _max_retries = 3
                    for _attempt in range(1, _max_retries + 1):
                        turn_task = asyncio.create_task(context.execute_turn())
                        try:
                            while not turn_task.done():
                                try:
                                    yield await asyncio.wait_for(
                                        context.event_channel.get(), timeout=0.1
                                    )
                                except asyncio.TimeoutError:
                                    pass
                            turn_result = turn_task.result()
                            break  # success
                        except (APITimeoutError, APIConnectionError, RateLimitError, InternalServerError) as _api_err:
                            if _attempt == _max_retries:
                                raise  # exhausted retries — propagate to outer handler
                            _delay = 2 ** _attempt  # 2s, 4s
                            bound_logger.warning(
                                "Transient API error, retrying",
                                error=str(_api_err),
                                attempt=_attempt,
                                max_retries=_max_retries,
                                retry_delay=_delay,
                            )
                            await asyncio.sleep(_delay)

                    # Drain any sub-agent events queued at the exact moment
                    # the turn completed.
                    while not context.event_channel.empty():
                        yield context.event_channel.get_nowait()

                    # Create TurnCompletedEvent with runtime metadata
                    turn_event = TurnCompletedEvent(
                        turn=context.turn,
                        state=turn_result.state,
                        is_finished=context.is_finished,
                        final_answer=context.final_answer,
                        state_metadata=turn_result.state_metadata,
                        usage=(
                            turn_result.usage.to_dict() if turn_result.usage else None
                        ),
                        reasoning=turn_result.reasoning,
                    )

                    # Per-turn state persistence: kernel checkpoint (on
                    # final turn) + snapshot. Identical helper used by
                    # SubAgentTool._execute_subagent so sub-agent snapshots
                    # and checkpoints are written on the same schedule.
                    await self._save_turn_state(context, bound_logger, turn_event)

                    turn_span.set_attribute("turn.completed", True)
                    turn_span.set_attribute(
                        "turn.final_answer_provided",
                        bool(context.final_answer),
                    )
                    turn_span.set_status("OK")

                # Yield event for streaming
                yield turn_event

                if context.turn >= self.settings.max_turns:
                    bound_logger.warning(
                        "Reached max turns", max_turns=self.settings.max_turns
                    )
                    break

            # HITL PAUSE — emit HITLRequestEvent instead of AgentFinishedEvent
            if context.pending_hitl_signal:
                hitl_data = context.pending_hitl_signal.data
                yield HITLRequestEvent(
                    signal_type=context.pending_hitl_signal.signal_type,
                    question=hitl_data.get("question", ""),
                    options=hitl_data.get("options"),
                    context=hitl_data.get("context", ""),
                    multi_select=hitl_data.get("multi_select", False),
                    turn=context.turn,
                    conversation_id=context.conversation_id,
                )
                bound_logger.info(
                    "Agent paused for HITL input",
                    signal_type=context.pending_hitl_signal.signal_type,
                    turn=context.turn,
                )
                return

            # Log completion with proper FinalAnswerResult handling
            if context.final_answer:
                bound_logger.info(
                    "Agent execution completed",
                    total_turns=context.turn,
                    final_answer_length=len(context.final_answer.answer),
                    has_sources=context.final_answer.sources is not None,
                    has_confidence=context.final_answer.confidence is not None,
                )
            else:
                bound_logger.info(
                    "Agent execution completed",
                    total_turns=context.turn,
                    final_answer=None,
                )

            # Collect per-agent token usage breakdown (with model info)
            sub_agent_usage = {}
            for tool_name, tool in context.sub_agent_tools.items():
                if (
                    hasattr(tool, "_cumulative_usage")
                    and tool._cumulative_usage is not None
                ):
                    usage_dict = tool._cumulative_usage.to_dict()
                    usage_dict["model"] = getattr(
                        tool.agent.llm_strategy, "model", "unknown"
                    )
                    sub_agent_usage[tool.agent.name] = usage_dict

            # Include main agent's model
            main_model = getattr(context.llm, "model", "unknown")

            # Per-model token breakdown for accurate multi-model cost attribution
            usage_by_model = {
                model: usage.to_dict()
                for model, usage in context.usage_by_model.items()
            }

            yield AgentFinishedEvent(
                final_answer=context.final_answer,
                total_turns=context.turn,
                execution_time=time.time() - start_time,
                total_usage={**context.cumulative_usage.to_dict(), "model": main_model},
                sub_agent_usage=sub_agent_usage,
                usage_by_model=usage_by_model,
                exit_method=context.exit_method,
            )

        except Exception as e:
            import traceback

            # Log with full stack trace
            bound_logger.error(
                "Agent execution failed",
                error=str(e),
                exception=type(e).__name__,
                traceback=traceback.format_exc(),
            )

            # Also log the exception for structured logging
            bound_logger.log_exception(e, "agent_execution")
            yield AgentErrorEvent(
                error=str(e),
                turn=context.turn if context else 0,
                exception_type=type(e).__name__,
                traceback=traceback.format_exc() if self.settings.debug_mode else None,
            )
            if self.settings.debug_mode:
                raise

    def get_conversation_history(self) -> List[Any]:
        """Get the current conversation history.

        Note: This method is deprecated as Agent no longer maintains instance state.
        Context is created fresh for each execution.

        Returns:
            Empty list (no persistent context)
        """
        return []

    def get_memory(self) -> List[Dict[str, Any]]:
        """Get the agent's long-term memory.

        Note: This method is deprecated as Agent no longer maintains instance state.
        Context is created fresh for each execution.

        Returns:
            Empty list (no persistent context)
        """
        return []

    def is_running(self) -> bool:
        """Check if the agent is currently running.

        Note: This method is deprecated as Agent no longer tracks running state.
        Each execution creates its own context.

        Returns:
            False (no persistent running state)
        """
        return False

    def get_current_state(self) -> Optional[str]:
        """Get the name of the current agent state.

        Note: This method is deprecated as Agent no longer maintains instance state.
        Context is created fresh for each execution.

        Returns:
            None (no persistent context)
        """
        return None

    def get_turn_count(self) -> int:
        """Get the current turn count.

        Note: This method is deprecated as Agent no longer maintains instance state.
        Context is created fresh for each execution.

        Returns:
            0 (no persistent context)
        """
        return 0
