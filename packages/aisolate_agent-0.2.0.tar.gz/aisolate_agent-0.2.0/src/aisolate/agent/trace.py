"""Conversation trace writers for agent runs.

Provides multiple trace formats for different audiences:

  TraceWriter         – Developer-detail Markdown trace (tool args, outputs, handovers)
  SummaryTraceWriter  – Concise human-readable Markdown (operator / manager overview)
  ConsoleTraceWriter  – Compact, colorized real-time terminal output
  MachineTraceWriter  – Structured JSONL for automated analysis

Usage:
    from aisolate.agent.trace import TraceWriter, SummaryTraceWriter, ConsoleTraceWriter

    traces = [
        TraceWriter(path="/tmp/traces", conversation_id="abc-123"),
        SummaryTraceWriter(path="/tmp/traces", conversation_id="abc-123"),
        ConsoleTraceWriter(conversation_id="abc-123"),
    ]
    async for event in agent.run_streaming(task, conversation_id):
        for t in traces:
            t.record(event)
        yield event
    for t in traces:
        t.close()
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Any, Optional


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate text with ellipsis indicator."""
    if not text or len(text) <= max_len:
        return text or ""
    return text[:max_len] + f"… [{len(text)} chars total]"


def _format_tool_output(output: str, max_len: int = 800) -> str:
    """Format tool output for trace, abbreviating large payloads."""
    if not output:
        return "(empty)"
    try:
        parsed = json.loads(output)
        if isinstance(parsed, dict):
            # Strip base64 images
            for key in ("image_png_base64",):
                if key in parsed and parsed[key] and parsed[key] is not True:
                    parsed[key] = f"<{len(str(parsed[key]))} chars>"
            output = json.dumps(parsed, indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError):
        pass
    return _truncate(output, max_len)


def _extract_handover_info(output: str) -> dict | None:
    """Extract handover metadata from a sub-agent's serialized result.

    The output is the report template wrapper. The actual JSON is embedded
    after the report header line. We try to find and parse it.
    """
    if not output:
        return None
    # The sub-agent report wraps a JSON string from serialize_final_answer.
    # Try to find JSON with a "handover" key.
    try:
        # Direct JSON parse (if output is raw serialized FinalAnswerResult)
        parsed = json.loads(output)
        if isinstance(parsed, dict) and parsed.get("handover"):
            return parsed["handover"]
    except (json.JSONDecodeError, TypeError):
        pass

    # The report template prepends text before the JSON.
    # Try to find JSON substring containing "handover"
    for start_char in ('{',):
        idx = output.find(start_char)
        while idx >= 0:
            # Try progressively longer substrings
            for end_idx in range(len(output), idx, -1):
                candidate = output[idx:end_idx]
                try:
                    parsed = json.loads(candidate)
                    if isinstance(parsed, dict) and parsed.get("handover"):
                        return parsed["handover"]
                except (json.JSONDecodeError, TypeError):
                    continue
                break  # Only try the first valid JSON at this position
            idx = output.find(start_char, idx + 1)

    return None


def _extract_answer_text(output: str) -> str:
    """Extract the answer text from a sub-agent's output for display."""
    if not output:
        return "(empty)"
    try:
        parsed = json.loads(output)
        if isinstance(parsed, dict):
            return parsed.get("answer", output)
    except (json.JSONDecodeError, TypeError):
        pass
    # Report template: "Here is the final answer from your managed agent ...\n{json}"
    # Just return the first part
    return output


class TraceWriter:
    """Writes a clean Markdown trace file for a single agent conversation.

    Captures high-level agent activity without verbose debug noise.
    Each conversation gets one file: ``{conversation_id}.trace.md``.
    """

    def __init__(
        self,
        path: str | Path,
        conversation_id: str,
        agent_name: str = "main_agent",
    ):
        self._dir = Path(path)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file_path = self._dir / f"{conversation_id}.trace.md"
        self._agent_name = agent_name
        self._conversation_id = conversation_id
        self._closed = False

        is_resume = self._file_path.exists() and self._file_path.stat().st_size > 0
        self._fh: IO[str] = open(self._file_path, "a", encoding="utf-8")

        if is_resume:
            self._write(f"\n\n---\n# Resumed: {datetime.now().isoformat()}\n")
        else:
            self._write(f"# Agent Trace: {conversation_id}\n")
            self._write(f"**Agent:** {agent_name}  ")
            self._write(f"**Started:** {datetime.now().isoformat()}\n")

    def record(self, event: Any) -> None:
        """Record a single AgentStreamEvent."""
        if self._closed:
            return

        event_type = getattr(event, "type", None)

        if event_type == "agent_started":
            self._record_started(event)
        elif event_type == "turn_completed":
            self._record_turn(event)
        elif event_type == "agent_finished":
            self._record_finished(event)
        elif event_type == "agent_error":
            self._record_error(event)
        elif event_type == "hitl_request":
            self._record_hitl(event)

    def close(self) -> None:
        """Flush and close the trace file."""
        if not self._closed:
            self._write(f"\n---\n*Trace closed at {datetime.now().isoformat()}*\n")
            self._fh.close()
            self._closed = True

    @property
    def file_path(self) -> Path:
        return self._file_path

    # ── Event handlers ──────────────────────────────────────────────

    def _record_started(self, event: Any) -> None:
        task = _truncate(getattr(event, "task", ""), 2000)
        max_turns = getattr(event, "max_turns", "?")
        self._write(f"\n## Task\n")
        self._write(f"**Max turns:** {max_turns}\n")
        self._write(f"```\n{task}\n```\n")

    def _record_turn(self, event: Any) -> None:
        turn = getattr(event, "turn", "?")
        state = getattr(event, "state", "?")
        usage = getattr(event, "usage", None) or {}
        reasoning = getattr(event, "reasoning", None)
        metadata = getattr(event, "state_metadata", None) or {}

        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)

        # Cumulative token counter for quick cost reference
        self._cumulative_input = getattr(self, "_cumulative_input", 0) + input_tokens
        self._cumulative_output = getattr(self, "_cumulative_output", 0) + output_tokens

        self._write(f"\n### Turn {turn} — {state}")
        self._write(
            f"*Tokens: {input_tokens:,} in / {output_tokens:,} out · cumulative: {self._cumulative_input:,} in / {self._cumulative_output:,} out*\n")

        # Planning state — show the plan text
        if state == "PlanningState":
            if reasoning:
                self._write(f"<details><summary>Plan</summary>\n\n{_truncate(reasoning, 3000)}\n\n</details>\n")
            return

        # Executing state — show tool call
        if metadata.get("type") == "tool_execution":
            tool_name = metadata.get("tool_name", "?")
            success = metadata.get("success", False)
            args = metadata.get("arguments", {})
            output = metadata.get("output", "")
            error = metadata.get("error")
            is_subagent = tool_name.startswith("functions_agents_")

            status = "✅" if success else "❌"

            if is_subagent:
                agent_name = tool_name.replace("functions_agents_", "")
                task_text = _truncate(args.get("task", ""), 1000)
                self._write(f"\n---")
                self._write(f"#### 🤖 Sub-agent: `{agent_name}` ({status})")
                self._write(
                    f"<details><summary>Task delegated to {agent_name}</summary>\n\n```\n{task_text}\n```\n\n</details>\n")

                # Extract handover info from sub-agent result
                handover_info = _extract_handover_info(output)
                if handover_info:
                    # Filter out framework-injected keys to show only variable declarations
                    _meta_keys = {"checkpoint_key", "manifest", "tmp_path"}
                    var_entries = {k: v for k, v in handover_info.items() if k not in _meta_keys}
                    manifest = handover_info.get("manifest", [])
                    type_map = {m["name"]: m.get("type", "?") for m in manifest} if manifest else {}

                    self._write(f"\n**📦 Handover: {len(var_entries)} variables**\n")
                    self._write(f"| Variable | Type | Description |")
                    self._write(f"|----------|------|-------------|")
                    for var_name, var_desc in var_entries.items():
                        vtype = type_map.get(var_name, "?")
                        self._write(f"| `{var_name}` | {vtype} | {var_desc} |")
                    self._write(f"\nCheckpoint: `{handover_info.get('checkpoint_key', 'NOT SET')}`\n")
                    if not manifest:
                        self._write(f"⚠️ Manifest: **EMPTY** (checkpoint may have failed)\n")
                    self._write(f"---\n")
                else:
                    self._write(f"\n**⚠️ No handover declared by sub-agent**\n")

                # Show abbreviated sub-agent answer (not the full report wrapper)
                answer_text = _extract_answer_text(output)
                self._write(
                    f"<details><summary>Sub-agent answer</summary>\n\n{_truncate(answer_text, 2000)}\n\n</details>\n")
            else:
                # Regular tool call
                args_str = _truncate(json.dumps(args, ensure_ascii=False), 500)
                self._write(f"**{status} `{tool_name}`** — `{args_str}`\n")

                # Highlight load_handover_data calls
                if "load_handover_data" in str(args.get("code", "")):
                    self._write(f"\n**🔗 load_handover_data call detected**\n")

                if error:
                    self._write(f"> ❌ Error: {_truncate(error, 500)}\n")
                elif output:
                    self._write(
                        f"<details><summary>Output</summary>\n\n```\n{_format_tool_output(output)}\n```\n\n</details>\n")

        # Check for final answer on this turn
        final = getattr(event, "final_answer", None)
        if final and getattr(event, "is_finished", False):
            answer_text = getattr(final, "answer", "") if hasattr(final, "answer") else str(final)
            self._write(f"\n## Final Answer\n")
            self._write(f"```\n{_truncate(answer_text, 5000)}\n```\n")
            handover = getattr(final, "handover", None)
            if handover:
                self._write(f"\n**Handover:** {json.dumps(handover, ensure_ascii=False)}\n")

    def _record_finished(self, event: Any) -> None:
        total_turns = getattr(event, "total_turns", "?")
        exec_time = getattr(event, "execution_time", None)
        total_usage = getattr(event, "total_usage", None) or {}
        sub_usage = getattr(event, "sub_agent_usage", None) or {}

        total_in = total_usage.get('input_tokens', 0)
        total_out = total_usage.get('output_tokens', 0)

        self._write(f"\n---\n## Summary\n")
        self._write(f"| Metric | Value |")
        self._write(f"|--------|-------|")
        self._write(f"| Turns | {total_turns} |")
        if exec_time:
            self._write(f"| Time | {exec_time:.1f}s |")
        self._write(f"| Input tokens | {total_in:,} |")
        self._write(f"| Output tokens | {total_out:,} |")
        if sub_usage:
            sub_in = sub_usage.get('input_tokens', 0)
            sub_out = sub_usage.get('output_tokens', 0)
            self._write(f"| Sub-agent input | {sub_in:,} ({sub_in*100//max(total_in, 1)}%) |")
            self._write(f"| Sub-agent output | {sub_out:,} |")

    def _record_error(self, event: Any) -> None:
        error = getattr(event, "error", "Unknown error")
        turn = getattr(event, "turn", "?")
        self._write(f"\n### ❌ Error at turn {turn}\n")
        self._write(f"```\n{_truncate(error, 1000)}\n```\n")

    def _record_hitl(self, event: Any) -> None:
        question = getattr(event, "question", "")
        options = getattr(event, "options", None)
        self._write(f"\n### ⏸️ HITL Pause\n")
        self._write(f"**Question:** {question}\n")
        if options:
            self._write(f"**Options:** {options}\n")

    # ── Helpers ──────────────────────────────────────────────────────

    def _write(self, text: str) -> None:
        self._fh.write(text + "\n")
        self._fh.flush()

    def __del__(self) -> None:
        if not self._closed:
            try:
                self.close()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════
# Machine-readable JSONL trace — one JSON object per line
# ═══════════════════════════════════════════════════════════════════


class MachineTraceWriter:
    """Writes a structured JSONL trace file for automated debugging.

    Each line is a self-contained JSON object with:
      ts        – ISO-8601 timestamp (UTC)
      elapsed_s – seconds since trace start (monotonic)
      event     – event type tag
      agent     – agent name
      turn      – turn number
      ...       – event-specific fields

    File: ``{conversation_id}.trace.jsonl``
    """

    def __init__(
        self,
        path: str | Path,
        conversation_id: str,
        agent_name: str = "main_agent",
    ):
        self._dir = Path(path)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file_path = self._dir / f"{conversation_id}.trace.jsonl"
        self._fh: IO[str] = open(self._file_path, "a", encoding="utf-8")
        self._agent_name = agent_name
        self._conversation_id = conversation_id
        self._t0 = time.monotonic()
        self._closed = False

    # ── Public API ──────────────────────────────────────────────────

    def record(self, event: Any) -> None:
        """Record a single AgentStreamEvent as one JSONL line."""
        if self._closed:
            return

        event_type = getattr(event, "type", None)
        handler = {
            "agent_started": self._on_started,
            "turn_completed": self._on_turn,
            "agent_finished": self._on_finished,
            "agent_error": self._on_error,
            "hitl_request": self._on_hitl,
        }.get(event_type)

        if handler:
            handler(event)

    def close(self) -> None:
        if not self._closed:
            self._emit("trace_closed", {})
            self._fh.close()
            self._closed = True

    @property
    def file_path(self) -> Path:
        return self._file_path

    def __del__(self) -> None:
        if not self._closed:
            try:
                self.close()
            except Exception:
                pass

    # ── Event handlers ──────────────────────────────────────────────

    def _on_started(self, event: Any) -> None:
        self._emit("agent_started", {
            "max_turns": getattr(event, "max_turns", None),
            "task_length": len(getattr(event, "task", "")),
            "conversation_id": getattr(event, "conversation_id", None),
        })

    def _on_turn(self, event: Any) -> None:
        turn = getattr(event, "turn", 0)
        state = getattr(event, "state", "")
        usage = getattr(event, "usage", None) or {}
        metadata = getattr(event, "state_metadata", None) or {}
        is_finished = getattr(event, "is_finished", False)

        row: dict[str, Any] = {
            "turn": turn,
            "state": state,
            "finished": is_finished,
            "input_tokens": usage.get("input_tokens", 0),
            "output_tokens": usage.get("output_tokens", 0),
        }

        # Capture plan text for PlanningState (critical for debugging report quality)
        reasoning = getattr(event, "reasoning", None)
        if state == "PlanningState" and reasoning:
            row["plan"] = reasoning[:5000]

        # Tool execution details (most valuable for debugging)
        if metadata.get("type") == "tool_execution":
            tool_name = metadata.get("tool_name", "")
            is_subagent = tool_name.startswith("functions_agents_")
            args = metadata.get("arguments", {})
            output = metadata.get("output", "")
            error = metadata.get("error")

            row["tool"] = tool_name
            row["tool_success"] = metadata.get("success", False)
            row["tool_error"] = error
            row["output_length"] = len(output) if output else 0

            if is_subagent:
                row["subagent"] = tool_name.replace("functions_agents_", "")
                row["subagent_task_length"] = len(args.get("task", ""))
                # Extract handover variable names (not content)
                handover = _extract_handover_info(output)
                if handover:
                    _meta = {"checkpoint_key", "manifest", "tmp_path"}
                    row["handover_vars"] = [k for k in handover if k not in _meta]
                    row["handover_checkpoint"] = handover.get("checkpoint_key")
                    row["handover_manifest_count"] = len(handover.get("manifest", []))
                else:
                    row["handover_vars"] = None
            else:
                # For code_interpreter: include first line of code and error
                code = args.get("code", "")
                if code:
                    row["code_first_line"] = code.split("\n")[0][:120]
                    row["code_length"] = len(code)
                # Parse output JSON for ok/error status
                if output:
                    try:
                        parsed = json.loads(output)
                        if isinstance(parsed, dict):
                            row["exec_ok"] = parsed.get("ok")
                            err = parsed.get("error")
                            if err and isinstance(err, dict):
                                row["exec_error_type"] = err.get("name")
                                row["exec_error_msg"] = (err.get("value") or "")[:200]
                    except (json.JSONDecodeError, TypeError):
                        pass

        # Final answer on this turn
        final = getattr(event, "final_answer", None)
        if final and is_finished:
            row["final_answer_length"] = len(getattr(final, "answer", "") or "")
            handover = getattr(final, "handover", None)
            if handover:
                _meta = {"checkpoint_key", "manifest", "tmp_path"}
                row["final_handover_vars"] = [k for k in handover if k not in _meta]

        self._emit("turn", row)

    def _on_finished(self, event: Any) -> None:
        total_usage = getattr(event, "total_usage", None) or {}
        sub_usage = getattr(event, "sub_agent_usage", None) or {}
        self._emit("agent_finished", {
            "total_turns": getattr(event, "total_turns", 0),
            "execution_time": getattr(event, "execution_time", None),
            "total_input_tokens": total_usage.get("input_tokens", 0),
            "total_output_tokens": total_usage.get("output_tokens", 0),
            "sub_agent_usage": sub_usage,
            "has_final_answer": getattr(event, "final_answer", None) is not None,
            "exit_method": getattr(event, "exit_method", None),
        })

    def _on_error(self, event: Any) -> None:
        self._emit("agent_error", {
            "turn": getattr(event, "turn", 0),
            "error": getattr(event, "error", ""),
            "exception_type": getattr(event, "exception_type", None),
            "traceback": getattr(event, "traceback", None),
        })

    def _on_hitl(self, event: Any) -> None:
        self._emit("hitl_request", {
            "turn": getattr(event, "turn", 0),
            "signal_type": getattr(event, "signal_type", ""),
            "question_length": len(getattr(event, "question", "")),
            "options": getattr(event, "options", None),
        })

    # ── Internal ────────────────────────────────────────────────────

    def _emit(self, event: str, data: dict[str, Any]) -> None:
        row = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "elapsed_s": round(time.monotonic() - self._t0, 3),
            "event": event,
            "agent": self._agent_name,
            **data,
        }
        self._fh.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
        self._fh.flush()


# ═══════════════════════════════════════════════════════════════════
# Human-friendly summary trace — concise overview for operators
# ═══════════════════════════════════════════════════════════════════


class SummaryTraceWriter:
    """Writes a concise, executive-style Markdown summary of an agent run.

    Designed for operators and managers who want to understand *what happened*
    without tool arguments, raw output, or internal framework details.

    File: ``{conversation_id}.summary.md``

    Compared to ``TraceWriter``:
      - No raw tool arguments or outputs
      - No token counts per turn (only totals in summary)
      - Sub-agent delegations shown as one-line entries
      - Timeline format: elapsed seconds for each action
      - Final answer shown in full
    """

    def __init__(
        self,
        path: str | Path,
        conversation_id: str,
        agent_name: str = "main_agent",
    ):
        self._dir = Path(path)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file_path = self._dir / f"{conversation_id}.summary.md"
        self._agent_name = agent_name
        self._conversation_id = conversation_id
        self._closed = False
        self._t0 = time.monotonic()
        self._steps: list[str] = []
        self._errors: list[str] = []
        self._task = ""
        self._max_turns = 0

        is_resume = self._file_path.exists() and self._file_path.stat().st_size > 0
        self._fh: IO[str] = open(self._file_path, "a", encoding="utf-8")

        if is_resume:
            self._write(f"\n---\n## Resumed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    def record(self, event: Any) -> None:
        if self._closed:
            return
        event_type = getattr(event, "type", None)
        handlers = {
            "agent_started": self._on_started,
            "turn_completed": self._on_turn,
            "agent_finished": self._on_finished,
            "agent_error": self._on_error,
            "hitl_request": self._on_hitl,
        }
        handler = handlers.get(event_type)
        if handler:
            handler(event)

    def close(self) -> None:
        if not self._closed:
            self._fh.close()
            self._closed = True

    @property
    def file_path(self) -> Path:
        return self._file_path

    def __del__(self) -> None:
        if not self._closed:
            try:
                self.close()
            except Exception:
                pass

    # ── Event handlers ──────────────────────────────────────────────

    def _on_started(self, event: Any) -> None:
        self._task = getattr(event, "task", "")
        self._max_turns = getattr(event, "max_turns", 0)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._write(f"# Agent Run Summary")
        self._write(f"")
        self._write(f"**Conversation:** `{self._conversation_id}`  ")
        self._write(f"**Started:** {now}  ")
        self._write(f"**Agent:** {self._agent_name}  ")
        self._write(f"")
        self._write(f"## Task")
        self._write(f"")
        # Show first 500 chars of task, clean
        task_preview = self._task.split("---")[0].strip()
        self._write(f"> {_truncate(task_preview, 500)}")
        self._write(f"")
        self._write(f"## Steps")
        self._write(f"")

    def _on_turn(self, event: Any) -> None:
        turn = getattr(event, "turn", 0)
        state = getattr(event, "state", "?")
        metadata = getattr(event, "state_metadata", None) or {}
        elapsed = time.monotonic() - self._t0

        # Simplify state name for humans
        state_label = state.replace("State", "")

        if metadata.get("type") == "tool_execution":
            tool_name = metadata.get("tool_name", "?")
            success = metadata.get("success", False)
            is_subagent = tool_name.startswith("functions_agents_")
            icon = "✓" if success else "✗"

            if is_subagent:
                agent_label = tool_name.replace("functions_agents_", "")
                args = metadata.get("arguments", {})
                task_preview = _truncate(args.get("task", ""), 120)
                self._write(f"{turn}. `+{elapsed:5.1f}s` {icon} **Delegated → {agent_label}** — {task_preview}")
            else:
                # Friendly tool label
                display_name = tool_name.replace("_", " ").title()
                self._write(f"{turn}. `+{elapsed:5.1f}s` {icon} {display_name}")
        elif state_label == "Planning":
            self._write(f"{turn}. `+{elapsed:5.1f}s` 📋 Planning")
        elif state_label == "Clarification":
            self._write(f"{turn}. `+{elapsed:5.1f}s` 💬 Clarification")
        elif state_label == "HITLWait":
            pass  # Handled by _on_hitl
        else:
            self._write(f"{turn}. `+{elapsed:5.1f}s` {state_label}")

        # Final answer
        final = getattr(event, "final_answer", None)
        if final and getattr(event, "is_finished", False):
            answer_text = getattr(final, "answer", "") if hasattr(final, "answer") else str(final)
            self._write(f"")
            self._write(f"## Result")
            self._write(f"")
            self._write(f"{_truncate(answer_text, 5000)}")
            self._write(f"")

    def _on_finished(self, event: Any) -> None:
        total_turns = getattr(event, "total_turns", 0)
        exec_time = getattr(event, "execution_time", None)
        total_usage = getattr(event, "total_usage", None) or {}
        exit_method = getattr(event, "exit_method", None)

        total_in = total_usage.get("input_tokens", 0)
        total_out = total_usage.get("output_tokens", 0)

        self._write(f"")
        self._write(f"---")
        exit_label = f" via `{exit_method}`" if exit_method else ""
        self._write(f"**Completed{exit_label}** in {total_turns} steps")
        parts = []
        if exec_time:
            parts.append(f"{exec_time:.1f}s")
        if total_in or total_out:
            parts.append(f"{total_in + total_out:,} tokens")
        if parts:
            self._write(f"({', '.join(parts)})")

    def _on_error(self, event: Any) -> None:
        error = getattr(event, "error", "Unknown error")
        turn = getattr(event, "turn", "?")
        self._write(f"")
        self._write(f"**⚠ Error at step {turn}:** {_truncate(error, 300)}")

    def _on_hitl(self, event: Any) -> None:
        question = getattr(event, "question", "")
        elapsed = time.monotonic() - self._t0
        # Show as a single concise line
        first_line = question.split("\n")[0][:200]
        self._write(f"⏸ `+{elapsed:5.1f}s` **Waiting for user input** — {first_line}")

    def _write(self, text: str) -> None:
        self._fh.write(text + "\n")
        self._fh.flush()


# ═══════════════════════════════════════════════════════════════════
# Compact console trace — clean real-time terminal output
# ═══════════════════════════════════════════════════════════════════


# ANSI color helpers (no dependency on Rich for the trace writer)
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_CYAN = "\033[36m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_RED = "\033[31m"
_MAGENTA = "\033[35m"
_BLUE = "\033[34m"


class ConsoleTraceWriter:
    """Writes a compact, colorized trace to stderr for real-time monitoring.

    Designed to replace the verbose Rich panels and interleaved structlog
    output during agent execution. Each event is a single line (or a short
    block for errors / final answers).

    Output format per line::

        [+  0.0s] 1/60  Clarification          💬 Checking user intent
        [+  5.5s] 2/60  Planning               📋 Created 4-step plan
        [+  6.2s] 3/60  Executing              ✓ query_meter_info (0.4s)
        [+ 12.1s] 4/60  Executing              → data_agent delegation (5.9s)
        [+ 12.3s] 5/60  Executing              ✓ code_interpreter (0.2s)
        [+ 13.0s] 6/60  Finished               ✓ Final answer (847 chars)

    No file is created — output goes to stderr.
    """

    def __init__(
        self,
        conversation_id: str,
        agent_name: str = "main_agent",
        file: IO[str] | None = None,
        color: bool = True,
    ):
        self._conversation_id = conversation_id
        self._agent_name = agent_name
        self._out = file or sys.stderr
        self._color = color and hasattr(self._out, "isatty") and self._out.isatty()
        self._t0 = time.monotonic()
        self._max_turns = 0
        self._closed = False

    def record(self, event: Any) -> None:
        if self._closed:
            return
        event_type = getattr(event, "type", None)
        handlers = {
            "agent_started": self._on_started,
            "turn_completed": self._on_turn,
            "agent_finished": self._on_finished,
            "agent_error": self._on_error,
            "hitl_request": self._on_hitl,
        }
        handler = handlers.get(event_type)
        if handler:
            handler(event)

    def close(self) -> None:
        self._closed = True

    @property
    def file_path(self) -> None:
        return None  # No file created

    # ── Formatting ──────────────────────────────────────────────────

    def _c(self, code: str, text: str) -> str:
        if not self._color:
            return text
        return f"{code}{text}{_RESET}"

    def _elapsed(self) -> str:
        secs = time.monotonic() - self._t0
        return self._c(_DIM, f"[+{secs:6.1f}s]")

    def _step(self, turn: int) -> str:
        return self._c(_CYAN, f"{turn:>2}/{self._max_turns:<2}")

    def _emit(self, line: str) -> None:
        self._out.write(line + "\n")
        self._out.flush()

    # ── Event handlers ──────────────────────────────────────────────

    def _on_started(self, event: Any) -> None:
        self._max_turns = getattr(event, "max_turns", 0)
        task = getattr(event, "task", "")
        task_preview = task.split("---")[0].strip().replace("\n", " ")[:100]
        self._emit("")
        self._emit(
            f"{self._elapsed()} {self._c(_BOLD, 'Agent started')} "
            f"{self._c(_DIM, f'({self._agent_name})')}"
        )
        self._emit(f"           {self._c(_DIM, f'Task: {task_preview}')}")

    def _on_turn(self, event: Any) -> None:
        turn = getattr(event, "turn", 0)
        state = getattr(event, "state", "?")
        metadata = getattr(event, "state_metadata", None) or {}
        usage = getattr(event, "usage", None) or {}
        state_label = state.replace("State", "")

        step = self._step(turn)

        if metadata.get("type") == "tool_execution":
            tool_name = metadata.get("tool_name", "?")
            success = metadata.get("success", False)
            is_subagent = tool_name.startswith("functions_agents_")

            if is_subagent:
                agent_label = tool_name.replace("functions_agents_", "")
                icon = self._c(_GREEN, "→") if success else self._c(_RED, "✗")
                self._emit(
                    f"{self._elapsed()} {step}  {self._c(_BOLD, 'Executing'):<22} "
                    f"{icon} {self._c(_MAGENTA, agent_label)} delegation"
                )
            else:
                icon = self._c(_GREEN, "✓") if success else self._c(_RED, "✗")
                error = metadata.get("error")
                suffix = ""
                if error:
                    suffix = f" — {self._c(_RED, _truncate(error, 80))}"
                self._emit(
                    f"{self._elapsed()} {step}  {self._c(_BOLD, 'Executing'):<22} "
                    f"{icon} {tool_name}{suffix}"
                )
        elif state_label == "Planning":
            reasoning = getattr(event, "reasoning", "")
            note = ""
            if reasoning:
                # Count plan steps heuristically
                step_count = reasoning.count("\n- ") + reasoning.count("\n1.")
                if step_count:
                    note = f" ({step_count} steps)"
            self._emit(
                f"{self._elapsed()} {step}  {self._c(_BOLD, 'Planning'):<22} "
                f"{self._c(_BLUE, '📋')}{note}"
            )
        elif state_label == "Clarification":
            self._emit(
                f"{self._elapsed()} {step}  {self._c(_BOLD, 'Clarification'):<22} "
                f"{self._c(_YELLOW, '💬')} Checking user intent"
            )
        elif state_label == "HITLWait":
            pass  # Handled by _on_hitl
        else:
            self._emit(f"{self._elapsed()} {step}  {self._c(_BOLD, state_label)}")

        # Final answer on this turn
        final = getattr(event, "final_answer", None)
        if final and getattr(event, "is_finished", False):
            answer = getattr(final, "answer", "") if hasattr(final, "answer") else str(final)
            self._emit(
                f"{self._elapsed()} {step}  {self._c(_GREEN + _BOLD, 'Done'):<22} "
                f"✓ Final answer ({len(answer):,} chars)"
            )

    def _on_finished(self, event: Any) -> None:
        total_turns = getattr(event, "total_turns", 0)
        exec_time = getattr(event, "execution_time", None)
        total_usage = getattr(event, "total_usage", None) or {}
        exit_method = getattr(event, "exit_method", None)

        total_tokens = total_usage.get("input_tokens", 0) + total_usage.get("output_tokens", 0)
        parts = [f"{total_turns} steps"]
        if exec_time:
            parts.append(f"{exec_time:.1f}s")
        if total_tokens:
            parts.append(f"{total_tokens:,} tokens")
        if exit_method:
            parts.append(f"exit={exit_method}")

        self._emit(
            f"{self._elapsed()} {self._c(_GREEN + _BOLD, '── Completed')} "
            f"{self._c(_DIM, '(' + ', '.join(parts) + ')')}"
        )
        self._emit("")

    def _on_error(self, event: Any) -> None:
        error = getattr(event, "error", "Unknown error")
        turn = getattr(event, "turn", "?")
        self._emit(
            f"{self._elapsed()} {self._c(_RED + _BOLD, '── ERROR')} "
            f"at step {turn}: {_truncate(error, 200)}"
        )

    def _on_hitl(self, event: Any) -> None:
        question = getattr(event, "question", "")
        first_line = question.split("\n")[0][:120]
        self._emit(
            f"{self._elapsed()} {self._c(_YELLOW + _BOLD, '⏸  Waiting for user')} "
            f"— {first_line}"
        )
