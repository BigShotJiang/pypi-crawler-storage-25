﻿from setuptools import setup, find_packages
import os

# Wczytaj zawartość README.md
readme_path = os.path.join(os.path.dirname(__file__), "telegram_async", "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = ""

setup(
    name="telegram-async",
    version='3.11.2',
    author="Denys",
    author_email="ostrovskyidenys30@gmail.com",
    description="Nowoczesna biblioteka asynchroniczna do Telegram Bot API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Denba236/telegram-async",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications :: Chat",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.7",
    install_requires=[
        "aiohttp>=3.8.0",
    ],
    extras_require={
        "redis": ["redis>=4.5.0"],
        "files": ["aiofiles>=22.1.0"],
        "rich": ["rich>=12.0.0"],
        "cron": ["croniter>=1.3.0"],
        "ssl": ["cryptography>=36.0.0"],
        "all": [
            "redis>=4.5.0",
            "aiofiles>=22.1.0",
            "rich>=12.0.0",
            "croniter>=1.3.0",
            "cryptography>=36.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "telegram-async=telegram_async.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)