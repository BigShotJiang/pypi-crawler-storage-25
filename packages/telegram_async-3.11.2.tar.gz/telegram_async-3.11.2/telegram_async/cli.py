"""
CLI tool for telegram_async - Scaffolding, utilities, and project management
"""
import os
import sys
import json
import shutil
import secrets
import argparse
from pathlib import Path
from typing import Optional, Dict, Any


# ============================================================================
# CLI Commands
# ============================================================================

class CLI:
    """CLI application."""

    def __init__(self):
        self.parser = self._build_parser()

    def _build_parser(self) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            prog="telegram-async",
            description="telegram_async CLI - Scaffold projects and utilities"
        )
        subparsers = parser.add_subparsers(dest="command", help="Available commands")

        # ---- init ----
        p_init = subparsers.add_parser("init", help="Scaffold a new bot project")
        p_init.add_argument("name", help="Project name")
        p_init.add_argument("path", nargs="?", default=None, help="Target directory (default: current)")
        p_init.add_argument("-t", "--template", choices=["minimal", "standard", "advanced"], default="standard",
                            help="Project template (default: standard)")
        p_init.add_argument("--no-gitignore", action="store_true", help="Skip .gitignore generation")

        # ---- add-handler ----
        p_handler = subparsers.add_parser("add-handler", help="Add a new handler file")
        p_handler.add_argument("name", help="Handler name (e.g. admin, settings)")
        p_handler.add_argument("project", nargs="?", default=".", help="Project root")
        p_handler.add_argument("--with-keyboard", action="store_true", help="Also generate a keyboard builder")

        # ---- add-middleware ----
        p_mw = subparsers.add_parser("add-middleware", help="Add a new middleware file")
        p_mw.add_argument("name", help="Middleware name (e.g. throttling, auth)")
        p_mw.add_argument("project", nargs="?", default=".", help="Project root")

        # ---- generate-token ----
        p_token = subparsers.add_parser("generate-token", help="Generate a secure webhook secret token")
        p_token.add_argument("-l", "--length", type=int, default=32, help="Token length (default: 32)")

        # ---- generate-env ----
        p_env = subparsers.add_parser("generate-env", help="Generate .env from .env.example or template")
        p_env.add_argument("project", nargs="?", default=".", help="Project root")
        p_env.add_argument("--token", help="Set BOT_TOKEN directly")

        # ---- list-templates ----
        subparsers.add_parser("list-templates", help="List available project templates")

        # ---- run ----
        p_run = subparsers.add_parser("run", help="Run the bot with polling or webhook mode")
        p_run.add_argument("mode", nargs="?", choices=["polling", "webhook"], default="polling",
                           help="Run mode (default: polling)")
        p_run.add_argument("--host", default="0.0.0.0", help="Webhook host (default: 0.0.0.0)")
        p_run.add_argument("--port", type=int, default=8080, help="Webhook port (default: 8080)")
        p_run.add_argument("--path", default="/webhook", help="Webhook path (default: /webhook)")
        p_run.add_argument("--url", help="Webhook URL (auto-generated if not provided)")
        p_run.add_argument("--cert", help="Path to SSL certificate")
        p_run.add_argument("--key", help="Path to SSL private key")
        p_run.add_argument("--skip-update", action="store_true", help="Skip pending updates on startup")
        p_run.add_argument("-t", "--target", default="bot:main", help="Module:callable target (default: bot:main)")

        # ---- deploy ----
        p_deploy = subparsers.add_parser("deploy", help="Generate deployment configurations")
        p_deploy.add_argument("type", nargs="?", choices=["docker", "systemd", "railway", "render"], default="docker",
                              help="Deployment type (default: docker)")
        p_deploy.add_argument("--project", default=".", help="Project root")
        p_deploy.add_argument("--name", help="Project name (default: directory name)")
        p_deploy.add_argument("--port", type=int, default=8080, help="Port for webhook mode")

        # ---- add-filter ----
        p_filter = subparsers.add_parser("add-filter", help="Add a new custom filter file")
        p_filter.add_argument("name", help="Filter name (e.g. is_admin, has_text)")
        p_filter.add_argument("project", nargs="?", default=".", help="Project root")
        p_filter.add_argument("--base", choices=["BaseFilter", "TextFilter", "CommandFilter"], default="BaseFilter",
                              help="Filter base class")

        # ---- add-state ----
        p_state = subparsers.add_parser("add-state", help="Add a new FSM state handler")
        p_state.add_argument("name", help="State name (e.g. registration, feedback)")
        p_state.add_argument("project", nargs="?", default=".", help="Project root")
        p_state.add_argument("--steps", type=int, default=2, help="Number of conversation steps")
        p_state.add_argument("--with-cancel", action="store_true", default=True, help="Add cancel state")

        return parser

    def run(self, args=None):
        parsed = self.parser.parse_args(args)
        if not parsed.command:
            self.parser.print_help()
            sys.exit(1)

        commands = {
            "init": self._cmd_init,
            "add-handler": self._cmd_add_handler,
            "add-middleware": self._cmd_add_middleware,
            "generate-token": self._cmd_generate_token,
            "generate-env": self._cmd_generate_env,
            "list-templates": self._cmd_list_templates,
            "run": self._cmd_run,
            "deploy": self._cmd_deploy,
            "add-filter": self._cmd_add_filter,
            "add-state": self._cmd_add_state,
        }

        handler = commands.get(parsed.command)
        if handler:
            success = handler(parsed)
            sys.exit(0 if success else 1)
        else:
            print(f"Unknown command: {parsed.command}")
            sys.exit(1)

    # ===================== init =====================
    def _cmd_init(self, args) -> bool:
        template_name = args.template
        base_path = Path(args.path) if args.path else Path.cwd()
        project_path = base_path / args.name

        if project_path.exists():
            print(f"Directory already exists: {project_path}")
            return False

        print(f"Creating project '{args.name}' with template '{template_name}'...")

        # Define template structures
        templates = {
            "minimal": {
                "dirs": [],
                "files": {
                    "__init__.py": f"# {args.name}\n",
                    "bot.py": self._minimal_bot_py(),
                    "config.py": self._config_py(),
                    "requirements.txt": "telegram-async>=3.2\naiohttp>=3.8.0\npython-dotenv>=0.19.0\n",
                    ".env.example": "BOT_TOKEN=your_token_here\n",
                    ".gitignore": "__pycache__/\n*.pyc\n.env\nvenv/\n.venv/\n",
                    "README.md": self._readme_md(args.name),
                }
            },
            "standard": {
                "dirs": ["handlers", "middlewares", "keyboards"],
                "files": {
                    "__init__.py": f"# {args.name}\n",
                    "bot.py": self._standard_bot_py(),
                    "config.py": self._config_py(),
                    "requirements.txt": "telegram-async>=3.2\naiohttp>=3.8.0\npython-dotenv>=0.19.0\n",
                    ".env.example": "BOT_TOKEN=your_token_here\nLOG_LEVEL=INFO\n",
                    ".gitignore": "__pycache__/\n*.pyc\n.env\nvenv/\n.venv/\n",
                    "README.md": self._readme_md(args.name),
                    "handlers/__init__.py": "from . import start\n\n__all__ = [\"start\"]\n",
                    "handlers/start.py": self._start_handler_py(),
                    "middlewares/__init__.py": "",
                    "keyboards/__init__.py": "from .main import MainKeyboard\n\n__all__ = [\"MainKeyboard\"]\n",
                    "keyboards/main.py": self._main_keyboard_py(),
                    "run.py": self._run_py(),
                }
            },
            "advanced": {
                "dirs": ["handlers", "middlewares", "keyboards", "locales", "tests", "services"],
                "files": {
                    "__init__.py": f"# {args.name}\n",
                    "bot.py": self._advanced_bot_py(),
                    "config.py": self._config_py(),
                    "requirements.txt": "telegram-async>=3.2\naiohttp>=3.8.0\npython-dotenv>=0.19.0\nredis>=4.0.0\npytest>=7.0.0\npytest-asyncio>=0.21.0\n",
                    ".env.example": "BOT_TOKEN=your_token_here\nLOG_LEVEL=INFO\nREDIS_URL=redis://localhost:6379\nDEFAULT_LOCALE=en\n",
                    ".gitignore": "__pycache__/\n*.pyc\n.env\nvenv/\n.venv/\n.pytest_cache/\n",
                    "README.md": self._readme_md(args.name),
                    "handlers/__init__.py": "from . import start\nfrom . import admin\n\n__all__ = [\"start\", \"admin\"]\n",
                    "handlers/start.py": self._start_handler_py(),
                    "handlers/admin.py": self._admin_handler_py(),
                    "middlewares/__init__.py": "from .logging import LoggingMiddleware\n\n__all__ = [\"LoggingMiddleware\"]\n",
                    "middlewares/logging.py": self._logging_middleware_py(),
                    "keyboards/__init__.py": "from .main import MainKeyboard\n\n__all__ = [\"MainKeyboard\"]\n",
                    "keyboards/main.py": self._main_keyboard_py(),
                    "locales/en.json": '{\n  "greeting": "Hello, $name!",\n  "help_text": "Available commands: /start, /help, /settings"\n}\n',
                    "locales/pl.json": '{\n  "greeting": "Cześć, $name!",\n  "help_text": "Dostępne komendy: /start, /help, /settings"\n}\n',
                    "tests/__init__.py": "",
                    "tests/test_start.py": self._test_start_py(),
                    "services/__init__.py": "",
                    "run.py": self._run_py(),
                    "pytest.ini": "[pytest]\nasyncio_mode = auto\n",
                }
            }
        }

        template = templates.get(template_name)
        if not template:
            print(f"Unknown template: {template_name}")
            return False

        # Create directories
        dirs_to_create = [project_path]
        for d in template.get("dirs", []):
            dirs_to_create.append(project_path / d)

        for dir_path in dirs_to_create:
            dir_path.mkdir(parents=True, exist_ok=True)
            print(f"  Created: {dir_path.relative_to(base_path)}")

        # Create files
        for rel_path, content in template.get("files", {}).items():
            if args.no_gitignore and rel_path == ".gitignore":
                continue

            file_path = project_path / rel_path
            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"  Created: {file_path.relative_to(base_path)}")

        has_run = "run.py" in template.get("files", {})
        print(f"\nProject '{args.name}' created successfully!")
        print(f"\nNext steps:")
        print(f"  cd {args.name}")
        print(f"  pip install -r requirements.txt")
        print(f"  cp .env.example .env  # and set BOT_TOKEN")
        print(f"  python run.py" if has_run else f"  python bot.py")
        return True

    # ===================== add-handler =====================
    def _cmd_add_handler(self, args) -> bool:
        project = Path(args.project)
        handlers_dir = project / "handlers"

        if not handlers_dir.exists():
            handlers_dir.mkdir(parents=True, exist_ok=True)
            init_file = handlers_dir / "__init__.py"
            init_file.write_text(f"from . import {args.name}\n\n__all__ = [\"{args.name}\"]\n")
            print(f"  Created handlers/ directory")

        handler_file = handlers_dir / f"{args.name}.py"
        if handler_file.exists():
            print(f"Handler already exists: {handler_file}")
            return False

        class_name = args.name.capitalize().replace("_", "")
        content = f'''"""
{args.name} handler
"""
from telegram_async.dispatcher import Router
from telegram_async.dispatcher.context import Context

router = Router("{args.name}")

@router.command("{args.name}")
async def cmd_{args.name}(ctx: Context):
    """Handle /{args.name} command"""
    await ctx.reply("{args.name} handler")
'''
        handler_file.write_text(content, encoding='utf-8')
        print(f"  Created handlers/{args.name}.py")

        # Update __init__.py if it exists
        init_file = handlers_dir / "__init__.py"
        if init_file.exists():
            text = init_file.read_text(encoding='utf-8')
            if f"import {args.name}" not in text:
                lines = text.split('\n')
                last_import_idx = 0
                for i, line in enumerate(lines):
                    if line.startswith("from . import") or line.startswith("import "):
                        last_import_idx = i
                lines.insert(last_import_idx + 1, f"from . import {args.name}")

                if "__all__" in text:
                    text = text.replace("__all__ = [", f"__all__ = [\"{args.name}\", ")
                    text = text.replace("__all__=[", f"__all__=[\"{args.name}\", ")
                    lines = text.split('\n')
                else:
                    lines.append(f"")
                    lines.append(f"__all__ = [\"{args.name}\"]")

                init_file.write_text('\n'.join(lines), encoding='utf-8')
                print(f"  Updated handlers/__init__.py")

        # Generate keyboard if requested
        if args.with_keyboard:
            keyboards_dir = project / "keyboards"
            keyboards_dir.mkdir(parents=True, exist_ok=True)
            kb_file = keyboards_dir / f"{args.name}.py"
            if not kb_file.exists():
                kb_content = f'''"""
{args.name} keyboard
"""
from telegram_async.keyboards import InlineKeyboardMarkup, InlineKeyboardButton

class {class_name}Keyboard:
    @staticmethod
    def menu() -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardMarkup()
        keyboard.row(
            InlineKeyboardButton("Option 1", callback_data="{args.name}_opt1"),
            InlineKeyboardButton("Option 2", callback_data="{args.name}_opt2")
        )
        return keyboard
'''
                kb_file.write_text(kb_content, encoding='utf-8')
                print(f"  Created keyboards/{args.name}.py")

        return True

    # ===================== add-middleware =====================
    def _cmd_add_middleware(self, args) -> bool:
        project = Path(args.project)
        mw_dir = project / "middlewares"

        if not mw_dir.exists():
            mw_dir.mkdir(parents=True, exist_ok=True)
            class_name = args.name.capitalize().replace("_", "")
            init_file = mw_dir / "__init__.py"
            init_file.write_text(f"from .{args.name} import {class_name}Middleware\n\n__all__ = [\"{class_name}Middleware\"]\n")
            print(f"  Created middlewares/ directory")

        mw_file = mw_dir / f"{args.name}.py"
        if mw_file.exists():
            print(f"Middleware already exists: {mw_file}")
            return False

        class_name = args.name.capitalize().replace("_", "")
        content = f'''"""
{args.name} middleware
"""
import logging
import time

logger = logging.getLogger(__name__)


class {class_name}Middleware:
    """{class_name} middleware"""

    async def __call__(self, handler, event, data):
        start_time = time.time()
        logger.info("[{args.name}] Processing update")

        result = await handler(event, data)

        duration = time.time() - start_time
        logger.info(f"[{args.name}] Update processed in {{duration:.3f}}s")

        return result
'''
        mw_file.write_text(content, encoding='utf-8')
        print(f"  Created middlewares/{args.name}.py")

        # Update __init__.py
        init_file = mw_dir / "__init__.py"
        if init_file.exists():
            text = init_file.read_text(encoding='utf-8')
            if f"import {args.name}" not in text and class_name not in text:
                lines = text.split('\n')
                lines.insert(0, f"from .{args.name} import {class_name}Middleware")
                if "__all__" in text:
                    text = text.replace("__all__ = [", f"__all__ = [\"{class_name}Middleware\", ")
                    lines = text.split('\n')
                else:
                    lines.append(f"")
                    lines.append(f"__all__ = [\"{class_name}Middleware\"]")
                init_file.write_text('\n'.join(lines), encoding='utf-8')
                print(f"  Updated middlewares/__init__.py")

        return True

    # ===================== generate-token =====================
    def _cmd_generate_token(self, args) -> bool:
        token = secrets.token_urlsafe(args.length)
        print(token)
        return True

    # ===================== generate-env =====================
    def _cmd_generate_env(self, args) -> bool:
        project = Path(args.project)
        env_file = project / ".env"
        example_file = project / ".env.example"

        if example_file.exists():
            shutil.copy(example_file, env_file)
            print(f"  Copied .env.example -> .env")
        else:
            token = args.token or "YOUR_BOT_TOKEN_HERE"
            content = f"BOT_TOKEN={token}\nLOG_LEVEL=INFO\nDEFAULT_LOCALE=en\nREDIS_URL=redis://localhost:6379\n"
            env_file.write_text(content, encoding='utf-8')
            print(f"  Created .env")

        # Always apply token if provided
        if args.token:
            text = env_file.read_text(encoding='utf-8')
            # Replace any token value after BOT_TOKEN=
            lines = text.split('\n')
            new_lines = []
            for line in lines:
                if line.startswith("BOT_TOKEN="):
                    new_lines.append(f"BOT_TOKEN={args.token}")
                else:
                    new_lines.append(line)
            env_file.write_text('\n'.join(new_lines), encoding='utf-8')
            print(f"  Set BOT_TOKEN in .env")

        print(f"\nRemember to edit .env with your actual values!")
        print(f"  And NEVER commit .env to git!")
        return True

    # ===================== list-templates =====================
    def _cmd_list_templates(self, args) -> bool:
        print("Available project templates:\n")
        print(f"  {'minimal':<12} Minimal bot with single file")
        print(f"  {'standard':<12} Standard bot with handlers, middlewares, keyboards")
        print(f"  {'advanced':<12} Advanced bot with FSM, i18n, metrics, broadcast, testing")
        print()
        return True

    # ===================== run =====================
    def _cmd_run(self, args) -> bool:
        mode = args.mode
        print(f"Running bot in {mode} mode...")

        if mode == "polling":
            skip_update_msg = " (skipping pending updates)" if args.skip_update else ""
            print(f"  Mode: Polling{skip_update_msg}")
            print(f"  Target: {args.target}")
            print(f"\nStarting polling loop...")
            print(f"  Use Ctrl+C to stop")
            return self._run_polling(args)
        else:
            webhook_url = args.url or f"https://YOUR_DOMAIN:{args.port}{args.path}"
            print(f"  Mode: Webhook")
            print(f"  Host: {args.host}")
            print(f"  Port: {args.port}")
            print(f"  Path: {args.path}")
            print(f"  URL: {webhook_url}")
            if args.cert:
                print(f"  SSL Cert: {args.cert}")
            if args.key:
                print(f"  SSL Key: {args.key}")
            print(f"  Target: {args.target}")
            print(f"\nTo run webhook mode, use the following code:")
            print(self._generate_webhook_run_code(args))
            return True

    def _run_polling(self, args) -> bool:
        module_path, callable_name = args.target.split(":")
        print(f"\n  Importing {callable_name} from {module_path}...")
        print(f"  Note: Ensure your bot.py has an async main() function")
        print(f"\n  Example run.py:")
        print(self._generate_polling_run_code(args))
        return True

    def _generate_polling_run_code(self, args) -> str:
        module_path, callable_name = args.target.split(":")
        skip_update = "\n    skip_updates=True" if args.skip_update else ""
        return f'''\
import asyncio
from {module_path} import {callable_name}

async def main():
    await {callable_name}(){skip_update}

if __name__ == "__main__":
    asyncio.run(main())
'''

    def _generate_webhook_run_code(self, args) -> str:
        module_path, callable_name = args.target.split(":")
        webhook_path = args.path
        ssl_code = ""
        if args.cert and args.key:
            ssl_code = f'''
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(args.cert, args.key)'''

        return f'''\
import asyncio
import ssl
from aiohttp import web
from {module_path} import {callable_name}

async def on_startup():
    bot = {callable_name}.bot
    webhook_url = "https://YOUR_DOMAIN:{args.port}{webhook_path}"
    await bot.set_webhook(webhook_url)

async def on_shutdown():
    bot = {callable_name}.bot
    await bot.delete_webhook()

async def handle(request):
    data = await request.json()
    await {callable_name}.process_update(data)
    return web.Response()

app = web.Application()
app.router.add_post("{webhook_path}", handle)
app.on_startup.append(on_startup)
app.on_shutdown.append(on_shutdown)

if __name__ == "__main__":
    web.run_app(app, host="{args.host}", port={args.port})
'''

    # ===================== deploy =====================
    def _cmd_deploy(self, args) -> bool:
        project = Path(args.project)
        project_name = args.name or project.absolute().name
        deploy_type = args.type

        print(f"Generating {deploy_type} deployment config for '{project_name}'...")

        deployers = {
            "docker": self._generate_docker,
            "systemd": self._generate_systemd,
            "railway": self._generate_railway,
            "render": self._generate_render,
        }

        deployer = deployers.get(deploy_type)
        if not deployer:
            print(f"Unknown deployment type: {deploy_type}")
            return False

        files = deployer(project, project_name, args)
        for rel_path, content in files.items():
            file_path = project / rel_path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding='utf-8')
            print(f"  Created: {rel_path}")

        print(f"\n{deploy_type.capitalize()} deployment config generated!")
        print(f"\nNext steps:")
        if deploy_type == "docker":
            print(f"  docker build -t {project_name} .")
            print(f"  docker run -d --env-file .env {project_name}")
        elif deploy_type == "systemd":
            print(f"  sudo cp {project_name}.service /etc/systemd/system/")
            print(f"  sudo systemctl enable {project_name}")
            print(f"  sudo systemctl start {project_name}")
        elif deploy_type in ("railway", "render"):
            print(f"  Push your code to git and connect to {deploy_type.capitalize()}")
        return True

    def _generate_docker(self, project, project_name, args) -> Dict[str, str]:
        port = args.port
        return {
            "Dockerfile": f'''\
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy project files
COPY . .

# Expose webhook port
EXPOSE {port}

# Run the bot
CMD ["python", "run.py"]
''',
            "docker-compose.yml": f'''\
version: "3.8"

services:
  bot:
    build: .
    container_name: {project_name}
    restart: unless-stopped
    env_file:
      - .env
    ports:
      - "{port}:{port}"
    depends_on:
      - redis
    networks:
      - bot_network

  redis:
    image: redis:7-alpine
    container_name: {project_name}-redis
    restart: unless-stopped
    volumes:
      - redis_data:/data
    networks:
      - bot_network

networks:
  bot_network:
    driver: bridge

volumes:
  redis_data:
''',
            ".dockerignore": f'''\
__pycache__/
*.pyc
.env
venv/
.venv/
.git/
.pytest_cache/
*.md
''',
        }

    def _generate_systemd(self, project, project_name, args) -> Dict[str, str]:
        return {
            f"{project_name}.service": f'''\
[Unit]
Description={project_name} Telegram Bot
After=network.target redis.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/{project_name}
ExecStart=/opt/{project_name}/venv/bin/python run.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

EnvironmentFile=/opt/{project_name}/.env

# Security
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true

[Install]
WantedBy=multi-user.target
''',
            "deploy.sh": f'''\
#!/bin/bash
set -e

echo "Deploying {project_name}..."

# Create deployment directory
sudo mkdir -p /opt/{project_name}
sudo chown $USER:$USER /opt/{project_name}

# Copy files
rsync -av --exclude='.env' --exclude='venv' --exclude='__pycache__' ./ /opt/{project_name}/

# Create virtual environment
cd /opt/{project_name}
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Copy .env file (make sure it exists!)
if [ -f .env ]; then
    sudo cp .env /opt/{project_name}/.env
    sudo chmod 600 /opt/{project_name}/.env
else
    echo "ERROR: .env file not found!"
    exit 1
fi

# Install systemd service
sudo cp {project_name}.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable {project_name}
sudo systemctl restart {project_name}

echo "Deployment complete!"
echo "Check status: sudo systemctl status {project_name}"
echo "View logs: sudo journalctl -u {project_name} -f"
''',
        }

    def _generate_railway(self, project, project_name, args) -> Dict[str, str]:
        return {
            "railway.json": f'''\
{{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {{
    "builder": "NIXPACKS"
  }},
  "deploy": {{
    "startCommand": "python run.py",
    "healthcheckPath": "/health",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }}
}}
''',
            "nixpacks.toml": f'''\
[phases.setup]
nixPkgs = ["python311"]

[phases.install]
cmds = ["pip install -r requirements.txt"]

[phases.start]
cmd = "python run.py"
''',
            "Procfile": f'''\
worker: python run.py
''',
            "README-deploy.md": f'''\
# Deploy to Railway

1. Push your code to GitHub
2. Go to [Railway](https://railway.app/)
3. Click "New Project" → "Deploy from GitHub repo"
4. Select your repository
5. Add environment variables in Railway dashboard:
   - `BOT_TOKEN` - Your bot token
   - `LOG_LEVEL` - INFO
6. Deploy!

## Webhook Configuration

Railway provides a public URL automatically. Update your bot code:

```python
WEBHOOK_URL = os.getenv("RAILWAY_PUBLIC_URL") + "/webhook"
```
''',
        }

    def _generate_render(self, project, project_name, args) -> Dict[str, str]:
        return {
            "render.yaml": f'''\
services:
  - type: web
    name: {project_name}
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: python run.py
    envVars:
      - key: BOT_TOKEN
        sync: false
      - key: LOG_LEVEL
        value: INFO
      - key: PYTHON_VERSION
        value: 3.11.0
    autoDeploy: true
''',
            "README-deploy.md": f'''\
# Deploy to Render

1. Push your code to GitHub
2. Go to [Render](https://render.com/)
3. Click "New +" → "Web Service"
4. Connect your repository
5. Configure:
   - Name: {project_name}
   - Environment: Python
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python run.py`
6. Add environment variables in Render dashboard
7. Deploy!
''',
        }

    # ===================== add-filter =====================
    def _cmd_add_filter(self, args) -> bool:
        project = Path(args.project)
        filters_dir = project / "filters"

        if not filters_dir.exists():
            filters_dir.mkdir(parents=True, exist_ok=True)
            init_file = filters_dir / "__init__.py"
            init_file.write_text(f"from .{args.name} import {args.name.capitalize().replace('_', '')}Filter\n\n__all__ = [\"{args.name.capitalize().replace('_', '')}Filter\"]\n")
            print(f"  Created filters/ directory")

        filter_file = filters_dir / f"{args.name}.py"
        if filter_file.exists():
            print(f"Filter already exists: {filter_file}")
            return False

        class_name = args.name.capitalize().replace("_", "")
        base_class = args.base

        if base_class == "BaseFilter":
            content = f'''"""
{args.name} filter
"""
from telegram_async.filters.base import BaseFilter
from telegram_async.dispatcher.context import Context


class {class_name}Filter(BaseFilter):
    """Filter for {args.name}"""

    async def __call__(self, ctx: Context) -> bool:
        """
        Check if update matches the filter.

        Args:
            ctx: Update context

        Returns:
            True if filter matches, False otherwise
        """
        # TODO: Implement your filter logic
        return True
'''
        elif base_class == "TextFilter":
            content = f'''"""
{args.name} text filter
"""
from telegram_async.filters.base import TextFilter
from telegram_async.dispatcher.context import Context


class {class_name}Filter(TextFilter):
    """Text filter for {args.name}"""

    async def __call__(self, ctx: Context) -> bool:
        """
        Check if text matches.

        Args:
            ctx: Update context

        Returns:
            True if text matches, False otherwise
        """
        if not ctx.text:
            return False

        # TODO: Implement your text matching logic
        return False
'''
        else:  # CommandFilter
            content = f'''"""
{args.name} command filter
"""
from telegram_async.filters.command import CommandFilter
from telegram_async.dispatcher.context import Context


class {class_name}Filter(CommandFilter):
    """Command filter for {args.name}"""

    def __init__(self):
        super().__init__("{" + args.name + "}")

    async def __call__(self, ctx: Context) -> bool:
        """
        Check if command matches.

        Args:
            ctx: Update context

        Returns:
            True if command matches, False otherwise
        """
        # TODO: Add pre-command checks if needed
        return True
'''

        filter_file.write_text(content, encoding='utf-8')
        print(f"  Created filters/{args.name}.py")

        # Update __init__.py
        init_file = filters_dir / "__init__.py"
        if init_file.exists():
            text = init_file.read_text(encoding='utf-8')
            if f"import {args.name}" not in text and class_name not in text:
                lines = text.split('\n')
                lines.insert(0, f"from .{args.name} import {class_name}Filter")
                if "__all__" in text:
                    text = text.replace("__all__ = [", f"__all__ = [\"{class_name}Filter\", ")
                    lines = text.split('\n')
                else:
                    lines.append(f"")
                    lines.append(f"__all__ = [\"{class_name}Filter\"]")
                init_file.write_text('\n'.join(lines), encoding='utf-8')
                print(f"  Updated filters/__init__.py")

        return True

    # ===================== add-state =====================
    def _cmd_add_state(self, args) -> bool:
        project = Path(args.project)
        handlers_dir = project / "handlers"

        if not handlers_dir.exists():
            handlers_dir.mkdir(parents=True, exist_ok=True)
            print(f"  Created handlers/ directory")

        state_file = handlers_dir / f"{args.name}.py"
        if state_file.exists():
            print(f"State handler already exists: {state_file}")
            return False

        class_name = args.name.capitalize().replace("_", "")
        steps = args.steps
        with_cancel = args.with_cancel

        # Generate state names
        state_names = [f"{args.name}_step{i+1}" for i in range(steps)]
        state_vars = [f"STEP_{i+1}" for i in range(steps)]

        # Generate step handlers
        step_handlers = ""
        for i in range(steps):
            step_num = i + 1
            step_names = [f"step{step_num}", f"ask_step{step_num}", f"handle_step{step_num}"]
            step_handlers += f'''
@router.message({class_name}State.{state_vars[i]})
async def {step_names[2]}(ctx: Context):
    """Handle step {step_num}"""
    # TODO: Process step {step_num} data
    await ctx.reply("Step {step_num} received. Continue...")
'''

        cancel_code = ""
        if with_cancel:
            cancel_code = f'''

@router.command("cancel")
async def cmd_cancel(ctx: Context):
    """Cancel the {args.name} process"""
    await ctx.state.set_state(None)
    await ctx.reply(f"{class_name} cancelled.")
'''

        content = f'''"""
{args.name} FSM state handler
"""
from telegram_async.dispatcher import Router
from telegram_async.dispatcher.context import Context
from telegram_async.fsm import State, StatesGroup


class {class_name}State(StatesGroup):
    """{class_name} states"""
'''
        # Add state definitions
        for var in state_vars:
            content += f"    {var} = State()\n"

        content += f'''

router = Router("{args.name}")

@router.command("{args.name}")
async def cmd_{args.name}(ctx: Context):
    """Start {args.name} conversation"""
    await ctx.state.set_state({class_name}State.{state_vars[0]})
    await ctx.reply("Welcome! Please provide step 1 info.")
{step_handlers}
{cancel_code}
'''

        state_file.write_text(content, encoding='utf-8')
        print(f"  Created handlers/{args.name}.py")

        # Update handlers/__init__.py
        init_file = handlers_dir / "__init__.py"
        if init_file.exists():
            text = init_file.read_text(encoding='utf-8')
            if f"import {args.name}" not in text:
                lines = text.split('\n')
                last_import_idx = 0
                for i, line in enumerate(lines):
                    if line.startswith("from . import") or line.startswith("import "):
                        last_import_idx = i
                lines.insert(last_import_idx + 1, f"from . import {args.name}")

                if "__all__" in text:
                    text = text.replace("__all__ = [", f"__all__ = [\"{args.name}\", ")
                    text = text.replace("__all__=[", f"__all__=[\"{args.name}\", ")
                    lines = text.split('\n')
                else:
                    lines.append(f"")
                    lines.append(f"__all__ = [\"{args.name}\"]")

                init_file.write_text('\n'.join(lines), encoding='utf-8')
                print(f"  Updated handlers/__init__.py")

        return True

    # ===================== Template file generators =====================

    def _minimal_bot_py(self):
        return '''\
"""
Minimal bot
"""
import asyncio
import logging
from telegram_async import Bot, Dispatcher
from config import BOT_TOKEN

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(BOT_TOKEN)
dp = Dispatcher(bot)

@dp.command("start")
async def cmd_start(ctx):
    await ctx.reply("Hello! I am a bot.")

@dp.message()
async def echo(ctx):
    if ctx.text:
        await ctx.reply(f"You said: {ctx.text}")

async def main():
    logger.info("Starting bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
'''

    def _standard_bot_py(self):
        return '''\
"""
Main bot module
"""
import asyncio
import logging
from telegram_async import Bot, Dispatcher
from config import BOT_TOKEN
from handlers import start as start_handler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(BOT_TOKEN)
dp = Dispatcher(bot)

dp.include_router(start_handler.router)

async def main():
    logger.info("Starting bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
'''

    def _advanced_bot_py(self):
        return '''\
"""
Advanced bot with FSM, i18n, metrics, background tasks
"""
import asyncio
import logging
import os
from telegram_async import Bot, Dispatcher, Router
from telegram_async.utils import I18n, BotMetrics, BackgroundTasksManager
from config import BOT_TOKEN, REDIS_URL, DEFAULT_LOCALE
from handlers import start as start_handler, admin as admin_handler
from middlewares import LoggingMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(BOT_TOKEN)
dp = Dispatcher(bot)

# i18n
i18n = I18n(locales_dir="./locales", default_locale=DEFAULT_LOCALE)

# Metrics
metrics = BotMetrics()

# Background tasks
bg = BackgroundTasksManager()

async def monitor_uptime():
    while True:
        metrics.update_uptime()
        await asyncio.sleep(60)

# Include routers
dp.include_router(start_handler.router)
dp.include_router(admin_handler.router)

async def on_startup():
    logger.info("Bot starting up...")
    await bg.start_all()

async def on_shutdown():
    logger.info("Bot shutting down...")
    await bg.stop_all()

async def main():
    await on_startup()
    try:
        await dp.start_polling(bot)
    finally:
        await on_shutdown()

if __name__ == "__main__":
    asyncio.run(main())
'''

    def _config_py(self):
        return '''\
"""
Configuration
"""
import os

# Bot token from @BotFather
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# Optional: Redis URL for FSM
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# Default locale
DEFAULT_LOCALE = os.getenv("DEFAULT_LOCALE", "en")

# Logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
'''

    def _start_handler_py(self):
        return '''\
"""
/start handler
"""
from telegram_async.dispatcher import Router
from telegram_async.dispatcher.context import Context

router = Router("start")

@router.command("start")
async def cmd_start(ctx: Context):
    """Handle /start command"""
    user = ctx.update.message.from_user
    await ctx.reply(f"Hello, {user.first_name}! Use /help for commands.")

@router.message()
async def echo_message(ctx: Context):
    """Echo all messages"""
    if ctx.text:
        await ctx.reply(f"You said: {ctx.text}")
'''

    def _admin_handler_py(self):
        return '''\
"""
Admin handlers
"""
from telegram_async.dispatcher import Router
from telegram_async.dispatcher.context import Context

router = Router("admin")

ADMIN_IDS = {123456789}  # Replace with your user ID

async def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

@router.command("admin")
async def cmd_admin(ctx: Context):
    """Admin panel"""
    if not await is_admin(ctx.user_id):
        await ctx.reply("Access denied")
        return
    await ctx.reply("Admin panel")
'''

    def _logging_middleware_py(self):
        return '''\
"""
Logging middleware
"""
import logging
import time

logger = logging.getLogger(__name__)


class LoggingMiddleware:
    """Log all updates"""

    async def __call__(self, handler, event, data):
        start_time = time.time()
        logger.info("Processing update")
        result = await handler(event, data)
        duration = time.time() - start_time
        logger.info(f"Update processed in {duration:.3f}s")
        return result
'''

    def _main_keyboard_py(self):
        return '''\
"""
Main keyboard
"""
from telegram_async.keyboards import InlineKeyboardMarkup, InlineKeyboardButton

class MainKeyboard:
    @staticmethod
    def start_menu() -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardMarkup()
        keyboard.row(
            InlineKeyboardButton("Help", callback_data="help"),
            InlineKeyboardButton("Stats", callback_data="stats")
        )
        return keyboard
'''

    def _run_py(self):
        return '''\
"""
Entry point
"""
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

from bot import main

if __name__ == "__main__":
    asyncio.run(main())
'''

    def _test_start_py(self):
        return '''\
"""
Tests for start handler
"""
import pytest
from telegram_async.utils import MockBot, MockContext


@pytest.mark.asyncio
async def test_cmd_start():
    from handlers.start import cmd_start

    bot = MockBot()
    ctx = MockContext(user_id=123, chat_id=456, text="/start")

    # This is a minimal test placeholder
    assert ctx.user_id == 123
    assert ctx.chat_id == 456
'''

    def _readme_md(self, name):
        return f'''\
# {name}

Telegram bot built with [telegram-async](https://github.com/your-org/telegram-async)

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set your bot token:
   ```bash
   cp .env.example .env
   # Edit .env with your BOT_TOKEN
   ```

3. Run the bot:
   ```bash
   python run.py
   # or for minimal:
   python bot.py
   ```

## Structure

- `bot.py` - Main bot setup
- `handlers/` - Message and command handlers
- `middlewares/` - Custom middlewares
- `keyboards/` - Keyboard builders
- `config.py` - Configuration

## Commands

- `/start` - Start the bot
- `/help` - Show help
'''


def main():
    """CLI entry point."""
    cli = CLI()
    cli.run()


if __name__ == "__main__":
    main()
