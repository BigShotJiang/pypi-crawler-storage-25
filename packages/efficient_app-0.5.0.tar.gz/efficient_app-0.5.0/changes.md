# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
none

## [0.5.0] - 2026 05 08
### Added
- set 'appName' key in appArgs as part of wrapper

## [0.4.0] - 2026 04 07
### Changed
- Doc Strings
- Minor Edits

## [0.3.0] - 2026 03 20
### Added
- github action specification
### Changed
- readme

## [0.2.0] - 2026 03 17
### Changed
- AppWrapper passes along app args to script

## [0.1.0] - 2026 03 12
### Added
- Initial Release
