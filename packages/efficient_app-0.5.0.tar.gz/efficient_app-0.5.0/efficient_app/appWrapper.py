from efficient_app.configurations.defaults import DEFAULT_BASE_DIR
from efficient_app.configurations.log import loadLogConfig
from efficient_app.configurations.app import loadAppConfig
from efficient_app.appInfo.loadPkgInfo import logAppInfo, logPkgInfo
from efficient_app.logging.appLogger import AppLogger
from kisspy import expandUser, splitPath
from logging.config import dictConfig
from functools import wraps


def appWrapper(appName: str, cmdArgs: dict, baseDir: str = DEFAULT_BASE_DIR, defaultCfg: dict = None, **appArgs):
    """
    application context manager\n
    implements logging, configuration, and handles unhandled exceptions

    Args:
        appName (str): the application name
        cmdArgs (dict): the command line arguments as a dictionary
        baseDir (str, optional): the base configuration directory, supports the use of ~ to signify the user's home directory. Defaults to DEFAULT_BASE_DIR
        defaultCfg (dict, optional): the default application configuration, only used if the appCfg.json is not found in the application configuration directory. Defaults to None

    Example:

    ```python
        import sys

        sys.path.append(".")

        from kisspy.decorators.pidFile import pidFile
        from efficient_app import appWrapper

        # you write this
        from example.args import getArgs

        import logging
        import time


        @pidFile()
        @appWrapper("myapp", cmdArgs=getArgs())
        def yourProgramStartPoint(*args, **kwargs):
            logger = logging.getLogger(__name__)
            logger.debug("Do A Bunch Of Stuff Here!")
            logger.info("KWARGS: {}".format(kwargs))
            time.sleep(1)
            logger.info("Done!!")


        if __name__ == "__main__":
            yourProgramStartPoint()

    ```
    """

    def appDecorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal appName, cmdArgs, baseDir, defaultCfg, appArgs
            baseDir = expandUser(baseDir, endInSeparator=True)
            environment = cmdArgs.get("environment", "test")
            logDir, logCfg = loadLogConfig(baseDir, environment, defaultCfg=appArgs.get("defaultLogCfg", None))
            dictConfig(logCfg)
            with AppLogger(logDir, onUnhandledExc=appArgs.get("onUnhandledExc", None)) as logger:
                # do some app and package logging
                logger.info("Running '{}' App Environment".format(environment))
                logger.info("Application Arguments: {}".format(cmdArgs))
                appArgs["appName"] = appName
                logAppInfo(appName)
                logPkgInfo()
                # get app config
                cfgFqfn, appCfg = loadAppConfig(baseDir, environment, defaultCfg)
                kwargs["appCfgDir"] = splitPath(cfgFqfn)[0]
                kwargs["appCfg"] = appCfg
                kwargs["appArgs"] = appArgs
                kwargs["cmdArgs"] = cmdArgs
                logger.debug("args: {}".format(args))
                logger.debug("kwargs: {}".format(kwargs))
                return func(*args, **kwargs)

        return wrapper

    return appDecorator
