from efficient_app.configurations.helpers.load import formatPath, loadSeparateCfg
from efficient_app.configurations.defaults import DEFAULT_APP_CFGFN
from typing import Tuple

_CFG_DEFAULT = {
    "dbConn": "host=<fqhostname> dbname=<dbname> user=<usr> password=<pswd>",
    "api": {"baseUrl": "<http://baseurl>", "apiKey": "<apikey>"},
}


def loadAppConfig(baseDir: str, environment: str, defaultCfg: dict = None) -> Tuple[str, dict]:
    fqfn = formatPath(baseDir, environment, "cfg/{}".format(DEFAULT_APP_CFGFN))
    if not defaultCfg:
        defaultCfg = _CFG_DEFAULT
    return fqfn, loadSeparateCfg(fqfn, defaultCfg)
