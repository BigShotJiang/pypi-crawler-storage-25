from kisspy import createDir, getValueOfPath, loadData, createAndReturnDefault
from efficient_app.configurations.defaults import DEFAULT_LOG_CFGFN
from efficient_app.configurations.helpers.load import formatPath
from typing import Tuple

LOG_LINE_FRMT = "%(levelname)-8s | %(asctime)s | %(module)-30s | %(funcName)-30s | %(message)s"


def _getLogCfg(logFn: str) -> dict:
    return {
        "version": 1,
        "formatters": {"default": {"format": LOG_LINE_FRMT}},
        "handlers": {
            "console": {"class": "logging.StreamHandler", "stream": "ext://sys.stdout", "formatter": "default"},
            "file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "filename": logFn,
                "formatter": "default",
                "when": "midnight",
                "backupCount": 90,
                "interval": 1,
            },
        },
        "loggers": {
            "__main__": {"level": "INFO", "handlers": ["console", "file"]},
            "efficient_app": {"level": "INFO", "handlers": ["console", "file"]},
            "efficient_args": {"level": "INFO", "handlers": ["console", "file"]},
            "kisspy": {"level": "INFO", "handlers": ["console", "file"]},
        },
    }


def getDictConfigFilename(logConfig: dict) -> str:
    """gets the file handler filename"""
    return getValueOfPath(logConfig, keyPath="handlers/file/filename")


def loadLogConfig(baseDir: str, environment: str, defaultCfg: dict = None) -> Tuple[str, dict]:
    fqfn = formatPath(baseDir, environment, "cfg/{}".format(DEFAULT_LOG_CFGFN))
    if not defaultCfg:
        logFn = formatPath(baseDir, environment, "logs/appLog.txt")
        defaultCfg = _getLogCfg(logFn)
    cfg = loadData(fqfn, defaultData=defaultCfg, onNotExist=createAndReturnDefault)
    cfgDir = createDir(getDictConfigFilename(cfg))
    return cfgDir, cfg
