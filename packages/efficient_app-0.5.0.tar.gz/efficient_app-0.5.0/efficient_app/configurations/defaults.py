DEFAULT_BASE_DIR = "wkdir/"
DEFAULT_APP_CFGFN = "appCfg.json"
DEFAULT_LOG_CFGFN = "logCfg.json"
