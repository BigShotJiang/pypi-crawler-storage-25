from kisspy import loadData, createAndReturnDefault
from efficient_app.exceptions import EffAppConfigurationException


def _saveAndRaiseCfgEx(*args, **kwargs):
    createAndReturnDefault(*args, **kwargs)
    msg = "No Config Could Be Found, One Was Created: '{}'; Update And Re-Run".format(args[0])
    raise EffAppConfigurationException(msg)


def formatPath(baseDir: str, environment: str, fileBasename: str) -> str:
    if not environment:
        return "{}{}".format(baseDir, fileBasename)
    return "{}{}/{}".format(baseDir, environment, fileBasename)


def loadSeparateCfg(fqfn: str, defaultCfg: dict = None) -> dict:
    return loadData(fqfn, defaultData=defaultCfg, onNotExist=_saveAndRaiseCfgEx)
