from efficient_app.configurations.log import LOG_LINE_FRMT
from contextlib import contextmanager
import logging


@contextmanager
def contextFileLogger(filename: str, logLevel=None, lineFrmt: str = LOG_LINE_FRMT, logName: str = __name__):
    """
    context file logger for specific folder / data, returns the file logger\n
    removes the file handler from the original logger during teardown
    """
    hdlr = logging.FileHandler(filename)
    if logLevel:
        hdlr.setLevel(logLevel)
    hdlr.setFormatter(logging.Formatter(fmt=lineFrmt))
    lggr = logging.getLogger(logName)
    try:
        lggr.addHandler(hdlr)
        yield lggr
    finally:
        lggr.removeHandler(hdlr)
