from datetime import datetime
import traceback
import logging

UNHANDLED_EXECPTION_MSG = "An Unhandled Exception Has Occurred: {}: {} See File '{}' For Full Traceback"


class AppLogger(object):
    def __init__(self, logDir: str, onUnhandledExc=None):
        self.logDir = logDir
        self.onUnhandledExc = onUnhandledExc

    def __enter__(self):
        logger = logging.getLogger(__name__)
        logger.info("---- started ----")
        return logger

    def __exit__(self, exc_type, exc_val, exc_tb):
        logger = logging.getLogger(__name__)
        # handle any unhandled application exceptions
        if exc_type:
            tbFileName = self.logDir + "unhandled_exc_{}.txt".format(datetime.now().strftime("%Y%m%dT%H%M%S"))
            with open(tbFileName, "w") as fw:
                fw.write("\n".join(traceback.format_tb(exc_tb)))
            msg = UNHANDLED_EXECPTION_MSG.format(exc_type.__name__, exc_val, tbFileName)
            logger.critical(msg)
            if self.onUnhandledExc:
                self.onUnhandledExc(message=msg, tracebackFilename=tbFileName)
        # close out
        logger.info("--- completed ---")
        return True
