from distlib.database import DistributionPath
import logging
import json
import os

_logger = logging.getLogger(__name__)
_logger.addHandler(logging.NullHandler())


def getAppVersion(appName: str, formatResponse: bool = False) -> str:
    fn = "{}/_metadata.json".format(appName)
    if not os.path.exists(fn):
        return None
    with open(fn, "r") as fr:
        md = json.load(fr)
        if formatResponse:
            return "{} {}".format(appName, md["version"])
        return md["version"]


def logAppInfo(appName: str):
    appVersion = getAppVersion(appName, True)
    if appVersion:
        _logger.info("Application Version: {}".format(appVersion))


def getPkgInfo():
    distPath = DistributionPath(include_egg=True)
    installedPkgs = distPath.get_distributions()
    installedList = sorted(["{} {}".format(i.name, i.version) for i in installedPkgs])
    return installedList


def logPkgInfo():
    _logger.info("Application Packages: {}".format(getPkgInfo()))
