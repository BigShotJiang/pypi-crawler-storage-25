from kisspy import getSortableNow, randomString
from datetime import datetime, timedelta
import pathlib
import shutil
import os

DT_FORMAT = "%Y%m%d_%H%M%S"


def createDTUniqueTempDir(baseDir: str) -> str:
    """
    creates a date-time text unique directory and returns the directory path; ie: ie: 'wkdir/temp/20250212_115801_86e0e18bd3/'

    Args:
        baseDir (str): the base directory to create the temp directory in

    Returns:
        str: the path of the temp directory including base directory
    """
    if not baseDir.endswith("/"):
        baseDir += "/"

    def _createName() -> str:
        return getSortableNow(prefix=baseDir, suffix="_{}/".format(randomString()), frmt=DT_FORMAT)

    dname = _createName()
    while os.path.exists(dname):
        dname = _createName()
    pathlib.Path(dname).mkdir(parents=True)
    return dname


def cleanUpTempDirs(baseDir: str, olderThan: timedelta) -> list[str]:
    """
    cleans up (deletes) the temp directories in the base directory location

    Args:
        baseDir (str): the base directory to search for old temp directories in
        olderThan (timedelta): any directories older than now() - [this value] are deleted

    Returns:
        list[str]: list of directories deleted
    """
    removedDirs = []
    tempDirs = [x for x in pathlib.Path(baseDir).iterdir() if x.is_dir()]
    for td in tempDirs:
        bn, dName = os.path.split(td)
        dtCreated = datetime.strptime(dName[:15], DT_FORMAT)
        if dtCreated < (datetime.now() - olderThan):
            shutil.rmtree(td)
            removedDirs.append(str(td).replace("\\", "/"))
    return removedDirs
