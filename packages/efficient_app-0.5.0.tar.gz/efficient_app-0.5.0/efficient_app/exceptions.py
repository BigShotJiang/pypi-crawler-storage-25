from kisspy.exceptions import KisspyException


class EffAppConfigurationException(KisspyException):
    pass
