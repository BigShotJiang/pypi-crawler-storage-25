# efficient-app - Simple Scripting Wrapper

Script configuration and logging setup

## Usage

Here's an example of a simple entry to a script, it also uses the package 'efficient-args', but 
that isn't required to use this package, the args just need to be returned as a dictionary:

````python
    from kisspy.decorators.pidFile import pidFile
    from efficient_args import FORMATTER, addBaseArgs, parseArgs
    from efficient_app import appWrapper
    import argparse
    import logging
    import time


    def getArgs() -> dict:
        parser = argparse.ArgumentParser(description="Example App", formatter_class=FORMATTER)
        addBaseArgs(parser, addEnvironment=True)
        return parseArgs(parser)


    @pidFile()
    @appWrapper("myapp", cmdArgs=getArgs())
    def yourProgramStartPoint(*args, **kwargs):
        logger = logging.getLogger(__name__)
        logger.debug("Do A Bunch Of Stuff Here!")
        # raise Exception("Doh!!")
        logger.info("KWARGS: {}".format(kwargs))
        time.sleep(1)
        logger.info("Done!!")


    if __name__ == "__main__":
        yourProgramStartPoint()
````

The kwargs dict passed into the start point method looks like this, obviously the actual 
data would look different, but from there you can call your methods...

````json
{
    "appCfgDir": "wkdir/test/cfg/",
    "appCfg": {
        "dbConn": "host=<fqhostname> dbname=<dbname> user=<usr> password=<pswd>",
        "api": {
            "baseUrl": "<http://baseurl>",
            "apiKey": "<apikey>"
        }
    },
    "appArgs": {
    },
    "cmdArgs": {
        "environment": "test"
    }
}
````

By default, the configuration and log files are created in this structure at the root of 
the project directory:

````
wkdir/
├── prod
│   ├── cfg
│   │   ├── appCfg.json
│   │   └── logCfg.json
│   └── logs
│       ├── appLog.txt
│       └── unhandled_exc_20260320T002548.txt
└── test
    ├── cfg
    │   ├── appCfg.json
    │   └── logCfg.json
    └── logs
        ├── appLog.txt
        ├── appLog.txt.2026-03-12
        ├── appLog.txt.2026-03-17
        ├── unhandled_exc_20260312T202100.txt
        └── unhandled_exc_20260312T202244.txt
````

Note that when the script encounters an unhandled exception, it will save the stack trace 
to a date and time stamped file for reference. This occurs when the app first runs, as it 
creates a default app config file and assumes the default isn't going to cut it. Edit to 
your hearts content and re-run.

The package also contains two methods to assist with temp directories:

````python
    from efficient_app import createDTUniqueTempDir, cleanUpTempDirs
    from datetime import timedelta

    # create the temp directory
    dirPath = createDTUniqueTempDir(baseDir="wkdir/dev/files/")
    # ...
    # do some stuff with the files added to the directory
    # ...
    # at some point in the future, if you want to clean it up...
    cleanUpTempDirs(baseDir="wkdir/dev/files/", olderThan=timedelta(days=90))
````

## Installation

### Using In Projects

Installation:

````bash
    pip install efficient-app
````

### Cloning For Development

<p>Set up a virtual environment. Once an environment is set up, run the command below to:

* validate the environment variable
* activate the environment (if not already activated) 
* install all of the necessary packages into the local environment

```bash
    pip install -U -r requirements/dev.txt
```

<p>The dev.txt file includes:

* BLACK, a code formatter, see notes at the bottom of this file for details

## Dependancies

This project uses the following projects:

* kisspy-python
* distlib

## Tests

To run tests:

```bash
    python -m unittest discover -s tests/
```

## Code Formatting

Code formatting is done using BLACK. BLACK allows almost no customization to how code is formatted with the exception of line length, which has been set to 119 characters.

Use the following to bulk format files:

````bash
    black . -l 144
````

## Creating A New Release

Please do the following when making a new release, most are documented above:

1. Run tests
1. Code format
1. Be sure to update the change log and _metadata.json with version and notes
1. git add, commit, and push changes
1. run the following code to generate a wheel:

````bash
    python -m build
````
