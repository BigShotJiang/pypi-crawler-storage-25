from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Callable
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, TextIO

from zero_engine import PaperEngine, load_scenario, load_strategy_runner, parse_scenario
from zero_engine.api import PaperApi, PaperApiState
from zero_engine.decision import fixture_stack
from zero_engine.evolve import snapshot_from_fixture as evolve_snapshot_from_fixture
from zero_engine.genesis import Proposal, load_proposals, snapshot_from_proposals
from zero_engine.memory import extract_from_decisions, isoformat
from zero_engine.research import snapshot_from_fixture as research_snapshot_from_fixture
from zero_engine.runtime import production_parity_snapshot

SERVER_NAME = "zero-mcp"
SERVER_VERSION_FALLBACK = "0.1.5"
DEFAULT_PROTOCOL_VERSION = "2025-06-18"
SUPPORTED_PROTOCOL_VERSIONS = {"2025-06-18", "2025-11-25"}
PAPER_TS = 1777646400.0
MCP_REFUSAL_SCHEMA_VERSION = "zero.mcp.refusal.v1"
MCP_ALLOWED_SURFACE = (
    "initialize",
    "ping",
    "tools/list",
    "tools/call:read-only",
    "resources/list",
    "resources/read:zero://...",
)

JsonMap = dict[str, Any]


def server_version() -> str:
    """Return the installed package version, with a source-tree fallback."""
    try:
        return version("zero-engine")
    except PackageNotFoundError:
        return SERVER_VERSION_FALLBACK


def parse_mcp_time() -> datetime:
    return datetime.fromtimestamp(PAPER_TS, UTC)


READ_ONLY_SAFETY: JsonMap = {
    "safetyClass": "read_only_public",
    "riskDirection": "none",
    "requiresOperatorApproval": False,
    "canPlaceOrders": False,
    "canChangeRuntimeState": False,
    "canReadSecrets": False,
    "annotations": {
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
}

EMBEDDED_SCENARIO: JsonMap = {
    "name": "paper-launch-smoke",
    "mode": "paper",
    "limits": {
        "max_notional_usd": 500,
        "max_position_notional_usd": 900,
        "min_confidence": 0.7,
    },
    "orders": [
        {"symbol": "BTC", "side": "buy", "quantity": 0.01, "price": 40000, "confidence": 0.84},
        {"symbol": "ETH", "side": "buy", "quantity": 1, "price": 3000, "confidence": 0.93},
        {
            "symbol": "BTC",
            "side": "sell",
            "quantity": 0.005,
            "price": 40500,
            "confidence": 0.1,
            "reduce_only": True,
        },
        {"symbol": "SOL", "side": "buy", "quantity": 10, "price": 140, "confidence": 0.95},
    ],
}

EMBEDDED_MARKET: JsonMap = {
    "BTC": {"as_of": "2026-05-01T00:05:00Z", "last": 40500.0},
    "ETH": {"as_of": "2026-05-01T00:00:00Z", "last": 3000.0},
    "SOL": {"as_of": "2026-05-01T00:00:00Z", "last": 140.0},
}

EMBEDDED_PROOF_PACK: JsonMap = {
    "schema_version": "zero.proof_pack.v1",
    "generated_at": "2026-05-01T00:00:00Z",
    "name": "demo-paper-launch-smoke",
    "mode": "paper",
    "claim_boundary": {
        "paper_mode_verified": True,
        "live_trading_claimed": False,
        "paper_vs_live_correlation_claimed": False,
        "pnl_claimed": False,
    },
    "paper": {
        "scenario": "paper-launch-smoke",
        "decisions": 4,
        "fills": 2,
        "rejections": 2,
        "open_positions": 1,
        "symbols": ["BTC", "ETH", "SOL"],
    },
    "live_correlation": {
        "status": "unavailable",
        "reason": "requires signed paper/live records and exchange-side evidence",
        "r_squared": None,
    },
    "privacy": {
        "contains_exchange_credentials": False,
        "contains_wallet_material": False,
        "contains_raw_exchange_order_ids": False,
        "contains_private_notes": False,
    },
    "artifacts": {
        "scenario_json": "embedded",
        "candles_jsonl": "embedded",
        "paper_decisions_csv": "source-checkout-only",
        "paper_proof_svg": "source-checkout-only",
        "demo_readme": "source-checkout-only",
    },
    "proof_hash": "embedded-source-checkout-required-for-file-hash-verification",
}

EMBEDDED_NETWORK_PROOF_PACK: JsonMap = {
    "schema_version": "zero.network_proof_pack.v1",
    "generated_at": "2026-05-01T00:00:00Z",
    "name": "demo-network-proof-chain",
    "mode": "paper",
    "profile_schema_version": "zero.network.profile.v1",
    "verification_schema_version": "zero.network.profile_verification.v1",
    "ok": True,
    "claim_boundary": {
        "paper_mode_verified": True,
        "hosted_ingestion_compatible": True,
        "live_trading_claimed": False,
        "paper_vs_live_correlation_claimed": False,
        "pnl_claimed": False,
    },
    "bindings": {
        "proof_hash": "source-checkout-required-for-network-proof-hash",
        "deployment_claim_hash": "source-checkout-required-for-claim-hash",
        "deployment_heartbeat_hash": "source-checkout-required-for-heartbeat-hash",
        "leaderboard_proof_hash": "source-checkout-required-for-network-proof-hash",
    },
    "identity": {
        "bundle_schema_version": "zero.deployment_identity_evidence.v1",
        "signature_present": False,
        "signature_required_for_static_fixture": False,
        "signed_identity_smoke_tested_in_ci": True,
    },
    "verification": {
        "ok": True,
        "checks_ok": 0,
        "checks_failed": 0,
        "hosted_ingestion_accepted": 1,
    },
    "privacy": {
        "contains_exchange_credentials": False,
        "contains_wallet_material": False,
        "contains_raw_decisions": False,
        "contains_trace_tokens": False,
        "contains_idempotency_tokens": False,
    },
    "artifacts": {
        "network-proof-pack.json": "source-checkout-only",
        "profile.json": "source-checkout-only",
        "profile-verification.json": "source-checkout-only",
        "leaderboard.json": "source-checkout-only",
        "identity/identity_bundle.json": "source-checkout-only",
    },
    "proof_hash": "embedded-source-checkout-required-for-file-hash-verification",
}

EMBEDDED_GENESIS_PROPOSALS = (
    Proposal(
        proposal_id="sha256:genesis-accepted-docs",
        title="Document strategy-runner acceptance floor",
        summary="Promote the fixture-backed strategy runner acceptance floor into contributor docs.",
        target_paths=("docs/strategy-plugins.md", "examples/strategy-runner/README.md"),
        evidence_refs=(
            "docs/proof/demo/proof-pack.json",
            "examples/strategy-runner/close-strength.yaml",
        ),
        sample_size=42,
        risk_tier="medium",
        revert_plan="Revert the documentation update and keep the runner fixture unchanged.",
        created_at=parse_mcp_time(),
        metadata={"source_class": "fixture-paper", "owner": "public-runtime"},
    ),
    Proposal(
        proposal_id="sha256:genesis-rejected-sample",
        title="Relax docs wording for a new rejection cohort",
        summary="Add a new cohort note before enough fixture decisions exist to justify it.",
        target_paths=("docs/memory-core.md",),
        evidence_refs=("examples/memory-core/decisions.jsonl",),
        sample_size=2,
        risk_tier="low",
        revert_plan="Remove the cohort note if the fixture does not reproduce.",
        created_at=parse_mcp_time(),
        metadata={"source_class": "fixture-paper", "owner": "public-runtime"},
    ),
    Proposal(
        proposal_id="sha256:genesis-escalated-live",
        title="Tune live adapter retry behavior",
        summary="Change live adapter retry behavior from observed operator evidence.",
        target_paths=("engine/src/zero_engine/live.py",),
        evidence_refs=("docs/live-certification.md", "docs/live-evidence.md"),
        sample_size=140,
        risk_tier="medium",
        revert_plan="Revert the retry behavior and keep the previous live preflight gate.",
        created_at=parse_mcp_time(),
        metadata={"source_class": "fixture-paper", "owner": "public-runtime"},
    ),
)


def find_repo_root() -> Path | None:
    for parent in Path(__file__).resolve().parents:
        if (parent / "examples" / "paper-trading" / "scenario.json").is_file():
            return parent
    return None


def repo_root() -> Path:
    root = find_repo_root()
    if root is None:
        raise RuntimeError("zero-mcp requires a ZERO source checkout for this resource")
    return root


def scenario_path() -> Path:
    return repo_root() / "examples" / "paper-trading" / "scenario.json"


def candles_path() -> Path:
    return repo_root() / "examples" / "paper-trading" / "candles.jsonl"


def proof_pack_path() -> Path:
    return repo_root() / "docs" / "proof" / "demo" / "proof-pack.json"


def genesis_proposals_path() -> Path:
    return repo_root() / "examples" / "genesis" / "proposals.jsonl"


DOC_RESOURCES: tuple[JsonMap, ...] = (
    {
        "uri": "zero://docs/strategy-runner",
        "name": "Strategy Runner Docs",
        "description": "Read-only contributor docs for declarative paper strategy runners.",
        "path": "examples/strategy-runner/README.md",
        "fallback": (
            "# Strategy Runner Docs\n\n"
            "Declarative strategy runners are paper-only examples for coding agents and "
            "contributors. Use `examples/strategy-runner/close-strength.yaml` as the "
            "reference fixture and keep new runners deterministic.\n"
        ),
    },
    {
        "uri": "zero://docs/strategy-plugin",
        "name": "Strategy Plugin Docs",
        "description": "Read-only contributor docs for deterministic paper strategy plugins.",
        "path": "examples/strategy-plugin/README.md",
        "fallback": (
            "# Strategy Plugin Docs\n\n"
            "Strategy plugins are the smallest paper-only contributor path. Keep plugin "
            "fixtures deterministic, avoid credentials, and include a focused smoke test.\n"
        ),
    },
    {
        "uri": "zero://docs/market-data-adapters",
        "name": "Market Data Adapter Docs",
        "description": "Read-only contributor docs for deterministic market-data adapters.",
        "path": "examples/market-data-adapter/README.md",
        "fallback": (
            "# Market Data Adapter Docs\n\n"
            "Market-data adapters should load public-safe deterministic fixtures for tests "
            "and examples. Do not add exchange credentials or live-only dependencies.\n"
        ),
    },
)


def load_demo_scenario() -> Any:
    root = find_repo_root()
    if root is None:
        return parse_scenario(EMBEDDED_SCENARIO)
    return load_scenario(root / "examples" / "paper-trading" / "scenario.json")


def market_snapshot(symbols: list[str]) -> JsonMap:
    root = find_repo_root()
    if root is None:
        return {symbol: EMBEDDED_MARKET[symbol] for symbol in symbols}

    from zero_engine import JsonlCandleAdapter

    market = JsonlCandleAdapter(root / "examples" / "paper-trading" / "candles.jsonl")
    return {
        symbol: {
            "as_of": market.latest(symbol).ts,
            "last": market.latest(symbol).close,
        }
        for symbol in symbols
    }


def run_paper_scenario() -> JsonMap:
    scenario = load_demo_scenario()
    engine = PaperEngine(limits=scenario.limits, clock=lambda: PAPER_TS)

    for order in scenario.orders:
        engine.submit(order, source=f"scenario:{scenario.name}")

    symbols = sorted({order.symbol for order in scenario.orders})
    return {
        "schema_version": "zero.mcp.paper_results.v1",
        "mode": scenario.mode,
        "scenario": scenario.name,
        "paper_only": True,
        "market": market_snapshot(symbols),
        "fills": len(engine.fills),
        "rejections": len(engine.rejections),
        "positions": {
            symbol: {
                "quantity": position.quantity,
                "avg_price": position.avg_price,
                "notional_usd": position.notional_usd,
            }
            for symbol, position in sorted(engine.positions.items())
        },
        "decisions": [record.to_dict() for record in engine.decisions],
    }


def demo_api() -> PaperApi:
    scenario = load_demo_scenario()
    engine = PaperEngine(limits=scenario.limits, clock=lambda: PAPER_TS)
    for order in scenario.orders:
        engine.submit(order, source=f"scenario:{scenario.name}")
    now = parse_mcp_time()
    return PaperApi(
        PaperApiState(
            engine=engine,
            clock=lambda: now,
            started_at=now,
        )
    )


def list_strategies() -> JsonMap:
    root = find_repo_root()
    runner = None
    if root is not None:
        runner = load_strategy_runner(root / "examples" / "strategy-runner" / "close-strength.yaml")
    return {
        "schema_version": "zero.mcp.strategies.v1",
        "mode": "paper",
        "strategies": [
            {
                "name": "momentum-close-above-open",
                "kind": "built_in",
                "paper_only": True,
                "path": "engine/src/zero_engine/strategy.py",
                "description": "Built-in candle close/open momentum strategy signal.",
            },
            {
                "name": runner.metadata.name if runner is not None else "close-strength-yaml",
                "kind": "declarative_runner",
                "version": runner.metadata.version if runner is not None else "0.1.0",
                "paper_only": runner.metadata.paper_only if runner is not None else True,
                "path": "examples/strategy-runner/close-strength.yaml",
                "description": (
                    runner.metadata.description
                    if runner is not None
                    else "Declarative close-above-open paper runner."
                ),
            },
            {
                "name": "close-strength",
                "kind": "strategy_plugin_example",
                "version": "0.1.0",
                "paper_only": True,
                "path": "examples/strategy-plugin/plugin.py",
                "description": "Smallest contributor path for a deterministic paper strategy plugin.",
            },
        ],
    }


def get_paper_results() -> JsonMap:
    return run_paper_scenario()


def get_position_state() -> JsonMap:
    paper = run_paper_scenario()
    return {
        "schema_version": "zero.mcp.position_state.v1",
        "mode": "paper",
        "paper_only": True,
        "scenario": paper["scenario"],
        "positions": paper["positions"],
    }


def get_runtime_status() -> JsonMap:
    return {
        **demo_api().v2_status(),
        "schema_version": "zero.mcp.runtime_status.v1",
        "mode": "paper",
        "paper_only": True,
    }


def get_runtime_parity() -> JsonMap:
    root = find_repo_root()
    if root is None:
        return {
            "schema_version": "zero.mcp.runtime_parity.v1",
            "mode": "production-parity",
            "paper_only": True,
            "places_live_orders": False,
            "available": False,
            "ok": False,
            "reason": "source checkout required for bundled scenario",
            "claim_boundary": {
                "production_ooda_parity": False,
                "live_trading_claimed": False,
                "operator_owned_canary_required_for_live_claim": True,
                "protected_live_code_evolution_allowed": False,
                "remote_push_allowed": False,
            },
        }
    return {
        **production_parity_snapshot(root, now=parse_mcp_time()),
        "schema_version": "zero.mcp.runtime_parity.v1",
        "paper_only": True,
    }


def get_health_status() -> JsonMap:
    return {
        **demo_api().health(),
        "schema_version": "zero.mcp.health_status.v1",
        "mode": "paper",
        "paper_only": True,
    }


def get_journal_tail() -> JsonMap:
    payload = demo_api().journal({"limit": ["10"]})
    return {
        "schema_version": "zero.mcp.journal_tail.v1",
        "mode": "paper",
        "paper_only": True,
        "source": "bundled-paper-scenario",
        **payload,
    }


def get_rejection_audit() -> JsonMap:
    payload = demo_api().rejections({"limit": ["20"]})
    by_reason: dict[str, int] = {}
    by_stage: dict[str, int] = {}
    for rejection in payload["rejections"]:
        reason = str(rejection.get("reason", "unknown"))
        stage = str(rejection.get("stage", "unknown"))
        by_reason[reason] = by_reason.get(reason, 0) + 1
        by_stage[stage] = by_stage.get(stage, 0) + 1
    return {
        "schema_version": "zero.mcp.rejection_audit.v1",
        "mode": "paper",
        "paper_only": True,
        "source": "bundled-paper-scenario",
        "summary": {
            "rejections": len(payload["rejections"]),
            "by_stage": dict(sorted(by_stage.items())),
            "by_reason": dict(sorted(by_reason.items())),
        },
        "rejections": payload["rejections"],
    }


def get_memory_stats() -> JsonMap:
    snapshot = get_memory_snapshot()
    return {
        "schema_version": "zero.mcp.memory_stats.v1",
        "mode": "paper",
        "paper_only": True,
        "source": snapshot["source"],
        "stats": snapshot["stats"],
    }


def get_immune_status() -> JsonMap:
    payload = demo_api().immune()
    return {
        **payload,
        "schema_version": "zero.mcp.immune_status.v1",
        "paper_only": True,
    }


def get_backtest_report() -> JsonMap:
    paper = run_paper_scenario()
    decisions = paper["decisions"]
    accepted = len([record for record in decisions if record["allowed"]])
    rejected = len(decisions) - accepted
    return {
        "schema_version": "zero.mcp.backtest_report.v1",
        "mode": "paper",
        "paper_only": True,
        "scenario": paper["scenario"],
        "claim_boundary": {
            "paper_mode_verified": True,
            "live_trading_claimed": False,
            "pnl_claimed": False,
        },
        "summary": {
            "decisions": len(decisions),
            "fills": paper["fills"],
            "rejections": rejected,
            "acceptance_rate": round(accepted / len(decisions), 4) if decisions else 0.0,
            "symbols": sorted(paper["market"].keys()),
        },
        "notes": [
            "deterministic paper fixture only",
            "not a profitability claim",
            "use strategy examples for contributor conformance",
        ],
    }


def get_evidence_bundle() -> JsonMap:
    payload = demo_api().live_evidence()
    return {
        **payload,
        "schema_version": "zero.mcp.evidence_bundle.v1",
        "paper_only": True,
    }


def get_memory_snapshot() -> JsonMap:
    paper = run_paper_scenario()
    entries = extract_from_decisions(paper["decisions"], now=parse_mcp_time())
    by_kind = {kind: 0 for kind in ["operator", "regime", "signal", "strategy_reference"]}
    for entry in entries:
        by_kind[entry.kind] += 1
    return {
        "schema_version": "zero.mcp.memory_snapshot.v1",
        "mode": "paper",
        "paper_only": True,
        "generated_at": isoformat(parse_mcp_time()),
        "source": "bundled-paper-scenario",
        "stats": {
            "active_entries": len(entries),
            "by_kind": by_kind,
            "privacy": {
                "contains_live_prices": False,
                "contains_wallet_material": False,
                "contains_exchange_order_ids": False,
                "contains_private_keys": False,
            },
        },
        "entries": [entry.to_dict() for entry in entries],
    }


def get_genesis_proposals() -> JsonMap:
    root = find_repo_root()
    proposals = (
        load_proposals(root / "examples" / "genesis" / "proposals.jsonl")
        if root is not None
        else list(EMBEDDED_GENESIS_PROPOSALS)
    )
    snapshot = snapshot_from_proposals(proposals, now=parse_mcp_time())
    return {
        **snapshot,
        "schema_version": "zero.mcp.genesis_proposals.v1",
        "mode": "plan-only",
        "paper_only": True,
    }


def get_evolve_status() -> JsonMap:
    root = find_repo_root()
    if root is None:
        return {
            "schema_version": "zero.mcp.evolve_status.v1",
            "mode": "paper-only",
            "paper_only": True,
            "source": "installed-package-fallback",
            "promotion": {
                "pushes_to_remote": False,
                "promoted": False,
                "requires_human_approval": True,
            },
        }
    snapshot = evolve_snapshot_from_fixture(root, now=parse_mcp_time())
    return {
        **snapshot,
        "schema_version": "zero.mcp.evolve_status.v1",
        "paper_only": True,
    }


def get_research_report() -> JsonMap:
    root = find_repo_root()
    snapshot = research_snapshot_from_fixture(root or Path.cwd(), now=parse_mcp_time())
    return {
        **snapshot,
        "schema_version": "zero.mcp.research_report.v1",
        "paper_only": True,
    }


def get_decision_stack() -> JsonMap:
    stack = fixture_stack(generated_at=parse_mcp_time())
    return {
        **stack,
        "schema_version": "zero.mcp.decision_stack.v1",
        "paper_only": True,
    }


def safety_catalog() -> JsonMap:
    tools = tool_definitions()
    return {
        "schema_version": "zero.mcp.safety_catalog.v1",
        "default": "read_only_public",
        "risk_increasing_tools": [],
        "risk_reducing_tools": [],
        "read_only_tools": [
            {
                "name": tool["name"],
                "safetyClass": tool["safetyClass"],
                "riskDirection": tool["riskDirection"],
                "canPlaceOrders": tool["canPlaceOrders"],
                "canChangeRuntimeState": tool["canChangeRuntimeState"],
                "requiresOperatorApproval": tool["requiresOperatorApproval"],
            }
            for tool in tools
        ],
    }


def get_proof_pack() -> JsonMap:
    root = find_repo_root()
    if root is None:
        return EMBEDDED_PROOF_PACK
    return json.loads((root / "docs" / "proof" / "demo" / "proof-pack.json").read_text())


def get_network_proof_pack() -> JsonMap:
    root = find_repo_root()
    if root is None:
        return EMBEDDED_NETWORK_PROOF_PACK
    return json.loads((root / "docs" / "proof" / "network" / "network-proof-pack.json").read_text())


def tool_definitions() -> list[JsonMap]:
    empty_schema = {"type": "object", "properties": {}, "additionalProperties": False}
    tools = [
        {
            "name": "zero_list_strategies",
            "description": "Read-only list of bundled paper strategies and contributor examples.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_runtime_status",
            "description": "Read-only paper runtime status derived from the bundled scenario.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_runtime_parity",
            "description": "Read-only production-parity OODA report with disabled live shadow execution.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_health",
            "description": "Read-only paper runtime health, dependency, and breaker status.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_paper_results",
            "description": "Read-only replay of the deterministic bundled paper scenario.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_position_state",
            "description": "Read-only paper position state derived from the bundled scenario.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_journal_tail",
            "description": "Read-only paper decision journal tail from the bundled scenario.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_rejection_audit",
            "description": "Read-only paper rejection audit grouped by stage and reason.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_proof_pack",
            "description": "Read-only public-safe demo proof-pack manifest.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_network_proof_pack",
            "description": "Read-only public-safe ZERO Network proof-chain manifest.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_memory_snapshot",
            "description": "Read-only public-safe local memory snapshot from bundled paper decisions.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_memory_stats",
            "description": "Read-only aggregate memory stats without entry bodies.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_genesis_proposals",
            "description": "Read-only plan-only genesis proposal classifications.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_evolve_status",
            "description": "Read-only paper-first evolve gate status.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_research_report",
            "description": "Read-only paper-only research command-chain report.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_decision_stack",
            "description": "Read-only paper-only lens, layer, and modifier decision stack.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_immune_status",
            "description": "Read-only paper immune breaker and risk-allowance status.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_backtest_report",
            "description": "Read-only deterministic paper backtest report without PnL claims.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_evidence_bundle",
            "description": "Read-only hash-only evidence bundle from the bundled paper runtime.",
            "inputSchema": empty_schema,
        },
        {
            "name": "zero_get_safety_catalog",
            "description": "Read-only MCP safety catalog for every public tool.",
            "inputSchema": empty_schema,
        },
    ]
    return [{**tool, **READ_ONLY_SAFETY} for tool in tools]


TOOLS: dict[str, Callable[[], JsonMap]] = {
    "zero_list_strategies": list_strategies,
    "zero_get_runtime_status": get_runtime_status,
    "zero_get_runtime_parity": get_runtime_parity,
    "zero_get_health": get_health_status,
    "zero_get_paper_results": get_paper_results,
    "zero_get_position_state": get_position_state,
    "zero_get_journal_tail": get_journal_tail,
    "zero_get_rejection_audit": get_rejection_audit,
    "zero_get_proof_pack": get_proof_pack,
    "zero_get_network_proof_pack": get_network_proof_pack,
    "zero_get_memory_snapshot": get_memory_snapshot,
    "zero_get_memory_stats": get_memory_stats,
    "zero_get_genesis_proposals": get_genesis_proposals,
    "zero_get_evolve_status": get_evolve_status,
    "zero_get_research_report": get_research_report,
    "zero_get_decision_stack": get_decision_stack,
    "zero_get_immune_status": get_immune_status,
    "zero_get_backtest_report": get_backtest_report,
    "zero_get_evidence_bundle": get_evidence_bundle,
    "zero_get_safety_catalog": safety_catalog,
}


def resource_definitions() -> list[JsonMap]:
    resources = [
        {
            "uri": "zero://paper/scenario",
            "name": "Bundled Paper Scenario",
            "description": "The deterministic paper scenario used by examples and MCP tools.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://paper/results",
            "name": "Bundled Paper Results",
            "description": "Read-only paper replay result generated from the bundled scenario.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://runtime/status",
            "name": "Demo Runtime Status",
            "description": "Read-only paper runtime status from the bundled scenario.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://runtime/health",
            "name": "Demo Runtime Health",
            "description": "Read-only paper runtime health, dependencies, and breakers.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://runtime/parity",
            "name": "Demo Runtime Production Parity",
            "description": "Read-only production-parity OODA report with live shadow fail-closed evidence.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://journal/tail",
            "name": "Demo Journal Tail",
            "description": "Read-only paper decision journal tail from the bundled scenario.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://rejections/audit",
            "name": "Demo Rejection Audit",
            "description": "Read-only paper rejection audit from the bundled scenario.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://proof/demo",
            "name": "Demo Proof Pack",
            "description": "Public-safe demo proof-pack manifest.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://proof/network",
            "name": "Network Proof Pack",
            "description": "Public-safe ZERO Network proof-chain manifest.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://memory/snapshot",
            "name": "Demo Memory Snapshot",
            "description": "Public-safe local memory extracted from bundled paper decisions.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://memory/stats",
            "name": "Demo Memory Stats",
            "description": "Read-only aggregate memory stats without entry bodies.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://genesis/proposals",
            "name": "Demo Genesis Proposals",
            "description": "Plan-only genesis proposal classifications for coding agents.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://evolve/status",
            "name": "Demo Evolve Status",
            "description": "Paper-first builder, red-team, canary, calibration, promotion-plan, and rollback evidence.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://research/report",
            "name": "Demo Research Report",
            "description": "Paper-only hunt, edge, convergence, thesis, score, meta, and sharpen report.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://decision/stack",
            "name": "Demo Decision Stack",
            "description": "Paper-only lens, layer, and modifier decision stack for coding agents.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://immune/status",
            "name": "Demo Immune Status",
            "description": "Read-only paper immune breaker status.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://backtest/report",
            "name": "Demo Backtest Report",
            "description": "Read-only deterministic paper backtest report without PnL claims.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://evidence/bundle",
            "name": "Demo Evidence Bundle",
            "description": "Read-only hash-only evidence bundle from the bundled paper runtime.",
            "mimeType": "application/json",
        },
        {
            "uri": "zero://mcp/safety",
            "name": "MCP Safety Catalog",
            "description": "Read-only safety classification for every public MCP tool.",
            "mimeType": "application/json",
        },
    ]
    resources.extend(
        {
            "uri": str(resource["uri"]),
            "name": str(resource["name"]),
            "description": str(resource["description"]),
            "mimeType": "text/markdown",
        }
        for resource in DOC_RESOURCES
    )
    return resources


def read_resource(uri: str) -> str:
    if uri == "zero://paper/scenario":
        root = find_repo_root()
        if root is None:
            return json.dumps(EMBEDDED_SCENARIO, indent=2, sort_keys=True)
        return (root / "examples" / "paper-trading" / "scenario.json").read_text(encoding="utf-8")
    if uri == "zero://paper/results":
        return json.dumps(get_paper_results(), indent=2, sort_keys=True)
    if uri == "zero://runtime/status":
        return json.dumps(get_runtime_status(), indent=2, sort_keys=True)
    if uri == "zero://runtime/health":
        return json.dumps(get_health_status(), indent=2, sort_keys=True)
    if uri == "zero://runtime/parity":
        return json.dumps(get_runtime_parity(), indent=2, sort_keys=True)
    if uri == "zero://journal/tail":
        return json.dumps(get_journal_tail(), indent=2, sort_keys=True)
    if uri == "zero://rejections/audit":
        return json.dumps(get_rejection_audit(), indent=2, sort_keys=True)
    if uri == "zero://proof/demo":
        return json.dumps(get_proof_pack(), indent=2, sort_keys=True)
    if uri == "zero://proof/network":
        return json.dumps(get_network_proof_pack(), indent=2, sort_keys=True)
    if uri == "zero://memory/snapshot":
        return json.dumps(get_memory_snapshot(), indent=2, sort_keys=True)
    if uri == "zero://memory/stats":
        return json.dumps(get_memory_stats(), indent=2, sort_keys=True)
    if uri == "zero://genesis/proposals":
        return json.dumps(get_genesis_proposals(), indent=2, sort_keys=True)
    if uri == "zero://evolve/status":
        return json.dumps(get_evolve_status(), indent=2, sort_keys=True)
    if uri == "zero://research/report":
        return json.dumps(get_research_report(), indent=2, sort_keys=True)
    if uri == "zero://decision/stack":
        return json.dumps(get_decision_stack(), indent=2, sort_keys=True)
    if uri == "zero://immune/status":
        return json.dumps(get_immune_status(), indent=2, sort_keys=True)
    if uri == "zero://backtest/report":
        return json.dumps(get_backtest_report(), indent=2, sort_keys=True)
    if uri == "zero://evidence/bundle":
        return json.dumps(get_evidence_bundle(), indent=2, sort_keys=True)
    if uri == "zero://mcp/safety":
        return json.dumps(safety_catalog(), indent=2, sort_keys=True)
    for resource in DOC_RESOURCES:
        if uri == resource["uri"]:
            root = find_repo_root()
            if root is None:
                return str(resource["fallback"])
            return (root / str(resource["path"])).read_text(encoding="utf-8")
    raise KeyError(uri)


def resource_mime_type(uri: str) -> str:
    for resource in resource_definitions():
        if resource["uri"] == uri:
            return str(resource["mimeType"])
    raise KeyError(uri)


def text_content(payload: JsonMap) -> list[JsonMap]:
    return [{"type": "text", "text": json.dumps(payload, indent=2, sort_keys=True)}]


def result_response(request_id: Any, result: JsonMap) -> JsonMap:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def error_response(request_id: Any, code: int, message: str) -> JsonMap:
    return error_response_with_data(request_id, code, message, None)


def error_response_with_data(
    request_id: Any,
    code: int,
    message: str,
    data: JsonMap | None,
) -> JsonMap:
    error: JsonMap = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": error,
    }


def requested_protocol(params: JsonMap) -> str:
    version = str(params.get("protocolVersion") or DEFAULT_PROTOCOL_VERSION)
    if version in SUPPORTED_PROTOCOL_VERSIONS:
        return version
    return DEFAULT_PROTOCOL_VERSION


def safe_identifier(value: Any, *, max_length: int = 80) -> str:
    text = str(value or "")
    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_./:-")
    if not text:
        return ""
    if len(text) > max_length or any(char not in allowed for char in text):
        return "<redacted>"
    return text


def refusal_payload(
    *,
    method: Any,
    reason: str,
    tool_name: Any = "",
    uri: Any = "",
) -> JsonMap:
    return {
        "schema_version": MCP_REFUSAL_SCHEMA_VERSION,
        "safetyClass": READ_ONLY_SAFETY["safetyClass"],
        "riskDirection": READ_ONLY_SAFETY["riskDirection"],
        "paper_only": True,
        "canPlaceOrders": False,
        "canChangeRuntimeState": False,
        "canReadSecrets": False,
        "reason": reason,
        "requested_method": safe_identifier(method),
        "requested_tool": safe_identifier(tool_name),
        "requested_uri": safe_identifier(str(uri).split("?", 1)[0].split("#", 1)[0]),
        "allowed_surface": list(MCP_ALLOWED_SURFACE),
    }


def handle_request(request: JsonMap) -> JsonMap | None:
    method = str(request.get("method", ""))
    request_id = request.get("id")
    params = request.get("params") or {}
    if not isinstance(params, dict):
        return error_response(request_id, -32602, "params must be an object")

    if method == "initialize":
        return result_response(
            request_id,
            {
                "protocolVersion": requested_protocol(params),
                "capabilities": {
                    "tools": {"listChanged": False},
                    "resources": {"subscribe": False, "listChanged": False},
                },
                "serverInfo": {"name": SERVER_NAME, "version": server_version()},
            },
        )
    if method == "notifications/initialized":
        return None
    if method == "ping":
        return result_response(request_id, {})
    if method == "tools/list":
        return result_response(request_id, {"tools": tool_definitions()})
    if method == "tools/call":
        name = str(params.get("name", ""))
        tool = TOOLS.get(name)
        if tool is None:
            safe_name = safe_identifier(name)
            return error_response_with_data(
                request_id,
                -32602,
                f"unknown read-only ZERO tool: {safe_name}",
                refusal_payload(
                    method=method,
                    reason="tool_not_available_on_read_only_surface",
                    tool_name=name,
                ),
            )
        return result_response(request_id, {"content": text_content(tool()), "isError": False})
    if method == "resources/list":
        return result_response(request_id, {"resources": resource_definitions()})
    if method == "resources/read":
        uri = str(params.get("uri", ""))
        try:
            text = read_resource(uri)
            mime_type = resource_mime_type(uri)
        except KeyError:
            safe_uri = safe_identifier(uri.split("?", 1)[0].split("#", 1)[0])
            return error_response_with_data(
                request_id,
                -32602,
                f"unknown read-only ZERO resource: {safe_uri}",
                refusal_payload(
                    method=method,
                    reason="resource_not_available_on_read_only_surface",
                    uri=uri,
                ),
            )
        return result_response(
            request_id,
            {"contents": [{"uri": uri, "mimeType": mime_type, "text": text}]},
        )
    safe_method = safe_identifier(method)
    return error_response_with_data(
        request_id,
        -32601,
        f"method not found on read-only ZERO MCP surface: {safe_method}",
        refusal_payload(method=method, reason="method_not_available_on_read_only_surface"),
    )


def serve(stdin: TextIO = sys.stdin, stdout: TextIO = sys.stdout) -> int:
    for raw_line in stdin:
        line = raw_line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except json.JSONDecodeError as exc:
            print(json.dumps(error_response(None, -32700, str(exc))), file=stdout, flush=True)
            continue
        if not isinstance(request, dict):
            print(
                json.dumps(error_response(None, -32600, "request must be an object")), file=stdout
            )
            stdout.flush()
            continue
        response = handle_request(request)
        if response is None:
            continue
        print(json.dumps(response, separators=(",", ":")), file=stdout, flush=True)
    return 0


def smoke() -> int:
    tools = tool_definitions()
    resources = resource_definitions()
    forbidden = ("execute", "live", "order", "place", "approve", "wallet")
    names = [tool["name"] for tool in tools]
    if any(marker in name for name in names for marker in forbidden):
        raise RuntimeError(f"zero-mcp exposed a forbidden live execution tool: {names}")
    for tool in tools:
        if tool["safetyClass"] != "read_only_public":
            raise RuntimeError(f"{tool['name']} has unsafe safety class")
        if tool["canPlaceOrders"] or tool["canChangeRuntimeState"] or tool["canReadSecrets"]:
            raise RuntimeError(f"{tool['name']} is not read-only")
    proof = get_proof_pack()
    boundary = proof.get("claim_boundary", {})
    if boundary.get("live_trading_claimed") or boundary.get("paper_vs_live_correlation_claimed"):
        raise RuntimeError("demo proof pack must not claim live trading or paper/live correlation")
    network_proof = get_network_proof_pack()
    network_boundary = network_proof.get("claim_boundary", {})
    if (
        network_boundary.get("live_trading_claimed")
        or network_boundary.get("paper_vs_live_correlation_claimed")
        or network_proof.get("privacy", {}).get("contains_exchange_credentials")
        or network_proof.get("privacy", {}).get("contains_wallet_material")
    ):
        raise RuntimeError("network proof pack must remain public-safe and non-live-claiming")
    for name in names:
        payload = TOOLS[name]()
        if not isinstance(payload, dict):
            raise RuntimeError(f"{name} did not return an object")
    refusal_checks = [
        handle_request({"jsonrpc": "2.0", "id": "smoke-method", "method": "orders/place"}),
        handle_request(
            {
                "jsonrpc": "2.0",
                "id": "smoke-tool",
                "method": "tools/call",
                "params": {"name": "zero_execute_live", "arguments": {}},
            }
        ),
        handle_request(
            {
                "jsonrpc": "2.0",
                "id": "smoke-resource",
                "method": "resources/read",
                "params": {"uri": "zero://live/order?prompt=ignore-previous"},
            }
        ),
    ]
    for response in refusal_checks:
        if response is None:
            raise RuntimeError("MCP refusal smoke produced no response")
        error = response.get("error", {})
        refusal = error.get("data", {})
        if refusal.get("schema_version") != MCP_REFUSAL_SCHEMA_VERSION:
            raise RuntimeError("MCP refusal smoke did not return zero.mcp.refusal.v1")
        if refusal.get("canPlaceOrders") or refusal.get("canChangeRuntimeState"):
            raise RuntimeError("MCP refusal smoke exposed write capability")
    print(f"zero mcp smoke passed: {len(tools)} tools, {len(resources)} resources")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="ZERO read-only MCP server")
    parser.add_argument("--smoke", action="store_true", help="validate tool and resource wiring")
    args = parser.parse_args()
    if args.smoke:
        return smoke()
    return serve()


if __name__ == "__main__":
    raise SystemExit(main())
