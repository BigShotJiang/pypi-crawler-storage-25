from typing import Any

from kirin import interp
from kirin.dialects import ilist

from bloqade.qubit import stmts as qubit
from bloqade.pyqrack.reg import QubitState, PyQrackQubit, MeasurementResultValue
from bloqade.pyqrack.base import PyQrackInterpreter


@qubit.dialect.register(key="pyqrack")
class PyQrackMethods(interp.MethodTable):
    @interp.impl(qubit.New)
    def new_qubit(
        self, interp: PyQrackInterpreter, frame: interp.Frame, stmt: qubit.New
    ):
        (addr,) = interp.memory.allocate(1)
        qb = PyQrackQubit(addr, interp.memory.sim_reg, QubitState.Active)
        return (qb,)

    def _measure_qubit(self, qbit: PyQrackQubit, interp: PyQrackInterpreter):
        if qbit.is_active():
            m = MeasurementResultValue(bool(qbit.sim_reg.m(qbit.addr)))
        else:
            m = MeasurementResultValue(interp.loss_m_result)

        interp.set_global_measurement_id(m)
        return m

    @interp.impl(qubit.Measure)
    def measure_qubit_list(
        self,
        interp: PyQrackInterpreter,
        frame: interp.Frame,
        stmt: qubit.Measure,
    ):
        qubits: ilist.IList[PyQrackQubit, Any] = frame.get(stmt.qubits)
        result = ilist.IList([self._measure_qubit(qbit, interp) for qbit in qubits])
        return (result,)

    @interp.impl(qubit.Reset)
    def reset(self, interp: PyQrackInterpreter, frame: interp.Frame, stmt: qubit.Reset):
        qubits: ilist.IList[PyQrackQubit, Any] = frame.get(stmt.qubits)
        for qbit in qubits:
            if not qbit.is_active():
                continue

            m = qbit.sim_reg.m(qbit.addr)
            if m == MeasurementResultValue.One:
                qbit.sim_reg.x(qbit.addr)
