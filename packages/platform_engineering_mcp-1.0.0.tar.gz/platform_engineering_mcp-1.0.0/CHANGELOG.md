# 1.0.0 (2026-04-29)


### Bug Fixes

* copy README.md into Docker image so hatchling metadata build succeeds ([c53a559](https://github.com/polarpoint-io/platform-engineering-mcp/commit/c53a559d5edb1a6e71a827db9e858c98f2e4fe04))
* remove unused variables and imports (ruff F401/F841) ([fda2fd2](https://github.com/polarpoint-io/platform-engineering-mcp/commit/fda2fd2ab1eb9a524a8ebe35f06f7f204875dae8))


### Features

* add GitHub Actions CI/CD, Dockerfile, and multi-plugin Backstage annotations ([4611cb5](https://github.com/polarpoint-io/platform-engineering-mcp/commit/4611cb5c7be08b2e120a20afd02db4728deb23c3))
* initial platform-engineering-mcp — Backstage Snyk, ADO, SonarQube & Grafana annotation tools ([d2e6f38](https://github.com/polarpoint-io/platform-engineering-mcp/commit/d2e6f38445018dafc50b4a049ed3479c83415127))
