"""Tests for catalog-info.yaml annotation logic — all plugins."""

import pytest
from platform_engineering_mcp.tools.catalog import (
    # Snyk
    apply_snyk_annotations,
    check_existing_snyk_annotations,
    # ADO
    apply_ado_annotations,
    check_existing_ado_annotations,
    # SonarQube
    apply_sonarqube_annotations,
    check_existing_sonarqube_annotations,
    # Grafana
    apply_grafana_annotations,
    check_existing_grafana_annotations,
    # Generic
    create_catalog_yaml,
    check_all_annotations,
)

EXISTING_CATALOG = """\
apiVersion: backstage.io/v1alpha1
kind: Component
metadata:
  name: my-service
  description: My service
  annotations:
    some.other/annotation: "keep-me"
spec:
  type: service
  lifecycle: production
  owner: group:my-team
"""

CATALOG_NO_ANNOTATIONS = """\
apiVersion: backstage.io/v1alpha1
kind: Component
metadata:
  name: my-service
spec:
  type: service
  lifecycle: production
  owner: group:my-team
"""


# ═══════════════════════════════════════════════════════════════════════════════
# Snyk
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplySnykAnnotations:
    def test_adds_annotations_to_existing_file(self):
        result, changed = apply_snyk_annotations(
            EXISTING_CATALOG,
            snyk_org_id="org-123",
            snyk_project_id="proj-456",
        )
        assert changed is True
        assert "snyk.io/org-id" in result
        assert "org-123" in result
        assert "proj-456" in result
        assert "some.other/annotation" in result
        assert "keep-me" in result

    def test_no_change_when_values_match(self):
        first, _ = apply_snyk_annotations(EXISTING_CATALOG, snyk_org_id="org-123", snyk_project_id="proj-456")
        _, changed = apply_snyk_annotations(first, snyk_org_id="org-123", snyk_project_id="proj-456")
        assert changed is False

    def test_creates_annotations_section_when_missing(self):
        result, changed = apply_snyk_annotations(CATALOG_NO_ANNOTATIONS, snyk_org_id="org-abc", snyk_project_id="proj-xyz")
        assert changed is True
        assert "snyk.io/org-id" in result

    def test_includes_org_name_when_provided(self):
        result, _ = apply_snyk_annotations(EXISTING_CATALOG, snyk_org_id="o", snyk_project_id="p", snyk_org_name="my-snyk-org")
        assert "snyk.io/org-name" in result
        assert "my-snyk-org" in result

    def test_check_detects_annotations(self):
        content, _ = apply_snyk_annotations(EXISTING_CATALOG, snyk_org_id="org-123", snyk_project_id="proj-456")
        result = check_existing_snyk_annotations(content)
        assert result["snyk_org_id"] == "org-123"
        assert result["snyk_project_id"] == "proj-456"
        assert result["has_snyk_annotations"] is True

    def test_check_no_annotations_returns_false(self):
        result = check_existing_snyk_annotations(CATALOG_NO_ANNOTATIONS)
        assert result["has_snyk_annotations"] is False


# ═══════════════════════════════════════════════════════════════════════════════
# Azure DevOps plugin
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplyAdoAnnotations:
    def test_adds_project_annotation(self):
        result, changed = apply_ado_annotations(EXISTING_CATALOG, ado_project="my-project")
        assert changed is True
        assert "dev.azure.com/project" in result
        assert "my-project" in result

    def test_adds_all_ado_annotations(self):
        result, changed = apply_ado_annotations(
            EXISTING_CATALOG,
            ado_project="my-project",
            ado_repo="my-project/my-repo",
            ado_build_definition="my-pipeline",
            ado_host_org="dev.azure.com/my-org",
        )
        assert changed is True
        assert "dev.azure.com/project-repo" in result
        assert "dev.azure.com/build-definition" in result
        assert "dev.azure.com/host-org" in result

    def test_preserves_existing_annotations(self):
        result, _ = apply_ado_annotations(EXISTING_CATALOG, ado_project="p")
        assert "some.other/annotation" in result
        assert "keep-me" in result

    def test_no_change_when_values_match(self):
        first, _ = apply_ado_annotations(EXISTING_CATALOG, ado_project="p", ado_repo="p/r")
        _, changed = apply_ado_annotations(first, ado_project="p", ado_repo="p/r")
        assert changed is False

    def test_check_detects_ado_annotations(self):
        content, _ = apply_ado_annotations(EXISTING_CATALOG, ado_project="my-project", ado_repo="my-project/my-repo")
        result = check_existing_ado_annotations(content)
        assert result["ado_project"] == "my-project"
        assert result["ado_project_repo"] == "my-project/my-repo"
        assert result["has_ado_annotations"] is True

    def test_check_no_annotations(self):
        result = check_existing_ado_annotations(CATALOG_NO_ANNOTATIONS)
        assert result["has_ado_annotations"] is False


# ═══════════════════════════════════════════════════════════════════════════════
# SonarQube
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplySonarqubeAnnotations:
    def test_adds_project_key(self):
        result, changed = apply_sonarqube_annotations(EXISTING_CATALOG, project_key="my-org_my-repo")
        assert changed is True
        assert "sonarqube.org/project-key" in result
        assert "my-org_my-repo" in result

    def test_supports_instance_prefix(self):
        result, changed = apply_sonarqube_annotations(EXISTING_CATALOG, project_key="instance-name/project-key")
        assert changed is True
        assert "instance-name/project-key" in result

    def test_no_change_when_value_matches(self):
        first, _ = apply_sonarqube_annotations(EXISTING_CATALOG, project_key="my-key")
        _, changed = apply_sonarqube_annotations(first, project_key="my-key")
        assert changed is False

    def test_preserves_existing_annotations(self):
        result, _ = apply_sonarqube_annotations(EXISTING_CATALOG, project_key="key")
        assert "some.other/annotation" in result

    def test_check_detects_annotation(self):
        content, _ = apply_sonarqube_annotations(EXISTING_CATALOG, project_key="my-key")
        result = check_existing_sonarqube_annotations(content)
        assert result["project_key"] == "my-key"
        assert result["has_sonarqube_annotations"] is True

    def test_check_no_annotation(self):
        result = check_existing_sonarqube_annotations(CATALOG_NO_ANNOTATIONS)
        assert result["has_sonarqube_annotations"] is False


# ═══════════════════════════════════════════════════════════════════════════════
# Grafana
# ═══════════════════════════════════════════════════════════════════════════════

class TestApplyGrafanaAnnotations:
    def test_adds_dashboard_selector(self):
        result, changed = apply_grafana_annotations(EXISTING_CATALOG, dashboard_selector="tag:my-service")
        assert changed is True
        assert "grafana/dashboard-selector" in result
        assert "tag:my-service" in result

    def test_adds_overview_dashboard(self):
        url = "https://grafana.example.com/d/abc123/my-dashboard"
        result, changed = apply_grafana_annotations(EXISTING_CATALOG, overview_dashboard=url)
        assert changed is True
        assert "grafana/overview-dashboard" in result
        assert url in result

    def test_adds_alert_label_selector(self):
        result, changed = apply_grafana_annotations(EXISTING_CATALOG, alert_label_selector="service=my-service")
        assert changed is True
        assert "grafana/alert-label-selector" in result

    def test_adds_all_grafana_annotations(self):
        result, changed = apply_grafana_annotations(
            EXISTING_CATALOG,
            dashboard_selector="tag:my-service",
            overview_dashboard="https://grafana.example.com/d/abc/dash",
            alert_label_selector="service=my-service",
        )
        assert changed is True
        assert "grafana/dashboard-selector" in result
        assert "grafana/overview-dashboard" in result
        assert "grafana/alert-label-selector" in result

    def test_raises_when_no_annotation_provided(self):
        with pytest.raises(ValueError, match="At least one"):
            apply_grafana_annotations(EXISTING_CATALOG)

    def test_no_change_when_values_match(self):
        first, _ = apply_grafana_annotations(EXISTING_CATALOG, dashboard_selector="tag:svc")
        _, changed = apply_grafana_annotations(first, dashboard_selector="tag:svc")
        assert changed is False

    def test_check_detects_annotations(self):
        content, _ = apply_grafana_annotations(EXISTING_CATALOG, dashboard_selector="tag:svc")
        result = check_existing_grafana_annotations(content)
        assert result["dashboard_selector"] == "tag:svc"
        assert result["has_grafana_annotations"] is True

    def test_check_no_annotations(self):
        result = check_existing_grafana_annotations(CATALOG_NO_ANNOTATIONS)
        assert result["has_grafana_annotations"] is False


# ═══════════════════════════════════════════════════════════════════════════════
# create_catalog_yaml — multi-plugin
# ═══════════════════════════════════════════════════════════════════════════════

class TestCreateCatalogYaml:
    def test_creates_with_snyk_only(self):
        content = create_catalog_yaml("svc", snyk_org_id="o", snyk_project_id="p")
        assert "backstage.io/v1alpha1" in content
        assert "snyk.io/org-id" in content

    def test_creates_with_all_plugins(self):
        content = create_catalog_yaml(
            "svc",
            snyk_org_id="o",
            snyk_project_id="p",
            ado_project="my-project",
            ado_repo="my-project/my-repo",
            sonarqube_project_key="sq-key",
            grafana_dashboard_selector="tag:svc",
            owner="my-team",
            lifecycle="experimental",
        )
        assert "snyk.io/org-id" in content
        assert "dev.azure.com/project" in content
        assert "sonarqube.org/project-key" in content
        assert "grafana/dashboard-selector" in content
        assert "my-team" in content

    def test_creates_minimal_without_annotations(self):
        content = create_catalog_yaml("my-svc")
        assert "my-svc" in content
        assert "backstage.io/v1alpha1" in content


# ═══════════════════════════════════════════════════════════════════════════════
# check_all_annotations
# ═══════════════════════════════════════════════════════════════════════════════

class TestCheckAllAnnotations:
    def test_returns_all_plugin_summaries(self):
        content, _ = apply_snyk_annotations(EXISTING_CATALOG, snyk_org_id="o", snyk_project_id="p")
        content, _ = apply_ado_annotations(content, ado_project="proj")
        result = check_all_annotations(content)
        assert "snyk" in result
        assert "ado" in result
        assert "sonarqube" in result
        assert "grafana" in result
        assert result["snyk"]["has_snyk_annotations"] is True
        assert result["ado"]["has_ado_annotations"] is True
        assert result["sonarqube"]["has_sonarqube_annotations"] is False
        assert result["grafana"]["has_grafana_annotations"] is False
