"""
Platform Engineering MCP Server

Exposes tools for:
  - Backstage catalog-info.yaml annotation (Snyk, Azure DevOps plugin, SonarQube, Grafana)
  - Snyk project discovery
  - SonarQube project discovery
  - Grafana dashboard discovery
"""

from __future__ import annotations

import logging
from typing import Optional

from mcp.server.fastmcp import FastMCP

from platform_engineering_mcp.config import settings
from platform_engineering_mcp.tools.annotate import (
    annotate_repo,
    annotate_repo_auto_snyk,
    annotate_repo_ado,
    annotate_repo_sonarqube,
    annotate_repo_grafana,
)
from platform_engineering_mcp.tools.snyk import (
    tool_snyk_find_project_for_repo,
    tool_snyk_list_orgs,
    tool_snyk_list_projects,
)
from platform_engineering_mcp.tools.sonarqube import (
    tool_sonarqube_search_projects,
    tool_sonarqube_get_project,
)
from platform_engineering_mcp.tools.grafana import (
    tool_grafana_search_dashboards,
    tool_grafana_list_tags,
    tool_grafana_get_dashboard,
)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

# ── Server ────────────────────────────────────────────────────────────────────
mcp = FastMCP(
    name="platform-engineering-mcp",
    instructions=(
        "Platform engineering toolbox for Backstage catalog annotation. "
        "Use snyk_* tools to discover Snyk organisations and projects. "
        "Use sonarqube_* tools to find SonarQube project keys. "
        "Use grafana_* tools to discover dashboards and tags. "
        "Use backstage_* tools to write plugin annotations into repository "
        "catalog-info.yaml files and raise pull requests."
    ),
)


# ═══════════════════════════════════════════════════════════════════════════════
# Snyk tools
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool(
    description=(
        "List all Snyk organisations accessible to the configured token. "
        "Returns org IDs, names, and slugs. Use org IDs with other snyk_* tools."
    )
)
async def snyk_list_orgs(
    snyk_token: Optional[str] = None,
) -> dict:
    """
    List all Snyk orgs accessible to the token.

    Args:
        snyk_token: Override the SNYK_TOKEN env var for this call.
    """
    return await tool_snyk_list_orgs(snyk_token=snyk_token)


@mcp.tool(
    description=(
        "List Snyk projects within a specific Snyk organisation. "
        "Optionally filter by a repo name substring to narrow results. "
        "Returns project IDs needed for catalog-info.yaml annotation."
    )
)
async def snyk_list_projects(
    org_id: str,
    repo_filter: Optional[str] = None,
    snyk_token: Optional[str] = None,
) -> dict:
    """
    List projects in a Snyk org.

    Args:
        org_id:      Snyk organisation ID (UUID).
        repo_filter: Optional substring to filter project names/URLs by repo name.
        snyk_token:  Override the SNYK_TOKEN env var for this call.
    """
    return await tool_snyk_list_projects(
        org_id=org_id, repo_filter=repo_filter, snyk_token=snyk_token
    )


@mcp.tool(
    description=(
        "Find Snyk projects that correspond to a given repository URL. "
        "Searches across all accessible Snyk orgs (or a specific one if org_id supplied). "
        "Returns matching project IDs and org IDs to use in backstage_annotate_repo."
    )
)
async def snyk_find_project_for_repo(
    repo_url: str,
    org_id: Optional[str] = None,
    snyk_token: Optional[str] = None,
) -> dict:
    """
    Find Snyk projects matching a repository URL.

    Args:
        repo_url:   Full URL of the repository (e.g. https://github.com/org/repo).
        org_id:     Optional Snyk org ID to restrict the search.
        snyk_token: Override the SNYK_TOKEN env var for this call.
    """
    return await tool_snyk_find_project_for_repo(
        repo_url=repo_url, org_id=org_id, snyk_token=snyk_token
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Backstage catalog tools
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool(
    description=(
        "Annotate a repository's catalog-info.yaml with Snyk org and project IDs so that "
        "Backstage can display the component's security posture. "
        "If catalog-info.yaml does not exist it will be created. "
        "Changes are delivered via a pull request — nothing is merged automatically. "
        "Supports GitHub and Azure DevOps. "
        "Provider must be 'github' or 'azure_devops'. "
        "For GitHub, repo format is 'owner/repo'. "
        "For Azure DevOps, repo format is 'project/repo'."
    )
)
async def backstage_annotate_repo(
    repo: str,
    provider: str,
    snyk_org_id: str,
    snyk_project_id: str,
    snyk_org_name: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    description: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> dict:
    """
    Add or update Snyk annotations in a repo's catalog-info.yaml and open a PR.

    Args:
        repo:             Repo identifier. GitHub: 'owner/repo'. Azure DevOps: 'project/repo'.
        provider:         VCS provider — 'github' or 'azure_devops'.
        snyk_org_id:      Snyk organisation UUID.
        snyk_project_id:  Snyk project UUID.
        snyk_org_name:    Optional human-readable Snyk org name for the annotation.
        vcs_token:        Override the VCS token env var (GITHUB_TOKEN / AZURE_DEVOPS_PAT).
        component_name:   Name for the Backstage component (used only when creating a new file).
        description:      Component description (used only when creating a new file).
        owner:            Backstage owner group (default: 'platform-engineering').
        dry_run:          If True, compute changes but do not push or open a PR.
    """
    result = await annotate_repo(
        repo=repo,
        provider=provider,
        snyk_org_id=snyk_org_id,
        snyk_project_id=snyk_project_id,
        snyk_org_name=snyk_org_name,
        vcs_token=vcs_token,
        component_name=component_name,
        description=description,
        owner=owner,
        dry_run=dry_run,
    )
    return result.model_dump()


@mcp.tool(
    description=(
        "Auto-discover the Snyk project for a repository from the Snyk API, then annotate "
        "catalog-info.yaml and open a pull request — one call does everything. "
        "If zero or multiple Snyk projects match the repo URL, the tool will return an error "
        "with instructions to use backstage_annotate_repo with an explicit snyk_project_id instead. "
        "Supports GitHub and Azure DevOps."
    )
)
async def backstage_annotate_repo_auto(
    repo: str,
    repo_url: str,
    provider: str,
    snyk_org_id: Optional[str] = None,
    snyk_token: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> dict:
    """
    Fully automatic annotation: look up Snyk project from repo URL, then annotate and PR.

    Args:
        repo:           Repo identifier. GitHub: 'owner/repo'. Azure DevOps: 'project/repo'.
        repo_url:       Full repository URL for Snyk project matching
                        (e.g. https://github.com/org/repo).
        provider:       VCS provider — 'github' or 'azure_devops'.
        snyk_org_id:    Optional Snyk org ID to scope the search.
        snyk_token:     Override the SNYK_TOKEN env var for this call.
        vcs_token:      Override the VCS token env var for this call.
        component_name: Backstage component name (used only when creating a new catalog file).
        owner:          Backstage owner group (default: 'platform-engineering').
        dry_run:        If True, compute changes but do not push or open a PR.
    """
    result = await annotate_repo_auto_snyk(
        repo=repo,
        repo_url=repo_url,
        provider=provider,
        snyk_org_id=snyk_org_id,
        snyk_token=snyk_token,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )
    return result.model_dump()


# ═══════════════════════════════════════════════════════════════════════════════
# SonarQube tools
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool(
    description=(
        "Search for projects in a SonarQube instance. "
        "Returns project keys needed for the sonarqube.org/project-key Backstage annotation. "
        "Optionally filter by a name or key substring."
    )
)
async def sonarqube_search_projects(
    sonarqube_url: str,
    sonarqube_token: str,
    query: Optional[str] = None,
) -> dict:
    """
    Search SonarQube projects to find the project key for catalog annotation.

    Args:
        sonarqube_url:   Base URL of your SonarQube instance, e.g. https://sonarqube.example.com
        sonarqube_token: SonarQube user or service-account token.
        query:           Optional search string to filter by project name or key.
    """
    return await tool_sonarqube_search_projects(sonarqube_url, sonarqube_token, query=query)


@mcp.tool(
    description=(
        "Verify that a SonarQube project key exists before using it in a catalog annotation. "
        "Returns the project's name, key, and qualifier."
    )
)
async def sonarqube_get_project(
    sonarqube_url: str,
    sonarqube_token: str,
    project_key: str,
) -> dict:
    """
    Fetch a single SonarQube project by its key to confirm it exists.

    Args:
        sonarqube_url:   Base URL of your SonarQube instance.
        sonarqube_token: SonarQube user or service-account token.
        project_key:     The SonarQube project key (e.g. 'my-org_my-repo').
    """
    return await tool_sonarqube_get_project(sonarqube_url, sonarqube_token, project_key)


# ═══════════════════════════════════════════════════════════════════════════════
# Grafana tools
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool(
    description=(
        "Search Grafana dashboards by name or tag. "
        "Returns dashboard UIDs and full URLs useful for building Backstage Grafana annotations. "
        "Use the tag parameter to find dashboards with a specific tag selector."
    )
)
async def grafana_search_dashboards(
    grafana_url: str,
    grafana_token: str,
    query: Optional[str] = None,
    tag: Optional[str] = None,
) -> dict:
    """
    Search Grafana dashboards.

    Args:
        grafana_url:   Base URL of your Grafana instance, e.g. https://grafana.example.com
        grafana_token: Grafana API key or service account token.
        query:         Optional search string to filter dashboards by title.
        tag:           Optional tag to filter dashboards (maps to grafana/dashboard-selector).
    """
    return await tool_grafana_search_dashboards(grafana_url, grafana_token, query=query, tag=tag)


@mcp.tool(
    description=(
        "List all dashboard tags in a Grafana instance. "
        "Use these tags to build the grafana/dashboard-selector annotation value, "
        "e.g. 'tag:my-service' shows all dashboards tagged with 'my-service'."
    )
)
async def grafana_list_tags(
    grafana_url: str,
    grafana_token: str,
) -> dict:
    """
    List all dashboard tags in Grafana.

    Args:
        grafana_url:   Base URL of your Grafana instance.
        grafana_token: Grafana API key or service account token.
    """
    return await tool_grafana_list_tags(grafana_url, grafana_token)


@mcp.tool(
    description=(
        "Fetch a specific Grafana dashboard by its UID. "
        "Returns the full dashboard URL to use as the grafana/overview-dashboard annotation."
    )
)
async def grafana_get_dashboard(
    grafana_url: str,
    grafana_token: str,
    uid: str,
) -> dict:
    """
    Get a Grafana dashboard by UID.

    Args:
        grafana_url:   Base URL of your Grafana instance.
        grafana_token: Grafana API key or service account token.
        uid:           The dashboard UID (visible in the dashboard URL).
    """
    return await tool_grafana_get_dashboard(grafana_url, grafana_token, uid)


# ═══════════════════════════════════════════════════════════════════════════════
# Backstage catalog tools — new plugins
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool(
    description=(
        "Annotate a repository's catalog-info.yaml with Azure DevOps Backstage plugin annotations "
        "(dev.azure.com/project, dev.azure.com/project-repo, etc.) and open a pull request. "
        "This enables the Backstage Azure DevOps plugin to display pipelines, pull requests, "
        "and readme content for the component. "
        "Provider must be 'github' or 'azure_devops'. "
        "For GitHub, repo format is 'owner/repo'. "
        "For Azure DevOps, repo format is 'project/repo'."
    )
)
async def backstage_annotate_ado_plugin(
    repo: str,
    provider: str,
    ado_project: str,
    ado_repo: Optional[str] = None,
    ado_build_definition: Optional[str] = None,
    ado_host_org: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> dict:
    """
    Add Backstage Azure DevOps plugin annotations to catalog-info.yaml and open a PR.

    Args:
        repo:                 Repo identifier. GitHub: 'owner/repo'. Azure DevOps: 'project/repo'.
        provider:             VCS provider — 'github' or 'azure_devops'.
        ado_project:          Azure DevOps project name → dev.azure.com/project.
        ado_repo:             'project/repo-name' → dev.azure.com/project-repo (optional).
        ado_build_definition: Build pipeline name or ID → dev.azure.com/build-definition (optional).
        ado_host_org:         'host/org' for multi-org setups → dev.azure.com/host-org (optional).
        vcs_token:            Override the VCS token env var.
        component_name:       Backstage component name (used only when creating a new file).
        owner:                Backstage owner group (default: 'platform-engineering').
        dry_run:              If True, compute changes but do not push or open a PR.
    """
    result = await annotate_repo_ado(
        repo=repo,
        provider=provider,
        ado_project=ado_project,
        ado_repo=ado_repo,
        ado_build_definition=ado_build_definition,
        ado_host_org=ado_host_org,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )
    return result.model_dump()


@mcp.tool(
    description=(
        "Annotate a repository's catalog-info.yaml with the SonarQube project key annotation "
        "(sonarqube.org/project-key) and open a pull request. "
        "This enables the Backstage SonarQube plugin to display code quality metrics. "
        "Use sonarqube_search_projects to find the right project key first. "
        "Provider must be 'github' or 'azure_devops'."
    )
)
async def backstage_annotate_sonarqube(
    repo: str,
    provider: str,
    sonarqube_project_key: str,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> dict:
    """
    Add SonarQube annotation to catalog-info.yaml and open a PR.

    Args:
        repo:                   Repo identifier. GitHub: 'owner/repo'. Azure DevOps: 'project/repo'.
        provider:               VCS provider — 'github' or 'azure_devops'.
        sonarqube_project_key:  SonarQube project key, optionally prefixed with instance name:
                                'instance-name/project-key' or just 'project-key' for default instance.
        vcs_token:              Override the VCS token env var.
        component_name:         Backstage component name (used only when creating a new file).
        owner:                  Backstage owner group (default: 'platform-engineering').
        dry_run:                If True, compute changes but do not push or open a PR.
    """
    result = await annotate_repo_sonarqube(
        repo=repo,
        provider=provider,
        sonarqube_project_key=sonarqube_project_key,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )
    return result.model_dump()


@mcp.tool(
    description=(
        "Annotate a repository's catalog-info.yaml with Grafana plugin annotations "
        "(grafana/dashboard-selector, grafana/overview-dashboard, grafana/alert-label-selector) "
        "and open a pull request. "
        "This enables the Backstage Grafana plugin to surface dashboards and alerts for the component. "
        "At least one of dashboard_selector, overview_dashboard, or alert_label_selector is required. "
        "Use grafana_list_tags and grafana_search_dashboards to discover the right values first. "
        "Provider must be 'github' or 'azure_devops'."
    )
)
async def backstage_annotate_grafana(
    repo: str,
    provider: str,
    dashboard_selector: Optional[str] = None,
    overview_dashboard: Optional[str] = None,
    alert_label_selector: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> dict:
    """
    Add Grafana plugin annotations to catalog-info.yaml and open a PR.

    Args:
        repo:                  Repo identifier. GitHub: 'owner/repo'. Azure DevOps: 'project/repo'.
        provider:              VCS provider — 'github' or 'azure_devops'.
        dashboard_selector:    Grafana tag selector → grafana/dashboard-selector
                               e.g. 'tag:my-service' shows dashboards tagged 'my-service'.
        overview_dashboard:    Full Grafana dashboard URL → grafana/overview-dashboard.
        alert_label_selector:  Grafana label selector → grafana/alert-label-selector
                               e.g. 'service=my-service'.
        vcs_token:             Override the VCS token env var.
        component_name:        Backstage component name (used only when creating a new file).
        owner:                 Backstage owner group (default: 'platform-engineering').
        dry_run:               If True, compute changes but do not push or open a PR.
    """
    result = await annotate_repo_grafana(
        repo=repo,
        provider=provider,
        dashboard_selector=dashboard_selector,
        overview_dashboard=overview_dashboard,
        alert_label_selector=alert_label_selector,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )
    return result.model_dump()


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
