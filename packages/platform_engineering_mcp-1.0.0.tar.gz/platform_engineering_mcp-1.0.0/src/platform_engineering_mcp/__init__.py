"""Platform Engineering MCP — Backstage catalog annotation & Snyk integration."""

__version__ = "0.1.0"
