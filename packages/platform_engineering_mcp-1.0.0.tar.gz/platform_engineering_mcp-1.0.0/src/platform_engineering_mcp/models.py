"""Shared data models."""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class VCSProvider(str, Enum):
    GITHUB = "github"
    AZURE_DEVOPS = "azure_devops"


class SnykOrg(BaseModel):
    id: str
    name: str
    slug: str


class SnykProject(BaseModel):
    id: str
    name: str
    org_id: str
    org_name: str
    target_reference: Optional[str] = None
    # The remote URL of the repo this project was imported from
    remote_url: Optional[str] = None


class AnnotationResult(BaseModel):
    repo: str
    provider: VCSProvider
    action: str  # "updated" | "created" | "skipped" | "error"
    pr_url: Optional[str] = None
    branch: Optional[str] = None
    message: str
    snyk_org_id: Optional[str] = None
    snyk_project_id: Optional[str] = None


class CatalogEntity(BaseModel):
    """Minimal representation of a Backstage catalog-info.yaml entity."""

    api_version: str = Field(default="backstage.io/v1alpha1", alias="apiVersion")
    kind: str = "Component"
    metadata: dict = Field(default_factory=dict)
    spec: dict = Field(default_factory=dict)

    model_config = {"populate_by_name": True}
