"""Configuration loaded from environment / .env file."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Snyk
    snyk_token: str = ""
    snyk_org_id: str = ""  # optional default org

    # Azure DevOps
    azure_devops_pat: str = ""
    azure_devops_org_url: str = ""  # e.g. https://dev.azure.com/my-org

    # GitHub
    github_token: str = ""

    # General
    log_level: str = "INFO"


settings = Settings()
