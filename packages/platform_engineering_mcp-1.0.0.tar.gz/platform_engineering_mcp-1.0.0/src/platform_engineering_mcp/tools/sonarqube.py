"""SonarQube Web API client and MCP tool handlers."""

from __future__ import annotations

import logging
from typing import Optional
import httpx

logger = logging.getLogger(__name__)


def _auth(token: str) -> tuple[str, str]:
    """SonarQube uses HTTP Basic auth with the token as the username, empty password."""
    return (token, "")


# ── Project helpers ────────────────────────────────────────────────────────────

async def search_projects(
    sonarqube_url: str,
    token: str,
    query: Optional[str] = None,
    page_size: int = 100,
) -> list[dict]:
    """
    Search SonarQube projects via the components/search API.

    Returns a list of dicts with keys: key, name, qualifier, visibility.
    """
    base = sonarqube_url.rstrip("/")
    projects: list[dict] = []
    page = 1

    async with httpx.AsyncClient(timeout=30) as client:
        while True:
            params: dict = {
                "qualifiers": "TRK",  # TRK = project
                "ps": page_size,
                "p": page,
            }
            if query:
                params["q"] = query

            resp = await client.get(
                f"{base}/api/components/search",
                auth=_auth(token),
                params=params,
            )
            resp.raise_for_status()
            body = resp.json()

            components = body.get("components", [])
            projects.extend(components)

            paging = body.get("paging", {})
            total = paging.get("total", 0)
            if len(projects) >= total or not components:
                break
            page += 1

    return projects


async def get_project(
    sonarqube_url: str,
    token: str,
    project_key: str,
) -> Optional[dict]:
    """Fetch a single SonarQube project by its key."""
    base = sonarqube_url.rstrip("/")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{base}/api/components/show",
            auth=_auth(token),
            params={"component": project_key},
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json().get("component")


# ── MCP tool handlers ──────────────────────────────────────────────────────────

async def tool_sonarqube_search_projects(
    sonarqube_url: str,
    sonarqube_token: str,
    query: Optional[str] = None,
) -> dict:
    """MCP tool: search for SonarQube projects, optionally filtered by name/key."""
    try:
        projects = await search_projects(sonarqube_url, sonarqube_token, query=query)
        return {
            "projects": [
                {"key": p.get("key"), "name": p.get("name"), "qualifier": p.get("qualifier")}
                for p in projects
            ],
            "count": len(projects),
        }
    except httpx.HTTPStatusError as e:
        return {"error": f"SonarQube API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}


async def tool_sonarqube_get_project(
    sonarqube_url: str,
    sonarqube_token: str,
    project_key: str,
) -> dict:
    """MCP tool: fetch a single SonarQube project by key to verify it exists."""
    try:
        project = await get_project(sonarqube_url, sonarqube_token, project_key)
        if project is None:
            return {"error": f"Project '{project_key}' not found in SonarQube at {sonarqube_url}"}
        return {"project": project}
    except httpx.HTTPStatusError as e:
        return {"error": f"SonarQube API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}
