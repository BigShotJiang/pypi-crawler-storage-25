"""Grafana HTTP API client and MCP tool handlers."""

from __future__ import annotations

import logging
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


def _auth_headers(token: str) -> dict:
    """Grafana supports both API keys (Bearer) and service account tokens."""
    return {"Authorization": f"Bearer {token}"}


# ── Dashboard helpers ──────────────────────────────────────────────────────────

async def search_dashboards(
    grafana_url: str,
    token: str,
    query: Optional[str] = None,
    tag: Optional[str] = None,
    limit: int = 100,
) -> list[dict]:
    """
    Search Grafana dashboards via the search API.

    Returns a list of dicts with: uid, title, url, tags, folderTitle.
    """
    base = grafana_url.rstrip("/")
    params: dict = {"type": "dash-db", "limit": limit}
    if query:
        params["query"] = query
    if tag:
        params["tag"] = tag

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{base}/api/search",
            headers=_auth_headers(token),
            params=params,
        )
        resp.raise_for_status()
        results = resp.json()

    return [
        {
            "uid": d.get("uid"),
            "title": d.get("title"),
            "url": f"{grafana_url.rstrip('/')}{d.get('url', '')}",
            "tags": d.get("tags", []),
            "folder": d.get("folderTitle", ""),
        }
        for d in results
    ]


async def list_dashboard_tags(grafana_url: str, token: str) -> list[str]:
    """Return all tags used across dashboards in this Grafana instance."""
    base = grafana_url.rstrip("/")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{base}/api/dashboards/tags",
            headers=_auth_headers(token),
        )
        resp.raise_for_status()
        return [t["term"] for t in resp.json()]


async def get_dashboard_by_uid(grafana_url: str, token: str, uid: str) -> Optional[dict]:
    """Fetch a dashboard by UID and return its metadata."""
    base = grafana_url.rstrip("/")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{base}/api/dashboards/uid/{uid}",
            headers=_auth_headers(token),
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        data = resp.json()
        meta = data.get("meta", {})
        dashboard = data.get("dashboard", {})
        return {
            "uid": dashboard.get("uid"),
            "title": dashboard.get("title"),
            "url": f"{grafana_url.rstrip('/')}{meta.get('url', '')}",
            "tags": dashboard.get("tags", []),
            "folder": meta.get("folderTitle", ""),
        }


# ── Alert helpers ──────────────────────────────────────────────────────────────

async def list_alert_rules(
    grafana_url: str,
    token: str,
    label_filter: Optional[str] = None,
) -> list[dict]:
    """
    List Grafana Alerting rules (Unified Alerting / Grafana 8+).

    label_filter is an optional label selector string used to filter results locally,
    e.g. "service=my-service".
    """
    base = grafana_url.rstrip("/")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{base}/api/v1/provisioning/alert-rules",
            headers=_auth_headers(token),
        )
        resp.raise_for_status()
        rules = resp.json()

    results = []
    for rule in rules:
        labels = rule.get("labels", {})
        results.append({
            "uid": rule.get("uid"),
            "title": rule.get("title"),
            "labels": labels,
            "folder_uid": rule.get("folderUID"),
        })

    if label_filter:
        # Parse "key=value" pairs and filter
        try:
            kv_pairs = dict(pair.split("=", 1) for pair in label_filter.split(",") if "=" in pair)
            results = [
                r for r in results
                if all(r["labels"].get(k) == v for k, v in kv_pairs.items())
            ]
        except Exception:
            logger.warning("Could not parse label_filter %r — returning all rules", label_filter)

    return results


# ── MCP tool handlers ──────────────────────────────────────────────────────────

async def tool_grafana_search_dashboards(
    grafana_url: str,
    grafana_token: str,
    query: Optional[str] = None,
    tag: Optional[str] = None,
) -> dict:
    """MCP tool: search Grafana dashboards by name or tag."""
    try:
        dashboards = await search_dashboards(grafana_url, grafana_token, query=query, tag=tag)
        return {"dashboards": dashboards, "count": len(dashboards)}
    except httpx.HTTPStatusError as e:
        return {"error": f"Grafana API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}


async def tool_grafana_list_tags(
    grafana_url: str,
    grafana_token: str,
) -> dict:
    """MCP tool: list all dashboard tags in a Grafana instance — useful for building dashboard selectors."""
    try:
        tags = await list_dashboard_tags(grafana_url, grafana_token)
        return {"tags": tags, "count": len(tags)}
    except httpx.HTTPStatusError as e:
        return {"error": f"Grafana API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}


async def tool_grafana_get_dashboard(
    grafana_url: str,
    grafana_token: str,
    uid: str,
) -> dict:
    """MCP tool: fetch a Grafana dashboard by UID."""
    try:
        dashboard = await get_dashboard_by_uid(grafana_url, grafana_token, uid)
        if dashboard is None:
            return {"error": f"Dashboard '{uid}' not found in Grafana at {grafana_url}"}
        return {"dashboard": dashboard}
    except httpx.HTTPStatusError as e:
        return {"error": f"Grafana API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}
