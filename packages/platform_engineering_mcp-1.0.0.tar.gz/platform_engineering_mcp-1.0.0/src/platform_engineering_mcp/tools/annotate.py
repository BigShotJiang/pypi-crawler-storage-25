"""
High-level orchestration: discover plugin metadata → update / create catalog-info.yaml → open PR.
"""

from __future__ import annotations

import logging
import re
from typing import Optional

from platform_engineering_mcp.models import AnnotationResult, VCSProvider
from platform_engineering_mcp.tools import snyk as snyk_tools
from platform_engineering_mcp.tools.catalog import (
    apply_snyk_annotations,
    apply_ado_annotations,
    apply_sonarqube_annotations,
    apply_grafana_annotations,
    check_existing_snyk_annotations,
    check_existing_ado_annotations,
    check_existing_sonarqube_annotations,
    check_existing_grafana_annotations,
    create_catalog_yaml,
)
from platform_engineering_mcp.tools.vcs.base import VCSAdapter
from platform_engineering_mcp.tools.vcs.azure_devops import AzureDevOpsAdapter
from platform_engineering_mcp.tools.vcs.github import GitHubAdapter

logger = logging.getLogger(__name__)

BRANCH_PREFIX = "platform-eng/snyk-annotations"


def _safe_branch_name(repo: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_\-]", "-", repo.split("/")[-1])
    return f"{BRANCH_PREFIX}-{slug}"


def _get_adapter(provider: str, token: str | None = None) -> VCSAdapter:
    if provider == VCSProvider.GITHUB:
        return GitHubAdapter(token=token)
    elif provider == VCSProvider.AZURE_DEVOPS:
        return AzureDevOpsAdapter(pat=token)
    else:
        raise ValueError(f"Unsupported VCS provider: {provider!r}. Use 'github' or 'azure_devops'.")


async def annotate_repo(
    repo: str,
    provider: str,
    snyk_org_id: str,
    snyk_project_id: str,
    snyk_org_name: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    description: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> AnnotationResult:
    """
    Ensure `catalog-info.yaml` in `repo` has the given Snyk annotations.

    - If the file exists: add/update Snyk annotations and open a PR.
    - If the file is missing: create it from scratch and open a PR.
    - If already annotated with the same values: skip (no PR created).
    - dry_run=True: compute changes but do not push or open a PR.
    """
    adapter = _get_adapter(provider, token=vcs_token)
    vcs_provider = VCSProvider(provider)

    try:
        default_branch = await adapter.get_default_branch(repo)
        catalog_file = await adapter.get_catalog_file(repo, branch=default_branch)

        if catalog_file.exists:
            # Check if already annotated with identical values
            existing = check_existing_snyk_annotations(catalog_file.content)
            if (
                existing.get("snyk_org_id") == snyk_org_id
                and existing.get("snyk_project_id") == snyk_project_id
            ):
                return AnnotationResult(
                    repo=repo,
                    provider=vcs_provider,
                    action="skipped",
                    message="Snyk annotations already present with correct values — no changes needed.",
                    snyk_org_id=snyk_org_id,
                    snyk_project_id=snyk_project_id,
                )

            new_content, changed = apply_snyk_annotations(
                catalog_file.content,
                snyk_org_id=snyk_org_id,
                snyk_project_id=snyk_project_id,
                snyk_org_name=snyk_org_name,
            )
            action = "updated"
            commit_msg = "chore: add Snyk annotations to catalog-info.yaml [platform-engineering-mcp]"
        else:
            name = component_name or repo.split("/")[-1]
            new_content = create_catalog_yaml(
                component_name=name,
                snyk_org_id=snyk_org_id,
                snyk_project_id=snyk_project_id,
                snyk_org_name=snyk_org_name,
                description=description or "",
                owner=owner,
            )
            action = "created"
            commit_msg = "chore: add catalog-info.yaml with Snyk annotations [platform-engineering-mcp]"

        if dry_run:
            return AnnotationResult(
                repo=repo,
                provider=vcs_provider,
                action=f"dry_run:{action}",
                message=f"[DRY RUN] Would have {action} catalog-info.yaml. No changes pushed.",
                snyk_org_id=snyk_org_id,
                snyk_project_id=snyk_project_id,
            )

        # Create branch + push file + open PR
        branch_name = _safe_branch_name(repo)
        await adapter.create_branch(repo, branch_name, from_branch=default_branch)
        await adapter.create_or_update_file(
            repo=repo,
            path="catalog-info.yaml",
            content=new_content,
            commit_message=commit_msg,
            branch=branch_name,
            sha=catalog_file.sha if catalog_file.exists else None,
        )

        pr_body = (
            "## Backstage Catalog Annotation — Snyk\n\n"
            f"This PR was opened automatically by **platform-engineering-mcp**.\n\n"
            f"| Field | Value |\n"
            f"|---|---|\n"
            f"| `snyk.io/org-id` | `{snyk_org_id}` |\n"
            f"| `snyk.io/project-id` | `{snyk_project_id}` |\n"
            + (f"| `snyk.io/org-name` | `{snyk_org_name}` |\n" if snyk_org_name else "")
            + "\nOnce merged, Backstage will discover and display the Snyk security posture "
            "for this component."
        )

        pr = await adapter.create_pull_request(
            repo=repo,
            title="chore: add Snyk annotations to catalog-info.yaml",
            body=pr_body,
            head_branch=branch_name,
            base_branch=default_branch,
        )

        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action=action,
            pr_url=pr.url,
            branch=branch_name,
            message=f"Successfully {action} catalog-info.yaml. PR opened: {pr.url}",
            snyk_org_id=snyk_org_id,
            snyk_project_id=snyk_project_id,
        )

    except Exception as e:
        logger.exception("Failed to annotate repo %s", repo)
        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action="error",
            message=str(e),
        )


async def annotate_repo_auto_snyk(
    repo: str,
    repo_url: str,
    provider: str,
    snyk_org_id: Optional[str] = None,
    snyk_token: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> AnnotationResult:
    """
    Full auto-mode: look up the Snyk project from the repo URL, then annotate.
    Raises if zero or multiple Snyk projects are found (caller should disambiguate).
    """
    vcs_provider = VCSProvider(provider)

    # Snyk lookup
    projects = await snyk_tools.find_project_for_repo(
        repo_url=repo_url,
        org_id=snyk_org_id,
        token=snyk_token,
    )

    if not projects:
        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action="error",
            message=(
                f"No Snyk projects found matching repo URL '{repo_url}'. "
                "Try snyk_find_project_for_repo to inspect available projects, "
                "then call backstage_annotate_repo with explicit snyk_project_id."
            ),
        )

    if len(projects) > 1:
        names = ", ".join(f"{p.name} ({p.id})" for p in projects)
        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action="error",
            message=(
                f"Multiple Snyk projects matched: {names}. "
                "Call backstage_annotate_repo with an explicit snyk_project_id to select one."
            ),
        )

    project = projects[0]
    return await annotate_repo(
        repo=repo,
        provider=provider,
        snyk_org_id=project.org_id,
        snyk_project_id=project.id,
        snyk_org_name=project.org_name or None,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )


# ── Generic single-plugin annotation helper ───────────────────────────────────

async def annotate_repo_with_plugin(
    repo: str,
    provider: str,
    plugin: str,
    annotation_pairs: dict,
    apply_fn,
    check_fn,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
    commit_msg_suffix: str = "",
) -> AnnotationResult:
    """
    Generic orchestration: apply a set of annotations to catalog-info.yaml via a PR.

    apply_fn(content, **annotation_pairs) → (new_content, changed)
    check_fn(content) → dict with a "has_*_annotations" key
    """
    adapter = _get_adapter(provider, token=vcs_token)
    vcs_provider = VCSProvider(provider)

    try:
        default_branch = await adapter.get_default_branch(repo)
        catalog_file = await adapter.get_catalog_file(repo, branch=default_branch)

        if catalog_file.exists:
            # Check if all values already match
            new_content, changed = apply_fn(catalog_file.content)
            if not changed:
                return AnnotationResult(
                    repo=repo,
                    provider=vcs_provider,
                    action="skipped",
                    message=f"{plugin} annotations already present with correct values — no changes needed.",
                )
            action = "updated"
            commit_msg = (
                f"chore: add {plugin} annotations to catalog-info.yaml"
                f"{' — ' + commit_msg_suffix if commit_msg_suffix else ''}"
                " [platform-engineering-mcp]"
            )
        else:
            name = component_name or repo.split("/")[-1]
            new_content = create_catalog_yaml(component_name=name, owner=owner, **annotation_pairs)
            action = "created"
            commit_msg = (
                f"chore: add catalog-info.yaml with {plugin} annotations"
                " [platform-engineering-mcp]"
            )

        if dry_run:
            return AnnotationResult(
                repo=repo,
                provider=vcs_provider,
                action=f"dry_run:{action}",
                message=f"[DRY RUN] Would have {action} catalog-info.yaml. No changes pushed.",
            )

        branch_name = _safe_branch_name(repo) + f"-{plugin.lower().replace(' ', '-')}"
        await adapter.create_branch(repo, branch_name, from_branch=default_branch)
        await adapter.create_or_update_file(
            repo=repo,
            path="catalog-info.yaml",
            content=new_content,
            commit_message=commit_msg,
            branch=branch_name,
            sha=catalog_file.sha if catalog_file.exists else None,
        )

        annotation_table = "\n".join(
            f"| `{k}` | `{v}` |"
            for k, v in annotation_pairs.items()
            if v is not None
        )
        pr_body = (
            f"## Backstage Catalog Annotation — {plugin}\n\n"
            "This PR was opened automatically by **platform-engineering-mcp**.\n\n"
            f"| Annotation | Value |\n|---|---|\n{annotation_table}\n"
        )

        pr = await adapter.create_pull_request(
            repo=repo,
            title=f"chore: add {plugin} annotations to catalog-info.yaml",
            body=pr_body,
            head_branch=branch_name,
            base_branch=default_branch,
        )

        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action=action,
            pr_url=pr.url,
            branch=branch_name,
            message=f"Successfully {action} catalog-info.yaml. PR opened: {pr.url}",
        )

    except Exception as e:
        logger.exception("Failed to annotate repo %s with %s", repo, plugin)
        return AnnotationResult(
            repo=repo,
            provider=vcs_provider,
            action="error",
            message=str(e),
        )


# ── ADO plugin ────────────────────────────────────────────────────────────────

async def annotate_repo_ado(
    repo: str,
    provider: str,
    ado_project: str,
    ado_repo: Optional[str] = None,
    ado_build_definition: Optional[str] = None,
    ado_host_org: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> AnnotationResult:
    """Annotate catalog-info.yaml with Backstage Azure DevOps plugin annotations."""
    annotation_pairs = {
        "ado_project": ado_project,
        "ado_repo": ado_repo,
        "ado_build_definition": ado_build_definition,
    }

    def apply_fn(content: str):
        return apply_ado_annotations(
            content,
            ado_project=ado_project,
            ado_repo=ado_repo,
            ado_build_definition=ado_build_definition,
            ado_host_org=ado_host_org,
        )

    return await annotate_repo_with_plugin(
        repo=repo,
        provider=provider,
        plugin="Azure DevOps",
        annotation_pairs=annotation_pairs,
        apply_fn=apply_fn,
        check_fn=check_existing_ado_annotations,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )


# ── SonarQube ─────────────────────────────────────────────────────────────────

async def annotate_repo_sonarqube(
    repo: str,
    provider: str,
    sonarqube_project_key: str,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> AnnotationResult:
    """Annotate catalog-info.yaml with the SonarQube project key."""

    def apply_fn(content: str):
        return apply_sonarqube_annotations(content, project_key=sonarqube_project_key)

    return await annotate_repo_with_plugin(
        repo=repo,
        provider=provider,
        plugin="SonarQube",
        annotation_pairs={"sonarqube_project_key": sonarqube_project_key},
        apply_fn=apply_fn,
        check_fn=check_existing_sonarqube_annotations,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )


# ── Grafana ───────────────────────────────────────────────────────────────────

async def annotate_repo_grafana(
    repo: str,
    provider: str,
    dashboard_selector: Optional[str] = None,
    overview_dashboard: Optional[str] = None,
    alert_label_selector: Optional[str] = None,
    vcs_token: Optional[str] = None,
    component_name: Optional[str] = None,
    owner: str = "platform-engineering",
    dry_run: bool = False,
) -> AnnotationResult:
    """Annotate catalog-info.yaml with Grafana dashboard/alert annotations."""

    def apply_fn(content: str):
        return apply_grafana_annotations(
            content,
            dashboard_selector=dashboard_selector,
            overview_dashboard=overview_dashboard,
            alert_label_selector=alert_label_selector,
        )

    annotation_pairs = {
        "grafana_dashboard_selector": dashboard_selector,
        "grafana_overview_dashboard": overview_dashboard,
        "grafana_alert_label_selector": alert_label_selector,
    }

    return await annotate_repo_with_plugin(
        repo=repo,
        provider=provider,
        plugin="Grafana",
        annotation_pairs={k: v for k, v in annotation_pairs.items() if v},
        apply_fn=apply_fn,
        check_fn=check_existing_grafana_annotations,
        vcs_token=vcs_token,
        component_name=component_name,
        owner=owner,
        dry_run=dry_run,
    )
