"""Snyk API v1 + REST client and MCP tool handlers."""

from __future__ import annotations

import logging
from typing import Optional
from urllib.parse import urlparse

import httpx

from platform_engineering_mcp.config import settings
from platform_engineering_mcp.models import SnykOrg, SnykProject

logger = logging.getLogger(__name__)

SNYK_API_BASE = "https://api.snyk.io"
SNYK_REST_VERSION = "2024-06-10"  # Snyk REST API version


def _auth_headers(token: str) -> dict:
    return {"Authorization": f"token {token}", "Content-Type": "application/json"}


def _rest_headers(token: str) -> dict:
    return {
        "Authorization": f"token {token}",
        "Content-Type": "application/vnd.api+json",
    }


# ─── Org helpers ──────────────────────────────────────────────────────────────


async def list_orgs(token: str | None = None) -> list[SnykOrg]:
    """Return all Snyk orgs accessible to the token."""
    token = token or settings.snyk_token
    if not token:
        raise ValueError("SNYK_TOKEN is not configured")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{SNYK_API_BASE}/v1/orgs",
            headers=_auth_headers(token),
        )
        resp.raise_for_status()
        data = resp.json()

    return [
        SnykOrg(id=o["id"], name=o["name"], slug=o["slug"])
        for o in data.get("orgs", [])
    ]


# ─── Project helpers ───────────────────────────────────────────────────────────


async def list_projects(
    org_id: str,
    token: str | None = None,
    repo_name_filter: Optional[str] = None,
) -> list[SnykProject]:
    """
    Return all projects in a Snyk org.

    If `repo_name_filter` is provided, only return projects whose name or
    target remoteUrl contains that string (case-insensitive).
    """
    token = token or settings.snyk_token
    if not token:
        raise ValueError("SNYK_TOKEN is not configured")

    projects: list[SnykProject] = []
    url = f"{SNYK_API_BASE}/rest/orgs/{org_id}/projects"

    async with httpx.AsyncClient(timeout=30) as client:
        params: dict = {
            "version": SNYK_REST_VERSION,
            "limit": 100,
        }
        while url:
            resp = await client.get(url, headers=_rest_headers(token), params=params)
            resp.raise_for_status()
            body = resp.json()

            for p in body.get("data", []):
                attrs = p.get("attributes", {})
                remote_url = attrs.get("remoteRepoUrl") or attrs.get("targetReference")

                projects.append(
                    SnykProject(
                        id=p["id"],
                        name=attrs.get("name", ""),
                        org_id=org_id,
                        org_name="",  # filled below if needed
                        target_reference=attrs.get("targetReference"),
                        remote_url=remote_url,
                    )
                )

            # Pagination: follow next link if present
            next_link = body.get("links", {}).get("next")
            if next_link:
                url = next_link
                params = {}  # version is baked into next link
            else:
                break

    if repo_name_filter:
        needle = repo_name_filter.lower()
        projects = [
            p
            for p in projects
            if needle in p.name.lower() or (p.remote_url and needle in p.remote_url.lower())
        ]

    return projects


async def find_project_for_repo(
    repo_url: str,
    org_id: str | None = None,
    token: str | None = None,
) -> list[SnykProject]:
    """
    Find Snyk projects that match a given repository URL.

    Matches on the repo path (owner/repo) extracted from the URL, checked
    against project names and remote URLs.
    """
    token = token or settings.snyk_token
    if not token:
        raise ValueError("SNYK_TOKEN is not configured")

    # Derive a short name to search with: owner/repo or last path segment
    parsed = urlparse(repo_url)
    path_parts = [p for p in parsed.path.strip("/").split("/") if p]
    if len(path_parts) >= 2:
        repo_name_filter = "/".join(path_parts[-2:])
    else:
        repo_name_filter = path_parts[-1] if path_parts else repo_url

    # If no org given, use settings default or search all orgs
    if org_id:
        org_ids = [org_id]
    elif settings.snyk_org_id:
        org_ids = [settings.snyk_org_id]
    else:
        orgs = await list_orgs(token)
        org_ids = [o.id for o in orgs]

    results: list[SnykProject] = []
    for oid in org_ids:
        matches = await list_projects(oid, token=token, repo_name_filter=repo_name_filter)
        results.extend(matches)

    return results


# ─── MCP tool handlers (called by server.py) ──────────────────────────────────


async def tool_snyk_list_orgs(snyk_token: str | None = None) -> dict:
    """MCP tool: list all Snyk orgs accessible to the configured token."""
    try:
        orgs = await list_orgs(snyk_token)
        return {
            "orgs": [o.model_dump() for o in orgs],
            "count": len(orgs),
        }
    except httpx.HTTPStatusError as e:
        return {"error": f"Snyk API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}


async def tool_snyk_list_projects(
    org_id: str,
    repo_filter: str | None = None,
    snyk_token: str | None = None,
) -> dict:
    """MCP tool: list projects in a Snyk org, optionally filtered by repo name."""
    try:
        projects = await list_projects(org_id, token=snyk_token, repo_name_filter=repo_filter)
        return {
            "projects": [p.model_dump() for p in projects],
            "count": len(projects),
        }
    except httpx.HTTPStatusError as e:
        return {"error": f"Snyk API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}


async def tool_snyk_find_project_for_repo(
    repo_url: str,
    org_id: str | None = None,
    snyk_token: str | None = None,
) -> dict:
    """MCP tool: find Snyk projects that match a given repository URL."""
    try:
        projects = await find_project_for_repo(repo_url, org_id=org_id, token=snyk_token)
        return {
            "matches": [p.model_dump() for p in projects],
            "count": len(projects),
        }
    except httpx.HTTPStatusError as e:
        return {"error": f"Snyk API error {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"error": str(e)}
