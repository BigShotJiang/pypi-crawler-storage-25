"""
catalog-info.yaml read / write / create helpers.

Uses ruamel.yaml to preserve existing comments and formatting when updating
an existing file, and produces clean output when creating from scratch.
"""

from __future__ import annotations

import logging
from typing import Optional

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap
from io import StringIO

logger = logging.getLogger(__name__)

# ── Annotation key constants ───────────────────────────────────────────────────

# Snyk
SNYK_ORG_ANNOTATION = "snyk.io/org-id"
SNYK_PROJECT_ANNOTATION = "snyk.io/project-id"
SNYK_ORG_NAME_ANNOTATION = "snyk.io/org-name"

# Azure DevOps (Backstage community plugin)
# https://github.com/backstage/community-plugins/tree/main/workspaces/azure-devops
ADO_PROJECT_ANNOTATION = "dev.azure.com/project"
ADO_PROJECT_REPO_ANNOTATION = "dev.azure.com/project-repo"
ADO_BUILD_DEFINITION_ANNOTATION = "dev.azure.com/build-definition"
ADO_HOST_ORG_ANNOTATION = "dev.azure.com/host-org"  # optional — for multi-org setups

# SonarQube (Backstage community plugin)
# https://github.com/backstage/community-plugins/tree/main/workspaces/sonarqube
SONARQUBE_PROJECT_KEY_ANNOTATION = "sonarqube.org/project-key"

# Grafana (Backstage community plugin)
# https://github.com/backstage/community-plugins/tree/main/workspaces/grafana
GRAFANA_DASHBOARD_SELECTOR_ANNOTATION = "grafana/dashboard-selector"
GRAFANA_OVERVIEW_DASHBOARD_ANNOTATION = "grafana/overview-dashboard"
GRAFANA_ALERT_LABEL_SELECTOR_ANNOTATION = "grafana/alert-label-selector"


# ── YAML helpers ───────────────────────────────────────────────────────────────

def _yaml_instance() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.default_flow_style = False
    y.width = 120
    return y


def load_catalog_yaml(content: str) -> CommentedMap:
    """Parse catalog-info.yaml content into a ruamel CommentedMap."""
    y = _yaml_instance()
    data = y.load(content)
    if data is None:
        raise ValueError("catalog-info.yaml is empty or invalid")
    return data


def dump_catalog_yaml(data: CommentedMap) -> str:
    """Serialise a CommentedMap back to a YAML string."""
    y = _yaml_instance()
    buf = StringIO()
    y.dump(data, buf)
    return buf.getvalue()


def _ensure_annotations(data: CommentedMap) -> CommentedMap:
    """Ensure metadata.annotations exists and return it."""
    if "metadata" not in data:
        data["metadata"] = CommentedMap()
    if "annotations" not in data["metadata"]:
        data["metadata"]["annotations"] = CommentedMap()
    return data["metadata"]["annotations"]


def _apply_annotation_dict(content: str, pairs: dict[str, str]) -> tuple[str, bool]:
    """
    Generic helper: merge a dict of annotation key→value into catalog-info.yaml.

    Returns (updated_yaml_string, was_changed). Skips None values.
    """
    data = load_catalog_yaml(content)
    annotations = _ensure_annotations(data)
    changed = False

    for key, value in pairs.items():
        if value is None:
            continue
        if annotations.get(key) != value:
            annotations[key] = value
            changed = True

    if changed:
        return dump_catalog_yaml(data), True
    return content, False


# ── Snyk ───────────────────────────────────────────────────────────────────────

def apply_snyk_annotations(
    content: str,
    snyk_org_id: str,
    snyk_project_id: str,
    snyk_org_name: Optional[str] = None,
) -> tuple[str, bool]:
    """Merge Snyk annotations into an existing catalog-info.yaml string."""
    pairs = {
        SNYK_ORG_ANNOTATION: snyk_org_id,
        SNYK_PROJECT_ANNOTATION: snyk_project_id,
    }
    if snyk_org_name:
        pairs[SNYK_ORG_NAME_ANNOTATION] = snyk_org_name
    return _apply_annotation_dict(content, pairs)


def check_existing_snyk_annotations(content: str) -> dict:
    """Inspect an existing catalog-info.yaml and return the current Snyk annotation values."""
    try:
        data = load_catalog_yaml(content)
        annotations = (data.get("metadata") or {}).get("annotations") or {}
        return {
            "snyk_org_id": annotations.get(SNYK_ORG_ANNOTATION),
            "snyk_project_id": annotations.get(SNYK_PROJECT_ANNOTATION),
            "snyk_org_name": annotations.get(SNYK_ORG_NAME_ANNOTATION),
            "has_snyk_annotations": bool(
                annotations.get(SNYK_ORG_ANNOTATION) or annotations.get(SNYK_PROJECT_ANNOTATION)
            ),
        }
    except Exception as e:
        return {"error": str(e), "has_snyk_annotations": False}


# ── Azure DevOps plugin ────────────────────────────────────────────────────────

def apply_ado_annotations(
    content: str,
    ado_project: str,
    ado_repo: Optional[str] = None,
    ado_build_definition: Optional[str] = None,
    ado_host_org: Optional[str] = None,
) -> tuple[str, bool]:
    """
    Merge Azure DevOps Backstage plugin annotations into catalog-info.yaml.

    - ado_project:          ADO project name  → dev.azure.com/project
    - ado_repo:             project/repo-name  → dev.azure.com/project-repo
    - ado_build_definition: build pipeline     → dev.azure.com/build-definition (optional)
    - ado_host_org:         host/org pair      → dev.azure.com/host-org (optional, multi-org)
    """
    pairs: dict[str, str] = {ADO_PROJECT_ANNOTATION: ado_project}
    if ado_repo:
        pairs[ADO_PROJECT_REPO_ANNOTATION] = ado_repo
    if ado_build_definition:
        pairs[ADO_BUILD_DEFINITION_ANNOTATION] = ado_build_definition
    if ado_host_org:
        pairs[ADO_HOST_ORG_ANNOTATION] = ado_host_org
    return _apply_annotation_dict(content, pairs)


def check_existing_ado_annotations(content: str) -> dict:
    """Return current ADO plugin annotation values from catalog-info.yaml."""
    try:
        data = load_catalog_yaml(content)
        annotations = (data.get("metadata") or {}).get("annotations") or {}
        return {
            "ado_project": annotations.get(ADO_PROJECT_ANNOTATION),
            "ado_project_repo": annotations.get(ADO_PROJECT_REPO_ANNOTATION),
            "ado_build_definition": annotations.get(ADO_BUILD_DEFINITION_ANNOTATION),
            "ado_host_org": annotations.get(ADO_HOST_ORG_ANNOTATION),
            "has_ado_annotations": bool(annotations.get(ADO_PROJECT_ANNOTATION)),
        }
    except Exception as e:
        return {"error": str(e), "has_ado_annotations": False}


# ── SonarQube ─────────────────────────────────────────────────────────────────

def apply_sonarqube_annotations(
    content: str,
    project_key: str,
) -> tuple[str, bool]:
    """
    Merge SonarQube annotation into catalog-info.yaml.

    project_key format: "instance-name/project-key"  (instance prefix optional for default instance)
    """
    return _apply_annotation_dict(content, {SONARQUBE_PROJECT_KEY_ANNOTATION: project_key})


def check_existing_sonarqube_annotations(content: str) -> dict:
    """Return current SonarQube annotation value from catalog-info.yaml."""
    try:
        data = load_catalog_yaml(content)
        annotations = (data.get("metadata") or {}).get("annotations") or {}
        project_key = annotations.get(SONARQUBE_PROJECT_KEY_ANNOTATION)
        return {
            "project_key": project_key,
            "has_sonarqube_annotations": bool(project_key),
        }
    except Exception as e:
        return {"error": str(e), "has_sonarqube_annotations": False}


# ── Grafana ───────────────────────────────────────────────────────────────────

def apply_grafana_annotations(
    content: str,
    dashboard_selector: Optional[str] = None,
    overview_dashboard: Optional[str] = None,
    alert_label_selector: Optional[str] = None,
) -> tuple[str, bool]:
    """
    Merge Grafana Backstage plugin annotations into catalog-info.yaml.

    - dashboard_selector:   Grafana tag selector, e.g. "tag:my-service"
    - overview_dashboard:   Full Grafana dashboard URL
    - alert_label_selector: Grafana label selector, e.g. "service=my-service"
    """
    if not any([dashboard_selector, overview_dashboard, alert_label_selector]):
        raise ValueError("At least one Grafana annotation must be provided")

    pairs: dict[str, Optional[str]] = {
        GRAFANA_DASHBOARD_SELECTOR_ANNOTATION: dashboard_selector,
        GRAFANA_OVERVIEW_DASHBOARD_ANNOTATION: overview_dashboard,
        GRAFANA_ALERT_LABEL_SELECTOR_ANNOTATION: alert_label_selector,
    }
    return _apply_annotation_dict(content, {k: v for k, v in pairs.items() if v is not None})


def check_existing_grafana_annotations(content: str) -> dict:
    """Return current Grafana annotation values from catalog-info.yaml."""
    try:
        data = load_catalog_yaml(content)
        annotations = (data.get("metadata") or {}).get("annotations") or {}
        return {
            "dashboard_selector": annotations.get(GRAFANA_DASHBOARD_SELECTOR_ANNOTATION),
            "overview_dashboard": annotations.get(GRAFANA_OVERVIEW_DASHBOARD_ANNOTATION),
            "alert_label_selector": annotations.get(GRAFANA_ALERT_LABEL_SELECTOR_ANNOTATION),
            "has_grafana_annotations": bool(
                annotations.get(GRAFANA_DASHBOARD_SELECTOR_ANNOTATION)
                or annotations.get(GRAFANA_OVERVIEW_DASHBOARD_ANNOTATION)
                or annotations.get(GRAFANA_ALERT_LABEL_SELECTOR_ANNOTATION)
            ),
        }
    except Exception as e:
        return {"error": str(e), "has_grafana_annotations": False}


# ── Catalog creation (all plugins) ────────────────────────────────────────────

def create_catalog_yaml(
    component_name: str,
    # Snyk (required for creation; use annotate_* helpers for updates)
    snyk_org_id: Optional[str] = None,
    snyk_project_id: Optional[str] = None,
    snyk_org_name: Optional[str] = None,
    # ADO plugin
    ado_project: Optional[str] = None,
    ado_repo: Optional[str] = None,
    ado_build_definition: Optional[str] = None,
    # SonarQube
    sonarqube_project_key: Optional[str] = None,
    # Grafana
    grafana_dashboard_selector: Optional[str] = None,
    grafana_overview_dashboard: Optional[str] = None,
    grafana_alert_label_selector: Optional[str] = None,
    # Component metadata
    description: str = "",
    owner: str = "platform-engineering",
    lifecycle: str = "production",
    component_type: str = "service",
) -> str:
    """
    Generate a minimal, valid Backstage catalog-info.yaml with any combination of plugin annotations.
    """
    annotations: dict = {}

    if snyk_org_id:
        annotations[SNYK_ORG_ANNOTATION] = snyk_org_id
    if snyk_project_id:
        annotations[SNYK_PROJECT_ANNOTATION] = snyk_project_id
    if snyk_org_name:
        annotations[SNYK_ORG_NAME_ANNOTATION] = snyk_org_name

    if ado_project:
        annotations[ADO_PROJECT_ANNOTATION] = ado_project
    if ado_repo:
        annotations[ADO_PROJECT_REPO_ANNOTATION] = ado_repo
    if ado_build_definition:
        annotations[ADO_BUILD_DEFINITION_ANNOTATION] = ado_build_definition

    if sonarqube_project_key:
        annotations[SONARQUBE_PROJECT_KEY_ANNOTATION] = sonarqube_project_key

    if grafana_dashboard_selector:
        annotations[GRAFANA_DASHBOARD_SELECTOR_ANNOTATION] = grafana_dashboard_selector
    if grafana_overview_dashboard:
        annotations[GRAFANA_OVERVIEW_DASHBOARD_ANNOTATION] = grafana_overview_dashboard
    if grafana_alert_label_selector:
        annotations[GRAFANA_ALERT_LABEL_SELECTOR_ANNOTATION] = grafana_alert_label_selector

    entity = {
        "apiVersion": "backstage.io/v1alpha1",
        "kind": "Component",
        "metadata": {
            "name": component_name,
            "description": description or f"{component_name} service",
            "annotations": annotations,
        },
        "spec": {
            "type": component_type,
            "lifecycle": lifecycle,
            "owner": f"group:{owner}",
        },
    }

    y = _yaml_instance()
    buf = StringIO()
    y.dump(entity, buf)
    header = "# Backstage catalog descriptor — auto-generated by platform-engineering-mcp\n"
    return header + buf.getvalue()


def check_all_annotations(content: str) -> dict:
    """Return a summary of all known plugin annotations present in catalog-info.yaml."""
    return {
        "snyk": check_existing_snyk_annotations(content),
        "ado": check_existing_ado_annotations(content),
        "sonarqube": check_existing_sonarqube_annotations(content),
        "grafana": check_existing_grafana_annotations(content),
    }
