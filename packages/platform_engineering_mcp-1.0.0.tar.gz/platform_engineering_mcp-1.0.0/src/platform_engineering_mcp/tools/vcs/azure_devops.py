"""Azure DevOps VCS adapter using the Azure DevOps REST API."""

from __future__ import annotations

import base64
import logging
from typing import Optional
from urllib.parse import quote

import httpx

from platform_engineering_mcp.config import settings
from .base import FileContent, PullRequest, VCSAdapter

logger = logging.getLogger(__name__)

ADO_API_VERSION = "7.1"


class AzureDevOpsAdapter(VCSAdapter):
    """
    Adapter for Azure DevOps repositories.

    `repo` parameter format: "project/repo-name"

    The organisation URL is loaded from AZURE_DEVOPS_ORG_URL (env var),
    e.g. https://dev.azure.com/my-org
    """

    def __init__(self, pat: str | None = None, org_url: str | None = None):
        self.pat = pat or settings.azure_devops_pat
        self.org_url = (org_url or settings.azure_devops_org_url).rstrip("/")
        if not self.pat:
            raise ValueError("AZURE_DEVOPS_PAT is not configured")
        if not self.org_url:
            raise ValueError("AZURE_DEVOPS_ORG_URL is not configured")

    def _headers(self) -> dict:
        token = base64.b64encode(f":{self.pat}".encode()).decode()
        return {
            "Authorization": f"Basic {token}",
            "Content-Type": "application/json",
        }

    def _parse_repo(self, repo: str) -> tuple[str, str]:
        """Split 'project/repo' into (project, repo_name)."""
        parts = repo.split("/", 1)
        if len(parts) != 2:
            raise ValueError(
                f"Azure DevOps repo must be in 'project/repo-name' format, got: {repo!r}"
            )
        return parts[0], parts[1]

    def _repo_url(self, project: str, repo_name: str) -> str:
        return f"{self.org_url}/{quote(project)}/_apis/git/repositories/{quote(repo_name)}"

    # ── read ──────────────────────────────────────────────────────────────────

    async def get_default_branch(self, repo: str) -> str:
        project, repo_name = self._parse_repo(repo)
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{self._repo_url(project, repo_name)}",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION},
            )
            resp.raise_for_status()
            default_branch = resp.json().get("defaultBranch", "refs/heads/main")
            # strip the "refs/heads/" prefix
            return default_branch.replace("refs/heads/", "")

    async def get_file(
        self,
        repo: str,
        path: str,
        branch: Optional[str] = None,
    ) -> FileContent:
        project, repo_name = self._parse_repo(repo)
        if not branch:
            branch = await self.get_default_branch(repo)

        params = {
            "api-version": ADO_API_VERSION,
            "path": f"/{path.lstrip('/')}",
            "versionDescriptor.version": branch,
            "versionDescriptor.versionType": "branch",
            "$format": "json",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{self._repo_url(project, repo_name)}/items",
                headers=self._headers(),
                params=params,
            )

        if resp.status_code == 404:
            return FileContent(path=path, content="", sha="", exists=False)

        resp.raise_for_status()
        data = resp.json()

        # Fetch raw content via the download URL
        async with httpx.AsyncClient(timeout=30) as client:
            raw_params = {**params, "$format": "text"}
            raw_resp = await client.get(
                f"{self._repo_url(project, repo_name)}/items",
                headers=self._headers(),
                params=raw_params,
            )
            raw_resp.raise_for_status()
            content = raw_resp.text

        sha = data.get("commitId", "")
        return FileContent(path=path, content=content, sha=sha, exists=True)

    # ── write ─────────────────────────────────────────────────────────────────

    async def create_branch(
        self,
        repo: str,
        branch_name: str,
        from_branch: Optional[str] = None,
    ) -> str:
        project, repo_name = self._parse_repo(repo)
        base = from_branch or await self.get_default_branch(repo)

        async with httpx.AsyncClient(timeout=30) as client:
            # Get the latest commit SHA of the base branch
            stats_resp = await client.get(
                f"{self._repo_url(project, repo_name)}/stats/branches",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION, "name": base},
            )
            stats_resp.raise_for_status()
            old_sha = stats_resp.json()["commit"]["commitId"]

            # Create the new branch via refs update
            payload = [
                {
                    "name": f"refs/heads/{branch_name}",
                    "oldObjectId": "0000000000000000000000000000000000000000",
                    "newObjectId": old_sha,
                }
            ]
            create_resp = await client.post(
                f"{self._repo_url(project, repo_name)}/refs",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION},
                json=payload,
            )
            create_resp.raise_for_status()

        return branch_name

    async def create_or_update_file(
        self,
        repo: str,
        path: str,
        content: str,
        commit_message: str,
        branch: str,
        sha: Optional[str] = None,
    ) -> None:
        """
        Push a file to a branch via the ADO push API.
        `sha` is the old commit ID (latest commit on the branch).
        """
        project, repo_name = self._parse_repo(repo)

        # If sha not supplied, look up the latest commit on the branch
        if not sha:
            async with httpx.AsyncClient(timeout=30) as client:
                stats_resp = await client.get(
                    f"{self._repo_url(project, repo_name)}/stats/branches",
                    headers=self._headers(),
                    params={"api-version": ADO_API_VERSION, "name": branch},
                )
                stats_resp.raise_for_status()
                sha = stats_resp.json()["commit"]["commitId"]

        # Determine if file exists to decide add vs edit
        existing = await self.get_file(repo, path, branch=branch)
        change_type = "edit" if existing.exists else "add"

        payload = {
            "refUpdates": [{"name": f"refs/heads/{branch}", "oldObjectId": sha}],
            "commits": [
                {
                    "comment": commit_message,
                    "changes": [
                        {
                            "changeType": change_type,
                            "item": {"path": f"/{path.lstrip('/')}"},
                            "newContent": {
                                "content": content,
                                "contentType": "rawtext",
                            },
                        }
                    ],
                }
            ],
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{self._repo_url(project, repo_name)}/pushes",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION},
                json=payload,
            )
            resp.raise_for_status()

    async def create_pull_request(
        self,
        repo: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str,
    ) -> PullRequest:
        project, repo_name = self._parse_repo(repo)

        payload = {
            "title": title,
            "description": body,
            "sourceRefName": f"refs/heads/{head_branch}",
            "targetRefName": f"refs/heads/{base_branch}",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{self._repo_url(project, repo_name)}/pullrequests",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION},
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()

        pr_url = (
            f"{self.org_url}/{quote(project)}/_git/{quote(repo_name)}"
            f"/pullrequest/{data['pullRequestId']}"
        )
        return PullRequest(
            url=pr_url,
            number=data["pullRequestId"],
            title=data["title"],
            branch=head_branch,
        )

    async def list_repos(self, project: str) -> list[str]:
        """List all repos in an ADO project. Returns list of 'project/repo' strings."""
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{self.org_url}/{quote(project)}/_apis/git/repositories",
                headers=self._headers(),
                params={"api-version": ADO_API_VERSION},
            )
            resp.raise_for_status()
            data = resp.json()
        return [f"{project}/{r['name']}" for r in data.get("value", [])]
