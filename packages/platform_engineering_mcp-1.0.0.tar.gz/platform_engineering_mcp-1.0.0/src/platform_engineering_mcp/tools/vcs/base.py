"""Abstract base class for VCS adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class FileContent:
    """Represents a file retrieved from a VCS."""
    path: str
    content: str
    sha: str  # commit SHA or blob SHA — used for update operations
    exists: bool


@dataclass
class PullRequest:
    url: str
    number: int | str
    title: str
    branch: str


class VCSAdapter(ABC):
    """Common interface for version control providers."""

    CATALOG_FILE_PATH = "catalog-info.yaml"

    @abstractmethod
    async def get_file(
        self,
        repo: str,
        path: str,
        branch: Optional[str] = None,
    ) -> FileContent:
        """
        Retrieve a file from the repo.

        `repo` format is provider-specific (see subclasses).
        Returns FileContent with exists=False if the file does not exist.
        """

    @abstractmethod
    async def create_or_update_file(
        self,
        repo: str,
        path: str,
        content: str,
        commit_message: str,
        branch: str,
        sha: Optional[str] = None,
    ) -> None:
        """Create or update a file on an existing branch."""

    @abstractmethod
    async def create_branch(
        self,
        repo: str,
        branch_name: str,
        from_branch: Optional[str] = None,
    ) -> str:
        """Create a branch. Returns the new branch name."""

    @abstractmethod
    async def create_pull_request(
        self,
        repo: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str,
    ) -> PullRequest:
        """Open a PR and return its URL."""

    @abstractmethod
    async def get_default_branch(self, repo: str) -> str:
        """Return the default branch name for the repo."""

    async def get_catalog_file(
        self, repo: str, branch: Optional[str] = None
    ) -> FileContent:
        return await self.get_file(repo, self.CATALOG_FILE_PATH, branch)
