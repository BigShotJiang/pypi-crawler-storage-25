"""GitHub VCS adapter using the GitHub REST API."""

from __future__ import annotations

import base64
import logging
from typing import Optional

import httpx

from platform_engineering_mcp.config import settings
from .base import FileContent, PullRequest, VCSAdapter

logger = logging.getLogger(__name__)

GITHUB_API = "https://api.github.com"


class GitHubAdapter(VCSAdapter):
    """
    Adapter for GitHub repositories.

    `repo` parameter format: "owner/repo-name"
    """

    def __init__(self, token: str | None = None):
        self.token = token or settings.github_token
        if not self.token:
            raise ValueError("GITHUB_TOKEN is not configured")

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    # ── read ──────────────────────────────────────────────────────────────────

    async def get_default_branch(self, repo: str) -> str:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{GITHUB_API}/repos/{repo}",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return resp.json()["default_branch"]

    async def get_file(
        self,
        repo: str,
        path: str,
        branch: Optional[str] = None,
    ) -> FileContent:
        params = {}
        if branch:
            params["ref"] = branch

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{GITHUB_API}/repos/{repo}/contents/{path}",
                headers=self._headers(),
                params=params,
            )

        if resp.status_code == 404:
            return FileContent(path=path, content="", sha="", exists=False)

        resp.raise_for_status()
        data = resp.json()
        content = base64.b64decode(data["content"]).decode("utf-8")
        return FileContent(path=path, content=content, sha=data["sha"], exists=True)

    # ── write ─────────────────────────────────────────────────────────────────

    async def create_branch(
        self,
        repo: str,
        branch_name: str,
        from_branch: Optional[str] = None,
    ) -> str:
        base = from_branch or await self.get_default_branch(repo)

        async with httpx.AsyncClient(timeout=30) as client:
            # Get SHA of base branch
            ref_resp = await client.get(
                f"{GITHUB_API}/repos/{repo}/git/ref/heads/{base}",
                headers=self._headers(),
            )
            ref_resp.raise_for_status()
            sha = ref_resp.json()["object"]["sha"]

            # Create the new branch
            create_resp = await client.post(
                f"{GITHUB_API}/repos/{repo}/git/refs",
                headers=self._headers(),
                json={"ref": f"refs/heads/{branch_name}", "sha": sha},
            )
            create_resp.raise_for_status()

        return branch_name

    async def create_or_update_file(
        self,
        repo: str,
        path: str,
        content: str,
        commit_message: str,
        branch: str,
        sha: Optional[str] = None,
    ) -> None:
        payload: dict = {
            "message": commit_message,
            "content": base64.b64encode(content.encode()).decode(),
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.put(
                f"{GITHUB_API}/repos/{repo}/contents/{path}",
                headers=self._headers(),
                json=payload,
            )
            resp.raise_for_status()

    async def create_pull_request(
        self,
        repo: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str,
    ) -> PullRequest:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{GITHUB_API}/repos/{repo}/pulls",
                headers=self._headers(),
                json={
                    "title": title,
                    "body": body,
                    "head": head_branch,
                    "base": base_branch,
                },
            )
            resp.raise_for_status()
            data = resp.json()

        return PullRequest(
            url=data["html_url"],
            number=data["number"],
            title=data["title"],
            branch=head_branch,
        )

    async def list_repos(self, org: str) -> list[str]:
        """List all repos in a GitHub org. Returns list of 'org/repo' strings."""
        repos = []
        page = 1
        async with httpx.AsyncClient(timeout=30) as client:
            while True:
                resp = await client.get(
                    f"{GITHUB_API}/orgs/{org}/repos",
                    headers=self._headers(),
                    params={"per_page": 100, "page": page, "type": "all"},
                )
                resp.raise_for_status()
                batch = resp.json()
                if not batch:
                    break
                repos.extend(r["full_name"] for r in batch)
                if len(batch) < 100:
                    break
                page += 1
        return repos
