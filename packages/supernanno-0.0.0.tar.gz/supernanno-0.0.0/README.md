# SuperNanno

> Nano, but modern. With UI, syntax highlighting, and a real developer workflow

A modern terminal-based text editor inspired by nano.

SuperNanno combines simplicity with powerful editing features, providing a clean and efficient editing experience directly in your terminal.