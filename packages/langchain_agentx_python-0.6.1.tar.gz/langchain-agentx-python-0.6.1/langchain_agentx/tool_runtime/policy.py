"""
runtime/policy.py — 工具权限策略引擎

职责：
    提供可复用的最小策略层，将工具本地校验（validate_input）与
    全局权限治理（check_permissions）分开。PolicyEngine 作为可注入
    的策略对象，由 RuntimeTool.__init__ 接收，在 check_permissions
    默认实现中委托调用。

    DefaultPolicyEngine 实现 v1.5 范围：
        - read_roots / write_roots 读写分离路径限制
        - deny_globs 用户自定义禁止模式匹配
        - ask_globs 需要人工确认的敏感路径模式（headless 时降级为 deny）
        - enable_builtin_deny 内置危险路径黑名单（.env/.ssh/*.key 等）
        - read_only_mode 全局只读
        - allow / deny / ask 三种决策

    决策优先级（严格顺序）：
        [1] read_only_mode + is_destructive → deny
        [2] enable_builtin_deny → 内置黑名单 → deny
        [3] deny_globs 命中 → deny
        [4] ask_globs 命中 → ask（headless 模式下由 pipeline 降级为 deny）
        [5] 读写分权：is_read_only → read_roots；否则 → write_roots
        [6] 通过 → allow

与 CC 对比：
    CC 的权限系统分三层：
        Layer 1: 每个工具的 checkPermissions()
        Layer 2: hasPermissionsToUseToolInner() 全局引擎
                 alwaysDenyRules → alwaysAskRules → alwaysAllowRules → PermissionMode
        Layer 3: HITL race（User UI + Hooks + Classifier + Bridge）
    本框架 v1.5 实现 Layer 1 + Layer 2 完整版：
        - deny_globs + BUILTIN_DENY_GLOBS 对应 CC alwaysDenyRules
        - ask_globs 对应 CC alwaysAskRules（需人工确认路径）
        - read_roots / write_roots 对应 CC allWorkingDirectories
        - headless 模式 ask → deny 对应 CC shouldAvoidPermissionPrompts
        - HITL 交互（Layer 3 完整 race）延期到 v2

    详细设计见 docs/design-docs/tool-runtime/tool-permission-system.html
    与 docs/design-docs/tool-runtime/permission-l3-hitl-seam.html
"""

from __future__ import annotations

import fnmatch
import os
import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .models import AuthorizationDecision, ToolExecutionContext
from .path_safety import PathSafetyConfig, PathSafetyEvaluator
from .permission_context import get_active_auto_approved_tools
from .read_permission import ReadPathAuthorizer
from .permission_decision import (
    POLICY_ID_PREFIX_ALWAYS_ASK_TOOL,
    PermissionDecisionType,
    attach_decision_reason,
    make_decision_reason,
    normalize_tool_name_set,
)

if TYPE_CHECKING:
    from .auto_mode.config import AutoModeConfig
    from .auto_mode.hook import AutoModeAuthHook
    from langchain_agentx.workspace.capabilities import RuntimeCapabilities


# ---------------------------------------------------------------------------
# ToolPolicyConfig
# ---------------------------------------------------------------------------

@dataclass
class ToolPolicyConfig:
    """
    工具策略配置。

    read_roots:         允许读操作的路径根列表（read/glob/grep 等只读工具）。
                        空列表 = 不限制（开发模式）。
    write_roots:        允许写操作的路径根列表（write/edit/bash 等写工具）。
                        通常是 read_roots 的子集。空列表 = 不限制（开发模式）。
    deny_globs:         硬拒绝的 glob 模式列表，优先级高于 roots 检查。
                        对应 CC alwaysDenyRules。
                        示例：["**/secrets/**", "**/*.prod.env"]
    read_deny_globs:    仅用于 Read 的 deny glob；同步隐藏于 Glob/Grep（CC getFileReadIgnorePatterns）。
                        不参与 ``DefaultPolicyEngine`` 路径 fnmatch，除非重复写入 deny_globs。
    ask_globs:          需要人工确认的敏感路径 glob 模式列表。
                        对应 CC alwaysAskRules（路径规则）。
                        headless 模式下自动降级为 deny；交互模式下触发 HITL。
                        示例：["**/config/**", "**/.claude/**"]
    always_ask_tools:   始终需要人工确认的工具名集合（CC alwaysAskRules 工具级）。
                        在 auto_mode 之后评估：classifier 可 allow，否则 ask。
                        默认空集（向后兼容单测）；生产/CLI 推荐显式含 bash。
    read_only_mode:     全局只读模式，is_destructive=True 的工具直接拒绝。
    enable_builtin_deny: 启用内置危险路径保护（.env/.ssh/*.key/credentials 等）。
                        生产环境建议保持 True。
    enable_path_safety: 启用写路径 CC 对齐安全（危险目录 / agent 配置 / worktrees 例外）。
    path_safety:        ``PathSafetyConfig``（含 ``agent_home_segment``）；为 None 时不评估。
    auto_mode:          Auto Mode 配置（可选，Phase 1）。
    """

    read_roots: list[str] = field(default_factory=list)
    write_roots: list[str] = field(default_factory=list)
    deny_globs: list[str] = field(default_factory=list)
    read_deny_globs: list[str] = field(default_factory=list)
    ask_globs: list[str] = field(default_factory=list)
    always_ask_tools: frozenset[str] = field(default_factory=frozenset)
    read_only_mode: bool = False
    enable_builtin_deny: bool = True
    enable_path_safety: bool = True
    path_safety: PathSafetyConfig | None = None
    auto_mode: "AutoModeConfig | None" = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "always_ask_tools",
            normalize_tool_name_set(self.always_ask_tools),
        )

    def with_infrastructure_paths(
        self,
        capabilities: "RuntimeCapabilities",
    ) -> "ToolPolicyConfig":
        """追加基础设施写路径（memory_dir、sessions_dir）到 read/write_roots。

        用于 workflow 场景：节点 workspace_root 与全局 agent_home_dir 不同时，
        agent 需要写 memory/session 文件，这些路径必须在 write_roots 内。
        """
        home_dir = (capabilities.primary_workspace_root / capabilities.primary_agent_home).resolve()
        defaults = capabilities.defaults
        infra_paths = [
            str(defaults.default_memory_dir or (home_dir / "memory")),
            str(defaults.default_sessions_dir or (home_dir / "sessions")),
        ]

        new_read = list(self.read_roots)
        new_write = list(self.write_roots)
        for p in infra_paths:
            if p not in new_read:
                new_read.append(p)
            if p not in new_write:
                new_write.append(p)

        return ToolPolicyConfig(
            read_roots=new_read,
            write_roots=new_write,
            deny_globs=self.deny_globs,
            read_deny_globs=self.read_deny_globs,
            ask_globs=self.ask_globs,
            always_ask_tools=self.always_ask_tools,
            read_only_mode=self.read_only_mode,
            enable_builtin_deny=self.enable_builtin_deny,
            enable_path_safety=self.enable_path_safety,
            path_safety=self.path_safety,
            auto_mode=self.auto_mode,
        )


# ---------------------------------------------------------------------------
# PolicyEngine 抽象基类
# ---------------------------------------------------------------------------

class PolicyEngine(ABC):
    """
    权限策略引擎抽象基类。

    由 RuntimeTool.check_permissions() 默认实现委托调用。
    子类实现 authorize() / aauthorize() 提供具体策略决策。

    基类不持有 ``_config`` / ``_auto_mode_hook`` 等实现字段；``read_only_mode``、
    ``auto_mode`` 短路仅在 :class:`DefaultPolicyEngine` 中实现。包装既有引擎请用
    :class:`~langchain_agentx.tool_runtime.policy_decorator.PolicyEngineDecorator`。
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if cls is PolicyEngine:
            return
        if "aauthorize" in cls.__dict__:
            return
        if "authorize" not in cls.__dict__:
            return
        warnings.warn(
            (
                f"{cls.__name__} overrides authorize() but not aauthorize(). "
                "PolicyEngine.aauthorize() only forwards to authorize(); "
                "use DefaultPolicyEngine for read_only_mode / auto_mode, or "
                "PolicyEngineDecorator to wrap an existing engine."
            ),
            UserWarning,
            stacklevel=2,
        )

    @abstractmethod
    def authorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """同步授权决策。"""
        ...

    async def aauthorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        异步授权决策（基类默认实现）。

        仅转发到同步 ``authorize()``，不访问子类私有字段。
        ``read_only_mode`` / ``auto_mode`` 异步路径见 :class:`DefaultPolicyEngine`。
        """
        return self.authorize(
            tool_name=tool_name,
            input_data=input_data,
            ctx=ctx,
        )


# ---------------------------------------------------------------------------
# DefaultPolicyEngine — v1 实现
# ---------------------------------------------------------------------------

class DefaultPolicyEngine(PolicyEngine):
    """
    v1.5 默认策略引擎。

    决策优先级（严格顺序）：
        [1] read_only_mode + is_destructive → deny      最高优先级
        [2] auto_mode hook（async aauthorize，permission_mode == "auto"）
             → allow / ask / deny；passthrough 继续
        [3] always_ask_tools 工具名命中 → ask（CC alwaysAskRules 工具级；在 auto_mode 之后）
        [4] enable_builtin_deny → BUILTIN_DENY_GLOBS → deny
        [5] deny_globs 命中 → deny
        [6] ask_globs 命中 → ask（headless 时 pipeline 降级为 deny）
        [6.5] enable_path_safety + 写工具 → PathSafetyEvaluator → ask（CC checkPathSafetyForAutoEdit）
        [7] 读写分权：
              is_read_only=True  → ReadPathAuthorizer（read_deny → deny → builtin → ask
                    → write_implies_read → read_roots；见 read_permission.py）
              is_read_only=False → path_safety + write_roots
              roots 为空列表 → 跳过，视为不限制
        [8] 通过 → allow

    对应 CC：
        [1] ~ read_only_mode（全局禁止写操作）
        [2][3] ~ alwaysDenyRules（固定拒绝）
        [4] ~ alwaysAskRules（需确认）
        [6.5] ~ DANGEROUS_DIRECTORIES / isClaudeConfigFilePath（写 ask）
        [5] ~ allWorkingDirectories（访问空间限制）

    工具读写标志来源：
        从 ctx.tool_flags["is_read_only"] / ctx.tool_flags["is_destructive"] 读取。
        由 LangChainAdapter.build_tool_execution_context() 在构造 ctx 时注入。

    路径提取规则：
        从 input_data 中按优先级查找路径字段：file_path > path > pattern
        找不到路径字段时跳过路径相关检查（直接 allow）。

    路径校验：
        使用 realpath 双检（对 path 和 root 均做 realpath），
        防路径遍历（../）、符号链接绕过、前缀误匹配。
    """

    # 按优先级尝试的路径字段名
    _PATH_FIELDS = ("file_path", "path", "pattern")

    # 内置危险路径黑名单，对应 CC 的危险目录/文件检查
    BUILTIN_DENY_GLOBS: list[str] = [
        # 环境变量 / 配置
        "**/.env", "**/.env.*", "**/*.env",
        # SSH 密钥
        "**/id_rsa", "**/id_rsa.pub", "**/id_ed25519", "**/id_ed25519.pub",
        "**/.ssh/**",
        # 证书与密钥文件
        "**/*.pem", "**/*.key", "**/*.p12", "**/*.pfx",
        # 云服务凭证
        "**/.aws/credentials", "**/.aws/config",
        "**/.gcp/**", "**/service-account*.json",
        # 密码/密钥目录
        "**/secrets/**", "**/.secrets/**", "**/credentials/**",
    ]

    def __init__(
        self,
        config: ToolPolicyConfig,
        *,
        auto_mode_hook: "AutoModeAuthHook | None" = None,
    ) -> None:
        """初始化默认策略引擎。

        Args:
            config: 策略配置
            auto_mode_hook: Auto Mode 授权 Hook（可选，Phase 1 集成）
        """
        self._config = config
        self._read_roots = [os.path.realpath(r) for r in config.read_roots]
        self._write_roots = [os.path.realpath(r) for r in config.write_roots]
        self._always_ask_tools = config.always_ask_tools
        self._auto_mode_hook = auto_mode_hook
        self._path_safety: PathSafetyEvaluator | None = None
        if config.enable_path_safety and config.path_safety is not None:
            self._path_safety = PathSafetyEvaluator(config.path_safety)
        self._read_authorizer = ReadPathAuthorizer(
            config,
            path_safety=self._path_safety,
            check_deny_globs=self._check_deny_globs,
            check_ask_globs=self._check_ask_globs,
            check_builtin_deny=self._check_builtin_deny,
            authorize_destructive_path=self._evaluate_write_allowance_for_implied_read,
            authorize_read_roots=lambda real_path: self._authorize_path_roots(
                real_path,
                is_read_only_tool=True,
            ),
            with_decision_source=self._with_decision_source,
        )

    def authorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        tool_flags = ctx.tool_flags if hasattr(ctx, "tool_flags") else {}
        is_destructive = tool_flags.get("is_destructive", False)
        is_read_only_tool = tool_flags.get("is_read_only", True)
        active_auto_approved_tools = get_active_auto_approved_tools(
            getattr(ctx, "session_store", None)
        )
        active_auto_approved_tools_lower = {
            name.lower() for name in active_auto_approved_tools
        }

        # [1] 全局只读模式：拒绝破坏性工具
        if self._config.read_only_mode and is_destructive:
            return self._with_decision_source(
                AuthorizationDecision(
                    behavior="deny",
                    message="Operation not permitted: agent is in read-only mode.",
                    policy_id="read_only_mode",
                ),
                matched_rule="read_only_mode",
            )

        # [2] Auto Mode：如果启用，返回标记要求调用异步版本
        if self._auto_mode_hook is not None and self._auto_mode_hook.enabled:
            return AuthorizationDecision(
                behavior="passthrough",
                message="Auto mode requires async authorization",
                policy_id="auto_mode_async_required",
                metadata={"auto_mode_async_required": True},
            )

        # [3] 工具级 always ask（同步路径，auto_mode 未介入时）
        always_ask = self._check_always_ask_tool(tool_name)
        if always_ask is not None:
            return always_ask

        # Bash 工具按”命令字符串”做规则匹配，不参与路径 roots 校验。
        # 对齐 docs/design-docs/tool-design/bash-tool.md 的 v2 方案。
        if tool_name == "bash":
            command = input_data.get("command")
            if not isinstance(command, str) or not command.strip():
                return AuthorizationDecision(behavior="allow")

            deny_result = self._check_deny_globs(command)
            if deny_result is not None:
                return self._with_decision_source(
                    deny_result,
                    matched_rule=deny_result.policy_id,
                )

            ask_result = self._check_ask_globs(command)
            if ask_result is not None:
                return self._with_decision_source(
                    ask_result,
                    matched_rule=ask_result.policy_id,
                )

            return self._with_decision_source(
                AuthorizationDecision(behavior="allow"),
                matched_rule="default_allow",
            )

        # 提取并规范化路径字段
        path = self._extract_path(input_data)
        if path is None:
            return self._with_decision_source(
                AuthorizationDecision(behavior="allow"),
                matched_rule="no_path_field",
            )

        real_path = os.path.realpath(os.path.expanduser(path))

        if is_read_only_tool:
            return self._read_authorizer.authorize(
                real_path,
                tool_name=tool_name,
                active_auto_approved_tools_lower=active_auto_approved_tools_lower,
            )

        # [2] 用户自定义 deny_globs（写工具）
        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return self._with_decision_source(
                deny_result,
                matched_rule=deny_result.policy_id,
            )

        builtin = self._check_builtin_deny(real_path)
        if builtin is not None:
            return self._with_decision_source(builtin, matched_rule="builtin_deny")

        # [4] ask_globs：敏感路径需要人工确认
        # headless 模式下 pipeline 会将 ask 自动降级为 deny；交互模式触发 HITL
        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            if tool_name.lower() in active_auto_approved_tools_lower:
                decision = AuthorizationDecision(
                    behavior="allow",
                    policy_id="skill_auto_approved_bypass_ask",
                    metadata={
                        "tool_name": tool_name,
                        "source": "skill_allowed_tools",
                        "decision_trace": [
                            {
                                "stage": "ask_globs",
                                "matched": True,
                                "decision": "allow",
                                "reason": "skill_auto_approved_bypass_ask",
                                "tool_name": tool_name,
                                "active_auto_approved_tools": sorted(active_auto_approved_tools),
                            }
                        ],
                    },
                )
                return self._with_decision_source(
                    decision,
                    matched_rule="skill_auto_approved_bypass_ask",
                )
            return self._with_decision_source(
                ask_result,
                matched_rule=ask_result.policy_id,
            )

        return self._authorize_destructive_path(real_path)

    async def aauthorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        异步授权：read_only 短路、auto_mode hook，再委托同步策略链。

        0.4.8 中误放在 :class:`PolicyEngine` 基类的逻辑现仅在此实现。
        """
        tool_flags = ctx.tool_flags if hasattr(ctx, "tool_flags") else {}
        is_destructive = tool_flags.get("is_destructive", False)

        if self._config.read_only_mode and is_destructive:
            return self._with_decision_source(
                AuthorizationDecision(
                    behavior="deny",
                    message="Operation not permitted: agent is in read-only mode.",
                    policy_id="read_only_mode",
                ),
                matched_rule="read_only_mode",
            )

        if self._auto_mode_hook is not None and self._auto_mode_hook.enabled:
            auto_decision = await self._auto_mode_hook.decide(
                tool_name=tool_name,
                tool_input=input_data,
                ctx=ctx,
            )
            if auto_decision.behavior in ("allow", "ask", "deny"):
                return auto_decision.to_authorization_decision()

        always_ask = self._check_always_ask_tool(tool_name)
        if always_ask is not None:
            return always_ask

        return self.authorize(
            tool_name=tool_name,
            input_data=input_data,
            ctx=ctx,
        )

    def authorize_path(
        self,
        path: str,
        *,
        is_write: bool,
    ) -> AuthorizationDecision:
        """
        对单个文件系统路径做授权。

        供 BashRuntimeTool v2 的路径安全层调用，避免 bash 因 command-string
        特殊分支而跳过 read_roots / write_roots / builtin deny 检查。
        """
        real_path = os.path.realpath(os.path.expanduser(path))

        if not is_write:
            return self._read_authorizer.authorize(
                real_path,
                tool_name="read",
                active_auto_approved_tools_lower=set(),
            )

        if self._config.read_only_mode and is_write:
            return self._with_decision_source(
                AuthorizationDecision(
                behavior="deny",
                message="Operation not permitted: agent is in read-only mode.",
                policy_id="read_only_mode",
                ),
                matched_rule="read_only_mode",
            )

        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return self._with_decision_source(
                deny_result,
                matched_rule=deny_result.policy_id,
            )

        builtin = self._check_builtin_deny(real_path)
        if builtin is not None:
            return self._with_decision_source(builtin, matched_rule="builtin_deny")

        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            return self._with_decision_source(
                ask_result,
                matched_rule=ask_result.policy_id,
            )

        return self._authorize_destructive_path(real_path)

    # ---- 内部辅助 ----

    def _authorize_destructive_path(self, real_path: str) -> AuthorizationDecision:
        """写工具路径尾部：path_safety + write_roots（deny/builtin/ask 已由 authorize 处理）。"""
        return self._authorize_path_roots(
            real_path,
            is_read_only_tool=False,
        )

    def _evaluate_write_allowance_for_implied_read(
        self,
        real_path: str,
    ) -> AuthorizationDecision:
        """CC Write allow ⇒ Read allow：复用写链（无 skill ask 绕过）。"""
        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return deny_result
        builtin = self._check_builtin_deny(real_path)
        if builtin is not None:
            return builtin
        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            return ask_result
        return self._authorize_path_roots(
            real_path,
            is_read_only_tool=False,
        )

    def _check_builtin_deny(self, real_path: str) -> AuthorizationDecision | None:
        if not self._config.enable_builtin_deny:
            return None
        for pattern in self.BUILTIN_DENY_GLOBS:
            if fnmatch.fnmatch(real_path, pattern):
                return AuthorizationDecision(
                    behavior="deny",
                    message="Permission denied: access to this path is not allowed.",
                    policy_id="builtin_deny",
                )
        return None

    def _authorize_path_roots(
        self,
        real_path: str,
        *,
        is_read_only_tool: bool,
    ) -> AuthorizationDecision:
        """ask_globs 之后：写路径安全 + read/write_roots。"""
        if not is_read_only_tool and self._path_safety is not None:
            safety = self._path_safety.evaluate_write_path(real_path)
            if safety is not None:
                return self._with_decision_source(
                    safety,
                    matched_rule=safety.policy_id or "path_safety",
                )

        roots = self._read_roots if is_read_only_tool else self._write_roots
        if roots:
            if not any(self._within_root(real_path, r) for r in roots):
                return self._with_decision_source(
                    AuthorizationDecision(
                        behavior="deny",
                        message="Permission denied: path is outside the allowed workspace.",
                        policy_id="read_roots" if is_read_only_tool else "write_roots",
                    ),
                    matched_rule="read_roots" if is_read_only_tool else "write_roots",
                )

        return self._with_decision_source(
            AuthorizationDecision(behavior="allow"),
            matched_rule="default_allow",
        )

    def _check_always_ask_tool(self, tool_name: str) -> AuthorizationDecision | None:
        """工具级 always ask（CC getAskRuleForTool 工具名维度）。"""
        if tool_name.lower() not in self._always_ask_tools:
            return None
        decision = AuthorizationDecision(
            behavior="ask",
            ask_prompt=(
                f"Tool '{tool_name}' requires user approval before execution.\n"
                f"Allow this operation?"
            ),
            policy_id=f"{POLICY_ID_PREFIX_ALWAYS_ASK_TOOL}{tool_name.lower()}",
        )
        return attach_decision_reason(
            self._with_decision_source(decision, matched_rule="always_ask_tool"),
            make_decision_reason(
                PermissionDecisionType.RULE,
                rule_kind="always_ask_tool",
                tool_name=tool_name,
            ),
        )

    def _extract_path(self, input_data: dict[str, Any]) -> str | None:
        for field_name in self._PATH_FIELDS:
            val = input_data.get(field_name)
            if isinstance(val, str) and val:
                return val
        return None

    def _check_deny_globs(self, real_path: str) -> AuthorizationDecision | None:
        for glob_pattern in self._config.deny_globs:
            if fnmatch.fnmatch(real_path, glob_pattern):
                return AuthorizationDecision(
                    behavior="deny",
                    message="Permission denied: path matches a restricted pattern.",
                    policy_id=f"deny_glob:{glob_pattern}",
                )
        return None

    @staticmethod
    def _with_decision_source(
        decision: AuthorizationDecision,
        *,
        matched_rule: str | None,
    ) -> AuthorizationDecision:
        meta = dict(decision.metadata or {})
        meta.setdefault("rule_source", "default_policy_engine")
        if matched_rule is not None:
            meta.setdefault("matched_rule", matched_rule)
        decision.metadata = meta
        return decision

    def _check_ask_globs(self, real_path: str) -> AuthorizationDecision | None:
        """
        检查路径是否命中 ask_globs（需要人工确认的敏感路径）。
        命中时返回 behavior="ask"，由 pipeline 根据 headless 标志决定后续处理：
            headless=True  → pipeline 自动降级为 deny
            headless=False → pipeline 抛出 PermissionAskInterrupt
        """
        for glob_pattern in self._config.ask_globs:
            if fnmatch.fnmatch(real_path, glob_pattern):
                return AuthorizationDecision(
                    behavior="ask",
                    ask_prompt=(
                        f"Tool wants to access a sensitive path: {real_path}\n"
                        f"(matched pattern: {glob_pattern})\n"
                        f"Allow this operation?"
                    ),
                    policy_id=f"ask_glob:{glob_pattern}",
                )
        return None

    @staticmethod
    def _within_root(path: str, root: str) -> bool:
        """
        判断 path 是否在 root 目录内。
        root 已在 __init__ 中 realpath，path 在调用前已 realpath，
        使用 os.sep 边界确保不会前缀误匹配（如 /proj 不会匹配 /proj_evil）。
        """
        return path == root or path.startswith(root.rstrip(os.sep) + os.sep)
