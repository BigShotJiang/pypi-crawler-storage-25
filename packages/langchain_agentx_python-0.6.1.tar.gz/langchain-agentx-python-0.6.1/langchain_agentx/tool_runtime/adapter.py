"""
runtime/adapter.py — LangChain 集成适配器

职责：
    框架内部 RuntimeTool 与 LangChain 生态之间的唯一边界层，负责：
    1. 从 RunnableConfig 构造 ToolExecutionContext（隔离 LangGraph 底层依赖）
       - 同时将 RuntimeTool 的 is_read_only / is_destructive 注入 ctx.tool_flags
       - 允许通过 configurable 透传 permission_mode、sandbox 相关运行时标志
       - PolicyEngine 从 ctx.tool_flags 读取，不污染 input_data
       - LangGraph `ToolRuntime.state` 注入 ctx（含 `_trace_collector` / `_run_id`）；
         并解析 `tool_config_path`（workspace + `tool_runtime_config.json`）
    2. 将 RuntimeTool 导出为 LangChain StructuredTool（保持模型可见 schema 稳定）
    3. 将内部 ToolResultEnvelope 映射为 ToolMessage.content 字符串（模型路径）
    4. 将 ToolResultEnvelope 映射为 JSON-roundtrippable dict（out-of-band / 事件路径）

    LangChain 工具执行路径：
        ToolNode → StructuredTool.func → (content, artifact)
        → ToolMessage.content（模型）+ ToolMessage.artifact（out-of-band）

    同参重复调用短路在 ``ToolExecutorPipeline``（``RuntimeTool.dedupe_identical_calls`` +
    ``IdenticalCallMemo``）完成；本适配器负责 ``pipeline.run/arun`` → (content, artifact)，不单独做去重。

与 CC 对比：
    CC 中工具直接实现 TypeScript 函数，由 ToolNode 调用，没有显式 adapter 层。
    本框架引入 LangChainAdapter 作为边界，将 LangGraph 底层对象（RunnableConfig、
    state）的消费集中在此处，工具内部只依赖 ToolExecutionContext。

    envelope_to_tool_output 的输出格式对应 CC 工具返回的 ToolResult.content，
    模型只收到紧凑文本，meta 不进入模型上下文。

    envelope_to_event_artifact 供 out-of-band 路径（ToolMessage.artifact、TOOL_RESULT 事件），
    payload 保留原始结构，meta 全量带出；与模型字符串格式化逻辑分离。
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, is_dataclass
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Literal, MutableMapping

from langgraph.prebuilt.tool_node import ToolRuntime
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import StructuredTool

from .models import ToolExecutionContext, ToolResultEnvelope
from langchain_agentx.observability.replay.store import (
    OBS_SCHEMA_VERSION,
    get_global_trace_store,
    sample_events,
    sanitize_value,
)
from .base import RuntimeTool
from .pipeline import ToolExecutorPipeline


def _resolve_tool_call_id(
    *,
    config: RunnableConfig,
    tool_runtime: ToolRuntime | None,
    kwargs: dict[str, Any],
) -> str | None:
    """在构造 ctx 前解析 tool_call_id（对齐 CC toolUseID 贯穿决策链）。

    优先级：ToolRuntime.tool_call_id → configurable → 工具入参 id 字段。
    """
    tid: str | None = None
    if tool_runtime is not None:
        raw = getattr(tool_runtime, "tool_call_id", None)
        if isinstance(raw, str) and raw:
            tid = raw

    configurable = config.get("configurable", {}) or {}
    if not tid:
        for key in ("tool_call_id", "tool_use_id"):
            val = configurable.get(key)
            if isinstance(val, str) and val:
                tid = val
                break

    if not tid:
        for key in ("tool_call_id", "id"):
            val = kwargs.get(key)
            if isinstance(val, str) and val:
                tid = val
                break

    return tid


class LangChainAdapter:
    """
    LangChain 集成适配器。

    职责边界：
        负责：上下文构造（含 tool_flags 注入）、StructuredTool 导出、
              envelope → str（模型路径）、envelope → dict（out-of-band 路径）
        不负责：业务执行、policy 规则决策、graph 路由
    """

    def build_tool_execution_context(
        self,
        *,
        tool_name: str,
        raw_input: dict[str, Any],
        state: MutableMapping[str, Any],
        config: RunnableConfig | None = None,
        tool_call_id: str | None = None,
        actor: Literal["agent", "human", "system"] = "agent",
        tool_flags: dict[str, Any] | None = None,
    ) -> ToolExecutionContext:
        """
        从 RunnableConfig.configurable 构造 ToolExecutionContext。

        LangGraph 在调用工具时通过 RunnableConfig 传递 thread_id、run_id、
        tool_call_id 等元数据。本方法将这些字段提取并归一化，
        隔离工具内部对 LangGraph 底层对象的直接依赖。

        tool_flags：由 build_structured_tool 从 RuntimeTool 类属性提取后传入，
            {"is_read_only": bool, "is_destructive": bool}
            PolicyEngine.authorize() 从 ctx.tool_flags 读取工具读写属性，
            不污染 input_data。

        config 参数接受 RunnableConfig 或 None。
        """
        configurable: dict = {}
        if config is not None:
            configurable = config.get("configurable", {}) or {}

        loop_config = configurable.get("loop_config")

        model = getattr(loop_config, "model", None)
        available_tools = list(getattr(loop_config, "available_tools", None) or [])
        session_id = getattr(loop_config, "session_id", None)
        conversation_session_id = getattr(loop_config, "conversation_session_id", None) or session_id
        workspace_root = getattr(loop_config, "workspace_root", None)
        agent_home = getattr(loop_config, "agent_home", ".langchain_agentx")
        boundary = getattr(loop_config, "boundary", None)

        sess = configurable.get("session_store")
        from langchain_agentx.tool_runtime.session_store import (
            AgentSessionStore as _AgentSessionStore,
        )

        boundary_view = None
        if boundary is not None and isinstance(sess, _AgentSessionStore):
            from langchain_agentx.workspace.view import WorkspaceBoundaryView

            boundary_view = WorkspaceBoundaryView(boundary, sess)

        cwd: str | None = None
        if boundary_view is not None:
            cwd = str(boundary_view.resolve_cwd(None))
        elif isinstance(sess, _AgentSessionStore):
            sess_cwd = sess.cwd_override
            if isinstance(sess_cwd, str) and sess_cwd:
                cwd = sess_cwd
        if not cwd:
            cwd = workspace_root
        if not cwd:
            from langchain_agentx.workspace.errors import ConfigError

            raise ConfigError(
                "ToolExecutionContext cwd resolution failed: "
                "neither boundary_view nor workspace_root configured."
            )

        original_cwd: str | None = None
        if boundary is not None:
            original_cwd = str(boundary.workspace_root)
        elif workspace_root:
            original_cwd = str(workspace_root)
        trace_enabled = bool(getattr(loop_config, "trace_enabled", True))

        _depth_from_loop = getattr(loop_config, "agent_depth", None)
        if _depth_from_loop is not None:
            agent_depth = int(_depth_from_loop)
        elif isinstance(state, dict):
            agent_depth = int(state.get("agent_depth") or 0)
        else:
            agent_depth = 0

        _agent_id_from_state = state.get("agent_id") if isinstance(state, dict) else None
        agent_id = getattr(loop_config, "agent_id", None) or _agent_id_from_state

        resolved_tool_call_id = tool_call_id
        if not isinstance(resolved_tool_call_id, str) or not resolved_tool_call_id:
            resolved_tool_call_id = configurable.get("tool_call_id")
        if not isinstance(resolved_tool_call_id, str) or not resolved_tool_call_id:
            raw_tool_call_id = raw_input.get("tool_call_id") or raw_input.get("id")
            if isinstance(raw_tool_call_id, str) and raw_tool_call_id:
                resolved_tool_call_id = raw_tool_call_id
            else:
                resolved_tool_call_id = configurable.get("run_id")

        cancel_ev = configurable.get("cancel_event")
        if not isinstance(cancel_ev, threading.Event):
            cancel_ev = None

        trace_collector: Any | None = None
        if isinstance(state, dict):
            trace_collector = state.get("_trace_collector")
        if trace_collector is None:
            trace_collector = configurable.get("_trace_collector")

        trace_emit_session_id: str | None = None
        if isinstance(state, dict):
            _srid = state.get("_run_id")
            if isinstance(_srid, str) and _srid:
                trace_emit_session_id = _srid
        if trace_emit_session_id is None:
            _crid = configurable.get("_run_id")
            if isinstance(_crid, str) and _crid:
                trace_emit_session_id = _crid
        if trace_emit_session_id is None:
            _run_cfg = configurable.get("run_id")
            if isinstance(_run_cfg, str) and _run_cfg:
                trace_emit_session_id = _run_cfg
        if trace_emit_session_id is None and isinstance(session_id, str) and session_id:
            trace_emit_session_id = session_id

        capabilities: Any | None = configurable.get("capabilities")

        tool_config_path: str | None = None
        if workspace_root:
            try:
                from langchain_agentx.workspace import resolve_agent_workspace_config

                ws_cfg = resolve_agent_workspace_config(
                    workspace_root=Path(str(workspace_root)),
                    agent_home=agent_home,
                )
                tool_config_path = str(ws_cfg.tool_runtime_config_path.resolve())
            except Exception:
                tool_config_path = None

        channels: set[str] | None = None
        raw_ch = configurable.get("channels") or configurable.get("active_channels")
        if isinstance(raw_ch, (list, tuple, set)):
            ch_set = {str(x).strip() for x in raw_ch if str(x).strip()}
            channels = ch_set or None

        question_preview_format: str | None = None
        raw_pf = configurable.get("question_preview_format")
        if isinstance(raw_pf, str) and raw_pf.strip():
            low = raw_pf.strip().lower()
            if low in ("markdown", "html"):
                question_preview_format = low

        network_access_allowed = bool(getattr(loop_config, "network_access_allowed", True))
        if "network_access_allowed" in configurable:
            network_access_allowed = bool(configurable.get("network_access_allowed"))

        # 保留原始 RunnableConfig 用于 adispatch_custom_event（子 Agent 事件冒泡）
        # 只在 config 非空时传递，避免工具层直接访问 LangGraph 内部字段
        runnable_config_to_pass: Any | None = None
        if config is not None and not isinstance(config, str):
            runnable_config_to_pass = config

        return ToolExecutionContext(
            tool_name=tool_name,
            # 回退顺序：显式 tool_call_id -> config.tool_call_id -> input.tool_call_id -> input.id -> run_id
            # 用于尽量保留上游真实 tool_call 语义，避免子 run 关联键缺失。
            tool_call_id=resolved_tool_call_id,
            input_args=raw_input,
            state=state,
            model=model,
            available_tools=available_tools,
            agent_id=agent_id,
            agent_depth=agent_depth,
            now_ts=time.time(),
            thread_id=configurable.get("thread_id"),
            run_id=configurable.get("run_id") or session_id,
            session_id=session_id,
            conversation_session_id=conversation_session_id,
            actor=actor,
            session_store=configurable.get("session_store"),
            tool_loader=configurable.get("tool_loader"),
            tool_registry=configurable.get("tool_registry"),
            tool_flags=tool_flags or {},
            workspace_root=workspace_root,
            agent_home=agent_home,
            cwd=cwd,
            original_cwd=original_cwd,
            boundary_view=boundary_view,
            trace_enabled=trace_enabled,
            cancel_event=cancel_ev,
            tool_config_path=tool_config_path,
            channels=channels,
            trace_collector=trace_collector,
            trace_emit_session_id=trace_emit_session_id,
            question_preview_format=question_preview_format,
            capabilities=capabilities,
            network_access_allowed=network_access_allowed,
            runnable_config=runnable_config_to_pass,
        )

    def build_structured_tool(
        self,
        *,
        tool: Any,  # RuntimeTool，避免循环导入用 Any
        pipeline: ToolExecutorPipeline,
        state_getter: Callable[[], MutableMapping[str, Any]] | None = None,
    ) -> StructuredTool:
        """
        将 RuntimeTool 导出为 LangChain StructuredTool。

        args_schema 直接使用 tool.input_model，保证模型可见 schema 稳定。
        内部 func / coroutine 调用 pipeline.run / arun，
        通过 LangChain 的 config 参数获取 RunnableConfig。

        从 tool 类属性提取 tool_flags，在每次调用时注入 ctx，
        使 PolicyEngine 可以获取工具的读写属性。

        state_getter：历史参数，已忽略；LangGraph state 不再注入 ctx.state，
        控制面请使用 ``config["configurable"]["loop_config"]``（见 ``build_tool_execution_context``）。

        返回值经 ``response_format="content_and_artifact"`` 分流：
        ``invoke()`` 对外仍只暴露 content 字符串；artifact 由 ToolNode 写入 ``ToolMessage.artifact``。
        """
        adapter = self
        # 在 StructuredTool 构造时从类属性提取，避免每次调用重复读取
        _tool_flags: dict[str, Any] = {
            "is_read_only": getattr(tool, "is_read_only", False),
            "is_destructive": getattr(tool, "is_destructive", False),
        }

        def _build_ctx(
            *,
            config: RunnableConfig,
            tool_runtime: ToolRuntime | None,
            kwargs: dict[str, Any],
        ) -> ToolExecutionContext:
            effective_state: MutableMapping[str, Any]
            if tool_runtime is not None:
                raw_st = getattr(tool_runtime, "state", None)
                effective_state = raw_st if isinstance(raw_st, dict) else {}
            else:
                effective_state = {}
            effective_tool_flags = dict(_tool_flags)
            configurable = config.get("configurable", {}) or {}
            if "permission_mode" in configurable:
                effective_tool_flags["permission_mode"] = configurable["permission_mode"]
            if "allow_dangerously_disable_sandbox" in configurable:
                effective_tool_flags["allow_dangerously_disable_sandbox"] = configurable[
                    "allow_dangerously_disable_sandbox"
                ]
            if "sandbox_excluded_commands" in configurable:
                effective_tool_flags["sandbox_excluded_commands"] = configurable[
                    "sandbox_excluded_commands"
                ]
            resolved_tool_call_id = _resolve_tool_call_id(
                config=config,
                tool_runtime=tool_runtime,
                kwargs=kwargs,
            )
            return adapter.build_tool_execution_context(
                tool_name=tool.name,
                raw_input=kwargs,
                state=effective_state,
                config=config,
                tool_call_id=resolved_tool_call_id,
                tool_flags=effective_tool_flags,
            )

        def _func(
            config: RunnableConfig,
            tool_runtime: ToolRuntime | None = None,
            **kwargs: Any,
        ) -> tuple[str, dict[str, Any]]:
            ctx = _build_ctx(config=config, tool_runtime=tool_runtime, kwargs=kwargs)
            envelope = pipeline.run(tool=tool, raw_input=kwargs, ctx=ctx)
            return adapter.envelope_to_structured_tool_return(
                envelope,
                tool=tool,
                ctx=ctx,
                parsed_input=pipeline.last_parsed_input,
                invoke_result=pipeline.last_invoke_result,
            )

        async def _afunc(
            config: RunnableConfig,
            tool_runtime: ToolRuntime | None = None,
            **kwargs: Any,
        ) -> tuple[str, dict[str, Any]]:
            ctx = _build_ctx(config=config, tool_runtime=tool_runtime, kwargs=kwargs)
            envelope = await pipeline.arun(tool=tool, raw_input=kwargs, ctx=ctx)
            return adapter.envelope_to_structured_tool_return(
                envelope,
                tool=tool,
                ctx=ctx,
                parsed_input=pipeline.last_parsed_input,
                invoke_result=pipeline.last_invoke_result,
            )

        return StructuredTool(
            name=tool.name,
            description=tool.description,
            args_schema=tool.input_model,
            func=_func,
            coroutine=_afunc,
            response_format="content_and_artifact",
        )

    def envelope_to_structured_tool_return(
        self,
        env: ToolResultEnvelope,
        *,
        tool: RuntimeTool | None = None,
        ctx: ToolExecutionContext | None = None,
        parsed_input: dict[str, Any] | None = None,
        invoke_result: Any = None,
    ) -> tuple[str, dict[str, Any]]:
        """同一 envelope 同时映射模型 content 与 out-of-band artifact（_func/_afunc 共用）。"""
        artifact = self.envelope_to_event_artifact(env)
        if tool is not None and ctx is not None and parsed_input is not None:
            display = tool.present_for_display(parsed_input, invoke_result, ctx)
            if display is not None:
                artifact = {
                    **artifact,
                    "display": self._json_safe_value(display),
                }
        return (
            self.envelope_to_tool_output(env),
            artifact,
        )

    def envelope_to_tool_output(self, env: ToolResultEnvelope) -> str:
        """
        将内部 ToolResultEnvelope 映射为 LangChain ToolMessage.content 字符串。

        输出格式：
            ok:      summary + payload 紧凑文本 + artifacts/hints（若有）
            blocked: "Permission denied: <message>"
            error:   summary + payload（若有）
            truncated 时：summary 已包含 overflow_file 提示（由 ToolOutputManager 注入）

        meta 默认不进入输出（面向系统，不面向模型）。
        """
        self._capture_observability(env)

        if env.status == "blocked":
            return env.summary  # "Permission denied: ..."

        parts: list[str] = [env.summary]
        payload_text = self._render_payload(env.payload)
        if payload_text:
            parts.append(payload_text)

        if env.blocks:
            parts.extend(self._render_blocks(env))

        if env.artifacts:
            parts.extend(self._render_artifacts(env))

        if env.hints:
            hint_lines = [f"[Hint: {h.message}]" for h in env.hints]
            parts.extend(hint_lines)

        meta_lines = self._render_selected_meta(env)
        if meta_lines:
            parts.extend(meta_lines)

        return "\n".join(parts)

    def envelope_to_event_artifact(self, env: ToolResultEnvelope) -> dict[str, Any]:
        """
        将 ToolResultEnvelope 映射为 out-of-band 路径专用的轻量 dict 投影。

        输出为纯 dict / list / 基本类型，供 LangGraph checkpoint、TOOL_RESULT 事件、
        Workflow / RPC 消费。不与 envelope_to_tool_output 共享格式化逻辑。
        """
        result = self._envelope_to_event_artifact_dict(env)
        if __debug__:
            try:
                json.dumps(result)
            except TypeError as e:
                raise AssertionError(
                    f"envelope_to_event_artifact produced non-JSON-serializable output: {e}. "
                    "All artifact fields must be JSON-roundtrippable for Workflow/RPC/Checkpoint scenarios."
                ) from e
        return result

    @staticmethod
    def _envelope_to_event_artifact_dict(env: ToolResultEnvelope) -> dict[str, Any]:
        raw = asdict(env)
        raw["schema_version"] = "1"
        return LangChainAdapter._json_safe_value(raw)

    @staticmethod
    def _json_safe_value(value: Any) -> Any:
        """将 asdict 产物下沉为 JSON-roundtrippable 结构（Path/datetime/Enum 等显式转换）。"""
        if value is None or isinstance(value, (bool, int, float, str)):
            return value
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        if is_dataclass(value) and not isinstance(value, type):
            return LangChainAdapter._json_safe_value(asdict(value))
        if isinstance(value, dict):
            return {
                str(k): LangChainAdapter._json_safe_value(v) for k, v in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [LangChainAdapter._json_safe_value(v) for v in value]
        return value

    @staticmethod
    def _render_payload(payload: dict[str, Any] | str | None) -> str | None:
        if payload is None:
            return None
        if isinstance(payload, str):
            return payload

        import json

        try:
            return json.dumps(payload, ensure_ascii=False)
        except Exception:
            return str(payload)

    @staticmethod
    def _render_artifacts(env: ToolResultEnvelope) -> list[str]:
        lines: list[str] = []
        for artifact in env.artifacts or ():
            label = artifact.description or artifact.media_type
            lines.append(f"[Artifact: {label} ({artifact.media_type})]")
        return lines

    @staticmethod
    def _render_blocks(env: ToolResultEnvelope) -> list[str]:
        lines: list[str] = []
        for block in env.blocks or ():
            if block.type == "text" and block.text:
                lines.append(block.text)
            elif block.type == "status" and block.text:
                lines.append(f"[Status] {block.text}")
            elif block.type == "reference":
                ref = block.uri or ""
                label = block.text or "reference"
                lines.append(f"[Reference: {label}] {ref}")
            elif block.type == "image":
                label = block.media_type or "image/*"
                lines.append(f"[Image block: {label}]")
        return lines

    @staticmethod
    def _render_selected_meta(env: ToolResultEnvelope) -> list[str]:
        if not env.meta:
            return []
        keys = (
            "task_id",
            "task_mode",
            "task_status",
            "task_exit_code",
            "auto_backgrounded",
        )
        lines: list[str] = []
        for key in keys:
            if key in env.meta and env.meta[key] is not None:
                lines.append(f"[Meta: {key}={env.meta[key]}]")
        obs = env.meta.get("observability")
        if isinstance(obs, dict):
            events = obs.get("events", [])
            lines.append(f"[Meta: observability_schema={obs.get('schema_version', OBS_SCHEMA_VERSION)}]")
            lines.append(f"[Meta: observability_events={len(events) if isinstance(events, list) else 0}]")
        return lines

    @staticmethod
    def _capture_observability(env: ToolResultEnvelope) -> None:
        if not env.meta:
            return
        obs = env.meta.get("observability")
        cleaned: dict[str, Any] | None = None
        if isinstance(obs, dict):
            cleaned = sanitize_value(obs)
            events = cleaned.get("events")
            if isinstance(events, list):
                cleaned["events"] = sample_events(events, limit=200)
        trace_ctx = (
            cleaned.get("trace_context")
            if isinstance(cleaned, dict) and isinstance(cleaned.get("trace_context"), dict)
            else {}
        )
        tool_call_id = trace_ctx.get("tool_call_id") or env.meta.get("tool_call_id")
        decision_trace = env.meta.get("decision_trace") if isinstance(env.meta.get("decision_trace"), list) else []
        if cleaned is None and not decision_trace:
            return
        record = {
            "schema_version": (cleaned or {}).get("schema_version", OBS_SCHEMA_VERSION),
            "tool_name": env.tool_name,
            "status": env.status,
            "summary": env.summary,
            "observability": cleaned or {},
            "decision_trace": sanitize_value(decision_trace),
        }
        get_global_trace_store().put(tool_call_id, record)
