"""
tool_runtime/process_loader.py — 进程级工具运行时装配（共享 policy / pipeline）

职责：
    持有跨 loop 共享的 PolicyEngine、ToolExecutorPipeline、LangChainAdapter。

链路位置：
    LoopLoader 构造时注入；ToolRuntimeLoader 内部组合本类。

当前裁剪范围：
    不含 RuntimeToolRegistry；不含 per-loop ToolStateBridge / Glob / Grep 实例。
"""

from __future__ import annotations

from .adapter import LangChainAdapter
from .auto_mode.config import AutoModeConfig
from .auto_mode.config_update import (
    apply_auto_mode_config_to_engine,
    apply_auto_mode_config_to_policy,
    merge_auto_mode_config,
)
from .auto_mode.state import get_auto_mode_state
from .pipeline import ToolExecutorPipeline, ToolOutputManager
from .policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from .prompt.handler import PermissionPromptHandler
from .resolvers import PermissionResolver


class ProcessLoader:
    """进程级共享组件：policy / pipeline / adapter。"""

    def __init__(
        self,
        *,
        policy_config: ToolPolicyConfig | None = None,
        policy_engine: PolicyEngine | None = None,
        output_manager: ToolOutputManager | None = None,
        headless: bool = False,
        prompt_handler: PermissionPromptHandler | None = None,
        permission_resolver: PermissionResolver | None = None,
    ) -> None:
        self._headless = headless
        self._permission_resolver = permission_resolver
        self._prompt_handler = prompt_handler
        self._pipeline = ToolExecutorPipeline(
            output_manager=output_manager,
            headless=headless,
            prompt_handler=prompt_handler,
            permission_resolver=permission_resolver,
        )
        self._adapter = LangChainAdapter()
        self._policy_config = policy_config
        if policy_engine is not None:
            self._policy: PolicyEngine | None = policy_engine
        elif policy_config is not None:
            self._policy = DefaultPolicyEngine(policy_config)
        else:
            self._policy = None

    def set_permission_resolver(
        self,
        permission_resolver: PermissionResolver | None,
    ) -> None:
        self._permission_resolver = permission_resolver
        self._pipeline.set_permission_resolver(permission_resolver)

    def set_prompt_handler(
        self,
        prompt_handler: PermissionPromptHandler | None,
    ) -> None:
        self._prompt_handler = prompt_handler
        self._pipeline.set_prompt_handler(prompt_handler)

    def update_auto_mode_config(
        self,
        *,
        enabled: bool | None = None,
        classifier_model: str | None = None,
        classifier_path: str | None = None,
        use_classifier: bool | None = None,
        auto_mode_config: AutoModeConfig | None = None,
    ) -> AutoModeConfig:
        model_id = classifier_model if classifier_model is not None else classifier_path

        if auto_mode_config is not None:
            effective = auto_mode_config
        else:
            current: AutoModeConfig | None = None
            if self._policy_config is not None:
                current = self._policy_config.auto_mode
            elif isinstance(self._policy, DefaultPolicyEngine):
                current = self._policy._config.auto_mode
            effective = merge_auto_mode_config(
                current,
                enabled=enabled,
                classifier_model=model_id,
                use_classifier=use_classifier,
            )

        if self._policy_config is not None:
            apply_auto_mode_config_to_policy(self._policy_config, effective)
        if isinstance(self._policy, DefaultPolicyEngine):
            apply_auto_mode_config_to_engine(self._policy, effective)
        elif enabled is not None:
            get_auto_mode_state().enabled = enabled

        return effective

    @property
    def policy_config(self) -> ToolPolicyConfig | None:
        return self._policy_config

    @property
    def policy(self) -> PolicyEngine | None:
        return self._policy

    @property
    def pipeline(self) -> ToolExecutorPipeline:
        return self._pipeline

    @property
    def adapter(self) -> LangChainAdapter:
        return self._adapter

    @property
    def headless(self) -> bool:
        return self._headless

    @property
    def prompt_handler(self) -> PermissionPromptHandler | None:
        return self._prompt_handler

    @property
    def permission_resolver(self) -> PermissionResolver | None:
        return self._permission_resolver


__all__ = ["ProcessLoader"]
