"""
runtime/state_bridge.py — 工具级最小共享状态管理

职责：
    管理工具执行过程中的跨工具共享状态（last_read_map、tool_audit、last_glob_summary、cwd），
    为 write/edit 的 read-before-write、Edit staleness、Glob hint、Bash cd 等提供统一入口。

链路位置：
    ToolRuntimeLoader.register_default_tools 注入共享 ToolStateBridge；Read/Edit/Bash/Glob
    after_invoke 或校验阶段调用本类。存储后端**仅**为 ``ToolExecutionContext.session_store``
   （``AgentSessionStore``），由 GraphFactory 经 ``configurable`` 注入。

当前裁剪范围：
    不再读写 LangGraph ``ctx.state`` 中 ``_tool_*`` 键（迁移完成）；不在此模块内做 LRU。
"""

from __future__ import annotations

from typing import Any

from .models import ToolExecutionContext
from .session_store import AgentSessionStore


class ToolStateBridge:
    """
    工具级最小共享状态管理器。

    要求 ``ctx.session_store`` 为 ``AgentSessionStore``；否则各方法抛出 ``ValueError``。
    """

    MAX_GLOB_SAMPLE_PATHS = 32

    def __init__(self, *, initial_cwd: str | None = None) -> None:
        """初始化状态 bridge。

        Args:
            initial_cwd: 初始工作目录；None 时 get_cwd 依赖 session 或 raise。
        """
        self._initial_cwd = initial_cwd

    def _require_store(self, ctx: ToolExecutionContext) -> AgentSessionStore:
        raw = ctx.session_store
        if not isinstance(raw, AgentSessionStore):
            raise ValueError(
                "ToolStateBridge requires ToolExecutionContext.session_store to be an "
                "AgentSessionStore instance (LangGraph state _tool_* keys are no longer used)."
            )
        return raw

    # ---- last_read_map ----

    def get_last_read_map(self, ctx: ToolExecutionContext) -> dict[str, Any]:
        return self._require_store(ctx).get_last_read_map_bridge_view()

    def set_last_read_map(
        self,
        ctx: ToolExecutionContext,
        value: dict[str, Any],
    ) -> None:
        self._require_store(ctx).replace_all_file_reads_from_bridge_map(value)

    def get_last_read(
        self, ctx: ToolExecutionContext, file_path: str
    ) -> dict[str, Any] | None:
        raw = self.get_last_read_map(ctx).get(file_path)
        return raw if isinstance(raw, dict) else None

    def set_last_read(
        self,
        ctx: ToolExecutionContext,
        file_path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
        mtime_ms: int = 0,
        content: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        entry: dict[str, Any] = {
            "tool_call_id": ctx.tool_call_id,
            "ts": ctx.now_ts,
            "offset": offset,
            "limit": limit,
            "mtime_ms": mtime_ms,
            "line_start": line_start,
            "line_end": line_end,
        }
        if content is not None:
            entry["content"] = content
        self._require_store(ctx).upsert_last_read_from_bridge_entry(file_path, entry)

    def record_read(
        self,
        ctx: ToolExecutionContext,
        file_path: str,
        *,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        self.set_last_read(
            ctx,
            file_path,
            offset=0,
            limit=None,
            mtime_ms=0,
            line_start=line_start,
            line_end=line_end,
        )

    def has_been_read(self, ctx: ToolExecutionContext, file_path: str) -> bool:
        return file_path in self.get_last_read_map(ctx)

    # ---- tool_audit ----

    def append_audit(
        self,
        ctx: ToolExecutionContext,
        record: dict[str, Any],
    ) -> None:
        self._require_store(ctx).append_audit(record)

    def get_audit_log(self, ctx: ToolExecutionContext) -> list[dict[str, Any]]:
        return self._require_store(ctx).get_audit_log()

    # ---- last_glob_summary ----

    def record_last_glob(
        self,
        ctx: ToolExecutionContext,
        *,
        pattern: str,
        search_root: str,
        filenames: list[str],
        num_files_page: int,
        total_matches: int,
        truncated: bool,
        offset: int,
    ) -> None:
        sample = list(filenames[: self.MAX_GLOB_SAMPLE_PATHS])
        payload = {
            "pattern": pattern,
            "search_root": search_root,
            "sample_paths": sample,
            "num_files_page": int(num_files_page),
            "total_matches": int(total_matches),
            "truncated": bool(truncated),
            "offset": int(offset),
            "tool_call_id": ctx.tool_call_id,
            "ts": ctx.now_ts,
        }
        self._require_store(ctx).set_last_glob_summary(payload)

    def get_last_glob_summary(self, ctx: ToolExecutionContext) -> dict[str, Any] | None:
        return self._require_store(ctx).get_last_glob_summary()

    def clear_last_glob_summary(self, ctx: ToolExecutionContext) -> None:
        self._require_store(ctx).clear_last_glob_summary()

    # ---- cwd ----

    def get_cwd(self, ctx: ToolExecutionContext) -> str:
        return self._require_store(ctx).get_cwd(initial=self._initial_cwd)

    def set_cwd(self, ctx: ToolExecutionContext, cwd: str) -> None:
        self._require_store(ctx).set_cwd(cwd)
