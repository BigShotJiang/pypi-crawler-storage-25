"""
runtime/loader.py — 工具运行时框架进程级初始化入口

职责：
    进程级一次性初始化，组装框架核心组件（pipeline / policy / registry）并统一管理工具注册。
    loader 只负责注册 RuntimeTool，不构造 StructuredTool。
    StructuredTool 构造由 factory（create_loop_agent）在 graph 构建时负责，
    通过 create_loop_agent(loader=...) 在构图时调用 to_langchain_tools() 构造 StructuredTool。

    policy_config 用于构造 DefaultPolicyEngine，在 register() 时自动注入给每个工具。
    工具无需手动传入 policy，由 loader 统一治理。

装配路径：
    ToolRuntimeLoader(policy_config=...) 构造
        → ProcessLoader（共享 policy / pipeline）
        → spawn_loop_loader(...) 构造 per-loop LoopLoader
        → 传入 create_loop_agent(loader=loader, ...)
        → factory 内部调用 loop_loader.registry.to_langchain_tools()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain_core.tools import BaseTool

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .loop_loader import LoopLoader
from .pipeline import ToolExecutorPipeline, ToolOutputManager
from .auto_mode.config import AutoModeConfig
from .process_loader import ProcessLoader
from .registry import RuntimeToolRegistry
from .prompt.handler import PermissionPromptHandler
from .resolvers import PermissionResolver
from .policy import PolicyEngine, ToolPolicyConfig
from .session_store import AgentSessionStore


class ToolRuntimeLoader:
    """
    工具运行时进程级装配入口。

    policy_config:  策略配置，构造 DefaultPolicyEngine 并自动注入给所有注册工具。
                    为 None 时不注入 policy（工具默认 allow，适用于开发/测试模式）。
    policy_engine:  直接传入自定义 PolicyEngine 实例（优先于 policy_config）。
    output_manager: 工具输出大小管控器，为 None 时使用默认配置。
    headless:       是否处于无交互（headless）模式。
                    True  — ask 走 HeadlessPromptHandler（仅 hook 链，无决议则 deny）。
                    False — ask 走 prompt_handler 或 legacy permission_resolver。
    prompt_handler: L3 PermissionPromptHandler；优先于 permission_resolver。
    permission_resolver: 旧 (name, prompt) -> bool 垫片，自动包装为 LegacyResolverPromptHandler。
    """

    def __init__(
        self,
        *,
        policy_config: ToolPolicyConfig | None = None,
        policy_engine: PolicyEngine | None = None,
        output_manager: ToolOutputManager | None = None,
        headless: bool = False,
        prompt_handler: PermissionPromptHandler | None = None,
        permission_resolver: PermissionResolver | None = None,
    ) -> None:
        self._process = ProcessLoader(
            policy_config=policy_config,
            policy_engine=policy_engine,
            output_manager=output_manager,
            headless=headless,
            prompt_handler=prompt_handler,
            permission_resolver=permission_resolver,
        )
        self._registry = RuntimeToolRegistry(
            pipeline=self._process.pipeline,
            adapter=self._process.adapter,
        )

    def register(self, tool: RuntimeTool) -> "ToolRuntimeLoader":
        """
        注册工具并自动注入 PolicyEngine。

        注入规则：
            - 工具已有 _policy（初始化时手动传入）→ 不覆盖，保留工具自己的 policy
            - 工具无 _policy（_policy is None）→ 注入 loader 的统一 policy
        这允许个别工具使用专属 policy，其余工具统一受 loader policy 保护。
        """
        if self._process.policy is not None and getattr(tool, "_policy", None) is None:
            tool._policy = self._process.policy
        self._registry.register(tool)
        return self

    def register_default_tools(
        self,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
        include_agent: bool = True,
        include_skill: bool = False,
        agent_registry: Any | None = None,
    ) -> "ToolRuntimeLoader":
        """
        注册默认工具集（Read/Grep/Glob/Bash + 可选 Agent/Skill）。

        向后兼容：在 loader 自身 registry 上注册（单 loop 模式）。
        create_loop_agent 应优先使用 ``spawn_loop_loader`` 获得 per-loop 隔离。
        """
        loop = self.spawn_loop_loader(
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        loop.register_default_tools(
            include_agent=include_agent,
            include_skill=include_skill,
            agent_registry=agent_registry,
        )
        for tool in loop.registry.list():
            if tool.name not in self._registry._tools:
                self._registry.register(tool)
        return self

    def spawn_loop_loader(
        self,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
    ) -> LoopLoader:
        """构造独立的 per-loop 工具注册表（不污染 loader 主 registry）。"""
        return LoopLoader(
            self._process,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )

    def create_session(self, session_id: str | None = None) -> AgentSessionStore:
        return AgentSessionStore(session_id=session_id)

    def fork_with_tools(self, tools: list[RuntimeTool]) -> "ToolRuntimeLoader":
        """
        基于当前 loader 派生一个子 loader（共享 policy/headless 语义），并注册给定工具集。

        目的：为 subagent 组装“过滤后的工具池”而不丢失权限/管控语义。
        """
        child = ToolRuntimeLoader(
            policy_engine=self._process.policy,
            headless=self._process.headless,
            prompt_handler=self._process.prompt_handler,
            permission_resolver=self._process.permission_resolver,
        )
        for t in tools:
            child.register(t)
        return child

    def set_permission_resolver(
        self,
        permission_resolver: PermissionResolver | None,
    ) -> None:
        """更新 loader 与 pipeline 的 permission_resolver（包装为 L3 垫片）。"""
        self._process.set_permission_resolver(permission_resolver)

    def set_prompt_handler(
        self,
        prompt_handler: PermissionPromptHandler | None,
    ) -> None:
        """更新 loader 与 pipeline 的 prompt_handler。"""
        self._process.set_prompt_handler(prompt_handler)

    def update_auto_mode_config(
        self,
        *,
        enabled: bool | None = None,
        classifier_model: str | None = None,
        classifier_path: str | None = None,
        use_classifier: bool | None = None,
        auto_mode_config: AutoModeConfig | None = None,
    ) -> AutoModeConfig:
        return self._process.update_auto_mode_config(
            enabled=enabled,
            classifier_model=classifier_model,
            classifier_path=classifier_path,
            use_classifier=use_classifier,
            auto_mode_config=auto_mode_config,
        )

    @property
    def process_loader(self) -> ProcessLoader:
        return self._process

    @property
    def policy_config(self) -> ToolPolicyConfig | None:
        return self._process.policy_config

    @property
    def policy(self) -> PolicyEngine | None:
        return self._process.policy

    @property
    def registry(self) -> RuntimeToolRegistry:
        return self._registry

    @property
    def pipeline(self) -> ToolExecutorPipeline:
        return self._process.pipeline

    @property
    def adapter(self) -> LangChainAdapter:
        return self._process.adapter

    def __repr__(self) -> str:
        return f"<ToolRuntimeLoader tools={list(self._registry._tools.keys())}>"
