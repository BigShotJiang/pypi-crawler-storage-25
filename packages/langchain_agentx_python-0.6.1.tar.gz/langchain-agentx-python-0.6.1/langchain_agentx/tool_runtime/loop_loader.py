"""
tool_runtime/loop_loader.py — loop 级工具注册与隔离实例

职责：
    每个 loop_agent 持有独立 RuntimeToolRegistry、ToolStateBridge、Glob/Grep 实例。

链路位置：
    create_loop_agent 经 ToolRuntimeLoader.spawn_loop_loader 构造 per-loop 实例。

当前裁剪范围：
    不含进程级 policy/pipeline 构造；从 ProcessLoader 注入共享组件。
"""

from __future__ import annotations

from typing import Any

from .path_safety import PathSafetyConfig
from .process_loader import ProcessLoader
from .read_ignore_patterns import ReadDenyPatternCollector
from .registry import RuntimeToolRegistry
from .policy import DefaultPolicyEngine


class LoopLoader:
    """单 loop 工具注册表与 per-loop 工具实例。"""

    def __init__(
        self,
        process: ProcessLoader,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
    ) -> None:
        self._process = process
        self._workspace_root = workspace_root
        self._agent_home = agent_home
        self._registry = RuntimeToolRegistry(
            pipeline=process.pipeline,
            adapter=process.adapter,
        )

    @property
    def process(self) -> ProcessLoader:
        return self._process

    @property
    def registry(self) -> RuntimeToolRegistry:
        return self._registry

    @property
    def workspace_root(self) -> str:
        return self._workspace_root

    def register(self, tool: Any) -> "LoopLoader":
        policy = self._process.policy
        if policy is not None and getattr(tool, "_policy", None) is None:
            tool._policy = policy
        self._registry.register(tool)
        return self

    def register_default_tools(
        self,
        *,
        include_agent: bool = True,
        include_skill: bool = False,
        agent_registry: Any | None = None,
    ) -> "LoopLoader":
        from pathlib import Path

        from langchain_agentx.tools.ask_user_question import AskUserQuestionTool
        from langchain_agentx.tools.bash import BashRuntimeTool
        from langchain_agentx.tools.edit import EditRuntimeTool
        from langchain_agentx.tools.edit.settings_validator import SettingsValidator
        from langchain_agentx.tools.edit.staleness import StalenessChecker
        from langchain_agentx.tools.edit.validator import EditStringValidator
        from langchain_agentx.tools.glob import GlobRuntimeTool
        from langchain_agentx.tools.grep import GrepRuntimeTool
        from langchain_agentx.tools.read import ReadRuntimeTool
        from langchain_agentx.tools.ripgrep_plugin_exclusions import PluginCacheGlobExclusions
        from langchain_agentx.tools.task_list.tool import TaskListRuntimeTool
        from langchain_agentx.tools.user_message import UserMessageTool
        from langchain_agentx.tools.webfetch import loader as webfetch_loader
        from langchain_agentx.tools.websearch import loader as websearch_loader
        from langchain_agentx.tools.write import WriteRuntimeTool
        from langchain_agentx.tool_runtime.state_bridge import ToolStateBridge
        from langchain_agentx.workspace.config import AgentWorkspaceConfig

        wr = Path(self._workspace_root).resolve()
        cfg = AgentWorkspaceConfig(workspace_root=wr, agent_home=self._agent_home)
        self._inject_path_safety_policy(
            workspace_root=str(wr),
            agent_home_segment=cfg.agent_home_dir.name,
        )
        plugin_ex = PluginCacheGlobExclusions(
            cache_root=str(cfg.plugin_cache_dir.resolve()),
        )

        shared_bridge = ToolStateBridge(initial_cwd=str(wr))
        search_ignore_patterns = self._collect_search_ignore_patterns()

        settings_validator = SettingsValidator(agent_home_segment=cfg.agent_home_dir.name)
        edit_staleness = StalenessChecker(shared_bridge)
        edit_string_validator = EditStringValidator(
            state_bridge=shared_bridge,
            staleness_checker=edit_staleness,
            settings_validator=settings_validator,
        )

        self.register(ReadRuntimeTool(state_bridge=shared_bridge))
        self.register(WriteRuntimeTool(state_bridge=shared_bridge))
        self.register(
            EditRuntimeTool(
                state_bridge=shared_bridge,
                string_validator=edit_string_validator,
                staleness_checker=edit_staleness,
            )
        )
        self.register(
            GrepRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
                ignore_patterns=search_ignore_patterns or None,
            )
        )
        self.register(
            GlobRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
                state_bridge=shared_bridge,
                ignore_patterns=search_ignore_patterns or None,
            )
        )
        self.register(BashRuntimeTool(state_bridge=shared_bridge))
        self.register(UserMessageTool())
        self.register(AskUserQuestionTool())
        self.register(TaskListRuntimeTool(config=cfg))

        websearch_loader.register(self)
        webfetch_loader.register(self)

        if include_agent:
            from langchain_agentx.tools.agent import AgentRuntimeTool

            self.register(AgentRuntimeTool(registry=agent_registry))

        if include_skill:
            from langchain_agentx.tools.skill import SkillRuntimeTool

            self.register(
                SkillRuntimeTool(
                    workspace_root=self._workspace_root,
                    agent_home=self._agent_home,
                )
            )

        return self

    def _collect_search_ignore_patterns(self) -> list[str]:
        cfg = self._process.policy_config
        policy = self._process.policy
        if cfg is None and isinstance(policy, DefaultPolicyEngine):
            cfg = policy._config
        return ReadDenyPatternCollector().collect(cfg)

    def _inject_path_safety_policy(
        self,
        *,
        workspace_root: str,
        agent_home_segment: str,
    ) -> None:
        path_cfg = PathSafetyConfig.from_workspace(
            workspace_root=workspace_root,
            agent_home_segment=agent_home_segment,
        )
        policy_config = self._process.policy_config
        if policy_config is not None and policy_config.path_safety is None:
            policy_config.path_safety = path_cfg
        policy = self._process.policy
        if isinstance(policy, DefaultPolicyEngine):
            pc = policy._config
            if pc.path_safety is None:
                pc.path_safety = path_cfg


__all__ = ["LoopLoader"]
