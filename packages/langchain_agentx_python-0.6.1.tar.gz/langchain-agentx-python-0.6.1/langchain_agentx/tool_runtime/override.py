"""
tool_runtime/override.py — deny 决策覆盖（L4 UX seam）

职责：
    记录 policy deny 的 tool_call，供 UI/CLI 展示覆盖横幅；
    apply_override 更新会话态；grant_replay / consume_replay 支持新 id 一次性放行。

链路位置：
    pipeline Step 4 → consume_replay → allow 短路
    pipeline deny → enrich_blocked_deny_envelope → request_override

CC 对照：
    不复用同一 toolUseID 重放（避免 transcript 双 ToolMessage 同 id）；
    宿主废掉原 deny 行后以新 tool 调用派发，与本仓 new-id replay grant 一致。
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from .models import AuthorizationDecision, ToolExecutionContext, ToolResultEnvelope
from .permission_decision import (
    ENVELOPE_META_KEY_CAN_OVERRIDE,
    ENVELOPE_META_KEY_DENY_OVERRIDE,
    ENVELOPE_META_KEY_POLICY_ID,
    ENVELOPE_META_KEY_TOOL_CALL_ID,
    POLICY_ID_DENY_OVERRIDE_CONSUMED,
    PermissionDecisionType,
    attach_decision_reason,
    make_decision_reason,
)

if TYPE_CHECKING:
    from .base import RuntimeTool
    from .session_store import AgentSessionStore

logger = logging.getLogger(__name__)

OverrideDecision = Literal["allow", "confirm_deny"]
OverrideActor = Literal["user", "admin"]
RecordStatus = Literal["pending", "allow", "confirm_deny"]


@dataclass
class DenyOverrideRecord:
    """单次 deny 的覆盖记录。"""

    tool_call_id: str
    tool_name: str
    original_decision: AuthorizationDecision
    original_input: dict[str, Any] = field(default_factory=dict)
    override_decision: RecordStatus = "pending"
    override_at: float | None = None
    override_by: OverrideActor | None = None

    def to_dict(self) -> dict[str, Any]:
        orig = self.original_decision
        return {
            "tool_call_id": self.tool_call_id,
            "tool_name": self.tool_name,
            "original_decision": {
                "behavior": orig.behavior,
                "message": orig.message,
                "policy_id": orig.policy_id,
                "metadata": orig.metadata,
            },
            "original_input": dict(self.original_input),
            "override_decision": self.override_decision,
            "override_at": self.override_at,
            "override_by": self.override_by,
        }


class DenyOverrideManager:
    """deny 覆盖管理器，绑定 AgentSessionStore。"""

    _STORE_KEY = "_deny_overrides"
    _GRANTS_KEY = "_deny_override_replay_grants"

    def __init__(self, session_store: AgentSessionStore) -> None:
        self._store = session_store
        if not hasattr(session_store, self._STORE_KEY):
            setattr(session_store, self._STORE_KEY, {})
        if not hasattr(session_store, self._GRANTS_KEY):
            setattr(session_store, self._GRANTS_KEY, {})

    def _records(self) -> dict[str, DenyOverrideRecord]:
        raw = getattr(self._store, self._STORE_KEY)
        return raw if isinstance(raw, dict) else {}

    def _grants(self) -> dict[str, str]:
        raw = getattr(self._store, self._GRANTS_KEY)
        return raw if isinstance(raw, dict) else {}

    def request_override(
        self,
        tool_call_id: str,
        tool_name: str,
        original_decision: AuthorizationDecision,
        *,
        override_by: OverrideActor = "user",
        original_input: dict[str, Any] | None = None,
    ) -> DenyOverrideRecord:
        """标记某次 deny 为待覆盖状态，返回记录供 UI 展示。"""
        if not tool_call_id:
            raise ValueError("tool_call_id is required for deny override")

        record = DenyOverrideRecord(
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            original_decision=original_decision,
            original_input=dict(original_input or {}),
            override_decision="pending",
            override_by=override_by,
        )
        self._records()[tool_call_id] = record
        self._store.append_audit(
            {
                "event": "deny_override_requested",
                "ts": time.time(),
                **record.to_dict(),
            }
        )
        return record

    def get(self, tool_call_id: str) -> DenyOverrideRecord | None:
        return self._records().get(tool_call_id)

    def apply_override(self, tool_call_id: str, decision: OverrideDecision) -> bool:
        """应用覆盖决策，更新会话状态。"""
        records = self._records()
        record = records.get(tool_call_id)
        if record is None or record.override_decision != "pending":
            return False

        record.override_decision = decision
        record.override_at = time.time()
        self._store.append_audit(
            {
                "event": "deny_override_applied",
                "ts": record.override_at,
                "tool_call_id": tool_call_id,
                "override_decision": decision,
                "override_by": record.override_by,
            }
        )
        return True

    def grant_replay(self, original_tool_call_id: str, replay_tool_call_id: str) -> bool:
        """在 apply_override(original, \"allow\") 之后颁发一次性 replay grant。"""
        record = self._records().get(original_tool_call_id)
        if record is None or record.override_decision != "allow":
            return False
        self._grants()[replay_tool_call_id] = original_tool_call_id
        self._store.append_audit(
            {
                "event": "deny_override_replay_granted",
                "ts": time.time(),
                "original_tool_call_id": original_tool_call_id,
                "replay_tool_call_id": replay_tool_call_id,
            }
        )
        return True

    def consume_replay(self, tool_call_id: str) -> str | None:
        """Pipeline 调用：命中 replay grant 时弹出并返回原 tool_call_id。"""
        original = self._grants().pop(tool_call_id, None)
        if original is not None:
            self._store.append_audit(
                {
                    "event": "deny_override_replay_consumed",
                    "ts": time.time(),
                    "original_tool_call_id": original,
                    "replay_tool_call_id": tool_call_id,
                }
            )
        return original

    def list_pending(self) -> list[DenyOverrideRecord]:
        return [r for r in self._records().values() if r.override_decision == "pending"]


def authorization_from_replay_grant(ctx: ToolExecutionContext) -> AuthorizationDecision | None:
    """Step 4 前消费 replay grant；命中则返回 allow，否则 None。"""
    if ctx.session_store is None or not ctx.tool_call_id:
        return None
    replay_origin = ctx.session_store.deny_overrides.consume_replay(ctx.tool_call_id)
    if replay_origin is None:
        return None
    logger.info(
        "tool deny override consumed tool=%s replay=%s origin=%s",
        ctx.tool_name,
        ctx.tool_call_id,
        replay_origin,
    )
    return attach_decision_reason(
        AuthorizationDecision(
            behavior="allow",
            policy_id=POLICY_ID_DENY_OVERRIDE_CONSUMED,
        ),
        make_decision_reason(
            PermissionDecisionType.OVERRIDE,
            replayed_from=replay_origin,
        ),
    )


def resolve_step4_authorization(
    tool: RuntimeTool,
    parsed_data: dict[str, Any],
    ctx: ToolExecutionContext,
) -> AuthorizationDecision:
    """同步 Step 4：replay grant 优先，否则 tool.check_permissions。"""
    granted = authorization_from_replay_grant(ctx)
    if granted is not None:
        return granted
    return tool.check_permissions(parsed_data, ctx)


async def resolve_step4_aauthorization(
    tool: RuntimeTool,
    parsed_data: dict[str, Any],
    ctx: ToolExecutionContext,
) -> AuthorizationDecision:
    """异步 Step 4：replay grant 优先，否则 aauthorize / check_permissions。"""
    granted = authorization_from_replay_grant(ctx)
    if granted is not None:
        return granted
    policy = getattr(tool, "_policy", None)
    if policy is not None and hasattr(policy, "aauthorize"):
        return await policy.aauthorize(
            tool_name=tool.name,
            input_data=parsed_data,
            ctx=ctx,
        )
    return tool.check_permissions(parsed_data, ctx)


def enrich_blocked_deny_envelope(
    envelope: ToolResultEnvelope,
    *,
    ctx: ToolExecutionContext,
    auth: AuthorizationDecision,
    input_data: dict[str, Any] | None = None,
) -> ToolResultEnvelope:
    """在 blocked deny envelope 上附加 can_override 并登记待覆盖记录。

    写入到 ``envelope.meta`` 的字段（key 见
    :mod:`langchain_agentx.tool_runtime.permission_decision` 中
    ``ENVELOPE_META_KEY_*`` 常量；CLI/测试/Trace UI 必须使用常量读取）：

    - ``ENVELOPE_META_KEY_CAN_OVERRIDE`` (``"can_override"``) — ``bool``，
      固定 ``True``，仅当 ``auth.behavior == "deny"`` 且 ``ctx.tool_call_id``
      非空时写入；否则函数原样返回不修改 envelope。
    - ``ENVELOPE_META_KEY_TOOL_CALL_ID`` (``"tool_call_id"``) — ``str``，
      使用 ``setdefault``，已有同名 meta 不覆盖。
    - ``ENVELOPE_META_KEY_POLICY_ID`` (``"policy_id"``) — ``str | None``，
      与 ``auth.policy_id`` 一致；使用 ``setdefault``。
    - ``ENVELOPE_META_KEY_DENY_OVERRIDE`` (``"deny_override"``) — ``dict``，
      :class:`DenyOverrideRecord` 的 ``to_dict()`` 快照；仅当
      ``ctx.session_store`` 非 ``None`` 时写入（同时会调用
      ``session_store.deny_overrides.request_override`` 登记记录）。
    """
    tool_call_id = ctx.tool_call_id
    if not tool_call_id or auth.behavior != "deny":
        return envelope

    meta = dict(envelope.meta or {})
    meta[ENVELOPE_META_KEY_CAN_OVERRIDE] = True
    meta.setdefault(ENVELOPE_META_KEY_TOOL_CALL_ID, tool_call_id)
    meta.setdefault(ENVELOPE_META_KEY_POLICY_ID, auth.policy_id)

    store = ctx.session_store
    if store is not None:
        mgr = DenyOverrideManager(store)
        record = mgr.request_override(
            tool_call_id,
            ctx.tool_name,
            auth,
            original_input=input_data or {},
        )
        meta[ENVELOPE_META_KEY_DENY_OVERRIDE] = record.to_dict()

    envelope.meta = meta
    return envelope
