"""
read_ignore_patterns.py — Read deny 规则 → Glob/Grep ripgrep 排除模式

职责：
    对齐 CC ``getFileReadIgnorePatterns``：将策略中的 Read 专用 deny glob 转为
    ``ignore_patterns``，供 ``build_rg_files_args`` / ``RipgrepBackend`` 追加 ``!pattern``。

链路位置：
    ``ToolRuntimeLoader.register_default_tools`` → ``ReadDenyPatternCollector.collect``
    → ``GlobRuntimeTool`` / ``GrepRuntimeTool`` 构造参数。

当前裁剪范围：
    不解析宿主 permissions.json；仅消费 ``ToolPolicyConfig.read_deny_globs``。
    不做按 root 分组的 ``normalizePatternsToPath``（单 workspace 搜索根足够）。
"""

from __future__ import annotations

from dataclasses import dataclass

from .policy import ToolPolicyConfig


def normalize_read_deny_pattern(pattern: str) -> str:
    """
    规范化单条 Read deny glob（对齐 CC patternWithRoot 对 ``./`` 前缀的处理）。

    返回供 ripgrep ``--glob '!…'`` 使用的相对 pattern（不含 ``!`` 前缀）。
    """
    p = str(pattern).strip()
    if not p:
        return ""
    if p.startswith("./"):
        p = p[2:]
    return p


@dataclass
class ReadDenyPatternCollector:
    """从 ``ToolPolicyConfig`` 收集 Read deny → 搜索工具 ``ignore_patterns``。"""

    def collect(self, config: ToolPolicyConfig | None) -> list[str]:
        if config is None:
            return []
        out: list[str] = []
        seen: set[str] = set()
        for raw in config.read_deny_globs:
            norm = normalize_read_deny_pattern(raw)
            if not norm or norm in seen:
                continue
            seen.add(norm)
            out.append(norm)
        return out
