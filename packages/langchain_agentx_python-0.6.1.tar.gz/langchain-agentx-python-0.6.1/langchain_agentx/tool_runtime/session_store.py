"""
runtime/session_store.py — 会话级状态存储

职责：
    AgentSessionStore 是 session 级别的状态对象，生命周期与一次 Agent 会话对齐。
    它独立于 LangGraph graph state（turn 级）和 ToolExecutionContext（call 级），
    负责跨 turn 持久化的会话状态：

        file_read_state   — 文件读取记录（为 read-before-write / Edit staleness 服务）
        file_history      — 文件写入/编辑历史
        audit_log         — 工具调用审计日志（含权限窗口事件与工具框架审计）
        permissions_cache — 权限决策缓存（避免重复询问）
        cwd               — Bash cd 等工作目录（与 ToolStateBridge 对齐的会话后端字段）
        last_glob_summary — 最近一次 Glob 摘要（hint，非授权依据）
        granted_roots     — 动态扩展的 read/write 边界（Phase 2 grant API）

链路位置：
    GraphFactory 注入 configurable["session_store"] → LangChainAdapter.build_tool_execution_context
    → ToolExecutionContext.session_store；ToolStateBridge **仅**读写本对象。

当前裁剪范围：
    不做磁盘持久化；grant 随 session 生命周期；enable_dynamic_root_grant 默认 False（workflow）。
"""

from __future__ import annotations

import copy
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from langchain_agentx.workspace.grant import GrantedRoot

if TYPE_CHECKING:
    from langchain_agentx.workspace.boundary import WorkspaceBoundary


@dataclass
class FileReadRecord:
    path: str
    tool_call_id: str | None
    ts: float
    line_start: int | None = None
    line_end: int | None = None
    offset: int | None = None
    limit: int | None = None
    mtime_ms: int = 0
    content: str | None = None

    def to_bridge_dict(self) -> dict[str, Any]:
        """转为 ToolStateBridge / StalenessChecker 消费的 dict 形态。"""
        out: dict[str, Any] = {
            "tool_call_id": self.tool_call_id,
            "ts": self.ts,
            "offset": self.offset,
            "limit": self.limit,
            "mtime_ms": self.mtime_ms,
            "line_start": self.line_start,
            "line_end": self.line_end,
        }
        if self.content is not None:
            out["content"] = self.content
        return out

    @classmethod
    def from_bridge_dict(cls, path: str, d: dict[str, Any]) -> FileReadRecord:
        ts_raw = d.get("ts")
        ts = float(ts_raw) if isinstance(ts_raw, (int, float)) else time.time()
        mtime_raw = d.get("mtime_ms", 0)
        try:
            mtime_ms = int(mtime_raw) if mtime_raw is not None else 0
        except (TypeError, ValueError):
            mtime_ms = 0
        raw_tid = d.get("tool_call_id")
        tool_call_id = raw_tid if isinstance(raw_tid, str) or raw_tid is None else None
        raw_content = d.get("content")
        content = raw_content if isinstance(raw_content, str) or raw_content is None else None
        return cls(
            path=path,
            tool_call_id=tool_call_id,
            ts=ts,
            line_start=d.get("line_start"),
            line_end=d.get("line_end"),
            offset=d.get("offset"),
            limit=d.get("limit"),
            mtime_ms=mtime_ms,
            content=content,
        )


@dataclass
class FileWriteRecord:
    path: str
    operation: str
    tool_call_id: str | None
    ts: float


class AgentSessionStore:
    CONFIGURABLE_KEY = "session_store"

    def __init__(self, session_id: str | None = None) -> None:
        self.session_id: str = session_id or str(uuid.uuid4())
        self._created_at: float = time.time()
        self._file_read_state: dict[str, FileReadRecord] = {}
        self._file_history: list[FileWriteRecord] = []
        self._audit_log: list[dict[str, Any]] = []
        self._permissions_cache: dict[str, Any] = {}
        self._cwd: str | None = None
        self._last_glob_summary: dict[str, Any] | None = None
        self._granted_roots: list[GrantedRoot] = []
        self.enable_dynamic_root_grant: bool = False
        self._boundary_for_grant: WorkspaceBoundary | None = None
        self._root_grant_manager: Any | None = None

    def record_file_read(
        self,
        path: str,
        *,
        tool_call_id: str | None = None,
        ts: float | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
        offset: int | None = None,
        limit: int | None = None,
        mtime_ms: int = 0,
        content: str | None = None,
    ) -> None:
        self._file_read_state[path] = FileReadRecord(
            path=path,
            tool_call_id=tool_call_id,
            ts=ts if ts is not None else time.time(),
            line_start=line_start,
            line_end=line_end,
            offset=offset,
            limit=limit,
            mtime_ms=mtime_ms,
            content=content,
        )

    def upsert_last_read_from_bridge_entry(
        self,
        path: str,
        entry: dict[str, Any],
    ) -> None:
        """用与 LangGraph state 中 last_read 条目同构的 dict 覆盖该路径。"""
        self._file_read_state[path] = FileReadRecord.from_bridge_dict(path, entry)

    def replace_all_file_reads_from_bridge_map(self, data: dict[str, Any]) -> None:
        """整体替换文件读映射（对应 ToolStateBridge.set_last_read_map）。"""
        self._file_read_state.clear()
        for path, raw in data.items():
            if isinstance(raw, dict):
                self._file_read_state[path] = FileReadRecord.from_bridge_dict(str(path), raw)

    def get_last_read_map_bridge_view(self) -> dict[str, dict[str, Any]]:
        """返回 path → bridge dict，供 ToolStateBridge 与 StalenessChecker 使用。"""
        return {p: rec.to_bridge_dict() for p, rec in self._file_read_state.items()}

    def has_been_read(self, path: str) -> bool:
        return path in self._file_read_state

    def get_file_read_record(self, path: str) -> FileReadRecord | None:
        return self._file_read_state.get(path)

    def get_all_read_paths(self) -> list[str]:
        return list(self._file_read_state.keys())

    def record_file_write(
        self,
        path: str,
        operation: str,
        *,
        tool_call_id: str | None = None,
        ts: float | None = None,
    ) -> None:
        self._file_history.append(
            FileWriteRecord(
                path=path,
                operation=operation,
                tool_call_id=tool_call_id,
                ts=ts if ts is not None else time.time(),
            )
        )

    def get_file_history(self) -> list[FileWriteRecord]:
        return list(self._file_history)

    def append_audit(self, record: dict[str, Any]) -> None:
        self._audit_log.append(record)

    def get_audit_log(self) -> list[dict[str, Any]]:
        return list(self._audit_log)

    def export_audit_log(self) -> list[dict[str, Any]]:
        """语义化导出出口；等价于 get_audit_log()."""
        return self.get_audit_log()

    def cache_permission(self, key: str, decision: Any) -> None:
        self._permissions_cache[key] = decision

    def get_cached_permission(self, key: str) -> Any | None:
        return self._permissions_cache.get(key)

    @property
    def granted_roots(self) -> tuple[GrantedRoot, ...]:
        """动态授权根；返回不可变副本。"""
        return tuple(self._granted_roots)

    def configure_root_grant(
        self,
        *,
        enabled: bool,
        boundary: WorkspaceBoundary | None = None,
    ) -> None:
        """由 create_loop_agent 注入 grant 开关与 boundary（去重参照）。"""
        self.enable_dynamic_root_grant = bool(enabled)
        self._boundary_for_grant = boundary
        self._root_grant_manager = None

    def _grant_manager(self) -> Any:
        from langchain_agentx.workspace.root_grant_manager import RootGrantManager

        if self._root_grant_manager is None:
            self._root_grant_manager = RootGrantManager(
                self,
                boundary=self._boundary_for_grant,
            )
        return self._root_grant_manager

    def grant_root(
        self,
        *,
        path: str | Path,
        scope: Literal["read", "write"] = "read",
        granter: Literal["user", "policy", "config"],
        reason: str | None = None,
        tool_call_id: str | None = None,
    ) -> str:
        return self._grant_manager().grant_root(
            path=path,
            scope=scope,
            granter=granter,
            reason=reason,
            tool_call_id=tool_call_id,
        )

    def revoke_grant(self, grant_id: str) -> bool:
        return self._grant_manager().revoke_grant(grant_id)

    def list_grants(
        self,
        *,
        scope: Literal["read", "write"] | None = None,
    ) -> list[GrantedRoot]:
        return self._grant_manager().list_grants(scope=scope)

    # ---- cwd（与 ToolStateBridge 会话后端对齐）----

    def get_cwd(self, *, initial: str | None = None) -> str:
        """已 set 的会话 cwd → initial；无可用值时 raise。"""
        if isinstance(self._cwd, str) and self._cwd:
            return self._cwd
        if isinstance(initial, str) and initial:
            return initial
        raise ValueError(
            "session cwd unset and no initial_cwd provided; "
            "set cwd via ToolStateBridge or pass initial_cwd"
        )

    def set_cwd(self, cwd: str) -> None:
        self._cwd = cwd

    def clear_cwd(self) -> None:
        self._cwd = None

    @property
    def cwd_override(self) -> str | None:
        """Bash cd 等显式设置过的 cwd；未设置时为 None。"""
        if isinstance(self._cwd, str) and self._cwd:
            return self._cwd
        return None

    # ---- last_glob_summary ----

    def set_last_glob_summary(self, payload: dict[str, Any]) -> None:
        self._last_glob_summary = dict(payload)

    def get_last_glob_summary(self) -> dict[str, Any] | None:
        if self._last_glob_summary is None:
            return None
        return dict(self._last_glob_summary)

    def clear_last_glob_summary(self) -> None:
        self._last_glob_summary = None

    # ---- fork：仅克隆文件读状态（权限 / cwd / glob 不共享）----

    def clone(self, *, file_state_only: bool = True) -> AgentSessionStore:
        new = AgentSessionStore(session_id=str(uuid.uuid4()))
        new._file_read_state = {
            k: copy.deepcopy(v) for k, v in self._file_read_state.items()
        }
        if not file_state_only:
            new._audit_log = copy.deepcopy(self._audit_log)
            new._file_history = copy.deepcopy(self._file_history)
        return new

    @property
    def created_at(self) -> float:
        return self._created_at

    @property
    def deny_overrides(self) -> "DenyOverrideManager":
        """会话级 deny 覆盖管理器（懒创建）。"""
        from .override import DenyOverrideManager

        mgr = getattr(self, "_deny_override_mgr", None)
        if mgr is None:
            mgr = DenyOverrideManager(self)
            self._deny_override_mgr = mgr
        return mgr

    def summary(self) -> dict[str, Any]:
        pending_overrides = 0
        if hasattr(self, "_deny_overrides") and isinstance(self._deny_overrides, dict):
            pending_overrides = sum(
                1
                for r in self._deny_overrides.values()
                if getattr(r, "override_decision", None) == "pending"
            )
        return {
            "session_id": self.session_id,
            "created_at": self._created_at,
            "files_read": len(self._file_read_state),
            "file_writes": len(self._file_history),
            "audit_entries": len(self._audit_log),
            "cached_permissions": len(self._permissions_cache),
            "has_cwd_override": bool(self._cwd),
            "has_glob_summary": self._last_glob_summary is not None,
            "granted_roots": len(self._granted_roots),
            "dynamic_root_grant_enabled": self.enable_dynamic_root_grant,
            "pending_deny_overrides": pending_overrides,
        }

    def __repr__(self) -> str:
        return (
            f"<AgentSessionStore session_id={self.session_id!r} "
            f"files_read={len(self._file_read_state)} "
            f"audit_entries={len(self._audit_log)}>"
        )
