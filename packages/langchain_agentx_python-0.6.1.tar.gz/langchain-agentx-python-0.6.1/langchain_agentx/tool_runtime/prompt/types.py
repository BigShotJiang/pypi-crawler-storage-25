"""
prompt/types.py — L3 HITL 数据契约

职责：
    PromptRequest / PromptResponse 与 PermissionUpdate、PromptDecisionSource。
    L2 ask 决策打包为 PromptRequest，L3 产出二态 PromptResponse。

链路位置：
    ToolExecutorPipeline ask 分支 → PermissionPromptHandler.handle（Phase 3 接线）。

当前裁剪：
    PermissionUpdate 为 CC addRules/replaceRules 等的最小 Python 镜像；持久化由 Phase 3 接入。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Literal

from ..models import AuthorizationDecision, ToolExecutionContext
from .messages import (
    GENERIC_DENY_TEMPLATE,
    NO_PARTICIPANTS_TEMPLATE,
    PROMPTS_UNAVAILABLE_TEMPLATE,
    UI_RESPONSE_TIMEOUT_TEMPLATE,
    USER_ABORT_TEMPLATE,
)


class PromptDecisionSource(StrEnum):
    """L3 决议来源，对齐 CC decisionReason.type。"""

    USER_UI = "user_ui"
    PERMISSION_HOOK = "permission_hook"
    CLASSIFIER = "classifier"
    HEADLESS_FALLBACK = "headless_fallback"
    LEGACY_RESOLVER = "legacy_resolver"


class DecisionReasonType(StrEnum):
    """结构化拒因类型（内部诊断 + LLM 模板路由）。"""

    HOOK_DENY = "hook_deny"
    CLASSIFIER_DENY = "classifier_deny"
    USER_REJECT = "user_reject"
    NO_PARTICIPANTS = "no_participants"
    PROMPTS_UNAVAILABLE = "prompts_unavailable"
    UI_RESPONSE_TIMEOUT = "ui_response_timeout"
    USER_ABORT = "user_abort"
    NO_DECISION = "no_decision"


@dataclass(frozen=True)
class DecisionReason:
    type: DecisionReasonType
    detail: str | None = None

    def to_llm_message(self, tool_name: str) -> str:
        if self.type == DecisionReasonType.PROMPTS_UNAVAILABLE:
            return PROMPTS_UNAVAILABLE_TEMPLATE.format(tool_name=tool_name)
        if self.type == DecisionReasonType.UI_RESPONSE_TIMEOUT:
            return UI_RESPONSE_TIMEOUT_TEMPLATE.format(tool_name=tool_name)
        if self.type == DecisionReasonType.USER_ABORT:
            return USER_ABORT_TEMPLATE.format(tool_name=tool_name)
        if self.type == DecisionReasonType.NO_PARTICIPANTS:
            return NO_PARTICIPANTS_TEMPLATE.format(tool_name=tool_name)
        if self.detail:
            return f"Permission to use {tool_name} has been denied: {self.detail}"
        return GENERIC_DENY_TEMPLATE.format(tool_name=tool_name)


@dataclass(frozen=True)
class PermissionUpdate:
    """
    用户或 hook 同意的权限规则更新（CC PermissionUpdate 子集）。

    type: addRules | replaceRules | removeRules | setMode | addDirectories | removeDirectories
    """

    type: str
    destination: str = "session"
    behavior: str | None = None
    rules: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    mode: str | None = None
    directories: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PromptRequest:
    """L2 ask → L3 入参；不传 PolicyEngine 实例。"""

    tool_name: str
    input_data: dict[str, Any]
    ctx: ToolExecutionContext
    ask_decision: AuthorizationDecision
    headless: bool = False
    """单次请求强制 headless（罕见 override；默认 False）。"""
    session_headless: bool = False
    """会话级 headless（对齐 CC shouldAvoidPermissionPrompts）。"""
    ask_prompt: str | None = None
    suggestions: tuple[PermissionUpdate, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PromptResponse:
    """L3 → Pipeline 出参；behavior 仅 allow/deny。"""

    behavior: Literal["allow", "deny"]
    decision_source: PromptDecisionSource
    decision_reason: DecisionReason | None = None
    message: str | None = None
    updated_input: dict[str, Any] | None = None
    permission_updates: tuple[PermissionUpdate, ...] = field(default_factory=tuple)

    @property
    def reason(self) -> str | None:
        """Deprecated：请用 ``message`` 或 ``decision_reason.detail``。"""
        if self.message is not None:
            return self.message
        if self.decision_reason is not None:
            return self.decision_reason.detail
        return None
