"""
prompt/session_mode.py — 会话 headless 推断（对齐 CC shouldAvoidPermissionPrompts）

职责：
    在 session / loop 创建时推断是否应避免交互式 permission prompt。
"""

from __future__ import annotations

import sys

_HEADLESS_CONTAINER_TYPES = frozenset({"background", "batch", "worker", "sdk"})


def infer_session_headless(
    *,
    headless: bool | None,
    container_type: str | None = None,
) -> bool:
    """显式 ``headless`` 优先；否则 container_type 或无 TTY stdout 推断。"""
    if headless is not None:
        return headless
    if container_type in _HEADLESS_CONTAINER_TYPES:
        return True
    try:
        return not sys.stdout.isatty()
    except Exception:
        return False
