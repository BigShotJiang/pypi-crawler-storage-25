"""
prompt/headless.py — HeadlessPromptHandler（L3 非交互路径）

职责：
    仅串行 PermissionRequest hook 链；无决议则 deny（对齐 CC headless agent）。

链路位置：
    pipeline headless=True 时注入。
"""

from __future__ import annotations

import logging
from collections.abc import Sequence

from .race import PromptBranch, _deny, _run_hook_chain
from .types import (
    DecisionReason,
    DecisionReasonType,
    PromptDecisionSource,
    PromptRequest,
    PromptResponse,
)

logger = logging.getLogger(__name__)


class HeadlessPromptHandler:
    """非交互 L3：只跑 hook，无 hook 决议则 ``PROMPTS_UNAVAILABLE`` deny。"""

    def __init__(
        self,
        *,
        hooks: Sequence[PromptBranch] | None = None,
        hook_timeout_seconds: float = 30.0,
    ) -> None:
        self._hooks = list(hooks or ())
        self._hook_timeout = hook_timeout_seconds

    async def handle(self, request: PromptRequest) -> PromptResponse:
        if not self._hooks:
            return _deny(
                reason=DecisionReason(
                    type=DecisionReasonType.PROMPTS_UNAVAILABLE,
                    detail="prompts unavailable",
                ),
                tool_name=request.tool_name,
                source=PromptDecisionSource.HEADLESS_FALLBACK,
            )
        try:
            resp = await _run_hook_chain(
                self._hooks,
                request,
                timeout=self._hook_timeout,
            )
        except Exception as exc:
            logger.exception("headless hook chain failed for %s: %s", request.tool_name, exc)
            return _deny(
                reason=DecisionReason(
                    type=DecisionReasonType.PROMPTS_UNAVAILABLE,
                    detail=f"headless hook failure: {exc}",
                ),
                tool_name=request.tool_name,
                source=PromptDecisionSource.HEADLESS_FALLBACK,
            )
        if resp is not None:
            return resp
        return _deny(
            reason=DecisionReason(
                type=DecisionReasonType.PROMPTS_UNAVAILABLE,
                detail="prompts unavailable",
            ),
            tool_name=request.tool_name,
            source=PromptDecisionSource.HEADLESS_FALLBACK,
        )
