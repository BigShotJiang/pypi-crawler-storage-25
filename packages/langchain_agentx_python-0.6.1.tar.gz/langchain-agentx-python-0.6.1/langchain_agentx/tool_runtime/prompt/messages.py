"""
prompt/messages.py — L3 deny 消息模板（对齐 CC AUTO_REJECT_MESSAGE）

职责：
    LLM-facing 拒因文案与 workaround 指引；内部诊断与展示层分离。
"""

from __future__ import annotations

DENIAL_WORKAROUND_GUIDANCE = (
    "You should only try to work around this restriction in reasonable ways "
    "that do not attempt to bypass the intent behind this denial. "
    "If you believe this capability is essential to complete the user's request, "
    "STOP and explain to the user what you were trying to do and why you need this permission."
)

PROMPTS_UNAVAILABLE_TEMPLATE = (
    "Permission to use {tool_name} has been denied because "
    "this session is running in non-interactive mode. "
    f"{DENIAL_WORKAROUND_GUIDANCE}"
)

UI_RESPONSE_TIMEOUT_TEMPLATE = (
    "Permission to use {tool_name} has been denied because "
    "no user response was received within the configured timeout. "
    f"{DENIAL_WORKAROUND_GUIDANCE}"
)

USER_ABORT_TEMPLATE = (
    "Permission to use {tool_name} has been denied because "
    "the session was aborted before a user response was received. "
    f"{DENIAL_WORKAROUND_GUIDANCE}"
)

NO_PARTICIPANTS_TEMPLATE = (
    "Permission to use {tool_name} has been denied because "
    "no permission prompt handler is configured for this session. "
    f"{DENIAL_WORKAROUND_GUIDANCE}"
)

GENERIC_DENY_TEMPLATE = (
    "Permission to use {tool_name} has been denied. "
    f"{DENIAL_WORKAROUND_GUIDANCE}"
)
