"""
tool_runtime/prompt/ — L3 HITL seam（PermissionPromptHandler 与默认实现）

对外暴露 Protocol、数据类型与 HitlRaceCoordinator / HeadlessPromptHandler。
"""

from .cli_interactive import (
    CliInteractivePolicyEngine,
    CliInteractivePromptHandler,
    permission_resolver_to_user_ui,
)
from .handler import PermissionPromptHandler
from .headless import HeadlessPromptHandler
from .legacy_resolver_adapter import LegacyResolverPromptHandler
from .race import HitlRaceCoordinator, PromptBranch, PromptClassifier
from .types import (
    DecisionReason,
    DecisionReasonType,
    PermissionUpdate,
    PromptDecisionSource,
    PromptRequest,
    PromptResponse,
)

__all__ = [
    "PermissionPromptHandler",
    "DecisionReason",
    "DecisionReasonType",
    "PermissionUpdate",
    "PromptDecisionSource",
    "PromptRequest",
    "PromptResponse",
    "HitlRaceCoordinator",
    "HeadlessPromptHandler",
    "LegacyResolverPromptHandler",
    "CliInteractivePromptHandler",
    "CliInteractivePolicyEngine",
    "permission_resolver_to_user_ui",
    "PromptBranch",
    "PromptClassifier",
]
