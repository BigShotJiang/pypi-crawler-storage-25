"""
prompt/cli_interactive.py — CLI 交互式 L3 参考实现与弃用薄壳

职责：
    CliInteractivePromptHandler：继承 HitlRaceCoordinator，注入 CLI user_ui 回调。
    CliInteractivePolicyEngine：0.4.x 兼容薄壳（DeprecationWarning），拆分为
    DefaultPolicyEngine + prompt_handler，供 loader 双注入。

链路位置：
    CLI 仓可复用或拷贝本模块；SDK 示例与迁移脚本以此为 SSOT。

当前裁剪：
    user_ui 为 async(PromptRequest) -> PromptResponse | None 回调，不绑定 questionary。
"""

from __future__ import annotations

import warnings
from collections.abc import Awaitable, Callable, Sequence
from typing import TYPE_CHECKING, Any

from ..policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from ..policy_decorator import PolicyEngineDecorator
from ..resolvers.base import PermissionResolver
from .race import HitlRaceCoordinator, PromptBranch, PromptClassifier
from .types import PromptDecisionSource, PromptRequest, PromptResponse

if TYPE_CHECKING:
    from .handler import PermissionPromptHandler

UserUiCallback = Callable[[PromptRequest], Awaitable[PromptResponse | None]]


def permission_resolver_to_user_ui(
    resolver: PermissionResolver,
) -> UserUiCallback:
    """将旧 ``PermissionResolver`` 适配为 L3 user_ui 分支。"""

    async def _ui(request: PromptRequest) -> PromptResponse:
        prompt = request.ask_prompt or request.ask_decision.ask_prompt
        allowed = await resolver(request.tool_name, prompt)
        return PromptResponse(
            behavior="allow" if allowed else "deny",
            decision_source=PromptDecisionSource.USER_UI,
            message=None if allowed else (prompt or "denied by user"),
        )

    return _ui


class CliInteractivePromptHandler(HitlRaceCoordinator):
    """
    CLI 交互式 L3 处理器：在 HitlRaceCoordinator 上固定注入 user_ui。

    用法::

        handler = CliInteractivePromptHandler(user_ui=my_async_ui)
        loader = ToolRuntimeLoader(
            policy_engine=DefaultPolicyEngine(cfg),
            prompt_handler=handler,
        )
    """

    def __init__(
        self,
        *,
        user_ui: UserUiCallback,
        hooks: Sequence[PromptBranch] | None = None,
        classifier: PromptClassifier | None = None,
        hard_timeout_seconds: float | None = None,
        hook_timeout_seconds: float = 30.0,
        classifier_timeout_seconds: float = 15.0,
        headless_session: bool = False,
    ) -> None:
        super().__init__(
            hooks=hooks,
            classifier=classifier,
            user_ui=user_ui,
            hard_timeout_seconds=hard_timeout_seconds,
            hook_timeout_seconds=hook_timeout_seconds,
            classifier_timeout_seconds=classifier_timeout_seconds,
            headless_session=headless_session,
        )

    @classmethod
    def from_permission_resolver(
        cls,
        resolver: PermissionResolver,
        **kwargs: object,
    ) -> CliInteractivePromptHandler:
        """由旧 resolver 构造（便于 CLI 渐进迁移）。"""
        return cls(user_ui=permission_resolver_to_user_ui(resolver), **kwargs)  # type: ignore[arg-type]


class CliInteractivePolicyEngine(PolicyEngineDecorator):
    """
    已弃用：请改用 ``DefaultPolicyEngine`` + ``CliInteractivePromptHandler``。

    本类保留为薄壳，避免 0.4.x 直接 ``继承 PolicyEngine`` 且无 ``_config`` 的崩溃形态；
    同时暴露 ``prompt_handler`` 供 ``ToolRuntimeLoader`` 注入。
    """

    def __init__(
        self,
        config: ToolPolicyConfig,
        *,
        user_ui: UserUiCallback | None = None,
        permission_resolver: PermissionResolver | None = None,
        auto_mode_hook: Any | None = None,
        hooks: Sequence[PromptBranch] | None = None,
        classifier: PromptClassifier | None = None,
        headless_session: bool = False,
    ) -> None:
        warnings.warn(
            "CliInteractivePolicyEngine is deprecated; use "
            "DefaultPolicyEngine(config) with "
            "CliInteractivePromptHandler(user_ui=...) on ToolRuntimeLoader.prompt_handler. "
            "This compatibility shell will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        inner = DefaultPolicyEngine(config, auto_mode_hook=auto_mode_hook)
        super().__init__(inner)
        self._config = config
        ui = user_ui
        if ui is None and permission_resolver is not None:
            ui = permission_resolver_to_user_ui(permission_resolver)
        if ui is None:
            raise ValueError(
                "CliInteractivePolicyEngine requires user_ui or permission_resolver"
            )
        self.prompt_handler: PermissionPromptHandler = CliInteractivePromptHandler(
            user_ui=ui,
            hooks=hooks,
            classifier=classifier,
            headless_session=headless_session,
        )

    @property
    def policy_engine(self) -> PolicyEngine:
        """L2 引擎（``DefaultPolicyEngine``），供 loader.policy_engine 注入。"""
        return self._inner

    def loader_kwargs(self) -> dict[str, Any]:
        """``ToolRuntimeLoader(**bundle.loader_kwargs())`` 推荐构造参数。"""
        return {
            "policy_engine": self.policy_engine,
            "prompt_handler": self.prompt_handler,
        }

    def apply_to_loader(self, loader: object) -> None:
        """将 L2/L3 拆线写入已有 ``ToolRuntimeLoader``（已注册工具需重新 register）。"""
        from ..loader import ToolRuntimeLoader

        if not isinstance(loader, ToolRuntimeLoader):
            raise TypeError("loader must be ToolRuntimeLoader")
        if getattr(loader, "_policy", None) is None:
            loader._policy = self.policy_engine
        loader.set_prompt_handler(self.prompt_handler)
