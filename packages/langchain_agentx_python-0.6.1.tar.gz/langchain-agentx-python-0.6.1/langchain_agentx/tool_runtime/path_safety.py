"""
path_safety.py — 写路径安全评估（对齐 CC filesystem.ts）

职责：
    将 CC ``DANGEROUS_DIRECTORIES`` / ``DANGEROUS_FILES`` / ``isClaudeConfigFilePath``
    映射为 SDK 的 ``AuthorizationDecision(behavior=ask)``；``agent_home`` 段名可配置。

链路位置：
    ``DefaultPolicyEngine.authorize`` / ``authorize_path`` 在 ask_globs 之后、roots 之前调用。

当前裁剪范围：
    不实现 session 级 ``/.claude/**`` allow 绕过、Windows 可疑路径全套、内部 plan/scratchpad 白名单。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from .models import AuthorizationDecision

if TYPE_CHECKING:
    pass

# 与 CC DANGEROUS_DIRECTORIES 对齐（不含 agent_home，运行时注入）
_DEFAULT_DANGEROUS_DIRECTORY_SEGMENTS: tuple[str, ...] = (
    ".git",
    ".vscode",
    ".idea",
)

# 与 CC DANGEROUS_FILES 对齐（按文件名，大小写不敏感）
_DANGEROUS_FILE_NAMES: frozenset[str] = frozenset(
    {
        ".gitconfig",
        ".gitmodules",
        ".bashrc",
        ".bash_profile",
        ".zshrc",
        ".zprofile",
        ".profile",
        ".ripgreprc",
        ".mcp.json",
        ".claude.json",
    }
)

_WORKTREES_SEGMENT = "worktrees"

# agent_home 下需 ask 的子目录（对齐 isClaudeConfigFilePath 的 commands/agents/skills）
_AGENT_CONFIG_SUBDIRS: tuple[str, ...] = ("commands", "agents", "skills")

_IDE_SETTINGS_PARENTS: tuple[str, ...] = (".vscode", ".cursor")


def _normalize_case(path: str) -> str:
    return path.replace("\\", "/").lower()


@dataclass
class PathSafetyConfig:
    """写路径安全配置。"""

    agent_home_segment: str
    workspace_root: str | None = None
    enabled: bool = True
    dangerous_directory_segments: tuple[str, ...] = field(
        default_factory=lambda: _DEFAULT_DANGEROUS_DIRECTORY_SEGMENTS
    )
    worktrees_segment: str = _WORKTREES_SEGMENT

    def __post_init__(self) -> None:
        seg = (self.agent_home_segment or "").strip()
        if not seg:
            raise ValueError("agent_home_segment must be non-empty")
        if not seg.startswith("."):
            seg = f".{seg}"
        object.__setattr__(self, "agent_home_segment", seg)

    @classmethod
    def from_workspace(
        cls,
        *,
        workspace_root: str,
        agent_home_segment: str,
        enabled: bool = True,
    ) -> PathSafetyConfig:
        return cls(
            agent_home_segment=agent_home_segment,
            workspace_root=str(Path(workspace_root).resolve()),
            enabled=enabled,
        )


class PathSafetyEvaluator:
    """评估写操作目标路径是否需人工确认（CC checkPathSafetyForAutoEdit 子集）。"""

    def __init__(self, config: PathSafetyConfig) -> None:
        self._config = config
        home = config.agent_home_segment.lower()
        self._dangerous_segments = frozenset(
            s.lower() for s in (*config.dangerous_directory_segments, config.agent_home_segment)
        )
        self._agent_home_lower = home
        self._worktrees_lower = config.worktrees_segment.lower()

    def evaluate_unc_path(self, path: str) -> AuthorizationDecision | None:
        """UNC / extended-length 前缀：Read 与 Write 均先拦截（CC 对齐）。"""
        if not self._config.enabled:
            return None
        raw = path.strip()
        if raw.startswith("\\\\") or raw.startswith("//"):
            return AuthorizationDecision(
                behavior="ask",
                message=(
                    f"Permission required: path uses a UNC or extended-length prefix: {path}"
                ),
                policy_id="dangerous_unc_path",
                metadata={"classifier_approvable": False},
            )
        return None

    def evaluate_write_path(self, path: str) -> AuthorizationDecision | None:
        """
        若路径需保护则返回 ``ask`` 决策；否则返回 ``None``（继续后续 roots 检查）。
        """
        if not self._config.enabled:
            return None

        unc = self.evaluate_unc_path(path)
        if unc is not None:
            return unc

        real = os.path.realpath(os.path.expanduser(path.strip()))
        if self._is_agent_config_file_path(real):
            return AuthorizationDecision(
                behavior="ask",
                message=(
                    f"Permission required: editing agent configuration file: {real}"
                ),
                policy_id="agent_config_file",
                metadata={"classifier_approvable": True},
            )

        if self._is_dangerous_path(real):
            return AuthorizationDecision(
                behavior="ask",
                message=f"Permission required: sensitive path: {real}",
                policy_id="dangerous_directory",
                metadata={"classifier_approvable": True},
            )

        return None

    def _is_dangerous_path(self, real_path: str) -> bool:
        parts = Path(real_path).parts
        for i, segment in enumerate(parts):
            seg_lower = segment.lower()
            if seg_lower not in self._dangerous_segments:
                continue
            if seg_lower == self._agent_home_lower:
                next_part = parts[i + 1] if i + 1 < len(parts) else None
                if next_part and next_part.lower() == self._worktrees_lower:
                    continue
            return True

        file_name = parts[-1].lower() if parts else ""
        if file_name in _DANGEROUS_FILE_NAMES:
            return True
        return False

    def _is_agent_config_file_path(self, real_path: str) -> bool:
        p = Path(real_path)
        posix = _normalize_case(p.as_posix())
        home = self._agent_home_lower

        for sub in _AGENT_CONFIG_SUBDIRS:
            marker = f"/{home}/{sub}/"
            if marker in posix:
                return True

        if p.name.lower() != "settings.json":
            return False

        for parent in (*_IDE_SETTINGS_PARENTS, self._config.agent_home_segment):
            pl = parent.lower()
            if f"/{pl}/" in posix:
                return True
            if p.parent.name.lower() == pl.lstrip("."):
                return True
        return False
