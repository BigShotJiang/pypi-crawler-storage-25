"""
tool_runtime/permission_decision.py — 权限决策结构化契约

职责：
    对齐 CC PermissionDecisionReason.type，提供稳定的 decision_reason 与
    policy_id 解析辅助，避免调用方依赖字符串前缀嗅探。

链路位置：
    PolicyEngine / AutoModeDecision → AuthorizationDecision.metadata
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from .models import AuthorizationDecision


class PermissionDecisionType(str, Enum):
    """CC PermissionDecisionReason.type 对齐子集。"""

    RULE = "rule"
    MODE = "mode"
    CLASSIFIER = "classifier"
    HOOK = "hook"
    AUTO_MODE = "auto_mode"
    OVERRIDE = "override"


POLICY_ID_DENY_OVERRIDE_CONSUMED = "deny_override_consumed"


# 公开 policy_id 前缀（文档化契约；新代码优先读 metadata["decision_reason"]）
POLICY_ID_PREFIX_AUTO_MODE = "auto_mode:"
POLICY_ID_PREFIX_ALWAYS_ASK_TOOL = "always_ask_tool:"
POLICY_ID_PREFIX_DENY_GLOB = "deny_glob:"
POLICY_ID_PREFIX_ASK_GLOB = "ask_glob:"


# ---------------------------------------------------------------------------
# Envelope.meta keys for deny / override (L4 UX seam stable contract)
#
# 当 pipeline Step 4 返回 behavior="deny" 时，blocked envelope 的 meta 上
# 会写入下列固定 key，CLI / 测试 / Trace UI 应通过这些常量读取，
# 避免硬编码字符串。详细写入条件见
# ``langchain_agentx.tool_runtime.override.enrich_blocked_deny_envelope``。
# ---------------------------------------------------------------------------

ENVELOPE_META_KEY_CAN_OVERRIDE = "can_override"
"""bool；是否允许 L4 用户覆盖（deny + tool_call_id 非空时固定为 True）。"""

ENVELOPE_META_KEY_TOOL_CALL_ID = "tool_call_id"
"""str；触发 deny 的 tool_call_id（与 ctx.tool_call_id 一致）。"""

ENVELOPE_META_KEY_POLICY_ID = "policy_id"
"""str | None；触发 deny 的策略标识（与 AuthorizationDecision.policy_id 一致）。"""

ENVELOPE_META_KEY_DENY_OVERRIDE = "deny_override"
"""dict；DenyOverrideRecord.to_dict() 快照，仅当 ctx.session_store 非 None 时写入。"""


def normalize_tool_name_set(names: Any) -> frozenset[str]:
    """工具名集合归一化为小写 frozenset。"""
    if names is None:
        return frozenset()
    if isinstance(names, frozenset):
        return frozenset(n.lower() for n in names if isinstance(n, str) and n.strip())
    return frozenset(str(n).strip().lower() for n in names if str(n).strip())


def make_decision_reason(
    reason_type: PermissionDecisionType | str,
    **fields: Any,
) -> dict[str, Any]:
    """构造 CC 风格的 decision_reason 字典。"""
    type_value = reason_type.value if isinstance(reason_type, PermissionDecisionType) else reason_type
    out: dict[str, Any] = {"type": type_value}
    for key, value in fields.items():
        if value is not None:
            out[key] = value
    return out


def attach_decision_reason(
    decision: AuthorizationDecision,
    reason: dict[str, Any],
) -> AuthorizationDecision:
    """将 decision_reason 写入 metadata（就地更新 metadata 引用）。"""
    meta = dict(decision.metadata or {})
    meta["decision_reason"] = reason
    decision.metadata = meta
    return decision


def is_override_policy_id(policy_id: str | None) -> bool:
    """replay grant 消费后 Step 4 短路的 policy_id。"""
    return policy_id == POLICY_ID_DENY_OVERRIDE_CONSUMED


def is_auto_mode_policy_id(policy_id: str | None) -> bool:
    """判断 policy_id 是否来自 Auto Mode（稳定契约，非前缀嗅探首选）。"""
    if not policy_id:
        return False
    return policy_id.startswith(POLICY_ID_PREFIX_AUTO_MODE) or policy_id.startswith("auto_mode_")


def decision_type_from_policy_id(policy_id: str | None) -> PermissionDecisionType | None:
    """从 policy_id 推断 decision_reason.type（向后兼容）。"""
    if not policy_id:
        return None
    if is_override_policy_id(policy_id):
        return PermissionDecisionType.OVERRIDE
    if is_auto_mode_policy_id(policy_id):
        return PermissionDecisionType.AUTO_MODE
    if policy_id.startswith(POLICY_ID_PREFIX_ALWAYS_ASK_TOOL):
        return PermissionDecisionType.RULE
    if policy_id.startswith(POLICY_ID_PREFIX_DENY_GLOB) or policy_id.startswith(
        POLICY_ID_PREFIX_ASK_GLOB
    ):
        return PermissionDecisionType.RULE
    if policy_id in ("read_only_mode", "builtin_deny", "read_roots", "write_roots"):
        return PermissionDecisionType.RULE
    return None


def get_decision_reason(decision: AuthorizationDecision) -> dict[str, Any] | None:
    """读取 metadata 中的 decision_reason。"""
    if not decision.metadata:
        return None
    reason = decision.metadata.get("decision_reason")
    return reason if isinstance(reason, dict) else None
