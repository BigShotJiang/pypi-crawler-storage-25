"""
read_permission.py — Read 工具路径授权（对齐 CC checkReadPermissionForTool 子集）

职责：
    编排 Read 专用 deny、UNC 防护、Write⇒Read 隐含允许与 read_roots 检查。

链路位置：
    ``DefaultPolicyEngine.authorize`` 在 ``is_read_only_tool`` 时委托 ``ReadPathAuthorizer``。

当前裁剪范围：
    不实现 read allow/ask 规则表、internal harness 路径、多 working directory 集合。
"""

from __future__ import annotations

import fnmatch
from typing import TYPE_CHECKING, Any

from .models import AuthorizationDecision

if TYPE_CHECKING:
    from .path_safety import PathSafetyEvaluator
    from .policy import ToolPolicyConfig


class ReadPathAuthorizer:
    """CC ``checkReadPermissionForTool`` 对齐的 Read 路径决策。"""

    def __init__(
        self,
        config: ToolPolicyConfig,
        *,
        path_safety: PathSafetyEvaluator | None,
        check_deny_globs: Any,
        check_ask_globs: Any,
        check_builtin_deny: Any,
        authorize_destructive_path: Any,
        authorize_read_roots: Any,
        with_decision_source: Any,
    ) -> None:
        self._config = config
        self._path_safety = path_safety
        self._check_deny_globs = check_deny_globs
        self._check_ask_globs = check_ask_globs
        self._check_builtin_deny = check_builtin_deny
        self._authorize_destructive_path = authorize_destructive_path
        self._authorize_read_roots = authorize_read_roots
        self._with_decision_source = with_decision_source

    def authorize(
        self,
        real_path: str,
        *,
        tool_name: str,
        active_auto_approved_tools_lower: set[str],
    ) -> AuthorizationDecision:
        unc = self._evaluate_unc(real_path)
        if unc is not None:
            return self._with_decision_source(unc, matched_rule=unc.policy_id)

        read_deny = self._check_read_deny_globs(real_path)
        if read_deny is not None:
            return self._with_decision_source(read_deny, matched_rule=read_deny.policy_id)

        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return self._with_decision_source(
                deny_result,
                matched_rule=deny_result.policy_id,
            )

        builtin = self._check_builtin_deny(real_path)
        if builtin is not None:
            return self._with_decision_source(builtin, matched_rule="builtin_deny")

        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            if tool_name.lower() in active_auto_approved_tools_lower:
                return self._with_decision_source(
                    AuthorizationDecision(
                        behavior="allow",
                        policy_id="skill_auto_approved_bypass_ask",
                    ),
                    matched_rule="skill_auto_approved_bypass_ask",
                )
            return self._with_decision_source(
                ask_result,
                matched_rule=ask_result.policy_id,
            )

        # CC step 5: write/edit allow ⇒ read allow（在 read_roots 之前）
        # write_roots 为空表示写不限制，不得据此放宽 Read（开发模式仍靠 read_roots）
        write_decision = self._authorize_destructive_path(real_path)
        if write_decision.behavior == "allow" and self._config.write_roots:
            return self._with_decision_source(
                AuthorizationDecision(
                    behavior="allow",
                    policy_id="write_implies_read",
                    message="Read allowed because write access is permitted for this path.",
                    metadata={"implied_from": "write_roots"},
                ),
                matched_rule="write_implies_read",
            )

        return self._authorize_read_roots(real_path)

    def _evaluate_unc(self, real_path: str) -> AuthorizationDecision | None:
        if self._path_safety is None:
            return None
        return self._path_safety.evaluate_unc_path(real_path)

    def _check_read_deny_globs(self, real_path: str) -> AuthorizationDecision | None:
        for glob_pattern in self._config.read_deny_globs:
            if fnmatch.fnmatch(real_path, glob_pattern):
                return AuthorizationDecision(
                    behavior="deny",
                    message="Permission denied: read access blocked by read_deny rule.",
                    policy_id=f"read_deny_glob:{glob_pattern}",
                )
        return None
