"""
tool_runtime/ — 工具运行时框架核心包

对外暴露框架的稳定公共接口，外部代码只需从此处导入，
不需要直接依赖子模块路径。
"""

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .errors import (
    ToolInputSchemaError,
    ToolNotFoundError,
    ToolRegistrationError,
    ToolRuntimeError,
    blocked_envelope,
    exception_to_envelope,
    validation_error_envelope,
)
from .models import (
    AuthorizationDecision,
    ToolArtifact,
    ToolErrorInfo,
    ToolExecutionContext,
    ToolHint,
    ToolResultEnvelope,
    ValidationResult,
)
from .identical_call_cache import IdenticalCallMemo
from .loader import ToolRuntimeLoader
from .pipeline import PermissionAskInterrupt, ToolExecutorPipeline, ToolOutputManager
from .path_safety import PathSafetyConfig, PathSafetyEvaluator
from .policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from .read_ignore_patterns import ReadDenyPatternCollector, normalize_read_deny_pattern
from .policy_decorator import PolicyEngineDecorator
from .prompt import (
    CliInteractivePolicyEngine,
    CliInteractivePromptHandler,
    HeadlessPromptHandler,
    HitlRaceCoordinator,
    LegacyResolverPromptHandler,
    PermissionPromptHandler,
    PermissionUpdate,
    PromptDecisionSource,
    PromptRequest,
    PromptResponse,
    permission_resolver_to_user_ui,
)
from .registry import RuntimeToolRegistry
from .resolvers import (
    AgentSessionPermissionResolver,
    BackgroundPermissionResolver,
    ConversationPermissionResolver,
    PermissionRequest,
    PermissionResolver,
    WorkflowPermissionResolver,
)
from .auto_mode.config import AutoModeConfig
from .auto_mode.events import AutoModeDecisionEvent
from .override import DenyOverrideManager, DenyOverrideRecord, enrich_blocked_deny_envelope
from .permission_decision import (
    ENVELOPE_META_KEY_CAN_OVERRIDE,
    ENVELOPE_META_KEY_DENY_OVERRIDE,
    ENVELOPE_META_KEY_POLICY_ID,
    ENVELOPE_META_KEY_TOOL_CALL_ID,
    POLICY_ID_DENY_OVERRIDE_CONSUMED,
)
from .session_store import AgentSessionStore, FileReadRecord, FileWriteRecord
from .state_bridge import ToolStateBridge

__all__ = [
    # auto mode
    "AutoModeConfig",
    "AutoModeDecisionEvent",
    # models
    "ToolExecutionContext",
    "ToolResultEnvelope",
    "ValidationResult",
    "AuthorizationDecision",
    "ToolErrorInfo",
    "ToolHint",
    "ToolArtifact",
    # base
    "RuntimeTool",
    # errors
    "ToolRuntimeError",
    "ToolRegistrationError",
    "ToolNotFoundError",
    "ToolInputSchemaError",
    "exception_to_envelope",
    "blocked_envelope",
    "validation_error_envelope",
    # policy
    "ToolPolicyConfig",
    "PolicyEngine",
    "DefaultPolicyEngine",
    "PolicyEngineDecorator",
    "PathSafetyConfig",
    "PathSafetyEvaluator",
    "ReadDenyPatternCollector",
    "normalize_read_deny_pattern",
    # prompt (L3)
    "PermissionPromptHandler",
    "PermissionUpdate",
    "PromptDecisionSource",
    "PromptRequest",
    "PromptResponse",
    "HitlRaceCoordinator",
    "HeadlessPromptHandler",
    "LegacyResolverPromptHandler",
    "CliInteractivePromptHandler",
    "CliInteractivePolicyEngine",
    "permission_resolver_to_user_ui",
    # state
    "ToolStateBridge",
    # session
    "AgentSessionStore",
    "FileReadRecord",
    "FileWriteRecord",
    # deny override (L4 UX seam)
    "DenyOverrideRecord",
    "DenyOverrideManager",
    "enrich_blocked_deny_envelope",
    "ENVELOPE_META_KEY_CAN_OVERRIDE",
    "ENVELOPE_META_KEY_TOOL_CALL_ID",
    "ENVELOPE_META_KEY_POLICY_ID",
    "ENVELOPE_META_KEY_DENY_OVERRIDE",
    "POLICY_ID_DENY_OVERRIDE_CONSUMED",
    # pipeline
    "ToolOutputManager",
    "ToolExecutorPipeline",
    "PermissionAskInterrupt",
    "IdenticalCallMemo",
    "PermissionResolver",
    "PermissionRequest",
    "AgentSessionPermissionResolver",
    "ConversationPermissionResolver",
    "BackgroundPermissionResolver",
    "WorkflowPermissionResolver",
    # adapter
    "LangChainAdapter",
    # registry
    "RuntimeToolRegistry",
    # loader
    "ToolRuntimeLoader",
]
