"""
LangChain-based agent utilities for CodeBaseX.

This package provides:
- LangChain-AgentX LangGraph agent factory (`loop`)

Typical usage:

```python
from langchain_agentx import create_loop_agent
```
"""

__version__ = "0.6.1"

from .loop import (  # noqa: F401
    create_loop_agent,
)

from .loop.hook import (  # noqa: F401
    ATTACHMENT_HOOK_BLOCKING_ERROR,
    ATTACHMENT_HOOK_CANCELLED,
    ATTACHMENT_HOOK_NON_BLOCKING_ERROR,
    ATTACHMENT_HOOK_STOPPED_CONTINUATION,
    ATTACHMENT_HOOK_SUCCESS,
)
from .observability import (  # noqa: F401
    EventAdapterState,
    LangchainAgentEvent,
    LangchainAgentEventType,
    LangGraphToLangchainAgentEventAdapter,
    TraceCollector,
    TraceSession,
    TraceSpan,
)
from .provider import CompatibleChatOpenAI  # noqa: F401
from .session import AgentSession, create_agent_session  # noqa: F401
from .workflow import BaseWorkflow  # noqa: F401

__all__ = [
    "ATTACHMENT_HOOK_BLOCKING_ERROR",
    "ATTACHMENT_HOOK_CANCELLED",
    "ATTACHMENT_HOOK_NON_BLOCKING_ERROR",
    "ATTACHMENT_HOOK_STOPPED_CONTINUATION",
    "ATTACHMENT_HOOK_SUCCESS",
    "create_loop_agent",
    "create_agent_session",
    "AgentSession",
    "BaseWorkflow",
    "EventAdapterState",
    "LangchainAgentEvent",
    "LangchainAgentEventType",
    "LangGraphToLangchainAgentEventAdapter",
    "TraceCollector",
    "TraceSession",
    "TraceSpan",
    "CompatibleChatOpenAI",
]
