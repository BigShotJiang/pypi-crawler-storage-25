"""
tools/edit/tool.py — EditRuntimeTool

职责：
    RuntimeTool 生命周期编排：normalize → validate → permissions → invoke → present；
    invoke 后 ``after_invoke`` 刷新 ``last_read_map``（edit-tool-migration §2.2）。

链路位置：
    ToolRuntimeLoader.register_default_tools；create_loop_agent(..., loader=)。

当前裁剪范围：
    v1 无 LSP；staleness 方案 B；权限兜底 deny 与设计 §3.4.3 一致。
    v2：可选 ``include_diff``、引号等价；unified diff 由 ``DiffGenerator``。
    v3：``include_diff`` 时 **git diff 优先**，失败则 unified；``GitDiffGenerator`` 可注入。
    Phase 4–6：见上文历史说明。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.errors import ToolRuntimeError
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.utils.path_user_input import UserPathInputNormalizer
from langchain_agentx.workspace.tool_boundary import (
    authorize_write_boundary,
    resolve_tool_cwd,
    validate_write_boundary,
)

from .backend import EditFileBackend, apply_edit_to_content
from .diff_generator import DiffGenerator
from .git_diff_generator import GitDiffGenerator
from .limits import get_edit_limits
from .models import EditToolInput, EditToolOutput
from .prompt import DESCRIPTION, TOOL_NAME
from .staleness import StalenessChecker
from .validator import EditStringValidator


def _snapshot_file_for_last_read(file_path: str) -> str | None:
    """写入 last_read_map 的 UTF-8 快照或占位（与 Read after_invoke 上限一致）。"""
    max_b = get_edit_limits()["max_file_size"]
    try:
        raw = Path(file_path).read_bytes()
    except OSError:
        return None
    if len(raw) > max_b:
        return f"<large file: {len(raw) // 1024}KB>"
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return "<non-utf8 binary>"


class EditRuntimeTool(RuntimeTool):
    """精确字符串替换编辑（CC FileEditTool）。"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = EditToolInput
    output_model = EditToolOutput

    is_read_only: bool = False
    is_destructive: bool = True
    is_concurrency_safe: bool = False
    dedupe_identical_calls: bool = False

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        backend: EditFileBackend | None = None,
        path_normalizer: UserPathInputNormalizer | None = None,
        string_validator: EditStringValidator | None = None,
        staleness_checker: StalenessChecker | None = None,
        diff_generator: DiffGenerator | None = None,
        git_diff_generator: GitDiffGenerator | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._backend = backend or EditFileBackend()
        self._path_normalizer = path_normalizer or UserPathInputNormalizer()
        self._staleness_checker = staleness_checker or (
            StalenessChecker(state_bridge) if state_bridge is not None else None
        )
        self._diff_generator = diff_generator or DiffGenerator()
        self._git_diff_generator = git_diff_generator or GitDiffGenerator()
        self._string_validator = string_validator or EditStringValidator(
            state_bridge=state_bridge,
            staleness_checker=self._staleness_checker,
        )

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        """路径展开为绝对路径（与 Read/Write 一致）。"""
        raw = dict(raw)
        path = raw.get("file_path", "")
        if isinstance(path, str) and path:
            raw["file_path"] = self._path_normalizer.normalize_and_expand(
                path, base_dir=resolve_tool_cwd(ctx)
            )
        return raw

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        """语义校验：edit-tool-migration §3.4.2。"""
        inp = EditToolInput.model_validate(data)
        boundary_fail = validate_write_boundary(ctx, inp.file_path)
        if boundary_fail is not None:
            return boundary_fail
        return self._string_validator.validate(data, ctx)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """显式覆写：写路径走 ``PolicyEngine``（与 ``RuntimeTool`` 一致，先 ``super()``）。

        对 ``super()`` 返回的未知 ``behavior`` 兜底 **deny**（edit-tool-migration §3.4.3；
        与 write-runtime 计划 Phase 4/5 一致）。
        """
        inp = EditToolInput.model_validate(data)
        boundary = authorize_write_boundary(ctx, inp.file_path)
        if boundary is not None and boundary.behavior != "allow":
            return boundary
        decision = super().check_permissions(data, ctx)
        if decision.behavior not in ("allow", "deny", "ask"):
            return AuthorizationDecision(
                behavior="deny",
                policy_id="fallback",
                message=f"Unknown authorization behavior: {decision.behavior}",
            )
        return decision

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        """第二次 staleness + backend 替换（§3.4.4）。"""
        inp = EditToolInput.model_validate(data)
        if self._staleness_checker is None:
            raise ToolRuntimeError(
                "EditRuntimeTool requires ToolStateBridge for staleness.",
                code="MISSING_STATE_BRIDGE",
            )
        sr = self._staleness_checker.check(inp.file_path, ctx)
        if not sr.ok:
            raise ToolRuntimeError(
                sr.message or "File is stale or modified since read.",
                code="STALE_FILE",
            )

        replaced_count, original_content = self._backend.replace_string(
            file_path=inp.file_path,
            old_string=inp.old_string,
            new_string=inp.new_string,
            replace_all=inp.replace_all,
        )

        diff_str: str | None = None
        git_diff_str: str | None = None
        if inp.include_diff and replaced_count > 0:
            new_content, _ = apply_edit_to_content(
                original_content,
                inp.old_string,
                inp.new_string,
                inp.replace_all,
            )
            git_diff_str = self._git_diff_generator.generate_git_diff(inp.file_path)
            if git_diff_str:
                diff_str = git_diff_str
            else:
                diff_str = self._diff_generator.generate(
                    original_content,
                    new_content,
                    label=Path(inp.file_path).name,
                )

        return EditToolOutput(
            file_path=inp.file_path,
            old_string=inp.old_string,
            new_string=inp.new_string,
            replaced_count=replaced_count,
            original_file=original_content,
            diff=diff_str,
            git_diff=git_diff_str,
        )

    def after_invoke(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> None:
        """成功后刷新 last_read，便于同会话后续 Edit 的 staleness（对齐 CC readFileState 更新）。"""
        if self._state_bridge is None:
            return
        if not isinstance(result, EditToolOutput):
            return
        inp = EditToolInput.model_validate(data)
        try:
            mtime_ms = int(os.path.getmtime(inp.file_path) * 1000)
        except OSError:
            mtime_ms = 0
        snap = _snapshot_file_for_last_read(inp.file_path)
        self._state_bridge.set_last_read(
            ctx,
            inp.file_path,
            offset=0,
            limit=None,
            mtime_ms=mtime_ms,
            content=snap,
            line_start=None,
            line_end=None,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        """edit-tool-migration §3.4.5：summary + meta 片段；payload 为 ``str(replaced_count)``。

        不向 ``ToolResultEnvelope`` 注入全文或 ``original_file``（tool-migration-design-guide §4.3）。
        """
        _ = data, ctx
        if not isinstance(result, EditToolOutput):
            return super().present(data, result, ctx)
        n = result.replaced_count
        summary = (
            f"Replaced 1 occurrence in {result.file_path}"
            if n == 1
            else f"Replaced {n} occurrences in {result.file_path}"
        )
        meta: dict[str, Any] = {
            "file_path": result.file_path,
            "replaced_count": n,
            "old_string": result.old_string[:100],
            "new_string": result.new_string[:100],
        }
        if result.diff is not None:
            meta["diff"] = result.diff
        if result.git_diff is not None:
            meta["git_diff"] = result.git_diff
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload=str(n),
            meta=meta,
        )

    def present_for_display(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> dict[str, Any] | None:
        """out-of-band：diff 视图数据（对位 CC FileEditTool UI.tsx）。"""
        _ = ctx
        if not isinstance(result, EditToolOutput):
            return None
        return {
            "file_path": result.file_path,
            "replaced_count": result.replaced_count,
            "diff": result.diff,
            "git_diff": result.git_diff,
            "old_string": data.get("old_string", result.old_string),
            "new_string": data.get("new_string", result.new_string),
        }
