"""
tools/bash/security.py — BashRuntimeTool 基础安全检查

v1 实现"可用性优先"的安全防护，防止常见误操作。
v2 将引入 AST 级分析（对应 CC bashSecurity.ts 的 2593 行）。

对应 CC：
    destructiveCommandWarning.ts  → detect_destructive_patterns()
    BashTool.tsx::validateInput() → detect_sleep_block()
    bashSecurity.ts (部分)        → detect_infinite_output()

安全层次（纵深防御）：
    validate_input 层（阻断）：sleep 大值、无限输出、空命令
    invoke 层（警告不阻断）：危险命令 → 注入 warning hint
"""

from __future__ import annotations

import re
import shlex

from .read_only_validation import BashReadOnlyClassifier


# ---------------------------------------------------------------------------
# 危险命令模式（对应 CC destructiveCommandWarning.ts::DESTRUCTIVE_PATTERNS）
# ---------------------------------------------------------------------------

# (正则模式, 警告描述)
_DESTRUCTIVE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # rm -rf / 或 rm -rf /path（根目录及其下一级）
    (
        re.compile(r"\brm\b.*-[^-\s]*[rf]{2}.*\s/(?:[^/\s]+)?(?:\s|$)"),
        "Dangerous: rm -rf targeting root or system path",
    ),
    # rm -rf 整体（任意路径，提示风险）
    (
        re.compile(r"\brm\b.*-[^-\s]*[rf]{1,2}"),
        "Potentially destructive: recursive remove with force flag",
    ),
    # chmod 777 或 chmod a+rwx（全权限）
    (
        re.compile(r"\bchmod\b.*(?:0*777|a\+rwx|ugo\+rwx)"),
        "Dangerous: granting full permissions to all users",
    ),
    # dd 直接写入设备
    (
        re.compile(r"\bdd\b.*\bof=/dev/(?!null\b)"),
        "Dangerous: direct device write via dd",
    ),
    # 重定向到非 /dev/null 的设备文件
    (
        re.compile(r">\s*/dev/(?!null\b)"),
        "Dangerous: redirecting output to a device file",
    ),
    # mkfs 格式化
    (
        re.compile(r"\bmkfs\b"),
        "Dangerous: filesystem creation (mkfs)",
    ),
    # fdisk 分区操作
    (
        re.compile(r"\bfdisk\b.*\b/dev/"),
        "Dangerous: disk partition operation (fdisk)",
    ),
    # :(){:|:&};: Fork Bomb
    (
        re.compile(r":\(\)\{.*:\|.*:.*\}"),
        "Dangerous: fork bomb pattern detected",
    ),
]

# ---------------------------------------------------------------------------
# 无限输出命令（对应 CC BLOCKED_DEVICE_PATHS 的命令级等价）
# ---------------------------------------------------------------------------

# 命令基础名称 → 会无限输出（无配合 head/timeout 等限制时）
_INFINITE_OUTPUT_BASE_COMMANDS: frozenset[str] = frozenset({
    "yes",
    "cat",  # 仅当目标为特定设备文件时，见 _INFINITE_DEVICE_ARGS
    "tail",  # 仅当使用 -f 且目标为设备文件时
})

# 与无限输出相关的设备文件路径
_INFINITE_DEVICE_PATHS: frozenset[str] = frozenset({
    "/dev/urandom",
    "/dev/random",
    "/dev/zero",
    "/dev/full",
})

# ---------------------------------------------------------------------------
# 公开 API
# ---------------------------------------------------------------------------


def detect_destructive_patterns(command: str) -> str | None:
    """
    检测命令中的危险操作模式。

    返回：
        str  — 警告文本（不阻断执行，在 present() 中作为 hint 展示）
        None — 无危险模式
    """
    for pattern, warning in _DESTRUCTIVE_PATTERNS:
        if pattern.search(command):
            return warning
    return None


def detect_infinite_output(command: str) -> bool:
    """
    检测命令是否会产生无限输出，导致进程挂起。

    策略：
    - `yes` 单独或作为管道起点（无 head/timeout 等限制时）
    - `cat /dev/urandom` 等读取无限设备文件
    - `tail -f /dev/urandom` 等

    注意：`yes | head -n 5` 是合法的（有 head 截断），不阻断。
    """
    stripped = command.strip()

    # 如果有管道，提取第一个命令检查
    # 有管道终结命令（head/timeout/take）时不阻断
    parts = _split_pipeline(stripped)

    # 检查是否有 head / timeout / wc 等截断命令
    has_limiter = any(
        _get_base_cmd(p) in {"head", "timeout", "wc", "tail", "tee", "take"}
        for p in parts[1:]  # 第二个之后的管道部分
    )

    first_cmd = parts[0] if parts else stripped
    base = _get_base_cmd(first_cmd)

    # yes 命令：单独使用时无限输出
    if base == "yes" and not has_limiter:
        return True

    # cat/tail 读取设备文件
    if base in {"cat", "tail"}:
        for dev_path in _INFINITE_DEVICE_PATHS:
            if dev_path in first_cmd:
                return True

    return False


def detect_sleep_block(command: str, threshold_sec: int) -> int | None:
    """
    检测 sleep N 中 N >= threshold_sec 的情况。

    返回：
        int  — 检测到的 sleep 时长（秒），提示模型使用 run_in_background
        None — 未检测到阻塞性 sleep

    对应 CC BashTool.tsx::detectBlockedSleepPattern()。

    注意：
    - `sleep 1.5` 等浮点数秒数 < threshold 时不阻断
    - `sleep 5 && cmd` 如果 sleep_sec < threshold 则不阻断
    - 支持 `sleep 5m`、`sleep 2h` 等带单位格式
    """
    # 匹配 sleep N（支持 s/m/h/d 单位）
    m = re.search(r"\bsleep\s+(\d+(?:\.\d+)?)([smhd]?)\b", command)
    if not m:
        return None

    val = float(m.group(1))
    unit = m.group(2)

    # 转换为秒
    unit_multipliers = {"": 1, "s": 1, "m": 60, "h": 3600, "d": 86400}
    total_sec = val * unit_multipliers.get(unit, 1)

    if total_sec >= threshold_sec:
        return int(total_sec)
    return None


def is_read_only_command(command: str) -> bool:
    """
    检测命令是否为只读操作（无副作用）。

    用于工具的 is_read_only 动态判断。
    对应 CC checkReadOnlyConstraints() 的简化版本（v1）。
    """
    classifier = BashReadOnlyClassifier()
    return classifier.classify(command).is_read_only


# ---------------------------------------------------------------------------
# 内部辅助
# ---------------------------------------------------------------------------


def _get_base_cmd(command: str) -> str:
    """提取命令的基础名（去掉路径前缀和参数）。"""
    stripped = command.strip()
    if not stripped:
        return ""
    # 取第一个 token
    try:
        tokens = shlex.split(stripped)
    except ValueError:
        tokens = stripped.split()
    if not tokens:
        return ""
    cmd = tokens[0]
    # 去掉路径前缀（/usr/bin/python → python）
    return cmd.rsplit("/", 1)[-1]


def _split_pipeline(command: str) -> list[str]:
    """
    简单分割管道命令（仅按 | 分割，不做完整 AST 解析）。
    v2 改为 AST 分析。
    """
    # 简单字符串分割，不处理引号内的 |
    parts = []
    current = []
    in_single = False
    in_double = False
    i = 0
    while i < len(command):
        c = command[i]
        if c == "'" and not in_double:
            in_single = not in_single
            current.append(c)
        elif c == '"' and not in_single:
            in_double = not in_double
            current.append(c)
        elif c == "|" and not in_single and not in_double:
            # 跳过 || （逻辑 OR）
            if i + 1 < len(command) and command[i + 1] == "|":
                current.append("||")
                i += 2
                continue
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(c)
        i += 1

    if current:
        parts.append("".join(current).strip())

    return [p for p in parts if p]
