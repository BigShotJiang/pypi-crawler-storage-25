"""
shell_quoting.py — 命令 stdin 重定向（防交互卡死）

职责：
    给进入 ``bash -c`` 的命令追加 stdin EOF（``eval '...' < /dev/null`` 或管道重排），
    让 REPL/编辑器读 EOF 自然退出，避免子进程继承父 stdin 阻塞。

链路位置：
    ``BashBackend._preprocess_shell_command`` / ``BashSessionRuntime`` 拼包装前调用。

CC 对照：
    ``utils/bash/shellQuoting.ts::quoteShellCommand``
    ``utils/bash/bashPipeCommand.ts::rearrangePipeCommand``
    ``utils/shell/bashProvider.ts`` → ``eval ${quotedCommand}``

当前裁剪范围：
    heredoc / 已有 stdin 重定向 / process substitution ``<(`` 跳过；
    管道命令重排 redirect 到头段（CC ``rearrangePipeCommand`` 简化版）。
"""

from __future__ import annotations

import re

_HEREDOC_RE = re.compile(r"<<-?\s*(?:['\"]?(\w+)['\"]?|\\(\w+))")
_BIT_SHIFT_RE = re.compile(r"\d\s*<<\s*\d")
_EXPLICIT_STDIN_RE = re.compile(r"(?<!<)<(?!<|\()\s*\S")
_PROCESS_SUBST_RE = re.compile(r"<\(")
_CONTROL_STRUCTURE_RE = re.compile(r"\b(for|while|until|if|case|select)\s")
_SHELL_VAR_RE = re.compile(r"\$[A-Za-z_{]")


def has_heredoc(command: str) -> bool:
    if _BIT_SHIFT_RE.search(command):
        return False
    return bool(_HEREDOC_RE.search(command))


def has_explicit_stdin(command: str) -> bool:
    return bool(_EXPLICIT_STDIN_RE.search(command))


def has_process_substitution(command: str) -> bool:
    return bool(_PROCESS_SUBST_RE.search(command))


def _bash_single_quote(command: str) -> str:
    escaped = command.replace("'", "'\"'\"'")
    return f"'{escaped}'"


def _eval_with_stdin_redirect(command: str) -> str:
    """``eval 'cmd' < /dev/null`` — 非管道场景的 CC 对齐形式。"""
    return f"eval {_bash_single_quote(command)} < /dev/null"


def _should_use_pipe_eval_fallback(command: str) -> bool:
    """复杂语法无法安全重排管道时，回退整段 eval（对齐 CC bashPipeCommand 早退）。"""
    if "`" in command or "$(" in command:
        return True
    if _SHELL_VAR_RE.search(command):
        return True
    if _CONTROL_STRUCTURE_RE.search(command):
        return True
    if "\n" in command:
        return True
    return False


def _split_top_level_pipes(command: str) -> list[str] | None:
    """按顶层 ``|`` 分段（不在引号内）。"""
    parts: list[str] = []
    buf: list[str] = []
    in_single = False
    in_double = False
    escape = False

    for ch in command:
        if escape:
            buf.append(ch)
            escape = False
            continue
        if ch == "\\" and in_double:
            escape = True
            buf.append(ch)
            continue
        if ch == "'" and not in_double:
            in_single = not in_single
            buf.append(ch)
            continue
        if ch == '"' and not in_single:
            in_double = not in_double
            buf.append(ch)
            continue
        if ch == "|" and not in_single and not in_double:
            parts.append("".join(buf))
            buf = []
            continue
        buf.append(ch)

    if in_single or in_double:
        return None

    parts.append("".join(buf))
    if len(parts) < 2:
        return None
    return parts


def _rearrange_pipe_command(command: str) -> str:
    """
    管道场景：``eval 'cmd1 < /dev/null | cmd2'``（redirect 在头段，不在 eval 尾）。

    CC 注释：``eval 'rg foo | wc -l' < /dev/null`` 会把 redirect 落到尾段，头段仍读 stdin 卡死。
    """
    if _should_use_pipe_eval_fallback(command):
        return _eval_with_stdin_redirect(command)

    segments = _split_top_level_pipes(command)
    if segments is None:
        return _eval_with_stdin_redirect(command)

    first = segments[0].strip()
    if not first:
        return _eval_with_stdin_redirect(command)

    rest = " | ".join(segment.strip() for segment in segments[1:])
    rearranged = f"{first} < /dev/null | {rest}"
    return f"eval {_bash_single_quote(rearranged)}"


def append_stdin_redirect(command: str) -> str:
    """给命令补 stdin EOF；heredoc / 显式 stdin / process subst 跳过。"""
    stripped = command.strip()
    if not stripped:
        return command
    if (
        has_heredoc(stripped)
        or has_explicit_stdin(stripped)
        or has_process_substitution(stripped)
    ):
        return command
    if "|" in stripped:
        return _rearrange_pipe_command(stripped)
    return _eval_with_stdin_redirect(stripped)
