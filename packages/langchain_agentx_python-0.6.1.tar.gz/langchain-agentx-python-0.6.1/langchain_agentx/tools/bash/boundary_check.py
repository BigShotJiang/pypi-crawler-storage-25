"""
tools/bash/boundary_check.py — Bash 命令边界检查（read/write_roots 分层）

职责：
    基于 BashReadOnlyClassifier 将命令归类为读/写边界检查；处理 cd 落点 read_roots 校验。

链路位置：
    BashRuntimeTool.check_permissions → authorize_bash_boundary()

当前裁剪范围：
    复合命令保守归写；未知命令归写；cd 单独处理。
"""

from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from langchain_agentx.tool_runtime.models import AuthorizationDecision
from langchain_agentx.workspace.tool_boundary import get_boundary_view, resolve_tool_cwd

from .read_only_validation import BashReadOnlyClassifier

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext


@dataclass(frozen=True)
class BashBoundaryScope:
    scope: Literal["read", "write"]
    reason: str


class BashBoundaryChecker:
    """按命令分类选择 read_roots 或 write_roots 边界。"""

    _REDIRECT_WRITE_RE = re.compile(r"(?<![<>])>>?(?![<>])")

    def __init__(self, classifier: BashReadOnlyClassifier | None = None) -> None:
        self._classifier = classifier or BashReadOnlyClassifier()

    def classify_scope(self, command: str) -> BashBoundaryScope:
        text = command.strip()
        if not text:
            return BashBoundaryScope(scope="write", reason="empty_command")

        if self._REDIRECT_WRITE_RE.search(text):
            return BashBoundaryScope(scope="write", reason="redirect")

        segments = self._split_compound(text)
        if len(segments) > 1:
            for seg in segments:
                sub = self.classify_scope(seg)
                if sub.scope == "write":
                    return BashBoundaryScope(scope="write", reason="compound_has_write")
            return BashBoundaryScope(scope="read", reason="compound_all_read")

        if "|" in text:
            parts = text.split("|")
            for part in parts:
                sub = self.classify_scope(part.strip())
                if sub.scope == "write":
                    return BashBoundaryScope(scope="write", reason="pipe_has_write")
            return BashBoundaryScope(scope="read", reason="pipe_all_read")

        classification = self._classifier.classify(text)
        if classification.is_read_only:
            return BashBoundaryScope(scope="read", reason="classifier_read_only")
        return BashBoundaryScope(scope="write", reason="classifier_write_or_unknown")

    @staticmethod
    def _split_compound(command: str) -> list[str]:
        parts: list[str] = []
        for chunk in re.split(r"(?:&&|\|\||;)", command):
            chunk = chunk.strip()
            if chunk:
                parts.append(chunk)
        return parts

    def extract_cd_target(self, command: str, *, cwd: str) -> Path | None:
        text = command.strip()
        if not text.startswith("cd"):
            return None
        tokens = text.split(None, 1)
        if len(tokens) < 2:
            return Path(cwd)
        target_raw = tokens[1].strip()
        if target_raw.startswith("-"):
            return None
        try:
            parts = shlex.split(target_raw, posix=os.name != "nt")
        except ValueError:
            parts = [target_raw]
        if not parts:
            return Path(cwd)
        target = parts[0]
        if target == "~" or target.startswith("~/"):
            return Path(os.path.expanduser(target)).resolve()
        p = Path(target)
        if p.is_absolute():
            return p.resolve()
        return (Path(cwd) / target).resolve()


def authorize_bash_boundary(
    command: str,
    ctx: ToolExecutionContext,
    *,
    classifier: BashReadOnlyClassifier | None = None,
) -> AuthorizationDecision | None:
    view = get_boundary_view(ctx)
    if view is None:
        return None

    checker = BashBoundaryChecker(classifier)
    cwd = resolve_tool_cwd(ctx)

    if not view.check_read(cwd):
        return AuthorizationDecision(
            behavior="deny",
            message=(
                f"Path {cwd} is not within any allowed read working directory. "
                f"Allowed read roots: [{', '.join(str(r) for r in view.effective_read_roots())}]"
            ),
            policy_id="boundary_read_roots",
        )

    cd_target = checker.extract_cd_target(command, cwd=cwd)
    if cd_target is not None:
        if not view.check_read(cd_target):
            return AuthorizationDecision(
                behavior="deny",
                message=(
                    f"Path {cd_target} is not within any allowed read working directory. "
                    f"Allowed read roots: [{', '.join(str(r) for r in view.effective_read_roots())}]"
                ),
                policy_id="boundary_read_roots",
            )
        stripped = command.strip()
        if (
            stripped.startswith("cd ")
            and "&&" not in stripped
            and "||" not in stripped
            and ";" not in stripped
            and "|" not in stripped
            and not checker._REDIRECT_WRITE_RE.search(stripped)
        ):
            return AuthorizationDecision(behavior="allow", policy_id="boundary_bash_cd")

    scope = checker.classify_scope(command)
    if scope.scope == "read":
        if not view.check_read(cwd):
            return AuthorizationDecision(
                behavior="deny",
                message=str(
                    f"cwd {cwd} not in allowed read roots"
                ),
                policy_id="boundary_read_roots",
            )
    else:
        if not view.check_write(cwd):
            return AuthorizationDecision(
                behavior="deny",
                message=(
                    f"Path {cwd} is not within any allowed write working directory. "
                    f"Allowed write roots: [{', '.join(str(r) for r in view.effective_write_roots())}]"
                ),
                policy_id="boundary_write_roots",
            )

    return AuthorizationDecision(behavior="allow", policy_id="boundary_bash")


__all__ = ["BashBoundaryChecker", "authorize_bash_boundary"]
