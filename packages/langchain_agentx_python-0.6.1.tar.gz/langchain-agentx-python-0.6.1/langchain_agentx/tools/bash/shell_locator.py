"""
shell_locator.py — POSIX shell（bash/zsh）可执行文件解析

职责：
    按冻结顺序解析 **绝对路径**：环境变量覆盖 → PATH 上 `where`/`which` → 固定回退路径；
    并对候选做 **basename 含 bash|zsh**、普通文件、可执行性校验（对齐 CC `findSuitableShell` 思路）。

链路位置：
    `BashBackend` / `BashSessionRuntime` 在 `Popen` / `create_subprocess_exec` 前取 argv[0]；
    顺序常量与 `bash_runtime_contract.SHELL_ENV_PRECEDENCE` 一致。

当前裁剪范围：
    不重写用户命令；WSL 包装命令非默认解析链。Windows cwd 文件回传见 **`cwd_reporter.py`**。
    Windows 使用 **`where.exe`** 遍历 PATH（与 CC `utils/which.ts` 语义对齐）；**不**将
    `shutil.which("bash")` 作为 Windows 主路径来源——因 `shutil.which` 与 `where.exe` 在
    PATHEXT、遍历顺序上可能不一致（若未来改为 which 主路径，须在模块注释与单测
    中写明与 CC 的差异及原因）。

CC 对照（src/ 相对 CC 检出根）：
    `utils/Shell.ts` — `findSuitableShell`
    `utils/which.ts` — `where.exe` 与首行语义
    `utils/windowsPaths.ts` — cwd 下同名 exe 过滤（本实现 `_skip_if_in_cwd`）
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from collections.abc import Mapping

from .bash_runtime_contract import SHELL_ENV_PRECEDENCE

_RUNTIME_ERROR_LEAD = (
    "BashRuntimeTool：未找到可用的 POSIX shell（bash / zsh）。\n\n"
    "推荐：\n"
    "  1. 安装 Git for Windows：https://git-scm.com/download/win\n"
    "  2. 安装后在 CMD 中执行：where bash\n"
    "     应出现类似：C:\\Program Files\\Git\\bin\\bash.exe\n\n"
    "临时指定（本工程优先于 CC 变量）：\n"
    "  set LANGCHAIN_AGENTX_SHELL=C:\\path\\to\\bash.exe\n\n"
    "兼容 CC：\n"
    "  set CLAUDE_CODE_SHELL=C:\\path\\to\\bash.exe\n\n"
    "当前已尝试：\n"
    "  LANGCHAIN_AGENTX_SHELL → CLAUDE_CODE_SHELL → SHELL → where/which → 常见路径回退\n"
)

_WIN_GIT_BASH_FALLBACKS: tuple[str, ...] = (
    r"C:\Program Files\Git\bin\bash.exe",
    r"C:\Program Files (x86)\Git\bin\bash.exe",
)

_POSIX_BASH_FALLBACKS: tuple[str, ...] = (
    "/bin/bash",
    "/usr/bin/bash",
    "/usr/local/bin/bash",
    "/opt/homebrew/bin/bash",
)

_POSIX_ZSH_FALLBACKS: tuple[str, ...] = (
    "/bin/zsh",
    "/usr/bin/zsh",
    "/usr/local/bin/zsh",
    "/opt/homebrew/bin/zsh",
)


def _norm_exe(path: str) -> str:
    return os.path.normpath(os.path.realpath(os.path.expanduser(path.strip().strip('"'))))


def _basename_ok(path: str) -> bool:
    base = os.path.basename(path).lower()
    return "bash" in base or "zsh" in base


def _skip_if_in_cwd(path: str) -> bool:
    """与 CC cwd 投毒防护类似：跳过「解析后位于当前工作目录」的候选。"""
    try:
        from pathlib import Path

        d = Path(path).resolve().parent
        c = Path.cwd().resolve()
        return d == c
    except (OSError, ValueError):
        return False


def _is_executable_file(path: str) -> bool:
    if not os.path.isfile(path):
        return False
    if os.access(path, os.X_OK):
        return True
    try:
        r = subprocess.run(
            [path, "--version"],
            capture_output=True,
            timeout=5,
            env=os.environ,
        )
        return r.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _validate_shell(path: str, *, allow_in_cwd: bool = False) -> str | None:
    p = _norm_exe(path)
    if not _basename_ok(p):
        return None
    if not allow_in_cwd and _skip_if_in_cwd(p):
        return None
    if not _is_executable_file(p):
        return None
    return p


def _where_win(names: tuple[str, ...], env: dict[str, str]) -> list[str]:
    out: list[str] = []
    for name in names:
        try:
            cp = subprocess.run(
                ["where.exe", name],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        if cp.returncode != 0 or not (cp.stdout or "").strip():
            continue
        for line in cp.stdout.splitlines():
            s = line.strip().strip('"')
            if s:
                out.append(s)
    return out


def _which_posix(cmd: str, env: dict[str, str]) -> str | None:
    path = env.get("PATH")
    if path:
        return shutil.which(cmd, path=path)
    return shutil.which(cmd)


class PosixShellLocator:
    """从环境中解析 POSIX shell 绝对路径。"""

    __slots__ = ("_environ",)

    def __init__(self, environ: Mapping[str, str] | None = None) -> None:
        self._environ = dict(os.environ if environ is None else environ)

    def resolve(self) -> str:
        merged = self._environ

        for key in SHELL_ENV_PRECEDENCE:
            raw = merged.get(key)
            if raw is None or not str(raw).strip():
                continue
            candidate = _norm_exe(str(raw))
            ok = _validate_shell(candidate, allow_in_cwd=True)
            if ok:
                return ok

        if sys.platform == "win32":
            for line in _where_win(("bash", "zsh"), merged):
                ok = _validate_shell(line, allow_in_cwd=False)
                if ok:
                    return ok
            for fb in _WIN_GIT_BASH_FALLBACKS:
                ok = _validate_shell(fb, allow_in_cwd=False)
                if ok:
                    return ok
        else:
            for cmd in ("bash", "zsh"):
                w = _which_posix(cmd, merged)
                if w:
                    ok = _validate_shell(w, allow_in_cwd=False)
                    if ok:
                        return ok
            for fb in _POSIX_BASH_FALLBACKS + _POSIX_ZSH_FALLBACKS:
                ok = _validate_shell(fb, allow_in_cwd=False)
                if ok:
                    return ok

        raise RuntimeError(_RUNTIME_ERROR_LEAD)


def resolve_posix_shell(environ: Mapping[str, str] | None = None) -> str:
    """解析并返回 POSIX shell 绝对路径（薄封装）。"""
    return PosixShellLocator(environ=environ).resolve()
