"""
tools/glob/rg_list_backend.py — rg --files 列路径（对齐 CC utils/glob.ts）

职责：拼装与 CC 一致的 ripgrep 参数并调用 run_ripgrep_lines。
链路：GlobRuntimeTool.invoke -> list_files_via_ripgrep -> run_ripgrep_lines。

裁剪：plugin cache 排除由调用方传入 `plugin_glob_exclusions`（与 CC glob.ts 追加顺序一致）。
Glob 默认不排除 VCS（与 CC glob.ts 一致）；可选 env ``LANGCHAIN_AGENTX_GLOB_EXCLUDE_VCS=1``。
"""

from __future__ import annotations

import os
import threading

from langchain_agentx.tools.grep.backend import RipgrepBackend, run_ripgrep_lines  # VCS_EXCLUDE_DIRS for opt-in
from langchain_agentx.utils.subprocess_text import (
    TextSubprocessRunner,
    default_text_subprocess_runner,
)


def _read_cc_style_flag(*, langchain_key: str, cc_key: str) -> bool:
    v = os.environ.get(langchain_key)
    if v is None:
        v = os.environ.get(cc_key, "1")
    return v.strip().lower() not in ("", "0", "false", "no", "off")


def _glob_exclude_vcs_from_env() -> bool:
    """默认 false（CC glob.ts 不硬排除 .git）；显式 env=1 时恢复旧 SDK 行为。"""
    for key in ("LANGCHAIN_AGENTX_GLOB_EXCLUDE_VCS", "CLAUDE_CODE_GLOB_EXCLUDE_VCS"):
        v = os.environ.get(key)
        if v is not None:
            return v.strip().lower() in ("1", "true", "yes", "on")
    return False


def _ignore_patterns_to_rg_globs(ignore_patterns: list[str] | None) -> list[str]:
    out: list[str] = []
    if not ignore_patterns:
        return out
    for p in ignore_patterns:
        p = str(p).strip()
        if not p:
            continue
        rg_pat = f"!{p}" if p.startswith("/") else f"!**/{p}"
        out.extend(["--glob", rg_pat])
    return out


def build_rg_files_args(
    relative_glob: str,
    *,
    no_ignore: bool | None = None,
    hidden: bool | None = None,
    ignore_patterns: list[str] | None = None,
    plugin_glob_exclusions: list[str] | None = None,
) -> list[str]:
    """
    对齐 CC glob.ts：--files --glob <pattern> --sort=modified，及默认 --no-ignore / --hidden。
    环境变量（与 CC 名称兼容，便于本机已有配置）：
      CLAUDE_CODE_GLOB_NO_IGNORE / LANGCHAIN_AGENTX_GLOB_NO_IGNORE
      CLAUDE_CODE_GLOB_HIDDEN / LANGCHAIN_AGENTX_GLOB_HIDDEN
      LANGCHAIN_AGENTX_GLOB_EXCLUDE_VCS / CLAUDE_CODE_GLOB_EXCLUDE_VCS（默认 false）
    未设置时默认 true（与 CC 一致）。
    """
    if no_ignore is None:
        no_ignore = _read_cc_style_flag(
            langchain_key="LANGCHAIN_AGENTX_GLOB_NO_IGNORE",
            cc_key="CLAUDE_CODE_GLOB_NO_IGNORE",
        )
    if hidden is None:
        hidden = _read_cc_style_flag(
            langchain_key="LANGCHAIN_AGENTX_GLOB_HIDDEN",
            cc_key="CLAUDE_CODE_GLOB_HIDDEN",
        )

    args: list[str] = [
        "--files",
        "--glob",
        relative_glob,
        "--sort=modified",
    ]
    if no_ignore:
        args.append("--no-ignore")
    if hidden:
        args.append("--hidden")
    if _glob_exclude_vcs_from_env():
        for d in RipgrepBackend.VCS_EXCLUDE_DIRS:
            args.extend(["--glob", f"!{d}"])
    args.extend(_ignore_patterns_to_rg_globs(ignore_patterns))
    if plugin_glob_exclusions:
        for ex in plugin_glob_exclusions:
            if ex:
                args.extend(["--glob", ex])
    return args


def list_files_via_ripgrep(
    search_root: str,
    relative_glob: str,
    *,
    rg_path: str,
    timeout: int,
    ignore_patterns: list[str] | None = None,
    plugin_glob_exclusions: list[str] | None = None,
    text_runner: TextSubprocessRunner | None = None,
    cancel_event: threading.Event | None = None,
) -> list[str]:
    """
    在 search_root 下执行 rg，返回**绝对路径**列表（仅文件），路径已 normpath。
    stdout 行为与 CC 一致：相对 search_root 的相对路径。
    """
    runner = text_runner or default_text_subprocess_runner()
    args = build_rg_files_args(
        relative_glob,
        ignore_patterns=ignore_patterns,
        plugin_glob_exclusions=plugin_glob_exclusions,
    )
    lines = run_ripgrep_lines(
        rg_path,
        args,
        search_root,
        timeout=timeout,
        text_runner=runner,
        is_retry=False,
        cancel_event=cancel_event,
    )
    root = os.path.realpath(search_root)
    files: list[str] = []
    seen: set[str] = set()
    for ln in lines:
        p = ln.strip()
        if not p:
            continue
        full = os.path.normpath(p if os.path.isabs(p) else os.path.join(root, p))
        if full in seen:
            continue
        if os.path.isfile(full):
            seen.add(full)
            files.append(full)
    # 对齐 CC：--sort=modified 升序；同 mtime 时按路径稳定次序
    def _mtime_key(path: str) -> tuple[float, str]:
        try:
            return (os.path.getmtime(path), path)
        except OSError:
            return (0.0, path)

    files.sort(key=_mtime_key)
    return files
