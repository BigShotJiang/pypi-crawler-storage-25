"""
hook_event_emitter.py — Hook 执行记录写入 TraceCollector，并向 LangGraph 事件流投影 UI 事件。

职责：
    - trace：HookExecutionRecord → collector（不变）
    - UI：per-script hook_progress / hook_response → 内存队列或 dispatch_custom_event

链路位置：
    HookEngine 执行前后调用本发射器；graph_wiring 在节点结束时 drain 队列写入 patch。

当前裁剪范围：
    UI 事件不写 trace；伴侣包单向依赖，SDK 不 import trace 展示层。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from langchain_agentx.loop.hook.types import HookExecutionRecord

from .collector import TraceCollector


@dataclass
class HookEventEmitter:
    """Hook 执行记录 + LangchainAgent UI 事件发射器。"""

    collector: TraceCollector
    enable_ui_events: bool = True
    _pending_ui_events: list[dict[str, Any]] = field(default_factory=list, repr=False)

    def emit_record(self, session_id: str, record: HookExecutionRecord) -> str:
        return self.collector.emit_event(
            session_id=session_id,
            event_type="hook.execution",
            payload={
                "hook_id": record.hook_id,
                "hook_event": record.hook_event,
                "hook_source": record.hook_source,
                "matcher": record.matcher,
                "matched": record.matched,
                "skip_reason": record.skip_reason,
                "snapshot_id": record.snapshot_id,
                "policy_source": record.policy_source,
                "outcome": record.outcome,
                "prevent_continuation": record.prevent_continuation,
                "duration_ms": record.duration_ms,
                "tool_call_id": record.tool_call_id,
                "stdout": record.stdout,
                "stderr": record.stderr,
                "exit_code": record.exit_code,
            },
        )

    def emit_progress(self, payload: dict[str, Any]) -> None:
        """对齐 CC hook_progress；默认入队，由图节点 patch 或 custom_event 消费。"""
        if not self.enable_ui_events:
            return
        self._enqueue_ui("hook_progress", payload)

    def emit_response(self, payload: dict[str, Any]) -> None:
        """对齐 CC hook_response；映射为 LangchainAgent HOOK_FINISHED（per-script）。"""
        if not self.enable_ui_events:
            return
        self._enqueue_ui("hook_response", payload)

    def _enqueue_ui(self, channel: str, payload: dict[str, Any]) -> None:
        self._pending_ui_events.append({"channel": channel, "data": dict(payload)})

    def drain_ui_events(self) -> list[dict[str, Any]]:
        """取出并清空待发射 UI 事件（供 graph 节点写入 _hook_ui_events）。"""
        pending = list(self._pending_ui_events)
        self._pending_ui_events.clear()
        return pending

    def try_dispatch_ui_event(
        self,
        channel: str,
        payload: dict[str, Any],
        *,
        runnable_config: Any | None = None,
    ) -> bool:
        """在具备 LangGraph RunnableConfig 时直接 dispatch_custom_event。"""
        if not self.enable_ui_events or runnable_config is None:
            return False
        try:
            from langchain_core.callbacks import dispatch_custom_event

            dispatch_custom_event(channel, payload, config=runnable_config)
            return True
        except Exception:
            return False


__all__ = ["HookEventEmitter"]
