"""
workspace/grant.py — 动态边界授权记录（GrantedRoot）

职责：
    定义 session 内动态扩展边界的不可变记录类型；Phase 2 接通 grant/revoke API。

链路位置：
    AgentSessionStore.granted_roots → WorkspaceBoundaryView.effective_*_roots()

当前裁剪范围：
    GrantedRoot 记录 + RootGrantManager（grant/revoke/去重/scope 提升）；L3 桥接见 l3_root_grant.py。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal


@dataclass(frozen=True, slots=True)
class GrantedRoot:
    """单条动态授权记录；撤销 = 从 session list 移除。"""

    grant_id: str
    path: Path
    scope: Literal["read", "write"]
    granter: Literal["user", "policy", "config"]
    granted_at: float
    tool_call_id: str | None = None
    reason: str | None = None


__all__ = ["GrantedRoot"]
