"""
workspace/errors.py — Workspace Boundary 协议层错误

职责：
    定义边界配置与运行时越界检查的异常类型；供 boundary.build、view 检查与工具层返回 deny。

链路位置：
    WorkspaceBoundary.build() → ConfigError
    WorkspaceBoundaryView.check_* → BoundaryViolationError
    工具 validate_input / check_permissions → 转为 ValidationResult / AuthorizationDecision

当前裁剪范围：
    仅 ConfigError、BoundaryViolationError；grant 相关错误在 Phase 2 扩展。
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal


class ConfigError(ValueError):
    """Workspace 配置无效（构造期 fail-fast）。"""


class BoundaryViolationError(PermissionError):
    """路径不在本 loop 允许的 read/write 边界内。"""

    def __init__(
        self,
        *,
        scope: Literal["read", "write"],
        path: Path | str,
        allowed_roots: list[Path],
        message: str | None = None,
    ) -> None:
        self.scope = scope
        self.path = Path(path)
        self.allowed_roots = list(allowed_roots)
        roots_text = ", ".join(str(r) for r in self.allowed_roots) or "(none)"
        default = (
            f"Path {self.path} is not within any allowed {scope} working directory. "
            f"Allowed {scope} roots: [{roots_text}]"
        )
        super().__init__(message or default)


__all__ = ["BoundaryViolationError", "ConfigError"]
