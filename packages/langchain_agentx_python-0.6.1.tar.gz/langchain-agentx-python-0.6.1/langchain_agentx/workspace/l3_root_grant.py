"""
workspace/l3_root_grant.py — L3 HITL allow 后动态 grant 桥接

职责：
    将 L3 PromptResponse.permission_updates 与工具入参路径转为 session.grant_root 调用。

链路位置：
    ToolExecutorPipeline L3 allow 分支 → apply_l3_root_grants()

当前裁剪范围：
    addDirectories + Read/Write/Edit/Glob/Grep 显式 addDirectories；无 permission_updates 时不隐式 grant。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext
    from langchain_agentx.tool_runtime.prompt.types import PermissionUpdate
    from langchain_agentx.tool_runtime.session_store import AgentSessionStore


def apply_l3_root_grants(
    ctx: ToolExecutionContext,
    *,
    tool_name: str,
    input_data: dict[str, Any],
    permission_updates: tuple[PermissionUpdate, ...] = (),
    granter: str = "user",
    decision_source: str | None = None,
) -> list[str]:
    """L3 allow 后应用动态 root grant；返回 grant_id 列表。"""
    store: AgentSessionStore | None = ctx.session_store
    if store is None or not store.enable_dynamic_root_grant:
        return []

    effective_granter: str = granter
    if decision_source in ("classifier", "permission_hook"):
        effective_granter = "policy"

    grant_ids: list[str] = []

    for update in permission_updates:
        if update.type == "addDirectories":
            for directory in update.directories:
                scope: Literal["read", "write"] = "read"
                if update.behavior == "allow" and tool_name in ("write", "edit"):
                    scope = "write"
                grant_ids.append(
                    store.grant_root(
                        path=directory,
                        scope=scope,
                        granter=effective_granter,  # type: ignore[arg-type]
                        tool_call_id=ctx.tool_call_id,
                        reason=f"l3_permission_update:{update.type}",
                    )
                )

    return grant_ids


__all__ = ["apply_l3_root_grants"]
