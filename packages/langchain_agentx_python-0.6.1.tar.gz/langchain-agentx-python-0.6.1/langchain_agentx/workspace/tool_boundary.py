"""
workspace/tool_boundary.py — 工具层边界检查薄封装

职责：
    从 ToolExecutionContext 取 boundary_view 并执行 read/write 检查，返回标准 ValidationResult / AuthorizationDecision。

链路位置：
    Read/Write/Edit/Glob/Grep/Bash check_permissions / validate_input

当前裁剪范围：
    无 boundary_view 时跳过（向后兼容过渡期）；有 view 时 fail-closed deny。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from langchain_agentx.tool_runtime.models import AuthorizationDecision, ValidationResult

from .errors import BoundaryViolationError, ConfigError
from .view import WorkspaceBoundaryView

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext


def get_boundary_view(ctx: ToolExecutionContext) -> WorkspaceBoundaryView | None:
    view = getattr(ctx, "boundary_view", None)
    if isinstance(view, WorkspaceBoundaryView):
        return view
    return None


def resolve_tool_cwd(ctx: ToolExecutionContext) -> str:
    view = get_boundary_view(ctx)
    if view is not None:
        return str(view.resolve_cwd(ctx))
    if isinstance(ctx.cwd, str) and ctx.cwd:
        return ctx.cwd
    if isinstance(ctx.workspace_root, str) and ctx.workspace_root:
        return ctx.workspace_root
    raise ConfigError(
        "resolve_tool_cwd: no boundary_view, ctx.cwd, or workspace_root provided. "
        "Ensure create_loop_agent() was called with explicit workspace_root."
    )


def validate_read_boundary(ctx: ToolExecutionContext, path: str | Path) -> ValidationResult | None:
    view = get_boundary_view(ctx)
    if view is None:
        return None
    try:
        view.require_read(path)
    except BoundaryViolationError as exc:
        return ValidationResult(ok=False, message=str(exc), code="BOUNDARY_READ_DENIED")
    return None


def validate_write_boundary(ctx: ToolExecutionContext, path: str | Path) -> ValidationResult | None:
    view = get_boundary_view(ctx)
    if view is None:
        return None
    try:
        view.require_write(path)
    except BoundaryViolationError as exc:
        return ValidationResult(ok=False, message=str(exc), code="BOUNDARY_WRITE_DENIED")
    return None


def authorize_read_boundary(ctx: ToolExecutionContext, path: str | Path) -> AuthorizationDecision | None:
    view = get_boundary_view(ctx)
    if view is None:
        return None
    try:
        view.require_read(path)
    except BoundaryViolationError as exc:
        return AuthorizationDecision(
            behavior="deny",
            message=str(exc),
            policy_id="boundary_read_roots",
        )
    return None


def authorize_write_boundary(ctx: ToolExecutionContext, path: str | Path) -> AuthorizationDecision | None:
    view = get_boundary_view(ctx)
    if view is None:
        return None
    try:
        view.require_write(path)
    except BoundaryViolationError as exc:
        return AuthorizationDecision(
            behavior="deny",
            message=str(exc),
            policy_id="boundary_write_roots",
        )
    return None


__all__ = [
    "authorize_read_boundary",
    "authorize_write_boundary",
    "get_boundary_view",
    "resolve_tool_cwd",
    "validate_read_boundary",
    "validate_write_boundary",
]
