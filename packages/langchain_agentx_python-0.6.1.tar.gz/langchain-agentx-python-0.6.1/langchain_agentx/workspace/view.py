"""
workspace/view.py — WorkspaceBoundaryView 运行期派生视图

职责：
    工具层唯一边界入口：resolve_cwd、effective_read/write_roots、check_read/write。

链路位置：
    LangChainAdapter.build_tool_execution_context → ctx.boundary_view
    各 RuntimeTool normalize/validate/check_permissions

当前裁剪范围：
    granted_roots 从 session 读取（Phase 2 grant API 已接通）；测试仍可用 extra_granted 注入。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from .boundary import is_descendant_or_eq
from .errors import BoundaryViolationError

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext
    from langchain_agentx.tool_runtime.session_store import AgentSessionStore

    from .boundary import WorkspaceBoundary
    from .grant import GrantedRoot


class WorkspaceBoundaryView:
    """per-call 构造的派生视图；合并 initial roots 与 session granted_roots。"""

    def __init__(
        self,
        boundary: WorkspaceBoundary,
        session: AgentSessionStore | None = None,
        *,
        extra_granted: tuple[GrantedRoot, ...] = (),
    ) -> None:
        self._boundary = boundary
        self._session = session
        self._extra_granted = extra_granted

    def _grants(self) -> tuple[GrantedRoot, ...]:
        grants: list[GrantedRoot] = list(self._extra_granted)
        if self._session is not None:
            grants.extend(self._session.granted_roots)
        return tuple(grants)

    def effective_read_roots(self) -> list[Path]:
        roots = list(self._boundary.initial_read_roots)
        for g in self._grants():
            if g.scope in ("read", "write"):
                roots.append(g.path)
        return roots

    def effective_write_roots(self) -> list[Path]:
        roots = list(self._boundary.initial_write_roots)
        for g in self._grants():
            if g.scope == "write":
                roots.append(g.path)
        return roots

    def check_read(self, path: Path | str) -> bool:
        target = Path(path)
        return any(is_descendant_or_eq(target, root) for root in self.effective_read_roots())

    def check_write(self, path: Path | str) -> bool:
        target = Path(path)
        return any(is_descendant_or_eq(target, root) for root in self.effective_write_roots())

    def require_read(self, path: Path | str) -> None:
        if not self.check_read(path):
            raise BoundaryViolationError(
                scope="read",
                path=path,
                allowed_roots=self.effective_read_roots(),
            )

    def require_write(self, path: Path | str) -> None:
        if not self.check_write(path):
            raise BoundaryViolationError(
                scope="write",
                path=path,
                allowed_roots=self.effective_write_roots(),
            )

    def resolve_cwd(self, ctx: ToolExecutionContext | None = None) -> Path:
        """所有工具 base_dir 统一入口（对应 CC getCwd()）。"""
        if self._session is not None:
            sess_cwd = self._session.cwd_override
            if isinstance(sess_cwd, str) and sess_cwd:
                candidate = Path(sess_cwd)
                if candidate.is_dir():
                    return candidate
        if ctx is not None and isinstance(ctx.cwd, str) and ctx.cwd:
            candidate = Path(ctx.cwd)
            if candidate.is_dir():
                return candidate
        return self._boundary.workspace_root

    def resolve_reset_target(self) -> Path:
        """cwd 失效回退目标（永远 = 主锚，不含 granted）。"""
        return self._boundary.workspace_root

    @property
    def workspace_root(self) -> Path:
        return self._boundary.workspace_root


__all__ = ["WorkspaceBoundaryView"]
