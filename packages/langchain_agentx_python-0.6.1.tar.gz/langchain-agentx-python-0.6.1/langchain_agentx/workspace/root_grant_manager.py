"""
workspace/root_grant_manager.py — 动态边界 grant/revoke 协作者

职责：
    实现 session 内 read/write root 动态扩展：路径归一化、去重、scope 提升、audit 写入。

链路位置：
    AgentSessionStore.grant_root / revoke_grant / list_grants → 本类

当前裁剪范围：
    仅 session 内存态；不做磁盘持久化（session 销毁 grant 清空）。
"""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from .boundary import WorkspaceBoundary, is_descendant_or_eq, paths_equal
from .errors import ConfigError
from .grant import GrantedRoot

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.session_store import AgentSessionStore

Granter = Literal["user", "policy", "config"]
GrantScope = Literal["read", "write"]


class RootGrantManager:
    """管理 AgentSessionStore._granted_roots 的 mutate 与 audit。"""

    def __init__(
        self,
        store: AgentSessionStore,
        *,
        boundary: WorkspaceBoundary | None = None,
    ) -> None:
        self._store = store
        self._boundary = boundary

    def grant_root(
        self,
        *,
        path: str | Path,
        scope: GrantScope = "read",
        granter: Granter,
        reason: str | None = None,
        tool_call_id: str | None = None,
    ) -> str:
        if not self._store.enable_dynamic_root_grant:
            raise ConfigError(
                "Dynamic root grant is disabled for this loop_agent. "
                "Pass enable_dynamic_root_grant=True to create_loop_agent "
                "(CLI entry points enable this by default)."
            )

        resolved = Path(path).expanduser().resolve()

        existing = self._find_matching_grant(resolved, scope)
        if existing is not None:
            return existing.grant_id

        if self._is_covered_without_grant(resolved, scope):
            return self._record_dedup_audit(
                path=resolved,
                scope=scope,
                granter=granter,
                tool_call_id=tool_call_id,
                reason=reason,
            )

        promoted = self._try_promote_read_to_write(resolved, scope, granter, tool_call_id, reason)
        if promoted is not None:
            return promoted

        grant = GrantedRoot(
            grant_id=uuid.uuid4().hex,
            path=resolved,
            scope=scope,
            granter=granter,
            granted_at=time.time(),
            tool_call_id=tool_call_id,
            reason=reason,
        )
        self._store._granted_roots.append(grant)
        self._store.append_audit(
            {
                "type": "root_grant",
                "grant_id": grant.grant_id,
                "path": str(resolved),
                "scope": scope,
                "granter": granter,
                "ts": grant.granted_at,
                "reason": reason,
                "tool_call_id": tool_call_id,
            }
        )
        return grant.grant_id

    def revoke_grant(self, grant_id: str) -> bool:
        before = len(self._store._granted_roots)
        removed: GrantedRoot | None = None
        kept: list[GrantedRoot] = []
        for g in self._store._granted_roots:
            if g.grant_id == grant_id:
                removed = g
            else:
                kept.append(g)
        if removed is None:
            return False
        self._store._granted_roots = kept
        self._store.append_audit(
            {
                "type": "root_revoke",
                "grant_id": grant_id,
                "path": str(removed.path),
                "scope": removed.scope,
                "granter": removed.granter,
                "ts": time.time(),
                "reason": removed.reason,
                "tool_call_id": removed.tool_call_id,
            }
        )
        return before > len(self._store._granted_roots)

    def list_grants(self, *, scope: GrantScope | None = None) -> list[GrantedRoot]:
        grants = list(self._store._granted_roots)
        if scope is None:
            return grants
        return [g for g in grants if g.scope == scope]

    def _find_matching_grant(self, path: Path, scope: GrantScope) -> GrantedRoot | None:
        for g in self._store._granted_roots:
            if g.scope == scope and paths_equal(g.path, path):
                return g
        return None

    def _is_covered_without_grant(self, path: Path, scope: GrantScope) -> bool:
        if self._boundary is not None:
            initial = (
                self._boundary.initial_read_roots
                if scope == "read"
                else self._boundary.initial_write_roots
            )
            for root in initial:
                if is_descendant_or_eq(path, root):
                    return True

        for g in self._store._granted_roots:
            if scope == "read" and g.scope in ("read", "write"):
                if is_descendant_or_eq(path, g.path):
                    return True
            if scope == "write" and g.scope == "write":
                if is_descendant_or_eq(path, g.path):
                    return True
        return False

    def _record_dedup_audit(
        self,
        *,
        path: Path,
        scope: GrantScope,
        granter: Granter,
        tool_call_id: str | None,
        reason: str | None,
    ) -> str:
        """嵌套/等价路径已覆盖：写 dedup audit，返回 synthetic id。"""
        dedup_id = f"dedup-{uuid.uuid4().hex[:12]}"
        self._store.append_audit(
            {
                "type": "root_grant",
                "grant_id": dedup_id,
                "path": str(path),
                "scope": scope,
                "granter": granter,
                "ts": time.time(),
                "reason": reason or "dedup_existing_root",
                "tool_call_id": tool_call_id,
                "dedup": True,
            }
        )
        return dedup_id

    def _try_promote_read_to_write(
        self,
        path: Path,
        scope: GrantScope,
        granter: Granter,
        tool_call_id: str | None,
        reason: str | None,
    ) -> str | None:
        if scope != "write":
            return None
        for idx, g in enumerate(self._store._granted_roots):
            if g.scope == "read" and paths_equal(g.path, path):
                promoted = GrantedRoot(
                    grant_id=g.grant_id,
                    path=g.path,
                    scope="write",
                    granter=granter,
                    granted_at=time.time(),
                    tool_call_id=tool_call_id or g.tool_call_id,
                    reason=reason or g.reason,
                )
                updated = list(self._store._granted_roots)
                updated[idx] = promoted
                self._store._granted_roots = updated
                self._store.append_audit(
                    {
                        "type": "root_grant",
                        "grant_id": promoted.grant_id,
                        "path": str(promoted.path),
                        "scope": "write",
                        "granter": granter,
                        "ts": promoted.granted_at,
                        "reason": reason or "scope_promotion_read_to_write",
                        "tool_call_id": tool_call_id,
                        "promoted_from": "read",
                    }
                )
                return promoted.grant_id
        return None


__all__ = ["RootGrantManager"]
