"""
workspace/boundary.py — WorkspaceBoundary 不可变边界配置

职责：
    每个 loop_agent 持有一个 frozen 实例；构造期归一化路径并校验不变量 I1–I4。

链路位置：
    create_loop_agent → WorkspaceBoundary.build() → AgentLoopConfig.boundary

当前裁剪范围：
  read_roots / write_roots 显式分层（Phase 1）；动态 grant 由 view 合并 session。
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

from .errors import ConfigError


def _path_key(path: Path) -> str:
    text = str(path)
    if sys.platform == "win32":
        return os.path.normcase(text)
    return text


def paths_equal(a: Path, b: Path) -> bool:
    try:
        ra = a.expanduser().resolve()
        rb = b.expanduser().resolve()
    except OSError:
        return _path_key(a.expanduser()) == _path_key(b.expanduser())
    return _path_key(ra) == _path_key(rb)


def is_descendant_or_eq(path: Path, root: Path) -> bool:
    """path 等于 root 或在 root 子树内（resolve 后比较，防 symlink 越界）。"""
    try:
        p = path.expanduser().resolve()
        r = root.expanduser().resolve()
    except OSError:
        return False

    p_key = _path_key(p)
    r_key = _path_key(r)
    if p_key == r_key:
        return True
    sep = "\\" if sys.platform == "win32" else "/"
    prefix = r_key if r_key.endswith(sep) else r_key + sep
    return p_key.startswith(prefix)


def dedupe_nested(paths: list[Path]) -> tuple[Path, ...]:
    """A 包含 A/sub 时只保留 A。"""
    unique: list[Path] = []
    for p in paths:
        if not any(is_descendant_or_eq(p, other) and not paths_equal(p, other) for other in paths):
            unique.append(p)
    return tuple(sorted(unique, key=lambda x: _path_key(x)))


def _normalize_root(path: str | Path, *, strict: bool) -> Path:
    p = Path(path).expanduser()
    if strict:
        return p.resolve(strict=True)
    return p.resolve()


@dataclass(frozen=True, slots=True)
class WorkspaceBoundary:
    """
    每个 loop_agent 持有一个，不可变。

    不变量（构造时强校验）：
      I1: workspace_root ∈ write_roots
      I2: write_roots ⊆ read_roots
      I3: 所有路径已 expanduser + resolve
      I4: 路径之间不存在严格嵌套（去重）
    """

    workspace_root: Path
    initial_read_roots: tuple[Path, ...]
    initial_write_roots: tuple[Path, ...]

    @classmethod
    def build(
        cls,
        *,
        workspace_root: str | Path | None,
        read_roots: list[str | Path] | None = None,
        write_roots: list[str | Path] | None = None,
        strict: bool = True,
    ) -> WorkspaceBoundary:
        if workspace_root is None:
            raise ConfigError("workspace_root is required and has no default")

        ws = _normalize_root(workspace_root, strict=strict)

        rr_raw = [_normalize_root(p, strict=strict) for p in (read_roots or [ws])]
        wr_raw = [_normalize_root(p, strict=strict) for p in (write_roots or [ws])]

        if not any(paths_equal(ws, w) for w in wr_raw):
            raise ConfigError(f"workspace_root {ws} must be in write_roots")

        for w in wr_raw:
            if not any(is_descendant_or_eq(w, r) for r in rr_raw):
                raise ConfigError(
                    f"write root {w} must be within read_roots; "
                    f"write_roots must be a subset of read_roots"
                )

        rr = dedupe_nested(rr_raw)
        wr = dedupe_nested(wr_raw)

        if not any(paths_equal(ws, w) for w in wr):
            raise ConfigError(f"workspace_root {ws} must be in write_roots after dedupe")

        for w in wr:
            if not any(is_descendant_or_eq(w, r) for r in rr):
                raise ConfigError(
                    f"write root {w} must be within read_roots after dedupe"
                )

        return cls(
            workspace_root=ws,
            initial_read_roots=rr,
            initial_write_roots=wr,
        )


__all__ = [
    "WorkspaceBoundary",
    "dedupe_nested",
    "is_descendant_or_eq",
    "paths_equal",
]
