"""
engine.py — Hook 执行引擎（P1/P2）。

职责：
    负责按顺序执行 Hook 候选并聚合结果，输出 AggregatedHookResult。

链路位置：
    graph wiring 节点调用 HookEngine.execute(event, ctx) 获取可消费结果。

当前裁剪范围：
    已覆盖 function/callback + command/http/prompt/agent 执行器；
    当前执行策略为 callback/function 顺序、其余执行器并行。
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from typing import Any, TYPE_CHECKING

from .config import (
    HookCandidate,
    HookCandidateDecision,
    HooksConfigSnapshot,
    resolve_executor_callable,
)
from .executors import CommandExecutor
from .executors import HttpExecutor
from .executors import PromptExecutor
from .executors import AgentExecutor
from .types import (
    AggregatedHookResult,
    HookContext,
    HookExecutionRecord,
    HookResult,
    PermissionBehavior,
)
from .hook_projection import build_hook_info
from .trust import WorkspaceTrustChecker

if TYPE_CHECKING:
    from ...observability.trace.hook_event_emitter import HookEventEmitter


logger = logging.getLogger(__name__)


class FunctionExecutor:
    """执行 function 类型 hook。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        fn = resolve_executor_callable(candidate.spec)
        out = fn(ctx)
        if inspect.isawaitable(out):
            out = await out
        return normalize_hook_result(out)


class CallbackExecutor:
    """执行 callback 类型 hook，支持 timeout。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        cb = resolve_executor_callable(candidate.spec)
        coro = cb(ctx)
        if not inspect.isawaitable(coro):
            return normalize_hook_result(coro)
        timeout = candidate.spec.timeout
        try:
            out = await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=[f"hook timeout after {timeout:.1f}s"],
            )
        return normalize_hook_result(out)


class HookEngine:
    """统一调度器（P1 顺序执行）。"""

    def __init__(
        self,
        snapshot: HooksConfigSnapshot,
        *,
        event_emitter: HookEventEmitter | None = None,
        trust_checker: WorkspaceTrustChecker | None = None,
    ) -> None:
        self._snapshot = snapshot
        self._function_executor = FunctionExecutor()
        self._callback_executor = CallbackExecutor()
        self._command_executor = CommandExecutor()
        self._http_executor = HttpExecutor()
        self._prompt_executor = PromptExecutor()
        self._agent_executor = AgentExecutor()
        self._event_emitter = event_emitter
        self._trust_checker = trust_checker

    async def execute(self, ctx: HookContext) -> AggregatedHookResult:
        batch_started_at = time.perf_counter()
        candidates, skipped = self._snapshot.get_candidates_with_decisions(ctx)
        self._emit_skipped_records(ctx, skipped)
        if not candidates:
            return AggregatedHookResult()
        if self._trust_checker is not None:
            candidates = self._filter_trusted_candidates(ctx, candidates)
            if not candidates:
                return AggregatedHookResult()

        result = AggregatedHookResult()
        sequential_candidates = [
            candidate
            for candidate in candidates
            if candidate.spec.executor_type in {"callback", "function"}
        ]
        parallel_candidates = [
            candidate
            for candidate in candidates
            if candidate.spec.executor_type in {"command", "http", "prompt", "agent"}
        ]

        for candidate in sequential_candidates:
            one = await self._run_with_record(candidate, ctx, result)
            self._merge(result, one)

        if parallel_candidates:

            async def _run_parallel(candidate: HookCandidate) -> tuple[HookResult, AggregatedHookResult]:
                local = AggregatedHookResult()
                one = await self._run_with_record(candidate, ctx, local)
                return one, local

            pairs = await asyncio.gather(
                *(_run_parallel(candidate) for candidate in parallel_candidates)
            )
            for one, local in pairs:
                self._merge(result, one)
                result.hook_infos.extend(local.hook_infos)
        result.duration_ms = (time.perf_counter() - batch_started_at) * 1000
        return result

    def _filter_trusted_candidates(
        self,
        ctx: HookContext,
        candidates: list[HookCandidate],
    ) -> list[HookCandidate]:
        trusted: list[HookCandidate] = []
        for candidate in candidates:
            executor_type = candidate.spec.executor_type
            if self._trust_checker is not None and self._trust_checker.should_skip(executor_type):
                self._emit_trust_skipped_record(ctx, candidate)
                continue
            trusted.append(candidate)
        return trusted

    async def _run_with_record(
        self,
        candidate: HookCandidate,
        ctx: HookContext,
        agg: AggregatedHookResult,
    ) -> HookResult:
        hook_name = str(candidate.spec.config.get("name") or candidate.spec.hook_id)
        if self._event_emitter is not None:
            self._event_emitter.emit_progress(
                {
                    "hook_id": candidate.spec.hook_id,
                    "hook_name": hook_name,
                    "hook_event": ctx.event.value,
                    "tool_call_id": ctx.tool_call_id,
                    "session_id": ctx.session_id,
                    "node_level": False,
                    "phase": "running",
                }
            )
        started_at = time.perf_counter()
        one = await self._run_one(candidate, ctx)
        duration_ms = (time.perf_counter() - started_at) * 1000
        outcome = self._emit_execution_record(ctx, candidate, one, duration_ms)
        info = build_hook_info(
            hook_id=candidate.spec.hook_id,
            hook_event=ctx.event.value,
            config=candidate.spec.config,
            outcome=outcome,  # type: ignore[arg-type]
            duration_ms=duration_ms,
            stdout=one.stdout,
            stderr=one.stderr,
            exit_code=one.exit_code,
            prevent_continuation=one.prevent_continuation,
            blocking_errors=list(one.blocking_errors) or None,
            tool_call_id=ctx.tool_call_id,
        )
        agg.hook_infos.append(info)
        agg.duration_ms += duration_ms
        if self._event_emitter is not None:
            self._event_emitter.emit_response(
                {
                    **info,
                    "combined_stdout": one.stdout,
                    "combined_stderr": one.stderr,
                    "node_level": False,
                    "phase": "finished",
                    "session_id": ctx.session_id,
                }
            )
        if outcome == "success" and candidate.spec.on_success is not None:
            candidate.spec.on_success()
        return one

    async def _run_one(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        et = candidate.spec.executor_type
        if et == "function":
            return await self._function_executor.run(candidate, ctx)
        if et == "callback":
            return await self._callback_executor.run(candidate, ctx)
        if et == "command":
            return await self._command_executor.run(candidate, ctx)
        if et == "http":
            return await self._http_executor.run(candidate, ctx)
        if et == "prompt":
            return await self._prompt_executor.run(candidate, ctx)
        if et == "agent":
            return await self._agent_executor.run(candidate, ctx)
        return HookResult(
            outcome="non_blocking_error",
            blocking_errors=[f"unsupported executor in P1: {et}"],
        )

    @staticmethod
    def _merge(agg: AggregatedHookResult, one: HookResult) -> None:
        if one.prevent_continuation:
            agg.prevent_continuation = True
        if one.blocking_errors:
            agg.blocking_errors.extend(one.blocking_errors)
        if one.additional_context:
            agg.additional_contexts.append(one.additional_context)
        if one.updated_input is not None:
            agg.updated_input = dict(one.updated_input)
        if one.state_patch:
            agg.state_patch.update(one.state_patch)

        # 聚合 Hook 输出结果（stdout/stderr/exit_code）
        if one.stdout is not None:
            agg.stdouts.append(one.stdout)
            agg.combined_stdout += one.stdout
        if one.stderr is not None:
            agg.stderrs.append(one.stderr)
            agg.combined_stderr += one.stderr
        if one.exit_code is not None:
            agg.exit_codes.append(one.exit_code)

        agg.permission_behavior = merge_permission_behavior(
            agg.permission_behavior,
            one.permission_behavior,
        )
        if one.hook_permission_decision_reason:
            agg.hook_permission_decision_reason = one.hook_permission_decision_reason

    def _emit_skipped_records(
        self,
        ctx: HookContext,
        skipped: list[HookCandidateDecision],
    ) -> None:
        for decision in skipped:
            record = HookExecutionRecord(
                hook_id=decision.spec.hook_id,
                hook_event=ctx.event.value,
                hook_source=decision.spec.source,
                matcher=decision.spec.matcher,
                matched=decision.matched,
                skip_reason=decision.skip_reason,
                snapshot_id=self._snapshot.snapshot_id,
                policy_source=self._snapshot.policy_source,
                outcome="cancelled",
                prevent_continuation=False,
                duration_ms=0.0,
            )
            self._try_emit_record(ctx.session_id, record)

    def _emit_execution_record(
        self,
        ctx: HookContext,
        candidate: HookCandidate,
        result: HookResult,
        duration_ms: float,
    ) -> str:
        outcome = result.outcome
        if result.prevent_continuation or result.blocking_errors:
            outcome = "blocking"
        record = HookExecutionRecord(
            hook_id=candidate.spec.hook_id,
            hook_event=ctx.event.value,
            hook_source=candidate.spec.source,
            matcher=candidate.spec.matcher,
            matched=True,
            skip_reason=None,
            snapshot_id=self._snapshot.snapshot_id,
            policy_source=self._snapshot.policy_source,
            outcome=outcome,
            prevent_continuation=result.prevent_continuation,
            duration_ms=duration_ms,
            tool_call_id=ctx.tool_call_id,
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
        )
        self._try_emit_record(ctx.session_id, record)
        return outcome

    def _emit_trust_skipped_record(
        self,
        ctx: HookContext,
        candidate: HookCandidate,
    ) -> None:
        reason = (
            self._trust_checker.skip_reason(candidate.spec.executor_type)
            if self._trust_checker is not None
            else "trust_check_skipped"
        )
        record = HookExecutionRecord(
            hook_id=candidate.spec.hook_id,
            hook_event=ctx.event.value,
            hook_source=candidate.spec.source,
            matcher=candidate.spec.matcher,
            matched=True,
            skip_reason=reason,
            snapshot_id=self._snapshot.snapshot_id,
            policy_source=self._snapshot.policy_source,
            outcome="trust_skipped",
            prevent_continuation=False,
            duration_ms=0.0,
        )
        self._try_emit_record(ctx.session_id, record)

    def _try_emit_record(self, session_id: str | None, record: HookExecutionRecord) -> None:
        if self._event_emitter is None or not session_id:
            return
        if not self._event_emitter.collector.has_session(session_id):
            return
        try:
            self._event_emitter.emit_record(session_id, record)
        except Exception as exc:
            # 发射失败不应阻断主链路
            logger.debug("hook event emit failed (non-blocking): %s", exc)
            return


def normalize_hook_result(value: Any) -> HookResult:
    """兼容 dict/HookResult 返回值。"""
    if value is None:
        return HookResult()
    if isinstance(value, HookResult):
        return value
    if isinstance(value, dict):
        kwargs = dict(value)
        # 文档约定别名
        if "preventContinuation" in kwargs and "prevent_continuation" not in kwargs:
            kwargs["prevent_continuation"] = kwargs.pop("preventContinuation")
        if "updatedInput" in kwargs and "updated_input" not in kwargs:
            kwargs["updated_input"] = kwargs.pop("updatedInput")
        if "permissionBehavior" in kwargs and "permission_behavior" not in kwargs:
            kwargs["permission_behavior"] = kwargs.pop("permissionBehavior")
        return HookResult(**kwargs)
    raise TypeError(f"Unsupported hook result type: {type(value).__name__}")


def merge_permission_behavior(
    current: PermissionBehavior | None,
    incoming: PermissionBehavior | None,
) -> PermissionBehavior | None:
    """deny > ask > allow > passthrough(None effect)."""
    if incoming is None or incoming == "passthrough":
        return current
    if incoming == "deny":
        return "deny"
    if incoming == "ask":
        return "ask" if current != "deny" else "deny"
    if incoming == "allow":
        return current or "allow"
    return current


__all__ = [
    "CallbackExecutor",
    "FunctionExecutor",
    "HookEngine",
    "merge_permission_behavior",
    "normalize_hook_result",
]
