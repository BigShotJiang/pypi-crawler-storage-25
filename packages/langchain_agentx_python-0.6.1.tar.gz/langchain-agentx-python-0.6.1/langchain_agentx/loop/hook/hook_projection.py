"""
hook_projection.py — Hook 结果到 LangchainAgent 事件的 SDK 侧投影（对齐 CC attachment / hook_response）。

职责：
    集中推导 outcome、attachment_type，并将 AggregatedHookResult / 单 hook 执行信息转为事件 data dict。

链路位置：
    graph_wiring、graph_edges、HookEventEmitter、langchain_agentx_event_adapter 共用。

当前裁剪范围：
    仅结构化投影；不做 CLI 展示决策。
"""

from __future__ import annotations

from typing import Any

from .types import AggregatedHookResult, HookOutcome

AttachmentType = str

ATTACHMENT_HOOK_SUCCESS = "hook_success"
ATTACHMENT_HOOK_BLOCKING_ERROR = "hook_blocking_error"
ATTACHMENT_HOOK_NON_BLOCKING_ERROR = "hook_non_blocking_error"
ATTACHMENT_HOOK_STOPPED_CONTINUATION = "hook_stopped_continuation"
ATTACHMENT_HOOK_CANCELLED = "hook_cancelled"


def derive_hook_outcome(result: AggregatedHookResult) -> HookOutcome:
    """从聚合结果推导 outcome（与 HookEngine._emit_execution_record 语义对齐）。"""
    if result.prevent_continuation or result.blocking_errors:
        return "blocking"
    if any(code != 0 for code in result.exit_codes):
        return "non_blocking_error"
    return "success"


def derive_attachment_type(
    result: AggregatedHookResult,
    outcome: HookOutcome | None = None,
) -> AttachmentType:
    """推导 CC 风格 attachment_type（CLI 仅据此选控件）。"""
    resolved = outcome or derive_hook_outcome(result)
    if result.prevent_continuation and not result.blocking_errors:
        return ATTACHMENT_HOOK_STOPPED_CONTINUATION
    if resolved == "blocking" or result.blocking_errors:
        return ATTACHMENT_HOOK_BLOCKING_ERROR
    if resolved == "non_blocking_error":
        return ATTACHMENT_HOOK_NON_BLOCKING_ERROR
    if resolved == "cancelled":
        return ATTACHMENT_HOOK_CANCELLED
    return ATTACHMENT_HOOK_SUCCESS


def hook_display_name(hook_id: str, hook_event: str, config: dict[str, Any]) -> str:
    """对齐 CC ``hookEvent:matcher`` 展示名（config.name 优先）。"""
    name = config.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    return hook_id or hook_event


def derive_attachment_type_for_hook(
    *,
    outcome: HookOutcome,
    prevent_continuation: bool = False,
    blocking_errors: list[str] | None = None,
    exit_codes: list[int] | None = None,
) -> AttachmentType:
    """单条 hook 的 attachment_type（避免为 build_hook_info 构造假 AggregatedHookResult）。"""
    blocking = list(blocking_errors or [])
    if prevent_continuation and not blocking:
        return ATTACHMENT_HOOK_STOPPED_CONTINUATION
    if outcome == "blocking" or blocking:
        return ATTACHMENT_HOOK_BLOCKING_ERROR
    if outcome == "non_blocking_error" or any(
        code != 0 for code in (exit_codes or [])
    ):
        return ATTACHMENT_HOOK_NON_BLOCKING_ERROR
    if outcome == "cancelled":
        return ATTACHMENT_HOOK_CANCELLED
    return ATTACHMENT_HOOK_SUCCESS


def build_hook_info(
    *,
    hook_id: str,
    hook_event: str,
    config: dict[str, Any],
    outcome: HookOutcome,
    duration_ms: float,
    stdout: str | None = None,
    stderr: str | None = None,
    exit_code: int | None = None,
    prevent_continuation: bool = False,
    blocking_errors: list[str] | None = None,
    tool_call_id: str | None = None,
) -> dict[str, Any]:
    """单条 hook 执行明细（STOP 批次 summary / hook_infos[]）。"""
    return {
        "hook_id": hook_id,
        "hook_name": hook_display_name(hook_id, hook_event, config),
        "hook_event": hook_event,
        "outcome": outcome,
        "duration_ms": duration_ms,
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "prevent_continuation": prevent_continuation,
        "blocking_errors": list(blocking_errors) if blocking_errors else None,
        "tool_call_id": tool_call_id,
        "attachment_type": derive_attachment_type_for_hook(
            outcome=outcome,
            prevent_continuation=prevent_continuation,
            blocking_errors=blocking_errors,
            exit_codes=[exit_code] if exit_code is not None else None,
        ),
    }


def hook_result_to_event_dict(
    result: AggregatedHookResult,
    *,
    tool_call_id: str | None = None,
) -> dict[str, Any]:
    """将 AggregatedHookResult 转为 HOOK_FINISHED / 图节点 __hook_result__ 契约。"""
    outcome = derive_hook_outcome(result)
    payload: dict[str, Any] = {
        "outcome": outcome,
        "attachment_type": derive_attachment_type(result, outcome),
        "prevent_continuation": result.prevent_continuation,
        "blocking_errors": list(result.blocking_errors) or None,
        "permission_behavior": result.permission_behavior,
        "hook_permission_decision_reason": result.hook_permission_decision_reason,
        "additional_contexts": list(result.additional_contexts) or None,
        "updated_input": result.updated_input,
        "state_patch": dict(result.state_patch) or None,
        "stdouts": list(result.stdouts) or None,
        "stderrs": list(result.stderrs) or None,
        "exit_codes": list(result.exit_codes) or None,
        "combined_stdout": result.combined_stdout or None,
        "combined_stderr": result.combined_stderr or None,
        "duration_ms": result.duration_ms if result.duration_ms > 0 else None,
        "hook_infos": list(result.hook_infos) or None,
    }
    if tool_call_id:
        payload["tool_call_id"] = tool_call_id
    return payload


__all__ = [
    "ATTACHMENT_HOOK_BLOCKING_ERROR",
    "ATTACHMENT_HOOK_CANCELLED",
    "ATTACHMENT_HOOK_NON_BLOCKING_ERROR",
    "ATTACHMENT_HOOK_STOPPED_CONTINUATION",
    "ATTACHMENT_HOOK_SUCCESS",
    "AttachmentType",
    "build_hook_info",
    "derive_attachment_type",
    "derive_attachment_type_for_hook",
    "derive_hook_outcome",
    "hook_display_name",
    "hook_result_to_event_dict",
]
