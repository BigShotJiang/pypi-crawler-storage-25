"""agent_loop_config.py — Agent Loop 不变配置（构建时确定）

职责：
    以强类型 dataclass 承载与 LangGraph 迭代轮次无关的不变配置；目标态下写入
    `config["configurable"]["loop_config"]`，不进入 LangGraph state。

在整体链路中的位置：
    create_loop_agent（及子代理派生）组装本对象并注入 configurable；工具层
   （如 adapter → ToolExecutionContext）从 configurable 读取模型与权限等控制面，
    替代从 state 猜测 `__loop_model__` 等临时字段。

CC 对照：
    语义上对齐 CC 的 QueryParams（不变入参）与 toolUseContext.options（控制面）
    的组合：控制面不进 queryLoop State，而通过独立上下文传递。

当前裁剪范围：
    仅提供 `AgentLoopConfig` 数据结构；与 `LoopRuntimeContext` 合并、工厂派生、
    factory/adapter 接线在后续步骤完成。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from langchain_agentx.provider.model_profile import ModelProfile, ModelProfileRegistry


@dataclass
class AgentLoopConfig:
    """Agent Loop 构建时确定的不变配置。

    父子代理共用同一类型：RuntimeContextFactory.derive() 返回子代理的 AgentLoopConfig。
    CC 对照：QueryParams（不变入参）+ toolUseContext.options（控制面）。
    """

    # 模型控制面
    model: Any  # BaseChatModel 或 provider-qualified 字符串
    fallback_model: Any | None = None

    # 执行限制
    max_steps: int | None = None
    max_turns: int | None = None
    max_withhold_retries: int = 1
    token_budget_max_continuations: int = 3
    managed_rules: str | None = None

    # 工具与权限
    available_tools: list[Any] = field(default_factory=list)
    # 为 False 时禁止需要外网的工具（如 WebSearch）；只读/离线模式由宿主设置。
    network_access_allowed: bool = True
    permission_mode: str = "default"
    permission_resolver: Any | None = None  # 弃用中：见 prompt_handler / LegacyResolverPromptHandler
    prompt_handler: Any | None = None  # L3 PermissionPromptHandler
    workspace_root: str | None = None  # 工具层 workspace 根路径，权限检查边界
    agent_home: str = ".langchain_agentx"  # Agent 家目录（skills/worktrees/tasks 派生根）
    cwd: str | None = None  # 过渡期保留；路径展开应走 boundary_view.resolve_cwd()
    boundary: Any | None = None  # WorkspaceBoundary frozen 实例
    enable_dynamic_root_grant: bool = False  # workflow 默认关；CLI 入口默认开

    # 会话标识
    session_id: str = ""
    conversation_session_id: str = ""
    agent_id: str | None = None
    parent_agent_id: str | None = None
    agent_depth: int = 0
    subagent_type: str | None = None
    # 观测控制面：主 Agent 打开则子 Agent 默认继承打开
    trace_enabled: bool = True
    headless: bool = False
    # 模型能力配置：显式 profile > registry 匹配 > model metadata > 代码兜底
    model_profile: ModelProfile | None = None
    model_profile_registry: ModelProfileRegistry | None = None
    compact_buffer_tokens: int = 13_000
    max_output_tokens_reserved: int = 20_000


__all__ = ["AgentLoopConfig"]
