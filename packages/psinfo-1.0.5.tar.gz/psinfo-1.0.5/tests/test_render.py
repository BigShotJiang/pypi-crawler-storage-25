import io
import pytest
from rich.console import Console
from rich.panel import Panel


def make_proc(cpu=0.5, mem=2.1, rss_mb=168.0, name="mysqld", pid=1234,
              cmdline=None, username="mysql", num_threads=32, num_fds=48,
              create_time=1000000.0):
    if cmdline is None:
        cmdline = ["/usr/sbin/mysqld", "--datadir=/var/lib/mysql"]
    from psinfo import ProcessInfo
    return ProcessInfo(
        pid=pid, name=name, cmdline=cmdline, username=username,
        cpu_percent=cpu, mem_percent=mem, rss_mb=rss_mb,
        num_threads=num_threads, create_time=create_time, num_fds=num_fds,
    )


def render_to_str(renderable) -> str:
    buf = io.StringIO()
    console = Console(file=buf, width=100, highlight=False, markup=False)
    console.print(renderable)
    return buf.getvalue()


def test_render_card_returns_panel():
    from psinfo import render_card
    proc = make_proc()
    card = render_card(proc)
    assert isinstance(card, Panel)


def test_render_card_contains_pid():
    from psinfo import render_card
    proc = make_proc(pid=1234)
    output = render_to_str(render_card(proc))
    assert "1234" in output


def test_render_card_contains_process_name():
    from psinfo import render_card
    proc = make_proc(name="mysqld")
    output = render_to_str(render_card(proc))
    assert "mysqld" in output


def test_render_card_contains_username():
    from psinfo import render_card
    proc = make_proc(username="mysql")
    output = render_to_str(render_card(proc))
    assert "mysql" in output


def test_render_card_contains_rss():
    from psinfo import render_card
    proc = make_proc(rss_mb=168.0)
    output = render_to_str(render_card(proc))
    assert "168" in output


def test_render_card_contains_thread_count():
    from psinfo import render_card
    proc = make_proc(num_threads=32)
    output = render_to_str(render_card(proc))
    assert "32" in output


def test_metric_color_green_below_10():
    from psinfo import _metric_color
    assert _metric_color(5.0) == "green"


def test_metric_color_orange_between_10_and_50():
    from psinfo import _metric_color
    assert _metric_color(25.0) == "dark_orange"


def test_metric_color_red_above_50():
    from psinfo import _metric_color
    assert _metric_color(75.0) == "red"


def test_render_card_contains_cpu():
    from psinfo import render_card
    proc = make_proc(cpu=42.5)
    output = render_to_str(render_card(proc))
    assert "42.5" in output


def test_render_card_contains_mem():
    from psinfo import render_card
    proc = make_proc(mem=3.7)
    output = render_to_str(render_card(proc))
    assert "3.7" in output


def test_render_card_contains_fd_count():
    from psinfo import render_card
    proc = make_proc(num_fds=99)
    output = render_to_str(render_card(proc))
    assert "99" in output


def test_render_card_contains_command():
    from psinfo import render_card
    proc = make_proc(cmdline=["/usr/sbin/mysqld", "--datadir=/var/lib/mysql"])
    output = render_to_str(render_card(proc))
    assert "/usr/sbin/mysqld" in output


def test_render_card_uses_primary_color_border():
    from psinfo import render_card
    from rich.panel import Panel
    from rich.text import Text
    proc = make_proc(name="mysqld")
    card = render_card(proc)
    assert card.border_style in ("green", "dark_orange", "red")


def test_metric_color_at_warn_boundary():
    from psinfo import _metric_color
    assert _metric_color(10.0) == "dark_orange"  # exactly at warn threshold


def test_metric_color_at_critical_boundary():
    from psinfo import _metric_color
    assert _metric_color(50.0) == "red"  # exactly at critical threshold


def test_render_results_shows_match_count():
    from psinfo import render_results
    procs = [make_proc(pid=1), make_proc(pid=2, name="mysqld_safe")]
    output = render_to_str(render_results(procs, "mysql"))
    assert "2" in output
    assert "mysql" in output


def test_render_results_shows_no_processes_when_empty():
    from psinfo import render_results
    output = render_to_str(render_results([], "mysql"))
    assert "No processes found" in output


def test_sort_procs_by_cpu_descending():
    from psinfo import sort_procs
    procs = [make_proc(cpu=1.0, pid=1), make_proc(cpu=5.0, pid=2), make_proc(cpu=0.5, pid=3)]
    result = sort_procs(procs, "cpu")
    assert result[0].cpu_percent == 5.0
    assert result[-1].cpu_percent == 0.5


def test_sort_procs_by_mem_descending():
    from psinfo import sort_procs
    procs = [make_proc(mem=1.0, pid=1), make_proc(mem=5.0, pid=2)]
    result = sort_procs(procs, "mem")
    assert result[0].mem_percent == 5.0


def test_sort_procs_by_pid_ascending():
    from psinfo import sort_procs
    procs = [make_proc(pid=300), make_proc(pid=100), make_proc(pid=200)]
    result = sort_procs(procs, "cpu")
    assert result[0].cpu_percent == 0.5


def test_render_results_highlights_highest_cpu():
    from psinfo import render_results
    high = make_proc(pid=1, cpu=50.0, name="high_cpu")
    low = make_proc(pid=2, cpu=1.0, name="low_cpu")
    output = render_to_str(render_results([high, low], "test"))
    assert "high_cpu" in output
    assert "low_cpu" in output
