from unittest.mock import MagicMock
import pytest


def make_mock_proc(
    pid=1234,
    name="mysqld",
    cmdline=None,
    username="mysql",
    cpu_percent=0.5,
    memory_percent=2.1,
    rss=176160768,  # bytes → 168 MB
    num_threads=32,
    create_time=1000000.0,
    num_fds=48,
):
    if cmdline is None:
        cmdline = ["/usr/sbin/mysqld", "--datadir=/var/lib/mysql"]
    proc = MagicMock()
    mem_info = MagicMock()
    mem_info.rss = rss
    proc.info = {
        "pid": pid,
        "name": name,
        "cmdline": cmdline,
        "username": username,
        "cpu_percent": cpu_percent,
        "memory_percent": memory_percent,
        "memory_info": mem_info,
        "num_threads": num_threads,
        "create_time": create_time,
        "num_fds": num_fds,
    }
    proc.as_dict.return_value = dict(proc.info)
    return proc


def test_process_info_fields():
    from psinfo import ProcessInfo
    p = ProcessInfo(
        pid=1234,
        name="mysqld",
        cmdline=["/usr/sbin/mysqld", "--datadir=/var/lib/mysql"],
        username="mysql",
        cpu_percent=0.5,
        mem_percent=2.1,
        rss_mb=168.0,
        num_threads=32,
        create_time=1000000.0,
        num_fds=48,
    )
    assert p.pid == 1234
    assert p.name == "mysqld"
    assert p.rss_mb == 168.0


def test_command_joins_cmdline():
    from psinfo import ProcessInfo
    p = ProcessInfo(
        pid=1, name="mysqld",
        cmdline=["/usr/sbin/mysqld", "--datadir=/var/lib/mysql"],
        username="mysql", cpu_percent=0.0, mem_percent=0.0,
        rss_mb=0.0, num_threads=1, create_time=1000000.0, num_fds=0,
    )
    assert p.command == "/usr/sbin/mysqld --datadir=/var/lib/mysql"


def test_command_falls_back_to_name_when_no_cmdline():
    from psinfo import ProcessInfo
    p = ProcessInfo(
        pid=1, name="kernel_task", cmdline=[],
        username="root", cpu_percent=0.0, mem_percent=0.0,
        rss_mb=0.0, num_threads=1, create_time=1000000.0, num_fds=0,
    )
    assert p.command == "kernel_task"


def test_proc_to_info_converts_mock():
    from psinfo import _proc_to_info
    mock = make_mock_proc()
    result = _proc_to_info(mock)
    assert result is not None
    assert result.pid == 1234
    assert result.name == "mysqld"
    assert abs(result.rss_mb - 168.0) < 1.0
    assert result.num_threads == 32


def test_proc_to_info_returns_none_on_no_such_process():
    import psutil
    from psinfo import _proc_to_info
    mock = MagicMock()
    mock.as_dict.side_effect = psutil.NoSuchProcess(pid=9999)
    assert _proc_to_info(mock) is None


def test_proc_to_info_returns_none_on_access_denied():
    import psutil
    from psinfo import _proc_to_info
    mock = MagicMock()
    mock.as_dict.side_effect = psutil.AccessDenied(pid=1)
    assert _proc_to_info(mock) is None


def test_find_by_name_matches_name_field(mocker):
    from psinfo import find_by_name
    mock_mysql = make_mock_proc(name="mysqld", cmdline=["/usr/sbin/mysqld"])
    mock_other = make_mock_proc(pid=9999, name="nginx", cmdline=["/usr/sbin/nginx"])
    mocker.patch("psutil.process_iter", return_value=[mock_mysql, mock_other])
    results = find_by_name("mysql")
    assert len(results) == 1
    assert results[0].name == "mysqld"


def test_find_by_name_matches_cmdline(mocker):
    from psinfo import find_by_name
    mock = make_mock_proc(name="python3", cmdline=["python3", "manage.py", "runserver"])
    mocker.patch("psutil.process_iter", return_value=[mock])
    results = find_by_name("manage")
    assert len(results) == 1


def test_find_by_name_is_case_insensitive(mocker):
    from psinfo import find_by_name
    mock = make_mock_proc(name="MySQLd")
    mocker.patch("psutil.process_iter", return_value=[mock])
    results = find_by_name("mysql")
    assert len(results) == 1


def test_find_by_name_returns_empty_when_no_match(mocker):
    from psinfo import find_by_name
    mock = make_mock_proc(name="nginx", cmdline=["/usr/sbin/nginx"])
    mocker.patch("psutil.process_iter", return_value=[mock])
    results = find_by_name("mysql")
    assert results == []


def test_find_by_name_skips_inaccessible_processes(mocker):
    import psutil
    from psinfo import find_by_name
    bad_proc = MagicMock()
    bad_proc.info = MagicMock()
    bad_proc.info.get = MagicMock(side_effect=psutil.AccessDenied(pid=1))
    good = make_mock_proc(name="mysqld")
    mocker.patch("psutil.process_iter", return_value=[bad_proc, good])
    results = find_by_name("mysql")
    assert len(results) == 1


def test_find_by_user_filters_by_username(mocker):
    from psinfo import find_by_user
    mysql_proc = make_mock_proc(pid=1234, name="mysqld", username="mysql")
    root_proc = make_mock_proc(pid=1235, name="sshd", username="root")
    mocker.patch("psutil.process_iter", return_value=[mysql_proc, root_proc])
    results = find_by_user("mysql")
    assert len(results) == 1
    assert results[0].username == "mysql"


def test_find_by_user_is_case_insensitive(mocker):
    from psinfo import find_by_user
    proc = make_mock_proc(username="MySQL")
    mocker.patch("psutil.process_iter", return_value=[proc])
    results = find_by_user("mysql")
    assert len(results) == 1


def test_find_by_pid_returns_process(mocker):
    from psinfo import find_by_pid
    mock = make_mock_proc(pid=1234)
    mocker.patch("psutil.Process", return_value=mock)
    result = find_by_pid(1234)
    assert result is not None
    assert result.pid == 1234


def test_find_by_pid_returns_none_when_not_found(mocker):
    import psutil
    from psinfo import find_by_pid
    mocker.patch("psutil.Process", side_effect=psutil.NoSuchProcess(pid=9999))
    assert find_by_pid(9999) is None


def test_find_by_port_returns_process_owning_port(mocker):
    from psinfo import find_by_port
    conn = MagicMock()
    conn.laddr.port = 3306
    conn.pid = 1234
    mocker.patch("psutil.net_connections", return_value=[conn])
    mock_proc = make_mock_proc(pid=1234, name="mysqld")
    mocker.patch("psutil.Process", return_value=mock_proc)
    result = find_by_port(3306)
    assert result is not None
    assert result.pid == 1234


def test_find_by_port_returns_none_when_port_not_in_use(mocker):
    from psinfo import find_by_port
    conn = MagicMock()
    conn.laddr.port = 8080
    conn.pid = 999
    mocker.patch("psutil.net_connections", return_value=[conn])
    result = find_by_port(3306)
    assert result is None


def test_find_by_port_returns_none_on_access_denied(mocker):
    import psutil
    from psinfo import find_by_port
    mocker.patch("psutil.net_connections", side_effect=psutil.AccessDenied(pid=0))
    with pytest.raises(psutil.AccessDenied):
        find_by_port(3306)


def test_find_by_pid_returns_none_on_access_denied(mocker):
    import psutil
    from psinfo import find_by_pid
    mocker.patch("psutil.Process", side_effect=psutil.AccessDenied(pid=1))
    assert find_by_pid(1) is None


def test_find_by_port_prefers_listen_state(mocker):
    from psinfo import find_by_port
    listen_conn = MagicMock()
    listen_conn.laddr.port = 3306
    listen_conn.pid = 1234
    listen_conn.status = "LISTEN"
    estab_conn = MagicMock()
    estab_conn.laddr.port = 3306
    estab_conn.pid = 5678
    estab_conn.status = "ESTABLISHED"
    mocker.patch("psutil.net_connections", return_value=[estab_conn, listen_conn])
    mock_proc = make_mock_proc(pid=1234, name="mysqld")
    mocker.patch("psutil.Process", return_value=mock_proc)
    result = find_by_port(3306)
    assert result is not None
    assert result.pid == 1234  # LISTEN connection preferred over ESTABLISHED


def test_find_by_name_excludes_self(mocker):
    import os
    from psinfo import find_by_name
    self_proc = make_mock_proc(pid=os.getpid(), name="python3",
                               cmdline=["python3", "psinfo", "mysql"])
    other_proc = make_mock_proc(pid=9999, name="mysqld", cmdline=["/usr/sbin/mysqld"])
    mocker.patch("psutil.process_iter", return_value=[self_proc, other_proc])
    results = find_by_name("mysql")
    assert all(r.pid != os.getpid() for r in results)
    assert len(results) == 1
    assert results[0].pid == 9999


def test_find_by_user_excludes_self(mocker):
    import os
    from psinfo import find_by_user
    self_proc = make_mock_proc(pid=os.getpid(), name="python3", username="dan")
    other_proc = make_mock_proc(pid=9999, name="bash", username="dan")
    mocker.patch("psutil.process_iter", return_value=[self_proc, other_proc])
    results = find_by_user("dan")
    assert all(r.pid != os.getpid() for r in results)
    assert len(results) == 1
    assert results[0].pid == 9999
