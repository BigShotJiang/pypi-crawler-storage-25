# psinfo

A rich terminal process viewer. Search, filter, and watch running processes with colour-coded output.

psinfo is for when you have a specific question — *"what's on port 8080"*, *"how much memory is Chrome using across all its helpers"*, *"is nginx running and what's it doing"* — and want a clean answer without launching a full process manager or constructing a `ps aux | grep | awk` pipeline.

---

## Install

```bash
pip install psinfo
```

Or install as an isolated CLI tool with [pipx](https://pypa.github.io/pipx/):

```bash
pipx install psinfo
```

---

## Quick Start

```bash
psinfo nginx              # search by process name
psinfo -u jdoe           # all processes owned by a user
psinfo -p 8080           # process listening on a port
psinfo -P 1234           # single process by PID
```

### Flags

| Flag | Short | Description |
|------|-------|-------------|
| `--watch [N]` | `-w` | Live refresh every N seconds (default: 2) |
| `--sort cpu\|mem` | `-s` | Sort order (default: cpu) |
| `--tree` | `-t` | Group results by process tree hierarchy |

### Examples

```bash
psinfo nginx -w              # watch nginx processes
psinfo python -w 5 -s mem    # watch python, sort by memory, 5s interval
psinfo slack -t -w           # slack with tree view
```

---

## Output

### Card View (default)

Each matching process is shown as a panel. The highest-CPU process gets a green border. Metrics are colour-coded: green (< 10%), orange (≥ 10%), red (≥ 50%).

![Card view](https://raw.githubusercontent.com/dblore/psinfo/main/assets/card-view.svg)

### Tree View (`-t`)

Results are grouped by parent/child relationships. Parent nodes show their own CPU plus a `∑` total across the whole subtree.

![Tree view](https://raw.githubusercontent.com/dblore/psinfo/main/assets/tree-view.svg)

---

## Requirements

- Python 3.9+

---

## Platform Support

| Platform | Status | Notes |
|----------|--------|-------|
| macOS | ✓ | `--port` requires `sudo` |
| Linux | ✓ | |
| Windows | ✓ | Shows handles instead of file descriptors |

---

## License

MIT — see [LICENSE](LICENSE).
