import numpy as np
import torch
from typing import Dict, List, Tuple

class PrioritizedReplayBuffer:
    """
    Prioritized Experience Replay buffer for hard samples.
    """
    def __init__(self, capacity: int, alpha: float = 0.6):
        self.capacity = capacity
        self.alpha = alpha
        
        self.buffer: List[Dict] = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.position = 0
        self.size = 0
        
    def add(self, sample: Dict, priority: float):
        """
        Adds a single sample with given priority.
        Priority is usually the difficulty score.
        """
        max_prio = self.priorities.max() if self.size > 0 else 1.0
        prio = max(priority, max_prio) # Ensure new samples get high priority if no explicit priority provided (or just use provided)
        prio = priority
        
        if self.size < self.capacity:
            self.buffer.append(sample)
        else:
            self.buffer[self.position] = sample
            
        self.priorities[self.position] = prio ** self.alpha
        self.position = (self.position + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)
        
    def sample(self, batch_size: int) -> Tuple[List[Dict], np.ndarray, np.ndarray]:
        """
        Sample a batch of experiences.
        Returns:
            samples: list of dicts
            indices: sampled indices
            weights: importance sampling weights
        """
        if self.size == 0:
            return [], np.array([]), np.array([])
            
        if self.size < batch_size:
            batch_size = self.size
            
        prios = self.priorities[:self.size]
        probs = prios / prios.sum()
        
        indices = np.random.choice(self.size, batch_size, p=probs, replace=False)
        samples = [self.buffer[idx] for idx in indices]
        
        # Importance sampling weights
        weights = (self.size * probs[indices]) ** (-1) # Default beta=1 for simplicity
        weights /= weights.max()
        
        return samples, indices, weights
        
    def update_priorities(self, indices: np.ndarray, priorities: np.ndarray):
        """
        Update priorities of sampled experiences.
        """
        for idx, prio in zip(indices, priorities):
            self.priorities[idx] = prio ** self.alpha
