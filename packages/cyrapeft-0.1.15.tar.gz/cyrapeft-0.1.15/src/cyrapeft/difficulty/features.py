import torch

def assemble_features(per_sample_loss: torch.Tensor, entropy: torch.Tensor, seq_lengths: torch.Tensor, grad_norms: torch.Tensor = None) -> torch.Tensor:
    """
    Assembles extracted signals into a feature tensor for the difficulty model.
    Inputs are all (batch_size,)
    Returns: (batch_size, feature_dim)
    """
    batch_size = per_sample_loss.size(0)
    if grad_norms is None:
        # Dummy grad norms if not provided, or computed externally
        grad_norms = torch.zeros_like(per_sample_loss)
        
    features = torch.stack([
        per_sample_loss,
        entropy,
        seq_lengths.float(),
        grad_norms
    ], dim=1)
    
    # Simple normalization (in practice, might want to track running stats)
    # Avoiding division by zero with eps
    features_mean = features.mean(dim=0, keepdim=True)
    features_std = features.std(dim=0, keepdim=True) + 1e-8
    features = (features - features_mean) / features_std
    
    return features
