import torch
import torch.nn as nn

class DifficultyEstimator(nn.Module):
    """
    MLP that predicts difficulty score from input features.
    Features: [loss, entropy, seq_length, grad_norm]
    Outputs difficulty score in [0, 1] using Sigmoid.
    """
    def __init__(self, input_dim: int = 4, hidden_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )
        
    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        features: (batch_size, input_dim)
        Returns: (batch_size,) difficulty scores
        """
        return self.net(features).squeeze(-1)
