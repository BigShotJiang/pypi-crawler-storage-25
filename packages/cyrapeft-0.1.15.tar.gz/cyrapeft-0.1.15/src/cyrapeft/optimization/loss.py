import torch

class WeightedLoss:
    """
    Computes the correct difficulty-weighted loss.
    """
    @staticmethod
    def compute(per_sample_loss: torch.Tensor, difficulties: torch.Tensor) -> torch.Tensor:
        """
        per_sample_loss: (batch_size,) true loss per sample
        difficulties: (batch_size,) difficulty scores in [0, 1]
        
        Returns a scalar loss for backpropagation.
        """
        # We want to weight the loss based on difficulty
        # Higher difficulty -> higher weight. Add eps to avoid zero weights.
        weights = difficulties / (difficulties.sum() + 1e-8)
        
        # Multiply by batch_size to maintain scale comparable to mean loss
        batch_size = per_sample_loss.size(0)
        weights = weights * batch_size
        
        weighted_loss = (per_sample_loss * weights.detach()).mean()
        return weighted_loss
