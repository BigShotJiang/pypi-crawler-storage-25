import torch
import numpy as np
from typing import Dict, List, Optional
from ..config.config import CyraConfig

class SwarmParticle:
    """
    A single particle in the hyperparameter swarm.
    Tracks its own position (hyperparameters), velocity, and best performance.
    """
    def __init__(self, bounds: Dict[str, tuple]):
        self.bounds = bounds
        # Current position (randomly initialized within bounds)
        self.position = {
            k: np.random.uniform(low, high) for k, (low, high) in bounds.items()
        }
        # Velocity
        self.velocity = {
            k: np.random.uniform(-0.1, 0.1) * (high - low) for k, (low, high) in bounds.items()
        }
        self.best_position = self.position.copy()
        self.best_score = float('inf')  # Lower is better (usually loss)

    def update_velocity(self, global_best_pos: Dict[str, float], w=0.5, c1=0.8, c2=0.9):
        """Update particle velocity based on personal and global bests."""
        for k in self.position.keys():
            r1, r2 = np.random.rand(), np.random.rand()
            cognitive = c1 * r1 * (self.best_position[k] - self.position[k])
            social = c2 * r2 * (global_best_pos[k] - self.position[k])
            self.velocity[k] = w * self.velocity[k] + cognitive + social

    def update_position(self):
        """Update position and clamp to bounds."""
        for k, (low, high) in self.bounds.items():
            self.position[k] += self.velocity[k]
            self.position[k] = np.clip(self.position[k], low, high)

class SwarmOptimizer:
    """
    Zero-Overhead Particle Swarm Optimization for live hyperparameter tuning.
    Instead of running parallel trainings (expensive), it uses 'Virtual Particles'
    to nudge the main training parameters toward optimal zones every N steps.
    """
    def __init__(self, num_particles: int = 5):
        # Define bounds for the parameters we want to tune
        self.bounds = {
            "learning_rate": (1e-6, 1e-4),
            "kp": (0.01, 0.5),
            "ki": (0.001, 0.1),
            "kd": (0.01, 0.2)
        }
        self.particles = [SwarmParticle(self.bounds) for _ in range(num_particles)]
        self.global_best_position = self.particles[0].position.copy()
        self.global_best_score = float('inf')
        
        # Meta-params for the swarm
        self.w = 0.5  # Inertia
        self.c1 = 0.8 # Cognitive weight
        self.c2 = 0.9 # Social weight

    def step(self, current_loss: float) -> Dict[str, float]:
        """
        Advances the swarm. 
        Returns the 'Global Best' parameters to be applied to the trainer.
        """
        # We treat the current training performance as a signal for all particles 
        # to converge toward better regions.
        for p in self.particles:
            if current_loss < p.best_score:
                p.best_score = current_loss
                p.best_position = p.position.copy()
            
            if current_loss < self.global_best_score:
                self.global_best_score = current_loss
                self.global_best_position = p.position.copy()

        # Update swarm state
        for p in self.particles:
            p.update_velocity(self.global_best_position, self.w, self.c1, self.c2)
            p.update_position()
            
        return self.global_best_position
