import yaml
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class DifficultyConfig:
    enabled: bool = True
    hidden_dim: int = 64
    learning_rate: float = 1e-3

@dataclass
class ControllerConfig:
    enabled: bool = True
    kp: float = 0.1
    ki: float = 0.01
    kd: float = 0.05
    target_difficulty: float = 0.5
    alpha_min: float = 1.0
    alpha_max: float = 128.0

@dataclass
class ReplayBufferConfig:
    enabled: bool = True
    capacity: int = 10000
    alpha: float = 0.6  # Priority exponent

@dataclass
class SwarmConfig:
    enabled: bool = False
    num_particles: int = 5
    update_interval: int = 100  # steps between swarm updates

@dataclass
class CyraConfig:
    model_name: str = "gpt2"
    lora_r: int = 8
    lora_alpha_init: float = 32.0
    lora_dropout: float = 0.1
    batch_size: int = 4
    learning_rate: float = 5e-5
    epochs: int = 3
    gradient_checkpointing: bool = False
    
    difficulty: DifficultyConfig = field(default_factory=DifficultyConfig)
    controller: ControllerConfig = field(default_factory=ControllerConfig)
    memory: ReplayBufferConfig = field(default_factory=ReplayBufferConfig)
    swarm: SwarmConfig = field(default_factory=SwarmConfig)

    @classmethod
    def from_yaml(cls, path: str):
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
            
        diff_cfg = DifficultyConfig(**data.get('difficulty', {}))
        ctrl_cfg = ControllerConfig(**data.get('controller', {}))
        mem_cfg = ReplayBufferConfig(**data.get('memory', {}))
        
        main_cfg = {k: v for k, v in data.items() if k not in ['difficulty', 'controller', 'memory']}
        return cls(**main_cfg, difficulty=diff_cfg, controller=ctrl_cfg, memory=mem_cfg)
