from typing import Dict, Any
import numpy as np

class MetricsTracker:
    """
    Tracks and aggregates metrics during training.
    """
    def __init__(self):
        self.history: Dict[str, list] = {
            "train_loss": [],
            "val_loss": [],
            "perplexity": [],
            "alpha": [],
            "mean_difficulty": [],
            "step": []
        }
        
    def update(self, metrics: Dict[str, float]):
        for k, v in metrics.items():
            if k not in self.history:
                self.history[k] = []
            self.history[k].append(v)
            
    def get_last(self, metric: str) -> float:
        if self.history.get(metric):
            return self.history[metric][-1]
        return 0.0

    def compute_perplexity(self, loss: float) -> float:
        try:
            return np.exp(loss)
        except OverflowError:
            return float('inf')
