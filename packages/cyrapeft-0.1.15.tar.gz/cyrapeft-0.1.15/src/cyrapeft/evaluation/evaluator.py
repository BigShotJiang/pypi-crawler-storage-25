from .metrics import MetricsTracker

class Evaluator:
    """
    Dedicated evaluation logic can be placed here to decouple from Trainer.
    Useful for generation testing and external benchmarks.
    """
    def __init__(self, model, dataloader, device):
        self.model = model
        self.dataloader = dataloader
        self.device = device
        
    def evaluate(self):
        # Additional evaluation tasks like Rouge, BLEU, or specific downstream tasks
        pass
