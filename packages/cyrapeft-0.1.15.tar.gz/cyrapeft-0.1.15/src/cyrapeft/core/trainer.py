import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Optional, Dict, Any, Callable
from tqdm import tqdm

from cyrapeft.config.config import CyraConfig
from cyrapeft.core.model import AdaptiveLoRAModel
from cyrapeft.controller.controller import AlphaController
from cyrapeft.controller.pid_controller import PIDController
from cyrapeft.difficulty.difficulty_model import DifficultyEstimator
from cyrapeft.difficulty.features import assemble_features
from cyrapeft.signals.extractor import SignalExtractor
from cyrapeft.memory.replay_buffer import PrioritizedReplayBuffer
from cyrapeft.optimization.loss import WeightedLoss
from cyrapeft.evaluation.metrics import MetricsTracker
from cyrapeft.utils.logging import logger

class CyraTrainer:
    """
    Core training loop implementing Adaptive LoRA with Control Systems.
    """
    def __init__(
        self, 
        model: AdaptiveLoRAModel,
        config: CyraConfig,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
        device: torch.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
        use_ray: bool = False
    ):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.use_ray = use_ray
        
        self.model.to(self.device)
        
        # Difficulty Model
        self.difficulty_model = DifficultyEstimator(input_dim=4, hidden_dim=config.difficulty.hidden_dim).to(self.device)
        
        self.controller = PIDController(
            kp=config.controller.kp,
            ki=config.controller.ki,
            kd=config.controller.kd,
            target=config.controller.target_difficulty,
            min_val=config.controller.alpha_min,
            max_val=config.controller.alpha_max
        )
        
        # 4. Swarm Optimizer (Meta-Heuristic Tuning)
        self.swarm = None
        if config.swarm.enabled:
            from ..optimization.swarm import SwarmOptimizer
            self.swarm = SwarmOptimizer(num_particles=config.swarm.num_particles)
        
        # Optimizers
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=config.learning_rate)
        self.difficulty_optimizer = torch.optim.Adam(self.difficulty_model.parameters(), lr=config.difficulty.learning_rate)
        
        # 5. Learning Rate Scheduler
        num_training_steps = len(self.train_loader) * config.epochs
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=num_training_steps)
        
        # Components
        self.replay_buffer = PrioritizedReplayBuffer(capacity=config.memory.capacity, alpha=config.memory.alpha)
        self.metrics = MetricsTracker()
        
    def train(self):
        logger.info("Starting Adaptive LoRA Training...")
        self.model.train()
        self.difficulty_model.train()
        
        global_step = 0
        
        for epoch in range(self.config.epochs):
            logger.info(f"Epoch {epoch+1}/{self.config.epochs}")
            
            # Progress bar
            pbar = tqdm(self.train_loader, desc=f"Training")
            
            for batch in pbar:
                # 1. Mix with replay buffer if enabled
                if self.config.memory.enabled and self.replay_buffer.size > 0:
                    # In a real implementation, you'd collate these properly. 
                    # For simplicity, we just train on the fresh batch here,
                    # and optionally do a second pass or mix tensors.
                    # This serves as the structural foundation.
                    pass 
                
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch.get('labels', input_ids).to(self.device)
                
                # 2. Forward pass
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                logits = outputs.logits
                
                # 3. Actual Loss (Attached to graph for main model training)
                per_sample_loss = SignalExtractor.extract_per_sample_loss(logits, labels)
                
                # 4. Extract Signals for Difficulty Estimation (Detached)
                with torch.no_grad():
                    entropy = SignalExtractor.extract_entropy(logits, labels)
                    seq_lengths = attention_mask.sum(dim=1)
                    
                    # Grad norm approximation (optional/heuristic)
                    grad_norms = torch.zeros_like(per_sample_loss)
                    
                    features = assemble_features(per_sample_loss.detach(), entropy, seq_lengths, grad_norms)
                
                # 5. Estimate Difficulty (Used for weighting and replay)
                difficulties = self.difficulty_model(features)
                
                # 5. Controller Update & LoRA Alpha Adjustment
                if self.config.controller.enabled:
                    mean_diff_tensor = difficulties.mean()
                    if self.use_ray:
                        import torch.distributed as dist
                        dist.all_reduce(mean_diff_tensor, op=dist.ReduceOp.AVG)
                    mean_diff = mean_diff_tensor.item()
                    current_alpha = self.model.module.current_alpha if hasattr(self.model, "module") else self.model.current_alpha
                    new_alpha = self.controller.update(mean_diff, current_alpha)
                    
                    # Ensure underlying AdaptiveLoRAModel updates alpha
                    # If wrapped in DDP, access module
                    if hasattr(self.model, "module"):
                        self.model.module.set_alpha(new_alpha)
                    else:
                        self.model.set_alpha(new_alpha)
                    
                # 6. Compute Weighted Loss
                loss = WeightedLoss.compute(per_sample_loss, difficulties)
                
                # 7. Backward Pass & Step (Main Model)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                self.scheduler.step()
                
                # 8. Train Difficulty Model (Self-supervised target: normalized loss)
                # We train it to predict the relative magnitude of the loss
                target_difficulty = (per_sample_loss - per_sample_loss.min()) / (per_sample_loss.max() - per_sample_loss.min() + 1e-8)
                diff_loss = nn.MSELoss()(difficulties, target_difficulty.detach())
                
                self.difficulty_optimizer.zero_grad()
                diff_loss.backward()
                self.difficulty_optimizer.step()
                
                # 9. Update Replay Buffer
                if self.config.memory.enabled:
                    for i in range(input_ids.size(0)):
                        sample = {
                            'input_ids': input_ids[i].cpu(),
                            'attention_mask': attention_mask[i].cpu(),
                            'labels': labels[i].cpu()
                        }
                        self.replay_buffer.add(sample, priority=difficulties[i].item())
                
                # 10. Track Metrics
                current_alpha = self.model.module.current_alpha if hasattr(self.model, "module") else self.model.current_alpha
                self.metrics.update({
                    "train_loss": loss.item(),
                    "alpha": current_alpha,
                    "mean_difficulty": difficulties.mean().item(),
                    "step": global_step
                })
                
                pbar.set_postfix({
                    "loss": f"{loss.item():.4f}",
                    "alpha": f"{current_alpha:.2f}",
                    "diff": f"{difficulties.mean().item():.3f}"
                })
                
                if self.use_ray:
                    import ray.train
                    ray.train.report({
                        "loss": loss.item(),
                        "alpha": current_alpha,
                        "mean_difficulty": difficulties.mean().item(),
                        "step": global_step,
                        "epoch": epoch
                    })
                
                # 11. Swarm Meta-Optimization (Zero-Overhead Hyperparameter Tuning)
                if self.swarm and global_step % self.config.swarm.update_interval == 0:
                    best_params = self.swarm.step(loss.item())
                    
                    # Apply Swarm tuned parameters to the live training loop
                    # 1. Update Learning Rate
                    for param_group in self.optimizer.param_groups:
                        param_group['lr'] = best_params['learning_rate']
                    
                    # 2. Update PID Gains
                    self.controller.kp = best_params['kp']
                    self.controller.ki = best_params['ki']
                    self.controller.kd = best_params['kd']
                    
                global_step += 1
                
            # Optional: Evaluation phase
            if self.val_loader:
                self.evaluate()
                
        logger.info("Training Complete.")

    def evaluate(self):
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc="Evaluating"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch.get('labels', input_ids).to(self.device)
                
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                total_loss += outputs.loss.item()
                
        avg_loss = total_loss / len(self.val_loader)
        perplexity = self.metrics.compute_perplexity(avg_loss)
        
        self.metrics.update({"val_loss": avg_loss, "perplexity": perplexity})
        logger.info(f"Validation Loss: {avg_loss:.4f} | Perplexity: {perplexity:.4f}")
        self.model.train()
