import torch
import torch.nn as nn
from transformers import PreTrainedModel
from peft import PeftModel, LoraConfig, get_peft_model
from typing import Dict, Any

class AdaptiveLoRAModel(nn.Module):
    """
    Wraps a base transformer model with PEFT LoRA and allows dynamic alpha updates.
    """
    def __init__(self, base_model: PreTrainedModel, lora_config: LoraConfig, init_alpha: float):
        super().__init__()
        self.model: PeftModel = get_peft_model(base_model, lora_config)
        self.current_alpha = init_alpha
        self.set_alpha(self.current_alpha)
        
    def set_alpha(self, alpha: float):
        """
        Dynamically updates the alpha parameter in all LoRA layers.
        In PEFT, the scaling factor is (alpha / r).
        We update the scaling attribute in the specific adapter.
        """
        self.current_alpha = alpha
        
        for name, module in self.model.named_modules():
            # In PEFT, lora layers are usually instances of Linear (peft.tuners.lora.Linear)
            if hasattr(module, 'scaling') and isinstance(module.scaling, dict):
                # LoRA scaling is a dict mapping adapter_name to (alpha/r)
                for adapter_name in module.scaling.keys():
                    if hasattr(module, 'r') and isinstance(module.r, dict):
                        r = module.r.get(adapter_name)
                        if r is not None and r > 0:
                            module.scaling[adapter_name] = self.current_alpha / r
    def forward(self, *args, **kwargs) -> Any:
        return self.model(*args, **kwargs)
        
    def generate(self, *args, **kwargs) -> Any:
        return self.model.generate(*args, **kwargs)
        
    def print_trainable_parameters(self):
        self.model.print_trainable_parameters()
