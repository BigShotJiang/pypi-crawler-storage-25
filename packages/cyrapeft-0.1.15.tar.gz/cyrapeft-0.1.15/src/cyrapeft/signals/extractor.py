import torch
import torch.nn.functional as F

class SignalExtractor:
    """Extracts training signals for difficulty estimation."""
    
    @staticmethod
    def extract_per_sample_loss(logits: torch.Tensor, targets: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
        """
        Computes the true per-sample loss.
        logits: (batch_size, seq_len, vocab_size)
        targets: (batch_size, seq_len)
        Returns:
            per_sample_loss: (batch_size,)
        """
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = targets[..., 1:].contiguous()
        
        loss_fct = torch.nn.CrossEntropyLoss(ignore_index=ignore_index, reduction='none')
        
        batch_size = shift_logits.size(0)
        # Flatten for loss computation
        token_losses = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
        token_losses = token_losses.view(batch_size, -1)
        
        # Calculate valid tokens per sample
        valid_tokens = (shift_labels != ignore_index).sum(dim=1).float()
        valid_tokens = torch.clamp(valid_tokens, min=1.0)
        
        # Mean loss per sample
        per_sample_loss = token_losses.sum(dim=1) / valid_tokens
        return per_sample_loss

    @staticmethod
    def extract_entropy(logits: torch.Tensor, targets: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
        """
        Computes the per-sample predictive entropy.
        Returns: (batch_size,)
        """
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = targets[..., 1:].contiguous()
        
        probs = F.softmax(shift_logits, dim=-1)
        log_probs = F.log_softmax(shift_logits, dim=-1)
        
        token_entropy = -(probs * log_probs).sum(dim=-1)  # (batch_size, seq_len - 1)
        
        mask = (shift_labels != ignore_index).float()
        valid_tokens = torch.clamp(mask.sum(dim=1), min=1.0)
        
        per_sample_entropy = (token_entropy * mask).sum(dim=1) / valid_tokens
        return per_sample_entropy
