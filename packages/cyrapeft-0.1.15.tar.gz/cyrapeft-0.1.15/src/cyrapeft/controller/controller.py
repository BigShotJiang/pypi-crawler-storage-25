from typing import Optional
from cyrapeft.config.config import ControllerConfig
from cyrapeft.controller.pid_controller import PIDController

class AlphaController:
    """
    Manages the adaptive scaling of LoRA alpha.
    """
    def __init__(self, config: ControllerConfig, init_alpha: float):
        self.enabled = config.enabled
        self.current_alpha = init_alpha
        self.pid = PIDController(
            kp=config.kp,
            ki=config.ki,
            kd=config.kd,
            target=config.target_difficulty,
            min_val=config.alpha_min,
            max_val=config.alpha_max
        )
        
    def update(self, mean_difficulty: float) -> float:
        """
        Updates and returns the new alpha value.
        """
        if not self.enabled:
            return self.current_alpha
            
        self.current_alpha = self.pid.step(mean_difficulty, self.current_alpha)
        return self.current_alpha
        
    def get_alpha(self) -> float:
        return self.current_alpha
