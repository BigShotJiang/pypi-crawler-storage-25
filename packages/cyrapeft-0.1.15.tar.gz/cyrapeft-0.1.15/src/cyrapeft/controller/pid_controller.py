class PIDController:
    """
    A discrete-time PID controller for dynamic scaling of LoRA alpha.
    """
    def __init__(self, kp: float, ki: float, kd: float, target: float, min_val: float, max_val: float):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.target = target
        self.min_val = min_val
        self.max_val = max_val
        
        self.prev_error = 0.0
        self.integral = 0.0
        
    def update(self, current_value: float, current_alpha: float) -> float:
        """
        Update the alpha value based on current observation.
        
        current_value: current difficulty or aggregated metric.
        current_alpha: the current scaling parameter.
        
        Returns: new_alpha
        """
        error = self.target - current_value
        self.integral += error
        derivative = error - self.prev_error
        
        adjustment = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        self.prev_error = error
        
        new_alpha = current_alpha + adjustment
        new_alpha = max(self.min_val, min(self.max_val, new_alpha))
        
        return new_alpha
