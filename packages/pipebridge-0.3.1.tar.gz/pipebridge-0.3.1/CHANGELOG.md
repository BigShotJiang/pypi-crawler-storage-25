# Changelog

All relevant changes to this project should be recorded here.

The format follows this convention:

- `feat:` new features
- `fix:` bug fixes
- `refactor:` internal refactoring
- `docs:` documentation
- `test:` tests

## [Unreleased]

- No pending entries.

## [0.3.1] - 2026-05-17

- `fix:` aligned connector option discovery with the contextual `cards(... throughConnectors ...)` resolver used by the Pipefy UI
- `fix:` resolved dynamic connector `repoId` from connected repo metadata, including `internal_id` for table-backed connectors
- `feat:` enriched connected repo metadata with `internal_id`, `uuid`, and an explicit discovery id helper
- `docs:` clarified contextual connector discovery semantics in the README, PyPI README, and use-case guidance
- `test:` added and updated unit coverage for contextual connector discovery and dynamic repo id resolution

## [0.3.0] - 2026-05-15

- `feat:` added first-class connector discovery through `api.connectors`, including field inspection, option listing, title resolution, and semantic card value helpers
- `feat:` expanded connector modeling with connected repo metadata, structured connector values, and richer table-backed option payloads via `record_fields` and `record_fields_map`
- `feat:` strengthened `createSafely(...)` to validate start-form connector ids against the connected repo and connector multiplicity rules
- `feat:` added public phase-schema helpers for explicit field existence checks through `api.phases.getField(...)`, `api.phases.hasField(...)`, and `api.phases.requireField(...)`
- `fix:` aligned file upload and download flows with schema-based attachment validation and card attachment aggregation instead of relying on `card.fields`
- `docs:` clarified that `card.fields` is a materialized value payload from Pipefy, not the complete schema of the phase or pipe
- `docs:` updated README, use cases, and agent-tooling docs for connector workflows, richer connector options, and the new file-flow semantics
- `test:` added unit and live coverage for connector schema discovery, connector card reads, safe connector creation, semantic connector updates, and corrected file-field resolution

## [0.2.5] - 2026-04-10

- `build:` restored the package runtime restriction to Python `>=3.14,<3.15` after import failures were confirmed on Python `3.13`
- `docs:` updated the published README badge and runtime badge for `v0.2.5`

## [0.2.4] - 2026-04-10

- `build:` relaxed the package metadata to support Python `>=3.12`
- `docs:` clarified that the project is developed and validated on Python `3.14`, while package metadata allows installation on Python `3.12+`

## [0.2.3] - 2026-04-10

- `docs:` updated the published README badge and release highlight so the PyPI page for `0.2.3` points to tag `v0.2.3`

## [0.2.2] - 2026-04-10

- `docs:` updated the README release badge and release highlight to point to `v0.2.1` before republishing on PyPI

## [0.2.1] - 2026-04-10

- `fix:` fallback field-type resolution in the high-level card update flow now consults the full pipe schema when the field is not present in the current phase or card payload
- `test:` added unit coverage for updating start form fields that are absent from the loaded card fields

## [0.2.0] - 2026-04-10

- `feat:` added `TransportConfig` as a public transport-layer configuration object
- `feat:` added TLS/SSL controls with `verify_ssl` and `ca_bundle_path`
- `feat:` added conservative transport retry for timeout and connection failures
- `feat:` expanded pipe field catalog coverage with `start_form_fields` and `internal_id`
- `feat:` added safe card creation through `api.cards.createSafely(...)`
- `fix:` corrected `createCard` mutation serialization to use valid GraphQL input for `fields_attributes`
- `fix:` ensured service-level operations honor transport timeout overrides
- `fix:` aligned `createSafely(...)` option validation with `InvalidFieldOptionError`
- `docs:` updated README and examples to document start form semantics and connector record id behavior
- `docs:` documented the destructive live integration battery that creates one card, mutates only that card, and can clean it up safely
- `test:` added unit coverage for transport configuration, retry behavior, create mutation serialization, and safe start form creation
- `test:` hardened the live integration battery to propagate one created card through create, update, move, destination update, and optional delete
