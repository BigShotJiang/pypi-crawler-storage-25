"""MCP Core — orchestrates multi-agent cognitive processing."""

import os
import json
import time
import uuid
from pathlib import Path
from typing import Optional, Dict, Any

from .minimax_client import MiniMaxClient, MiniMaxError
from .agents import CreatorAgent, CriticAgent, AnalystAgent
from .memory import WorkingMemory


DEFAULT_CONFIG_PATH = Path("~/.mcp/config.json").expanduser()
DEFAULT_LOG_DIR = Path("~/.mcp/logs").expanduser()
DEFAULT_MEMORY_DIR = Path("~/.mcp/memory").expanduser()


class MCP:
    """Multi-agent Cognitive Processing engine."""

    def __init__(self, config_path: Optional[str] = None, skip_api_key_check: bool = False):
        self.config_path = Path(config_path or DEFAULT_CONFIG_PATH)
        self.log_dir = Path(DEFAULT_LOG_DIR)
        self.memory_dir = Path(DEFAULT_MEMORY_DIR)

        self.config = self._load_config()
        self.session_id = str(uuid.uuid4())[:8]
        self.llm = None
        self.agents = {}

        # Ensure directories exist
        for d in (self.log_dir, self.memory_dir):
            d.mkdir(parents=True, exist_ok=True)

        # Initialize LLM
        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not api_key and not skip_api_key_check:
            raise ValueError("No API key configured. Run: mcp setup")

        if api_key:
            self.llm = MiniMaxClient(api_key)
            model = self.config.get("model", "abab5.5-chat")
            self.agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }

        self.memory = WorkingMemory(storage_path=str(self.memory_dir))

    def _load_config(self) -> Dict[str, Any]:
        """Load or create default config."""
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)

        # Create default config
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        default = {
            "api_key": "",
            "model": "abab5.5-chat",
            "max_tokens": 2000,
            "temperature": 0.7,
        }
        with open(self.config_path, "w") as f:
            json.dump(default, f, indent=2)
        return default

    def is_setup(self) -> bool:
        """Check if API key is configured."""
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "abab5.5-chat") -> bool:
        """Configure API key and model, reinitialize components."""
        self.config["api_key"] = api_key
        self.config["model"] = model
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=2)

        # Reinitialize with new key
        self.llm = MiniMaxClient(api_key)
        self.agents = {
            "creator": CreatorAgent(api_key, model=model),
            "critic": CriticAgent(api_key, model=model),
            "analyst": AnalystAgent(api_key, model=model),
        }
        return True

    # ── Cognitive pipeline ─────────────────────────────────────────────────────

    def process_task(self, task: str, verbose: bool = True) -> Dict[str, Any]:
        """Run the full 5-step cognitive pipeline."""
        if not self.is_setup():
            raise ValueError("MCP not set up. Run: mcp setup <api_key>")

        print(f"[MCP] Task: {task}") if verbose else None
        start_time = time.time()

        # Step 1 — Analyst breaks it down
        analysis = self._run_step("analyst", task, "Initial analysis of the task.")
        if verbose:
            print(f"  ✓ Analysis: {analysis['response'][:80]}...")

        # Step 2 — Creator generates a first draft
        creation = self._run_step("creator", task, self.memory.get_context())
        if verbose:
            print(f"  ✓ Creation: {creation['response'][:80]}...")

        # Step 3 — Critic evaluates
        critique = self._run_step("critic", task, self.memory.get_context())
        if verbose:
            print(f"  ✓ Critique: {critique['response'][:80]}...")

        # Step 4 — Creator improves based on critique
        improvement = self._run_step(
            "creator",
            f"Improve your previous solution based on this criticism: {critique['response']}",
            self.memory.get_context(),
        )
        if verbose:
            print(f"  ✓ Improvement: {improvement['response'][:80]}...")

        # Step 5 — Critic final evaluation
        final_eval = self._run_step(
            "critic",
            f"Provide a final evaluation of this improved solution. Rate it and note any remaining issues: {improvement['response']}",
            self.memory.get_context(),
        )
        if verbose:
            print(f"  ✓ Final eval: {final_eval['response'][:80]}...")

        duration = time.time() - start_time

        result = {
            "task": task,
            "session_id": self.session_id,
            "duration_seconds": round(duration, 2),
            "analysis": analysis["response"],
            "solution": improvement["response"],
            "evaluation": final_eval["response"],
        }

        self._save_session_log(task, result)
        if verbose:
            print(f"[MCP] Done in {duration:.2f}s  session={self.session_id}")

        return result

    def _run_step(self, agent_name: str, task: str, context: str) -> Dict[str, Any]:
        """Run one agent step and store result in memory."""
        agent = self.agents[agent_name]
        result = agent.process(task, context)
        self.memory.add(result)
        return result

    def _save_session_log(self, task: str, result: Dict[str, Any]) -> str:
        """Persist session to disk."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        path = self.log_dir / f"session_{ts}_{self.session_id}.json"
        with open(path, "w") as f:
            json.dump({
                "task": task,
                "session_id": self.session_id,
                "timestamp": ts,
                "result": result,
            }, f, indent=2)
        return str(path)
