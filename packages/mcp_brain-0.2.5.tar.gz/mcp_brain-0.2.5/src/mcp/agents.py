"""Specialized agents for multi-agent cognitive processing."""

import time
from typing import Optional, Dict, Any
from .minimax_client import MiniMaxClient


class Agent:
    """Base agent class."""

    def __init__(
        self,
        agent_id: str,
        role: str,
        persona: str,
        api_key: Optional[str] = None,
        model: str = "abab5.5-chat",
        max_tokens: int = 2000,
    ):
        self.agent_id = agent_id
        self.role = role
        self.persona = persona
        self.llm = MiniMaxClient(api_key)
        self.model = model
        self.max_tokens = max_tokens

    def process(self, task: str, context: str = "") -> Dict[str, Any]:
        """Process a task with this agent."""
        prompt = f"""{self.persona}

CONTEXT:
{context}

TASK:
{task}

Respond as a specialized {self.role} agent."""

        response = self.llm.generate(
            prompt=prompt,
            model=self.model,
            max_tokens=self.max_tokens,
        )

        return {
            "agent_id": self.agent_id,
            "role": self.role,
            "task": task,
            "response": response,
            "timestamp": time.time(),
        }


# ── Persona definitions ────────────────────────────────────────────────────────

CREATOR_PERSONA = """You are a Creator Agent. Your role is to generate creative solutions and content.
You excel at thinking outside the box and proposing novel approaches.
Focus on innovation and possibilities, not limitations.
Be bold and imaginative in your responses.
When providing a solution, include concrete details, examples, and actionable steps."""

CRITIC_PERSONA = """You are a Critic Agent. Your role is to evaluate solutions and identify flaws.
You excel at logical analysis and finding potential problems.
Focus on accuracy, consistency, and potential issues.
Be thorough and precise in your criticism, but always constructive — suggest improvements, don't just tear down.
When reviewing, consider: feasibility, completeness, edge cases, and clarity."""

ANALYST_PERSONA = """You are an Analyst Agent. Your role is to break down complex problems into structured components.
You excel at understanding systems and identifying patterns.
Focus on thorough examination and structured thinking.
Be methodical and detail-oriented in your analysis.
Break the problem into: context, key constraints, success criteria, and potential approaches."""


# ── Agent subclasses ──────────────────────────────────────────────────────────

class CreatorAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "abab5.5-chat", max_tokens: int = 2000):
        super().__init__(
            agent_id="creator",
            role="Creator",
            persona=CREATOR_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )


class CriticAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "abab5.5-chat", max_tokens: int = 2000):
        super().__init__(
            agent_id="critic",
            role="Critic",
            persona=CRITIC_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )


class AnalystAgent(Agent):
    def __init__(self, api_key: Optional[str] = None, model: str = "abab5.5-chat", max_tokens: int = 2000):
        super().__init__(
            agent_id="analyst",
            role="Analyst",
            persona=ANALYST_PERSONA,
            api_key=api_key,
            model=model,
            max_tokens=max_tokens,
        )
