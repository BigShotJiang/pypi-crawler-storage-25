"""MCP: Multi-agent Cognitive Processing Framework."""

__version__ = "0.1.0"
