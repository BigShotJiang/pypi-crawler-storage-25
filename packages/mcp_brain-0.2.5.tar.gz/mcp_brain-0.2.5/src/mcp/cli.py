"""MCP CLI — command-line interface for the cognitive processing framework."""

import os
import sys
import json
import click
from pathlib import Path

# Add src to path for direct execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp.mcp_core import MCP
from mcp.minimax_client import MiniMaxClient


DEFAULT_CONFIG = Path("~/.mcp/config.json").expanduser()


# ── Helpers ────────────────────────────────────────────────────────────────────

def get_mcp() -> MCP:
    """Get or create MCP instance, exits with clear message if not set up."""
    try:
        mcp = MCP()
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        click.echo("Run 'mcp setup' first.", err=True)
        sys.exit(1)
    if not mcp.is_setup():
        click.echo("Error: MCP not configured.", err=True)
        click.echo("Run 'mcp setup' first.", err=True)
        sys.exit(1)
    return mcp


def render_result(result: dict):
    """Pretty-print a processing result."""
    click.echo("\n" + "=" * 60)
    click.echo(f"SOLUTION  (session={result['session_id']}, {result['duration_seconds']}s)")
    click.echo("=" * 60)
    click.echo(result["solution"])

    click.echo("\n" + "-" * 60)
    click.echo("EVALUATION")
    click.echo("-" * 60)
    click.echo(result["evaluation"])

    click.echo("\n" + "-" * 60)
    click.echo("ANALYSIS")
    click.echo("-" * 60)
    click.echo(result["analysis"])


# ── Commands ─────────────────────────────────────────────────────────────────

@click.group()
@click.version_option(version="0.1.0")
def cli():
    """Multi-agent Cognitive Processing Framework.

    Uses specialized Creator, Critic, and Analyst agents to solve
    complex problems through structured cognitive collaboration.
    """
    pass


@cli.command()
def setup():
    """Interactively set up your MiniMax API key."""
    config_path = Path("~/.mcp/config.json").expanduser()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    click.echo("MCP Setup\n")

    api_key = os.environ.get("MINIMAX_API_KEY", "")
    prompted_key = click.prompt(
        "MiniMax API Key",
        default=api_key,
        hide_input=True,
        show_default=bool(api_key),
    ).strip()

    if not prompted_key:
        click.echo("No API key provided. Setup cancelled.", err=True)
        sys.exit(1)

    # Fetch available models using the provided key
    click.echo("Fetching available models...")
    try:
        client = MiniMaxClient(prompted_key)
        models = client.list_models()
    except Exception as e:
        click.echo(f"Warning: Could not fetch models ({e})", err=True)
        models = []

    if models:
        click.echo("\nAvailable models:")
        # Filter to chat models only (exclude embedding/others)
        chat_models = [
            m for m in models
            if "chat" in m.get("id", "").lower() or "text" in m.get("id", "").lower()
        ]
        for m in chat_models[:15]:
            click.echo(f"  - {m['id']}")
        if len(chat_models) > 15:
            click.echo(f"  ... and {len(chat_models) - 15} more")

        click.echo("")
        default_model = chat_models[0]["id"] if chat_models else "abab5.5-chat"
    else:
        default_model = "abab5.5-chat"

    model = click.prompt(
        "Model",
        default=default_model,
        show_default=True,
    ).strip()

    mcp = MCP(skip_api_key_check=True)
    mcp.setup(api_key=prompted_key, model=model)

    click.echo(f"\n✓ Config saved to {config_path}")
    click.echo("✓ MCP is ready. Run 'mcp process \"your task\"' to get started.")


@cli.command()
@click.argument("task", nargs=-1, type=click.UNPROCESSED, required=True)
@click.option("--quiet", "-q", is_flag=True, help="Suppress verbose output")
def process(task: tuple, quiet: bool):
    """Process a task through the cognitive pipeline."""
    task_str = " ".join(task)
    if not task_str.strip():
        click.echo("Error: empty task", err=True)
        sys.exit(1)

    mcp = get_mcp()

    try:
        result = mcp.process_task(task_str, verbose=not quiet)
        if not quiet:
            render_result(result)
        else:
            click.echo(result["solution"])
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command(name="sessions")
@click.option("--limit", "-n", default=10, help="Number of sessions to show")
def list_sessions(limit: int):
    """List recent session logs."""
    log_dir = Path("~/.mcp/logs").expanduser()
    if not log_dir.exists():
        click.echo("No sessions found.")
        return

    files = sorted(log_dir.glob("session_*.json"), reverse=True)[:limit]
    if not files:
        click.echo("No sessions found.")
        return

    click.echo(f"{'Session ID':<12} {'Timestamp':<20} {'Task':<50}")
    click.echo("-" * 84)
    for f in files:
        try:
            with open(f) as fh:
                data = json.load(f)
            sid = data.get("session_id", "-")
            ts = data.get("timestamp", "-")
            task = data.get("task", "-")[:47]
            click.echo(f"{sid:<12} {ts:<20} {task:<50}")
        except Exception:
            pass


@cli.command()
@click.argument("session_id")
def session(session_id: str):
    """Show full details of a past session."""
    log_dir = Path("~/.mcp/logs").expanduser()
    matches = list(log_dir.glob(f"session_*_{session_id}.json"))
    if not matches:
        click.echo(f"Session '{session_id}' not found.", err=True)
        sys.exit(1)

    with open(matches[0]) as f:
        data = json.load(f)

    result = data.get("result", {})
    click.echo(f"\nTask: {data.get('task')}")
    click.echo(f"Session: {data.get('session_id')}  Timestamp: {data.get('timestamp')}")
    render_result(result)


@cli.command()
def status():
    """Check MCP configuration status."""
    try:
        mcp = MCP()
    except Exception as e:
        click.echo(f"Config: not initialized — {e}")
        return

    cfg = mcp.config
    key_set = bool(cfg.get("api_key") or os.environ.get("MINIMAX_API_KEY"))
    click.echo(f"API key set:  {'✓' if key_set else '✗'}")
    click.echo(f"Model:        {cfg.get('model', 'unknown')}")
    click.echo(f"Config:       {mcp.config_path}")

    log_dir = Path("~/.mcp/logs").expanduser()
    n_sessions = len(list(log_dir.glob("session_*.json"))) if log_dir.exists() else 0
    click.echo(f"Sessions:     {n_sessions} on disk")


def main():
    cli()


if __name__ == "__main__":
    main()
