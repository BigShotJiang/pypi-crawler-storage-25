"""Working memory for MCP agents."""

import os
import json
import time
from pathlib import Path
from typing import List, Dict, Any, Optional


class WorkingMemory:
    """Manages short-term context across agent turns."""

    def __init__(self, capacity: int = 20, storage_path: Optional[str] = None):
        self.items: List[Dict[str, Any]] = []
        self.capacity = capacity
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/memory"))
        self.storage_path.mkdir(parents=True, exist_ok=True)

    def add(self, item: Dict[str, Any]) -> None:
        """Add an item to working memory, evicting oldest if at capacity."""
        if len(self.items) >= self.capacity:
            self.items.pop(0)
        self.items.append(item)

    def get_context(self) -> str:
        """Render current memory as a string for LLM context."""
        if not self.items:
            return "(no prior context)"
        lines = []
        for item in self.items:
            role = item.get("role", item.get("agent_id", "Agent"))
            resp = item.get("response", item.get("content", ""))
            lines.append(f"[{role}]: {resp}")
        return "\n\n".join(lines)

    def save(self, session_id: Optional[str] = None) -> str:
        """Persist current memory to disk. Returns the saved file path."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        suffix = f"_{session_id}" if session_id else ""
        path = self.storage_path / f"memory{suffix}_{ts}.json"
        with open(path, "w") as f:
            json.dump({"items": self.items, "saved_at": ts}, f, indent=2)
        return str(path)

    def load(self, session_id: Optional[str] = None) -> bool:
        """Load most recent memory (or session-specific). Returns True if loaded."""
        files = sorted(self.storage_path.glob("memory*.json"), reverse=True)
        if not files:
            return False
        if session_id:
            matches = [f for f in files if session_id in f.name]
            if not matches:
                return False
            file_path = matches[0]
        else:
            file_path = files[0]
        with open(file_path) as f:
            data = json.load(f)
        self.items = data.get("items", [])
        return True

    def clear(self) -> None:
        """Clear in-memory items (does not delete saved files)."""
        self.items.clear()
