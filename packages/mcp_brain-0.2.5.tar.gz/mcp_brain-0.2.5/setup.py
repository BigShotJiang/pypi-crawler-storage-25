from setuptools import setup, find_packages

setup(
    name="mcp-brain",
    version="0.2.5",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests>=2.25.0",
        "rich>=10.0.0",
        "click>=8.0.0",
    ],
    entry_points={
        "console_scripts": [
            "mcp=mcp.cli:main",
        ],
    },
    author="MC",
    description="Multi-agent Cognitive Processing Framework with MiniMax",
    python_requires=">=3.8",
)
