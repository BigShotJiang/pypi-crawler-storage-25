from __future__ import annotations

from pathlib import Path

EXAMPLES_DIR = Path(__file__).resolve().parent
CONTRACT_PATH = EXAMPLES_DIR / "TRAINING_CONTRACT.md"
PROMPT_PATH = EXAMPLES_DIR / "PROMPT.md"
EVAL_DATASET_PATH = EXAMPLES_DIR / "data" / "support_eval.jsonl"
TRAIN_DATASET_PATH = EXAMPLES_DIR / "data" / "support_train.jsonl"
