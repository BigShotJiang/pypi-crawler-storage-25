from __future__ import annotations

import json

from freesolo.tracing import (
    configure_tracer,
    force_flush,
    get_tracer,
    shutdown,
)


def answer_support_question(question: str) -> str:
    """Pretend this is your app code or model call."""

    if "password" in question.lower():
        return "Reset your password from Account settings > Security."
    return "A support teammate will follow up with the next step."


def main() -> None:
    configure_tracer(
        project_name="support-agent",
        resource_attributes={
            "deployment.environment": "local",
            "example.name": "tracing_manual_span",
        },
    )
    tracer = get_tracer("support-agent")

    question = "How do I reset my password?"
    with tracer.start_as_current_span("support_agent.answer") as span:
        span.set_attribute("gen_ai.system", "example")
        span.set_attribute("gen_ai.request.model", "local-rule-based-support-agent")
        span.set_attribute("trace.input", json.dumps({"question": question}))

        answer = answer_support_question(question)

        span.set_attribute("trace.output", answer)
        print(answer)

    force_flush()
    shutdown()


if __name__ == "__main__":
    main()
