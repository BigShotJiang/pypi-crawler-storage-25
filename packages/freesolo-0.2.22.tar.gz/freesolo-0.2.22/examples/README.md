# Freesolo SDK examples

These are standalone scripts that show the usual ways to use the `freesolo`
package from an application, eval job, or training job.

## Setup

Install the package and set your API key:

```bash
pip install freesolo
export FREESOLO_API_KEY=fslo_...
```

When running these examples from this repo checkout before publishing/installing
the package, add the local package source to `PYTHONPATH`:

```bash
cd freesolo-sdk
export PYTHONPATH="$PWD/pypi"
```

If you source the repo-level `../.env`, unset its project-env override before
using this package checkout:

```bash
set -a
source ../.env
set +a
unset UV_PROJECT_ENVIRONMENT
```

`FREESOLO_BASE_URL` is optional and defaults to `https://api.freesolo.co`.

## Trace an application path

```bash
uv run python examples/tracing_manual_span.py
```

This configures OpenTelemetry export to Freesolo, creates one span around a
support-agent function, and flushes the span before exit.

## Run an eval with custom scorers

Run only in your process, without uploading:

```bash
uv run python examples/evaluation_custom_scorer.py --local
```

Run and upload the eval results to Freesolo:

```bash
uv run python examples/evaluation_custom_scorer.py --name support-agent-smoke-test
```

## Run an environment eval

The environment and datasets are real files in this directory:

- `environment.py`: prompt construction, GRPO config, and reward scoring.
- `data/support_eval.jsonl`: eval records.
- `data/support_train.jsonl`: training records.
- `support_dataset.py`: path constants for the example datasets and prompts.
- `TRAINING_CONTRACT.md`: training contract for package training examples.
- `PROMPT.md`: model-facing prompt used by the GEPA prompt example.

```bash
uv run python examples/evaluation_from_files.py --name support-environment-smoke-test
```

## Try the GEPA adapter

This runs the Freesolo GEPA adapter locally and prints baseline/proposed scores.
Pass `--optimize` only after installing the GEPA extra.

```bash
uv run python examples/gepa_prompt_example.py
```

## Start a training run

Training uses Tinker and the Freesolo storage API. Install the Tinker
dependencies and make sure `FREESOLO_API_KEY`, your Tinker credentials, and any
W&B environment variables are available.

The script uses `support_dataset.py` for the training JSONL and changes into
`examples/` so `TRAINING_CONTRACT.md` and `environment.py` are discovered by the
training helpers without passing `contract_path` or `environment` explicitly.

```bash
uv run python examples/training_sft_grpo.py sft

uv run python examples/training_sft_grpo.py grpo --sft-log-dir ./logs/sft
```
