from __future__ import annotations

import json
from dataclasses import dataclass

from ..utils.core import loads_json_object
from .types import Candidate, ReflectionGenerator, ReflectiveDataset


@dataclass
class DefaultReflectionAgent:
    """Minimal reflection agent that users can subclass or wrap with any LLM."""

    generate: ReflectionGenerator | None = None

    def propose_new_texts(
        self,
        candidate: Candidate,
        reflective_dataset: ReflectiveDataset,
        components_to_update: list[str],
    ) -> Candidate:
        if self.generate is None:
            raise RuntimeError(
                "DefaultReflectionAgent requires a generate(prompt) callable, "
                "or subclass propose_new_texts for custom proposal logic."
            )

        prompt = self.build_prompt(candidate, reflective_dataset, components_to_update)
        raw_response = self.generate(prompt)
        return self.parse_response(raw_response, components_to_update)

    def build_prompt(
        self,
        candidate: Candidate,
        reflective_dataset: ReflectiveDataset,
        components_to_update: list[str],
    ) -> str:
        payload = {
            "current_candidate": {
                name: candidate[name]
                for name in components_to_update
                if name in candidate
            },
            "reflective_dataset": reflective_dataset,
            "components_to_update": components_to_update,
        }
        return "\n".join(
            [
                "You are improving text components used by an agent or evaluator.",
                "Treat scores and feedback as the source of truth.",
                "Internally form a causal hypothesis for why the current text failed before editing it.",
                "Make one coherent, minimal change per component unless the feedback clearly requires broader restructuring.",
                "Preserve the task requirements, required output format, and component names.",
                "Keep human-specified constraints stronger than any pattern inferred from examples.",
                "Make targeted changes that address observed failures; do not reward verbosity, remove constraints, or overfit to example wording.",
                "Do not special-case training examples, memorize answers, or add brittle rules tied to exact sample wording.",
                "Favor instructions that generalize to held-out validation cases, including edge cases and varied phrasing.",
                "If a component is already working, refine it conservatively instead of rewriting it from scratch.",
                "Return JSON only: an object mapping each component name to its new text.",
                "Do not include markdown, commentary, or keys outside components_to_update.",
                json.dumps(payload, indent=2, sort_keys=True),
            ]
        )

    def parse_response(
        self,
        raw_response: str,
        components_to_update: list[str],
    ) -> Candidate:
        parsed = loads_json_object(raw_response)
        if parsed is None:
            if len(components_to_update) == 1:
                return {components_to_update[0]: raw_response.strip()}
            raise ValueError("Reflection response must be a JSON object")

        proposed: Candidate = {}
        for component_name in components_to_update:
            value = parsed.get(component_name)
            if isinstance(value, str) and value.strip():
                proposed[component_name] = value
        if not proposed:
            raise ValueError("Reflection response did not include any updated text")
        return proposed


__all__ = [
    "DefaultReflectionAgent",
]
