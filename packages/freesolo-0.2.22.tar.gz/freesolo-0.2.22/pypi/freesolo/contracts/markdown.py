from __future__ import annotations

import json
import re
from pathlib import Path
from typing import cast

from .types import ChatMessage, ContractMessageSpec, ContractSpec

_FREESOLO_CONTRACT_BLOCK = re.compile(
    r"```(?:json\s+)?freesolo-contract\s*(.*?)```",
    flags=re.DOTALL | re.IGNORECASE,
)


def load_contract_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8").strip()


def extract_contract_spec(contract_text: str) -> ContractSpec | None:
    stripped = contract_text.strip()
    payload: str | None = stripped if stripped.startswith(("{", "[")) else None
    if payload is None:
        match = _FREESOLO_CONTRACT_BLOCK.search(contract_text)
        if match is not None:
            payload = match.group(1).strip()
    if payload is None:
        return None
    if not payload:
        return None
    parsed = json.loads(payload)
    if not isinstance(parsed, dict):
        raise ValueError("Expected the contract JSON to contain a JSON object")
    return cast(ContractSpec, parsed)


def load_contract_spec(path: str | Path) -> ContractSpec | None:
    return extract_contract_spec(load_contract_text(path))


def build_oracle_messages(
    task_text: str,
    contract_text: str,
    contract_spec: ContractSpec | None = None,
) -> list[ChatMessage]:
    message_specs: list[ContractMessageSpec] = []
    if contract_spec:
        prompt = contract_spec.get("prompt")
        if prompt and (
            isinstance(prompt.get("system"), str) or isinstance(prompt.get("user"), str)
        ):
            system_content = str(prompt.get("system", "")).strip()
            user_content = str(prompt.get("user", "")).strip()
            rendered = []
            if system_content:
                rendered.append(
                    {
                        "role": "system",
                        "content": _render_prompt_content(system_content, task_text),
                    }
                )
            rendered.append(
                {
                    "role": "user",
                    "content": _render_prompt_content(
                        user_content or task_text, task_text
                    ),
                }
            )
            return rendered
        if prompt and isinstance(prompt.get("messages"), list):
            message_specs = [
                cast(ContractMessageSpec, item)
                for item in prompt["messages"]
                if isinstance(item, dict)
            ]

    if message_specs:
        rendered: list[ChatMessage] = []
        for message_spec in message_specs:
            rendered.append(
                {
                    "role": str(message_spec.get("role", "user")).strip() or "user",
                    "content": _render_prompt_content(
                        str(message_spec.get("content", "")),
                        task_text,
                    ),
                }
            )
        return rendered

    system_content = (
        json.dumps(contract_spec, indent=2, sort_keys=True, ensure_ascii=True)
        if contract_spec
        else contract_text
    )
    return [
        {"role": "system", "content": system_content},
        {"role": "user", "content": task_text},
    ]


def _render_prompt_content(content: str, task_text: str) -> str:
    rendered = content
    for placeholder in ("{input}", "{task}", "{query}"):
        rendered = rendered.replace(placeholder, task_text)
    return rendered
