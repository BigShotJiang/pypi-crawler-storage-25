from __future__ import annotations

from typing import Literal, TypedDict

ContractScale = Literal["boolean", "numeric"]
ContractMethod = Literal["llm", "rule_based"]


class ChatMessage(TypedDict):
    role: str
    content: str


class ContractMessageSpec(TypedDict, total=False):
    role: str
    content: str


class EvaluationSpec(TypedDict, total=False):
    name: str
    description: str
    scale: ContractScale
    method: ContractMethod


class RewardFunctionSpec(TypedDict, total=False):
    name: str
    description: str
    scale: ContractScale
    method: ContractMethod


class PromptConfig(TypedDict, total=False):
    system: str
    user: str
    messages: list[ContractMessageSpec]


class ContractSpec(TypedDict, total=False):
    prompt: PromptConfig
    evaluations: list[EvaluationSpec]
    reward_functions: list[RewardFunctionSpec]


__all__ = [
    "ChatMessage",
    "ContractMessageSpec",
    "ContractMethod",
    "ContractScale",
    "ContractSpec",
    "EvaluationSpec",
    "PromptConfig",
    "RewardFunctionSpec",
]
