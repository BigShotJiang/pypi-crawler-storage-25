from __future__ import annotations

import json
import logging
import math
from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager
from typing import Any

from opentelemetry import trace as otel_trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import (
    ReadableSpan,
    SpanLimits,
    SpanProcessor,
    TracerProvider,
)
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)

from ..utils.core import _env_value, _require_api_key, _resolve_base_url, truncate_text
from .sanitize import sanitize_value

logger = logging.getLogger("freesolo.tracing.otel")

OTEL_TRACER_NAME = "freesolo"
OTLP_TRACE_INGEST_PATH = "/api/traces/ingest"
DEFAULT_MAX_ATTRIBUTE_LENGTH = 8_192
DEFAULT_MAX_SPAN_ATTRIBUTES = 128
TRACE_SCORE_ATTRIBUTE = "trace.score"
TRACE_SUCCESS_ATTRIBUTE = "trace.success"
TRACE_SCORERS_DATA_ATTRIBUTE = "trace.scorers_data"
SCORER_BUNDLE_ID_ATTRIBUTE = "scorer_bundle_id"
PROJECT_NAME_ATTRIBUTE = "project_name"
SCORER_BUNDLE_ID_ENV = "FREESOLO_SCORER_BUNDLE_ID"
PROJECT_NAME_ENV = "FREESOLO_PROJECT_NAME"

_configured_provider: TracerProvider | None = None
_configured_scorer_bundle_id: str | None = None


class _FreesoloSpanExporter(SpanExporter):
    """OpenTelemetry exporter that sends spans to Freesolo over native OTLP/HTTP."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        endpoint_path: str = OTLP_TRACE_INGEST_PATH,
        timeout_seconds: float = 10.0,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        resolved_api_key = _require_api_key(
            api_key,
            error_message="Freesolo OpenTelemetry export requires FREESOLO_API_KEY.",
        )
        endpoint = _otlp_endpoint(base_url=base_url, endpoint_path=endpoint_path)
        self._delegate = OTLPSpanExporter(
            endpoint=endpoint,
            headers={
                "Authorization": f"Bearer {resolved_api_key}",
                **dict(headers or {}),
            },
            timeout=timeout_seconds,
        )

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        return self._delegate.export(spans)

    def shutdown(self) -> None:
        self._delegate.shutdown()

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return self._delegate.force_flush(timeout_millis)


def configure_tracer(
    *,
    project_name: str = "freesolo",
    base_url: str | None = None,
    api_key: str | None = None,
    resource_attributes: Mapping[str, Any] | None = None,
    batch: bool = True,
    set_global: bool = True,
    endpoint_path: str = OTLP_TRACE_INGEST_PATH,
    timeout_seconds: float = 10.0,
    serializer: Callable[[Any], str] | None = None,
    span_limits: SpanLimits | None = None,
    max_attribute_length: int = DEFAULT_MAX_ATTRIBUTE_LENGTH,
    max_span_attributes: int = DEFAULT_MAX_SPAN_ATTRIBUTES,
    span_processors: Sequence[SpanProcessor] | None = None,
    headers: Mapping[str, str] | None = None,
    scorer_bundle_id: str | None = None,
) -> TracerProvider:
    """Configure the Freesolo OpenTelemetry tracer exporter."""

    global _configured_provider
    global _configured_scorer_bundle_id

    resolved_project_name = project_name or _env_value(PROJECT_NAME_ENV) or "freesolo"
    resource_payload: dict[str, Any] = {
        "service.name": resolved_project_name,
        PROJECT_NAME_ATTRIBUTE: resolved_project_name,
        "telemetry.sdk.name": "freesolo",
        **_sanitize_otel_attributes(
            resource_attributes or {},
            serializer=serializer,
            max_attribute_length=max_attribute_length,
        ),
    }
    resolved_scorer_bundle_id = scorer_bundle_id or _env_value(SCORER_BUNDLE_ID_ENV)
    if resolved_scorer_bundle_id:
        resource_payload[SCORER_BUNDLE_ID_ATTRIBUTE] = resolved_scorer_bundle_id
    resource = Resource.create(resource_payload)
    provider = TracerProvider(
        resource=resource,
        span_limits=span_limits
        or SpanLimits(
            max_span_attributes=max_span_attributes,
            max_span_attribute_length=max_attribute_length,
        ),
    )
    exporter = _FreesoloSpanExporter(
        base_url=base_url,
        api_key=api_key,
        endpoint_path=endpoint_path,
        timeout_seconds=timeout_seconds,
        headers=headers,
    )
    processor = BatchSpanProcessor(exporter) if batch else SimpleSpanProcessor(exporter)
    provider.add_span_processor(processor)
    for extra_processor in span_processors or ():
        provider.add_span_processor(extra_processor)

    if set_global:
        try:
            otel_trace.set_tracer_provider(provider)
        except Exception:
            logger.exception("failed to set global OpenTelemetry tracer provider")

    _configured_provider = provider
    _configured_scorer_bundle_id = resolved_scorer_bundle_id
    return provider


def get_tracer(name: str = OTEL_TRACER_NAME):
    return otel_trace.get_tracer(name)


def setup_tracing(
    *,
    project_name: str = "freesolo",
    base_url: str | None = None,
    api_key: str | None = None,
    scorer_bundle_id: str | None = None,
) -> bool:
    """Configure Freesolo tracing when an API key is available.

    Returns ``False`` without importing/exporting anything when no API key is
    configured, so application code can call this unconditionally at startup.
    """

    if _configured_provider is not None:
        return True
    resolved_api_key = api_key or _env_value("FREESOLO_API_KEY")
    if not resolved_api_key:
        return False
    configure_tracer(
        project_name=project_name,
        base_url=base_url,
        api_key=resolved_api_key,
        scorer_bundle_id=scorer_bundle_id,
    )
    return True


class FreesoloTrace:
    def __init__(self, span: Any | None) -> None:
        self._span = span

    def set_attribute(self, key: str, value: Any) -> None:
        if value is None or self._span is None:
            return
        self._span.set_attribute(key, _coerce_trace_attribute(value))

    def set_output(self, value: Any) -> None:
        self.set_attribute("trace.output", value)


@contextmanager
def trace_api_call(
    name: str,
    *,
    input: Any | None = None,
    provider: str | None = None,
    model: str | None = None,
    scorer_bundle_id: str | None = None,
    attributes: Mapping[str, Any] | None = None,
):
    """Create a Freesolo span around a model/API call.

    If tracing has not been configured, this is a no-op context manager.
    """

    if _configured_provider is None:
        yield FreesoloTrace(None)
        return

    tracer = _configured_provider.get_tracer(OTEL_TRACER_NAME)
    with tracer.start_as_current_span(name) as span:
        trace = FreesoloTrace(span)
        trace.set_attribute("trace.input", input)
        trace.set_attribute("gen_ai.system", provider)
        trace.set_attribute("llm.provider", provider)
        trace.set_attribute("gen_ai.request.model", model)
        trace.set_attribute("llm.model", model)
        trace.set_attribute(
            SCORER_BUNDLE_ID_ATTRIBUTE,
            scorer_bundle_id or _configured_scorer_bundle_id,
        )
        for key, value in (attributes or {}).items():
            trace.set_attribute(str(key), value)
        yield trace


def set_trace_score(
    *,
    score: float | None = None,
    success: bool | None = None,
    scorers_data: Sequence[Mapping[str, Any]] | None = None,
    scorer_bundle_id: str | None = None,
) -> None:
    """Attach trace-level scoring metadata to the current OpenTelemetry span."""

    span = otel_trace.get_current_span()
    if not span or not span.is_recording():
        return
    if score is not None:
        span.set_attribute(TRACE_SCORE_ATTRIBUTE, float(score))
    if success is not None:
        span.set_attribute(TRACE_SUCCESS_ATTRIBUTE, bool(success))
    if scorers_data is not None:
        span.set_attribute(
            TRACE_SCORERS_DATA_ATTRIBUTE,
            truncate_text(
                json.dumps(
                    [dict(item) for item in scorers_data],
                    ensure_ascii=False,
                    sort_keys=True,
                    default=str,
                ),
                DEFAULT_MAX_ATTRIBUTE_LENGTH,
            ),
        )
    if scorer_bundle_id:
        span.set_attribute(SCORER_BUNDLE_ID_ATTRIBUTE, scorer_bundle_id)


def force_flush(timeout_millis: int = 30_000) -> bool:
    provider = _configured_provider
    return bool(provider and provider.force_flush(timeout_millis))


def shutdown() -> None:
    provider = _configured_provider
    if provider is not None:
        provider.shutdown()


def _sanitize_otel_attributes(
    attributes: Mapping[str, Any],
    *,
    serializer: Callable[[Any], str] | None = None,
    max_attribute_length: int = DEFAULT_MAX_ATTRIBUTE_LENGTH,
) -> dict[str, str | bool | int | float | Sequence[str | bool | int | float]]:
    sanitized: dict[
        str, str | bool | int | float | Sequence[str | bool | int | float]
    ] = {}
    for key, value in attributes.items():
        coerced = _coerce_otel_attribute(
            value,
            serializer=serializer,
            max_attribute_length=max_attribute_length,
        )
        if coerced is not None:
            sanitized[str(key)] = coerced
    return sanitized


def _otlp_endpoint(*, base_url: str | None, endpoint_path: str) -> str:
    normalized_path = (
        endpoint_path if endpoint_path.startswith("/") else f"/{endpoint_path}"
    )
    return f"{_resolve_base_url(base_url)}{normalized_path}"


def _coerce_otel_attribute(
    value: Any,
    *,
    serializer: Callable[[Any], str] | None,
    max_attribute_length: int,
) -> str | bool | int | float | Sequence[str | bool | int | float] | None:
    value = sanitize_value(value)
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, str):
        return truncate_text(value, max_attribute_length)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        scalar_values = [
            _coerce_scalar_attribute(item, max_attribute_length=max_attribute_length)
            for item in value
        ]
        if all(item is not None for item in scalar_values):
            return [item for item in scalar_values if item is not None]
    return truncate_text(_serialize_attribute(value, serializer), max_attribute_length)


def _coerce_trace_attribute(
    value: Any,
) -> str | bool | int | float | Sequence[str | bool | int | float]:
    coerced = _coerce_otel_attribute(
        value,
        serializer=None,
        max_attribute_length=DEFAULT_MAX_ATTRIBUTE_LENGTH,
    )
    return "" if coerced is None else coerced


def _coerce_scalar_attribute(
    value: Any,
    *,
    max_attribute_length: int,
) -> str | bool | int | float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, str):
        return truncate_text(value, max_attribute_length)
    return None


def _serialize_attribute(
    value: Any,
    serializer: Callable[[Any], str] | None,
) -> str:
    if serializer is not None:
        return serializer(value)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


__all__ = [
    "configure_tracer",
    "force_flush",
    "get_tracer",
    "set_trace_score",
    "setup_tracing",
    "shutdown",
    "trace_api_call",
]
