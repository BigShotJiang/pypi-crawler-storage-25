# Tracing

Tracing configures OpenTelemetry export for SDK activity.

## Public Imports

```python
from freesolo.tracing import (
    configure_tracer,
    force_flush,
    get_tracer,
    setup_tracing,
    shutdown,
    trace_api_call,
)
```

## Agent Guidance

- Prefer `setup_tracing(...)` plus `trace_api_call(...)` for source-repo
  instrumentation. `setup_tracing(...)` returns `False` without error when no
  Freesolo API key is configured, and `trace_api_call(...)` is a no-op until
  tracing is configured.
- Call `configure_tracer(...)` from a generated entrypoint only when trace export
  is explicitly requested.
- Pass `api_key` and `base_url` at runtime when they are known by the caller.
- Pass `project_name` to group traces by source project in Freesolo.
- To let the backend automatically score traces, pass `scorer_bundle_id` to
  `configure_tracer(...)` or set `FREESOLO_SCORER_BUNDLE_ID`.
- Use `get_tracer(...)` for custom spans around generated repo work.
- Call `force_flush(...)` or `shutdown()` before process exit when a short-lived
  command needs trace delivery.
- Do not import `sanitize` or exporter internals from generated repos.
