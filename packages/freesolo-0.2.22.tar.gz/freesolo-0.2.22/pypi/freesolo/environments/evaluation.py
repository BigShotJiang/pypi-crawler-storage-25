from __future__ import annotations

import asyncio
import inspect
import json
import time
from collections.abc import Awaitable, Callable, Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TypeAlias

from freesolo.datasets import TaskExample
from freesolo.datasets.records import load_task_examples
from freesolo.datasets.types import DatasetSource

from ..contracts.markdown import ChatMessage, load_contract_text
from ..evaluation.results import ScorerData, ScorerMetricData, ScoringResult
from ..utils.core import JsonObject, json_safe_value, optional_int
from .base import Environment, load_environment
from .types import (
    EnvironmentMetadata,
    RewardMetric,
    RewardResult,
)


@dataclass(slots=True)
class EnvironmentGeneration:
    """Model output returned by an environment eval generation callback."""

    response_text: str
    latency_ms: int | None = None
    total_tokens: int | None = None
    metadata: EnvironmentMetadata = field(default_factory=dict)


GenerationValue: TypeAlias = str | dict[str, Any] | EnvironmentGeneration
EnvironmentGenerate: TypeAlias = Callable[
    [list[ChatMessage], TaskExample],
    GenerationValue | Awaitable[GenerationValue],
]
EnvironmentSource: TypeAlias = DatasetSource


def _run_local_environment_evaluation(
    *,
    source: EnvironmentSource,
    generate: EnvironmentGenerate,
    contract_path: str | Path = "TRAINING_CONTRACT.md",
    contract_text: str | None = None,
    environment: str | Environment | None = None,
    environment_kwargs: dict[str, object] | None = None,
    concurrency: int = 1,
) -> list[ScoringResult]:
    """Run an environment end-to-end and return DB-compatible eval results.

    Flow:
    load examples -> build prompt messages -> call generate -> score response.
    Internal implementation for EvaluationClient.run_environment.
    """

    resolved_contract_text = (
        contract_text
        if contract_text is not None
        else load_contract_text(contract_path)
    )
    resolved_environment = _resolve_environment(
        environment,
        source=source,
        contract_path=contract_path,
        environment_kwargs=environment_kwargs,
    )
    examples = load_task_examples(source)
    started = time.monotonic()
    worker_count = _resolve_concurrency(concurrency)
    if worker_count == 1:
        results = [
            _evaluate_example(
                example,
                environment=resolved_environment,
                generate=generate,
                contract_text=resolved_contract_text,
            )
            for example in examples
        ]
    else:
        results_by_index: list[ScoringResult | None] = [None] * len(examples)
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = {
                executor.submit(
                    _evaluate_example,
                    example,
                    environment=resolved_environment,
                    generate=generate,
                    contract_text=resolved_contract_text,
                ): index
                for index, example in enumerate(examples)
            }
            for future in as_completed(futures):
                results_by_index[futures[future]] = future.result()
        results = [result for result in results_by_index if result is not None]

    run_duration = time.monotonic() - started
    for result in results:
        result.run_duration = run_duration
    return results


def _evaluate_example(
    example: TaskExample,
    *,
    environment: Environment,
    generate: EnvironmentGenerate,
    contract_text: str,
) -> ScoringResult:
    messages = environment.build_prompt_messages(
        example,
        contract_text,
    )
    generation_started = time.monotonic()
    raw_generation = _resolve_generation(
        _call_generate(
            generate,
            messages=messages,
            example=example,
            environment=environment,
            contract_text=contract_text,
        )
    )
    measured_latency_ms = int((time.monotonic() - generation_started) * 1000)
    latency_ms = raw_generation.latency_ms
    if latency_ms is None:
        latency_ms = measured_latency_ms

    reward_results = environment.score_responses(
        example,
        [raw_generation.response_text],
    )
    if len(reward_results) != 1:
        raise RuntimeError(
            "Environment score_responses() must return one RewardResult per "
            "generated response"
        )

    scorer = _reward_to_scorer_data(
        reward_results[0],
        latency_ms=latency_ms,
        total_tokens=raw_generation.total_tokens,
    )
    data_object = _data_object(
        example,
        response_text=raw_generation.response_text,
        generation_metadata=raw_generation.metadata,
    )
    return ScoringResult(
        success=scorer.success,
        scorers_data=[scorer],
        data_object=data_object,
    )


def _resolve_concurrency(value: int) -> int:
    if isinstance(value, bool) or value < 1:
        raise ValueError("concurrency must be a positive integer")
    return value


def _resolve_environment(
    environment: str | Environment | None,
    *,
    source: EnvironmentSource,
    contract_path: str | Path,
    environment_kwargs: dict[str, object] | None,
) -> Environment:
    if isinstance(environment, Environment):
        return environment

    kwargs = dict(environment_kwargs or {})
    kwargs.setdefault("contract_path", str(contract_path))
    kwargs.setdefault("mode", "eval")
    if isinstance(source, (str, Path)):
        kwargs.setdefault("dataset_path", str(source))
    return load_environment(environment, **kwargs)


def _call_generate(
    generate: EnvironmentGenerate,
    *,
    messages: list[ChatMessage],
    example: TaskExample,
    environment: Environment,
    contract_text: str,
) -> GenerationValue | Awaitable[GenerationValue]:
    try:
        signature = inspect.signature(generate)
    except (TypeError, ValueError):
        return generate(messages, example)
    parameters = list(signature.parameters.values())
    accepts_kwargs = any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD for parameter in parameters
    )
    named_arguments: dict[str, object] = {
        "messages": messages,
        "example": example,
        "environment": environment,
        "contract_text": contract_text,
    }
    if accepts_kwargs:
        return generate(**named_arguments)  # type: ignore[misc]

    keyword_arguments = {
        name: value
        for name, value in named_arguments.items()
        if name in signature.parameters
    }
    if keyword_arguments:
        return generate(**keyword_arguments)  # type: ignore[misc]

    positional_parameters = [
        parameter
        for parameter in parameters
        if parameter.kind
        in {
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        }
    ]
    if len(positional_parameters) <= 1:
        return generate(messages)  # type: ignore[call-arg]
    return generate(messages, example)


def _resolve_generation(
    value: GenerationValue | Awaitable[GenerationValue],
) -> EnvironmentGeneration:
    if inspect.isawaitable(value):
        value = asyncio.run(value)
    if isinstance(value, EnvironmentGeneration):
        return value
    if isinstance(value, str):
        return EnvironmentGeneration(response_text=value)
    if isinstance(value, dict):
        text_keys = ("response_text", "text", "content", "actual_output", "output")
        text = _first_text_value(
            value,
            keys=text_keys,
        )
        if text is None:
            joined_keys = ", ".join(text_keys)
            raise ValueError(
                f"Generation result dict must include a non-null text field: {joined_keys}"
            )
        metadata = value.get("metadata")
        return EnvironmentGeneration(
            response_text=text,
            latency_ms=optional_int(value.get("latency_ms")),
            total_tokens=optional_int(value.get("total_tokens")),
            metadata=metadata if isinstance(metadata, dict) else {},
        )
    raise TypeError(f"Unsupported generation result: {type(value).__name__}")


def _first_text_value(value: dict[str, Any], *, keys: Sequence[str]) -> str | None:
    for key in keys:
        if key not in value:
            continue
        item = value[key]
        if isinstance(item, str):
            return item
        if item is None:
            return None
        return json.dumps(json_safe_value(item), ensure_ascii=True)
    return None


def _reward_to_scorer_data(
    reward: RewardResult,
    *,
    latency_ms: int | None,
    total_tokens: int | None,
) -> ScorerData:
    return ScorerData(
        name=reward.name or "environment_reward",
        success=reward.resolved_success(),
        value=reward.resolved_value(),
        score=reward.score,
        threshold=reward.threshold,
        reason=reward.reason,
        error=reward.error,
        return_type=reward.return_type,
        latency_ms=reward.latency_ms if reward.latency_ms is not None else latency_ms,
        total_tokens=reward.total_tokens
        if reward.total_tokens is not None
        else total_tokens,
        metadata=reward.metadata,
        metrics=[_metric_to_scorer_metric(metric) for metric in reward.metrics],
    )


def _metric_to_scorer_metric(metric: RewardMetric) -> ScorerMetricData:
    return ScorerMetricData(
        name=metric.name,
        score=metric.score,
        value=metric.value,
        success=metric.success,
        threshold=metric.threshold,
        weight=metric.weight,
        reason=metric.reason,
        metadata=metric.metadata,
    )


def _data_object(
    example: TaskExample,
    *,
    response_text: str,
    generation_metadata: EnvironmentMetadata,
) -> JsonObject:
    payload: JsonObject = {
        "input": example.task,
        "actual_output": response_text,
    }
    if example.expected_output is not None:
        payload["expected_output"] = json_safe_value(example.expected_output)
    if example.task_id:
        payload["task_id"] = example.task_id
    if example.metadata:
        payload["metadata"] = example.metadata
    if generation_metadata:
        payload["generation_metadata"] = generation_metadata
    image_url = example.record.get("image_url")
    if isinstance(image_url, str):
        payload["image_url"] = image_url
    return payload


__all__ = [
    "EnvironmentGeneration",
]
