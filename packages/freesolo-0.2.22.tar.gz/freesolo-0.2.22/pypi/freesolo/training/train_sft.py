from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from typing import Unpack

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from freesolo.contracts.markdown import load_contract_text
from freesolo.datasets import load_dataset
from freesolo.environments.base import load_environment as load_training_environment
from freesolo.training.storage import start_stored_training_run
from freesolo.training.types import (
    TRAINING_BASE_MODEL,
    TRAINING_RENDERER_NAME,
    SftConfig,
    TrainSftOptions,
    resolve_sft_config,
)
from freesolo.utils.checkpoints import (
    checkpoint_step,
    get_last_tinker_checkpoint,
    resolve_checkpoint_state_path,
    save_tinker_checkpoint,
)
from freesolo.utils.core import load_dotenv_if_available, required_path
from freesolo.utils.wandb import numeric_metrics_from_result, start_wandb_run


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Basic Tinker SFT scaffold.")
    parser.add_argument("--contract", default="TRAINING_CONTRACT.md")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--environment")
    parser.add_argument("--log-dir", default="./logs/sft")
    parser.add_argument("--base-url")
    parser.add_argument("--max-length", type=int, required=True)
    return parser.parse_args()


def train_sft(**kwargs: Unpack[TrainSftOptions]) -> int:
    if "dataset_path" not in kwargs:
        raise TypeError(
            "train_sft() missing required keyword-only argument: 'dataset_path'"
        )
    if "base_model" in kwargs:
        raise TypeError(
            "train_sft() does not accept base_model; Freesolo training is pinned "
            f"to {TRAINING_BASE_MODEL}"
        )
    return _train_sft(
        contract_path=kwargs.get("contract_path", "TRAINING_CONTRACT.md"),
        dataset_path=kwargs["dataset_path"],
        environment=kwargs.get("environment"),
        log_dir=kwargs.get("log_dir", "./logs/sft"),
        base_url=kwargs.get("base_url"),
        sft_config=kwargs.get("sft_config"),
    )


def _train_sft(
    *,
    contract_path: str | Path = "TRAINING_CONTRACT.md",
    dataset_path: str | Path,
    environment: str | None = None,
    log_dir: str | Path = "./logs/sft",
    base_url: str | None = None,
    sft_config: SftConfig | None = None,
) -> int:
    load_dotenv_if_available()
    try:
        import tinker
        from tinker_cookbook import checkpoint_utils, renderers
        from tinker_cookbook.supervised.data import conversation_to_datum
        from tinker_cookbook.tokenizer_utils import get_tokenizer
    except ImportError as error:
        raise RuntimeError(
            "Install tinker and tinker-cookbook to run training/train_sft.py"
        ) from error

    dataset_path = required_path(dataset_path, "dataset_path")
    contract_text = load_contract_text(contract_path)
    training_environment = load_training_environment(
        environment,
        contract_path=str(contract_path),
        dataset_path=str(dataset_path),
        mode="sft",
    )
    dataset = load_dataset(dataset_path)
    resolved_sft_config = resolve_sft_config(sft_config)
    batch_size = resolved_sft_config.batch_size
    learning_rate = resolved_sft_config.learning_rate
    lora_rank = resolved_sft_config.lora_rank
    max_length = resolved_sft_config.max_length
    num_epochs = resolved_sft_config.num_epochs
    save_every = resolved_sft_config.save_every
    conversations = dataset.build_conversations(training_environment, contract_text)
    if not conversations:
        raise RuntimeError(f"No SFT records found in {dataset_path}")

    tokenizer = get_tokenizer(TRAINING_BASE_MODEL)
    renderer = renderers.get_renderer(TRAINING_RENDERER_NAME, tokenizer)
    service_client = tinker.ServiceClient(base_url=base_url or None)
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    run_name = f"freesolo-sft-{log_dir.name}"
    run_config = {
        "phase": "sft",
        "contract_path": str(contract_path),
        "dataset_path": str(dataset_path),
        "environment": environment,
        "log_dir": str(log_dir),
        "base_model": TRAINING_BASE_MODEL,
        "renderer": TRAINING_RENDERER_NAME,
        "batch_size": batch_size,
        "learning_rate": learning_rate,
        "lora_rank": lora_rank,
        "max_length": max_length,
        "num_epochs": num_epochs,
        "save_every": save_every,
        "record_count": len(conversations),
    }
    stored_run = start_stored_training_run(
        phase="sft",
        name=run_name,
        description="Freesolo SFT training run",
        config=run_config,
    )
    wandb_run = None

    try:
        wandb_run = start_wandb_run(
            "sft",
            log_dir=log_dir,
            name=run_name,
            group=stored_run.run_id,
            tags=("freesolo", "sft"),
            config=run_config,
        )
        stored_run.link_wandb(wandb_run.url)

        resume_info = get_last_tinker_checkpoint(checkpoint_utils, log_dir)
        start_step = checkpoint_step(resume_info)

        resume_state_path = resolve_checkpoint_state_path(resume_info)
        if resume_state_path:
            training_client = (
                service_client.create_training_client_from_state_with_optimizer(
                    str(resume_state_path)
                )
            )
        else:
            training_client = service_client.create_lora_training_client(
                base_model=TRAINING_BASE_MODEL,
                rank=lora_rank,
            )
            start_step = 0

        batches_per_epoch = math.ceil(len(conversations) / batch_size)
        total_steps = max(1, num_epochs * batches_per_epoch)
        step = 0

        for epoch in range(num_epochs):
            for batch_index in range(batches_per_epoch):
                if step < start_step:
                    step += 1
                    continue

                batch = conversations[
                    batch_index * batch_size : (batch_index + 1) * batch_size
                ]
                datums = [
                    conversation_to_datum(
                        messages,
                        renderer,
                        max_length,
                        renderers.TrainOnWhat.ALL_ASSISTANT_MESSAGES,
                    )
                    for messages in batch
                ]

                warmup_steps = max(1, total_steps // 10)
                lr_multiplier = min(1.0, (step + 1) / warmup_steps)
                effective_learning_rate = learning_rate * lr_multiplier
                adam_params = tinker.AdamParams(
                    learning_rate=effective_learning_rate,
                    beta1=0.9,
                    beta2=0.95,
                    eps=1e-8,
                )

                fwd_bwd_future = training_client.forward_backward(
                    datums,
                    loss_fn="cross_entropy",
                )
                optim_step_future = training_client.optim_step(adam_params)
                fwd_bwd_result = fwd_bwd_future.result()
                optim_step_result = optim_step_future.result()
                metrics: dict[str, object] = {
                    "trainer/global_step": step,
                    "sft/epoch": epoch,
                    "sft/batch_index": batch_index,
                    "sft/batch_size": len(batch),
                    "sft/examples_seen": min(
                        len(conversations),
                        batch_index * batch_size + len(batch),
                    )
                    + (epoch * len(conversations)),
                    "sft/learning_rate": effective_learning_rate,
                    "sft/lr_multiplier": lr_multiplier,
                }
                metrics.update(
                    numeric_metrics_from_result("sft/forward_backward", fwd_bwd_result)
                )
                metrics.update(
                    numeric_metrics_from_result("sft/optim_step", optim_step_result)
                )
                wandb_run.log(metrics, step=step)

                if save_every > 0 and step > 0 and step % save_every == 0:
                    checkpoint_name = f"sft_{step:06d}"
                    save_tinker_checkpoint(
                        checkpoint_utils=checkpoint_utils,
                        training_client=training_client,
                        name=checkpoint_name,
                        log_dir=log_dir,
                        loop_state={"epoch": epoch, "step": step},
                    )
                    wandb_run.log(
                        {
                            "trainer/global_step": step,
                            "sft/checkpoint_saved": 1,
                            "sft/checkpoint_name": checkpoint_name,
                        },
                        step=step,
                    )

                step += 1

        save_tinker_checkpoint(
            checkpoint_utils=checkpoint_utils,
            training_client=training_client,
            name="final",
            log_dir=log_dir,
            loop_state={"epoch": num_epochs, "step": step},
        )
        wandb_run.summary_update(
            {
                "sft/final_step": step,
                "sft/final_checkpoint_name": "final",
                "sft/record_count": len(conversations),
            }
        )
        stored_run.complete()
    except BaseException as error:
        stored_run.fail(error)
        raise
    finally:
        if wandb_run is not None:
            wandb_run.finish()
    return 0


def main() -> int:
    args = _parse_args()
    dataset_path = required_path(args.dataset, "--dataset")
    return train_sft(
        contract_path=args.contract,
        dataset_path=dataset_path,
        environment=args.environment,
        log_dir=args.log_dir,
        base_url=args.base_url,
        sft_config=SftConfig(max_length=args.max_length),
    )


_parent_module = sys.modules.get("freesolo.training")
if _parent_module is not None:
    setattr(_parent_module, "train_sft", train_sft)
del _parent_module


if __name__ == "__main__":
    raise SystemExit(main())
