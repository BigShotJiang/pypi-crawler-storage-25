from dataclasses import dataclass
from pathlib import Path
from typing import Required, TypedDict

TRAINING_BASE_MODEL = "Qwen/Qwen3.6-35B-A3B"
TRAINING_RENDERER_NAME = "qwen3_5_disable_thinking"
DEFAULT_TRAINING_LORA_RANK = 64


@dataclass(frozen=True)
class SftConfig:
    batch_size: int | None = None
    learning_rate: float | None = None
    lora_rank: int | None = None
    max_length: int | None = None
    num_epochs: int | None = None
    save_every: int | None = None


@dataclass(frozen=True, slots=True)
class ResolvedSftConfig:
    batch_size: int
    learning_rate: float
    lora_rank: int
    max_length: int
    num_epochs: int
    save_every: int


def resolve_sft_config(config: SftConfig | None) -> ResolvedSftConfig:
    config = config or SftConfig()
    if config.max_length is None:
        raise ValueError(
            "SftConfig.max_length must be set explicitly. Choose a task-specific "
            "sequence length in generated freesolo/config.py instead of relying "
            "on an SDK default."
        )
    max_length = int(config.max_length)
    if max_length < 1:
        raise ValueError("SftConfig.max_length must be at least 1")
    lora_rank = int(
        config.lora_rank
        if config.lora_rank is not None
        else DEFAULT_TRAINING_LORA_RANK
    )
    if lora_rank < 1:
        raise ValueError("SftConfig.lora_rank must be at least 1")
    return ResolvedSftConfig(
        batch_size=int(config.batch_size if config.batch_size is not None else 16),
        learning_rate=float(
            config.learning_rate if config.learning_rate is not None else 1e-4
        ),
        lora_rank=lora_rank,
        max_length=max_length,
        num_epochs=int(config.num_epochs if config.num_epochs is not None else 1),
        save_every=int(config.save_every if config.save_every is not None else 50),
    )


class TrainSftOptions(TypedDict, total=False):
    dataset_path: Required[str | Path]
    contract_path: str | Path
    environment: str | None
    log_dir: str | Path
    base_url: str | None
    sft_config: SftConfig | None


class TrainGrpoOptions(TypedDict, total=False):
    dataset_path: Required[str | Path]
    contract_path: str | Path
    environment: str | None
    log_dir: str | Path
    sft_log_dir: str | Path
    sft_checkpoint_name: str
    sft_state_path: str | None
    reward_command: str | None
    base_url: str | None


__all__ = [
    "DEFAULT_TRAINING_LORA_RANK",
    "TRAINING_BASE_MODEL",
    "TRAINING_RENDERER_NAME",
    "ResolvedSftConfig",
    "SftConfig",
    "TrainGrpoOptions",
    "TrainSftOptions",
    "resolve_sft_config",
]
