# Training

Training helpers run SFT and GRPO with the repo environment adapter.

## Public Imports

```python
from freesolo.training import GrpoConfig, SftConfig, train_grpo, train_sft
```

`GrpoConfig` belongs here because it controls training behavior. Do not import
it from `freesolo.environments`.
`TrainSftOptions` and `TrainGrpoOptions` are exported for callers that want
typed `**kwargs` dictionaries; generated repos usually do not need them.

## Generated Repo Pattern

Generated `freesolo/config.py` should define:

```python
from freesolo.training import GrpoConfig, SftConfig

ENVIRONMENT_REFERENCE = "freesolo/environment.py:load_environment"
CONTRACT_PATH = "freesolo/TRAINING_CONTRACT.md"
SFT_DATASET_PATH = "runs/sft/train.jsonl"
GRPO_DATASET_PATH = "runs/grpo/train.jsonl"
SFT_LOG_DIR = "runs/sft"
GRPO_LOG_DIR = "runs/grpo"
SFT_CONFIG = SftConfig(max_length=32768, ...)
GRPO_CONFIG = GrpoConfig(max_tokens=1024, ...)
```

The SDK pins trainable runs to `Qwen/Qwen3.6-35B-A3B` with the
`qwen3_5_disable_thinking` renderer and a default LoRA rank of 64; generated
repos should not define or expose a base-model, renderer, or routine LoRA-rank
setting.

Generated `freesolo/training.py` should call package helpers:

```python
from freesolo.training import train_grpo, train_sft
from config import (
    CONTRACT_PATH,
    ENVIRONMENT_REFERENCE,
    GRPO_DATASET_PATH,
    GRPO_LOG_DIR,
    SFT_CONFIG,
    SFT_DATASET_PATH,
    SFT_LOG_DIR,
)


def run_sft() -> int:
    return train_sft(
        contract_path=CONTRACT_PATH,
        dataset_path=SFT_DATASET_PATH,
        environment=ENVIRONMENT_REFERENCE,
        log_dir=SFT_LOG_DIR,
        sft_config=SFT_CONFIG,
    )


def run_grpo() -> int:
    return train_grpo(
        contract_path=CONTRACT_PATH,
        dataset_path=GRPO_DATASET_PATH,
        environment=ENVIRONMENT_REFERENCE,
        log_dir=GRPO_LOG_DIR,
        sft_log_dir=SFT_LOG_DIR,
    )
```

Generated `freesolo/environment.py` should expose GRPO config through the
environment hook:

```python
from config import GRPO_CONFIG
from freesolo.environments import Environment
from freesolo.training import GrpoConfig


class RepoEnvironment(Environment):
    def get_grpo_config(self) -> GrpoConfig:
        return GRPO_CONFIG
```

## Agent Guidance

- Put SFT hyperparameters in `SFT_CONFIG = SftConfig(...)` in generated config.
- Set `SFT_CONFIG.max_length` explicitly; there is no SDK default sequence
  length.
- Omit `SFT_CONFIG.lora_rank` unless you are intentionally running a controlled
  adapter-size experiment. The SDK standard default is 64 for
  `Qwen/Qwen3.6-35B-A3B`.
- Put GRPO hyperparameters in `GRPO_CONFIG = GrpoConfig(...)` in generated config.
- Set `GRPO_CONFIG.max_tokens` explicitly; there is no SDK default generation
  limit.
- Have `Environment.get_grpo_config()` return `GRPO_CONFIG`.
- Always pass `environment=ENVIRONMENT_REFERENCE`.
- Do not add model-selection or renderer-selection flags, config fields,
  `base_model=`, or renderer override arguments; SDK training is pinned to
  `Qwen/Qwen3.6-35B-A3B` with `qwen3_5_disable_thinking`.
- Do not duplicate trainer internals in generated repos.
- Do not add CLI flags or function override parameters for repo config.
