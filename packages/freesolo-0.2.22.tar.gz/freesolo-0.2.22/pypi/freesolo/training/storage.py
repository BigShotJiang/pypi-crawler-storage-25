from __future__ import annotations

from contextlib import suppress
from dataclasses import dataclass
from typing import Any

from freesolo.utils.storage import FreesoloStorageClient


@dataclass(frozen=True)
class StoredTrainingRun:
    client: FreesoloStorageClient
    run_id: str

    def link_wandb(self, wandb_url: str | None) -> None:
        self.client.link_wandb(self.run_id, wandb_url)

    def complete(self) -> None:
        self.client.update_run(self.run_id, status="completed")

    def fail(self, error: BaseException) -> None:
        with suppress(Exception):
            # Preserve the original training exception for the caller.
            self.client.update_run(self.run_id, status="failed", error=str(error))


def start_stored_training_run(
    *,
    phase: str,
    name: str,
    description: str | None = None,
    config: dict[str, Any] | None = None,
) -> StoredTrainingRun:
    client = FreesoloStorageClient()
    initial_config = {
        **(config or {}),
        "phase": phase,
    }
    run_id = client.create_run(
        name=name,
        description=description,
        config=initial_config,
    )
    client.update_run(
        run_id,
        status="running",
        config=initial_config,
    )
    return StoredTrainingRun(client=client, run_id=run_id)
