import sys
from types import ModuleType

from .grpo.config import GrpoConfig
from .types import (
    DEFAULT_TRAINING_LORA_RANK,
    TRAINING_BASE_MODEL,
    TRAINING_RENDERER_NAME,
    SftConfig,
    TrainGrpoOptions,
    TrainSftOptions,
    resolve_sft_config,
)


class _TrainingModule(ModuleType):
    def __getattribute__(self, name: str) -> object:
        if name == "train_grpo":
            from .train_grpo import train_grpo

            return train_grpo
        if name == "train_sft":
            from .train_sft import train_sft

            return train_sft
        return super().__getattribute__(name)


sys.modules[__name__].__class__ = _TrainingModule


__all__ = [
    "DEFAULT_TRAINING_LORA_RANK",
    "TRAINING_BASE_MODEL",
    "TRAINING_RENDERER_NAME",
    "GrpoConfig",
    "SftConfig",
    "TrainGrpoOptions",
    "TrainSftOptions",
    "resolve_sft_config",
    "train_grpo",
    "train_sft",
]
