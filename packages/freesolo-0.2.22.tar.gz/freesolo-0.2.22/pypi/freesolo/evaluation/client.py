from __future__ import annotations

import asyncio
import inspect
import io
import json
import tarfile
import time
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from ..utils.core import (
    _auth_headers,
    _env_value,
    _normalize_data_row,
    _require_api_key,
    _resolve_base_url,
    elapsed_ms,
    json_safe_value,
    require_non_empty,
)
from .judges import CustomScorer
from .responses import BinaryResponse, NumericResponse, ScorerResponse
from .results import ScorerData, ScoringResult
from .types import DataRow, EvaluationMetadata

if TYPE_CHECKING:
    from ..environments.base import Environment
    from ..environments.evaluation import EnvironmentGenerate, EnvironmentSource

RESULTS_PATH = "/api/evals/results"
SCORER_BUNDLES_PATH = "/api/evals/scorer-bundles"
TRAINING_JOB_ID_ENV = "FREESOLO_TRAINING_JOB_ID"
TRAINING_ROOT_JOB_ID_ENV = "FREESOLO_TRAINING_ROOT_JOB_ID"


class EvaluationClient:
    """Run scorers over data and post results to freesolo.

    Each call to ``run(name=...)`` appends a run to the eval identified by
    ``name``. The eval is auto-created on first post.

    Data row conventions:
        Each row in ``data`` is passed through to the backend verbatim. The
        following keys are recognized and lifted into typed columns on
        ``eval_tasks``: ``input``, ``actual_output``, ``expected_output``,
        ``image_url``. Any other keys are preserved on the row but will not
        populate the relational fields used by dashboards.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        internal_key: str | None = None,
        user_id: str | None = None,
        org_id: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = 300.0,
    ) -> None:
        self._api_key = api_key or _env_value("FREESOLO_API_KEY")
        self._internal_key = internal_key or _env_value("FREESOLO_INTERNAL_KEY")
        self._user_id = user_id or _env_value("FREESOLO_TRAINING_USER_ID")
        self._org_id = org_id or _env_value("FREESOLO_TRAINING_ORG_ID")
        if self._api_key:
            self._api_key = _require_api_key(
                self._api_key,
                error_message=_auth_error_message(),
            )
        else:
            if not self._internal_key or not self._user_id or not self._org_id:
                raise ValueError(_auth_error_message())
            self._internal_key = require_non_empty(
                self._internal_key or "",
                "FREESOLO_INTERNAL_KEY",
            )
            self._user_id = require_non_empty(
                self._user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            )
            self._org_id = require_non_empty(
                self._org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            )
        self._base_url = _resolve_base_url(base_url)
        self._timeout_seconds = timeout_seconds

    def run(
        self,
        *,
        name: str,
        data: Sequence[DataRow],
        scorers: Sequence[CustomScorer[Any]],
        metadata: EvaluationMetadata | None = None,
    ) -> list[ScoringResult]:
        if not name.strip():
            raise ValueError("name is required")
        scorer_list = list(scorers)
        if not scorer_list:
            raise ValueError("at least one scorer is required")
        for scorer in scorer_list:
            if not isinstance(scorer, CustomScorer):
                raise TypeError("all scorers must be CustomScorer instances")

        rows = [_normalize_data_row(row, index) for index, row in enumerate(data)]
        if not rows:
            return []

        results = _score_rows(rows, scorer_list)
        run_id = self._post(
            name.strip(),
            results,
            metadata,
        )
        if run_id:
            for result in results:
                result.run_id = run_id
        return results

    def run_environment(
        self,
        *,
        name: str,
        source: EnvironmentSource,
        generate: EnvironmentGenerate,
        contract_path: str | Path = "TRAINING_CONTRACT.md",
        contract_text: str | None = None,
        environment: str | Environment | None = None,
        environment_kwargs: dict[str, object] | None = None,
        metadata: EvaluationMetadata | None = None,
        concurrency: int = 1,
    ) -> list[ScoringResult]:
        """Run a Freesolo Environment and upload DB-compatible eval results."""

        if not name.strip():
            raise ValueError("name is required")
        from ..environments.evaluation import _run_local_environment_evaluation

        results = _run_local_environment_evaluation(
            source=source,
            generate=generate,
            contract_path=contract_path,
            contract_text=contract_text,
            environment=environment,
            environment_kwargs=environment_kwargs,
            concurrency=concurrency,
        )
        if not results:
            return []
        run_id = self._post(
            name.strip(),
            results,
            metadata,
        )
        if run_id:
            for result in results:
                result.run_id = run_id
        return results

    def upload_scorer_bundle(
        self,
        *,
        name: str,
        files: Sequence[str | Path] | None = None,
        root: str | Path = ".",
        manifest: dict[str, Any] | None = None,
        manifest_path: str | Path | None = None,
        metadata: EvaluationMetadata | None = None,
        bundle_path: str | Path | None = None,
    ) -> str:
        """Package and upload the scorer implementation used by an eval.

        ``bundle_path`` may point to a prebuilt ``.tar.gz``/``.tgz`` archive. If
        omitted, ``files`` are archived relative to ``root``. The backend stores
        the archive as an immutable artifact and validates that it is a safe
        Python source bundle; it does not execute uploaded code.
        """

        if not name.strip():
            raise ValueError("name is required")
        manifest_payload = _manifest_payload(
            manifest=manifest,
            manifest_path=manifest_path,
            files=files,
        )
        if bundle_path is not None:
            archive_path = Path(bundle_path)
            archive_content = archive_path.read_bytes()
            filename = archive_path.name
        else:
            if files is None:
                raise ValueError("files or bundle_path is required")
            archive_content, filename = _build_scorer_bundle_archive(
                root=Path(root),
                files=files,
                manifest_path=manifest_path,
                manifest=manifest_payload,
            )

        with httpx.Client(timeout=self._timeout_seconds) as client:
            response = client.post(
                f"{self._base_url}{SCORER_BUNDLES_PATH}",
                headers=self._multipart_headers(),
                data={
                    "name": name.strip(),
                    "manifest": json.dumps(
                        json_safe_value(manifest_payload),
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    "metadata": json.dumps(
                        json_safe_value(metadata or {}),
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                },
                files={
                    "bundle": (
                        filename,
                        archive_content,
                        "application/gzip",
                    )
                },
            )
            if response.is_error:
                raise httpx.HTTPStatusError(
                    f"freesolo /api/evals/scorer-bundles returned "
                    f"{response.status_code}: {response.text}",
                    request=response.request,
                    response=response,
                )
            data = response.json()
        if not isinstance(data, dict):
            raise ValueError("freesolo scorer bundle response must be a JSON object")
        bundle_id = data.get("scorer_bundle_id")
        if not isinstance(bundle_id, str) or not bundle_id:
            raise ValueError("freesolo scorer bundle response missing scorer_bundle_id")
        return bundle_id

    def _post(
        self,
        name: str,
        results: list[ScoringResult],
        metadata: EvaluationMetadata | None,
    ) -> str | None:
        payload = {
            "name": name,
            "metadata": metadata,
            "results": [result.to_dict() for result in results],
        }
        with httpx.Client(timeout=self._timeout_seconds) as client:
            response = client.post(
                f"{self._base_url}{RESULTS_PATH}",
                headers=self._headers(),
                json=payload,
            )
            if response.is_error:
                # surface the server body — httpx's default error swallows it
                # and leaves users guessing what was wrong with their payload.
                raise httpx.HTTPStatusError(
                    f"freesolo /api/evals/results returned {response.status_code}: "
                    f"{response.text}",
                    request=response.request,
                    response=response,
                )
            data = response.json()
        if isinstance(data, dict):
            run_id = data.get("run_id")
            if run_id:
                return str(run_id)
        return None

    def _headers(self) -> dict[str, str]:
        if self._api_key:
            return _auth_headers(self._api_key)
        return {
            **self._internal_headers(),
            "Content-Type": "application/json",
        }

    def _multipart_headers(self) -> dict[str, str]:
        if self._api_key:
            return {"Authorization": f"Bearer {self._api_key}"}
        return self._internal_headers()

    def _internal_headers(self) -> dict[str, str]:
        return {
            "Authorization": (
                f"Bearer {require_non_empty(self._internal_key or '', 'FREESOLO_INTERNAL_KEY')}"
            ),
            "X-Freesolo-Org-Id": require_non_empty(
                self._org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            ),
            "X-Freesolo-User-Id": require_non_empty(
                self._user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            ),
            **_training_job_headers(),
        }


def run_local_evaluation(
    *,
    data: Sequence[DataRow],
    scorers: Sequence[CustomScorer[Any]],
) -> list[ScoringResult]:
    """Run scorers locally without uploading results to the Freesolo backend."""

    scorer_list = list(scorers)
    if not scorer_list:
        raise ValueError("at least one scorer is required")
    for scorer in scorer_list:
        if not isinstance(scorer, CustomScorer):
            raise TypeError("all scorers must be CustomScorer instances")

    rows = [_normalize_data_row(row, index) for index, row in enumerate(data)]
    if not rows:
        return []
    return _score_rows(rows, scorer_list)


def _training_job_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    job_id = (_env_value(TRAINING_JOB_ID_ENV) or "").strip()
    root_job_id = (_env_value(TRAINING_ROOT_JOB_ID_ENV) or job_id).strip()
    if job_id:
        headers["X-Freesolo-Training-Job-Id"] = job_id
    if root_job_id:
        headers["X-Freesolo-Training-Root-Job-Id"] = root_job_id
    return headers


def _manifest_payload(
    *,
    manifest: dict[str, Any] | None,
    manifest_path: str | Path | None,
    files: Sequence[str | Path] | None,
) -> dict[str, Any]:
    if manifest_path is not None:
        parsed = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
        if not isinstance(parsed, dict):
            raise ValueError("manifest_path must contain a JSON object")
        base = dict(parsed)
    else:
        base = dict(manifest or {})
    if manifest:
        base.update(manifest)
    if "entrypoint" not in base:
        base["entrypoint"] = "eval:build_scorers"
    if files is not None and "files" not in base:
        base["files"] = [Path(file).as_posix() for file in files]
    return base


def _build_scorer_bundle_archive(
    *,
    root: Path,
    files: Sequence[str | Path],
    manifest_path: str | Path | None,
    manifest: dict[str, Any],
) -> tuple[bytes, str]:
    root = root.expanduser().resolve()
    file_paths = [_resolve_bundle_file(root, file) for file in files]
    if manifest_path is not None:
        manifest_file = _resolve_bundle_file(root, manifest_path)
        if manifest_file not in file_paths:
            file_paths.append(manifest_file)

    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for path in file_paths:
            archive.add(path, arcname=_archive_name(root, path), recursive=False)
        manifest_bytes = json.dumps(
            json_safe_value(manifest),
            indent=2,
            sort_keys=True,
        ).encode("utf-8")
        info = tarfile.TarInfo("eval_manifest.json")
        info.size = len(manifest_bytes)
        info.mtime = int(time.time())
        archive.addfile(info, io.BytesIO(manifest_bytes))
    return buffer.getvalue(), "scorer-bundle.tar.gz"


def _resolve_bundle_file(root: Path, file: str | Path) -> Path:
    path = Path(file)
    resolved = path.expanduser().resolve() if path.is_absolute() else (root / path).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"scorer bundle file is outside root: {file}") from exc
    if not resolved.is_file():
        raise FileNotFoundError(f"scorer bundle file not found: {file}")
    return resolved


def _archive_name(root: Path, path: Path) -> str:
    relative = path.relative_to(root).as_posix()
    if not relative or relative.startswith("../") or "/../" in relative:
        raise ValueError(f"unsafe scorer bundle file path: {path}")
    return relative


def _score_rows(
    rows: list[DataRow],
    scorers: list[CustomScorer[Any]],
) -> list[ScoringResult]:
    started = time.monotonic()
    by_row: list[list[ScorerData]] = [[] for _ in rows]

    with ThreadPoolExecutor() as executor:
        futures = {}
        for index, row in enumerate(rows):
            for scorer in scorers:
                future = executor.submit(_score_one, scorer, row)
                futures[future] = index
        for future in as_completed(futures):
            by_row[futures[future]].append(future.result())

    duration = time.monotonic() - started
    results: list[ScoringResult] = []
    for index, row in enumerate(rows):
        scorer_data = sorted(by_row[index], key=lambda item: item.name)
        results.append(
            ScoringResult(
                success=all(item.success for item in scorer_data),
                scorers_data=scorer_data,
                data_object=row,
                run_duration=duration,
            )
        )
    return results


def _auth_error_message() -> str:
    return (
        "FREESOLO_API_KEY or FREESOLO_INTERNAL_KEY with FREESOLO_TRAINING_USER_ID "
        "and FREESOLO_TRAINING_ORG_ID is required for evaluations"
    )


def _score_one(scorer: CustomScorer[Any], row: DataRow) -> ScorerData:
    started = time.perf_counter()
    name = _scorer_label(scorer)
    try:
        raw = scorer.score(row)
        response: ScorerResponse
        response = asyncio.run(raw) if inspect.isawaitable(raw) else raw
        latency_ms = elapsed_ms(started)
        return _response_to_scorer_data(scorer, response, latency_ms=latency_ms)
    except Exception as exc:
        # record latency even on failure: the user still waited for that time.
        return ScorerData(
            name=name,
            success=False,
            error=f"{type(exc).__name__}: {exc}",
            latency_ms=elapsed_ms(started),
        )


def _response_to_scorer_data(
    scorer: CustomScorer[Any],
    response: ScorerResponse,
    *,
    latency_ms: int | None,
) -> ScorerData:
    threshold = scorer.threshold
    name = _scorer_label(scorer)
    if isinstance(response, BinaryResponse):
        score = 1.0 if response.value else 0.0
        threshold = 1.0
        success = bool(response.value)
    elif isinstance(response, NumericResponse):
        if threshold is None:
            raise ValueError(
                f'scorer "{name}" returned a NumericResponse but no '
                'threshold was provided. set "threshold" on the scorer.'
            )
        score = float(response.value)
        success = score >= threshold
    else:
        raise TypeError(f"unsupported scorer response: {type(response).__name__}")

    return ScorerData(
        name=name,
        success=success,
        value=response.value,
        score=score,
        threshold=threshold,
        reason=response.reason or None,
        return_type=response.return_type,
        latency_ms=latency_ms,
        total_tokens=response.total_tokens,
        metadata=response.metadata,
    )


def _scorer_label(scorer: CustomScorer[Any]) -> str:
    return scorer.name or type(scorer).__name__
