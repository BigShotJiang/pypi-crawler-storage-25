from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from ..responses import ScorerResponse
from ..types import DataRow

R = TypeVar("R", bound=ScorerResponse)


class CustomScorer(ABC, Generic[R]):
    """Base class for custom scorers.

    Subclasses implement `score`. The method may be async or sync; the runner
    handles both. `threshold` is used for numeric responses.
    """

    name: str | None = None
    threshold: float | None = None

    @abstractmethod
    async def score(self, row: DataRow) -> R:
        raise NotImplementedError
