from __future__ import annotations

from typing import Any

import httpx

from .core import (
    JsonObject,
    _auth_headers,
    _env_value,
    _require_api_key,
    _resolve_base_url,
    json_safe_value,
    require_non_empty,
    truncate_text,
)

AUTH_VERIFY_PATH = "/api/auth/verify"
RUNS_PATH = "/api/runs"
CODEX_LOGS_PATH = "/api/codex-logs"
DEFAULT_TIMEOUT_SECONDS = 300.0
MAX_ERROR_BODY_CHARS = 2_000
TRUNCATED_BODY_SUFFIX = "... [truncated]"
TRAINING_JOB_ID_ENV = "FREESOLO_TRAINING_JOB_ID"
TRAINING_ROOT_JOB_ID_ENV = "FREESOLO_TRAINING_ROOT_JOB_ID"


def _training_run_config(config: dict[str, Any] | None = None) -> JsonObject | None:
    merged = dict(config or {})
    job_id = (_env_value(TRAINING_JOB_ID_ENV) or "").strip()
    root_job_id = (_env_value(TRAINING_ROOT_JOB_ID_ENV) or job_id).strip()
    if job_id:
        merged.setdefault("training_agent_job_id", job_id)
    if root_job_id:
        merged.setdefault("training_agent_root_job_id", root_job_id)
    if not merged:
        return None
    safe_config = json_safe_value(merged)
    if not isinstance(safe_config, dict):
        return None
    return safe_config


def _training_job_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    job_id = (_env_value(TRAINING_JOB_ID_ENV) or "").strip()
    root_job_id = (_env_value(TRAINING_ROOT_JOB_ID_ENV) or job_id).strip()
    if job_id:
        headers["X-Freesolo-Training-Job-Id"] = job_id
    if root_job_id:
        headers["X-Freesolo-Training-Root-Job-Id"] = root_job_id
    return headers


class FreesoloStorageClient:
    """Small authenticated client for Freesolo run records."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        internal_key: str | None = None,
        user_id: str | None = None,
        org_id: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self.api_key = api_key or _env_value("FREESOLO_API_KEY")
        self.internal_key = internal_key or _env_value("FREESOLO_INTERNAL_KEY")
        self.user_id = user_id or _env_value("FREESOLO_TRAINING_USER_ID")
        self.org_id = org_id or _env_value("FREESOLO_TRAINING_ORG_ID")
        if not self.api_key:
            self.internal_key = require_non_empty(
                self.internal_key or "",
                "FREESOLO_INTERNAL_KEY",
            )
            self.user_id = require_non_empty(
                self.user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            )
            self.org_id = require_non_empty(
                self.org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            )
        else:
            self.api_key = _require_api_key(
                self.api_key,
                error_message=(
                    "FREESOLO_API_KEY or FREESOLO_INTERNAL_KEY with "
                    "FREESOLO_TRAINING_USER_ID and FREESOLO_TRAINING_ORG_ID is "
                    "required for Freesolo storage sync"
                ),
            )
        self.base_url = _resolve_base_url(base_url)
        self.timeout_seconds = timeout_seconds

    def verify_api_key(self) -> None:
        """Check authentication without creating platform data."""
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.get(
                f"{self.base_url}{AUTH_VERIFY_PATH}",
                headers=self._json_headers(),
            )
        _json_response(response, AUTH_VERIFY_PATH)

    def create_run(
        self,
        *,
        name: str,
        description: str | None = None,
        version: str | None = None,
        evaluator_ids: list[str] | tuple[str, ...] = (),
        model_id: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> str:
        payload: JsonObject = {"name": require_non_empty(name, "name")}
        if description:
            payload["description"] = description
        if version:
            payload["version"] = version
        if model_id:
            payload["model_id"] = model_id
        if evaluator_ids:
            payload["evaluator_ids"] = [str(value) for value in evaluator_ids]
        run_config = _training_run_config(config)
        if run_config:
            payload["config"] = run_config
        data = self._post_json(
            RUNS_PATH,
            payload,
        )
        return _response_id(data, "run_id")

    def update_run(
        self,
        run_id: str,
        *,
        status: str | None = None,
        error: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        payload: JsonObject = {}
        if status is not None:
            payload["status"] = require_non_empty(status, "status")
        if error is not None:
            payload["error"] = error
        if config is not None:
            payload["config"] = _training_run_config(config) or {}
        if not payload:
            return
        self._patch_json(
            f"{RUNS_PATH}/{require_non_empty(run_id, 'run_id')}",
            payload,
        )

    def link_wandb(self, run_id: str, wandb_url: str | None) -> None:
        if not wandb_url:
            return
        self._post_json(
            f"{RUNS_PATH}/{require_non_empty(run_id, 'run_id')}/wandb",
            {"wandb_url": require_non_empty(wandb_url, "wandb_url")},
        )

    def append_codex_log(self, content: str) -> str:
        data = self._post_json(
            CODEX_LOGS_PATH,
            {"content": require_non_empty(content, "content")},
        )
        return _response_id(data, "codex_log_id")

    def _post_json(
        self,
        path: str,
        payload: JsonObject,
    ) -> JsonObject:
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.post(
                f"{self.base_url}{path}",
                headers=self._json_headers(),
                json=payload,
            )
        return _json_response(response, path)

    def _patch_json(
        self,
        path: str,
        payload: JsonObject,
    ) -> JsonObject:
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.patch(
                f"{self.base_url}{path}",
                headers=self._json_headers(),
                json=payload,
            )
        return _json_response(response, path)

    def _json_headers(self) -> dict[str, str]:
        if self.api_key:
            return _auth_headers(self.api_key)
        return {
            **self._internal_headers(),
            "Content-Type": "application/json",
        }

    def _internal_headers(self) -> dict[str, str]:
        authorization = require_non_empty(
            self.internal_key or "",
            "FREESOLO_INTERNAL_KEY",
        )
        return {
            "Authorization": f"Bearer {authorization}",
            "X-Freesolo-User-Id": require_non_empty(
                self.user_id or "",
                "FREESOLO_TRAINING_USER_ID",
            ),
            "X-Freesolo-Org-Id": require_non_empty(
                self.org_id or "",
                "FREESOLO_TRAINING_ORG_ID",
            ),
            **_training_job_headers(),
        }


def _json_response(response: httpx.Response, path: str) -> JsonObject:
    if response.is_error:
        raise httpx.HTTPStatusError(
            f"freesolo {path} returned {response.status_code}: "
            f"{_response_error_body(response)}",
            request=response.request,
            response=response,
        )
    data = response.json()
    if not isinstance(data, dict):
        raise ValueError(f"freesolo {path} returned a non-object response")
    return data


def _response_id(data: JsonObject, key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"freesolo response missing {key}")
    return value


def _response_error_body(response: httpx.Response) -> str:
    body = response.text.strip()
    if len(body) <= MAX_ERROR_BODY_CHARS:
        return body
    return truncate_text(
        body,
        MAX_ERROR_BODY_CHARS + len(TRUNCATED_BODY_SUFFIX),
        suffix=TRUNCATED_BODY_SUFFIX,
    )
