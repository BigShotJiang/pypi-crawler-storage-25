from __future__ import annotations

from typing import Any

import httpx

from .core import _env_value, require_non_empty

DEFAULT_UPLOAD_URL = (
    "https://clado-ai--freesolo-tinker-deployment-fastapi-app.modal.run"
)
UPLOADS_PATH = "/deployments"
DEFAULT_TIMEOUT_SECONDS = 6 * 60 * 60
DEFAULT_POLL_SECONDS = 5.0
TERMINAL_DEPLOYMENT_STATUSES = {"succeeded", "failed"}


def _deployment_url(value: str | None = None) -> str:
    return (value or _env_value("FREESOLO_DEPLOYMENT_URL") or DEFAULT_UPLOAD_URL).rstrip("/")


def upload_tinker_checkpoint_to_huggingface(
    tinker_path: str,
    *,
    base_model: str,
    repo_name: str | None = None,
    deployment_url: str | None = None,
) -> dict[str, Any]:
    """Upload a Tinker checkpoint and wait for the Hugging Face adapter repo."""

    payload: dict[str, Any] = {
        "tinkerPath": _require_tinker_path(tinker_path),
        "baseModel": require_non_empty(base_model, "base_model"),
        "private": True,
    }
    if repo_name is not None:
        payload["repoName"] = require_non_empty(repo_name, "repo_name")
    with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as client:
        response = client.post(
            f"{_deployment_url(deployment_url)}{UPLOADS_PATH}/sync",
            json=payload,
        )
        return _json_response(response, "Hugging Face upload")


def deploy_tinker_lora_adapter(
    tinker_path: str,
    *,
    base_model: str,
    adapter_id: str | None = None,
    repo_name: str | None = None,
    deployment_url: str | None = None,
    private: bool = True,
) -> dict[str, Any]:
    """Queue a Tinker checkpoint export as a hosted LoRA adapter."""

    payload: dict[str, Any] = {
        "tinkerPath": _require_tinker_path(tinker_path),
        "baseModel": require_non_empty(base_model, "base_model"),
        "artifactType": "lora_adapter",
        "private": private,
    }
    if adapter_id is not None:
        payload["adapterId"] = require_non_empty(adapter_id, "adapter_id")
    if repo_name is not None:
        payload["repoName"] = require_non_empty(repo_name, "repo_name")
    with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as client:
        response = client.post(f"{_deployment_url(deployment_url)}{UPLOADS_PATH}", json=payload)
        return _json_response(response, "LoRA adapter deployment")


def get_deployment_job(
    job_id: str,
    *,
    deployment_url: str | None = None,
) -> dict[str, Any]:
    """Fetch a queued deployment job by id."""

    cleaned_job_id = require_non_empty(job_id, "job_id")
    with httpx.Client(timeout=60.0) as client:
        response = client.get(f"{_deployment_url(deployment_url)}{UPLOADS_PATH}/{cleaned_job_id}")
        return _json_response(response, "deployment job lookup")


def wait_for_deployment(
    job_id: str,
    *,
    deployment_url: str | None = None,
    poll_seconds: float = DEFAULT_POLL_SECONDS,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Poll a deployment job until it succeeds or fails."""

    import time

    deadline = time.monotonic() + timeout_seconds
    while True:
        job = get_deployment_job(job_id, deployment_url=deployment_url)
        status = job.get("status")
        if status in TERMINAL_DEPLOYMENT_STATUSES:
            if status == "failed":
                raise RuntimeError(f"Deployment job failed: {job.get('error') or job}")
            return job
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Deployment job {job_id!r} did not finish before timeout")
        time.sleep(poll_seconds)


def _require_tinker_path(value: str) -> str:
    cleaned = require_non_empty(value, "tinker_path")
    if not cleaned.startswith("tinker://"):
        raise ValueError("tinker_path must start with 'tinker://'")
    return cleaned


def _json_response(response: httpx.Response, action: str) -> dict[str, Any]:
    if response.is_error:
        raise httpx.HTTPStatusError(
            f"{action} returned {response.status_code}: {response.text}",
            request=response.request,
            response=response,
        )
    data = response.json()
    if not isinstance(data, dict):
        raise ValueError(f"{action} response must be a JSON object")
    return data


__all__ = [
    "deploy_tinker_lora_adapter",
    "get_deployment_job",
    "upload_tinker_checkpoint_to_huggingface",
    "wait_for_deployment",
]
