from __future__ import annotations

from typing import Any

import httpx

from .core import _env_value, require_non_empty

DEFAULT_HOSTING_URL = "https://clado-ai--freesolo-lora-hosting.modal.run"
DEFAULT_TIMEOUT_SECONDS = 300.0


def _hosting_url(value: str | None = None) -> str:
    return (value or _env_value("FREESOLO_HOSTING_URL") or DEFAULT_HOSTING_URL).rstrip("/")


class HostedLoraClient:
    """Client for Freesolo hosted LoRA adapter inference."""

    def __init__(
        self,
        *,
        hosting_url: str | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self.hosting_url = _hosting_url(hosting_url)
        self.timeout_seconds = timeout_seconds

    def list_adapters(self) -> dict[str, Any]:
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.get(f"{self.hosting_url}/adapters")
            return _json_response(response, "hosted adapter list")

    def generate(
        self,
        adapter_id: str,
        *,
        prompt: str | None = None,
        messages: list[dict[str, Any]] | None = None,
        max_tokens: int = 1024,
        temperature: float = 0.0,
        top_p: float = 0.95,
    ) -> dict[str, Any]:
        payload = _generation_payload(
            adapter_id,
            prompt=prompt,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
        )
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.post(f"{self.hosting_url}/generate", json=payload)
            return _json_response(response, "hosted LoRA generation")

    def chat_completion(
        self,
        adapter_id: str,
        messages: list[dict[str, Any]],
        *,
        max_tokens: int = 1024,
        temperature: float = 0.0,
        top_p: float = 0.95,
    ) -> dict[str, Any]:
        payload = {
            "model": require_non_empty(adapter_id, "adapter_id"),
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
        }
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.post(f"{self.hosting_url}/v1/chat/completions", json=payload)
            return _json_response(response, "hosted LoRA chat completion")


def generate_with_lora(
    adapter_id: str,
    *,
    prompt: str | None = None,
    messages: list[dict[str, Any]] | None = None,
    max_tokens: int = 1024,
    temperature: float = 0.0,
    top_p: float = 0.95,
    hosting_url: str | None = None,
) -> dict[str, Any]:
    return HostedLoraClient(hosting_url=hosting_url).generate(
        adapter_id,
        prompt=prompt,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
    )


def chat_completion_with_lora(
    adapter_id: str,
    messages: list[dict[str, Any]],
    *,
    max_tokens: int = 1024,
    temperature: float = 0.0,
    top_p: float = 0.95,
    hosting_url: str | None = None,
) -> dict[str, Any]:
    return HostedLoraClient(hosting_url=hosting_url).chat_completion(
        adapter_id,
        messages,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
    )


def _generation_payload(
    adapter_id: str,
    *,
    prompt: str | None,
    messages: list[dict[str, Any]] | None,
    max_tokens: int,
    temperature: float,
    top_p: float,
) -> dict[str, Any]:
    if prompt is None and messages is None:
        raise ValueError("prompt or messages is required")
    payload: dict[str, Any] = {
        "adapterId": require_non_empty(adapter_id, "adapter_id"),
        "maxTokens": max_tokens,
        "temperature": temperature,
        "topP": top_p,
    }
    if prompt is not None:
        payload["prompt"] = prompt
    if messages is not None:
        payload["messages"] = messages
    return payload


def _json_response(response: httpx.Response, action: str) -> dict[str, Any]:
    if response.is_error:
        raise httpx.HTTPStatusError(
            f"{action} returned {response.status_code}: {response.text}",
            request=response.request,
            response=response,
        )
    data = response.json()
    if not isinstance(data, dict):
        raise ValueError(f"{action} response must be a JSON object")
    return data


__all__ = [
    "HostedLoraClient",
    "chat_completion_with_lora",
    "generate_with_lora",
]
