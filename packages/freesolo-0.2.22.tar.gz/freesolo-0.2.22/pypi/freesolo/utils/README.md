# Utilities

Utilities are support APIs for generated repo entrypoints. Prefer the focused
helpers below over copying provider, storage, checkpoint, or W&B logic.

## Oracle Generation

```python
from freesolo.utils.oracle import generate_ground_truth_records
```

Use this from generated `freesolo/data.py` to create labeled records from raw
tasks and the approved contract. Pass `environment=ENVIRONMENT_REFERENCE` so
oracle prompt construction stays aligned with the repo environment. Pass
`max_tokens=...` explicitly from generated config; the SDK does not choose an
oracle output-token fallback.

## W&B

```python
from freesolo.utils.wandb import generate_wandb_run_id, start_wandb_run
```

Use W&B when `WANDB_API_KEY` is available. Never print or commit secret values.
Do not trust a user-provided `WANDB_RUN_ID`; generate a fresh id per run or let
the helper defaults do it.

## Checkpoints And Storage

Checkpoint/storage helpers are used by package training helpers. Dataset uploads
are platform-owned and only happen from the contract-page upload flow; generated
repos should use the job-provided dataset path instead of creating new dataset
records. Generated repos normally should not call lower-level checkpoint or
storage functions directly unless a package-level training helper explicitly
returns a path that must be recorded.

## Agent Guidance

- Use public helper functions instead of provider-specific rewrites.
- Keep generated repo configuration in `freesolo/config.py`.
- Keep secrets in the process environment only.
- Keep logs, checkpoints, generated datasets, and trackers under run artifact
  directories, not inside the SDK package.
