import { authHeaders, jsonSafeValue, resolveBaseUrl, type JsonObject } from "./core.js";

export type DataRow = Record<string, unknown>;
export type ScorerValue = string | number | boolean | null;

export interface ScorerData {
  name: string;
  success: boolean;
  value?: ScorerValue | undefined;
  score?: number | undefined;
  threshold?: number | undefined;
  reason?: string | undefined;
  error?: string | undefined;
  return_type?: "binary" | "numeric" | undefined;
  latency_ms?: number | undefined;
  total_tokens?: number | undefined;
  metadata?: JsonObject | undefined;
}

export interface ScoringResult {
  success: boolean;
  scorers_data: ScorerData[];
  data_object: JsonObject;
  run_id?: string | undefined;
  run_duration?: number | undefined;
}

export class BinaryResponse {
  readonly return_type = "binary" as const;
  value: boolean;
  reason: string;
  metadata: JsonObject;
  total_tokens?: number | undefined;

  constructor(options: { value: boolean; reason?: string; metadata?: JsonObject; total_tokens?: number }) {
    this.value = Boolean(options.value);
    this.reason = options.reason ?? "";
    this.metadata = options.metadata ?? {};
    this.total_tokens = options.total_tokens;
  }
}

export class NumericResponse {
  readonly return_type = "numeric" as const;
  value: number;
  reason: string;
  metadata: JsonObject;
  total_tokens?: number | undefined;

  constructor(options: { value: number; reason?: string; metadata?: JsonObject; total_tokens?: number }) {
    this.value = Number(options.value);
    this.reason = options.reason ?? "";
    this.metadata = options.metadata ?? {};
    this.total_tokens = options.total_tokens;
  }
}

export type ScorerResponse = BinaryResponse | NumericResponse;

export abstract class CustomScorer<R extends ScorerResponse = ScorerResponse> {
  name?: string;
  threshold?: number;

  abstract score(row: DataRow): Promise<R> | R;
}

export function runLocalEvaluation(options: {
  data: DataRow[];
  scorers: CustomScorer[];
}): Promise<ScoringResult[]> {
  return Promise.all(options.data.map((row, index) => scoreRow(normalizeRow(row, index), options.scorers)));
}

export const run_local_evaluation = runLocalEvaluation;

export class EvaluationClient {
  private readonly base_url: string;
  private readonly headers: Record<string, string>;
  private readonly uploadHeaders: Record<string, string>;

  constructor(options: {
    api_key?: string;
    internal_key?: string;
    user_id?: string;
    org_id?: string;
    base_url?: string;
  } = {}) {
    this.base_url = resolveBaseUrl(options.base_url);
    this.uploadHeaders = authHeaders(options);
    this.headers = {
      "Content-Type": "application/json",
      ...this.uploadHeaders,
    };
  }

  async run(options: {
    name: string;
    data: DataRow[];
    scorers: CustomScorer[];
    metadata?: JsonObject;
  }): Promise<ScoringResult[]> {
    if (!options.name.trim()) throw new Error("name is required");
    if (!options.scorers.length) throw new Error("at least one scorer is required");
    const started = performance.now();
    const results = await runLocalEvaluation({ data: options.data, scorers: options.scorers });
    const response = await fetch(`${this.base_url}/api/evals/results`, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify({
        name: options.name.trim(),
        metadata: jsonSafeValue(options.metadata ?? {}),
        results: results.map((result) => scoringResultToJson(result)),
      }),
    });
    if (!response.ok) {
      throw new Error(`freesolo /api/evals/results returned ${response.status}: ${await response.text()}`);
    }
    const payload = (await response.json()) as Record<string, unknown>;
    const runId = typeof payload.run_id === "string" ? payload.run_id : undefined;
    const duration = (performance.now() - started) / 1000;
    for (const result of results) {
      result.run_id = runId;
      result.run_duration = duration;
    }
    return results;
  }

  async uploadScorerBundle(options: {
    name: string;
    bundle: Blob | ArrayBuffer | Uint8Array;
    filename?: string;
    manifest: JsonObject;
    metadata?: JsonObject;
  }): Promise<string> {
    if (!options.name.trim()) throw new Error("name is required");
    const form = new FormData();
    const blob = options.bundle instanceof Blob ? options.bundle : bytesToBlob(options.bundle);
    form.set("name", options.name.trim());
    form.set("manifest", JSON.stringify(jsonSafeValue(options.manifest)));
    form.set("metadata", JSON.stringify(jsonSafeValue(options.metadata ?? {})));
    form.set("bundle", blob, options.filename ?? "scorer-bundle.tar.gz");
    const response = await fetch(`${this.base_url}/api/evals/scorer-bundles`, {
      method: "POST",
      headers: this.uploadHeaders,
      body: form,
    });
    if (!response.ok) {
      throw new Error(
        `freesolo /api/evals/scorer-bundles returned ${response.status}: ${await response.text()}`,
      );
    }
    const payload = (await response.json()) as Record<string, unknown>;
    if (typeof payload.scorer_bundle_id !== "string") {
      throw new Error("freesolo scorer bundle response missing scorer_bundle_id");
    }
    return payload.scorer_bundle_id;
  }
}

export const Evaluation_Client = EvaluationClient;

async function scoreRow(row: JsonObject, scorers: CustomScorer[]): Promise<ScoringResult> {
  const scorersData = await Promise.all(scorers.map((scorer) => scoreOne(scorer, row)));
  return {
    success: scorersData.every((item) => item.success),
    scorers_data: scorersData,
    data_object: row,
  };
}

async function scoreOne(scorer: CustomScorer, row: JsonObject): Promise<ScorerData> {
  const started = performance.now();
  const name = scorer.name ?? scorer.constructor.name;
  try {
    const response = await scorer.score(row);
    const threshold = scorer.threshold;
    const score = response.return_type === "binary" ? (response.value ? 1 : 0) : response.value;
    const success = response.return_type === "binary" ? response.value : threshold === undefined || response.value >= threshold;
    return compact<ScorerData>({
      name,
      success,
      value: response.value,
      score,
      threshold,
      reason: response.reason,
      return_type: response.return_type,
      latency_ms: elapsedMs(started),
      total_tokens: response.total_tokens,
      metadata: response.metadata,
    });
  } catch (error) {
    return compact<ScorerData>({
      name,
      success: false,
      error: `${error instanceof Error ? error.name : "Error"}: ${error instanceof Error ? error.message : String(error)}`,
      latency_ms: elapsedMs(started),
    });
  }
}

function normalizeRow(row: DataRow, index: number): JsonObject {
  const normalized = jsonSafeValue(row);
  if (!normalized || typeof normalized !== "object" || Array.isArray(normalized)) {
    return { input: normalized, row_index: index };
  }
  return normalized as JsonObject;
}

function scoringResultToJson(result: ScoringResult): JsonObject {
  return {
    success: result.success,
    scorers_data: jsonSafeValue(result.scorers_data),
    data_object: result.data_object,
  };
}

function elapsedMs(started: number): number {
  return Math.max(0, Math.round(performance.now() - started));
}

function compact<T extends object>(payload: T): T {
  const record = payload as Record<string, unknown>;
  for (const key of Object.keys(record)) {
    const value = record[key];
    if (value === undefined || value === null) delete record[key];
    if (Array.isArray(value) && value.length === 0) delete record[key];
    if (typeof value === "object" && value && !Array.isArray(value) && !Object.keys(value).length) {
      delete record[key];
    }
  }
  return payload;
}

function bytesToBlob(value: ArrayBuffer | Uint8Array): Blob {
  if (value instanceof ArrayBuffer) {
    return new Blob([value], { type: "application/gzip" });
  }
  const bytes = new Uint8Array(value.byteLength);
  bytes.set(value);
  return new Blob([bytes.buffer], { type: "application/gzip" });
}
