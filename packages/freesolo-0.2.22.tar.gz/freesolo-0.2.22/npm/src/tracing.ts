import { trace as otelTrace, SpanStatusCode, type Span } from "@opentelemetry/api";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-http";
import { resourceFromAttributes } from "@opentelemetry/resources";
import { BatchSpanProcessor } from "@opentelemetry/sdk-trace-base";
import { NodeTracerProvider } from "@opentelemetry/sdk-trace-node";

import { envValue, resolveBaseUrl, serializeAttribute } from "./core.js";

const OTEL_TRACER_NAME = "freesolo";
const OTLP_TRACE_INGEST_PATH = "/api/traces/ingest";

let configuredProvider: NodeTracerProvider | undefined;
let configuredScorerBundleId: string | undefined;

export interface SetupTracingOptions {
  project_name?: string;
  base_url?: string;
  api_key?: string;
  scorer_bundle_id?: string;
}

export interface TraceApiCallOptions {
  input?: unknown;
  provider?: string;
  model?: string;
  scorer_bundle_id?: string;
}

export class FreesoloTrace {
  constructor(private readonly span?: Span) {}

  setAttribute(key: string, value: unknown): void {
    if (value === undefined || value === null || !this.span) return;
    this.span.setAttribute(key, serializeAttribute(value));
  }

  set_attribute(key: string, value: unknown): void {
    this.setAttribute(key, value);
  }

  setOutput(value: unknown): void {
    this.setAttribute("trace.output", value);
  }

  set_output(value: unknown): void {
    this.setOutput(value);
  }
}

export function setupTracing(options: SetupTracingOptions = {}): boolean {
  if (configuredProvider) return true;

  const api_key = options.api_key ?? envValue("FREESOLO_API_KEY");
  if (!api_key) return false;

  configuredScorerBundleId = options.scorer_bundle_id ?? envValue("FREESOLO_SCORER_BUNDLE_ID");
  const project_name = options.project_name ?? envValue("FREESOLO_PROJECT_NAME") ?? "freesolo";

  const resourceAttributes: Record<string, string | number | boolean | string[]> = {
    "service.name": project_name,
    project_name,
    "telemetry.sdk.name": "freesolo",
  };
  if (configuredScorerBundleId) {
    resourceAttributes.scorer_bundle_id = configuredScorerBundleId;
  }

  const exporter = new OTLPTraceExporter({
    url: `${resolveBaseUrl(options.base_url)}${OTLP_TRACE_INGEST_PATH}`,
    headers: { Authorization: `Bearer ${api_key}` },
    timeoutMillis: 10000,
  });

  configuredProvider = new NodeTracerProvider({
    resource: resourceFromAttributes(resourceAttributes),
    spanProcessors: [new BatchSpanProcessor(exporter)],
  });
  configuredProvider.register();
  return true;
}

export const setup_tracing = setupTracing;

export async function traceApiCall<T>(
  name: string,
  options: TraceApiCallOptions,
  callback: (trace: FreesoloTrace) => Promise<T> | T,
): Promise<T> {
  if (!configuredProvider) {
    return await callback(new FreesoloTrace());
  }

  const tracer = otelTrace.getTracer(OTEL_TRACER_NAME);
  return await tracer.startActiveSpan(name, async (span) => {
    const trace = new FreesoloTrace(span);
    trace.setAttribute("trace.input", options.input);
    trace.setAttribute("gen_ai.system", options.provider);
    trace.setAttribute("llm.provider", options.provider);
    trace.setAttribute("gen_ai.request.model", options.model);
    trace.setAttribute("llm.model", options.model);
    trace.setAttribute("scorer_bundle_id", options.scorer_bundle_id ?? configuredScorerBundleId);
    try {
      return await callback(trace);
    } catch (error) {
      span.recordException(error as Error);
      span.setStatus({ code: SpanStatusCode.ERROR, message: String(error) });
      throw error;
    } finally {
      span.end();
    }
  });
}

export const trace_api_call = traceApiCall;

export async function forceFlush(timeoutMillis = 30000): Promise<boolean> {
  if (!configuredProvider) return false;
  await configuredProvider.forceFlush();
  return true;
}

export const force_flush = forceFlush;

export async function shutdown(): Promise<void> {
  if (!configuredProvider) return;
  await configuredProvider.shutdown();
  configuredProvider = undefined;
}

export function getTracer(name = OTEL_TRACER_NAME) {
  return otelTrace.getTracer(name);
}

export const get_tracer = getTracer;
