export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

export type JsonObject = { [key: string]: JsonValue };

export function envValue(name: string): string | undefined {
  const value = process.env[name]?.trim();
  return value ? value : undefined;
}

export function resolveBaseUrl(base_url?: string): string {
  const resolved = base_url ?? envValue("FREESOLO_BASE_URL") ?? "https://api.freesolo.co";
  return resolved.replace(/\/+$/, "");
}

export function authHeaders(options: {
  api_key?: string;
  internal_key?: string;
  user_id?: string;
  org_id?: string;
}): Record<string, string> {
  const api_key = options.api_key ?? envValue("FREESOLO_API_KEY");
  if (api_key) {
    return { Authorization: `Bearer ${api_key}` };
  }

  const internal_key = options.internal_key ?? envValue("FREESOLO_INTERNAL_KEY");
  const user_id = options.user_id ?? envValue("FREESOLO_TRAINING_USER_ID");
  const org_id = options.org_id ?? envValue("FREESOLO_TRAINING_ORG_ID");
  if (!internal_key || !user_id || !org_id) {
    throw new Error(
      "Freesolo auth requires FREESOLO_API_KEY or FREESOLO_INTERNAL_KEY with FREESOLO_TRAINING_USER_ID and FREESOLO_TRAINING_ORG_ID",
    );
  }
  return {
    "x-freesolo-internal-key": internal_key,
    "x-freesolo-user-id": user_id,
    "x-freesolo-org-id": org_id,
  };
}

export function jsonSafeValue(value: unknown, depth = 0): JsonValue {
  if (value === null || value === undefined) return null;
  if (typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") return Number.isFinite(value) ? value : String(value);
  if (typeof value === "bigint") return value.toString();
  if (depth >= 8) return String(value);
  if (Array.isArray(value)) return value.slice(0, 256).map((item) => jsonSafeValue(item, depth + 1));
  if (typeof value === "object") {
    const output: JsonObject = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>).slice(0, 256)) {
      output[key] = jsonSafeValue(item, depth + 1);
    }
    return output;
  }
  return String(value);
}

export function serializeAttribute(value: unknown, maxLength = 8192): string | number | boolean | string[] {
  const safe = jsonSafeValue(value);
  let serialized: string | number | boolean | string[];
  if (typeof safe === "string" || typeof safe === "number" || typeof safe === "boolean") {
    serialized = safe;
  } else if (Array.isArray(safe) && safe.every((item) => typeof item === "string")) {
    serialized = safe as string[];
  } else {
    serialized = JSON.stringify(safe);
  }
  if (typeof serialized === "string" && serialized.length > maxLength) {
    return `${serialized.slice(0, Math.max(0, maxLength - 3))}...`;
  }
  return serialized;
}
