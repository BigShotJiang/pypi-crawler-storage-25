import { afterEach, expect, test } from "bun:test";

import {
  BinaryResponse,
  CustomScorer,
  EvaluationClient,
  NumericResponse,
  runLocalEvaluation,
} from "../src/evaluation";

const originalFetch = globalThis.fetch;

afterEach(() => {
  globalThis.fetch = originalFetch;
  delete process.env.FREESOLO_API_KEY;
});

class NonEmpty extends CustomScorer<BinaryResponse> {
  name = "non_empty";

  score(row: Record<string, unknown>): BinaryResponse {
    return new BinaryResponse({
      value: Boolean(String(row.actual_output ?? "").trim()),
      reason: "checked",
      metadata: { source: "test" },
    });
  }
}

class AtLeast extends CustomScorer<NumericResponse> {
  name = "at_least";
  threshold = 0.5;

  score(row: Record<string, unknown>): NumericResponse {
    return new NumericResponse({ value: Number(row.score ?? 0) });
  }
}

class BrokenScorer extends CustomScorer<BinaryResponse> {
  name = "broken";

  score(): BinaryResponse {
    throw new Error("boom");
  }
}

test("runLocalEvaluation scores binary and numeric scorers", async () => {
  const results = await runLocalEvaluation({
    data: [{ actual_output: "ok", score: 0.75 }],
    scorers: [new NonEmpty(), new AtLeast()],
  });

  expect(results).toHaveLength(1);
  expect(results[0]?.success).toBe(true);
  expect(results[0]?.scorers_data.map((item) => item.name)).toEqual(["non_empty", "at_least"]);
  expect(results[0]?.scorers_data[0]?.metadata).toEqual({ source: "test" });
});

test("runLocalEvaluation records scorer failures", async () => {
  const results = await runLocalEvaluation({
    data: [{ actual_output: "ok" }],
    scorers: [new BrokenScorer()],
  });

  expect(results[0]?.success).toBe(false);
  expect(results[0]?.scorers_data[0]?.name).toBe("broken");
  expect(results[0]?.scorers_data[0]?.error).toBe("Error: boom");
});

test("EvaluationClient requires Freesolo auth", () => {
  expect(() => new EvaluationClient({ base_url: "https://api.example.test" })).toThrow(
    "Freesolo auth requires",
  );
});

test("EvaluationClient posts scoring results", async () => {
  const requests: Request[] = [];
  globalThis.fetch = ((input: RequestInfo | URL, init?: RequestInit) => {
    const request = new Request(input, init);
    requests.push(request);
    return Promise.resolve(
      new Response(JSON.stringify({ run_id: "run-1" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
  }) as typeof fetch;

  const results = await new EvaluationClient({
    api_key: "fs_test",
    base_url: "https://api.example.test/",
  }).run({
    name: "local-check",
    data: [{ actual_output: "ok" }],
    scorers: [new NonEmpty()],
    metadata: { suite: "unit" },
  });

  expect(results[0]?.run_id).toBe("run-1");
  expect(requests).toHaveLength(1);
  expect(requests[0]?.url).toBe("https://api.example.test/api/evals/results");
  expect(requests[0]?.headers.get("Authorization")).toBe("Bearer fs_test");
  const body = await requests[0]?.json();
  expect(body.name).toBe("local-check");
  expect(body.results[0].success).toBe(true);
});

test("EvaluationClient uploads scorer bundles with constructor auth", async () => {
  const requests: Request[] = [];
  globalThis.fetch = ((input: RequestInfo | URL, init?: RequestInit) => {
    const request = new Request(input, init);
    requests.push(request);
    return Promise.resolve(
      new Response(JSON.stringify({ scorer_bundle_id: "bundle-1" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
  }) as typeof fetch;

  const bundleId = await new EvaluationClient({
    api_key: "fs_upload",
    base_url: "https://api.example.test",
  }).uploadScorerBundle({
    name: "quality",
    bundle: new Uint8Array([1, 2, 3]),
    filename: "quality.tar.gz",
    manifest: { entrypoint: "eval:build_scorers" },
  });

  expect(bundleId).toBe("bundle-1");
  expect(requests[0]?.url).toBe("https://api.example.test/api/evals/scorer-bundles");
  expect(requests[0]?.headers.get("Authorization")).toBe("Bearer fs_upload");
  expect(requests[0]?.headers.get("Content-Type") ?? "").toContain("multipart/form-data");
});
