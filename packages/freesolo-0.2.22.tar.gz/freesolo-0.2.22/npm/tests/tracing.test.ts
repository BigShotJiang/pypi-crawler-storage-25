import { afterEach, expect, test } from "bun:test";

import { forceFlush, setupTracing, shutdown, traceApiCall } from "../src/tracing";

afterEach(async () => {
  await shutdown();
  delete process.env.FREESOLO_API_KEY;
  delete process.env.FREESOLO_SCORER_BUNDLE_ID;
  delete process.env.FREESOLO_PROJECT_NAME;
});

test("setupTracing is no-op safe without api key", () => {
  expect(setupTracing({ project_name: "search" })).toBe(false);
});

test("traceApiCall runs callback when tracing is disabled", async () => {
  const result = await traceApiCall(
    "openai.chat.completions",
    { input: { q: "founders" }, provider: "openai", model: "gpt-4o-mini" },
    (trace) => {
      trace.setOutput({ ok: true });
      return "done";
    },
  );

  expect(result).toBe("done");
  expect(await forceFlush()).toBe(false);
});

test("setupTracing accepts scorer bundle ids", async () => {
  expect(
    setupTracing({
      project_name: "search",
      api_key: "fs_test",
      base_url: "https://api.example.test",
      scorer_bundle_id: "bundle-1",
    }),
  ).toBe(true);
});
