from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
EXAMPLES_DIR = PACKAGE_ROOT / "examples"


def test_file_backed_eval_example_delegates_to_evaluation_client(
    monkeypatch,
    capsys,
) -> None:
    module = _load_example_module("evaluation_from_files.py")
    captured: dict[str, Any] = {}

    class FakeEvaluationClient:
        def run_environment(self, **kwargs: Any) -> list[Any]:
            captured.update(kwargs)
            scorer = SimpleNamespace(
                name="support_answer_quality",
                score=1.0,
                reason="ok",
            )
            return [
                SimpleNamespace(success=True, scorers_data=[scorer]) for _ in range(3)
            ]

    monkeypatch.setattr(module, "EvaluationClient", FakeEvaluationClient)
    monkeypatch.setattr(
        sys,
        "argv",
        ["evaluation_from_files.py", "--name", "support-environment-smoke-test"],
    )

    module.main()

    stdout = capsys.readouterr().out
    assert "support_answer_quality score=1.0" in stdout
    assert stdout.count("pass: support_answer_quality") == 3
    assert captured["name"] == "support-environment-smoke-test"
    assert captured["metadata"] == {"example": "evaluation_from_files"}


def test_gepa_prompt_example_runs_without_optimizer_extra() -> None:
    result = _run_example("gepa_prompt_example.py")

    assert "baseline_scores=[0.0, 0.0, 0.0]" in result.stdout
    assert "improved_scores=[1.0, 1.0, 1.0]" in result.stdout
    assert "proposed_prompt=Answer with the canonical support action" in result.stdout


def test_training_example_help_hides_contract_and_environment_flags() -> None:
    result = _run_example("training_sft_grpo.py", "--help")

    assert "--dataset" in result.stdout
    assert "--base-model" not in result.stdout
    assert "--contract" not in result.stdout
    assert "--environment" not in result.stdout


def test_training_example_delegates_to_sft_without_contract_or_environment(
    monkeypatch,
) -> None:
    module = _load_example_module("training_sft_grpo.py")
    captured: dict[str, Any] = {}

    def fake_train_sft(**kwargs: Any) -> int:
        captured.update(kwargs)
        return 17

    monkeypatch.setattr(module, "train_sft", fake_train_sft)
    monkeypatch.setattr(
        sys,
        "argv",
        ["training_sft_grpo.py", "sft", "--max-length", "4096"],
    )

    assert module.main() == 17
    assert captured["dataset_path"].endswith("examples/data/support_train.jsonl")
    assert captured["log_dir"] == "./logs/sft"
    assert captured["sft_config"].max_length == 4096
    assert "base_model" not in captured
    assert "contract_path" not in captured
    assert "environment" not in captured


def test_training_example_delegates_to_grpo_without_contract_or_environment(
    monkeypatch,
) -> None:
    module = _load_example_module("training_sft_grpo.py")
    captured: dict[str, Any] = {}

    def fake_train_grpo(**kwargs: Any) -> int:
        captured.update(kwargs)
        return 23

    monkeypatch.setattr(module, "train_grpo", fake_train_grpo)
    monkeypatch.setattr(sys, "argv", ["training_sft_grpo.py", "grpo"])

    assert module.main() == 23
    assert captured["dataset_path"].endswith("examples/data/support_train.jsonl")
    assert captured["log_dir"] == "./logs/grpo"
    assert captured["sft_log_dir"] == "./logs/sft"
    assert "base_model" not in captured
    assert "contract_path" not in captured
    assert "environment" not in captured


def _run_example(*args: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = _pythonpath_with_local_package(env)
    return subprocess.run(
        [
            sys.executable,
            *(str(EXAMPLES_DIR / arg) if arg.endswith(".py") else arg for arg in args),
        ],
        cwd=PACKAGE_ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )


def _load_example_module(filename: str) -> ModuleType:
    sys.path.insert(0, str(EXAMPLES_DIR))
    spec = importlib.util.spec_from_file_location(
        f"_freesolo_example_{Path(filename).stem}",
        EXAMPLES_DIR / filename,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load example module: {filename}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _pythonpath_with_local_package(env: dict[str, str]) -> str:
    entries = [str(PACKAGE_ROOT / "pypi"), str(EXAMPLES_DIR)]
    existing = env.get("PYTHONPATH")
    if existing:
        entries.append(existing)
    return os.pathsep.join(entries)
