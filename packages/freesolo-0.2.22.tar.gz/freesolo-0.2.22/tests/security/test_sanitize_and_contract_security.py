from __future__ import annotations

import base64

import pytest
from freesolo.contracts.markdown import build_oracle_messages, extract_contract_spec
from freesolo.datasets.records import load_records
from freesolo.tracing.sanitize import MAX_INLINE_IMAGE_BYTES, sanitize_value


def test_sanitize_omits_unsupported_inline_image_data_url() -> None:
    data_url = "data:image/svg+xml;base64," + base64.b64encode(b"<svg />").decode(
        "ascii"
    )

    sanitized = sanitize_value(data_url)

    assert sanitized["type"] == "data_url"
    assert sanitized["media_type"] == "image/svg+xml"
    assert sanitized["omitted_data_url_reason"] == "unsupported_image_media_type"
    assert "data_url" not in sanitized


def test_sanitize_omits_oversized_supported_inline_image() -> None:
    payload = base64.b64encode(b"x" * (MAX_INLINE_IMAGE_BYTES + 1)).decode("ascii")

    sanitized = sanitize_value(f"data:image/png;base64,{payload}")

    assert sanitized["type"] == "data_url"
    assert sanitized["media_type"] == "image/png"
    assert sanitized["omitted_data_url_reason"] == "image_too_large"
    assert sanitized["max_inline_image_bytes"] == MAX_INLINE_IMAGE_BYTES
    assert "data_url" not in sanitized


def test_sanitize_truncates_large_mappings_and_sequences() -> None:
    sanitized_mapping = sanitize_value({f"k{i}": i for i in range(60)})
    sanitized_sequence = sanitize_value(list(range(60)))

    assert sanitized_mapping["__truncated_items__"] == 10
    assert sanitized_sequence[-1] == {"type": "truncated_items", "count": 10}


def test_contract_spec_rejects_non_object_payload() -> None:
    contract_text = """
```freesolo-contract
["not", "an", "object"]
```
"""

    with pytest.raises(ValueError, match="JSON object"):
        extract_contract_spec(contract_text)


def test_contract_spec_accepts_raw_json_prompt_and_evaluations() -> None:
    contract_text = """
{
  "prompt": {"system": "Answer carefully.", "user": "Question: {query}"},
  "evaluations": [{"name": "correctness", "description": "Checks the answer."}]
}
"""

    spec = extract_contract_spec(contract_text)

    assert spec is not None
    assert spec["prompt"]["system"] == "Answer carefully."
    assert spec["evaluations"][0]["name"] == "correctness"


def test_oracle_messages_render_system_and_user_prompt_fields() -> None:
    contract_text = """
{
  "prompt": {"system": "Use evidence.", "user": "Task: {task}"},
  "evaluations": [{"name": "correctness", "description": "Checks the answer."}]
}
"""
    spec = extract_contract_spec(contract_text)

    assert build_oracle_messages("find it", contract_text, spec) == [
        {"role": "system", "content": "Use evidence."},
        {"role": "user", "content": "Task: find it"},
    ]


def test_load_records_rejects_non_object_jsonl_records(tmp_path) -> None:
    dataset_path = tmp_path / "bad.jsonl"
    dataset_path.write_text("[1, 2, 3]\n", encoding="utf-8")

    with pytest.raises(ValueError, match="Expected JSON object on line 1"):
        load_records(dataset_path)
