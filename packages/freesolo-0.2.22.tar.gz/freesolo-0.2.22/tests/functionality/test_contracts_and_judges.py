from __future__ import annotations

import pytest
from freesolo.contracts.markdown import (
    build_oracle_messages,
    extract_contract_spec,
    load_contract_spec,
    load_contract_text,
)


def test_contract_markdown_load_extract_and_render_paths(tmp_path) -> None:
    contract_path = tmp_path / "TRAINING_CONTRACT.md"
    contract_path.write_text(
        """
        Intro text.

        ```freesolo-contract
        {
          "prompt": {
            "messages": [
              {"role": "system", "content": "Answer using {task}"},
              {"role": "", "content": "Question: {input}"}
            ]
          }
        }
        ```
        """,
        encoding="utf-8",
    )

    contract_text = load_contract_text(contract_path)
    contract_spec = load_contract_spec(contract_path)

    assert "Intro text" in contract_text
    assert contract_spec is not None
    assert build_oracle_messages("find people", contract_text, contract_spec) == [
        {"role": "system", "content": "Answer using find people"},
        {"role": "user", "content": "Question: find people"},
    ]


def test_contract_spec_fallbacks_and_validation() -> None:
    system_user_spec = {"prompt": {"system": "System {query}", "user": "User {task}"}}
    assert build_oracle_messages("task text", "raw contract", system_user_spec) == [
        {"role": "system", "content": "System task text"},
        {"role": "user", "content": "User task text"},
    ]
    assert build_oracle_messages(
        "task text", "raw contract", {"reward_functions": []}
    ) == [
        {
            "role": "system",
            "content": '{\n  "reward_functions": []\n}',
        },
        {"role": "user", "content": "task text"},
    ]
    assert extract_contract_spec("plain markdown") is None
    assert extract_contract_spec("```freesolo-contract\n\n```") is None
    with pytest.raises(ValueError, match="JSON object"):
        extract_contract_spec("[1, 2, 3]")
