from __future__ import annotations

import pytest
from freesolo.datasets import (
    Dataset,
    TaskExample,
    load_dataset,
)
from freesolo.datasets.core import _build_conversation
from freesolo.datasets.records import load_task_examples
from freesolo.training import SftConfig


class _PromptBuilder:
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": prompt_text},
            {"role": "user", "content": example.task},
        ]


def test_load_task_examples_normalizes_records() -> None:
    examples = load_task_examples(
        [
            {
                "id": "task-1",
                "query": {"question": "continue?"},
                "metadata": {"split": "train"},
                "expected_output": {"answer": "yes"},
            }
        ]
    )

    assert examples == [
        TaskExample(
            record={
                "id": "task-1",
                "query": {"question": "continue?"},
                "metadata": {"split": "train"},
                "expected_output": {"answer": "yes"},
            },
            task='{\n  "question": "continue?"\n}',
            task_id="task-1",
            metadata={"split": "train"},
            expected_output={"answer": "yes"},
        )
    ]


def test_dataset_builds_conversations_from_examples() -> None:
    example = TaskExample(
        record={"task": "say yes", "expected_output": "yes"},
        task="say yes",
        expected_output="yes",
    )

    dataset = Dataset(examples=[example])

    assert dataset.build_conversations(_PromptBuilder(), "Follow the contract.") == [
        [
            {"role": "system", "content": "Follow the contract."},
            {"role": "user", "content": "say yes"},
            {"role": "assistant", "content": "yes"},
        ]
    ]


def test_load_dataset_preserves_source_order() -> None:
    dataset = load_dataset(
        [
            {"id": "1", "task": "first", "expected_output": "A"},
            {"id": "2", "task": "second", "expected_output": "B"},
        ],
    )

    assert [example.task for example in dataset.examples] == ["first", "second"]
    assert [example.expected_output for example in dataset.examples] == ["A", "B"]


def test_sft_config_lives_with_training_options() -> None:
    config = SftConfig(batch_size=8, learning_rate=1e-5)

    assert config.batch_size == 8
    assert config.learning_rate == 1e-5


def test_build_conversation_serializes_structured_outputs() -> None:
    example = TaskExample(
        record={"task": "return json", "expected_output": {"answer": "yes"}},
        task="return json",
        expected_output={"answer": "yes"},
    )

    assert _build_conversation(_PromptBuilder(), example, "Follow the contract.")[
        -1
    ] == {
        "role": "assistant",
        "content": '{\n  "answer": "yes"\n}',
    }


def test_build_conversation_requires_expected_output() -> None:
    example = TaskExample(record={"task": "say yes"}, task="say yes")

    try:
        _build_conversation(_PromptBuilder(), example, "Follow the contract.")
    except ValueError as exc:
        assert "ground_truth/expected_output/output/completion" in str(exc)
    else:
        raise AssertionError("build_conversation should reject unlabeled examples")


def test_load_task_examples_from_path_and_preserves_falsey_labels(tmp_path) -> None:
    path = tmp_path / "data.json"
    path.write_text(
        '[{"id":"zero","task":"count","expected_output":0},{"task":"flag","ground_truth":false}]',
        encoding="utf-8",
    )

    dataset = load_dataset(path)

    assert [example.task_id for example in dataset.examples] == ["zero", None]
    assert [example.expected_output for example in dataset.examples] == [0, False]


def test_load_dataset_keeps_task_example_instances() -> None:
    example = TaskExample(
        record={"task": "already normalized"}, task="already normalized"
    )

    dataset = load_dataset([example])

    assert dataset.examples == [example]
    assert dataset.examples[0] is example


def test_load_records_error_branches(tmp_path) -> None:
    missing_path = tmp_path / "missing.json"
    unsupported_path = tmp_path / "data.yaml"
    unsupported_path.write_text("task: hi\n", encoding="utf-8")
    invalid_jsonl_path = tmp_path / "bad.jsonl"
    invalid_jsonl_path.write_text("[1, 2]\n", encoding="utf-8")
    invalid_json_path = tmp_path / "bad.json"
    invalid_json_path.write_text('{"not_data": []}', encoding="utf-8")
    invalid_json_item_path = tmp_path / "bad-item.json"
    invalid_json_item_path.write_text("[1]", encoding="utf-8")

    with pytest.raises(FileNotFoundError, match="Input dataset not found"):
        load_dataset(missing_path)
    with pytest.raises(ValueError, match="Unsupported dataset extension"):
        load_dataset(unsupported_path)
    with pytest.raises(ValueError, match="Expected JSON object on line 1"):
        load_dataset(invalid_jsonl_path)
    with pytest.raises(ValueError, match="Expected a JSON array"):
        load_dataset(invalid_json_path)
    with pytest.raises(ValueError, match="Expected JSON object items"):
        load_dataset(invalid_json_item_path)
    with pytest.raises(ValueError, match="task, prompt, query, or input"):
        load_dataset([{"expected_output": "answer"}])
