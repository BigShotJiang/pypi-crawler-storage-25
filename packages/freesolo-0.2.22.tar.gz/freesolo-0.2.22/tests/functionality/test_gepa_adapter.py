from __future__ import annotations

import freesolo.gepa as gepa
import pytest
from freesolo.datasets import TaskExample
from freesolo.datasets.records import task_example_from_record
from freesolo.environments import Environment, RewardResult
from freesolo.gepa import DefaultReflectionAgent
from freesolo.gepa.adapter import (
    EnvironmentGEPAAdapter,
    EnvironmentGEPAOutput,
    _make_seed_candidate,
    _render_candidate_prompt,
)


class ToyEnvironment(Environment):
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[dict[str, str]]:
        return [{"role": "user", "content": f"{prompt_text}\n{example.task}"}]

    def score_response(
        self,
        example: TaskExample,
        response_text: str,
    ) -> RewardResult:
        return RewardResult(
            score=1.0 if response_text == example.expected_output else 0.0,
            metadata={"response": response_text},
        )


def test_gepa_adapter_evaluates_batch_and_captures_trajectories() -> None:
    environment = ToyEnvironment()
    examples = [
        task_example_from_record(
            {"id": "1", "task": "say yes", "expected_output": "yes"}
        ),
        task_example_from_record(
            {"id": "2", "task": "say no", "expected_output": "no"}
        ),
    ]
    adapter = EnvironmentGEPAAdapter(
        environment=environment,
        rollout=lambda context: EnvironmentGEPAOutput(
            response_text=context.example.expected_output,
            metadata={"candidate": context.candidate["prompt"]},
        ),
    )

    batch = adapter.evaluate(
        examples,
        _make_seed_candidate("Follow the instruction."),
        capture_traces=True,
    )

    assert batch.scores == [1.0, 1.0]
    assert batch.objective_scores == [
        {"environment_reward": 1.0},
        {"environment_reward": 1.0},
    ]
    assert [output.response_text for output in batch.outputs] == ["yes", "no"]
    assert batch.trajectories is not None
    assert [trajectory.reward.score for trajectory in batch.trajectories] == [1.0, 1.0]
    assert batch.trajectories[0].prompt_text == "Follow the instruction."


def test_gepa_adapter_turns_rollout_errors_into_failure_scores() -> None:
    environment = ToyEnvironment()
    example = task_example_from_record(
        {"id": "1", "task": "fail", "expected_output": "ok"}
    )

    def broken_rollout(context: object) -> str:
        raise RuntimeError("rollout failed")

    adapter = EnvironmentGEPAAdapter(
        environment=environment,
        rollout=broken_rollout,
        failure_score=0.25,
    )

    batch = adapter.evaluate([example], {"prompt": "Do it."}, capture_traces=True)

    assert batch.scores == [0.25]
    assert batch.outputs[0].response_text == ""
    assert batch.trajectories is not None
    assert batch.trajectories[0].error is not None
    assert "RuntimeError: rollout failed" in batch.trajectories[0].error


def test_render_candidate_prompt_prefers_named_component() -> None:
    assert _render_candidate_prompt({"prompt": "A", "reward": "B"}) == "A"
    assert _render_candidate_prompt({"only": "A"}) == "A"
    assert (
        _render_candidate_prompt(
            {"z": "last", "a": "first"},
            preferred_component="missing",
        )
        == "## a\nfirst\n\n## z\nlast"
    )


def test_gepa_reflection_exports_use_clear_names_only() -> None:
    assert hasattr(gepa, "DefaultReflectionAgent")
    assert hasattr(gepa, "ReflectionAgentProtocol")
    assert hasattr(gepa, "ReflectionGenerator")
    assert not hasattr(gepa, "REflectionAgent")
    assert not hasattr(gepa, "ReflectionAgent")


def test_default_reflection_agent_generates_candidate_updates() -> None:
    agent = DefaultReflectionAgent(generate=lambda prompt: '{"prompt": "Be precise."}')

    assert agent.propose_new_texts(
        {"prompt": "Be helpful."},
        {"prompt": []},
        ["prompt"],
    ) == {"prompt": "Be precise."}


def test_default_reflection_agent_rejects_single_component_json_alias() -> None:
    agent = DefaultReflectionAgent(
        generate=lambda prompt: '{"new_prompt": "Be precise."}'
    )

    with pytest.raises(ValueError, match="did not include any updated text"):
        agent.propose_new_texts(
            {"prompt": "Be helpful."},
            {"prompt": []},
            ["prompt"],
        )
