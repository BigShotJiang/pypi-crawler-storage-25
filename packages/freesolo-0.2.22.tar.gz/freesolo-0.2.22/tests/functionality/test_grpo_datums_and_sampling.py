from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest
from freesolo.training.grpo.datums import (
    build_importance_sampling_datum,
    centered_advantages,
    sample_group,
)
from freesolo.training.grpo.sampling import (
    SamplerState,
    ensure_sampling_client,
    save_sampler_checkpoint,
    session_id_from_tinker_path,
)


class _Future:
    def __init__(self, value=None, error: BaseException | None = None) -> None:
        self.value = value
        self.error = error

    def result(self):
        if self.error is not None:
            raise self.error
        return self.value


class _Renderer:
    def build_generation_prompt(self, _messages):
        return SimpleNamespace(to_ints=lambda: [10, 11])

    def parse_response(self, tokens):
        return {"content": f"decoded:{tokens[-1]}"}, None


class _SamplingClient:
    def __init__(self, results) -> None:
        self.results = list(results)

    def sample(self, **_kwargs):
        return _Future(self.results.pop(0))


class _Environment:
    def extract_response_text(self, parsed_message):
        return parsed_message["content"]


def test_centered_advantages_clip_and_unclipped() -> None:
    assert centered_advantages([1.0, 3.0, 10.0], advantage_clip=2.0) == [
        -2.0,
        pytest.approx(-5 / 3),
        2.0,
    ]
    assert centered_advantages([1.0, 3.0], advantage_clip=0) == [-1.0, 1.0]


def test_sample_group_collects_tokens_and_text() -> None:
    sequence_a = SimpleNamespace(tokens=[20, 21], logprobs=[-0.1, -0.2])
    sequence_b = SimpleNamespace(tokens=[30], logprobs=[-0.3])
    sampling_client = _SamplingClient(
        [
            SimpleNamespace(sequences=[sequence_a]),
            SimpleNamespace(sequences=[sequence_b]),
        ]
    )

    payloads, response_texts = asyncio.run(
        sample_group(
            sampling_client=sampling_client,
            renderer=_Renderer(),
            model_input=SimpleNamespace(),
            prompt_tokens=[10, 11],
            sampling_params=SimpleNamespace(),
            group_size=2,
            training_environment=_Environment(),
        )
    )

    assert payloads == [
        ([10, 11, 20, 21], [-0.1, -0.2], 0.0),
        ([10, 11, 30], [-0.3], 0.0),
    ]
    assert response_texts == ["decoded:21", "decoded:30"]


def test_sample_group_requires_logprobs() -> None:
    sequence = SimpleNamespace(tokens=[20], logprobs=None)
    sampling_client = _SamplingClient([SimpleNamespace(sequences=[sequence])])

    with pytest.raises(RuntimeError, match="logprobs"):
        asyncio.run(
            sample_group(
                sampling_client=sampling_client,
                renderer=_Renderer(),
                model_input=SimpleNamespace(),
                prompt_tokens=[10],
                sampling_params=SimpleNamespace(),
                group_size=1,
                training_environment=_Environment(),
            )
        )


class _FakeNp:
    int32 = "int32"
    float32 = "float32"

    @staticmethod
    def asarray(value, dtype):
        return {"value": list(value), "dtype": dtype}


class _FakeTensorData:
    @staticmethod
    def from_numpy(value):
        return {"tensor": value}


class _FakeModelInput:
    @staticmethod
    def from_ints(*, tokens):
        return {"tokens": tokens}


class _FakeTypes:
    ModelInput = _FakeModelInput

    @staticmethod
    def Datum(*, model_input, loss_fn_inputs):
        return {"model_input": model_input, "loss_fn_inputs": loss_fn_inputs}


def test_build_importance_sampling_datum_pads_prompt_observation() -> None:
    datum = build_importance_sampling_datum(
        tokens=[10, 11, 20, 21],
        logprobs=[-0.1, -0.2],
        prompt_tokens=[10, 11],
        advantage=0.75,
        np=_FakeNp,
        types=_FakeTypes,
        TensorData=_FakeTensorData,
    )

    assert datum["model_input"] == {"tokens": [10, 11, 20]}
    assert datum["loss_fn_inputs"]["target_tokens"]["tensor"] == {
        "value": [11, 20, 21],
        "dtype": "int32",
    }
    assert datum["loss_fn_inputs"]["logprobs"]["tensor"]["value"] == [0.0, -0.1, -0.2]
    assert datum["loss_fn_inputs"]["advantages"]["tensor"]["value"] == [0.0, 0.75, 0.75]


def test_build_importance_sampling_datum_rejects_length_mismatch() -> None:
    with pytest.raises(RuntimeError, match="GRPO datum lengths do not match"):
        build_importance_sampling_datum(
            tokens=[1, 2],
            logprobs=[-0.1],
            prompt_tokens=[1, 2, 3],
            advantage=1.0,
            np=_FakeNp,
            types=_FakeTypes,
            TensorData=_FakeTensorData,
        )


class _ConflictError(Exception):
    pass


class _TrainingClient:
    session_id = "session-1"

    def __init__(self, outcomes) -> None:
        self.outcomes = list(outcomes)
        self.names: list[str] = []

    def save_weights_for_sampler(self, *, name):
        self.names.append(name)
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, BaseException):
            return _Future(error=outcome)
        return _Future(SimpleNamespace(path=outcome))


class _WeightsApi:
    def __init__(self) -> None:
        self.deleted: list[str] = []

    def delete(self, *, path):
        self.deleted.append(path)


class _ServiceClient:
    def __init__(self) -> None:
        self.weights = _WeightsApi()
        self.created_paths: list[str] = []

    def create_sampling_client(self, *, model_path):
        self.created_paths.append(model_path)
        return {"model_path": model_path}


def test_save_sampler_checkpoint_deletes_conflict_and_records_session(
    monkeypatch,
) -> None:
    async def fake_sleep(_seconds):
        return None

    monkeypatch.setattr("freesolo.training.grpo.sampling.asyncio.sleep", fake_sleep)
    service_client = _ServiceClient()
    training_client = _TrainingClient(
        [
            _ConflictError("exists"),
            "tinker://session-1:train:0/sampler_weights/sample",
        ]
    )
    state = SamplerState()

    asyncio.run(
        save_sampler_checkpoint(
            service_client=service_client,
            training_client=training_client,
            state=state,
            checkpoint_name="sample",
            conflict_error_type=_ConflictError,
        )
    )

    assert state.current_path == "tinker://session-1:train:0/sampler_weights/sample"
    assert state.session_id == "session-1"
    assert service_client.weights.deleted == [
        "tinker://session-1:train:0/sampler_weights/sample"
    ]


def test_ensure_sampling_client_reuses_current_path_between_save_intervals() -> None:
    service_client = _ServiceClient()
    training_client = _TrainingClient([])
    state = SamplerState(
        current_path="tinker://session-2:train:0/sampler_weights/sample"
    )

    sampling_client = asyncio.run(
        ensure_sampling_client(
            service_client=service_client,
            training_client=training_client,
            state=state,
            global_step=3,
            save_every=5,
            conflict_error_type=_ConflictError,
        )
    )

    assert sampling_client == {"model_path": state.current_path}
    assert service_client.created_paths == [state.current_path]
    assert session_id_from_tinker_path(state.current_path) == "session-2"
    assert session_id_from_tinker_path("not-a-tinker-path") is None
