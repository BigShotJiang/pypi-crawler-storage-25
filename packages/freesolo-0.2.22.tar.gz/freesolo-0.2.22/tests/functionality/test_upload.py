from __future__ import annotations

from typing import Any, ClassVar

import httpx
import pytest
from freesolo.utils.upload import (
    DEFAULT_TIMEOUT_SECONDS,
    DEFAULT_UPLOAD_URL,
    UPLOADS_PATH,
    upload_tinker_checkpoint_to_huggingface,
)


class _FakeHttpClient:
    calls: ClassVar[list[dict[str, Any]]] = []
    status_code: ClassVar[int] = 200
    response_json: ClassVar[Any] = {"repoId": "org/model"}
    response_text: ClassVar[str] = ""

    def __init__(self, *, timeout: float) -> None:
        self.timeout = timeout

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        self.calls.append({"url": url, "timeout": self.timeout, **kwargs})
        request = httpx.Request("POST", url)
        if self.status_code >= 400:
            return httpx.Response(
                self.status_code,
                text=self.response_text,
                request=request,
            )
        return httpx.Response(
            self.status_code, json=self.response_json, request=request
        )


@pytest.fixture(autouse=True)
def _reset_fake_client() -> None:
    _FakeHttpClient.calls = []
    _FakeHttpClient.status_code = 200
    _FakeHttpClient.response_json = {"repoId": "org/model"}
    _FakeHttpClient.response_text = ""


def test_upload_tinker_checkpoint_to_huggingface_posts_upload_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.upload.httpx.Client", _FakeHttpClient)

    result = upload_tinker_checkpoint_to_huggingface(
        "tinker://run/sampler_weights/final",
        base_model="Qwen/Qwen3.5-35B-A3B",
        repo_name="org/model",
    )

    assert result == {"repoId": "org/model"}
    assert _FakeHttpClient.calls == [
        {
            "url": f"{DEFAULT_UPLOAD_URL}{UPLOADS_PATH}/sync",
            "timeout": DEFAULT_TIMEOUT_SECONDS,
            "json": {
                "tinkerPath": "tinker://run/sampler_weights/final",
                "baseModel": "Qwen/Qwen3.5-35B-A3B",
                "private": True,
                "repoName": "org/model",
            },
        }
    ]


def test_upload_tinker_checkpoint_to_huggingface_requires_tinker_path() -> None:
    with pytest.raises(ValueError, match="tinker_path must start"):
        upload_tinker_checkpoint_to_huggingface(
            "https://example.com/model",
            base_model="Qwen/Qwen3.5-35B-A3B",
        )


def test_upload_tinker_checkpoint_to_huggingface_surfaces_server_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.upload.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.status_code = 500
    _FakeHttpClient.response_text = "upload failed"

    with pytest.raises(httpx.HTTPStatusError, match="Hugging Face upload returned 500"):
        upload_tinker_checkpoint_to_huggingface(
            "tinker://run/sampler_weights/final",
            base_model="Qwen/Qwen3.5-35B-A3B",
        )
