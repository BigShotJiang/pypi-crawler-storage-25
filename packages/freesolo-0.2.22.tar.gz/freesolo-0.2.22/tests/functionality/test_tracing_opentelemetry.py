from __future__ import annotations

import freesolo
import freesolo.tracing as tracing
import freesolo.tracing.otel as otel
import pytest
from freesolo.tracing import (
    configure_tracer,
    set_trace_score,
    setup_tracing,
    trace_api_call,
)
from freesolo.tracing.otel import _FreesoloSpanExporter, _sanitize_otel_attributes
from opentelemetry.sdk.trace.export import SpanExportResult


class FakeOTLPSpanExporter:
    def __init__(self, *, endpoint, headers, timeout):
        self.endpoint = endpoint
        self.headers = headers
        self.timeout = timeout
        self.exported_spans = None
        self.flushed_with = None
        self.shutdown_called = False

    def export(self, spans):
        self.exported_spans = spans
        return SpanExportResult.SUCCESS

    def shutdown(self):
        self.shutdown_called = True

    def force_flush(self, timeout_millis=30_000):
        self.flushed_with = timeout_millis
        return True


def test_freesolo_span_exporter_delegates_to_native_otlp(monkeypatch) -> None:
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )

    exporter = _FreesoloSpanExporter(
        base_url="https://api.example.test/",
        api_key="fs_test",
        headers={"X-Test": "1"},
        timeout_seconds=3.5,
    )
    result = exporter.export([])

    assert result is SpanExportResult.SUCCESS
    assert exporter._delegate.endpoint == "https://api.example.test/api/traces/ingest"
    assert exporter._delegate.headers["Authorization"] == "Bearer fs_test"
    assert exporter._delegate.headers["X-Test"] == "1"
    assert exporter._delegate.timeout == 3.5


def test_freesolo_span_exporter_requires_api_key(monkeypatch) -> None:
    monkeypatch.delenv("FREESOLO_API_KEY", raising=False)

    with pytest.raises(ValueError, match="Freesolo OpenTelemetry export requires"):
        _FreesoloSpanExporter(base_url="https://api.example.test")


def test_configure_tracer_sanitizes_resource_attrs_and_sets_limits(
    monkeypatch,
) -> None:
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )

    provider = configure_tracer(
        base_url="https://api.example.test",
        api_key="fs_test",
        set_global=False,
        batch=False,
        project_name="search",
        resource_attributes={
            "nested": {"b": 2, "a": 1},
            "long": "x" * 40,
            "missing": None,
        },
        scorer_bundle_id="bundle-1",
        max_attribute_length=32,
        max_span_attributes=7,
    )

    attrs = provider.resource.attributes
    assert attrs["service.name"] == "search"
    assert attrs["project_name"] == "search"
    assert attrs["telemetry.sdk.name"] == "freesolo"
    assert attrs["nested"] == '{"a": 1, "b": 2}'
    assert attrs["long"] == f"{'x' * 29}..."
    assert attrs["scorer_bundle_id"] == "bundle-1"
    assert "missing" not in attrs
    assert provider._span_limits.max_span_attributes == 7
    assert provider._span_limits.max_span_attribute_length == 32


def test_configure_tracer_reads_scorer_bundle_from_env(monkeypatch) -> None:
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )
    monkeypatch.setenv("FREESOLO_SCORER_BUNDLE_ID", "bundle-env")

    provider = configure_tracer(
        base_url="https://api.example.test",
        api_key="fs_test",
        set_global=False,
        batch=False,
    )

    attrs = provider.resource.attributes
    assert attrs["scorer_bundle_id"] == "bundle-env"


def test_setup_tracing_is_noop_without_api_key(monkeypatch) -> None:
    monkeypatch.setattr("freesolo.tracing.otel._configured_provider", None)
    monkeypatch.delenv("FREESOLO_API_KEY", raising=False)

    assert setup_tracing(project_name="copywriter") is False


def test_setup_tracing_configures_with_scorer_bundle(monkeypatch) -> None:
    monkeypatch.setattr("freesolo.tracing.otel._configured_provider", None)
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )

    assert (
        setup_tracing(
            project_name="copywriter",
            api_key="fs_test",
            base_url="https://api.example.test",
            scorer_bundle_id="bundle-1",
        )
        is True
    )

    provider = otel._configured_provider
    assert provider is not None
    attrs = provider.resource.attributes
    assert attrs["service.name"] == "copywriter"
    assert attrs["project_name"] == "copywriter"
    assert attrs["scorer_bundle_id"] == "bundle-1"


def test_trace_api_call_sets_standard_attributes(monkeypatch) -> None:
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )
    provider = configure_tracer(
        base_url="https://api.example.test",
        api_key="fs_test",
        set_global=False,
        batch=False,
        scorer_bundle_id="configured-bundle",
    )

    with trace_api_call(
        "copywriter.anthropic.messages.create",
        input={"topic": "lost deal"},
        provider="anthropic",
        model="claude-sonnet-4-6",
    ) as trace:
        trace.set_output("post text")

    processor = provider._active_span_processor._span_processors[0]
    span = processor.span_exporter._delegate.exported_spans[0]
    attrs = span.attributes
    assert attrs["trace.input"] == '{"topic": "lost deal"}'
    assert attrs["trace.output"] == "post text"
    assert attrs["gen_ai.system"] == "anthropic"
    assert attrs["gen_ai.request.model"] == "claude-sonnet-4-6"
    assert attrs["scorer_bundle_id"] == "configured-bundle"


def test_sanitize_otel_attributes_serializes_messy_values() -> None:
    attrs = _sanitize_otel_attributes(
        {
            "ok": ["a", "b"],
            "complex": {"z": object()},
            "none": None,
        },
        serializer=lambda value: "serialized",
    )

    assert attrs["ok"] == ["a", "b"]
    assert attrs["complex"] == "serialized"
    assert "none" not in attrs


def test_set_trace_score_sets_current_span_attributes(monkeypatch) -> None:
    monkeypatch.setattr(
        "freesolo.tracing.otel.OTLPSpanExporter",
        FakeOTLPSpanExporter,
    )
    provider = configure_tracer(
        base_url="https://api.example.test",
        api_key="fs_test",
        set_global=False,
        batch=False,
    )
    tracer = provider.get_tracer("test")

    with tracer.start_as_current_span("score") as span:
        set_trace_score(
            score=0.75,
            success=True,
            scorer_bundle_id="bundle-1",
            scorers_data=[{"name": "quality", "score": 0.75, "success": True}],
        )

    attrs = span.attributes
    assert attrs["trace.score"] == 0.75
    assert attrs["trace.success"] is True
    assert attrs["scorer_bundle_id"] == "bundle-1"
    assert "quality" in attrs["trace.scorers_data"]


def test_tracing_exports_are_namespaced_and_explicit() -> None:
    expected_exports = {
        "configure_tracer",
        "force_flush",
        "get_tracer",
        "set_trace_score",
        "setup_tracing",
        "shutdown",
        "trace_api_call",
    }

    assert set(tracing.__all__) == expected_exports
    assert set(otel.__all__) == expected_exports


def test_public_helpers_are_not_top_level_exports() -> None:
    assert freesolo.__all__ == []
    assert not hasattr(freesolo, "BinaryResponse")
    assert not hasattr(freesolo, "CustomScorer")
    assert not hasattr(freesolo, "NumericResponse")
    assert not hasattr(freesolo, "configure_tracer")
    assert not hasattr(freesolo, "get_tracer")
    assert not hasattr(freesolo, "set_trace_score")
    assert not hasattr(freesolo, "force_flush")
    assert not hasattr(freesolo, "shutdown")
