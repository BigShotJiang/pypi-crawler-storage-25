from __future__ import annotations

from typing import Any, ClassVar

import httpx
from freesolo.utils.hosting import HostedLoraClient
from freesolo.utils.upload import (
    deploy_tinker_lora_adapter,
    get_deployment_job,
    upload_tinker_checkpoint_to_huggingface,
)


class _FakeHttpClient:
    requests: ClassVar[list[dict[str, Any]]] = []

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.timeout = kwargs.get("timeout")

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: Any) -> None:
        return None

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        self.requests.append({"method": "POST", "url": url, **kwargs})
        request = httpx.Request("POST", url)
        if url.endswith("/deployments"):
            return httpx.Response(
                202,
                json={"ok": True, "jobId": "job-1", "status": "queued"},
                request=request,
            )
        if url.endswith("/deployments/sync"):
            return httpx.Response(
                200,
                json={
                    "ok": True,
                    "repoId": "Freesolo-Co/adapter",
                    "adapterId": "adapter",
                    "url": "https://huggingface.co/Freesolo-Co/adapter",
                },
                request=request,
            )
        if url.endswith("/generate"):
            return httpx.Response(
                200,
                json={"ok": True, "adapterId": "adapter", "text": "done"},
                request=request,
            )
        if url.endswith("/v1/chat/completions"):
            return httpx.Response(
                200,
                json={"choices": [{"message": {"content": "done"}}]},
                request=request,
            )
        return httpx.Response(404, text="not found", request=request)

    def get(self, url: str, **kwargs: Any) -> httpx.Response:
        self.requests.append({"method": "GET", "url": url, **kwargs})
        request = httpx.Request("GET", url)
        if url.endswith("/deployments/job-1"):
            return httpx.Response(
                200,
                json={"ok": True, "jobId": "job-1", "status": "succeeded"},
                request=request,
            )
        if url.endswith("/adapters"):
            return httpx.Response(200, json={"ok": True, "adapters": []}, request=request)
        return httpx.Response(404, text="not found", request=request)


def test_deploy_tinker_lora_adapter_queues_job(monkeypatch) -> None:
    _FakeHttpClient.requests = []
    monkeypatch.setattr("freesolo.utils.upload.httpx.Client", _FakeHttpClient)

    response = deploy_tinker_lora_adapter(
        "tinker://run/sampler_weights/final",
        base_model="openai/gpt-oss-20b",
        adapter_id="adapter",
        deployment_url="https://deploy.test",
    )

    assert response["jobId"] == "job-1"
    assert _FakeHttpClient.requests[0]["url"] == "https://deploy.test/deployments"
    assert _FakeHttpClient.requests[0]["json"]["adapterId"] == "adapter"


def test_blocking_upload_uses_sync_endpoint(monkeypatch) -> None:
    _FakeHttpClient.requests = []
    monkeypatch.setattr("freesolo.utils.upload.httpx.Client", _FakeHttpClient)

    response = upload_tinker_checkpoint_to_huggingface(
        "tinker://run/sampler_weights/final",
        base_model="openai/gpt-oss-20b",
        deployment_url="https://deploy.test",
    )

    assert response["adapterId"] == "adapter"
    assert _FakeHttpClient.requests[0]["url"] == "https://deploy.test/deployments/sync"


def test_get_deployment_job(monkeypatch) -> None:
    _FakeHttpClient.requests = []
    monkeypatch.setattr("freesolo.utils.upload.httpx.Client", _FakeHttpClient)

    response = get_deployment_job("job-1", deployment_url="https://deploy.test")

    assert response["status"] == "succeeded"
    assert _FakeHttpClient.requests[0]["url"] == "https://deploy.test/deployments/job-1"


def test_hosted_lora_client_calls_generate_and_chat(monkeypatch) -> None:
    _FakeHttpClient.requests = []
    monkeypatch.setattr("freesolo.utils.hosting.httpx.Client", _FakeHttpClient)

    client = HostedLoraClient(hosting_url="https://hosting.test")
    generated = client.generate("adapter", prompt="hello", max_tokens=5)
    chat = client.chat_completion("adapter", [{"role": "user", "content": "hello"}])

    assert generated["text"] == "done"
    assert chat["choices"][0]["message"]["content"] == "done"
    assert _FakeHttpClient.requests[0]["url"] == "https://hosting.test/generate"
    assert _FakeHttpClient.requests[0]["json"]["adapterId"] == "adapter"
    assert _FakeHttpClient.requests[1]["url"] == "https://hosting.test/v1/chat/completions"
    assert _FakeHttpClient.requests[1]["json"]["model"] == "adapter"
