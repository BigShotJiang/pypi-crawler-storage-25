from __future__ import annotations

import pytest
from freesolo.datasets import TaskExample
from freesolo.environments import Environment, RewardMetric, RewardResult
from freesolo.environments.evaluation import (
    EnvironmentGeneration,
    _call_generate,
    _evaluate_example,
    _resolve_concurrency,
    _resolve_generation,
    _run_local_environment_evaluation,
)


class _EvalEnvironment(Environment):
    def __init__(self, *, reward_count: int = 1) -> None:
        self.reward_count = reward_count

    def build_prompt_messages(self, example, prompt_text):
        return [{"role": "user", "content": f"{prompt_text}: {example.task}"}]

    def normalize_response_text(self, example, response_text):
        return response_text.strip()

    def score_response(self, example, response_text):
        return RewardResult(
            name="exact",
            score=1.0 if response_text else 0.0,
            success=bool(response_text),
            threshold=0.5,
            reason="non-empty",
            latency_ms=3,
            total_tokens=5,
            return_type="numeric",
            metadata={"normalized": response_text},
            metrics=[
                RewardMetric(
                    name="length",
                    score=float(len(response_text)),
                    value=len(response_text),
                    success=True,
                )
            ],
        )

    def score_responses(self, example, response_texts):
        rewards = super().score_responses(example, response_texts)
        if self.reward_count != len(rewards):
            return rewards[: self.reward_count]
        return rewards


def test_run_local_environment_evaluation_concurrent_and_metadata() -> None:
    source = [
        TaskExample(
            record={"task": "one", "image_url": "https://example.test/image.png"},
            task="one",
            task_id="1",
            metadata={"split": "eval"},
            expected_output={"answer": "yes"},
        ),
        {"id": "2", "task": "two", "expected_output": "ok"},
    ]

    def generate(*, messages, example, **_kwargs):
        return {
            "output": {"message": f" response for {example.task} "},
            "latency_ms": 12.8,
            "total_tokens": 9,
            "metadata": {"message_count": len(messages)},
        }

    results = _run_local_environment_evaluation(
        source=source,
        generate=generate,
        contract_text="contract",
        environment=_EvalEnvironment(),
        concurrency=2,
    )

    assert [result.success for result in results] == [True, True]
    assert all(result.run_duration is not None for result in results)
    first = results[0]
    assert first.data_object == {
        "input": "one",
        "actual_output": '{"message": " response for one "}',
        "expected_output": {"answer": "yes"},
        "task_id": "1",
        "metadata": {"split": "eval"},
        "generation_metadata": {"message_count": 1},
        "image_url": "https://example.test/image.png",
    }
    scorer = first.scorers_data[0]
    assert scorer.name == "exact"
    assert scorer.latency_ms == 3
    assert scorer.total_tokens == 5
    assert scorer.metrics[0].to_dict() == {
        "name": "length",
        "score": 33.0,
        "value": 33,
        "success": True,
    }


def test_evaluate_example_rejects_reward_count_mismatch() -> None:
    example = TaskExample(record={"task": "one"}, task="one")

    with pytest.raises(RuntimeError, match="one RewardResult"):
        _evaluate_example(
            example,
            environment=_EvalEnvironment(reward_count=0),
            generate=lambda messages, example: "answer",
            contract_text="contract",
        )


def test_generation_resolution_and_call_shapes() -> None:
    async def async_generation():
        return {"content": "async text"}

    assert _resolve_generation("text").response_text == "text"
    assert _resolve_generation(EnvironmentGeneration("ready")).response_text == "ready"
    assert _resolve_generation(async_generation()).response_text == "async text"
    with pytest.raises(ValueError, match="must include a non-null text field"):
        _resolve_generation({"content": None})
    with pytest.raises(ValueError, match="must include a non-null text field"):
        _resolve_generation({"metadata": {"source": "test"}})
    with pytest.raises(TypeError, match="Unsupported generation result"):
        _resolve_generation(123)  # type: ignore[arg-type]

    seen: list[object] = []

    def positional_only(messages):
        seen.append(messages)
        return "ok"

    messages = [{"role": "user", "content": "hi"}]
    assert (
        _call_generate(
            positional_only,
            messages=messages,
            example=TaskExample(record={"task": "x"}, task="x"),
            environment=_EvalEnvironment(),
            contract_text="contract",
        )
        == "ok"
    )
    assert seen == [messages]


def test_resolve_concurrency_rejects_invalid_values() -> None:
    assert _resolve_concurrency(3) == 3
    for value in (0, -1, True):
        with pytest.raises(ValueError, match="positive integer"):
            _resolve_concurrency(value)  # type: ignore[arg-type]
