from __future__ import annotations

import json

import pytest
from freesolo.utils.openrouter import build_openrouter_chat_payload
from freesolo.utils.oracle import generate_ground_truth_records


def test_openrouter_payload_requires_explicit_max_tokens() -> None:
    with pytest.raises(ValueError, match="at least 1"):
        build_openrouter_chat_payload(
            model="anthropic/claude-opus-4.7",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=0,
        )

    payload = build_openrouter_chat_payload(
        model="anthropic/claude-opus-4.7",
        messages=[{"role": "user", "content": "hi"}],
        max_tokens=321,
        temperature=0.2,
    )

    assert payload["max_tokens"] == 321
    assert payload["temperature"] == 0.2


def test_oracle_generation_passes_explicit_max_tokens(monkeypatch, tmp_path) -> None:
    contract_path = tmp_path / "TRAINING_CONTRACT.md"
    contract_path.write_text(
        json.dumps(
            {
                "prompt": {
                    "system": "Return JSON.",
                    "user": "Task: {task}",
                }
            }
        ),
        encoding="utf-8",
    )
    input_path = tmp_path / "data.json"
    input_path.write_text('[{"id":"one","task":"answer yes"}]', encoding="utf-8")
    environment_path = tmp_path / "environment.py"
    environment_path.write_text(
        "\n".join(
            [
                "from freesolo.environments import Environment, RewardResult",
                "",
                "class TestEnvironment(Environment):",
                "    def build_prompt_messages(self, example, prompt_text):",
                "        return [{'role': 'user', 'content': example.task}]",
                "    def score_response(self, example, response_text):",
                "        return RewardResult(score=1.0)",
                "",
                "def load_environment(**_):",
                "    return TestEnvironment()",
            ]
        ),
        encoding="utf-8",
    )
    calls: list[dict[str, object]] = []

    def fake_generate_openrouter_text(**kwargs: object) -> str:
        calls.append(kwargs)
        return '{"answer": "yes"}'

    monkeypatch.setattr(
        "freesolo.utils.oracle.generate_openrouter_text",
        fake_generate_openrouter_text,
    )

    records = generate_ground_truth_records(
        input_path=input_path,
        contract_path=contract_path,
        environment=f"{environment_path}:load_environment",
        max_tokens=777,
    )

    assert calls[0]["max_tokens"] == 777
    assert records[0]["ground_truth"] == {"answer": "yes"}
