from typing import TypeVar

import os

from ssapi.defaults import DEFAULT_SSAPI_DATABASE_PATH
from ssapi.db import Database, ShopDatabase


def get_database_path() -> str:
    """Get the current database path based on the environment variable"""
    return os.environ.get("SSAPI_DATABASE_PATH", DEFAULT_SSAPI_DATABASE_PATH)


T = TypeVar("T", bound=Database)

_db_cache: dict = {}


def get_env_database(database_type: type[T] = ShopDatabase) -> T:
    """Get database in this execution environment"""
    path = get_database_path()
    key = (database_type, path)
    if key not in _db_cache:
        _db_cache[key] = database_type(path)
    return _db_cache[key]
