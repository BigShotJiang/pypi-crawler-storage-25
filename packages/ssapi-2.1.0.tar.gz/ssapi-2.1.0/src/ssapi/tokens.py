import logging

from ssapi.db import KsefDatabase
from ssapi import kseflib
from ssapi.env import get_env_database
from ssapi.exceptions import NotAuthenticatedRemotelyException

logger = logging.getLogger(__name__)


class TokenManager:
    """Manages access and refresh tokens fetched from KSeF API

    Tokens are saved in the local database, together with their expiry date
    and time. When they are expired, they are requested again.

    It requires a valid authentication token.
    """

    def __init__(self, auth_token: kseflib.AuthenticationToken | None = None):
        self.db = get_env_database(database_type=KsefDatabase)
        self.auth_token = auth_token

    def get_tokens(self) -> kseflib.TokenTuple:
        """Get tokens, using cached if valid, otherwise fetch fresh"""
        access_token = self.db.get_token("access")
        refresh_token = self.db.get_token("refresh")

        if access_token and refresh_token:
            logger.debug("Using cached tokens (access valid until: %s)", access_token.valid_until)
            return (access_token, refresh_token)

        logger.info("No valid cached tokens, fetching fresh tokens from KSeF")
        return self._fetch_and_save_tokens()

    def _fetch_and_save_tokens(self) -> kseflib.TokenTuple:
        """Fetch fresh tokens from KSeF and save to database"""
        if not self.auth_token:
            raise NotAuthenticatedRemotelyException("No auth token provided")

        access_token, refresh_token = kseflib.get_tokens(self.auth_token)

        if access_token:
            self.db.save_token(access_token)
            logger.info("Saved access token (valid until: %s)", access_token.valid_until)
        if refresh_token:
            self.db.save_token(refresh_token)
            logger.info("Saved refresh token (valid until: %s)", refresh_token.valid_until)

        return (access_token, refresh_token)
