# SSAPI
A CRUD API that can run on mod_python shared web hosting services such as Namecheap.

## Migrations
Make sure you run the migrations *once* when upgrading to a newer version listed
below:
 - v1.8.0: [0002_invoices_add_shop_and_gross.py](migrations/0002_invoices_add_shop_and_gross.py)
 - v1.7.0: [0001_invoices_add_qr_fields.py](migrations/0001_invoices_add_qr_fields.py)
