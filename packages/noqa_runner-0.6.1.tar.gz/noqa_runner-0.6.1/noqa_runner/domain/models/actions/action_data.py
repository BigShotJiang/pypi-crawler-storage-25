from __future__ import annotations

from typing import Union

from pydantic import BaseModel, Field

from noqa_runner.domain.models.actions.activate_app import ActivateApp
from noqa_runner.domain.models.actions.background_app import BackgroundApp
from noqa_runner.domain.models.actions.drag import Drag
from noqa_runner.domain.models.actions.input_text import InputText
from noqa_runner.domain.models.actions.open_url import OpenUrl
from noqa_runner.domain.models.actions.restart_app import RestartApp
from noqa_runner.domain.models.actions.stop import Stop
from noqa_runner.domain.models.actions.swipe import Swipe
from noqa_runner.domain.models.actions.tap import Tap
from noqa_runner.domain.models.actions.terminate_app import TerminateApp
from noqa_runner.domain.models.actions.wait import Wait
from noqa_runner.domain.models.state.expected_result import ExpectedResultUpdate

Actions = Union[
    Tap,
    Swipe,
    Drag,
    Wait,
    Stop,
    ActivateApp,
    BackgroundApp,
    TerminateApp,
    RestartApp,
    OpenUrl,
]


class Reasoning(BaseModel):
    """Structured reasoning for vision-based actions in QA testing"""

    history: str = Field(
        description="Summary of key events and actions from previous test steps"
    )
    current_state: str = Field(
        description="Description of the current screen state and relevant UI elements"
    )
    previous_action_result: str = Field(
        description="Outcome and observations from the last action performed"
    )
    next_action: str = Field(
        description="Explanation and justification for the chosen next action"
    )
    next_action_flow: int = Field(
        ge=1, description="Flow number (1-indexed) that the next action belongs to"
    )


class ActionData(BaseModel):
    action: Union[Actions, InputText] = Field(discriminator="name")
    reasoning: Reasoning = Field(
        description="Structured explanation of your decision including history, current state, previous action result, and reasoning for next action"
    )
    expected_results_updates: list[ExpectedResultUpdate] | None = Field(
        default=None, description="List of expected result updates by alias"
    )

    @property
    def action_description(self) -> str:
        """Human-readable description of the action."""
        return self.action.get_action_description()
