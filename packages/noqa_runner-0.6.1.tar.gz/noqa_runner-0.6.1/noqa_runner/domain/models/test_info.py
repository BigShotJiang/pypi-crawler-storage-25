"""Domain models for test information"""

from __future__ import annotations

from uuid import uuid4

from pydantic import BaseModel, Field

from noqa_runner.domain.models.state.flow import FlowItemRaw


class RunnerTestInfo(BaseModel):
    """Test case information for runner"""

    test_id: str = Field(
        default_factory=lambda: str(uuid4()), description="Unique test identifier"
    )
    flows: list[FlowItemRaw] = Field(
        min_length=1,
        description="Test case flows with instructions and expected results",
    )
    case_name: str = Field(default="", description="Test case name")
