"""Typer CLI for the pylzsg command."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import typer

from pylizlib.core.app.configini import CfgPath  # type: ignore[import-untyped]
from pylizlib.core.app.pytoml import PyProjectToml  # type: ignore[import-untyped]
from pylizlib.core.os.path import PathMatcher  # type: ignore[import-untyped]
from pylizlib.qt.scripts import (  # type: ignore[import-untyped]
    exec_gen_css_py,
    exec_gen_qrc,
    exec_gen_res_py,
)

app = typer.Typer(
    name="pylzsg",
    help="Legacy pylizlib utility commands, repackaged as the pylzsg CLI.",
    add_completion=False,
)


def _get_version() -> str:
    try:
        return version("pylzsg")
    except PackageNotFoundError:
        return "0.1.0"


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version_flag: bool = typer.Option(
        False,
        "--version",
        help="Show the installed pylzsg version and exit.",
        is_eager=True,
    ),
) -> None:
    """Provide top-level CLI options."""

    if version_flag:
        typer.echo(_get_version())
        raise typer.Exit()

    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command("expFileList")
def exp_file_list(
    input: Path = typer.Argument(..., help="Input path to scan"),
    output: Path = typer.Argument(..., help="Output path where to save the file"),
    file_name: str = typer.Argument(..., help="Name of the file to save"),
    recursive: bool = typer.Option(False, "--recursive", help="Enable recursive scan"),
) -> None:
    """Export the scanned path contents to a text file."""

    matcher = PathMatcher()
    matcher.load_path(input, recursive)
    output.mkdir(parents=True, exist_ok=True)
    matcher.export_file_list(output, file_name)


@app.command("iniDup")
def ini_dup(
    input: Path = typer.Argument(..., help="Input path to scan"),
    sections: bool = typer.Option(
        False, "--sections", help="Enable search for duplicate sections"
    ),
    keys: bool = typer.Option(False, "--keys", help="Enable search for duplicate keys"),
) -> None:
    """Inspect INI files under a directory and print sections and keys."""

    cfg = CfgPath(input)
    cfg.check_duplicates(keys, sections)


@app.command("gen-project-py")
def gen_project_py(
    pyproject_path: Path = typer.Argument(..., help="Path to the pyproject.toml file"),
    py_file: Path = typer.Argument(..., help="Path to the Python file to update"),
) -> None:
    """Generate a Python module from a pyproject.toml file."""

    try:
        toml = PyProjectToml(pyproject_path)
        toml.gen_project_py(py_file)
    except Exception as exc:  # pragma: no cover - exercised through CLI behavior
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=1) from exc


@app.command("temp")
def temp() -> None:
    """Temporary placeholder command preserved from the legacy CLI."""

    typer.echo("This is a temporary command.")


@app.command("gen-qrc")
def gen_qrc(
    qrc_path: Path = typer.Option(..., "--qrc-path", help=".QRC file path to generate"),
    res_dir: list[Path] = typer.Option(
        ..., "--res-dir", help="Add resource directories to qrc file"
    ),
) -> None:
    """Generate a Qt .qrc file from one or more resource directories."""

    if not res_dir:
        typer.echo(
            "Errore: devi specificare almeno una directory con --res-dir", err=True
        )
        raise typer.Exit(code=1)

    for path in res_dir:
        if not path.is_dir():
            typer.echo(f"Error: folder {path} dont exist.", err=True)
            raise typer.Exit(code=1)

    typer.echo(f"QRC generation in: {qrc_path}")
    typer.echo("Folder resources:")
    for path in res_dir:
        typer.echo(f" - {path}")
    exec_gen_qrc(qrc_path, res_dir)


@app.command("gen-res-ids")
def gen_res_ids(
    qrc_path: Path = typer.Argument(..., help="Path del file .qrc (deve esistere)"),
    py_file: Path = typer.Argument(
        ..., help="Path del file Python da generare (puo non esistere)"
    ),
    class_name: str = typer.Option(
        "ResourcesIds", help="Nome della classe da generare nel file Python"
    ),
) -> None:
    """Generate Python resource identifiers from an existing .qrc file."""

    if not qrc_path.is_file():
        typer.echo(f"Errore: il file '{qrc_path}' non esiste.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Generazione identificatori risorse da '{qrc_path}' in '{py_file}'")
    exec_gen_res_py(qrc_path, py_file, class_name)


@app.command("gen-css-py")
def gen_css_py(
    css_dir: Path = typer.Argument(
        ..., help="Path della cartella CSS (deve esistere)"
    ),
    py_file: Path = typer.Argument(
        ..., help="Path del file Python da generare (puo non esistere)"
    ),
) -> None:
    """Generate a Python module from CSS files under a directory."""

    if not css_dir.is_dir():
        typer.echo(f"Errore: la cartella '{css_dir}' non esiste.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Generazione file Python da CSS nella cartella '{css_dir}' in '{py_file}'")
    exec_gen_css_py(css_dir, py_file)


def main() -> None:
    """Entrypoint used by the installed console script."""

    app()


if __name__ == "__main__":
    main()
