from pathlib import Path

from typer.testing import CliRunner

import pylzsg.cli as cli
from pylzsg.cli import app

runner = CliRunner()


def test_help_shows_legacy_commands() -> None:
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "expFileList" in result.output
    assert "iniDup" in result.output
    assert "gen-project-py" in result.output
    assert "gen-qrc" in result.output
    assert "gen-res-ids" in result.output
    assert "gen-css-py" in result.output
    assert "temp" in result.output


def test_version_option() -> None:
    result = runner.invoke(app, ["--version"])

    assert result.exit_code == 0
    assert result.output.strip()


def test_temp_command() -> None:
    result = runner.invoke(app, ["temp"])

    assert result.exit_code == 0
    assert "temporary command" in result.output


def test_exp_file_list_exports_items(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "a.txt").write_text("a", encoding="utf-8")
    (source / "b.txt").write_text("b", encoding="utf-8")

    output = tmp_path / "out"
    result = runner.invoke(app, ["expFileList", str(source), str(output), "files.txt"])

    assert result.exit_code == 0
    exported = (output / "files.txt").read_text(encoding="utf-8").splitlines()
    assert set(exported) == {"a.txt", "b.txt"}


def test_ini_dup_reads_ini_tree(tmp_path: Path) -> None:
    ini_dir = tmp_path / "cfg"
    ini_dir.mkdir()
    (ini_dir / "app.ini").write_text("[demo]\nkey = value\n", encoding="utf-8")

    result = runner.invoke(app, ["iniDup", str(ini_dir), "--sections", "--keys"])

    assert result.exit_code == 0
    assert "Sections in" in result.output
    assert "demo" in result.output
    assert "key" in result.output


def test_gen_project_py_generates_python_module(tmp_path: Path) -> None:
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text(
        """
[project]
name = "demo"
version = "1.2.3"
description = "Sample project"
requires-python = ">=3.12"
authors = [{name = "Alice", email = "alice@example.com"}]
""".strip()
        + "\n",
        encoding="utf-8",
    )
    destination = tmp_path / "generated" / "project.py"

    result = runner.invoke(app, ["gen-project-py", str(pyproject), str(destination)])

    assert result.exit_code == 0
    generated = destination.read_text(encoding="utf-8")
    assert "name = 'demo'" in generated or 'name = "demo"' in generated
    assert "version = '1.2.3'" in generated or 'version = "1.2.3"' in generated
    assert "Alice" in generated


def test_gen_qrc_validates_resource_directories(tmp_path: Path) -> None:
    qrc_path = tmp_path / "resources.qrc"

    result = runner.invoke(
        app,
        ["gen-qrc", "--qrc-path", str(qrc_path), "--res-dir", str(tmp_path / "missing")],
    )

    assert result.exit_code == 1
    assert "dont exist" in result.output


def test_gen_qrc_calls_legacy_script(tmp_path: Path, monkeypatch) -> None:
    qrc_path = tmp_path / "resources.qrc"
    res_dir = tmp_path / "assets"
    res_dir.mkdir()
    calls: list[tuple[Path, list[Path]]] = []

    def _fake_exec_gen_qrc(path: Path, dirs: list[Path]) -> None:
        calls.append((path, dirs))

    monkeypatch.setattr(cli, "exec_gen_qrc", _fake_exec_gen_qrc)

    result = runner.invoke(
        app,
        ["gen-qrc", "--qrc-path", str(qrc_path), "--res-dir", str(res_dir)],
    )

    assert result.exit_code == 0
    assert calls == [(qrc_path, [res_dir])]


def test_gen_res_ids_calls_legacy_script(tmp_path: Path, monkeypatch) -> None:
    qrc_path = tmp_path / "resources.qrc"
    qrc_path.write_text("<RCC></RCC>\n", encoding="utf-8")
    py_file = tmp_path / "res_ids.py"
    calls: list[tuple[Path, Path, str]] = []

    def _fake_exec_gen_res_py(src: Path, dst: Path, cls: str) -> None:
        calls.append((src, dst, cls))

    monkeypatch.setattr(cli, "exec_gen_res_py", _fake_exec_gen_res_py)

    result = runner.invoke(app, ["gen-res-ids", str(qrc_path), str(py_file)])

    assert result.exit_code == 0
    assert calls == [(qrc_path, py_file, "ResourcesIds")]


def test_gen_css_py_calls_legacy_script(tmp_path: Path, monkeypatch) -> None:
    css_dir = tmp_path / "css"
    css_dir.mkdir()
    py_file = tmp_path / "style.py"
    calls: list[tuple[Path, Path]] = []

    def _fake_exec_gen_css_py(src_dir: Path, dst: Path) -> None:
        calls.append((src_dir, dst))

    monkeypatch.setattr(cli, "exec_gen_css_py", _fake_exec_gen_css_py)

    result = runner.invoke(app, ["gen-css-py", str(css_dir), str(py_file)])

    assert result.exit_code == 0
    assert calls == [(css_dir, py_file)]
