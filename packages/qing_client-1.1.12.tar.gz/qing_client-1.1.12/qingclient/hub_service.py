"""能力枢纽服务（与 npm HubService 对齐）。"""
from typing import Any, Dict, List, Optional, Literal, TypedDict

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class ResultPayload(TypedDict, total=False):
    """任务结果载体。
    
    - type: 结果类型，"content" | "file_path" | "url" | 自定义字符串
    - data: 实际结果，含义由 type 决定
    - metadata: 可选元数据，如 file_size、mime_type、processing_time_ms 等
    """
    type: str       # "content" | "file_path" | "url" | ...
    data: Any       # 实际内容，类型随 type 变化
    metadata: Dict[str, Any]  # 可选的附加信息


class HubService(BaseClient):
    service_path = "hub"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "hub"

    def get_stats(self, options: Optional[RequestOptions] = None) -> Any:
        """大盘统计。"""
        return self.request("/stats", RequestOptions(method="GET"))

    def list_workers(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """Worker 列表（分页）。"""
        return self.request("/workers", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def get_worker(self, worker_id: str, options: Optional[RequestOptions] = None) -> Any:
        """Worker 详情。"""
        return self.request(f"/workers/{worker_id}", RequestOptions(method="GET"))

    def list_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """Task 列表（分页）。
        
        Args:
            params: 查询参数，可选字段：
                - status: str，任务状态
                - worker_id: str，Worker ID
                - caller_user_id: str，仅 SUPER_ADMIN 可用，指定查询特定用户的任务
                - page: int，页码
                - per_page: int，每页条数
                - offset: int，偏移量
                - limit: int，限制条数
        """
        return self.request("/tasks", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def get_task(self, task_id: str, options: Optional[RequestOptions] = None) -> Any:
        """Task 详情。"""
        return self.request(f"/tasks/{task_id}", RequestOptions(method="GET"))

    def cancel_task(self, task_id: str, options: Optional[RequestOptions] = None) -> Any:
        """取消任务。"""
        return self.request(f"/tasks/{task_id}/cancel", RequestOptions(method="POST"))

    def invoke_task(
        self,
        worker_id: str,
        input_data: Dict[str, Any],
        trace_id: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """异步下发任务，立即返回 task_id。"""
        body: Dict[str, Any] = {"worker_id": worker_id, "input_data": input_data}
        if trace_id:
            body["trace_id"] = trace_id
        return self.request("/tasks/invoke", RequestOptions(method="POST", body=body))

    def invoke_task_sync(
        self,
        worker_id: str,
        input_data: Dict[str, Any],
        trace_id: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """同步调用能力（适用于简单傀儡节点，最长等待 15 秒）。
        
        返回值中 result_payload 为 ResultPayload 结构（含 type/data/metadata），
        可根据 type 判断如何处理 data：
          - "content"   → data 是文件正文（字符串或对象）
          - "file_path" → data 是文件路径字符串
          - "url"       → data 是可访问的 URL 字符串
        """
        body: Dict[str, Any] = {"worker_id": worker_id, "input_data": input_data}
        if trace_id:
            body["trace_id"] = trace_id
        return self.request("/tasks/invoke/sync", RequestOptions(method="POST", body=body))

    def list_capabilities(self, options: Optional[RequestOptions] = None) -> List[Any]:
        """获取所有在线 Worker 的能力列表（供大模型意图识别使用）。"""
        return self.request("/capabilities", RequestOptions(method="GET"))
