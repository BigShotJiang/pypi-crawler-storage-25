"""短剧生产服务（Drama Service）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class DramaService(BaseClient):
    """短剧生产项目管理、剧集规划、角色生成等功能服务。"""
    
    service_path = "drama"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "drama"

    # ==================== Production Project CRUD ====================

    def create_production(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """创建生产项目 - POST /api/drama/productions"""
        return self.request("/productions", RequestOptions(
            method="POST",
            body=request,
        ))

    def get_production(
        self,
        production_project_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """获取生产项目详情 - GET /api/drama/productions/:productionProjectId"""
        return self.request(f"/productions/{production_project_id}", RequestOptions(
            method="GET",
        ))

    def list_productions(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """获取生产项目列表 - GET /api/drama/productions"""
        return self.request("/productions", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def update_production(
        self,
        production_project_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """更新生产项目 - PUT /api/drama/productions/:productionProjectId"""
        return self.request(f"/productions/{production_project_id}", RequestOptions(
            method="PUT",
            body=update_data,
        ))

    # ==================== Episode Plan CRUD ====================

    def create_episode(
        self,
        production_project_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """创建剧集 - POST /api/drama/productions/:productionProjectId/episodes"""
        return self.request(f"/productions/{production_project_id}/episodes", RequestOptions(
            method="POST",
            body=request,
        ))

    def get_episode(
        self,
        production_project_id: str,
        episode_number: int,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """获取剧集详情 - GET /api/drama/productions/:productionProjectId/episodes/:episodeNumber"""
        return self.request(
            f"/productions/{production_project_id}/episodes/{episode_number}",
            RequestOptions(method="GET"),
        )

    def list_episodes(
        self,
        production_project_id: str,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """列出某项目下的剧集 - GET /api/drama/productions/:productionProjectId/episodes"""
        return self.request(
            f"/productions/{production_project_id}/episodes",
            RequestOptions(method="GET", params=params or {}),
        )

    def update_episode(
        self,
        production_project_id: str,
        episode_number: int,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """更新剧集 - PATCH /api/drama/productions/:productionProjectId/episodes/:episodeNumber"""
        return self.request(
            f"/productions/{production_project_id}/episodes/{episode_number}",
            RequestOptions(method="PATCH", body=update_data),
        )

    # ==================== Character Generation ====================

    def generate_character(
        self,
        production_project_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """发起角色生成任务 - POST /api/drama/productions/:productionProjectId/characters/generate"""
        return self.request(
            f"/productions/{production_project_id}/characters/generate",
            RequestOptions(method="POST", body=request),
        )

    # ==================== Task Management ====================

    def get_task(
        self,
        task_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """获取任务详情 - GET /api/drama/tasks/:taskId"""
        return self.request(f"/tasks/{task_id}", RequestOptions(method="GET"))

    def list_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """获取任务列表 - GET /api/drama/tasks

        常用 query：page, limit, taskType, status, projectId, referenceId
        """
        return self.request("/tasks", RequestOptions(
            method="GET",
            params=params or {},
        ))
