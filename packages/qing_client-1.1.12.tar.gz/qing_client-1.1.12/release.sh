#!/bin/bash
# release.sh - 版本递增并构建/发布（与 super/client/pip 一致）
# 用法: ./release.sh [major|minor|patch] [--no-upload]
#   --no-upload  仅递增 version.txt 并构建，不上传 PyPI

set -e

# 清理旧文件
rm -rf build dist *.egg-info

# 检查参数
if [[ "$1" != "major" && "$1" != "minor" && "$1" != "patch" ]]; then
    echo "错误: 请指定版本更新类型 [major|minor|patch]"
    echo "用法: ./release.sh [major|minor|patch] [--no-upload]"
    exit 1
fi

UPLOAD=1
[[ "${2:-}" == "--no-upload" || "${2:-}" == "--build-only" ]] && UPLOAD=0

# 读取当前版本（与 npm 对齐时请保持 version.txt 为当前一致版本）
current_version=$(cat version.txt)
IFS='.' read -ra version_parts <<< "$current_version"
major=${version_parts[0]}
minor=${version_parts[1]}
patch=${version_parts[2]}

# 更新版本号
case $1 in
    "major")
        new_version="$((major + 1)).0.0"
        ;;
    "minor")
        new_version="${major}.$((minor + 1)).0"
        ;;
    "patch")
        new_version="${major}.${minor}.$((patch + 1))"
        ;;
esac

# 更新 version.txt
echo "$new_version" > version.txt

# 同步 pyproject.toml 中的 fallback_version，便于无 git 时版本一致
if grep -q '^fallback_version = "' pyproject.toml 2>/dev/null; then
    sed -i "s/^fallback_version = \".*\"/fallback_version = \"$new_version\"/" pyproject.toml
fi

# 构建时强制使用此版本（不依赖 git tag）
export SETUPTOOLS_SCM_PRETEND_VERSION=$new_version

# 安装构建工具（仅在缺失时安装，避免网络超时）
if ! python3 -c "import build" &>/dev/null || ! python3 -c "import twine" &>/dev/null; then
    pip install --quiet build twine
fi

# 构建包
python3 -m build

if [[ $UPLOAD -eq 1 ]]; then
    twine upload dist/*
    rm -rf build *.egg-info
    echo "✅ 版本 $new_version 已发布到 PyPI"
    echo "访问: https://pypi.org/project/qing-client/"
else
    rm -rf build *.egg-info
    echo "✅ 版本已递增为 $new_version 并完成本地构建（未上传）"
    echo "   dist/ 已生成，需要上传时请执行: twine upload dist/*"
fi
