# ----------------------------------------------------
# SPDX-FileCopyrightText: AsFigo Technologies, UK
# SPDX-FileCopyrightText: VerifWorks, India
# SPDX-License-Identifier: MIT
# ----------------------------------------------------
'''
import sys
import os
import argparse
# Add the 'src' directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

import logging
import verible_verilog_syntax
from af_lint_rule import AsFigoLintRule
from asfigo_linter import AsFigoLinter
from afsvalint.rules.af_asrt_no_label import MissingLabelChk
from afsvalint.rules.af_perf_no_pass_ablk import PerfNoPABlk
from afsvalint.rules.af_no_timeliteral import NoExplTimeLiterals
from afsvalint.rules.af_no_within_oper import NoWithinOperInAsrt
from afsvalint.rules.af_no_fmatch_oper import NoFirstMatchOperInAsrt
from afsvalint.rules.af_no_range_ant import NoRangeInAntAsrt
from afsvalint.rules.af_perf_no_ub_range_ant import NoUBRangeInAntAsrt
from afsvalint.rules.af_func_missing_fablk import FuncMissingFABLK
from afsvalint.rules.af_missing_elbl_prop import MissingEndLblProp
from afsvalint.rules.af_missing_elbl_seq import MissingEndLblSEQ
from afsvalint.rules.af_prop_naming import PropNaming
from afsvalint.rules.af_perf_missing_impl_oper import MissingImplicationOper
from afsvalint.rules.af_perf_no_large_del import NoLargeDelayProp
from afsvalint.rules.af_use_simple_cnseq import UseSimpleExprConseq
from afsvalint.rules.af_no_dollar_time import UseRealTimeVsTime
from afsvalint.rules.af_func_cov_nolap import FuncNOLAPInCoverProp 
from afsvalint.rules.af_func_cov_olap import FuncOLAPInCoverProp 
from afsvalint.rules.af_reuse_fa_one_liner import ReuseNoOneLinerFABLK 
from afsvalint.rules.af_func_no_ub_in_cnseq import NoUBRangeInConseqAsrt 
from afsvalint.rules.af_asrt_naming import AssertNaming
from afsvalint.rules.af_no_aa_exists_sva import AvoidAAExistsSVA
from afsvalint.rules.af_no_pop_back_sva import AvoidPopBkSVA
from afsvalint.rules.af_no_pop_front_sva import AvoidPopFrSVA
from afsvalint.rules.af_assume_naming import AssumeNaming
from afsvalint.rules.af_cover_naming import CoverNaming

class SVALinter(AsFigoLinter):
    """Linter that applies multiple rules on SVA code"""

    def __init__(self, configFile, logLevel=logging.INFO):
        super().__init__(configFile=configFile, logLevel=logLevel)
        # Automatically discover and register all subclasses of AsFigoLintRule
        self.rules = [rule_cls(self) for rule_cls in AsFigoLintRule.__subclasses__()]

    def loadSyntaxTree(self):
        """Loads Verilog syntax tree using VeribleVerilogSyntax."""
        parser = verible_verilog_syntax.VeribleVerilogSyntax()
        return parser.parse_files([self.testName], options={"gen_tree": True})

    def runLinter(self):
        """Runs all registered lint rules on the Verilog file."""
        treeData = self.loadSyntaxTree()

        for filePath, fileData in treeData.items():
            self.logInfo("SVALint", f"Loaded test file: {self.testName}")
            
            for rule in self.rules:
                rule.run(filePath, fileData)

            self.logSummary()


def main():
    byolDemo = SVALinter(configFile="config.toml", logLevel=logging.INFO)
    byolDemo.runLinter()

if __name__ == "__main__":
    main()

def main():
    parser = argparse.ArgumentParser(description="Run SVALint linter")
    parser.add_argument("--config", default="config.toml", help="Path to config file")
    args = parser.parse_args()

    linter = SVALinter(configFile=args.config, logLevel=logging.INFO)
    linter.runLinter()

if __name__ == "__main__":
    main()

'''
import argparse
import logging

# Import Verible parser and linter classes from package
from afsvalint import verible_verilog_syntax
from afsvalint.asfigo_linter import SVALinter  # assuming your class was renamed appropriately

# --- Example method inside your linter class ---
class SVALinter:  # if not already defined elsewhere
    def __init__(self, configFile="config.toml", logLevel=logging.INFO):
        self.configFile = configFile
        self.rules = []  # populate with rule instances elsewhere
        logging.basicConfig(level=logLevel)
        self.logger = logging.getLogger("SVALint")

    def logInfo(self, module, msg):
        self.logger.info(f"[{module}] {msg}")

    def logSummary(self):
        self.logger.info("Linting completed!")

    def loadSyntaxTree(self):
        """Loads Verilog syntax tree using VeribleVerilogSyntax."""
        parser = verible_verilog_syntax.VeribleVerilogSyntax()
        return parser.parse_files([self.testName], options={"gen_tree": True})

        # Original code commented:
        # """Loads Verilog syntax tree using VeribleVerilogSyntax."""
        # parser = verible_verilog_syntax.VeribleVerilogSyntax()
        # return parser.parse_files([self.testName], options={"gen_tree": True})

    def runLinter(self):
        """Runs all registered lint rules on the Verilog file."""
        treeData = self.loadSyntaxTree()

        for filePath, fileData in treeData.items():
            self.logInfo("SVALint", f"Loaded test file: {self.testName}")

            for rule in self.rules:
                rule.run(filePath, fileData)

            self.logSummary()

        # Original code commented:
        '''
        def runLinter(self):
            """Runs all registered lint rules on the Verilog file."""
            treeData = self.loadSyntaxTree()

            for filePath, fileData in treeData.items():
                self.logInfo("SVALint", f"Loaded test file: {self.testName}")

                for rule in self.rules:
                    rule.run(filePath, fileData)

                self.logSummary()
        '''


# --- Main entry point ---
def main():
    parser = argparse.ArgumentParser(description="Run SVALint linter")
    parser.add_argument("--config", default="config.toml", help="Path to config file")
    parser.add_argument("-t", "--test", help="Path to Verilog test file")
    parser.add_argument("--version", action="store_true", help="Show SVALint version")
    args = parser.parse_args()

    if args.version:
        from afsvalint import __version__
        print(f"svalint version {__version__}")
        return

    if not args.test:
        parser.error("the following arguments are required: -t/--test")

    linter = SVALinter(configFile=args.config, logLevel=logging.INFO)
    linter.testName = args.test
    linter.runLinter()
# Original main code commented:
'''
def main():
    byolDemo = SVALinter(configFile="config.toml", logLevel=logging.INFO)
    byolDemo.runLinter()

if __name__ == "__main__":
    main()
'''

if __name__ == "__main__":
    main()
