"""Configuration management for the AgentsHive SDK CLI.

Handles reading, writing, and validating ~/.agentshive/config.json.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path

CONFIG_DIR = Path(os.environ.get("AGENTSHIVE_CONFIG_DIR", Path.home() / ".agentshive"))
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "daemon.pid"
LOG_FILE = CONFIG_DIR / "daemon.log"


@dataclass
class Config:
    """SDK configuration."""

    server_url: str = "https://agentshive.agency/"
    token: str = ""
    backends: dict[str, bool] = field(default_factory=dict)
    auto_start: bool = False
    log_level: str = "info"
    timeout: int = 300


class ConfigError(Exception):
    """Raised when configuration is invalid or missing."""


def load_config() -> Config:
    """Load config from disk. Raises ConfigError if file missing or invalid."""
    if not CONFIG_FILE.exists():
        raise ConfigError(
            f"Config not found: {CONFIG_FILE}\nRun 'agentshive setup' to create one."
        )
    try:
        data = json.loads(CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        raise ConfigError(f"Invalid config file: {exc}") from exc

    raw_timeout = data.get("timeout", 300)
    try:
        timeout = int(raw_timeout)
    except (TypeError, ValueError):
        raise ConfigError(
            f"Invalid timeout value: {raw_timeout!r} (must be a positive integer)"
        )

    return Config(
        server_url=data.get("server_url", ""),
        token=data.get("token", ""),
        backends=data.get("backends", {}),
        auto_start=data.get("auto_start", False),
        log_level=data.get("log_level", "info"),
        timeout=timeout,
    )


def save_config(config: Config) -> None:
    """Write config to disk with restricted permissions (0o600)."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(CONFIG_DIR, 0o700)
        content = json.dumps(asdict(config), indent=2) + "\n"
        fd = os.open(str(CONFIG_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, content.encode())
        finally:
            os.close(fd)
    except OSError as exc:
        raise ConfigError(f"Failed to write config: {exc}") from exc


def validate_config(config: Config) -> list[str]:
    """Return list of validation errors (empty = valid)."""
    errors = []
    if not config.server_url:
        errors.append("server_url is required")
    if not config.token:
        errors.append("token is required")
    elif not config.token.startswith("ahv_"):
        errors.append("token must start with 'ahv_'")
    enabled = [k for k, v in config.backends.items() if v]
    if not enabled:
        errors.append("At least one backend must be enabled")
    if not isinstance(config.timeout, int) or config.timeout <= 0:
        errors.append("timeout must be a positive integer (seconds)")
    return errors


def detect_backends() -> dict[str, bool]:
    """Detect which CLI backends are installed on PATH.

    Returns dict mapping backend name -> is_installed.
    """
    from agentshive.backends import list_all, is_available

    return {name: is_available(name) for name in list_all()}
