"""agentshive status — show daemon and backend status."""

from __future__ import annotations

import argparse
import os

from agentshive.config import (
    ConfigError,
    CONFIG_FILE,
    PID_FILE,
    detect_backends,
    load_config,
)


def _is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def run_status(_args: argparse.Namespace) -> None:
    """Run the status command."""
    print()

    # Config
    try:
        config = load_config()
    except ConfigError:
        print(f"  Config:  not found ({CONFIG_FILE})")
        print("  Run 'agentshive setup' first.")
        print()
        return

    # Daemon
    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            if not _is_running(pid):
                pid = None
                PID_FILE.unlink(missing_ok=True)
        except (ValueError, OSError):
            pid = None

    if pid:
        print(f"  Daemon:    running (PID {pid})")
    else:
        print("  Daemon:    stopped")

    print(f"  Server:    {config.server_url}")
    print()

    # Backends
    detected = detect_backends()
    print("  Backends:")
    for name in sorted(set(list(config.backends.keys()) + list(detected.keys()))):
        enabled = config.backends.get(name, False)
        installed = detected.get(name, False)
        if enabled and installed:
            status = "\u2713 enabled, available"
        elif enabled and not installed:
            status = "\u2713 enabled, NOT INSTALLED"
        elif not enabled and installed:
            status = "- disabled (installed)"
        else:
            status = "- not installed"
        print(f"    {name:15s} {status}")

    print()
