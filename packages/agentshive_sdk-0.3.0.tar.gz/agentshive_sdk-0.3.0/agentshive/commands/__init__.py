"""CLI subcommands for the AgentsHive SDK."""
