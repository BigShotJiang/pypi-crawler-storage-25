"""Memory tag extraction from agent responses.

Ported from backend/services/backends/agent_memory.py.
"""

from __future__ import annotations

import logging
import re

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MEMORY_DELIMITER = "\n---\n"

MEMORY_TAG_RE = re.compile(
    r"^\[MEMORY:\s*(self|peer|project|learned)\s*\|\s*([^|]*?)\s*\|\s*(.+?)\s*\]$",
    re.MULTILINE,
)

# Matches: [MEMORY:correct | domain | subject | new content]
CORRECTION_TAG_RE = re.compile(
    r"^\[MEMORY:correct\s*\|\s*(self|peer|project|learned)\s*\|\s*([^|]*?)\s*\|\s*(.+?)\s*\]$",
    re.MULTILINE,
)

# Guardrails: filter subjective peer memories
# Ported from backend/services/backends/agent_memory.py SUBJECTIVE_PATTERNS
SUBJECTIVE_PATTERNS = [
    re.compile(
        r"\b(slow|fast|bad|good|terrible|great|lazy|brilliant|mediocre|incompetent|careless|sloppy|unreliable|difficult)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(tends to|always|never|usually|often fails|struggles with|not great at|needs hand-holding)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(overcomplicates|over-engineers|too (slow|verbose|aggressive|cautious)|doesn't listen|hard to work with)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(worst|best|most annoying|frustrating|disappointing|impressive)\b",
        re.IGNORECASE,
    ),
]

# Guardrails: filter self-identity rewrites
SELF_IDENTITY_KEYWORDS = ("i am a", "my role is", "i'm a")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_memory_tags(response_text: str) -> tuple[str, list[dict], list[dict]]:
    """Extract [MEMORY: ...] and [MEMORY:correct ...] tags from response.

    Memory tags are only recognized after a ``---`` delimiter at the end of the
    response.  The delimiter and everything after it is stripped from the clean
    text returned as the first element of the tuple.

    Returns:
        (clean_response_text, list_of_memory_dicts, list_of_correction_dicts).
        Each dict has keys: ``domain``, ``subject``, ``content``.
    """
    delimiter_pos = response_text.rfind(MEMORY_DELIMITER)
    if delimiter_pos == -1:
        return response_text, [], []

    suffix = response_text[delimiter_pos + len(MEMORY_DELIMITER) :]

    # Only treat as memory section if it actually contains memory tags.
    # Otherwise the --- is just a markdown horizontal rule.
    if not MEMORY_TAG_RE.search(suffix) and not CORRECTION_TAG_RE.search(suffix):
        return response_text, [], []

    body = response_text[:delimiter_pos].rstrip()
    memories: list[dict] = []
    corrections: list[dict] = []

    # Parse corrections first
    for match in CORRECTION_TAG_RE.finditer(suffix):
        domain = match.group(1)
        subject = match.group(2).strip() or None
        content = match.group(3).strip()
        corrections.append({"domain": domain, "subject": subject, "content": content})

    # Parse regular memories
    for match in MEMORY_TAG_RE.finditer(suffix):
        domain = match.group(1)
        subject = match.group(2).strip() or None
        content = match.group(3).strip()

        # Guardrail: skip subjective peer memories
        if domain == "peer" and any(p.search(content) for p in SUBJECTIVE_PATTERNS):
            logger.debug("Filtered subjective peer memory: %s", content[:80])
            continue

        # Guardrail: skip self-identity rewrites
        if domain == "self" and any(
            kw in content.lower() for kw in SELF_IDENTITY_KEYWORDS
        ):
            logger.debug("Filtered self-identity memory: %s", content[:80])
            continue

        memories.append({"domain": domain, "subject": subject, "content": content})

    return body, memories, corrections
