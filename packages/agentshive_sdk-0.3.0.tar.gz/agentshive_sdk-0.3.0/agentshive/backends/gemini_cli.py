"""Gemini CLI backend."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalGeminiCliBackend(LocalCliBackend):
    """Wraps the ``gemini`` CLI."""

    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("gemini") is not None

    def _base_command(self) -> list[str]:
        return ["gemini", "--approval-mode=yolo", "--output-format", "json", "-p", "-"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        cmd = list(self._base_command())
        if session_id:
            p_idx = cmd.index("-p")
            cmd.insert(p_idx, "--resume")
            cmd.insert(p_idx + 1, session_id)
        return cmd

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            logger.warning(
                "Failed to parse JSON from gemini output, treating as plain text"
            )
            return LocalInvocationResult(text=stdout.strip())

        input_tokens = output_tokens = cache_read = 0
        for model_info in data.get("stats", {}).get("models", {}).values():
            tokens = model_info.get("tokens", {})
            input_tokens += tokens.get("input", 0)
            output_tokens += tokens.get("candidates", 0)
            cache_read += tokens.get("cached", 0)

        return LocalInvocationResult(
            text=data.get("response", ""),
            session_id=data.get("session_id"),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
        )
