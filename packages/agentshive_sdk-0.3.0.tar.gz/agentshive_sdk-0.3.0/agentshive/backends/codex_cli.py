"""Codex CLI backend (JSONL event stream)."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)

_MAX_TRANSIENT_ERRORS = 5


class LocalCodexCliBackend(LocalCliBackend):
    """Wraps the ``codex`` CLI."""

    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("codex") is not None

    def _base_command(self) -> list[str]:
        return ["codex", "exec", "--full-auto", "--json", "-"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        if session_id:
            return ["codex", "exec", "resume", session_id, "-", "--full-auto", "--json"]
        return list(self._base_command())

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        """Parse Codex CLI JSONL event stream.

        Ported from ``local_runner.parse_codex_jsonl``.
        """
        result_text = ""
        session_id = None
        input_tokens = 0
        output_tokens = 0
        cache_read_tokens = 0
        transient_errors = 0

        for line in stdout.strip().split("\n"):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping malformed JSONL line: %s", line[:100])
                continue

            event_type = event.get("type", "")
            if event_type == "thread.started":
                session_id = event.get("thread_id")
            elif event_type == "item.completed":
                item = event.get("item", {})
                text = item.get("text", "")
                if text and item.get("type") == "agent_message":
                    result_text += text
            elif event_type == "message.completed":
                # Legacy format (pre-v0.114): content blocks
                for block in event.get("content", []):
                    if block.get("type") == "text":
                        result_text += block.get("text", "")
            elif event_type == "turn.completed":
                usage = event.get("usage", {})
                input_tokens += usage.get("input_tokens", 0)
                output_tokens += usage.get("output_tokens", 0)
                cache_read_tokens += usage.get("cached_input_tokens", 0)
            elif event_type == "error":
                error_msg = event.get("message", "")
                if "reconnect" in error_msg.lower():
                    transient_errors += 1
                    logger.warning(
                        "Codex transient error (%d/%d): %s",
                        transient_errors,
                        _MAX_TRANSIENT_ERRORS,
                        error_msg[:200],
                    )
                    if transient_errors >= _MAX_TRANSIENT_ERRORS:
                        raise RuntimeError(
                            f"Codex failed after {transient_errors} transient errors: "
                            f"{error_msg[:300]}"
                        )
                else:
                    raise RuntimeError(f"Codex error: {error_msg[:500]}")
            elif event_type == "turn.failed":
                err = event.get("error", {})
                msg = (
                    err.get("message", str(err)) if isinstance(err, dict) else str(err)
                )
                raise RuntimeError(f"Codex turn failed: {msg[:500]}")

        return LocalInvocationResult(
            text=result_text,
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
        )
