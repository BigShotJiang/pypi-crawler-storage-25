"""Per-backend module structure for local CLI agents."""

from .registry import register, create_backend, is_available, list_available, list_all
from .base import LocalCliBackend, LocalInvocationResult
from .claude_code import LocalClaudeCodeBackend
from .gemini_cli import LocalGeminiCliBackend
from .codex_cli import LocalCodexCliBackend
from .openclaw import LocalOpenClawBackend
from .opencode import LocalOpenCodeBackend

register("claude_code", LocalClaudeCodeBackend)
register("gemini_cli", LocalGeminiCliBackend)
register("codex", LocalCodexCliBackend)
register("openclaw", LocalOpenClawBackend)
register("opencode", LocalOpenCodeBackend)

__all__ = [
    "register",
    "create_backend",
    "is_available",
    "list_available",
    "list_all",
    "LocalCliBackend",
    "LocalInvocationResult",
    "LocalClaudeCodeBackend",
    "LocalGeminiCliBackend",
    "LocalCodexCliBackend",
    "LocalOpenClawBackend",
    "LocalOpenCodeBackend",
]
