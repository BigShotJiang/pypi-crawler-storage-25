"""Rate limit detection and retry logic.

Ported from backend/services/backends/base.py.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Callable, TypeVar

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Rate-limit / quota patterns (ported from base.py QUOTA_PATTERNS)
# ---------------------------------------------------------------------------

QUOTA_PATTERNS = [
    re.compile(r"TerminalQuotaError", re.IGNORECASE),
    re.compile(r"QUOTA_EXHAUSTED", re.IGNORECASE),
    re.compile(r"exhausted.*(?:your|api)\s*(?:capacity|quota)", re.IGNORECASE),
    re.compile(r"rate[_\s-]?limit(?:ed|ing)?\s*(?:error|exceeded)", re.IGNORECASE),
    re.compile(r"(?:HTTP|status(?:\s*code)?)\s*429", re.IGNORECASE),
    re.compile(r"too many requests.*(?:retry|wait|later)", re.IGNORECASE),
    re.compile(r"ResourceExhausted", re.IGNORECASE),
]

BASE_DELAY_S = 5
MAX_RETRIES = 3

# ---------------------------------------------------------------------------
# Truncation detection (ported from base.py)
# ---------------------------------------------------------------------------

_TRUNCATION_MAX_CHARS = 200


def _looks_truncated(text: str) -> bool:
    """Heuristic: response is likely truncated if it is short and ends with
    a header-like pattern (trailing ``':'`` or ``'---'``) suggesting the model
    started a section but never produced the body."""
    stripped = text.strip()
    if not stripped or len(stripped) > _TRUNCATION_MAX_CHARS:
        return False
    return stripped.endswith(":") or stripped.endswith("\u2014")


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def classify_rate_limit(text: str) -> str | None:
    """Return a context snippet if *text* contains a rate-limit signal, else ``None``."""
    for pattern in QUOTA_PATTERNS:
        match = pattern.search(text)
        if match:
            start = max(0, match.start() - 80)
            end = min(len(text), match.end() + 120)
            return text[start:end].strip()
    return None


def is_truncated(result_text: str, stop_reason: str | None) -> bool:
    """Check if a response was truncated.

    Two signals:
    1. ``stop_reason == "max_tokens"`` from the LLM.
    2. Heuristic --- short response ending with ``':'`` or em-dash.
    """
    if stop_reason == "max_tokens":
        return True
    return _looks_truncated(result_text)


class RateLimitError(RuntimeError):
    """Raised when a rate-limit / quota error is detected."""

    def __init__(self, backend: str, raw_error: str, attempt: int = 0):
        self.backend = backend
        self.raw_error = raw_error
        self.attempt = attempt
        super().__init__(
            f"Rate limit for '{backend}' (attempt {attempt}): {raw_error[:300]}"
        )


T = TypeVar("T")


async def retry_with_backoff(
    func: Callable[..., T],
    *args,
    max_retries: int = MAX_RETRIES,
    base_delay: float = BASE_DELAY_S,
    **kwargs,
) -> T:
    """Execute *func* with exponential back-off on :class:`RateLimitError`.

    Parameters
    ----------
    func:
        An async callable to execute.
    max_retries:
        Maximum number of retries (in addition to the initial attempt).
    base_delay:
        Initial delay in seconds; tripled on each subsequent retry.

    Returns the result of *func* on success; re-raises after exhausting retries.
    """
    delay = base_delay
    last_exc: RateLimitError | None = None

    for attempt in range(max_retries + 1):
        try:
            return await func(*args, **kwargs)
        except RateLimitError as exc:
            last_exc = exc
            if attempt < max_retries:
                logger.warning(
                    "Rate limit hit (attempt %d/%d), retrying in %.0fs: %s",
                    attempt + 1,
                    max_retries + 1,
                    delay,
                    str(exc)[:200],
                )
                await asyncio.sleep(delay)
                delay *= 3
            else:
                logger.error("Rate limit exhausted after %d attempts", max_retries + 1)

    raise last_exc  # type: ignore[misc]
