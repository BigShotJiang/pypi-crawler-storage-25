from agentshive.local_runner import (
    build_user_prompt,
    build_resume_prompt,
    build_system_prompt,
    build_prompt,
)
from agentshive.models import Attachment, Message


def test_build_user_prompt_no_quote():
    history = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
        Message(
            id="2",
            text="hi there",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
        ),
    ]
    prompt = build_user_prompt(history)
    assert "@user1: hello" in prompt
    assert "@agent1: hi there" in prompt
    assert "MANDATORY_REPLY: NO" in prompt
    # Ensure no empty "In response to" blocks
    assert "In response to" not in prompt


def test_build_user_prompt_with_quote():
    history = [
        Message(
            id="1",
            text="original message",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
        Message(
            id="2",
            text="reply with quote",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"},
        ),
    ]
    prompt = build_user_prompt(history)
    assert "@user1: original message" in prompt
    assert (
        '@agent1: (In response to @user1: "original message") reply with quote'
        in prompt
    )


def test_build_resume_prompt_with_quote():
    new_messages = [
        Message(
            id="2",
            text="reply with quote",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"},
        )
    ]
    prompt = build_resume_prompt(new_messages, handle="agent1", must_reply=True)
    assert (
        '@agent1: (In response to @user1: "original message") reply with quote'
        in prompt
    )
    assert "You were directly addressed. You MUST reply — do not output PASS." in prompt


def test_build_system_prompt_includes_custom_instruction():
    """Per-agent system_instruction is included in the system prompt."""
    prompt = build_system_prompt(
        "You are a senior Python engineer.",
        "claude-eng",
    )
    assert "You are a senior Python engineer." in prompt
    assert "@claude-eng" in prompt


def test_build_system_prompt_includes_space_rules():
    """space_rules are injected as Project Rules."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="Always respond in bullet points.\nNo emojis.",
    )
    assert "## Project Rules" in prompt
    assert "Always respond in bullet points." in prompt
    assert "No emojis." in prompt


def test_build_system_prompt_omits_empty_rules():
    """Empty space_rules should not produce a Project Rules section."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="",
    )
    assert "## Project Rules" not in prompt


def test_build_system_prompt_includes_memory_context():
    """Memory context is appended to the system prompt."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        memory_context="SELF: I prefer concise answers.",
    )
    assert "SELF: I prefer concise answers." in prompt


def test_build_prompt_uses_per_agent_instruction():
    """build_prompt passes system_instruction through to the system prompt."""
    history = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_prompt(
        history,
        "You are the TPM responsible for project tracking.",
        "claude-tpm",
        space_rules="Ship weekly updates.",
    )
    assert "You are the TPM responsible for project tracking." in prompt
    assert "@claude-tpm" in prompt
    assert "## Project Rules" in prompt
    assert "Ship weekly updates." in prompt
    assert "@human: hello" in prompt


def test_build_resume_prompt_includes_project_rules():
    """Resume prompt includes project rules as a context reminder."""
    new_messages = [
        Message(
            id="1",
            text="what's the plan?",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(
        new_messages,
        handle="bot",
        must_reply=True,
        space_rules="Always use TypeScript.\nNo console.log in prod.",
    )
    assert "Context reminder" in prompt
    assert "Project Rules:" in prompt
    assert "Always use TypeScript." in prompt
    assert "No console.log in prod." in prompt
    assert "@human: what's the plan?" in prompt


def test_build_resume_prompt_includes_memory_context():
    """Resume prompt includes memory context as a reminder."""
    new_messages = [
        Message(
            id="1",
            text="hi",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(
        new_messages,
        handle="bot",
        memory_context="LEARNED: The codebase uses FastAPI with aiosqlite.",
    )
    assert "Context reminder" in prompt
    assert "LEARNED: The codebase uses FastAPI with aiosqlite." in prompt


def test_build_resume_prompt_no_context_when_empty():
    """Resume prompt omits context reminder when no rules or memory."""
    new_messages = [
        Message(
            id="1",
            text="hi",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot")
    assert "Context reminder" not in prompt
    assert "Project Rules:" not in prompt


def test_build_resume_prompt_backwards_compatible():
    """Resume prompt still works without the new kwargs (backwards compat)."""
    new_messages = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot", must_reply=False)
    assert "@user1: hello" in prompt
    assert 'output exactly "PASS"' in prompt
    assert "Context reminder" not in prompt


# ---------------------------------------------------------------------------
# Attachment rendering
#
# Regression tests for the bug where build_user_prompt / build_resume_prompt
# iterated messages and only emitted `m.text`, silently dropping every
# m.attachments entry. That made the model receive prompts like
# "@user: what does this pdf say?" with zero mention of the uploaded file, so
# it either confabulated content or replied "I don't see any attachment" even
# though the file was on disk on the server. The fix threads an
# ``attachment_paths`` mapping ({id: local_path}) through the prompt builders
# and renders a `[attachment: name (mime) — local path: ... Use your Read
# tool to open it.]` line per attachment.
# ---------------------------------------------------------------------------


def _msg_with_pdf(**overrides):
    defaults = dict(
        id="m1",
        text="can you read this pdf?",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=[
            Attachment(
                id="att-abc",
                filename="insurance.pdf",
                content_type="application/pdf",
                url="/api/attachments/att-abc",
            )
        ],
    )
    defaults.update(overrides)
    return Message(**defaults)


def test_build_user_prompt_renders_attachment_with_local_path():
    """When a local path is supplied, the prompt tells the agent exactly where to Read it."""
    msg = _msg_with_pdf()
    prompt = build_user_prompt(
        [msg],
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/att-abc_insurance.pdf"},
    )
    assert "@human: can you read this pdf?" in prompt
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "local path: /tmp/ahv/att-abc_insurance.pdf" in prompt
    assert "Use your Read tool to open it." in prompt


def test_build_user_prompt_flags_failed_download():
    """When no local path is supplied, the agent is told the content is unavailable.

    Important: we do NOT silently drop the attachment (that was the old bug) —
    the agent needs to know a file *exists* even if we couldn't fetch it, so
    it can ask the human to re-upload instead of hallucinating.
    """
    msg = _msg_with_pdf()
    prompt = build_user_prompt([msg], must_reply=True, attachment_paths=None)
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "download failed" in prompt
    assert "content is NOT available" in prompt


def test_build_user_prompt_omits_attachment_line_when_no_attachments():
    """Messages without attachments must not gain a bogus attachment line."""
    msg = Message(
        id="m1",
        text="plain text",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
    )
    prompt = build_user_prompt([msg], attachment_paths={"att-abc": "/tmp/x"})
    assert "[attachment:" not in prompt


def test_build_user_prompt_handles_missing_mime_type():
    """A missing/blank content_type should fall back to application/octet-stream, not crash."""
    msg = _msg_with_pdf(
        attachments=[
            Attachment(id="att-1", filename="weird.bin", content_type="", url="/x")
        ]
    )
    prompt = build_user_prompt(
        [msg],
        attachment_paths={"att-1": "/tmp/weird.bin"},
    )
    assert "[attachment: weird.bin (application/octet-stream)" in prompt


def test_build_resume_prompt_renders_attachment_with_local_path():
    """The resume path must render attachments too — this was half of the original bug."""
    msg = _msg_with_pdf()
    prompt = build_resume_prompt(
        [msg],
        handle="claude-eng",
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/att-abc_insurance.pdf"},
    )
    assert "@human: can you read this pdf?" in prompt
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "local path: /tmp/ahv/att-abc_insurance.pdf" in prompt


def test_build_prompt_passes_attachments_through_to_user_prompt():
    """The flat build_prompt wrapper must plumb attachment_paths through."""
    msg = _msg_with_pdf()
    prompt = build_prompt(
        [msg],
        "You are an engineer.",
        "claude-eng",
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/insurance.pdf"},
    )
    assert "local path: /tmp/ahv/insurance.pdf" in prompt


def test_build_user_prompt_renders_multiple_attachments_in_message_order():
    """Multi-attachment messages should render one line per attachment."""
    msg = Message(
        id="m1",
        text="two files attached",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=[
            Attachment(
                id="a1", filename="one.pdf", content_type="application/pdf", url="/x"
            ),
            Attachment(id="a2", filename="two.png", content_type="image/png", url="/x"),
        ],
    )
    prompt = build_user_prompt(
        [msg],
        attachment_paths={"a1": "/tmp/one.pdf", "a2": "/tmp/two.png"},
    )
    # Both files must be present and each linked to its own local path.
    assert "[attachment: one.pdf (application/pdf)" in prompt
    assert "local path: /tmp/one.pdf" in prompt
    assert "[attachment: two.png (image/png)" in prompt
    assert "local path: /tmp/two.png" in prompt
