"""Tests for agentshive.client._process_task using AsyncMock."""

import pytest
from unittest.mock import AsyncMock
from agentshive.client import BackendClient, AgentClient
from agentshive.models import Message, Task


def make_message(id="msg1", thread_id="t1", text="hello"):
    return Message(
        id=id,
        text=text,
        thread_id=thread_id,
        space_id="s1",
        author_handle="user1",
        author_type="human",
    )


@pytest.fixture
def client():
    c = BackendClient(server_url="http://testserver", token="test-token")
    return c


@pytest.fixture
def mock_api(client):
    api = AsyncMock()
    api.ack_task.return_value = {"status": "running"}
    api.complete_task.return_value = {"status": "completed"}
    api.fail_task.return_value = {"status": "failed"}
    api.get_messages.return_value = [make_message()]
    client._api = api
    return api


async def test_process_task_calls_ack_and_complete(client, mock_api):
    handler = AsyncMock()
    client._handler = handler

    task = Task(id="task1", thread_id="t1", agent_handle="bot", backend="claude_code")
    await client._process_task(task)

    mock_api.ack_task.assert_called_once_with("task1")
    mock_api.get_messages.assert_called_once_with("t1")
    handler.assert_called_once()
    # Verify handler receives (agent_handle, backend, msg)
    call_args = handler.call_args
    assert call_args[0][0] == "bot"
    assert call_args[0][1] == "claude_code"
    assert isinstance(call_args[0][2], Message)
    mock_api.complete_task.assert_called_once_with("task1")
    mock_api.fail_task.assert_not_called()


async def test_process_task_no_handler_does_nothing(client, mock_api):
    client._handler = None
    task = Task(id="task1", thread_id="t1")
    await client._process_task(task)

    mock_api.ack_task.assert_not_called()
    mock_api.complete_task.assert_not_called()
    mock_api.fail_task.assert_not_called()


async def test_process_task_fails_when_no_messages(client, mock_api):
    mock_api.get_messages.return_value = []
    handler = AsyncMock()
    client._handler = handler

    task = Task(id="task1", thread_id="t1", agent_handle="bot", backend="claude_code")
    await client._process_task(task)

    mock_api.ack_task.assert_called_once_with("task1")
    mock_api.fail_task.assert_called_once_with("task1", error="No messages in thread")
    handler.assert_not_called()
    mock_api.complete_task.assert_not_called()


async def test_process_task_uses_trigger_message_when_present(client, mock_api):
    msg1 = make_message(id="msg1", text="first")
    msg2 = make_message(id="msg2", text="trigger")
    msg3 = make_message(id="msg3", text="last")
    mock_api.get_messages.return_value = [msg1, msg2, msg3]

    received = []

    async def handler(agent_handle, backend, msg):
        received.append((agent_handle, backend, msg))

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        trigger_message_id="msg2",
    )
    await client._process_task(task)

    assert len(received) == 1
    assert received[0][0] == "bot"
    assert received[0][2].id == "msg2"


async def test_process_task_falls_back_to_last_message_when_trigger_not_found(
    client, mock_api
):
    msg1 = make_message(id="msg1", text="first")
    msg2 = make_message(id="msg2", text="last")
    mock_api.get_messages.return_value = [msg1, msg2]

    received = []

    async def handler(agent_handle, backend, msg):
        received.append(msg)

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        trigger_message_id="nonexistent",
    )
    await client._process_task(task)

    assert len(received) == 1
    assert received[0].id == "msg2"


async def test_process_task_falls_back_to_last_message_when_no_trigger_id(
    client, mock_api
):
    msg1 = make_message(id="msg1", text="first")
    msg2 = make_message(id="msg2", text="last")
    mock_api.get_messages.return_value = [msg1, msg2]

    received = []

    async def handler(agent_handle, backend, msg):
        received.append(msg)

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        trigger_message_id=None,
    )
    await client._process_task(task)

    assert received[0].id == "msg2"


async def test_process_task_binds_api_and_agent_handle_to_trigger_message(
    client, mock_api
):
    msg = make_message()
    mock_api.get_messages.return_value = [msg]

    received = []

    async def handler(agent_handle, backend, m):
        received.append(m)

    client._handler = handler
    task = Task(id="task1", thread_id="t1", agent_handle="bot", backend="claude_code")
    await client._process_task(task)

    assert received[0]._api is client._api
    assert received[0]._task_id == "task1"
    assert received[0]._agent_handle == "bot"


async def test_process_task_passes_system_instruction_to_message(client, mock_api):
    """system_instruction from Task is forwarded to the trigger Message."""
    msg = make_message()
    mock_api.get_messages.return_value = [msg]

    received = []

    async def handler(agent_handle, backend, m):
        received.append(m)

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        system_instruction="You are a senior Python engineer.",
    )
    await client._process_task(task)

    assert received[0]._system_instruction == "You are a senior Python engineer."


async def test_handle_ws_message_parses_system_instruction(client, mock_api):
    """system_instruction from WS payload reaches the handler via Message."""
    received = []

    async def handler(agent_handle, backend, m):
        received.append(m)

    client._handler = handler

    await client._handle_ws_message(
        {
            "type": "task",
            "task_id": "t1",
            "thread_id": "th1",
            "agent_handle": "bot",
            "backend": "claude_code",
            "trigger_message_id": "msg1",
            "system_instruction": "You are a design reviewer.",
        }
    )
    import asyncio

    await asyncio.sleep(0.05)

    assert len(received) == 1
    assert received[0]._system_instruction == "You are a design reviewer."


async def test_process_task_sets_space_id_from_task(client, mock_api):
    """space_id from Task is set on the trigger message (messages lack space_id)."""
    # Message without space_id (as returned by the real API)
    msg = Message(
        id="msg1",
        text="hello",
        thread_id="t1",
        space_id="",
        author_handle="user1",
        author_type="human",
    )
    mock_api.get_messages.return_value = [msg]

    received = []

    async def handler(agent_handle, backend, m):
        received.append(m)

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        space_id="space-123",
    )
    await client._process_task(task)

    assert received[0].space_id == "space-123"


async def test_process_task_preserves_existing_space_id(client, mock_api):
    """If message already has space_id, task doesn't overwrite it."""
    msg = make_message()  # has space_id="s1"
    mock_api.get_messages.return_value = [msg]

    received = []

    async def handler(agent_handle, backend, m):
        received.append(m)

    client._handler = handler
    task = Task(
        id="task1",
        thread_id="t1",
        agent_handle="bot",
        backend="claude_code",
        space_id="space-from-task",
    )
    await client._process_task(task)

    # Original space_id from message is preserved
    assert received[0].space_id == "s1"


async def test_process_task_calls_fail_on_handler_exception(client, mock_api):
    async def bad_handler(agent_handle, backend, msg):
        raise ValueError("handler error")

    client._handler = bad_handler
    task = Task(id="task1", thread_id="t1", agent_handle="bot", backend="claude_code")
    await client._process_task(task)

    mock_api.fail_task.assert_called_once_with("task1", error="handler error")
    mock_api.complete_task.assert_not_called()


async def test_process_task_handles_fail_task_exception(client, mock_api):
    async def bad_handler(agent_handle, backend, msg):
        raise ValueError("handler error")

    mock_api.fail_task.side_effect = Exception("fail_task also broken")
    client._handler = bad_handler
    task = Task(id="task1", thread_id="t1", agent_handle="bot", backend="claude_code")
    # Should not raise even if fail_task also raises
    await client._process_task(task)


async def test_handle_ws_message_creates_task_with_agent_handle(client, mock_api):
    handler = AsyncMock()
    client._handler = handler

    await client._handle_ws_message(
        {
            "type": "task",
            "task_id": "t1",
            "thread_id": "th1",
            "agent_handle": "bot",
            "backend": "claude_code",
            "trigger_message_id": "m1",
        }
    )
    # Give the created task a moment to start
    import asyncio

    await asyncio.sleep(0.05)

    handler.assert_called_once()
    call_args = handler.call_args[0]
    assert call_args[0] == "bot"
    assert call_args[1] == "claude_code"


async def test_handle_ws_message_non_task_type_ignored(client, mock_api):
    handler = AsyncMock()
    client._handler = handler

    await client._handle_ws_message({"type": "ping"})
    await client._handle_ws_message({"type": "connected"})
    handler.assert_not_called()


async def test_on_task_decorator(client):
    @client.on_task
    async def my_handler(agent_handle, backend, msg):
        pass

    assert client._handler is my_handler


async def test_on_message_compat_decorator(client):
    """on_message still works for backwards compatibility."""

    @client.on_message
    async def my_handler(msg):
        pass

    # The wrapper is stored, not the original function
    assert client._handler is not None


async def test_stop_closes_ws_and_api(client, mock_api):
    mock_ws = AsyncMock()
    client._ws = mock_ws

    await client.stop()

    mock_ws.disconnect.assert_called_once()
    mock_api.close.assert_called_once()


def test_agent_client_is_backend_client():
    """AgentClient is a backwards-compat alias for BackendClient."""
    assert AgentClient is BackendClient
