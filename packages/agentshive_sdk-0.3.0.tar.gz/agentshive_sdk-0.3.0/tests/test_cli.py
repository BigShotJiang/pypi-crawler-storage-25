"""Tests for agentshive.cli module."""

from __future__ import annotations

import json

import pytest

from agentshive.cli import main


class TestCLIDispatch:
    def test_no_command_prints_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main([])
        assert exc_info.value.code == 1

    def test_help_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "setup" in out
        assert "start" in out
        assert "stop" in out
        assert "status" in out
        assert "doctor" in out

    def test_setup_subcommand_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--no-interactive" in out


class TestSetupNonInteractive:
    def test_writes_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
        # Also patch at the import location in the setup module
        monkeypatch.setattr(
            "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
        )

        main(
            [
                "setup",
                "--no-interactive",
                "--server",
                "https://example.com",
                "--token",
                "ahv_test_token_123",
            ]
        )

        config_file = tmp_path / "config.json"
        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["server_url"] == "https://example.com"
        assert data["token"] == "ahv_test_token_123"
        assert isinstance(data["backends"], dict)

    # Note: `test_missing_server_exits` was removed for the same reason as
    # `test_config.py::test_missing_server` — ``Config.server_url`` has a
    # default of ``"https://agentshive.agency/"``, so ``setup --no-interactive``
    # without ``--server`` does not exit, it just uses the default.

    def test_missing_token_exits(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
        monkeypatch.setattr(
            "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
        )

        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--no-interactive", "--server", "http://x"])
        assert exc_info.value.code == 1


class TestStopNoProcess:
    def test_stop_no_pid_file(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr(
            "agentshive.commands.stop.PID_FILE", tmp_path / "daemon.pid"
        )
        main(["stop"])
        out = capsys.readouterr().out
        assert "not running" in out.lower()


class TestStatusNoConfig:
    def test_status_no_config(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
        main(["status"])
        out = capsys.readouterr().out
        assert "not found" in out.lower()
