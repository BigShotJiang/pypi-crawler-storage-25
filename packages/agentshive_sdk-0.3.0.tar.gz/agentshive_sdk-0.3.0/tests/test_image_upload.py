"""Tests for generated image detection, upload, and artifact creation."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from agentshive.backends.base import (
    IMAGE_EXTENSIONS,
    MAX_GENERATED_FILE_BYTES,
    LocalCliBackend,
    LocalInvocationResult,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class FakeBackend(LocalCliBackend):
    """Minimal concrete backend for testing file scanning."""

    @classmethod
    def is_available(cls) -> bool:
        return True

    def _base_command(self) -> list[str]:
        return ["echo"]

    def _build_args(self, session_id=None) -> list[str]:
        return ["echo", "hello"]

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        return LocalInvocationResult(text=stdout.strip())


# ---------------------------------------------------------------------------
# _snapshot_image_files / _detect_new_files
# ---------------------------------------------------------------------------


class TestImageFileDetection:
    def test_snapshot_empty_dir(self, tmp_path):
        backend = FakeBackend()
        result = backend._snapshot_image_files(str(tmp_path))
        assert result == {}

    def test_snapshot_detects_image_files(self, tmp_path):
        (tmp_path / "photo.png").write_bytes(b"\x89PNG")
        (tmp_path / "readme.txt").write_text("not an image")
        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(tmp_path))
        assert len(snapshot) == 1
        resolved = str((tmp_path / "photo.png").resolve())
        assert resolved in snapshot

    def test_snapshot_recursive_finds_subdirectory_images(self, tmp_path):
        """Ensures images in subdirectories (e.g. nanobanana-output/) are found."""
        subdir = tmp_path / "output"
        subdir.mkdir()
        (subdir / "generated.png").write_bytes(b"\x89PNG")
        (tmp_path / "root.jpg").write_bytes(b"\xff\xd8")
        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(tmp_path))
        assert len(snapshot) == 2

    def test_snapshot_skips_dotdirs(self, tmp_path):
        dotdir = tmp_path / ".hidden"
        dotdir.mkdir()
        (dotdir / "secret.png").write_bytes(b"\x89PNG")
        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(tmp_path))
        assert len(snapshot) == 0

    def test_snapshot_respects_depth_limit(self, tmp_path):
        # Create a deeply nested file (depth 5)
        deep = tmp_path
        for i in range(5):
            deep = deep / f"level{i}"
            deep.mkdir()
        (deep / "deep.png").write_bytes(b"\x89PNG")
        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(tmp_path))
        # MAX_SCAN_DEPTH is 3, so depth 5 should be missed
        assert len(snapshot) == 0

    def test_snapshot_skips_oversized_files(self, tmp_path):
        big_file = tmp_path / "huge.png"
        big_file.write_bytes(b"\x00" * (MAX_GENERATED_FILE_BYTES + 1))
        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(tmp_path))
        assert len(snapshot) == 0

    def test_snapshot_rejects_symlinks_outside_cwd(self, tmp_path):
        """Symlinks pointing outside cwd are skipped (exfiltration guard)."""
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.png"
        secret.write_bytes(b"\x89PNG")

        workspace = tmp_path / "workspace"
        workspace.mkdir()
        link = workspace / "linked.png"
        link.symlink_to(secret)

        backend = FakeBackend()
        snapshot = backend._snapshot_image_files(str(workspace))
        # The symlink should be skipped because follow_symlinks=False
        # means is_file() returns False for symlinks
        assert len(snapshot) == 0

    def test_detect_new_files(self, tmp_path):
        (tmp_path / "existing.png").write_bytes(b"\x89PNG")
        backend = FakeBackend()
        before = backend._snapshot_image_files(str(tmp_path))

        # Create a new file
        (tmp_path / "new.jpg").write_bytes(b"\xff\xd8")
        new_files = backend._detect_new_files(before, str(tmp_path))
        assert len(new_files) == 1
        assert "new.jpg" in new_files[0]

    def test_detect_new_files_empty_when_unchanged(self, tmp_path):
        (tmp_path / "existing.png").write_bytes(b"\x89PNG")
        backend = FakeBackend()
        before = backend._snapshot_image_files(str(tmp_path))
        new_files = backend._detect_new_files(before, str(tmp_path))
        assert new_files == []

    def test_detect_new_files_none_cwd(self):
        backend = FakeBackend()
        assert backend._detect_new_files({}, None) == []

    def test_snapshot_none_cwd(self):
        backend = FakeBackend()
        assert backend._snapshot_image_files(None) == {}


class TestImageExtensions:
    def test_svg_excluded(self):
        assert ".svg" not in IMAGE_EXTENSIONS

    def test_common_formats_included(self):
        for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp"]:
            assert ext in IMAGE_EXTENSIONS

    def test_heic_formats_included(self):
        for ext in [".heic", ".heif", ".avif", ".apng"]:
            assert ext in IMAGE_EXTENSIONS


class TestGeneratedFilesResult:
    def test_default_empty(self):
        result = LocalInvocationResult(text="hello")
        assert result.generated_files == []

    def test_with_files(self):
        result = LocalInvocationResult(
            text="hello", generated_files=["/a.png", "/b.jpg"]
        )
        assert len(result.generated_files) == 2


# ---------------------------------------------------------------------------
# MIME type derivation (api.py)
# ---------------------------------------------------------------------------


class TestMimeFromExt:
    def test_known_extensions(self):
        from agentshive.api import _mime_from_ext

        assert _mime_from_ext(".png") == "image/png"
        assert _mime_from_ext(".jpg") == "image/jpeg"
        assert _mime_from_ext(".gif") == "image/gif"

    def test_svg_blocked(self):
        from agentshive.api import _mime_from_ext

        assert _mime_from_ext(".svg") == "application/octet-stream"

    def test_unknown_extension(self):
        from agentshive.api import _mime_from_ext

        assert _mime_from_ext(".xyz") == "application/octet-stream"

    def test_all_image_extensions_resolve(self):
        """Every extension in IMAGE_EXTENSIONS produces a non-octet-stream MIME."""
        from agentshive.api import _mime_from_ext

        for ext in IMAGE_EXTENSIONS:
            mime = _mime_from_ext(ext)
            assert mime != "application/octet-stream", f"{ext} resolved to octet-stream"


# ---------------------------------------------------------------------------
# Message.reply_with_files
# ---------------------------------------------------------------------------


class TestReplyWithFiles:
    @pytest.mark.asyncio
    async def test_reply_with_files_calls_api(self):
        mock_api = AsyncMock()
        mock_api.post_message_with_files.return_value = None
        msg = _make_message(mock_api)
        await msg.reply_with_files("text", ["/a.png"])
        mock_api.post_message_with_files.assert_called_once_with(
            thread_id="t1",
            text="text",
            file_paths=["/a.png"],
            agent_handle="bot",
            mentions=None,
            quoted_message_id=None,
            task_id="task1",
        )

    @pytest.mark.asyncio
    async def test_reply_with_files_raises_without_api(self):
        from agentshive.models import Message

        msg = Message(
            id="m1",
            text="",
            thread_id="t1",
            space_id="s1",
            author_handle="u",
            author_type="human",
        )
        with pytest.raises(RuntimeError, match="not bound to an API client"):
            await msg.reply_with_files("text", ["/a.png"])


def _make_message(mock_api):
    from agentshive.models import Message

    msg = Message(
        id="m1",
        text="hello",
        thread_id="t1",
        space_id="s1",
        author_handle="u",
        author_type="human",
        _api=mock_api,
        _task_id="task1",
        _agent_handle="bot",
    )
    return msg
