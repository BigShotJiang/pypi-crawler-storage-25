"""Tests for the on-disk attachment cache used by local_runner.

These cover the behaviour that PR #9 review comments asked for:

* The cache is a single shared directory, not a per-task ``mkdtemp``, so
  paths rendered into the prompt on one task are still valid on the next
  resumed turn.
* Downloads are idempotent — a cache hit short-circuits the HTTP fetch and
  bumps mtime so the age-based pruner treats an active session as fresh.
* The cache directory is created lazily (only when something is about to
  be written) so threads with no attachments leave no trace.
* Pruning removes files whose mtime is older than the TTL, but does not
  touch files that were recently used (mtime bumped).
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from agentshive import local_runner
from agentshive.models import Attachment, Message


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def cache_dir(tmp_path, monkeypatch):
    """Point the module-level cache dir at an isolated tmp path per test."""
    target = tmp_path / "agentshive_att"
    monkeypatch.setattr(local_runner, "_attachment_cache_dir", lambda: str(target))
    return target


def _msg_with_attachments(*atts: Attachment) -> Message:
    return Message(
        id="m1",
        text="please read",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=list(atts),
    )


def _att(
    att_id: str = "att-1",
    filename: str = "insurance.pdf",
    content_type: str = "application/pdf",
    size_bytes: int = 0,
) -> Attachment:
    return Attachment(
        id=att_id,
        filename=filename,
        content_type=content_type,
        url=f"/api/attachments/{att_id}",
        size_bytes=size_bytes,
    )


def _fake_api(payloads: dict[str, bytes]) -> AsyncMock:
    api = AsyncMock()

    async def _get(att_id: str) -> bytes:
        api.call_log.append(att_id)
        return payloads[att_id]

    api.call_log = []
    api.get_attachment_bytes.side_effect = _get
    return api


# ---------------------------------------------------------------------------
# Lazy dir creation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_dir_not_created_when_no_attachments(cache_dir):
    """A thread with zero attachments must not leave an empty dir behind."""
    api = _fake_api({})
    messages = [
        Message(
            id="m1",
            text="hi",
            thread_id="t",
            space_id="s",
            author_handle="human",
            author_type="human",
        ),
    ]

    paths = await local_runner._download_attachments(messages, api)

    assert paths == {}
    assert not cache_dir.exists(), (
        "cache dir must be created lazily — no attachments means no dir"
    )
    assert api.call_log == []


@pytest.mark.asyncio
async def test_cache_dir_not_created_when_all_downloads_fail(cache_dir):
    """If every download 404s we should also leave no empty dir behind."""
    api = AsyncMock()
    api.get_attachment_bytes.side_effect = RuntimeError("boom")
    messages = [_msg_with_attachments(_att("att-1"))]

    paths = await local_runner._download_attachments(messages, api)

    assert paths == {}
    assert not cache_dir.exists()


# ---------------------------------------------------------------------------
# Cache hits / idempotency
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_first_download_writes_file_and_returns_path(cache_dir):
    api = _fake_api({"att-1": b"%PDF-1.4 real bytes"})
    messages = [_msg_with_attachments(_att("att-1"))]

    paths = await local_runner._download_attachments(messages, api)

    assert set(paths) == {"att-1"}
    local = paths["att-1"]
    assert os.path.exists(local)
    with open(local, "rb") as fh:
        assert fh.read() == b"%PDF-1.4 real bytes"
    assert api.call_log == ["att-1"], "first run must hit the network"


@pytest.mark.asyncio
async def test_second_download_is_cache_hit_no_network(cache_dir):
    """A second task must not re-fetch an attachment that is already on disk."""
    api = _fake_api({"att-1": b"first-bytes"})
    messages = [_msg_with_attachments(_att("att-1"))]

    first = await local_runner._download_attachments(messages, api)
    # Clear the call log — we want to see whether the second call hits the API.
    api.call_log.clear()

    second = await local_runner._download_attachments(messages, api)

    assert second == first, "cache hit must return the same path"
    assert api.call_log == [], "cache hit must NOT hit the network"


@pytest.mark.asyncio
async def test_cache_hit_returns_stable_path_across_calls(cache_dir):
    """Review comment 1: paths must not move between tasks.

    A follow-up turn on the same session must see the same local path as
    the turn that originally downloaded the file, otherwise Claude's
    resumed session can't Read what it was shown before.
    """
    api = _fake_api({"att-1": b"payload"})
    messages = [_msg_with_attachments(_att("att-1"))]

    p1 = await local_runner._download_attachments(messages, api)
    p2 = await local_runner._download_attachments(messages, api)
    p3 = await local_runner._download_attachments(messages, api)

    assert p1["att-1"] == p2["att-1"] == p3["att-1"]


@pytest.mark.asyncio
async def test_cache_hit_bumps_mtime(cache_dir):
    """Active use must keep a file alive against the age-based pruner."""
    api = _fake_api({"att-1": b"payload"})
    messages = [_msg_with_attachments(_att("att-1"))]

    paths = await local_runner._download_attachments(messages, api)
    local = paths["att-1"]

    # Backdate the file to simulate it being old from an earlier run.
    old_time = time.time() - 10_000
    os.utime(local, (old_time, old_time))
    assert os.path.getmtime(local) < time.time() - 9_000

    await local_runner._download_attachments(messages, api)

    assert os.path.getmtime(local) > time.time() - 5, (
        "cache hit must bump mtime so the pruner treats it as fresh"
    )


@pytest.mark.asyncio
async def test_zero_byte_cached_file_is_redownloaded(cache_dir):
    """A zero-byte file on disk should be treated as a miss, not a hit.

    Protects against a crashed prior run leaving a truncated file.
    """
    api = _fake_api({"att-1": b"real bytes"})
    # Pre-create a zero-byte "stale" file at the would-be cache path.
    cache_dir.mkdir(parents=True)
    stub = cache_dir / "att-1_insurance.pdf"
    stub.write_bytes(b"")
    assert stub.stat().st_size == 0

    messages = [_msg_with_attachments(_att("att-1"))]
    paths = await local_runner._download_attachments(messages, api)

    assert api.call_log == ["att-1"], "zero-byte file must trigger re-download"
    with open(paths["att-1"], "rb") as fh:
        assert fh.read() == b"real bytes"


# ---------------------------------------------------------------------------
# Pruning
# ---------------------------------------------------------------------------


def test_prune_removes_only_stale_files(cache_dir, monkeypatch):
    """Files older than the TTL get removed; fresh ones stay put."""
    cache_dir.mkdir(parents=True)
    stale = cache_dir / "att-stale_insurance.pdf"
    fresh = cache_dir / "att-fresh_insurance.pdf"
    stale.write_bytes(b"old")
    fresh.write_bytes(b"new")

    now = time.time()
    # Stale: 2h ago. Fresh: 1s ago.
    os.utime(stale, (now - 7200, now - 7200))
    os.utime(fresh, (now - 1, now - 1))

    monkeypatch.setattr(local_runner, "_ATTACHMENT_CACHE_MAX_AGE_S", 3600)
    local_runner._prune_stale_attachments()

    assert not stale.exists(), "stale file should have been pruned"
    assert fresh.exists(), "fresh file must survive pruning"


def test_prune_is_noop_when_cache_dir_missing(cache_dir):
    """Running the pruner before any attachment is downloaded must not crash."""
    assert not cache_dir.exists()
    local_runner._prune_stale_attachments()  # should not raise
    assert not cache_dir.exists()


# ---------------------------------------------------------------------------
# Validation: reject truncated / tampered files
#
# Follow-up to PR #9 review round 2. The original fixup trusted any
# non-empty file at the cache path as a valid cache hit, which meant an
# interrupted prior write, a concurrent writer caught mid-flight, or any
# out-of-band tamper could leave a truncated file that would be reused
# forever. Two layers of defence:
#
#   1. Atomic writes (mkstemp + os.replace) so an SDK-originated write
#      never makes a partial file visible at the cache path.
#   2. Size verification against Attachment.size_bytes (populated by the
#      server) so anything that still ends up at the cache path with the
#      wrong size — e.g. pre-seeded by a test, or a tampered file — is
#      rejected and re-fetched.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_rejects_truncated_file_when_size_known(cache_dir):
    """Reviewer's exact reproduction: pre-seeded partial file must NOT be trusted."""
    cache_dir.mkdir(parents=True)
    full = b"this is the REAL full payload, 46 bytes on disk"
    (cache_dir / "att-1_insurance.pdf").write_bytes(b"partial")  # 7 bytes

    api = _fake_api({"att-1": full})
    messages = [_msg_with_attachments(_att("att-1", size_bytes=len(full)))]

    paths = await local_runner._download_attachments(messages, api)

    assert api.call_log == ["att-1"], (
        "size mismatch must force re-download, not trust the partial file"
    )
    assert open(paths["att-1"], "rb").read() == full, (
        "cache file must end up with the full server payload"
    )


@pytest.mark.asyncio
async def test_cache_accepts_exact_size_match(cache_dir):
    """A cached file whose size matches the server-provided size is a hit."""
    cache_dir.mkdir(parents=True)
    payload = b"exactly thirty-two bytes of data"
    assert len(payload) == 32
    (cache_dir / "att-1_insurance.pdf").write_bytes(payload)

    api = _fake_api({"att-1": payload})
    messages = [_msg_with_attachments(_att("att-1", size_bytes=32))]

    paths = await local_runner._download_attachments(messages, api)

    assert api.call_log == [], "exact-size match must be a cache hit"
    assert open(paths["att-1"], "rb").read() == payload


@pytest.mark.asyncio
async def test_cache_hit_fallback_when_size_unknown(cache_dir):
    """Legacy path: if size_bytes is 0, fall back to the non-empty check.

    This keeps older Attachment payloads that don't carry size_bytes working,
    while still benefiting from the atomic-write invariant (no partial writes
    from this SDK can leave a non-empty file at the cache path).
    """
    cache_dir.mkdir(parents=True)
    (cache_dir / "att-1_insurance.pdf").write_bytes(b"some real content")

    api = _fake_api({"att-1": b"should not be fetched"})
    messages = [_msg_with_attachments(_att("att-1", size_bytes=0))]

    paths = await local_runner._download_attachments(messages, api)

    assert api.call_log == [], "non-empty fallback hit expected when size unknown"
    assert open(paths["att-1"], "rb").read() == b"some real content"


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_download_is_atomic_no_partial_file_on_failure(cache_dir, monkeypatch):
    """If the final rename fails, the cache path must not hold a partial file.

    Simulates os.replace raising. The partial temp file should be cleaned up,
    and the cache path should remain in its previous state (absent here, since
    there was no prior successful download).
    """
    api = _fake_api({"att-1": b"some payload"})
    messages = [_msg_with_attachments(_att("att-1", size_bytes=12))]

    original_replace = os.replace

    def failing_replace(src, dst):
        raise OSError("simulated rename failure")

    monkeypatch.setattr(local_runner.os, "replace", failing_replace)

    paths = await local_runner._download_attachments(messages, api)

    assert "att-1" not in paths, "failed write must not produce a cache path"
    local = cache_dir / "att-1_insurance.pdf"
    assert not local.exists(), "cache path must be absent when the write failed"

    # The mkstemp temp file must have been unlinked on failure.
    leftovers = list(cache_dir.iterdir()) if cache_dir.exists() else []
    assert not leftovers, f"partial temp files leaked: {leftovers}"

    # Restore os.replace before another call (monkeypatch handles it on teardown).
    monkeypatch.setattr(local_runner.os, "replace", original_replace)


@pytest.mark.asyncio
async def test_download_overwrites_partial_via_atomic_replace(cache_dir):
    """A successful download over a previously-truncated file ends up with the full content."""
    cache_dir.mkdir(parents=True)
    (cache_dir / "att-1_insurance.pdf").write_bytes(b"stale partial")

    full = b"the correct full payload of known length"
    api = _fake_api({"att-1": full})
    messages = [_msg_with_attachments(_att("att-1", size_bytes=len(full)))]

    paths = await local_runner._download_attachments(messages, api)

    local = Path(paths["att-1"])
    assert local.read_bytes() == full
    # And no stray .partial.* temp files left behind from the atomic write.
    leftovers = [p.name for p in cache_dir.iterdir() if p.name != local.name]
    assert leftovers == [], (
        f"unexpected cache entries after atomic replace: {leftovers}"
    )


@pytest.mark.asyncio
async def test_active_download_then_prune_keeps_file(cache_dir, monkeypatch):
    """End-to-end: download → prune → cache hit → prune → file still present.

    Exercises the interaction between the mtime bump on cache hit and the
    age-based pruner. A file that is still being used must survive pruning.
    """
    monkeypatch.setattr(local_runner, "_ATTACHMENT_CACHE_MAX_AGE_S", 3600)
    api = _fake_api({"att-1": b"payload"})
    messages = [_msg_with_attachments(_att("att-1"))]

    paths = await local_runner._download_attachments(messages, api)
    local = paths["att-1"]
    assert os.path.exists(local)

    local_runner._prune_stale_attachments()
    assert os.path.exists(local), "fresh file must survive first prune"

    # Cache hit bumps mtime; prune again and ensure it still survives.
    await local_runner._download_attachments(messages, api)
    local_runner._prune_stale_attachments()
    assert os.path.exists(local), "cache hit + prune must keep file alive"
