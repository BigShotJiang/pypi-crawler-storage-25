# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Generate peptides from CTA protein sequences and check CTA exclusivity.

Requires the ``pyensembl`` package (install with ``pip install tsarina[peptides]``).

Typical usage::

    from tsarina.peptides import cta_peptides, cta_exclusive_peptides

    # All 8-11mer peptides from expressed CTAs
    df = cta_peptides()

    # Only peptides found exclusively in CTA proteins (not in any non-CTA protein)
    exclusive = cta_exclusive_peptides()
"""

from __future__ import annotations

from functools import lru_cache
from typing import Union

import pandas as pd

AA20 = set("ACDEFGHIKLMNPQRSTVWY")

DEFAULT_PEPTIDE_LENGTHS = (8, 9, 10, 11)


@lru_cache(maxsize=8)
def _proteome_kmers(
    ensembl_release: int,
    lengths: tuple[int, ...],
    gene_ids: frozenset[str] | None = None,
) -> frozenset[str]:
    """Return every k-mer found in the requested subset of the Ensembl proteome.

    Single cached primitive behind every tsarina function that needs to
    subtract a self-peptide background — CTA exclusivity, viral human-
    exclusivity, and viral cancer-specificity all call this with
    different ``gene_ids`` filters.

    Parameters
    ----------
    ensembl_release
        Ensembl release (e.g. 112).
    lengths
        Peptide lengths to enumerate.
    gene_ids
        Frozenset of Ensembl gene IDs to restrict the walk to.  ``None``
        (default) iterates every protein-coding gene in the release,
        matching what a full-proteome background walk would produce.

    Returns
    -------
    frozenset[str]
        Unique k-mers at the requested lengths across the chosen gene
        subset, with any non-AA20 residue stretches dropped.

    Notes
    -----
    The walk is expensive (~10-60s depending on release + length mix +
    gene subset size).  Result is ``@lru_cache``'d keyed on
    ``(ensembl_release, lengths, gene_ids)``, so a second call with the
    same arguments returns in sub-millisecond time.  Cache holds up to
    8 combinations — enough for a handful of common partitions
    (non-CTA, CTA, full proteome) across 1-2 releases.  Clear via
    ``_proteome_kmers.cache_clear()``.

    Long-term this primitive is a candidate to move upstream into
    ``hitlist.proteome`` (tracked in hitlist#99) so sibling packages
    can share a cross-package cache.  Call sites would collapse from
    ``_proteome_kmers(r, l, gene_ids)`` to the one-line
    ``hitlist.proteome_kmer_set(r, l, gene_ids=gene_ids)``.
    """
    from pyensembl import EnsemblRelease

    ensembl = EnsemblRelease(ensembl_release)

    if gene_ids is None:
        genes = (g for g in ensembl.genes() if g.biotype == "protein_coding")
    else:
        genes = _genes_by_id(ensembl, gene_ids)

    kmers: set[str] = set()
    for gene in genes:
        for t in gene.transcripts:
            if t.biotype != "protein_coding":
                continue
            try:
                seq = t.protein_sequence
            except Exception:
                continue
            if not seq:
                continue
            for k in lengths:
                for i in range(len(seq) - k + 1):
                    pep = seq[i : i + k]
                    if set(pep).issubset(AA20):
                        kmers.add(pep)
    return frozenset(kmers)


def _genes_by_id(ensembl, gene_ids):
    """Yield ``ensembl.gene_by_id`` results for each id, skipping those
    that fail lookup or are non-protein-coding."""
    for gene_id in gene_ids:
        try:
            gene = ensembl.gene_by_id(gene_id)
        except ValueError:
            continue
        if gene.biotype != "protein_coding":
            continue
        yield gene


@lru_cache(maxsize=4)
def _non_cta_gene_ids(ensembl_release: int) -> frozenset[str]:
    """Cached frozenset of non-CTA Ensembl gene IDs for a release.

    Pre-building the frozenset means downstream ``_proteome_kmers``
    lookups reuse a single hashable instance rather than rebuilding
    from the mutable ``CTA_partition_gene_ids(...).non_cta`` set on
    every call.
    """
    from .partition import CTA_partition_gene_ids

    return frozenset(CTA_partition_gene_ids(ensembl_release).non_cta)


@lru_cache(maxsize=4)
def _cta_gene_ids(ensembl_release: int) -> frozenset[str]:
    """Cached frozenset of CTA Ensembl gene IDs for a release."""
    from .partition import CTA_partition_gene_ids

    return frozenset(CTA_partition_gene_ids(ensembl_release).cta)


def cta_peptides(
    ensembl_release: int = 112,
    lengths: tuple[int, ...] = DEFAULT_PEPTIDE_LENGTHS,
    flank_length: int = 15,
) -> pd.DataFrame:
    """Generate all peptides from expressed CTA canonical protein sequences.

    Parameters
    ----------
    ensembl_release
        Ensembl release for protein sequences (default 112).
    lengths
        Peptide lengths to generate (default 8, 9, 10, 11).
    flank_length
        Number of flanking residues to include for processing prediction
        (default 15).

    Returns
    -------
    pd.DataFrame
        Columns: ``gene_name``, ``gene_id``, ``transcript_id``,
        ``peptide``, ``length``, ``start`` (1-based), ``end``,
        ``n_flank``, ``c_flank``.
    """
    from pyensembl import EnsemblRelease

    from .gene_sets import CTA_gene_ids

    ensembl = EnsemblRelease(ensembl_release)
    cta_ids = CTA_gene_ids()

    rows: list[dict] = []
    for gene_id in sorted(cta_ids):
        try:
            gene = ensembl.gene_by_id(gene_id)
        except ValueError:
            continue

        # Pick the canonical (longest) protein-coding transcript
        best_transcript = None
        best_length = 0
        for t in gene.transcripts:
            if t.biotype != "protein_coding":
                continue
            try:
                seq = t.protein_sequence
            except Exception:
                continue
            if seq and len(seq) > best_length:
                best_transcript = t
                best_length = len(seq)

        if best_transcript is None:
            continue

        protein = best_transcript.protein_sequence
        if not protein:
            continue

        for k in lengths:
            for i in range(len(protein) - k + 1):
                pep = protein[i : i + k]
                if not set(pep).issubset(AA20):
                    continue
                n_flank = protein[max(0, i - flank_length) : i]
                c_flank = protein[i + k : i + k + flank_length]
                rows.append(
                    {
                        "gene_name": gene.name,
                        "gene_id": gene_id,
                        "transcript_id": best_transcript.id,
                        "peptide": pep,
                        "length": k,
                        "start": i + 1,
                        "end": i + k,
                        "n_flank": n_flank,
                        "c_flank": c_flank,
                    }
                )

    return pd.DataFrame(rows)


def cta_exclusive_peptides(
    ensembl_release: int = 112,
    lengths: tuple[int, ...] = DEFAULT_PEPTIDE_LENGTHS,
) -> pd.DataFrame:
    """Return CTA peptides that do NOT appear in any non-CTA protein.

    This filters the output of :func:`cta_peptides` to only include
    peptides whose sequence is exclusive to CTA proteins -- i.e., the
    peptide is not found as a substring of any non-CTA protein-coding
    gene's canonical protein sequence.

    Parameters
    ----------
    ensembl_release
        Ensembl release (default 112).
    lengths
        Peptide lengths to generate (default 8, 9, 10, 11).

    Returns
    -------
    pd.DataFrame
        Same columns as :func:`cta_peptides`, filtered to exclusive peptides.

    Notes
    -----
    The non-CTA k-mer set is computed once per ``(ensembl_release, lengths)``
    via :func:`_proteome_kmers` and cached for the life of the process.
    First call pays ~10-30s walking the non-CTA transcript set; subsequent
    calls with the same inputs return in sub-millisecond time.
    """
    noncta_peptides = _proteome_kmers(
        ensembl_release, tuple(lengths), _non_cta_gene_ids(ensembl_release)
    )
    cta_df = cta_peptides(ensembl_release=ensembl_release, lengths=lengths)
    mask = ~cta_df["peptide"].isin(noncta_peptides)
    return cta_df[mask].reset_index(drop=True)


def build_pmhc_table(
    peptide_df: pd.DataFrame,
    alleles: Union[list[str], None] = None,
) -> pd.DataFrame:
    """Combine a peptide DataFrame with an allele panel to produce a pMHC table.

    Parameters
    ----------
    peptide_df
        DataFrame with at least a ``peptide`` column (and typically
        ``gene_name``, ``gene_id``, etc.).
    alleles
        List of HLA allele names.  If None, uses the IEDB-27 panel.

    Returns
    -------
    pd.DataFrame
        Cross-product of peptides and alleles, with an ``allele`` column added.
    """
    if alleles is None:
        from .alleles import IEDB27_AB

        alleles = IEDB27_AB

    allele_df = pd.DataFrame({"allele": alleles, "_key": 1})
    peptide_cross = peptide_df.assign(_key=1)
    result = peptide_cross.merge(allele_df, on="_key").drop(columns="_key")
    return result
