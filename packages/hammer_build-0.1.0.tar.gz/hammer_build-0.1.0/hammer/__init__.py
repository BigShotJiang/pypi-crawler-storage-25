import ctypes
from ctypes import c_void_p, c_char_p, c_int, c_double
import ctypes.util
import sys
import os



# Artifact types — compose with bitwise OR, e.g. `static_lib | shared_lib`.
executable = 1 << 0
static_lib = 1 << 1
shared_lib = 1 << 2

debug   = 0
info    = 1
warning = 2
error   = 3

# TODO: gather in cleaner way
c_language = 0
cpp_language = 1
asm_language = 2


def _load_library(name: str):
    path = ctypes.util.find_library(name)

    if path:
        try:
            lib = ctypes.CDLL(path)
            return lib
        except:
            pass


    # Fallback: construct manually
    if sys.platform.endswith("bsd") or sys.platform.startswith(("linux", "dragonfly")):
        libname = f"lib{name}.so"
    elif sys.platform == "darwin":
        libname = f"lib{name}.dylib"
    elif sys.platform == "win32":
        libname = f"{name}.dll"
    else:
        raise RuntimeError(f"Unsupported platform: {sys.platform}")

    return ctypes.CDLL(libname)




try:
    _lib = _load_library("hammer")
except OSError:
    sys.stderr.write("Hammer was not found. Please install it first from here: https://codeberg.org/navier-1/hammer\n")
    raise




# ---- void-returning APIs ------------------------------------------------- #

_lib.SetLogLevel.argtypes = [c_int]
_lib.SetLogLevel.restype  = None

# Log is variadic on the C side (`void Log(loglevel_t, const char* fmt, ...)`);
# we leave argtypes unset so ctypes doesn't enforce a fixed signature. The
# Python wrapper always passes `"%s"` as the format to neutralise any `%`
# characters the caller may have in their message.
_lib.Log.restype = None

_lib.DestroyTarget.argtypes = [c_void_p]
_lib.DestroyTarget.restype  = None

_lib.PrintTarget.argtypes = [c_void_p]
_lib.PrintTarget.restype  = None


# ---- target_t* constructor --------------------------------------------- #

_lib.CreateTarget.argtypes = [c_char_p, c_int, c_char_p]
_lib.CreateTarget.restype  = c_void_p


# ---- int-returning target configuration APIs ---------------------------- #

_lib.AddSources.argtypes = [c_void_p, c_char_p]
_lib.AddSources.restype  = c_int

_lib.AddSourcesFromDir.argtypes = [c_void_p, c_char_p, c_char_p]
_lib.AddSourcesFromDir.restype  = c_int

_lib.AddIncludes.argtypes = [c_void_p, c_char_p]
_lib.AddIncludes.restype  = c_int

_lib.AddGlobbedDir.argtypes = [c_void_p, c_char_p, c_char_p]
_lib.AddGlobbedDir.restype  = c_int

_lib.AddDefines.argtypes = [c_void_p, c_char_p]
_lib.AddDefines.restype  = c_int

_lib.AddDefinesForSources.argtypes = [c_void_p, c_char_p, c_char_p]
_lib.AddDefinesForSources.restype  = c_int

_lib.AddCompilerFlags.argtypes = [c_void_p, c_char_p]
_lib.AddCompilerFlags.restype  = c_int

_lib.AddCompilerFlagsForSources.argtypes = [c_void_p, c_char_p, c_char_p]
_lib.AddCompilerFlagsForSources.restype  = c_int

_lib.AddLinkerFlags.argtypes = [c_void_p, c_char_p]
_lib.AddLinkerFlags.restype  = c_int

_lib.AddLibraries.argtypes = [c_void_p, c_char_p]
_lib.AddLibraries.restype  = c_int

_lib.AddLibraryDirs.argtypes = [c_void_p, c_char_p]
_lib.AddLibraryDirs.restype  = c_int

_lib.SetCompiler.argtypes = [c_void_p, c_int, c_char_p]
_lib.SetCompiler.restype  = c_int

_lib.Build.argtypes = [c_void_p]
_lib.Build.restype  = c_int


# ---- other APIs -------------------------------------- #

_lib.GitFetch.argtypes = [c_char_p, c_char_p]
_lib.GitFetch.restype  = c_int

_lib.timer_start.argtypes = None
_lib.timer_start.restype  = None

_lib.timer_stop.argtypes = None
_lib.timer_stop.restype  = None

_lib.timer_get_elapsed_seconds.argtypes = None
_lib.timer_get_elapsed_seconds.restype  = c_double

_lib.stdout_mute.argtypes = None
_lib.stdout_mute.restype  = None

_lib.stdout_unmute.argtypes = None
_lib.stdout_unmute.restype  = None

# ---- module-level helpers ---------------------------------------------- #

def set_log_level(lvl: int) -> None:
    _lib.SetLogLevel(lvl)

def log(level: int, message: str) -> None:
    # Pass the message as a single printf argument so stray `%` characters
    # in the caller's string aren't interpreted as format specifiers.
    _lib.Log(c_int(level), b"%s", message.encode('utf-8'))

def stdout_mute() -> None:
    _lib.stdout_mute()

def stdout_unmute() -> None:
    _lib.stdout_unmute()

def clone(repo: str, version: str = None):
    if not version:
        version = 'latest'

    _lib.GitFetch(repo.encode('utf-8'), version.encode('utf-8'))



class timer:
    def start() -> None:
        _lib.timer_start()

    def stop() -> None:
        _lib.timer_stop()

    def get_elapsed_seconds() -> float:
        return _lib.timer_get_elapsed_seconds()



# TODO: add checks on reval for all functions; make it so that we raise a runtime error if they fail
class target:
    def __init__(self, name: str, artifact_type: int, build_dir: str):
        self.name = name
        self._ptr = _lib.CreateTarget(name.encode('utf-8'), int(artifact_type), build_dir.encode('utf-8'))
        self._ptr = c_void_p(self._ptr)

    def __del__(self):
        if hasattr(self, "_ptr") and self._ptr:
            _lib.DestroyTarget(self._ptr)
            self._ptr = None

    def add_sources(self, sources: str):
        _lib.AddSources(self._ptr, sources.encode('utf-8'))

    def add_sources_from_dir(self, directory: str, sources: str):
        _lib.AddSourcesFromDir(self._ptr, directory.encode('utf-8'), sources.encode('utf-8'))

    def add_includes(self, includes: str):
        _lib.AddIncludes(self._ptr, includes.encode('utf-8'))

    def add_globbed_dir(self, directory: str, accepted_extensions: str = '.c .cc .cpp'):
        _lib.AddGlobbedDir(self._ptr, directory.encode('utf-8'), accepted_extensions.encode('utf-8'))

    def add_defines(self, defines: str, sources: str = None):
        if not sources:
            ret = _lib.AddDefines(self._ptr, defines.encode('utf-8'))
        else:
            ret = _lib.AddDefinesForSources(self._ptr, defines.encode('utf-8'), sources.encode('utf-8'))

        if ret != 0:
            raise RuntimeError(f"Failed to add defines for target {self.name}")

    def add_compiler_flags(self, flags: str, sources: str = None):
        if not sources:
            ret = _lib.AddCompilerFlags(self._ptr, flags.encode('utf-8'))
        else:
            ret = _lib.AddCompilerFlagsForSources(self._ptr, flags.encode('utf-8'), sources.encode('utf-8'))

        if ret != 0:
            raise RuntimeError(f"Failed to set compiler flags for {self.name}")

    def add_linker_flags(self, flags: str):
        _lib.AddLinkerFlags(self._ptr, flags.encode('utf-8'))

    def add_libraries(self, libraries: str):
        _lib.AddLibraries(self._ptr, libraries.encode('utf-8'))

    def add_library_dirs(self, dirs: str):
        _lib.AddLibraryDirs(self._ptr, dirs.encode('utf-8'))

    def set_compiler(self, language: int, compiler: str):
        # TODO: add checks
        _lib.SetCompiler(self._ptr, language, compiler.encode('utf-8'))

    def build(self):
        _lib.Build(self._ptr)

    def print(self):
        _lib.PrintTarget(self._ptr)
