# without this file you will not be able to run the package as
# /usr/bin/python3 -m ymvas
# or
# python3 -m ymvas

import os, sys
from ymvas.client import Operator
from ymvas.errors import YException


# main cli used for command line
# example:
# > ym server
def execute():
    cli = Operator( os.getcwd() )
    
    if cli.version: # print version
        from .__init__ import __version__
        print( __version__ )
        sys.exit(0)

    if cli.help: # print help
        cli.print_help()
        sys.exit(0)

    action, args, kwargs = cli.parse()

    # no action specified
    if action is None:
        cli.print_help()
        sys.exit(1)
    
    try:
        print(args,kwargs)
        sys.exit(action(*args,**kwargs))
    except YException as e:
        # raise e
        print(e)
        sys.exit(1)

# main cli to use as ymvas cli
# example
# > python3 -m ymvas server
if __name__ == "__main__":
    execute()
