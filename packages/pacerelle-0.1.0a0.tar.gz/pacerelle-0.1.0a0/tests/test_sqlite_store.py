from __future__ import annotations

import sqlite3
from pathlib import Path

from agent_gateway_sdk import SQLiteSignalStore, _SignalStore


def test_sqlite_store_crud_and_pragmas(tmp_path: Path) -> None:
    agent_id = "agent-1"
    store = SQLiteSignalStore(agent_id, root=tmp_path)
    try:
        assert store.path == tmp_path / agent_id / "signal.db"
        assert store.load() is None

        store.save(b"snapshot-v1")
        assert store.load() == b"snapshot-v1"

        store.save(b"snapshot-v2")
        assert store.load() == b"snapshot-v2"

        # PRAGMAs must be the ones the ticket calls out:
        # journal_mode=wal so concurrent reads do not block writes,
        # secure_delete=1 so overwritten ratchet keys are zeroed from free pages.
        conn = sqlite3.connect(str(store.path))
        try:
            journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            secure_delete = conn.execute("PRAGMA secure_delete").fetchone()[0]
        finally:
            conn.close()
        assert str(journal_mode).lower() == "wal"
        assert int(secure_delete) == 1

        store.clear()
        assert store.load() is None
    finally:
        store.close()


def test_sqlite_store_persists_signal_session_across_restart(tmp_path: Path) -> None:
    """End-to-end: encrypt with store A, persist snapshot, rebuild store B from
    snapshot, and confirm B can keep decrypting messages from the original peer.
    This is the CA-2 spirit for SDK Python (without the gateway/Redis inbox piece).
    """
    persistent = SQLiteSignalStore("agent-restart", root=tmp_path)
    try:
        agent = _SignalStore("agent:agent-restart")
        human = _SignalStore("human:user-1:conv-1")
        try:
            human.process_prekey_bundle("agent:agent-restart", agent.generate_prekey_bundle())

            # Establish the session both directions before snapshotting.
            ct1 = human.encrypt("agent:agent-restart", b"hello")
            assert agent.decrypt("human:user-1:conv-1", ct1) == b"hello"
            ct_back = agent.encrypt("human:user-1:conv-1", b"hi back")
            assert human.decrypt("agent:agent-restart", ct_back) == b"hi back"

            persistent.save(agent.export_bytes())
        finally:
            agent.close()

        # Simulate a restart: rebuild only from the persisted snapshot.
        snapshot = persistent.load()
        assert snapshot is not None
        restored = _SignalStore.from_snapshot("agent:agent-restart", snapshot)
        try:
            ct2 = human.encrypt("agent:agent-restart", b"after restart")
            assert restored.decrypt("human:user-1:conv-1", ct2) == b"after restart"

            ct3 = restored.encrypt("human:user-1:conv-1", b"reply after restart")
            assert human.decrypt("agent:agent-restart", ct3) == b"reply after restart"
        finally:
            restored.close()
            human.close()
    finally:
        persistent.close()
