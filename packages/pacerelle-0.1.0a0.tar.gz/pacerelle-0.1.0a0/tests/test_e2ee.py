import base64

from agent_gateway_sdk import _SignalStore


def test_native_signal_store_round_trips_agent_and_human() -> None:
    agent = _SignalStore("agent:agent-1")
    human = _SignalStore("human:user-1:conversation-1")
    try:
        agent_bundle = agent.generate_prekey_bundle()
        human.process_prekey_bundle("agent:agent-1", agent_bundle)

        human_ciphertext = human.encrypt("agent:agent-1", b"bonjour agent")
        assert base64.b64encode(human_ciphertext).decode() != "bonjour agent"
        assert agent.decrypt("human:user-1:conversation-1", human_ciphertext) == b"bonjour agent"

        agent_ciphertext = agent.encrypt("human:user-1:conversation-1", b"bonjour humain")
        assert human.decrypt("agent:agent-1", agent_ciphertext) == b"bonjour humain"
    finally:
        agent.close()
        human.close()
