import asyncio
import base64
import json
from typing import Any
from urllib.request import Request

from agent_gateway_sdk import (
    AgentAttachment,
    AgentGatewayClient,
    AgentWidgetResponse,
    SignalPreKeyBundle,
    __version__,
    _encode_chat_payload,
    _merge_attachments,
    _parse_chat_payload,
    _parse_payload_parts,
)


def test_version() -> None:
    assert __version__ == "0.1.0a0"


def test_signal_prekey_bundle_shape() -> None:
    bundle = SignalPreKeyBundle(
        registration_id=1,
        device_id=1,
        identity_key="identity",
        signed_prekey_id=2,
        signed_prekey_public="signed",
        signed_prekey_signature="signed-sig",
        kyber_prekey_id=3,
        kyber_prekey_public="kyber",
        kyber_prekey_signature="kyber-sig",
        prekey_id=4,
        prekey_public="pre",
    )
    assert bundle.prekey_id == 4


def test_agent_client_accepts_e2ee_when_native_signal_library_is_available() -> None:
    client = AgentGatewayClient(token="token", agent_id="agent", e2ee=True)
    assert client.e2ee is True


def test_chat_payload_exposes_attachment_secrets_to_agent_message() -> None:
    text, secrets = _parse_chat_payload(
        '{"kind":"chat.message","text":"hello","attachments":[{"id":"att-1","blob_id":"blob-1","key_b64":"key","iv_b64":"iv"}]}'
    )
    attachments = _merge_attachments(
        [
            {
                "id": "att-1",
                "name": "photo.png",
                "mime": "image/png",
                "size": 42,
                "blob_id": "blob-1",
                "sha256": "sha",
            }
        ],
        secrets,
    )

    assert text == "hello"
    assert len(attachments) == 1
    assert attachments[0].blob_id == "blob-1"
    assert attachments[0].key_b64 == "key"
    assert attachments[0].iv_b64 == "iv"


def test_encode_chat_payload_matches_web_attachment_secret_shape() -> None:
    payload = _encode_chat_payload(
        "voici le fichier",
        [
            AgentAttachment(
                id="att-1",
                name="report.txt",
                mime="text/plain",
                size=12,
                blob_id="blob-1",
                key_b64="key",
                iv_b64="iv",
            )
        ],
    )

    assert payload == (
        '{"kind": "chat.message", "text": "voici le fichier", '
        '"attachments": [{"id": "att-1", "blob_id": "blob-1", "key_b64": "key", "iv_b64": "iv"}]}'
    )


def test_widget_response_payload_is_correlated() -> None:
    parsed = _parse_payload_parts(
        '{"type":"widget.response","id":"response-1","v":1,"ref":"confirm-1","value":true,"cancelled":false}'
    )

    assert parsed["text"] == "Widget response"
    assert parsed["widget_response"] == AgentWidgetResponse(
        id="response-1",
        ref="confirm-1",
        value=True,
        cancelled=False,
    )


def test_confirm_widget_helper_sends_standard_widget() -> None:
    class FakeWS:
        def __init__(self) -> None:
            self.sent: list[str] = []

        async def send(self, payload: str) -> None:
            self.sent.append(payload)

    async def run() -> None:
        client = AgentGatewayClient(token="token", agent_id="agent")
        fake = FakeWS()
        client._ws = fake
        widget_id = await client.send_confirm_widget(
            conversation_id="conversation-1",
            to="user-1",
            title="Delete file?",
            body="This cannot be undone.",
            danger=True,
            widget_id="confirm-1",
        )

        assert widget_id == "confirm-1"
        env = json.loads(fake.sent[0])
        payload = base64.b64decode(env["payload_b64"]).decode()
        assert json.loads(payload) == {
            "type": "widget.standard",
            "id": "confirm-1",
            "v": 1,
            "kind": "confirm",
            "spec": {
                "title": "Delete file?",
                "body": "This cannot be undone.",
                "danger": True,
            },
        }

    asyncio.run(run())


def test_upload_file_encrypts_blob_before_agent_upload(monkeypatch: Any) -> None:
    captured: dict[str, Any] = {}

    class FakeResponse:
        status = 201

        def __enter__(self) -> "FakeResponse":
            return self

        def __exit__(self, *_exc: object) -> None:
            return None

        def read(self) -> bytes:
            return (
                b'{"id":"blob-1","name":"cipher.bin","mime":"application/octet-stream",'
                b'"size":28,"sha256":"sha"}'
            )

    def fake_urlopen(req: Request) -> FakeResponse:
        captured["data"] = req.data
        captured["headers"] = dict(req.header_items())
        return FakeResponse()

    monkeypatch.setattr("agent_gateway_sdk.request.urlopen", fake_urlopen)
    client = AgentGatewayClient(token="token", agent_id="agent", e2ee=True)

    attachment = client.upload_file(name="report.txt", data=b"secret report", mime="text/plain")

    assert attachment.blob_id == "blob-1"
    assert attachment.key_b64
    assert attachment.iv_b64
    assert captured["data"] != b"secret report"
    assert captured["headers"]["Authorization"] == "Bearer token"
