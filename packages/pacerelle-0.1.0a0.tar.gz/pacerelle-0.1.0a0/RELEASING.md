# Releasing

The source tree keeps `AgentGatewayClient` pointed at `http://localhost:8080`
so local development works without extra configuration.

Release artifacts must be built with the public API URL injected:

```bash
python scripts/build_release.py
uvx twine check dist/pacerelle-*
```

The release script sets `PACERELLE_SDK_DEFAULT_BASE_URL=https://api.pacerelle.com`
for the Hatch build. The build hook restores the source file after the artifact
is created, so the working tree keeps the local default.

## TestPyPI

```bash
python scripts/upload_testpypi.py
```

The current helper uploads the source distribution only. Wheels built directly
from the local WSL environment can use a raw `linux_aarch64` platform tag, which
TestPyPI rejects. Build publishable binary wheels with a manylinux-compatible
builder before uploading wheels.
