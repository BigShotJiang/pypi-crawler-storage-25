from __future__ import annotations

import asyncio
import base64
import contextlib
import ctypes
import json
import os
import sqlite3
import sys
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypedDict, cast
from urllib import request

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

__version__ = "0.1.0a0"


@dataclass(frozen=True)
class AgentMessage:
    id: str
    conversation_id: str
    from_id: str
    text: str
    encrypted: bool
    raw: dict[str, Any]
    attachments: list[AgentAttachment] | None = None
    reply_to_message_id: str | None = None
    widget_response: AgentWidgetResponse | None = None
    widget_update: AgentWidgetUpdate | None = None


@dataclass(frozen=True)
class AgentAttachment:
    id: str
    name: str
    mime: str
    size: int
    blob_id: str
    sha256: str | None = None
    width: int | None = None
    height: int | None = None
    duration_ms: int | None = None
    thumbnail_blob_id: str | None = None
    key_b64: str | None = None
    iv_b64: str | None = None


@dataclass(frozen=True)
class AgentWidgetResponse:
    id: str
    ref: str
    value: Any | None = None
    cancelled: bool = False


@dataclass(frozen=True)
class AgentWidgetUpdate:
    id: str
    ref: str
    patch: dict[str, Any]


class ParsedPayload(TypedDict):
    text: str
    secrets: dict[str, dict[str, str]]
    widget_response: AgentWidgetResponse | None
    widget_update: AgentWidgetUpdate | None


@dataclass(frozen=True)
class SignalPreKeyBundle:
    registration_id: int
    device_id: int
    identity_key: str
    signed_prekey_id: int
    signed_prekey_public: str
    signed_prekey_signature: str
    kyber_prekey_id: int
    kyber_prekey_public: str
    kyber_prekey_signature: str
    prekey_id: int | None = None
    prekey_public: str | None = None


class SignalRuntimeError(RuntimeError):
    pass


class _NativePreKeyBundle(ctypes.Structure):
    _fields_ = [
        ("registration_id", ctypes.c_uint32),
        ("device_id", ctypes.c_uint32),
        ("pre_key_id", ctypes.c_uint32),
        ("pre_key_public", ctypes.POINTER(ctypes.c_ubyte)),
        ("pre_key_public_len", ctypes.c_size_t),
        ("signed_pre_key_id", ctypes.c_uint32),
        ("signed_pre_key_public", ctypes.POINTER(ctypes.c_ubyte)),
        ("signed_pre_key_public_len", ctypes.c_size_t),
        ("signed_pre_key_signature", ctypes.POINTER(ctypes.c_ubyte)),
        ("signed_pre_key_signature_len", ctypes.c_size_t),
        ("kyber_pre_key_id", ctypes.c_uint32),
        ("kyber_pre_key_public", ctypes.POINTER(ctypes.c_ubyte)),
        ("kyber_pre_key_public_len", ctypes.c_size_t),
        ("kyber_pre_key_signature", ctypes.POINTER(ctypes.c_ubyte)),
        ("kyber_pre_key_signature_len", ctypes.c_size_t),
        ("identity_key", ctypes.POINTER(ctypes.c_ubyte)),
        ("identity_key_len", ctypes.c_size_t),
    ]


class _SignalLibrary:
    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self.path = str(path or _find_signal_library())
        self.lib = ctypes.CDLL(self.path)
        self._configure()

    def _configure(self) -> None:
        lib = self.lib
        lib.signal_store_new.argtypes = [ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t]
        lib.signal_store_new.restype = ctypes.c_void_p
        lib.signal_store_free.argtypes = [ctypes.c_void_p]
        lib.signal_store_free.restype = None
        lib.signal_prekey_bundle_free.argtypes = [ctypes.POINTER(_NativePreKeyBundle)]
        lib.signal_prekey_bundle_free.restype = None
        lib.poc_free_buf.argtypes = [ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t]
        lib.poc_free_buf.restype = None
        lib.signal_store_generate_prekey_bundle.argtypes = [
            ctypes.c_void_p,
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.POINTER(_NativePreKeyBundle),
        ]
        lib.signal_store_generate_prekey_bundle.restype = ctypes.c_int
        lib.signal_store_process_prekey_bundle.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.c_uint32,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.c_uint32,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
        ]
        lib.signal_store_process_prekey_bundle.restype = ctypes.c_int
        bytes_out_args: Any = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),
            ctypes.POINTER(ctypes.c_size_t),
        ]
        lib.signal_store_encrypt.argtypes = bytes_out_args
        lib.signal_store_encrypt.restype = ctypes.c_int
        lib.signal_store_decrypt.argtypes = bytes_out_args
        lib.signal_store_decrypt.restype = ctypes.c_int
        lib.signal_store_export.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),
            ctypes.POINTER(ctypes.c_size_t),
        ]
        lib.signal_store_export.restype = ctypes.c_int
        lib.signal_store_import.argtypes = [
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
        ]
        lib.signal_store_import.restype = ctypes.c_void_p


class _SignalStore:
    def __init__(self, name: str, library_path: str | os.PathLike[str] | None = None) -> None:
        self._ctx: int | None = None
        self._library = _SignalLibrary(library_path)
        name_buf = _bytes(name.encode())
        self._ctx = self._library.lib.signal_store_new(name_buf, len(name_buf))
        if not self._ctx:
            raise SignalRuntimeError("could not create Signal store")

    @classmethod
    def from_snapshot(
        cls,
        name: str,
        snapshot: bytes,
        library_path: str | os.PathLike[str] | None = None,
    ) -> _SignalStore:
        # Construct without invoking signal_store_new — the snapshot import is the source of truth.
        instance = cls.__new__(cls)
        instance._ctx = None
        instance._library = _SignalLibrary(library_path)
        name_buf = _bytes(name.encode())
        snapshot_buf = _bytes(snapshot)
        ctx = instance._library.lib.signal_store_import(
            name_buf, len(name_buf), snapshot_buf, len(snapshot_buf)
        )
        if not ctx:
            raise SignalRuntimeError("could not import Signal store snapshot")
        instance._ctx = ctx
        return instance

    def export_bytes(self) -> bytes:
        out = ctypes.POINTER(ctypes.c_ubyte)()
        out_len = ctypes.c_size_t()
        code = self._library.lib.signal_store_export(
            self._ctx, ctypes.byref(out), ctypes.byref(out_len)
        )
        _raise_signal_error(code)
        try:
            return _read_ptr(out, out_len.value)
        finally:
            self._library.lib.poc_free_buf(out, out_len.value)

    def close(self) -> None:
        if self._ctx:
            self._library.lib.signal_store_free(self._ctx)
            self._ctx = None

    def __del__(self) -> None:
        self.close()

    def generate_prekey_bundle(
        self,
        pre_key_id: int = 1,
        signed_pre_key_id: int = 1,
        kyber_pre_key_id: int = 1,
    ) -> SignalPreKeyBundle:
        raw = _NativePreKeyBundle()
        code = self._library.lib.signal_store_generate_prekey_bundle(
            self._ctx,
            pre_key_id,
            signed_pre_key_id,
            kyber_pre_key_id,
            ctypes.byref(raw),
        )
        _raise_signal_error(code)
        try:
            return SignalPreKeyBundle(
                registration_id=raw.registration_id,
                device_id=raw.device_id,
                identity_key=_b64(_read_ptr(raw.identity_key, raw.identity_key_len)),
                signed_prekey_id=raw.signed_pre_key_id,
                signed_prekey_public=_b64(
                    _read_ptr(raw.signed_pre_key_public, raw.signed_pre_key_public_len)
                ),
                signed_prekey_signature=_b64(
                    _read_ptr(raw.signed_pre_key_signature, raw.signed_pre_key_signature_len)
                ),
                kyber_prekey_id=raw.kyber_pre_key_id,
                kyber_prekey_public=_b64(
                    _read_ptr(raw.kyber_pre_key_public, raw.kyber_pre_key_public_len)
                ),
                kyber_prekey_signature=_b64(
                    _read_ptr(raw.kyber_pre_key_signature, raw.kyber_pre_key_signature_len)
                ),
                prekey_id=raw.pre_key_id,
                prekey_public=_b64(_read_ptr(raw.pre_key_public, raw.pre_key_public_len)),
            )
        finally:
            self._library.lib.signal_prekey_bundle_free(ctypes.byref(raw))

    def process_prekey_bundle(self, remote_name: str, bundle: SignalPreKeyBundle) -> None:
        remote = _bytes(remote_name.encode())
        pre_key_public = _bytes(_unb64(_required(bundle.prekey_public, "prekey_public")))
        signed_prekey_public = _bytes(_unb64(bundle.signed_prekey_public))
        signed_prekey_signature = _bytes(_unb64(bundle.signed_prekey_signature))
        kyber_prekey_public = _bytes(_unb64(bundle.kyber_prekey_public))
        kyber_prekey_signature = _bytes(_unb64(bundle.kyber_prekey_signature))
        identity_key = _bytes(_unb64(bundle.identity_key))
        code = self._library.lib.signal_store_process_prekey_bundle(
            self._ctx,
            remote,
            len(remote),
            bundle.registration_id,
            bundle.device_id,
            _required(bundle.prekey_id, "prekey_id"),
            pre_key_public,
            len(pre_key_public),
            bundle.signed_prekey_id,
            signed_prekey_public,
            len(signed_prekey_public),
            signed_prekey_signature,
            len(signed_prekey_signature),
            bundle.kyber_prekey_id,
            kyber_prekey_public,
            len(kyber_prekey_public),
            kyber_prekey_signature,
            len(kyber_prekey_signature),
            identity_key,
            len(identity_key),
        )
        _raise_signal_error(code)

    def encrypt(self, remote_name: str, plaintext: bytes) -> bytes:
        return self._crypt(self._library.lib.signal_store_encrypt, remote_name, plaintext)

    def decrypt(self, remote_name: str, framed: bytes) -> bytes:
        return self._crypt(self._library.lib.signal_store_decrypt, remote_name, framed)

    def _crypt(self, fn: Any, remote_name: str, payload: bytes) -> bytes:
        remote = _bytes(remote_name.encode())
        payload_buf = _bytes(payload)
        out = ctypes.POINTER(ctypes.c_ubyte)()
        out_len = ctypes.c_size_t()
        code = fn(
            self._ctx,
            remote,
            len(remote),
            payload_buf,
            len(payload_buf),
            ctypes.byref(out),
            ctypes.byref(out_len),
        )
        _raise_signal_error(code)
        try:
            return _read_ptr(out, out_len.value)
        finally:
            self._library.lib.poc_free_buf(out, out_len.value)


class SQLiteSignalStore:
    """Persistent Signal store snapshot for SDK Python agents.

    The wrapped libsignal store serializes to a single opaque protobuf blob via
    `signal_store_export`/`signal_store_import`. T-015 §2 originally listed five
    granular tables (identity_keys, sessions, prekeys, signed_prekeys,
    kyber_prekeys); we deliberately collapse them into one `signal_snapshot` row
    because libsignal does not expose those subfields individually. WAL mode +
    `PRAGMA secure_delete=ON` ensure that overwritten ratchet keys are zeroed on
    disk rather than left in free pages.
    """

    def __init__(self, agent_id: str, root: str | os.PathLike[str] | None = None) -> None:
        base = Path(root) if root else Path.home() / ".myagents"
        self.agent_dir = base / agent_id
        self.agent_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.agent_dir / "signal.db"
        self._conn = sqlite3.connect(str(self.path), isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA secure_delete=ON")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS signal_snapshot (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                blob BLOB NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

    def load(self) -> bytes | None:
        row = self._conn.execute(
            "SELECT blob FROM signal_snapshot WHERE id = 1"
        ).fetchone()
        return bytes(row[0]) if row else None

    def save(self, blob: bytes) -> None:
        self._conn.execute(
            """
            INSERT INTO signal_snapshot (id, blob, updated_at)
            VALUES (1, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET
                blob = excluded.blob,
                updated_at = CURRENT_TIMESTAMP
            """,
            (sqlite3.Binary(blob),),
        )

    def clear(self) -> None:
        self._conn.execute("DELETE FROM signal_snapshot")

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> SQLiteSignalStore:
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


MessageHandler = Callable[[AgentMessage, "AgentGatewayClient"], Awaitable[None] | None]


class AgentGatewayClient:
    def __init__(
        self,
        *,
        token: str,
        agent_id: str,
        base_url: str = "https://api.pacerelle.com",
        ws_url: str | None = None,
        e2ee: bool = False,
        signal_library_path: str | os.PathLike[str] | None = None,
        persistent_store: SQLiteSignalStore | None = None,
        store_root: str | os.PathLike[str] | None = None,
    ) -> None:
        self.token = token
        self.agent_id = agent_id
        self.base_url = base_url.rstrip("/")
        self.ws_url = (ws_url or self.base_url.replace("http", "ws", 1)).rstrip("/")
        self.e2ee = e2ee
        self._library_path = signal_library_path
        self._persistent_store: SQLiteSignalStore | None = None
        self._signal_store: _SignalStore | None = None
        self._identity_changed_handler: Callable[[str], Awaitable[None] | None] | None = None

        if e2ee:
            self._persistent_store = persistent_store or SQLiteSignalStore(agent_id, store_root)
            snapshot = self._persistent_store.load()
            peer_name = _agent_peer_name(agent_id)
            if snapshot is not None:
                self._signal_store = _SignalStore.from_snapshot(
                    peer_name, snapshot, signal_library_path
                )
            else:
                self._signal_store = _SignalStore(peer_name, signal_library_path)

        self._handler: MessageHandler | None = None
        self._ws: Any | None = None

    def on_message(self, handler: MessageHandler) -> None:
        self._handler = handler

    def on_identity_changed(self, handler: Callable[[str], Awaitable[None] | None]) -> None:
        """Register a callback for `IDENTITY_CHANGED` envelopes from the gateway.

        The callback receives the peer user id whose identity key changed. The
        SDK has already purged the matching Signal session before invoking it.
        """
        self._identity_changed_handler = handler

    def publish_prekey_bundle(self, bundle: SignalPreKeyBundle) -> None:
        self._json_request(
            "PUT",
            "/agent/prekey-bundle",
            {
                "registration_id": bundle.registration_id,
                "device_id": bundle.device_id,
                "identity_key": bundle.identity_key,
                "signed_prekey_id": bundle.signed_prekey_id,
                "signed_prekey_public": bundle.signed_prekey_public,
                "signed_prekey_signature": bundle.signed_prekey_signature,
                "kyber_prekey_id": bundle.kyber_prekey_id,
                "kyber_prekey_public": bundle.kyber_prekey_public,
                "kyber_prekey_signature": bundle.kyber_prekey_signature,
            },
        )
        if bundle.prekey_id is not None and bundle.prekey_public is not None:
            self._json_request(
                "POST",
                "/agent/one-time-prekeys",
                {
                    "one_time_prekeys": [
                        {"prekey_id": bundle.prekey_id, "public_key": bundle.prekey_public}
                    ]
                },
                expect_body=False,
            )
        self._save_snapshot()

    async def connect(self) -> None:
        if self.e2ee:
            self.publish_prekey_bundle(self._signal().generate_prekey_bundle())
        try:
            import websockets
        except ImportError as exc:
            raise RuntimeError("Install websockets to use AgentGatewayClient.connect()") from exc

        async with websockets.connect(f"{self.ws_url}/ws/agent?token={self.token}") as ws:
            self._ws = ws
            async for raw in ws:
                await self._handle_raw(str(raw))

    async def send_message(
        self,
        *,
        conversation_id: str,
        to: str,
        text: str,
        reply_to_message_id: str | None = None,
        attachments: list[AgentAttachment] | None = None,
    ) -> None:
        if self._ws is None:
            raise RuntimeError("agent is not connected")
        plaintext = _encode_chat_payload(text, attachments or [])
        encrypted = self.e2ee
        payload_b64 = (
            _b64(
                self._signal().encrypt(
                    _human_peer_name(to, conversation_id), plaintext.encode()
                )
            )
            if encrypted
            else _encode_text(plaintext)
        )
        if encrypted:
            self._save_snapshot()
        env = {
            "type": "MSG",
            "id": str(uuid.uuid4()),
            "conversation_id": conversation_id,
            "to": to,
            "payload_b64": payload_b64,
            "encrypted": encrypted,
        }
        if reply_to_message_id:
            env["reply_to_message_id"] = reply_to_message_id
        if attachments:
            env["attachments"] = [_attachment_public(attachment) for attachment in attachments]
        await self._ws.send(json.dumps(env))

    def upload_file(
        self,
        *,
        name: str,
        data: bytes,
        mime: str = "application/octet-stream",
    ) -> AgentAttachment:
        if not self.e2ee:
            raise RuntimeError("E2EE must be enabled before uploading encrypted attachments")
        key = AESGCM.generate_key(bit_length=256)
        iv = os.urandom(12)
        ciphertext = AESGCM(key).encrypt(iv, data, None)
        uploaded = self._raw_request(
            "POST",
            "/agent/blobs",
            ciphertext,
            {
                "Content-Type": "application/octet-stream",
                "X-Blob-Name": _safe_header_value(name or "file"),
            },
        )
        return AgentAttachment(
            id=str(uuid.uuid4()),
            name=name or cast(str, uploaded.get("name", "file")),
            mime=mime or "application/octet-stream",
            size=len(data),
            blob_id=cast(str, uploaded["id"]),
            sha256=uploaded.get("sha256") if isinstance(uploaded.get("sha256"), str) else None,
            key_b64=_b64(key),
            iv_b64=_b64(iv),
        )

    async def send_file(
        self,
        *,
        conversation_id: str,
        to: str,
        name: str,
        data: bytes,
        mime: str = "application/octet-stream",
        text: str = "",
        reply_to_message_id: str | None = None,
    ) -> AgentAttachment:
        attachment = self.upload_file(name=name, data=data, mime=mime)
        await self.send_message(
            conversation_id=conversation_id,
            to=to,
            text=text,
            reply_to_message_id=reply_to_message_id,
            attachments=[attachment],
        )
        return attachment

    async def send_media(
        self,
        *,
        conversation_id: str,
        to: str,
        name: str,
        data: bytes,
        mime: str,
        text: str = "",
        reply_to_message_id: str | None = None,
        width: int | None = None,
        height: int | None = None,
        duration_ms: int | None = None,
        thumbnail_blob_id: str | None = None,
    ) -> AgentAttachment:
        uploaded = self.upload_file(name=name, data=data, mime=mime)
        attachment = AgentAttachment(
            **{
                **uploaded.__dict__,
                "width": width,
                "height": height,
                "duration_ms": duration_ms,
                "thumbnail_blob_id": thumbnail_blob_id,
            }
        )
        await self.send_message(
            conversation_id=conversation_id,
            to=to,
            text=text,
            reply_to_message_id=reply_to_message_id,
            attachments=[attachment],
        )
        return attachment

    async def send_confirm_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        body: str | None = None,
        danger: bool | None = None,
        labels: dict[str, str] | None = None,
        widget_id: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        spec: dict[str, Any] = {"title": title}
        if body:
            spec["body"] = body
        if danger is not None:
            spec["danger"] = danger
        if labels:
            spec["labels"] = labels
        return await self._send_standard_widget(
            conversation_id, to, "confirm", spec, widget_id=widget_id, expires_at=expires_at
        )

    async def send_choice_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        options: list[dict[str, Any]],
        widget_id: str | None = None,
        expires_at: str | None = None,
        **extra: Any,
    ) -> str:
        return await self._send_standard_widget(
            conversation_id,
            to,
            "choice",
            {"title": title, "options": options, **extra},
            widget_id=widget_id,
            expires_at=expires_at,
        )

    async def send_permission_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        body: str | None = None,
        scopes: list[str] | None = None,
        widget_id: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        spec: dict[str, Any] = {"title": title}
        if body:
            spec["body"] = body
        if scopes:
            spec["scopes"] = scopes
        return await self._send_standard_widget(
            conversation_id, to, "permission", spec, widget_id=widget_id, expires_at=expires_at
        )

    async def send_form_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        fields: list[dict[str, Any]],
        widget_id: str | None = None,
        expires_at: str | None = None,
        **options: Any,
    ) -> str:
        return await self._send_standard_widget(
            conversation_id,
            to,
            "form",
            {"title": title, "fields": fields, **options},
            widget_id=widget_id,
            expires_at=expires_at,
        )

    async def send_progress_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        value: int | float,
        widget_id: str | None = None,
        expires_at: str | None = None,
        **options: Any,
    ) -> str:
        return await self._send_standard_widget(
            conversation_id,
            to,
            "progress",
            {"title": title, "value": value, **options},
            widget_id=widget_id,
            expires_at=expires_at,
        )

    async def send_file_picker_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        body: str | None = None,
        multiple: bool | None = None,
        accept: list[str] | None = None,
        max_files: int | None = None,
        widget_id: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        spec: dict[str, Any] = {"title": title}
        if body:
            spec["body"] = body
        if multiple is not None:
            spec["multiple"] = multiple
        if accept:
            spec["accept"] = accept
        if max_files is not None:
            spec["maxFiles"] = max_files
        return await self._send_standard_widget(
            conversation_id, to, "file-picker", spec, widget_id=widget_id, expires_at=expires_at
        )

    async def send_datetime_widget(
        self,
        *,
        conversation_id: str,
        to: str,
        title: str,
        mode: str,
        body: str | None = None,
        min: str | None = None,
        max: str | None = None,
        widget_id: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        spec: dict[str, Any] = {"title": title, "mode": mode}
        if body:
            spec["body"] = body
        if min:
            spec["min"] = min
        if max:
            spec["max"] = max
        return await self._send_standard_widget(
            conversation_id, to, "datetime", spec, widget_id=widget_id, expires_at=expires_at
        )

    async def send_widget_update(
        self,
        *,
        conversation_id: str,
        to: str,
        ref: str,
        spec: dict[str, Any] | None = None,
        expires_at: str | None = None,
        widget_id: str | None = None,
    ) -> str:
        patch: dict[str, Any] = {}
        payload: dict[str, Any] = {
            "type": "widget.update",
            "id": widget_id or str(uuid.uuid4()),
            "v": 1,
            "ref": ref,
            "patch": patch,
        }
        if spec is not None:
            patch["spec"] = spec
        if expires_at is not None:
            patch["expires_at"] = expires_at
        await self.send_message(conversation_id=conversation_id, to=to, text=json.dumps(payload))
        return cast(str, payload["id"])

    async def _send_standard_widget(
        self,
        conversation_id: str,
        to: str,
        kind: str,
        spec: dict[str, Any],
        *,
        widget_id: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        payload: dict[str, Any] = {
            "type": "widget.standard",
            "id": widget_id or str(uuid.uuid4()),
            "v": 1,
            "kind": kind,
            "spec": spec,
        }
        if expires_at:
            payload["expires_at"] = expires_at
        await self.send_message(conversation_id=conversation_id, to=to, text=json.dumps(payload))
        return cast(str, payload["id"])

    async def _handle_raw(self, raw: str) -> None:
        try:
            env = json.loads(raw)
        except json.JSONDecodeError:
            return
        env_type = env.get("type")
        if env_type == "IDENTITY_CHANGED":
            await self._handle_identity_changed(env)
            return
        if env_type != "MSG":
            return
        encrypted = env.get("encrypted") is True
        if encrypted:
            text = (
                self._signal()
                .decrypt(
                    _human_peer_name(env.get("from", ""), env["conversation_id"]),
                    _unb64(env.get("payload_b64", "")),
                )
                .decode()
            )
            self._save_snapshot()
        else:
            text = _decode_text(env.get("payload_b64", ""))
        parsed = _parse_payload_parts(text)
        message = AgentMessage(
            id=env["id"],
            conversation_id=env["conversation_id"],
            from_id=env.get("from", ""),
            text=parsed["text"],
            encrypted=encrypted,
            raw=env,
            attachments=_merge_attachments(env.get("attachments", []), parsed["secrets"]),
            reply_to_message_id=env.get("reply_to_message_id"),
            widget_response=parsed["widget_response"],
            widget_update=parsed["widget_update"],
        )
        if self._ws is not None and message.from_id:
            await self._ws.send(
                json.dumps(
                    {
                        "type": "ACK_READ",
                        "to": message.from_id,
                        "message_id": message.id,
                        "conversation_id": message.conversation_id,
                    }
                )
            )
        result = self._handler(message, self) if self._handler else None
        if asyncio.iscoroutine(result):
            await result

    def _signal(self) -> _SignalStore:
        if self._signal_store is None:
            raise SignalRuntimeError("E2EE is not enabled for this client")
        return self._signal_store

    def _save_snapshot(self) -> None:
        if self._persistent_store is None or self._signal_store is None:
            return
        # Persistence is best-effort; failing here must not break message flow.
        with contextlib.suppress(SignalRuntimeError):
            self._persistent_store.save(self._signal_store.export_bytes())

    async def _handle_identity_changed(self, env: dict[str, Any]) -> None:
        """Drop the stored Signal session for the peer whose identity rotated.

        The gateway emits `IDENTITY_CHANGED` when it detects that a peer's
        identity_public_key has changed since the last MSG observed for this
        agent. We rebuild a fresh in-memory store and persist it, which forces
        the next outbound message to fetch a new prekey bundle and re-establish
        X3DH from scratch.
        """
        peer_id = env.get("user_id") or env.get("agent_id") or ""
        if self.e2ee and self._signal_store is not None:
            peer_name = _agent_peer_name(self.agent_id)
            self._signal_store.close()
            self._signal_store = _SignalStore(peer_name, self._library_path)
            self._save_snapshot()
        handler = self._identity_changed_handler
        if handler is not None:
            result = handler(peer_id)
            if asyncio.iscoroutine(result):
                await result

    def close(self) -> None:
        if self._signal_store is not None:
            self._signal_store.close()
            self._signal_store = None
        if self._persistent_store is not None:
            self._persistent_store.close()
            self._persistent_store = None

    def _json_request(
        self,
        method: str,
        path: str,
        body: dict[str, Any],
        *,
        expect_body: bool = True,
    ) -> dict[str, Any] | None:
        data = json.dumps(body).encode()
        req = request.Request(
            f"{self.base_url}{path}",
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
            },
        )
        with request.urlopen(req) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"HTTP {resp.status}")
            if not expect_body:
                return None
            return cast(dict[str, Any], json.loads(resp.read().decode()))

    def _raw_request(
        self,
        method: str,
        path: str,
        body: bytes,
        headers: dict[str, str],
    ) -> dict[str, Any]:
        req = request.Request(
            f"{self.base_url}{path}",
            data=body,
            method=method,
            headers={
                "Authorization": f"Bearer {self.token}",
                **headers,
            },
        )
        with request.urlopen(req) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"HTTP {resp.status}")
            return cast(dict[str, Any], json.loads(resp.read().decode()))


def _encode_text(text: str) -> str:
    return _b64(text.encode())


def _decode_text(payload_b64: str) -> str:
    return _unb64(payload_b64).decode()


def _parse_chat_payload(text: str) -> tuple[str, dict[str, dict[str, str]]]:
    parsed = _parse_payload_parts(text)
    return parsed["text"], parsed["secrets"]


def _parse_payload_parts(
    text: str,
) -> ParsedPayload:
    if not text.startswith("{"):
        return {"text": text, "secrets": {}, "widget_response": None, "widget_update": None}
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return {"text": text, "secrets": {}, "widget_response": None, "widget_update": None}
    if not isinstance(parsed, dict):
        return {"text": text, "secrets": {}, "widget_response": None, "widget_update": None}
    if (
        parsed.get("type") == "widget.response"
        and isinstance(parsed.get("id"), str)
        and isinstance(parsed.get("ref"), str)
    ):
        return {
            "text": "Widget cancelled" if parsed.get("cancelled") is True else "Widget response",
            "secrets": {},
            "widget_response": AgentWidgetResponse(
                id=parsed["id"],
                ref=parsed["ref"],
                value=parsed.get("value"),
                cancelled=parsed.get("cancelled") is True,
            ),
            "widget_update": None,
        }
    if (
        parsed.get("type") == "widget.update"
        and isinstance(parsed.get("id"), str)
        and isinstance(parsed.get("ref"), str)
        and isinstance(parsed.get("patch"), dict)
    ):
        return {
            "text": "Widget update",
            "secrets": {},
            "widget_response": None,
            "widget_update": AgentWidgetUpdate(
                id=parsed["id"],
                ref=parsed["ref"],
                patch=parsed["patch"],
            ),
        }
    if parsed.get("kind") != "chat.message" or not isinstance(parsed.get("text"), str):
        return {"text": text, "secrets": {}, "widget_response": None, "widget_update": None}
    secrets: dict[str, dict[str, str]] = {}
    attachments = parsed.get("attachments")
    if isinstance(attachments, list):
        for item in attachments:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            key_b64 = item.get("key_b64")
            iv_b64 = item.get("iv_b64")
            if isinstance(item_id, str) and isinstance(key_b64, str) and isinstance(iv_b64, str):
                secrets[item_id] = {"key_b64": key_b64, "iv_b64": iv_b64}
    return {
        "text": parsed["text"],
        "secrets": secrets,
        "widget_response": None,
        "widget_update": None,
    }


def _encode_chat_payload(text: str, attachments: list[AgentAttachment]) -> str:
    secrets = [
        {
            "id": attachment.id,
            "blob_id": attachment.blob_id,
            "key_b64": attachment.key_b64,
            "iv_b64": attachment.iv_b64,
        }
        for attachment in attachments
        if attachment.key_b64 and attachment.iv_b64
    ]
    if not secrets:
        return text
    return json.dumps({"kind": "chat.message", "text": text, "attachments": secrets})


def _attachment_public(attachment: AgentAttachment) -> dict[str, Any]:
    public: dict[str, Any] = {
        "id": attachment.id,
        "name": attachment.name,
        "mime": attachment.mime,
        "size": attachment.size,
        "blob_id": attachment.blob_id,
    }
    if attachment.sha256:
        public["sha256"] = attachment.sha256
    if attachment.width is not None:
        public["width"] = attachment.width
    if attachment.height is not None:
        public["height"] = attachment.height
    if attachment.duration_ms is not None:
        public["duration_ms"] = attachment.duration_ms
    if attachment.thumbnail_blob_id:
        public["thumbnail_blob_id"] = attachment.thumbnail_blob_id
    return public


def _safe_header_value(value: str) -> str:
    return request.pathname2url(value)[:240]


def _merge_attachments(raw: Any, secrets: dict[str, dict[str, str]]) -> list[AgentAttachment]:
    if not isinstance(raw, list):
        return []
    attachments: list[AgentAttachment] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        item_id = item.get("id")
        name = item.get("name")
        mime = item.get("mime")
        size = item.get("size")
        blob_id = item.get("blob_id")
        if not isinstance(item_id, str):
            continue
        if not isinstance(name, str):
            continue
        if not isinstance(mime, str):
            continue
        if not isinstance(blob_id, str):
            continue
        if not isinstance(size, int):
            continue
        secret = secrets.get(item_id)
        attachments.append(
            AgentAttachment(
                id=item_id,
                name=name,
                mime=mime,
                size=size,
                blob_id=blob_id,
                sha256=item.get("sha256") if isinstance(item.get("sha256"), str) else None,
                width=item.get("width") if isinstance(item.get("width"), int) else None,
                height=item.get("height") if isinstance(item.get("height"), int) else None,
                duration_ms=(
                    item.get("duration_ms") if isinstance(item.get("duration_ms"), int) else None
                ),
                thumbnail_blob_id=(
                    item.get("thumbnail_blob_id")
                    if isinstance(item.get("thumbnail_blob_id"), str)
                    else None
                ),
                key_b64=secret.get("key_b64") if secret else None,
                iv_b64=secret.get("iv_b64") if secret else None,
            )
        )
    return attachments


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def _unb64(payload_b64: str) -> bytes:
    return base64.b64decode(payload_b64.encode())


def _bytes(data: bytes) -> Any:
    return (ctypes.c_ubyte * len(data)).from_buffer_copy(data)


def _read_ptr(ptr: Any, length: int) -> bytes:
    if not ptr and length:
        raise SignalRuntimeError("Signal runtime returned a null buffer")
    return bytes(ctypes.string_at(ptr, length))


def _required(value: int | str | None, name: str) -> Any:
    if value is None:
        raise ValueError(f"{name} is required")
    return value


def _raise_signal_error(code: int) -> None:
    if code == 0:
        return
    names = {
        -1: "null pointer",
        -2: "Signal protocol error",
        -3: "message deserialize error",
        -4: "invalid input",
    }
    raise SignalRuntimeError(names.get(code, f"Signal runtime error {code}"))


def _agent_peer_name(agent_id: str) -> str:
    return f"agent:{agent_id}"


def _human_peer_name(human_id: str, conversation_id: str) -> str:
    return f"human:{human_id}:{conversation_id}"


def _find_signal_library() -> Path:
    configured = os.environ.get("AGENT_GATEWAY_SIGNAL_LIB")
    if configured:
        path = Path(configured)
        if path.exists():
            return path
        raise SignalRuntimeError(f"AGENT_GATEWAY_SIGNAL_LIB does not exist: {path}")

    names = {
        "linux": "libsignalwrap.so",
        "darwin": "libsignalwrap.dylib",
        "win32": "signalwrap.dll",
    }
    lib_name = names.get(sys.platform, "libsignalwrap.so")
    here = Path(__file__).resolve()
    repo_root = here.parents[3]
    candidates = [
        repo_root / "gateway" / "rust" / "signal-wrapper" / "target" / "debug" / lib_name,
        repo_root / "gateway" / "rust" / "signal-wrapper" / "target" / "release" / lib_name,
        repo_root / "target" / "debug" / lib_name,
        repo_root / "target" / "release" / lib_name,
        here.parent / "native" / lib_name,
        here.parent / lib_name,
    ]
    for path in candidates:
        if path.exists():
            return path
    raise SignalRuntimeError(
        "Signal native library not found. Build gateway/rust/signal-wrapper or set "
        "AGENT_GATEWAY_SIGNAL_LIB."
    )
