from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PUBLIC_API_URL = "https://api.pacerelle.com"


def main() -> int:
    env = os.environ.copy()
    env["PACERELLE_SDK_DEFAULT_BASE_URL"] = PUBLIC_API_URL
    return subprocess.call(["uv", "build"], cwd=ROOT, env=env)


if __name__ == "__main__":
    raise SystemExit(main())
