from __future__ import annotations

import asyncio
import os

from pacerelle import AgentGatewayClient


client = AgentGatewayClient(
    token=os.environ["PACERELLE_AGENT_TOKEN"],
    agent_id=os.environ["PACERELLE_AGENT_ID"],
    e2ee=True,
)


async def handle(message, agent):
    print(f"AGENT_MESSAGE {message.text}", flush=True)
    await agent.send_message(
        conversation_id=message.conversation_id,
        to=message.from_id,
        reply_to_message_id=message.id,
        text=f"SDK local echo: {message.text}",
    )
    print("AGENT_REPLIED", flush=True)


client.on_message(handle)
print("AGENT_STARTING", flush=True)
asyncio.run(client.connect())
