from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT.parent / ".env.dev"


def read_token() -> str:
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        if line.startswith("PYTEST_TOKEN="):
            return line.split("=", 1)[1].strip()
    raise RuntimeError("PYTEST_TOKEN is missing from .env.dev")


def main() -> int:
    token = read_token()
    if not token:
        raise RuntimeError("PYTEST_TOKEN is empty")

    env = os.environ.copy()
    env["TWINE_USERNAME"] = "__token__"
    env["TWINE_PASSWORD"] = token
    distributions = sorted(str(path) for path in (ROOT / "dist").glob("pacerelle-*.tar.gz"))
    if not distributions:
        raise RuntimeError("No pacerelle distributions found in dist/")

    return subprocess.call(
        [
            "uvx",
            "twine",
            "upload",
            "--repository",
            "testpypi",
            "--non-interactive",
            "--skip-existing",
            "--verbose",
            "--disable-progress-bar",
            *distributions,
        ],
        cwd=ROOT,
        env=env,
    )


if __name__ == "__main__":
    raise SystemExit(main())
