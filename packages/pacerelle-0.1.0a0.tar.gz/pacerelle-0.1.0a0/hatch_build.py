from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


CLIENT_PATH = Path("src/agent_gateway_sdk/__init__.py")
LOCAL_DEFAULT = 'base_url: str = "http://localhost:8080"'


class CustomBuildHook(BuildHookInterface):
    _original_client_source: str | None = None

    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        release_base_url = os.environ.get("PACERELLE_SDK_DEFAULT_BASE_URL")
        if release_base_url:
            release_default = f'base_url: str = "{release_base_url.rstrip("/")}"'
            client_path = Path(self.root) / CLIENT_PATH
            self._original_client_source = client_path.read_text(encoding="utf-8")
            if LOCAL_DEFAULT not in self._original_client_source:
                if release_default in self._original_client_source:
                    self._original_client_source = None
                else:
                    raise RuntimeError(f"Could not find SDK default URL in {CLIENT_PATH}")
            else:
                client_path.write_text(
                    self._original_client_source.replace(
                        LOCAL_DEFAULT,
                        release_default,
                    ),
                    encoding="utf-8",
                )

        if self.target_name == "wheel":
            build_data["infer_tag"] = True
            build_data["pure_python"] = False

    def finalize(
        self,
        version: str,
        build_data: dict[str, Any],
        artifact_path: str,
    ) -> None:
        if self._original_client_source is not None:
            client_path = Path(self.root) / CLIENT_PATH
            client_path.write_text(self._original_client_source, encoding="utf-8")
            self._original_client_source = None


def get_build_hook() -> type[CustomBuildHook]:
    return CustomBuildHook
