"""Postgres + pgvector storage backend — cloud mode.

DORMANT until first paying Azure customer triggers cloud-track activation
(per `docs/architecture/IMPORTANT-PRODUCT-ARCHITECTURE.md`).

This file ships as a STUB that raises a clear error if instantiated. The
real implementation lands in EPIC G when cloud track activates. The stub
exists now so the abstraction layer compiles + tests cover all three
modes (memory / sqlite / postgres) without errors at import time.

When activated, this module will:
- Use asyncpg + SQLAlchemy 2.0 for queries
- Use pgvector for ALMA embeddings (HNSW index, 1536-dim)
- Honor multi-tenant RLS via per-request `SET app.current_org_id`
- Read DATABASE_URL from env / Cloudflare secret binding
- Mirror schemas from migrations 009-013

Schema source of truth: `database/provider/migrations/009_create_verdicts.sql`
through `014_enable_rls_aios_contract.sql`.
"""

from __future__ import annotations

from typing import Any

from agents._shared.storage.backends.base import (
    AlmaStore,
    EvidenceChainStore,
    KeyMaterialStore,
    StorageBackend,
    StorageMode,
    VerdictRepository,
)


class _PostgresStub:
    def __init__(self, role: str) -> None:
        self._role = role

    def _raise(self) -> None:
        raise NotImplementedError(
            f"Postgres backend stub: {self._role} not implemented. "
            "Cloud-track storage is dormant per "
            "docs/architecture/IMPORTANT-PRODUCT-ARCHITECTURE.md. "
            "Lands in EPIC G when first paying Azure customer activates "
            "the cloud track. For now, use AGTESTARI_MODE=local (default)."
        )


class _PostgresVerdictRepository(_PostgresStub, VerdictRepository):
    def __init__(self) -> None:
        super().__init__("VerdictRepository")

    async def save(self, org_id: str, verdict: dict[str, Any]) -> str:
        self._raise()
        return ""  # unreachable

    async def get(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        self._raise()
        return None

    async def list_recent(
        self,
        org_id: str,
        agent_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        self._raise()
        return []

    async def delete(self, org_id: str, run_id: str) -> bool:
        self._raise()
        return False


class _PostgresEvidenceChainStore(_PostgresStub, EvidenceChainStore):
    def __init__(self) -> None:
        super().__init__("EvidenceChainStore")

    async def save_chain(
        self,
        org_id: str,
        run_id: str,
        chain: dict[str, Any],
    ) -> str:
        self._raise()
        return ""

    async def get_chain(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        self._raise()
        return None

    async def get_link(self, org_id: str, link_id: str) -> dict[str, Any] | None:
        self._raise()
        return None

    async def store_blob(
        self,
        org_id: str,
        run_id: str,
        link_id: str,
        blob_bytes: bytes,
        content_type: str = "application/octet-stream",
    ) -> str:
        self._raise()
        return ""

    async def get_blob(self, blob_url: str) -> bytes | None:
        self._raise()
        return None


class _PostgresAlmaStore(_PostgresStub, AlmaStore):
    def __init__(self) -> None:
        super().__init__("AlmaStore")

    async def add_heuristic(self, *args: Any, **kwargs: Any) -> str:
        self._raise()
        return ""

    async def add_anti_pattern(self, *args: Any, **kwargs: Any) -> str:
        self._raise()
        return ""

    async def add_episode(self, *args: Any, **kwargs: Any) -> str:
        self._raise()
        return ""

    async def query_similar(self, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
        self._raise()
        return []

    async def get_anti_patterns(self, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
        self._raise()
        return []

    async def get_heuristics(self, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
        self._raise()
        return []


class _PostgresKeyMaterialStore(_PostgresStub, KeyMaterialStore):
    def __init__(self) -> None:
        super().__init__("KeyMaterialStore")

    async def get_signing_key(self, org_id: str) -> bytes | None:
        self._raise()
        return None

    async def get_encryption_key(self, org_id: str) -> bytes | None:
        self._raise()
        return None

    async def rotate_keys(self, org_id: str) -> None:
        self._raise()


def make_postgres_backend(database_url: str | None = None) -> StorageBackend:
    """Stub factory. Raises if anyone calls into it.

    Real implementation lands in EPIC G. The factory returns a backend
    handle that fails fast on first method call rather than at import.
    """
    return StorageBackend(
        mode=StorageMode.CLOUD,
        verdicts=_PostgresVerdictRepository(),
        chains=_PostgresEvidenceChainStore(),
        alma=_PostgresAlmaStore(),
        keys=_PostgresKeyMaterialStore(),
        metadata={
            "backend": "postgres",
            "status": "stub — dormant until cloud track activates",
            "database_url_set": database_url is not None,
        },
    )
