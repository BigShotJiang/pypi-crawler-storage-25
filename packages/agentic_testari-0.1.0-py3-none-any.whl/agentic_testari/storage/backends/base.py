"""Abstract storage backend interfaces.

These define the contract every backend (SQLite local / Postgres cloud /
in-memory test) must satisfy. The framework code at
`agents/_shared/quality/` calls only these interfaces — never imports a
concrete backend module — so swapping cloud↔local is one env var.

Design principles:
- Async everywhere (matches existing FastAPI + SQLAlchemy 2.0 pattern)
- Dict in / dict out (no ORM lock-in; concrete backends may use ORMs internally)
- Tenant isolation at the call site: all methods take `org_id` explicitly
- Idempotent saves: same `id` overwrites; never raises on re-save
- No exceptions for "not found" — methods return None
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class StorageMode(str, Enum):
    """Selection mode for the storage backend.

    LOCAL (default): SQLite at ~/.agtestari/agtestari.db. Single-user.
    CLOUD: Postgres via DATABASE_URL. Multi-tenant with RLS.
    MEMORY: in-process dict; tests only.
    """

    LOCAL = "local"
    CLOUD = "cloud"
    MEMORY = "memory"


# ─────────────────────────────────────────────────────────────────────────────
# Repository protocols — one per concept
# ─────────────────────────────────────────────────────────────────────────────


class VerdictRepository(ABC):
    """Persists Verdict + Issues + ClassifiedDefects from the framework.

    The framework calls `save(verdict_dict)` after every test run.
    Verdict dict shape matches `agents._shared.quality.verdict.Verdict.to_dict()`.
    """

    @abstractmethod
    async def save(self, org_id: str, verdict: dict[str, Any]) -> str:
        """Persist a verdict. Returns the stored verdict_id (idempotent on re-save)."""

    @abstractmethod
    async def get(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        """Fetch the latest verdict for a run_id. None if not found."""

    @abstractmethod
    async def list_recent(
        self,
        org_id: str,
        agent_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Recent verdicts, newest first. Optionally filter by agent_id."""

    @abstractmethod
    async def delete(self, org_id: str, run_id: str) -> bool:
        """Soft-delete a verdict (cascades to issues + defects). Returns True if removed."""


class EvidenceChainStore(ABC):
    """Persists evidence chain links + Merkle proofs.

    Chain payloads (screenshots, videos, traces) go to blob storage; only
    the data_hash + blob_url + Merkle linking metadata land here. This
    keeps the chain queryable + integrity-checkable even if blob storage
    is unavailable.
    """

    @abstractmethod
    async def save_chain(
        self,
        org_id: str,
        run_id: str,
        chain: dict[str, Any],
    ) -> str:
        """Persist a chain (links + root_hash + signing metadata)."""

    @abstractmethod
    async def get_chain(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        """Fetch full chain by run_id."""

    @abstractmethod
    async def get_link(self, org_id: str, link_id: str) -> dict[str, Any] | None:
        """Fetch a single link by id (for Merkle proof verification)."""

    @abstractmethod
    async def store_blob(
        self,
        org_id: str,
        run_id: str,
        link_id: str,
        blob_bytes: bytes,
        content_type: str = "application/octet-stream",
    ) -> str:
        """Persist a blob payload (screenshot, video, etc). Returns a URL/path
        that can be later fetched via `get_blob`."""

    @abstractmethod
    async def get_blob(self, blob_url: str) -> bytes | None:
        """Fetch blob bytes by URL/path. None if not found."""


class AlmaStore(ABC):
    """Persists ALMA memory: heuristics, anti-patterns, episodes, knowledge,
    preferences. Includes vector similarity search via pgvector / sqlite-vec.
    """

    @abstractmethod
    async def add_heuristic(
        self,
        org_id: str,
        agent_id: str,
        rule: str,
        description: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        ...

    @abstractmethod
    async def add_anti_pattern(
        self,
        org_id: str,
        agent_id: str,
        pattern_name: str,
        description: str,
        avoidance_strategy: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        ...

    @abstractmethod
    async def add_episode(
        self,
        org_id: str,
        agent_id: str,
        episode_type: str,
        context: dict[str, Any],
        actions: list[dict[str, Any]],
        outcome: dict[str, Any],
    ) -> str:
        ...

    @abstractmethod
    async def query_similar(
        self,
        org_id: str,
        agent_id: str,
        memory_type: str,
        query_embedding: list[float],
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Vector similarity search. memory_type ∈ heuristic / anti_pattern /
        episode / knowledge / preference."""

    @abstractmethod
    async def get_anti_patterns(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        ...

    @abstractmethod
    async def get_heuristics(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        ...


class KeyMaterialStore(ABC):
    """Persists per-org Ed25519 signing keys + AES-GCM encryption keys.

    LOCAL backend: OS keychain via `keyring` (macOS Keychain, Windows
    Credential Manager, Linux Secret Service).
    CLOUD backend: encrypted Postgres column with customer-passphrase KEK
    (per ADR-013 / AIDR-024).

    Keys are stored encrypted at rest in both cases — the storage layer
    never sees them in plaintext.
    """

    @abstractmethod
    async def get_signing_key(self, org_id: str) -> bytes | None:
        """Retrieve the Ed25519 signing key for an org. None if not provisioned."""

    @abstractmethod
    async def get_encryption_key(self, org_id: str) -> bytes | None:
        """Retrieve the AES-GCM encryption key for an org. None if not provisioned."""

    @abstractmethod
    async def rotate_keys(self, org_id: str) -> None:
        """Generate new keys, archive old, update active pointer.
        Old keys MUST remain retrievable for chain verification — never deleted."""


# ─────────────────────────────────────────────────────────────────────────────
# StorageBackend — composite handle returned by `get_storage()`
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class StorageBackend:
    """One handle that exposes all four repositories.

    Concrete factories construct this with the right backend wired into each
    field. The framework code holds a `StorageBackend` and never imports
    any concrete module.
    """

    mode: StorageMode
    verdicts: VerdictRepository
    chains: EvidenceChainStore
    alma: AlmaStore
    keys: KeyMaterialStore
    metadata: dict[str, Any] = field(default_factory=dict)

    async def healthcheck(self) -> dict[str, Any]:
        """Self-test that all backends respond. Used by /healthz endpoints."""
        return {
            "mode": self.mode.value,
            "ok": True,
            "metadata": self.metadata,
        }

    async def close(self) -> None:
        """Release resources. Implementations may override; default is no-op.
        Caller should `await storage.close()` on shutdown."""
        for repo in (self.verdicts, self.chains, self.alma, self.keys):
            close = getattr(repo, "close", None)
            if callable(close):
                result = close()
                if hasattr(result, "__await__"):
                    await result  # type: ignore[func-returns-value]
