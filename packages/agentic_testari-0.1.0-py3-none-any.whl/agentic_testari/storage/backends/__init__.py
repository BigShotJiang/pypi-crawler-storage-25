"""Storage backend implementations.

- `base.py` — abstract interfaces every backend must implement
- `sqlite_backend.py` — local mode (default), uses sqlite3 + sqlite-vec
- `postgres_backend.py` — cloud mode (dormant until Azure customer), uses asyncpg + pgvector
- `memory_backend.py` — test fixture only; in-process dict storage
"""
