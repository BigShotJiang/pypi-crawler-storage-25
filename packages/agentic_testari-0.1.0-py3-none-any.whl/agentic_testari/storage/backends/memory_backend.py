"""In-memory storage backend — TESTS ONLY.

No persistence across process restarts. Useful for:
- Framework unit tests
- CI smoke tests where SQLite/Postgres aren't worth the setup
- Headless evaluation in scripts

NOT for production use. The factory refuses to return this in any mode
other than `MEMORY` explicitly.
"""

from __future__ import annotations

from collections import OrderedDict, defaultdict
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from agents._shared.storage.backends.base import (
    AlmaStore,
    EvidenceChainStore,
    KeyMaterialStore,
    StorageBackend,
    StorageMode,
    VerdictRepository,
)


class _MemoryVerdictRepository(VerdictRepository):
    def __init__(self) -> None:
        self._verdicts: dict[tuple[str, str], dict[str, Any]] = OrderedDict()
        # key = (org_id, run_id)

    async def save(self, org_id: str, verdict: dict[str, Any]) -> str:
        run_id = str(verdict.get("verdict", verdict).get("run_id") or verdict.get("run_id") or uuid4().hex)
        verdict_id = verdict.get("verdict", verdict).get("verdict_id") or verdict.get("verdict_id") or uuid4().hex
        stored = dict(verdict)
        stored["_org_id"] = org_id
        stored["_run_id"] = run_id
        stored["_verdict_id"] = verdict_id
        stored.setdefault("_saved_at", datetime.now(timezone.utc).isoformat())
        self._verdicts[(org_id, run_id)] = stored
        return verdict_id

    async def get(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        return self._verdicts.get((org_id, run_id))

    async def list_recent(
        self,
        org_id: str,
        agent_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        items = [v for (o, _), v in self._verdicts.items() if o == org_id]
        if agent_id is not None:
            items = [
                v for v in items
                if (v.get("verdict", {}).get("agent_id") or v.get("agent_id")) == agent_id
            ]
        items.reverse()
        return items[:limit]

    async def delete(self, org_id: str, run_id: str) -> bool:
        return self._verdicts.pop((org_id, run_id), None) is not None


class _MemoryEvidenceChainStore(EvidenceChainStore):
    def __init__(self) -> None:
        self._chains: dict[tuple[str, str], dict[str, Any]] = {}
        self._links: dict[tuple[str, str], dict[str, Any]] = {}
        self._blobs: dict[str, bytes] = {}

    async def save_chain(
        self,
        org_id: str,
        run_id: str,
        chain: dict[str, Any],
    ) -> str:
        chain_id = chain.get("chain_id") or uuid4().hex
        stored = dict(chain)
        stored["_org_id"] = org_id
        stored["_run_id"] = run_id
        self._chains[(org_id, run_id)] = stored
        for link in chain.get("links", []):
            link_id = link.get("id") or uuid4().hex
            stored_link = dict(link)
            stored_link["_chain_id"] = chain_id
            stored_link["_org_id"] = org_id
            self._links[(org_id, link_id)] = stored_link
        return chain_id

    async def get_chain(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        return self._chains.get((org_id, run_id))

    async def get_link(self, org_id: str, link_id: str) -> dict[str, Any] | None:
        return self._links.get((org_id, link_id))

    async def store_blob(
        self,
        org_id: str,
        run_id: str,
        link_id: str,
        blob_bytes: bytes,
        content_type: str = "application/octet-stream",
    ) -> str:
        blob_url = f"memory://{org_id}/{run_id}/{link_id}"
        self._blobs[blob_url] = blob_bytes
        return blob_url

    async def get_blob(self, blob_url: str) -> bytes | None:
        return self._blobs.get(blob_url)


class _MemoryAlmaStore(AlmaStore):
    def __init__(self) -> None:
        self._heuristics: list[dict[str, Any]] = []
        self._anti_patterns: list[dict[str, Any]] = []
        self._episodes: list[dict[str, Any]] = []
        self._knowledge: list[dict[str, Any]] = []
        self._preferences: list[dict[str, Any]] = []

    async def add_heuristic(
        self,
        org_id: str,
        agent_id: str,
        rule: str,
        description: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        rec_id = uuid4().hex
        self._heuristics.append({
            "id": rec_id, "org_id": org_id, "agent_id": agent_id,
            "rule": rule, "description": description,
            "embedding": embedding, "context": context or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        return rec_id

    async def add_anti_pattern(
        self,
        org_id: str,
        agent_id: str,
        pattern_name: str,
        description: str,
        avoidance_strategy: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        rec_id = uuid4().hex
        self._anti_patterns.append({
            "id": rec_id, "org_id": org_id, "agent_id": agent_id,
            "pattern_name": pattern_name, "description": description,
            "avoidance_strategy": avoidance_strategy,
            "embedding": embedding, "context": context or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        return rec_id

    async def add_episode(
        self,
        org_id: str,
        agent_id: str,
        episode_type: str,
        context: dict[str, Any],
        actions: list[dict[str, Any]],
        outcome: dict[str, Any],
    ) -> str:
        rec_id = uuid4().hex
        self._episodes.append({
            "id": rec_id, "org_id": org_id, "agent_id": agent_id,
            "episode_type": episode_type, "context": context,
            "actions": actions, "outcome": outcome,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        return rec_id

    async def query_similar(
        self,
        org_id: str,
        agent_id: str,
        memory_type: str,
        query_embedding: list[float],
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        # Memory backend: cosine similarity in-process. Adequate for tests.
        bucket = {
            "heuristic": self._heuristics,
            "anti_pattern": self._anti_patterns,
            "episode": self._episodes,
            "knowledge": self._knowledge,
            "preference": self._preferences,
        }.get(memory_type, [])

        candidates = [
            r for r in bucket
            if r.get("org_id") == org_id and r.get("agent_id") == agent_id
            and r.get("embedding")
        ]

        def cosine(a: list[float], b: list[float]) -> float:
            if not a or not b or len(a) != len(b):
                return 0.0
            dot = sum(x * y for x, y in zip(a, b))
            na = sum(x * x for x in a) ** 0.5
            nb = sum(y * y for y in b) ** 0.5
            return dot / (na * nb) if na > 0 and nb > 0 else 0.0

        scored = sorted(
            candidates,
            key=lambda r: cosine(r.get("embedding", []), query_embedding),
            reverse=True,
        )
        return scored[:limit]

    async def get_anti_patterns(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        items = [
            r for r in self._anti_patterns
            if r["org_id"] == org_id and r["agent_id"] == agent_id
        ]
        items.reverse()
        return items[:limit]

    async def get_heuristics(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        items = [
            r for r in self._heuristics
            if r["org_id"] == org_id and r["agent_id"] == agent_id
        ]
        items.reverse()
        return items[:limit]


class _MemoryKeyMaterialStore(KeyMaterialStore):
    """Memory key store — TESTS ONLY. Returns deterministic bytes per org_id
    so tests can sign + verify within the same process."""

    def __init__(self) -> None:
        self._signing: dict[str, bytes] = {}
        self._encryption: dict[str, bytes] = {}
        self._archive: dict[str, list[bytes]] = defaultdict(list)

    async def get_signing_key(self, org_id: str) -> bytes | None:
        if org_id not in self._signing:
            # Deterministic 32-byte key for tests
            import hashlib
            self._signing[org_id] = hashlib.sha256(f"signing:{org_id}".encode()).digest()
        return self._signing[org_id]

    async def get_encryption_key(self, org_id: str) -> bytes | None:
        if org_id not in self._encryption:
            import hashlib
            self._encryption[org_id] = hashlib.sha256(f"encryption:{org_id}".encode()).digest()
        return self._encryption[org_id]

    async def rotate_keys(self, org_id: str) -> None:
        if org_id in self._signing:
            self._archive[org_id].append(self._signing[org_id])
            del self._signing[org_id]
        if org_id in self._encryption:
            self._archive[org_id].append(self._encryption[org_id])
            del self._encryption[org_id]


def make_memory_backend() -> StorageBackend:
    """Factory for the memory backend (tests only)."""
    return StorageBackend(
        mode=StorageMode.MEMORY,
        verdicts=_MemoryVerdictRepository(),
        chains=_MemoryEvidenceChainStore(),
        alma=_MemoryAlmaStore(),
        keys=_MemoryKeyMaterialStore(),
        metadata={"backend": "memory", "warning": "tests only — no persistence"},
    )
