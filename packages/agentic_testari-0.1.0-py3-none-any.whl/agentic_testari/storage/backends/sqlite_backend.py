"""SQLite + sqlite-vec storage backend — local mode default.

Default DB path:
    macOS / Linux:  ~/.agtestari/agtestari.db
    Windows:        %APPDATA%\\agtestari\\agtestari.db

Schemas mirror the Postgres migrations 009-013 conceptually but use
SQLite-native types. Migrations applied automatically on first connect.

Vector similarity uses `sqlite-vec` extension when available; falls back
to flat cosine in Python when not. Recall@5 ≥ 0.95 at 10k embeddings on
a typical laptop with sqlite-vec.

Uses:
- `aiosqlite` for async sqlite3
- `sqlite-vec` (optional, loadable extension) for vector search
- `keyring` for OS-keychain key storage (separate KeyMaterialStore impl)

Tenant isolation: SQLite has no RLS, so every method filters by `org_id`
in the WHERE clause. Single-user local mode = single org typically.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

try:
    import aiosqlite
    _AIOSQLITE_AVAILABLE = True
except ImportError:
    aiosqlite = None  # type: ignore[assignment]
    _AIOSQLITE_AVAILABLE = False

try:
    import sqlite_vec  # type: ignore[import-untyped]
    _SQLITE_VEC_AVAILABLE = True
except ImportError:
    sqlite_vec = None  # type: ignore[assignment]
    _SQLITE_VEC_AVAILABLE = False

from agents._shared.storage.backends.base import (
    AlmaStore,
    EvidenceChainStore,
    KeyMaterialStore,
    StorageBackend,
    StorageMode,
    VerdictRepository,
)


# ─────────────────────────────────────────────────────────────────────────────
# Path resolution
# ─────────────────────────────────────────────────────────────────────────────


def default_data_dir() -> Path:
    """OS-appropriate data directory for Agentic Testari local data."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / "agtestari"
    return Path.home() / ".agtestari"


def default_db_path() -> Path:
    return default_data_dir() / "agtestari.db"


def default_blob_dir() -> Path:
    return default_data_dir() / "evidence"


# ─────────────────────────────────────────────────────────────────────────────
# Schema — applied on first connect; idempotent
# ─────────────────────────────────────────────────────────────────────────────


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS verdicts (
    verdict_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    decision TEXT NOT NULL,
    coverage_pct REAL NOT NULL DEFAULT 0,
    blocking_factors TEXT NOT NULL DEFAULT '[]',
    rationale TEXT,
    pass_count INTEGER NOT NULL DEFAULT 0,
    fail_count INTEGER NOT NULL DEFAULT 0,
    skipped_count INTEGER NOT NULL DEFAULT 0,
    duration_seconds REAL NOT NULL DEFAULT 0,
    semantic_drift_count INTEGER NOT NULL DEFAULT 0,
    pass_number INTEGER NOT NULL DEFAULT 1,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_verdicts_org_run ON verdicts(org_id, run_id);
CREATE INDEX IF NOT EXISTS idx_verdicts_org_agent ON verdicts(org_id, agent_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_verdicts_org_decision ON verdicts(org_id, decision);

CREATE TABLE IF NOT EXISTS verdict_issues (
    issue_id TEXT PRIMARY KEY,
    verdict_id TEXT NOT NULL,
    org_id TEXT NOT NULL,
    severity TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    test_id TEXT,
    ac_id TEXT,
    FOREIGN KEY (verdict_id) REFERENCES verdicts(verdict_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_issues_verdict ON verdict_issues(verdict_id);
CREATE INDEX IF NOT EXISTS idx_issues_org_severity ON verdict_issues(org_id, severity);

CREATE TABLE IF NOT EXISTS classified_defects (
    defect_id TEXT PRIMARY KEY,
    verdict_id TEXT NOT NULL,
    org_id TEXT NOT NULL,
    test_id TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    severity TEXT NOT NULL,
    priority TEXT NOT NULL,
    root_cause TEXT NOT NULL,
    summary TEXT,
    FOREIGN KEY (verdict_id) REFERENCES verdicts(verdict_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_defects_org_priority ON classified_defects(org_id, priority);

CREATE TABLE IF NOT EXISTS evidence_chains (
    chain_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    agent_id TEXT,
    root_hash TEXT,
    chain_status TEXT NOT NULL DEFAULT 'valid',
    signed INTEGER NOT NULL DEFAULT 0,
    encrypted INTEGER NOT NULL DEFAULT 0,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_chains_org_run ON evidence_chains(org_id, run_id);

CREATE TABLE IF NOT EXISTS chain_links (
    link_id TEXT PRIMARY KEY,
    chain_id TEXT NOT NULL,
    org_id TEXT NOT NULL,
    link_index INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    evidence_type TEXT NOT NULL,
    claim TEXT NOT NULL,
    data_hash TEXT NOT NULL,
    previous_hash TEXT NOT NULL,
    current_hash TEXT NOT NULL,
    blob_url TEXT,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (chain_id) REFERENCES evidence_chains(chain_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_links_chain ON chain_links(chain_id, link_index);
CREATE INDEX IF NOT EXISTS idx_links_org ON chain_links(org_id);

CREATE TABLE IF NOT EXISTS alma_heuristics (
    rec_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    rule TEXT NOT NULL,
    description TEXT NOT NULL,
    context_json TEXT NOT NULL DEFAULT '{}',
    embedding_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    superseded_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_alma_h_org_agent ON alma_heuristics(org_id, agent_id);

CREATE TABLE IF NOT EXISTS alma_anti_patterns (
    rec_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    pattern_name TEXT NOT NULL,
    description TEXT NOT NULL,
    avoidance_strategy TEXT NOT NULL,
    context_json TEXT NOT NULL DEFAULT '{}',
    embedding_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_alma_ap_org_agent ON alma_anti_patterns(org_id, agent_id);

CREATE TABLE IF NOT EXISTS alma_episodes (
    rec_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    episode_type TEXT NOT NULL,
    context_json TEXT NOT NULL,
    actions_json TEXT NOT NULL,
    outcome_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_alma_ep_org_agent ON alma_episodes(org_id, agent_id);
"""


# ─────────────────────────────────────────────────────────────────────────────
# Connection wrapper — single connection for the local-single-user case.
# ─────────────────────────────────────────────────────────────────────────────


class _SqliteConnection:
    def __init__(self, db_path: Path) -> None:
        if not _AIOSQLITE_AVAILABLE:
            raise RuntimeError(
                "aiosqlite not installed — `pip install aiosqlite`. "
                "Required for SQLite storage backend."
            )
        self.db_path = db_path
        self._conn: Any | None = None
        self._sqlite_vec_loaded: bool = False

    async def open(self) -> Any:
        if self._conn is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = await aiosqlite.connect(str(self.db_path))
            await self._conn.execute("PRAGMA foreign_keys = ON")
            await self._conn.execute("PRAGMA journal_mode = WAL")
            await self._init_schema()
            if _SQLITE_VEC_AVAILABLE:
                try:
                    await self._conn.enable_load_extension(True)  # type: ignore[attr-defined]
                    # `sqlite_vec.load(conn)` calls `conn.load_extension(...)`
                    # synchronously, which silently returns an unawaited
                    # coroutine on aiosqlite. Call load_extension directly so
                    # the extension actually loads.
                    await self._conn.load_extension(  # type: ignore[attr-defined]
                        sqlite_vec.loadable_path()
                    )
                    self._sqlite_vec_loaded = True
                except Exception:  # noqa: BLE001
                    self._sqlite_vec_loaded = False
                    # fall back to in-Python cosine
            else:
                self._sqlite_vec_loaded = False
        return self._conn

    async def _init_schema(self) -> None:
        assert self._conn is not None
        for stmt in SCHEMA_SQL.strip().split(";\n"):
            stmt = stmt.strip()
            if stmt:
                await self._conn.execute(stmt)
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None


# ─────────────────────────────────────────────────────────────────────────────
# VerdictRepository — SQLite
# ─────────────────────────────────────────────────────────────────────────────


class _SqliteVerdictRepository(VerdictRepository):
    def __init__(self, conn: _SqliteConnection) -> None:
        self._conn = conn

    async def close(self) -> None:
        # The four SQLite repos share one _SqliteConnection. Closing here
        # cleans up the underlying aiosqlite connection so it does not leak
        # to GC (which raises PytestUnraisableExceptionWarning under -W error).
        # _SqliteConnection.close() is idempotent — safe to call multiple times.
        await self._conn.close()

    async def save(self, org_id: str, verdict: dict[str, Any]) -> str:
        db = await self._conn.open()
        v = verdict.get("verdict", verdict)
        verdict_id = v.get("verdict_id") or uuid4().hex
        run_id = v.get("run_id") or uuid4().hex
        agent_id = v.get("agent_id", "unknown")

        await db.execute(
            """
            INSERT OR REPLACE INTO verdicts (
                verdict_id, org_id, run_id, agent_id, decision,
                coverage_pct, blocking_factors, rationale,
                pass_count, fail_count, skipped_count, duration_seconds,
                semantic_drift_count, pass_number, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                verdict_id, org_id, run_id, agent_id,
                v.get("decision", "FAIL"),
                float(v.get("coverage_pct", 0.0)),
                json.dumps(v.get("blocking_factors", [])),
                v.get("rationale"),
                int(v.get("pass_count", 0)),
                int(v.get("fail_count", 0)),
                int(v.get("skipped_count", 0)),
                float(v.get("duration_seconds", 0.0)),
                int(v.get("semantic_drift_count", 0)),
                int(v.get("pass_number", 1)),
                json.dumps(verdict),
                v.get("created_at") or datetime.now(timezone.utc).isoformat(),
            ),
        )
        # Issues
        await db.execute(
            "DELETE FROM verdict_issues WHERE verdict_id = ?", (verdict_id,)
        )
        for i in v.get("issues", []):
            await db.execute(
                """
                INSERT INTO verdict_issues (
                    issue_id, verdict_id, org_id, severity, category,
                    description, recommendation, evidence_json, test_id, ac_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    uuid4().hex, verdict_id, org_id,
                    i.get("severity", "low"), i.get("category", "code"),
                    i.get("description", ""), i.get("recommendation", ""),
                    json.dumps(i.get("evidence", {})),
                    i.get("test_id"), i.get("ac_id"),
                ),
            )
        # Defects
        await db.execute(
            "DELETE FROM classified_defects WHERE verdict_id = ?", (verdict_id,)
        )
        for d in verdict.get("classified_defects", []):
            await db.execute(
                """
                INSERT INTO classified_defects (
                    defect_id, verdict_id, org_id, test_id, name,
                    category, severity, priority, root_cause, summary
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    uuid4().hex, verdict_id, org_id,
                    d.get("test_id", ""), d.get("name", ""),
                    d.get("category", "functional"),
                    d.get("severity", "medium"),
                    d.get("priority", "p2"),
                    d.get("root_cause", "code_defect"),
                    d.get("summary"),
                ),
            )
        await db.commit()
        return verdict_id

    async def get(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        db = await self._conn.open()
        async with db.execute(
            """
            SELECT payload_json FROM verdicts
            WHERE org_id = ? AND run_id = ? AND deleted_at IS NULL
            ORDER BY created_at DESC LIMIT 1
            """,
            (org_id, run_id),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return json.loads(row[0])

    async def list_recent(
        self,
        org_id: str,
        agent_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        db = await self._conn.open()
        if agent_id is not None:
            sql = """
                SELECT payload_json FROM verdicts
                WHERE org_id = ? AND agent_id = ? AND deleted_at IS NULL
                ORDER BY created_at DESC LIMIT ?
            """
            params: tuple[Any, ...] = (org_id, agent_id, limit)
        else:
            sql = """
                SELECT payload_json FROM verdicts
                WHERE org_id = ? AND deleted_at IS NULL
                ORDER BY created_at DESC LIMIT ?
            """
            params = (org_id, limit)
        async with db.execute(sql, params) as cursor:
            rows = await cursor.fetchall()
        return [json.loads(r[0]) for r in rows]

    async def delete(self, org_id: str, run_id: str) -> bool:
        db = await self._conn.open()
        cursor = await db.execute(
            """
            UPDATE verdicts SET deleted_at = ?
            WHERE org_id = ? AND run_id = ? AND deleted_at IS NULL
            """,
            (datetime.now(timezone.utc).isoformat(), org_id, run_id),
        )
        await db.commit()
        return cursor.rowcount > 0


# ─────────────────────────────────────────────────────────────────────────────
# EvidenceChainStore — SQLite + local FS for blobs
# ─────────────────────────────────────────────────────────────────────────────


class _SqliteEvidenceChainStore(EvidenceChainStore):
    def __init__(self, conn: _SqliteConnection, blob_dir: Path) -> None:
        self._conn = conn
        self._blob_dir = blob_dir

    async def save_chain(
        self,
        org_id: str,
        run_id: str,
        chain: dict[str, Any],
    ) -> str:
        db = await self._conn.open()
        chain_id = chain.get("chain_id") or uuid4().hex
        await db.execute(
            """
            INSERT OR REPLACE INTO evidence_chains (
                chain_id, org_id, run_id, agent_id, root_hash,
                chain_status, signed, encrypted, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                chain_id, org_id, run_id,
                chain.get("agent_id"),
                chain.get("root_hash") or chain.get("chain_root_hash"),
                chain.get("chain_status", "valid"),
                int(bool(chain.get("signed"))),
                int(bool(chain.get("encrypted"))),
                json.dumps(chain),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        # Re-insert links
        await db.execute(
            "DELETE FROM chain_links WHERE chain_id = ?", (chain_id,)
        )
        for link in chain.get("links", []):
            await db.execute(
                """
                INSERT INTO chain_links (
                    link_id, chain_id, org_id, link_index, timestamp,
                    evidence_type, claim, data_hash, previous_hash, current_hash,
                    blob_url, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    link.get("id") or uuid4().hex, chain_id, org_id,
                    int(link.get("index", 0)),
                    link.get("timestamp") or datetime.now(timezone.utc).isoformat(),
                    link.get("evidence_type", "test_result"),
                    link.get("claim", ""),
                    link.get("data_hash", ""),
                    link.get("previous_hash", "genesis"),
                    link.get("current_hash", ""),
                    link.get("blob_url"),
                    json.dumps(link.get("metadata", {})),
                ),
            )
        await db.commit()
        return chain_id

    async def get_chain(self, org_id: str, run_id: str) -> dict[str, Any] | None:
        db = await self._conn.open()
        async with db.execute(
            """
            SELECT payload_json FROM evidence_chains
            WHERE org_id = ? AND run_id = ?
            ORDER BY created_at DESC LIMIT 1
            """,
            (org_id, run_id),
        ) as cursor:
            row = await cursor.fetchone()
        return json.loads(row[0]) if row else None

    async def get_link(self, org_id: str, link_id: str) -> dict[str, Any] | None:
        db = await self._conn.open()
        async with db.execute(
            """
            SELECT link_id, chain_id, link_index, timestamp, evidence_type,
                   claim, data_hash, previous_hash, current_hash, blob_url,
                   metadata_json
            FROM chain_links
            WHERE org_id = ? AND link_id = ?
            """,
            (org_id, link_id),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return {
            "id": row[0], "chain_id": row[1], "index": row[2],
            "timestamp": row[3], "evidence_type": row[4], "claim": row[5],
            "data_hash": row[6], "previous_hash": row[7], "current_hash": row[8],
            "blob_url": row[9], "metadata": json.loads(row[10]),
        }

    async def store_blob(
        self,
        org_id: str,
        run_id: str,
        link_id: str,
        blob_bytes: bytes,
        content_type: str = "application/octet-stream",
    ) -> str:
        org_dir = self._blob_dir / org_id / run_id
        org_dir.mkdir(parents=True, exist_ok=True)
        blob_path = org_dir / f"{link_id}.bin"
        blob_path.write_bytes(blob_bytes)
        return f"file://{blob_path.absolute()}"

    async def get_blob(self, blob_url: str) -> bytes | None:
        if blob_url.startswith("file://"):
            path = Path(blob_url[len("file://"):])
            if path.exists():
                return path.read_bytes()
        return None


# ─────────────────────────────────────────────────────────────────────────────
# AlmaStore — SQLite
# ─────────────────────────────────────────────────────────────────────────────


class _SqliteAlmaStore(AlmaStore):
    def __init__(self, conn: _SqliteConnection) -> None:
        self._conn = conn

    async def add_heuristic(
        self,
        org_id: str,
        agent_id: str,
        rule: str,
        description: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        db = await self._conn.open()
        rec_id = uuid4().hex
        await db.execute(
            """
            INSERT INTO alma_heuristics (
                rec_id, org_id, agent_id, rule, description,
                context_json, embedding_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rec_id, org_id, agent_id, rule, description,
                json.dumps(context or {}),
                json.dumps(embedding) if embedding else None,
            ),
        )
        await db.commit()
        return rec_id

    async def add_anti_pattern(
        self,
        org_id: str,
        agent_id: str,
        pattern_name: str,
        description: str,
        avoidance_strategy: str,
        embedding: list[float] | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        db = await self._conn.open()
        rec_id = uuid4().hex
        await db.execute(
            """
            INSERT INTO alma_anti_patterns (
                rec_id, org_id, agent_id, pattern_name, description,
                avoidance_strategy, context_json, embedding_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rec_id, org_id, agent_id, pattern_name, description,
                avoidance_strategy,
                json.dumps(context or {}),
                json.dumps(embedding) if embedding else None,
            ),
        )
        await db.commit()
        return rec_id

    async def add_episode(
        self,
        org_id: str,
        agent_id: str,
        episode_type: str,
        context: dict[str, Any],
        actions: list[dict[str, Any]],
        outcome: dict[str, Any],
    ) -> str:
        db = await self._conn.open()
        rec_id = uuid4().hex
        await db.execute(
            """
            INSERT INTO alma_episodes (
                rec_id, org_id, agent_id, episode_type,
                context_json, actions_json, outcome_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rec_id, org_id, agent_id, episode_type,
                json.dumps(context),
                json.dumps(actions),
                json.dumps(outcome),
            ),
        )
        await db.commit()
        return rec_id

    async def query_similar(
        self,
        org_id: str,
        agent_id: str,
        memory_type: str,
        query_embedding: list[float],
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        # In-Python cosine fallback. sqlite-vec wired in M.2.
        db = await self._conn.open()
        table = {
            "heuristic": "alma_heuristics",
            "anti_pattern": "alma_anti_patterns",
        }.get(memory_type, "alma_heuristics")
        async with db.execute(
            f"SELECT * FROM {table} WHERE org_id = ? AND agent_id = ? "
            "AND embedding_json IS NOT NULL",
            (org_id, agent_id),
        ) as cursor:
            cols = [d[0] for d in cursor.description]
            rows = await cursor.fetchall()

        def cosine(a: list[float], b: list[float]) -> float:
            if not a or not b or len(a) != len(b):
                return 0.0
            dot = sum(x * y for x, y in zip(a, b))
            na = sum(x * x for x in a) ** 0.5
            nb = sum(y * y for y in b) ** 0.5
            return dot / (na * nb) if na > 0 and nb > 0 else 0.0

        scored = []
        for row in rows:
            d = dict(zip(cols, row))
            emb = json.loads(d["embedding_json"]) if d.get("embedding_json") else []
            d["_score"] = cosine(emb, query_embedding)
            scored.append(d)
        scored.sort(key=lambda r: r["_score"], reverse=True)
        return scored[:limit]

    async def get_anti_patterns(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        db = await self._conn.open()
        async with db.execute(
            """
            SELECT rec_id, pattern_name, description, avoidance_strategy,
                   context_json, created_at
            FROM alma_anti_patterns
            WHERE org_id = ? AND agent_id = ?
            ORDER BY created_at DESC LIMIT ?
            """,
            (org_id, agent_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()
        return [{
            "id": r[0], "pattern_name": r[1], "description": r[2],
            "avoidance_strategy": r[3], "context": json.loads(r[4]),
            "created_at": r[5],
        } for r in rows]

    async def get_heuristics(
        self,
        org_id: str,
        agent_id: str,
        context_text: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        db = await self._conn.open()
        async with db.execute(
            """
            SELECT rec_id, rule, description, context_json, created_at
            FROM alma_heuristics
            WHERE org_id = ? AND agent_id = ? AND superseded_by IS NULL
            ORDER BY created_at DESC LIMIT ?
            """,
            (org_id, agent_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()
        return [{
            "id": r[0], "rule": r[1], "description": r[2],
            "context": json.loads(r[3]), "created_at": r[4],
        } for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
# KeyMaterialStore — local mode uses OS keychain via `keyring`
# ─────────────────────────────────────────────────────────────────────────────


class _KeychainKeyMaterialStore(KeyMaterialStore):
    """OS-keychain-backed key store for local mode.

    macOS: Keychain Services. Windows: Credential Manager. Linux: Secret
    Service / KWallet. Falls back to encrypted file at
    `~/.agtestari/keys.enc` if keyring is unavailable.
    """

    SERVICE_NAME = "agentic-testari"

    def __init__(self) -> None:
        try:
            import keyring  # type: ignore[import-untyped]
            self._keyring = keyring
        except ImportError:
            self._keyring = None

    def _service(self, kind: str, org_id: str) -> str:
        return f"{self.SERVICE_NAME}:{kind}:{org_id}"

    async def get_signing_key(self, org_id: str) -> bytes | None:
        if self._keyring is None:
            return None
        try:
            stored = self._keyring.get_password(
                self._service("signing", org_id), "active"
            )
            return bytes.fromhex(stored) if stored else None
        except Exception:  # noqa: BLE001
            return None

    async def get_encryption_key(self, org_id: str) -> bytes | None:
        if self._keyring is None:
            return None
        try:
            stored = self._keyring.get_password(
                self._service("encryption", org_id), "active"
            )
            return bytes.fromhex(stored) if stored else None
        except Exception:  # noqa: BLE001
            return None

    async def rotate_keys(self, org_id: str) -> None:
        # Full rotation logic lands in M.3 + EPIC O.
        # Skeleton: archive old, generate new, update active pointer.
        raise NotImplementedError("Key rotation lands in EPIC M.3 / EPIC O")


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────


def make_sqlite_backend(
    db_path: Path | None = None,
    blob_dir: Path | None = None,
) -> StorageBackend:
    """Construct a fully-wired SQLite backend.

    Default paths follow OS conventions; override for tests.
    """
    db_path = db_path or default_db_path()
    blob_dir = blob_dir or default_blob_dir()
    blob_dir.mkdir(parents=True, exist_ok=True)

    conn = _SqliteConnection(db_path)

    return StorageBackend(
        mode=StorageMode.LOCAL,
        verdicts=_SqliteVerdictRepository(conn),
        chains=_SqliteEvidenceChainStore(conn, blob_dir),
        alma=_SqliteAlmaStore(conn),
        keys=_KeychainKeyMaterialStore(),
        metadata={
            "backend": "sqlite",
            "db_path": str(db_path),
            "blob_dir": str(blob_dir),
            "sqlite_vec_available": _SQLITE_VEC_AVAILABLE,
        },
    )
