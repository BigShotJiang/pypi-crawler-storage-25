"""Storage abstraction for the AIOS Quality + Trust Contract.

The framework code at `agents/_shared/quality/` calls into these interfaces.
Concrete backends (SQLite for local mode, Postgres for cloud mode) implement
them. Selection happens at startup via `AGTESTARI_MODE` env var:

    AGTESTARI_MODE=local    → SQLite at ~/.agtestari/agtestari.db (default)
    AGTESTARI_MODE=cloud    → Postgres via DATABASE_URL

This module is the core EPIC M.1 deliverable. It unblocks F.2-F.5 and
EPICs G/N/O so they can write storage-agnostic code.

Usage:
    from agents._shared.storage import get_storage

    storage = get_storage()             # auto-detects mode
    await storage.verdicts.save(verdict)
    await storage.chains.save(chain)
    await storage.alma.add_anti_pattern(pattern)
"""

from agents._shared.storage.backends.base import (
    StorageBackend,
    StorageMode,
    VerdictRepository,
    EvidenceChainStore,
    AlmaStore,
    KeyMaterialStore,
)
from agents._shared.storage.factory import (
    get_storage,
    reset_storage,
    select_backend,
)

__all__ = [
    "StorageBackend",
    "StorageMode",
    "VerdictRepository",
    "EvidenceChainStore",
    "AlmaStore",
    "KeyMaterialStore",
    "get_storage",
    "reset_storage",
    "select_backend",
]

__version__ = "1.0.0"
