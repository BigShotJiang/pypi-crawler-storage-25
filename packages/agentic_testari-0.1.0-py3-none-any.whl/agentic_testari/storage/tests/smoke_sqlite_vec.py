"""Manual smoke test for sqlite-vec + aiosqlite roundtrip.

Run directly:  python -m agents._shared.storage.tests.smoke_sqlite_vec

This is NOT a pytest test — it's a developer sanity check that the M.2
dependencies (aiosqlite, sqlite-vec) work together on the host platform.
The full pytest suite uses the framework's existing fixtures.
"""

from __future__ import annotations

import asyncio
import os
import tempfile

import aiosqlite
import sqlite_vec


async def main() -> int:
    tmpf = tempfile.NamedTemporaryFile(suffix=".db", delete=False).name
    try:
        async with aiosqlite.connect(tmpf) as db:
            await db.enable_load_extension(True)
            await db.load_extension(sqlite_vec.loadable_path())
            cur = await db.execute("SELECT vec_version()")
            row = await cur.fetchone()
            assert row is not None
            print(f"vec_version: {row[0]}")

            await db.execute("CREATE TABLE smoke_t (id TEXT PRIMARY KEY)")
            await db.execute("INSERT INTO smoke_t VALUES ('a')")
            await db.commit()

            cur = await db.execute("SELECT count(*) FROM smoke_t")
            row = await cur.fetchone()
            assert row is not None
            assert row[0] == 1
            print(f"row_count: {row[0]}")

        print("SMOKE PASS")
        return 0
    finally:
        try:
            os.unlink(tmpf)
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
