"""M.1 — Storage abstraction tests.

Covers:
- Factory selection via AGTESTARI_MODE env var
- Memory backend roundtrip (verdicts, chains, ALMA, keys)
- SQLite backend roundtrip (skipped if aiosqlite unavailable)
- Postgres backend stub raises NotImplementedError
- Multi-tenant filtering (org_id isolation in shared storage)
- M.2 sqlite-vec extension actually loads on async connection
  (regression for bug fixed 2026-04-28; see
  docs/architecture/M.2-audit-bugs-and-fixes.md Bug 1)
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest
import pytest_asyncio

from agents._shared.storage import (
    StorageBackend,
    StorageMode,
    get_storage,
    reset_storage,
    select_backend,
)
from agents._shared.storage.backends.memory_backend import make_memory_backend


# ─────────────────────────────────────────────────────────────────────────────
# Factory + mode resolution
# ─────────────────────────────────────────────────────────────────────────────


def test_factory_defaults_to_local(monkeypatch):
    monkeypatch.delenv("AGTESTARI_MODE", raising=False)
    reset_storage()
    backend = select_backend(StorageMode.MEMORY)  # don't actually open SQLite
    assert backend.mode == StorageMode.MEMORY


def test_factory_respects_env_var(monkeypatch):
    monkeypatch.setenv("AGTESTARI_MODE", "memory")
    reset_storage()
    backend = get_storage()
    assert backend.mode == StorageMode.MEMORY


def test_factory_caches_singleton(monkeypatch):
    monkeypatch.setenv("AGTESTARI_MODE", "memory")
    reset_storage()
    a = get_storage()
    b = get_storage()
    assert a is b


def test_factory_unknown_mode_falls_back_to_local(monkeypatch):
    monkeypatch.setenv("AGTESTARI_MODE", "kebab")
    reset_storage()
    # Force memory backend to avoid touching disk during this assertion
    backend = select_backend(StorageMode.MEMORY)
    assert backend.mode == StorageMode.MEMORY


# ─────────────────────────────────────────────────────────────────────────────
# Memory backend roundtrip — required to pass on every Python install
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def mem_backend() -> StorageBackend:
    reset_storage()
    return select_backend(StorageMode.MEMORY)


@pytest.mark.asyncio
async def test_memory_verdict_save_get(mem_backend: StorageBackend):
    verdict = {
        "verdict": {
            "verdict_id": "v-1", "run_id": "r-1", "agent_id": "helena",
            "decision": "PASS", "pass_count": 1, "fail_count": 0,
            "issues": [],
        },
        "classified_defects": [],
    }
    vid = await mem_backend.verdicts.save(org_id="org-A", verdict=verdict)
    assert vid == "v-1"
    fetched = await mem_backend.verdicts.get(org_id="org-A", run_id="r-1")
    assert fetched is not None
    assert fetched["verdict"]["decision"] == "PASS"


@pytest.mark.asyncio
async def test_memory_verdict_org_isolation(mem_backend: StorageBackend):
    """Cross-org reads MUST return None — tenant isolation at API level."""
    await mem_backend.verdicts.save(
        org_id="org-A",
        verdict={"verdict": {"verdict_id": "v-A", "run_id": "r-1", "agent_id": "h"}},
    )
    # Org B asking for org-A's run = miss
    assert await mem_backend.verdicts.get(org_id="org-B", run_id="r-1") is None


@pytest.mark.asyncio
async def test_memory_verdict_list_recent(mem_backend: StorageBackend):
    for i in range(5):
        await mem_backend.verdicts.save(
            org_id="org-A",
            verdict={"verdict": {"verdict_id": f"v-{i}", "run_id": f"r-{i}",
                                 "agent_id": "helena", "decision": "PASS"}},
        )
    recent = await mem_backend.verdicts.list_recent(org_id="org-A", limit=3)
    assert len(recent) == 3


@pytest.mark.asyncio
async def test_memory_verdict_filter_by_agent(mem_backend: StorageBackend):
    await mem_backend.verdicts.save(
        org_id="org-A",
        verdict={"verdict": {"verdict_id": "v-h", "run_id": "r-h",
                             "agent_id": "helena"}},
    )
    await mem_backend.verdicts.save(
        org_id="org-A",
        verdict={"verdict": {"verdict_id": "v-v", "run_id": "r-v",
                             "agent_id": "victor"}},
    )
    helena_only = await mem_backend.verdicts.list_recent(
        org_id="org-A", agent_id="helena", limit=10,
    )
    assert len(helena_only) == 1
    assert helena_only[0]["verdict"]["agent_id"] == "helena"


@pytest.mark.asyncio
async def test_memory_chain_save_get(mem_backend: StorageBackend):
    chain = {
        "chain_id": "c-1",
        "agent_id": "helena",
        "root_hash": "abc123",
        "links": [
            {"id": "l-1", "index": 0, "evidence_type": "ui_test",
             "claim": "login works", "data_hash": "h1",
             "previous_hash": "genesis", "current_hash": "h1c"},
        ],
    }
    cid = await mem_backend.chains.save_chain(org_id="org-A", run_id="r-1", chain=chain)
    assert cid == "c-1"
    fetched = await mem_backend.chains.get_chain(org_id="org-A", run_id="r-1")
    assert fetched is not None
    assert fetched["chain_id"] == "c-1"

    link = await mem_backend.chains.get_link(org_id="org-A", link_id="l-1")
    assert link is not None
    assert link["claim"] == "login works"


@pytest.mark.asyncio
async def test_memory_chain_blob_roundtrip(mem_backend: StorageBackend):
    blob = b"\x89PNG\r\n\x1a\n fake screenshot bytes"
    url = await mem_backend.chains.store_blob(
        org_id="org-A", run_id="r-1", link_id="l-1",
        blob_bytes=blob, content_type="image/png",
    )
    assert url.startswith("memory://")
    fetched = await mem_backend.chains.get_blob(url)
    assert fetched == blob


@pytest.mark.asyncio
async def test_memory_alma_anti_pattern_get(mem_backend: StorageBackend):
    rec_id = await mem_backend.alma.add_anti_pattern(
        org_id="org-A", agent_id="helena",
        pattern_name="flaky-selector",
        description="Login button uses .login-btn which Cypress flags",
        avoidance_strategy="Prefer data-test attribute",
    )
    assert rec_id
    patterns = await mem_backend.alma.get_anti_patterns(
        org_id="org-A", agent_id="helena",
    )
    assert len(patterns) == 1
    assert patterns[0]["pattern_name"] == "flaky-selector"


@pytest.mark.asyncio
async def test_memory_alma_query_similar(mem_backend: StorageBackend):
    await mem_backend.alma.add_heuristic(
        org_id="org-A", agent_id="helena",
        rule="prefer-data-test", description="...",
        embedding=[1.0, 0.0, 0.0],
    )
    await mem_backend.alma.add_heuristic(
        org_id="org-A", agent_id="helena",
        rule="explicit-waits", description="...",
        embedding=[0.0, 1.0, 0.0],
    )
    results = await mem_backend.alma.query_similar(
        org_id="org-A", agent_id="helena", memory_type="heuristic",
        query_embedding=[1.0, 0.0, 0.0], limit=2,
    )
    assert len(results) == 2
    assert results[0]["rule"] == "prefer-data-test"  # closer match wins


@pytest.mark.asyncio
async def test_memory_keys_provisioned_lazily(mem_backend: StorageBackend):
    sk = await mem_backend.keys.get_signing_key(org_id="org-A")
    assert sk is not None
    assert len(sk) == 32  # SHA-256 size
    # Same key on second call (deterministic in memory backend)
    sk2 = await mem_backend.keys.get_signing_key(org_id="org-A")
    assert sk == sk2


@pytest.mark.asyncio
async def test_healthcheck(mem_backend: StorageBackend):
    health = await mem_backend.healthcheck()
    assert health["ok"] is True
    assert health["mode"] == "memory"


# ─────────────────────────────────────────────────────────────────────────────
# Postgres stub — fail-fast on use
# ─────────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_postgres_stub_raises_on_use():
    backend = select_backend(StorageMode.CLOUD)
    assert backend.mode == StorageMode.CLOUD
    with pytest.raises(NotImplementedError) as exc_info:
        await backend.verdicts.get(org_id="org-A", run_id="r-1")
    assert "dormant" in str(exc_info.value).lower()


# ─────────────────────────────────────────────────────────────────────────────
# SQLite backend — only run if aiosqlite is installed
# ─────────────────────────────────────────────────────────────────────────────


def _aiosqlite_available() -> bool:
    try:
        import aiosqlite  # noqa: F401
        return True
    except ImportError:
        return False


@pytest_asyncio.fixture
async def tmp_sqlite_backend(tmp_path: Path):
    """Async fixture that explicitly closes the backend on teardown.

    Without `await backend.close()`, aiosqlite connections leak and get
    finalized by GC, which surfaces as PytestUnraisableExceptionWarning
    under `pytest -W error`. See M.2.2 audit report for context.
    """
    if not _aiosqlite_available():
        pytest.skip("aiosqlite not installed; SQLite backend tests skipped")
    from agents._shared.storage.backends.sqlite_backend import make_sqlite_backend

    backend = make_sqlite_backend(
        db_path=tmp_path / "test.db",
        blob_dir=tmp_path / "blobs",
    )
    try:
        yield backend
    finally:
        await backend.close()


@pytest.mark.asyncio
async def test_sqlite_verdict_roundtrip(tmp_sqlite_backend: StorageBackend):
    verdict = {
        "verdict": {
            "verdict_id": "v-1", "run_id": "r-1", "agent_id": "helena",
            "decision": "PASS", "coverage_pct": 92.5,
            "pass_count": 14, "fail_count": 0, "skipped_count": 1,
            "duration_seconds": 12.4,
            "blocking_factors": [],
            "issues": [
                {"severity": "low", "category": "code", "description": "minor",
                 "recommendation": "fix"},
            ],
        },
        "classified_defects": [],
    }
    vid = await tmp_sqlite_backend.verdicts.save(org_id="org-A", verdict=verdict)
    assert vid == "v-1"
    fetched = await tmp_sqlite_backend.verdicts.get(org_id="org-A", run_id="r-1")
    assert fetched is not None
    assert fetched["verdict"]["decision"] == "PASS"
    assert fetched["verdict"]["coverage_pct"] == 92.5


@pytest.mark.asyncio
async def test_sqlite_org_isolation(tmp_sqlite_backend: StorageBackend):
    await tmp_sqlite_backend.verdicts.save(
        org_id="org-A",
        verdict={"verdict": {"verdict_id": "v-A", "run_id": "r-1", "agent_id": "h"}},
    )
    assert await tmp_sqlite_backend.verdicts.get(org_id="org-B", run_id="r-1") is None


@pytest.mark.asyncio
async def test_sqlite_chain_blob_writes_to_fs(tmp_sqlite_backend: StorageBackend):
    blob = b"actual screenshot bytes"
    url = await tmp_sqlite_backend.chains.store_blob(
        org_id="org-A", run_id="r-1", link_id="l-1",
        blob_bytes=blob,
    )
    assert url.startswith("file://")
    fetched = await tmp_sqlite_backend.chains.get_blob(url)
    assert fetched == blob


@pytest.mark.asyncio
async def test_sqlite_alma_anti_pattern(tmp_sqlite_backend: StorageBackend):
    await tmp_sqlite_backend.alma.add_anti_pattern(
        org_id="org-A", agent_id="helena",
        pattern_name="flaky-selector",
        description="...",
        avoidance_strategy="...",
    )
    patterns = await tmp_sqlite_backend.alma.get_anti_patterns(
        org_id="org-A", agent_id="helena",
    )
    assert len(patterns) == 1
    assert patterns[0]["pattern_name"] == "flaky-selector"


@pytest.mark.asyncio
async def test_sqlite_metadata_includes_paths(tmp_sqlite_backend: StorageBackend):
    health = await tmp_sqlite_backend.healthcheck()
    assert health["mode"] == "local"
    assert "db_path" in health["metadata"]


# ─────────────────────────────────────────────────────────────────────────────
# M.2 — sqlite-vec extension load (regression for bug fixed 2026-04-28)
# ─────────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_sqlite_vec_extension_loads_when_available(tmp_path: Path):
    """Regression: sqlite_vec.load(conn) silently failed on aiosqlite because
    it called load_extension synchronously. Fix awaits load_extension directly.
    See docs/architecture/M.2-audit-bugs-and-fixes.md Bug 1.
    """
    if not _aiosqlite_available():
        pytest.skip("aiosqlite not installed")
    try:
        import sqlite_vec  # noqa: F401
    except ImportError:
        pytest.skip("sqlite-vec not installed")

    from agents._shared.storage.backends.sqlite_backend import _SqliteConnection

    conn = _SqliteConnection(db_path=tmp_path / "vec_test.db")
    await conn.open()
    try:
        # The fix sets this flag to True when extension actually loads.
        assert conn._sqlite_vec_loaded is True, (
            "sqlite-vec extension did not load — regression of the silent-failure bug"
        )

        # Confirm the extension is functionally available by calling a
        # vec function. If extension isn't loaded, this raises OperationalError.
        db = await conn.open()
        async with db.execute("SELECT vec_version()") as cursor:
            row = await cursor.fetchone()
        assert row is not None
        assert isinstance(row[0], str)
    finally:
        await conn.close()


@pytest.mark.asyncio
async def test_sqlite_vec_loaded_flag_false_when_unavailable(
    tmp_path: Path, monkeypatch
):
    """Flag must be False (not None / not undefined) when sqlite-vec missing."""
    if not _aiosqlite_available():
        pytest.skip("aiosqlite not installed")

    # Force the unavailable code path even if sqlite_vec is installed.
    monkeypatch.setattr(
        "agents._shared.storage.backends.sqlite_backend._SQLITE_VEC_AVAILABLE",
        False,
    )
    from agents._shared.storage.backends.sqlite_backend import _SqliteConnection

    conn = _SqliteConnection(db_path=tmp_path / "no_vec.db")
    await conn.open()
    try:
        assert conn._sqlite_vec_loaded is False
    finally:
        await conn.close()


@pytest.mark.asyncio
async def test_sqlite_init_is_idempotent(tmp_path: Path):
    """Connecting twice to the same DB does not crash on schema re-creation.

    PRD AC: 'Migrations applied automatically on first run; idempotent'.
    """
    if not _aiosqlite_available():
        pytest.skip("aiosqlite not installed")
    from agents._shared.storage.backends.sqlite_backend import _SqliteConnection

    db_path = tmp_path / "idempotent.db"
    conn1 = _SqliteConnection(db_path=db_path)
    await conn1.open()
    await conn1.close()

    # Re-open same DB — schema CREATE statements use IF NOT EXISTS.
    conn2 = _SqliteConnection(db_path=db_path)
    await conn2.open()
    await conn2.close()


def test_default_db_path_resolves_to_agtestari_db():
    """PRD AC: DB at `~/.agtestari/agtestari.db` (Linux/macOS)
    or `%APPDATA%\\agtestari\\agtestari.db` (Windows)."""
    from agents._shared.storage.backends.sqlite_backend import (
        default_data_dir,
        default_db_path,
    )

    path = default_db_path()
    assert path.name == "agtestari.db"
    assert path.parent == default_data_dir()


def test_default_data_dir_uses_dot_agtestari_on_posix(monkeypatch):
    import sys

    monkeypatch.setattr(sys, "platform", "linux")
    from agents._shared.storage.backends.sqlite_backend import default_data_dir

    expected = Path.home() / ".agtestari"
    assert default_data_dir() == expected


def test_default_data_dir_uses_appdata_on_windows(monkeypatch, tmp_path: Path):
    import sys

    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
    from agents._shared.storage.backends.sqlite_backend import default_data_dir

    expected = tmp_path / "Roaming" / "agtestari"
    assert default_data_dir() == expected


@pytest.mark.parametrize(
    "decision",
    ["PASS", "CONCERNS", "FAIL", "BLOCKED", "WAIVED"],
)
@pytest.mark.asyncio
async def test_sqlite_verdict_roundtrip_per_decision(
    tmp_sqlite_backend: StorageBackend, decision: str
):
    """PRD AC: 'SQLite roundtrip works for all 5 verdict types'."""
    verdict = {
        "verdict": {
            "verdict_id": f"v-{decision.lower()}",
            "run_id": f"r-{decision.lower()}",
            "agent_id": "helena",
            "decision": decision,
            "coverage_pct": 80.0,
            "pass_count": 1,
            "fail_count": 0,
            "skipped_count": 0,
            "duration_seconds": 1.0,
            "blocking_factors": [],
            "issues": [],
        },
        "classified_defects": [],
    }
    await tmp_sqlite_backend.verdicts.save(org_id="org-X", verdict=verdict)
    fetched = await tmp_sqlite_backend.verdicts.get(
        org_id="org-X", run_id=f"r-{decision.lower()}"
    )
    assert fetched is not None
    assert fetched["verdict"]["decision"] == decision
