"""Storage backend factory + selection.

Reads `AGTESTARI_MODE` env var on first call to decide which backend to
construct. Caches the result so subsequent calls return the same handle.

Selection logic:
    AGTESTARI_MODE=local  (default)  → SQLite at OS-appropriate path
    AGTESTARI_MODE=cloud              → Postgres via DATABASE_URL (stub today)
    AGTESTARI_MODE=memory             → In-process dict (tests only)

Override at runtime with `select_backend(StorageMode.X)` — primarily for
tests that need a clean slate per test function.
"""

from __future__ import annotations

import os
from typing import Optional

from agents._shared.storage.backends.base import StorageBackend, StorageMode

_cached: Optional[StorageBackend] = None


def _resolve_mode() -> StorageMode:
    raw = os.environ.get("AGTESTARI_MODE", "local").strip().lower()
    try:
        return StorageMode(raw)
    except ValueError:
        return StorageMode.LOCAL


def get_storage() -> StorageBackend:
    """Return the active storage backend (singleton).

    First call constructs the backend based on `AGTESTARI_MODE`.
    Subsequent calls return the cached instance.
    """
    global _cached
    if _cached is None:
        _cached = _construct(_resolve_mode())
    return _cached


def select_backend(mode: StorageMode, **kwargs) -> StorageBackend:
    """Force-construct a specific backend.

    Replaces the cached singleton. Primarily for tests + CLI overrides.
    """
    global _cached
    _cached = _construct(mode, **kwargs)
    return _cached


def reset_storage() -> None:
    """Clear the cached singleton. Next get_storage() call will reconstruct."""
    global _cached
    _cached = None


def _construct(mode: StorageMode, **kwargs) -> StorageBackend:
    if mode == StorageMode.MEMORY:
        from agents._shared.storage.backends.memory_backend import make_memory_backend
        return make_memory_backend()
    if mode == StorageMode.LOCAL:
        from agents._shared.storage.backends.sqlite_backend import make_sqlite_backend
        return make_sqlite_backend(**kwargs)
    if mode == StorageMode.CLOUD:
        from agents._shared.storage.backends.postgres_backend import make_postgres_backend
        return make_postgres_backend(**kwargs)
    raise ValueError(f"Unknown storage mode: {mode}")
