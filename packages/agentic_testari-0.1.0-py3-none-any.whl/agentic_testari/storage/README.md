# `agents/_shared/storage/` — Storage Abstraction (M.1 + M.2)

Storage-agnostic persistence layer for verdicts, evidence chains, ALMA
patterns, and key material. Selection happens at startup via the
`AGTESTARI_MODE` env var.

| Mode    | Backend                       | Default | Notes                                        |
| ------- | ----------------------------- | ------- | -------------------------------------------- |
| `local` | SQLite (`aiosqlite`)          | yes     | Single-user desktop / CLI install            |
| `cloud` | Postgres (`asyncpg`)          | no      | Stub today — wired in EPIC G cloud rollout   |
| `memory` | In-process `dict`            | no      | Tests + CI                                   |

```python
from agents._shared.storage import get_storage

storage = get_storage()                 # auto-selects per AGTESTARI_MODE
verdict_id = await storage.verdicts.save(org_id="org-A", verdict=...)
chain      = await storage.chains.get_chain(org_id="org-A", run_id="r-1")
patterns   = await storage.alma.get_anti_patterns(org_id="org-A", agent_id="helena")
```

## Local-mode requirements (M.2)

The SQLite backend requires two runtime dependencies:

```bash
pip install aiosqlite sqlite-vec
```

These are declared in each consuming agent's `pyproject.toml` (Helena,
Victor, Aurora, Marco, Pekka). When the wheel ships in M.4, both deps
are pinned in the install spec.

### Why these two

- **`aiosqlite`** — async wrapper around stdlib `sqlite3`. Keeps the
  storage interface uniform with the FastAPI + SQLAlchemy 2.0 pattern
  used elsewhere in the codebase.
- **`sqlite-vec`** — loadable extension that adds vector-similarity
  search to SQLite. Used by `AlmaStore` for embedding-based pattern
  retrieval. Recall@5 ≥ 0.95 at 10k embeddings on a typical laptop.

If `sqlite-vec` is unavailable, the backend falls back to a flat cosine
search in Python — slower at scale but functionally identical.

## Schema bootstrap

The SQLite backend creates its schema on first connect — no separate
migration files. The Postgres backend (cloud mode) consumes the canonical
migrations under `database/provider/migrations/`.

This split keeps the local-mode wheel self-contained: install the wheel,
run the CLI, the DB at `~/.agtestari/agtestari.db` is created and
populated automatically.

## Default DB paths

| OS        | Path                                       |
| --------- | ------------------------------------------ |
| macOS     | `~/.agtestari/agtestari.db`                |
| Linux     | `~/.agtestari/agtestari.db`                |
| Windows   | `%APPDATA%\agtestari\agtestari.db`         |

Override via `AGTESTARI_DB_PATH=/custom/path.db`.

## Tenant isolation

Every method takes `org_id` explicitly. There is no implicit "current
org" — callers must pass it. Cross-org reads return `None` (or empty
list). Single-user local mode typically runs as a single org.

## Smoke test

To verify the full stack on a fresh machine:

```bash
python -m agents._shared.storage.tests.smoke_sqlite_vec
```

Expected output:

```
vec_version: v0.1.9
row_count: 1
SMOKE PASS
```

The full test suite uses pytest:

```bash
PYTHONIOENCODING=utf-8 python -m pytest agents/_shared/storage/tests/ -v
```
