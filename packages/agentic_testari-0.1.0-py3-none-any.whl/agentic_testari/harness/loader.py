"""Harness loader — read-only access to AIOS bundled resources.

Resource layout in the bundle root:
    .aios-core/development/agents/{id}.md         → personas
    .aios-core/development/tasks/{id}.md          → tasks
    .aios-core/development/workflows/{id}.yaml    → workflows
    .aios-core/development/templates/{id}.{ext}   → templates (yaml/md/hbs)
    .aios-core/product/checklists/{id}.md         → checklists
    .claude/rules/{id}.md                         → rules
    .claude/skills/{id}/SKILL.md                  → skills

API:
    HarnessLoader().load_persona("dev")          → markdown text
    HarnessLoader().load_workflow("greenfield-fullstack")
    HarnessLoader().load_rule("agent-authority")
    HarnessLoader().load_skill("aiox-maestro")
    HarnessLoader().load_checklist("story-dod-checklist")
    HarnessLoader().load_task("create-next-story")
    HarnessLoader().load_template("agent-template")  # finds any extension

    HarnessLoader().list_personas()  → ["aios-master", "analyst", ...]
    HarnessLoader().list_workflows() → ["greenfield-fullstack", ...]
    HarnessLoader().list_rules()     → ["agent-authority", ...]
    HarnessLoader().list_skills()    → ["aiox-maestro", ...]
    HarnessLoader().list_checklists()
    HarnessLoader().list_tasks()
    HarnessLoader().list_templates()
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

from agents._shared.harness.bundle import BundleRoot, resolve_bundle_root
from agents._shared.harness.types import (
    HarnessError,
    ResourceKind,
    ResourceNotFoundError,
)

_TEMPLATE_EXTENSIONS = (".yaml", ".yml", ".md", ".hbs")


class HarnessLoader:
    """Read-only loader for AIOS bundled resources.

    Constructed with no args in production. Tests pass `bundle_root` to point
    at a fixture directory.
    """

    def __init__(self, bundle_root: Optional[Path] = None):
        self._bundle: BundleRoot = resolve_bundle_root(bundle_root)

    @property
    def bundle_root(self) -> Path:
        return self._bundle.root

    # ---- personas ----

    def _personas_dir(self) -> Path:
        return self._bundle.aios_core / "development" / "agents"

    def list_personas(self) -> list[str]:
        return _list_md_ids(self._personas_dir())

    def load_persona(self, resource_id: str) -> str:
        path = self._personas_dir() / f"{resource_id}.md"
        return _read_or_raise(path, ResourceKind.PERSONA, resource_id, [str(path)])

    # ---- tasks ----

    def _tasks_dir(self) -> Path:
        return self._bundle.aios_core / "development" / "tasks"

    def list_tasks(self) -> list[str]:
        return _list_md_ids(self._tasks_dir())

    def load_task(self, resource_id: str) -> str:
        path = self._tasks_dir() / f"{resource_id}.md"
        return _read_or_raise(path, ResourceKind.TASK, resource_id, [str(path)])

    # ---- workflows ----

    def _workflows_dir(self) -> Path:
        return self._bundle.aios_core / "development" / "workflows"

    def list_workflows(self) -> list[str]:
        d = self._workflows_dir()
        if not d.is_dir():
            return []
        return sorted(p.stem for p in d.iterdir() if p.suffix in (".yaml", ".yml"))

    def load_workflow(self, resource_id: str) -> str:
        d = self._workflows_dir()
        searched: list[str] = []
        for ext in (".yaml", ".yml"):
            path = d / f"{resource_id}{ext}"
            searched.append(str(path))
            if path.is_file():
                return path.read_text(encoding="utf-8")
        raise ResourceNotFoundError(ResourceKind.WORKFLOW, resource_id, searched)

    # ---- templates ----

    def _template_dirs(self) -> Iterable[Path]:
        # Development templates first, then product templates as fallback.
        yield self._bundle.aios_core / "development" / "templates"
        yield self._bundle.aios_core / "product" / "templates"

    def list_templates(self) -> list[str]:
        seen: set[str] = set()
        for d in self._template_dirs():
            if not d.is_dir():
                continue
            for p in d.iterdir():
                if p.is_file() and p.suffix in _TEMPLATE_EXTENSIONS:
                    seen.add(p.stem)
        return sorted(seen)

    def load_template(self, resource_id: str) -> str:
        searched: list[str] = []
        for d in self._template_dirs():
            for ext in _TEMPLATE_EXTENSIONS:
                path = d / f"{resource_id}{ext}"
                searched.append(str(path))
                if path.is_file():
                    return path.read_text(encoding="utf-8")
        raise ResourceNotFoundError(ResourceKind.TEMPLATE, resource_id, searched)

    # ---- checklists ----

    def _checklist_dirs(self) -> Iterable[Path]:
        # Product checklists are the canonical location.
        yield self._bundle.aios_core / "product" / "checklists"
        # Development checklists are a future possibility — checked second.
        yield self._bundle.aios_core / "development" / "checklists"

    def list_checklists(self) -> list[str]:
        seen: set[str] = set()
        for d in self._checklist_dirs():
            if not d.is_dir():
                continue
            for p in d.iterdir():
                if p.is_file() and p.suffix == ".md":
                    seen.add(p.stem)
        return sorted(seen)

    def load_checklist(self, resource_id: str) -> str:
        searched: list[str] = []
        for d in self._checklist_dirs():
            path = d / f"{resource_id}.md"
            searched.append(str(path))
            if path.is_file():
                return path.read_text(encoding="utf-8")
        raise ResourceNotFoundError(ResourceKind.CHECKLIST, resource_id, searched)

    # ---- rules ----

    def _rules_dir(self) -> Path:
        return self._bundle.claude_dir / "rules"

    def list_rules(self) -> list[str]:
        return _list_md_ids(self._rules_dir())

    def load_rule(self, resource_id: str) -> str:
        path = self._rules_dir() / f"{resource_id}.md"
        return _read_or_raise(path, ResourceKind.RULE, resource_id, [str(path)])

    # ---- skills ----

    def _skills_dir(self) -> Path:
        return self._bundle.claude_dir / "skills"

    def list_skills(self) -> list[str]:
        d = self._skills_dir()
        if not d.is_dir():
            return []
        return sorted(
            child.name
            for child in d.iterdir()
            if child.is_dir() and (child / "SKILL.md").is_file()
        )

    def load_skill(self, resource_id: str) -> str:
        path = self._skills_dir() / resource_id / "SKILL.md"
        return _read_or_raise(path, ResourceKind.SKILL, resource_id, [str(path)])

    # ---- generic accessor ----

    def load(self, kind: ResourceKind, resource_id: str) -> str:
        """Generic load by ResourceKind. Useful for dispatch tables."""
        match kind:
            case ResourceKind.PERSONA:
                return self.load_persona(resource_id)
            case ResourceKind.TASK:
                return self.load_task(resource_id)
            case ResourceKind.WORKFLOW:
                return self.load_workflow(resource_id)
            case ResourceKind.TEMPLATE:
                return self.load_template(resource_id)
            case ResourceKind.CHECKLIST:
                return self.load_checklist(resource_id)
            case ResourceKind.RULE:
                return self.load_rule(resource_id)
            case ResourceKind.SKILL:
                return self.load_skill(resource_id)
        raise HarnessError(f"Unsupported ResourceKind: {kind}")


# ---- helpers ----


def _list_md_ids(d: Path) -> list[str]:
    if not d.is_dir():
        return []
    return sorted(p.stem for p in d.iterdir() if p.suffix == ".md" and p.is_file())


def _read_or_raise(
    path: Path,
    kind: ResourceKind,
    resource_id: str,
    searched: list[str],
) -> str:
    if not path.is_file():
        raise ResourceNotFoundError(kind, resource_id, searched)
    return path.read_text(encoding="utf-8")


# ---- module-level singleton ----

_default: Optional[HarnessLoader] = None


def get_harness() -> HarnessLoader:
    """Return a process-wide HarnessLoader instance.

    Construction is cheap (just resolves the bundle root), but caching makes
    consumers' lives easier and centralises any future warm-up.
    """
    global _default
    if _default is None:
        _default = HarnessLoader()
    return _default
