"""Tests for bundle root resolution."""

from __future__ import annotations

from pathlib import Path

import pytest

from agents._shared.harness.bundle import BundleRoot, resolve_bundle_root


def test_resolves_dev_root_walking_up():
    """In the source tree, the loader finds the repo root automatically."""
    root = resolve_bundle_root()
    assert isinstance(root, BundleRoot)
    assert (root.root / ".aios-core").is_dir()
    assert (root.root / ".claude").is_dir()


def test_explicit_root_accepted_when_markers_present(tmp_path: Path):
    """An explicit root with the right markers is accepted verbatim."""
    (tmp_path / ".aios-core").mkdir()
    (tmp_path / ".claude").mkdir()
    root = resolve_bundle_root(tmp_path)
    assert root.root == tmp_path.resolve()


def test_explicit_root_rejected_when_markers_missing(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        resolve_bundle_root(tmp_path)


def test_aios_core_and_claude_paths_exposed(tmp_path: Path):
    (tmp_path / ".aios-core").mkdir()
    (tmp_path / ".claude").mkdir()
    root = resolve_bundle_root(tmp_path)
    assert root.aios_core == (tmp_path / ".aios-core").resolve()
    assert root.claude_dir == (tmp_path / ".claude").resolve()


def test_repr_contains_path(tmp_path: Path):
    (tmp_path / ".aios-core").mkdir()
    (tmp_path / ".claude").mkdir()
    root = resolve_bundle_root(tmp_path)
    assert str(tmp_path.resolve()) in repr(root)
