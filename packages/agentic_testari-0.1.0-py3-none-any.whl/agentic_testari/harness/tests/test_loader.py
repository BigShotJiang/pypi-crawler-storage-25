"""Tests for HarnessLoader against the real source-tree bundle.

These tests run against the actual `.aios-core/` and `.claude/` directories
in the repo, which is the same layout that ships in the wheel under
`agents/_shared/harness/_resources/`.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agents._shared.harness import (
    HarnessLoader,
    ResourceKind,
    ResourceNotFoundError,
    get_harness,
)


@pytest.fixture(scope="module")
def harness() -> HarnessLoader:
    return HarnessLoader()


# ---- personas ----


def test_lists_at_least_seven_personas(harness: HarnessLoader):
    personas = harness.list_personas()
    assert len(personas) >= 7
    # Spot-check the personas Renata uses most.
    for must_have in ("dev", "qa", "architect", "pm", "po", "sm", "devops"):
        assert must_have in personas, f"{must_have!r} not in {personas}"


def test_loads_dev_persona_returns_markdown(harness: HarnessLoader):
    text = harness.load_persona("dev")
    assert isinstance(text, str)
    assert len(text) > 100
    # Persona files are markdown — should contain a header somewhere.
    assert "#" in text


def test_loads_each_listed_persona(harness: HarnessLoader):
    """Every listed persona must actually load. No phantom entries."""
    for pid in harness.list_personas():
        text = harness.load_persona(pid)
        assert text, f"Persona {pid} loaded as empty string"


def test_unknown_persona_raises(harness: HarnessLoader):
    with pytest.raises(ResourceNotFoundError) as exc_info:
        harness.load_persona("not-a-real-persona")
    assert exc_info.value.kind == ResourceKind.PERSONA
    assert exc_info.value.resource_id == "not-a-real-persona"
    assert exc_info.value.searched, "searched list should not be empty"


# ---- workflows ----


def test_lists_at_least_four_workflows(harness: HarnessLoader):
    workflows = harness.list_workflows()
    assert len(workflows) >= 4
    # Greenfield + brownfield are the canonical AIOS workflows.
    assert any(w.startswith("greenfield-") for w in workflows)
    assert any(w.startswith("brownfield-") for w in workflows)


def test_loads_workflow_yaml(harness: HarnessLoader):
    text = harness.load_workflow("greenfield-fullstack")
    assert "workflow" in text.lower() or "name:" in text


def test_unknown_workflow_raises(harness: HarnessLoader):
    with pytest.raises(ResourceNotFoundError) as exc_info:
        harness.load_workflow("not-a-real-workflow")
    assert exc_info.value.kind == ResourceKind.WORKFLOW


# ---- rules ----


def test_lists_at_least_twelve_rules(harness: HarnessLoader):
    rules = harness.list_rules()
    assert len(rules) >= 12
    # Spot-check rules referenced from CLAUDE.md.
    for must_have in (
        "agent-authority",
        "quality-foundation",
        "session-handoff",
        "mcp-usage",
    ):
        assert must_have in rules, f"{must_have!r} not in {rules}"


def test_loads_rule_returns_markdown(harness: HarnessLoader):
    text = harness.load_rule("agent-authority")
    assert isinstance(text, str)
    assert "agent" in text.lower()


def test_unknown_rule_raises(harness: HarnessLoader):
    with pytest.raises(ResourceNotFoundError):
        harness.load_rule("not-a-real-rule")


# ---- skills ----


def test_lists_skills_includes_aiox_maestro(harness: HarnessLoader):
    skills = harness.list_skills()
    assert "aiox-maestro" in skills


def test_loads_skill_returns_markdown(harness: HarnessLoader):
    text = harness.load_skill("aiox-maestro")
    assert "AIOX Maestro" in text or "Maestro" in text


def test_unknown_skill_raises(harness: HarnessLoader):
    with pytest.raises(ResourceNotFoundError):
        harness.load_skill("not-a-real-skill")


# ---- checklists ----


def test_lists_checklists_returns_known_ids(harness: HarnessLoader):
    checklists = harness.list_checklists()
    assert len(checklists) >= 5
    # Spot-check checklists referenced in story-lifecycle.md.
    for must_have in ("story-dod-checklist", "story-draft-checklist"):
        assert must_have in checklists


def test_loads_checklist(harness: HarnessLoader):
    text = harness.load_checklist("story-dod-checklist")
    assert isinstance(text, str)
    assert text.strip()


# ---- templates ----


def test_lists_templates(harness: HarnessLoader):
    templates = harness.list_templates()
    assert len(templates) >= 3


def test_loads_template_handles_yaml_extension(harness: HarnessLoader):
    """Template files ship in multiple extensions; loader picks the right one."""
    templates = harness.list_templates()
    # Pick any template and verify it loads.
    sample = templates[0]
    text = harness.load_template(sample)
    assert isinstance(text, str)
    assert text  # non-empty


def test_unknown_template_raises(harness: HarnessLoader):
    with pytest.raises(ResourceNotFoundError):
        harness.load_template("not-a-real-template")


# ---- generic load() dispatch ----


def test_generic_load_dispatches_by_kind(harness: HarnessLoader):
    persona = harness.load(ResourceKind.PERSONA, "dev")
    rule = harness.load(ResourceKind.RULE, "agent-authority")
    workflow = harness.load(ResourceKind.WORKFLOW, "greenfield-fullstack")
    assert persona and rule and workflow


# ---- singleton ----


def test_get_harness_returns_same_instance():
    a = get_harness()
    b = get_harness()
    assert a is b


# ---- explicit root override ----


def test_explicit_root_is_isolated(tmp_path: Path):
    """Pointing at a fixture root must not see resources from the real repo."""
    (tmp_path / ".aios-core").mkdir()
    (tmp_path / ".aios-core" / "development").mkdir()
    agents_dir = tmp_path / ".aios-core" / "development" / "agents"
    agents_dir.mkdir()
    (agents_dir / "fake.md").write_text("# Fake persona\n", encoding="utf-8")
    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "rules").mkdir()
    (tmp_path / ".claude" / "rules" / "fake-rule.md").write_text(
        "# Fake rule\n", encoding="utf-8"
    )

    isolated = HarnessLoader(bundle_root=tmp_path)
    assert isolated.list_personas() == ["fake"]
    assert isolated.list_rules() == ["fake-rule"]
    assert "Fake persona" in isolated.load_persona("fake")
    # Real repo's `dev` persona must be invisible from the isolated root.
    with pytest.raises(ResourceNotFoundError):
        isolated.load_persona("dev")
