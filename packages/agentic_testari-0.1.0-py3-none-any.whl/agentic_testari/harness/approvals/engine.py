"""ApprovalEngine — state machine that drives an HITL approval.

Key methods:

    create_request(...) → ApprovalRequest
        Build the request, fan out via channels, store as PENDING.

    resolve(request_id, status, decided_by, reason) → ApprovalResponse
        Move from PENDING → terminal (approved / rejected / abstained /
        cancelled). Idempotent: resolving an already-terminal request
        returns the existing response without changing state.

    wait(request_id, poll_seconds, deadline) → ApprovalResponse
        Block (async) until the request is terminal or its expires_at
        passes. The engine auto-converts PENDING → TIMED_OUT when the
        expires_at clock passes.

    get(request_id) → ApprovalRequest | None
    get_response(request_id) → ApprovalResponse | None

The default in-memory store is process-local. Production wiring will
swap it for the M.1 storage layer; the engine takes any object
implementing the `ApprovalStore` protocol.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Iterable, Optional, Protocol

from agents._shared.harness.approvals.channels import NotificationChannel
from agents._shared.harness.approvals.types import (
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
)


class ApprovalNotFoundError(Exception):
    """Raised when a request_id has no record in the store."""


class ApprovalStore(Protocol):
    """Contract for any backing store the engine may use."""

    def save_request(self, request: ApprovalRequest) -> None: ...
    def save_response(self, response: ApprovalResponse) -> None: ...
    def get_request(self, request_id: str) -> Optional[ApprovalRequest]: ...
    def get_response(self, request_id: str) -> Optional[ApprovalResponse]: ...
    def list_pending(self) -> list[ApprovalRequest]: ...


class InMemoryApprovalStore:
    """Default in-memory store. Process-local; swap for production."""

    def __init__(self) -> None:
        self._requests: dict[str, ApprovalRequest] = {}
        self._responses: dict[str, ApprovalResponse] = {}

    def save_request(self, request: ApprovalRequest) -> None:
        self._requests[request.request_id] = request

    def save_response(self, response: ApprovalResponse) -> None:
        self._responses[response.request_id] = response

    def get_request(self, request_id: str) -> Optional[ApprovalRequest]:
        return self._requests.get(request_id)

    def get_response(self, request_id: str) -> Optional[ApprovalResponse]:
        return self._responses.get(request_id)

    def list_pending(self) -> list[ApprovalRequest]:
        pending = []
        for req in self._requests.values():
            resp = self._responses.get(req.request_id)
            if resp is None or resp.status is ApprovalStatus.PENDING:
                pending.append(req)
        return pending


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ApprovalEngine:
    """State machine for HITL approval requests."""

    def __init__(self, store: Optional[ApprovalStore] = None):
        self._store: ApprovalStore = store or InMemoryApprovalStore()

    @property
    def store(self) -> ApprovalStore:
        return self._store

    # ---- create + notify ----

    def create_request(
        self,
        *,
        run_id: str,
        title: str,
        message: str,
        approvers: Iterable[str],
        timeout_hours: float = 24.0,
        channels: Iterable[NotificationChannel] = (),
        metadata: Optional[dict] = None,
    ) -> ApprovalRequest:
        request = ApprovalRequest.build(
            run_id=run_id,
            title=title,
            message=message,
            approvers=tuple(approvers),
            timeout_hours=timeout_hours,
            metadata=metadata,
        )
        self._store.save_request(request)
        for channel in channels:
            try:
                channel.notify(request)
            except Exception as exc:
                # Notification failures must NOT block the request;
                # the engine logs and moves on. Production code can
                # subscribe to a callback for retry handling.
                request.metadata.setdefault("notification_errors", []).append(
                    {"channel": channel.name, "error": str(exc)}
                )
        return request

    # ---- resolve ----

    def resolve(
        self,
        request_id: str,
        status: ApprovalStatus,
        *,
        decided_by: Optional[str] = None,
        reason: str = "",
    ) -> ApprovalResponse:
        if status is ApprovalStatus.PENDING:
            raise ValueError("cannot resolve to PENDING")
        request = self._store.get_request(request_id)
        if request is None:
            raise ApprovalNotFoundError(
                f"approval request {request_id!r} not found"
            )
        existing = self._store.get_response(request_id)
        if existing is not None and existing.is_terminal:
            return existing
        response = ApprovalResponse(
            request_id=request_id,
            status=status,
            decided_by=decided_by,
            reason=reason,
        )
        self._store.save_response(response)
        return response

    def cancel(
        self,
        request_id: str,
        *,
        reason: str = "cancelled by admin",
    ) -> ApprovalResponse:
        return self.resolve(
            request_id,
            ApprovalStatus.CANCELLED,
            decided_by="system",
            reason=reason,
        )

    # ---- wait + timeout ----

    async def wait(
        self,
        request_id: str,
        *,
        poll_seconds: float = 1.0,
        deadline: Optional[datetime] = None,
    ) -> ApprovalResponse:
        """Block until the request is terminal or expires.

        Polls the store every `poll_seconds`. On expiry, auto-converts
        PENDING → TIMED_OUT.
        """
        request = self._store.get_request(request_id)
        if request is None:
            raise ApprovalNotFoundError(
                f"approval request {request_id!r} not found"
            )
        effective_deadline = deadline or request.expires_at
        while True:
            response = self._store.get_response(request_id)
            if response is not None and response.is_terminal:
                return response
            if _utc_now() >= effective_deadline:
                return self._timeout(request_id)
            await asyncio.sleep(poll_seconds)

    def _timeout(self, request_id: str) -> ApprovalResponse:
        existing = self._store.get_response(request_id)
        if existing is not None and existing.is_terminal:
            return existing
        response = ApprovalResponse(
            request_id=request_id,
            status=ApprovalStatus.TIMED_OUT,
            decided_by="system",
            reason="timeout window elapsed",
        )
        self._store.save_response(response)
        return response

    # ---- accessors ----

    def get(self, request_id: str) -> Optional[ApprovalRequest]:
        return self._store.get_request(request_id)

    def get_response(self, request_id: str) -> Optional[ApprovalResponse]:
        return self._store.get_response(request_id)

    def list_pending(self) -> list[ApprovalRequest]:
        return self._store.list_pending()
