"""HITL Approval Engine (EPIC P).

Replaces the workflow-engine stub at services/workflow-engine/src/nodes/
control.py:301-312 with a real approval state machine.

When a workflow hits an `approval` node, the harness creates an
ApprovalRequest, fans it out to one or more NotificationChannels (CLI
prompt / email / Slack / Teams), and parks the workflow until either:

  - An approver responds (approve / reject / abstain)
  - The timeout window elapses (default: 24 hours)
  - Admin force-resolves via kill switch (EPIC Q)

The engine is storage-agnostic — pass an in-memory store for tests, or
the M.1 sqlite/postgres-backed store in production.

Usage:
    from agents._shared.harness.approvals import (
        ApprovalEngine, ApprovalChannel, CliChannel,
    )

    engine = ApprovalEngine()
    request = engine.create_request(
        run_id="r-1",
        title="Production deploy",
        message="Approve deploy of v0.2.0?",
        approvers=("alice@org.com",),
        timeout_hours=24,
        channels=(CliChannel(),),
    )
    # ... send notifications ...
    response = await engine.wait(request.request_id, poll_seconds=1)
    # response.status == ApprovalStatus.APPROVED | REJECTED | TIMED_OUT
"""

from agents._shared.harness.approvals.channels import (
    CliChannel,
    NotificationChannel,
    SlackChannel,
    TeamsChannel,
    EmailChannel,
)
from agents._shared.harness.approvals.engine import (
    ApprovalEngine,
    ApprovalNotFoundError,
)
from agents._shared.harness.approvals.types import (
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    ApprovalChannel,
)

__all__ = [
    "ApprovalEngine",
    "ApprovalRequest",
    "ApprovalResponse",
    "ApprovalStatus",
    "ApprovalChannel",
    "ApprovalNotFoundError",
    "NotificationChannel",
    "CliChannel",
    "SlackChannel",
    "TeamsChannel",
    "EmailChannel",
]

__version__ = "1.0.0"
