"""Notification channels — fan out an ApprovalRequest to humans.

Concrete channels (CLI, Slack, Teams, email) all implement the same
interface so the engine doesn't care which one it's sending to.

The CliChannel is fully wired (writes to a file or stdout). Slack /
Teams / Email are STUBS that record the call without sending — this
keeps the engine testable end-to-end without external API access.
M.7 (license) and EPIC Q (admin portal) ship the production senders.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, TextIO

from agents._shared.harness.approvals.types import ApprovalRequest


class NotificationChannel(Protocol):
    """Implementations send approval notifications to humans."""

    name: str

    def notify(self, request: ApprovalRequest) -> None: ...


@dataclass
class CliChannel:
    """Prints the approval prompt to a stream (default stdout).

    Useful for local CLI runs. The engine doesn't read from stdin —
    approvers respond via the CLI/dashboard which calls
    `engine.resolve(request_id, ...)` directly.
    """

    name: str = "cli"
    out: TextIO | None = None

    def notify(self, request: ApprovalRequest) -> None:
        import sys

        stream = self.out if self.out is not None else sys.stdout
        approvers = ", ".join(request.approvers)
        stream.write(
            f"\n[approval] {request.title}\n"
            f"  request_id: {request.request_id}\n"
            f"  message:    {request.message}\n"
            f"  approvers:  {approvers}\n"
            f"  expires_at: {request.expires_at.isoformat()}\n"
            f"\nApprove with: at-cli approval resolve {request.request_id} approve\n"
            f"Reject with:  at-cli approval resolve {request.request_id} reject\n"
        )
        stream.flush()


@dataclass
class _StubChannel:
    """Records `notify()` calls without sending. Subclass for stub channels."""

    name: str
    sent: list[ApprovalRequest] = field(default_factory=list)

    def notify(self, request: ApprovalRequest) -> None:
        self.sent.append(request)


@dataclass
class SlackChannel(_StubChannel):
    """Stub for Slack — production sender lands in EPIC Q admin portal."""

    name: str = "slack"


@dataclass
class TeamsChannel(_StubChannel):
    """Stub for Microsoft Teams."""

    name: str = "teams"


@dataclass
class EmailChannel(_StubChannel):
    """Stub for SMTP / SES email."""

    name: str = "email"
