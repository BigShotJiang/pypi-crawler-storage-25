"""Approval engine types."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Optional
from uuid import uuid4


class ApprovalStatus(str, Enum):
    """Lifecycle states for an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    ABSTAINED = "abstained"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"


class ApprovalChannel(str, Enum):
    """Built-in notification channel kinds."""

    CLI = "cli"
    EMAIL = "email"
    SLACK = "slack"
    TEAMS = "teams"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class ApprovalRequest:
    """A pending approval request."""

    request_id: str
    run_id: str
    title: str
    message: str
    approvers: tuple[str, ...]
    timeout_hours: float
    created_at: datetime
    expires_at: datetime
    metadata: dict = field(default_factory=dict)

    @classmethod
    def build(
        cls,
        *,
        run_id: str,
        title: str,
        message: str,
        approvers: tuple[str, ...],
        timeout_hours: float = 24.0,
        request_id: Optional[str] = None,
        created_at: Optional[datetime] = None,
        metadata: Optional[dict] = None,
    ) -> "ApprovalRequest":
        if not approvers:
            raise ValueError("at least one approver required")
        now = created_at or _utc_now()
        return cls(
            request_id=request_id or f"apr-{uuid4().hex[:12]}",
            run_id=run_id,
            title=title.strip() or "(untitled)",
            message=message.strip(),
            approvers=tuple(approvers),
            timeout_hours=float(timeout_hours),
            created_at=now,
            expires_at=now + timedelta(hours=float(timeout_hours)),
            metadata=dict(metadata or {}),
        )


@dataclass(frozen=True)
class ApprovalResponse:
    """An approver's response (or a timeout / cancel record)."""

    request_id: str
    status: ApprovalStatus
    decided_by: Optional[str] = None
    reason: str = ""
    decided_at: datetime = field(default_factory=_utc_now)

    @property
    def is_terminal(self) -> bool:
        return self.status is not ApprovalStatus.PENDING
