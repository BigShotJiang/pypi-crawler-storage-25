"""Tests for the HITL ApprovalEngine."""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from io import StringIO

import pytest

from agents._shared.harness.approvals import (
    ApprovalEngine,
    ApprovalNotFoundError,
    ApprovalRequest,
    ApprovalStatus,
    CliChannel,
    EmailChannel,
    SlackChannel,
)
from agents._shared.harness.approvals.engine import InMemoryApprovalStore


# ---- ApprovalRequest builder ----


def test_build_request_generates_id_and_expiry():
    req = ApprovalRequest.build(
        run_id="r",
        title="Deploy",
        message="ok?",
        approvers=("alice@org",),
        timeout_hours=2,
    )
    assert req.request_id.startswith("apr-")
    assert req.run_id == "r"
    assert req.title == "Deploy"
    assert req.expires_at == req.created_at + timedelta(hours=2)


def test_build_request_rejects_empty_approvers():
    with pytest.raises(ValueError):
        ApprovalRequest.build(
            run_id="r", title="x", message="", approvers=()
        )


def test_build_request_strips_title_and_handles_empty():
    req = ApprovalRequest.build(
        run_id="r", title="   ", message="", approvers=("a@b",)
    )
    assert req.title == "(untitled)"


# ---- create + notify ----


def test_create_persists_request_and_notifies_channels():
    engine = ApprovalEngine()
    cli_buf = StringIO()
    cli = CliChannel(out=cli_buf)
    slack = SlackChannel()
    req = engine.create_request(
        run_id="r-1",
        title="Approve deploy",
        message="ship it?",
        approvers=("alice@org",),
        channels=(cli, slack),
    )
    assert engine.get(req.request_id) is req
    text = cli_buf.getvalue()
    assert "Approve deploy" in text
    assert "ship it?" in text
    assert req.request_id in text
    assert len(slack.sent) == 1
    assert slack.sent[0].request_id == req.request_id


def test_notification_failure_recorded_not_raised():
    engine = ApprovalEngine()

    class BadChannel:
        name = "bad"

        def notify(self, request: ApprovalRequest) -> None:
            raise RuntimeError("smtp down")

    req = engine.create_request(
        run_id="r",
        title="x",
        message="y",
        approvers=("a@b",),
        channels=(BadChannel(),),
    )
    errs = req.metadata.get("notification_errors", [])
    assert len(errs) == 1
    assert errs[0]["channel"] == "bad"
    assert "smtp down" in errs[0]["error"]


# ---- resolve ----


def test_resolve_approves_request():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    resp = engine.resolve(
        req.request_id,
        ApprovalStatus.APPROVED,
        decided_by="alice@org",
        reason="LGTM",
    )
    assert resp.status is ApprovalStatus.APPROVED
    assert resp.decided_by == "alice@org"
    assert resp.is_terminal


def test_resolve_rejects_request():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    resp = engine.resolve(req.request_id, ApprovalStatus.REJECTED)
    assert resp.status is ApprovalStatus.REJECTED


def test_resolve_idempotent_on_second_call():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    first = engine.resolve(req.request_id, ApprovalStatus.APPROVED)
    second = engine.resolve(req.request_id, ApprovalStatus.REJECTED)
    # Once approved, second call returns the existing approval — no flip-flop.
    assert second is first
    assert second.status is ApprovalStatus.APPROVED


def test_resolve_cannot_set_pending():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    with pytest.raises(ValueError):
        engine.resolve(req.request_id, ApprovalStatus.PENDING)


def test_resolve_unknown_request_raises():
    engine = ApprovalEngine()
    with pytest.raises(ApprovalNotFoundError):
        engine.resolve("not-a-request", ApprovalStatus.APPROVED)


def test_cancel_marks_cancelled():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    resp = engine.cancel(req.request_id, reason="stop deploy")
    assert resp.status is ApprovalStatus.CANCELLED
    assert resp.decided_by == "system"


# ---- wait + timeout ----


@pytest.mark.asyncio
async def test_wait_returns_when_resolved():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )

    async def resolve_later():
        await asyncio.sleep(0.05)
        engine.resolve(req.request_id, ApprovalStatus.APPROVED)

    asyncio.create_task(resolve_later())
    resp = await engine.wait(req.request_id, poll_seconds=0.01)
    assert resp.status is ApprovalStatus.APPROVED


@pytest.mark.asyncio
async def test_wait_times_out_when_deadline_passes():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",), timeout_hours=24,
    )
    deadline = datetime.now(timezone.utc) - timedelta(seconds=1)
    resp = await engine.wait(req.request_id, poll_seconds=0.01, deadline=deadline)
    assert resp.status is ApprovalStatus.TIMED_OUT
    assert resp.decided_by == "system"


@pytest.mark.asyncio
async def test_wait_unknown_request_raises():
    engine = ApprovalEngine()
    with pytest.raises(ApprovalNotFoundError):
        await engine.wait("nope")


@pytest.mark.asyncio
async def test_wait_idempotent_on_already_resolved():
    """Calling wait() on an already-resolved request returns immediately."""
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    engine.resolve(req.request_id, ApprovalStatus.APPROVED)
    resp = await engine.wait(req.request_id, poll_seconds=0.01)
    assert resp.status is ApprovalStatus.APPROVED


# ---- accessors ----


def test_get_returns_none_for_unknown():
    assert ApprovalEngine().get("missing") is None


def test_get_response_returns_none_until_resolved():
    engine = ApprovalEngine()
    req = engine.create_request(
        run_id="r", title="x", message="", approvers=("a@b",)
    )
    assert engine.get_response(req.request_id) is None
    engine.resolve(req.request_id, ApprovalStatus.APPROVED)
    assert engine.get_response(req.request_id) is not None


def test_list_pending_excludes_resolved():
    engine = ApprovalEngine()
    a = engine.create_request(
        run_id="r1", title="A", message="", approvers=("x@y",)
    )
    b = engine.create_request(
        run_id="r2", title="B", message="", approvers=("x@y",)
    )
    engine.resolve(a.request_id, ApprovalStatus.APPROVED)
    pending = engine.list_pending()
    assert len(pending) == 1
    assert pending[0].request_id == b.request_id


# ---- channels ----


def test_cli_channel_writes_actionable_command():
    buf = StringIO()
    cli = CliChannel(out=buf)
    req = ApprovalRequest.build(
        run_id="r", title="t", message="m", approvers=("a@b",)
    )
    cli.notify(req)
    text = buf.getvalue()
    assert "at-cli approval resolve" in text
    assert "approve" in text
    assert "reject" in text


def test_stub_channels_record_calls():
    slack = SlackChannel()
    teams = TeamsChannel = SlackChannel().__class__  # default name 'slack'
    email = EmailChannel()

    req = ApprovalRequest.build(
        run_id="r", title="t", message="", approvers=("a@b",)
    )
    slack.notify(req)
    email.notify(req)
    assert slack.sent[0] is req
    assert email.sent[0] is req


def test_inmemory_store_independent_instances():
    a = InMemoryApprovalStore()
    b = InMemoryApprovalStore()
    req = ApprovalRequest.build(
        run_id="r", title="t", message="", approvers=("a@b",)
    )
    a.save_request(req)
    assert a.get_request(req.request_id) is req
    assert b.get_request(req.request_id) is None
