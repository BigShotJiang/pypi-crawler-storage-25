"""Shared types + errors for the harness loader."""

from __future__ import annotations

from enum import Enum


class ResourceKind(str, Enum):
    """Kinds of AIOS resources the harness can load."""

    PERSONA = "persona"
    TASK = "task"
    TEMPLATE = "template"
    CHECKLIST = "checklist"
    WORKFLOW = "workflow"
    RULE = "rule"
    SKILL = "skill"


class HarnessError(Exception):
    """Base error for harness operations."""


class ResourceNotFoundError(HarnessError):
    """Raised when a requested resource id does not exist."""

    def __init__(self, kind: ResourceKind, resource_id: str, searched: list[str]):
        self.kind = kind
        self.resource_id = resource_id
        self.searched = searched
        super().__init__(
            f"{kind.value} '{resource_id}' not found. Searched: "
            + ", ".join(searched)
        )
