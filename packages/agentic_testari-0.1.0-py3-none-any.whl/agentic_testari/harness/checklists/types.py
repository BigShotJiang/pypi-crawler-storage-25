"""Checklist types."""

from __future__ import annotations

from dataclasses import dataclass


class ChecklistError(Exception):
    """Base error for checklist operations."""


@dataclass(frozen=True)
class ChecklistItemResult:
    """Result of a single checklist item."""

    item_id: str       # e.g., "qa_gate.1"
    label: str         # human-readable label from the .md checklist
    passed: bool
    message: str = ""
    recommendation: str = ""


@dataclass(frozen=True)
class ChecklistResult:
    """Aggregate result of running a full checklist."""

    checklist_id: str
    items: tuple[ChecklistItemResult, ...]

    @property
    def passed(self) -> bool:
        return all(i.passed for i in self.items)

    def failed_items(self) -> tuple[ChecklistItemResult, ...]:
        return tuple(i for i in self.items if not i.passed)

    def passed_items(self) -> tuple[ChecklistItemResult, ...]:
        return tuple(i for i in self.items if i.passed)

    def total(self) -> int:
        return len(self.items)

    def passed_count(self) -> int:
        return sum(1 for i in self.items if i.passed)
