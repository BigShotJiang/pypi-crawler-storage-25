"""QA Gate Checklist — 12-point Quality Foundation matrix as runnable code.

Ported line-by-line from `.claude/rules/quality-foundation-checklist.md`
and `.claude/rules/story-lifecycle.md`. The 12 items map 1:1 to the
markdown checklist so a passing run here matches a passing dev-time
checklist review.

Items 1-5: Tests (BLOCKING)
    1. All unit tests pass
    2. Test coverage >= 80% on changed files
    3. No skipped tests
    4. 3 tests per new function
    5. All acceptance criteria met (with test evidence)

Items 6-8: Documentation (BLOCKING)
    6. Doc comments on all exported functions
    7. Module-level documentation
    8. Complex logic commented

Items 9-12: Validation
    9. No regressions
    10. API documentation (if endpoints added)
    11. Security (OWASP basics)
    12. Performance within acceptable limits

Each item is a check function over CheckContext — re-using the rules
engine context shape so callers don't have to build two parallel
dataclasses.
"""

from __future__ import annotations

from typing import Callable

from agents._shared.harness.checklists.types import (
    ChecklistItemResult,
    ChecklistResult,
)
from agents._shared.harness.rules.types import CheckContext


# Human-readable labels — mirror `quality-foundation-checklist.md`.
QA_GATE_LABELS: dict[str, str] = {
    "qa_gate.1": "All unit tests pass",
    "qa_gate.2": "Test coverage >= 80% on changed files",
    "qa_gate.3": "No skipped tests",
    "qa_gate.4": "3 tests per new function (happy/error/edge)",
    "qa_gate.5": "All acceptance criteria met with evidence",
    "qa_gate.6": "Doc comments on all exported functions",
    "qa_gate.7": "Module-level documentation present",
    "qa_gate.8": "Complex logic commented",
    "qa_gate.9": "No regressions in related areas",
    "qa_gate.10": "API documentation complete",
    "qa_gate.11": "Security basics (OWASP)",
    "qa_gate.12": "Performance within limits",
}


_MIN_TESTS = 3
_MIN_COVERAGE = 0.80


def _item(
    item_id: str, passed: bool, *, message: str = "", recommendation: str = ""
) -> ChecklistItemResult:
    return ChecklistItemResult(
        item_id=item_id,
        label=QA_GATE_LABELS[item_id],
        passed=passed,
        message=message,
        recommendation=recommendation,
    )


def _check_1_tests_pass(ctx: CheckContext) -> ChecklistItemResult:
    failed = int(ctx.metadata.get("failed_test_count", 0))
    if failed > 0:
        return _item(
            "qa_gate.1",
            False,
            message=f"{failed} unit test(s) failed.",
            recommendation="Fix failing tests before requesting QA gate.",
        )
    return _item("qa_gate.1", True)


def _check_2_coverage(ctx: CheckContext) -> ChecklistItemResult:
    if ctx.coverage_changed_files is None:
        return _item("qa_gate.2", True, message="No coverage data supplied.")
    if ctx.coverage_changed_files < _MIN_COVERAGE:
        return _item(
            "qa_gate.2",
            False,
            message=(
                f"Coverage on changed files {ctx.coverage_changed_files:.1%} "
                f"< {_MIN_COVERAGE:.0%}."
            ),
            recommendation="Add tests until coverage on changed files >= 80%.",
        )
    return _item("qa_gate.2", True)


def _check_3_no_skipped(ctx: CheckContext) -> ChecklistItemResult:
    if ctx.skipped_tests_count > 0:
        return _item(
            "qa_gate.3",
            False,
            message=f"{ctx.skipped_tests_count} skipped test(s) found.",
            recommendation="Unskip or remove (with documented reason).",
        )
    return _item("qa_gate.3", True)


def _check_4_tests_per_function(ctx: CheckContext) -> ChecklistItemResult:
    insufficient = [
        fn
        for fn in ctx.new_functions
        if ctx.tests_per_function.get(fn, 0) < _MIN_TESTS
    ]
    if insufficient:
        return _item(
            "qa_gate.4",
            False,
            message=(
                f"{len(insufficient)} function(s) have fewer than "
                f"{_MIN_TESTS} tests: {insufficient[:5]}"
            ),
            recommendation=(
                f"Each new function needs >= {_MIN_TESTS} tests covering "
                "happy path + error path + edge case."
            ),
        )
    return _item("qa_gate.4", True)


def _check_5_ac_met(ctx: CheckContext) -> ChecklistItemResult:
    total = int(ctx.metadata.get("ac_total", 0))
    met = int(ctx.metadata.get("ac_met", 0))
    if total == 0:
        return _item("qa_gate.5", True, message="No AC declared.")
    if met < total:
        return _item(
            "qa_gate.5",
            False,
            message=f"Only {met} of {total} acceptance criteria met.",
            recommendation=(
                "Every AC requires a passing test. Add tests for "
                f"{total - met} unmet AC(s)."
            ),
        )
    return _item("qa_gate.5", True)


def _check_6_doc_comments(ctx: CheckContext) -> ChecklistItemResult:
    undocumented = [
        fn for fn in ctx.new_functions if fn not in ctx.documented_functions
    ]
    if undocumented:
        return _item(
            "qa_gate.6",
            False,
            message=(
                f"{len(undocumented)} new function(s) lack doc comments."
            ),
            recommendation=(
                "Add a docstring to each exported function: what, params, "
                "return, raises."
            ),
        )
    return _item("qa_gate.6", True)


def _check_7_module_docs(ctx: CheckContext) -> ChecklistItemResult:
    """Module-level docs are surfaced via metadata['modules_without_docstring']."""
    missing = ctx.metadata.get("modules_without_docstring", ())
    if missing:
        return _item(
            "qa_gate.7",
            False,
            message=f"{len(missing)} module(s) missing top-level docstring.",
            recommendation=(
                "Add a top-level docstring to each module describing "
                "purpose + dependencies."
            ),
        )
    return _item("qa_gate.7", True)


def _check_8_complex_logic_commented(ctx: CheckContext) -> ChecklistItemResult:
    flagged = ctx.metadata.get("uncommented_complex_blocks", 0)
    if flagged:
        return _item(
            "qa_gate.8",
            False,
            message=f"{flagged} complex logic block(s) without WHY comments.",
            recommendation=(
                "Add inline WHY comments to non-obvious logic (loops > 10 "
                "lines, conditional branching, algorithms)."
            ),
        )
    return _item("qa_gate.8", True)


def _check_9_no_regressions(ctx: CheckContext) -> ChecklistItemResult:
    regressions = int(ctx.metadata.get("regression_count", 0))
    if regressions > 0:
        return _item(
            "qa_gate.9",
            False,
            message=f"{regressions} regression(s) detected in related areas.",
            recommendation=(
                "Fix each regression. If a fix is impossible, document "
                "and seek @architect approval."
            ),
        )
    return _item("qa_gate.9", True)


def _check_10_api_docs(ctx: CheckContext) -> ChecklistItemResult:
    api_added = bool(ctx.metadata.get("api_endpoints_added"))
    api_documented = bool(ctx.metadata.get("api_endpoints_documented"))
    if api_added and not api_documented:
        return _item(
            "qa_gate.10",
            False,
            message="New API endpoints lack documentation.",
            recommendation=(
                "Document method, path, request body, response shape, "
                "and error codes for each new endpoint."
            ),
        )
    return _item("qa_gate.10", True)


def _check_11_security(ctx: CheckContext) -> ChecklistItemResult:
    issues = int(ctx.metadata.get("security_findings", 0))
    if issues > 0:
        return _item(
            "qa_gate.11",
            False,
            message=f"{issues} security finding(s) flagged.",
            recommendation=(
                "Resolve OWASP-class issues (injection, XSS, auth bypass, "
                "broken access control). Block on CRITICAL/HIGH."
            ),
        )
    return _item("qa_gate.11", True)


def _check_12_performance(ctx: CheckContext) -> ChecklistItemResult:
    issues = int(ctx.metadata.get("performance_findings", 0))
    if issues > 0:
        return _item(
            "qa_gate.12",
            False,
            message=f"{issues} performance issue(s) outside acceptable limits.",
            recommendation=(
                "Profile and optimise the offending paths or document the "
                "regression with @architect approval."
            ),
        )
    return _item("qa_gate.12", True)


_CHECKS: list[Callable[[CheckContext], ChecklistItemResult]] = [
    _check_1_tests_pass,
    _check_2_coverage,
    _check_3_no_skipped,
    _check_4_tests_per_function,
    _check_5_ac_met,
    _check_6_doc_comments,
    _check_7_module_docs,
    _check_8_complex_logic_commented,
    _check_9_no_regressions,
    _check_10_api_docs,
    _check_11_security,
    _check_12_performance,
]


class QaGateChecklist:
    """Runnable port of the 12-point QA gate matrix."""

    checklist_id = "qa_gate"

    def run(self, ctx: CheckContext) -> ChecklistResult:
        items = tuple(check(ctx) for check in _CHECKS)
        return ChecklistResult(checklist_id=self.checklist_id, items=items)

    def labels(self) -> dict[str, str]:
        """Return the canonical label map (kept stable for UI rendering)."""
        return dict(QA_GATE_LABELS)
