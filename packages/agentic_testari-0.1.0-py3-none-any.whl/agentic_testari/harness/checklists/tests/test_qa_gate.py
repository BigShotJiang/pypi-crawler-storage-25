"""Tests for the runnable QA gate checklist.

Verifies all 12 items map to the correct labels and fire under the
expected conditions. The full happy-path produces 12/12 passed; targeted
adverse contexts fail one item at a time.
"""

from __future__ import annotations

from agents._shared.harness.checklists import (
    QA_GATE_LABELS,
    QaGateChecklist,
)
from agents._shared.harness.rules.types import CheckContext


def _ok_ctx(**overrides) -> CheckContext:
    base = dict(
        run_id="r-1",
        new_functions=("foo",),
        tests_per_function={"foo": 3},
        documented_functions=frozenset({"foo"}),
        coverage_changed_files=0.95,
        skipped_tests_count=0,
        deleted_tests_count=0,
        bug_fix_has_regression_test=True,
        metadata={
            "failed_test_count": 0,
            "ac_total": 1,
            "ac_met": 1,
            "modules_without_docstring": (),
            "uncommented_complex_blocks": 0,
            "regression_count": 0,
            "api_endpoints_added": False,
            "api_endpoints_documented": False,
            "security_findings": 0,
            "performance_findings": 0,
        },
    )
    for k, v in overrides.items():
        if k == "metadata":
            base["metadata"] = {**base["metadata"], **v}
        else:
            base[k] = v
    return CheckContext(**base)


def test_full_happy_path_passes_all_12():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx())
    assert result.passed
    assert result.total() == 12
    assert result.passed_count() == 12
    assert result.failed_items() == ()


def test_labels_dict_has_all_12_items():
    assert len(QA_GATE_LABELS) == 12
    for i in range(1, 13):
        assert f"qa_gate.{i}" in QA_GATE_LABELS


def test_item_1_failing_tests_block():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"failed_test_count": 2}))
    failed = result.failed_items()
    assert len(failed) == 1
    assert failed[0].item_id == "qa_gate.1"
    assert "2 unit test" in failed[0].message


def test_item_2_low_coverage_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(coverage_changed_files=0.65))
    failed = result.failed_items()
    assert any(i.item_id == "qa_gate.2" for i in failed)
    assert "65.0%" in next(i for i in failed if i.item_id == "qa_gate.2").message


def test_item_3_skipped_tests_block():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(skipped_tests_count=1))
    failed = result.failed_items()
    assert any(i.item_id == "qa_gate.3" for i in failed)


def test_item_4_insufficient_tests_block():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(new_functions=("foo", "bar"), tests_per_function={"foo": 3, "bar": 1})
    )
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.4"]
    assert failed
    assert "bar" in failed[0].message


def test_item_5_unmet_ac_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"ac_total": 3, "ac_met": 1}))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.5"]
    assert failed
    assert "1 of 3" in failed[0].message


def test_item_5_no_ac_passes_silently():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"ac_total": 0, "ac_met": 0}))
    item = next(i for i in result.items if i.item_id == "qa_gate.5")
    assert item.passed


def test_item_6_undocumented_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(documented_functions=frozenset()))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.6"]
    assert failed
    assert "1 new function" in failed[0].message


def test_item_7_modules_missing_docstring_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(metadata={"modules_without_docstring": ("agents/foo.py",)})
    )
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.7"]
    assert failed


def test_item_8_uncommented_complex_logic_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"uncommented_complex_blocks": 3}))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.8"]
    assert failed and "3 complex" in failed[0].message


def test_item_9_regressions_block():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"regression_count": 1}))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.9"]
    assert failed


def test_item_10_undocumented_api_blocks():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(
            metadata={
                "api_endpoints_added": True,
                "api_endpoints_documented": False,
            }
        )
    )
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.10"]
    assert failed


def test_item_10_documented_api_passes():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(
            metadata={
                "api_endpoints_added": True,
                "api_endpoints_documented": True,
            }
        )
    )
    item = next(i for i in result.items if i.item_id == "qa_gate.10")
    assert item.passed


def test_item_11_security_findings_block():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"security_findings": 1}))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.11"]
    assert failed


def test_item_12_performance_findings_block():
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx(metadata={"performance_findings": 1}))
    failed = [i for i in result.failed_items() if i.item_id == "qa_gate.12"]
    assert failed


def test_aggregate_result_helpers():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(
            skipped_tests_count=1,
            metadata={"failed_test_count": 1, "regression_count": 1},
        )
    )
    assert not result.passed
    assert len(result.failed_items()) == 3
    assert len(result.passed_items()) == 9
    assert result.passed_count() == 9
    assert result.total() == 12


def test_label_present_on_every_item():
    """No item ever ships with an empty label."""
    checklist = QaGateChecklist()
    result = checklist.run(_ok_ctx())
    for item in result.items:
        assert item.label
        assert item.item_id in QA_GATE_LABELS
        assert item.label == QA_GATE_LABELS[item.item_id]


def test_recommendation_present_on_every_failure():
    checklist = QaGateChecklist()
    result = checklist.run(
        _ok_ctx(
            coverage_changed_files=0.5,
            skipped_tests_count=1,
            new_functions=("a", "b"),
            tests_per_function={},
            documented_functions=frozenset(),
            metadata={
                "failed_test_count": 1,
                "ac_total": 1,
                "ac_met": 0,
                "modules_without_docstring": ("m.py",),
                "uncommented_complex_blocks": 1,
                "regression_count": 1,
                "api_endpoints_added": True,
                "api_endpoints_documented": False,
                "security_findings": 1,
                "performance_findings": 1,
            },
        )
    )
    for item in result.failed_items():
        assert item.recommendation, f"{item.item_id} missing recommendation"


def test_checklist_id_stable():
    assert QaGateChecklist.checklist_id == "qa_gate"
    result = QaGateChecklist().run(_ok_ctx())
    assert result.checklist_id == "qa_gate"


def test_labels_method_returns_copy():
    checklist = QaGateChecklist()
    labels = checklist.labels()
    labels["qa_gate.1"] = "MUTATED"
    assert checklist.labels()["qa_gate.1"] == QA_GATE_LABELS["qa_gate.1"]
