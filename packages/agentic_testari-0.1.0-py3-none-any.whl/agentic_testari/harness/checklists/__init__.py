"""Checklists as runnable code (EPIC N.8).

Ports `.aios-core/development/checklists/*.md` to executable Python. Each
checklist item becomes a runtime check that takes a CheckContext (from
N.4 rules engine — same shape) and returns a per-item pass/fail result.

The most important checklist is the 12-point QA gate matrix (Pillar 1-4
Quality Foundation) — ported here line-by-line so test results match the
dev-time markdown checklist exactly.

Usage:
    from agents._shared.harness.checklists import (
        QaGateChecklist, ChecklistResult,
    )
    from agents._shared.harness.rules import CheckContext

    checklist = QaGateChecklist()
    result = checklist.run(ctx)
    # result.passed == bool
    # result.items[i].label, .passed, .recommendation
    # result.failed_items() → only failed
"""

from agents._shared.harness.checklists.qa_gate import (
    QA_GATE_LABELS,
    QaGateChecklist,
)
from agents._shared.harness.checklists.types import (
    ChecklistError,
    ChecklistItemResult,
    ChecklistResult,
)

__all__ = [
    "QaGateChecklist",
    "QA_GATE_LABELS",
    "ChecklistResult",
    "ChecklistItemResult",
    "ChecklistError",
]

__version__ = "1.0.0"
