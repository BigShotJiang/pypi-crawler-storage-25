"""Resource path resolution for both dev tree and wheel installs.

Strategy:
    1. Dev tree (default during development): walk up from this file until
       we find a directory containing `.aios-core/` and `.claude/`.
    2. Wheel install (future, post-Cython packaging): resources are bundled
       under `agents/_shared/harness/_resources/`. Detected via
       `importlib.resources` if the directory exists alongside this module.

The dev-tree path covers Phase 1.5 sprint work. The wheel path is wired now
so M.4 (npm CLI / Python wheel) can drop bundled resources into _resources/
without changing this loader.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional


_DEV_MARKERS = (".aios-core", ".claude")


class BundleRoot:
    """Resolves the root directory holding `.aios-core/` and `.claude/`."""

    def __init__(self, root: Path):
        self.root = root.resolve()

    @property
    def aios_core(self) -> Path:
        return self.root / ".aios-core"

    @property
    def claude_dir(self) -> Path:
        return self.root / ".claude"

    def __repr__(self) -> str:
        return f"BundleRoot({self.root})"


def _walk_up_for_dev_root(start: Path) -> Optional[Path]:
    """Walk up from `start` looking for a directory containing dev markers."""
    cur = start.resolve()
    for _ in range(8):
        if all((cur / m).exists() for m in _DEV_MARKERS):
            return cur
        if cur.parent == cur:
            return None
        cur = cur.parent
    return None


def _wheel_bundle_root() -> Optional[Path]:
    """Look for bundled `_resources/` next to this module (wheel install)."""
    here = Path(__file__).resolve().parent
    candidate = here / "_resources"
    if candidate.is_dir() and (candidate / ".aios-core").exists():
        return candidate
    return None


def resolve_bundle_root(explicit: Optional[Path] = None) -> BundleRoot:
    """Find the root directory holding the AIOS resources.

    Resolution order:
        1. `explicit` argument if provided (used by tests / CLI overrides).
        2. Bundled `_resources/` directory next to this module (wheel mode).
        3. Walk upward from this file until `.aios-core/` and `.claude/` found.

    Raises FileNotFoundError if no candidate path is valid.
    """
    if explicit is not None:
        root = Path(explicit).resolve()
        if not all((root / m).exists() for m in _DEV_MARKERS):
            raise FileNotFoundError(
                f"Explicit bundle root {root} missing required markers "
                f"{_DEV_MARKERS}"
            )
        return BundleRoot(root)

    wheel = _wheel_bundle_root()
    if wheel is not None:
        return BundleRoot(wheel)

    dev = _walk_up_for_dev_root(Path(__file__).resolve().parent)
    if dev is not None:
        return BundleRoot(dev)

    raise FileNotFoundError(
        "Unable to locate AIOS bundle root (no `.aios-core/` + `.claude/` found "
        "either bundled with the wheel or in any parent directory)."
    )
