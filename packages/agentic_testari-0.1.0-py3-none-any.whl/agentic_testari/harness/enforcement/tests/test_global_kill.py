"""Tests for GlobalKillFetcher (EPIC Q tier-4 client poller)."""

from __future__ import annotations

import pytest

from agents._shared.harness.enforcement import (
    GlobalKillFetcher,
    KillSwitch,
    KillTier,
)


class _StubAdminClient:
    """Pre-scripted responses for the global kill endpoint."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = 0

    def fetch_global_kill(self):
        self.calls += 1
        if not self.script:
            raise RuntimeError("no more scripted responses")
        action = self.script.pop(0)
        if isinstance(action, Exception):
            raise action
        return action


def _fetcher(client):
    return GlobalKillFetcher(kill_switch=KillSwitch(), client=client)


# ---- happy paths ----


def test_inactive_response_keeps_running():
    fetcher = _fetcher(_StubAdminClient([{"active": False, "ts": ""}]))
    fetcher.tick()
    assert fetcher.last_active is False
    assert fetcher._kill_switch.is_running()


def test_active_response_trips_tier_4():
    fetcher = _fetcher(
        _StubAdminClient([{"active": True, "ts": "2026-04-28T00:00:00Z"}])
    )
    fetcher.tick()
    assert fetcher.last_active is True
    snap = fetcher._kill_switch.snapshot()
    assert snap["running"] is False
    assert snap["tiers_off"][0]["tier"] == 4
    assert "global kill flag active" in snap["tiers_off"][0]["reason"]


def test_recovery_clears_tier_4():
    """Once the server flips back to inactive, tier 4 re-arms."""
    fetcher = _fetcher(
        _StubAdminClient(
            [
                {"active": True, "ts": "t1"},
                {"active": False, "ts": ""},
            ]
        )
    )
    fetcher.tick()
    assert not fetcher._kill_switch.is_running()
    fetcher.tick()
    assert fetcher._kill_switch.is_running()


def test_repeated_active_does_not_overwrite_record():
    """Multiple ticks while flag is on should not mutate the original record."""
    fetcher = _fetcher(
        _StubAdminClient(
            [
                {"active": True, "ts": "t1"},
                {"active": True, "ts": "t2"},
            ]
        )
    )
    fetcher.tick()
    first = fetcher._kill_switch.reason_for(KillTier.GLOBAL)
    fetcher.tick()
    second = fetcher._kill_switch.reason_for(KillTier.GLOBAL)
    assert first is second  # same KillRecord, no rewrite


# ---- failure modes ----


def test_network_error_does_not_trip_tier_4():
    """If Cloudflare is down, customers must NOT be blocked."""
    fetcher = _fetcher(_StubAdminClient([RuntimeError("network down")]))
    fetcher.tick()
    assert fetcher._kill_switch.is_running()


def test_network_error_after_active_keeps_existing_record():
    fetcher = _fetcher(
        _StubAdminClient(
            [
                {"active": True, "ts": "t1"},
                RuntimeError("flake"),
            ]
        )
    )
    fetcher.tick()
    assert not fetcher._kill_switch.is_running()
    fetcher.tick()
    # Still tripped — network error doesn't clear the existing flag.
    assert not fetcher._kill_switch.is_running()


def test_tick_records_last_checked_at():
    fetcher = _fetcher(_StubAdminClient([{"active": False, "ts": ""}]))
    assert fetcher.last_checked_at is None
    fetcher.tick()
    assert fetcher.last_checked_at is not None
    assert fetcher.last_checked_at.tzinfo is not None


def test_request_stop_is_set():
    fetcher = _fetcher(_StubAdminClient([]))
    assert fetcher._stop_requested is False
    fetcher.request_stop()
    assert fetcher._stop_requested is True
