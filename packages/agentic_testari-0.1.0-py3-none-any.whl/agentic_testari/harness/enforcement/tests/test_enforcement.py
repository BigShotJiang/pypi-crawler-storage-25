"""Tests for the 4-tier kill switch + heartbeat enforcer."""

from __future__ import annotations

from dataclasses import dataclass

import pytest

from agents._shared.harness.enforcement import (
    HeartbeatConfig,
    HeartbeatEnforcer,
    HeartbeatStatus,
    KillSwitch,
    KillSwitchTripped,
    KillTier,
)


# ---- KillSwitch ----


def test_default_kill_switch_is_running():
    s = KillSwitch()
    assert s.is_running()
    assert s.highest_off_tier() is None
    s.assert_running()  # no exception


def test_tier_1_off_trips_assert():
    s = KillSwitch()
    s.tier_1_workflow_off(actor="admin@org", reason="paused")
    assert not s.is_running()
    with pytest.raises(KillSwitchTripped) as exc_info:
        s.assert_running()
    assert exc_info.value.tier is KillTier.WORKFLOW


def test_higher_tier_overrides_lower():
    """Tier 4 OFF + Tier 1 OFF → exception cites Tier 4 (highest)."""
    s = KillSwitch()
    s.tier_1_workflow_off(actor="x", reason="pause")
    s.tier_4_global_off(actor="cloudflare", reason="emergency")
    with pytest.raises(KillSwitchTripped) as exc_info:
        s.assert_running()
    assert exc_info.value.tier is KillTier.GLOBAL


def test_tier_on_rearms_only_that_tier():
    s = KillSwitch()
    s.tier_3_license_off(actor="server", reason="revoked")
    s.tier_4_global_off(actor="cloudflare", reason="kill")
    assert s.tier_on(KillTier.GLOBAL) is True
    # Tier 3 is still OFF.
    assert not s.is_running()
    with pytest.raises(KillSwitchTripped) as exc_info:
        s.assert_running()
    assert exc_info.value.tier is KillTier.LICENSE


def test_tier_on_returns_false_when_not_off():
    s = KillSwitch()
    assert s.tier_on(KillTier.WORKFLOW) is False


def test_record_captures_actor_reason_timestamp():
    s = KillSwitch()
    rec = s.tier_2_org_off(actor="alice@org", reason="billing failed")
    assert rec.actor == "alice@org"
    assert rec.reason == "billing failed"
    assert rec.tier is KillTier.ORG
    assert rec.tripped_at.tzinfo is not None


def test_reason_for_returns_record_or_none():
    s = KillSwitch()
    assert s.reason_for(KillTier.ORG) is None
    s.tier_2_org_off(actor="x", reason="r")
    assert s.reason_for(KillTier.ORG) is not None


def test_snapshot_serialises_state():
    s = KillSwitch()
    s.tier_3_license_off(actor="server", reason="revoked")
    snap = s.snapshot()
    assert snap["running"] is False
    assert len(snap["tiers_off"]) == 1
    assert snap["tiers_off"][0]["tier"] == 3
    assert snap["tiers_off"][0]["tier_name"] == "LICENSE"
    assert snap["tiers_off"][0]["reason"] == "revoked"


def test_kill_switch_tripped_message_includes_tier_name():
    s = KillSwitch()
    s.tier_3_license_off(actor="server", reason="x")
    try:
        s.assert_running()
    except KillSwitchTripped as exc:
        assert "TIER 3" in str(exc)
        assert "LICENSE" in str(exc)


def test_default_reason_when_empty():
    s = KillSwitch()
    rec = s.tier_off(KillTier.WORKFLOW, actor="x", reason="")
    assert rec.reason == "(no reason given)"


# ---- HeartbeatEnforcer ----


@dataclass
class _OkResponse:
    ok: bool = True
    revoked: bool = False
    last_seen: str = "2026-04-28T00:00:00Z"
    tier: str = "pro"


@dataclass
class _RevokedResponse:
    ok: bool = False
    revoked: bool = True
    last_seen: str = ""
    tier: str = ""


class _StubClient:
    """Records heartbeat calls; responds per the supplied script."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def heartbeat(self, *, token, activation_id, hardware_id):
        self.calls.append((token, activation_id, hardware_id))
        if not self.script:
            raise RuntimeError("no more scripted responses")
        action = self.script.pop(0)
        if isinstance(action, Exception):
            raise action
        return action


def _enforcer(client, *, threshold=2):
    return HeartbeatEnforcer(
        kill_switch=KillSwitch(),
        client=client,
        token="lic-test",
        activation_id="act-1",
        hardware_id="hwid-1",
        config=HeartbeatConfig(grace_threshold=threshold),
    )


def test_tick_ok_returns_ok_status():
    client = _StubClient([_OkResponse()])
    enforcer = _enforcer(client)
    assert enforcer.tick() is HeartbeatStatus.OK
    assert enforcer.last_status is HeartbeatStatus.OK
    assert enforcer.consecutive_failures == 0


def test_tick_revoked_trips_tier_3():
    client = _StubClient([_RevokedResponse()])
    enforcer = _enforcer(client)
    assert enforcer.tick() is HeartbeatStatus.REVOKED
    snap = enforcer._kill_switch.snapshot()
    assert snap["running"] is False
    assert snap["tiers_off"][0]["tier"] == 3
    assert "revoked" in snap["tiers_off"][0]["reason"]


def test_tick_unreachable_increments_failures():
    client = _StubClient([RuntimeError("network down")])
    enforcer = _enforcer(client, threshold=3)
    assert enforcer.tick() is HeartbeatStatus.UNREACHABLE
    assert enforcer.consecutive_failures == 1
    # Below threshold, kill switch still running.
    assert enforcer._kill_switch.is_running()


def test_tick_unreachable_past_threshold_trips_tier_3():
    client = _StubClient([
        RuntimeError("down 1"),
        RuntimeError("down 2"),
        RuntimeError("down 3"),
    ])
    enforcer = _enforcer(client, threshold=2)
    enforcer.tick()
    enforcer.tick()
    enforcer.tick()
    assert enforcer.consecutive_failures == 3
    snap = enforcer._kill_switch.snapshot()
    assert snap["running"] is False
    assert snap["tiers_off"][0]["tier"] == 3
    assert "unreachable" in snap["tiers_off"][0]["reason"]


def test_tick_recovery_resets_failure_counter():
    client = _StubClient([
        RuntimeError("flake"),
        _OkResponse(),
    ])
    enforcer = _enforcer(client, threshold=5)
    enforcer.tick()
    assert enforcer.consecutive_failures == 1
    enforcer.tick()
    assert enforcer.consecutive_failures == 0
    assert enforcer.last_status is HeartbeatStatus.OK


def test_tick_no_token_returns_not_configured():
    enforcer = HeartbeatEnforcer(
        kill_switch=KillSwitch(),
        client=_StubClient([]),
        token="",
        activation_id="",
        hardware_id="hwid",
    )
    assert enforcer.tick() is HeartbeatStatus.NOT_CONFIGURED


def test_kill_switch_stays_off_after_recovery():
    """Once tripped, the kill switch does NOT auto-recover on heartbeat OK.

    Operators must re-arm via admin portal. Auto-recovery would mask
    flaky-network → policy-bypass attacks.
    """
    client = _StubClient([
        RuntimeError("d1"),
        RuntimeError("d2"),
        RuntimeError("d3"),
        _OkResponse(),
    ])
    enforcer = _enforcer(client, threshold=2)
    for _ in range(3):
        enforcer.tick()
    assert not enforcer._kill_switch.is_running()
    enforcer.tick()  # OK response
    # KillSwitch tier 3 still OFF — recovery is operator-only.
    assert not enforcer._kill_switch.is_running()
