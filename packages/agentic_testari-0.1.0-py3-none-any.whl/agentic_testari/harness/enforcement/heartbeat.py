"""HeartbeatEnforcer — call the license server, trip the kill switch on revoke.

Wraps the M.7 LicenseClient and runs a long-lived loop:

    every `interval_seconds`:
        try heartbeat()
        if revoked:        kill_switch.tier_3_license_off(...)
        if exception:      grace_failures += 1
        if grace_failures > grace_threshold:
            kill_switch.tier_3_license_off(... "license server unreachable")

Most enforcers are spawned once per process. The loop is async so it
co-exists with the FastAPI dashboard / workflow-engine without
blocking.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, Protocol

from agents._shared.harness.enforcement.kill_switch import (
    KillSwitch,
    KillTier,
)

logger = logging.getLogger(__name__)


class _LicenseClientProto(Protocol):
    def heartbeat(self, *, token: str, activation_id: str, hardware_id: str): ...


class HeartbeatStatus(str, Enum):
    OK = "ok"
    REVOKED = "revoked"
    UNREACHABLE = "unreachable"
    NOT_CONFIGURED = "not_configured"


@dataclass(frozen=True)
class HeartbeatConfig:
    interval_seconds: float = 300.0  # 5 minutes
    grace_threshold: int = 3          # how many consecutive failures before tripping
    initial_delay_seconds: float = 0.0


class HeartbeatEnforcer:
    """Periodically validates the active license; trips kill switch on revoke."""

    def __init__(
        self,
        *,
        kill_switch: KillSwitch,
        client: _LicenseClientProto,
        token: str,
        activation_id: str,
        hardware_id: str,
        config: Optional[HeartbeatConfig] = None,
    ):
        self._kill_switch = kill_switch
        self._client = client
        self._token = token
        self._activation_id = activation_id
        self._hardware_id = hardware_id
        self._config = config or HeartbeatConfig()
        self._consecutive_failures = 0
        self._last_status: Optional[HeartbeatStatus] = None
        self._last_checked_at: Optional[datetime] = None
        self._stop_requested = False

    @property
    def last_status(self) -> Optional[HeartbeatStatus]:
        return self._last_status

    @property
    def last_checked_at(self) -> Optional[datetime]:
        return self._last_checked_at

    @property
    def consecutive_failures(self) -> int:
        return self._consecutive_failures

    def request_stop(self) -> None:
        self._stop_requested = True

    # ---- single-tick API ----

    def tick(self) -> HeartbeatStatus:
        """Run one heartbeat cycle. Public for testing.

        Returns the resulting HeartbeatStatus and updates internal counters.
        """
        if not self._token or not self._activation_id:
            self._last_status = HeartbeatStatus.NOT_CONFIGURED
            self._last_checked_at = datetime.now(timezone.utc)
            return HeartbeatStatus.NOT_CONFIGURED

        try:
            response = self._client.heartbeat(
                token=self._token,
                activation_id=self._activation_id,
                hardware_id=self._hardware_id,
            )
        except Exception as exc:
            self._consecutive_failures += 1
            self._last_status = HeartbeatStatus.UNREACHABLE
            self._last_checked_at = datetime.now(timezone.utc)
            if self._consecutive_failures > self._config.grace_threshold:
                self._kill_switch.tier_3_license_off(
                    actor="heartbeat-enforcer",
                    reason=(
                        f"license server unreachable for "
                        f"{self._consecutive_failures} consecutive heartbeats: {exc}"
                    ),
                )
            else:
                logger.warning(
                    "heartbeat failed (attempt %d/%d): %s",
                    self._consecutive_failures,
                    self._config.grace_threshold,
                    exc,
                )
            return HeartbeatStatus.UNREACHABLE

        # Successful HTTP round-trip — reset failure counter.
        self._consecutive_failures = 0
        self._last_checked_at = datetime.now(timezone.utc)

        if getattr(response, "revoked", False):
            self._kill_switch.tier_3_license_off(
                actor="license-server",
                reason="license revoked via heartbeat response",
            )
            self._last_status = HeartbeatStatus.REVOKED
            return HeartbeatStatus.REVOKED

        # If the kill switch was tripped due to past unreachable cycles,
        # leave it OFF — operator must re-arm via admin portal. We do NOT
        # auto-recover, because a flaky network rebound is a worse failure
        # mode than a stuck-OFF state that an admin clears.
        self._last_status = HeartbeatStatus.OK
        return HeartbeatStatus.OK

    # ---- long-running loop ----

    async def run_forever(self) -> None:
        if self._config.initial_delay_seconds > 0:
            await asyncio.sleep(self._config.initial_delay_seconds)

        while not self._stop_requested:
            try:
                self.tick()
            except Exception as exc:
                logger.error("heartbeat loop tick raised: %s", exc)
            await asyncio.sleep(self._config.interval_seconds)
