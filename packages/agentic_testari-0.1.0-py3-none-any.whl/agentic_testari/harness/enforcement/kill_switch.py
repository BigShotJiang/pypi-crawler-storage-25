"""4-tier kill switch.

The four tiers, ranked by blast radius:

    TIER 1  per-workflow          surgical                 admin portal
    TIER 2  per-org                org-wide                 admin portal
    TIER 3  per-license            license server signal    M.7 heartbeat
    TIER 4  global                 every customer           Cloudflare KV

A higher tier OFF overrides every lower tier ON: if TIER 4 is OFF, no
amount of TIER 1/2/3 ON saves the run. `assert_running()` raises
KillSwitchTripped naming the highest tier that is OFF.

Each tier records WHY it was tripped (reason, who, when). Reactivating
a tier (calling `tier_X_on`) wipes that reason — the audit trail lives
in the storage layer (M.1), not in this in-memory object.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import IntEnum
from typing import Optional


class KillTier(IntEnum):
    """Tiers, ordered by blast radius (1 = smallest)."""

    WORKFLOW = 1
    ORG = 2
    LICENSE = 3
    GLOBAL = 4


@dataclass(frozen=True)
class KillRecord:
    """Why a tier is currently OFF."""

    tier: KillTier
    actor: str
    reason: str
    tripped_at: datetime


class KillSwitchTripped(Exception):
    """Raised by `assert_running()` when any tier is OFF.

    `tier` names the highest tier that is OFF — the one the operator
    needs to flip back ON before runs resume.
    """

    def __init__(self, record: KillRecord):
        self.record = record
        self.tier = record.tier
        super().__init__(
            f"Kill switch tripped at TIER {record.tier.value} "
            f"({record.tier.name}) by {record.actor}: {record.reason}"
        )


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class KillSwitch:
    """Process-local kill switch with all four tiers ON by default."""

    _records: dict[KillTier, KillRecord] = field(default_factory=dict)

    # ---- predicates ----

    def is_running(self) -> bool:
        return not self._records

    def is_tier_off(self, tier: KillTier) -> bool:
        return tier in self._records

    def highest_off_tier(self) -> Optional[KillTier]:
        if not self._records:
            return None
        return max(self._records.keys())

    def reason_for(self, tier: KillTier) -> Optional[KillRecord]:
        return self._records.get(tier)

    def assert_running(self) -> None:
        """Raise KillSwitchTripped if any tier is OFF."""
        top = self.highest_off_tier()
        if top is None:
            return
        raise KillSwitchTripped(self._records[top])

    # ---- mutators ----

    def tier_off(
        self,
        tier: KillTier,
        *,
        actor: str = "system",
        reason: str = "",
    ) -> KillRecord:
        record = KillRecord(
            tier=tier, actor=actor, reason=reason or "(no reason given)",
            tripped_at=_utc_now(),
        )
        self._records[tier] = record
        return record

    def tier_on(self, tier: KillTier) -> bool:
        """Re-arm a tier. Returns True if it was previously OFF."""
        return self._records.pop(tier, None) is not None

    # ---- per-tier helpers (sugar) ----

    def tier_1_workflow_off(self, actor: str, reason: str) -> KillRecord:
        return self.tier_off(KillTier.WORKFLOW, actor=actor, reason=reason)

    def tier_2_org_off(self, actor: str, reason: str) -> KillRecord:
        return self.tier_off(KillTier.ORG, actor=actor, reason=reason)

    def tier_3_license_off(self, actor: str, reason: str) -> KillRecord:
        return self.tier_off(KillTier.LICENSE, actor=actor, reason=reason)

    def tier_4_global_off(self, actor: str, reason: str) -> KillRecord:
        return self.tier_off(KillTier.GLOBAL, actor=actor, reason=reason)

    # ---- introspection ----

    def snapshot(self) -> dict:
        return {
            "running": self.is_running(),
            "tiers_off": [
                {
                    "tier": r.tier.value,
                    "tier_name": r.tier.name,
                    "actor": r.actor,
                    "reason": r.reason,
                    "tripped_at": r.tripped_at.isoformat(),
                }
                for r in sorted(self._records.values(), key=lambda x: x.tier)
            ],
        }
